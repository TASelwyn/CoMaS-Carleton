package com.ibm.media.parser.video;

import javax.media.MediaException;

class BadDataException extends MediaException {
  BadDataException() {}
  
  BadDataException(String reason) {
    super(reason);
  }
}
