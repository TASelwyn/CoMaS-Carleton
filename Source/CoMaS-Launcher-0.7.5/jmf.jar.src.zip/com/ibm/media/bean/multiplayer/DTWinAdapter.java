/*    */ package com.ibm.media.bean.multiplayer;
/*    */ 
/*    */ import java.awt.Frame;
/*    */ import java.awt.event.WindowAdapter;
/*    */ import java.awt.event.WindowEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DTWinAdapter
/*    */   extends WindowAdapter
/*    */ {
/*    */   boolean doExit = false;
/*    */   
/*    */   public DTWinAdapter(boolean close) {
/* 19 */     this.doExit = close;
/*    */   }
/*    */ 
/*    */   
/*    */   public void windowClosing(WindowEvent evt) {
/* 24 */     Frame f = (Frame)evt.getSource();
/* 25 */     f.setVisible(false);
/* 26 */     if (this.doExit) {
/* 27 */       f.dispose();
/* 28 */       System.exit(0);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\bean\multiplayer\DTWinAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */