package com.ibm.media.bean.multiplayer;

import java.awt.image.RGBImageFilter;

class GrayFilter extends RGBImageFilter {
  private int darkness = -5263441;
  
  public GrayFilter() {
    this.canFilterIndexColorModel = true;
  }
  
  public GrayFilter(int darkness) {
    this();
    this.darkness = darkness;
  }
  
  public int filterRGB(int x, int y, int rgb) {
    return rgb & this.darkness;
  }
}
