/*      */ package com.ibm.media.bean.multiplayer;
/*      */ 
/*      */ import java.applet.Applet;
/*      */ import java.applet.AppletContext;
/*      */ import java.awt.BorderLayout;
/*      */ import java.awt.Button;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.FlowLayout;
/*      */ import java.awt.GridBagConstraints;
/*      */ import java.awt.GridBagLayout;
/*      */ import java.awt.GridLayout;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Panel;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.ComponentEvent;
/*      */ import java.awt.event.ComponentListener;
/*      */ import java.beans.Beans;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.Serializable;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.util.Vector;
/*      */ import javax.media.ClockStartedError;
/*      */ import javax.media.ControllerEvent;
/*      */ import javax.media.ControllerListener;
/*      */ import javax.media.Time;
/*      */ import javax.media.bean.playerbean.MediaPlayer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MultiPlayerBean
/*      */   extends Panel
/*      */   implements ActionListener, Serializable, ControllerListener, ComponentListener
/*      */ {
/*      */   transient Panel buttonPanel;
/*      */   transient Panel gifPanel;
/*      */   transient Panel scrollPanel;
/*      */   transient Panel utilPanel;
/*      */   transient Panel videoPanel;
/*      */   transient ImageButton up;
/*      */   transient ImageButton down;
/*      */   transient ImageButton left;
/*      */   transient ImageButton right;
/*  188 */   private MediaPlayer currentPlayer = null;
/*      */   transient Button infoButton;
/*  190 */   transient GridBagLayout gridbag = new GridBagLayout();
/*  191 */   transient GridBagConstraints constraint = new GridBagConstraints();
/*  192 */   private final String infoWindow = JMFUtil.getString("Info");
/*  193 */   private URL currentU = null;
/*      */ 
/*      */   
/*      */   private boolean displayURL = false;
/*      */   
/*      */   private boolean panelVisible = true;
/*      */   
/*      */   private boolean fitVideo = true;
/*      */   
/*      */   private boolean looping = true;
/*      */   
/*      */   private boolean sequential = true;
/*      */   
/*  206 */   private URL mpCodeBase = null;
/*  207 */   private AppletContext mpAppletContext = null;
/*      */   private int currentNum;
/*  209 */   private int numOfClips = 0;
/*  210 */   protected int numOfMGroups = 0;
/*  211 */   private int preferredHeight = 400;
/*  212 */   private int preferredWidth = 300;
/*      */   private String linksString;
/*      */   private String[] mediaNames;
/*      */   private String[] links;
/*      */   public MediaGroup[] mGroups;
/*  217 */   private int maxMediaGroup = 10;
/*      */   private boolean loadOnInit = false;
/*      */   private boolean fixAspectRatio = true;
/*  220 */   private int startingButton = 1;
/*  221 */   private String buttonPosition = JMFUtil.getString("SOUTH");
/*  222 */   private int tabsize = 16;
/*      */   
/*      */   private boolean msVM = false;
/*      */   
/*  226 */   private PropertyChangeSupport changes = new PropertyChangeSupport(this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MultiPlayerBean() {
/*  239 */     setup();
/*      */   }
/*      */ 
/*      */   
/*      */   private void getContext(Object parent) {
/*  244 */     if (parent == null) {
/*  245 */       parent = getParent();
/*      */     }
/*  247 */     if (this.mpCodeBase != null)
/*      */       return; 
/*  249 */     if (parent instanceof Applet) {
/*      */       
/*  251 */       this.mpCodeBase = ((Applet)parent).getCodeBase();
/*  252 */       this.mpAppletContext = ((Applet)parent).getAppletContext();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setup() {
/*  264 */     getContext(null);
/*      */     
/*  266 */     if (!JMFUtil.msVersion()) {
/*      */       
/*  268 */       this.msVM = false;
/*  269 */       doDebug("Not Microsoft VM");
/*      */     }
/*      */     else {
/*      */       
/*  273 */       this.msVM = true;
/*  274 */       doDebug("Microsoft VM");
/*      */     } 
/*      */ 
/*      */     
/*  278 */     setLayout(new BorderLayout(0, 0));
/*  279 */     setBackground(getBackground());
/*      */     
/*  281 */     this.currentPlayer = null;
/*      */ 
/*      */     
/*  284 */     this.buttonPanel = new Panel();
/*  285 */     this.buttonPanel.setLayout(new BorderLayout(0, 0));
/*  286 */     this.buttonPanel.setBackground(getBackground());
/*  287 */     this.buttonPanel.setVisible(false);
/*      */ 
/*      */ 
/*      */     
/*  291 */     this.gifPanel = new Panel();
/*  292 */     this.gifPanel.setBackground(getBackground());
/*  293 */     this.gifPanel.setVisible(false);
/*  294 */     this.gifPanel.addComponentListener(this);
/*      */     
/*  296 */     this.scrollPanel = new Panel();
/*  297 */     this.scrollPanel.setLayout(new BorderLayout(0, 0));
/*  298 */     this.scrollPanel.setBackground(getBackground());
/*  299 */     this.scrollPanel.add("Center", this.gifPanel);
/*      */     
/*  301 */     this.buttonPanel.add("Center", this.scrollPanel);
/*      */ 
/*      */     
/*  304 */     this.infoButton = new Button(JMFUtil.getString("Link"));
/*  305 */     this.infoButton.setActionCommand("info");
/*  306 */     this.infoButton.addActionListener(this);
/*  307 */     this.infoButton.setEnabled(true);
/*  308 */     this.infoButton.setVisible(true);
/*  309 */     this.utilPanel = new Panel();
/*  310 */     this.utilPanel.setBackground(getBackground());
/*  311 */     this.utilPanel.setVisible(false);
/*  312 */     this.utilPanel.add("Center", this.infoButton);
/*      */ 
/*      */ 
/*      */     
/*  316 */     this.videoPanel = new Panel(this) {
/*      */         public Insets insets() {
/*  318 */           return new Insets(10, 10, 10, 10);
/*      */         } private final MultiPlayerBean this$0;
/*      */       };
/*  321 */     this.videoPanel.setBounds((getBounds()).x, (getBounds()).y, (getSize()).width, (getSize()).height - (this.buttonPanel.getSize()).height);
/*  322 */     this.videoPanel.setLayout(new BorderLayout(0, 0));
/*  323 */     this.videoPanel.setBackground(getBackground());
/*  324 */     this.videoPanel.setVisible(true);
/*  325 */     this.utilPanel.setVisible(true);
/*      */     
/*  327 */     this.buttonPanel.setVisible(true);
/*  328 */     this.videoPanel.validate();
/*  329 */     setLayout(new BorderLayout());
/*      */ 
/*      */     
/*  332 */     position();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void position() {
/*  343 */     remove(this.videoPanel);
/*  344 */     remove(this.buttonPanel);
/*      */     
/*  346 */     if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("WEST"))) {
/*      */       
/*  348 */       add("Center", this.videoPanel);
/*  349 */       add("West", this.buttonPanel);
/*      */     }
/*  351 */     else if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("EAST"))) {
/*      */       
/*  353 */       add("Center", this.videoPanel);
/*  354 */       add("East", this.buttonPanel);
/*      */     }
/*  356 */     else if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("SOUTH"))) {
/*      */       
/*  358 */       add("Center", this.videoPanel);
/*  359 */       add("South", this.buttonPanel);
/*      */     }
/*  361 */     else if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("NORTH"))) {
/*      */       
/*  363 */       add("Center", this.videoPanel);
/*  364 */       add("North", this.buttonPanel);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  369 */       add("Center", this.videoPanel);
/*      */     } 
/*  371 */     updateGifPanel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void createLeftRight(int height) {
/*  385 */     this.left = new ImageButton("<", true, this.tabsize, height);
/*  386 */     this.right = new ImageButton(">", true, this.tabsize, height);
/*  387 */     this.left.setActionCommand("left");
/*  388 */     this.right.setActionCommand("right");
/*  389 */     this.left.addActionListener(this);
/*  390 */     this.right.addActionListener(this);
/*  391 */     this.left.setBackground(Color.lightGray);
/*  392 */     this.right.setBackground(Color.lightGray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void createUpDown(int width) {
/*  404 */     this.up = new ImageButton("UP", true, width, this.tabsize);
/*  405 */     this.down = new ImageButton("DOWN", true, width, this.tabsize);
/*  406 */     this.up.setActionCommand("up");
/*  407 */     this.down.setActionCommand("down");
/*  408 */     this.up.addActionListener(this);
/*  409 */     this.down.addActionListener(this);
/*  410 */     this.up.setBackground(Color.lightGray);
/*  411 */     this.down.setBackground(Color.lightGray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void start() {
/*  423 */     doDebug("in start()");
/*      */     
/*  425 */     if (this.loadOnInit)
/*      */     {
/*  427 */       for (int i = 0; i < this.numOfMGroups; i++)
/*      */       {
/*  429 */         this.mGroups[i].setPlayer(formPlayer((this.mGroups[i]).mediaName));
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  435 */     this.videoPanel.setBounds((getBounds()).x, (getBounds()).y, (getSize()).width, (getSize()).height - (this.buttonPanel.getSize()).height);
/*  436 */     this.videoPanel.setVisible(true);
/*      */ 
/*      */     
/*  439 */     pauseCurrent();
/*  440 */     setPlayer(1);
/*      */     
/*  442 */     validate();
/*  443 */     repaint();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void stop() {
/*  454 */     doDebug("in stop()");
/*      */     
/*  456 */     if (this.currentPlayer != null) {
/*  457 */       this.currentPlayer.stop();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void destroy() {
/*  470 */     doDebug("in destroy()");
/*      */     
/*  472 */     this.currentPlayer.stop();
/*  473 */     this.currentPlayer.close();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  481 */     this.numOfClips = 0;
/*  482 */     System.out.println("out destroy");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void controllerUpdate(ControllerEvent evt) {
/*  497 */     if (evt instanceof javax.media.EndOfMediaEvent) {
/*      */ 
/*      */ 
/*      */       
/*  501 */       if (!this.looping && this.currentPlayer != null)
/*      */       {
/*  503 */         this.currentPlayer.setMediaTime(new Time(0L));
/*      */       }
/*  505 */       if (this.sequential)
/*      */       {
/*  507 */         nextPlayer();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void actionPerformed(ActionEvent e) {
/*  523 */     if (e.getActionCommand().equalsIgnoreCase("info") && this.mpAppletContext != null) {
/*      */       
/*  525 */       doDebug("Info: currentNum = " + this.currentNum);
/*  526 */       if (this.mGroups[this.currentNum - 1].getRelated() != null) {
/*      */         
/*  528 */         Vector links = this.mGroups[this.currentNum - 1].getRelated();
/*  529 */         int numLinks = links.size();
/*  530 */         double currentTime = this.currentPlayer.getMediaTime().getSeconds();
/*      */ 
/*      */         
/*  533 */         for (int i = 0; i < numLinks; i++)
/*      */         {
/*  535 */           RelatedLink l = links.elementAt(i);
/*  536 */           if (l.startTime <= currentTime)
/*      */           {
/*  538 */             if (l.stopTime == 0L || l.stopTime >= currentTime)
/*      */             {
/*  540 */               this.mpAppletContext.showDocument(l.uLink, this.infoWindow);
/*  541 */               i = numLinks;
/*      */             }
/*      */           
/*      */           }
/*      */         }
/*      */       
/*      */       } 
/*  548 */     } else if (e.getActionCommand().equalsIgnoreCase("left") || e.getActionCommand().equalsIgnoreCase("up")) {
/*      */       
/*  550 */       shiftButtons(-1);
/*      */     } 
/*  552 */     if (e.getActionCommand().equalsIgnoreCase("right") || e.getActionCommand().equalsIgnoreCase("down")) {
/*      */       
/*  554 */       shiftButtons(1);
/*      */     } else {
/*      */       int buttonIndex;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  562 */         buttonIndex = Integer.parseInt(e.getActionCommand());
/*      */       }
/*  564 */       catch (NumberFormatException n) {
/*      */         return;
/*  566 */       }  doDebug("Button " + buttonIndex + " pressed.");
/*  567 */       if (this.currentNum != buttonIndex) {
/*      */         
/*  569 */         pauseCurrent();
/*  570 */         setPlayer(buttonIndex);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected URL getURL(String filename) {
/*  584 */     URL url = null;
/*  585 */     doDebug(filename);
/*      */     
/*      */     try {
/*  588 */       if ((((!filename.startsWith("http") && !filename.startsWith("file")) ? 1 : 0) & ((this.mpCodeBase != null) ? 1 : 0)) != 0)
/*  589 */       { url = new URL(this.mpCodeBase, filename); }
/*  590 */       else { url = new URL(filename); }
/*      */     
/*      */     } catch (MalformedURLException e) {
/*  593 */       System.out.println(JMFUtil.getString("InvalidURL:") + filename);
/*  594 */       return null;
/*      */     } 
/*      */     
/*  597 */     return url;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void videoResize() {
/*  608 */     doDebug("videoResize");
/*  609 */     MediaPlayer pb = this.currentPlayer;
/*  610 */     if (pb == null) {
/*      */       return;
/*      */     }
/*  613 */     Dimension d = getSize();
/*      */     
/*  615 */     int height = d.height;
/*  616 */     int width = d.width;
/*  617 */     int maxHeight = 10;
/*      */     
/*  619 */     this.buttonPanel.validate();
/*  620 */     Dimension buttonD = this.buttonPanel.getSize();
/*      */     
/*  622 */     if (maxHeight < buttonD.height) {
/*  623 */       maxHeight = buttonD.height;
/*      */     }
/*  625 */     pb.setBounds((getBounds()).x, (getBounds()).y, width, height - maxHeight);
/*  626 */     while (pb.getState() != 500 && pb.getState() != 600) {
/*      */ 
/*      */       
/*      */       try {
/*  630 */         Thread.sleep(200L);
/*      */       }
/*  632 */       catch (InterruptedException ie) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MediaPlayer formPlayer(String mediaName) {
/*      */     try {
/*  649 */       mediaName = mediaName.trim();
/*  650 */       if (mediaName.length() != 0) {
/*      */         
/*  652 */         doDebug("Forming player: " + mediaName + "| CodeBase = " + this.mpCodeBase);
/*  653 */         ClassLoader cl = getClass().getClassLoader();
/*  654 */         MediaPlayer pb = (MediaPlayer)Beans.instantiate(cl, "javax.media.bean.playerbean.MediaPlayer");
/*      */         
/*  656 */         if ((((!mediaName.startsWith("http") && !mediaName.startsWith("file")) ? 1 : 0) & ((this.mpCodeBase != null) ? 1 : 0)) != 0) {
/*  657 */           mediaName = this.mpCodeBase + mediaName;
/*      */         }
/*  659 */         doDebug("loading: 111" + mediaName);
/*  660 */         pb.setMediaLocation(mediaName);
/*  661 */         pb.prefetch();
/*  662 */         pb.waitForState(500);
/*  663 */         System.out.println("Wait for state done");
/*      */         
/*  665 */         pb.addControllerListener(this);
/*  666 */         pb.addComponentListener(this);
/*      */         
/*  668 */         pb.setVisible(false);
/*  669 */         pb.setBackground(getBackground());
/*      */         
/*  671 */         pb.setMediaLocationVisible(this.displayURL);
/*  672 */         pb.setPlaybackLoop(this.looping);
/*  673 */         pb.setControlPanelVisible(this.panelVisible);
/*  674 */         this.numOfClips++;
/*  675 */         System.out.println("num of Clips=" + this.numOfClips);
/*      */ 
/*      */         
/*  678 */         Dimension d = getSize();
/*      */         
/*  680 */         int height = d.height;
/*  681 */         int width = d.width;
/*  682 */         int maxHeight = 0;
/*  683 */         int pbHeight = 0;
/*  684 */         int pbWidth = 0;
/*      */         
/*  686 */         Dimension buttonD = this.buttonPanel.getSize();
/*      */         
/*  688 */         if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("NORTH")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("SOUTH"))) {
/*      */           
/*  690 */           pbHeight = height - buttonD.height;
/*  691 */           pbWidth = width;
/*      */         
/*      */         }
/*  694 */         else if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("WEST")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("EAST"))) {
/*      */           
/*  696 */           pbHeight = height;
/*  697 */           pbWidth = width - buttonD.width;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  702 */         if (this.fixAspectRatio) {
/*      */           
/*  704 */           Component vc = pb.getVisualComponent();
/*      */           
/*  706 */           float aspect = 1.0F;
/*  707 */           if (vc != null) {
/*      */             
/*  709 */             int cHeight = 0;
/*  710 */             if (pb.getControlPanelComponent() != null && this.panelVisible)
/*  711 */               cHeight = (pb.getControlPanelComponent().getSize()).height; 
/*  712 */             if (this.displayURL) {
/*  713 */               cHeight += 23;
/*      */             }
/*      */             
/*  716 */             Dimension pbD = vc.getPreferredSize();
/*      */             
/*  718 */             aspect = JMFUtil.aspectRatio(pbD.width, pbD.height, 0);
/*  719 */             pbHeight = (int)(width / aspect) + cHeight;
/*  720 */             if (pbHeight > height) {
/*      */               
/*  722 */               pbWidth = (int)(aspect * (height - cHeight));
/*  723 */               pbHeight = height - maxHeight;
/*      */             } else {
/*  725 */               pbWidth = width;
/*      */             } 
/*      */           } 
/*  728 */         }  pb.setBounds((getBounds()).x, (getBounds()).y, pbWidth, pbHeight);
/*      */         
/*  730 */         doDebug("Number of Clips: " + this.numOfClips);
/*  731 */         return pb;
/*      */       } 
/*      */       
/*  734 */       return null;
/*      */     } catch (Exception e) {
/*      */       
/*  737 */       System.err.println(JMFUtil.getString("PlayerBeanNotGood") + e);
/*  738 */       e.printStackTrace();
/*      */ 
/*      */       
/*  741 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean containsButton(Component but) {
/*  752 */     Component[] comps = this.gifPanel.getComponents();
/*  753 */     for (int i = 0; i < comps.length; i++) {
/*      */       
/*  755 */       if (comps[i] == but) return true;
/*      */     
/*      */     } 
/*  758 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ImageButton formButton(URL i, int index) {
/*  774 */     doDebug("Form image button");
/*  775 */     ImageButton newButton = new ImageButton(i);
/*  776 */     newButton.setActionCommand(Integer.toString(index));
/*  777 */     newButton.addActionListener(this);
/*  778 */     newButton.setEnabled(true);
/*  779 */     newButton.waitForImage(true);
/*  780 */     return newButton;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ImageButton formButton(int index) {
/*  795 */     doDebug("Form Index button");
/*  796 */     ImageButton newButton = new ImageButton(Integer.toString(index), true, 80, 60);
/*  797 */     newButton.setActionCommand(Integer.toString(index));
/*  798 */     newButton.addActionListener(this);
/*  799 */     newButton.waitForImage(true);
/*  800 */     return newButton;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pauseCurrent() {
/*  812 */     if (this.currentNum <= this.numOfMGroups && this.currentNum > 0) {
/*      */       
/*  814 */       ImageButton imgB = this.mGroups[this.currentNum - 1].getButton();
/*  815 */       imgB.setBorderColor(new Color(160, 160, 160));
/*  816 */       imgB.drawBorder(true);
/*      */     } 
/*  818 */     if (this.currentPlayer != null) {
/*      */       
/*  820 */       this.currentPlayer.stop();
/*  821 */       this.currentPlayer.close();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  829 */       this.currentPlayer.setVisible(false);
/*  830 */       this.videoPanel.remove((Component)this.currentPlayer);
/*      */ 
/*      */       
/*  833 */       doDebug("Exiting PauseCurrent.");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void changeCurrentPlayer(MediaPlayer newPB, int num) {
/*  847 */     this.currentNum = num;
/*  848 */     this.currentPlayer = newPB;
/*  849 */     doDebug("Switching current Player");
/*  850 */     this.currentPlayer.setVisible(true);
/*  851 */     this.videoPanel.add((Component)this.currentPlayer);
/*  852 */     JMFUtil.center(this.videoPanel, (Component)this.currentPlayer, true, this.currentPlayer.getMediaLocationHeight() + this.currentPlayer.getControlPanelHeight());
/*      */     
/*  854 */     this.videoPanel.setVisible(true);
/*      */     try {
/*  856 */       if (this.currentPlayer.getState() != 600)
/*  857 */       { this.currentPlayer.start(); }
/*  858 */       else { System.out.println("Player already in started state."); }
/*      */     
/*      */     } catch (ClockStartedError cse) {
/*      */       
/*  862 */       this.currentPlayer.close();
/*  863 */       this.currentPlayer.deallocate();
/*  864 */       this.currentPlayer.start();
/*      */     } 
/*  866 */     this.currentPlayer.setVisible(true);
/*  867 */     this.currentPlayer.waitForState(600);
/*  868 */     this.currentPlayer.invalidate();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  873 */     this.videoPanel.validate();
/*      */     
/*  875 */     this.videoPanel.setVisible(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void nextPlayer() {
/*  887 */     if (this.numOfMGroups <= 1) {
/*      */       return;
/*      */     }
/*  890 */     pauseCurrent();
/*  891 */     this.currentNum++;
/*      */     
/*  893 */     if (this.currentNum > this.numOfMGroups) {
/*  894 */       this.currentNum = 1;
/*      */     }
/*  896 */     while (!containsButton(this.mGroups[this.currentNum - 1].getButton()))
/*      */     {
/*  898 */       shiftButtons(1);
/*      */     }
/*      */     
/*  901 */     doDebug("Next Player");
/*  902 */     setPlayer(this.currentNum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void previousPlayer() {
/*  913 */     if (this.numOfMGroups <= 1) {
/*      */       return;
/*      */     }
/*  916 */     pauseCurrent();
/*  917 */     this.currentNum--;
/*  918 */     if (this.currentNum < 1) {
/*  919 */       this.currentNum = this.numOfMGroups;
/*      */     }
/*  921 */     while (!containsButton(this.mGroups[this.currentNum - 1].getButton()))
/*      */     {
/*  923 */       shiftButtons(-1);
/*      */     }
/*      */     
/*  926 */     doDebug("Previous Player");
/*  927 */     setPlayer(this.currentNum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPlayer(int current) {
/*  938 */     MediaGroup mGrp = null;
/*  939 */     ImageButton imgBut = null;
/*  940 */     if (current < 1 || current > this.numOfMGroups) {
/*      */       return;
/*      */     }
/*  943 */     mGrp = this.mGroups[current - 1];
/*      */     
/*  945 */     mGrp.setPlayer(formPlayer(mGrp.mediaName));
/*      */     
/*  947 */     if (!containsButton(mGrp.getButton())) {
/*      */       
/*  949 */       this.startingButton = this.currentNum;
/*  950 */       updateGifPanel();
/*      */     } 
/*      */     
/*  953 */     if (mGrp.getRelated() != null && this.mpAppletContext != null) {
/*  954 */       if (mGrp.getRelated().size() > 0) {
/*      */         
/*  956 */         if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("SOUTH")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("NORTH")))
/*      */         {
/*      */           
/*  959 */           this.buttonPanel.add("South", this.utilPanel);
/*  960 */           validate();
/*      */         }
/*  962 */         else if (!this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("NONE")))
/*      */         {
/*  964 */           this.videoPanel.add("South", this.utilPanel);
/*  965 */           validate();
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/*  970 */         this.buttonPanel.remove(this.utilPanel);
/*  971 */         this.videoPanel.remove(this.utilPanel);
/*  972 */         validate();
/*      */       } 
/*      */     } else {
/*      */       
/*  976 */       this.buttonPanel.remove(this.utilPanel);
/*  977 */       this.videoPanel.remove(this.utilPanel);
/*      */     } 
/*      */     
/*  980 */     imgBut = mGrp.getButton();
/*  981 */     imgBut.requestFocus();
/*  982 */     imgBut.setBorderColor(Color.darkGray);
/*  983 */     imgBut.drawBorder(false);
/*      */     
/*  985 */     this.currentPlayer = mGrp.getPlayer();
/*  986 */     changeCurrentPlayer(this.currentPlayer, current);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFixAspectRatio() {
/*  997 */     return this.fixAspectRatio;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixAspectRatio(boolean f) {
/* 1009 */     boolean old = this.fixAspectRatio;
/* 1010 */     if (old != f) {
/* 1011 */       for (int i = 0; i < this.numOfClips; i++);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1016 */     this.fixAspectRatio = f;
/* 1017 */     this.changes.firePropertyChange("fixAspectRatio", new Boolean(old), new Boolean(f));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getButtonPosition() {
/* 1029 */     return this.buttonPosition;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setButtonPosition(String p) {
/* 1041 */     String old = this.buttonPosition;
/* 1042 */     if (!old.equalsIgnoreCase(p)) {
/*      */       
/* 1044 */       this.buttonPosition = p;
/* 1045 */       position();
/* 1046 */       this.changes.firePropertyChange("buttonPosition", new String(old), new String(p));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSequentialPlay() {
/* 1059 */     return this.sequential;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSequentialPlay(boolean b) {
/* 1071 */     boolean old = this.sequential;
/* 1072 */     if (old != b) {
/*      */       
/* 1074 */       this.sequential = b;
/* 1075 */       this.changes.firePropertyChange("sequentialPlay", new Boolean(old), new Boolean(b));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLooping() {
/* 1087 */     return this.looping;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLooping(boolean l) {
/* 1099 */     boolean old = this.looping;
/* 1100 */     if (old != l) {
/* 1101 */       for (int i = 0; i < this.numOfClips; i++)
/*      */       {
/* 1103 */         this.mGroups[i].getPlayer().setPlaybackLoop(l);
/*      */       }
/*      */     }
/* 1106 */     this.looping = l;
/* 1107 */     this.changes.firePropertyChange("looping", new Boolean(old), new Boolean(l));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPanelVisible() {
/* 1118 */     return this.panelVisible;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPanelVisible(boolean val) {
/* 1130 */     if (this.panelVisible != val) {
/*      */       
/* 1132 */       for (int i = 0; i < this.numOfClips; i++)
/*      */       {
/* 1134 */         this.mGroups[i].getPlayer().setControlPanelVisible(val);
/*      */       }
/* 1136 */       validate();
/* 1137 */       this.panelVisible = val;
/* 1138 */       this.changes.firePropertyChange("panelVisible", new Boolean(!val), new Boolean(val));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isURLVisible() {
/* 1151 */     return this.displayURL;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURLVisible(boolean val) {
/* 1163 */     if (this.displayURL != val) {
/*      */       
/* 1165 */       for (int i = 0; i < this.numOfClips; i++)
/*      */       {
/* 1167 */         this.mGroups[i].getPlayer().setMediaLocationVisible(val);
/*      */       }
/* 1169 */       validate();
/* 1170 */       this.displayURL = val;
/* 1171 */       this.changes.firePropertyChange("URLVisible", new Boolean(!val), new Boolean(val));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFitVideo() {
/* 1184 */     return this.fitVideo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFitVideo(boolean f) {
/* 1196 */     boolean old = this.fitVideo;
/* 1197 */     if (old != f) {
/*      */       
/* 1199 */       for (int i = 0; i < this.numOfClips; i++);
/*      */ 
/*      */ 
/*      */       
/* 1203 */       this.fitVideo = f;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getLoadOnInit() {
/* 1218 */     return this.loadOnInit;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLoadOnInit(boolean b) {
/* 1230 */     boolean old = this.loadOnInit;
/* 1231 */     if (old != b) {
/*      */       
/* 1233 */       this.loadOnInit = b;
/* 1234 */       this.changes.firePropertyChange("loadOnInit", new Boolean(old), new Boolean(b));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveUp(int index) {
/* 1248 */     MediaGroup mg = this.mGroups[index];
/* 1249 */     if (index > 0) {
/*      */       
/* 1251 */       this.mGroups[index] = this.mGroups[index - 1];
/* 1252 */       this.mGroups[index - 1] = mg;
/* 1253 */       this.mGroups[index].setIndex(index);
/* 1254 */       this.mGroups[index - 1].setIndex(index - 1);
/*      */ 
/*      */       
/* 1257 */       this.mGroups[index].getButton().setActionCommand(Integer.toString(index + 1));
/* 1258 */       this.mGroups[index - 1].getButton().setActionCommand(Integer.toString(index));
/* 1259 */       if (switchLinkIndex(Integer.toString(index), Integer.toString(index + 1)))
/* 1260 */         setLinks(this.links); 
/* 1261 */       doDebug("ActionCommand = " + (index + 1));
/* 1262 */       doDebug("ActionCommand = " + index);
/*      */     } 
/*      */ 
/*      */     
/* 1266 */     for (int i = index - 1; i < this.numOfMGroups; i++) {
/*      */       
/* 1268 */       ImageButton b = this.mGroups[i].getButton();
/* 1269 */       this.gifPanel.remove(b);
/* 1270 */       this.gifPanel.add(b);
/*      */     } 
/* 1272 */     validate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveDown(int index) {
/* 1285 */     MediaGroup mg = this.mGroups[index];
/* 1286 */     if (index < this.numOfMGroups - 1) {
/*      */       
/* 1288 */       this.mGroups[index] = this.mGroups[index + 1];
/* 1289 */       this.mGroups[index + 1] = mg;
/* 1290 */       this.mGroups[index].setIndex(index);
/* 1291 */       this.mGroups[index + 1].setIndex(index + 1);
/*      */ 
/*      */       
/* 1294 */       this.mGroups[index].getButton().setActionCommand(Integer.toString(index + 1));
/* 1295 */       this.mGroups[index + 1].getButton().setActionCommand(Integer.toString(index + 2));
/* 1296 */       if (switchLinkIndex(Integer.toString(index + 1), Integer.toString(index + 2)))
/* 1297 */         setLinks(this.links); 
/* 1298 */       doDebug("moveDown(i):ActionCommand=" + (index + 1));
/* 1299 */       doDebug("moveDown(i):ActionCommand=" + (index + 2));
/*      */     } 
/*      */ 
/*      */     
/* 1303 */     for (int i = index; i < this.numOfMGroups; i++) {
/*      */       
/* 1305 */       ImageButton b = this.mGroups[i].getButton();
/* 1306 */       doDebug("Moving media " + (this.mGroups[i]).mediaName);
/* 1307 */       this.gifPanel.remove(b);
/* 1308 */       this.gifPanel.add(b);
/*      */     } 
/* 1310 */     validate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addMGroup(String mediaName, String buttonGif) {
/* 1324 */     doDebug("adding media group - " + this.numOfMGroups);
/* 1325 */     if (this.mGroups == null) this.mGroups = new MediaGroup[this.maxMediaGroup]; 
/* 1326 */     if (this.numOfMGroups < this.maxMediaGroup) {
/*      */       
/* 1328 */       this.mGroups[this.numOfMGroups] = new MediaGroup(mediaName, buttonGif, "", this);
/*      */     } else {
/*      */       
/* 1331 */       System.out.println(JMFUtil.getString("MaxMGroup"));
/* 1332 */     }  doDebug("Number of next media group = " + this.numOfMGroups);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void deleteMGroup(int i) {
/* 1345 */     boolean changed = false;
/* 1346 */     String index = Integer.toString(i + 1);
/* 1347 */     doDebug("i = " + i);
/* 1348 */     doDebug("index = " + index);
/* 1349 */     doDebug("MGroups length = " + this.mGroups.length);
/* 1350 */     String[] temp = null;
/* 1351 */     MediaGroup mg = this.mGroups[i];
/* 1352 */     int linksLength = 0;
/*      */     
/* 1354 */     if (this.links != null) linksLength = this.links.length;
/*      */     
/* 1356 */     for (int j = 0; j < linksLength; j += 4) {
/*      */       
/* 1358 */       if (index.equals(this.links[j])) {
/*      */         
/* 1360 */         changed = true;
/* 1361 */         temp = new String[this.links.length - 4];
/* 1362 */         JMFUtil.copyShortenStringArray(this.links, temp, j, 4);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1368 */     for (int k = i; k < this.numOfMGroups - 1; k++) {
/*      */       
/* 1370 */       this.mGroups[k] = this.mGroups[k + 1];
/* 1371 */       if (this.links != null) {
/*      */         
/* 1373 */         index = Integer.toString(k + 1);
/* 1374 */         if (changed) {
/* 1375 */           for (int m = 0; m < temp.length; m += 4) {
/*      */             
/* 1377 */             if (temp[m].equals(index)) {
/* 1378 */               temp[m] = Integer.toString(k);
/*      */             }
/*      */           } 
/*      */         } else {
/* 1382 */           temp = new String[linksLength];
/* 1383 */           JMFUtil.copyStringArray(this.links, temp);
/* 1384 */           for (int m = 0; m < temp.length; m += 4) {
/*      */             
/* 1386 */             if (temp[m].equals(index)) {
/*      */               
/* 1388 */               changed = true;
/* 1389 */               temp[m] = Integer.toString(k);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1397 */     if (changed) setLinks(temp); 
/* 1398 */     this.mGroups[this.numOfMGroups - 1] = null;
/* 1399 */     this.numOfMGroups--;
/* 1400 */     doDebug("Remove button " + mg.gifName);
/* 1401 */     this.gifPanel.remove(mg.getButton());
/* 1402 */     updateGifPanel();
/* 1403 */     validate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean switchLinkIndex(String index1, String index2) {
/* 1415 */     boolean changed = false;
/*      */     
/* 1417 */     if (this.links != null) {
/* 1418 */       for (int i = 0; i < this.links.length; i += 4) {
/*      */         
/* 1420 */         if (index1.equals(this.links[i])) {
/*      */           
/* 1422 */           doDebug("Switched " + this.links[i] + " with " + index2);
/* 1423 */           changed = true;
/* 1424 */           this.links[i] = index2;
/*      */         }
/* 1426 */         else if (index2.equals(this.links[i])) {
/*      */           
/* 1428 */           doDebug("Switched " + this.links[i] + " with " + index1);
/* 1429 */           changed = true;
/* 1430 */           this.links[i] = index1;
/*      */         } 
/*      */       } 
/*      */     }
/* 1434 */     return changed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void replaceMGroup(int i, String mName, String gName) {
/* 1447 */     if (i < this.numOfMGroups) {
/*      */       
/* 1449 */       if (i < this.numOfMGroups - 1) {
/*      */ 
/*      */         
/* 1452 */         MediaGroup m1 = this.mGroups[i + 1];
/* 1453 */         if ((m1.mediaName.equals(mName) & m1.gifName.equals(gName)) != 0) {
/*      */ 
/*      */           
/* 1456 */           moveDown(i);
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*      */       
/* 1462 */       MediaGroup mg = this.mGroups[i];
/*      */       
/* 1464 */       if (mg.getPlayer() != null) {
/*      */         
/* 1466 */         MediaPlayer pb = mg.getPlayer();
/* 1467 */         pb.close();
/* 1468 */         pb.deallocate();
/* 1469 */         mg.setPlayer(null);
/*      */       } 
/*      */       
/* 1472 */       doDebug("Media Name = " + mName);
/* 1473 */       doDebug("Gif Name = " + gName);
/* 1474 */       mg.mediaName = mName;
/* 1475 */       mg.gifName = gName;
/* 1476 */       if (gName != null || gName.compareTo("") != 0) {
/* 1477 */         mg.setButton(formButton(getURL(gName), i + 1));
/*      */       } else {
/* 1479 */         mg.setButton(formButton(i + 1));
/* 1480 */       }  doDebug("Replacing " + i);
/* 1481 */       refreshAllButtons();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void refreshAllButtons() {
/* 1492 */     this.gifPanel.removeAll();
/* 1493 */     for (int i = 0; i < this.numOfMGroups; i++)
/*      */     {
/* 1495 */       this.gifPanel.add(this.mGroups[i].getButton());
/*      */     }
/* 1497 */     validate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean addLink(int index, String l, long start, long end) {
/* 1514 */     doDebug("adding link: index = " + index);
/* 1515 */     doDebug("Link = " + l + " start=" + start + " stop=" + end);
/*      */     
/*      */     try {
/* 1518 */       RelatedLink link = new RelatedLink(l, start, end, this);
/* 1519 */       this.mGroups[index - 1].setRelated(link);
/*      */     } catch (MalformedURLException e) {
/*      */       
/* 1522 */       System.out.println(JMFUtil.getString("InvalidURL"));
/* 1523 */       return false;
/*      */     } 
/*      */     
/* 1526 */     if (!duplicate(Integer.toString(index + 1), l, Long.toString(start), Long.toString(end))) {
/*      */ 
/*      */       
/* 1529 */       int len = 0;
/*      */       
/* 1531 */       if (this.links != null) {
/* 1532 */         len = this.links.length;
/*      */       }
/* 1534 */       String[] temp = new String[len + 4];
/* 1535 */       JMFUtil.copyStringArray(this.links, temp);
/* 1536 */       temp[len] = Integer.toString(index + 1);
/* 1537 */       temp[len + 1] = l;
/* 1538 */       temp[len + 2] = Long.toString(start);
/* 1539 */       temp[len + 3] = Long.toString(end);
/*      */     } 
/*      */     
/* 1542 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean duplicate(String mIndex, String url, String start, String stop) {
/* 1557 */     if (this.links != null)
/*      */     {
/* 1559 */       for (int i = 0; i < this.links.length; i += 4) {
/*      */         
/* 1561 */         if ((this.links[i].equals(mIndex) & this.links[i + 1].equals(url) & this.links[i + 2].equals(start) & this.links[i + 3].equals(stop)) != 0)
/*      */         {
/*      */ 
/*      */           
/* 1565 */           return true; } 
/*      */       } 
/*      */     }
/* 1568 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMGroups(MediaGroup[] indexprop) {
/* 1581 */     MediaGroup[] oldValue = this.mGroups;
/* 1582 */     this.mGroups = indexprop;
/* 1583 */     this.changes.firePropertyChange("mGroups", oldValue, indexprop);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMGroups(int index, MediaGroup indexprop) {
/* 1596 */     MediaGroup[] oldValue = this.mGroups;
/* 1597 */     this.mGroups[index] = indexprop;
/* 1598 */     this.changes.firePropertyChange("mGroups", oldValue, this.mGroups);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MediaGroup[] getMGroups() {
/* 1610 */     return this.mGroups;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MediaGroup getMGroups(int index) {
/* 1624 */     return this.mGroups[index];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMediaNames(String[] indexprop) {
/* 1713 */     String[] oldValue = this.mediaNames;
/* 1714 */     this.mediaNames = indexprop;
/* 1715 */     doDebug("setmediaNames " + this.mediaNames);
/* 1716 */     updateMGroups(this.mediaNames);
/* 1717 */     updateLinks(this.links);
/* 1718 */     doDebug("updateMGroups done");
/* 1719 */     updateGifPanel();
/* 1720 */     this.changes.firePropertyChange("mediaNames", oldValue, indexprop);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMediaNames(String[] indexprop, Object t) {
/* 1733 */     String[] oldValue = this.mediaNames;
/* 1734 */     this.mediaNames = indexprop;
/* 1735 */     doDebug("setmediaNames " + this.mediaNames);
/* 1736 */     getContext(t);
/* 1737 */     updateMGroups(this.mediaNames);
/* 1738 */     updateLinks(this.links);
/* 1739 */     doDebug("updateMGroups done");
/* 1740 */     updateGifPanel();
/* 1741 */     this.changes.firePropertyChange("mediaNames", oldValue, indexprop);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMediaNames(int index, String indexprop) {
/* 1754 */     String str1, str2, oldValue[] = this.mediaNames;
/*      */     
/* 1756 */     this.mediaNames[index] = indexprop;
/* 1757 */     if (index % 2 == 0) {
/*      */       
/* 1759 */       str1 = this.mediaNames[index];
/* 1760 */       str2 = this.mediaNames[index + 1];
/*      */     }
/*      */     else {
/*      */       
/* 1764 */       str1 = this.mediaNames[index - 1];
/* 1765 */       str2 = this.mediaNames[index];
/*      */     } 
/* 1767 */     updateMGroups(index / 2, str1, str2);
/* 1768 */     updateGifPanel();
/* 1769 */     this.changes.firePropertyChange("mediaNames", oldValue, this.mediaNames);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean updateMGroups(String[] mNames) {
/* 1781 */     boolean changed = false;
/* 1782 */     int mNamesLength = 0;
/* 1783 */     int mindex = 0;
/*      */     
/* 1785 */     if (mNames != null) mNamesLength = mNames.length; 
/* 1786 */     doDebug("Updating MGroups " + mNamesLength);
/*      */     
/* 1788 */     for (int i = 0; i < mNamesLength; i += 2) {
/*      */       
/* 1790 */       mindex = i / 2;
/* 1791 */       if (changed) { updateMGroups(mindex, mNames[i], mNames[i + 1]); }
/* 1792 */       else { changed = updateMGroups(mindex, mNames[i], mNames[i + 1]); }
/*      */     
/*      */     } 
/* 1795 */     if (mNamesLength / 2 < this.numOfMGroups)
/*      */     {
/* 1797 */       for (int j = this.numOfMGroups - 1; j >= mNamesLength / 2; j--) {
/*      */         
/* 1799 */         doDebug("Deleting mGroup " + j);
/* 1800 */         this.mGroups[j].delete();
/*      */       } 
/*      */     }
/*      */     
/* 1804 */     return changed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean updateMGroups(int i, String mediaName, String gifName) {
/* 1818 */     doDebug("Index=" + i + " Media=" + mediaName + " Gif=" + gifName);
/* 1819 */     if (i < this.numOfMGroups) {
/*      */       
/* 1821 */       MediaGroup m = this.mGroups[i];
/* 1822 */       if (((!m.mediaName.equals(mediaName) ? 1 : 0) | (!m.gifName.equals(gifName) ? 1 : 0)) != 0)
/*      */       {
/* 1824 */         replaceMGroup(i, mediaName, gifName);
/* 1825 */         return true;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1830 */       addMGroup(mediaName, gifName);
/* 1831 */       return true;
/*      */     } 
/* 1833 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getMediaNames() {
/* 1846 */     return this.mediaNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getMediaNames(int index) {
/* 1860 */     return this.mediaNames[index];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLinks(String[] indexprop) {
/* 1872 */     String[] oldValue = this.links;
/* 1873 */     boolean changed = false;
/*      */     
/* 1875 */     this.links = indexprop;
/*      */     
/* 1877 */     doDebug("Inside setLinks(String[])");
/* 1878 */     changed = deleteLinks(this.links);
/*      */     
/* 1880 */     doDebug("updating links...");
/* 1881 */     if (updateLinks(this.links) | changed) {
/* 1882 */       this.changes.firePropertyChange("links", oldValue, indexprop);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLinks(int index, String indexprop) {
/* 1895 */     String[] oldValue = this.links;
/* 1896 */     String mediaNum = "";
/* 1897 */     String relatedName = "";
/* 1898 */     String startString = "";
/* 1899 */     String stopString = "";
/* 1900 */     this.links[index] = indexprop;
/* 1901 */     if (index % 4 == 0) {
/*      */       
/* 1903 */       mediaNum = this.links[index];
/* 1904 */       relatedName = this.links[index + 1];
/* 1905 */       startString = this.links[index + 2];
/* 1906 */       stopString = this.links[index + 3];
/*      */     }
/* 1908 */     else if (index % 4 == 1) {
/*      */       
/* 1910 */       mediaNum = this.links[index - 1];
/* 1911 */       relatedName = this.links[index];
/* 1912 */       startString = this.links[index + 1];
/* 1913 */       stopString = this.links[index + 2];
/*      */     }
/* 1915 */     else if (index % 3 == 2) {
/*      */       
/* 1917 */       mediaNum = this.links[index - 2];
/* 1918 */       relatedName = this.links[index - 1];
/* 1919 */       startString = this.links[index];
/* 1920 */       stopString = this.links[index + 1];
/*      */     }
/* 1922 */     else if (index % 3 == 4) {
/*      */       
/* 1924 */       mediaNum = this.links[index - 3];
/* 1925 */       relatedName = this.links[index - 2];
/* 1926 */       startString = this.links[index - 1];
/* 1927 */       stopString = this.links[index];
/*      */     } 
/*      */     
/* 1930 */     if (updateLinks(mediaNum, relatedName, startString, stopString)) {
/* 1931 */       this.changes.firePropertyChange("links", oldValue, this.links);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean deleteLinks(String[] linksList) {
/* 1943 */     int index = 0;
/* 1944 */     Vector rl = null;
/* 1945 */     RelatedLink l = null;
/* 1946 */     boolean changed = false;
/* 1947 */     boolean match = false;
/*      */     
/* 1949 */     for (int i = 0; i < this.numOfMGroups; i++) {
/*      */       
/* 1951 */       rl = this.mGroups[i].getRelated();
/* 1952 */       if (rl != null)
/* 1953 */         for (int j = 0; j < rl.size(); j++) {
/*      */           
/* 1955 */           l = rl.elementAt(j);
/* 1956 */           match = false;
/* 1957 */           if (linksList != null) {
/* 1958 */             for (int k = 0; k < linksList.length; k += 4) {
/*      */               
/* 1960 */               if ((Integer.toString(i).equals(linksList[k]) & l.link.equals(linksList[k + 1]) & Long.toString(l.startTime).equals(linksList[k + 2]) & Long.toString(l.stopTime).equals(linksList[k + 3])) != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 1965 */                 match = true;
/*      */                 break;
/*      */               } 
/*      */             } 
/*      */           }
/* 1970 */           if (!match) {
/*      */             
/* 1972 */             rl.removeElementAt(j);
/* 1973 */             changed = true;
/*      */           } 
/*      */         }  
/*      */     } 
/* 1977 */     return changed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean updateLinks(String[] linksList) {
/* 1989 */     boolean changed = false;
/*      */     
/* 1991 */     if (linksList != null) {
/*      */       
/* 1993 */       doDebug("links length: " + linksList.length);
/* 1994 */       if (this.msVM)
/*      */       {
/*      */         
/* 1997 */         for (int j = 0; j < linksList.length; j++)
/*      */         {
/* 1999 */           String temp = linksList[j];
/*      */         }
/*      */       }
/* 2002 */       for (int i = 0; i < linksList.length; i += 4) {
/*      */         
/* 2004 */         if (changed) { updateLinks(linksList[i], linksList[i + 1], linksList[i + 2], linksList[i + 3]); }
/* 2005 */         else { changed = updateLinks(linksList[i], linksList[i + 1], linksList[i + 2], linksList[i + 3]); }
/*      */       
/*      */       } 
/*      */     } 
/* 2009 */     return changed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean updateLinks(String mediaNum, String relatedName, String startString, String stopString) {
/* 2024 */     doDebug("MediaNum=" + mediaNum + " related=" + relatedName);
/* 2025 */     doDebug("Start=" + startString + " Stop=" + stopString);
/*      */     
/* 2027 */     int i = Integer.parseInt(mediaNum) - 1;
/* 2028 */     long start = 0L;
/* 2029 */     long stop = 0L;
/* 2030 */     boolean dup = false;
/*      */ 
/*      */     
/*      */     try {
/* 2034 */       start = Long.parseLong(startString);
/* 2035 */       stop = Long.parseLong(stopString);
/*      */     }
/*      */     catch (NumberFormatException n) {
/*      */       
/* 2039 */       return false;
/*      */     } 
/*      */     
/* 2042 */     if ((((i < this.numOfMGroups) ? 1 : 0) & ((i >= 0) ? 1 : 0)) != 0) {
/*      */       
/* 2044 */       MediaGroup m = this.mGroups[i];
/*      */       
/* 2046 */       Vector r = m.getRelated();
/* 2047 */       RelatedLink rl = null;
/* 2048 */       if (r != null)
/*      */       {
/* 2050 */         for (int j = 0; j < r.size(); j++) {
/*      */           
/* 2052 */           rl = r.elementAt(j);
/* 2053 */           if ((rl.link.equals(relatedName) & ((rl.startTime == start) ? 1 : 0) & ((rl.stopTime == stop) ? 1 : 0)) != 0) {
/*      */             
/* 2055 */             dup = true;
/* 2056 */             j = r.size();
/* 2057 */             return false;
/*      */           } 
/*      */         } 
/*      */       }
/*      */       
/* 2062 */       if (!dup) {
/*      */ 
/*      */         
/*      */         try {
/* 2066 */           m.setRelated(new RelatedLink(relatedName, start, stop, this));
/*      */         } catch (MalformedURLException me) {
/*      */           
/* 2069 */           System.out.println(JMFUtil.getBIString("BadURL") + relatedName);
/* 2070 */           return false;
/*      */         } 
/*      */         
/* 2073 */         return true;
/*      */       } 
/*      */     } 
/*      */     
/* 2077 */     System.out.println(JMFUtil.getBIString("MEDIA_GROUP_BOUNDS"));
/* 2078 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getLinks() {
/* 2091 */     return this.links;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getLinks(int index) {
/* 2105 */     return this.links[index];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAppletContext(AppletContext ac) {
/* 2118 */     this.mpAppletContext = ac;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCodeBase(URL cb) {
/* 2130 */     this.mpCodeBase = cb;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addControllerListener(ControllerListener listener) {
/* 2142 */     for (int i = 0; i < this.numOfClips; i++) {
/* 2143 */       this.mGroups[i].getPlayer().addControllerListener(listener);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeControllerListener(ControllerListener listener) {
/* 2155 */     for (int i = 0; i < this.numOfClips; i++) {
/* 2156 */       this.mGroups[i].getPlayer().removeControllerListener(listener);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumberOfMediaGroups() {
/* 2168 */     return this.numOfMGroups;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBounds(int x, int y, int w, int h) {
/* 2183 */     super.setBounds(x, y, w, h);
/* 2184 */     Dimension d = getSize();
/*      */     
/* 2186 */     int height = d.height;
/* 2187 */     int maxHeight = 10;
/*      */     
/* 2189 */     Dimension buttonD = this.buttonPanel.getSize();
/* 2190 */     if (maxHeight < buttonD.height) {
/* 2191 */       maxHeight = buttonD.height;
/*      */     }
/* 2193 */     doDebug("Num of Clips = " + this.numOfClips);
/* 2194 */     for (int i = 0; i < this.numOfClips; i++)
/*      */     {
/* 2196 */       this.mGroups[i].getPlayer().setBounds(x, y, w, h - maxHeight);
/*      */     }
/* 2198 */     updateGifPanel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Dimension getPreferredSize() {
/* 2210 */     if (Beans.isDesignTime()) return new Dimension(this.preferredWidth, this.preferredHeight);
/*      */ 
/*      */     
/* 2213 */     Dimension d = getSize();
/* 2214 */     if (d.width == 0 || d.height == 0) {
/* 2215 */       return new Dimension(this.preferredWidth, this.preferredHeight);
/*      */     }
/* 2217 */     return d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addPropertyChangeListener(PropertyChangeListener c) {
/* 2230 */     this.changes.addPropertyChangeListener(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removePropertyChangeListener(PropertyChangeListener c) {
/* 2242 */     this.changes.removePropertyChangeListener(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void createTabs(int length) {
/* 2253 */     if (this.up != null)
/* 2254 */       this.scrollPanel.remove(this.up); 
/* 2255 */     if (this.down != null)
/* 2256 */       this.scrollPanel.remove(this.down); 
/* 2257 */     if (this.left != null)
/* 2258 */       this.scrollPanel.remove(this.left); 
/* 2259 */     if (this.right != null)
/* 2260 */       this.scrollPanel.remove(this.right); 
/* 2261 */     if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("SOUTH")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("NORTH"))) {
/*      */       
/* 2263 */       createLeftRight(length);
/* 2264 */       this.scrollPanel.add("West", this.left);
/* 2265 */       this.scrollPanel.add("East", this.right);
/*      */     }
/* 2267 */     else if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("WEST")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("EAST"))) {
/*      */       
/* 2269 */       createUpDown(length);
/* 2270 */       this.scrollPanel.add("North", this.up);
/* 2271 */       this.scrollPanel.add("South", this.down);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void shiftButtons(int difference) {
/* 2283 */     this.startingButton += difference;
/* 2284 */     if (this.startingButton > this.numOfMGroups)
/* 2285 */       this.startingButton -= this.numOfMGroups; 
/* 2286 */     if (this.startingButton < 1) {
/* 2287 */       this.startingButton = this.numOfMGroups + this.startingButton;
/*      */     }
/* 2289 */     updateGifPanel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateGifPanel() {
/* 2300 */     if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("NONE"))) {
/*      */       
/* 2302 */       validate();
/*      */       return;
/*      */     } 
/* 2305 */     if (this.numOfMGroups <= 0)
/* 2306 */       return;  int numOfButtons = 0;
/* 2307 */     int i = this.startingButton - 1;
/* 2308 */     int stop = i + 1;
/* 2309 */     if (stop == this.numOfMGroups) stop = 0; 
/* 2310 */     int tabLength = 0;
/*      */     
/* 2312 */     ImageButton iButton = this.mGroups[i].getButton();
/* 2313 */     int gifLength = (getSize()).width;
/* 2314 */     int buttonsLength = 0;
/* 2315 */     tabLength = iButton.height;
/*      */     
/* 2317 */     if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("WEST")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("EAST"))) {
/*      */       
/* 2319 */       gifLength = (getSize()).height;
/* 2320 */       buttonsLength = 0;
/* 2321 */       tabLength = iButton.width;
/*      */     } 
/*      */     
/* 2324 */     gifLength -= 2 * this.tabsize;
/* 2325 */     boolean first = true;
/*      */     
/* 2327 */     this.scrollPanel.setVisible(false);
/* 2328 */     this.scrollPanel.removeAll();
/* 2329 */     this.gifPanel.setVisible(false);
/* 2330 */     this.gifPanel.removeAll();
/*      */     
/* 2332 */     i++;
/* 2333 */     if (i >= this.numOfMGroups) i = 0; 
/* 2334 */     doDebug("ButtonsLength: " + buttonsLength);
/* 2335 */     doDebug("Gif Length: " + gifLength);
/* 2336 */     doDebug("i: " + i);
/* 2337 */     doDebug("stop: " + stop);
/* 2338 */     iButton = this.mGroups[i].getButton();
/* 2339 */     while (first || i != stop) {
/*      */       
/* 2341 */       first = false;
/*      */ 
/*      */       
/* 2344 */       if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("NORTH")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("SOUTH"))) {
/*      */         
/* 2346 */         if (iButton.width + buttonsLength > gifLength)
/*      */           break; 
/* 2348 */         numOfButtons++;
/* 2349 */         buttonsLength += iButton.width;
/* 2350 */         if (iButton.height > tabLength) {
/* 2351 */           tabLength = iButton.height;
/*      */         }
/* 2353 */       } else if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("WEST")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("EAST"))) {
/*      */         
/* 2355 */         if (iButton.height + buttonsLength > gifLength)
/*      */           break; 
/* 2357 */         numOfButtons++;
/* 2358 */         buttonsLength += iButton.height;
/* 2359 */         if (iButton.width > tabLength)
/* 2360 */           tabLength = iButton.width; 
/*      */       } 
/* 2362 */       i++;
/* 2363 */       if (i >= this.numOfMGroups) i = 0; 
/*      */     } 
/* 2365 */     int gap = 0;
/*      */ 
/*      */     
/* 2368 */     if (numOfButtons > 1)
/* 2369 */       gap = (gifLength - buttonsLength) / (numOfButtons - 1); 
/* 2370 */     System.out.println("gap=" + gap + " gifLength=" + gifLength + " buttonsLength=" + buttonsLength);
/*      */     
/* 2372 */     if (numOfButtons == 1) {
/* 2373 */       this.gifPanel.setLayout(new FlowLayout());
/* 2374 */     } else if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("NORTH")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("SOUTH"))) {
/* 2375 */       this.gifPanel.setLayout(new GridLayout(1, numOfButtons, gap, 0));
/* 2376 */     } else if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("WEST")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("EAST"))) {
/*      */       
/* 2378 */       this.gifPanel.setLayout(new GridLayout(numOfButtons, 1, 0, gap));
/*      */     } 
/*      */ 
/*      */     
/* 2382 */     iButton = this.mGroups[this.startingButton - 1].getButton();
/* 2383 */     buttonsLength = iButton.width;
/* 2384 */     first = true;
/* 2385 */     if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("WEST")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("EAST")))
/*      */     {
/* 2387 */       buttonsLength = iButton.height;
/*      */     }
/*      */     
/* 2390 */     i = this.startingButton;
/* 2391 */     if (i >= this.numOfMGroups) i = 0;
/*      */     
/* 2393 */     while (buttonsLength <= gifLength && (first || i != stop)) {
/*      */       
/* 2395 */       first = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2404 */       this.gifPanel.add(iButton);
/* 2405 */       iButton = this.mGroups[i].getButton();
/* 2406 */       if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("NORTH")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("SOUTH"))) {
/*      */         
/* 2408 */         buttonsLength += iButton.width;
/*      */       }
/* 2410 */       else if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("WEST")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("EAST"))) {
/*      */         
/* 2412 */         buttonsLength += iButton.height;
/*      */       } 
/* 2414 */       i++;
/* 2415 */       if (i >= this.numOfMGroups) i = 0;
/*      */     
/*      */     } 
/* 2418 */     if (buttonsLength > gifLength && i != stop)
/*      */     {
/* 2420 */       createTabs(tabLength);
/*      */     }
/* 2422 */     this.scrollPanel.add("Center", this.gifPanel);
/*      */     
/* 2424 */     this.gifPanel.setVisible(true);
/* 2425 */     this.scrollPanel.setVisible(true);
/* 2426 */     validate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void componentResized(ComponentEvent ce) {
/* 2439 */     doDebug("Something is being resized.");
/* 2440 */     doDebug("videoPanel=" + this.videoPanel);
/* 2441 */     if (this.currentPlayer != null)
/*      */     {
/* 2443 */       doDebug("pb=" + this.currentPlayer);
/*      */     }
/* 2445 */     if (ce.getSource() == this.gifPanel) {
/*      */       
/* 2447 */       doDebug("resize gifPanel: " + this.gifPanel);
/* 2448 */       videoResize();
/* 2449 */       if (!this.msVM) {
/* 2450 */         updateGifPanel();
/*      */       }
/*      */     }
/* 2453 */     else if (ce.getSource() == this.currentPlayer) {
/*      */       
/* 2455 */       doDebug("resize currentPlayer: " + this.currentPlayer.getSize());
/* 2456 */       JMFUtil.center(this.videoPanel, (Component)this.currentPlayer, true, (this.currentPlayer.getPreferredSize()).height - (this.currentPlayer.getVisualComponent().getSize()).height);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void componentMoved(ComponentEvent ce) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void componentHidden(ComponentEvent ce) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void componentShown(ComponentEvent ce) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doDebug(String s) {
/* 2503 */     System.out.println(s);
/*      */   }
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\bean\multiplayer\MultiPlayerBean.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */