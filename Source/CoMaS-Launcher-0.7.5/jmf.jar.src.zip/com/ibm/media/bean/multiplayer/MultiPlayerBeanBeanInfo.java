/*     */ package com.ibm.media.bean.multiplayer;
/*     */ 
/*     */ import java.awt.Image;
/*     */ import java.beans.BeanDescriptor;
/*     */ import java.beans.EventSetDescriptor;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.beans.SimpleBeanInfo;
/*     */ import javax.media.ControllerListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultiPlayerBeanBeanInfo
/*     */   extends SimpleBeanInfo
/*     */ {
/*     */   public PropertyDescriptor[] getPropertyDescriptors() {
/*     */     try {
/*  42 */       PropertyDescriptor background = new PropertyDescriptor("background", beanClass);
/*     */       
/*  44 */       PropertyDescriptor foreground = new PropertyDescriptor("foreground", beanClass);
/*     */       
/*  46 */       PropertyDescriptor font = new PropertyDescriptor("font", beanClass);
/*     */ 
/*     */ 
/*     */       
/*  50 */       PropertyDescriptor UrlVisible = new PropertyDescriptor("URLVisible", beanClass);
/*     */       
/*  52 */       UrlVisible.setDisplayName(JMFUtil.getBIString("MEDIA_NAME_VISIBLE"));
/*  53 */       UrlVisible.setBound(true);
/*     */       
/*  55 */       PropertyDescriptor PanelVisible = new PropertyDescriptor("panelVisible", beanClass);
/*     */       
/*  57 */       PanelVisible.setDisplayName(JMFUtil.getBIString("CONTROL_PANEL_VISIBLE"));
/*  58 */       PanelVisible.setBound(true);
/*     */       
/*  60 */       PropertyDescriptor loop = new PropertyDescriptor("looping", beanClass);
/*     */       
/*  62 */       loop.setDisplayName(JMFUtil.getBIString("LOOP"));
/*  63 */       loop.setBound(true);
/*     */       
/*  65 */       PropertyDescriptor sequential = new PropertyDescriptor("sequentialPlay", beanClass);
/*     */       
/*  67 */       sequential.setDisplayName(JMFUtil.getBIString("SEQUENTIAL"));
/*  68 */       sequential.setBound(true);
/*     */       
/*  70 */       PropertyDescriptor fixAspect = new PropertyDescriptor("fixAspectRatio", beanClass);
/*     */       
/*  72 */       fixAspect.setDisplayName(JMFUtil.getBIString("FIXASPECT"));
/*  73 */       fixAspect.setBound(true);
/*     */       
/*  75 */       PropertyDescriptor buttonPosition = new PropertyDescriptor("buttonPosition", beanClass);
/*     */       
/*  77 */       buttonPosition.setDisplayName(JMFUtil.getBIString("BUTTONPOSITION"));
/*  78 */       buttonPosition.setBound(true);
/*  79 */       buttonPosition.setPropertyEditorClass(ButtonPositionEditor.class);
/*     */       
/*  81 */       PropertyDescriptor loadOnInit = new PropertyDescriptor("loadOnInit", beanClass);
/*     */       
/*  83 */       loadOnInit.setDisplayName(JMFUtil.getBIString("LOAD_ALL"));
/*  84 */       loadOnInit.setBound(true);
/*     */       
/*  86 */       PropertyDescriptor linkList = new PropertyDescriptor("links", beanClass);
/*     */       
/*  88 */       linkList.setBound(true);
/*  89 */       linkList.setPropertyEditorClass(LinksArrayEditor.class);
/*  90 */       linkList.setDisplayName(JMFUtil.getBIString("RELATED_LINKS"));
/*     */       
/*  92 */       PropertyDescriptor mediaNames = new PropertyDescriptor("mediaNames", beanClass);
/*     */       
/*  94 */       mediaNames.setBound(true);
/*  95 */       mediaNames.setPropertyEditorClass(MediaArrayEditor.class);
/*  96 */       mediaNames.setDisplayName(JMFUtil.getBIString("MEDIA_GROUP"));
/*     */ 
/*     */ 
/*     */       
/* 100 */       PropertyDescriptor[] rv = { mediaNames, linkList, UrlVisible, PanelVisible, loop, sequential, fixAspect, buttonPosition, loadOnInit, background, foreground, font };
/*     */ 
/*     */       
/* 103 */       return rv;
/*     */     } catch (IntrospectionException e) {
/* 105 */       throw new Error(e.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDefaultPropertyIndex() {
/* 116 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDescriptor getBeanDescriptor() {
/* 126 */     return new BeanDescriptor(beanClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EventSetDescriptor[] getEventSetDescriptors() {
/*     */     try {
/* 138 */       EventSetDescriptor cl = new EventSetDescriptor(beanClass, "controllerUpdate", ControllerListener.class, "controllerUpdate");
/*     */ 
/*     */ 
/*     */       
/* 142 */       EventSetDescriptor pc = new EventSetDescriptor(beanClass, "propertyChange", PropertyChangeListener.class, "propertyChange");
/*     */ 
/*     */ 
/*     */       
/* 146 */       cl.setDisplayName("Controller Events");
/* 147 */       EventSetDescriptor[] rv = { cl, pc };
/* 148 */       return rv;
/*     */     } catch (IntrospectionException e) {
/* 150 */       throw new Error(e.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Image getIcon(int ic) {
/* 156 */     switch (ic) {
/*     */       case 1:
/* 158 */         return loadImage("IconColor16.gif");
/*     */       case 2:
/* 160 */         return loadImage("IconColor32.gif");
/*     */       case 3:
/* 162 */         return loadImage("IconMono16.gif");
/*     */       case 4:
/* 164 */         return loadImage("IconMono32.gif");
/*     */     } 
/* 166 */     return null;
/*     */   }
/*     */ 
/*     */   
/* 170 */   private static final Class beanClass = MultiPlayerBean.class;
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\bean\multiplayer\MultiPlayerBeanBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */