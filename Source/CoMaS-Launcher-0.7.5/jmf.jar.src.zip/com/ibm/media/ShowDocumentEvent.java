/*    */ package com.ibm.media;
/*    */ 
/*    */ import java.net.URL;
/*    */ import javax.media.Controller;
/*    */ import javax.media.ControllerEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShowDocumentEvent
/*    */   extends ControllerEvent
/*    */ {
/*    */   private URL u;
/*    */   private String s;
/*    */   
/*    */   public ShowDocumentEvent(Controller from, URL u, String s) {
/* 31 */     super(from);
/* 32 */     this.u = u;
/* 33 */     this.s = s;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public URL getURL() {
/* 43 */     return this.u;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getString() {
/* 53 */     return this.s;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\ShowDocumentEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */