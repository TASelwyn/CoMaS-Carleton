package com.ibm.media.controls;

import java.awt.Component;
import java.util.Hashtable;
import javax.media.Control;

public class ParametersControl implements Control {
  Hashtable parameters = new Hashtable();
  
  public String get(String param) {
    return (String)this.parameters.get(param);
  }
  
  public void set(String param, String value) {
    this.parameters.remove(param);
    this.parameters.put(param, value);
  }
  
  public Component getControlComponent() {
    return null;
  }
}
