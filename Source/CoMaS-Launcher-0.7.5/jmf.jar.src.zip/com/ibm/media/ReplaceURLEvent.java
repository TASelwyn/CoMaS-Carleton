package com.ibm.media;

import java.net.URL;
import javax.media.Controller;
import javax.media.ControllerEvent;

public class ReplaceURLEvent extends ControllerEvent {
  private URL u;
  
  public ReplaceURLEvent(Controller from, URL u) {
    super(from);
    this.u = u;
  }
  
  public URL getURL() {
    return this.u;
  }
}
