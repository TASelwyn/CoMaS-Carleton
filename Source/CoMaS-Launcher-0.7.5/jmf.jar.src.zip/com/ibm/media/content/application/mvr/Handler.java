package com.ibm.media.content.application.mvr;

import com.ibm.media.ReplaceURLEvent;
import com.ibm.media.controls.ParametersControl;
import com.ibm.media.util.PullSourceStream2InputStream;
import com.sun.media.BasicPlayer;
import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Panel;
import java.io.InputStream;
import java.net.URL;
import javax.media.Control;
import javax.media.Controller;
import javax.media.ControllerEvent;
import javax.media.IncompatibleSourceException;
import javax.media.SizeChangeEvent;
import javax.media.TimeBase;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.DataSource;
import javax.media.protocol.PullDataSource;
import javax.media.protocol.PullSourceStream;

public class Handler extends BasicPlayer {
  public Master bl;
  
  public DataSource bk;
  
  public InputStream bd;
  
  public ParametersControl bj = new ParametersControl();
  
  public Applet bi;
  
  public boolean bh = false;
  
  public Applet bg = new Handler$AppletAdaptor(this);
  
  public static void cd(Handler paramHandler, URL paramURL) {
    paramHandler.ch(paramURL);
  }
  
  public static void ce(Handler paramHandler, Component paramComponent) {
    paramHandler.ci(paramComponent);
  }
  
  public static void cf(Handler paramHandler) {
    paramHandler.cg();
  }
  
  public static Applet b6(Handler paramHandler) {
    return paramHandler.bi;
  }
  
  private void cg() {
    sendEvent((ControllerEvent)new SizeChangeEvent((Controller)this, (this.bg.getSize()).width, (this.bg.getSize()).height, 1.0F));
  }
  
  private void ch(URL paramURL) {
    sendEvent((ControllerEvent)new ReplaceURLEvent((Controller)this, paramURL));
  }
  
  public void processEvent(ControllerEvent paramControllerEvent) {
    if (paramControllerEvent instanceof ReplaceURLEvent)
      sendEvent(paramControllerEvent); 
    if (paramControllerEvent instanceof com.ibm.media.ShowDocumentEvent) {
      sendEvent(paramControllerEvent);
    } else {
      super.processEvent(paramControllerEvent);
    } 
  }
  
  public void doClose() {
    this.controlComp = null;
    super.doClose();
  }
  
  private void ci(Component paramComponent) {
    ((Panel)this.controlComp).add(paramComponent);
  }
  
  public Component getControlPanelComponent() {
    if (this.controlComp == null)
      this.controlComp = new Panel(new BorderLayout()); 
    super.getControlPanelComponent();
    return this.controlComp;
  }
  
  public Component getVisualComponent() {
    super.getVisualComponent();
    return this.bg;
  }
  
  public void setSource(DataSource paramDataSource) {
    if (!(paramDataSource instanceof PullDataSource))
      throw new IncompatibleSourceException("Can accept only PullDataSource"); 
    this.bk = paramDataSource;
    String str = paramDataSource.getContentType();
    ContentDescriptor contentDescriptor = new ContentDescriptor(str);
    if ((!str.equals("application.mvr") && !str.equals("application.x_unknown_content_type_mvr_auto_file")) || !(paramDataSource instanceof PullDataSource))
      throw new IncompatibleSourceException(); 
    this.bg.setLayout(null);
    this.bl = new Master((PullDataSource)paramDataSource, this.bg);
    manageController(this.bl.b8());
    paramDataSource.start();
    PullSourceStream pullSourceStream = ((PullDataSource)paramDataSource).getStreams()[0];
    this.bd = (InputStream)new PullSourceStream2InputStream(pullSourceStream);
    this.bh = false;
    super.setSource(paramDataSource);
  }
  
  public Control[] getControls() {
    Control[] arrayOfControl = new Control[1];
    arrayOfControl[0] = (Control)this.bj;
    return arrayOfControl;
  }
  
  public void setHostingHM(Applet paramApplet) {
    this.bi = paramApplet;
  }
  
  public void setTrackDefs(byte[] paramArrayOfbyte) {
    this.bl.ca(paramArrayOfbyte);
  }
  
  public void updateStats() {}
  
  public boolean videoEnabled() {
    return false;
  }
  
  public boolean audioEnabled() {
    return false;
  }
  
  public TimeBase getMasterTimeBase() {
    return getClock().getTimeBase();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\content\application\mvr\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */