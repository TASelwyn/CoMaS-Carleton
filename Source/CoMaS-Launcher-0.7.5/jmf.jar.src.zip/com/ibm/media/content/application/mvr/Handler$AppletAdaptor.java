package com.ibm.media.content.application.mvr;

import java.applet.Applet;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class Handler$AppletAdaptor extends Applet {
  public final Handler this$0;
  
  public Component gui;
  
  public Rectangle guiBounds;
  
  public boolean playerExist;
  
  public Dimension parsedSize;
  
  public Handler$AppletAdaptor(Handler paramHandler) {
    this.this$0 = paramHandler;
    this.this$0 = paramHandler;
    this.guiBounds = new Rectangle(0, 0, 0, 0);
    this.playerExist = false;
    this.parsedSize = new Dimension(0, 0);
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof Object[]) {
      int i;
      byte[] arrayOfByte;
      Container container;
      String str;
      Object[] arrayOfObject = (Object[])paramObject;
      switch (((Integer)arrayOfObject[0]).intValue()) {
        case 0:
          i = ((Integer)arrayOfObject[1]).intValue();
          arrayOfByte = (byte[])arrayOfObject[2];
          arrayOfObject[1] = Toolkit.getDefaultToolkit().createImage(arrayOfByte);
          break;
        case 1:
          Handler.cd(this.this$0, (URL)arrayOfObject[2]);
          break;
        case 2:
          if (Handler.b6(this.this$0) != null) {
            Handler.b6(this.this$0).equals(paramObject);
            break;
          } 
          container = getParent();
          if (container != null) {
            int j = ((Integer)arrayOfObject[1]).intValue();
            if (j >= 99) {
              boolean bool = (j != 99) ? false : true;
              j = bool ? 3 : 0;
            } 
            container.setCursor(new Cursor(j));
          } 
          break;
        case 3:
          if (Handler.b6(this.this$0) != null) {
            Handler.b6(this.this$0).equals(paramObject);
            break;
          } 
          container = getParent();
          if (container != null)
            arrayOfObject[1] = new Integer(container.getCursor().getType()); 
          break;
        case 4:
          try {
            Handler handler = this.this$0;
            if (handler.bk.getLocator().getURL().equals(arrayOfObject[1])) {
              Handler handler1 = this.this$0;
              if (!handler1.bh) {
                arrayOfObject[1] = this.this$0.bd;
                boolean bool = true;
                Handler handler2 = this.this$0;
                handler2.bh = bool;
              } 
            } 
            if (Handler.b6(this.this$0) != null) {
              Handler.b6(this.this$0).equals(paramObject);
              break;
            } 
            URL uRL = (URL)arrayOfObject[1];
            arrayOfObject[1] = null;
            URLConnection uRLConnection = uRL.openConnection();
            uRLConnection.setUseCaches(false);
            arrayOfObject[1] = uRLConnection.getInputStream();
          } catch (MalformedURLException malformedURLException) {
            System.out.println("EX: " + malformedURLException);
          } catch (IOException iOException) {
            System.out.println("EX: " + iOException);
          } 
          break;
        case 5:
          if (Handler.b6(this.this$0) != null) {
            Handler.b6(this.this$0).equals(paramObject);
            break;
          } 
          str = (String)arrayOfObject[1];
          arrayOfObject[1] = null;
          if (str != null)
            try {
              arrayOfObject[1] = Class.forName(str);
            } catch (ClassNotFoundException classNotFoundException) {
              System.out.println("EX: " + classNotFoundException);
            }  
          break;
      } 
      return false;
    } 
    return super.equals(paramObject);
  }
  
  public URL getDocumentBase() {
    return (Handler.b6(this.this$0) != null) ? Handler.b6(this.this$0).getDocumentBase() : null;
  }
  
  public void showStatus(String paramString) {
    if (Handler.b6(this.this$0) != null) {
      Handler.b6(this.this$0).showStatus(paramString);
    } else {
      System.out.println(paramString);
    } 
  }
  
  public URL getCodeBase() {
    return (Handler.b6(this.this$0) != null) ? Handler.b6(this.this$0).getCodeBase() : null;
  }
  
  public String getParameter(String paramString) {
    Handler handler = this.this$0;
    String str = handler.bj.get(paramString);
    return (str == null && Handler.b6(this.this$0) != null) ? Handler.b6(this.this$0).getParameter(paramString) : str;
  }
  
  public synchronized Component add(Component paramComponent, int paramInt) {
    if (Handler.b6(this.this$0) != null) {
      this.gui = paramComponent;
      super.add(paramComponent, paramInt);
    } else {
      Handler.ce(this.this$0, paramComponent);
    } 
    Handler.cf(this.this$0);
    return paramComponent;
  }
  
  public synchronized Component add(Component paramComponent) {
    this.playerExist = true;
    cc();
    paramComponent.setSize(this.parsedSize);
    super.add(paramComponent);
    Handler.cf(this.this$0);
    return paramComponent;
  }
  
  public Dimension size() {
    return this.parsedSize;
  }
  
  public void setSize(int paramInt1, int paramInt2) {
    if (Handler.b6(this.this$0) != null) {
      this.parsedSize = Handler.b6(this.this$0).getSize();
    } else {
      this.parsedSize = new Dimension(paramInt1, paramInt2);
      super.setSize(paramInt1, paramInt2);
    } 
  }
  
  public void cb(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.guiBounds = new Rectangle(paramInt1, paramInt2, paramInt3, paramInt4);
    cc();
    Handler.cf(this.this$0);
  }
  
  private synchronized void cc() {
    if (this.gui != null) {
      if (Handler.b6(this.this$0) != null) {
        if (this.playerExist) {
          setBounds(0, 0, this.parsedSize.width, this.parsedSize.height);
          this.gui.setBounds(this.guiBounds);
        } else {
          setBounds(0, this.parsedSize.height - this.guiBounds.height, this.guiBounds.width, this.guiBounds.height);
          this.gui.setBounds(0, 0, this.guiBounds.width, this.guiBounds.height);
        } 
      } else {
        this.gui.setBounds(0, 0, this.guiBounds.width, this.guiBounds.height);
      } 
    } else if (this.playerExist) {
      setBounds(0, 0, this.parsedSize.width, this.parsedSize.height);
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\content\application\mvr\Handler$AppletAdaptor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */