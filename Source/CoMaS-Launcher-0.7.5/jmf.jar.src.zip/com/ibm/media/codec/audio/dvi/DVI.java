package com.ibm.media.codec.audio.dvi;

import com.ibm.media.codec.audio.ima4.IMA4;

public class DVI {
  public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997,1998.";
  
  static void encode(byte[] indata, int inOffset, byte[] outdata, int outOffset, int len, DVIState state) {
    int outputbuffer = 0;
    int[] indexTable = IMA4.indexTable;
    int[] stepsizeTable = IMA4.stepsizeTable;
    int valpred = state.valprev;
    int index = state.index;
    int step = stepsizeTable[index];
    boolean bufferstep = false;
    for (; len > 0; len--) {
      byte b;
      int temp = indata[inOffset++] & 0xFF;
      int val = indata[inOffset++] << 8 | temp;
      int diff = val - valpred;
      if (diff < 0) {
        b = 8;
        diff = -diff;
      } else {
        b = 0;
      } 
      int delta = 0;
      int vpdiff = step >> 3;
      if (diff >= step) {
        delta = 4;
        diff -= step;
        vpdiff += step;
      } 
      step >>= 1;
      if (diff >= step) {
        delta |= 0x2;
        diff -= step;
        vpdiff += step;
      } 
      step >>= 1;
      if (diff >= step) {
        delta |= 0x1;
        vpdiff += step;
      } 
      if (b) {
        valpred -= vpdiff;
      } else {
        valpred += vpdiff;
      } 
      if (valpred > 32767) {
        valpred = 32767;
      } else if (valpred < -32768) {
        valpred = -32768;
      } 
      delta |= b;
      index += indexTable[delta];
      if (index < 0) {
        index = 0;
      } else if (index > 88) {
        index = 88;
      } 
      step = stepsizeTable[index];
      if (bufferstep) {
        outputbuffer = delta << 4;
      } else {
        outdata[outOffset++] = (byte)(delta | outputbuffer);
      } 
      bufferstep = !bufferstep;
    } 
    if (bufferstep)
      outdata[outOffset++] = (byte)outputbuffer; 
    state.valprev = valpred;
    state.index = index;
  }
  
  public static void decode(byte[] indata, int inOffset, byte[] outdata, int outOffset, int len, DVIState state) {
    int inputbuffer = 0;
    boolean bufferstep = false;
    byte[] outp = outdata;
    byte[] inp = indata;
    int valpred = state.valprev;
    int index = state.index;
    int lastIndex = index;
    int[] indexTable = IMA4.indexTable;
    int[] diffLUT = IMA4.diffLUT;
    for (; len > 0; len--) {
      int i;
      if (bufferstep) {
        i = inputbuffer & 0xF;
      } else {
        inputbuffer = inp[inOffset++];
        i = inputbuffer >> 4 & 0xF;
      } 
      bufferstep = !bufferstep;
      index += indexTable[i];
      if (index < 0) {
        index = 0;
      } else if (index > 88) {
        index = 88;
      } 
      valpred += diffLUT[(lastIndex << 4) + i];
      if (valpred > 32767) {
        valpred = 32767;
      } else if (valpred < -32768) {
        valpred = -32768;
      } 
      lastIndex = index;
      outp[outOffset++] = (byte)valpred;
      outp[outOffset++] = (byte)(valpred >> 8);
    } 
    state.valprev = valpred;
    state.index = index;
  }
}
