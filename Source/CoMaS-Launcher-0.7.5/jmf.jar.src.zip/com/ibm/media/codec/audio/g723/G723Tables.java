/*     */ package com.ibm.media.codec.audio.g723;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class G723Tables
/*     */ {
/*     */   public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997, 1998.";
/*  23 */   public static final float[] fLspDcTable = new float[10];
/*  24 */   public static final float[] fBand0Tb8 = new float[768];
/*  25 */   public static final float[] fBand1Tb8 = new float[768];
/*  26 */   public static final float[] fBand2Tb8 = new float[1024];
/*  27 */   public static final float[] fAcbkGainTable085 = new float[1700];
/*  28 */   public static final float[] fAcbkGainTable170 = new float[3400];
/*  29 */   public static final float[] FcbkGainTable = new float[24];
/*  30 */   public static final float[] CosFunction = new float[512];
/*  31 */   public static final int[][] CombinatorialTable = new int[6][30];
/*     */ 
/*     */ 
/*     */   
/*  35 */   public static String s = "L{R±^Jjvvp¯h4£Ì¬@@@@@@>2:ä;8=#9Î:Ú=m8e7<;Þ8ª<4;Ç6ª<Ì:#:ã;%:M9Z;\0059ê7D<7:ß7Ý<:5u<\036:\0212±<80¡?P?ç@\036=«>?? <^>n>??>*>ê>@>¡=á>A<#@P@S=tA¶Aé<t>æ@5>&>7A:=N=Ô?­Gã=Z<äJe?ª>àJÐAqC°Gâ@»B\033J\016>äB=L?Bª@\035Lú??\021P»AÉEXOBBúFæR\001@=øD\r?i=dFè@ì>ñGµ?>@\030GEA¡@¿HÝ;@ü@K=??õ=<s@\036=º=Ø<õ>¼<;ç>Ù:©=Ñ=:Ê;\031??\023>s@c?7=¯?h@¿;\n@<;¼B:x:jA\001?È=BD>Ð<B\027>Æ=2C\r<'=ÚBä<\037=MEG:|>ìF¤>G;ZFG;e9êE<<8:{=±;Á:0<\t;¿9¸;Ü:58m9=Ò:=@y>i9õA=;\0349\036?µ<×7Ô=(98[>Ô7Ú3®:5;`8§4è;5÷4\031@ç?L@A>¤?g?\030>àB¸@#=/AÕ@>Á>@ç=\022=~>-<ê?2>á;ÿ>A?ø>\037B?Ö>fA?e=·@ó>\003<ZA\002>\035<\\Bk@\003=3CPAP<\001?¬>À<ï@=(:ó@.?:öAæ>48\017Ai=_7!?Ñ<\037=ê@A=¤<h?½<\016:->÷=7:\"?©<68\026?ã>à9n=\b=À8#>C<7¹A\020<\021;^@;Ó9\003?:÷7õ?|>¦6Å?<ÿ5F>=:Ú4[?g@D;²< >û;}>Õ<\002<¾=«;Ò<>¾<l:c=Í;¹9<¹<\003<é=<\003:\037;\027<:ÃAù@Y<ñBÏ?%;£DÇ?Ò=C@=9¹AßAÔ??ACÇ>²BÞA3>\034CcB=ÞD¸B<\022B\r@÷AÉCA½@ªB¡@~?%CX@\006>ûB\037Ce@D¶Cl@DDA®>\034E]B'?SFB?ñC2B¿?MC'C\004>\tE\034D±=ÙC\034A¥BÆD\013BÛBëDÌF]C¾E°G\037A\035D²BU@:EÝCÀAÇF%D@£DDCbF|CD®CéDÉAWF÷D&BëEzD~@cEËElAìEÔE4@hH|Fz@C7B`D\006D¡CÝD/DFEfE\rEOCUGYEkD8GµFüD\025GKGEFÙCH¥EEUH>GB9KoIoD]@t@ã?ô@&Au>T?ùB«@g?fCA3=²B ?q=)D+@Û>`E\004BÃAFDy@¦AuFx?B³FBVABÃA\bB6BÞB\t@\nD¦BÒB¤D«BÚBîD\007D°?½A¹BM@jB\004CË@E\020DKAðHCÈ@ÉC\025Et>C6D°<ùGAD\036=\021Ai@\006<îBíAþ;GB¸Cz>¯= @í=O<'@Ð>?7CD?Í?ME^=¢>3A¶;=?3B¿<É?ïD±;C>y@Þ:½=pB @ì@AÓAÂ@?B4>LBJCÎ<BÓE¬>µAmE>ÜC@GU=ÛCI³Aý?Æ@<Bµ?éB\023A[?CC¦A\b?ÌE¥B5@ôDcBTAØE%CóA`GNEmC\"I\034C¼D\003K\017EµF|MD·FPI2GzEÙJÖ?6@ÆC*@ÚA3EkA<CXDA=E|FB:CFCSB$IPCZFÿECA\021H|F¼?ÈEëF>¾G H¹C»D\tHBA\bE\bHÉE\025ECDùEµF¤E.F0F\nFPFdFâHE­HD7GçI­DEKE!HÞGóFH\\GÞH(FõH3GI~I\023GáKqKVI\032I'MÉG\033MuP_JCJ«H1F!J\025IaEÇL=KIrLLvJ£P OêDXF:GZD\032HH\000E(H_J\034FeIûLHöIJ\036AàF-JÐB\025I`L!D$IOÊHnH\034M0G\033JØQðE}MóOdD\000OSzFÝRùW¼@@@@@@7þ:*@5ä;B:è4!<\004>ã1\\7²>ã0Ö>Ô>5.´1)2-¤9p?\r=L@?§;A8@¬:¶DÏ<ý<ÀAÆ=\0079@;Á8&Cå8\0366MAÛ8\0168&Eë6º9õCM56E_<D$A\0359ãFØB;B©AX9wAÉB:HDuDï7Ë?EÀ6x;\001I2¾?E³:Ë?Þ<õ7t?;Ã:o=j:=9*>79p8õ<\0138×72:T6\0345\035;Ê4\023@ê@n<\r??t;ÁA?|:DCLA<\020@\tA±;eBÊ?o;\034D¸?1;Dó>=8õ<Æ=\f:ª=Â<ì8¿@ñ=]:ò>;=29¾@\016>©7qA=2<\nAå;ù<OB==á:ÀCy:18lA¥<·8)?\006;`9\f=ì:¤8B?÷;¹7ü?Í:Ú5+? 98 ?:7¬4¶=·95\025=×:3n<8]3\"<\024FHGÑ8\002B~G\020:D´J5ÅF\024Eì6H\001I\033COG¶EÛBJºE @,HÕG>{K¿HI=HÂJE:\002LÁM@> ?AF@¹?«?B6>¤@\016DN?tCFi>wBüCé=À=\tE$=0<@?_=1>=\f;ù>ô=Z>ß?:8>u@8\003>\\>.9.=eCy6Ç?VA¾9Ae>16mAé=\f5\031CrA\020>Ú@¶>É=Û@\006<Ö=Bë>ü:øDÃ?;û@Á>ü; B£<æAñAÂ>Ì?ÈA&=Æ@*C=ÉB@À@nDAÚ@ßB\013?¯>Dî?ë=ïE®A¯>ÚFÓAª<|FïB®@mG1C>ÁKBe>F@GAÑ@t@CkAßBvBÜ@iA\023D\002@Â@Cý??'F±?Ù=«AD@\026<£?âB¤>ÿ>C\005<,= F7AÐ=CKB%=íF£?AsBÑ>ÂCC§<\022AÐD\007A¬BD\037@y@Fc@×A\027H/?ïC=E\036@#EþDBÒD;FµBØE\006IAG?ÁAüAH@C\tCZ@ëBCu@úD\nAÔA\016BEACÖCZE@EÏ@\004EíG#A­FE\tBàIFìA<CfD\026B}B\tDÆDvEEEÜD\020F>DäDµB=BÃC DHC]D?CÄBsGcE*BáIHFHD©LèEýDZFzGÙEfG\004IG*HLM\022HIJ|D!?Ê@Fÿ@\002AåH^?\016>qC\nBð>D½Cø?ÒD&D;=µEªCáAÑGèDÏ@(A×=P?MC;â@ì?]<ä<`<$;©:Ü@H:>>¼A¡9K;3=d>³<\031<ë?$:\002;s;8<I;Û6Q:9A58Ý6Ð3{<ª9ã<1=ü7Õ=;÷6\004?à:Õ:W@G9\f7$=¨:5<06ö3ó?\b4\0307\024?2\0011ÄA|;¨<Æ=Ú8¨;\033< >\025:S<X=À8\006:J::@;o8Þ89d;\0028¿7ö=R6+7l:\0236Ó5Ï;æ6R2½:\0034ë0Å;¸7:Ï<W5l9\0339\0065ï8:B4Z5\00077¬=5I4R;ò8h4(;82<9¡92V>G6a0 8á6#57H2Ð6ß3µ8h2x277y3e.¢>eCõ@Û?«EBa=KF¬D{?gHEE:§H=EöA/F½BQ@JG5B$HbGªC\022KOH6CÏCCYAäD\007C?CD\025A\003CLF\020B\004CvE=A\\E¨HB¡FBIAB²B\\IDãCûJZD'?9LlD«B\026M§F\002AìJîF°E[KìD\017G\032M\003G(E\020DJF¹C§DöH³DLGOID\021GPF)E\025FeI\\F3D\000FGE\bGªI\021A\021JÔJ\030CCNvMJGJgJKIJùIäJIÇFqHnKÚE\\G&K1G\017M¤K GXQøKÞHDVJCHfEM*INI\017G£KèGIBOÒL\bK¬N¢LM,H NHOÀKFI¿MiK=GËR¥LRJP¼OÒR_O\030NO\003T\026Sp@@@@@@@@BB@=\"AAìD>\\?¼BÌB®>¹=\004AºC_@Í<äDPAÙ@°=\026D£BÞ?õ<ñEÍA.>\005;ùCSC)@²>tC\034FÈ@\030=C/D\031?¼;aDqAÏ@ú?;D.@\001=?¿A@\004@s=¿C?\005A>vD-BwB>æE<Cµ@\022=;G+Cé@±<(E§DhA@fGìEüA\013@ÅHNDâ?Þ?ÇJQEåA:>ËIFFÒ?><K|GÓB=@ÊM=IxBÉ>¢@\033@ð>²>\013Aò?ò><Ð>èAmAI=\030<­A\026BÑ>ÄAã>?>{A<@H=\016CU?\025@T<An=î>à;¹DP@¬=¤<¤Eu@\022;9ÁA#B>â;ÌC+Cx<\036; B)@z=ó:A@7<­9­ANC\\=p8EDøB\022?b?E\016DÜ>¤= Fú@ó?û=7G?C=¦:¾?®@\036>'<\033?@?Î:%?¨D~?O=D>B\035=ç:*<ÿ?>á=ç<è>>¥;\035=U>Ý=ú9Ô<û@\022<¬;È88@`<Ò9©?\020?);Æ@t>â>§9È>ÔAI=h<æ=ÿA\n?I;Ë<[Bó>©8|;·?þ?Ø=;_>?ã;8\f@\013=d<X9£@J<\0008\n8%A-?À:¤9XA(>\t9~6T=³=,;Â;¬;\002>\0379:C=;;9Z;8:w7&:M=o;|7[5\030@L=%:t;Õ?\030<±7\006>>i>\\7e93?³<d49977\n=ùA:Ù5l>¾?37ú5#;@7Ý3¡<{AÆ4»3\\=ÓB½0ý/\026<ßCc:9<ó>É=\034:¸;¯>Y;C:È9¦;=>8^8Ë;;T:¶78S?À7-45»>\n<;<9>@ù9ð<­7£=\033@S<\013;ÇA @ø;©:ô=Í=\035;\0009Ã<±?h:b7«<<%:&6ú>}<¤8ß5T==è9ò1'<Ë6è6`AAo4ä7\021>\nB}2¼7ã@q?Ï7>Bã?®5K=,D\017A\0375Ä>Z?xB£2{<u?zB\0001Å@íA@>-Â:?\036C°CI>@@²?6D\"?þAú?;BB¥A\004>àD\bCIBã<J:ä?ñ;?R6ë?/;»<\016:`=;Ó;\0348<!8k88K<\";\024?×3Ê<½8'?~?¤<ÊAÊ>\002>>:=Bg@\n=(9CÎA<ñ;ëC[?;­;ØB\013BG;\b:\031FÕBÜ<X8¿@ @\023:q7ÜC@î;Í>ÊAÞ?<:S:ÙAÌ>à<LA÷?\005<y8,B\002>;:8>÷?\036<\00569\f?©=â7ÏA¶>'@4|@'?1=DBvB\021@\021FÕBtA¿@¢GªB.CX?ßBl?\000Bq?ãC¬@âCÑ?*C\001BãEP@ÌB4>´CB`A¨>\021E}AÌC®?*EøC>\013>/BÂ?¿=?îCA\006?;?\021DmC&?âC\007D=Aj>WAÁE\001B*>Ï=sEu@2AY<_FþCÜA\020BFgE ?F@\016IcD×>A¹=ë>#<DCS<*>!>v>¦@\027Ag=ó<ä?ÇC];©@º>A\022:x?ÇA¯CÜ@*ACB=\025@Ñ@^C$@Z@C@?¯?ËD-A\032>±:iD[@\032>F:ÒBöC\"@B¨@G@ApDd@t?\002CCA\006BÉE<>A\020@o@=\002Dï?\031A»@²?ÞA(A%B\027@4BBø?ôA\007BßBb=\013?3@ÑCs>ÈByA\000D¨@\032@ºAIDÏ@&B\"CäC+@ÊA\035@dA\002AÔCS?÷C(A1D+AÃD\017@Q@\017@\003?ñBrA¦@u?¢A-AÃA\036@ýBæCBÀBn?{BKB¥@yAíC¾CA@¯@DÖBxA?D\032Cx@;CEËDrC A!CÜE\002BÝB\024FCGBÎFvAýADB]A\030EÍD0DCZB\037DBÜD_CDèC<CJDCfGFD\\E7FsH§C±FPD1AÇB\026C¨GTBEýAXC0B¨E»BGKD\034F²EbD¼DpEQFÅG·DBHmDTHDåF¬GéJ[E(@Y>\005?7?ÖAb>íAì>?ü<1B\037CD@5=\025A\024@oA<ÁCn@Ò@+A°<|<?uA{9\";Ca@Q>,>ÞC¾>Q<+=ÅB\fAc;>ÛBp><=c?>Bç>D:«@\023?\r?\002>BmA=Â?mB¦<Ò;\037?ì?ù>¼:¹?>\002=N9\032@\026=%:µ8l?ä<-?\021<è>å?A@W;?A=®>Y<ÃA¡<19\r=øA;:´<å>ÆAù7\021:m?·A÷>ÿ::8?4>Ù7ÿ=\027?8<\0018Â9'@`<J6:ñ<>e>\t??T<µ>AT=Ý?à>°@r=z><B?6<g?{>>=X=\001=Ý<<=>¶>5<8=Ü<?@:þ<\036;Þ<$9\036<\007=NB\bC¬@Í@#C\025E%@@¼EöD\fC\023?\031F\006C'E\tAøH5DCAAøI\bE\bD\031A¤IêGµFVCjCÕD®B?ºA=GQCM?ÅFðE\"Bo>G5IMB\026?¥K\027J´DóANL\nF(BSFGoC£@÷F.GôFB@¡G^H®EBBÓHîJ\006GZCÄLóHFûC$NqI`I¨EíK«MýJGEf@@@@@@@@@@C`E\030@ç?@>î>r=A-JOAwE\013@ÐCPCàD\033?óASM\002D`;Z?Ã?\030>8A½Sã@ÊAHçJNE{N¥K<ÉC¢9ÙE´H¢HûACî@MQ»M\035<\034=±=l@>@2WáIÞB²9W)Q\021;\033>âE¯_qA?>«L=/B I\"OfJ]=K%U#>¬LcBAE16,\006IäWºD>ºGéRåJ\016IR>0tFÁ8éEãFåa²JÜcs<QB39G5]¼EECêMNC²O\022DòISG>=O@ºg¶BA\0018)i\002O^=1<IpSùNJ8éC\\Lme¡>¬9G;7\020f\032Oá)´=Ö0ïA\\3íA¾RÌ_70HÖ<ÝK\007nÖ9µCó,û>Z¥NûE@Øe>PÇ8¸E\022I\020@\001cT13ôaPK\\@LBeHH5\026[>c:ú?LAVs;D\013?8¥`YX½CÕ6A8.HM5cWèg^Óc\t2ïIé:Z:ª`¹e4µFKC/©UOa!J\004@Íx\030BòAA?Ðnâ8ýGN<~<ÌNÐGþH\030Q(L{;£B>B\020w\037?h.\037R\032gÀFaM|>GÌ|'8\016BÑ/\023GtOºUÍXB\0317EyãN<:×Vét[3ÿER¦eýDq6L\nGs1\030pÆZ29)EÙII\013E¤b9r³V;7«C\037z H®;cCÎ>PRo\\×StB2\013Dç7äT@tú:¶:F<\017_?eà:3BFà7\006l\035LÃ8Ñ<ûe\017[Ñ@\025=±·B¬>ÀS @c25NÎah<dEî5ÀzÿJº,?4&?\013U·Y»LDz\0354ÞGR<uE_T+knH;1úO\003U3RJGWG¸7íJ\002.«r]HU2==LÓ/\013R9Gn9D³#B\fGú0;gn65\030k.lY1\001E÷M²CËJåcJNv?ÂMÙ8mD8*DX7ÌO&ÐdÊqd8åC\002=×FìP§\\\033XÿC+5\000U7Þ6\017BDû<îDé8º~¸OÏ7:l2?-Nf<.:ö~\034\\9¿/d>AZRmÑRY^(Q\rGÑG[½MªK×V+`Db~V9c\030_÷OM[@@@@@@@@@@CH@\024B\013BÞCiEPEd?>\000<\021=óBèIîAt=ì=a>Y?;KÄA\024DRF\002DlAB²A&<?O*KI;íE1=A?ÄP DBI¹D3M¯?å;²;]C\017@íO\007G\025G\\B¸EjHNDG>Sh@4>\0058J?p;òA\017>VURÃJh8øC9.G¦M\r@c?&H¡5µGqO(IËFn<ôM^W\032;\035='D#C8K\fHâEåHsH%O\006M\r4\nAÐ;æaI¶;ã.\0228eO6ÙH\022F':PÐXP=KFz:DK[ZGÀ=\016R¬O5=ñIµFPb<A¢:°R\037.ñ@i:y4 HjDèC.F­R5IVEÒ?âE:ûDF»bûAyf<CÔ>Ã<\030@Ib;9?HOYXV;h>ïN;CQY?¼5$FåSAJbL\037O¨E\tBêPwB°CoQÅHõ2I>×S|J'R6jN\017aïA{Iá=Kíf%>;Ê8Â@¨3Ê2î.è2!9¼G~[[EÖ@je*L<CËFCQKnP'L+ZÑMHóFÒ3¯MÃOzA¬^á5ð(22¾68âP.1ÂD­^éM³?iPdKL@B/Ì/,V3ap8<E 9FLMÛM\032<'QÉK]_]N¯*\bOÊFB@Ö[#HALYBª] R¹?R2\023KÕ4{^([ä8sIË<;çe\rPjGîL-g¥2ùHy?Ð:èbäR\026H@5\033Aö8\021X\\¢M¾BicçS*d=,=©o&Iÿ<T7\fEe:[láKõDé5·k;T==EI¥>ik@\013CN8ñVulZ5ÚE1Wg3+SñT6Ne^W6¸GÈ,ÝM0Q0UÄM»F\0215&OÏjÓ91C£>x=iMinn]¯I¶GÆE½FDQ=a?²sÙE+_NZ:<PJá-®:ÝQê=þ)ÛLÔWWcI¾5¿A¹E`vÚ:Bå2ÕZ²Az<ËVvL£b7lJ·K=UõE%U_?Ã#f4*JcsìAOGABØ>*z¶C÷=yChF*a\022V':rK7FCG\020=\"e¨BBwC>ýCÀ<ÅC¼@ÞTµkq9ý9ôJD/xp.VSY%bB¤W\035RÑK->FI£eÙEj=Nr¨QÀ7ÿEÿPßE\004SÿIK :åBWEÉyL<[T89pO3;lNéFt3'xN³;­@\024_ud?20G\031CH6=Í[R[QIu/å[:^CMkAQ)v%1UD\0023M\013A\033Hmÿ4wOLFý`8TÉ<³L¼|Ø6`DjCÿ2\026eÑe9_]×nT-SLô9YIFúF$/áW¿6ÌoÁSîEF7\0167:\003\\d>8DF[ºPÇFOLETAn{>c9kH:3@N3Waf8;+N%V-\0062ìVjE1ès¢[Z9¦H§1>[eo£;x4÷eïhd5C#XaHÈBkG\001Yý>TAÇN=@0qU5úK\0035¹1\024=*M·[Z+ÉWM_ëNR.XMZVPC;\016IlDw~#@2<ÏFÚ>*@#;1F¤q}â:B~=å?ÕI¦<üsè_y/L°x`28H\017879ôI\b=%=ºI<#5¸xÓUG5½I:.e¥iß/T.\0219ÇSP\\\0172\\-f#JÅ4¥Z}1p^{J.MáTÏfjMÇDm0½D\0335öÄGAJÃKTLaVR\021QNKÀ\\jNkDÉvO¯=¡6?MZ[ÍV\027K±`ú-7±rfc\0360õF,/szVÇ>P{^ã;^@\022[\002+í6¡_(x\0270üGd9\025A>05~ß'EpS%,i]\001L\026.£ljkQ5\001Uÿý1DÎ=97è>{üS49ÐH\0333_I5ó<)NG«2\034XÇp\036_´H-'\017TRW³>¾7M]?|[5J\031;«OÐsWI\f8éF+5ÄGiD\\QÏ|ßEû0K\002I0[y]ÇG\f+ç8õbIh¯FM/faCÑ]»5rÁ;}IÐF\035XßYPdLLV1\fR;\":\tCjbÌ^øBÎ0a)\020GJdLC$d8KÅo$hr>O0Ù4éFPzSf2>PLë`j]âMmH§\032¡@|MíT/gæ%f6G*ú7­!2ë;ËRVul^\031Qz)\022_0¨N#V[mOHÛ>|\\AK¢4ÞMÝ0Ãu«^ãG³C>bò_du/e{EÜFF3ut+gU7iFûTñ`öbè^NYÊ@B@D@F@H@L@R@Z@d@t@@®@à@&AA BøC,EìHtK\032QbX\004c\fsþ";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 429 */     byte[] buf = new byte[7738];
/* 430 */     int[] ibuf = new int[3869];
/*     */ 
/*     */     
/* 433 */     s.getBytes(0, 7738, buf, 0);
/*     */ 
/*     */     
/* 436 */     for (int i = 0; i < 3869; i++) {
/* 437 */       ibuf[i] = (short)(((0xFF & buf[2 * i] - 64) << 8) + (buf[2 * i + 1] - 64 & 0xFF));
/*     */     }
/*     */ 
/*     */     
/* 441 */     int index = 0;
/* 442 */     float[] fG = new float[6];
/* 443 */     for (int k = 0; k < 10; k++)
/* 444 */       fLspDcTable[k] = ibuf[index++] * 0.0078125F; 
/* 445 */     for (int m = 0; m < 768; m++)
/* 446 */       fBand0Tb8[m] = ibuf[index++] * 0.0078125F; 
/* 447 */     for (int n = 0; n < 768; n++)
/* 448 */       fBand1Tb8[n] = ibuf[index++] * 0.0078125F; 
/* 449 */     for (int i1 = 0; i1 < 1024; i1++) {
/* 450 */       fBand2Tb8[i1] = ibuf[index++] * 0.0078125F;
/*     */     }
/*     */     
/* 453 */     for (int itable = 0; itable < 2; itable++) {
/* 454 */       float[] table = (itable == 0) ? fAcbkGainTable085 : fAcbkGainTable170;
/* 455 */       for (int i5 = 0; i5 < table.length / 20; i5++) {
/* 456 */         for (int i6 = 0; i6 < 5; i6++) {
/* 457 */           table[i5 * 20 + i6] = ibuf[index++] * 6.1035156E-5F; fG[i6 + 1] = ibuf[index++] * 6.1035156E-5F;
/* 458 */           table[i5 * 20 + i6 + 5] = -fG[i6 + 1] * fG[i6 + 1];
/*     */         } 
/* 460 */         table[i5 * 20 + 10] = -fG[1] * fG[2];
/* 461 */         table[i5 * 20 + 11] = -fG[1] * fG[3];
/* 462 */         table[i5 * 20 + 12] = -fG[2] * fG[3];
/* 463 */         table[i5 * 20 + 13] = -fG[1] * fG[4];
/* 464 */         table[i5 * 20 + 14] = -fG[2] * fG[4];
/* 465 */         table[i5 * 20 + 15] = -fG[3] * fG[4];
/* 466 */         table[i5 * 20 + 16] = -fG[1] * fG[5];
/* 467 */         table[i5 * 20 + 17] = -fG[2] * fG[5];
/* 468 */         table[i5 * 20 + 18] = -fG[3] * fG[5];
/* 469 */         table[i5 * 20 + 19] = -fG[4] * fG[5];
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 474 */     for (int i2 = 0; i2 < 24; i2++) {
/* 475 */       FcbkGainTable[i2] = ibuf[index++];
/*     */     }
/*     */     
/* 478 */     for (int i3 = 0; i3 < 512; i3++) {
/* 479 */       CosFunction[i3] = (float)Math.cos(6.283185307179586D * i3 / 512.0D);
/*     */     }
/* 481 */     CosFunction[128] = 0.0F;
/* 482 */     CosFunction[384] = 0.0F;
/*     */ 
/*     */     
/* 485 */     for (int j = 0; j < (CombinatorialTable[5]).length; j++) {
/* 486 */       CombinatorialTable[5][j] = 1;
/*     */     }
/* 488 */     for (int i4 = 4; i4 >= 0; i4--) {
/* 489 */       for (int i5 = 0; i5 < (CombinatorialTable[i4]).length; i5++) {
/* 490 */         int sum = 0;
/* 491 */         for (int i6 = i5 + 1; i6 < (CombinatorialTable[i4]).length; i6++)
/* 492 */           sum += CombinatorialTable[i4 + 1][i6]; 
/* 493 */         CombinatorialTable[i4][i5] = sum;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\g723\G723Tables.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */