package com.ibm.media.codec.audio.ulaw;

import com.ibm.media.codec.audio.AudioCodec;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.ResourceUnavailableException;
import javax.media.format.AudioFormat;

public class JavaEncoder extends AudioCodec {
  private Format lastFormat = null;
  
  private int numberOfInputChannels;
  
  private int numberOfOutputChannels = 1;
  
  private boolean downmix = false;
  
  private int inputSampleSize;
  
  private int lsbOffset;
  
  private int msbOffset;
  
  private int inputBias;
  
  private int signMask;
  
  public JavaEncoder() {
    this.supportedInputFormats = new AudioFormat[] { new AudioFormat("LINEAR", -1.0D, 16, 1, -1, -1), new AudioFormat("LINEAR", -1.0D, 16, 2, -1, -1), new AudioFormat("LINEAR", -1.0D, 8, 1, -1, -1), new AudioFormat("LINEAR", -1.0D, 8, 2, -1, -1) };
    this.defaultOutputFormats = new AudioFormat[] { new AudioFormat("ULAW", 8000.0D, 8, 1, -1, -1) };
    this.PLUGIN_NAME = "pcm to mu-law converter";
  }
  
  protected Format[] getMatchingOutputFormats(Format in) {
    AudioFormat inFormat = (AudioFormat)in;
    int channels = inFormat.getChannels();
    int sampleRate = (int)inFormat.getSampleRate();
    if (channels == 2) {
      this.supportedOutputFormats = new AudioFormat[] { new AudioFormat("ULAW", sampleRate, 8, 2, -1, -1), new AudioFormat("ULAW", sampleRate, 8, 1, -1, -1) };
    } else {
      this.supportedOutputFormats = new AudioFormat[] { new AudioFormat("ULAW", sampleRate, 8, 1, -1, -1) };
    } 
    return (Format[])this.supportedOutputFormats;
  }
  
  public void open() throws ResourceUnavailableException {}
  
  public void close() {}
  
  public int process(Buffer inputBuffer, Buffer outputBuffer) {
    if (!checkInputBuffer(inputBuffer))
      return 1; 
    if (isEOM(inputBuffer)) {
      propagateEOM(outputBuffer);
      return 0;
    } 
    Format newFormat = inputBuffer.getFormat();
    if (this.lastFormat != newFormat)
      initConverter((AudioFormat)newFormat); 
    int inpLength = inputBuffer.getLength();
    int outLength = calculateOutputSize(inputBuffer.getLength());
    byte[] inpData = (byte[])inputBuffer.getData();
    byte[] outData = validateByteArraySize(outputBuffer, outLength);
    convert(inpData, inputBuffer.getOffset(), inpLength, outData, 0);
    updateOutput(outputBuffer, (Format)this.outputFormat, outLength, 0);
    return 0;
  }
  
  private int calculateOutputSize(int inputLength) {
    if (this.inputSampleSize == 16)
      inputLength /= 2; 
    if (this.downmix)
      inputLength /= 2; 
    return inputLength;
  }
  
  private void initConverter(AudioFormat inFormat) {
    this.lastFormat = (Format)inFormat;
    this.numberOfInputChannels = inFormat.getChannels();
    if (this.outputFormat != null)
      this.numberOfOutputChannels = this.outputFormat.getChannels(); 
    this.inputSampleSize = inFormat.getSampleSizeInBits();
    if (inFormat.getEndian() == 1 || 8 == this.inputSampleSize) {
      this.lsbOffset = 1;
      this.msbOffset = 0;
    } else {
      this.lsbOffset = -1;
      this.msbOffset = 1;
    } 
    if (inFormat.getSigned() == 1) {
      this.inputBias = 0;
      this.signMask = -1;
    } else {
      this.inputBias = 32768;
      this.signMask = 65535;
    } 
    if (this.numberOfInputChannels == 2 && this.numberOfOutputChannels == 1) {
      this.downmix = true;
    } else {
      this.downmix = false;
    } 
  }
  
  private void convert(byte[] input, int inputOffset, int inputLength, byte[] outData, int outputOffset) {
    for (int i = inputOffset + this.msbOffset; i < inputLength + inputOffset; ) {
      boolean bool;
      int j;
      if (8 == this.inputSampleSize) {
        j = input[i++] << 8;
        if (this.downmix)
          j = (j & this.signMask) + (input[i++] << 8 & this.signMask) >> 1; 
      } else {
        j = (input[i] << 8) + (0xFF & input[i + this.lsbOffset]);
        i += 2;
        if (this.downmix) {
          j = (j & this.signMask) + ((input[i] << 8) + (0xFF & input[i + this.lsbOffset]) & this.signMask) >> 1;
          i += 2;
        } 
      } 
      int sample = (short)(j + this.inputBias);
      if (sample >= 0) {
        bool = true;
      } else {
        sample = -sample;
        bool = false;
      } 
      sample = 132 + sample >> 3;
      outData[outputOffset++] = (sample < 32) ? (byte)(bool | 0x70 | 31 - (sample >> 0)) : ((sample < 64) ? (byte)(bool | 0x60 | 31 - (sample >> 1)) : ((sample < 128) ? (byte)(bool | 0x50 | 31 - (sample >> 2)) : ((sample < 256) ? (byte)(bool | 0x40 | 31 - (sample >> 3)) : ((sample < 512) ? (byte)(bool | 0x30 | 31 - (sample >> 4)) : ((sample < 1024) ? (byte)(bool | 0x20 | 31 - (sample >> 5)) : ((sample < 2048) ? (byte)(bool | 0x10 | 31 - (sample >> 6)) : ((sample < 4096) ? (byte)(bool | false | 31 - (sample >> 7)) : (byte)(bool | false | 0x0))))))));
    } 
  }
}
