/*     */ package com.ibm.media.codec.audio;
/*     */ 
/*     */ import com.sun.media.BasicCodec;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayToPCM
/*     */   extends BasicCodec
/*     */ {
/*  14 */   private static String ArrayToPCM = "ArrayToPCM";
/*     */ 
/*     */   
/*     */   public String getName() {
/*  18 */     return ArrayToPCM;
/*     */   }
/*     */   
/*     */   public ArrayToPCM() {
/*  22 */     this.inputFormats = new Format[] { (Format)new AudioFormat("LINEAR", -1.0D, -1, -1, -1, -1, -1, -1.0D, Format.byteArray) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  32 */     this.outputFormats = new Format[] { (Format)new AudioFormat("LINEAR", -1.0D, 16, -1, -1, -1, -1, -1.0D, Format.shortArray) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format[] getSupportedOutputFormats(Format in) {
/*  44 */     if (!(in instanceof AudioFormat))
/*  45 */       return this.outputFormats; 
/*  46 */     AudioFormat iaf = (AudioFormat)in;
/*  47 */     if (!iaf.getEncoding().equals("LINEAR") || iaf.getDataType() != Format.byteArray)
/*     */     {
/*  49 */       return new Format[0];
/*     */     }
/*  51 */     AudioFormat oaf = new AudioFormat("LINEAR", iaf.getSampleRate(), 16, iaf.getChannels(), 0, 1, iaf.getFrameSizeInBits(), iaf.getFrameRate(), Format.shortArray);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     return new Format[] { (Format)oaf };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int process(Buffer inputBuffer, Buffer outputBuffer) {
/*  66 */     if (isEOM(inputBuffer)) {
/*  67 */       return 0;
/*     */     }
/*  69 */     byte[] inBuffer = (byte[])inputBuffer.getData();
/*  70 */     AudioFormat inFormat = (AudioFormat)inputBuffer.getFormat();
/*  71 */     boolean isSigned = (inFormat.getSigned() == 1);
/*  72 */     boolean isBigEndian = (inFormat.getEndian() == 1);
/*  73 */     int sampleSize = inFormat.getFrameSizeInBits() + 7 >> 3;
/*     */     
/*  75 */     int inLength = inputBuffer.getLength();
/*     */     
/*  77 */     int samplesNumber = (sampleSize == 1) ? inLength : (inLength >> 1);
/*  78 */     int outLength = samplesNumber;
/*     */     
/*  80 */     short[] outBuffer = validateShortArraySize(outputBuffer, outLength);
/*     */ 
/*     */     
/*  83 */     int offset = isSigned ? 0 : 32768;
/*     */     
/*  85 */     int inOffset = 0;
/*  86 */     int outOffset = 0;
/*     */ 
/*     */     
/*  89 */     if (sampleSize == 1) {
/*     */       
/*  91 */       for (int i = samplesNumber - 1; i >= 0; i--) {
/*  92 */         outBuffer[i] = (short)((inBuffer[i] << 8) + offset);
/*     */       
/*     */       }
/*     */     
/*     */     }
/*  97 */     else if (isBigEndian) {
/*  98 */       for (int i = samplesNumber - 1; i >= 0; i--) {
/*  99 */         int sample1 = inBuffer[inOffset++] << 8;
/* 100 */         int sample2 = inBuffer[inOffset++] & 0xFF;
/* 101 */         outBuffer[outOffset++] = (short)((sample1 | sample2) + offset);
/*     */       } 
/*     */     } else {
/* 104 */       for (int i = samplesNumber - 1; i >= 0; i--) {
/* 105 */         int sample1 = inBuffer[inOffset++] & 0xFF;
/* 106 */         int sample2 = inBuffer[inOffset++] << 8;
/* 107 */         outBuffer[outOffset++] = (short)((sample1 | sample2) + offset);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     outputBuffer.setLength(samplesNumber);
/* 115 */     outputBuffer.setFormat(this.outputFormat);
/*     */ 
/*     */     
/* 118 */     return 0;
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 122 */     ArrayToPCM arrayToPCM = new ArrayToPCM();
/* 123 */     Format[] ifmt = arrayToPCM.getSupportedInputFormats();
/* 124 */     Format[] ofmt = arrayToPCM.getSupportedOutputFormats((Format)new AudioFormat("LINEAR", 8000.0D, 8, 2, 0, 0));
/*     */ 
/*     */ 
/*     */     
/* 128 */     for (int i = 0; i < ifmt.length; i++) {
/* 129 */       System.out.println(ifmt[i]);
/*     */     }
/* 131 */     System.out.println("* out *");
/*     */     
/* 133 */     for (int j = 0; j < ofmt.length; j++)
/* 134 */       System.out.println(ofmt[j]); 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\ArrayToPCM.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */