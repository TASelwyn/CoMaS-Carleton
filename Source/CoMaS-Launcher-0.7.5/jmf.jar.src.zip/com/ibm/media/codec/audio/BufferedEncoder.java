/*     */ package com.ibm.media.codec.audio;
/*     */ 
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BufferedEncoder
/*     */   extends AudioCodec
/*     */ {
/*  19 */   protected int[] readBytes = new int[1];
/*     */   
/*  21 */   protected int[] writeBytes = new int[1];
/*     */   
/*  23 */   protected int[] frameNumber = new int[1];
/*     */   
/*  25 */   protected Buffer history = new Buffer();
/*     */   
/*     */   protected int[] regions;
/*     */   
/*     */   protected int[] regionsTypes;
/*     */   
/*     */   protected int pendingFrames;
/*     */   
/*  33 */   protected int packetSize = -1;
/*     */   
/*     */   public int getPacketSize() {
/*  36 */     return this.packetSize;
/*     */   }
/*     */   protected int historySize;
/*     */   public int setPacketSize(int newPacketSize) {
/*  40 */     this.packetSize = newPacketSize;
/*  41 */     return this.packetSize;
/*     */   }
/*     */   
/*     */   public void reset() {
/*  45 */     this.history.setLength(0);
/*  46 */     codecReset();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void codecReset();
/*     */ 
/*     */   
/*     */   public int process(Buffer inputBuffer, Buffer outputBuffer) {
/*  55 */     if (this.pendingFrames > 0)
/*     */     {
/*  57 */       return 0;
/*     */     }
/*     */     
/*  60 */     if (!checkInputBuffer(inputBuffer)) {
/*  61 */       return 1;
/*     */     }
/*     */     
/*  64 */     if (isEOM(inputBuffer)) {
/*  65 */       propagateEOM(outputBuffer);
/*  66 */       return 0;
/*     */     } 
/*     */     
/*  69 */     int inpOffset = inputBuffer.getOffset();
/*  70 */     int inpLength = inputBuffer.getLength();
/*  71 */     int outLength = 0;
/*  72 */     int outOffset = 0;
/*  73 */     byte[] inpData = (byte[])inputBuffer.getData();
/*  74 */     byte[] outData = validateByteArraySize(outputBuffer, calculateOutputSize(inpData.length + this.historySize));
/*  75 */     int historyLength = this.history.getLength();
/*  76 */     byte[] historyData = validateByteArraySize(this.history, this.historySize);
/*  77 */     int framesNumber = calculateFramesNumber(inpData.length + this.historySize);
/*     */     
/*  79 */     if (this.regions == null || this.regions.length < framesNumber + 1) {
/*  80 */       this.regions = new int[framesNumber + 1];
/*     */     }
/*  82 */     if (this.regionsTypes == null || this.regionsTypes.length < framesNumber) {
/*  83 */       this.regionsTypes = new int[framesNumber];
/*     */     }
/*  85 */     if (historyLength != 0) {
/*  86 */       int bytesToCopy = historyData.length - historyLength;
/*  87 */       if (bytesToCopy > inpLength) {
/*  88 */         bytesToCopy = inpLength;
/*     */       }
/*     */       
/*  91 */       System.arraycopy(inpData, inpOffset, historyData, historyLength, bytesToCopy);
/*     */ 
/*     */ 
/*     */       
/*  95 */       codecProcess(historyData, 0, outData, outOffset, historyLength + bytesToCopy, this.readBytes, this.writeBytes, this.frameNumber, this.regions, this.regionsTypes);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 100 */       if (this.readBytes[0] <= 0) {
/* 101 */         if (this.writeBytes[0] <= 0)
/*     */         {
/* 103 */           return 4;
/*     */         }
/* 105 */         updateOutput(outputBuffer, (Format)this.outputFormat, this.writeBytes[0], 0);
/*     */         
/* 107 */         return 0;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 113 */       outOffset += this.writeBytes[0];
/* 114 */       outLength += this.writeBytes[0];
/*     */       
/* 116 */       inpOffset += this.readBytes[0] - historyLength;
/* 117 */       inpLength += historyLength - this.readBytes[0];
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 122 */     codecProcess(inpData, inpOffset, outData, outOffset, inpLength, this.readBytes, this.writeBytes, this.frameNumber, this.regions, this.regionsTypes);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     outLength += this.writeBytes[0];
/*     */     
/* 134 */     inpOffset += this.readBytes[0];
/* 135 */     inpLength -= this.readBytes[0];
/*     */     
/* 137 */     System.arraycopy(inpData, inpOffset, historyData, 0, inpLength);
/* 138 */     this.history.setLength(inpLength);
/*     */     
/* 140 */     updateOutput(outputBuffer, (Format)this.outputFormat, outLength, 0);
/*     */ 
/*     */     
/* 143 */     return 0;
/*     */   }
/*     */   
/*     */   protected abstract int calculateOutputSize(int paramInt);
/*     */   
/*     */   protected abstract int calculateFramesNumber(int paramInt);
/*     */   
/*     */   protected abstract boolean codecProcess(byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, int paramInt3, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, int[] paramArrayOfint4, int[] paramArrayOfint5);
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\BufferedEncoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */