/*     */ package com.ibm.media.codec.audio.gsm;
/*     */ 
/*     */ import com.ibm.media.codec.audio.AudioCodec;
/*     */ import com.sun.media.format.WavAudioFormat;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaEncoder_ms
/*     */   extends JavaEncoder
/*     */ {
/*     */   public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997,1999.";
/*     */   
/*     */   public JavaEncoder_ms() {
/*  40 */     ((AudioCodec)this).supportedInputFormats = new AudioFormat[] { new AudioFormat("LINEAR", -1.0D, 16, 1, 0, 1, -1, -1.0D, Format.byteArray) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  53 */     ((AudioCodec)this).defaultOutputFormats = new AudioFormat[] { (AudioFormat)new WavAudioFormat("gsm/ms") };
/*     */     
/*  55 */     ((AudioCodec)this).PLUGIN_NAME = "MS GSM Encoder";
/*  56 */     this.historySize = 640;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Format[] getMatchingOutputFormats(Format in) {
/*  61 */     AudioFormat af = (AudioFormat)in;
/*     */     
/*  63 */     ((AudioCodec)this).supportedOutputFormats = new AudioFormat[] { (AudioFormat)new WavAudioFormat("gsm/ms", af.getSampleRate(), 0, af.getChannels(), 520, (int)(af.getSampleRate() * af.getChannels() / 320.0D * 65.0D), -1, -1, -1.0F, Format.byteArray, new byte[] { 64, 1 }) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  79 */     return (Format[])((AudioCodec)this).supportedOutputFormats;
/*     */   }
/*     */   
/*     */   public void open() throws ResourceUnavailableException {
/*  83 */     this.encoder = new GsmEncoder_ms();
/*  84 */     this.encoder.gsm_encoder_reset();
/*     */   }
/*     */   
/*     */   protected int calculateOutputSize(int inputSize) {
/*  88 */     return calculateFramesNumber(inputSize) * 65;
/*     */   }
/*     */   
/*     */   protected int calculateFramesNumber(int inputSize) {
/*  92 */     return inputSize / 640;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean codecProcess(byte[] inpData, int readPtr, byte[] outData, int writePtr, int inpLength, int[] readBytes, int[] writeBytes, int[] frameNumber, int[] regions, int[] regionsTypes) {
/* 102 */     int inCount = 0;
/* 103 */     int outCount = 0;
/* 104 */     int channels = ((AudioCodec)this).inputFormat.getChannels();
/* 105 */     boolean isStereo = (channels == 2);
/*     */     
/* 107 */     int frames = inpLength / 640;
/*     */     
/* 109 */     regions[0] = writePtr;
/*     */     
/* 111 */     for (int frameCounter = 0; frameCounter < frames; frameCounter++) {
/* 112 */       this.encoder.gsm_encode_frame(inpData, readPtr, outData, writePtr);
/* 113 */       readPtr += 640;
/* 114 */       inCount += 640;
/*     */       
/* 116 */       outCount += 65;
/* 117 */       writePtr += 65;
/*     */       
/* 119 */       regions[frameCounter + 1] = outCount + writePtr;
/* 120 */       regionsTypes[frameCounter] = 0;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 125 */     readBytes[0] = inCount;
/* 126 */     writeBytes[0] = outCount;
/* 127 */     frameNumber[0] = frames;
/*     */     
/* 129 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\gsm\JavaEncoder_ms.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */