package com.ibm.media.codec.audio.rc;

public final class RateConversion {
  public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997,1998.";
  
  public static final int RATE_CONVERSION_OK = -1;
  
  public static final int RATE_CONVERSION_NOT_SUPPORTED = -2;
  
  public static final int RATE_CONVERSION_NOT_INITIALIZED = -3;
  
  public static final int RATE_CONVERSION_ILLEGAL_PARAMETER = -4;
  
  public static final int RATE_CONVERSION_RECOMMENDED_INPUT_SIZE = 1056;
  
  public static final int RATE_CONVERSION_MAX_SUPPORTED_CHANNELS = 2;
  
  public static final int RATE_CONVERSION_MAX_OUTPUT_FACTOR = 5;
  
  public static final int RATE_CONVERSION_BIG_ENDIAN_FORMAT = 0;
  
  public static final int RATE_CONVERSION_LITTLE_ENDIAN_FORMAT = 1;
  
  public static final int RATE_CONVERSION_BYTE_FORMAT = 2;
  
  private static final boolean USE_REMOVE_DC = false;
  
  private boolean useMuLaw = false;
  
  private static final int MAX_RATE_IN = 11;
  
  private static final int UNROLLING_ORDER = 4;
  
  private static final int CORRECTION_FRAME_SIZE = 441;
  
  private static final int CONV_ERROR = -1;
  
  private static final int CONV_11to2 = 1;
  
  private static final int CONV_11to4 = 2;
  
  private static final int CONV_11to8 = 3;
  
  private static final int CONV_6to1 = 4;
  
  private static final int CONV_4to1 = 5;
  
  private static final int CONV_2to1 = 6;
  
  private static final int MAX_MEM_SIZE = 792;
  
  private static final float DCFACT = 0.9921875F;
  
  private static final float SHRT_MIN = -32767.0F;
  
  private static final float SHRT_MAX = 32767.0F;
  
  private static final float FRACTION_DELTA = 0.0022727272F;
  
  private static final float FRACTION_DELIMITER = 1.0011364F;
  
  private int bias;
  
  private int signMask;
  
  private int filterHistoryLength;
  
  private int decimFlag;
  
  private int numberOfInputChannels;
  
  private int numberOfOutputChannels;
  
  private boolean channels2To1 = false;
  
  private boolean channels1To2 = false;
  
  private boolean channels2To2 = false;
  
  private int rateIn;
  
  private int rateOut;
  
  private int[] index = new int[2];
  
  private int inputRemainedSamples;
  
  private int maxInputLength;
  
  private int paddingLength;
  
  private int maxDrainedSamples;
  
  private int pcmType;
  
  private int inputSampleSize;
  
  private float[] poly;
  
  private float[] x1;
  
  private float[] x2;
  
  private float[] y1;
  
  private float[] y2;
  
  private boolean needInputCorrection;
  
  private boolean isDrained;
  
  private boolean isRateConversionInited;
  
  private int delay;
  
  private float lastInputSample1;
  
  private float lastInputSample2;
  
  private float frac;
  
  private float prev_fsample1;
  
  private float prev_fsample2;
  
  private float fractionDelta = 0.0022727272F;
  
  private float fractionDelimiter;
  
  private int precisionCountDelimiter = 1;
  
  private int precisionCount;
  
  public int init(int maxInputBufferSize, int rateInput, int rateOutput, int inputChannels, int outputChannels, int pcmType, boolean signed, boolean useMuLaw) {
    int i, filterLength;
    this.useMuLaw = useMuLaw;
    this.inputSampleSize = 2;
    if (0 != pcmType && 1 != pcmType && 2 != pcmType)
      return -4; 
    if (signed) {
      this.bias = 0;
      this.signMask = -1;
    } else {
      this.bias = 32768;
      this.signMask = 65535;
    } 
    if (2 == pcmType)
      this.inputSampleSize = 1; 
    this.pcmType = pcmType;
    this.maxInputLength = maxInputBufferSize / this.inputSampleSize * inputChannels;
    this.numberOfInputChannels = inputChannels;
    this.numberOfOutputChannels = outputChannels;
    if (this.numberOfInputChannels == 2 && this.numberOfOutputChannels == 1) {
      this.channels2To1 = true;
    } else {
      this.channels2To1 = false;
    } 
    if (this.numberOfInputChannels == 1 && this.numberOfOutputChannels == 2) {
      this.channels1To2 = true;
    } else {
      this.channels1To2 = false;
    } 
    if (this.numberOfInputChannels == 2 && this.numberOfOutputChannels == 2) {
      this.channels2To2 = true;
    } else {
      this.channels2To2 = false;
    } 
    this.needInputCorrection = false;
    this.delay = 0;
    this.decimFlag = -1;
    if (rateInput == 44100 && rateOutput == 8000) {
      this.decimFlag = 1;
      this.rateIn = 11;
      this.rateOut = 2;
      this.needInputCorrection = true;
    } else if (rateInput == 22050 && rateOutput == 8000) {
      this.decimFlag = 2;
      this.rateIn = 11;
      this.rateOut = 4;
      this.needInputCorrection = true;
    } else if (rateInput == 11025 && rateOutput == 8000) {
      this.decimFlag = 3;
      this.rateIn = 11;
      this.rateOut = 8;
      this.needInputCorrection = true;
    } else if (rateInput == 48000 && rateOutput == 8000) {
      this.decimFlag = 4;
      this.rateIn = 6;
      this.rateOut = 1;
      this.needInputCorrection = false;
    } else if (rateInput == 32000 && rateOutput == 8000) {
      this.decimFlag = 5;
      this.rateIn = 4;
      this.rateOut = 1;
      this.needInputCorrection = false;
    } else if (rateInput == 16000 && rateOutput == 8000) {
      this.decimFlag = 6;
      this.rateIn = 2;
      this.rateOut = 1;
      this.needInputCorrection = false;
    } else if (rateInput == 11127 && rateOutput == 8000) {
      this.decimFlag = 3;
      this.rateIn = 11;
      this.rateOut = 8;
      this.needInputCorrection = true;
      this.fractionDelta = 0.011545454F;
      this.precisionCountDelimiter = 127;
    } else if (rateInput == 22254 && rateOutput == 8000) {
      this.decimFlag = 2;
      this.rateIn = 11;
      this.rateOut = 4;
      this.needInputCorrection = true;
      this.fractionDelta = 0.011545454F;
      this.precisionCountDelimiter = 127;
    } else if (rateInput == 22255 && rateOutput == 8000) {
      this.decimFlag = 2;
      this.rateIn = 11;
      this.rateOut = 4;
      this.needInputCorrection = true;
      this.fractionDelta = 0.011590909F;
      this.precisionCountDelimiter = 255;
    } else {
      close();
      return -2;
    } 
    switch (this.decimFlag) {
      case 3:
        this.filterHistoryLength = 25;
        this.delay = 9;
        filterLength = 200;
        break;
      case 2:
        this.filterHistoryLength = 50;
        this.delay = 9;
        filterLength = 200;
        break;
      case 1:
        this.filterHistoryLength = 100;
        this.delay = 9;
        filterLength = 200;
        break;
      case 4:
        this.filterHistoryLength = 128;
        this.delay = 11;
        filterLength = 128;
        break;
      case 5:
        this.filterHistoryLength = 128;
        this.delay = 16;
        filterLength = 128;
        break;
      case 6:
        this.filterHistoryLength = 64;
        this.delay = 16;
        filterLength = 64;
        break;
      default:
        close();
        return -2;
    } 
    this.poly = new float[filterLength];
    this.x1 = new float[this.maxInputLength + this.filterHistoryLength + 4 * this.rateIn];
    this.y1 = new float[(this.maxInputLength + this.filterHistoryLength + 4 * this.rateIn) / this.rateIn * this.rateOut];
    if (this.channels2To2) {
      this.x2 = new float[this.maxInputLength + this.filterHistoryLength + 4 * this.rateIn];
      this.y2 = new float[(this.maxInputLength + this.filterHistoryLength + 4 * this.rateIn) / this.rateIn * this.rateOut];
    } 
    float gain = 1.0F;
    switch (this.decimFlag) {
      case 1:
        gain = 2.0F;
        for (i = 0; i < 2; i++) {
          for (int j = 0; j < 100; j++)
            this.poly[i * 100 + j] = RateConversionTables.filter11[i + j * 2] * gain; 
        } 
        break;
      case 2:
        gain = 4.0F;
        for (i = 0; i < 4; i++) {
          for (byte b = 0; b < 50; b++)
            this.poly[i * 50 + b] = RateConversionTables.filter11[i + b * 4] * gain; 
        } 
        break;
      case 3:
        gain = 8.0F;
        for (i = 0; i < 8; i++) {
          for (byte b = 0; b < 25; b++)
            this.poly[i * 25 + b] = RateConversionTables.filter11[i + b * 8] * gain; 
        } 
        break;
      case 4:
        for (i = 0; i < 128; i++)
          this.poly[i] = RateConversionTables.filter6[i]; 
        break;
      case 5:
        for (i = 0; i < 128; i++)
          this.poly[i] = RateConversionTables.filter4[i]; 
        break;
      case 6:
        for (i = 0; i < 64; i++)
          this.poly[i] = RateConversionTables.filter2[i]; 
        break;
    } 
    this.paddingLength = this.filterHistoryLength / 2;
    this.maxDrainedSamples = (int)(((this.paddingLength + 4 * this.rateIn * 2) * this.rateOut) / this.rateIn);
    this.isRateConversionInited = true;
    this.fractionDelimiter = 1.0F + this.fractionDelta / 2.0F;
    reset();
    return -1;
  }
  
  public int reset() {
    if (false == this.isRateConversionInited)
      return -3; 
    this.inputRemainedSamples = 0;
    this.isDrained = false;
    this.frac = 1.0F;
    this.precisionCount = this.precisionCountDelimiter - 1;
    this.prev_fsample1 = 0.0F;
    this.prev_fsample2 = 0.0F;
    int i;
    for (i = 0; i < this.filterHistoryLength; i++)
      this.x1[i] = 0.0F; 
    this.index[0] = 0;
    if (this.channels2To2) {
      for (i = 0; i < this.filterHistoryLength; i++)
        this.x2[i] = 0.0F; 
      this.index[1] = 0;
    } 
    this.lastInputSample1 = 0.0F;
    this.lastInputSample2 = 0.0F;
    return -1;
  }
  
  public void close() {
    this.isRateConversionInited = false;
    this.x1 = null;
    this.x2 = null;
    this.y1 = null;
    this.y2 = null;
    this.poly = null;
  }
  
  public int getDelay() {
    if (false == this.isRateConversionInited)
      return -3; 
    int outputDelayLength = this.delay;
    if (false == this.useMuLaw)
      outputDelayLength *= 2; 
    return outputDelayLength;
  }
  
  public int process(byte[] inputData, int inputDataOffset, int inputDataLength, byte[] output, int outputDataOffset) {
    if (false == this.isRateConversionInited)
      return -3; 
    if (false == this.isDrained && inputDataLength > this.maxInputLength * this.inputSampleSize * this.numberOfInputChannels)
      enlargeBufferAllocation(inputDataLength); 
    if (0 == inputDataLength)
      return 0; 
    int inputOffset = this.inputRemainedSamples + this.filterHistoryLength;
    inputDataLength = extractInput(inputData, inputDataOffset, inputDataLength, inputOffset);
    int inputLength = inputDataLength + this.inputRemainedSamples;
    int inputBlocks = inputLength / 4 * this.rateIn;
    this.inputRemainedSamples = inputLength - inputBlocks * 4 * this.rateIn;
    inputLength -= this.inputRemainedSamples;
    inputOffset = this.inputRemainedSamples + this.filterHistoryLength;
    if (inputLength == 0)
      return 0; 
    int outputLength = inputLength / this.rateIn * this.rateOut;
    int numberOfChannels = 1;
    if (this.channels2To2)
      numberOfChannels = 2; 
    for (int i = 0; i < numberOfChannels; i++) {
      float[] arrayOfFloat1;
      float[] arrayOfFloat2;
      if (i > 0) {
        arrayOfFloat1 = this.x2;
        arrayOfFloat2 = this.y2;
      } else {
        arrayOfFloat1 = this.x1;
        arrayOfFloat2 = this.y1;
      } 
      switch (this.decimFlag) {
        case 3:
          this.index[i] = downsampleMtoL(arrayOfFloat1, arrayOfFloat2, this.index[i], this.poly, 25, 8, 11, (outputLength >> 5) * 11, outputLength >> 2);
          break;
        case 2:
          this.index[i] = downsampleMtoL(arrayOfFloat1, arrayOfFloat2, this.index[i], this.poly, 50, 4, 11, (outputLength >> 4) * 11, outputLength >> 2);
          break;
        case 1:
          this.index[i] = downsampleMtoL(arrayOfFloat1, arrayOfFloat2, this.index[i], this.poly, 100, 2, 11, (outputLength >> 3) * 11, outputLength >> 2);
          break;
        case 4:
          downsampleM(arrayOfFloat1, arrayOfFloat2, this.poly, 128, 6, outputLength);
          break;
        case 5:
          downsampleM(arrayOfFloat1, arrayOfFloat2, this.poly, 128, 4, outputLength);
          break;
        case 6:
          downsampleM(arrayOfFloat1, arrayOfFloat2, this.poly, 64, 2, outputLength);
          break;
      } 
      for (int j = 0; j < inputOffset; j++)
        arrayOfFloat1[j] = arrayOfFloat1[j + inputLength]; 
    } 
    if (false == this.useMuLaw) {
      if (this.numberOfOutputChannels == 1) {
        Fl2Byte(this.y1, outputLength, output, outputDataOffset);
        return 2 * outputLength;
      } 
      if (this.channels1To2)
        this.y2 = this.y1; 
      Fl2ByteStereo(this.y1, this.y2, outputLength, output, outputDataOffset);
      return 4 * outputLength;
    } 
    convertToMuLaw(this.y1, outputLength, output, outputDataOffset);
    return outputLength;
  }
  
  public int drain(byte[] output, int outputOffset) {
    if (false == this.isRateConversionInited)
      return -3; 
    int inputSamples = (this.paddingLength + 4 * this.rateIn) * this.numberOfInputChannels * this.inputSampleSize;
    this.isDrained = true;
    int actualOutputSamples = (int)(((this.paddingLength + this.inputRemainedSamples) * this.rateOut) / this.rateIn);
    if (false == this.useMuLaw)
      actualOutputSamples *= 2; 
    int numberOfOutputSamples = process(null, 0, inputSamples, output, outputOffset);
    this.isDrained = false;
    if (actualOutputSamples < numberOfOutputSamples)
      numberOfOutputSamples = actualOutputSamples; 
    return numberOfOutputSamples;
  }
  
  public int getMaxOutputLength() {
    if (false == this.isRateConversionInited)
      return -3; 
    int outputLength = (this.maxInputLength + this.rateIn * 4) * this.rateOut / this.rateIn;
    if (false == this.useMuLaw)
      outputLength *= 2; 
    return outputLength;
  }
  
  public int getMaxOutputLength(int inputLength) {
    if (false == this.isRateConversionInited)
      return -3; 
    int inputSamples = inputLength / this.inputSampleSize * this.numberOfInputChannels;
    int outputLength = (inputSamples + this.rateIn * 4) * this.rateOut / this.rateIn;
    if (false == this.useMuLaw)
      outputLength *= 2; 
    outputLength *= this.numberOfOutputChannels;
    return outputLength;
  }
  
  public int getDrainMaxLength() {
    if (false == this.isRateConversionInited)
      return -3; 
    int drainMaxLength = this.maxDrainedSamples;
    if (false == this.useMuLaw)
      drainMaxLength *= 2; 
    return drainMaxLength;
  }
  
  private void convertToMuLaw(float[] inBuffer, int Len, byte[] outBuffer, int indexOut) {
    for (int i = 0; i < Len; i++) {
      boolean bool;
      float inSample = inBuffer[i];
      if (inSample < -32767.0F) {
        inSample = -32767.0F;
      } else if (inSample > 32767.0F) {
        inSample = 32767.0F;
      } 
      int sample = (int)inSample;
      if (sample >= 0) {
        bool = true;
      } else {
        sample = -sample;
        bool = false;
      } 
      sample = 132 + sample >> 3;
      if (sample < 32) {
        outBuffer[indexOut++] = (byte)(bool | 0x70 | 31 - (sample >> 0));
      } else if (sample < 64) {
        outBuffer[indexOut++] = (byte)(bool | 0x60 | 31 - (sample >> 1));
      } else if (sample < 128) {
        outBuffer[indexOut++] = (byte)(bool | 0x50 | 31 - (sample >> 2));
      } else if (sample < 256) {
        outBuffer[indexOut++] = (byte)(bool | 0x40 | 31 - (sample >> 3));
      } else if (sample < 512) {
        outBuffer[indexOut++] = (byte)(bool | 0x30 | 31 - (sample >> 4));
      } else if (sample < 1024) {
        outBuffer[indexOut++] = (byte)(bool | 0x20 | 31 - (sample >> 5));
      } else if (sample < 2048) {
        outBuffer[indexOut++] = (byte)(bool | 0x10 | 31 - (sample >> 6));
      } else if (sample < 4096) {
        outBuffer[indexOut++] = (byte)(bool | false | 31 - (sample >> 7));
      } else {
        outBuffer[indexOut++] = (byte)(bool | false | 0x0);
      } 
    } 
  }
  
  private final void Fl2Byte(float[] inBuffer, int Len, byte[] outBuffer, int indexOut) {
    int j = 0;
    for (int i = 0; i < Len; i++) {
      float sample = inBuffer[i];
      if (sample < -32767.0F) {
        sample = -32767.0F;
      } else if (sample > 32767.0F) {
        sample = 32767.0F;
      } 
      int TempInt = (int)sample;
      outBuffer[indexOut + j] = (byte)(TempInt & 0xFF);
      outBuffer[indexOut + j + 1] = (byte)(TempInt >> 8);
      j += 2;
    } 
  }
  
  private final void Fl2ByteStereo(float[] inBuffer1, float[] inBuffer2, int Len, byte[] outBuffer, int indexOut) {
    int j = 0;
    for (int i = 0; i < Len; i++) {
      float sample = inBuffer1[i];
      if (sample < -32767.0F) {
        sample = -32767.0F;
      } else if (sample > 32767.0F) {
        sample = 32767.0F;
      } 
      int TempInt = (int)sample;
      outBuffer[indexOut + j] = (byte)(TempInt & 0xFF);
      outBuffer[indexOut + j + 1] = (byte)(TempInt >> 8);
      sample = inBuffer2[i];
      if (sample < -32767.0F) {
        sample = -32767.0F;
      } else if (sample > 32767.0F) {
        sample = 32767.0F;
      } 
      TempInt = (int)sample;
      outBuffer[indexOut + j + 2] = (byte)(TempInt & 0xFF);
      outBuffer[indexOut + j + 3] = (byte)(TempInt >> 8);
      j += 4;
    } 
  }
  
  private int extractInput(byte[] input, int inputOffset, int inputLength, int internalBufferOffset) {
    byte b1, b2;
    int internalBufferIndex = internalBufferOffset;
    float fsample1 = 0.0F;
    float fsample2 = 0.0F;
    int sample1 = 0;
    int sample2 = 0;
    int inputSample = 0;
    if (this.isDrained) {
      int length = inputLength / this.numberOfInputChannels * this.inputSampleSize;
      int j;
      for (j = 0; j < length; j++)
        this.x1[internalBufferIndex + j] = 0.0F; 
      if (this.channels2To2)
        for (j = 0; j < length; j++)
          this.x2[internalBufferIndex + j] = 0.0F;  
      return length;
    } 
    if (this.pcmType == 1) {
      b1 = -1;
      b2 = 1;
    } else {
      b1 = 1;
      b2 = 0;
    } 
    for (int i = inputOffset + b2; i < inputLength + inputOffset; ) {
      if (1 == this.inputSampleSize) {
        sample1 = input[i++] << 8;
        if (this.numberOfInputChannels == 2)
          sample2 = input[i++] << 8; 
      } else {
        sample1 = (input[i] << 8) + (0xFF & input[i + b1]);
        i += 2;
        if (this.numberOfInputChannels == 2) {
          sample2 = (input[i] << 8) + (0xFF & input[i + b1]);
          i += 2;
        } 
      } 
      if (this.channels2To1)
        sample1 = (sample1 & this.signMask) + (sample2 & this.signMask) >> 1; 
      fsample1 = (short)(sample1 + this.bias);
      if (this.channels2To2)
        fsample2 = (short)(sample2 + this.bias); 
      if (this.channels1To2)
        fsample2 = fsample1; 
      if (this.needInputCorrection) {
        if (this.frac > this.fractionDelimiter) {
          this.precisionCount++;
          if (this.precisionCount == this.precisionCountDelimiter) {
            this.precisionCount = 0;
            this.frac = this.fractionDelta;
          } else {
            this.frac--;
          } 
          this.prev_fsample1 = fsample1;
          this.prev_fsample2 = fsample2;
          continue;
        } 
        this.x1[internalBufferIndex] = this.prev_fsample1 * (1.0F - this.frac) + this.frac * fsample1;
        this.prev_fsample1 = fsample1;
        if (this.channels2To2) {
          this.x2[internalBufferIndex] = this.prev_fsample2 * (1.0F - this.frac) + this.frac * fsample2;
          this.prev_fsample2 = fsample2;
        } 
        this.frac += this.fractionDelta;
      } else {
        this.x1[internalBufferIndex] = fsample1;
        if (this.channels2To2)
          this.x2[internalBufferIndex] = fsample2; 
      } 
      internalBufferIndex++;
    } 
    return internalBufferIndex - internalBufferOffset;
  }
  
  private float remove_dc(float[] input, int inputOffset, float previous_sample, int length) {
    return 0.0F;
  }
  
  private int downsampleMtoL(float[] x, float[] y, int index, float[] poly, int poly_length, int interpolation_factor, int decimation_factor, int input_block_size, int output_block_size) {
    int m = 0;
    for (int n = 0; n < output_block_size; n++) {
      float sum3 = 0.0F, sum2 = sum3, sum1 = sum2, sum0 = sum1;
      int offset = index * poly_length;
      for (int j = 0; j < poly_length; j++) {
        float polySample = poly[offset + j];
        sum0 += polySample * x[j + m];
        sum1 += polySample * x[j + m + 1 * input_block_size];
        sum2 += polySample * x[j + m + 2 * input_block_size];
        sum3 += polySample * x[j + m + 3 * input_block_size];
      } 
      y[n + 1 * output_block_size] = sum1;
      y[n + 2 * output_block_size] = sum2;
      y[n + 3 * output_block_size] = sum3;
      y[n] = sum0;
      while (index < decimation_factor) {
        index += interpolation_factor;
        m++;
      } 
      index -= decimation_factor;
    } 
    return index;
  }
  
  void downsampleM(float[] x, float[] y, float[] filter, int filter_length, int decimation_factor, int output_length) {
    int filt_length = filter_length / 2;
    int offset_inc = decimation_factor * 4;
    int sym_offset = filter_length - 1;
    for (int offset1 = 0, n = 0; n < output_length; offset1 += offset_inc) {
      float sum3 = 0.0F, sum2 = sum3, sum1 = sum2, sum0 = sum1;
      int offset2 = offset1 + decimation_factor;
      int offset3 = offset2 + decimation_factor;
      int offset4 = offset3 + decimation_factor;
      for (int i = 0; i < filt_length; i++) {
        float filterSample = filter[i];
        sum0 += filterSample * (x[offset1 + i] + x[offset1 + sym_offset - i]);
        sum1 += filterSample * (x[offset2 + i] + x[offset2 + sym_offset - i]);
        sum2 += filterSample * (x[offset3 + i] + x[offset3 + sym_offset - i]);
        sum3 += filterSample * (x[offset4 + i] + x[offset4 + sym_offset - i]);
      } 
      y[n++] = sum0;
      y[n++] = sum1;
      y[n++] = sum2;
      y[n++] = sum3;
    } 
  }
  
  private void enlargeBufferAllocation(int length) {
    this.maxInputLength = length / this.inputSampleSize * this.numberOfInputChannels;
    float[] inputBuffer = new float[this.maxInputLength + this.filterHistoryLength + 4 * this.rateIn];
    float[] outputBuffer = new float[(this.maxInputLength + this.filterHistoryLength + 4 * this.rateIn) / this.rateIn * this.rateOut];
    int i;
    for (i = 0; i < this.x1.length; i++)
      inputBuffer[i] = this.x1[i]; 
    for (i = 0; i < this.y1.length; i++)
      outputBuffer[i] = this.y1[i]; 
    this.x1 = inputBuffer;
    this.y1 = outputBuffer;
    if (this.channels2To2) {
      inputBuffer = new float[this.maxInputLength + this.filterHistoryLength + 4 * this.rateIn];
      outputBuffer = new float[(this.maxInputLength + this.filterHistoryLength + 4 * this.rateIn) / this.rateIn * this.rateOut];
      for (i = 0; i < this.x2.length; i++)
        inputBuffer[i] = this.x2[i]; 
      for (i = 0; i < this.y2.length; i++)
        outputBuffer[i] = this.y2[i]; 
      this.x2 = inputBuffer;
      this.y2 = outputBuffer;
    } 
  }
}
