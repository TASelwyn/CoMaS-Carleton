/*     */ package com.ibm.media.codec.audio.gsm;
/*     */ 
/*     */ import com.sun.media.controls.PacketSizeAdapter;
/*     */ import javax.media.Codec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PacketSizeAdapter
/*     */   extends PacketSizeAdapter
/*     */ {
/*     */   public PacketSizeAdapter(Codec newOwner, int newPacketSize, boolean newIsSetable) {
/* 114 */     super(newOwner, newPacketSize, newIsSetable);
/*     */   }
/*     */ 
/*     */   
/*     */   public int setPacketSize(int numBytes) {
/* 119 */     int numOfPackets = numBytes / 33;
/*     */     
/* 121 */     if (numOfPackets < 1) {
/* 122 */       numOfPackets = 1;
/*     */     }
/*     */     
/* 125 */     if (numOfPackets > 100) {
/* 126 */       numOfPackets = 100;
/*     */     }
/* 128 */     this.packetSize = numOfPackets * 33;
/*     */ 
/*     */     
/* 131 */     ((Packetizer)this.owner).setPacketSize(this.packetSize);
/*     */     
/* 133 */     return this.packetSize;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\gsm\PacketSizeAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */