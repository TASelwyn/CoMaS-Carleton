/*    */ package com.ibm.media.codec.audio;
/*    */ 
/*    */ import com.sun.media.BasicCodec;
/*    */ import com.sun.media.BasicPlugIn;
/*    */ import javax.media.Format;
/*    */ import javax.media.format.AudioFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AudioCodec
/*    */   extends BasicCodec
/*    */ {
/*    */   protected String PLUGIN_NAME;
/*    */   protected AudioFormat[] defaultOutputFormats;
/*    */   protected AudioFormat[] supportedInputFormats;
/*    */   protected AudioFormat[] supportedOutputFormats;
/*    */   protected AudioFormat inputFormat;
/*    */   protected AudioFormat outputFormat;
/*    */   protected final boolean DEBUG = true;
/*    */   
/*    */   public String getName() {
/* 25 */     return this.PLUGIN_NAME;
/*    */   }
/*    */   
/*    */   public Format[] getSupportedInputFormats() {
/* 29 */     return (Format[])this.supportedInputFormats;
/*    */   }
/*    */ 
/*    */   
/*    */   public Format setInputFormat(Format format) {
/* 34 */     if (!(format instanceof AudioFormat) || null == BasicPlugIn.matches(format, (Format[])this.supportedInputFormats))
/*    */     {
/* 36 */       return null;
/*    */     }
/* 38 */     this.inputFormat = (AudioFormat)format;
/* 39 */     return format;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Format setOutputFormat(Format format) {
/* 47 */     if (!(format instanceof AudioFormat) || null == BasicPlugIn.matches(format, getMatchingOutputFormats((Format)this.inputFormat)))
/*    */     {
/* 49 */       return null;
/*    */     }
/* 51 */     this.outputFormat = (AudioFormat)format;
/*    */     
/* 53 */     return format;
/*    */   }
/*    */   
/*    */   protected Format getInputFormat() {
/* 57 */     return (Format)this.inputFormat;
/*    */   }
/*    */   
/*    */   protected Format getOutputFormat() {
/* 61 */     return (Format)this.outputFormat;
/*    */   }
/*    */   
/*    */   protected Format[] getMatchingOutputFormats(Format in) {
/* 65 */     return new Format[0];
/*    */   }
/*    */ 
/*    */   
/*    */   public Format[] getSupportedOutputFormats(Format in) {
/* 70 */     if (in == null) {
/* 71 */       return (Format[])this.defaultOutputFormats;
/*    */     }
/*    */ 
/*    */     
/* 75 */     if (!(in instanceof AudioFormat) || BasicPlugIn.matches(in, (Format[])this.supportedInputFormats) == null)
/*    */     {
/* 77 */       return new Format[0];
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 82 */     return getMatchingOutputFormats(in);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean checkFormat(Format format) {
/* 93 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\AudioCodec.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */