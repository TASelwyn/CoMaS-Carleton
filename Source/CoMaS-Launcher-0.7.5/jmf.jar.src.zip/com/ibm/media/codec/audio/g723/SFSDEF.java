package com.ibm.media.codec.audio.g723;

class SFSDEF {
  int AcLg;
  
  int AcGn;
  
  int Mamp;
  
  int Grid;
  
  int Tran;
  
  int Pamp;
  
  int Ppos;
}
