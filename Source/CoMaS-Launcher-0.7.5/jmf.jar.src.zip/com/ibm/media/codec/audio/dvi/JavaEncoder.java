/*     */ package com.ibm.media.codec.audio.dvi;
/*     */ 
/*     */ import com.ibm.media.codec.audio.AudioCodec;
/*     */ import com.ibm.media.codec.audio.AudioPacketizer;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.controls.SilenceSuppressionAdapter;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Codec;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaEncoder
/*     */   extends AudioPacketizer
/*     */ {
/*  33 */   private Buffer pcmBuffer = new Buffer();
/*     */ 
/*     */ 
/*     */   
/*  37 */   private DVIState dviState = new DVIState();
/*     */   
/*  39 */   private long currentSeq = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaEncoder() {
/*  46 */     this.packetSize = 240;
/*  47 */     ((AudioCodec)this).supportedInputFormats = new AudioFormat[] { new AudioFormat("LINEAR", -1.0D, 16, 1, 0, 1, -1, -1.0D, Format.byteArray) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     ((AudioCodec)this).defaultOutputFormats = new AudioFormat[] { new AudioFormat("dvi/rtp", -1.0D, 4, 1, -1, -1, -1, -1.0D, Format.byteArray) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     ((AudioCodec)this).PLUGIN_NAME = "DVI Encoder";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Format[] getMatchingOutputFormats(Format in) {
/*  79 */     AudioFormat af = (AudioFormat)in;
/*     */     
/*  81 */     ((AudioCodec)this).supportedOutputFormats = new AudioFormat[] { new AudioFormat("dvi/rtp", af.getSampleRate(), 4, 1, -1, -1, -1, -1.0D, Format.byteArray) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  92 */     return (Format[])((AudioCodec)this).supportedOutputFormats;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format setOutputFormat(Format out) {
/*  99 */     Format f = super.setOutputFormat(out);
/* 100 */     AudioFormat af = (AudioFormat)f;
/* 101 */     if (af.getSampleRate() == 8000.0D) {
/* 102 */       this.packetSize = 240;
/* 103 */     } else if (af.getSampleRate() == 11025.0D) {
/* 104 */       this.packetSize = 330;
/* 105 */     } else if (af.getSampleRate() == 22050.0D) {
/* 106 */       this.packetSize = 660;
/* 107 */     } else if (af.getSampleRate() == 44100.0D) {
/* 108 */       this.packetSize = 1320;
/* 109 */     }  return f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int process(Buffer inputBuffer, Buffer outputBuffer) {
/* 116 */     int rc = super.process(inputBuffer, this.pcmBuffer);
/* 117 */     if ((rc & 0x4) != 0) {
/* 118 */       return rc;
/*     */     }
/* 120 */     byte[] pcmData = (byte[])this.pcmBuffer.getData();
/* 121 */     int inpLength = this.pcmBuffer.getLength();
/*     */ 
/*     */     
/* 124 */     int outLength = this.pcmBuffer.getLength() / 4;
/* 125 */     byte[] outData = validateByteArraySize(outputBuffer, outLength + 4);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     outData[0] = (byte)(this.dviState.valprev >> 8);
/* 131 */     outData[1] = (byte)this.dviState.valprev;
/* 132 */     outData[2] = (byte)this.dviState.index;
/* 133 */     outData[3] = 0;
/*     */     
/* 135 */     DVI.encode(pcmData, 0, outData, 4, inpLength >> 1, this.dviState);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 142 */     this.pcmBuffer.setOffset(0);
/* 143 */     this.pcmBuffer.setLength(0);
/*     */     
/* 145 */     outputBuffer.setSequenceNumber(this.currentSeq++);
/* 146 */     outputBuffer.setTimeStamp(this.pcmBuffer.getTimeStamp());
/*     */     
/* 148 */     updateOutput(outputBuffer, (Format)((AudioCodec)this).outputFormat, outLength + 4, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     return rc;
/*     */   }
/*     */ 
/*     */   
/*     */   public void open() throws ResourceUnavailableException {
/* 158 */     this.dviState = new DVIState();
/*     */     
/* 160 */     setPacketSize(this.packetSize);
/* 161 */     reset();
/*     */   }
/*     */   
/*     */   public void reset() {
/* 165 */     super.reset();
/* 166 */     this.dviState.valprev = 0;
/* 167 */     this.dviState.index = 0;
/* 168 */     this.pcmBuffer.setOffset(0);
/* 169 */     this.pcmBuffer.setLength(0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getControls() {
/* 175 */     if (((BasicPlugIn)this).controls == null) {
/* 176 */       ((BasicPlugIn)this).controls = (Object[])new javax.media.Control[2];
/* 177 */       ((BasicPlugIn)this).controls[0] = new PacketSizeAdapter((Codec)this, this.packetSize, true);
/* 178 */       ((BasicPlugIn)this).controls[1] = new SilenceSuppressionAdapter((Codec)this, false, false);
/*     */     } 
/* 180 */     return ((BasicPlugIn)this).controls;
/*     */   }
/*     */   
/*     */   public synchronized void setPacketSize(int newPacketSize) {
/* 184 */     this.packetSize = newPacketSize * 4;
/*     */     
/* 186 */     this.sample_count = this.packetSize / 2;
/*     */     
/* 188 */     if (this.history == null) {
/* 189 */       this.history = new byte[this.packetSize];
/*     */       
/*     */       return;
/*     */     } 
/* 193 */     if (this.packetSize > this.history.length) {
/* 194 */       byte[] newHistory = new byte[this.packetSize];
/* 195 */       System.arraycopy(this.history, 0, newHistory, 0, this.historyLength);
/* 196 */       this.history = newHistory;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\dvi\JavaEncoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */