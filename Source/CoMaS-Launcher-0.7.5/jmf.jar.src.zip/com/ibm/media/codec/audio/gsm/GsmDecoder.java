/*     */ package com.ibm.media.codec.audio.gsm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GsmDecoder
/*     */ {
/*  49 */   private static final float[] QLB = new float[] { 0.1F, 0.35F, 0.65F, 1.0F };
/*     */ 
/*     */   
/*  52 */   private static final int[] larInterpStart = new int[] { 0, 13, 27, 40, 160 };
/*     */ 
/*     */ 
/*     */   
/*  56 */   private static final float[][] InterpLarCoef = new float[][] { { 0.75F, 0.25F }, { 0.5F, 0.5F }, { 0.25F, 0.75F }, { 0.0F, 1.0F } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   private short[] outsig = new short[160];
/*     */   
/*  89 */   private byte[] inByteStream = new byte[33];
/*     */   
/*  91 */   private float[] prevLARpp = new float[9];
/*     */   
/*  93 */   private float[] rp = new float[9];
/*     */   
/*  95 */   private float[] u = new float[9];
/*     */ 
/*     */   
/*  98 */   private int[] lastSID = new int[76];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   private float[] quantRes = new float[280];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   private int[] parameters = new int[76];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   private float[] LARpp = new float[9];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int GSMrand() {
/* 130 */     this.seed = this.seed * 1103515245 + 12345;
/* 131 */     return this.seed & 0x7FFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 140 */     short[] B = { 0, 0, 2048, -2560, 94, -1792, -341, -1144 };
/* 141 */     short[] MIC = { -32, -32, -16, -16, -8, -8, -4, -4 };
/* 142 */     short[] INVA = { 13107, 13107, 13107, 13107, 19223, 17476, 31454, 29708 };
/*     */   }
/*     */   
/* 145 */   private static float[] xmaxTable = new float[64];
/*     */   static {
/* 147 */     for (int xmaxc = 0; xmaxc < 64; xmaxc++) {
/*     */       int i;
/*     */       
/* 150 */       if (xmaxc < 16) {
/* 151 */         i = 31 + (xmaxc << 5);
/*     */       } else {
/* 153 */         int exp = xmaxc - 16 >> 3;
/* 154 */         i = (576 << exp) - 1 + (xmaxc - 16 - 8 * exp) * (64 << exp);
/*     */       } 
/* 156 */       xmaxTable[xmaxc] = i / 32768.0F;
/*     */     } 
/*     */   }
/*     */   public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997,1999."; private static final int OutputSize = 160; private static final int InputSize = 33; private static final int LpcOrder = 8; private static final int SubFrameSize = 40; private static final int NumOfSubframes = 4;
/* 160 */   private static float[][] larTable = new float[8][]; private static final int NumOfParameters = 76; private static final int NumOfPulses = 13; private static final int NumOfLarInterp = 4; private static final int QuantResBase = 120; private static final int SidFrame = 2; private static final int SpeechFrame = 1; static {
/* 161 */     for (int larNum = 0; larNum < 8; larNum++) {
/* 162 */       larTable[larNum] = new float[-MIC[larNum] * 2];
/* 163 */       for (int larQuant = 0; larQuant < -MIC[larNum] * 2; larQuant++) {
/* 164 */         short temp = (short)((larQuant + MIC[larNum] << 10) - B[larNum] * 2);
/* 165 */         temp = (short)(int)((temp * INVA[larNum]) + 16384L >> 15L);
/* 166 */         larTable[larNum][larQuant] = (temp * 2) / 16384.0F;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private static final int NullFrame = 0; private static final int Parameter_SubFramesBase = 8; private static final int Parameter_SubFramesLength = 17; private static final int Parameter_LtpLag = 0; private static final int Parameter_LtpGain = 1; private static final int Parameter_RpeGridPosition = 2;
/*     */   private static final int Parameter_BlockAmplitude = 3;
/*     */   private static final int Parameter_RpePulsesBase = 4;
/*     */   private int prevNc;
/*     */   private float prevOut;
/*     */   private int seed;
/*     */   private static final int GSM_MAGIC = 13;
/*     */   
/*     */   public void decoderInit() {
/* 179 */     this.prevNc = 40;
/* 180 */     this.prevOut = 0.0F;
/*     */     
/* 182 */     for (int i = 0; i < 9; i++) {
/* 183 */       this.prevLARpp[i] = 0.0F;
/* 184 */       this.rp[i] = 0.0F;
/* 185 */       this.u[i] = 0.0F;
/*     */     } 
/*     */     
/* 188 */     for (int j = 0; j < this.lastSID.length; j++) {
/* 189 */       this.lastSID[j] = 0;
/*     */     }
/* 191 */     this.lastSID[0] = 2;
/* 192 */     this.lastSID[1] = 28;
/* 193 */     this.lastSID[2] = 18;
/* 194 */     this.lastSID[3] = 12;
/* 195 */     this.lastSID[4] = 7;
/* 196 */     this.lastSID[5] = 5;
/* 197 */     this.lastSID[6] = 3;
/* 198 */     this.lastSID[7] = 2;
/*     */ 
/*     */ 
/*     */     
/* 202 */     for (int k = 0; k < this.quantRes.length; k++) {
/* 203 */       this.quantRes[k] = 0.0F;
/*     */     }
/* 205 */     this.seed = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean decodeFrame(byte[] src, int srcoffset, byte[] dst, int dstoffset) {
/* 218 */     int[] parameters = this.parameters;
/* 219 */     int[] lastSID = this.lastSID;
/* 220 */     float[] LARpp = this.LARpp;
/* 221 */     float[] u = this.u;
/* 222 */     float[] rp = this.rp;
/* 223 */     float[] prevLARpp = this.prevLARpp;
/* 224 */     float[] quantRes = this.quantRes;
/*     */ 
/*     */     
/* 227 */     System.arraycopy(quantRes, 160, quantRes, 0, 120);
/*     */     
/* 229 */     if (false == UnpackBitStream(src, srcoffset, parameters)) {
/* 230 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 235 */     int frameType = 0;
/*     */ 
/*     */ 
/*     */     
/* 239 */     for (int i = 0; i < 76; i++) {
/* 240 */       if (0 != parameters[i]) {
/* 241 */         frameType = 2;
/*     */         break;
/*     */       } 
/*     */     } 
/* 245 */     if (frameType == 0) {
/*     */       
/* 247 */       System.arraycopy(lastSID, 0, parameters, 0, 76);
/*     */       
/* 249 */       frameType = 2;
/*     */     } else {
/* 251 */       for (int m = 0; m < 4; m++) {
/*     */         
/* 253 */         int subFramePulseBase = m * 17 + 8 + 4;
/*     */ 
/*     */         
/* 256 */         for (int n = 0; n < 13; n++) {
/* 257 */           if (parameters[subFramePulseBase + n] != 0) {
/* 258 */             frameType = 1;
/* 259 */             m = 4;
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 264 */       if (frameType == 2) {
/* 265 */         System.arraycopy(parameters, 0, lastSID, 0, 76);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 270 */     if (frameType == 2)
/*     */     {
/*     */       
/* 273 */       for (int m = 0; m < 4; m++) {
/*     */         
/* 275 */         int subFrameParamBase = m * 17 + 8;
/*     */ 
/*     */         
/* 278 */         for (byte b = 0; b < 13; b++) {
/* 279 */           parameters[subFrameParamBase + 4 + b] = GSMrand() / 5461 + 1;
/*     */         }
/* 281 */         parameters[subFrameParamBase + 2] = GSMrand() / 10923;
/*     */         
/* 283 */         parameters[subFrameParamBase + 1] = 0;
/*     */         
/* 285 */         parameters[subFrameParamBase + 0] = ((((m == 0) ? 1 : 0) | ((m == 2) ? 1 : 0)) != 0) ? 40 : 120;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 293 */     for (int subFrameNumber = 0; subFrameNumber < 4; subFrameNumber++) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 303 */       int subFrameParamBase = subFrameNumber * 17 + 8;
/*     */ 
/*     */       
/* 306 */       int tempLtpLag = parameters[subFrameParamBase + 0];
/* 307 */       if (tempLtpLag >= 40 && tempLtpLag <= 120) {
/* 308 */         this.prevNc = tempLtpLag;
/*     */       }
/* 310 */       float ltpGain = QLB[parameters[subFrameParamBase + 1]];
/* 311 */       int rpeGridPos = parameters[subFrameParamBase + 2];
/* 312 */       float xmaxp = xmaxTable[parameters[subFrameParamBase + 3]];
/*     */       
/* 314 */       int subFrameResidualBase = subFrameNumber * 40 + 120;
/*     */ 
/*     */       
/* 317 */       for (int m = 0; m < 40; m++) {
/* 318 */         quantRes[subFrameResidualBase + m] = ltpGain * quantRes[subFrameResidualBase + m - this.prevNc];
/*     */       }
/*     */ 
/*     */       
/* 322 */       for (int n = 0; n < 13; n++) {
/* 323 */         quantRes[subFrameResidualBase + rpeGridPos + 3 * n] = (float)(quantRes[subFrameResidualBase + rpeGridPos + 3 * n] + (0.25D * parameters[subFrameParamBase + 4 + n] - 0.875D) * xmaxp);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 331 */     for (int larNum = 0; larNum < 8; larNum++) {
/* 332 */       LARpp[larNum + 1] = larTable[larNum][parameters[larNum]];
/*     */     }
/* 334 */     float prevOut = this.prevOut;
/* 335 */     for (int larInterpNumber = 0; larInterpNumber < 4; larInterpNumber++) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 341 */       for (int m = 1; m <= 8; m++) {
/*     */         
/* 343 */         float LARpi = prevLARpp[m] * InterpLarCoef[larInterpNumber][0] + LARpp[m] * InterpLarCoef[larInterpNumber][1];
/*     */ 
/*     */         
/* 346 */         if (Math.abs(LARpi) < 0.675D) {
/* 347 */           rp[m] = LARpi;
/* 348 */         } else if (Math.abs(LARpi) < 1.225D) {
/* 349 */           rp[m] = ((LARpi > 0.0F) ? 1.0F : -1.0F) * (0.5F * Math.abs(LARpi) + 0.3375F);
/*     */         } else {
/* 351 */           rp[m] = ((LARpi > 0.0F) ? 1.0F : -1.0F) * (0.125F * Math.abs(LARpi) + 0.796875F);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 358 */       for (int outCount = larInterpStart[larInterpNumber]; outCount < larInterpStart[larInterpNumber + 1]; outCount++) {
/*     */         
/* 360 */         float temp = quantRes[120 + outCount];
/* 361 */         temp -= rp[8] * u[7];
/* 362 */         u[8] = u[7] + rp[8] * temp;
/* 363 */         temp -= rp[7] * u[6];
/* 364 */         u[7] = u[6] + rp[7] * temp;
/* 365 */         temp -= rp[6] * u[5];
/* 366 */         u[6] = u[5] + rp[6] * temp;
/* 367 */         temp -= rp[5] * u[4];
/* 368 */         u[5] = u[4] + rp[5] * temp;
/* 369 */         temp -= rp[4] * u[3];
/* 370 */         u[4] = u[3] + rp[4] * temp;
/* 371 */         temp -= rp[3] * u[2];
/* 372 */         u[3] = u[2] + rp[3] * temp;
/* 373 */         temp -= rp[2] * u[1];
/* 374 */         u[2] = u[1] + rp[2] * temp;
/* 375 */         temp -= rp[1] * u[0];
/* 376 */         u[1] = u[0] + rp[1] * temp;
/* 377 */         prevOut = temp + prevOut * 0.85998535F;
/* 378 */         u[0] = temp;
/* 379 */         temp = 65532.0F * prevOut;
/* 380 */         if (temp > 32766.0F)
/* 381 */           temp = 32766.0F; 
/* 382 */         if (temp < -32766.0F)
/* 383 */           temp = -32766.0F; 
/* 384 */         this.outsig[outCount] = (short)(int)temp;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 392 */     for (int j = 1; j <= 8; j++) {
/* 393 */       prevLARpp[j] = LARpp[j];
/*     */     }
/* 395 */     this.prevOut = prevOut;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 402 */     int dstIndex = 0;
/*     */     
/* 404 */     for (int k = 0; k < 160; k++) {
/*     */       
/* 406 */       int TempInt = this.outsig[k];
/*     */       
/* 408 */       dst[dstoffset + dstIndex++] = (byte)(TempInt & 0xFF);
/* 409 */       dst[dstoffset + dstIndex++] = (byte)(TempInt >> 8);
/*     */     } 
/*     */ 
/*     */     
/* 413 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean UnpackBitStream(byte[] inByteStream, int inputIndex, int[] Parameters) {
/* 427 */     int paramIndex = 0;
/*     */ 
/*     */ 
/*     */     
/* 431 */     if ((inByteStream[inputIndex] >> 4 & 0xF) != 13) {
/* 432 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 440 */     Parameters[paramIndex++] = (inByteStream[inputIndex] & 0xF) << 2 | inByteStream[++inputIndex] >> 6 & 0x3;
/* 441 */     Parameters[paramIndex++] = inByteStream[inputIndex] & 0x3F;
/* 442 */     Parameters[paramIndex++] = inByteStream[++inputIndex] >> 3 & 0x1F;
/* 443 */     Parameters[paramIndex++] = (inByteStream[inputIndex] & 0x7) << 2 | inByteStream[++inputIndex] >> 6 & 0x3;
/* 444 */     Parameters[paramIndex++] = inByteStream[inputIndex] >> 2 & 0xF;
/* 445 */     Parameters[paramIndex++] = (inByteStream[inputIndex] & 0x3) << 2 | inByteStream[++inputIndex] >> 6 & 0x3;
/* 446 */     Parameters[paramIndex++] = inByteStream[inputIndex] >> 3 & 0x7;
/* 447 */     Parameters[paramIndex++] = inByteStream[inputIndex] & 0x7;
/* 448 */     inputIndex++;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 455 */     for (int n = 0; n < 4; n++) {
/* 456 */       Parameters[paramIndex++] = inByteStream[inputIndex] >> 1 & 0x7F;
/* 457 */       Parameters[paramIndex++] = (inByteStream[inputIndex] & 0x1) << 1 | inByteStream[++inputIndex] >> 7 & 0x1;
/* 458 */       Parameters[paramIndex++] = inByteStream[inputIndex] >> 5 & 0x3;
/* 459 */       Parameters[paramIndex++] = (inByteStream[inputIndex] & 0x1F) << 1 | inByteStream[++inputIndex] >> 7 & 0x1;
/* 460 */       Parameters[paramIndex++] = inByteStream[inputIndex] >> 4 & 0x7;
/* 461 */       Parameters[paramIndex++] = inByteStream[inputIndex] >> 1 & 0x7;
/* 462 */       Parameters[paramIndex++] = (inByteStream[inputIndex] & 0x1) << 2 | inByteStream[++inputIndex] >> 6 & 0x3;
/* 463 */       Parameters[paramIndex++] = inByteStream[inputIndex] >> 3 & 0x7;
/* 464 */       Parameters[paramIndex++] = inByteStream[inputIndex] & 0x7;
/* 465 */       Parameters[paramIndex++] = inByteStream[++inputIndex] >> 5 & 0x7;
/* 466 */       Parameters[paramIndex++] = inByteStream[inputIndex] >> 2 & 0x7;
/* 467 */       Parameters[paramIndex++] = (inByteStream[inputIndex] & 0x3) << 1 | inByteStream[++inputIndex] >> 7 & 0x1;
/* 468 */       Parameters[paramIndex++] = inByteStream[inputIndex] >> 4 & 0x7;
/* 469 */       Parameters[paramIndex++] = inByteStream[inputIndex] >> 1 & 0x7;
/* 470 */       Parameters[paramIndex++] = (inByteStream[inputIndex] & 0x1) << 2 | inByteStream[++inputIndex] >> 6 & 0x3;
/* 471 */       Parameters[paramIndex++] = inByteStream[inputIndex] >> 3 & 0x7;
/* 472 */       Parameters[paramIndex++] = inByteStream[inputIndex] & 0x7;
/* 473 */       inputIndex++;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 478 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\gsm\GsmDecoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */