package com.ibm.media.codec.audio.dvi;

import com.ibm.media.codec.audio.AudioCodec;
import com.sun.media.BasicPlugIn;
import com.sun.media.controls.SilenceSuppressionAdapter;
import javax.media.Buffer;
import javax.media.Codec;
import javax.media.Format;
import javax.media.format.AudioFormat;

public class JavaDecoder extends AudioCodec {
  private DVIState dviState;
  
  public JavaDecoder() {
    this.supportedInputFormats = new AudioFormat[] { new AudioFormat("dvi/rtp") };
    this.defaultOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR") };
    this.PLUGIN_NAME = "DVI Decoder";
  }
  
  protected Format[] getMatchingOutputFormats(Format in) {
    AudioFormat af = (AudioFormat)in;
    this.supportedOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR", af.getSampleRate(), 16, af.getChannels(), 0, 1) };
    return (Format[])this.supportedOutputFormats;
  }
  
  public void open() {
    this.dviState = new DVIState();
  }
  
  public void close() {
    this.dviState = null;
  }
  
  public int process(Buffer inputBuffer, Buffer outputBuffer) {
    int outLength = 0;
    if (!checkInputBuffer(inputBuffer))
      return 1; 
    if (isEOM(inputBuffer)) {
      propagateEOM(outputBuffer);
      return 0;
    } 
    int channels = this.outputFormat.getChannels();
    byte[] inData = (byte[])inputBuffer.getData();
    byte[] outData = validateByteArraySize(outputBuffer, (inData.length - 4) * 4);
    int offset = inputBuffer.getOffset();
    int prevVal = inData[offset++] << 8;
    prevVal |= inData[offset++] & 0xFF;
    int index = inData[offset++] & 0xFF;
    offset++;
    this.dviState.valprev = prevVal;
    this.dviState.index = index;
    DVI.decode(inData, offset, outData, 0, 2 * (inputBuffer.getLength() - 4), this.dviState);
    outLength = 4 * (inputBuffer.getLength() - 4);
    updateOutput(outputBuffer, (Format)this.outputFormat, outLength, 0);
    return 0;
  }
  
  public Object[] getControls() {
    if (((BasicPlugIn)this).controls == null) {
      ((BasicPlugIn)this).controls = (Object[])new javax.media.Control[1];
      ((BasicPlugIn)this).controls[0] = new SilenceSuppressionAdapter((Codec)this, false, false);
    } 
    return ((BasicPlugIn)this).controls;
  }
}
