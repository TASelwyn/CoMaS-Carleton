package com.ibm.media.codec.audio.ulaw;

import com.ibm.media.codec.audio.AudioCodec;
import com.sun.media.BasicPlugIn;
import com.sun.media.controls.SilenceSuppressionAdapter;
import javax.media.Buffer;
import javax.media.Codec;
import javax.media.Format;
import javax.media.format.AudioFormat;

public class JavaDecoder extends AudioCodec {
  private static final byte[] lutTableL = new byte[256];
  
  private static final byte[] lutTableH = new byte[256];
  
  public JavaDecoder() {
    this.supportedInputFormats = new AudioFormat[] { new AudioFormat("ULAW") };
    this.defaultOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR") };
    this.PLUGIN_NAME = "Mu-Law Decoder";
  }
  
  protected Format[] getMatchingOutputFormats(Format in) {
    AudioFormat af = (AudioFormat)in;
    this.supportedOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR", af.getSampleRate(), 16, af.getChannels(), 0, 1) };
    return (Format[])this.supportedOutputFormats;
  }
  
  public void open() {
    initTables();
  }
  
  public int process(Buffer inputBuffer, Buffer outputBuffer) {
    if (!checkInputBuffer(inputBuffer))
      return 1; 
    if (isEOM(inputBuffer)) {
      propagateEOM(outputBuffer);
      return 0;
    } 
    int channels = this.outputFormat.getChannels();
    byte[] inData = (byte[])inputBuffer.getData();
    byte[] outData = validateByteArraySize(outputBuffer, inData.length * 2);
    int inpLength = inputBuffer.getLength();
    int outLength = 2 * inpLength;
    int inOffset = inputBuffer.getOffset();
    int outOffset = outputBuffer.getOffset();
    for (int i = 0; i < inpLength; i++) {
      int temp = inData[inOffset++] & 0xFF;
      outData[outOffset++] = lutTableL[temp];
      outData[outOffset++] = lutTableH[temp];
    } 
    updateOutput(outputBuffer, (Format)this.outputFormat, outLength, outputBuffer.getOffset());
    return 0;
  }
  
  private void initTables() {
    for (int i = 0; i < 256; i++) {
      int input = i ^ 0xFFFFFFFF;
      int mantissa = ((input & 0xF) << 3) + 132;
      int segment = (input & 0x70) >> 4;
      int value = mantissa << segment;
      value -= 132;
      if ((input & 0x80) != 0)
        value = -value; 
      lutTableL[i] = (byte)value;
      lutTableH[i] = (byte)(value >> 8);
    } 
  }
  
  public Object[] getControls() {
    if (((BasicPlugIn)this).controls == null) {
      ((BasicPlugIn)this).controls = (Object[])new javax.media.Control[1];
      ((BasicPlugIn)this).controls[0] = new SilenceSuppressionAdapter((Codec)this, false, false);
    } 
    return ((BasicPlugIn)this).controls;
  }
}
