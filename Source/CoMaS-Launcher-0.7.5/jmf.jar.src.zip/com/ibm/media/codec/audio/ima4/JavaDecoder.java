/*     */ package com.ibm.media.codec.audio.ima4;
/*     */ 
/*     */ import com.ibm.media.codec.audio.AudioCodec;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.controls.SilenceSuppressionAdapter;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Codec;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaDecoder
/*     */   extends AudioCodec
/*     */ {
/*     */   private IMA4State ima4state;
/*     */   
/*     */   public JavaDecoder() {
/*  32 */     this.supportedInputFormats = new AudioFormat[] { new AudioFormat("ima4") };
/*  33 */     this.defaultOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR") };
/*  34 */     this.PLUGIN_NAME = "IMA4 Decoder";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Format[] getMatchingOutputFormats(Format in) {
/*  40 */     AudioFormat af = (AudioFormat)in;
/*     */     
/*  42 */     this.supportedOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR", af.getSampleRate(), 16, af.getChannels(), 1, 1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  53 */     return (Format[])this.supportedOutputFormats;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() {
/*  60 */     this.ima4state = new IMA4State();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*  66 */     this.ima4state = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int process(Buffer inputBuffer, Buffer outputBuffer) {
/*  75 */     if (!checkInputBuffer(inputBuffer)) {
/*  76 */       return 1;
/*     */     }
/*     */     
/*  79 */     if (isEOM(inputBuffer)) {
/*  80 */       propagateEOM(outputBuffer);
/*  81 */       return 0;
/*     */     } 
/*     */     
/*  84 */     int channels = this.outputFormat.getChannels();
/*  85 */     byte[] inData = (byte[])inputBuffer.getData();
/*  86 */     byte[] outData = validateByteArraySize(outputBuffer, inData.length * 4);
/*     */     
/*  88 */     int outLength = decodeJavaIMA4(inData, outData, inputBuffer.getLength(), outData.length, channels);
/*     */ 
/*     */     
/*  91 */     updateOutput(outputBuffer, (Format)this.outputFormat, outLength, 0);
/*     */     
/*  93 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int decodeJavaIMA4(byte[] inData, byte[] outData, int lenIn, int lenOut, int nChannels) {
/* 102 */     switch (nChannels) {
/*     */       case 1:
/* 104 */         return decodeIMA4mono(inData, outData, lenIn, lenOut, 32);
/*     */       case 2:
/* 106 */         return decodeIMA4stereo(inData, outData, lenIn, lenOut, 32);
/*     */     } 
/* 108 */     throw new RuntimeException("IMA4: Can only handle 1 or 2 channels\n");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int decodeIMA4mono(byte[] inData, byte[] outData, int lenIn, int lenOut, int blockSize) {
/* 114 */     int inCount = 0;
/* 115 */     int outCount = 0;
/*     */ 
/*     */ 
/*     */     
/* 119 */     lenIn = lenIn / (blockSize + 2) * (blockSize + 2);
/*     */     
/* 121 */     while (inCount < lenIn) {
/* 122 */       int state = inData[inCount++] << 8;
/* 123 */       state |= inData[inCount++] & 0xFF;
/*     */ 
/*     */ 
/*     */       
/* 127 */       int index = state & 0x7F;
/*     */       
/* 129 */       if (index > 88) {
/* 130 */         index = 88;
/*     */       }
/* 132 */       this.ima4state.valprev = state & 0xFFFFFF80;
/* 133 */       this.ima4state.index = index;
/*     */       
/* 135 */       IMA4.decode(inData, inCount, outData, outCount, blockSize << 1, this.ima4state, 0);
/*     */       
/* 137 */       inCount += blockSize;
/* 138 */       outCount += blockSize << 2;
/*     */     } 
/*     */     
/* 141 */     return outCount;
/*     */   }
/*     */   
/*     */   private int decodeIMA4stereo(byte[] inData, byte[] outData, int lenIn, int lenOut, int blockSize) {
/* 145 */     int inCount = 0;
/* 146 */     int outCount = 0;
/*     */ 
/*     */     
/* 149 */     lenIn = lenIn / 2 / (blockSize + 2) * (blockSize + 2) * 2;
/*     */ 
/*     */     
/* 152 */     while (inCount < lenIn) {
/*     */       
/* 154 */       int stateL = inData[inCount++] << 8;
/* 155 */       stateL |= inData[inCount++] & 0xFF;
/*     */       
/* 157 */       int indexL = stateL & 0x7F;
/*     */       
/* 159 */       if (indexL > 88) {
/* 160 */         indexL = 88;
/*     */       }
/* 162 */       this.ima4state.valprev = stateL & 0xFFFFFF80;
/* 163 */       this.ima4state.index = indexL;
/*     */ 
/*     */       
/* 166 */       IMA4.decode(inData, inCount, outData, outCount, blockSize << 1, this.ima4state, 2);
/*     */       
/* 168 */       inCount += blockSize;
/*     */ 
/*     */       
/* 171 */       int stateR = inData[inCount++] << 8;
/* 172 */       stateR |= inData[inCount++] & 0xFF;
/*     */       
/* 174 */       int indexR = stateR & 0x7F;
/*     */       
/* 176 */       if (indexR > 88) {
/* 177 */         indexR = 88;
/*     */       }
/* 179 */       this.ima4state.valprev = stateR & 0xFFFFFF80;
/* 180 */       this.ima4state.index = indexR;
/*     */ 
/*     */       
/* 183 */       IMA4.decode(inData, inCount, outData, outCount + 2, blockSize << 1, this.ima4state, 2);
/*     */ 
/*     */       
/* 186 */       inCount += blockSize;
/* 187 */       outCount += blockSize << 3;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 192 */     return outCount;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getControls() {
/* 197 */     if (((BasicPlugIn)this).controls == null) {
/* 198 */       ((BasicPlugIn)this).controls = (Object[])new javax.media.Control[1];
/* 199 */       ((BasicPlugIn)this).controls[0] = new SilenceSuppressionAdapter((Codec)this, false, false);
/*     */     } 
/* 201 */     return ((BasicPlugIn)this).controls;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\ima4\JavaDecoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */