/*      */ package com.ibm.media.codec.video.h263;
/*      */ 
/*      */ import java.awt.Point;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class H263Decoder
/*      */   extends ReadStream
/*      */ {
/*      */   public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997-1999.";
/*      */   private static final boolean DEBUG = false;
/*      */   private static final int I_PICTURE = 0;
/*      */   private static final int P_PICTURE = 1;
/*      */   private static final int INTRA_STUFFING = -1;
/*      */   private static final int INTER_STUFFING = -1;
/*      */   private static final int ESCAPE_CODE = 7167;
/*      */   private static final int PSC = 32;
/*      */   private static final int GBSC_1 = 33;
/*      */   private static final int GBSC_17 = 49;
/*      */   private static final int GBSC_30 = 62;
/*      */   private static final int EOS = 63;
/*      */   private static final int INIT_FORMAT = 9;
/*      */   private static final int USER_DEFINED_FORMAT = 7;
/*      */   private static final int SUB_QCIF_FORMAT = 1;
/*      */   private static final int QCIF_PAL_FORMAT = 2;
/*      */   private static final int CIF_PAL_FORMAT = 3;
/*      */   private static final int W0 = 277;
/*      */   private static final int W1 = 362;
/*      */   private static final int W2 = 473;
/*      */   private static final int W3 = 669;
/*      */   public static final int H263_RC_PICTURE_NOT_DONE = 0;
/*      */   public static final int H263_RC_PICTURE_DONE = 1;
/*      */   public static final int H263_RC_PICTURE_FORMAT_NOT_SUPPORTED = 2;
/*      */   public static final int H263_RC_PICTURE_FORMAT_NOT_INITED = 3;
/*      */   public int TemporalReference;
/*      */   public int LastTemporalReference;
/*      */   private int rtpTemporalReference;
/*      */   private int HeaderPlus;
/*      */   private int TypeInformation;
/*      */   private int CodingType;
/*      */   private int UnrestrictedMV;
/*      */   private int DeblockingFilter;
/*      */   private int SourceFormat;
/*      */   private int CPM;
/*      */   private int Quantizer;
/*      */   private int GroupNumber;
/*      */   private int GOB_FrameID;
/*      */   private int[][] BlockData;
/*   81 */   private int[][] BlockPtr = new int[6][];
/*   82 */   private int[] BlockOffset = new int[6];
/*      */   
/*      */   private int[] FrameWidthBlock;
/*      */   
/*      */   private int LastValue;
/*      */   
/*      */   private int FrameWidth;
/*      */   
/*      */   private int FrameWidthDiv2;
/*      */   
/*      */   private int FrameWidthx8;
/*      */   
/*      */   private int FrameHeight;
/*      */   
/*      */   private int HorMV;
/*      */   
/*      */   private int VerMV;
/*      */   
/*      */   private int Half_HorMV;
/*      */   
/*      */   private int Half_VerMV;
/*      */   
/*      */   private int xFrameWidth;
/*      */   
/*      */   private int xFrameWidthDiv2;
/*      */   
/*      */   public FrameBuffer CurrentFrame;
/*      */   
/*      */   protected boolean frameDone;
/*      */   private boolean foundPSC = false;
/*      */   private boolean standardH263Only;
/*  113 */   private long prevTimeStamp = 0L;
/*      */   
/*      */   private FrameBuffer PreviousFrame;
/*      */   private FrameBuffer xPrevFrame;
/*      */   private int MB_address;
/*      */   private int FirstMBinGOB;
/*      */   private int MBperGOB;
/*      */   private int MBpositionInGOB;
/*      */   private int GOBperFrame;
/*      */   private boolean HeaderInGOB;
/*      */   private int CurrentLumiOffset;
/*      */   private int CurrentCromOffset;
/*      */   private int xCurrentLumiOffset;
/*      */   private int xCurrentCromOffset;
/*  127 */   private static final int[] LumiOffset = new int[36];
/*  128 */   private static final int[] CromOffset = new int[36];
/*  129 */   private static final int[] xLumiOffset = new int[36];
/*  130 */   private static final int[] xCromOffset = new int[36];
/*      */   
/*  132 */   private static final int[] CodedMap = new int[2048];
/*      */   
/*      */   private int[] MBtypeCurrGOB;
/*      */   
/*      */   private int[] MBtypePrevGOB;
/*      */   
/*      */   private Point[] MotVectCurrGOB;
/*      */   
/*      */   private Point[] MotVectPrevGOB;
/*      */   private int prevCBP;
/*  142 */   private static final int[] dQuant = new int[] { 1, 0, 3, 4 };
/*      */   
/*  144 */   private static final int[][] recLevel_tab = new int[32][128];
/*  145 */   private static final int[] clipQ_tab = new int[36];
/*  146 */   private static final int[] pre8x8_tab = new int[] { 512, 710, 669, 602, 512, 402, 277, 141, 710, 985, 928, 835, 710, 558, 384, 196, 669, 928, 874, 787, 669, 526, 362, 185, 602, 835, 787, 708, 602, 473, 326, 166, 512, 710, 669, 602, 512, 402, 277, 141, 402, 558, 526, 473, 402, 316, 218, 111, 277, 384, 362, 326, 277, 218, 150, 76, 141, 196, 185, 166, 141, 111, 76, 39 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  152 */   private static final int[] STRENGTH = new int[31];
/*      */   
/*  154 */   private static final int[] zigzag_tab = new int[64];
/*  155 */   private static final int[] IntraMCBPC_VLC_tab0 = new int[64];
/*  156 */   private static final int[] IntraMCBPC_VLC_tab1 = new int[64];
/*  157 */   private static final int[] InterMCBPC_VLC_tab0 = new int[512];
/*  158 */   private static final int[] InterMCBPC_VLC_tab1 = new int[512];
/*  159 */   private static final int[] CBPY_VLC_tab0 = new int[64];
/*  160 */   private static final int[] CBPY_VLC_tab1 = new int[64];
/*  161 */   private static final int[] MVD1_VLC_tab0 = new int[256];
/*  162 */   private static final int[] MVD1_VLC_tab1 = new int[256];
/*  163 */   private static final int[] MVD2_VLC_tab0 = new int[256];
/*  164 */   private static final int[] MVD2_VLC_tab1 = new int[256];
/*  165 */   private static final int[] TCOEFF1_tab0 = new int[112];
/*  166 */   private static final int[] TCOEFF1_tab1 = new int[112];
/*  167 */   private static final int[] TCOEFF2_tab0 = new int[96];
/*  168 */   private static final int[] TCOEFF2_tab1 = new int[96];
/*  169 */   private static final int[] TCOEFF3_tab0 = new int[120];
/*  170 */   private static final int[] TCOEFF3_tab1 = new int[120];
/*      */   
/*  172 */   private static final int[] clipTable = new int[1024];
/*  173 */   private static final int[] DfiltClip = new int[512];
/*      */ 
/*      */ 
/*      */   
/*      */   final void init() {
/*  178 */     this.SourceFormat = 9;
/*      */   }
/*      */ 
/*      */   
/*      */   public H263Decoder(boolean standardOnly) {
/*  183 */     this.standardH263Only = standardOnly;
/*      */     
/*  185 */     this.SourceFormat = 9;
/*  186 */     this.foundPSC = false;
/*  187 */     this.TemporalReference = 0;
/*  188 */     this.LastTemporalReference = 0;
/*      */     
/*  190 */     this.BlockData = new int[6][64];
/*  191 */     this.FrameWidthBlock = new int[6];
/*      */     
/*  193 */     this.MotVectCurrGOB = new Point[88];
/*  194 */     this.MotVectPrevGOB = new Point[88];
/*  195 */     for (int i = 0; i < 88; i++) {
/*  196 */       this.MotVectCurrGOB[i] = new Point(0, 0);
/*  197 */       this.MotVectPrevGOB[i] = new Point(0, 0);
/*      */     } 
/*      */     
/*  200 */     this.MBtypeCurrGOB = new int[22];
/*  201 */     this.MBtypePrevGOB = new int[22];
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  207 */     int row = 0, col = 0;
/*  208 */     int direction = 1;
/*  209 */     for (int i = 0; i < 32; i++) {
/*  210 */       int temp = row * 8 + col;
/*  211 */       zigzag_tab[i] = temp;
/*  212 */       zigzag_tab[63 - i] = 63 - temp;
/*      */       
/*  214 */       row -= direction;
/*  215 */       col += direction;
/*      */       
/*  217 */       if (col < 0) {
/*  218 */         direction = 1;
/*  219 */         col = 0;
/*      */       } 
/*      */       
/*  222 */       if (row < 0) {
/*  223 */         direction = -1;
/*  224 */         row = 0;
/*      */       } 
/*      */     } 
/*      */     
/*  228 */     for (int j = 0; j < 1024; j++) {
/*  229 */       clipTable[j] = (j < 256) ? j : ((j < 512) ? 255 : 0);
/*      */     }
/*      */     
/*  232 */     for (int k = 0; k < recLevel_tab.length; k++) {
/*  233 */       for (int i10 = 0; i10 < (recLevel_tab[k]).length; i10++) {
/*  234 */         if (i10 == 0) {
/*  235 */           recLevel_tab[k][i10] = 0;
/*      */         } else {
/*  237 */           int temp = k * (2 * i10 + 1);
/*  238 */           recLevel_tab[k][i10] = (temp < -2048) ? -2048 : ((temp > 2047) ? 2047 : temp);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  243 */     for (int m = 0; m < clipQ_tab.length; m++) {
/*  244 */       int temp = m - 2;
/*  245 */       clipQ_tab[m] = (temp < 1) ? 1 : ((temp > 31) ? 31 : temp);
/*      */     } 
/*      */     
/*  248 */     for (int n = 1; n < IntraMCBPC_VLC_tab0.length; n++) {
/*  249 */       IntraMCBPC_VLC_tab0[n] = (n <= 3) ? (64 + n) : ((n <= 7) ? 64 : ((n <= 31) ? (n / 8 + 48) : 48));
/*  250 */       IntraMCBPC_VLC_tab1[n] = (n <= 3) ? 6 : ((n <= 7) ? 4 : ((n <= 31) ? 3 : 1));
/*      */     } 
/*      */     
/*  253 */     for (int i1 = 1; i1 < InterMCBPC_VLC_tab0.length; i1++) {
/*  254 */       InterMCBPC_VLC_tab0[i1] = (i1 <= 1) ? -1 : ((i1 <= 4) ? (69 - i1) : ((i1 <= 5) ? 19 : ((i1 <= 9) ? (53 - i1 / 2) : ((i1 <= 11) ? 35 : ((i1 <= 15) ? 51 : ((i1 <= 19) ? 34 : ((i1 <= 23) ? 33 : ((i1 <= 27) ? 18 : ((i1 <= 31) ? 17 : ((i1 <= 39) ? 64 : ((i1 <= 47) ? 3 : ((i1 <= 63) ? 48 : ((i1 <= 95) ? 2 : ((i1 <= 127) ? 1 : ((i1 <= 191) ? 32 : ((i1 < 256) ? 16 : 0))))))))))))))));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  261 */       InterMCBPC_VLC_tab1[i1] = (i1 <= 5) ? 9 : ((i1 <= 11) ? 8 : ((i1 <= 31) ? 7 : ((i1 <= 47) ? 6 : ((i1 <= 63) ? 5 : ((i1 <= 127) ? 4 : ((i1 <= 255) ? 3 : 1))))));
/*      */     } 
/*      */ 
/*      */     
/*  265 */     for (int i2 = 2; i2 < CBPY_VLC_tab0.length; i2++) {
/*  266 */       CBPY_VLC_tab0[i2] = (i2 <= 2) ? 105 : ((i2 <= 3) ? 150 : ((i2 <= 5) ? 135 : ((i2 <= 7) ? 75 : ((i2 <= 9) ? 45 : ((i2 <= 11) ? 30 : ((i2 <= 15) ? 15 : ((i2 <= 19) ? 195 : ((i2 <= 23) ? 165 : ((i2 <= 27) ? 225 : ((i2 <= 31) ? 90 : ((i2 <= 35) ? 210 : ((i2 <= 39) ? 60 : ((i2 <= 43) ? 180 : ((i2 <= 47) ? 120 : 240))))))))))))));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  271 */       CBPY_VLC_tab1[i2] = (i2 <= 3) ? 6 : ((i2 <= 11) ? 5 : ((i2 <= 47) ? 4 : 2));
/*      */     } 
/*      */     
/*  274 */     for (int i3 = 6; i3 < MVD1_VLC_tab0.length; i3++) {
/*  275 */       MVD1_VLC_tab0[i3] = (i3 <= 11) ? ((10 - i3 / 2) * (1 - (i3 & 0x1) * 2)) : ((i3 <= 15) ? (4 * (1 - (i3 & 0x2))) : ((i3 <= 31) ? (3 * (1 - (0x1 & i3 >> 3) * 2)) : ((i3 <= 63) ? (2 * (1 - (0x1 & i3 >> 4) * 2)) : ((i3 < 128) ? (1 - (0x1 & i3 >> 5) * 2) : 0))));
/*      */       
/*  277 */       MVD1_VLC_tab1[i3] = (i3 <= 11) ? 8 : ((i3 <= 15) ? 7 : ((i3 <= 31) ? 5 : ((i3 <= 63) ? 4 : ((i3 <= 127) ? 3 : 1))));
/*      */     } 
/*      */ 
/*      */     
/*  281 */     for (int i4 = 0; i4 < MVD2_VLC_tab0.length; i4++) {
/*  282 */       MVD2_VLC_tab0[i4] = (i4 < 5) ? 0 : ((i4 == 5) ? -32 : ((i4 <= 7) ? (31 * (1 - (i4 & 0x1) * 2)) : ((i4 <= 31) ? ((32 - (i4 >> 2)) * (1 - (0x1 & i4 >> 1) * 2)) : ((i4 <= 143) ? ((28 - (i4 >> 3)) * (1 - (0x1 & i4 >> 2) * 2)) : ((19 - (i4 >> 4)) * (1 - (0x1 & i4 >> 3) * 2))))));
/*      */       
/*  284 */       MVD2_VLC_tab1[i4] = (i4 <= 4) ? 5 : ((i4 <= 7) ? 13 : ((i4 <= 31) ? 12 : ((i4 <= 143) ? 11 : ((i4 <= 191) ? 10 : 5))));
/*      */     } 
/*      */ 
/*      */     
/*  288 */     for (int i5 = 0; i5 < TCOEFF1_tab0.length; i5++) {
/*  289 */       TCOEFF1_tab0[i5] = (i5 <= 3) ? (4225 - i5 * 16) : ((i5 <= 6) ? (257 - i5 * 16) : ((i5 <= 7) ? 4 : ((i5 <= 15) ? (4225 - i5 / 2 * 16) : ((i5 <= 23) ? (273 - i5 / 2 * 16) : ((i5 <= 25) ? 18 : ((i5 <= 27) ? 3 : ((i5 <= 39) ? (193 - i5 / 4 * 16) : ((i5 <= 47) ? 4097 : ((i5 <= 79) ? 1 : ((i5 <= 95) ? 17 : ((i5 <= 103) ? 33 : 2)))))))))));
/*      */ 
/*      */ 
/*      */       
/*  293 */       TCOEFF1_tab1[i5] = (i5 <= 7) ? 7 : ((i5 <= 27) ? 6 : ((i5 <= 39) ? 5 : ((i5 <= 47) ? 4 : ((i5 <= 79) ? 2 : ((i5 <= 95) ? 3 : 4)))));
/*      */     } 
/*      */ 
/*      */     
/*  297 */     for (int i6 = 0; i6 < TCOEFF2_tab0.length; i6++) {
/*  298 */       TCOEFF2_tab0[i6] = (i6 <= 1) ? (9 - i6) : ((i6 <= 17) ? (4497 - i6 / 2 * 16) : ((i6 <= 19) ? 4098 : ((i6 <= 35) ? (513 - i6 / 2 * 16) : ((i6 <= 39) ? (354 - i6 / 2 * 16) : ((i6 <= 43) ? (27 - i6 / 2) : ((i6 <= 75) ? (4529 - i6 / 4 * 16) : ((i6 <= 83) ? (529 - i6 / 4 * 16) : ((i6 <= 91) ? (349 - i6 / 4 * 15) : 5))))))));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  303 */       TCOEFF2_tab1[i6] = (i6 <= 1) ? 10 : ((i6 <= 43) ? 9 : 8);
/*      */     } 
/*      */     
/*  306 */     for (int i7 = 0; i7 < TCOEFF3_tab0.length; i7++) {
/*  307 */       TCOEFF3_tab0[i7] = (i7 <= 3) ? (4114 - i7 / 2 * 15) : ((i7 <= 7) ? (13 - i7 / 2) : ((i7 <= 23) ? (4577 - i7 / 4 * 16) : ((i7 <= 43) ? (242 - i7 / 4 * 16) : ((i7 <= 51) ? (227 - i7 / 4 * 16) : ((i7 <= 55) ? 20 : ((i7 <= 59) ? (i7 / 2 * 9 - 240) : ((i7 <= 63) ? (i7 / 2 * 16 - 111) : ((i7 <= 71) ? (i7 / 2 * 16 + 4049) : ((i7 <= 72) ? 22 : ((i7 <= 73) ? 36 : ((i7 <= 74) ? 67 : ((i7 <= 75) ? 83 : ((i7 <= 76) ? 99 : ((i7 <= 77) ? 162 : ((i7 <= 78) ? 401 : ((i7 <= 79) ? 417 : ((i7 <= 87) ? (i7 * 16 + 3345) : 7167)))))))))))))))));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  313 */       TCOEFF3_tab1[i7] = (i7 <= 7) ? 11 : ((i7 <= 55) ? 10 : ((i7 <= 71) ? 11 : ((i7 <= 87) ? 12 : 6)));
/*      */     } 
/*      */ 
/*      */     
/*  317 */     for (int i8 = 0; i8 < 31; i8++) {
/*  318 */       STRENGTH[i8] = (i8 < 6) ? ((i8 >> 1) + 1) : ((i8 < 9) ? 4 : ((i8 < 13) ? (i8 + 1 >> 1) : ((i8 + 2) / 3 + 2)));
/*      */     }
/*      */     
/*  321 */     for (int i9 = 0; i9 < 512; i9++) {
/*  322 */       DfiltClip[i9] = (i9 < 128) ? 0 : ((i9 < 384) ? (i9 - 128) : 255);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final int ChangeFormat(int NewFormat, int UnrestrictedMV) {
/*  328 */     switch (NewFormat) {
/*      */ 
/*      */       
/*      */       case 1:
/*  332 */         this.FrameWidth = 128;
/*  333 */         this.FrameHeight = 96;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 2:
/*  338 */         this.FrameWidth = 176;
/*  339 */         this.FrameHeight = 144;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 3:
/*  344 */         this.FrameWidth = 352;
/*  345 */         this.FrameHeight = 288;
/*      */         break;
/*      */       
/*      */       case 7:
/*      */         break;
/*      */       
/*      */       default:
/*  352 */         return 2;
/*      */     } 
/*      */ 
/*      */     
/*  356 */     this.GOBperFrame = this.FrameHeight >> 4;
/*  357 */     this.MBperGOB = this.FrameWidth >> 4;
/*  358 */     for (int i = 0; i < this.GOBperFrame; i++) {
/*  359 */       LumiOffset[i] = (this.FrameWidth << 4) * i;
/*  360 */       CromOffset[i] = (this.FrameWidth << 2) * i;
/*  361 */       xLumiOffset[i] = 16 + (32 + this.FrameWidth << 4) * (i + 1);
/*  362 */       xCromOffset[i] = 8 + (16 + (this.FrameWidth >> 1) << 3) * (i + 1);
/*      */     } 
/*  364 */     this.FrameWidthDiv2 = this.FrameWidth >> 1;
/*  365 */     this.FrameWidthx8 = this.FrameWidth << 3;
/*      */     
/*  367 */     this.CurrentFrame = new FrameBuffer(this.FrameWidth, this.FrameHeight);
/*  368 */     this.PreviousFrame = new FrameBuffer(this.FrameWidth, this.FrameHeight);
/*      */     
/*  370 */     this.FrameWidthBlock[0] = this.FrameWidth;
/*  371 */     this.FrameWidthBlock[1] = this.FrameWidth;
/*  372 */     this.FrameWidthBlock[2] = this.FrameWidth;
/*  373 */     this.FrameWidthBlock[3] = this.FrameWidth;
/*  374 */     this.FrameWidthBlock[4] = this.FrameWidthDiv2;
/*  375 */     this.FrameWidthBlock[5] = this.FrameWidthDiv2;
/*      */     
/*  377 */     if (UnrestrictedMV == 1) {
/*  378 */       this.xFrameWidth = this.FrameWidth + 32;
/*  379 */       this.xFrameWidthDiv2 = this.xFrameWidth >> 1;
/*  380 */       this.xPrevFrame = new FrameBuffer(this.FrameWidth + 32, this.FrameHeight + 32);
/*      */     } else {
/*      */       
/*  383 */       this.xFrameWidth = this.FrameWidth;
/*  384 */       this.xFrameWidthDiv2 = this.xFrameWidth >> 1;
/*  385 */       this.xPrevFrame = null;
/*      */     } 
/*      */     
/*  388 */     this.SourceFormat = NewFormat;
/*  389 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int DecodeRtpPacket(byte[] inputBuffer, int inputOffset, int inputLength, byte[] packetHeader, int packetOffset, long timeStamp) {
/*  407 */     int mode = H263RtpPayloadParser.getMode(packetHeader, packetOffset);
/*  408 */     int startBit = H263RtpPayloadParser.getStartBit(packetHeader, packetOffset);
/*  409 */     int endBit = H263RtpPayloadParser.getEndBit(packetHeader, packetOffset);
/*  410 */     int src = H263RtpPayloadParser.getSRC(packetHeader, packetOffset);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  417 */     int rc = 0;
/*  418 */     this.rdptr = inputOffset;
/*      */ 
/*      */ 
/*      */     
/*  422 */     if (mode == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  435 */       boolean prevdone = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  443 */       if (false == this.frameDone && this.foundPSC && timeStamp != this.prevTimeStamp && timeStamp != 0L) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  448 */         this.rtpTemporalReference = H263RtpPayloadParser.getTemporalReference(packetHeader, packetOffset);
/*  449 */         if (this.rtpTemporalReference != 0)
/*      */         {
/*      */           
/*  452 */           this.TemporalReference = this.rtpTemporalReference;
/*      */         }
/*  454 */         this.frameDone = true;
/*  455 */         this.foundPSC = false;
/*  456 */         prevdone = true;
/*      */       } 
/*      */ 
/*      */       
/*  460 */       this.prevTimeStamp = timeStamp;
/*      */ 
/*      */       
/*  463 */       while (this.rdptr < inputLength + inputOffset) {
/*      */         
/*      */         try {
/*  466 */           rc = DecodeGobs(inputBuffer, this.rdptr);
/*      */         
/*      */         }
/*      */         catch (Exception e) {
/*      */ 
/*      */           
/*  472 */           e.printStackTrace();
/*  473 */           System.out.println("[H263Decodeer::decodeRtpPacket] returning H263_RC_PICTURE_FORMAT_NOT_SUPPORTED");
/*  474 */           return 2;
/*      */         } 
/*      */       } 
/*  477 */       if (prevdone == true) {
/*  478 */         prevdone = false;
/*  479 */         return 1;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  484 */       return rc;
/*      */     } 
/*      */     
/*  487 */     if (mode == 1)
/*      */     {
/*      */       
/*  490 */       return 2;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  495 */     return 2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int DecodePicture(byte[] ds_rdbfr, int ds_rdbfr_offset, boolean EntireFrame) {
/*  503 */     int rc = 0;
/*      */     
/*  505 */     if (EntireFrame) {
/*  506 */       this.frameDone = false;
/*  507 */       this.rdptr = ds_rdbfr_offset;
/*  508 */       while (rc == 0)
/*      */       {
/*  510 */         rc = DecodeGobs(ds_rdbfr, this.rdptr);
/*      */       
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/*  516 */       rc = DecodeGobs(ds_rdbfr, ds_rdbfr_offset);
/*      */     } 
/*      */     
/*  519 */     return rc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int DecodeGobs(byte[] ds_rdbfr, int ds_rdbfr_offset) {
/*  534 */     int rc = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  539 */     setInBuf(ds_rdbfr, ds_rdbfr_offset);
/*      */ 
/*      */     
/*  542 */     GetNextStartCode();
/*  543 */     int startCode = getBits(22);
/*      */     
/*  545 */     if (startCode != 32 && startCode != 63 && !this.foundPSC)
/*      */     {
/*      */       
/*  548 */       return 3;
/*      */     }
/*      */     
/*  551 */     if (startCode == 32) {
/*  552 */       this.foundPSC = true;
/*      */     }
/*  554 */     else if (startCode == 63) {
/*      */ 
/*      */       
/*  557 */       return 0;
/*      */     } 
/*  559 */     if (startCode == 63) {
/*  560 */       GetNextStartCode();
/*  561 */       startCode = getBits(22);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  566 */     if (startCode != 32 && !this.foundPSC)
/*      */     {
/*      */       
/*  569 */       return 0;
/*      */     }
/*      */     
/*  572 */     if (startCode == 32) {
/*      */ 
/*      */       
/*  575 */       this.foundPSC = true;
/*  576 */       int tmpTemporalReference = getBits(8);
/*  577 */       this.TypeInformation = getBits(8);
/*  578 */       this.HeaderPlus = this.TypeInformation & 0x7;
/*  579 */       int srcFormat = this.HeaderPlus;
/*  580 */       if (this.HeaderPlus == 7) {
/*  581 */         rc = ParseHeaderPlus();
/*  582 */         if (rc == 2) {
/*  583 */           return rc;
/*      */         }
/*      */       } else {
/*  586 */         this.TypeInformation = getBits(5);
/*      */         
/*  588 */         if ((this.TypeInformation & 0x7) != 0)
/*      */         {
/*  590 */           return 2;
/*      */         }
/*  592 */         this.CodingType = this.TypeInformation >> 4 & 0x1;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  597 */         this.UnrestrictedMV = (this.TypeInformation & 0x8) >> 3;
/*      */       } 
/*      */ 
/*      */       
/*  601 */       this.LastTemporalReference = this.TemporalReference;
/*  602 */       this.TemporalReference = tmpTemporalReference;
/*      */       
/*  604 */       this.Quantizer = getBits(5);
/*  605 */       if (this.HeaderPlus != 7) {
/*  606 */         this.CPM = getBits(1);
/*  607 */         if (this.CPM != 0) {
/*  608 */           getBits(2);
/*      */         }
/*      */       } 
/*      */       
/*  612 */       int PEI = getBits(1);
/*  613 */       if (PEI == 1) {
/*  614 */         return 2;
/*      */       }
/*  616 */       if (srcFormat != this.SourceFormat) {
/*      */         
/*  618 */         rc = ChangeFormat(srcFormat, this.UnrestrictedMV);
/*  619 */         if (rc == 2)
/*      */         {
/*  621 */           return rc;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  626 */       FrameBuffer tmpFrame = this.CurrentFrame;
/*  627 */       this.CurrentFrame = this.PreviousFrame;
/*  628 */       this.PreviousFrame = tmpFrame;
/*      */       
/*  630 */       this.BlockPtr[0] = this.CurrentFrame.Y;
/*  631 */       this.BlockPtr[1] = this.CurrentFrame.Y;
/*  632 */       this.BlockPtr[2] = this.CurrentFrame.Y;
/*  633 */       this.BlockPtr[3] = this.CurrentFrame.Y;
/*      */ 
/*      */ 
/*      */       
/*  637 */       this.BlockPtr[4] = this.CurrentFrame.Cb;
/*  638 */       this.BlockPtr[5] = this.CurrentFrame.Cr;
/*      */ 
/*      */       
/*  641 */       if (this.CodingType == 0) {
/*  642 */         this.GroupNumber = 0;
/*  643 */         GetIntraPictMB();
/*      */       } else {
/*      */         
/*  646 */         if (this.UnrestrictedMV == 1) {
/*  647 */           this.xFrameWidth = this.FrameWidth + 32;
/*  648 */           this.xFrameWidthDiv2 = this.xFrameWidth >> 1;
/*      */           
/*  650 */           CopyExtendedFrame(this.PreviousFrame.Y, this.xPrevFrame.Y, this.FrameWidth, this.FrameHeight, this.xFrameWidth, 16);
/*      */           
/*  652 */           CopyExtendedFrame(this.PreviousFrame.Cb, this.xPrevFrame.Cb, this.FrameWidthDiv2, this.FrameHeight >> 1, this.xFrameWidthDiv2, 8);
/*      */           
/*  654 */           CopyExtendedFrame(this.PreviousFrame.Cr, this.xPrevFrame.Cr, this.FrameWidthDiv2, this.FrameHeight >> 1, this.xFrameWidthDiv2, 8);
/*      */         } 
/*      */         
/*  657 */         this.GroupNumber = 0;
/*  658 */         GetInterPictMB();
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*  664 */     else if (startCode >= 33 && startCode <= 62) {
/*      */ 
/*      */ 
/*      */       
/*  668 */       int tmp = startCode & 0x1F;
/*  669 */       if (tmp != this.GroupNumber)
/*      */       {
/*  671 */         this.GroupNumber = tmp;
/*      */       }
/*      */       
/*  674 */       if (this.CPM != 0)
/*  675 */         skipBits(2); 
/*  676 */       this.GOB_FrameID = getBits(2);
/*  677 */       this.Quantizer = getBits(5);
/*  678 */       if (this.CodingType == 0) {
/*  679 */         GetIntraPictMB();
/*      */       } else {
/*      */         
/*  682 */         GetInterPictMB();
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  687 */       return 2;
/*      */     } 
/*  689 */     if (this.GroupNumber == this.GOBperFrame) {
/*  690 */       this.frameDone = true;
/*  691 */       this.foundPSC = false;
/*  692 */       if (this.DeblockingFilter == 1) {
/*  693 */         EdgeFilter();
/*      */       }
/*  695 */       return 1;
/*      */     } 
/*      */     
/*  698 */     this.frameDone = false;
/*  699 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int ParseHeaderPlus() {
/*  711 */     int srcFormat = 0;
/*  712 */     int UFEP = getBits(3);
/*  713 */     if (UFEP == 1) {
/*  714 */       srcFormat = getBits(3);
/*  715 */       int tmpBits = getBits(1);
/*  716 */       if (tmpBits == 1)
/*  717 */         return 2; 
/*  718 */       this.UnrestrictedMV = getBits(1);
/*  719 */       tmpBits = getBits(4);
/*  720 */       if (tmpBits > 1)
/*  721 */         return 2; 
/*  722 */       this.DeblockingFilter = tmpBits & 0x1;
/*  723 */       tmpBits = getBits(9);
/*  724 */       if (tmpBits != 8) {
/*  725 */         return 2;
/*      */       }
/*      */     } 
/*  728 */     this.CodingType = getBits(3);
/*  729 */     if (this.CodingType > 1) {
/*  730 */       return 2;
/*      */     }
/*  732 */     int i = getBits(6);
/*  733 */     if (i != 1) {
/*  734 */       return 2;
/*      */     }
/*  736 */     this.CPM = getBits(1);
/*  737 */     if (this.CPM != 0) {
/*  738 */       getBits(2);
/*      */     }
/*      */     
/*  741 */     if (srcFormat == 6) {
/*  742 */       i = getBits(4);
/*  743 */       if (i != 2)
/*  744 */         return 2; 
/*  745 */       int PDI = getBits(9);
/*  746 */       i = PDI + 1 << 2;
/*  747 */       if (i != this.FrameWidth) {
/*  748 */         this.SourceFormat = 9;
/*  749 */         this.FrameWidth = i;
/*      */       } 
/*  751 */       i = getBits(1);
/*  752 */       PDI = getBits(9);
/*  753 */       i = PDI << 2;
/*  754 */       if (i != this.FrameHeight) {
/*  755 */         this.SourceFormat = 9;
/*  756 */         this.FrameHeight = i;
/*      */       } 
/*      */     } 
/*  759 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void EdgeFilter() {
/*  766 */     HorizEdgeFilter(this.CurrentFrame.Y, 0);
/*  767 */     VertEdgeFilter(this.CurrentFrame.Y, 0);
/*      */ 
/*      */     
/*  770 */     HorizEdgeFilter(this.CurrentFrame.Cb, 1);
/*  771 */     VertEdgeFilter(this.CurrentFrame.Cb, 1);
/*  772 */     HorizEdgeFilter(this.CurrentFrame.Cr, 1);
/*  773 */     VertEdgeFilter(this.CurrentFrame.Cr, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void HorizEdgeFilter(int[] rec, int divisor) {
/*  784 */     int width = this.FrameWidth >> divisor;
/*  785 */     int height = this.FrameHeight >> divisor;
/*      */ 
/*      */     
/*  788 */     for (int j = 8; j < height; j += 8) {
/*      */       
/*  790 */       int mbr = j >> 4 - divisor;
/*  791 */       int mbr_above = j + (divisor - 1 << 3) >> 4;
/*  792 */       int index = j * width;
/*  793 */       for (int i = 0; i < width; i++, index++) {
/*      */         
/*  795 */         int mbc = i >> 4 - divisor;
/*      */         
/*  797 */         if (CodedMap[(mbr + 1) * (mbc + 1)] > 0 || CodedMap[(mbr_above + 1) * (mbc + 1)] > 0) {
/*      */           
/*  799 */           int delta = rec[index - (width << 1)] - (rec[index - width] << 2) + (rec[index] << 2) - rec[index + width] >> 3;
/*      */ 
/*      */           
/*  802 */           int d1 = ((delta < 0) ? -1 : 1) * Math.max(0, Math.abs(delta) - Math.max(0, Math.abs(delta) - STRENGTH[this.Quantizer - 1] << 1));
/*      */           
/*  804 */           int d2 = Math.min(Math.abs(d1 >> 1), Math.max(-Math.abs(d1 >> 1), rec[index - (width << 1)] - rec[index + width] >> 2));
/*      */ 
/*      */           
/*  807 */           rec[index + width] = rec[index + width] + d2;
/*  808 */           rec[index] = DfiltClip[rec[index] - d1 + 128];
/*      */           
/*  810 */           rec[index - width] = DfiltClip[rec[index - width] + d1 + 128];
/*      */           
/*  812 */           rec[index - (width << 1)] = rec[index - (width << 1)] - d2;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void VertEdgeFilter(int[] rec, int divisor) {
/*  825 */     int width = this.FrameWidth >> divisor;
/*  826 */     int height = this.FrameHeight >> divisor;
/*      */ 
/*      */     
/*  829 */     for (int i = 8; i < width; i += 8) {
/*      */       
/*  831 */       int mbc = i >> 4 - divisor;
/*  832 */       int mbc_left = i + (divisor - 1 << 3) >> 4;
/*  833 */       int index = i;
/*  834 */       for (int j = 0; j < height; j++, index += width) {
/*      */         
/*  836 */         int mbr = j >> 4 - divisor;
/*  837 */         if (CodedMap[(mbr + 1) * (mbc + 1)] > 0 || CodedMap[(mbr + 1) * (mbc_left + 1)] > 0) {
/*      */           
/*  839 */           int delta = rec[index - 2] - (rec[index - 1] << 2) + (rec[index] << 2) - rec[index + 1] >> 3;
/*      */ 
/*      */           
/*  842 */           int d1 = ((delta < 0) ? -1 : 1) * Math.max(0, Math.abs(delta) - Math.max(0, Math.abs(delta) - STRENGTH[this.Quantizer - 1] << 1));
/*      */           
/*  844 */           int d2 = Math.min(Math.abs(d1 >> 1), Math.max(-Math.abs(d1 >> 1), rec[index - 2] - rec[index + 1] >> 2));
/*      */ 
/*      */           
/*  847 */           rec[index + 1] = rec[index + 1] + d2;
/*  848 */           rec[index] = DfiltClip[rec[index] - d1 + 128];
/*      */           
/*  850 */           rec[index - 1] = DfiltClip[rec[index - 1] + d1 + 128];
/*      */           
/*  852 */           rec[index - 2] = rec[index - 2] - d2;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void GetIntraPictMB() {
/*  865 */     int[] clipQ = clipQ_tab;
/*      */     
/*      */     do {
/*  868 */       this.FirstMBinGOB = this.GroupNumber * this.MBperGOB;
/*      */       
/*  870 */       this.CurrentLumiOffset = LumiOffset[this.GroupNumber];
/*  871 */       this.CurrentCromOffset = CromOffset[this.GroupNumber];
/*  872 */       this.MB_address = this.FirstMBinGOB; int MBinNextGOB = this.FirstMBinGOB + this.MBperGOB;
/*  873 */       for (; this.MB_address < MBinNextGOB; this.MB_address++) {
/*      */         int MCBPC; do {
/*  875 */           MCBPC = GetIntraMCBPC_VLC();
/*  876 */         } while (MCBPC == -1);
/*      */         
/*  878 */         int MBtype = MCBPC >> 4;
/*  879 */         int CBPY = GetCBPY_VLC() >> 4;
/*      */         
/*  881 */         if (MBtype == 4) {
/*  882 */           this.Quantizer = clipQ[this.Quantizer + dQuant[nextBits(2)]];
/*  883 */           skipBits(2);
/*      */         } 
/*      */         
/*  886 */         CodedMap[this.MB_address] = 2;
/*      */         
/*  888 */         this.BlockOffset[0] = this.CurrentLumiOffset;
/*  889 */         this.BlockOffset[1] = this.BlockOffset[0] + 8;
/*  890 */         this.BlockOffset[2] = this.BlockOffset[0] + this.FrameWidthx8;
/*  891 */         this.BlockOffset[3] = this.BlockOffset[2] + 8;
/*  892 */         this.BlockOffset[4] = this.CurrentCromOffset;
/*  893 */         this.BlockOffset[5] = this.CurrentCromOffset;
/*      */         
/*  895 */         int CBP = CBPY << 2 | MCBPC & 0x3;
/*  896 */         for (int cnt = 0; cnt < 6; cnt++) {
/*  897 */           int tempDC = getBits(8);
/*  898 */           if (tempDC == 255) tempDC = 128; 
/*  899 */           this.BlockData[cnt][0] = tempDC << 12;
/*  900 */           if ((CBP & 0x20) != 0) {
/*  901 */             GetCoefficients(1, cnt);
/*      */           }
/*  903 */           idct8x8(this.BlockData[cnt], this.BlockPtr[cnt], this.BlockOffset[cnt], this.FrameWidthBlock[cnt], 1);
/*      */ 
/*      */           
/*  906 */           CBP <<= 1;
/*      */         } 
/*      */         
/*  909 */         this.CurrentLumiOffset += 16;
/*  910 */         this.CurrentCromOffset += 8;
/*      */       } 
/*      */ 
/*      */       
/*  914 */       this.GroupNumber++;
/*      */     }
/*  916 */     while (StartCodeFound() == 0 && this.GroupNumber < this.GOBperFrame);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void GetInterPictMB() {
/*  922 */     int MCBPC = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  927 */     int[] clipQ = clipQ_tab;
/*  928 */     this.HeaderInGOB = true;
/*      */     do {
/*  930 */       this.FirstMBinGOB = this.GroupNumber * this.MBperGOB;
/*      */       
/*  932 */       this.CurrentLumiOffset = LumiOffset[this.GroupNumber];
/*  933 */       this.CurrentCromOffset = CromOffset[this.GroupNumber];
/*  934 */       this.xCurrentLumiOffset = xLumiOffset[this.GroupNumber];
/*  935 */       this.xCurrentCromOffset = xCromOffset[this.GroupNumber];
/*      */       
/*  937 */       this.MB_address = this.FirstMBinGOB; int MBinNextGOB = this.FirstMBinGOB + this.MBperGOB;
/*  938 */       for (; this.MB_address < MBinNextGOB; this.MB_address++) {
/*  939 */         int COD; this.MBpositionInGOB = this.MB_address - this.FirstMBinGOB;
/*      */         do {
/*  941 */           COD = getBits(1);
/*  942 */           if (COD != 0) {
/*      */             
/*  944 */             if (this.UnrestrictedMV != 0) {
/*      */               
/*  946 */               Copy16x16Pel(this.xPrevFrame.Y, this.xCurrentLumiOffset, this.CurrentFrame.Y, this.CurrentLumiOffset);
/*      */ 
/*      */               
/*  949 */               Copy8x8Pel(this.xPrevFrame.Cr, this.xCurrentCromOffset, this.CurrentFrame.Cr, this.CurrentCromOffset);
/*      */ 
/*      */               
/*  952 */               Copy8x8Pel(this.xPrevFrame.Cb, this.xCurrentCromOffset, this.CurrentFrame.Cb, this.CurrentCromOffset);
/*      */             }
/*      */             else {
/*      */               
/*  956 */               Copy16x16Pel(this.PreviousFrame.Y, this.CurrentLumiOffset, this.CurrentFrame.Y, this.CurrentLumiOffset);
/*      */ 
/*      */               
/*  959 */               Copy8x8Pel(this.PreviousFrame.Cr, this.CurrentCromOffset, this.CurrentFrame.Cr, this.CurrentCromOffset);
/*      */ 
/*      */               
/*  962 */               Copy8x8Pel(this.PreviousFrame.Cb, this.CurrentCromOffset, this.CurrentFrame.Cb, this.CurrentCromOffset);
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/*  967 */             (this.MotVectCurrGOB[this.MBpositionInGOB]).x = 0;
/*  968 */             (this.MotVectCurrGOB[this.MBpositionInGOB]).y = 0;
/*      */             
/*  970 */             this.CurrentLumiOffset += 16;
/*  971 */             this.CurrentCromOffset += 8;
/*  972 */             this.xCurrentLumiOffset += 16;
/*  973 */             this.xCurrentCromOffset += 8;
/*      */             break;
/*      */           } 
/*  976 */           MCBPC = GetInterMCBPC_VLC();
/*  977 */         } while (MCBPC == -1);
/*  978 */         if (COD == 0) {
/*  979 */           int MBtype = MCBPC >> 4;
/*      */           
/*  981 */           this.BlockOffset[0] = this.CurrentLumiOffset;
/*  982 */           this.BlockOffset[1] = this.BlockOffset[0] + 8;
/*  983 */           this.BlockOffset[2] = this.BlockOffset[0] + this.FrameWidthx8;
/*  984 */           this.BlockOffset[3] = this.BlockOffset[2] + 8;
/*  985 */           this.BlockOffset[4] = this.CurrentCromOffset;
/*  986 */           this.BlockOffset[5] = this.CurrentCromOffset;
/*      */           
/*  988 */           if (MBtype >= 3) {
/*  989 */             CodedMap[this.MB_address] = 2;
/*  990 */             int CBPY = GetCBPY_VLC() >> 4;
/*  991 */             if (MBtype == 4) {
/*  992 */               this.Quantizer = clipQ[this.Quantizer + dQuant[nextBits(2)]];
/*  993 */               skipBits(2);
/*      */             } 
/*      */             
/*  996 */             int CBP = CBPY << 2 | MCBPC & 0x3;
/*  997 */             for (int cnt = 0; cnt < 6; cnt++) {
/*  998 */               int tempDC = getBits(8);
/*  999 */               if (tempDC == 255) tempDC = 128; 
/* 1000 */               this.BlockData[cnt][0] = tempDC << 12;
/* 1001 */               if ((CBP & 0x20) != 0)
/* 1002 */                 GetCoefficients(1, cnt); 
/* 1003 */               idct8x8(this.BlockData[cnt], this.BlockPtr[cnt], this.BlockOffset[cnt], this.FrameWidthBlock[cnt], 1);
/*      */               
/* 1005 */               CBP <<= 1;
/*      */             } 
/* 1007 */             (this.MotVectCurrGOB[this.MBpositionInGOB]).x = 0;
/* 1008 */             (this.MotVectCurrGOB[this.MBpositionInGOB]).y = 0;
/*      */           } else {
/* 1010 */             CodedMap[this.MB_address] = 1;
/* 1011 */             int i = GetCBPY_VLC();
/* 1012 */             if (MBtype == 1) {
/* 1013 */               this.Quantizer = clipQ[this.Quantizer + dQuant[nextBits(2)]];
/* 1014 */               skipBits(2);
/*      */             } 
/*      */             
/* 1017 */             FindMV();
/* 1018 */             BasePredPel();
/* 1019 */             int j = i << 2 | MCBPC & 0x3;
/* 1020 */             for (int cnt = 0; cnt < 6; cnt++) {
/* 1021 */               if ((j & 0x20) != 0) {
/* 1022 */                 GetCoefficients(0, cnt);
/* 1023 */                 idct8x8(this.BlockData[cnt], this.BlockPtr[cnt], this.BlockOffset[cnt], this.FrameWidthBlock[cnt], 0);
/*      */               } 
/*      */ 
/*      */               
/* 1027 */               j <<= 1;
/*      */             } 
/*      */           } 
/*      */           
/* 1031 */           this.CurrentLumiOffset += 16;
/* 1032 */           this.CurrentCromOffset += 8;
/* 1033 */           this.xCurrentLumiOffset += 16;
/* 1034 */           this.xCurrentCromOffset += 8;
/*      */         } else {
/* 1036 */           CodedMap[this.MB_address] = 0;
/*      */         } 
/*      */       } 
/* 1039 */       Point[] MotVectTemp = this.MotVectCurrGOB;
/* 1040 */       this.MotVectCurrGOB = this.MotVectPrevGOB;
/* 1041 */       this.MotVectPrevGOB = MotVectTemp;
/*      */ 
/*      */       
/* 1044 */       this.GroupNumber++;
/* 1045 */       this.HeaderInGOB = false;
/* 1046 */     } while (StartCodeFound() == 0 && this.GroupNumber < this.GOBperFrame);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void GetCoefficients(int startIndex, int cnt) {
/* 1055 */     int j, bits = 0;
/*      */ 
/*      */     
/* 1058 */     int vlcValue = 0, vlcBits = 0;
/* 1059 */     int[] zigzag = zigzag_tab;
/* 1060 */     int[] pre8x8 = pre8x8_tab;
/* 1061 */     int[][] recLevel = recLevel_tab;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1068 */     int[] tempData = this.BlockData[cnt];
/*      */     
/* 1070 */     int[] TCOEFF10 = TCOEFF1_tab0;
/* 1071 */     int[] TCOEFF11 = TCOEFF1_tab1;
/* 1072 */     int[] TCOEFF20 = TCOEFF2_tab0;
/* 1073 */     int[] TCOEFF21 = TCOEFF2_tab1;
/* 1074 */     int[] TCOEFF30 = TCOEFF3_tab0;
/* 1075 */     int[] TCOEFF31 = TCOEFF3_tab1;
/*      */     
/*      */     int i;
/* 1078 */     for (i = startIndex; i < 64; i++) {
/* 1079 */       tempData[i] = 0;
/*      */     }
/*      */     
/* 1082 */     i = startIndex - 1;
/*      */     
/*      */     do {
/*      */       int m;
/* 1086 */       bits = nextBits(13);
/*      */ 
/*      */       
/* 1089 */       if (bits >= 1024) {
/* 1090 */         int offset = (bits >> 6) - 16;
/* 1091 */         vlcValue = TCOEFF10[offset];
/* 1092 */         vlcBits = TCOEFF11[offset];
/* 1093 */       } else if (bits >= 256) {
/* 1094 */         int offset = (bits >> 3) - 32;
/* 1095 */         vlcValue = TCOEFF20[offset];
/* 1096 */         vlcBits = TCOEFF21[offset];
/*      */       } else {
/* 1098 */         int offset = (bits >> 1) - 8;
/* 1099 */         vlcValue = TCOEFF30[offset];
/* 1100 */         vlcBits = TCOEFF31[offset];
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1107 */       skipBits(vlcBits + 1);
/* 1108 */       int value = vlcValue;
/*      */       
/* 1110 */       if (value != 7167) {
/* 1111 */         k = ((bits >> 12 - vlcBits & 0x1) != 0) ? -(value & 0xF) : (value & 0xF);
/*      */         
/* 1113 */         m = value >> 4 & 0x3F;
/* 1114 */         j = value & 0x1000;
/*      */       } else {
/* 1116 */         value = getBits(15);
/* 1117 */         k = value << 24 >> 24;
/* 1118 */         m = value >> 8 & 0x3F;
/* 1119 */         j = value & 0x4000;
/*      */       } 
/*      */ 
/*      */       
/* 1123 */       i += m + 1;
/* 1124 */       i &= 0x3F;
/* 1125 */       int index = zigzag[i];
/*      */       
/* 1127 */       if (k == 0)
/* 1128 */         continue;  int sign = (k < 0) ? 1 : 0;
/* 1129 */       int k = Math.abs(k);
/* 1130 */       if ((this.Quantizer & 0x1) != 0) {
/* 1131 */         tempData[index] = pre8x8[index] * ((sign != 0) ? -recLevel[this.Quantizer][k] : recLevel[this.Quantizer][k]);
/*      */       } else {
/* 1133 */         tempData[index] = pre8x8[index] * ((sign != 0) ? (1 - recLevel[this.Quantizer][k]) : (recLevel[this.Quantizer][k] - 1));
/*      */       }
/*      */     
/* 1136 */     } while (j == 0);
/*      */ 
/*      */     
/* 1139 */     this.LastValue = i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int GetIntraMCBPC_VLC() {
/* 1146 */     int bits = nextBits(9);
/* 1147 */     if (bits == 1) {
/* 1148 */       skipBits(9);
/* 1149 */       return -1;
/*      */     } 
/* 1151 */     int index = bits >> 3;
/* 1152 */     int vlcValue = IntraMCBPC_VLC_tab0[index];
/* 1153 */     int vlcBits = IntraMCBPC_VLC_tab1[index];
/* 1154 */     skipBits(vlcBits);
/* 1155 */     return vlcValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int GetCBPY_VLC() {
/* 1162 */     int index = nextBits(6);
/* 1163 */     int vlcValue = CBPY_VLC_tab0[index];
/* 1164 */     int vlcBits = CBPY_VLC_tab1[index];
/*      */     
/* 1166 */     skipBits(vlcBits);
/*      */     
/* 1168 */     return vlcValue;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final int GetInterMCBPC_VLC() {
/* 1174 */     int index = nextBits(9);
/* 1175 */     int vlcValue = InterMCBPC_VLC_tab0[index];
/* 1176 */     int vlcBits = InterMCBPC_VLC_tab1[index];
/* 1177 */     skipBits(vlcBits);
/*      */     
/* 1179 */     return vlcValue;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final int GetMVD_VLC() {
/* 1185 */     int i, j, bits = nextBits(13);
/* 1186 */     if (bits >= 192) {
/* 1187 */       int index = bits >> 5;
/* 1188 */       i = MVD1_VLC_tab0[index];
/* 1189 */       j = MVD1_VLC_tab1[index];
/*      */     } else {
/* 1191 */       int index = bits;
/* 1192 */       i = MVD2_VLC_tab0[index];
/* 1193 */       j = MVD2_VLC_tab1[index];
/*      */     } 
/*      */     
/* 1196 */     skipBits(j);
/*      */     
/* 1198 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void CopyExtendedFrame(int[] src, int[] dest, int Width, int Height, int xWidth, int edge) {
/* 1211 */     int imageSize = Width * Height;
/* 1212 */     int xImageSize = xWidth * (Height + (edge << 1));
/* 1213 */     int xStripe = xWidth * edge;
/*      */     
/*      */     int destIndex, srcIndex;
/*      */     
/* 1217 */     for (srcIndex = 0, destIndex = xStripe + edge; srcIndex < imageSize; 
/* 1218 */       srcIndex += Width, destIndex += xWidth) {
/* 1219 */       System.arraycopy(src, srcIndex, dest, destIndex, Width);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1224 */     for (destIndex = xStripe, srcIndex = 0; destIndex < xImageSize - xStripe; 
/* 1225 */       destIndex += xWidth, srcIndex += Width) {
/* 1226 */       for (int Index = 0; Index < edge; Index++) {
/* 1227 */         dest[destIndex + Index] = src[srcIndex];
/* 1228 */         dest[destIndex + Width + edge + Index] = src[srcIndex + Width - 1];
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1233 */     for (destIndex = 0; destIndex < xStripe; destIndex += xWidth) {
/* 1234 */       System.arraycopy(dest, xStripe, dest, destIndex, edge);
/* 1235 */       System.arraycopy(dest, xStripe + Width + edge, dest, destIndex + Width + edge, edge);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1240 */     for (destIndex = xImageSize - xStripe; destIndex < xImageSize; 
/* 1241 */       destIndex += xWidth) {
/* 1242 */       System.arraycopy(dest, xImageSize - xStripe - xWidth, dest, destIndex, edge);
/*      */       
/* 1244 */       System.arraycopy(dest, xImageSize - xStripe - edge, dest, destIndex + Width + edge, edge);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1249 */     for (destIndex = edge; destIndex < xStripe + edge; destIndex += xWidth) {
/* 1250 */       System.arraycopy(dest, xStripe + edge, dest, destIndex, Width);
/* 1251 */       System.arraycopy(dest, xImageSize - xStripe - xWidth + edge, dest, destIndex + xImageSize - xStripe, Width);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void BasePredPel() {
/* 1271 */     int arrayOfInt1[], arrayOfInt2[], i, x_vec = (this.MotVectCurrGOB[this.MBpositionInGOB]).x;
/* 1272 */     int y_vec = (this.MotVectCurrGOB[this.MBpositionInGOB]).y;
/*      */     
/* 1274 */     if (x_vec < -32 && this.MBpositionInGOB == 0) {
/* 1275 */       x_vec = -32;
/* 1276 */     } else if (x_vec > 32 && this.MBpositionInGOB == this.GOBperFrame - 1) {
/* 1277 */       x_vec = 32;
/*      */     } 
/* 1279 */     this.HorMV = x_vec >> 1;
/* 1280 */     this.Half_HorMV = x_vec & 0x1;
/*      */     
/* 1282 */     if (y_vec < -32 && this.GroupNumber == 0) {
/* 1283 */       y_vec = -32;
/* 1284 */     } else if (y_vec > 32 && this.GroupNumber == this.GOBperFrame - 1) {
/* 1285 */       y_vec = 32;
/*      */     } 
/* 1287 */     this.VerMV = y_vec >> 1;
/* 1288 */     this.Half_VerMV = y_vec & 0x1;
/*      */ 
/*      */     
/* 1291 */     int dest[] = this.CurrentFrame.Y, destIndex = this.CurrentLumiOffset;
/* 1292 */     if (this.UnrestrictedMV != 0) {
/* 1293 */       arrayOfInt1 = this.xPrevFrame.Y; i = this.xCurrentLumiOffset + this.VerMV * this.xFrameWidth + this.HorMV;
/*      */     }
/*      */     else {
/*      */       
/* 1297 */       arrayOfInt1 = this.PreviousFrame.Y; i = this.CurrentLumiOffset + this.VerMV * this.FrameWidth + this.HorMV;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1302 */     if (this.Half_HorMV != 0 && this.Half_VerMV != 0) {
/* 1303 */       InterpF16x16Pel(arrayOfInt1, i, dest, destIndex);
/* 1304 */     } else if (this.Half_HorMV != 0 || this.Half_VerMV != 0) {
/* 1305 */       Interp16x16Pel(arrayOfInt1, i, dest, destIndex, this.Half_HorMV, this.Half_VerMV);
/*      */     } else {
/* 1307 */       Copy16x16Pel(arrayOfInt1, i, dest, destIndex);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1319 */     this.Half_HorMV |= this.HorMV & 0x1; this.HorMV >>= 1;
/* 1320 */     this.Half_VerMV |= this.VerMV & 0x1; this.VerMV >>= 1;
/*      */     
/* 1322 */     dest = this.CurrentFrame.Cr;
/* 1323 */     destIndex = this.CurrentCromOffset;
/*      */     
/* 1325 */     int[] dest1 = this.CurrentFrame.Cb;
/*      */     
/* 1327 */     if (this.UnrestrictedMV != 0) {
/* 1328 */       arrayOfInt1 = this.xPrevFrame.Cr;
/* 1329 */       i = this.xCurrentCromOffset + this.VerMV * this.xFrameWidthDiv2 + this.HorMV;
/* 1330 */       arrayOfInt2 = this.xPrevFrame.Cb;
/*      */     } else {
/*      */       
/* 1333 */       arrayOfInt1 = this.PreviousFrame.Cr;
/* 1334 */       i = this.CurrentCromOffset + this.VerMV * this.FrameWidthDiv2 + this.HorMV;
/* 1335 */       arrayOfInt2 = this.PreviousFrame.Cb;
/*      */     } 
/*      */     
/* 1338 */     if (this.Half_HorMV != 0 && this.Half_VerMV != 0) {
/* 1339 */       InterpF8x8Pel(arrayOfInt1, i, dest, destIndex);
/* 1340 */       InterpF8x8Pel(arrayOfInt2, i, dest1, destIndex);
/* 1341 */     } else if (this.Half_HorMV != 0 || this.Half_VerMV != 0) {
/* 1342 */       Interp8x8Pel(arrayOfInt1, i, dest, destIndex, this.Half_HorMV, this.Half_VerMV);
/* 1343 */       Interp8x8Pel(arrayOfInt2, i, dest1, destIndex, this.Half_HorMV, this.Half_VerMV);
/*      */     } else {
/* 1345 */       Copy8x8Pel(arrayOfInt1, i, dest, destIndex);
/* 1346 */       Copy8x8Pel(arrayOfInt2, i, dest1, destIndex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void FindMV() {
/* 1368 */     int i, j, k, m, MBpositionInGOB = this.MB_address - this.FirstMBinGOB;
/*      */     
/* 1370 */     int HorMVD = GetMVD_VLC();
/* 1371 */     int VerMVD = GetMVD_VLC();
/*      */     
/* 1373 */     if (MBpositionInGOB == 0) {
/* 1374 */       i = 0;
/* 1375 */       j = 0;
/*      */     } else {
/* 1377 */       i = (this.MotVectCurrGOB[MBpositionInGOB - 1]).x;
/* 1378 */       j = (this.MotVectCurrGOB[MBpositionInGOB - 1]).y;
/*      */     } 
/*      */     
/* 1381 */     if (this.HeaderInGOB) {
/*      */       
/* 1383 */       (this.MotVectCurrGOB[MBpositionInGOB]).x = CALC_MVC(HorMVD, i);
/* 1384 */       (this.MotVectCurrGOB[MBpositionInGOB]).y = CALC_MVC(VerMVD, j);
/*      */       return;
/*      */     } 
/* 1387 */     int MV2x = (this.MotVectPrevGOB[MBpositionInGOB]).x;
/* 1388 */     int MV2y = (this.MotVectPrevGOB[MBpositionInGOB]).y;
/*      */ 
/*      */     
/* 1391 */     if (MBpositionInGOB + 1 == this.MBperGOB) {
/* 1392 */       k = 0;
/* 1393 */       m = 0;
/*      */     } else {
/* 1395 */       k = (this.MotVectPrevGOB[MBpositionInGOB + 1]).x;
/* 1396 */       m = (this.MotVectPrevGOB[MBpositionInGOB + 1]).y;
/*      */     } 
/*      */     
/* 1399 */     int MVx = median(i, MV2x, k);
/* 1400 */     int MVy = median(j, MV2y, m);
/*      */     
/* 1402 */     (this.MotVectCurrGOB[MBpositionInGOB]).x = CALC_MVC(HorMVD, MVx);
/* 1403 */     (this.MotVectCurrGOB[MBpositionInGOB]).y = CALC_MVC(VerMVD, MVy);
/*      */   }
/*      */   
/*      */   private final int median(int mv1, int mv2, int mv3) {
/* 1407 */     return (mv1 >= mv2) ? ((mv2 >= mv3) ? mv2 : ((mv1 >= mv3) ? mv3 : mv1)) : ((mv1 >= mv3) ? mv1 : ((mv2 >= mv3) ? mv3 : mv2));
/*      */   }
/*      */ 
/*      */   
/*      */   private final int CALC_MVC(int MVd, int Pc) {
/* 1412 */     return (this.UnrestrictedMV == 0) ? ((MVd + Pc + 96 & 0x3F) - 32) : ((Pc >= 33) ? (MVd + Pc & 0x3F) : ((Pc <= -32) ? -(-(MVd + Pc) & 0x3F) : (MVd + Pc)));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void Copy16x16Pel(int[] src, int srcIndex, int[] dest, int destIndex) {
/* 1418 */     int frameW = this.FrameWidth, xframeW = this.xFrameWidth;
/* 1419 */     for (int i = 0; i < 16; i++) {
/* 1420 */       System.arraycopy(src, srcIndex, dest, destIndex, 16);
/* 1421 */       destIndex += frameW;
/* 1422 */       srcIndex += xframeW;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final void Interp16x16Pel(int[] src, int srcIndex, int[] dest, int destIndex, int Hor, int Ver) {
/* 1428 */     int offset1 = srcIndex;
/* 1429 */     int offset2 = srcIndex + Ver * this.xFrameWidth + Hor;
/* 1430 */     int frameW = this.FrameWidth, xframeW = this.xFrameWidth;
/*      */     
/* 1432 */     for (int i = 0; i < 16; i++) {
/* 1433 */       for (int j = 0; j < 16; j++) {
/* 1434 */         dest[destIndex + j] = src[offset1 + j] + src[offset2 + j] + 1 >> 1;
/*      */       }
/* 1436 */       destIndex += frameW;
/* 1437 */       offset1 += xframeW;
/* 1438 */       offset2 += xframeW;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final void InterpF16x16Pel(int[] src, int srcIndex, int[] dest, int destIndex) {
/* 1444 */     int offset1 = srcIndex;
/* 1445 */     int offset2 = srcIndex + this.xFrameWidth;
/* 1446 */     int width1 = this.FrameWidth - 15;
/* 1447 */     int width2 = this.xFrameWidth - 16;
/*      */     
/* 1449 */     for (int i = 0; i < 16; i++) {
/* 1450 */       int x10 = src[offset1++];
/* 1451 */       int x11 = src[offset1++];
/* 1452 */       int x12 = src[offset1++];
/* 1453 */       int x13 = src[offset1++];
/* 1454 */       int x14 = src[offset1++];
/* 1455 */       int x15 = src[offset1++];
/* 1456 */       int x16 = src[offset1++];
/* 1457 */       int x17 = src[offset1++];
/* 1458 */       int x18 = src[offset1++];
/* 1459 */       int x19 = src[offset1++];
/* 1460 */       int x110 = src[offset1++];
/* 1461 */       int x111 = src[offset1++];
/* 1462 */       int x112 = src[offset1++];
/* 1463 */       int x113 = src[offset1++];
/* 1464 */       int x114 = src[offset1++];
/* 1465 */       int x115 = src[offset1++];
/* 1466 */       int x116 = src[offset1];
/* 1467 */       int x20 = src[offset2++];
/* 1468 */       int x21 = src[offset2++];
/* 1469 */       int x22 = src[offset2++];
/* 1470 */       int x23 = src[offset2++];
/* 1471 */       int x24 = src[offset2++];
/* 1472 */       int x25 = src[offset2++];
/* 1473 */       int x26 = src[offset2++];
/* 1474 */       int x27 = src[offset2++];
/* 1475 */       int x28 = src[offset2++];
/* 1476 */       int x29 = src[offset2++];
/* 1477 */       int x210 = src[offset2++];
/* 1478 */       int x211 = src[offset2++];
/* 1479 */       int x212 = src[offset2++];
/* 1480 */       int x213 = src[offset2++];
/* 1481 */       int x214 = src[offset2++];
/* 1482 */       int x215 = src[offset2++];
/* 1483 */       int x216 = src[offset2];
/*      */       
/* 1485 */       dest[destIndex++] = x10 + x11 + x20 + x21 + 2 >> 2;
/* 1486 */       dest[destIndex++] = x11 + x12 + x21 + x22 + 2 >> 2;
/* 1487 */       dest[destIndex++] = x12 + x13 + x22 + x23 + 2 >> 2;
/* 1488 */       dest[destIndex++] = x13 + x14 + x23 + x24 + 2 >> 2;
/* 1489 */       dest[destIndex++] = x14 + x15 + x24 + x25 + 2 >> 2;
/* 1490 */       dest[destIndex++] = x15 + x16 + x25 + x26 + 2 >> 2;
/* 1491 */       dest[destIndex++] = x16 + x17 + x26 + x27 + 2 >> 2;
/* 1492 */       dest[destIndex++] = x17 + x18 + x27 + x28 + 2 >> 2;
/* 1493 */       dest[destIndex++] = x18 + x19 + x28 + x29 + 2 >> 2;
/* 1494 */       dest[destIndex++] = x19 + x110 + x29 + x210 + 2 >> 2;
/* 1495 */       dest[destIndex++] = x110 + x111 + x210 + x211 + 2 >> 2;
/* 1496 */       dest[destIndex++] = x111 + x112 + x211 + x212 + 2 >> 2;
/* 1497 */       dest[destIndex++] = x112 + x113 + x212 + x213 + 2 >> 2;
/* 1498 */       dest[destIndex++] = x113 + x114 + x213 + x214 + 2 >> 2;
/* 1499 */       dest[destIndex++] = x114 + x115 + x214 + x215 + 2 >> 2;
/* 1500 */       dest[destIndex] = x115 + x116 + x215 + x216 + 2 >> 2;
/*      */       
/* 1502 */       destIndex += width1;
/* 1503 */       offset1 += width2;
/* 1504 */       offset2 += width2;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final void Copy8x8Pel(int[] src, int srcIndex, int[] dest, int destIndex) {
/* 1510 */     int width1 = this.FrameWidthDiv2;
/* 1511 */     int width2 = this.xFrameWidthDiv2;
/*      */     
/* 1513 */     for (int i = 0; i < 8; i++) {
/* 1514 */       System.arraycopy(src, srcIndex, dest, destIndex, 8);
/* 1515 */       destIndex += width1;
/* 1516 */       srcIndex += width2;
/*      */     } 
/*      */   }
/*      */   
/*      */   private final void Interp8x8Pel(int[] src, int srcIndex, int[] dest, int destIndex, int Hor, int Ver) {
/* 1521 */     int offset1 = srcIndex;
/* 1522 */     int offset2 = srcIndex + Ver * this.xFrameWidthDiv2 + Hor;
/* 1523 */     int width1 = this.FrameWidthDiv2 - 8;
/* 1524 */     int width2 = this.xFrameWidthDiv2 - 8;
/*      */     
/* 1526 */     for (int i = 0; i < 8; i++) {
/* 1527 */       for (int j = 0; j < 8; j++) {
/* 1528 */         dest[destIndex++] = src[offset1++] + src[offset2++] + 1 >> 1;
/*      */       }
/* 1530 */       destIndex += width1;
/* 1531 */       offset1 += width2;
/* 1532 */       offset2 += width2;
/*      */     } 
/*      */   }
/*      */   
/*      */   private final void InterpF8x8Pel(int[] src, int srcIndex, int[] dest, int destIndex) {
/* 1537 */     int offset1 = srcIndex;
/* 1538 */     int offset2 = srcIndex + this.xFrameWidthDiv2;
/* 1539 */     int width1 = this.FrameWidthDiv2 - 7;
/* 1540 */     int width2 = this.xFrameWidthDiv2 - 8;
/*      */     
/* 1542 */     for (int i = 0; i < 8; i++) {
/* 1543 */       int x10 = src[offset1++];
/* 1544 */       int x11 = src[offset1++];
/* 1545 */       int x12 = src[offset1++];
/* 1546 */       int x13 = src[offset1++];
/* 1547 */       int x14 = src[offset1++];
/* 1548 */       int x15 = src[offset1++];
/* 1549 */       int x16 = src[offset1++];
/* 1550 */       int x17 = src[offset1++];
/* 1551 */       int x18 = src[offset1];
/* 1552 */       int x20 = src[offset2++];
/* 1553 */       int x21 = src[offset2++];
/* 1554 */       int x22 = src[offset2++];
/* 1555 */       int x23 = src[offset2++];
/* 1556 */       int x24 = src[offset2++];
/* 1557 */       int x25 = src[offset2++];
/* 1558 */       int x26 = src[offset2++];
/* 1559 */       int x27 = src[offset2++];
/* 1560 */       int x28 = src[offset2];
/*      */       
/* 1562 */       dest[destIndex++] = x10 + x11 + x20 + x21 + 2 >> 2;
/* 1563 */       dest[destIndex++] = x11 + x12 + x21 + x22 + 2 >> 2;
/* 1564 */       dest[destIndex++] = x12 + x13 + x22 + x23 + 2 >> 2;
/* 1565 */       dest[destIndex++] = x13 + x14 + x23 + x24 + 2 >> 2;
/* 1566 */       dest[destIndex++] = x14 + x15 + x24 + x25 + 2 >> 2;
/* 1567 */       dest[destIndex++] = x15 + x16 + x25 + x26 + 2 >> 2;
/* 1568 */       dest[destIndex++] = x16 + x17 + x26 + x27 + 2 >> 2;
/* 1569 */       dest[destIndex] = x17 + x18 + x27 + x28 + 2 >> 2;
/*      */       
/* 1571 */       destIndex += width1;
/* 1572 */       offset1 += width2;
/* 1573 */       offset2 += width2;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final void GetNextStartCode() {
/* 1579 */     while (nextBits(17) != 1) {
/* 1580 */       skipBits(1);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final int StartCodeFound() {
/* 1587 */     int code = nextBits(16);
/* 1588 */     if (code == 0) {
/* 1589 */       int count = 0;
/* 1590 */       while ((code = nextBits(17)) != 1 && count < 7) {
/* 1591 */         skipBits(1);
/* 1592 */         count++;
/*      */       } 
/* 1594 */       if (code == 1) {
/* 1595 */         return 1;
/*      */       }
/* 1597 */       return 0;
/*      */     } 
/*      */     
/* 1600 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void idct8x8(int[] blk, int[] pixel, int pixOffset, int width, int flag) {
/* 1610 */     int i8 = 7, i16 = 15, i24 = 23, i32 = 31, i40 = 39, i48 = 47;
/* 1611 */     int i56 = 55;
/*      */     
/* 1613 */     for (int i = -1; i < 7; ) {
/* 1614 */       int blk_i = blk[++i];
/* 1615 */       int blk_i8 = blk[++i8];
/* 1616 */       int blk_i16 = blk[++i16];
/* 1617 */       int blk_i24 = blk[++i24];
/* 1618 */       int blk_i32 = blk[++i32];
/* 1619 */       int blk_i40 = blk[++i40];
/* 1620 */       int blk_i48 = blk[++i48];
/* 1621 */       int blk_i56 = blk[++i56];
/* 1622 */       if ((blk_i8 | blk_i16 | blk_i24 | blk_i32 | blk_i40 | blk_i48 | blk_i56) == 0) {
/* 1623 */         blk[i56] = blk_i; blk[i48] = blk_i; blk[i40] = blk_i; blk[i32] = blk_i; blk[i24] = blk_i; blk[i16] = blk_i; blk[i8] = blk_i;
/*      */         
/*      */         continue;
/*      */       } 
/* 1627 */       int x8 = blk_i + blk_i32;
/* 1628 */       int x9 = blk_i - blk_i32;
/* 1629 */       int x11 = blk_i16 + blk_i48;
/* 1630 */       int x10 = (362 * (blk_i16 - blk_i48) >> 8) - x11;
/*      */       
/* 1632 */       int x0 = x8 + x11;
/* 1633 */       int x3 = x8 - x11;
/* 1634 */       int x1 = x9 + x10;
/* 1635 */       int x2 = x9 - x10;
/*      */       
/* 1637 */       int y5 = blk_i40 + blk_i24;
/* 1638 */       int y2 = blk_i40 - blk_i24;
/* 1639 */       int y3 = blk_i8 + blk_i56;
/* 1640 */       int y4 = blk_i8 - blk_i56;
/*      */       
/* 1642 */       int x7 = y3 + y5;
/* 1643 */       x9 = 362 * (y3 - y5) >> 8;
/*      */       
/* 1645 */       int y1 = 473 * (y2 + y4) >> 8;
/* 1646 */       x8 = (277 * y4 >> 8) - y1;
/* 1647 */       x10 = (-669 * y2 >> 8) + y1;
/*      */       
/* 1649 */       int x6 = x10 - x7;
/* 1650 */       int x5 = x9 - x6;
/* 1651 */       int x4 = x8 + x5;
/*      */       
/* 1653 */       blk[i] = x0 + x7;
/* 1654 */       blk[i8] = x1 + x6;
/* 1655 */       blk[i16] = x2 + x5;
/* 1656 */       blk[i24] = x3 - x4;
/* 1657 */       blk[i32] = x3 + x4;
/* 1658 */       blk[i40] = x2 - x5;
/* 1659 */       blk[i48] = x1 - x6;
/* 1660 */       blk[i56] = x0 - x7;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1667 */     int offset = 0;
/* 1668 */     int[] clip = clipTable;
/*      */     
/* 1670 */     for (int j = 0; j < 8; j++) {
/* 1671 */       int o0, blk_o0 = blk[o0 = offset++];
/* 1672 */       int o1, blk_o1 = blk[o1 = offset++];
/* 1673 */       int o2, blk_o2 = blk[o2 = offset++];
/* 1674 */       int o3, blk_o3 = blk[o3 = offset++];
/* 1675 */       int o4, blk_o4 = blk[o4 = offset++];
/* 1676 */       int o5, blk_o5 = blk[o5 = offset++];
/* 1677 */       int o6, blk_o6 = blk[o6 = offset++];
/* 1678 */       int o7, blk_o7 = blk[o7 = offset++];
/*      */       
/* 1680 */       if ((blk_o1 | blk_o2 | blk_o3 | blk_o4 | blk_o5 | blk_o6 | blk_o7) == 0) {
/* 1681 */         int temp = blk_o0 + 2048 >> 12;
/* 1682 */         blk[o7] = temp; blk[o6] = temp; blk[o5] = temp; blk[o4] = temp; blk[o3] = temp; blk[o2] = temp; blk[o1] = temp; blk[o0] = temp;
/*      */         
/* 1684 */         if (flag != 0) {
/* 1685 */           temp = clip[0x3FF & temp];
/* 1686 */           pixel[pixOffset++] = temp; pixel[pixOffset++] = temp; pixel[pixOffset++] = temp; pixel[pixOffset++] = temp; pixel[pixOffset++] = temp; pixel[pixOffset++] = temp; pixel[pixOffset++] = temp; pixel[pixOffset++] = temp;
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1691 */           pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + temp];
/* 1692 */           pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + temp];
/* 1693 */           pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + temp];
/* 1694 */           pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + temp];
/* 1695 */           pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + temp];
/* 1696 */           pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + temp];
/* 1697 */           pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + temp];
/* 1698 */           pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + temp];
/*      */         } 
/* 1700 */         pixOffset += width - 8;
/*      */       }
/*      */       else {
/*      */         
/* 1704 */         int i6 = blk_o0 + blk_o4;
/* 1705 */         int i7 = blk_o0 - blk_o4;
/*      */         
/* 1707 */         int i10 = blk_o2 + blk_o6;
/* 1708 */         int i9 = (362 * (blk_o2 - blk_o6) >> 8) - i10;
/*      */         
/* 1710 */         int k = i6 + i10 + 2048;
/* 1711 */         int i1 = i6 - i10 + 2048;
/* 1712 */         int m = i7 + i9 + 2048;
/* 1713 */         int n = i7 - i9 + 2048;
/*      */         
/* 1715 */         int i15 = blk_o5 + blk_o3;
/* 1716 */         int i12 = blk_o5 - blk_o3;
/* 1717 */         int i13 = blk_o1 + blk_o7;
/* 1718 */         int i14 = blk_o1 - blk_o7;
/*      */         
/* 1720 */         int i5 = i13 + i15;
/* 1721 */         i7 = 362 * (i13 - i15) >> 8;
/*      */         
/* 1723 */         int i11 = 473 * (i12 + i14) >> 8;
/* 1724 */         i6 = (277 * i14 >> 8) - i11;
/* 1725 */         i9 = (-669 * i12 >> 8) + i11;
/*      */         
/* 1727 */         int i4 = i9 - i5;
/* 1728 */         int i3 = i7 - i4;
/* 1729 */         int i2 = i6 + i3;
/*      */         
/* 1731 */         if (flag != 0) {
/* 1732 */           blk[o0] = k + i5 >> 12; pixel[pixOffset++] = clip[0x3FF & k + i5 >> 12];
/* 1733 */           blk[o1] = m + i4 >> 12; pixel[pixOffset++] = clip[0x3FF & m + i4 >> 12];
/* 1734 */           blk[o2] = n + i3 >> 12; pixel[pixOffset++] = clip[0x3FF & n + i3 >> 12];
/* 1735 */           blk[o3] = i1 - i2 >> 12; pixel[pixOffset++] = clip[0x3FF & i1 - i2 >> 12];
/* 1736 */           blk[o4] = i1 + i2 >> 12; pixel[pixOffset++] = clip[0x3FF & i1 + i2 >> 12];
/* 1737 */           blk[o5] = n - i3 >> 12; pixel[pixOffset++] = clip[0x3FF & n - i3 >> 12];
/* 1738 */           blk[o6] = m - i4 >> 12; pixel[pixOffset++] = clip[0x3FF & m - i4 >> 12];
/* 1739 */           blk[o7] = k - i5 >> 12; pixel[pixOffset++] = clip[0x3FF & k - i5 >> 12];
/*      */         } else {
/* 1741 */           blk[o0] = k + i5 >> 12; pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + (k + i5 >> 12)];
/* 1742 */           blk[o1] = m + i4 >> 12; pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + (m + i4 >> 12)];
/* 1743 */           blk[o2] = n + i3 >> 12; pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + (n + i3 >> 12)];
/* 1744 */           blk[o3] = i1 - i2 >> 12; pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + (i1 - i2 >> 12)];
/* 1745 */           blk[o4] = i1 + i2 >> 12; pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + (i1 + i2 >> 12)];
/* 1746 */           blk[o5] = n - i3 >> 12; pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + (n - i3 >> 12)];
/* 1747 */           blk[o6] = m - i4 >> 12; pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + (m - i4 >> 12)];
/* 1748 */           blk[o7] = k - i5 >> 12; pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + (k - i5 >> 12)];
/*      */         } 
/* 1750 */         pixOffset += width - 8;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void finalize() {
/* 1758 */     this.CurrentFrame = null;
/* 1759 */     this.PreviousFrame = null;
/* 1760 */     this.xPrevFrame = null;
/* 1761 */     this.MotVectCurrGOB = null;
/* 1762 */     this.MotVectPrevGOB = null;
/* 1763 */     this.MBtypeCurrGOB = null;
/* 1764 */     this.MBtypePrevGOB = null;
/*      */   }
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\video\h263\H263Decoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */