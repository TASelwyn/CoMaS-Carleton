/*     */ package com.ibm.media.codec.video;
/*     */ 
/*     */ import com.sun.media.BasicCodec;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import java.awt.Dimension;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class VideoCodec
/*     */   extends BasicCodec
/*     */ {
/*     */   protected String PLUGIN_NAME;
/*     */   protected VideoFormat[] defaultOutputFormats;
/*     */   protected VideoFormat[] supportedInputFormats;
/*     */   protected VideoFormat[] supportedOutputFormats;
/*     */   protected VideoFormat inputFormat;
/*     */   protected VideoFormat outputFormat;
/*     */   protected final boolean DEBUG = true;
/*     */   
/*     */   public String getName() {
/*  27 */     return this.PLUGIN_NAME;
/*     */   }
/*     */   
/*     */   public Format[] getSupportedInputFormats() {
/*  31 */     return (Format[])this.supportedInputFormats;
/*     */   }
/*     */   
/*     */   public Format setInputFormat(Format format) {
/*  35 */     if (!(format instanceof VideoFormat) || null == BasicPlugIn.matches(format, (Format[])this.supportedInputFormats))
/*     */     {
/*  37 */       return null;
/*     */     }
/*  39 */     this.inputFormat = (VideoFormat)format;
/*  40 */     return format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format setOutputFormat(Format format) {
/*  48 */     if (!(format instanceof VideoFormat) || null == BasicPlugIn.matches(format, getMatchingOutputFormats((Format)this.inputFormat)))
/*     */     {
/*  50 */       return null;
/*     */     }
/*  52 */     this.outputFormat = (VideoFormat)format;
/*     */     
/*  54 */     return format;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Format getInputFormat() {
/*  59 */     return (Format)this.inputFormat;
/*     */   }
/*     */   
/*     */   protected Format getOutputFormat() {
/*  63 */     return (Format)this.outputFormat;
/*     */   }
/*     */   
/*     */   protected Format[] getMatchingOutputFormats(Format in) {
/*  67 */     return new Format[0];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Format[] getSupportedOutputFormats(Format in) {
/*  73 */     if (in == null) {
/*  74 */       return (Format[])this.defaultOutputFormats;
/*     */     }
/*     */ 
/*     */     
/*  78 */     if (!(in instanceof VideoFormat) || BasicPlugIn.matches(in, (Format[])this.supportedInputFormats) == null)
/*     */     {
/*  80 */       return new Format[0];
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  85 */     return getMatchingOutputFormats(in);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkFormat(Format format) {
/*  92 */     Dimension inSize = ((VideoFormat)format).getSize();
/*  93 */     if (!inSize.equals(this.outputFormat.getSize())) {
/*  94 */       videoResized();
/*     */     }
/*  96 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void videoResized() {}
/*     */ 
/*     */   
/*     */   protected void updateOutput(Buffer outputBuffer, Format format, int length, int offset) {
/* 104 */     outputBuffer.setFormat(format);
/* 105 */     outputBuffer.setLength(length);
/* 106 */     outputBuffer.setOffset(offset);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\video\VideoCodec.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */