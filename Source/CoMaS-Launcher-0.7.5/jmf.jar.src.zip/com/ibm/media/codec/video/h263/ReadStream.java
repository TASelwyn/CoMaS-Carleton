/*     */ package com.ibm.media.codec.video.h263;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReadStream
/*     */ {
/*     */   public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997, 1998.";
/*     */   protected int rdptr;
/*     */   private byte[] rdbfr;
/*  30 */   private int incnt = 0;
/*     */   
/*  32 */   long lBufferHistory = 0L;
/*     */   
/*     */   public void initBitstream() {
/*  35 */     this.incnt = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInBuf(byte[] ds_rdbfr, int ds_rdbfr_offset) {
/*  40 */     this.rdbfr = ds_rdbfr;
/*  41 */     this.rdptr = ds_rdbfr_offset;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInBufOffset() {
/*  47 */     return this.rdptr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int nextBits(int n) {
/*  55 */     if (this.incnt < n) {
/*  56 */       fillBuffer();
/*     */     }
/*     */     
/*  59 */     return (int)(this.lBufferHistory << 64 - this.incnt >>> 64 - n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void skipBits(int n) {
/*  66 */     this.incnt -= n;
/*  67 */     if (this.incnt < 0) {
/*  68 */       fillBuffer();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int getBits(int n) {
/*  89 */     int bits = nextBits(n);
/*  90 */     this.incnt -= n;
/*  91 */     return bits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void fillBuffer() {
/* 100 */     this.lBufferHistory <<= 32L;
/* 101 */     int newBits = this.rdbfr[this.rdptr++] << 24 | (this.rdbfr[this.rdptr++] & 0xFF) << 16 | (this.rdbfr[this.rdptr++] & 0xFF) << 8 | this.rdbfr[this.rdptr++] & 0xFF;
/*     */     
/* 103 */     this.lBufferHistory |= newBits & 0xFFFFFFFFL;
/*     */     
/* 105 */     this.incnt += 32;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\video\h263\ReadStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */