package com.ibm.media.protocol;

public interface SourceStreamSlave {
  void connect();
  
  void disconnect();
}
