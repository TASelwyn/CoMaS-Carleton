package com.ibm.media.protocol;

import java.io.IOException;
import javax.media.Time;
import javax.media.protocol.DataSource;
import javax.media.protocol.PushBufferDataSource;
import javax.media.protocol.PushBufferStream;
import javax.media.protocol.SourceCloneable;
import javax.media.protocol.SourceStream;

public class CloneablePushBufferDataSource extends PushBufferDataSource implements SourceCloneable {
  private SuperCloneableDataSource superClass;
  
  public CloneablePushBufferDataSource(PushBufferDataSource source) {
    this.superClass = new SuperCloneableDataSource((DataSource)source);
  }
  
  public PushBufferStream[] getStreams() {
    if (this.superClass.streams == null) {
      this.superClass.streams = (SourceStream[])new PushBufferStream[this.superClass.streamsAdapters.length];
      for (int i = 0; i < this.superClass.streamsAdapters.length; i++)
        this.superClass.streams[i] = this.superClass.streamsAdapters[i].getAdapter(); 
    } 
    return (PushBufferStream[])this.superClass.streams;
  }
  
  public DataSource createClone() {
    return this.superClass.createClone();
  }
  
  public String getContentType() {
    return this.superClass.getContentType();
  }
  
  public void connect() throws IOException {
    this.superClass.connect();
  }
  
  public void disconnect() {
    this.superClass.disconnect();
  }
  
  public void start() throws IOException {
    this.superClass.start();
  }
  
  public void stop() throws IOException {
    this.superClass.stop();
  }
  
  public Object[] getControls() {
    return this.superClass.getControls();
  }
  
  public Object getControl(String controlType) {
    return this.superClass.getControl(controlType);
  }
  
  public Time getDuration() {
    return this.superClass.getDuration();
  }
}
