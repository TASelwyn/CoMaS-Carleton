/*     */ package com.ibm.media.protocol;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.media.Time;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PullBufferDataSource;
/*     */ import javax.media.protocol.PullBufferStream;
/*     */ import javax.media.protocol.SourceCloneable;
/*     */ import javax.media.protocol.SourceStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CloneablePullBufferDataSource
/*     */   extends PullBufferDataSource
/*     */   implements SourceCloneable
/*     */ {
/*     */   private SuperCloneableDataSource superClass;
/*     */   
/*     */   public CloneablePullBufferDataSource(PullBufferDataSource source) {
/*  33 */     this.superClass = new SuperCloneableDataSource((DataSource)source);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PullBufferStream[] getStreams() {
/*  47 */     if (this.superClass.streams == null) {
/*  48 */       this.superClass.streams = (SourceStream[])new PullBufferStream[this.superClass.streamsAdapters.length];
/*  49 */       for (int i = 0; i < this.superClass.streamsAdapters.length; i++) {
/*  50 */         this.superClass.streams[i] = this.superClass.streamsAdapters[i].getAdapter();
/*     */       }
/*     */     } 
/*  53 */     return (PullBufferStream[])this.superClass.streams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataSource createClone() {
/*  67 */     return this.superClass.createClone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/*  81 */     return this.superClass.getContentType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect() throws IOException {
/*  96 */     this.superClass.connect();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disconnect() {
/* 111 */     this.superClass.disconnect();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() throws IOException {
/* 124 */     this.superClass.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() throws IOException {
/* 134 */     this.superClass.stop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getControls() {
/* 149 */     return this.superClass.getControls();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getControl(String controlType) {
/* 166 */     return this.superClass.getControl(controlType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Time getDuration() {
/* 181 */     return this.superClass.getDuration();
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\protocol\CloneablePullBufferDataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */