package com.ibm.media.protocol;

import java.util.Vector;
import javax.media.CaptureDeviceInfo;
import javax.media.control.FormatControl;
import javax.media.protocol.CaptureDevice;
import javax.media.protocol.PushBufferDataSource;

public class MergingCDPushBDS extends MergingPushBufferDataSource implements CaptureDevice {
  FormatControl[] fcontrols = null;
  
  public MergingCDPushBDS(PushBufferDataSource[] sources) {
    super(sources);
    consolidateFormatControls(sources);
  }
  
  public FormatControl[] getFormatControls() {
    return this.fcontrols;
  }
  
  public CaptureDeviceInfo getCaptureDeviceInfo() {
    return null;
  }
  
  protected void consolidateFormatControls(PushBufferDataSource[] sources) {
    Vector fcs = new Vector(1);
    for (int i = 0; i < sources.length; i++) {
      if (sources[i] instanceof CaptureDevice) {
        CaptureDevice cd = (CaptureDevice)sources[i];
        FormatControl[] cdfcs = cd.getFormatControls();
        for (int j = 0; j < cdfcs.length; j++)
          fcs.addElement(cdfcs[j]); 
      } 
    } 
    if (fcs.size() > 0) {
      this.fcontrols = new FormatControl[fcs.size()];
      for (int f = 0; f < fcs.size(); f++)
        this.fcontrols[f] = fcs.elementAt(f); 
    } else {
      this.fcontrols = new FormatControl[0];
    } 
  }
}
