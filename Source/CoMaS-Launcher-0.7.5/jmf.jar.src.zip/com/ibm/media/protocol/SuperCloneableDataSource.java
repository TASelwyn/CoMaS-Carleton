/*     */ package com.ibm.media.protocol;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ import javax.media.Time;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PullBufferDataSource;
/*     */ import javax.media.protocol.PullBufferStream;
/*     */ import javax.media.protocol.PullDataSource;
/*     */ import javax.media.protocol.PullSourceStream;
/*     */ import javax.media.protocol.PushBufferDataSource;
/*     */ import javax.media.protocol.PushBufferStream;
/*     */ import javax.media.protocol.PushDataSource;
/*     */ import javax.media.protocol.PushSourceStream;
/*     */ import javax.media.protocol.SourceStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SuperCloneableDataSource
/*     */   extends DataSource
/*     */ {
/*     */   protected DataSource input;
/*     */   public CloneableSourceStreamAdapter[] streamsAdapters;
/*     */   public SourceStream[] streams;
/*     */   private Vector clones;
/*     */   
/*     */   SuperCloneableDataSource(DataSource input) {
/*     */     PushBufferStream[] arrayOfPushBufferStream;
/*  58 */     this.streams = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  63 */     this.clones = new Vector();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  70 */     this.input = input;
/*  71 */     SourceStream[] originalStreams = null;
/*     */     
/*  73 */     if (input instanceof PullDataSource)
/*  74 */       PullSourceStream[] arrayOfPullSourceStream = ((PullDataSource)input).getStreams(); 
/*  75 */     if (input instanceof PushDataSource)
/*  76 */       PushSourceStream[] arrayOfPushSourceStream = ((PushDataSource)input).getStreams(); 
/*  77 */     if (input instanceof PullBufferDataSource)
/*  78 */       PullBufferStream[] arrayOfPullBufferStream = ((PullBufferDataSource)input).getStreams(); 
/*  79 */     if (input instanceof PushBufferDataSource)
/*  80 */       arrayOfPushBufferStream = ((PushBufferDataSource)input).getStreams(); 
/*  81 */     this.streamsAdapters = new CloneableSourceStreamAdapter[arrayOfPushBufferStream.length];
/*     */     
/*  83 */     for (int i = 0; i < arrayOfPushBufferStream.length; i++) {
/*  84 */       this.streamsAdapters[i] = new CloneableSourceStreamAdapter((SourceStream)arrayOfPushBufferStream[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DataSource createClone() {
/*     */     PushBufferDataSourceSlave pushBufferDataSourceSlave;
/*  99 */     if (this.input instanceof PullDataSource || this.input instanceof PushDataSource) {
/*     */       
/* 101 */       PushDataSourceSlave pushDataSourceSlave = new PushDataSourceSlave(this);
/*     */     } else {
/* 103 */       pushBufferDataSourceSlave = new PushBufferDataSourceSlave(this);
/*     */     } 
/* 105 */     this.clones.addElement(pushBufferDataSourceSlave);
/*     */     
/*     */     try {
/* 108 */       pushBufferDataSourceSlave.connect();
/*     */     } catch (IOException e) {
/* 110 */       return null;
/*     */     } 
/*     */     
/* 113 */     return (DataSource)pushBufferDataSourceSlave;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/* 127 */     return this.input.getContentType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect() throws IOException {
/* 142 */     this.input.connect();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disconnect() {
/* 157 */     this.input.disconnect();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() throws IOException {
/* 170 */     this.input.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() throws IOException {
/* 180 */     this.input.stop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getControls() {
/* 195 */     return this.input.getControls();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getControl(String controlType) {
/* 212 */     return this.input.getControl(controlType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Time getDuration() {
/* 227 */     return this.input.getDuration();
/*     */   }
/*     */   
/*     */   class PushDataSourceSlave extends PushDataSource {
/*     */     PushSourceStream[] streams;
/*     */     
/*     */     public PushDataSourceSlave(SuperCloneableDataSource this$0) {
/* 234 */       this.this$0 = this$0; this.streams = null;
/* 235 */       this.streams = new PushSourceStream[this$0.streamsAdapters.length];
/* 236 */       for (int i = 0; i < this.streams.length; i++)
/* 237 */         this.streams[i] = (PushSourceStream)this$0.streamsAdapters[i].createSlave(); 
/*     */     }
/*     */     private final SuperCloneableDataSource this$0;
/*     */     
/*     */     public String getContentType() {
/* 242 */       return this.this$0.input.getContentType();
/*     */     }
/*     */     
/*     */     public void connect() throws IOException {
/* 246 */       for (int i = 0; i < this.streams.length; i++) {
/* 247 */         ((SourceStreamSlave)this.streams[i]).connect();
/*     */       }
/*     */     }
/*     */     
/*     */     public void disconnect() {
/* 252 */       for (int i = 0; i < this.streams.length; i++) {
/* 253 */         ((SourceStreamSlave)this.streams[i]).disconnect();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void start() throws IOException {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void stop() throws IOException {}
/*     */ 
/*     */ 
/*     */     
/*     */     public PushSourceStream[] getStreams() {
/* 268 */       return this.streams;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object[] getControls() {
/* 274 */       return this.this$0.input.getControls();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getControl(String controlType) {
/* 280 */       return this.this$0.input.getControl(controlType);
/*     */     }
/*     */ 
/*     */     
/*     */     public Time getDuration() {
/* 285 */       return this.this$0.input.getDuration();
/*     */     } }
/*     */   
/*     */   class PushBufferDataSourceSlave extends PushBufferDataSource {
/*     */     PushBufferStream[] streams;
/*     */     private final SuperCloneableDataSource this$0;
/*     */     
/*     */     public PushBufferDataSourceSlave(SuperCloneableDataSource this$0) {
/* 293 */       this.this$0 = this$0; this.streams = null;
/* 294 */       this.streams = new PushBufferStream[this$0.streamsAdapters.length];
/* 295 */       for (int i = 0; i < this.streams.length; i++) {
/* 296 */         this.streams[i] = (PushBufferStream)this$0.streamsAdapters[i].createSlave();
/*     */       }
/*     */     }
/*     */     
/*     */     public String getContentType() {
/* 301 */       return this.this$0.input.getContentType();
/*     */     }
/*     */     
/*     */     public void connect() throws IOException {
/* 305 */       for (int i = 0; i < this.streams.length; i++) {
/* 306 */         ((SourceStreamSlave)this.streams[i]).connect();
/*     */       }
/*     */     }
/*     */     
/*     */     public void disconnect() {
/* 311 */       for (int i = 0; i < this.streams.length; i++) {
/* 312 */         ((SourceStreamSlave)this.streams[i]).disconnect();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void start() throws IOException {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void stop() throws IOException {}
/*     */ 
/*     */ 
/*     */     
/*     */     public PushBufferStream[] getStreams() {
/* 327 */       return this.streams;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object[] getControls() {
/* 333 */       return this.this$0.input.getControls();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getControl(String controlType) {
/* 339 */       return this.this$0.input.getControl(controlType);
/*     */     }
/*     */ 
/*     */     
/*     */     public Time getDuration() {
/* 344 */       return this.this$0.input.getDuration();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\protocol\SuperCloneableDataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */