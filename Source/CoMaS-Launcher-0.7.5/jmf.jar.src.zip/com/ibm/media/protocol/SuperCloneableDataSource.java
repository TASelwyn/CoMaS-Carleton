package com.ibm.media.protocol;

import java.io.IOException;
import java.util.Vector;
import javax.media.Time;
import javax.media.protocol.DataSource;
import javax.media.protocol.PullBufferDataSource;
import javax.media.protocol.PullBufferStream;
import javax.media.protocol.PullDataSource;
import javax.media.protocol.PullSourceStream;
import javax.media.protocol.PushBufferDataSource;
import javax.media.protocol.PushBufferStream;
import javax.media.protocol.PushDataSource;
import javax.media.protocol.PushSourceStream;
import javax.media.protocol.SourceStream;

class SuperCloneableDataSource extends DataSource {
  protected DataSource input;
  
  public CloneableSourceStreamAdapter[] streamsAdapters;
  
  public SourceStream[] streams;
  
  private Vector clones;
  
  SuperCloneableDataSource(DataSource input) {
    PushBufferStream[] arrayOfPushBufferStream;
    this.streams = null;
    this.clones = new Vector();
    this.input = input;
    SourceStream[] originalStreams = null;
    if (input instanceof PullDataSource)
      PullSourceStream[] arrayOfPullSourceStream = ((PullDataSource)input).getStreams(); 
    if (input instanceof PushDataSource)
      PushSourceStream[] arrayOfPushSourceStream = ((PushDataSource)input).getStreams(); 
    if (input instanceof PullBufferDataSource)
      PullBufferStream[] arrayOfPullBufferStream = ((PullBufferDataSource)input).getStreams(); 
    if (input instanceof PushBufferDataSource)
      arrayOfPushBufferStream = ((PushBufferDataSource)input).getStreams(); 
    this.streamsAdapters = new CloneableSourceStreamAdapter[arrayOfPushBufferStream.length];
    for (int i = 0; i < arrayOfPushBufferStream.length; i++)
      this.streamsAdapters[i] = new CloneableSourceStreamAdapter((SourceStream)arrayOfPushBufferStream[i]); 
  }
  
  DataSource createClone() {
    PushBufferDataSourceSlave pushBufferDataSourceSlave;
    if (this.input instanceof PullDataSource || this.input instanceof PushDataSource) {
      PushDataSourceSlave pushDataSourceSlave = new PushDataSourceSlave(this);
    } else {
      pushBufferDataSourceSlave = new PushBufferDataSourceSlave(this);
    } 
    this.clones.addElement(pushBufferDataSourceSlave);
    try {
      pushBufferDataSourceSlave.connect();
    } catch (IOException e) {
      return null;
    } 
    return (DataSource)pushBufferDataSourceSlave;
  }
  
  public String getContentType() {
    return this.input.getContentType();
  }
  
  public void connect() throws IOException {
    this.input.connect();
  }
  
  public void disconnect() {
    this.input.disconnect();
  }
  
  public void start() throws IOException {
    this.input.start();
  }
  
  public void stop() throws IOException {
    this.input.stop();
  }
  
  public Object[] getControls() {
    return this.input.getControls();
  }
  
  public Object getControl(String controlType) {
    return this.input.getControl(controlType);
  }
  
  public Time getDuration() {
    return this.input.getDuration();
  }
  
  class PushDataSourceSlave extends PushDataSource {
    PushSourceStream[] streams;
    
    private final SuperCloneableDataSource this$0;
    
    public PushDataSourceSlave(SuperCloneableDataSource this$0) {
      this.this$0 = this$0;
      this.streams = null;
      this.streams = new PushSourceStream[this$0.streamsAdapters.length];
      for (int i = 0; i < this.streams.length; i++)
        this.streams[i] = (PushSourceStream)this$0.streamsAdapters[i].createSlave(); 
    }
    
    public String getContentType() {
      return this.this$0.input.getContentType();
    }
    
    public void connect() throws IOException {
      for (int i = 0; i < this.streams.length; i++)
        ((SourceStreamSlave)this.streams[i]).connect(); 
    }
    
    public void disconnect() {
      for (int i = 0; i < this.streams.length; i++)
        ((SourceStreamSlave)this.streams[i]).disconnect(); 
    }
    
    public void start() throws IOException {}
    
    public void stop() throws IOException {}
    
    public PushSourceStream[] getStreams() {
      return this.streams;
    }
    
    public Object[] getControls() {
      return this.this$0.input.getControls();
    }
    
    public Object getControl(String controlType) {
      return this.this$0.input.getControl(controlType);
    }
    
    public Time getDuration() {
      return this.this$0.input.getDuration();
    }
  }
  
  class PushBufferDataSourceSlave extends PushBufferDataSource {
    PushBufferStream[] streams;
    
    private final SuperCloneableDataSource this$0;
    
    public PushBufferDataSourceSlave(SuperCloneableDataSource this$0) {
      this.this$0 = this$0;
      this.streams = null;
      this.streams = new PushBufferStream[this$0.streamsAdapters.length];
      for (int i = 0; i < this.streams.length; i++)
        this.streams[i] = (PushBufferStream)this$0.streamsAdapters[i].createSlave(); 
    }
    
    public String getContentType() {
      return this.this$0.input.getContentType();
    }
    
    public void connect() throws IOException {
      for (int i = 0; i < this.streams.length; i++)
        ((SourceStreamSlave)this.streams[i]).connect(); 
    }
    
    public void disconnect() {
      for (int i = 0; i < this.streams.length; i++)
        ((SourceStreamSlave)this.streams[i]).disconnect(); 
    }
    
    public void start() throws IOException {}
    
    public void stop() throws IOException {}
    
    public PushBufferStream[] getStreams() {
      return this.streams;
    }
    
    public Object[] getControls() {
      return this.this$0.input.getControls();
    }
    
    public Object getControl(String controlType) {
      return this.this$0.input.getControl(controlType);
    }
    
    public Time getDuration() {
      return this.this$0.input.getDuration();
    }
  }
}
