/*     */ package com.sun.media.datasink.file;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import com.sun.media.Syncable;
/*     */ import com.sun.media.datasink.BasicDataSink;
/*     */ import com.sun.media.datasink.RandomAccess;
/*     */ import com.sun.media.util.jdk12;
/*     */ import com.sun.media.util.jdk12DeleteFileAction;
/*     */ import java.io.File;
/*     */ import java.io.FileDescriptor;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.media.Control;
/*     */ import javax.media.IncompatibleSourceException;
/*     */ import javax.media.MediaLocator;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PullDataSource;
/*     */ import javax.media.protocol.PushDataSource;
/*     */ import javax.media.protocol.PushSourceStream;
/*     */ import javax.media.protocol.Seekable;
/*     */ import javax.media.protocol.SourceStream;
/*     */ import javax.media.protocol.SourceTransferHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Handler
/*     */   extends BasicDataSink
/*     */   implements SourceTransferHandler, Seekable, Runnable, RandomAccess, Syncable
/*     */ {
/*     */   private static final boolean DEBUG = false;
/*     */   protected static final int NOT_INITIALIZED = 0;
/*     */   protected static final int OPENED = 1;
/*     */   protected static final int STARTED = 2;
/*     */   protected static final int CLOSED = 3;
/*  59 */   protected int state = 0;
/*     */   
/*     */   protected DataSource source;
/*     */   
/*     */   protected SourceStream[] streams;
/*     */   protected SourceStream stream;
/*     */   protected boolean push;
/*     */   protected boolean errorEncountered = false;
/*  67 */   protected String errorReason = null;
/*     */   
/*     */   protected Control[] controls;
/*     */   
/*     */   protected File file;
/*  72 */   protected File tempFile = null;
/*  73 */   protected RandomAccessFile raFile = null;
/*  74 */   protected RandomAccessFile qtStrRaFile = null;
/*     */   protected boolean fileClosed = false;
/*  76 */   protected FileDescriptor fileDescriptor = null;
/*  77 */   protected MediaLocator locator = null;
/*  78 */   protected String contentType = null;
/*  79 */   protected int fileSize = 0;
/*  80 */   protected int filePointer = 0;
/*  81 */   protected int bytesWritten = 0;
/*     */   
/*     */   protected static final int BUFFER_LEN = 131072;
/*     */   protected boolean syncEnabled = false;
/*  85 */   protected byte[] buffer1 = new byte[131072];
/*  86 */   protected byte[] buffer2 = new byte[131072];
/*     */   protected boolean buffer1Pending = false;
/*  88 */   protected long buffer1PendingLocation = -1L;
/*     */   protected int buffer1Length;
/*     */   protected boolean buffer2Pending = false;
/*  91 */   protected long buffer2PendingLocation = -1L;
/*     */   protected int buffer2Length;
/*  93 */   protected long nextLocation = 0L;
/*  94 */   protected Thread writeThread = null;
/*  95 */   private Integer bufferLock = new Integer(0);
/*     */   
/*     */   private boolean receivedEOS = false;
/*  98 */   private static JMFSecurity jmfSecurity = null;
/*     */   private static boolean securityPrivelege = false;
/* 100 */   private Method[] m = new Method[1];
/* 101 */   private Class[] cl = new Class[1];
/* 102 */   private Object[][] args = new Object[1][0];
/* 103 */   public int WRITE_CHUNK_SIZE = 16384;
/*     */   private boolean streamingEnabled = false;
/*     */   private boolean errorCreatingStreamingFile = false;
/*     */   
/*     */   static {
/*     */     try {
/* 109 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/* 110 */       securityPrivelege = true;
/* 111 */     } catch (SecurityException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSource(DataSource ds) throws IncompatibleSourceException {
/* 118 */     if (!(ds instanceof PushDataSource) && !(ds instanceof PullDataSource))
/*     */     {
/*     */       
/* 121 */       throw new IncompatibleSourceException("Incompatible datasource");
/*     */     }
/* 123 */     this.source = ds;
/*     */     
/* 125 */     if (this.source instanceof PushDataSource) {
/* 126 */       this.push = true;
/*     */       try {
/* 128 */         ((PushDataSource)this.source).connect();
/* 129 */       } catch (IOException ioe) {}
/*     */       
/* 131 */       this.streams = (SourceStream[])((PushDataSource)this.source).getStreams();
/*     */     } else {
/* 133 */       this.push = false;
/*     */       try {
/* 135 */         ((PullDataSource)this.source).connect();
/* 136 */       } catch (IOException ioe) {}
/*     */       
/* 138 */       this.streams = (SourceStream[])((PullDataSource)this.source).getStreams();
/*     */     } 
/*     */     
/* 141 */     if (this.streams == null || this.streams.length != 1)
/* 142 */       throw new IncompatibleSourceException("DataSource should have 1 stream"); 
/* 143 */     this.stream = this.streams[0];
/*     */     
/* 145 */     this.contentType = this.source.getContentType();
/* 146 */     if (this.push) {
/* 147 */       ((PushSourceStream)this.stream).setTransferHandler(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOutputLocator(MediaLocator output) {
/* 158 */     this.locator = output;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean b) {
/* 162 */     this.streamingEnabled = b;
/*     */   }
/*     */   
/*     */   public void setSyncEnabled() {
/* 166 */     this.syncEnabled = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean write(long inOffset, int numBytes) {
/*     */     try {
/* 174 */       if (inOffset >= 0L && numBytes > 0) {
/* 175 */         int remaining = numBytes;
/*     */         
/* 177 */         this.raFile.seek(inOffset);
/*     */         
/* 179 */         while (remaining > 0) {
/* 180 */           int bytesToRead = (remaining > 131072) ? 131072 : remaining;
/* 181 */           this.raFile.read(this.buffer1, 0, bytesToRead);
/* 182 */           this.qtStrRaFile.write(this.buffer1, 0, bytesToRead);
/* 183 */           remaining -= bytesToRead;
/*     */         } 
/* 185 */       } else if (inOffset < 0L && numBytes > 0) {
/* 186 */         this.qtStrRaFile.seek(0L);
/* 187 */         this.qtStrRaFile.seek((numBytes - 1));
/* 188 */         this.qtStrRaFile.writeByte(0);
/* 189 */         this.qtStrRaFile.seek(0L);
/*     */       } else {
/* 191 */         sendEndofStreamEvent();
/*     */       } 
/*     */     } catch (Exception e) {
/* 194 */       this.errorCreatingStreamingFile = true;
/* 195 */       System.err.println("Exception when creating streamable version of media file: " + e.getMessage());
/*     */       
/* 197 */       return false;
/*     */     } 
/* 199 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void open() throws IOException, SecurityException {
/*     */     try {
/* 205 */       if (this.state == 0)
/*     */       {
/* 207 */         if (this.locator != null) {
/* 208 */           String pathName = this.locator.getRemainder();
/*     */           
/* 210 */           while (pathName.charAt(0) == '/' && (pathName.charAt(1) == '/' || pathName.charAt(2) == ':'))
/*     */           {
/* 212 */             pathName = pathName.substring(1);
/*     */           }
/* 214 */           String fileSeparator = System.getProperty("file.separator");
/* 215 */           if (fileSeparator.equals("\\")) {
/* 216 */             pathName = pathName.replace('/', '\\');
/*     */           }
/*     */           
/* 219 */           JMFSecurityManager.checkFileSave();
/* 220 */           if (securityPrivelege && jmfSecurity != null) {
/* 221 */             String permission = null;
/*     */             
/*     */             try {
/* 224 */               if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 225 */                 permission = "read file";
/* 226 */                 jmfSecurity.requestPermission(this.m, this.cl, this.args, 2);
/* 227 */                 this.m[0].invoke(this.cl[0], this.args[0]);
/*     */                 
/* 229 */                 permission = "write file";
/* 230 */                 jmfSecurity.requestPermission(this.m, this.cl, this.args, 4);
/* 231 */                 this.m[0].invoke(this.cl[0], this.args[0]);
/* 232 */               } else if (jmfSecurity.getName().startsWith("internet")) {
/* 233 */                 PolicyEngine.checkPermission(PermissionID.FILEIO);
/* 234 */                 PolicyEngine.assertPermission(PermissionID.FILEIO);
/*     */               } 
/*     */             } catch (Exception e) {
/* 237 */               securityPrivelege = false;
/* 238 */               if (this.push)
/* 239 */                 ((PushSourceStream)this.stream).setTransferHandler(null); 
/* 240 */               throw new SecurityException(e.getMessage());
/*     */             } catch (Error e) {
/* 242 */               securityPrivelege = false;
/* 243 */               if (this.push)
/* 244 */                 ((PushSourceStream)this.stream).setTransferHandler(null); 
/* 245 */               throw new SecurityException(e.getMessage());
/*     */             } 
/*     */           } 
/* 248 */           if (!securityPrivelege) {
/* 249 */             if (this.push)
/* 250 */               ((PushSourceStream)this.stream).setTransferHandler(null); 
/* 251 */             throw new IOException("Datasink: Unable to get security privileges for file writing");
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 262 */           this.file = new File(pathName);
/* 263 */           if (this.file.exists() && 
/* 264 */             !deleteFile(this.file)) {
/* 265 */             System.err.println("datasink open: Existing file " + pathName + " cannot be deleted. Check if " + "some other process is using " + " this file");
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 270 */             if (this.push)
/* 271 */               ((PushSourceStream)this.stream).setTransferHandler(null); 
/* 272 */             throw new IOException("Existing file " + pathName + " cannot be deleted");
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 277 */           String parent = this.file.getParent();
/* 278 */           if (parent != null) {
/* 279 */             (new File(parent)).mkdirs();
/*     */           }
/*     */           try {
/* 282 */             if (!this.streamingEnabled) {
/* 283 */               this.raFile = new RandomAccessFile(this.file, "rw");
/* 284 */               this.fileDescriptor = this.raFile.getFD();
/*     */             } else {
/*     */               String str;
/*     */               int index;
/* 288 */               if ((index = pathName.lastIndexOf(".")) > 0) {
/*     */                 
/* 290 */                 str = pathName.substring(0, index) + ".nonstreamable" + pathName.substring(index, pathName.length());
/*     */ 
/*     */ 
/*     */               
/*     */               }
/*     */               else {
/*     */ 
/*     */ 
/*     */                 
/* 299 */                 str = this.file + ".nonstreamable.mov";
/*     */               } 
/* 301 */               this.tempFile = new File(str);
/*     */               
/* 303 */               this.raFile = new RandomAccessFile(this.tempFile, "rw");
/* 304 */               this.fileDescriptor = this.raFile.getFD();
/* 305 */               this.qtStrRaFile = new RandomAccessFile(this.file, "rw");
/*     */             }
/*     */           
/*     */           } catch (IOException e) {
/*     */             
/* 310 */             System.err.println("datasink open: IOException when creating RandomAccessFile " + pathName + " : " + e);
/*     */             
/* 312 */             if (this.push)
/* 313 */               ((PushSourceStream)this.stream).setTransferHandler(null); 
/* 314 */             throw e;
/*     */           } 
/*     */           
/* 317 */           setState(1);
/*     */         } 
/*     */       }
/*     */     } finally {
/* 321 */       if (this.state == 0 && this.stream != null) {
/* 322 */         ((PushSourceStream)this.stream).setTransferHandler(null);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public MediaLocator getOutputLocator() {
/* 329 */     return this.locator;
/*     */   }
/*     */   
/*     */   public void start() throws IOException {
/* 333 */     if (this.state == 1) {
/* 334 */       if (this.source != null)
/* 335 */         this.source.start(); 
/* 336 */       if (this.writeThread == null) {
/* 337 */         this.writeThread = new Thread(this);
/* 338 */         this.writeThread.start();
/*     */       } 
/* 340 */       setState(2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() throws IOException {
/* 350 */     if (this.state == 2) {
/* 351 */       if (this.source != null)
/* 352 */         this.source.stop(); 
/* 353 */       setState(1);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void setState(int state) {
/* 358 */     synchronized (this) {
/* 359 */       this.state = state;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void close() {
/* 364 */     close(null);
/*     */   }
/*     */   
/*     */   protected final void close(String reason) {
/* 368 */     synchronized (this) {
/* 369 */       if (this.state == 3)
/*     */         return; 
/* 371 */       setState(3);
/*     */     } 
/*     */     
/* 374 */     if (this.push) {
/* 375 */       for (int i = 0; i < this.streams.length; i++) {
/* 376 */         ((PushSourceStream)this.streams[i]).setTransferHandler(null);
/*     */       }
/*     */     }
/*     */     
/* 380 */     if (reason != null) {
/* 381 */       this.errorEncountered = true;
/* 382 */       sendDataSinkErrorEvent(reason);
/*     */       
/* 384 */       synchronized (this.bufferLock) {
/* 385 */         this.bufferLock.notifyAll();
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 402 */       this.source.stop();
/*     */     } catch (IOException e) {
/* 404 */       System.err.println("IOException when stopping source " + e);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 410 */       if (this.raFile != null) {
/* 411 */         this.raFile.close();
/*     */       }
/*     */       
/* 414 */       if (this.streamingEnabled && 
/* 415 */         this.qtStrRaFile != null) {
/* 416 */         this.qtStrRaFile.close();
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 421 */       if (this.source != null) {
/* 422 */         this.source.disconnect();
/*     */       }
/*     */ 
/*     */       
/* 426 */       if (this.streamingEnabled && this.tempFile != null)
/*     */       {
/*     */         
/* 429 */         if (!this.errorCreatingStreamingFile) {
/* 430 */           boolean status = deleteFile(this.tempFile);
/*     */         } else {
/* 432 */           boolean status = deleteFile(this.file);
/*     */         }
/*     */       
/*     */       }
/*     */     } catch (IOException e) {
/*     */       
/* 438 */       System.out.println("close: " + e);
/*     */     } 
/*     */     
/* 441 */     this.raFile = null;
/* 442 */     this.qtStrRaFile = null;
/*     */     
/* 444 */     removeAllListeners();
/*     */   }
/*     */   
/*     */   public String getContentType() {
/* 448 */     return this.contentType;
/*     */   }
/*     */   
/*     */   public Object[] getControls() {
/* 452 */     if (this.controls == null) {
/* 453 */       this.controls = new Control[0];
/*     */     }
/* 455 */     return (Object[])this.controls;
/*     */   }
/*     */   
/*     */   public Object getControl(String controlName) {
/* 459 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void transferData(PushSourceStream pss) {
/* 465 */     int totalRead = 0;
/* 466 */     int spaceAvailable = 131072;
/* 467 */     int bytesRead = 0;
/* 468 */     if (this.errorEncountered) {
/*     */       return;
/*     */     }
/* 471 */     if (this.buffer1Pending) {
/* 472 */       synchronized (this.bufferLock) {
/* 473 */         while (this.buffer1Pending) {
/*     */           
/*     */           try {
/* 476 */             this.bufferLock.wait();
/* 477 */           } catch (InterruptedException ie) {}
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 485 */     while (spaceAvailable > 0) {
/*     */       try {
/* 487 */         bytesRead = pss.read(this.buffer1, totalRead, spaceAvailable);
/*     */         
/* 489 */         if (bytesRead > 16384 && this.WRITE_CHUNK_SIZE < 32768) {
/* 490 */           if (bytesRead > 65536 && this.WRITE_CHUNK_SIZE < 131072) {
/*     */             
/* 492 */             this.WRITE_CHUNK_SIZE = 131072;
/* 493 */           } else if (bytesRead > 32768 && this.WRITE_CHUNK_SIZE < 65536) {
/*     */             
/* 495 */             this.WRITE_CHUNK_SIZE = 65536;
/* 496 */           } else if (this.WRITE_CHUNK_SIZE < 32768) {
/* 497 */             this.WRITE_CHUNK_SIZE = 32768;
/*     */           }
/*     */         
/*     */         }
/* 501 */       } catch (IOException ioe) {}
/*     */ 
/*     */       
/* 504 */       if (bytesRead <= 0) {
/*     */         break;
/*     */       }
/* 507 */       totalRead += bytesRead;
/* 508 */       spaceAvailable -= bytesRead;
/*     */     } 
/*     */     
/* 511 */     if (totalRead > 0) {
/* 512 */       synchronized (this.bufferLock) {
/* 513 */         this.buffer1Pending = true;
/* 514 */         this.buffer1PendingLocation = this.nextLocation;
/* 515 */         this.buffer1Length = totalRead;
/* 516 */         this.nextLocation = -1L;
/*     */ 
/*     */         
/* 519 */         this.bufferLock.notifyAll();
/*     */       } 
/*     */     }
/*     */     
/* 523 */     if (bytesRead == -1) {
/*     */       
/* 525 */       this.receivedEOS = true;
/*     */ 
/*     */ 
/*     */       
/* 529 */       while (!this.fileClosed && !this.errorEncountered && this.state != 3) {
/*     */         try {
/* 531 */           Thread.sleep(50L);
/* 532 */         } catch (InterruptedException ie) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 540 */     while (this.state != 3 && !this.errorEncountered) {
/* 541 */       synchronized (this.bufferLock) {
/*     */ 
/*     */         
/* 544 */         while (!this.buffer1Pending && !this.buffer2Pending && !this.errorEncountered && this.state != 3 && !this.receivedEOS) {
/*     */           
/*     */           try {
/* 547 */             this.bufferLock.wait(500L);
/* 548 */           } catch (InterruptedException ie) {}
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 554 */       if (this.buffer2Pending) {
/*     */ 
/*     */         
/* 557 */         write(this.buffer2, this.buffer2PendingLocation, this.buffer2Length);
/*     */         
/* 559 */         this.buffer2Pending = false;
/*     */       } 
/*     */       
/* 562 */       synchronized (this.bufferLock) {
/* 563 */         if (this.buffer1Pending) {
/* 564 */           byte[] tempBuffer = this.buffer2;
/* 565 */           this.buffer2 = this.buffer1;
/* 566 */           this.buffer2Pending = true;
/* 567 */           this.buffer2PendingLocation = this.buffer1PendingLocation;
/* 568 */           this.buffer2Length = this.buffer1Length;
/* 569 */           this.buffer1Pending = false;
/* 570 */           this.buffer1 = tempBuffer;
/*     */           
/* 572 */           this.bufferLock.notifyAll();
/*     */         }
/* 574 */         else if (this.receivedEOS) {
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 579 */     if (this.receivedEOS) {
/*     */ 
/*     */       
/* 582 */       if (this.raFile != null) {
/* 583 */         if (!this.streamingEnabled) {
/*     */           try {
/* 585 */             this.raFile.close();
/* 586 */           } catch (IOException ioe) {}
/*     */           
/* 588 */           this.raFile = null;
/*     */         } 
/* 590 */         this.fileClosed = true;
/*     */       } 
/* 592 */       if (!this.streamingEnabled) {
/* 593 */         sendEndofStreamEvent();
/*     */       }
/*     */     } 
/* 596 */     if (this.errorEncountered && this.state != 3) {
/* 597 */       close(this.errorReason);
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized long seek(long where) {
/* 602 */     this.nextLocation = where;
/* 603 */     return where;
/*     */   }
/*     */   
/* 606 */   long lastSyncTime = -1L;
/*     */ 
/*     */   
/*     */   private void write(byte[] buffer, long location, int length) {
/*     */     try {
/* 611 */       if (location != -1L)
/* 612 */         doSeek(location); 
/* 613 */       int offset = 0;
/* 614 */       while (length > 0) {
/* 615 */         int toWrite = this.WRITE_CHUNK_SIZE;
/* 616 */         if (length < toWrite)
/* 617 */           toWrite = length; 
/* 618 */         this.raFile.write(buffer, offset, toWrite);
/* 619 */         this.bytesWritten += toWrite;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 641 */         if (this.fileDescriptor != null && this.syncEnabled && this.bytesWritten >= this.WRITE_CHUNK_SIZE) {
/*     */           
/* 643 */           this.bytesWritten -= this.WRITE_CHUNK_SIZE;
/* 644 */           this.fileDescriptor.sync();
/*     */         } 
/*     */ 
/*     */         
/* 648 */         this.filePointer += toWrite;
/* 649 */         length -= toWrite;
/* 650 */         offset += toWrite;
/* 651 */         if (this.filePointer > this.fileSize)
/* 652 */           this.fileSize = this.filePointer; 
/* 653 */         Thread.yield();
/*     */       } 
/*     */     } catch (IOException ioe) {
/* 656 */       this.errorEncountered = true;
/* 657 */       this.errorReason = ioe.toString();
/*     */     } 
/*     */   }
/*     */   
/*     */   public long doSeek(long where) {
/* 662 */     if (this.raFile != null) {
/*     */       try {
/* 664 */         this.raFile.seek(where);
/* 665 */         this.filePointer = (int)where;
/* 666 */         return where;
/*     */       } catch (IOException ioe) {
/* 668 */         close("Error in seek: " + ioe);
/*     */       } 
/*     */     }
/* 671 */     return -1L;
/*     */   }
/*     */   
/*     */   public long tell() {
/* 675 */     return this.nextLocation;
/*     */   }
/*     */   
/*     */   public long doTell() {
/* 679 */     if (this.raFile != null) {
/*     */       try {
/* 681 */         return this.raFile.getFilePointer();
/*     */       } catch (IOException ioe) {
/* 683 */         close("Error in tell: " + ioe);
/*     */       } 
/*     */     }
/* 686 */     return -1L;
/*     */   }
/*     */   
/*     */   public boolean isRandomAccess() {
/* 690 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean deleteFile(File file) {
/* 695 */     boolean fileDeleted = false;
/*     */     try {
/* 697 */       if (jmfSecurity != null) {
/*     */         try {
/* 699 */           if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 700 */             jmfSecurity.requestPermission(this.m, this.cl, this.args, 8);
/* 701 */             this.m[0].invoke(this.cl[0], this.args[0]);
/* 702 */           } else if (jmfSecurity.getName().startsWith("internet")) {
/* 703 */             PolicyEngine.checkPermission(PermissionID.FILEIO);
/* 704 */             PolicyEngine.assertPermission(PermissionID.FILEIO);
/*     */           }
/*     */         
/* 707 */         } catch (Exception e) {
/*     */ 
/*     */ 
/*     */           
/* 711 */           securityPrivelege = false;
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 716 */       if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/* 717 */         Constructor cons = jdk12DeleteFileAction.cons;
/*     */         
/* 719 */         Boolean success = (Boolean)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { file }) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 727 */         fileDeleted = success.booleanValue();
/*     */       } else {
/* 729 */         fileDeleted = file.delete();
/*     */       } 
/* 731 */     } catch (Throwable e) {}
/*     */     
/* 733 */     return fileDeleted;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\datasink\file\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */