/*    */ package com.sun.media.datasink;
/*    */ import java.io.IOException;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Vector;
/*    */ import javax.media.DataSink;
/*    */ import javax.media.IncompatibleSourceException;
/*    */ import javax.media.MediaLocator;
/*    */ import javax.media.datasink.DataSinkErrorEvent;
/*    */ import javax.media.datasink.DataSinkEvent;
/*    */ import javax.media.datasink.DataSinkListener;
/*    */ import javax.media.datasink.EndOfStreamEvent;
/*    */ import javax.media.protocol.DataSource;
/*    */ 
/*    */ public abstract class BasicDataSink implements DataSink {
/* 15 */   protected Vector listeners = new Vector(1);
/*    */   
/*    */   public void addDataSinkListener(DataSinkListener dsl) {
/* 18 */     if (dsl != null && 
/* 19 */       !this.listeners.contains(dsl))
/* 20 */       this.listeners.addElement(dsl); 
/*    */   }
/*    */   
/*    */   public void removeDataSinkListener(DataSinkListener dsl) {
/* 24 */     if (dsl != null)
/* 25 */       this.listeners.removeElement(dsl); 
/*    */   }
/*    */   
/*    */   protected void sendEvent(DataSinkEvent event) {
/* 29 */     if (!this.listeners.isEmpty()) {
/* 30 */       synchronized (this.listeners) {
/* 31 */         Enumeration list = this.listeners.elements();
/* 32 */         while (list.hasMoreElements()) {
/* 33 */           DataSinkListener listener = list.nextElement();
/* 34 */           listener.dataSinkUpdate(event);
/*    */         } 
/*    */       } 
/*    */     }
/*    */   }
/*    */   
/*    */   protected void removeAllListeners() {
/* 41 */     this.listeners.removeAllElements();
/*    */   }
/*    */   
/*    */   protected final void sendEndofStreamEvent() {
/* 45 */     sendEvent((DataSinkEvent)new EndOfStreamEvent(this));
/*    */   }
/*    */   
/*    */   protected final void sendDataSinkErrorEvent(String reason) {
/* 49 */     sendEvent((DataSinkEvent)new DataSinkErrorEvent(this, reason));
/*    */   }
/*    */   
/*    */   public abstract String getContentType();
/*    */   
/*    */   public abstract void close();
/*    */   
/*    */   public abstract void open() throws IOException, SecurityException;
/*    */   
/*    */   public abstract void stop() throws IOException;
/*    */   
/*    */   public abstract void start() throws IOException;
/*    */   
/*    */   public abstract MediaLocator getOutputLocator();
/*    */   
/*    */   public abstract void setOutputLocator(MediaLocator paramMediaLocator);
/*    */   
/*    */   public abstract void setSource(DataSource paramDataSource) throws IOException, IncompatibleSourceException;
/*    */   
/*    */   public abstract Object getControl(String paramString);
/*    */   
/*    */   public abstract Object[] getControls();
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\datasink\BasicDataSink.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */