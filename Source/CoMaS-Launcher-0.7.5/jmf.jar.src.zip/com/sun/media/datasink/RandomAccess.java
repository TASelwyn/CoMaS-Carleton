package com.sun.media.datasink;

public interface RandomAccess {
  void setEnabled(boolean paramBoolean);
  
  boolean write(long paramLong, int paramInt);
}
