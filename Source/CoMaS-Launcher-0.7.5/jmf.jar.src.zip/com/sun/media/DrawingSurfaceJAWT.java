package com.sun.media;

import java.awt.Component;
import java.awt.Toolkit;

public class DrawingSurfaceJAWT {
  public static final int valid = 0;
  
  public static final int pawt = 1;
  
  public static final int pds = 2;
  
  public static final int pwinid = 3;
  
  public static final int pdisp = 4;
  
  private static boolean avail = true;
  
  static {
    try {
      Toolkit.getDefaultToolkit();
      JMFSecurityManager.loadLibrary("jmfjawt");
      avail = true;
    } catch (Throwable t) {
      t.printStackTrace();
      avail = false;
    } 
  }
  
  int[] winfo = null;
  
  public DrawingSurfaceJAWT() {
    if (!avail)
      throw new RuntimeException("can't load jmfjawt native module"); 
    this.winfo = new int[5];
    for (int i = 0; i < 5; i++)
      this.winfo[i] = 0; 
  }
  
  public int[] getWindowInfo(Component cc) {
    int value = 0;
    value = getAWT();
    if (value == 0) {
      this.winfo[0] = 0;
      return this.winfo;
    } 
    this.winfo[1] = value;
    value = getDrawingSurface(cc, this.winfo[1]);
    if (value == 0) {
      this.winfo[0] = 0;
      return this.winfo;
    } 
    this.winfo[2] = value;
    value = getDrawingSurfaceWinID(this.winfo[2]);
    if (value == 0) {
      this.winfo[0] = 0;
      return this.winfo;
    } 
    this.winfo[3] = value;
    value = getDrawingSurfaceDisplay(this.winfo[2]);
    if (value == 0) {
      this.winfo[0] = 0;
      return this.winfo;
    } 
    this.winfo[4] = value;
    this.winfo[0] = 1;
    return this.winfo;
  }
  
  public static native int getWindowHandle(Component paramComponent);
  
  public static native boolean lockAWT(int paramInt);
  
  public static native void unlockAWT(int paramInt);
  
  public static native void freeResource(int paramInt1, int paramInt2);
  
  public native int getAWT();
  
  public native int getDrawingSurface(Component paramComponent, int paramInt);
  
  public native int getDrawingSurfaceWinID(int paramInt);
  
  public native int getDrawingSurfaceDisplay(int paramInt);
}
