/*     */ package com.sun.media;
/*     */ 
/*     */ import javax.media.Buffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CircularBuffer
/*     */ {
/*     */   private Buffer[] buf;
/*     */   private int head;
/*     */   private int tail;
/*     */   private int availableFramesForReading;
/*     */   private int availableFramesForWriting;
/*     */   private int lockedFramesForReading;
/*     */   private int lockedFramesForWriting;
/*     */   private int size;
/*     */   
/*     */   public CircularBuffer(int n) {
/*  39 */     this.size = n;
/*  40 */     this.buf = new Buffer[n];
/*  41 */     for (int i = 0; i < n; i++)
/*  42 */       this.buf[i] = new ExtBuffer(); 
/*  43 */     reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void readReport() {
/*  48 */     if (this.lockedFramesForReading == 0) {
/*  49 */       error();
/*     */     }
/*  51 */     this.lockedFramesForReading--;
/*  52 */     this.availableFramesForWriting++;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean canRead() {
/*  57 */     return (this.availableFramesForReading > 0);
/*     */   }
/*     */   
/*     */   public synchronized boolean lockedRead() {
/*  61 */     return (this.lockedFramesForReading > 0);
/*     */   }
/*     */   
/*     */   public synchronized boolean lockedWrite() {
/*  65 */     return (this.lockedFramesForWriting > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Buffer read() {
/*  72 */     if (this.availableFramesForReading == 0) {
/*  73 */       error();
/*     */     }
/*  75 */     Buffer buffer = this.buf[this.head];
/*  76 */     this.lockedFramesForReading++;
/*  77 */     this.availableFramesForReading--;
/*  78 */     this.head++;
/*  79 */     if (this.head >= this.size) {
/*  80 */       this.head -= this.size;
/*     */     }
/*  82 */     return buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Buffer peek() {
/*  89 */     if (this.availableFramesForReading == 0) {
/*  90 */       error();
/*     */     }
/*  92 */     return this.buf[this.head];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void writeReport() {
/*  99 */     if (this.lockedFramesForWriting == 0) {
/* 100 */       error();
/*     */     }
/* 102 */     this.lockedFramesForWriting--;
/* 103 */     this.availableFramesForReading++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Buffer getEmptyBuffer() {
/* 117 */     if (this.availableFramesForWriting == 0) {
/* 118 */       error();
/*     */     }
/* 120 */     this.lockedFramesForWriting++;
/* 121 */     Buffer buffer = this.buf[this.tail];
/* 122 */     this.availableFramesForWriting--;
/* 123 */     this.tail++;
/* 124 */     if (this.tail >= this.size) {
/* 125 */       this.tail -= this.size;
/*     */     }
/* 127 */     return buffer;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean canWrite() {
/* 132 */     return (this.availableFramesForWriting > 0);
/*     */   }
/*     */   
/*     */   public void error() {
/* 136 */     throw new RuntimeException("CircularQueue failure:\n head=" + this.head + "\n tail=" + this.tail + "\n canRead=" + this.availableFramesForReading + "\n canWrite=" + this.availableFramesForWriting + "\n lockedRead=" + this.lockedFramesForReading + "\n lockedWrite=" + this.lockedFramesForWriting);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void print() {
/* 142 */     System.err.println("CircularQueue : head=" + this.head + " tail=" + this.tail + " canRead=" + this.availableFramesForReading + " canWrite=" + this.availableFramesForWriting + " lockedRead=" + this.lockedFramesForReading + " lockedWrite=" + this.lockedFramesForWriting);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void reset() {
/* 149 */     this.availableFramesForReading = 0;
/* 150 */     this.availableFramesForWriting = this.size;
/* 151 */     this.lockedFramesForReading = 0;
/* 152 */     this.lockedFramesForWriting = 0;
/* 153 */     this.head = 0;
/* 154 */     this.tail = 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\CircularBuffer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */