/*     */ package com.sun.media.multiplexer;
/*     */ 
/*     */ import com.sun.media.BasicClock;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.MediaTimeBase;
/*     */ import com.sun.media.Syncable;
/*     */ import com.sun.media.controls.MonitorAdapter;
/*     */ import com.sun.media.datasink.RandomAccess;
/*     */ import java.awt.Component;
/*     */ import java.io.IOException;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Clock;
/*     */ import javax.media.ClockStoppedException;
/*     */ import javax.media.Control;
/*     */ import javax.media.Duration;
/*     */ import javax.media.Format;
/*     */ import javax.media.IncompatibleTimeBaseException;
/*     */ import javax.media.Multiplexer;
/*     */ import javax.media.Owned;
/*     */ import javax.media.Time;
/*     */ import javax.media.TimeBase;
/*     */ import javax.media.control.StreamWriterControl;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PushDataSource;
/*     */ import javax.media.protocol.PushSourceStream;
/*     */ import javax.media.protocol.Seekable;
/*     */ import javax.media.protocol.SourceTransferHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BasicMux
/*     */   extends BasicPlugIn
/*     */   implements Multiplexer, Clock
/*     */ {
/*     */   protected Format[] supportedInputs;
/*     */   protected ContentDescriptor[] supportedOutputs;
/*  45 */   protected int numTracks = 0;
/*     */   protected Format[] inputs;
/*     */   protected BasicMuxDataSource source;
/*     */   protected BasicMuxPushStream stream;
/*     */   protected ContentDescriptor outputCD;
/*     */   protected boolean flushing = false;
/*  51 */   protected Integer sourceLock = new Integer(0);
/*     */   protected boolean eos = false;
/*     */   protected boolean firstBuffer = true;
/*  54 */   protected int fileSize = 0;
/*  55 */   protected int filePointer = 0;
/*  56 */   protected long fileSizeLimit = -1L;
/*     */   protected boolean streamSizeLimitSupported = true;
/*     */   protected boolean fileSizeLimitReached = false;
/*  59 */   protected SourceTransferHandler sth = null;
/*     */   
/*     */   protected boolean isLiveData = false;
/*  62 */   protected StreamWriterControl swc = null;
/*  63 */   protected MonitorAdapter[] mc = null;
/*     */ 
/*     */   
/*  66 */   protected BasicMuxTimeBase timeBase = null;
/*     */ 
/*     */   
/*  69 */   Object startup = new Integer(0);
/*     */ 
/*     */   
/*     */   boolean readyToStart = false;
/*     */ 
/*     */   
/*     */   long[] mediaTime;
/*     */   
/*     */   boolean[] ready;
/*     */   
/*  79 */   protected BasicClock clock = null;
/*     */ 
/*     */   
/*  82 */   int master = 0; boolean mClosed = false;
/*     */   boolean dataReady;
/*     */   boolean startCompensated;
/*     */   Object dataLock;
/*     */   Buffer[] firstBuffers;
/*     */   boolean[] firstBuffersDone;
/*     */   int[] nonKeyCount;
/*     */   long masterTime;
/*     */   VideoFormat jpegFmt;
/*     */   VideoFormat mjpgFmt;
/*     */   VideoFormat rgbFmt;
/*     */   VideoFormat yuvFmt;
/*     */   protected int maxBufSize;
/*     */   protected byte[] buf;
/*     */   protected int bufOffset;
/*     */   protected int bufLength;
/*     */   Object timeSetSync;
/*     */   boolean started;
/*     */   long systemStartTime;
/*     */   
/*     */   public void open() {
/* 103 */     this.firstBuffer = true;
/* 104 */     this.firstBuffers = new Buffer[this.inputs.length];
/* 105 */     this.firstBuffersDone = new boolean[this.inputs.length];
/* 106 */     this.nonKeyCount = new int[this.inputs.length];
/* 107 */     this.mediaTime = new long[this.inputs.length];
/*     */     int i;
/* 109 */     for (i = 0; i < this.inputs.length; i++) {
/* 110 */       this.firstBuffers[i] = null;
/* 111 */       this.firstBuffersDone[i] = false;
/* 112 */       this.nonKeyCount[i] = 0;
/* 113 */       this.mediaTime[i] = 0L;
/*     */     } 
/*     */     
/* 116 */     this.ready = new boolean[this.inputs.length];
/* 117 */     resetReady();
/*     */     
/* 119 */     int len = 0;
/* 120 */     this.mc = new MonitorAdapter[this.inputs.length];
/*     */     
/* 122 */     for (i = 0; i < this.inputs.length; i++) {
/* 123 */       if (this.inputs[i] instanceof VideoFormat || this.inputs[i] instanceof AudioFormat) {
/*     */         
/* 125 */         this.mc[i] = new MonitorAdapter(this.inputs[i], this);
/* 126 */         if (this.mc[i] != null) {
/* 127 */           len++;
/*     */         }
/*     */       } 
/*     */     } 
/* 131 */     int j = 0;
/* 132 */     this.controls = (Object[])new Control[len + 1];
/* 133 */     for (i = 0; i < this.mc.length; i++) {
/* 134 */       if (this.mc[i] != null)
/* 135 */         this.controls[j++] = this.mc[i]; 
/*     */     } 
/* 137 */     this.controls[j] = this.swc;
/*     */   }
/*     */   
/*     */   public void close() {
/* 141 */     if (this.sth != null) {
/* 142 */       writeFooter();
/* 143 */       write(null, 0, -1);
/*     */     } 
/*     */     
/* 146 */     for (int i = 0; i < this.mc.length; i++) {
/* 147 */       if (this.mc[i] != null) {
/* 148 */         this.mc[i].close();
/*     */       }
/*     */     } 
/* 151 */     synchronized (this.dataLock) {
/* 152 */       this.mClosed = true;
/* 153 */       this.dataLock.notifyAll();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 159 */     for (int i = 0; i < this.mediaTime.length; i++) {
/* 160 */       this.mediaTime[i] = 0L;
/* 161 */       if (this.mc[i] != null)
/* 162 */         this.mc[i].reset(); 
/*     */     } 
/* 164 */     this.timeBase.update();
/* 165 */     resetReady();
/* 166 */     synchronized (this.sourceLock) {
/* 167 */       this.flushing = true;
/* 168 */       this.sourceLock.notifyAll();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void resetReady() {
/* 173 */     for (int i = 0; i < this.ready.length; i++)
/* 174 */       this.ready[i] = false; 
/* 175 */     this.readyToStart = false;
/* 176 */     synchronized (this.startup) {
/* 177 */       this.startup.notifyAll();
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean checkReady() {
/* 182 */     if (this.readyToStart)
/* 183 */       return true; 
/* 184 */     for (int i = 0; i < this.ready.length; i++) {
/* 185 */       if (!this.ready[i])
/* 186 */         return false; 
/*     */     } 
/* 188 */     this.readyToStart = true;
/* 189 */     return true;
/*     */   }
/*     */   
/*     */   public Format[] getSupportedInputFormats() {
/* 193 */     return this.supportedInputs;
/*     */   }
/*     */   
/*     */   public ContentDescriptor[] getSupportedOutputContentDescriptors(Format[] inputs) {
/* 197 */     return this.supportedOutputs;
/*     */   }
/*     */   
/*     */   public int setNumTracks(int numTracks) {
/* 201 */     this.numTracks = numTracks;
/*     */     
/* 203 */     if (this.inputs == null) {
/* 204 */       this.inputs = new Format[numTracks];
/*     */     } else {
/* 206 */       Format[] newInputs = new Format[numTracks];
/* 207 */       for (int i = 0; i < this.inputs.length; i++) {
/* 208 */         newInputs[i] = this.inputs[i];
/*     */       }
/* 210 */       this.inputs = newInputs;
/*     */     } 
/*     */     
/* 213 */     return numTracks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format setInputFormat(Format format, int trackID) {
/* 221 */     this.inputs[trackID] = format;
/* 222 */     return format;
/*     */   }
/*     */   
/*     */   public int process(Buffer buffer, int trackID) {
/* 226 */     if (buffer.isDiscard())
/* 227 */       return 0; 
/* 228 */     if (!this.isLiveData && (buffer.getFlags() & 0x8000) > 0) {
/* 229 */       this.isLiveData = true;
/*     */     }
/*     */     
/* 232 */     while (this.source == null || !this.source.isConnected() || !this.source.isStarted()) {
/* 233 */       synchronized (this.sourceLock) {
/*     */         try {
/* 235 */           this.sourceLock.wait(500L);
/* 236 */         } catch (InterruptedException ie) {}
/*     */         
/* 238 */         if (this.flushing) {
/* 239 */           this.flushing = false;
/* 240 */           buffer.setLength(0);
/* 241 */           return 0;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 246 */     synchronized (this) {
/* 247 */       if (this.firstBuffer) {
/* 248 */         writeHeader();
/* 249 */         this.firstBuffer = false;
/*     */       } 
/*     */     } 
/*     */     
/* 253 */     if (this.numTracks > 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 258 */       if ((buffer.getFlags() & 0x1000) != 0 && 
/* 259 */         buffer.getTimeStamp() <= 0L) {
/* 260 */         return 0;
/*     */       }
/*     */       
/* 263 */       if (!this.startCompensated && 
/* 264 */         !compensateStart(buffer, trackID))
/*     */       {
/* 266 */         return 0;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 271 */     updateClock(buffer, trackID);
/* 272 */     if (this.mc[trackID] != null && this.mc[trackID].isEnabled())
/* 273 */       this.mc[trackID].process(buffer); 
/* 274 */     int processResult = doProcess(buffer, trackID);
/* 275 */     if (this.fileSizeLimitReached)
/* 276 */       processResult |= 0x8; 
/* 277 */     return processResult;
/*     */   }
/*     */   
/*     */   public BasicMux() {
/* 281 */     this.dataReady = false;
/* 282 */     this.startCompensated = false;
/* 283 */     this.dataLock = new Object();
/*     */ 
/*     */ 
/*     */     
/* 287 */     this.masterTime = -1L;
/*     */ 
/*     */ 
/*     */     
/* 291 */     this.jpegFmt = new VideoFormat("jpeg");
/* 292 */     this.mjpgFmt = new VideoFormat("mjpg");
/* 293 */     this.rgbFmt = new VideoFormat("rgb");
/* 294 */     this.yuvFmt = new VideoFormat("yuv");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 537 */     this.maxBufSize = 32768;
/* 538 */     this.buf = new byte[this.maxBufSize];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 630 */     this.timeSetSync = new Object();
/* 631 */     this.started = false;
/* 632 */     this.systemStartTime = System.currentTimeMillis() * 1000000L; this.timeBase = new BasicMuxTimeBase(this); this.clock = new BasicClock(); try { this.clock.setTimeBase((TimeBase)this.timeBase); } catch (Exception e) {} this.swc = new SWC(this, this); this.controls = (Object[])new Control[] { (Control)this.swc };
/*     */   }
/*     */   private boolean compensateStart(Buffer buffer, int trackID) { synchronized (this.dataLock) { if (this.dataReady) { if (!this.firstBuffersDone[trackID]) { if (buffer.getTimeStamp() < this.masterTime) return false;  if (buffer.getFormat() instanceof VideoFormat) { Format fmt = buffer.getFormat(); boolean isKey = (this.jpegFmt.matches(fmt) || this.mjpgFmt.matches(fmt) || this.rgbFmt.matches(fmt) || this.yuvFmt.matches(fmt)); this.nonKeyCount[trackID] = this.nonKeyCount[trackID] + 1; if (isKey || (buffer.getFlags() & 0x10) != 0 || this.nonKeyCount[trackID] > 30) { buffer.setTimeStamp(this.masterTime); this.firstBuffersDone[trackID] = true; } else { return false; }  } else { buffer.setTimeStamp(this.masterTime); this.firstBuffersDone[trackID] = true; }  for (int m = 0; m < this.firstBuffersDone.length; m++) { if (!this.firstBuffersDone[m]) return true;  }  this.startCompensated = true; return true; }  return true; }  if (buffer.getTimeStamp() < 0L) { this.startCompensated = true; this.dataReady = true; this.dataLock.notifyAll(); return true; }  this.firstBuffers[trackID] = buffer; boolean done = true; for (int i = 0; i < this.firstBuffers.length; i++) { if (this.firstBuffers[i] == null) done = false;  }  if (!done) { while (!this.dataReady && !this.mClosed) { try { this.dataLock.wait(); } catch (Exception e) {} }  if (this.mClosed || this.firstBuffers[trackID] == null) return false;  return true; }  this.masterTime = this.firstBuffers[0].getTimeStamp(); for (int j = 0; j < this.firstBuffers.length; j++) { if (this.firstBuffers[j].getFormat() instanceof AudioFormat) { this.masterTime = this.firstBuffers[j].getTimeStamp(); break; }  if (this.firstBuffers[j].getTimeStamp() < this.masterTime) this.masterTime = this.firstBuffers[j].getTimeStamp();  }  this.startCompensated = true; for (int k = 0; k < this.firstBuffers.length; k++) { if (this.firstBuffers[k].getTimeStamp() >= this.masterTime) { this.firstBuffers[k].setTimeStamp(this.masterTime); this.firstBuffersDone[k] = true; } else { this.firstBuffers[k] = null; this.startCompensated = false; }  }  synchronized (this.dataLock) { this.dataReady = true; this.dataLock.notifyAll(); }  return (this.firstBuffers[trackID] != null); }  }
/* 635 */   private void updateClock(Buffer buffer, int trackID) { if (!this.readyToStart && this.numTracks > 1) synchronized (this.startup) { this.ready[trackID] = true; if (checkReady()) { this.startup.notifyAll(); } else { try { while (!this.readyToStart) this.startup.wait(1000L);  } catch (Exception e) {} }  }   long timestamp = buffer.getTimeStamp(); if (timestamp <= 0L && buffer.getFormat() instanceof AudioFormat) { timestamp = this.mediaTime[trackID]; this.mediaTime[trackID] = this.mediaTime[trackID] + getDuration(buffer); } else if (timestamp <= 0L) { this.mediaTime[trackID] = System.currentTimeMillis() * 1000000L - this.systemStartTime; } else { this.mediaTime[trackID] = timestamp; }  this.timeBase.update(); } public ContentDescriptor setContentDescriptor(ContentDescriptor outputCD) { if (BasicPlugIn.matches((Format)outputCD, (Format[])this.supportedOutputs) == null) return null;  this.outputCD = outputCD; return outputCD; } public DataSource getDataOutput() { if (this.source == null) { this.source = new BasicMuxDataSource(this, this, this.outputCD); synchronized (this.sourceLock) { this.sourceLock.notifyAll(); }  }  return (DataSource)this.source; } protected int doProcess(Buffer buffer, int trackID) { byte[] data = (byte[])buffer.getData(); int dataLen = buffer.getLength(); if (!buffer.isEOM()) write(data, buffer.getOffset(), dataLen);  return 0; } protected int write(byte[] data, int offset, int length) { if (this.source == null || !this.source.isConnected()) return length;  if (length > 0) { this.filePointer += length; if (this.filePointer > this.fileSize) this.fileSize = this.filePointer;  if (this.fileSizeLimit > 0L && this.fileSize >= this.fileSizeLimit) this.fileSizeLimitReached = true;  }  return this.stream.write(data, offset, length); } void setStream(BasicMuxPushStream ps) { this.stream = ps; } long getStreamSize() { return this.fileSize; } boolean needsSeekable() { return false; } protected int seek(int location) { if (this.source == null || !this.source.isConnected()) return location;  this.filePointer = this.stream.seek(location); return this.filePointer; } boolean isEOS() { return this.eos; } protected void writeHeader() {} public void setTimeBase(TimeBase master) throws IncompatibleTimeBaseException { if (master != this.timeBase)
/* 636 */       throw new IncompatibleTimeBaseException();  }
/*     */   protected void writeFooter() {}
/*     */   protected void bufClear() { this.bufOffset = 0; this.bufLength = 0; }
/*     */   protected void bufSkip(int size) { this.bufOffset += size; this.bufLength += size; this.filePointer += size; }
/* 640 */   protected void bufWriteBytes(String s) { byte[] bytes = s.getBytes(); bufWriteBytes(bytes); } protected void bufWriteBytes(byte[] bytes) { System.arraycopy(bytes, 0, this.buf, this.bufOffset, bytes.length); this.bufOffset += bytes.length; this.bufLength += bytes.length; this.filePointer += bytes.length; } protected void bufWriteInt(int value) { this.buf[this.bufOffset + 0] = (byte)(value >> 24 & 0xFF); this.buf[this.bufOffset + 1] = (byte)(value >> 16 & 0xFF); this.buf[this.bufOffset + 2] = (byte)(value >> 8 & 0xFF); this.buf[this.bufOffset + 3] = (byte)(value >> 0 & 0xFF); this.bufOffset += 4; this.bufLength += 4; this.filePointer += 4; } protected void bufWriteIntLittleEndian(int value) { this.buf[this.bufOffset + 3] = (byte)(value >>> 24 & 0xFF); this.buf[this.bufOffset + 2] = (byte)(value >>> 16 & 0xFF); this.buf[this.bufOffset + 1] = (byte)(value >>> 8 & 0xFF); this.buf[this.bufOffset + 0] = (byte)(value >>> 0 & 0xFF); this.bufOffset += 4; this.bufLength += 4; this.filePointer += 4; } protected void bufWriteShort(short value) { this.buf[this.bufOffset + 0] = (byte)(value >> 8 & 0xFF); this.buf[this.bufOffset + 1] = (byte)(value >> 0 & 0xFF); this.bufOffset += 2; this.bufLength += 2; this.filePointer += 2; } protected void bufWriteShortLittleEndian(short value) { this.buf[this.bufOffset + 1] = (byte)(value >> 8 & 0xFF); this.buf[this.bufOffset + 0] = (byte)(value >> 0 & 0xFF); this.bufOffset += 2; this.bufLength += 2; this.filePointer += 2; } protected void bufWriteByte(byte value) { this.buf[this.bufOffset] = value; this.bufOffset++; this.bufLength++; this.filePointer++; } protected void bufFlush() { this.filePointer -= this.bufLength; write(this.buf, 0, this.bufLength); } private long getDuration(Buffer buffer) { AudioFormat format = (AudioFormat)buffer.getFormat(); long duration = format.computeDuration(buffer.getLength()); if (duration < 0L) return 0L;  return duration; } public void syncStart(Time at) { synchronized (this.timeSetSync) {
/* 641 */       if (this.started)
/* 642 */         return;  this.started = true;
/* 643 */       this.clock.syncStart(at);
/* 644 */       this.timeBase.mediaStarted();
/* 645 */       this.systemStartTime = System.currentTimeMillis() * 1000000L;
/*     */     }  }
/*     */ 
/*     */   
/*     */   public void stop() {
/* 650 */     synchronized (this.timeSetSync) {
/* 651 */       if (!this.started)
/* 652 */         return;  this.started = false;
/* 653 */       this.clock.stop();
/* 654 */       this.timeBase.mediaStopped();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setStopTime(Time stopTime) {
/* 659 */     this.clock.setStopTime(stopTime);
/*     */   }
/*     */   
/*     */   public Time getStopTime() {
/* 663 */     return this.clock.getStopTime();
/*     */   }
/*     */   
/*     */   public void setMediaTime(Time now) {
/* 667 */     synchronized (this.timeSetSync) {
/* 668 */       this.clock.setMediaTime(now);
/* 669 */       for (int i = 0; i < this.mediaTime.length; i++)
/* 670 */         this.mediaTime[i] = now.getNanoseconds(); 
/* 671 */       this.timeBase.update();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Time getMediaTime() {
/* 676 */     return this.clock.getMediaTime();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getMediaNanoseconds() {
/* 681 */     return this.clock.getMediaNanoseconds();
/*     */   }
/*     */   
/*     */   public Time getSyncTime() {
/* 685 */     return this.clock.getSyncTime();
/*     */   }
/*     */ 
/*     */   
/*     */   public TimeBase getTimeBase() {
/* 690 */     return this.clock.getTimeBase();
/*     */   }
/*     */   
/*     */   public Time mapToTimeBase(Time t) throws ClockStoppedException {
/* 694 */     return this.clock.mapToTimeBase(t);
/*     */   }
/*     */   
/*     */   public float getRate() {
/* 698 */     return this.clock.getRate();
/*     */   }
/*     */   
/*     */   public float setRate(float factor) {
/* 702 */     if (factor == this.clock.getRate())
/* 703 */       return factor; 
/* 704 */     return this.clock.setRate(1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean requireTwoPass() {
/* 714 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   class SWC
/*     */     implements StreamWriterControl, Owned
/*     */   {
/*     */     private BasicMux bmx;
/*     */     private final BasicMux this$0;
/*     */     
/*     */     public SWC(BasicMux this$0, BasicMux bmx) {
/* 725 */       this.this$0 = this$0;
/* 726 */       this.bmx = bmx;
/*     */     }
/*     */     
/*     */     public boolean setStreamSizeLimit(long limit) {
/* 730 */       this.bmx.fileSizeLimit = limit;
/* 731 */       return this.this$0.streamSizeLimitSupported;
/*     */     }
/*     */     
/*     */     public long getStreamSize() {
/* 735 */       return this.bmx.getStreamSize();
/*     */     }
/*     */     
/*     */     public Object getOwner() {
/* 739 */       return this.bmx;
/*     */     }
/*     */     
/*     */     public Component getControlComponent() {
/* 743 */       return null;
/*     */     } }
/*     */   class BasicMuxTimeBase extends MediaTimeBase { long ticks; boolean updated; private final BasicMux this$0;
/*     */     BasicMuxTimeBase(BasicMux this$0) {
/* 747 */       this.this$0 = this$0;
/*     */       
/* 749 */       this.ticks = 0L;
/* 750 */       this.updated = false;
/*     */     }
/*     */     public long getMediaTime() {
/* 753 */       if (!this.updated) {
/* 754 */         return this.ticks;
/*     */       }
/* 756 */       if (this.this$0.mediaTime.length == 1) {
/* 757 */         this.ticks = this.this$0.mediaTime[0];
/*     */       } else {
/* 759 */         this.ticks = this.this$0.mediaTime[0];
/* 760 */         for (int i = 1; i < this.this$0.mediaTime.length; i++) {
/* 761 */           if (this.this$0.mediaTime[i] < this.ticks)
/* 762 */             this.ticks = this.this$0.mediaTime[i]; 
/*     */         } 
/*     */       } 
/* 765 */       this.updated = false;
/* 766 */       return this.ticks;
/*     */     }
/*     */     
/*     */     public void update() {
/* 770 */       this.updated = true;
/*     */     } }
/*     */ 
/*     */   
/*     */   class BasicMuxDataSource
/*     */     extends PushDataSource {
/*     */     private BasicMux mux;
/*     */     private ContentDescriptor cd;
/*     */     private BasicMux.BasicMuxPushStream[] streams;
/*     */     private BasicMux.BasicMuxPushStream stream;
/*     */     private boolean connected;
/*     */     private boolean started;
/*     */     private final BasicMux this$0;
/*     */     
/*     */     public BasicMuxDataSource(BasicMux this$0, BasicMux mux, ContentDescriptor cd) {
/* 785 */       this.this$0 = this$0; this.connected = false; this.started = false;
/* 786 */       this.cd = cd;
/* 787 */       this.mux = mux;
/*     */     }
/*     */     
/*     */     public PushSourceStream[] getStreams() {
/* 791 */       if (this.streams == null) {
/* 792 */         this.streams = new BasicMux.BasicMuxPushStream[1];
/* 793 */         this.stream = new BasicMux.BasicMuxPushStream(this.this$0, this.cd);
/* 794 */         this.streams[0] = this.stream;
/* 795 */         this.this$0.setStream(this.stream);
/*     */       } 
/* 797 */       return (PushSourceStream[])this.streams;
/*     */     }
/*     */     
/*     */     public String getContentType() {
/* 801 */       return this.cd.getContentType();
/*     */     }
/*     */     
/*     */     public void connect() throws IOException {
/* 805 */       if (this.streams == null)
/* 806 */         getStreams(); 
/* 807 */       this.connected = true;
/* 808 */       synchronized (this.this$0.sourceLock) {
/* 809 */         this.this$0.sourceLock.notifyAll();
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean isConnected() {
/* 814 */       return this.connected;
/*     */     }
/*     */     
/*     */     boolean isStarted() {
/* 818 */       return this.started;
/*     */     }
/*     */     
/*     */     public void disconnect() {
/* 822 */       this.connected = false;
/*     */     }
/*     */     
/*     */     public void start() throws IOException {
/* 826 */       if (this.streams == null || !this.connected)
/* 827 */         throw new IOException("Source not connected yet!"); 
/* 828 */       this.started = true;
/* 829 */       synchronized (this.this$0.sourceLock) {
/* 830 */         this.this$0.sourceLock.notifyAll();
/*     */       } 
/*     */     }
/*     */     
/*     */     public void stop() {
/* 835 */       this.started = false;
/*     */     }
/*     */     
/*     */     public Object[] getControls() {
/* 839 */       return (Object[])new Control[0];
/*     */     }
/*     */     
/*     */     public Object getControl(String s) {
/* 843 */       return null;
/*     */     }
/*     */     
/*     */     public Time getDuration() {
/* 847 */       return Duration.DURATION_UNKNOWN;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   class BasicMuxPushStream
/*     */     implements PushSourceStream
/*     */   {
/*     */     private ContentDescriptor cd;
/*     */     private byte[] data;
/*     */     private int dataLen;
/*     */     private int dataOff;
/*     */     private Integer writeLock;
/*     */     private final BasicMux this$0;
/*     */     
/*     */     public BasicMuxPushStream(BasicMux this$0, ContentDescriptor cd) {
/* 863 */       this.this$0 = this$0; this.writeLock = new Integer(0);
/* 864 */       this.cd = cd;
/*     */     }
/*     */     
/*     */     public ContentDescriptor getContentDescriptor() {
/* 868 */       return this.cd;
/*     */     }
/*     */     
/*     */     public long getContentLength() {
/* 872 */       return -1L;
/*     */     }
/*     */     
/*     */     public boolean endOfStream() {
/* 876 */       return this.this$0.isEOS();
/*     */     }
/*     */ 
/*     */     
/*     */     synchronized int write(byte[] data, int offset, int length) {
/* 881 */       if (this.this$0.sth == null) {
/* 882 */         return 0;
/*     */       }
/* 884 */       if (this.this$0.isLiveData && this.this$0.sth instanceof Syncable) {
/* 885 */         ((Syncable)this.this$0.sth).setSyncEnabled();
/*     */       }
/* 887 */       synchronized (this.writeLock) {
/* 888 */         this.data = data;
/* 889 */         this.dataOff = offset;
/* 890 */         this.dataLen = length;
/*     */ 
/*     */         
/* 893 */         this.this$0.sth.transferData(this);
/* 894 */         while (this.dataLen > 0) {
/* 895 */           if (this.dataLen == length) {
/*     */             try {
/* 897 */               this.writeLock.wait();
/* 898 */             } catch (InterruptedException ie) {}
/*     */           }
/*     */           
/* 901 */           if (this.this$0.sth == null) {
/*     */             break;
/*     */           }
/* 904 */           if (this.dataLen > 0 && this.dataLen != length) {
/* 905 */             length = this.dataLen;
/* 906 */             this.this$0.sth.transferData(this);
/*     */           } 
/*     */         } 
/*     */       } 
/* 910 */       return length;
/*     */     }
/*     */     
/*     */     synchronized int seek(int location) {
/* 914 */       if (this.this$0.sth != null) {
/* 915 */         ((Seekable)this.this$0.sth).seek(location);
/* 916 */         int seekVal = (int)((Seekable)this.this$0.sth).tell();
/* 917 */         return seekVal;
/*     */       } 
/* 919 */       return -1;
/*     */     }
/*     */     
/*     */     public int read(byte[] buffer, int offset, int length) throws IOException {
/* 923 */       int transferred = 0;
/*     */       
/* 925 */       synchronized (this.writeLock) {
/* 926 */         if (this.dataLen == -1) {
/* 927 */           transferred = -1;
/*     */         } else {
/* 929 */           if (length >= this.dataLen) {
/* 930 */             transferred = this.dataLen;
/*     */           } else {
/* 932 */             transferred = length;
/*     */           } 
/* 934 */           System.arraycopy(this.data, this.dataOff, buffer, offset, transferred);
/*     */           
/* 936 */           this.dataLen -= transferred;
/* 937 */           this.dataOff += transferred;
/*     */         } 
/* 939 */         this.writeLock.notifyAll();
/* 940 */         return transferred;
/*     */       } 
/*     */     }
/*     */     
/*     */     public int getMinimumTransferSize() {
/* 945 */       return this.dataLen;
/*     */     }
/*     */     
/*     */     public void setTransferHandler(SourceTransferHandler sth) {
/* 949 */       synchronized (this.writeLock) {
/* 950 */         this.this$0.sth = sth;
/* 951 */         if (sth != null && this.this$0.needsSeekable() && !(sth instanceof Seekable)) {
/* 952 */           throw new Error("SourceTransferHandler needs to be seekable");
/*     */         }
/* 954 */         boolean requireTwoPass = this.this$0.requireTwoPass();
/*     */         
/* 956 */         if (requireTwoPass && 
/* 957 */           sth != null && sth instanceof RandomAccess) {
/*     */           
/* 959 */           RandomAccess st = (RandomAccess)sth;
/* 960 */           st.setEnabled(true);
/*     */         } 
/*     */         
/* 963 */         this.writeLock.notifyAll();
/*     */       } 
/*     */     }
/*     */     
/*     */     public Object[] getControls() {
/* 968 */       return (Object[])new Control[0];
/*     */     }
/*     */     
/*     */     public Object getControl(String s) {
/* 972 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\multiplexer\BasicMux.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */