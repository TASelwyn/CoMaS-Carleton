/*    */ package com.sun.media.multiplexer;
/*    */ 
/*    */ import com.sun.media.rtp.FormatInfo;
/*    */ import com.sun.media.rtp.RTPSessionMgr;
/*    */ import javax.media.Format;
/*    */ import javax.media.protocol.ContentDescriptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RTPSyncBufferMux
/*    */   extends RawSyncBufferMux
/*    */ {
/* 17 */   FormatInfo rtpFormats = new FormatInfo();
/*    */ 
/*    */   
/*    */   public RTPSyncBufferMux() {
/* 21 */     this.supported = new ContentDescriptor[1];
/* 22 */     this.supported[0] = new ContentDescriptor("raw.rtp");
/* 23 */     this.monoIncrTime = true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 31 */     return "RTP Sync Buffer Multiplexer";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Format setInputFormat(Format input, int trackID) {
/* 37 */     if (!RTPSessionMgr.formatSupported(input)) {
/* 38 */       return null;
/*    */     }
/* 40 */     return super.setInputFormat(input, trackID);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\multiplexer\RTPSyncBufferMux.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */