/*     */ package com.sun.media.multiplexer.audio;
/*     */ 
/*     */ import com.sun.media.format.WavAudioFormat;
/*     */ import com.sun.media.multiplexer.BasicMux;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.FileTypeDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WAVMux
/*     */   extends BasicMux
/*     */ {
/*     */   private AudioFormat audioFormat;
/*     */   private WavAudioFormat wavAudioFormat;
/*     */   private int sampleSizeInBits;
/*     */   private double sampleRate;
/*     */   private int channels;
/*     */   private byte[] codecSpecificHeader;
/*     */   private short wFormatTag;
/*  40 */   private int blockAlign = 0;
/*  41 */   private int bytesPerSecond = 0;
/*     */   private int dataSizeOffset;
/*     */   private int numberOfSamplesOffset;
/*  44 */   private int factChunkLength = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   Format signed;
/*     */ 
/*     */ 
/*     */   
/*     */   Format unsigned;
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  57 */     return "WAVE Audio Multiplexer";
/*     */   }
/*     */   
/*     */   public WAVMux() {
/*  61 */     this.signed = (Format)new AudioFormat(null, -1.0D, -1, -1, 0, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  68 */     this.unsigned = (Format)new AudioFormat(null, -1.0D, -1, -1, 0, 0);
/*     */     this.supportedInputs = new Format[1];
/*     */     this.supportedInputs[0] = (Format)new AudioFormat(null);
/*     */     this.supportedOutputs = new ContentDescriptor[1];
/*     */     this.supportedOutputs[0] = (ContentDescriptor)new FileTypeDescriptor("audio.x_wav");
/*     */   }
/*     */   
/*     */   public Format setInputFormat(Format input, int trackID) {
/*  76 */     if (!(input instanceof AudioFormat))
/*  77 */       return null; 
/*  78 */     AudioFormat format = (AudioFormat)input;
/*  79 */     this.sampleRate = format.getSampleRate();
/*     */     
/*  81 */     String reason = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     this.audioFormat = format;
/*  96 */     if (format instanceof WavAudioFormat) {
/*  97 */       this.wavAudioFormat = (WavAudioFormat)format;
/*     */     }
/*     */     
/* 100 */     String encodingString = this.audioFormat.getEncoding();
/* 101 */     this.sampleSizeInBits = this.audioFormat.getSampleSizeInBits();
/*     */     
/* 103 */     if (encodingString.equalsIgnoreCase("LINEAR")) {
/* 104 */       if (this.sampleSizeInBits > 8) {
/*     */         
/* 106 */         if (this.audioFormat.getEndian() == 1) {
/* 107 */           return null;
/*     */         }
/* 109 */         if (this.audioFormat.getSigned() == 0) {
/* 110 */           return null;
/*     */         }
/*     */         
/* 113 */         if (this.audioFormat.getEndian() == -1 || this.audioFormat.getSigned() == -1)
/*     */         {
/* 115 */           format = (AudioFormat)this.audioFormat.intersects(this.signed);
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 120 */         if (this.audioFormat.getSigned() == 1) {
/* 121 */           return null;
/*     */         }
/*     */         
/* 124 */         if (this.audioFormat.getEndian() == -1 || this.audioFormat.getSigned() == -1)
/*     */         {
/* 126 */           format = (AudioFormat)this.audioFormat.intersects(this.unsigned);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 131 */     Integer formatTag = (Integer)WavAudioFormat.reverseFormatMapper.get(encodingString.toLowerCase());
/*     */ 
/*     */     
/* 134 */     if (formatTag == null) {
/* 135 */       reason = "Cannot handle format";
/* 136 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 141 */     this.wFormatTag = formatTag.shortValue();
/* 142 */     switch (this.wFormatTag) {
/*     */       case 2:
/*     */       case 17:
/*     */       case 49:
/* 146 */         if (this.wavAudioFormat == null) {
/* 147 */           reason = "A WavAudioFormat is required  to provide encoding specific information for this encoding " + this.wFormatTag;
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 153 */     if (this.wavAudioFormat != null) {
/* 154 */       this.codecSpecificHeader = this.wavAudioFormat.getCodecSpecificHeader();
/* 155 */       this.bytesPerSecond = this.wavAudioFormat.getAverageBytesPerSecond();
/*     */     } 
/*     */     
/* 158 */     this.sampleRate = this.audioFormat.getSampleRate();
/* 159 */     this.channels = this.audioFormat.getChannels();
/*     */     
/* 161 */     if (reason != null) {
/* 162 */       return null;
/*     */     }
/* 164 */     this.inputs[0] = (Format)format;
/* 165 */     return (Format)format;
/*     */   }
/*     */ 
/*     */   
/*     */   public int setNumTracks(int nTracks) {
/* 170 */     if (nTracks != 1) {
/* 171 */       return 1;
/*     */     }
/* 173 */     return super.setNumTracks(nTracks);
/*     */   }
/*     */   
/*     */   protected void writeHeader() {
/* 177 */     int formatSize = 16;
/* 178 */     bufClear();
/* 179 */     this.audioFormat = (AudioFormat)this.inputs[0];
/*     */     
/* 181 */     this.codecSpecificHeader = null;
/* 182 */     if (this.audioFormat instanceof WavAudioFormat)
/* 183 */       this.codecSpecificHeader = ((WavAudioFormat)this.audioFormat).getCodecSpecificHeader(); 
/* 184 */     if (this.codecSpecificHeader != null) {
/* 185 */       formatSize += 2 + this.codecSpecificHeader.length;
/*     */     }
/* 187 */     else if (this.wFormatTag == 85) {
/*     */       
/* 189 */       formatSize += 14;
/*     */     } 
/*     */ 
/*     */     
/* 193 */     bufWriteBytes("RIFF");
/* 194 */     bufWriteInt(0);
/* 195 */     bufWriteBytes("WAVE");
/*     */     
/* 197 */     bufWriteBytes("fmt ");
/*     */     
/* 199 */     bufWriteIntLittleEndian(formatSize);
/* 200 */     int frameSizeInBits = this.audioFormat.getFrameSizeInBits();
/* 201 */     if (frameSizeInBits > 0) {
/* 202 */       this.blockAlign = frameSizeInBits / 8;
/*     */     } else {
/* 204 */       this.blockAlign = this.sampleSizeInBits / 8 * this.channels;
/*     */     } 
/*     */ 
/*     */     
/* 208 */     bufWriteShortLittleEndian(this.wFormatTag);
/*     */     
/* 210 */     bufWriteShortLittleEndian((short)this.channels);
/*     */     
/* 212 */     bufWriteIntLittleEndian((int)this.sampleRate);
/*     */ 
/*     */     
/* 215 */     int frameRate = -1;
/* 216 */     if (this.wFormatTag == 85) {
/* 217 */       this.blockAlign = 1;
/* 218 */       frameRate = (int)this.audioFormat.getFrameRate();
/* 219 */       if (frameRate != -1) {
/* 220 */         this.bytesPerSecond = frameRate;
/*     */       }
/*     */     } 
/*     */     
/* 224 */     if (this.bytesPerSecond <= 0) {
/* 225 */       this.bytesPerSecond = this.channels * this.sampleSizeInBits * (int)this.sampleRate / 8;
/*     */     }
/*     */     
/* 228 */     bufWriteIntLittleEndian(this.bytesPerSecond);
/*     */     
/* 230 */     bufWriteShortLittleEndian((short)this.blockAlign);
/*     */     
/* 232 */     if (this.wFormatTag == 85) {
/* 233 */       bufWriteShortLittleEndian((short)0);
/*     */     } else {
/* 235 */       bufWriteShortLittleEndian((short)this.sampleSizeInBits);
/*     */     } 
/*     */     
/* 238 */     if (this.codecSpecificHeader != null) {
/* 239 */       bufWriteShortLittleEndian((short)this.codecSpecificHeader.length);
/* 240 */       bufWriteBytes(this.codecSpecificHeader);
/* 241 */     } else if (this.wFormatTag == 85) {
/*     */       char c;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 267 */       if (frameRate > 0) {
/* 268 */         float temp = 72.0F * frameRate * 8.0F / 8000.0F;
/* 269 */         temp = (float)(temp * 8000.0D / this.sampleRate);
/* 270 */         c = (int)temp;
/*     */       } else {
/* 272 */         c = 'ơ';
/*     */       } 
/*     */       
/* 275 */       bufWriteShortLittleEndian((short)12);
/* 276 */       bufWriteShortLittleEndian((short)1);
/* 277 */       bufWriteIntLittleEndian(2);
/* 278 */       bufWriteShortLittleEndian((short)c);
/* 279 */       bufWriteShortLittleEndian((short)1);
/* 280 */       bufWriteShortLittleEndian((short)1393);
/*     */     } 
/*     */     
/* 283 */     this.factChunkLength = 0;
/* 284 */     if (this.wFormatTag != 1) {
/*     */       
/* 286 */       bufWriteBytes("fact");
/* 287 */       bufWriteIntLittleEndian(4);
/* 288 */       this.numberOfSamplesOffset = this.filePointer;
/* 289 */       bufWriteInt(0);
/* 290 */       this.factChunkLength = 12;
/*     */     } 
/*     */     
/* 293 */     bufWriteBytes("data");
/* 294 */     this.dataSizeOffset = this.filePointer;
/* 295 */     bufWriteInt(0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 307 */     bufFlush();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writeFooter() {
/* 312 */     seek(4);
/* 313 */     bufClear();
/* 314 */     bufWriteIntLittleEndian(this.fileSize - 8);
/*     */     
/* 316 */     bufFlush();
/*     */     
/* 318 */     seek(this.dataSizeOffset);
/* 319 */     bufClear();
/* 320 */     int dataSize = this.fileSize - this.dataSizeOffset + 4;
/* 321 */     bufWriteIntLittleEndian(dataSize);
/* 322 */     bufFlush();
/* 323 */     if (this.factChunkLength > 0) {
/*     */ 
/*     */ 
/*     */       
/* 327 */       float duration = dataSize / this.bytesPerSecond;
/* 328 */       int numberOfSamples = (int)(duration * this.sampleRate);
/* 329 */       seek(this.numberOfSamplesOffset);
/* 330 */       bufClear();
/* 331 */       bufWriteIntLittleEndian(numberOfSamples);
/* 332 */       bufFlush();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\multiplexer\audio\WAVMux.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */