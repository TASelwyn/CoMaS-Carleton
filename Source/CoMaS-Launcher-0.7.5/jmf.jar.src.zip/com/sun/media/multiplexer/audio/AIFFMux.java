/*     */ package com.sun.media.multiplexer.audio;
/*     */ 
/*     */ import com.sun.media.multiplexer.BasicMux;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.FileTypeDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AIFFMux
/*     */   extends BasicMux
/*     */ {
/*     */   private Format format;
/*     */   private AudioFormat audioFormat;
/*     */   private int sampleSizeInBits;
/*     */   private double sampleRate;
/*     */   private int channels;
/*  47 */   private int blockAlign = 1;
/*     */   private int dataSizeOffset;
/*  49 */   private int maxFrames = 0;
/*  50 */   private int maxFramesOffset = 0;
/*     */   private String formType;
/*     */   private String aiffEncoding;
/*  53 */   private int headerSize = 0;
/*  54 */   private int dataSize = 0;
/*     */   
/*  56 */   private static int AIFCVersion1 = -1568648896;
/*     */ 
/*     */   
/*     */   private static final String FormID = "FORM";
/*     */ 
/*     */   
/*     */   private static final String FormatVersionID = "FVER";
/*     */ 
/*     */   
/*     */   private static final String CommonID = "COMM";
/*     */   
/*     */   private static final String SoundDataID = "SSND";
/*     */   
/*     */   private static final int CommonIDSize = 18;
/*     */   
/*     */   Format bigEndian;
/*     */ 
/*     */   
/*     */   public String getName() {
/*  75 */     return "AIFF Audio Multiplexer";
/*     */   }
/*     */   
/*     */   public int setNumTracks(int nTracks) {
/*  79 */     if (nTracks != 1) {
/*  80 */       return 1;
/*     */     }
/*  82 */     return super.setNumTracks(nTracks);
/*     */   }
/*     */   
/*     */   protected void writeHeader() {
/*  86 */     bufClear();
/*  87 */     bufWriteBytes("FORM");
/*  88 */     bufWriteInt(0);
/*  89 */     bufWriteBytes(this.formType);
/*     */     
/*  91 */     if (this.formType.equals("AIFC")) {
/*  92 */       bufWriteBytes("FVER");
/*  93 */       bufWriteInt(4);
/*  94 */       bufWriteInt(AIFCVersion1);
/*     */     } 
/*     */     
/*  97 */     bufWriteBytes("COMM");
/*  98 */     int commonIDSize = 18;
/*  99 */     if (this.formType.equals("AIFC")) {
/* 100 */       commonIDSize += 8;
/*     */     }
/*     */ 
/*     */     
/* 104 */     bufWriteInt(commonIDSize);
/*     */     
/* 106 */     bufWriteShort((short)this.channels);
/* 107 */     this.maxFramesOffset = this.filePointer;
/* 108 */     bufWriteInt(this.maxFrames);
/* 109 */     bufWriteShort((short)this.sampleSizeInBits);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     int exponent = 16398;
/*     */ 
/*     */     
/* 118 */     double highMantissa = this.sampleRate;
/* 119 */     while (highMantissa < 44000.0D) {
/* 120 */       highMantissa *= 2.0D;
/* 121 */       exponent--;
/*     */     } 
/* 123 */     bufWriteShort((short)exponent);
/* 124 */     bufWriteInt((int)highMantissa << 16);
/* 125 */     bufWriteInt(0);
/*     */ 
/*     */ 
/*     */     
/* 129 */     if (this.formType.equals("AIFC")) {
/* 130 */       bufWriteBytes(this.aiffEncoding);
/* 131 */       bufWriteBytes(this.aiffEncoding);
/*     */     } 
/*     */     
/* 134 */     bufWriteBytes("SSND");
/* 135 */     this.dataSizeOffset = this.filePointer;
/* 136 */     bufWriteInt(0);
/*     */ 
/*     */     
/* 139 */     bufWriteInt(0);
/* 140 */     bufWriteInt(0);
/* 141 */     bufFlush();
/* 142 */     this.headerSize = this.filePointer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AIFFMux() {
/* 148 */     this.bigEndian = (Format)new AudioFormat(null, -1.0D, -1, -1, 1, 1);
/*     */     this.supportedInputs = new Format[1];
/*     */     this.supportedInputs[0] = (Format)new AudioFormat(null);
/*     */     this.supportedOutputs = new ContentDescriptor[1];
/*     */     this.supportedOutputs[0] = (ContentDescriptor)new FileTypeDescriptor("audio.x_aiff");
/*     */   }
/*     */ 
/*     */   
/*     */   public Format setInputFormat(Format format, int trackID) {
/* 157 */     String reason = null;
/*     */     
/* 159 */     if (!(format instanceof AudioFormat)) {
/* 160 */       return null;
/*     */     }
/* 162 */     this.audioFormat = (AudioFormat)format;
/*     */     
/* 164 */     String encodingString = this.audioFormat.getEncoding();
/* 165 */     this.sampleSizeInBits = this.audioFormat.getSampleSizeInBits();
/* 166 */     this.sampleRate = this.audioFormat.getSampleRate();
/* 167 */     this.channels = this.audioFormat.getChannels();
/*     */     
/* 169 */     this.blockAlign = this.channels * this.sampleSizeInBits / 8;
/*     */     
/* 171 */     if (encodingString.equalsIgnoreCase("LINEAR")) {
/*     */       
/* 173 */       if (this.sampleSizeInBits > 8 && this.audioFormat.getEndian() == 0)
/*     */       {
/* 175 */         return null;
/*     */       }
/* 177 */       if (this.audioFormat.getSigned() == 0) {
/* 178 */         return null;
/*     */       }
/* 180 */       if (this.audioFormat.getEndian() == -1 || this.audioFormat.getSigned() == -1)
/*     */       {
/* 182 */         format = this.audioFormat.intersects(this.bigEndian);
/*     */       }
/*     */       
/* 185 */       this.formType = "AIFF";
/* 186 */       this.aiffEncoding = "NONE";
/*     */     }
/*     */     else {
/*     */       
/* 190 */       this.formType = "AIFC";
/* 191 */       if (encodingString.equalsIgnoreCase("ULAW")) {
/* 192 */         this.aiffEncoding = "ulaw";
/* 193 */       } else if (encodingString.equalsIgnoreCase("alaw")) {
/* 194 */         this.aiffEncoding = "alaw";
/* 195 */       } else if (encodingString.equalsIgnoreCase("ima4")) {
/* 196 */         this.aiffEncoding = "ima4";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 204 */         this.blockAlign = 34 * this.channels;
/* 205 */       } else if (encodingString.equalsIgnoreCase("MAC3")) {
/* 206 */         this.aiffEncoding = encodingString;
/*     */         
/* 208 */         this.blockAlign = 2;
/* 209 */       } else if (encodingString.equalsIgnoreCase("MAC6")) {
/* 210 */         this.aiffEncoding = encodingString;
/*     */         
/* 212 */         this.blockAlign = 1;
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 222 */         reason = "Cannot handle encoding " + encodingString;
/*     */       } 
/*     */     } 
/* 225 */     if (reason == null) {
/* 226 */       this.inputs[0] = format;
/* 227 */       return format;
/*     */     } 
/* 229 */     return null;
/*     */   }
/*     */   
/*     */   protected void writeFooter() {
/* 233 */     byte[] dummy = { 0 };
/*     */     
/* 235 */     this.dataSize = this.filePointer - this.headerSize;
/*     */     
/* 237 */     if ((this.filePointer & 0x1) != 0)
/*     */     {
/* 239 */       write(dummy, 0, 1);
/*     */     }
/*     */     
/* 242 */     bufClear();
/* 243 */     seek(4);
/* 244 */     bufWriteInt(this.fileSize);
/* 245 */     bufFlush();
/*     */     
/* 247 */     bufClear();
/* 248 */     seek(this.maxFramesOffset);
/* 249 */     this.maxFrames = this.dataSize / this.blockAlign;
/*     */     
/* 251 */     bufWriteInt(this.maxFrames);
/* 252 */     bufFlush();
/*     */     
/* 254 */     bufClear();
/* 255 */     seek(this.dataSizeOffset);
/* 256 */     bufWriteInt(this.dataSize + 8);
/* 257 */     bufFlush();
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\multiplexer\audio\AIFFMux.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */