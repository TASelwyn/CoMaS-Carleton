/*    */ package com.sun.media.multiplexer.audio;
/*    */ 
/*    */ import com.sun.media.multiplexer.BasicMux;
/*    */ import javax.media.Format;
/*    */ import javax.media.format.AudioFormat;
/*    */ import javax.media.protocol.ContentDescriptor;
/*    */ import javax.media.protocol.FileTypeDescriptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MPEGMux
/*    */   extends BasicMux
/*    */ {
/*    */   public MPEGMux() {
/* 41 */     this.supportedInputs = new Format[2];
/* 42 */     this.supportedInputs[0] = (Format)new AudioFormat("mpeglayer3");
/* 43 */     this.supportedInputs[1] = (Format)new AudioFormat("mpegaudio");
/*    */     
/* 45 */     this.supportedOutputs = new ContentDescriptor[1];
/* 46 */     this.supportedOutputs[0] = (ContentDescriptor)new FileTypeDescriptor("audio.mpeg");
/*    */   }
/*    */   
/*    */   public String getName() {
/* 50 */     return "MPEG Audio Multiplexer";
/*    */   }
/*    */   
/*    */   public Format setInputFormat(Format input, int trackID) {
/* 54 */     if (!(input instanceof AudioFormat))
/* 55 */       return null; 
/* 56 */     AudioFormat format = (AudioFormat)input;
/* 57 */     double sampleRate = format.getSampleRate();
/*    */     
/* 59 */     String reason = null;
/* 60 */     double epsilon = 0.25D;
/*    */ 
/*    */     
/* 63 */     if (!format.getEncoding().equalsIgnoreCase("mpeglayer3") && !format.getEncoding().equalsIgnoreCase("mpegaudio"))
/*    */     {
/* 65 */       reason = "Encoding has to be MPEG audio";
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 74 */     if (reason != null) {
/* 75 */       return null;
/*    */     }
/* 77 */     this.inputs[0] = (Format)format;
/* 78 */     return (Format)format;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\multiplexer\audio\MPEGMux.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */