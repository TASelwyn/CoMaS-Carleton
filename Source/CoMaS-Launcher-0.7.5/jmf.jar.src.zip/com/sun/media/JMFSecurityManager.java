/*     */ package com.sun.media;
/*     */ 
/*     */ import com.sun.media.util.Registry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JMFSecurityManager
/*     */ {
/*  13 */   private static JMFSecurity security = null;
/*  14 */   private static JMFSecurity enabledSecurity = null;
/*     */   private static SecurityManager securityManager;
/*  16 */   private static int count = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean DEBUG = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean jdk12 = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String STR_NOPERMCAPTURE = "No permission to capture from applets";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String STR_NOPERMFILE = "No permission to write files from applets";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  45 */     securityManager = System.getSecurityManager();
/*     */     
/*  47 */     boolean jdk11 = false;
/*  48 */     boolean msjvm = false;
/*     */ 
/*     */     
/*     */     try {
/*  52 */       String javaVersion = System.getProperty("java.version");
/*     */ 
/*     */ 
/*     */       
/*  56 */       if (!javaVersion.equals(""))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  69 */         if (javaVersion.startsWith("1.1")) {
/*     */ 
/*     */           
/*  72 */           jdk11 = true;
/*     */         } else {
/*     */           
/*  75 */           char c = javaVersion.charAt(0);
/*     */           
/*  77 */           if (c >= '0' && c <= '9' && 
/*  78 */             javaVersion.compareTo("1.2") >= 0)
/*     */           {
/*     */             
/*  81 */             jdk12 = true;
/*     */           }
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*  87 */       String javaVendor = System.getProperty("java.vendor", "Sun").toLowerCase();
/*     */ 
/*     */       
/*  90 */       if (javaVendor.indexOf("icrosoft") > 0) {
/*  91 */         msjvm = true;
/*     */       }
/*     */     }
/*     */     catch (Throwable t) {
/*     */       
/*  96 */       System.out.println(t);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     if (securityManager != null)
/*     */     {
/*     */ 
/*     */       
/* 107 */       if (securityManager.toString().indexOf("netscape") != -1) {
/*     */         
/* 109 */         security = NetscapeSecurity.security;
/* 110 */       } else if (securityManager.toString().indexOf("com.ms.security") != -1 || msjvm) {
/*     */         
/* 112 */         security = IESecurity.security;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 121 */       else if (securityManager.toString().indexOf("sun.applet.AppletSecurity") != -1 || securityManager.toString().indexOf("sun.plugin.ActivatorSecurityManager") != -1) {
/*     */ 
/*     */         
/* 124 */         if (jdk11)
/*     */         {
/*     */           
/* 127 */           security = DefaultSecurity.security;
/*     */         }
/*     */         
/* 130 */         if (jdk12)
/*     */         {
/* 132 */           security = JDK12Security.security;
/*     */         }
/*     */       }
/* 135 */       else if (securityManager.toString().indexOf("java.lang.SecurityManager") != -1) {
/*     */ 
/*     */         
/* 138 */         if (jdk12)
/*     */         {
/* 140 */           security = JDK12Security.security;
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 145 */       else if (jdk12) {
/* 146 */         security = JDK12Security.security;
/*     */       } else {
/* 148 */         security = DefaultSecurity.security;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     enabledSecurity = security;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JMFSecurity getJMFSecurity() throws SecurityException {
/* 186 */     return security;
/*     */   }
/*     */   
/*     */   public static boolean isLinkPermissionEnabled() {
/* 190 */     if (security == null) {
/* 191 */       return true;
/*     */     }
/* 193 */     return security.isLinkPermissionEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void loadLibrary(String name) throws UnsatisfiedLinkError {
/*     */     try {
/* 199 */       JMFSecurity s = getJMFSecurity();
/* 200 */       if (s != null) {
/* 201 */         s.loadLibrary(name);
/*     */       } else {
/* 203 */         System.loadLibrary(name);
/*     */       } 
/*     */     } catch (Throwable t) {
/* 206 */       throw new UnsatisfiedLinkError("JMFSecurityManager: " + t);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static synchronized void disableSecurityFeatures() {
/* 212 */     security = DisabledSecurity.security;
/* 213 */     count++;
/*     */   }
/*     */   
/*     */   public static synchronized void enableSecurityFeatures() {
/* 217 */     count--;
/* 218 */     if (count <= 0) {
/* 219 */       security = enabledSecurity;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkCapture() {
/* 229 */     if (security == null) {
/*     */       return;
/*     */     }
/* 232 */     Object captureFromApplets = Registry.get("secure.allowCaptureFromApplets");
/*     */     
/* 234 */     if (captureFromApplets == null || !(captureFromApplets instanceof Boolean) || !((Boolean)captureFromApplets).booleanValue())
/*     */     {
/*     */       
/* 237 */       throw new RuntimeException("No permission to capture from applets");
/*     */     }
/*     */   }
/*     */   
/*     */   public static void checkFileSave() {
/* 242 */     if (security == null) {
/*     */       return;
/*     */     }
/* 245 */     Object saveFromApplets = Registry.get("secure.allowSaveFileFromApplets");
/*     */     
/* 247 */     if (saveFromApplets == null || !(saveFromApplets instanceof Boolean) || !((Boolean)saveFromApplets).booleanValue())
/*     */     {
/*     */       
/* 250 */       throw new RuntimeException("No permission to write files from applets"); } 
/*     */   }
/*     */   
/*     */   public static boolean isJDK12() {
/* 254 */     return jdk12;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\JMFSecurityManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */