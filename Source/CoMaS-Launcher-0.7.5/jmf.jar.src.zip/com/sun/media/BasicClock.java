/*     */ package com.sun.media;
/*     */ 
/*     */ import javax.media.Clock;
/*     */ import javax.media.ClockStartedError;
/*     */ import javax.media.ClockStoppedException;
/*     */ import javax.media.IncompatibleTimeBaseException;
/*     */ import javax.media.StopTimeSetError;
/*     */ import javax.media.SystemTimeBase;
/*     */ import javax.media.Time;
/*     */ import javax.media.TimeBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicClock
/*     */   implements Clock
/*     */ {
/*     */   private TimeBase master;
/*  21 */   private long startTime = Long.MAX_VALUE;
/*  22 */   private long stopTime = Long.MAX_VALUE;
/*  23 */   private long mediaTime = 0L;
/*     */   
/*  25 */   private long mediaStart = 0L;
/*  26 */   private long mediaLength = -1L;
/*  27 */   private float rate = 1.0F;
/*     */   
/*     */   public static final int STOPPED = 0;
/*     */   public static final int STARTED = 1;
/*     */   
/*     */   public BasicClock() {
/*  33 */     this.master = (TimeBase)new SystemTimeBase();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeBase(TimeBase master) throws IncompatibleTimeBaseException {
/*  46 */     if (getState() == 1) {
/*  47 */       throwError((Error)new ClockStartedError("setTimeBase cannot be used on a started clock."));
/*     */     }
/*  49 */     if (master == null) {
/*  50 */       if (!(this.master instanceof SystemTimeBase))
/*  51 */         this.master = (TimeBase)new SystemTimeBase(); 
/*     */     } else {
/*  53 */       this.master = master;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void syncStart(Time tbt) {
/*  61 */     if (getState() == 1) {
/*  62 */       throwError((Error)new ClockStartedError("syncStart() cannot be used on an already started clock."));
/*     */     }
/*     */ 
/*     */     
/*  66 */     if (this.master.getNanoseconds() > tbt.getNanoseconds()) {
/*  67 */       this.startTime = this.master.getNanoseconds();
/*     */     } else {
/*  69 */       this.startTime = tbt.getNanoseconds();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/*  76 */     if (getState() == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  82 */     this.mediaTime = getMediaNanoseconds();
/*     */ 
/*     */     
/*  85 */     this.startTime = Long.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStopTime(Time t) {
/*  93 */     if (getState() == 1 && this.stopTime != Long.MAX_VALUE) {
/*  94 */       throwError((Error)new StopTimeSetError("setStopTime() may be set only once on a Started Clock"));
/*     */     }
/*  96 */     this.stopTime = t.getNanoseconds();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Time getStopTime() {
/* 104 */     return new Time(this.stopTime);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMediaTime(Time now) {
/* 113 */     if (getState() == 1) {
/* 114 */       throwError((Error)new ClockStartedError("setMediaTime() cannot be used on a started clock."));
/*     */     }
/* 116 */     long t = now.getNanoseconds();
/* 117 */     if (t < this.mediaStart) {
/* 118 */       this.mediaTime = this.mediaStart;
/* 119 */     } else if (this.mediaLength != -1L && t > this.mediaStart + this.mediaLength) {
/* 120 */       this.mediaTime = this.mediaStart + this.mediaLength;
/*     */     } else {
/* 122 */       this.mediaTime = t;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Time getMediaTime() {
/* 130 */     return new Time(getMediaNanoseconds());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMediaNanoseconds() {
/* 138 */     if (getState() == 0) {
/* 139 */       return this.mediaTime;
/*     */     }
/*     */     
/* 142 */     long now = this.master.getNanoseconds();
/* 143 */     if (now > this.startTime) {
/*     */       
/* 145 */       long t = (long)((now - this.startTime) * this.rate) + this.mediaTime;
/* 146 */       if (this.mediaLength != -1L && t > this.mediaStart + this.mediaLength) {
/* 147 */         return this.mediaStart + this.mediaLength;
/*     */       }
/* 149 */       return t;
/*     */     } 
/*     */     
/* 152 */     return this.mediaTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setMediaStart(long t) {
/* 161 */     this.mediaStart = t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setMediaLength(long t) {
/* 169 */     this.mediaLength = t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getState() {
/* 180 */     if (this.startTime == Long.MAX_VALUE) {
/* 181 */       return 0;
/*     */     }
/*     */     
/* 184 */     if (this.stopTime == Long.MAX_VALUE) {
/* 185 */       return 1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 208 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Time getSyncTime() {
/* 216 */     return new Time(0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TimeBase getTimeBase() {
/* 224 */     return this.master;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Time mapToTimeBase(Time t) throws ClockStoppedException {
/* 235 */     if (getState() == 0) {
/* 236 */       ClockStoppedException e = new ClockStoppedException();
/* 237 */       Log.dumpStack((Throwable)e);
/* 238 */       throw e;
/*     */     } 
/* 240 */     return new Time((long)((float)(t.getNanoseconds() - this.mediaTime) / this.rate) + this.startTime);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float setRate(float factor) {
/* 250 */     if (getState() == 1) {
/* 251 */       throwError((Error)new ClockStartedError("setRate() cannot be used on a started clock."));
/*     */     }
/* 253 */     this.rate = factor;
/* 254 */     return this.rate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getRate() {
/* 262 */     return this.rate;
/*     */   }
/*     */   
/*     */   protected void throwError(Error e) {
/* 266 */     Log.dumpStack(e);
/* 267 */     throw e;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\BasicClock.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */