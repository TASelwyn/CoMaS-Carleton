/*     */ package com.sun.media.processor.rtp;
/*     */ import com.sun.media.BasicController;
/*     */ import com.sun.media.BasicPlayer;
/*     */ import com.sun.media.BasicProcessor;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.protocol.rtp.DataSource;
/*     */ import com.sun.media.rtp.RTPMediaLocator;
/*     */ import com.sun.media.rtp.RTPSessionMgr;
/*     */ import java.awt.Component;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetAddress;
/*     */ import java.util.Vector;
/*     */ import javax.media.Control;
/*     */ import javax.media.Controller;
/*     */ import javax.media.ControllerErrorEvent;
/*     */ import javax.media.ControllerEvent;
/*     */ import javax.media.ControllerListener;
/*     */ import javax.media.Format;
/*     */ import javax.media.IncompatibleSourceException;
/*     */ import javax.media.IncompatibleTimeBaseException;
/*     */ import javax.media.Manager;
/*     */ import javax.media.MediaLocator;
/*     */ import javax.media.NotConfiguredError;
/*     */ import javax.media.NotRealizedError;
/*     */ import javax.media.Player;
/*     */ import javax.media.Processor;
/*     */ import javax.media.SystemTimeBase;
/*     */ import javax.media.TimeBase;
/*     */ import javax.media.control.TrackControl;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.rtp.RTPControl;
/*     */ import javax.media.rtp.RTPManager;
/*     */ import javax.media.rtp.RTPPushDataSource;
/*     */ import javax.media.rtp.RTPSocket;
/*     */ import javax.media.rtp.ReceiveStream;
/*     */ import javax.media.rtp.ReceiveStreamListener;
/*     */ import javax.media.rtp.SessionAddress;
/*     */ import javax.media.rtp.event.NewReceiveStreamEvent;
/*     */ import javax.media.rtp.event.ReceiveStreamEvent;
/*     */ 
/*     */ public class Handler extends BasicProcessor implements ReceiveStreamListener {
/*  46 */   RTPSessionMgr[] mgrs = null;
/*  47 */   DataSource[] sources = null;
/*  48 */   Processor processor = null;
/*  49 */   Format[] formats = null;
/*  50 */   Vector locators = null;
/*     */   
/*  52 */   Object dataLock = new Object();
/*     */   
/*     */   boolean dataReady = false;
/*     */   
/*     */   private boolean closed = false;
/*     */   private boolean audioEnabled = false;
/*     */   private boolean videoEnabled = false;
/*  59 */   private static JMFSecurity jmfSecurity = null;
/*     */   private static boolean securityPrivelege = false;
/*  61 */   private Method[] m = new Method[1];
/*  62 */   private Class[] cl = new Class[1]; String sessionError; Object closeSync;
/*  63 */   private Object[][] args = new Object[1][0];
/*     */   protected synchronized boolean doConfigure() { super.doConfigure(); try { if (((BasicPlayer)this).source instanceof RTPSocket) { this.mgrs = new RTPSessionMgr[1]; this.mgrs[1] = new RTPSessionMgr((RTPPushDataSource)((BasicPlayer)this).source); this.mgrs[1].addReceiveStreamListener(this); this.sources = new DataSource[1]; this.sources[0] = ((BasicPlayer)this).source; this.formats = new Format[1]; this.dataReady = false; } else { SessionAddress localAddr = new SessionAddress(); this.mgrs = new RTPSessionMgr[this.locators.size()]; this.sources = new DataSource[this.locators.size()]; this.formats = new Format[this.locators.size()]; this.dataReady = false; for (int i = 0; i < this.locators.size(); i++) { SessionAddress sessionAddress; RTPMediaLocator rml = this.locators.elementAt(i); this.mgrs[i] = (RTPSessionMgr)RTPManager.newInstance(); this.mgrs[i].addReceiveStreamListener(this); InetAddress ipAddr = InetAddress.getByName(rml.getSessionAddress()); if (ipAddr.isMulticastAddress()) { localAddr = new SessionAddress(ipAddr, rml.getSessionPort(), rml.getTTL()); sessionAddress = new SessionAddress(ipAddr, rml.getSessionPort(), rml.getTTL()); } else { localAddr = new SessionAddress(InetAddress.getLocalHost(), rml.getSessionPort()); sessionAddress = new SessionAddress(ipAddr, rml.getSessionPort()); }  this.mgrs[i].initialize(localAddr); this.mgrs[i].addTarget(sessionAddress); }  }  }
/*     */     catch (Exception e) { Log.error("Cannot create the RTP Session: " + e.getMessage()); ((BasicController)this).processError = this.sessionError; return false; }
/*     */      try { synchronized (this.dataLock) { while (!this.dataReady && !isInterrupted() && !this.closed)
/*     */           this.dataLock.wait();  }
/*     */        }
/*     */     catch (Exception e) {} if (this.closed || isInterrupted()) { resetInterrupt(); ((BasicController)this).processError = "no RTP data was received."; return false; }
/*  70 */      return true; } public Handler() { this.sessionError = "cannot create and initialize the RTP Session.";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 174 */     this.closeSync = new Object();
/*     */     ((BasicPlayer)this).framePositioning = false; }
/*     */    private void closeSessions() {
/* 177 */     synchronized (this.closeSync) {
/* 178 */       for (int i = 0; i < this.mgrs.length; i++) {
/* 179 */         if (this.mgrs[i] != null) {
/* 180 */           this.mgrs[i].removeTargets("Closing session from the RTP Handler");
/* 181 */           this.mgrs[i].dispose();
/* 182 */           this.mgrs[i] = null;
/*     */         } 
/*     */       } 
/*     */     }  } protected void completeConfigure() { ((BasicController)this).state = 180;
/*     */     super.completeConfigure(); }
/*     */   protected void doFailedConfigure() { closeSessions();
/*     */     super.doFailedConfigure(); }
/*     */   protected boolean doRealize() {
/* 190 */     return waitForRealize(this.processor);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void completeRealize() {
/* 195 */     ((BasicController)this).state = 300;
/* 196 */     super.completeRealize();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doFailedRealize() {
/* 201 */     closeSessions();
/* 202 */     super.doFailedRealize();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doStart() {
/* 207 */     super.doStart();
/* 208 */     waitForStart((Player)this.processor);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doStop() {
/* 213 */     super.doStop();
/* 214 */     waitForStop((Player)this.processor);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doDeallocate() {
/* 219 */     this.processor.deallocate();
/* 220 */     synchronized (this.dataLock) {
/* 221 */       this.dataLock.notifyAll();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void doClose() {
/* 226 */     this.closed = true;
/*     */     
/* 228 */     synchronized (this.dataLock) {
/* 229 */       this.dataLock.notify();
/*     */     } 
/*     */     
/* 232 */     stop();
/*     */     
/* 234 */     if (this.processor != null) {
/* 235 */       this.processor.close();
/*     */     }
/*     */     
/* 238 */     closeSessions();
/*     */     
/* 240 */     super.doClose();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTimeBase(TimeBase tb) throws IncompatibleTimeBaseException {}
/*     */   
/*     */   protected TimeBase getMasterTimeBase() {
/* 247 */     return (TimeBase)new SystemTimeBase();
/*     */   }
/*     */   
/*     */   protected boolean audioEnabled() {
/* 251 */     return this.audioEnabled;
/*     */   }
/*     */   
/*     */   protected boolean videoEnabled() {
/* 255 */     return this.videoEnabled;
/*     */   }
/*     */   
/*     */   private void sendMyEvent(ControllerEvent e) {
/* 259 */     sendEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public void update(ReceiveStreamEvent event) {
/* 264 */     RTPSessionMgr mgr = (RTPSessionMgr)event.getSource();
/*     */     
/*     */     int idx;
/* 267 */     for (idx = 0; idx < this.mgrs.length && 
/* 268 */       this.mgrs[idx] != mgr; idx++);
/*     */ 
/*     */ 
/*     */     
/* 272 */     if (idx >= this.mgrs.length) {
/*     */       
/* 274 */       System.err.println("Unknown manager: " + mgr);
/*     */       
/*     */       return;
/*     */     } 
/* 278 */     if (event instanceof javax.media.rtp.event.RemotePayloadChangeEvent) {
/*     */       
/* 280 */       Log.comment("Received an RTP PayloadChangeEvent");
/* 281 */       Log.error("The RTP processor cannot handle mid-stream payload change.\n");
/* 282 */       sendEvent((ControllerEvent)new ControllerErrorEvent((Controller)this, "Cannot handle mid-stream payload change."));
/* 283 */       close();
/*     */     } 
/*     */ 
/*     */     
/* 287 */     if (event instanceof NewReceiveStreamEvent) {
/*     */       
/* 289 */       if (this.sources[idx] != null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 294 */       ReceiveStream stream = null;
/*     */       try {
/*     */         DataSource mixDS;
/* 297 */         stream = ((NewReceiveStreamEvent)event).getReceiveStream();
/* 298 */         this.sources[idx] = stream.getDataSource();
/*     */         
/* 300 */         RTPControl ctl = (RTPControl)this.sources[idx].getControl("javax.media.rtp.RTPControl");
/* 301 */         if (ctl != null) {
/* 302 */           this.formats[idx] = ctl.getFormat();
/* 303 */           if (this.formats[idx] instanceof AudioFormat)
/* 304 */             this.audioEnabled = true; 
/* 305 */           if (this.formats[idx] instanceof javax.media.format.VideoFormat) {
/* 306 */             this.videoEnabled = true;
/*     */           }
/*     */         } 
/* 309 */         if (((BasicPlayer)this).source instanceof RTPSocket) {
/* 310 */           ((RTPSocket)((BasicPlayer)this).source).setChild(this.sources[idx]);
/*     */         } else {
/* 312 */           ((DataSource)((BasicPlayer)this).source).setChild((DataSource)this.sources[idx]);
/*     */         } 
/*     */         
/* 315 */         for (int i = 0; i < this.sources.length; i++) {
/*     */           
/* 317 */           if (this.sources[i] == null) {
/*     */             return;
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 326 */           mixDS = Manager.createMergingDataSource(this.sources);
/*     */         } catch (Exception e) {
/* 328 */           System.err.println("Cannot merge data sources.");
/*     */           
/*     */           return;
/*     */         } 
/*     */         try {
/* 333 */           this.processor = Manager.createProcessor(mixDS);
/*     */         } catch (Exception e) {
/* 335 */           System.err.println("Cannot create the mix processor.");
/*     */           
/*     */           return;
/*     */         } 
/* 339 */         if (!waitForConfigure(this.processor)) {
/*     */           return;
/*     */         }
/*     */         
/* 343 */         synchronized (this.dataLock) {
/* 344 */           this.dataReady = true;
/* 345 */           this.dataLock.notifyAll();
/*     */         } 
/*     */       } catch (Exception e) {
/*     */         
/* 349 */         System.err.println("NewReceiveStreamEvent exception " + e.getMessage());
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
/* 361 */     super.setSource(source);
/* 362 */     if (source instanceof DataSource) {
/* 363 */       MediaLocator ml = source.getLocator();
/* 364 */       String mlStr = ml.getRemainder();
/*     */ 
/*     */ 
/*     */       
/* 368 */       int start = 0;
/* 369 */       while (mlStr.charAt(start) == '/')
/* 370 */         start++; 
/* 371 */       this.locators = new Vector();
/*     */       try {
/*     */         String str;
/*     */         int idx;
/* 375 */         while (start < mlStr.length() && (idx = mlStr.indexOf("&", start)) != -1) {
/* 376 */           str = mlStr.substring(start, idx);
/* 377 */           RTPMediaLocator rml = new RTPMediaLocator("rtp://" + str);
/* 378 */           this.locators.addElement(rml);
/* 379 */           start = idx + 1;
/*     */         } 
/* 381 */         if (start != 0) {
/* 382 */           str = mlStr.substring(start);
/*     */         } else {
/* 384 */           str = mlStr;
/* 385 */         }  RTPMediaLocator rTPMediaLocator = new RTPMediaLocator("rtp://" + str);
/* 386 */         this.locators.addElement(rTPMediaLocator);
/*     */       } catch (Exception e) {
/*     */         
/* 389 */         throw new IncompatibleSourceException();
/*     */       }
/*     */     
/* 392 */     } else if (!(source instanceof RTPSocket)) {
/* 393 */       throw new IncompatibleSourceException();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 398 */     RTPControl ctl = (RTPControl)source.getControl("javax.media.rtp.RTPControl");
/*     */     
/* 400 */     if (ctl != null) {
/* 401 */       ctl.addFormat((Format)new AudioFormat("dvi/rtp", 44100.0D, 4, 1), 18);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void invalidateComp() {
/* 409 */     ((BasicPlayer)this).controlComp = null;
/* 410 */     ((BasicPlayer)this).controls = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getVisualComponent() {
/* 422 */     super.getVisualComponent();
/* 423 */     return this.processor.getVisualComponent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Control[] getControls() {
/* 432 */     return this.processor.getControls();
/*     */   }
/*     */   
/*     */   public void updateStats() {
/* 436 */     if (this.processor != null) {
/* 437 */       ((BasicProcessor)this.processor).updateStats();
/*     */     }
/*     */   }
/*     */   
/*     */   public TrackControl[] getTrackControls() throws NotConfiguredError {
/* 442 */     super.getTrackControls();
/* 443 */     return this.processor.getTrackControls();
/*     */   }
/*     */ 
/*     */   
/*     */   public ContentDescriptor[] getSupportedContentDescriptors() throws NotConfiguredError {
/* 448 */     super.getSupportedContentDescriptors();
/* 449 */     return this.processor.getSupportedContentDescriptors();
/*     */   }
/*     */ 
/*     */   
/*     */   public ContentDescriptor setContentDescriptor(ContentDescriptor ocd) throws NotConfiguredError {
/* 454 */     super.setContentDescriptor(ocd);
/* 455 */     return this.processor.setContentDescriptor(ocd);
/*     */   }
/*     */ 
/*     */   
/*     */   public ContentDescriptor getContentDescriptor() throws NotConfiguredError {
/* 460 */     super.getContentDescriptor();
/* 461 */     return this.processor.getContentDescriptor();
/*     */   }
/*     */   
/*     */   public DataSource getDataOutput() throws NotRealizedError {
/* 465 */     super.getDataOutput();
/* 466 */     return this.processor.getDataOutput();
/*     */   }
/*     */   
/*     */   private boolean waitForConfigure(Processor p) {
/* 470 */     return (new StateWaiter(this)).waitForConfigure(p);
/*     */   }
/*     */   
/*     */   private boolean waitForRealize(Processor p) {
/* 474 */     return (new StateWaiter(this)).waitForRealize(p);
/*     */   }
/*     */   
/*     */   private void waitForStart(Player p) {
/* 478 */     (new StateWaiter(this)).waitForStart(p, true);
/*     */   }
/*     */   
/*     */   private void waitForStop(Player p) {
/* 482 */     (new StateWaiter(this)).waitForStart(p, false);
/*     */   }
/*     */   
/*     */   private void waitForClose(Player p) {
/* 486 */     (new StateWaiter(this)).waitForClose(p);
/*     */   } class StateWaiter implements ControllerListener { boolean closeDown; Object stateLock; private final Handler this$0;
/*     */     StateWaiter(Handler this$0) {
/* 489 */       this.this$0 = this$0;
/* 490 */       this.closeDown = false;
/* 491 */       this.stateLock = new Object();
/*     */     }
/*     */     public boolean waitForConfigure(Processor p) {
/* 494 */       p.addControllerListener(this);
/* 495 */       p.configure();
/* 496 */       synchronized (this.stateLock) {
/* 497 */         while (p.getState() != 180 && !this.closeDown) {
/*     */           try {
/* 499 */             this.stateLock.wait(1000L);
/*     */           }
/* 501 */           catch (InterruptedException ie) {
/*     */             break;
/*     */           } 
/*     */         } 
/* 505 */       }  p.removeControllerListener(this);
/* 506 */       return !this.closeDown;
/*     */     }
/*     */     
/*     */     public boolean waitForRealize(Processor p) {
/* 510 */       p.addControllerListener(this);
/* 511 */       p.realize();
/* 512 */       synchronized (this.stateLock) {
/* 513 */         while (p.getState() != 300 && !this.closeDown) {
/*     */           try {
/* 515 */             this.stateLock.wait(1000L);
/*     */           }
/* 517 */           catch (InterruptedException ie) {
/*     */             break;
/*     */           } 
/*     */         } 
/* 521 */       }  p.removeControllerListener(this);
/* 522 */       return !this.closeDown;
/*     */     }
/*     */     
/*     */     public void waitForStart(Player p, boolean startOn) {
/* 526 */       p.addControllerListener(this);
/* 527 */       if (startOn) {
/* 528 */         p.start();
/*     */       } else {
/* 530 */         p.stop();
/* 531 */       }  synchronized (this.stateLock) {
/*     */         
/* 533 */         while (((startOn && p.getState() != 600) || (!startOn && p.getState() == 600)) && !this.closeDown) {
/*     */           
/*     */           try {
/* 536 */             this.stateLock.wait(1000L);
/*     */           }
/* 538 */           catch (InterruptedException ie) {
/*     */             break;
/*     */           } 
/*     */         } 
/* 542 */       }  p.removeControllerListener(this);
/*     */     }
/*     */     
/*     */     public void waitForClose(Player p) {
/* 546 */       p.addControllerListener(this);
/* 547 */       p.close();
/* 548 */       synchronized (this.stateLock) {
/* 549 */         while (!this.closeDown) {
/*     */           try {
/* 551 */             this.stateLock.wait(1000L);
/*     */           }
/* 553 */           catch (InterruptedException ie) {
/*     */             break;
/*     */           } 
/*     */         } 
/* 557 */       }  p.removeControllerListener(this);
/*     */     }
/*     */     
/*     */     public void controllerUpdate(ControllerEvent ce) {
/* 561 */       if (ce instanceof javax.media.ControllerClosedEvent || ce instanceof ControllerErrorEvent)
/*     */       {
/* 563 */         this.closeDown = true;
/*     */       }
/* 565 */       synchronized (this.stateLock) {
/* 566 */         this.stateLock.notify();
/*     */       } 
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\processor\rtp\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */