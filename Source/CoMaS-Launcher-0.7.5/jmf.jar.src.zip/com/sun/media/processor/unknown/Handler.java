package com.sun.media.processor.unknown;

import com.sun.media.MediaProcessor;

public class Handler extends MediaProcessor {}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\processo\\unknown\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */