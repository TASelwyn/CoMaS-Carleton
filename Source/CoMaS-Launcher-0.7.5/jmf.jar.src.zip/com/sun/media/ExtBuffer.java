/*    */ package com.sun.media;
/*    */ 
/*    */ import javax.media.Buffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExtBuffer
/*    */   extends Buffer
/*    */ {
/* 13 */   protected NBA nativeData = null;
/*    */   
/*    */   protected boolean nativePreferred = false;
/*    */ 
/*    */   
/*    */   public void setNativeData(NBA nativeData) {
/* 19 */     this.nativeData = nativeData;
/*    */   }
/*    */   
/*    */   public NBA getNativeData() {
/* 23 */     return this.nativeData;
/*    */   }
/*    */   
/*    */   public boolean isNativePreferred() {
/* 27 */     return this.nativePreferred;
/*    */   }
/*    */   
/*    */   public void setNativePreferred(boolean prefer) {
/* 31 */     this.nativePreferred = prefer;
/*    */   }
/*    */   
/*    */   public Object getData() {
/* 35 */     if (this.nativeData != null) {
/* 36 */       return this.nativeData.getData();
/*    */     }
/* 38 */     return this.data;
/*    */   }
/*    */   
/*    */   public void setData(Object data) {
/* 42 */     this.nativeData = null;
/* 43 */     this.data = data;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void copy(Buffer buffer, boolean swap) {
/* 52 */     super.copy(buffer, swap);
/* 53 */     if (buffer instanceof ExtBuffer) {
/* 54 */       ExtBuffer fromBuf = (ExtBuffer)buffer;
/* 55 */       if (swap) {
/* 56 */         NBA temp = fromBuf.nativeData;
/* 57 */         fromBuf.nativeData = this.nativeData;
/* 58 */         this.nativeData = temp;
/* 59 */         boolean prefer = fromBuf.nativePreferred;
/* 60 */         fromBuf.nativePreferred = this.nativePreferred;
/* 61 */         this.nativePreferred = prefer;
/*    */       } else {
/* 63 */         this.nativeData = fromBuf.nativeData;
/* 64 */         this.nativePreferred = fromBuf.nativePreferred;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\ExtBuffer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */