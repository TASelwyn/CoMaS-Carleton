package com.sun.media;

import javax.media.Buffer;

public class ExtBuffer extends Buffer {
  protected NBA nativeData = null;
  
  protected boolean nativePreferred = false;
  
  public void setNativeData(NBA nativeData) {
    this.nativeData = nativeData;
  }
  
  public NBA getNativeData() {
    return this.nativeData;
  }
  
  public boolean isNativePreferred() {
    return this.nativePreferred;
  }
  
  public void setNativePreferred(boolean prefer) {
    this.nativePreferred = prefer;
  }
  
  public Object getData() {
    if (this.nativeData != null)
      return this.nativeData.getData(); 
    return this.data;
  }
  
  public void setData(Object data) {
    this.nativeData = null;
    this.data = data;
  }
  
  public void copy(Buffer buffer, boolean swap) {
    super.copy(buffer, swap);
    if (buffer instanceof ExtBuffer) {
      ExtBuffer fromBuf = (ExtBuffer)buffer;
      if (swap) {
        NBA temp = fromBuf.nativeData;
        fromBuf.nativeData = this.nativeData;
        this.nativeData = temp;
        boolean prefer = fromBuf.nativePreferred;
        fromBuf.nativePreferred = this.nativePreferred;
        this.nativePreferred = prefer;
      } else {
        this.nativeData = fromBuf.nativeData;
        this.nativePreferred = fromBuf.nativePreferred;
      } 
    } 
  }
}
