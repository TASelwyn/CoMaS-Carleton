package com.sun.media.util;

import java.lang.reflect.Constructor;
import java.net.URLConnection;
import java.security.PrivilegedAction;

public class jdk12ConnectionAction implements PrivilegedAction {
  public static Constructor cons;
  
  private URLConnection urlC;
  
  static {
    try {
      cons = jdk12ConnectionAction.class.getConstructor(new Class[] { URLConnection.class });
    } catch (Throwable e) {}
  }
  
  public jdk12ConnectionAction(URLConnection urlC) {
    try {
      this.urlC = urlC;
    } catch (Throwable e) {}
  }
  
  public Object run() {
    try {
      return this.urlC.getInputStream();
    } catch (Throwable t) {
      return null;
    } 
  }
}
