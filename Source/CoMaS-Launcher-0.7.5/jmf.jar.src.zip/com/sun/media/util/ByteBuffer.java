/*    */ package com.sun.media.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteBuffer
/*    */ {
/*    */   public byte[] buffer;
/*    */   public int offset;
/*    */   public int length;
/*    */   public int size;
/*    */   
/*    */   public ByteBuffer(int size) {
/* 17 */     this.size = size;
/* 18 */     this.buffer = new byte[size];
/*    */   }
/*    */   
/*    */   public final void clear() {
/* 22 */     this.offset = 0;
/* 23 */     this.length = 0;
/*    */   }
/*    */   
/*    */   public final void writeBytes(String s) {
/* 27 */     byte[] bytes = s.getBytes();
/* 28 */     writeBytes(bytes);
/*    */   }
/*    */   
/*    */   public final void writeBytes(byte[] bytes) {
/* 32 */     System.arraycopy(bytes, 0, this.buffer, this.offset, bytes.length);
/*    */     
/* 34 */     this.offset += bytes.length;
/* 35 */     this.length += bytes.length;
/*    */   }
/*    */   
/*    */   public final void writeInt(int value) {
/* 39 */     this.buffer[this.offset + 0] = (byte)(value >> 24 & 0xFF);
/* 40 */     this.buffer[this.offset + 1] = (byte)(value >> 16 & 0xFF);
/* 41 */     this.buffer[this.offset + 2] = (byte)(value >> 8 & 0xFF);
/* 42 */     this.buffer[this.offset + 3] = (byte)(value >> 0 & 0xFF);
/* 43 */     this.offset += 4;
/* 44 */     this.length += 4;
/*    */   }
/*    */   
/*    */   public final void writeIntLittleEndian(int value) {
/* 48 */     this.buffer[this.offset + 3] = (byte)(value >>> 24 & 0xFF);
/* 49 */     this.buffer[this.offset + 2] = (byte)(value >>> 16 & 0xFF);
/* 50 */     this.buffer[this.offset + 1] = (byte)(value >>> 8 & 0xFF);
/* 51 */     this.buffer[this.offset + 0] = (byte)(value >>> 0 & 0xFF);
/* 52 */     this.offset += 4;
/* 53 */     this.length += 4;
/*    */   }
/*    */   
/*    */   public final void writeShort(short value) {
/* 57 */     this.buffer[this.offset + 0] = (byte)(value >> 8 & 0xFF);
/* 58 */     this.buffer[this.offset + 1] = (byte)(value >> 0 & 0xFF);
/* 59 */     this.offset += 2;
/* 60 */     this.length += 2;
/*    */   }
/*    */   
/*    */   public final void writeShortLittleEndian(short value) {
/* 64 */     this.buffer[this.offset + 1] = (byte)(value >> 8 & 0xFF);
/* 65 */     this.buffer[this.offset + 0] = (byte)(value >> 0 & 0xFF);
/* 66 */     this.offset += 2;
/* 67 */     this.length += 2;
/*    */   }
/*    */   
/*    */   public final void writeByte(byte value) {
/* 71 */     this.buffer[this.offset] = value;
/* 72 */     this.offset++;
/* 73 */     this.length++;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\util\ByteBuffer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */