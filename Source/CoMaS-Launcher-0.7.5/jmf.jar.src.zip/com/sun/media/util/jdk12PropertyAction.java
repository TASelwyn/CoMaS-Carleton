/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class jdk12PropertyAction
/*    */   implements PrivilegedAction
/*    */ {
/*    */   public static Constructor cons;
/*    */   private String name;
/*    */   
/*    */   static {
/*    */     try {
/* 20 */       cons = jdk12PropertyAction.class.getConstructor(new Class[] { String.class });
/*    */     }
/* 22 */     catch (Throwable e) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public jdk12PropertyAction(String name) {
/*    */     try {
/* 30 */       this.name = name;
/* 31 */     } catch (Throwable e) {}
/*    */   }
/*    */ 
/*    */   
/*    */   public Object run() {
/*    */     try {
/* 37 */       return System.getProperty(this.name);
/*    */     } catch (Throwable t) {
/* 39 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\util\jdk12PropertyAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */