package com.sun.media.util;

public interface RTPInfo {
  String getCNAME();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\util\RTPInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */