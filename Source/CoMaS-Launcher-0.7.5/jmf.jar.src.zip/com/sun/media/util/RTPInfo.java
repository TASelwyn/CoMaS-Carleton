package com.sun.media.util;

public interface RTPInfo {
  String getCNAME();
}
