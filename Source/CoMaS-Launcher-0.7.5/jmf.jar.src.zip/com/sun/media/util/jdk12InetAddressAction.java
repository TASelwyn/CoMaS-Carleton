package com.sun.media.util;

import java.lang.reflect.Constructor;
import java.net.InetAddress;
import java.security.PrivilegedAction;

public class jdk12InetAddressAction implements PrivilegedAction {
  public static Constructor cons;
  
  private InetAddress addr;
  
  private String method;
  
  private String arg;
  
  static {
    try {
      cons = jdk12InetAddressAction.class.getConstructor(new Class[] { InetAddress.class, String.class, String.class });
    } catch (Throwable e) {}
  }
  
  public jdk12InetAddressAction(InetAddress addr, String method, String arg) {
    this.addr = addr;
    this.method = method;
    this.arg = arg;
  }
  
  public Object run() {
    try {
      if (this.method.equals("getLocalHost"))
        return InetAddress.getLocalHost(); 
      if (this.method.equals("getAllByName"))
        return InetAddress.getAllByName(this.arg); 
      if (this.method.equals("getByName"))
        return InetAddress.getByName(this.arg); 
      if (this.method.equals("getHostName"))
        return this.addr.getHostName(); 
      return null;
    } catch (Throwable t) {
      return null;
    } 
  }
}
