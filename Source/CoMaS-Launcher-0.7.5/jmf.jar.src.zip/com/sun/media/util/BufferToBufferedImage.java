package com.sun.media.util;

import java.awt.Image;
import java.awt.Point;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.awt.image.DirectColorModel;
import java.awt.image.Raster;
import java.awt.image.SinglePixelPackedSampleModel;
import java.awt.image.WritableRaster;
import javax.media.Buffer;
import javax.media.format.RGBFormat;
import javax.media.format.VideoFormat;
import javax.media.util.BufferToImage;

public class BufferToBufferedImage extends BufferToImage {
  public BufferToBufferedImage() throws ClassNotFoundException {
    super(null);
    Class.forName("java.awt.Graphics2D");
  }
  
  public BufferToBufferedImage(VideoFormat paramVideoFormat) throws ClassNotFoundException {
    super(paramVideoFormat);
    Class.forName("java.awt.Graphics2D");
  }
  
  public Image createImage(Buffer paramBuffer) {
    RGBFormat rGBFormat = (RGBFormat)paramBuffer.getFormat();
    Object object = paramBuffer.getData();
    int i = rGBFormat.getRedMask();
    int j = rGBFormat.getGreenMask();
    int k = rGBFormat.getBlueMask();
    int[] arrayOfInt = new int[3];
    arrayOfInt[0] = i;
    arrayOfInt[1] = j;
    arrayOfInt[2] = k;
    DataBufferInt dataBufferInt = new DataBufferInt((int[])object, 
        rGBFormat.getLineStride() * 
        (rGBFormat.getSize()).height);
    SinglePixelPackedSampleModel singlePixelPackedSampleModel = new SinglePixelPackedSampleModel(3, 
        rGBFormat.getLineStride(), 
        (rGBFormat.getSize()).height, 
        arrayOfInt);
    WritableRaster writableRaster = Raster.createWritableRaster(singlePixelPackedSampleModel, dataBufferInt, new Point(0, 0));
    DirectColorModel directColorModel = new DirectColorModel(24, i, j, k);
    BufferedImage bufferedImage1 = new BufferedImage(directColorModel, writableRaster, true, null);
    AffineTransform affineTransform = new AffineTransform(1.0F, 0.0F, 
        0.0F, 1.0F, 
        0.0F, 0.0F);
    AffineTransformOp affineTransformOp = new AffineTransformOp(affineTransform, null);
    BufferedImage bufferedImage2 = affineTransformOp.createCompatibleDestImage(bufferedImage1, 
        directColorModel);
    affineTransformOp.filter(bufferedImage1, bufferedImage2);
    return bufferedImage2;
  }
}
