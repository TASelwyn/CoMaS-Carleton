package com.sun.media.util;

import javax.media.Format;

public interface DynamicPlugIn {
  Format[] getBaseInputFormats();
  
  Format[] getBaseOutputFormats();
}
