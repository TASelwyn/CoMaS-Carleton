/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.net.InetAddress;
/*    */ import java.net.MulticastSocket;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class jdk12MulticastSocketJoinGroupAction
/*    */   implements PrivilegedAction
/*    */ {
/*    */   public static Constructor cons;
/*    */   private MulticastSocket s;
/*    */   private InetAddress a;
/*    */   
/*    */   static {
/*    */     try {
/* 25 */       cons = jdk12MulticastSocketJoinGroupAction.class.getConstructor(new Class[] { MulticastSocket.class, InetAddress.class });
/*    */     
/*    */     }
/* 28 */     catch (Throwable e) {}
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public jdk12MulticastSocketJoinGroupAction(MulticastSocket s, InetAddress a) {
/* 34 */     this.s = s;
/* 35 */     this.a = a;
/*    */   }
/*    */   
/*    */   public Object run() {
/*    */     try {
/* 40 */       this.s.joinGroup(this.a);
/* 41 */       return this.s;
/*    */     } catch (Throwable t) {
/* 43 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\util\jdk12MulticastSocketJoinGroupAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */