/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.util.Vector;
/*    */ import javax.media.ControllerEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ThreadedEventQueue
/*    */   extends MediaThread
/*    */ {
/* 20 */   private Vector eventQueue = new Vector();
/*    */   private boolean killed = false;
/*    */   
/*    */   public ThreadedEventQueue() {
/* 24 */     useControlPriority();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract void processEvent(ControllerEvent paramControllerEvent);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean dispatchEvents() {
/* 43 */     ControllerEvent evt = null;
/*    */     
/* 45 */     synchronized (this) {
/*    */ 
/*    */       
/*    */       try {
/* 49 */         while (!this.killed && this.eventQueue.size() == 0)
/* 50 */           wait(); 
/*    */       } catch (InterruptedException e) {
/* 52 */         System.err.println("MediaNode event thread " + e);
/* 53 */         return true;
/*    */       } 
/*    */ 
/*    */       
/* 57 */       if (this.eventQueue.size() > 0) {
/* 58 */         evt = this.eventQueue.firstElement();
/* 59 */         this.eventQueue.removeElementAt(0);
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 64 */     if (evt != null) {
/* 65 */       processEvent(evt);
/*    */     }
/*    */ 
/*    */     
/* 69 */     return (!this.killed || this.eventQueue.size() != 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized void postEvent(ControllerEvent evt) {
/* 76 */     this.eventQueue.addElement(evt);
/* 77 */     notifyAll();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized void kill() {
/* 84 */     this.killed = true;
/* 85 */     notifyAll();
/*    */   }
/*    */ 
/*    */   
/*    */   public void run() {
/*    */     do {
/*    */     
/* 92 */     } while (dispatchEvents());
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\util\ThreadedEventQueue.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */