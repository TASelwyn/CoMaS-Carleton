package com.sun.media.util;

import java.lang.reflect.Constructor;
import java.security.Permission;

public class jdk12Action {
  public static Constructor getCheckPermissionAction() throws NoSuchMethodException {
    return CheckPermissionAction.class.getConstructor(new Class[] { Permission.class });
  }
}
