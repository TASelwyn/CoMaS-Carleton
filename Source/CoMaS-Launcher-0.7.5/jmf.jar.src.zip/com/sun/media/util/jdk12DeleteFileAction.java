/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class jdk12DeleteFileAction
/*    */   implements PrivilegedAction
/*    */ {
/*    */   public static Constructor cons;
/*    */   private File file;
/* 18 */   private static Boolean TRUE = new Boolean(true);
/* 19 */   private static Boolean FALSE = new Boolean(false);
/*    */   
/*    */   static {
/*    */     try {
/* 23 */       cons = jdk12DeleteFileAction.class.getConstructor(new Class[] { File.class });
/*    */     }
/* 25 */     catch (Throwable e) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public jdk12DeleteFileAction(File file) {
/*    */     try {
/* 33 */       this.file = file;
/* 34 */     } catch (Throwable e) {}
/*    */   }
/*    */ 
/*    */   
/*    */   public Object run() {
/*    */     try {
/* 40 */       if (this.file != null) {
/* 41 */         if (this.file.delete()) {
/* 42 */           return TRUE;
/*    */         }
/* 44 */         return FALSE;
/*    */       } 
/* 46 */       return FALSE;
/*    */     } catch (Throwable e) {
/*    */       
/* 49 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\util\jdk12DeleteFileAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */