/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.MissingResourceException;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JMFI18N
/*    */ {
/* 13 */   public static ResourceBundle bundle = null;
/* 14 */   public static ResourceBundle bundleApps = null;
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getResource(String key) {
/* 19 */     Locale currentLocale = Locale.getDefault();
/*    */     
/* 21 */     if (bundle == null) {
/*    */       try {
/* 23 */         bundle = ResourceBundle.getBundle("com.sun.media.util.locale.JMFProps", currentLocale);
/*    */       } catch (MissingResourceException e) {
/* 25 */         System.out.println("Could not load Resources");
/* 26 */         System.exit(0);
/*    */       } 
/*    */       try {
/* 29 */         bundleApps = ResourceBundle.getBundle("com.sun.media.util.locale.JMFAppProps", currentLocale);
/* 30 */       } catch (MissingResourceException me) {}
/*    */     } 
/*    */     
/* 33 */     String value = "";
/*    */     try {
/* 35 */       value = (String)bundle.getObject(key);
/*    */     } catch (MissingResourceException e) {
/* 37 */       if (bundleApps != null) {
/*    */         try {
/* 39 */           value = (String)bundleApps.getObject(key);
/*    */         } catch (MissingResourceException mre) {
/* 41 */           System.out.println("Could not find " + key);
/*    */         } 
/*    */       } else {
/* 44 */         System.out.println("Could not find " + key);
/*    */       } 
/* 46 */     }  return value;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\util\JMFI18N.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */