/*    */ package com.sun.media.util;
/*    */ 
/*    */ import javax.media.Time;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SettableTime
/*    */   extends Time
/*    */ {
/*    */   public SettableTime() {
/* 14 */     super(0L);
/*    */   }
/*    */   
/*    */   public SettableTime(long nanoseconds) {
/* 18 */     super(nanoseconds);
/*    */   }
/*    */   
/*    */   public SettableTime(double seconds) {
/* 22 */     super(seconds);
/*    */   }
/*    */   
/*    */   public final Time set(long nanoseconds) {
/* 26 */     this.nanoseconds = nanoseconds;
/* 27 */     return this;
/*    */   }
/*    */   
/*    */   public final Time set(double seconds) {
/* 31 */     this.nanoseconds = secondsToNanoseconds(seconds);
/* 32 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\util\SettableTime.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */