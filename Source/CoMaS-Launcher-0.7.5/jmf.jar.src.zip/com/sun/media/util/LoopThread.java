/*     */ package com.sun.media.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LoopThread
/*     */   extends MediaThread
/*     */ {
/*     */   protected boolean paused = false, started = false;
/*     */   protected boolean killed = false;
/*     */   private boolean waitingAtPaused = false;
/*     */   
/*     */   public LoopThread() {
/*  30 */     setName("Loop thread");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void pause() {
/*  40 */     this.paused = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void blockingPause() {
/*  48 */     if (this.waitingAtPaused || this.killed)
/*  49 */       return;  this.paused = true;
/*  50 */     waitForCompleteStop();
/*     */   }
/*     */   
/*     */   public boolean isPaused() {
/*  54 */     return this.paused;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void waitForCompleteStop() {
/*     */     try {
/*  62 */       while (!this.killed && !this.waitingAtPaused && this.paused)
/*  63 */         wait(); 
/*  64 */     } catch (InterruptedException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void waitForCompleteStop(int millis) {
/*     */     try {
/*  73 */       if (!this.killed && !this.waitingAtPaused && this.paused)
/*  74 */         wait(millis); 
/*  75 */     } catch (InterruptedException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void start() {
/*  83 */     if (!this.started) {
/*  84 */       super.start();
/*  85 */       this.started = true;
/*     */     } 
/*  87 */     this.paused = false;
/*  88 */     notifyAll();
/*     */   }
/*     */   
/*     */   public synchronized void kill() {
/*  92 */     this.killed = true;
/*  93 */     notifyAll();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean waitHereIfPaused() {
/* 101 */     if (this.killed)
/* 102 */       return false; 
/* 103 */     this.waitingAtPaused = true;
/* 104 */     if (this.paused)
/* 105 */       notifyAll(); 
/*     */     try {
/* 107 */       while (!this.killed && this.paused)
/* 108 */         wait(); 
/*     */     } catch (InterruptedException e) {
/* 110 */       System.err.println("Timer: timeLoop() wait interrupted " + e);
/*     */     } 
/* 112 */     this.waitingAtPaused = false;
/* 113 */     if (this.killed)
/* 114 */       return false; 
/* 115 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean process();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 131 */     while (waitHereIfPaused()) {
/*     */ 
/*     */ 
/*     */       
/* 135 */       if (!process())
/*     */         break; 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\util\LoopThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */