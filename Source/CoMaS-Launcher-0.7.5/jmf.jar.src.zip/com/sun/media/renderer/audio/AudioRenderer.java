package com.sun.media.renderer.audio;

import com.sun.media.BasicPlugIn;
import com.sun.media.Log;
import com.sun.media.MediaTimeBase;
import com.sun.media.renderer.audio.device.AudioOutput;
import java.awt.Component;
import javax.media.Buffer;
import javax.media.Clock;
import javax.media.ClockStoppedException;
import javax.media.Control;
import javax.media.Drainable;
import javax.media.Format;
import javax.media.GainControl;
import javax.media.IncompatibleTimeBaseException;
import javax.media.Owned;
import javax.media.Prefetchable;
import javax.media.Renderer;
import javax.media.Time;
import javax.media.TimeBase;
import javax.media.control.BufferControl;
import javax.media.format.AudioFormat;

public abstract class AudioRenderer extends BasicPlugIn implements Renderer, Prefetchable, Drainable, Clock {
  Format[] supportedFormats;
  
  protected AudioFormat inputFormat;
  
  protected AudioFormat devFormat;
  
  protected AudioOutput device = null;
  
  protected TimeBase timeBase = null;
  
  protected boolean started = false;
  
  protected boolean prefetched = false;
  
  protected boolean resetted = false;
  
  protected boolean devicePaused = true;
  
  protected GainControl gainControl;
  
  protected BufferControl bufferControl;
  
  protected Control peakVolumeMeter = null;
  
  protected long bytesWritten = 0L;
  
  protected int bytesPerSec;
  
  private Object writeLock = new Object();
  
  long mediaTimeAnchor;
  
  long startTime;
  
  long stopTime;
  
  long ticksSinceLastReset;
  
  float rate;
  
  TimeBase master;
  
  public Format[] getSupportedInputFormats() {
    return this.supportedFormats;
  }
  
  public Format setInputFormat(Format format) {
    for (int i = 0; i < this.supportedFormats.length; i++) {
      if (this.supportedFormats[i].matches(format)) {
        this.inputFormat = (AudioFormat)format;
        return format;
      } 
    } 
    return null;
  }
  
  public void close() {
    stop();
    if (this.device != null) {
      pauseDevice();
      this.device.flush();
      this.mediaTimeAnchor = getMediaNanoseconds();
      this.ticksSinceLastReset = 0L;
      this.device.dispose();
    } 
    this.device = null;
  }
  
  public void reset() {
    this.resetted = true;
    this.mediaTimeAnchor = getMediaNanoseconds();
    if (this.device != null) {
      this.device.flush();
      this.ticksSinceLastReset = this.device.getMediaNanoseconds();
    } else {
      this.ticksSinceLastReset = 0L;
    } 
    this.prefetched = false;
  }
  
  synchronized void pauseDevice() {
    if (!this.devicePaused && this.device != null) {
      this.device.pause();
      this.devicePaused = true;
    } 
    if (this.timeBase instanceof AudioTimeBase)
      ((AudioTimeBase)this.timeBase).mediaStopped(); 
  }
  
  synchronized void resumeDevice() {
    if (this.timeBase instanceof AudioTimeBase)
      ((AudioTimeBase)this.timeBase).mediaStarted(); 
    if (this.devicePaused && this.device != null) {
      this.device.resume();
      this.devicePaused = false;
    } 
  }
  
  public void start() {
    syncStart(getTimeBase().getTime());
  }
  
  public synchronized void drain() {
    if (this.started && this.device != null)
      this.device.drain(); 
    this.prefetched = false;
  }
  
  public int process(Buffer buffer) {
    int rtn = processData(buffer);
    if (buffer.isEOM() && rtn != 2) {
      drain();
      pauseDevice();
    } 
    return rtn;
  }
  
  protected boolean checkInput(Buffer buffer) {
    Format format = buffer.getFormat();
    if (this.device == null || this.devFormat == null || !this.devFormat.equals(format)) {
      if (!initDevice((AudioFormat)format)) {
        buffer.setDiscard(true);
        return false;
      } 
      this.devFormat = (AudioFormat)format;
    } 
    return true;
  }
  
  protected int processData(Buffer buffer) {
    if (!checkInput(buffer))
      return 1; 
    return doProcessData(buffer);
  }
  
  protected int doProcessData(Buffer buffer) {
    byte[] data = (byte[])buffer.getData();
    int remain = buffer.getLength();
    int off = buffer.getOffset();
    int len = 0;
    synchronized (this) {
      if (!this.started) {
        if (!this.devicePaused)
          pauseDevice(); 
        this.resetted = false;
        int available = this.device.bufferAvailable();
        if (available > remain)
          available = remain; 
        if (available > 0) {
          len = this.device.write(data, off, available);
          this.bytesWritten += len;
        } 
        buffer.setLength(remain - len);
        if (buffer.getLength() > 0 || buffer.isEOM()) {
          buffer.setOffset(off + len);
          this.prefetched = true;
          return 2;
        } 
        return 0;
      } 
    } 
    synchronized (this.writeLock) {
      if (this.devicePaused)
        return 2; 
      try {
        while (remain > 0 && !this.resetted) {
          len = this.device.write(data, off, remain);
          this.bytesWritten += len;
          off += len;
          remain -= len;
        } 
      } catch (NullPointerException e) {
        return 0;
      } 
    } 
    buffer.setLength(0);
    buffer.setOffset(0);
    return 0;
  }
  
  protected boolean initDevice(AudioFormat format) {
    if (format == null) {
      System.err.println("AudioRenderer: ERROR: Unknown AudioFormat");
      return false;
    } 
    if (format.getSampleRate() == -1.0D || format.getSampleSizeInBits() == -1) {
      Log.error("Cannot initialize audio renderer with format: " + format);
      return false;
    } 
    if (this.device != null) {
      this.device.drain();
      pauseDevice();
      this.mediaTimeAnchor = getMediaNanoseconds();
      this.ticksSinceLastReset = 0L;
      this.device.dispose();
      this.device = null;
    } 
    AudioFormat audioFormat = new AudioFormat(format.getEncoding(), format.getSampleRate(), format.getSampleSizeInBits(), format.getChannels(), format.getEndian(), format.getSigned());
    this.device = createDevice(audioFormat);
    if (this.device == null || !this.device.initialize(audioFormat, computeBufferSize(audioFormat))) {
      this.device = null;
      return false;
    } 
    this.device.setMute(this.gainControl.getMute());
    this.device.setGain(this.gainControl.getDB());
    if (this.rate != 1.0F && 
      this.rate != this.device.setRate(this.rate)) {
      System.err.println("The AudioRenderer does not support the given rate: " + this.rate);
      this.device.setRate(1.0F);
    } 
    if (this.started)
      resumeDevice(); 
    this.bytesPerSec = (int)(format.getSampleRate() * format.getChannels() * format.getSampleSizeInBits() / 8.0D);
    return true;
  }
  
  protected void processByWaiting(Buffer buffer) {
    synchronized (this) {
      if (!this.started) {
        this.prefetched = true;
        return;
      } 
    } 
    AudioFormat format = (AudioFormat)buffer.getFormat();
    int sampleRate = (int)format.getSampleRate();
    int sampleSize = format.getSampleSizeInBits();
    int channels = format.getChannels();
    long duration = (buffer.getLength() * 1000 / sampleSize / 8 * sampleRate * channels);
    int timeToWait = (int)((float)duration / getRate());
    try {
      Thread.currentThread();
      Thread.sleep(timeToWait);
    } catch (Exception e) {}
    buffer.setLength(0);
    buffer.setOffset(0);
    this.mediaTimeAnchor += duration * 1000000L;
  }
  
  public Object[] getControls() {
    Control[] c = { (Control)this.gainControl, (Control)this.bufferControl };
    return (Object[])c;
  }
  
  public boolean isPrefetched() {
    return this.prefetched;
  }
  
  public AudioRenderer() {
    this.mediaTimeAnchor = 0L;
    this.startTime = Long.MAX_VALUE;
    this.stopTime = Long.MAX_VALUE;
    this.ticksSinceLastReset = 0L;
    this.rate = 1.0F;
    this.master = null;
    this.bufLenReq = 200L;
    this.timeBase = (TimeBase)new AudioTimeBase(this, this);
    this.bufferControl = new BC(this, this);
  }
  
  public void setTimeBase(TimeBase master) throws IncompatibleTimeBaseException {
    if (!(master instanceof AudioTimeBase))
      Log.warning("AudioRenderer cannot be controlled by time bases other than its own: " + master); 
    this.master = master;
  }
  
  public synchronized void syncStart(Time at) {
    this.started = true;
    this.prefetched = true;
    this.resetted = false;
    resumeDevice();
    this.startTime = at.getNanoseconds();
  }
  
  public synchronized void stop() {
    this.started = false;
    this.prefetched = false;
    synchronized (this.writeLock) {
      pauseDevice();
    } 
  }
  
  public void setStopTime(Time t) {
    this.stopTime = t.getNanoseconds();
  }
  
  public Time getStopTime() {
    return new Time(this.stopTime);
  }
  
  public void setMediaTime(Time now) {
    this.mediaTimeAnchor = now.getNanoseconds();
  }
  
  public Time getMediaTime() {
    return new Time(getMediaNanoseconds());
  }
  
  public long getMediaNanoseconds() {
    return this.mediaTimeAnchor + ((this.device != null) ? this.device.getMediaNanoseconds() : 0L) - this.ticksSinceLastReset;
  }
  
  public long getLatency() {
    long ts = this.bytesWritten * 1000L / this.bytesPerSec * 1000000L;
    return ts - getMediaNanoseconds();
  }
  
  public Time getSyncTime() {
    return new Time(0L);
  }
  
  public TimeBase getTimeBase() {
    if (this.master != null)
      return this.master; 
    return this.timeBase;
  }
  
  public Time mapToTimeBase(Time t) throws ClockStoppedException {
    return new Time((long)((float)(t.getNanoseconds() - this.mediaTimeAnchor) / this.rate) + this.startTime);
  }
  
  public float getRate() {
    return this.rate;
  }
  
  public float setRate(float factor) {
    if (this.device != null) {
      this.rate = this.device.setRate(factor);
    } else {
      this.rate = 1.0F;
    } 
    return this.rate;
  }
  
  public int computeBufferSize(AudioFormat f) {
    long l1, bytesPerSecond = (long)(f.getSampleRate() * f.getChannels() * f.getSampleSizeInBits() / 8.0D);
    if (this.bufLenReq < DefaultMinBufferSize) {
      l1 = DefaultMinBufferSize;
    } else if (this.bufLenReq > DefaultMaxBufferSize) {
      l1 = DefaultMaxBufferSize;
    } else {
      l1 = this.bufLenReq;
    } 
    float r = (float)l1 / 1000.0F;
    long bufSize = (long)((float)bytesPerSecond * r);
    return (int)bufSize;
  }
  
  class AudioTimeBase extends MediaTimeBase {
    AudioRenderer renderer;
    
    private final AudioRenderer this$0;
    
    AudioTimeBase(AudioRenderer this$0, AudioRenderer r) {
      this.this$0 = this$0;
      this.renderer = r;
    }
    
    public long getMediaTime() {
      if (this.this$0.rate == 1.0F || this.this$0.rate == 0.0F)
        return (this.this$0.device != null) ? this.this$0.device.getMediaNanoseconds() : 0L; 
      return (long)(((this.this$0.device != null) ? (float)this.this$0.device.getMediaNanoseconds() : 0.0F) / this.this$0.rate);
    }
  }
  
  static int DefaultMinBufferSize = 62;
  
  static int DefaultMaxBufferSize = 4000;
  
  long bufLenReq;
  
  protected abstract AudioOutput createDevice(AudioFormat paramAudioFormat);
  
  class BC implements BufferControl, Owned {
    AudioRenderer renderer;
    
    private final AudioRenderer this$0;
    
    BC(AudioRenderer this$0, AudioRenderer ar) {
      this.this$0 = this$0;
      this.renderer = ar;
    }
    
    public long getBufferLength() {
      return this.this$0.bufLenReq;
    }
    
    public long setBufferLength(long time) {
      if (time < AudioRenderer.DefaultMinBufferSize) {
        this.this$0.bufLenReq = AudioRenderer.DefaultMinBufferSize;
      } else if (time > AudioRenderer.DefaultMaxBufferSize) {
        this.this$0.bufLenReq = AudioRenderer.DefaultMaxBufferSize;
      } else {
        this.this$0.bufLenReq = time;
      } 
      return this.this$0.bufLenReq;
    }
    
    public long getMinimumThreshold() {
      return 0L;
    }
    
    public long setMinimumThreshold(long time) {
      return 0L;
    }
    
    public void setEnabledThreshold(boolean b) {}
    
    public boolean getEnabledThreshold() {
      return false;
    }
    
    public Component getControlComponent() {
      return null;
    }
    
    public Object getOwner() {
      return this.renderer;
    }
  }
}
