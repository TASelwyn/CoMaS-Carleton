package com.sun.media.renderer.audio.device;

import javax.media.format.AudioFormat;

public interface AudioOutput {
  boolean initialize(AudioFormat paramAudioFormat, int paramInt);
  
  void dispose();
  
  void pause();
  
  void resume();
  
  void drain();
  
  void flush();
  
  long getMediaNanoseconds();
  
  void setGain(double paramDouble);
  
  double getGain();
  
  void setMute(boolean paramBoolean);
  
  boolean getMute();
  
  float setRate(float paramFloat);
  
  float getRate();
  
  int bufferAvailable();
  
  int write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\renderer\audio\device\AudioOutput.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */