package com.sun.media.renderer.video;

public class LightWeightRenderer extends AWTRenderer {
  private static final String MyName = "LightWeight Renderer";
  
  public LightWeightRenderer() {
    super("LightWeight Renderer");
  }
  
  public boolean isLightWeight() {
    return true;
  }
}
