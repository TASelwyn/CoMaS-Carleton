package com.sun.media.renderer.video;

import com.ms.awt.HeavyComponent;

public class MSHeavyComponent extends HeavyComponent implements HeavyComponent {
  public boolean needsHeavyPeer() {
    return true;
  }
}
