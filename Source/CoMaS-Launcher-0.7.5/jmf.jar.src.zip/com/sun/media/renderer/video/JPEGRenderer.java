/*     */ package com.sun.media.renderer.video;
/*     */ 
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import com.sun.media.SlowPlugIn;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.MediaTracker;
/*     */ import java.awt.Toolkit;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JPEGRenderer
/*     */   extends BasicVideoRenderer
/*     */   implements SlowPlugIn
/*     */ {
/*     */   private static final String MyName = "JPEG Renderer";
/*  34 */   private VideoFormat supportedJPEG = null;
/*  35 */   private VideoFormat supportedMJPG = null;
/*     */ 
/*     */   
/*     */   private boolean forceToFail = false;
/*     */ 
/*     */   
/*     */   public void forceToUse() {
/*  42 */     this.forceToFail = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JPEGRenderer() {
/*  51 */     super("JPEG Renderer");
/*     */ 
/*     */ 
/*     */     
/*  55 */     if (BasicPlugIn.plugInExists("com.sun.media.codec.video.jpeg.NativeDecoder", 2)) {
/*     */       try {
/*  57 */         JMFSecurityManager.loadLibrary("jmutil");
/*  58 */         JMFSecurityManager.loadLibrary("jmjpeg");
/*  59 */         this.forceToFail = true;
/*  60 */       } catch (Throwable t) {}
/*     */     }
/*     */ 
/*     */     
/*  64 */     this.supportedJPEG = new VideoFormat("jpeg", null, -1, Format.byteArray, -1.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  70 */     this.supportedMJPG = new VideoFormat("mjpg", null, -1, Format.byteArray, -1.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     this.supportedFormats = new VideoFormat[1];
/*  79 */     this.supportedFormats[0] = this.supportedJPEG;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() throws ResourceUnavailableException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format setInputFormat(Format format) {
/* 112 */     if (this.forceToFail)
/* 113 */       return null; 
/* 114 */     if (super.setInputFormat(format) != null) {
/* 115 */       reset();
/* 116 */       return format;
/*     */     } 
/* 118 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int doProcess(Buffer buffer) {
/* 126 */     if (this.component == null)
/* 127 */       return 0; 
/* 128 */     if (!buffer.getFormat().equals(this.inputFormat)) {
/* 129 */       Format in = buffer.getFormat();
/* 130 */       if (!in.matches((Format)this.supportedJPEG)) {
/* 131 */         return 1;
/*     */       }
/* 133 */       this.inputFormat = (VideoFormat)in;
/*     */     } 
/*     */ 
/*     */     
/* 137 */     Dimension size = this.inputFormat.getSize();
/*     */     
/* 139 */     Object data = buffer.getData();
/* 140 */     if (!(data instanceof byte[])) {
/* 141 */       return 1;
/*     */     }
/* 143 */     Image im = Toolkit.getDefaultToolkit().createImage((byte[])data);
/* 144 */     MediaTracker tracker = new MediaTracker(this.component);
/*     */     
/* 146 */     Dimension d = this.component.getSize();
/* 147 */     this.outWidth = d.width;
/* 148 */     this.outHeight = d.height;
/*     */     
/* 150 */     tracker.addImage(im, 0);
/*     */     try {
/* 152 */       tracker.waitForAll();
/* 153 */     } catch (Exception e) {}
/*     */     
/* 155 */     Graphics g = this.component.getGraphics();
/* 156 */     if (g != null) {
/* 157 */       g.drawImage(im, 0, 0, this.outWidth, this.outHeight, 0, 0, size.width, size.height, this.component);
/*     */     }
/*     */     
/* 160 */     return 0;
/*     */   }
/*     */   
/*     */   protected void repaint() {}
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\renderer\video\JPEGRenderer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */