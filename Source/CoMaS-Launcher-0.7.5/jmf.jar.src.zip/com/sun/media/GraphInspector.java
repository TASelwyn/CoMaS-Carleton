package com.sun.media;

import javax.media.Codec;
import javax.media.Format;
import javax.media.Multiplexer;
import javax.media.PlugIn;
import javax.media.Renderer;

public interface GraphInspector {
  boolean detailMode();
  
  boolean verify(Codec paramCodec, Format paramFormat1, Format paramFormat2);
  
  boolean verify(Renderer paramRenderer, Format paramFormat);
  
  boolean verify(Multiplexer paramMultiplexer, Format[] paramArrayOfFormat);
  
  void verifyInputFailed(PlugIn paramPlugIn, Format paramFormat);
  
  void verifyOutputFailed(PlugIn paramPlugIn, Format paramFormat);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\GraphInspector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */