package com.sun.media.parser;

import com.sun.media.BasicPlugIn;
import com.sun.media.CircularBuffer;
import com.sun.media.rtp.Depacketizer;
import java.awt.Dimension;
import java.io.IOException;
import java.util.Vector;
import javax.media.Buffer;
import javax.media.Demultiplexer;
import javax.media.Format;
import javax.media.IncompatibleSourceException;
import javax.media.PlugInManager;
import javax.media.Time;
import javax.media.Track;
import javax.media.TrackListener;
import javax.media.format.AudioFormat;
import javax.media.format.VideoFormat;
import javax.media.protocol.BufferTransferHandler;
import javax.media.protocol.DataSource;
import javax.media.protocol.PushBufferDataSource;
import javax.media.protocol.PushBufferStream;
import javax.media.protocol.SourceStream;

public class RawBufferParser extends RawStreamParser {
  static final String NAMEBUFFER = "Raw video/audio buffer stream parser";
  
  private boolean started = false;
  
  static AudioFormat mpegAudio = new AudioFormat("mpegaudio/rtp");
  
  static VideoFormat mpegVideo = new VideoFormat("mpeg/rtp");
  
  static VideoFormat jpegVideo = new VideoFormat("jpeg/rtp");
  
  static VideoFormat h261Video = new VideoFormat("h261/rtp");
  
  static VideoFormat h263Video = new VideoFormat("h263/rtp");
  
  static VideoFormat h263_1998Video = new VideoFormat("h263-1998/rtp");
  
  public String getName() {
    return "Raw video/audio buffer stream parser";
  }
  
  public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
    if (!(source instanceof PushBufferDataSource))
      throw new IncompatibleSourceException("DataSource not supported: " + source); 
    this.streams = (SourceStream[])((PushBufferDataSource)source).getStreams();
    if (this.streams == null)
      throw new IOException("Got a null stream from the DataSource"); 
    if (this.streams.length == 0)
      throw new IOException("Got a empty stream array from the DataSource"); 
    if (!supports(this.streams))
      throw new IncompatibleSourceException("DataSource not supported: " + source); 
    this.source = source;
    this.streams = this.streams;
  }
  
  protected boolean supports(SourceStream[] streams) {
    return (streams[0] != null && streams[0] instanceof PushBufferStream);
  }
  
  public void open() {
    if (this.tracks != null)
      return; 
    this.tracks = new Track[this.streams.length];
    for (int i = 0; i < this.streams.length; i++)
      this.tracks[i] = new FrameTrack(this, this, (PushBufferStream)this.streams[i], 1); 
  }
  
  public void close() {
    if (this.source != null) {
      try {
        this.source.stop();
        for (int i = 0; i < this.tracks.length; i++) {
          ((FrameTrack)this.tracks[i]).stop();
          ((FrameTrack)this.tracks[i]).close();
        } 
        this.source.disconnect();
      } catch (Exception e) {}
      this.source = null;
    } 
    this.started = false;
  }
  
  public Track[] getTracks() {
    for (int i = 0; i < this.tracks.length; i++)
      ((FrameTrack)this.tracks[i]).parse(); 
    return this.tracks;
  }
  
  public void start() throws IOException {
    for (int i = 0; i < this.tracks.length; i++)
      ((FrameTrack)this.tracks[i]).start(); 
    this.source.start();
    this.started = true;
  }
  
  public void stop() {
    try {
      this.source.stop();
      for (int i = 0; i < this.tracks.length; i++)
        ((FrameTrack)this.tracks[i]).stop(); 
    } catch (Exception e) {}
    this.started = false;
  }
  
  public void reset() {
    for (int i = 0; i < this.tracks.length; i++)
      ((FrameTrack)this.tracks[i]).reset(); 
  }
  
  boolean isRTPFormat(Format fmt) {
    return (fmt != null && fmt.getEncoding() != null && (fmt.getEncoding().endsWith("rtp") || fmt.getEncoding().endsWith("RTP")));
  }
  
  final int[] h261Widths = new int[] { 176, 352 };
  
  final int[] h261Heights = new int[] { 144, 288 };
  
  final int[] h263Widths = new int[] { 0, 128, 176, 352, 704, 1408, 0, 0 };
  
  final int[] h263Heights = new int[] { 0, 96, 144, 288, 576, 1152, 0, 0 };
  
  final float[] MPEGRateTbl = new float[] { 0.0F, 23.976F, 24.0F, 25.0F, 29.97F, 30.0F, 50.0F, 59.94F, 60.0F };
  
  public static int[][] MPASampleTbl = new int[][] { { 22050, 24000, 16000, 0 }, { 44100, 48000, 32000, 0 } };
  
  class FrameTrack implements Track, BufferTransferHandler {
    Demultiplexer parser;
    
    PushBufferStream pbs;
    
    boolean enabled;
    
    CircularBuffer bufferQ;
    
    Format format;
    
    TrackListener listener;
    
    boolean stopped;
    
    boolean closed;
    
    boolean keyFrameFound;
    
    boolean checkDepacketizer;
    
    Depacketizer depacketizer;
    
    Object keyFrameLock;
    
    private final RawBufferParser this$0;
    
    public FrameTrack(RawBufferParser this$0, Demultiplexer parser, PushBufferStream pbs, int numOfBufs) {
      this.this$0 = this$0;
      this.enabled = true;
      this.format = null;
      this.stopped = true;
      this.closed = false;
      this.keyFrameFound = false;
      this.checkDepacketizer = false;
      this.depacketizer = null;
      this.keyFrameLock = new Object();
      this.pbs = pbs;
      this.format = pbs.getFormat();
      if (this$0.source instanceof com.sun.media.protocol.DelegateDataSource || !this$0.isRTPFormat(this.format))
        this.keyFrameFound = true; 
      this.bufferQ = new CircularBuffer(numOfBufs);
      pbs.setTransferHandler(this);
    }
    
    public Format getFormat() {
      return this.format;
    }
    
    public void setEnabled(boolean t) {
      if (t) {
        this.pbs.setTransferHandler(this);
      } else {
        this.pbs.setTransferHandler(null);
      } 
      this.enabled = t;
    }
    
    public boolean isEnabled() {
      return this.enabled;
    }
    
    public Time getDuration() {
      return this.parser.getDuration();
    }
    
    public Time getStartTime() {
      return new Time(0L);
    }
    
    public void setTrackListener(TrackListener l) {
      this.listener = l;
    }
    
    public void parse() {
      try {
        synchronized (this.keyFrameLock) {
          while (!this.keyFrameFound)
            this.keyFrameLock.wait(); 
        } 
      } catch (Exception e) {}
    }
    
    private Depacketizer findDepacketizer(String name, Format input) {
      try {
        Class cls = BasicPlugIn.getClassForName(name);
        Object obj = cls.newInstance();
        if (!(obj instanceof Depacketizer))
          return null; 
        Depacketizer dpktizer = (Depacketizer)obj;
        if (dpktizer.setInputFormat(input) == null)
          return null; 
        dpktizer.open();
        return dpktizer;
      } catch (Exception e) {
      
      } catch (Error e) {}
      return null;
    }
    
    private boolean findKeyFrame(Buffer buf) {
      if (!this.checkDepacketizer) {
        Vector pnames = PlugInManager.getPlugInList(buf.getFormat(), null, 6);
        if (pnames.size() != 0)
          this.depacketizer = findDepacketizer(pnames.elementAt(0), buf.getFormat()); 
        this.checkDepacketizer = true;
      } 
      Format fmt = buf.getFormat();
      if (fmt == null)
        return false; 
      if (fmt.getEncoding() == null) {
        synchronized (this.keyFrameLock) {
          this.keyFrameFound = true;
          this.keyFrameLock.notifyAll();
        } 
        return true;
      } 
      boolean rtn = true;
      if (RawBufferParser.jpegVideo.matches(fmt)) {
        rtn = findJPEGKey(buf);
      } else if (RawBufferParser.h261Video.matches(fmt)) {
        rtn = findH261Key(buf);
      } else if (RawBufferParser.h263Video.matches(fmt)) {
        rtn = findH263Key(buf);
      } else if (RawBufferParser.h263_1998Video.matches(fmt)) {
        rtn = findH263_1998Key(buf);
      } else if (RawBufferParser.mpegVideo.matches(fmt)) {
        rtn = findMPEGKey(buf);
      } else if (RawBufferParser.mpegAudio.matches(fmt)) {
        rtn = findMPAKey(buf);
      } else if (this.depacketizer != null) {
        fmt = this.depacketizer.parse(buf);
        if (fmt != null) {
          this.format = fmt;
          buf.setFormat(this.format);
          this.depacketizer.close();
          this.depacketizer = null;
        } else {
          rtn = false;
        } 
      } 
      if (rtn)
        synchronized (this.keyFrameLock) {
          this.keyFrameFound = true;
          this.keyFrameLock.notifyAll();
        }  
      return this.keyFrameFound;
    }
    
    public boolean findJPEGKey(Buffer b) {
      if ((b.getFlags() & 0x800) == 0)
        return false; 
      byte[] data = (byte[])b.getData();
      int width = (data[b.getOffset() + 6] & 0xFF) * 8;
      int height = (data[b.getOffset() + 7] & 0xFF) * 8;
      this.format = (Format)new VideoFormat("jpeg/rtp", new Dimension(width, height), ((VideoFormat)this.format).getMaxDataLength(), ((VideoFormat)this.format).getDataType(), ((VideoFormat)this.format).getFrameRate());
      b.setFormat(this.format);
      return true;
    }
    
    public boolean findH261Key(Buffer b) {
      byte[] data;
      if ((data = (byte[])b.getData()) == null)
        return false; 
      int offset = b.getOffset();
      int skipBytes = 4;
      if (data[offset + skipBytes] != 0 || data[offset + skipBytes + 1] != 1 || (data[offset + skipBytes + 2] & 0xFC) != 0)
        return false; 
      int s = data[offset + skipBytes + 3] >> 3 & 0x1;
      int width = this.this$0.h261Widths[s];
      int height = this.this$0.h261Heights[s];
      this.format = (Format)new VideoFormat("h261/rtp", new Dimension(width, height), ((VideoFormat)this.format).getMaxDataLength(), ((VideoFormat)this.format).getDataType(), ((VideoFormat)this.format).getFrameRate());
      b.setFormat(this.format);
      return true;
    }
    
    public boolean findH263Key(Buffer b) {
      byte[] data;
      if ((data = (byte[])b.getData()) == null)
        return false; 
      int payloadLen = getH263PayloadHeaderLength(data, b.getOffset());
      int offset = b.getOffset();
      if (data[offset + payloadLen] != 0 || data[offset + payloadLen + 1] != 0 || (data[offset + payloadLen + 2] & 0xFC) != 128)
        return false; 
      int s = data[offset + payloadLen + 4] >> 2 & 0x7;
      int width = this.this$0.h263Widths[s];
      int height = this.this$0.h263Heights[s];
      this.format = (Format)new VideoFormat("h263/rtp", new Dimension(width, height), ((VideoFormat)this.format).getMaxDataLength(), ((VideoFormat)this.format).getDataType(), ((VideoFormat)this.format).getFrameRate());
      b.setFormat(this.format);
      return true;
    }
    
    int getH263PayloadHeaderLength(byte[] input, int offset) {
      int l = 0;
      byte b = input[offset];
      if ((b & 0x80) != 0) {
        if ((b & 0x40) != 0) {
          l = 12;
        } else {
          l = 8;
        } 
      } else {
        l = 4;
      } 
      return l;
    }
    
    public boolean findH263_1998Key(Buffer b) {
      int s = -1;
      int picOffset = -1;
      byte[] data;
      if ((data = (byte[])b.getData()) == null)
        return false; 
      int offset = b.getOffset();
      int payloadLen = 2 + ((data[offset] & 0x1) << 5 | (data[offset + 1] & 0xF8) >> 3);
      if ((data[offset] & 0x2) != 0)
        payloadLen++; 
      picOffset = -1;
      if (payloadLen > 5) {
        if ((data[offset] & 0x2) == 2 && (data[offset + 3] & 0xFC) == 128) {
          picOffset = offset + 3;
        } else if ((data[offset + 2] & 0xFC) == 128) {
          picOffset = offset + 2;
        } 
      } else if ((data[offset] & 0x4) == 4 && (data[offset + payloadLen] & 0xFC) == 128) {
        picOffset = offset + payloadLen;
      } 
      if (picOffset < 0)
        return false; 
      s = data[picOffset + 2] >> 2 & 0x7;
      if (s == 7)
        if ((data[picOffset + 3] >> 1 & 0x7) == 1) {
          s = data[picOffset + 3] << 2 & 0x4 | data[picOffset + 4] >> 6 & 0x3;
        } else {
          return false;
        }  
      if (s < 0)
        return false; 
      int width = this.this$0.h263Widths[s];
      int height = this.this$0.h263Heights[s];
      this.format = (Format)new VideoFormat("h263-1998/rtp", new Dimension(width, height), ((VideoFormat)this.format).getMaxDataLength(), ((VideoFormat)this.format).getDataType(), ((VideoFormat)this.format).getFrameRate());
      b.setFormat(this.format);
      return true;
    }
    
    public boolean findMPEGKey(Buffer b) {
      byte[] data;
      if ((data = (byte[])b.getData()) == null)
        return false; 
      int off = b.getOffset();
      if (b.getLength() < 12)
        return false; 
      if ((data[off + 2] & 0x20) != 32)
        return false; 
      if (data[off + 4] != 0 || data[off + 5] != 0 || data[off + 6] != 1 || (data[off + 7] & 0xFF) != 179)
        return false; 
      int frix = data[off + 11] & 0xF;
      if (frix == 0 || frix > 8)
        return false; 
      int width = (data[off + 8] & 0xFF) << 4 | (data[off + 9] & 0xF0) >> 4;
      int height = (data[off + 9] & 0xF) << 8 | data[off + 10] & 0xFF;
      float frameRate = this.this$0.MPEGRateTbl[frix];
      this.format = (Format)new VideoFormat("mpeg/rtp", new Dimension(width, height), ((VideoFormat)this.format).getMaxDataLength(), ((VideoFormat)this.format).getDataType(), frameRate);
      b.setFormat(this.format);
      return true;
    }
    
    public boolean findMPAKey(Buffer b) {
      byte[] data;
      if ((data = (byte[])b.getData()) == null)
        return false; 
      int off = b.getOffset();
      if (b.getLength() < 8)
        return false; 
      if (data[off + 2] != 0 || data[off + 3] != 0)
        return false; 
      off += 4;
      if ((data[off] & 0xFF) != 255 || (data[off + 1] & 0xF6) <= 240 || (data[off + 2] & 0xF0) == 240 || (data[off + 2] & 0xC) == 12 || (data[off + 3] & 0x3) == 2)
        return false; 
      int id = data[off + 1] >> 3 & 0x1;
      int six = data[off + 2] >> 2 & 0x3;
      int channels = ((data[off + 3] >> 6 & 0x3) == 3) ? 1 : 2;
      double sampleRate = RawBufferParser.MPASampleTbl[id][six];
      this.format = (Format)new AudioFormat("mpegaudio/rtp", sampleRate, 16, channels, 0, 1);
      b.setFormat(this.format);
      return true;
    }
    
    public void stop() {
      synchronized (this.bufferQ) {
        this.stopped = true;
        this.bufferQ.notifyAll();
      } 
    }
    
    public void start() {
      synchronized (this.bufferQ) {
        this.stopped = false;
        if (this.this$0.source instanceof javax.media.protocol.CaptureDevice)
          while (this.bufferQ.canRead()) {
            this.bufferQ.read();
            this.bufferQ.readReport();
          }  
        this.bufferQ.notifyAll();
      } 
    }
    
    public void close() {
      setEnabled(false);
      synchronized (this.bufferQ) {
        this.closed = true;
        this.bufferQ.notifyAll();
      } 
    }
    
    public void reset() {}
    
    public void readFrame(Buffer buffer) {
      Buffer filled;
      if (this.stopped) {
        buffer.setDiscard(true);
        buffer.setFormat(this.format);
        return;
      } 
      synchronized (this.bufferQ) {
        while (!this.bufferQ.canRead()) {
          try {
            this.bufferQ.wait();
            if (this.stopped) {
              buffer.setDiscard(true);
              buffer.setFormat(this.format);
              return;
            } 
          } catch (Exception e) {}
        } 
        filled = this.bufferQ.read();
      } 
      Object hdr = buffer.getHeader();
      buffer.copy(filled, true);
      filled.setHeader(hdr);
      this.format = filled.getFormat();
      synchronized (this.bufferQ) {
        this.bufferQ.readReport();
        this.bufferQ.notifyAll();
      } 
    }
    
    public int mapTimeToFrame(Time t) {
      return -1;
    }
    
    public Time mapFrameToTime(int frameNumber) {
      return new Time(0L);
    }
    
    public void transferData(PushBufferStream pbs) {
      Buffer buffer;
      synchronized (this.bufferQ) {
        while (!this.bufferQ.canWrite() && !this.closed) {
          try {
            this.bufferQ.wait();
          } catch (Exception e) {}
        } 
        if (this.closed)
          return; 
        buffer = this.bufferQ.getEmptyBuffer();
      } 
      try {
        pbs.read(buffer);
      } catch (IOException e) {
        buffer.setDiscard(true);
      } 
      if (!this.keyFrameFound && !findKeyFrame(buffer)) {
        synchronized (this.bufferQ) {
          this.bufferQ.writeReport();
          this.bufferQ.read();
          this.bufferQ.readReport();
        } 
        return;
      } 
      synchronized (this.bufferQ) {
        this.bufferQ.writeReport();
        this.bufferQ.notifyAll();
      } 
    }
  }
}
