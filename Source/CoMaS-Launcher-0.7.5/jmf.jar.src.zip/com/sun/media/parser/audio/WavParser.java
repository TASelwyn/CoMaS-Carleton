/*     */ package com.sun.media.parser.audio;
/*     */ 
/*     */ import com.sun.media.format.WavAudioFormat;
/*     */ import com.sun.media.parser.BasicPullParser;
/*     */ import com.sun.media.parser.BasicTrack;
/*     */ import com.sun.media.util.SettableTime;
/*     */ import java.io.IOException;
/*     */ import javax.media.BadHeaderException;
/*     */ import javax.media.Duration;
/*     */ import javax.media.Format;
/*     */ import javax.media.Time;
/*     */ import javax.media.Track;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.PullSourceStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WavParser
/*     */   extends BasicPullParser
/*     */ {
/*  42 */   private Time duration = Duration.DURATION_UNKNOWN;
/*  43 */   private WavAudioFormat format = null;
/*  44 */   private Track[] tracks = new Track[1];
/*  45 */   private int numBuffers = 4;
/*     */   private int bufferSize;
/*     */   private int dataSize;
/*  48 */   private SettableTime mediaTime = new SettableTime(0L);
/*     */   private int encoding;
/*     */   private String encodingString;
/*     */   private int sampleRate;
/*     */   private int channels;
/*     */   private int sampleSizeInBits;
/*     */   private int blockAlign;
/*     */   private int samplesPerBlock;
/*     */   private long minLocation;
/*     */   private long maxLocation;
/*  58 */   private double locationToMediaTime = -1.0D;
/*  59 */   private double timePerBlockNano = -1.0D;
/*  60 */   private PullSourceStream stream = null;
/*  61 */   private static ContentDescriptor[] supportedFormat = new ContentDescriptor[] { new ContentDescriptor("audio.x_wav") };
/*     */   
/*     */   public ContentDescriptor[] getSupportedInputContentDescriptors() {
/*  64 */     return supportedFormat;
/*     */   }
/*     */   
/*     */   public Track[] getTracks() throws IOException, BadHeaderException {
/*  68 */     if (this.tracks[0] != null) {
/*  69 */       return this.tracks;
/*     */     }
/*  71 */     this.stream = (PullSourceStream)this.streams[0];
/*  72 */     if (this.cacheStream != null)
/*     */     {
/*  74 */       this.cacheStream.setEnabledBuffering(false);
/*     */     }
/*  76 */     readHeader();
/*  77 */     if (this.cacheStream != null) {
/*  78 */       this.cacheStream.setEnabledBuffering(true);
/*     */     }
/*     */     
/*  81 */     this.minLocation = getLocation(this.stream);
/*  82 */     this.maxLocation = this.minLocation + this.dataSize;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     this.tracks[0] = (Track)new WavTrack(this.format, true, new Time(0L), this.numBuffers, this.bufferSize, this.minLocation, this.maxLocation);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     return this.tracks;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void readHeader() throws IOException, BadHeaderException {
/*     */     boolean bool;
/* 102 */     String magicRIFF = readString(this.stream);
/*     */     
/* 104 */     if (!magicRIFF.equals("RIFF"))
/*     */     {
/* 106 */       throw new BadHeaderException("WAVE Parser: expected magic string RIFF, got " + magicRIFF);
/*     */     }
/*     */ 
/*     */     
/* 110 */     int length = readInt(this.stream, false);
/*     */ 
/*     */ 
/*     */     
/* 114 */     String magicWAVE = readString(this.stream);
/*     */     
/* 116 */     if (!magicWAVE.equals("WAVE"))
/*     */     {
/*     */       
/* 119 */       throw new BadHeaderException("WAVE Parser: expected magic string WAVE, got " + magicWAVE);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 124 */     length += 8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     while (!readString(this.stream).equals("fmt ")) {
/* 131 */       int size = readInt(this.stream, false);
/* 132 */       skip(this.stream, size);
/*     */     } 
/*     */ 
/*     */     
/* 136 */     int formatSize = readInt(this.stream, false);
/* 137 */     int remainingFormatSize = formatSize;
/*     */ 
/*     */ 
/*     */     
/* 141 */     if (formatSize < 16);
/*     */ 
/*     */ 
/*     */     
/* 145 */     this.encoding = readShort(this.stream, false);
/* 146 */     this.encodingString = (String)WavAudioFormat.formatMapper.get(new Integer(this.encoding));
/* 147 */     if (this.encodingString == null) {
/* 148 */       this.encodingString = "unknown";
/*     */     }
/* 150 */     this.channels = readShort(this.stream, false);
/*     */     
/* 152 */     this.sampleRate = readInt(this.stream, false);
/* 153 */     int bytesPerSecond = readInt(this.stream, false);
/*     */     
/* 155 */     this.blockAlign = readShort(this.stream, false);
/*     */     
/* 157 */     this.sampleSizeInBits = readShort(this.stream, false);
/* 158 */     if (this.encoding == 85)
/*     */     {
/* 160 */       this.sampleSizeInBits = 16;
/*     */     }
/* 162 */     this.samplesPerBlock = -1;
/* 163 */     remainingFormatSize -= 16;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 177 */     if ((remainingFormatSize > 0 && this.encoding == 1) || remainingFormatSize <= 2) {
/*     */ 
/*     */       
/* 180 */       skip(this.stream, remainingFormatSize);
/* 181 */       remainingFormatSize = 0;
/*     */     } 
/*     */ 
/*     */     
/* 185 */     byte[] codecSpecificHeader = null;
/* 186 */     int extraFieldsSize = 0;
/* 187 */     if (remainingFormatSize >= 2) {
/* 188 */       extraFieldsSize = readShort(this.stream, false);
/* 189 */       remainingFormatSize -= 2;
/*     */       
/* 191 */       if (extraFieldsSize > 0) {
/* 192 */         codecSpecificHeader = new byte[extraFieldsSize];
/* 193 */         readBytes(this.stream, codecSpecificHeader, codecSpecificHeader.length);
/* 194 */         remainingFormatSize -= extraFieldsSize;
/*     */       } 
/*     */     } 
/*     */     
/* 198 */     switch (this.encoding) {
/*     */       
/*     */       case 2:
/*     */       case 17:
/*     */       case 49:
/* 203 */         if (extraFieldsSize < 2) {
/* 204 */           throw new BadHeaderException("msadpcm: samplesPerBlock field not available");
/*     */         }
/* 206 */         this.samplesPerBlock = BasicPullParser.parseShortFromArray(codecSpecificHeader, false);
/*     */ 
/*     */         
/* 209 */         this.locationToMediaTime = this.samplesPerBlock / (this.sampleRate * this.blockAlign);
/*     */         break;
/*     */       
/*     */       default:
/* 213 */         this.locationToMediaTime = 1.0D / (this.sampleRate * this.blockAlign);
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 218 */     if (remainingFormatSize < 0)
/*     */     {
/* 220 */       throw new BadHeaderException("WAVE Parser: incorrect chunkSize in the fmt chunk");
/*     */     }
/*     */     
/* 223 */     if (remainingFormatSize > 0) {
/* 224 */       skip(this.stream, remainingFormatSize);
/*     */     }
/*     */ 
/*     */     
/* 228 */     while (!readString(this.stream).equals("data")) {
/* 229 */       int size = readInt(this.stream, false);
/* 230 */       skip(this.stream, size);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 235 */     this.dataSize = readInt(this.stream, false);
/*     */ 
/*     */ 
/*     */     
/* 239 */     if (this.blockAlign != 0) {
/* 240 */       if (bytesPerSecond < this.dataSize) {
/* 241 */         this.bufferSize = bytesPerSecond - bytesPerSecond % this.blockAlign;
/*     */       } else {
/*     */         
/* 244 */         this.bufferSize = this.dataSize - this.dataSize % this.blockAlign;
/*     */       } 
/* 246 */     } else if (bytesPerSecond < this.dataSize) {
/* 247 */       this.bufferSize = bytesPerSecond;
/*     */     } else {
/* 249 */       this.bufferSize = this.dataSize;
/*     */     } 
/*     */     
/* 252 */     double durationSeconds = -1.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 265 */     if (this.channels * this.sampleSizeInBits / 8 == this.blockAlign) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 272 */       durationSeconds = (this.dataSize / bytesPerSecond);
/* 273 */     } else if (this.samplesPerBlock > 0) {
/*     */       
/* 275 */       durationSeconds = (this.dataSize / this.blockAlign * this.samplesPerBlock / this.sampleRate);
/* 276 */       this.timePerBlockNano = this.samplesPerBlock * 1.0E9D / this.sampleRate;
/*     */     } else {
/*     */       
/* 279 */       this.timePerBlockNano = this.blockAlign * 1.0E9D / bytesPerSecond;
/* 280 */       durationSeconds = (this.dataSize / bytesPerSecond);
/*     */     } 
/*     */     
/* 283 */     this.duration = new Time(durationSeconds);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 297 */     if (this.sampleSizeInBits > 8) {
/* 298 */       bool = true;
/*     */     } else {
/* 300 */       bool = false;
/*     */     } 
/* 302 */     this.format = new WavAudioFormat(this.encodingString, this.sampleRate, this.sampleSizeInBits, this.channels, this.blockAlign * 8, bytesPerSecond, 0, bool ? 1 : 0, -1.0F, Format.byteArray, codecSpecificHeader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Time setPosition(Time where, int rounding) {
/*     */     long l1;
/* 321 */     if (!this.seekable) {
/* 322 */       return getMediaTime();
/*     */     }
/* 324 */     long time = where.getNanoseconds();
/*     */ 
/*     */     
/* 327 */     if (time < 0L) {
/* 328 */       time = 0L;
/*     */     }
/*     */     
/* 331 */     if (this.timePerBlockNano <= 0.0D) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 339 */       int bytesPerSecond = this.sampleRate * this.blockAlign;
/* 340 */       double newPosd = (time * this.sampleRate * this.blockAlign) / 1.0E9D;
/* 341 */       double remainder = newPosd % this.blockAlign;
/*     */       
/* 343 */       l1 = (long)(newPosd - remainder);
/*     */       
/* 345 */       if (remainder > 0.0D) {
/* 346 */         switch (rounding) {
/*     */           case 1:
/* 348 */             l1 += this.blockAlign;
/*     */             break;
/*     */           case 3:
/* 351 */             if (remainder > this.blockAlign / 2.0D) {
/* 352 */               l1 += this.blockAlign;
/*     */             }
/*     */             break;
/*     */         } 
/*     */ 
/*     */       
/*     */       }
/*     */     } else {
/* 360 */       double blockNum = time / this.timePerBlockNano;
/* 361 */       int blockNumInt = (int)blockNum;
/* 362 */       double remainder = blockNum - blockNumInt;
/*     */       
/* 364 */       if (remainder > 0.0D)
/* 365 */         switch (rounding) {
/*     */           case 1:
/* 367 */             blockNumInt++;
/*     */             break;
/*     */           case 3:
/* 370 */             if (remainder > 0.5D) {
/* 371 */               blockNumInt++;
/*     */             }
/*     */             break;
/*     */         }  
/* 375 */       l1 = (blockNumInt * this.blockAlign);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 381 */     l1 += this.minLocation;
/* 382 */     ((BasicTrack)this.tracks[0]).setSeekLocation(l1);
/* 383 */     if (this.cacheStream != null) {
/* 384 */       synchronized (this) {
/*     */         
/* 386 */         this.cacheStream.abortRead();
/*     */       } 
/*     */     }
/* 389 */     return where;
/*     */   }
/*     */ 
/*     */   
/*     */   public Time getMediaTime() {
/* 394 */     long l1, seekLocation = ((BasicTrack)this.tracks[0]).getSeekLocation();
/* 395 */     if (seekLocation != -1L) {
/* 396 */       l1 = seekLocation - this.minLocation;
/*     */     } else {
/* 398 */       l1 = getLocation(this.stream) - this.minLocation;
/* 399 */     }  synchronized (this.mediaTime) {
/* 400 */       this.mediaTime.set(l1 * this.locationToMediaTime);
/*     */     } 
/* 402 */     return (Time)this.mediaTime;
/*     */   }
/*     */   
/*     */   public Time getDuration() {
/* 406 */     return this.duration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 415 */     return "Parser for WAV file format";
/*     */   }
/*     */ 
/*     */   
/*     */   class WavTrack
/*     */     extends BasicTrack
/*     */   {
/*     */     private double sampleRate;
/*     */     
/*     */     private float timePerFrame;
/*     */     
/*     */     private SettableTime frameToTime;
/*     */     private final WavParser this$0;
/*     */     
/*     */     WavTrack(WavParser this$0, WavAudioFormat format, boolean enabled, Time startTime, int numBuffers, int bufferSize, long minLocation, long maxLocation) {
/* 430 */       super(WavParser.this, (Format)format, enabled, WavParser.this.duration, startTime, numBuffers, bufferSize, WavParser.this.stream, minLocation, maxLocation);
/*     */       
/*     */       WavParser.this = WavParser.this;
/*     */       
/*     */       this.frameToTime = new SettableTime();
/* 435 */       double sampleRate = format.getSampleRate();
/* 436 */       int channels = format.getChannels();
/* 437 */       int sampleSizeInBits = format.getSampleSizeInBits();
/* 438 */       int blockSize = format.getFrameSizeInBits() / 8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 445 */       if (WavParser.this.encoding == 1 || WavParser.this.encoding == 7 || WavParser.this.encoding == 6 || WavParser.this.encoding == 257 || WavParser.this.encoding == 258) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 450 */         float bytesPerSecond = (float)sampleRate * blockSize;
/* 451 */         float bytesPerFrame = bufferSize;
/* 452 */         this.timePerFrame = bufferSize / bytesPerSecond;
/* 453 */       } else if (WavParser.this.encoding == 2 || WavParser.this.encoding == 17 || WavParser.this.encoding == 49) {
/*     */ 
/*     */ 
/*     */         
/* 457 */         float f1 = bufferSize;
/* 458 */         float blocksPerFrame = bufferSize / blockSize;
/* 459 */         float samplesPerFrame = blocksPerFrame * WavParser.this.samplesPerBlock;
/* 460 */         this.timePerFrame = (float)(samplesPerFrame / sampleRate);
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 466 */         float f1 = (float)sampleRate * blockSize;
/* 467 */         float f2 = bufferSize;
/* 468 */         this.timePerFrame = bufferSize / f1;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     WavTrack(WavAudioFormat format, boolean enabled, Time startTime, int numBuffers, int bufferSize) {
/* 474 */       this(format, enabled, startTime, numBuffers, bufferSize, 0L, Long.MAX_VALUE);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\parser\audio\WavParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */