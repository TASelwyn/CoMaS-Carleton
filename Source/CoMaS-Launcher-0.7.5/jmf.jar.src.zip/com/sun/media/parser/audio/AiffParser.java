/*     */ package com.sun.media.parser.audio;
/*     */ 
/*     */ import com.sun.media.parser.BasicPullParser;
/*     */ import com.sun.media.parser.BasicTrack;
/*     */ import com.sun.media.util.SettableTime;
/*     */ import java.io.IOException;
/*     */ import javax.media.BadHeaderException;
/*     */ import javax.media.Duration;
/*     */ import javax.media.Format;
/*     */ import javax.media.Time;
/*     */ import javax.media.Track;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.PullSourceStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AiffParser
/*     */   extends BasicPullParser
/*     */ {
/*  31 */   private Time duration = Duration.DURATION_UNKNOWN;
/*  32 */   private Format format = null;
/*  33 */   private Track[] tracks = new Track[1];
/*  34 */   private int numBuffers = 4;
/*  35 */   private int bufferSize = -1;
/*     */   private int dataSize;
/*  37 */   private SettableTime mediaTime = new SettableTime(0L);
/*  38 */   private PullSourceStream stream = null;
/*     */   private int maxFrame;
/*  40 */   private int blockSize = 0;
/*  41 */   private double sampleRate = -1.0D;
/*     */   private long minLocation;
/*     */   private long maxLocation;
/*  44 */   private String encodingString = null;
/*  45 */   private int samplesPerBlock = 1;
/*  46 */   private double timePerBlockNano = -1.0D;
/*  47 */   private double locationToMediaTime = -1.0D;
/*     */   
/*     */   public static final String FormID = "FORM";
/*     */   public static final String FormatVersionID = "FVER";
/*     */   public static final String CommonID = "COMM";
/*     */   public static final String SoundDataID = "SSND";
/*  53 */   private static ContentDescriptor[] supportedFormat = new ContentDescriptor[] { new ContentDescriptor("audio.x_aiff") };
/*     */   
/*     */   public static final int CommonIDSize = 18;
/*     */   
/*     */   private boolean isAIFC = false;
/*     */   
/*     */   private boolean commonChunkSeen = false;
/*     */   private boolean soundDataChunkSeen = false;
/*     */   private boolean formatVersionChunkSeen = false;
/*     */   
/*     */   public ContentDescriptor[] getSupportedInputContentDescriptors() {
/*  64 */     return supportedFormat;
/*     */   }
/*     */ 
/*     */   
/*     */   public Track[] getTracks() throws IOException, BadHeaderException {
/*  69 */     if (this.tracks[0] != null) {
/*  70 */       return this.tracks;
/*     */     }
/*  72 */     this.stream = (PullSourceStream)this.streams[0];
/*  73 */     if (this.cacheStream != null)
/*     */     {
/*  75 */       this.cacheStream.setEnabledBuffering(false);
/*     */     }
/*  77 */     readHeader();
/*  78 */     if (this.cacheStream != null) {
/*  79 */       this.cacheStream.setEnabledBuffering(true);
/*     */     }
/*     */     
/*  82 */     this.tracks[0] = (Track)new AiffTrack((AudioFormat)this.format, true, new Time(0L), this.numBuffers, this.bufferSize, this.minLocation, this.maxLocation);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     return this.tracks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readHeader() throws IOException, BadHeaderException {
/*  99 */     boolean signed = true;
/*     */     
/* 101 */     String magic = readString(this.stream);
/* 102 */     if (!magic.equals("FORM")) {
/* 103 */       throw new BadHeaderException("AIFF Parser: expected string FORM, got " + magic);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 108 */     int fileLength = readInt(this.stream) + 8;
/*     */     
/* 110 */     String formType = readString(this.stream);
/* 111 */     if (formType.equals("AIFC")) {
/* 112 */       this.isAIFC = true;
/*     */     } else {
/* 114 */       this.encodingString = "LINEAR";
/*     */     } 
/*     */     
/* 117 */     int remainingLength = fileLength - 12;
/*     */     
/* 119 */     String compressionType = null;
/* 120 */     int offset = 0;
/* 121 */     int channels = -1;
/* 122 */     int sampleSizeInBits = -1;
/*     */ 
/*     */     
/* 125 */     while (remainingLength >= 8) {
/* 126 */       String type = readString(this.stream);
/* 127 */       int size = readInt(this.stream);
/* 128 */       remainingLength -= 8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 138 */       if (type.equals("FVER")) {
/* 139 */         if (!this.isAIFC);
/*     */ 
/*     */         
/* 142 */         int timestamp = readInt(this.stream);
/* 143 */         if (size != 4) {
/* 144 */           throw new BadHeaderException("Illegal FormatVersionID: chunk size is not 4 but " + size);
/*     */         }
/*     */         
/* 147 */         this.formatVersionChunkSeen = true;
/* 148 */       } else if (type.equals("COMM")) {
/* 149 */         if (size < 18) {
/* 150 */           throw new BadHeaderException("Size of COMM chunk should be atleast 18");
/*     */         }
/*     */         
/* 153 */         channels = readShort(this.stream);
/*     */         
/* 155 */         if (channels < 1) {
/* 156 */           throw new BadHeaderException("Number of channels is " + channels);
/*     */         }
/* 158 */         this.maxFrame = readInt(this.stream);
/* 159 */         sampleSizeInBits = readShort(this.stream);
/* 160 */         if (sampleSizeInBits <= 0) {
/* 161 */           throw new BadHeaderException("Illegal sampleSize " + sampleSizeInBits);
/*     */         }
/* 163 */         this.sampleRate = readIeeeExtended(this.stream);
/* 164 */         if (this.sampleRate < 0.0D) {
/* 165 */           throw new BadHeaderException("Negative Sample Rate " + this.sampleRate);
/*     */         }
/* 167 */         int remainingCommSize = size - 18;
/* 168 */         if (this.isAIFC) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 173 */           if (remainingCommSize < 4) {
/* 174 */             throw new BadHeaderException("COMM chunk in AIFC doesn't have compressionType info");
/*     */           }
/* 176 */           compressionType = readString(this.stream);
/* 177 */           if (compressionType == null) {
/* 178 */             throw new BadHeaderException("Compression type for AIFC is null");
/*     */           }
/* 180 */           skip(this.stream, remainingCommSize - 4);
/*     */         } 
/* 182 */         this.commonChunkSeen = true;
/* 183 */       } else if (type.equals("SSND")) {
/* 184 */         if (this.soundDataChunkSeen) {
/* 185 */           throw new BadHeaderException("Cannot have more than 1 Sound Data Chunk");
/*     */         }
/*     */         
/* 188 */         offset = readInt(this.stream);
/* 189 */         this.blockSize = readInt(this.stream);
/* 190 */         this.minLocation = getLocation(this.stream);
/* 191 */         this.dataSize = size - 8;
/* 192 */         this.maxLocation = this.minLocation + this.dataSize;
/*     */         
/* 194 */         this.soundDataChunkSeen = true;
/* 195 */         if (this.commonChunkSeen) {
/*     */           
/* 197 */           remainingLength -= 8;
/*     */           break;
/*     */         } 
/* 200 */         skip(this.stream, size - 8);
/*     */       } else {
/*     */         
/* 203 */         skip(this.stream, size);
/*     */       } 
/* 205 */       remainingLength -= size;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 226 */     if (!this.commonChunkSeen) {
/* 227 */       throw new BadHeaderException("Mandatory chunk COMM missing");
/*     */     }
/*     */     
/* 230 */     if (!this.soundDataChunkSeen) {
/* 231 */       throw new BadHeaderException("Mandatory chunk SSND missing");
/*     */     }
/*     */     
/* 234 */     double durationSeconds = -1.0D;
/*     */     
/* 236 */     if (this.isAIFC) {
/* 237 */       String c = compressionType;
/* 238 */       if (c.equalsIgnoreCase("NONE")) {
/* 239 */         this.encodingString = "LINEAR";
/* 240 */       } else if (c.equalsIgnoreCase("twos")) {
/* 241 */         this.encodingString = "LINEAR";
/* 242 */       } else if (c.equalsIgnoreCase("raw")) {
/* 243 */         this.encodingString = "LINEAR";
/* 244 */         signed = false;
/* 245 */       } else if (c.equalsIgnoreCase("ULAW")) {
/* 246 */         this.encodingString = "ULAW";
/* 247 */         sampleSizeInBits = 8;
/* 248 */         signed = false;
/* 249 */       } else if (c.equalsIgnoreCase("ALAW")) {
/* 250 */         this.encodingString = "alaw";
/* 251 */         sampleSizeInBits = 8;
/* 252 */         signed = false;
/* 253 */       } else if (c.equalsIgnoreCase("G723")) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 267 */         this.encodingString = "g723";
/*     */ 
/*     */       
/*     */       }
/* 271 */       else if (c.equalsIgnoreCase("MAC3")) {
/*     */         
/* 273 */         this.encodingString = "MAC3";
/*     */         
/* 275 */         this.blockSize = 2;
/* 276 */         this.samplesPerBlock = 6;
/* 277 */         this.timePerBlockNano = this.samplesPerBlock * 1.0E9D / this.sampleRate;
/* 278 */       } else if (c.equalsIgnoreCase("MAC6")) {
/*     */         
/* 280 */         this.encodingString = "MAC6";
/*     */         
/* 282 */         this.blockSize = 1;
/* 283 */         this.samplesPerBlock = 6;
/* 284 */         this.timePerBlockNano = this.samplesPerBlock * 1.0E9D / this.sampleRate;
/* 285 */       } else if (c.equalsIgnoreCase("IMA4")) {
/* 286 */         this.encodingString = "ima4";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 294 */         this.blockSize = 34 * channels;
/* 295 */         this.samplesPerBlock = 64;
/* 296 */         this.timePerBlockNano = this.samplesPerBlock * 1.0E9D / this.sampleRate;
/*     */       } else {
/*     */         
/* 299 */         throw new BadHeaderException("Unsupported encoding" + c);
/*     */       } 
/*     */     } 
/*     */     
/* 303 */     if (this.blockSize == 0) {
/* 304 */       this.blockSize = channels * sampleSizeInBits / 8;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 332 */     this.bufferSize = this.blockSize * (int)(this.sampleRate / this.samplesPerBlock);
/* 333 */     durationSeconds = (this.maxFrame * this.samplesPerBlock) / this.sampleRate;
/*     */ 
/*     */     
/* 336 */     if (durationSeconds > 0.0D) {
/* 337 */       this.duration = new Time(durationSeconds);
/*     */     }
/* 339 */     this.locationToMediaTime = this.samplesPerBlock / this.sampleRate * this.blockSize;
/*     */     
/* 341 */     this.format = (Format)new AudioFormat(this.encodingString, this.sampleRate, sampleSizeInBits, channels, 1, signed ? 1 : 0, this.blockSize * 8, -1.0D, Format.byteArray);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Time setPosition(Time where, int rounding) {
/*     */     long l1;
/* 355 */     if (!this.seekable) {
/* 356 */       return getMediaTime();
/*     */     }
/*     */     
/* 359 */     long time = where.getNanoseconds();
/*     */ 
/*     */     
/* 362 */     if (time < 0L) {
/* 363 */       time = 0L;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 368 */     if (this.timePerBlockNano == -1.0D) {
/*     */ 
/*     */       
/* 371 */       int bytesPerSecond = (int)this.sampleRate * this.blockSize;
/* 372 */       double newPosd = time * this.sampleRate * this.blockSize / 1.0E9D;
/* 373 */       double remainder = newPosd % this.blockSize;
/*     */       
/* 375 */       l1 = (long)(newPosd - remainder);
/*     */       
/* 377 */       if (remainder > 0.0D) {
/* 378 */         switch (rounding) {
/*     */           case 1:
/* 380 */             l1 += this.blockSize;
/*     */             break;
/*     */           case 3:
/* 383 */             if (remainder > this.blockSize / 2.0D) {
/* 384 */               l1 += this.blockSize;
/*     */             }
/*     */             break;
/*     */         } 
/*     */       }
/*     */     } else {
/* 390 */       double blockNum = time / this.timePerBlockNano;
/* 391 */       int blockNumInt = (int)blockNum;
/* 392 */       double remainder = blockNum - blockNumInt;
/*     */       
/* 394 */       if (remainder > 0.0D)
/* 395 */         switch (rounding) {
/*     */           case 1:
/* 397 */             blockNumInt++;
/*     */             break;
/*     */           case 3:
/* 400 */             if (remainder > 0.5D) {
/* 401 */               blockNumInt++;
/*     */             }
/*     */             break;
/*     */         }  
/* 405 */       l1 = (blockNumInt * this.blockSize);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 411 */     l1 += this.minLocation;
/* 412 */     ((BasicTrack)this.tracks[0]).setSeekLocation(l1);
/* 413 */     if (this.cacheStream != null) {
/* 414 */       synchronized (this) {
/*     */         
/* 416 */         this.cacheStream.abortRead();
/*     */       } 
/*     */     }
/* 419 */     return where;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Time getMediaTime() {
/* 425 */     long l1, seekLocation = ((BasicTrack)this.tracks[0]).getSeekLocation();
/* 426 */     if (seekLocation != -1L) {
/* 427 */       l1 = seekLocation - this.minLocation;
/*     */     } else {
/* 429 */       l1 = getLocation(this.stream) - this.minLocation;
/* 430 */     }  synchronized (this.mediaTime) {
/* 431 */       this.mediaTime.set(l1 * this.locationToMediaTime);
/*     */     } 
/* 433 */     return (Time)this.mediaTime;
/*     */   }
/*     */   
/*     */   public Time getDuration() {
/* 437 */     if (this.maxFrame <= 0 && 
/* 438 */       this.tracks[0] != null) {
/* 439 */       long mediaSizeAtEOM = ((BasicTrack)this.tracks[0]).getMediaSizeAtEOM();
/* 440 */       if (mediaSizeAtEOM > 0L) {
/* 441 */         this.maxFrame = (int)(mediaSizeAtEOM / this.blockSize);
/* 442 */         double durationSeconds = (this.maxFrame * this.samplesPerBlock) / this.sampleRate;
/* 443 */         if (durationSeconds > 0.0D) {
/* 444 */           this.duration = new Time(durationSeconds);
/*     */         }
/*     */       } 
/*     */     } 
/* 448 */     return this.duration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 456 */     return "Parser for AIFF file format";
/*     */   }
/*     */   
/*     */   class AiffTrack
/*     */     extends BasicTrack {
/*     */     private double sampleRate;
/*     */     private float timePerFrame;
/*     */     private SettableTime frameToTime;
/*     */     private final AiffParser this$0;
/*     */     
/*     */     AiffTrack(AiffParser this$0, AudioFormat format, boolean enabled, Time startTime, int numBuffers, int bufferSize, long minLocation, long maxLocation) {
/* 467 */       super(AiffParser.this, (Format)format, enabled, AiffParser.this.duration, startTime, numBuffers, bufferSize, AiffParser.this.stream, minLocation, maxLocation);
/*     */       
/*     */       AiffParser.this = AiffParser.this;
/*     */       
/*     */       this.frameToTime = new SettableTime();
/* 472 */       double sampleRate = format.getSampleRate();
/* 473 */       int channels = format.getChannels();
/* 474 */       int sampleSizeInBits = format.getSampleSizeInBits();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 481 */       if (AiffParser.this.timePerBlockNano == -1.0D) {
/*     */         
/* 483 */         float bytesPerSecond = (float)(sampleRate * AiffParser.this.blockSize);
/* 484 */         this.timePerFrame = bufferSize / bytesPerSecond;
/*     */       } else {
/*     */         
/* 487 */         float blocksPerFrame = bufferSize / AiffParser.this.blockSize;
/* 488 */         float samplesPerFrame = blocksPerFrame * AiffParser.this.samplesPerBlock;
/* 489 */         this.timePerFrame = (float)(samplesPerFrame / sampleRate);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     AiffTrack(AudioFormat format, boolean enabled, Time startTime, int numBuffers, int bufferSize) {
/* 495 */       this(format, enabled, startTime, numBuffers, bufferSize, 0L, Long.MAX_VALUE);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double readIeeeExtended(PullSourceStream stream) throws IOException {
/* 513 */     double f = 0.0D;
/* 514 */     int expon = 0;
/* 515 */     long hiMant = 0L, loMant = 0L;
/*     */     
/* 517 */     double huge = 3.4028234663852886E38D;
/*     */ 
/*     */ 
/*     */     
/* 521 */     expon = readShort(stream);
/* 522 */     hiMant = readInt(stream);
/* 523 */     if (hiMant < 0L) {
/* 524 */       hiMant += 4294967296L;
/*     */     }
/* 526 */     loMant = readInt(stream);
/* 527 */     if (loMant < 0L) {
/* 528 */       loMant += 4294967296L;
/*     */     }
/* 530 */     if (expon == 0 && hiMant == 0L && loMant == 0L) {
/* 531 */       f = 0.0D;
/*     */     }
/* 533 */     else if (expon == 32767) {
/* 534 */       f = huge;
/*     */     } else {
/* 536 */       expon -= 16383;
/* 537 */       expon -= 31;
/* 538 */       f = hiMant * Math.pow(2.0D, expon);
/* 539 */       expon -= 32;
/* 540 */       f += loMant * Math.pow(2.0D, expon);
/*     */     } 
/*     */     
/* 543 */     return f;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\parser\audio\AiffParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */