/*      */ package com.sun.media.parser.video;
/*      */ 
/*      */ import com.sun.media.parser.BasicPullParser;
/*      */ import com.sun.media.util.SettableTime;
/*      */ import java.awt.Dimension;
/*      */ import java.io.IOException;
/*      */ import javax.media.BadHeaderException;
/*      */ import javax.media.Buffer;
/*      */ import javax.media.Duration;
/*      */ import javax.media.Format;
/*      */ import javax.media.IncompatibleSourceException;
/*      */ import javax.media.Time;
/*      */ import javax.media.Track;
/*      */ import javax.media.TrackListener;
/*      */ import javax.media.format.AudioFormat;
/*      */ import javax.media.format.RGBFormat;
/*      */ import javax.media.format.VideoFormat;
/*      */ import javax.media.format.YUVFormat;
/*      */ import javax.media.protocol.CachedStream;
/*      */ import javax.media.protocol.ContentDescriptor;
/*      */ import javax.media.protocol.DataSource;
/*      */ import javax.media.protocol.PullSourceStream;
/*      */ import javax.media.protocol.Seekable;
/*      */ import javax.media.protocol.SourceStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class QuicktimeParser
/*      */   extends BasicPullParser
/*      */ {
/*      */   private final boolean enableHintTrackSupport = true;
/*   36 */   private static ContentDescriptor[] supportedFormat = new ContentDescriptor[] { new ContentDescriptor("video.quicktime") };
/*   37 */   private PullSourceStream stream = null;
/*      */   
/*      */   private Track[] tracks;
/*      */   
/*      */   private Seekable seekableStream;
/*      */   
/*      */   private boolean mdatAtomPresent = false;
/*      */   
/*      */   private boolean moovAtomPresent = false;
/*      */   public static final int MVHD_ATOM_SIZE = 100;
/*      */   public static final int TKHD_ATOM_SIZE = 84;
/*      */   public static final int MDHD_ATOM_SIZE = 24;
/*      */   public static final int MIN_HDLR_ATOM_SIZE = 24;
/*      */   public static final int MIN_STSD_ATOM_SIZE = 8;
/*      */   public static final int MIN_STTS_ATOM_SIZE = 8;
/*      */   public static final int MIN_STSC_ATOM_SIZE = 8;
/*      */   public static final int MIN_STSZ_ATOM_SIZE = 8;
/*      */   public static final int MIN_STCO_ATOM_SIZE = 8;
/*      */   public static final int MIN_STSS_ATOM_SIZE = 8;
/*      */   public static final int MIN_VIDEO_SAMPLE_DATA_SIZE = 70;
/*      */   public static final int MIN_AUDIO_SAMPLE_DATA_SIZE = 20;
/*      */   public static final int TRACK_ENABLED = 1;
/*      */   public static final int TRACK_IN_MOVIE = 2;
/*      */   public static final int TRACK_IN_PREVIEW = 4;
/*      */   public static final int TRACK_IN_POSTER = 8;
/*      */   public static final String VIDEO = "vide";
/*      */   public static final String AUDIO = "soun";
/*      */   public static final String HINT = "hint";
/*      */   private static final int DATA_SELF_REFERENCE_FLAG = 1;
/*      */   private static final int HINT_NOP_IGNORE = 0;
/*      */   private static final int HINT_IMMEDIATE_DATA = 1;
/*      */   private static final int HINT_SAMPLE_DATA = 2;
/*      */   private static final int HINT_SAMPLE_DESCRIPTION = 3;
/*   70 */   private MovieHeader movieHeader = new MovieHeader();
/*      */   
/*   72 */   private int numTracks = 0;
/*   73 */   private int numSupportedTracks = 0;
/*   74 */   private int numberOfHintTracks = 0;
/*      */   
/*   76 */   private static int MAX_TRACKS_SUPPORTED = 100;
/*   77 */   private TrakList[] trakList = new TrakList[MAX_TRACKS_SUPPORTED];
/*      */   private TrakList currentTrack;
/*   79 */   private int keyFrameTrack = -1;
/*   80 */   private SettableTime mediaTime = new SettableTime(0L);
/*      */   
/*   82 */   private int hintAudioTrackNum = -1;
/*      */   
/*      */   private boolean debug = false;
/*      */   
/*      */   private boolean debug1 = false;
/*      */   
/*      */   private boolean debug2 = false;
/*      */   
/*   90 */   private Object seekSync = new Object();
/*      */ 
/*      */   
/*   93 */   private int tmpIntBufferSize = 16384;
/*   94 */   private byte[] tmpBuffer = new byte[this.tmpIntBufferSize * 4];
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean supports(SourceStream[] s) {
/*  100 */     return this.seekable;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
/*  106 */     super.setSource(source);
/*  107 */     this.stream = (PullSourceStream)this.streams[0];
/*  108 */     this.seekableStream = (Seekable)this.streams[0];
/*      */   }
/*      */   
/*      */   private CachedStream getCacheStream() {
/*  112 */     return this.cacheStream;
/*      */   }
/*      */   
/*      */   public ContentDescriptor[] getSupportedInputContentDescriptors() {
/*  116 */     return supportedFormat;
/*      */   }
/*      */   
/*      */   public Track[] getTracks() throws IOException, BadHeaderException {
/*  120 */     if (this.tracks != null) {
/*  121 */       return this.tracks;
/*      */     }
/*  123 */     if (this.seekableStream == null) {
/*  124 */       return new Track[0];
/*      */     }
/*      */     
/*  127 */     if (this.cacheStream != null)
/*      */     {
/*  129 */       this.cacheStream.setEnabledBuffering(false);
/*      */     }
/*  131 */     readHeader();
/*  132 */     if (this.cacheStream != null) {
/*  133 */       this.cacheStream.setEnabledBuffering(true);
/*      */     }
/*      */     
/*  136 */     this.tracks = new Track[this.numSupportedTracks];
/*      */ 
/*      */ 
/*      */     
/*  140 */     int index = 0;
/*  141 */     for (int i = 0; i < this.numSupportedTracks; i++) {
/*  142 */       TrakList trakInfo = this.trakList[i];
/*  143 */       if (trakInfo.trackType.equals("soun")) {
/*  144 */         this.tracks[i] = new AudioTrack(this, trakInfo);
/*      */       
/*      */       }
/*  147 */       else if (trakInfo.trackType.equals("vide")) {
/*  148 */         this.tracks[i] = new VideoTrack(this, trakInfo);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  153 */     for (int j = 0; j < this.numSupportedTracks; j++) {
/*  154 */       TrakList trakInfo = this.trakList[j];
/*  155 */       if (trakInfo.trackType.equals("hint")) {
/*  156 */         int trackBeingHinted = trakInfo.trackIdOfTrackBeingHinted;
/*  157 */         for (int k = 0; k < this.numTracks; k++) {
/*  158 */           if (trackBeingHinted == (this.trakList[k]).id) {
/*  159 */             trakInfo.indexOfTrackBeingHinted = k;
/*  160 */             String hintedTrackType = (this.trakList[k]).trackType;
/*  161 */             String encodingOfHintedTrack = (this.trakList[trakInfo.indexOfTrackBeingHinted]).media.encoding;
/*      */ 
/*      */             
/*  164 */             if (encodingOfHintedTrack.equals("agsm")) {
/*  165 */               encodingOfHintedTrack = "gsm";
/*      */             }
/*  167 */             String rtpEncoding = encodingOfHintedTrack + "/rtp";
/*  168 */             if (hintedTrackType.equals("soun")) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  174 */               Audio audio = (Audio)(this.trakList[k]).media;
/*      */               
/*  176 */               this.hintAudioTrackNum = j;
/*      */               
/*  178 */               int channels = audio.channels;
/*  179 */               int frameSizeInBytes = audio.frameSizeInBits / 8;
/*  180 */               int samplesPerBlock = audio.samplesPerBlock;
/*  181 */               int sampleRate = audio.sampleRate;
/*      */               
/*  183 */               ((Hint)trakInfo.media).format = (Format)new AudioFormat(rtpEncoding, sampleRate, 8, channels);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  189 */               this.tracks[j] = new HintAudioTrack(this, trakInfo, channels, rtpEncoding, frameSizeInBytes, samplesPerBlock, sampleRate);
/*      */ 
/*      */ 
/*      */               
/*      */               break;
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/*  198 */             if (hintedTrackType.equals("vide")) {
/*      */               
/*  200 */               int indexOfTrackBeingHinted = trakInfo.indexOfTrackBeingHinted;
/*  201 */               TrakList sampleTrakInfo = null;
/*  202 */               if (indexOfTrackBeingHinted >= 0) {
/*  203 */                 sampleTrakInfo = this.trakList[indexOfTrackBeingHinted];
/*      */               }
/*      */               
/*  206 */               int width = 0;
/*  207 */               int height = 0;
/*  208 */               if (sampleTrakInfo != null) {
/*  209 */                 Video sampleTrakVideo = (Video)sampleTrakInfo.media;
/*  210 */                 width = sampleTrakVideo.width;
/*  211 */                 height = sampleTrakVideo.height;
/*      */               } 
/*      */               
/*  214 */               if (width > 0 && height > 0) {
/*  215 */                 ((Hint)trakInfo.media).format = (Format)new VideoFormat(rtpEncoding, new Dimension(width, height), -1, null, -1.0F);
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  224 */               HintVideoTrack hintVideoTrack = new HintVideoTrack(this, trakInfo);
/*      */               
/*  226 */               this.tracks[j] = hintVideoTrack;
/*      */             } 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  236 */     return this.tracks;
/*      */   }
/*      */ 
/*      */   
/*      */   private void readHeader() throws IOException, BadHeaderException {
/*      */     do {
/*      */     
/*  243 */     } while (parseAtom());
/*  244 */     if (!this.moovAtomPresent) {
/*  245 */       throw new BadHeaderException("moov atom not present");
/*      */     }
/*  247 */     if (!this.mdatAtomPresent) {
/*  248 */       throw new BadHeaderException("mdat atom not present");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  253 */     for (int i = 0; i < this.numSupportedTracks; i++) {
/*  254 */       TrakList trak = this.trakList[i];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  266 */       if (trak.buildSyncTable()) {
/*  267 */         this.keyFrameTrack = i;
/*      */       }
/*      */       
/*  270 */       trak.buildSamplePerChunkTable();
/*      */ 
/*      */       
/*  273 */       if (!trak.trackType.equals("soun")) {
/*  274 */         trak.buildSampleOffsetTable();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  280 */         trak.buildStartTimeAndDurationTable();
/*      */         
/*  282 */         float frameRate = (float)(trak.numberOfSamples / trak.duration.getSeconds());
/*      */ 
/*      */         
/*  285 */         trak.media.frameRate = frameRate;
/*      */       } 
/*      */ 
/*      */       
/*  289 */       trak.buildCumulativeSamplePerChunkTable();
/*  290 */       trak.media.createFormat();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time setPosition(Time where, int rounding) {
/*  301 */     double time = where.getSeconds();
/*  302 */     if (time < 0.0D) {
/*  303 */       time = 0.0D;
/*      */     }
/*      */     
/*      */     int keyT;
/*      */     
/*  308 */     if (((keyT = this.keyFrameTrack) != -1 && this.tracks[this.keyFrameTrack].isEnabled()) || ((keyT = this.hintAudioTrackNum) != -1 && this.tracks[this.hintAudioTrackNum].isEnabled())) {
/*      */ 
/*      */ 
/*      */       
/*  312 */       TrakList trakInfo = this.trakList[keyT];
/*  313 */       int index = trakInfo.time2Index(time);
/*      */       
/*  315 */       if (index < 0) {
/*  316 */         ((MediaTrack)this.tracks[keyT]).setSampleIndex(trakInfo.numberOfSamples + 1);
/*      */       } else {
/*      */         int j;
/*      */         
/*  320 */         if (keyT == this.keyFrameTrack) {
/*  321 */           if (index >= trakInfo.syncSampleMapping.length) {
/*  322 */             index = trakInfo.syncSampleMapping.length - 1;
/*      */           }
/*  324 */           if (trakInfo.syncSampleMapping != null) {
/*  325 */             j = trakInfo.syncSampleMapping[index];
/*  326 */             double newtime = (trakInfo.index2TimeAndDuration(j)).startTime;
/*  327 */             time = newtime;
/*      */           }
/*      */           else {
/*      */             
/*  331 */             j = index;
/*      */           } 
/*      */         } else {
/*  334 */           j = index;
/*  335 */           double newtime = (trakInfo.index2TimeAndDuration(j)).startTime;
/*  336 */           time = newtime;
/*      */         } 
/*  338 */         ((MediaTrack)this.tracks[keyT]).setSampleIndex(j);
/*      */       } 
/*      */     } 
/*      */     
/*  342 */     for (int i = 0; i < this.numSupportedTracks; i++) {
/*  343 */       if (i != keyT)
/*      */       {
/*      */ 
/*      */         
/*  347 */         if (this.tracks[i].isEnabled()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  353 */           TrakList trakInfo = this.trakList[i];
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  358 */           int index = trakInfo.time2Index(time);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  363 */           if (trakInfo.trackType.equals("vide") || (trakInfo.trackType.equals("hint") && this.tracks[i] instanceof HintVideoTrack)) {
/*      */ 
/*      */ 
/*      */             
/*  367 */             if (index < 0) {
/*  368 */               ((MediaTrack)this.tracks[i]).setSampleIndex(trakInfo.numberOfSamples + 1);
/*      */             } else {
/*      */               int j;
/*  371 */               if (trakInfo.syncSampleMapping != null) {
/*  372 */                 j = trakInfo.syncSampleMapping[index];
/*      */               } else {
/*  374 */                 j = index;
/*  375 */               }  ((MediaTrack)this.tracks[i]).setSampleIndex(j);
/*      */             }
/*      */           
/*      */           }
/*  379 */           else if (index < 0) {
/*  380 */             ((MediaTrack)this.tracks[i]).setChunkNumber(trakInfo.numberOfChunks + 1);
/*      */           } else {
/*      */             int j;
/*      */             
/*  384 */             ((MediaTrack)this.tracks[i]).setSampleIndex(index);
/*      */ 
/*      */             
/*  387 */             int chunkNumber = trakInfo.index2Chunk(index);
/*      */             
/*  389 */             if (chunkNumber != 0) {
/*  390 */               if (trakInfo.constantSamplesPerChunk == -1)
/*      */               {
/*      */                 
/*  393 */                 j = index - trakInfo.samplesPerChunk[chunkNumber - 1];
/*      */               }
/*      */               else
/*      */               {
/*  397 */                 j = index - chunkNumber * trakInfo.constantSamplesPerChunk;
/*      */               }
/*      */             
/*      */             } else {
/*      */               
/*  402 */               j = index;
/*      */             } 
/*  404 */             ((AudioTrack)this.tracks[i]).setChunkNumberAndSampleOffset(chunkNumber, j);
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*  409 */     if (this.cacheStream != null) {
/*  410 */       synchronized (this) {
/*  411 */         this.cacheStream.abortRead();
/*      */       } 
/*      */     }
/*  414 */     synchronized (this.mediaTime) {
/*  415 */       this.mediaTime.set(time);
/*      */     } 
/*  417 */     return (Time)this.mediaTime;
/*      */   }
/*      */ 
/*      */   
/*      */   public Time getMediaTime() {
/*  422 */     return null;
/*      */   }
/*      */   
/*      */   public Time getDuration() {
/*  426 */     return this.movieHeader.duration;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  435 */     return "Parser for quicktime file format";
/*      */   }
/*      */   
/*      */   private boolean parseAtom() throws BadHeaderException {
/*  439 */     boolean readSizeField = false;
/*      */     
/*      */     try {
/*  442 */       int atomSize = readInt(this.stream);
/*      */       
/*  444 */       readSizeField = true;
/*      */       
/*  446 */       String atom = readString(this.stream);
/*      */ 
/*      */       
/*  449 */       if (atomSize < 8) {
/*  450 */         throw new BadHeaderException(atom + ": Bad Atom size " + atomSize);
/*      */       }
/*  452 */       if (atom.equals("moov"))
/*  453 */         return parseMOOV(atomSize - 8); 
/*  454 */       if (atom.equals("mdat"))
/*  455 */         return parseMDAT(atomSize - 8); 
/*  456 */       skipAtom(atom + " [not implemented]", atomSize - 8);
/*  457 */       return true;
/*      */     } catch (IOException e) {
/*      */       
/*  460 */       if (!readSizeField)
/*      */       {
/*  462 */         return false;
/*      */       }
/*  464 */       throw new BadHeaderException("Unexpected End of Media");
/*      */     } 
/*      */   }
/*      */   
/*      */   private void skipAtom(String atom, int size) throws IOException {
/*  469 */     if (this.debug2)
/*  470 */       System.out.println("skip unsupported atom " + atom); 
/*  471 */     skip(this.stream, size);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean parseMOOV(int moovSize) throws BadHeaderException {
/*  480 */     boolean trakAtomPresent = false;
/*      */     
/*      */     try {
/*  483 */       this.moovAtomPresent = true;
/*  484 */       long moovMax = getLocation(this.stream) + moovSize;
/*  485 */       int remainingSize = moovSize;
/*      */ 
/*      */       
/*  488 */       int atomSize = readInt(this.stream);
/*  489 */       String atom = readString(this.stream);
/*      */       
/*  491 */       if (atomSize < 8) {
/*  492 */         throw new BadHeaderException(atom + ": Bad Atom size " + atomSize);
/*      */       }
/*  494 */       if (!atom.equals("mvhd")) {
/*  495 */         if (atom.equals("cmov")) {
/*  496 */           throw new BadHeaderException("Compressed movie headers are not supported");
/*      */         }
/*  498 */         throw new BadHeaderException("Expected mvhd atom but got " + atom);
/*      */       } 
/*  500 */       parseMVHD(atomSize - 8);
/*      */ 
/*      */       
/*  503 */       remainingSize -= atomSize;
/*      */ 
/*      */ 
/*      */       
/*  507 */       while (remainingSize > 0) {
/*  508 */         atomSize = readInt(this.stream);
/*  509 */         atom = readString(this.stream);
/*  510 */         if (atom.equals("trak")) {
/*  511 */           if (this.trakList[this.numSupportedTracks] == null) {
/*  512 */             this.trakList[this.numSupportedTracks] = this.currentTrack = new TrakList();
/*      */           }
/*  514 */           if (parseTRAK(atomSize - 8)) {
/*  515 */             this.numSupportedTracks++;
/*      */           }
/*  517 */           trakAtomPresent = true;
/*  518 */           this.numTracks++;
/*  519 */         } else if (atom.equals("ctab")) {
/*  520 */           parseCTAB(atomSize - 8);
/*      */         } else {
/*  522 */           skipAtom(atom + " [atom in moov: not implemented]", atomSize - 8);
/*      */         } 
/*  524 */         remainingSize -= atomSize;
/*      */       } 
/*      */       
/*  527 */       if (!trakAtomPresent) {
/*  528 */         throw new BadHeaderException("trak atom not present in trak atom container");
/*      */       }
/*  530 */       return !this.mdatAtomPresent;
/*      */     } catch (IOException e) {
/*  532 */       throw new BadHeaderException("IOException when parsing the header");
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean parseMDAT(int size) throws BadHeaderException {
/*      */     try {
/*  538 */       this.mdatAtomPresent = true;
/*  539 */       this.movieHeader.mdatStart = getLocation(this.stream);
/*  540 */       this.movieHeader.mdatSize = size;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  555 */       if (!this.moovAtomPresent) {
/*  556 */         skip(this.stream, size);
/*  557 */         return true;
/*      */       } 
/*  559 */       return false;
/*      */     } catch (IOException e) {
/*  561 */       throw new BadHeaderException("Got IOException when seeking past MDAT atom");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseMVHD(int size) throws BadHeaderException {
/*      */     try {
/*  570 */       if (size != 100) {
/*  571 */         throw new BadHeaderException("mvhd atom: header size is incorrect");
/*      */       }
/*      */ 
/*      */       
/*  575 */       skip(this.stream, 12);
/*      */       
/*  577 */       this.movieHeader.timeScale = readInt(this.stream);
/*  578 */       int duration = readInt(this.stream);
/*  579 */       this.movieHeader.duration = new Time(duration / this.movieHeader.timeScale);
/*      */       
/*  581 */       int preferredRate = readInt(this.stream);
/*  582 */       int preferredVolume = readShort(this.stream);
/*      */       
/*  584 */       skip(this.stream, 10);
/*  585 */       skip(this.stream, 36);
/*      */       
/*  587 */       int previewTime = readInt(this.stream);
/*  588 */       int previewDuration = readInt(this.stream);
/*  589 */       int posterTime = readInt(this.stream);
/*  590 */       int selectionTime = readInt(this.stream);
/*  591 */       int selectionDuration = readInt(this.stream);
/*  592 */       int currentTime = readInt(this.stream);
/*  593 */       int nextTrackID = readInt(this.stream);
/*      */     } catch (IOException e) {
/*  595 */       throw new BadHeaderException("Got IOException when seeking past MVHD atom");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean parseTRAK(int trakSize) throws BadHeaderException {
/*  604 */     boolean mdiaAtomPresent = false;
/*  605 */     boolean supported = false;
/*      */     try {
/*  607 */       int remainingSize = trakSize;
/*  608 */       int atomSize = readInt(this.stream);
/*  609 */       String atom = readString(this.stream);
/*      */       
/*  611 */       if (atomSize < 8) {
/*  612 */         throw new BadHeaderException(atom + ": Bad Atom size " + atomSize);
/*      */       }
/*  614 */       if (!atom.equals("tkhd")) {
/*  615 */         throw new BadHeaderException("Expected tkhd atom but got " + atom);
/*      */       }
/*  617 */       parseTKHD(atomSize - 8);
/*  618 */       remainingSize -= atomSize;
/*      */ 
/*      */       
/*  621 */       while (remainingSize > 0) {
/*  622 */         atomSize = readInt(this.stream);
/*  623 */         atom = readString(this.stream);
/*  624 */         if (atom.equals("mdia")) {
/*  625 */           supported = parseMDIA(atomSize - 8);
/*  626 */           mdiaAtomPresent = true;
/*  627 */         } else if (atom.equals("tref")) {
/*  628 */           parseTREF(atomSize - 8);
/*      */         } else {
/*  630 */           skipAtom(atom + " [atom in trak: not implemented]", atomSize - 8);
/*      */         } 
/*  632 */         remainingSize -= atomSize;
/*      */       } 
/*      */     } catch (IOException e) {
/*  635 */       throw new BadHeaderException("Got IOException when seeking past TRAK atom");
/*      */     } 
/*  637 */     if (!mdiaAtomPresent) {
/*  638 */       throw new BadHeaderException("mdia atom not present in trak atom container");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  645 */     if (supported && this.currentTrack.media == null)
/*      */     {
/*  647 */       supported = false;
/*      */     }
/*  649 */     return supported;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseCTAB(int ctabSize) throws BadHeaderException {
/*      */     try {
/*  656 */       skip(this.stream, ctabSize);
/*      */     } catch (IOException e) {
/*      */       
/*  659 */       throw new BadHeaderException("....");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseTKHD(int tkhdSize) throws BadHeaderException {
/*      */     try {
/*  669 */       if (tkhdSize != 84) {
/*  670 */         throw new BadHeaderException("mvhd atom: header size is incorrect");
/*      */       }
/*  672 */       int iVersionPlusFlag = readInt(this.stream);
/*  673 */       this.currentTrack.flag = iVersionPlusFlag & 0xFFFFFF;
/*  674 */       skip(this.stream, 8);
/*  675 */       this.currentTrack.id = readInt(this.stream);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  683 */       skip(this.stream, 4);
/*  684 */       int duration = readInt(this.stream);
/*  685 */       this.currentTrack.duration = new Time(duration / this.movieHeader.timeScale);
/*      */       
/*  687 */       skip(this.stream, tkhdSize - 4 - 8 - 4 - 4 - 4);
/*      */     } catch (IOException e) {
/*  689 */       throw new BadHeaderException("Got IOException when seeking past TKHD atom");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean parseMDIA(int mdiaSize) throws BadHeaderException {
/*  703 */     boolean hdlrAtomPresent = false;
/*  704 */     boolean minfAtomPresent = false;
/*      */     
/*      */     try {
/*  707 */       this.currentTrack.trackType = null;
/*  708 */       int remainingSize = mdiaSize;
/*  709 */       int atomSize = readInt(this.stream);
/*  710 */       String atom = readString(this.stream);
/*      */       
/*  712 */       if (atomSize < 8) {
/*  713 */         throw new BadHeaderException(atom + ": Bad Atom size " + atomSize);
/*      */       }
/*  715 */       if (!atom.equals("mdhd")) {
/*  716 */         throw new BadHeaderException("Expected mdhd atom but got " + atom);
/*      */       }
/*  718 */       parseMDHD(atomSize - 8);
/*  719 */       remainingSize -= atomSize;
/*      */ 
/*      */       
/*  722 */       while (remainingSize > 0) {
/*  723 */         atomSize = readInt(this.stream);
/*  724 */         atom = readString(this.stream);
/*  725 */         if (atom.equals("hdlr")) {
/*  726 */           parseHDLR(atomSize - 8);
/*  727 */           hdlrAtomPresent = true;
/*  728 */         } else if (atom.equals("minf")) {
/*  729 */           if (this.currentTrack.trackType == null) {
/*  730 */             throw new BadHeaderException("In MDIA atom container minf atom appears before hdlr");
/*      */           }
/*  732 */           if (this.currentTrack.supported) {
/*  733 */             parseMINF(atomSize - 8);
/*      */           } else {
/*  735 */             skipAtom(atom + " [atom in mdia] as trackType " + this.currentTrack.trackType + " is not supported", atomSize - 8);
/*      */           } 
/*      */ 
/*      */           
/*  739 */           minfAtomPresent = true;
/*      */         } else {
/*  741 */           skipAtom(atom + " [atom in mdia: not implemented]", atomSize - 8);
/*      */         } 
/*  743 */         remainingSize -= atomSize;
/*      */       } 
/*  745 */       if (!hdlrAtomPresent)
/*  746 */         throw new BadHeaderException("hdlr atom not present in mdia atom container"); 
/*  747 */       if (!minfAtomPresent) {
/*  748 */         throw new BadHeaderException("minf atom not present in mdia atom container");
/*      */       }
/*  750 */       return this.currentTrack.supported;
/*      */     } catch (IOException e) {
/*  752 */       throw new BadHeaderException("Got IOException when seeking past MDIA atom");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseMDHD(int mdhdSize) throws BadHeaderException {
/*      */     try {
/*  761 */       if (mdhdSize != 24) {
/*  762 */         throw new BadHeaderException("mdhd atom: header size is incorrect");
/*      */       }
/*      */ 
/*      */       
/*  766 */       skip(this.stream, 12);
/*  767 */       int timeScale = readInt(this.stream);
/*  768 */       int duration = readInt(this.stream);
/*  769 */       this.currentTrack.mediaDuration = new Time(duration / timeScale);
/*  770 */       this.currentTrack.mediaTimeScale = timeScale;
/*  771 */       skip(this.stream, 4);
/*      */     } catch (IOException e) {
/*  773 */       throw new BadHeaderException("Got IOException when seeking past MDHD atom");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseHDLR(int hdlrSize) throws BadHeaderException {
/*      */     try {
/*  782 */       if (hdlrSize < 24) {
/*  783 */         throw new BadHeaderException("hdlr atom: header size is incorrect");
/*      */       }
/*      */ 
/*      */       
/*  787 */       skip(this.stream, 8);
/*  788 */       this.currentTrack.trackType = readString(this.stream);
/*      */       
/*  790 */       this.currentTrack.supported = isSupported(this.currentTrack.trackType);
/*      */ 
/*      */ 
/*      */       
/*  794 */       skip(this.stream, hdlrSize - 8 - 4);
/*      */     } catch (IOException e) {
/*  796 */       throw new BadHeaderException("Got IOException when seeking past HDLR atom");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseTREF(int size) throws BadHeaderException {
/*      */     try {
/*  806 */       int childAtomSize = readInt(this.stream);
/*  807 */       size -= 4;
/*      */ 
/*      */       
/*  810 */       String atom = readString(this.stream);
/*  811 */       size -= 4;
/*      */       
/*  813 */       if (atom.equalsIgnoreCase("hint")) {
/*  814 */         this.currentTrack.trackIdOfTrackBeingHinted = readInt(this.stream);
/*  815 */         size -= 4;
/*      */       } 
/*      */       
/*  818 */       skip(this.stream, size);
/*      */     } catch (IOException e) {
/*  820 */       throw new BadHeaderException("Got IOException when seeking past HDLR atom");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseMINF(int minfSize) throws BadHeaderException {
/*  834 */     boolean hdlrAtomPresent = false;
/*      */     try {
/*  836 */       int remainingSize = minfSize;
/*  837 */       int atomSize = readInt(this.stream);
/*  838 */       String atom = readString(this.stream);
/*      */       
/*  840 */       if (atomSize < 8) {
/*  841 */         throw new BadHeaderException(atom + ": Bad Atom size " + atomSize);
/*      */       }
/*  843 */       if (!atom.endsWith("hd")) {
/*  844 */         throw new BadHeaderException("Expected media information header atom but got " + atom);
/*      */       }
/*  846 */       skipAtom(atom + " [atom in minf: not implemented]", atomSize - 8);
/*      */       
/*  848 */       remainingSize -= atomSize;
/*      */ 
/*      */       
/*  851 */       while (remainingSize > 0) {
/*  852 */         atomSize = readInt(this.stream);
/*  853 */         atom = readString(this.stream);
/*  854 */         if (atom.equals("hdlr")) {
/*  855 */           skipAtom(atom + " [atom in minf: not implemented]", atomSize - 8);
/*  856 */           hdlrAtomPresent = true;
/*  857 */         } else if (atom.equals("dinf")) {
/*  858 */           parseDINF(atomSize - 8);
/*  859 */         } else if (atom.equals("stbl")) {
/*  860 */           parseSTBL(atomSize - 8);
/*      */         } else {
/*  862 */           skipAtom(atom + " [atom in minf: not implemented]", atomSize - 8);
/*      */         } 
/*  864 */         remainingSize -= atomSize;
/*      */       } 
/*  866 */       if (!hdlrAtomPresent) {
/*  867 */         throw new BadHeaderException("hdlr atom not present in minf atom container");
/*      */       }
/*      */     } catch (IOException e) {
/*  870 */       throw new BadHeaderException("Got IOException when seeking past MINF atom");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void parseDINF(int dinfSize) throws BadHeaderException {
/*      */     try {
/*  877 */       int remainingSize = dinfSize;
/*      */ 
/*      */       
/*  880 */       while (remainingSize > 0) {
/*  881 */         int atomSize = readInt(this.stream);
/*  882 */         String atom = readString(this.stream);
/*      */ 
/*      */         
/*  885 */         if (atom.equals("dref")) {
/*  886 */           parseDREF(atomSize - 8);
/*      */         } else {
/*  888 */           skipAtom(atom + " [Unknown atom in dinf]", atomSize - 8);
/*      */         } 
/*  890 */         remainingSize -= atomSize;
/*      */       } 
/*      */     } catch (IOException e) {
/*  893 */       throw new BadHeaderException("Got IOException when seeking past DIMF atom");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseDREF(int drefSize) throws BadHeaderException {
/*      */     try {
/*  906 */       skip(this.stream, 4);
/*  907 */       int numEntries = readInt(this.stream);
/*      */ 
/*      */       
/*  910 */       for (int i = 0; i < numEntries; i++) {
/*  911 */         int drefEntrySize = readInt(this.stream);
/*      */         
/*  913 */         int type = readInt(this.stream);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  926 */         int versionPlusFlag = readInt(this.stream);
/*      */         
/*  928 */         skip(this.stream, drefEntrySize - 12);
/*  929 */         if ((versionPlusFlag & 0x1) <= 0) {
/*  930 */           throw new BadHeaderException("Only self contained Quicktime movies are supported");
/*      */         }
/*      */       } 
/*      */     } catch (IOException e) {
/*  934 */       throw new BadHeaderException("Got IOException when seeking past DREF atom");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseSTBL(int stblSize) throws BadHeaderException {
/*      */     try {
/*  944 */       int remainingSize = stblSize;
/*      */       
/*  946 */       while (remainingSize > 0) {
/*  947 */         int atomSize = readInt(this.stream);
/*  948 */         String atom = readString(this.stream);
/*  949 */         if (atom.equals("stsd")) {
/*  950 */           parseSTSD(atomSize - 8);
/*  951 */         } else if (atom.equals("stts")) {
/*  952 */           parseSTTS(atomSize - 8);
/*  953 */         } else if (atom.equals("stss")) {
/*  954 */           parseSTSS(atomSize - 8);
/*  955 */         } else if (atom.equals("stsc")) {
/*  956 */           parseSTSC(atomSize - 8);
/*  957 */         } else if (atom.equals("stsz")) {
/*  958 */           parseSTSZ(atomSize - 8);
/*  959 */         } else if (atom.equals("stco")) {
/*  960 */           parseSTCO(atomSize - 8);
/*  961 */         } else if (atom.equals("stsh")) {
/*      */           
/*  963 */           skipAtom(atom + " [not implemented]", atomSize - 8);
/*      */         } else {
/*  965 */           skipAtom(atom + " [UNKNOWN atom in stbl: ignored]", atomSize - 8);
/*      */         } 
/*  967 */         remainingSize -= atomSize;
/*      */       } 
/*      */     } catch (IOException e) {
/*  970 */       throw new BadHeaderException("Got IOException when seeking past STBL atom");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseSTSD(int stsdSize) throws BadHeaderException {
/*      */     try {
/*  982 */       if (stsdSize < 8) {
/*  983 */         throw new BadHeaderException("stsd atom: header size is incorrect");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  990 */       skip(this.stream, 4);
/*      */       
/*  992 */       int numEntries = readInt(this.stream);
/*      */ 
/*      */       
/*  995 */       if (numEntries > 1);
/*      */ 
/*      */       
/*  998 */       for (int i = 0; i < numEntries; i++) {
/*  999 */         int sampleDescriptionSize = readInt(this.stream);
/*      */ 
/*      */         
/* 1002 */         String encoding = readString(this.stream);
/*      */ 
/*      */         
/* 1005 */         if (i != 0) {
/* 1006 */           skip(this.stream, sampleDescriptionSize - 8);
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1011 */           skip(this.stream, 6);
/*      */ 
/*      */           
/* 1014 */           if (this.currentTrack.trackType.equals("vide")) {
/* 1015 */             this.currentTrack.media = parseVideoSampleData(encoding, sampleDescriptionSize - 4 - 4 - 6);
/*      */           
/*      */           }
/* 1018 */           else if (this.currentTrack.trackType.equals("soun")) {
/* 1019 */             this.currentTrack.media = parseAudioSampleData(encoding, sampleDescriptionSize - 4 - 4 - 6);
/*      */           
/*      */           }
/* 1022 */           else if (this.currentTrack.trackType.equals("hint")) {
/* 1023 */             this.numberOfHintTracks++;
/* 1024 */             this.currentTrack.media = parseHintSampleData(encoding, sampleDescriptionSize - 4 - 4 - 6);
/*      */ 
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */ 
/*      */             
/* 1032 */             skip(this.stream, sampleDescriptionSize - 4 - 4 - 6);
/*      */           }
/*      */         
/*      */         } 
/*      */       } 
/*      */     } catch (IOException e) {
/*      */       
/* 1039 */       throw new BadHeaderException("Got IOException when seeking past STSD atom");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Video parseVideoSampleData(String encoding, int dataSize) throws IOException, BadHeaderException {
/* 1046 */     skip(this.stream, 2);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1051 */     skip(this.stream, 16);
/*      */     
/* 1053 */     Video video = new Video();
/* 1054 */     video.encoding = encoding;
/*      */     
/* 1056 */     video.width = readShort(this.stream);
/* 1057 */     video.height = readShort(this.stream);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1064 */     skip(this.stream, 14);
/*      */     
/* 1066 */     skip(this.stream, 32);
/* 1067 */     video.pixelDepth = readShort(this.stream);
/* 1068 */     video.colorTableID = readShort(this.stream);
/*      */     
/* 1070 */     int colorTableSize = 0;
/* 1071 */     if (video.colorTableID == 0) {
/*      */       
/* 1073 */       colorTableSize = readInt(this.stream);
/* 1074 */       skip(this.stream, colorTableSize - 4);
/*      */     } 
/*      */     
/* 1077 */     skip(this.stream, dataSize - 2 - 70 - -colorTableSize);
/*      */     
/* 1079 */     return video;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Audio parseAudioSampleData(String encoding, int dataSize) throws IOException, BadHeaderException {
/* 1085 */     skip(this.stream, 2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1091 */     skip(this.stream, 8);
/*      */     
/* 1093 */     Audio audio = new Audio();
/* 1094 */     audio.encoding = encoding;
/* 1095 */     audio.channels = readShort(this.stream);
/* 1096 */     audio.bitsPerSample = readShort(this.stream);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1102 */     skip(this.stream, 4);
/* 1103 */     int sampleRate = readInt(this.stream);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1115 */     audio.sampleRate = this.currentTrack.mediaTimeScale;
/*      */ 
/*      */     
/* 1118 */     skip(this.stream, dataSize - 2 - 20);
/* 1119 */     return audio;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Hint parseHintSampleData(String encoding, int dataSize) throws IOException, BadHeaderException {
/* 1128 */     if (!encoding.equals("rtp ")) {
/* 1129 */       System.err.println("Hint track Data Format is not rtp");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1134 */     Hint hint = new Hint();
/*      */     
/* 1136 */     int dataReferenceIndex = readShort(this.stream);
/* 1137 */     int hintTrackVersion = readShort(this.stream);
/*      */     
/* 1139 */     if (hintTrackVersion == 0) {
/* 1140 */       System.err.println("Hint Track version #0 is not supported");
/* 1141 */       System.err.println("Use QuickTimePro to convert it to version #1");
/* 1142 */       this.currentTrack.supported = false;
/* 1143 */       if (dataSize - 2 - 2 > 0)
/* 1144 */         skip(this.stream, dataSize - 2 - 2); 
/* 1145 */       return hint;
/*      */     } 
/*      */     
/* 1148 */     int lastCompatibleHintTrackVersion = readShort(this.stream);
/*      */ 
/*      */     
/* 1151 */     int maxPacketSize = readInt(this.stream);
/* 1152 */     this.currentTrack.maxPacketSize = maxPacketSize;
/* 1153 */     int remaining = dataSize - 2 - 2 - 2 - 4;
/*      */     
/* 1155 */     if (this.debug1) {
/* 1156 */       System.out.println("dataReferenceIndex is " + dataReferenceIndex);
/* 1157 */       System.out.println("hintTrackVersion is " + hintTrackVersion);
/* 1158 */       System.out.println("lastCompatibleHintTrackVersion is " + lastCompatibleHintTrackVersion);
/* 1159 */       System.out.println("maxPacketSize is " + maxPacketSize);
/* 1160 */       System.out.println("remaining is " + remaining);
/*      */     } 
/*      */     
/* 1163 */     while (remaining > 8) {
/*      */ 
/*      */       
/* 1166 */       int entryLength = readInt(this.stream);
/* 1167 */       remaining -= 4;
/* 1168 */       if (entryLength > 8) {
/* 1169 */         if (this.debug2) {
/* 1170 */           System.out.println("entryLength is " + entryLength);
/*      */         }
/* 1172 */         String dataTag = readString(this.stream);
/* 1173 */         if (this.debug2)
/* 1174 */           System.out.println("dataTag is " + dataTag); 
/* 1175 */         remaining -= 4;
/*      */ 
/*      */         
/* 1178 */         if (dataTag.equals("tims")) {
/*      */ 
/*      */           
/* 1181 */           int rtpTimeScale = readInt(this.stream);
/*      */ 
/*      */ 
/*      */           
/* 1185 */           remaining -= 4; continue;
/* 1186 */         }  if (dataTag.equals("tsro")) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1192 */           System.out.println("QuicktimeParser: rtp: tsro dataTag not supported");
/* 1193 */           int rtpTimeStampOffset = readInt(this.stream);
/* 1194 */           remaining -= 4; continue;
/* 1195 */         }  if (dataTag.equals("snro")) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1201 */           System.out.println("QuicktimeParser: rtp: snro dataTag not supported");
/* 1202 */           int rtpSequenceNumberOffset = readInt(this.stream);
/*      */           
/* 1204 */           remaining -= 4; continue;
/* 1205 */         }  if (dataTag.equals("rely")) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1212 */           System.out.println("QuicktimeParser: rtp: rely dataTag not supported");
/* 1213 */           int rtpReliableTransportFlag = readByte(this.stream);
/*      */           
/* 1215 */           remaining--;
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/* 1221 */         skip(this.stream, remaining);
/* 1222 */         remaining = 0;
/*      */         continue;
/*      */       } 
/* 1225 */       skip(this.stream, remaining);
/* 1226 */       remaining = 0;
/*      */       
/*      */       break;
/*      */     } 
/* 1230 */     if (remaining > 0)
/* 1231 */       skip(this.stream, remaining); 
/* 1232 */     return hint;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseSTTS(int sttsSize) throws BadHeaderException {
/* 1241 */     if (this.debug2) {
/* 1242 */       System.out.println("parseSTTS: " + sttsSize);
/*      */     }
/*      */     try {
/* 1245 */       if (sttsSize < 8) {
/* 1246 */         throw new BadHeaderException("stts atom: header size is incorrect");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1252 */       skip(this.stream, 4);
/* 1253 */       int numEntries = readInt(this.stream);
/*      */       
/* 1255 */       if (this.debug2)
/* 1256 */         System.out.println("numEntries is " + numEntries); 
/* 1257 */       int requiredSize = sttsSize - 8 - numEntries * 8;
/* 1258 */       if (requiredSize < 0) {
/* 1259 */         throw new BadHeaderException("stts atom: inconsistent number_of_entries field");
/*      */       }
/* 1261 */       int totalNumSamples = 0;
/*      */       
/* 1263 */       double timeScaleFactor = 1.0D / this.currentTrack.mediaTimeScale;
/* 1264 */       if (numEntries == 1) {
/* 1265 */         totalNumSamples = readInt(this.stream);
/* 1266 */         this.currentTrack.durationOfSamples = readInt(this.stream) * timeScaleFactor;
/*      */       } else {
/* 1268 */         int[] timeToSampleIndices = new int[numEntries];
/* 1269 */         double[] durations = new double[numEntries];
/*      */         
/* 1271 */         timeToSampleIndices[0] = readInt(this.stream);
/* 1272 */         totalNumSamples += timeToSampleIndices[0];
/* 1273 */         durations[0] = readInt(this.stream) * timeScaleFactor * timeToSampleIndices[0];
/*      */ 
/*      */         
/* 1276 */         int remaining = numEntries - 1;
/*      */         
/* 1278 */         int numIntsWrittenPerLoop = 2;
/*      */         
/* 1280 */         int maxEntriesPerLoop = this.tmpIntBufferSize / numIntsWrittenPerLoop;
/* 1281 */         int i = 1;
/* 1282 */         while (remaining > 0) {
/* 1283 */           int numEntriesPerLoop = (remaining > maxEntriesPerLoop) ? maxEntriesPerLoop : remaining;
/*      */ 
/*      */           
/* 1286 */           readBytes(this.stream, this.tmpBuffer, numEntriesPerLoop * numIntsWrittenPerLoop * 4);
/*      */ 
/*      */ 
/*      */           
/* 1290 */           int offset = 0;
/* 1291 */           for (int ii = 1; ii <= numEntriesPerLoop; ii++, i++) {
/* 1292 */             timeToSampleIndices[i] = parseIntFromArray(this.tmpBuffer, offset, true);
/*      */             
/* 1294 */             offset += 4;
/* 1295 */             int value = parseIntFromArray(this.tmpBuffer, offset, true);
/* 1296 */             offset += 4;
/* 1297 */             durations[i] = durations[i] + value * timeScaleFactor * timeToSampleIndices[i] + durations[i - 1];
/*      */ 
/*      */             
/* 1300 */             totalNumSamples += timeToSampleIndices[i];
/* 1301 */             timeToSampleIndices[i] = totalNumSamples;
/*      */           } 
/* 1303 */           remaining -= numEntriesPerLoop;
/*      */         } 
/* 1305 */         this.currentTrack.timeToSampleIndices = timeToSampleIndices;
/* 1306 */         this.currentTrack.cumulativeDurationOfSamples = durations;
/*      */       } 
/*      */       
/* 1309 */       if (this.currentTrack.numberOfSamples == 0) {
/* 1310 */         this.currentTrack.numberOfSamples = totalNumSamples;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1316 */       skip(this.stream, requiredSize);
/*      */     } catch (IOException e) {
/* 1318 */       throw new BadHeaderException("Got IOException when seeking past STTS atom");
/*      */     } 
/*      */   }
/*      */   
/*      */   private void parseSTSC(int stscSize) throws BadHeaderException {
/*      */     try {
/* 1324 */       if (stscSize < 8) {
/* 1325 */         throw new BadHeaderException("stsc atom: header size is incorrect");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1331 */       skip(this.stream, 4);
/* 1332 */       int numEntries = readInt(this.stream);
/* 1333 */       int requiredSize = stscSize - 8 - numEntries * 12;
/* 1334 */       if (requiredSize < 0) {
/* 1335 */         throw new BadHeaderException("stsc atom: inconsistent number_of_entries field");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1342 */       int[] compactSamplesChunkNum = new int[numEntries];
/* 1343 */       int[] compactSamplesPerChunk = new int[numEntries];
/* 1344 */       byte[] tmpBuf = new byte[numEntries * 4 * 3];
/* 1345 */       readBytes(this.stream, tmpBuf, numEntries * 4 * 3);
/* 1346 */       int offset = 0;
/* 1347 */       for (int i = 0; i < numEntries; i++) {
/* 1348 */         compactSamplesChunkNum[i] = parseIntFromArray(tmpBuf, offset, true);
/* 1349 */         offset += 4;
/* 1350 */         compactSamplesPerChunk[i] = parseIntFromArray(tmpBuf, offset, true);
/* 1351 */         offset += 4;
/*      */         
/* 1353 */         offset += 4;
/*      */       } 
/* 1355 */       tmpBuf = null;
/* 1356 */       this.currentTrack.compactSamplesChunkNum = compactSamplesChunkNum;
/* 1357 */       this.currentTrack.compactSamplesPerChunk = compactSamplesPerChunk;
/* 1358 */       skip(this.stream, requiredSize);
/*      */     } catch (IOException e) {
/* 1360 */       throw new BadHeaderException("Got IOException when seeking past STSC atom");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseSTSZ(int stszSize) throws BadHeaderException {
/* 1369 */     if (this.debug2)
/* 1370 */       System.out.println("parseSTSZ: " + stszSize); 
/*      */     try {
/* 1372 */       if (stszSize < 8) {
/* 1373 */         throw new BadHeaderException("stsz atom: header size is incorrect");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1379 */       skip(this.stream, 4);
/* 1380 */       this.currentTrack.sampleSize = readInt(this.stream);
/* 1381 */       if (this.currentTrack.sampleSize != 0) {
/*      */         
/* 1383 */         skip(this.stream, stszSize - 8);
/* 1384 */         this.currentTrack.media.maxSampleSize = this.currentTrack.sampleSize;
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 1389 */       if (stszSize - 8 < 4) {
/* 1390 */         throw new BadHeaderException("stsz atom: incorrect atom size");
/*      */       }
/*      */       
/* 1393 */       int numEntries = readInt(this.stream);
/* 1394 */       if (this.currentTrack.numberOfSamples == 0) {
/* 1395 */         this.currentTrack.numberOfSamples = numEntries;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1400 */       int requiredSize = stszSize - 8 - 4 - numEntries * 4;
/*      */ 
/*      */       
/* 1403 */       if (requiredSize < 0) {
/* 1404 */         throw new BadHeaderException("stsz atom: inconsistent number_of_entries field");
/*      */       }
/* 1406 */       int[] sampleSizeArray = new int[numEntries];
/* 1407 */       int maxSampleSize = Integer.MIN_VALUE;
/*      */ 
/*      */       
/* 1410 */       int remaining = numEntries;
/*      */       
/* 1412 */       int numIntsWrittenPerLoop = 1;
/* 1413 */       int maxEntriesPerLoop = this.tmpIntBufferSize / numIntsWrittenPerLoop;
/* 1414 */       int i = 0;
/* 1415 */       while (remaining > 0) {
/* 1416 */         int numEntriesPerLoop = (remaining > maxEntriesPerLoop) ? maxEntriesPerLoop : remaining;
/*      */ 
/*      */         
/* 1419 */         readBytes(this.stream, this.tmpBuffer, numEntriesPerLoop * numIntsWrittenPerLoop * 4);
/*      */         
/* 1421 */         int offset = 0;
/* 1422 */         for (int ii = 1; ii <= numEntriesPerLoop; ii++, i++) {
/* 1423 */           int value = parseIntFromArray(this.tmpBuffer, offset, true);
/* 1424 */           offset += 4;
/* 1425 */           if (value > maxSampleSize)
/* 1426 */             maxSampleSize = value; 
/* 1427 */           sampleSizeArray[i] = value;
/*      */         } 
/* 1429 */         remaining -= numEntriesPerLoop;
/*      */       } 
/* 1431 */       this.currentTrack.sampleSizeArray = sampleSizeArray;
/* 1432 */       this.currentTrack.media.maxSampleSize = maxSampleSize;
/* 1433 */       skip(this.stream, requiredSize);
/*      */     } catch (IOException e) {
/* 1435 */       throw new BadHeaderException("Got IOException when seeking past STSZ atom");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseSTCO(int stcoSize) throws BadHeaderException {
/* 1444 */     if (this.debug2) {
/* 1445 */       System.out.println("rtp:parseSTCO: " + stcoSize);
/*      */     }
/*      */     try {
/* 1448 */       if (stcoSize < 8) {
/* 1449 */         throw new BadHeaderException("stco atom: header size is incorrect");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1455 */       skip(this.stream, 4);
/*      */       
/* 1457 */       int numEntries = readInt(this.stream);
/* 1458 */       this.currentTrack.numberOfChunks = numEntries;
/* 1459 */       int[] chunkOffsets = new int[numEntries];
/* 1460 */       int requiredSize = stcoSize - 8 - numEntries * 4;
/* 1461 */       if (requiredSize < 0) {
/* 1462 */         throw new BadHeaderException("stco atom: inconsistent number_of_entries field");
/*      */       }
/*      */       
/* 1465 */       int remaining = numEntries;
/*      */       
/* 1467 */       int numIntsWrittenPerLoop = 1;
/* 1468 */       int maxEntriesPerLoop = this.tmpIntBufferSize / numIntsWrittenPerLoop;
/* 1469 */       int i = 0;
/* 1470 */       while (remaining > 0) {
/* 1471 */         int numEntriesPerLoop = (remaining > maxEntriesPerLoop) ? maxEntriesPerLoop : remaining;
/*      */ 
/*      */         
/* 1474 */         readBytes(this.stream, this.tmpBuffer, numEntriesPerLoop * numIntsWrittenPerLoop * 4);
/*      */         
/* 1476 */         int offset = 0;
/* 1477 */         for (int ii = 1; ii <= numEntriesPerLoop; ii++, i++) {
/* 1478 */           chunkOffsets[i] = parseIntFromArray(this.tmpBuffer, offset, true);
/* 1479 */           offset += 4;
/*      */         } 
/* 1481 */         remaining -= numEntriesPerLoop;
/*      */       } 
/* 1483 */       this.currentTrack.chunkOffsets = chunkOffsets;
/* 1484 */       skip(this.stream, requiredSize);
/*      */     } catch (IOException e) {
/* 1486 */       throw new BadHeaderException("Got IOException when seeking past STCO atom");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseSTSS(int stssSize) throws BadHeaderException {
/*      */     try {
/* 1496 */       if (stssSize < 8) {
/* 1497 */         throw new BadHeaderException("stss atom: header size is incorrect");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1503 */       skip(this.stream, 4);
/* 1504 */       int numEntries = readInt(this.stream);
/*      */       
/* 1506 */       int requiredSize = stssSize - 8 - numEntries * 4;
/* 1507 */       if (requiredSize < 0) {
/* 1508 */         throw new BadHeaderException("stss atom: inconsistent number_of_entries field");
/*      */       }
/*      */       
/* 1511 */       if (numEntries < 1) {
/* 1512 */         skip(this.stream, requiredSize);
/*      */         
/*      */         return;
/*      */       } 
/* 1516 */       int[] syncSamples = new int[numEntries];
/*      */       
/* 1518 */       int remaining = numEntries;
/*      */       
/* 1520 */       int numIntsWrittenPerLoop = 1;
/* 1521 */       int maxEntriesPerLoop = this.tmpIntBufferSize / numIntsWrittenPerLoop;
/* 1522 */       int i = 0;
/* 1523 */       while (remaining > 0) {
/* 1524 */         int numEntriesPerLoop = (remaining > maxEntriesPerLoop) ? maxEntriesPerLoop : remaining;
/*      */ 
/*      */         
/* 1527 */         readBytes(this.stream, this.tmpBuffer, numEntriesPerLoop * numIntsWrittenPerLoop * 4);
/*      */         
/* 1529 */         int offset = 0;
/* 1530 */         for (int ii = 1; ii <= numEntriesPerLoop; ii++, i++) {
/* 1531 */           syncSamples[i] = parseIntFromArray(this.tmpBuffer, offset, true);
/* 1532 */           offset += 4;
/*      */         } 
/* 1534 */         remaining -= numEntriesPerLoop;
/*      */       } 
/* 1536 */       this.currentTrack.syncSamples = syncSamples;
/* 1537 */       skip(this.stream, requiredSize);
/*      */     } catch (IOException e) {
/* 1539 */       throw new BadHeaderException("Got IOException when seeking past STSS atom");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isSupported(String trackType) {
/* 1546 */     return (trackType.equals("vide") || trackType.equals("soun") || trackType.equals("hint"));
/*      */   }
/*      */   
/*      */   private class MovieHeader
/*      */   {
/*      */     int timeScale;
/*      */     Time duration;
/*      */     long mdatStart;
/*      */     long mdatSize;
/*      */     private final QuicktimeParser this$0;
/*      */     
/*      */     private MovieHeader(QuicktimeParser this$0) {
/* 1558 */       QuicktimeParser.this = QuicktimeParser.this;
/*      */ 
/*      */       
/* 1561 */       this.duration = Duration.DURATION_UNKNOWN;
/*      */     } }
/*      */   private abstract class Media { String encoding; int maxSampleSize;
/*      */     float frameRate;
/*      */     private final QuicktimeParser this$0;
/*      */     
/*      */     private Media(QuicktimeParser this$0) {
/* 1568 */       QuicktimeParser.this = QuicktimeParser.this;
/*      */     }
/*      */     abstract Format createFormat(); }
/*      */   private class Audio extends Media { int channels; int bitsPerSample; int sampleRate; AudioFormat format;
/*      */     int frameSizeInBits;
/*      */     int samplesPerBlock;
/*      */     private final QuicktimeParser this$0;
/*      */     
/*      */     private Audio(QuicktimeParser this$0) {
/* 1577 */       QuicktimeParser.this = QuicktimeParser.this;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1583 */       this.format = null;
/*      */       
/* 1585 */       this.samplesPerBlock = 1;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1590 */       String info = "Audio: " + this.format + "\n";
/* 1591 */       info = info + "encoding is " + this.encoding + "\n";
/* 1592 */       info = info + "Number of channels " + this.channels + "\n";
/* 1593 */       info = info + "Bits per sample " + this.bitsPerSample + "\n";
/* 1594 */       info = info + "sampleRate " + this.sampleRate + "\n";
/* 1595 */       return info;
/*      */     }
/*      */ 
/*      */     
/*      */     Format createFormat() {
/* 1600 */       if (this.format != null) {
/* 1601 */         return (Format)this.format;
/*      */       }
/* 1603 */       String encodingString = null;
/* 1604 */       boolean signed = true;
/* 1605 */       boolean bigEndian = true;
/*      */ 
/*      */       
/* 1608 */       if (this.encoding.equals("ulaw") || this.encoding.equals("alaw"))
/*      */       {
/* 1610 */         this.bitsPerSample = 8;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1615 */       this.frameSizeInBits = this.channels * this.bitsPerSample;
/*      */       
/* 1617 */       if (this.encoding.equals("ulaw")) {
/* 1618 */         encodingString = "ULAW";
/* 1619 */         signed = false;
/* 1620 */       } else if (this.encoding.equals("alaw")) {
/* 1621 */         encodingString = "alaw";
/* 1622 */         signed = false;
/* 1623 */       } else if (this.encoding.equals("twos")) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1631 */         encodingString = "LINEAR";
/* 1632 */       } else if (this.encoding.equals("ima4")) {
/* 1633 */         encodingString = "ima4";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1641 */         this.samplesPerBlock = 64;
/* 1642 */         this.frameSizeInBits = 34 * this.channels * 8;
/* 1643 */       } else if (this.encoding.equals("raw ")) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1651 */         encodingString = "LINEAR";
/* 1652 */         signed = false;
/*      */       }
/* 1654 */       else if (this.encoding.equals("agsm")) {
/* 1655 */         encodingString = "gsm";
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1660 */         this.samplesPerBlock = 33;
/* 1661 */         this.frameSizeInBits = 264;
/* 1662 */       } else if (this.encoding.equals("mac3")) {
/* 1663 */         encodingString = "MAC3";
/* 1664 */       } else if (this.encoding.equals("mac6")) {
/* 1665 */         encodingString = "MAC6";
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1672 */         encodingString = this.encoding;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1682 */       this.format = new AudioFormat(encodingString, this.sampleRate, this.bitsPerSample, this.channels, bigEndian ? 1 : 0, signed ? 1 : 0, this.frameSizeInBits, -1.0D, Format.byteArray);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1692 */       return (Format)this.format;
/*      */     } }
/*      */   private class Video extends Media { int width; int height; int pixelDepth;
/*      */     private Video(QuicktimeParser this$0) {
/* 1696 */       QuicktimeParser.this = QuicktimeParser.this;
/*      */     }
/*      */ 
/*      */     
/*      */     int colorTableID;
/*      */     
/*      */     VideoFormat format;
/*      */     private final QuicktimeParser this$0;
/*      */     
/*      */     Format createFormat() {
/* 1706 */       if (this.format != null) {
/* 1707 */         return (Format)this.format;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1727 */       if (this.encoding.toLowerCase().startsWith("raw")) {
/* 1728 */         this.encoding = "rgb";
/* 1729 */         if (this.pixelDepth == 24) {
/* 1730 */           this.format = (VideoFormat)new RGBFormat(new Dimension(this.width, this.height), -1, Format.byteArray, this.frameRate, this.pixelDepth, 1, 2, 3, 3, this.width * 3, 0, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/* 1740 */         else if (this.pixelDepth == 16) {
/* 1741 */           this.format = (VideoFormat)new RGBFormat(new Dimension(this.width, this.height), -1, Format.byteArray, this.frameRate, this.pixelDepth, 31744, 992, 31, 2, this.width * 2, 0, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/* 1753 */         else if (this.pixelDepth == 32) {
/* 1754 */           this.encoding = "rgb";
/*      */ 
/*      */           
/* 1757 */           this.format = (VideoFormat)new RGBFormat(new Dimension(this.width, this.height), -1, Format.byteArray, this.frameRate, this.pixelDepth, 2, 3, 4, 4, this.width * 4, 0, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1768 */       else if (this.encoding.toLowerCase().equals("8bps")) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1775 */         this.format = new VideoFormat(this.encoding, new Dimension(this.width, this.height), this.maxSampleSize, Format.byteArray, this.frameRate);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1780 */       else if (this.encoding.toLowerCase().equals("yuv2")) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1786 */         this.format = (VideoFormat)new YUVFormat(new Dimension(this.width, this.height), -1, Format.byteArray, this.frameRate, 96, this.width * 2, this.width * 2, 0, 1, 3);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1798 */         this.format = new VideoFormat(this.encoding, new Dimension(this.width, this.height), this.maxSampleSize, Format.byteArray, this.frameRate);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1803 */       return (Format)this.format;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1809 */       String info = "Video: " + this.format + "\n";
/* 1810 */       info = info + "encoding is " + this.encoding + "\n";
/*      */ 
/*      */       
/* 1813 */       info = info + "pixelDepth is " + this.pixelDepth + "\n";
/*      */ 
/*      */       
/* 1816 */       return info;
/*      */     } }
/*      */   private class Hint extends Media { Format format; private final QuicktimeParser this$0;
/*      */     
/*      */     private Hint(QuicktimeParser this$0) {
/* 1821 */       QuicktimeParser.this = QuicktimeParser.this;
/* 1822 */       this.format = null;
/*      */     }
/*      */     Format createFormat() {
/* 1825 */       return this.format;
/*      */     } }
/*      */ 
/*      */ 
/*      */   
/*      */   private class TrakList
/*      */   {
/*      */     int flag;
/*      */     
/*      */     int id;
/*      */     
/*      */     Time duration;
/*      */     
/*      */     int mediaTimeScale;
/*      */     
/*      */     Time mediaDuration;
/*      */     
/*      */     String trackType;
/*      */     
/*      */     int numberOfSamples;
/*      */     
/*      */     int sampleSize;
/*      */     
/*      */     int[] sampleSizeArray;
/*      */     boolean supported;
/*      */     QuicktimeParser.Media media;
/*      */     int numberOfChunks;
/*      */     int[] chunkOffsets;
/*      */     int[] compactSamplesChunkNum;
/*      */     int[] compactSamplesPerChunk;
/*      */     int constantSamplesPerChunk;
/*      */     int[] samplesPerChunk;
/*      */     double durationOfSamples;
/*      */     int[] timeToSampleIndices;
/*      */     double[] cumulativeDurationOfSamples;
/*      */     double[] startTimeOfSampleArray;
/*      */     double[] durationOfSampleArray;
/*      */     long[] sampleOffsetTable;
/*      */     int[] syncSamples;
/*      */     int[] syncSampleMapping;
/*      */     QuicktimeParser.TimeAndDuration timeAndDuration;
/*      */     int trackIdOfTrackBeingHinted;
/*      */     int indexOfTrackBeingHinted;
/*      */     int maxPacketSize;
/*      */     private final QuicktimeParser this$0;
/*      */     
/*      */     private TrakList(QuicktimeParser this$0) {
/* 1872 */       QuicktimeParser.this = QuicktimeParser.this;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1881 */       this.duration = Duration.DURATION_UNKNOWN;
/*      */ 
/*      */ 
/*      */       
/* 1885 */       this.mediaDuration = Duration.DURATION_UNKNOWN;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1892 */       this.sampleSize = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1905 */       this.chunkOffsets = new int[0];
/*      */ 
/*      */       
/* 1908 */       this.compactSamplesChunkNum = new int[0];
/* 1909 */       this.compactSamplesPerChunk = new int[0];
/*      */ 
/*      */ 
/*      */       
/* 1913 */       this.constantSamplesPerChunk = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1918 */       this.durationOfSamples = -1.0D;
/*      */       
/* 1920 */       this.timeToSampleIndices = new int[0];
/* 1921 */       this.cumulativeDurationOfSamples = new double[0];
/* 1922 */       this.startTimeOfSampleArray = new double[0];
/* 1923 */       this.durationOfSampleArray = new double[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1930 */       this.timeAndDuration = new QuicktimeParser.TimeAndDuration();
/*      */       
/* 1932 */       this.trackIdOfTrackBeingHinted = -1;
/* 1933 */       this.indexOfTrackBeingHinted = -1;
/* 1934 */       this.maxPacketSize = -1;
/*      */     }
/*      */     
/*      */     void buildSamplePerChunkTable() {
/* 1938 */       if (this.numberOfChunks <= 0)
/*      */         return; 
/* 1940 */       if (this.compactSamplesPerChunk.length == 1) {
/* 1941 */         this.constantSamplesPerChunk = this.compactSamplesPerChunk[0];
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 1946 */       this.samplesPerChunk = new int[this.numberOfChunks];
/* 1947 */       int i = 1; int j;
/* 1948 */       for (j = 0; j < this.compactSamplesChunkNum.length - 1; j++) {
/* 1949 */         int numSamples = this.compactSamplesPerChunk[j];
/*      */         
/* 1951 */         while (i != this.compactSamplesChunkNum[j + 1]) {
/* 1952 */           this.samplesPerChunk[i - 1] = numSamples;
/* 1953 */           i++;
/*      */         } 
/*      */       } 
/* 1956 */       for (; i <= this.numberOfChunks; i++) {
/* 1957 */         this.samplesPerChunk[i - 1] = this.compactSamplesPerChunk[j];
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void buildCumulativeSamplePerChunkTable() {
/* 1967 */       if (this.constantSamplesPerChunk == -1) {
/* 1968 */         for (int i = 1; i < this.numberOfChunks; i++) {
/* 1969 */           this.samplesPerChunk[i] = this.samplesPerChunk[i] + this.samplesPerChunk[i - 1];
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void buildSampleOffsetTable() {
/* 1978 */       this.sampleOffsetTable = new long[this.numberOfSamples];
/*      */       
/* 1980 */       int index = 0;
/*      */ 
/*      */ 
/*      */       
/* 1984 */       if (this.sampleSize != 0) {
/*      */ 
/*      */         
/* 1987 */         if (this.constantSamplesPerChunk != -1) {
/* 1988 */           for (int i = 0; i < this.numberOfChunks; i++) {
/* 1989 */             long offset = this.chunkOffsets[i];
/* 1990 */             for (int j = 0; j < this.constantSamplesPerChunk; j++) {
/* 1991 */               this.sampleOffsetTable[index++] = offset + (j * this.sampleSize);
/*      */             }
/*      */           } 
/*      */         } else {
/* 1995 */           for (byte b = 0; b < this.numberOfChunks; b++) {
/* 1996 */             long l = this.chunkOffsets[b];
/* 1997 */             for (byte b1 = 0; b1 < this.samplesPerChunk[b]; b1++) {
/* 1998 */               this.sampleOffsetTable[index++] = l + (b1 * this.sampleSize);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } else {
/* 2003 */         int numSamplesInChunk = 0;
/* 2004 */         if (this.constantSamplesPerChunk != -1)
/* 2005 */           numSamplesInChunk = this.constantSamplesPerChunk; 
/* 2006 */         for (byte b = 0; b < this.numberOfChunks; b++) {
/* 2007 */           long l = this.chunkOffsets[b];
/*      */ 
/*      */           
/* 2010 */           this.sampleOffsetTable[index] = l;
/* 2011 */           index++;
/*      */           
/* 2013 */           if (this.constantSamplesPerChunk == -1) {
/* 2014 */             numSamplesInChunk = this.samplesPerChunk[b];
/*      */           }
/* 2016 */           for (byte b1 = 1; b1 < numSamplesInChunk; b1++) {
/* 2017 */             this.sampleOffsetTable[index] = this.sampleOffsetTable[index - 1] + this.sampleSizeArray[index - 1];
/*      */             
/* 2019 */             index++;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     boolean buildSyncTable() {
/*      */       int i;
/* 2027 */       if (this.syncSamples == null) {
/* 2028 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2044 */       if (!this.trackType.equals("vide")) {
/* 2045 */         return false;
/*      */       }
/* 2047 */       int numEntries = this.syncSamples.length;
/* 2048 */       if (numEntries == this.numberOfSamples) {
/*      */ 
/*      */         
/* 2051 */         this.syncSamples = null;
/* 2052 */         return false;
/*      */       } 
/*      */       
/* 2055 */       this.syncSampleMapping = new int[this.numberOfSamples];
/* 2056 */       int index = 0;
/*      */       
/* 2058 */       if (this.syncSamples[0] != 1) {
/*      */ 
/*      */         
/* 2061 */         i = this.syncSampleMapping[0] = 0;
/*      */       } else {
/* 2063 */         i = this.syncSampleMapping[0] = 0;
/* 2064 */         index++;
/*      */       } 
/*      */       
/* 2067 */       for (; index < this.syncSamples.length; index++) {
/* 2068 */         int next = this.syncSamples[index] - 1;
/* 2069 */         this.syncSampleMapping[next] = next;
/* 2070 */         int range = next - i - 1;
/* 2071 */         for (int j = i + 1; j < next; j++)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2080 */           this.syncSampleMapping[j] = i;
/*      */         }
/* 2082 */         i = next;
/*      */       } 
/* 2084 */       int lastSyncFrame = this.syncSamples[this.syncSamples.length - 1] - 1;
/* 2085 */       for (index = lastSyncFrame + 1; index < this.numberOfSamples; index++) {
/* 2086 */         this.syncSampleMapping[index] = lastSyncFrame;
/*      */       }
/*      */       
/* 2089 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int time2Index(double time) {
/*      */       int j, k;
/*      */       double d1;
/* 2098 */       if (time < 0.0D) {
/* 2099 */         time = 0.0D;
/*      */       }
/* 2101 */       int length = this.timeToSampleIndices.length;
/*      */ 
/*      */ 
/*      */       
/* 2105 */       if (length == 0) {
/* 2106 */         i = (int)(time / this.mediaDuration.getSeconds() * this.numberOfSamples + 0.5D);
/*      */         
/* 2108 */         if (i >= this.numberOfSamples)
/* 2109 */           return -1; 
/* 2110 */         return i;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2117 */       int approxLocation = (int)(time / this.mediaDuration.getSeconds() * length);
/*      */ 
/*      */       
/* 2120 */       if (approxLocation == length) {
/* 2121 */         approxLocation--;
/*      */       }
/* 2123 */       if (approxLocation >= this.cumulativeDurationOfSamples.length) {
/* 2124 */         return -1;
/*      */       }
/*      */ 
/*      */       
/* 2128 */       if (this.cumulativeDurationOfSamples[approxLocation] < time) {
/*      */         int m;
/* 2130 */         for (m = approxLocation + 1; m < length && 
/* 2131 */           this.cumulativeDurationOfSamples[m] < time; m++);
/*      */ 
/*      */ 
/*      */         
/* 2135 */         j = m;
/* 2136 */       } else if (this.cumulativeDurationOfSamples[approxLocation] > time) {
/*      */         int m;
/* 2138 */         for (m = approxLocation - 1; m >= 0 && 
/* 2139 */           this.cumulativeDurationOfSamples[m] >= time; m--);
/*      */ 
/*      */ 
/*      */         
/* 2143 */         j = m + 1;
/*      */       } else {
/* 2145 */         j = approxLocation;
/*      */       } 
/*      */       
/* 2148 */       if (j == length) {
/* 2149 */         j--;
/*      */       }
/* 2151 */       double delta = this.cumulativeDurationOfSamples[j] - time;
/*      */ 
/*      */       
/* 2154 */       if (j == 0) {
/* 2155 */         i = this.timeToSampleIndices[j];
/* 2156 */         k = i;
/* 2157 */         d1 = this.cumulativeDurationOfSamples[j];
/*      */       } else {
/* 2159 */         i = this.timeToSampleIndices[j];
/* 2160 */         k = i - this.timeToSampleIndices[j - 1];
/*      */         
/* 2162 */         d1 = this.cumulativeDurationOfSamples[j] - this.cumulativeDurationOfSamples[j - 1];
/*      */       } 
/*      */       
/* 2165 */       double fraction = delta / d1;
/* 2166 */       int i = (int)(i - k * fraction);
/* 2167 */       return i;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     QuicktimeParser.TimeAndDuration index2TimeAndDuration(int index) {
/* 2173 */       double startTime = 0.0D;
/* 2174 */       double duration = 0.0D;
/*      */       
/*      */       try {
/* 2177 */         if (index < 0) {
/* 2178 */           index = 0;
/* 2179 */         } else if (index >= this.numberOfSamples) {
/* 2180 */           index = this.numberOfSamples - 1;
/*      */         } 
/* 2182 */         int length = this.timeToSampleIndices.length;
/*      */         
/* 2184 */         if (length == 0) {
/*      */           
/* 2186 */           duration = this.durationOfSamples;
/* 2187 */           startTime = duration * index;
/* 2188 */         } else if (this.startTimeOfSampleArray.length >= index) {
/* 2189 */           duration = this.durationOfSampleArray[index];
/* 2190 */           startTime = this.startTimeOfSampleArray[index];
/*      */         } else {
/*      */           
/* 2193 */           float factor = length / this.numberOfSamples;
/* 2194 */           int location = (int)(index * factor);
/* 2195 */           duration = 0.0D;
/* 2196 */           startTime = 0.0D;
/*      */         } 
/*      */       } finally {
/* 2199 */         synchronized (this.timeAndDuration) {
/* 2200 */           this.timeAndDuration.startTime = startTime;
/* 2201 */           this.timeAndDuration.duration = duration;
/* 2202 */           return this.timeAndDuration;
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int index2Chunk(int index) {
/*      */       int i;
/* 2212 */       if (this.constantSamplesPerChunk != -1) {
/* 2213 */         i = index / this.constantSamplesPerChunk;
/* 2214 */         return i;
/*      */       } 
/* 2216 */       int length = this.samplesPerChunk.length;
/* 2217 */       int approxChunk = (int)((index / this.numberOfSamples) * length);
/* 2218 */       if (approxChunk == length) {
/* 2219 */         approxChunk--;
/*      */       }
/*      */ 
/*      */       
/* 2223 */       if (this.samplesPerChunk[approxChunk] < index) {
/*      */         int j;
/* 2225 */         for (j = approxChunk + 1; j < length && 
/* 2226 */           this.samplesPerChunk[j] < index; j++);
/*      */ 
/*      */ 
/*      */         
/* 2230 */         i = j;
/* 2231 */       } else if (this.samplesPerChunk[approxChunk] > index) {
/*      */         int j;
/* 2233 */         for (j = approxChunk - 1; j >= 0 && 
/* 2234 */           this.samplesPerChunk[j] >= index; j--);
/*      */ 
/*      */ 
/*      */         
/* 2238 */         i = j + 1;
/*      */       } else {
/* 2240 */         i = approxChunk;
/*      */       } 
/* 2242 */       return i;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     long index2Offset(int index) {
/* 2253 */       int i, j, chunk = index2Chunk(index + 1);
/* 2254 */       if (QuicktimeParser.this.debug) {
/* 2255 */         System.out.println(" index2Chunk chunk is " + chunk);
/*      */       }
/* 2257 */       if (chunk >= this.chunkOffsets.length)
/*      */       {
/*      */         
/* 2260 */         return -2L;
/*      */       }
/*      */       
/* 2263 */       long offset = this.chunkOffsets[chunk];
/*      */       
/* 2265 */       if (QuicktimeParser.this.debug1) {
/* 2266 */         System.out.println("index2Offset: index, chunk, chunkOffset " + index + " : " + chunk + " : " + offset);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2279 */       if (this.constantSamplesPerChunk != -1) {
/* 2280 */         i = index % this.constantSamplesPerChunk;
/* 2281 */         j = chunk * this.constantSamplesPerChunk;
/*      */       } else {
/* 2283 */         if (chunk == 0) {
/* 2284 */           j = 0;
/*      */         } else {
/* 2286 */           j = this.samplesPerChunk[chunk - 1];
/* 2287 */         }  i = index - j;
/* 2288 */         if (QuicktimeParser.this.debug1) {
/* 2289 */           System.out.println("index, start, sampleNumInChunk " + index + " : " + j + " : " + i);
/*      */ 
/*      */           
/* 2292 */           System.out.println("sampleSize is " + this.sampleSize);
/*      */         } 
/*      */       } 
/* 2295 */       if (QuicktimeParser.this.debug1)
/* 2296 */         System.out.println("sampleSize is " + this.sampleSize); 
/* 2297 */       if (this.sampleSize != 0) {
/*      */         
/* 2299 */         offset += (this.sampleSize * i);
/*      */       } else {
/* 2301 */         for (int k = 0; k < i; k++)
/* 2302 */           offset += this.sampleSizeArray[j++]; 
/*      */       } 
/* 2304 */       return offset;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void buildStartTimeAndDurationTable() {
/* 2311 */       if (QuicktimeParser.this.debug2) {
/* 2312 */         System.out.println("buildStartTimeAndDurationTable");
/*      */       }
/* 2314 */       int length = this.timeToSampleIndices.length;
/*      */ 
/*      */       
/* 2317 */       if (length == 0) {
/*      */         return;
/*      */       }
/* 2320 */       this.startTimeOfSampleArray = new double[this.numberOfSamples];
/* 2321 */       this.durationOfSampleArray = new double[this.numberOfSamples];
/* 2322 */       int previousSamples = 0;
/* 2323 */       double previousDuration = 0.0D;
/* 2324 */       double time = 0.0D;
/* 2325 */       int index = 0;
/* 2326 */       for (int i = 0; i < length; i++) {
/* 2327 */         int numSamples = this.timeToSampleIndices[i];
/* 2328 */         double duration = (this.cumulativeDurationOfSamples[i] - previousDuration) / (numSamples - previousSamples);
/*      */ 
/*      */ 
/*      */         
/* 2332 */         for (int j = 0; j < numSamples - previousSamples; j++) {
/* 2333 */           this.startTimeOfSampleArray[index] = time;
/* 2334 */           this.durationOfSampleArray[index] = duration;
/* 2335 */           index++;
/* 2336 */           time += duration;
/*      */         } 
/* 2338 */         previousSamples = numSamples;
/* 2339 */         previousDuration = this.cumulativeDurationOfSamples[i];
/*      */       } 
/*      */     }
/*      */     
/*      */     public String toString() {
/* 2344 */       String info = "";
/*      */       
/* 2346 */       info = info + "track id is " + this.id + "\n";
/* 2347 */       info = info + "duration itrack is " + this.duration.getSeconds() + "\n";
/* 2348 */       info = info + "duration of media is " + this.mediaDuration.getSeconds() + "\n";
/* 2349 */       info = info + "trackType is " + this.trackType + "\n";
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2354 */       info = info + this.media;
/*      */       
/* 2356 */       return info;
/*      */     }
/*      */   }
/*      */   
/*      */   private abstract class MediaTrack implements Track {
/*      */     QuicktimeParser.TrakList trakInfo;
/*      */     boolean enabled;
/*      */     int numBuffers;
/*      */     Format format;
/*      */     long sequenceNumber;
/*      */     int chunkNumber;
/*      */     int sampleIndex;
/*      */     int useChunkNumber;
/*      */     int useSampleIndex;
/*      */     QuicktimeParser parser;
/*      */     CachedStream cacheStream;
/*      */     int constantSamplesPerChunk;
/*      */     int[] samplesPerChunk;
/*      */     protected TrackListener listener;
/*      */     private final QuicktimeParser this$0;
/*      */     
/*      */     MediaTrack(QuicktimeParser this$0, QuicktimeParser.TrakList trakInfo) {
/* 2378 */       this.this$0 = this$0; this.enabled = true; this.numBuffers = 4; this.sequenceNumber = 0L; this.chunkNumber = 0; this.sampleIndex = 0; this.useChunkNumber = 0; this.useSampleIndex = 0; this.parser = this.this$0; this.cacheStream = this.parser.getCacheStream();
/* 2379 */       this.trakInfo = trakInfo;
/* 2380 */       if (trakInfo != null) {
/* 2381 */         this.enabled = ((trakInfo.flag & 0x1) != 0);
/* 2382 */         this.format = trakInfo.media.createFormat();
/* 2383 */         this.samplesPerChunk = trakInfo.samplesPerChunk;
/* 2384 */         this.constantSamplesPerChunk = trakInfo.constantSamplesPerChunk;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void setTrackListener(TrackListener l) {
/* 2390 */       this.listener = l;
/*      */     }
/*      */     
/*      */     public Format getFormat() {
/* 2394 */       return this.format;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setEnabled(boolean t) {
/* 2399 */       this.enabled = t;
/*      */     }
/*      */     
/*      */     public boolean isEnabled() {
/* 2403 */       return this.enabled;
/*      */     }
/*      */     
/*      */     public Time getDuration() {
/* 2407 */       return this.trakInfo.duration;
/*      */     }
/*      */ 
/*      */     
/*      */     public Time getStartTime() {
/* 2412 */       return new Time(0L);
/*      */     }
/*      */     
/*      */     synchronized void setSampleIndex(int index) {
/* 2416 */       this.sampleIndex = index;
/*      */     }
/*      */     
/*      */     synchronized void setChunkNumber(int number) {
/* 2420 */       this.chunkNumber = number;
/*      */     }
/*      */     
/*      */     public void readFrame(Buffer buffer) {
/* 2424 */       if (buffer == null) {
/*      */         return;
/*      */       }
/* 2427 */       if (!this.enabled) {
/* 2428 */         buffer.setDiscard(true);
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 2433 */       synchronized (this) {
/* 2434 */         this.useChunkNumber = this.chunkNumber;
/* 2435 */         this.useSampleIndex = this.sampleIndex;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2444 */       if (this.useChunkNumber >= this.trakInfo.numberOfChunks || this.useChunkNumber < 0) {
/*      */         
/* 2446 */         buffer.setEOM(true);
/*      */         
/*      */         return;
/*      */       } 
/* 2450 */       buffer.setFormat(this.format);
/* 2451 */       doReadFrame(buffer);
/*      */     }
/*      */     
/*      */     abstract void doReadFrame(Buffer param1Buffer);
/*      */     
/*      */     public int mapTimeToFrame(Time t) {
/* 2457 */       return Integer.MAX_VALUE;
/*      */     }
/*      */     
/*      */     public Time mapFrameToTime(int frameNumber) {
/* 2461 */       return Track.TIME_UNKNOWN;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class AudioTrack
/*      */     extends MediaTrack
/*      */   {
/*      */     String encoding;
/*      */     
/*      */     int channels;
/*      */     int sampleOffsetInChunk;
/*      */     int useSampleOffsetInChunk;
/*      */     int frameSizeInBytes;
/*      */     int samplesPerBlock;
/*      */     int sampleRate;
/*      */     private final QuicktimeParser this$0;
/*      */     
/*      */     AudioTrack(QuicktimeParser this$0, QuicktimeParser.TrakList trakInfo, int channels, String encoding, int frameSizeInBytes, int samplesPerBlock, int sampleRate) {
/* 2480 */       super(this$0, trakInfo); this.this$0 = this$0; this.sampleOffsetInChunk = -1; this.useSampleOffsetInChunk = 0;
/* 2481 */       this.channels = channels;
/* 2482 */       this.encoding = encoding;
/* 2483 */       this.frameSizeInBytes = frameSizeInBytes;
/* 2484 */       this.samplesPerBlock = samplesPerBlock;
/* 2485 */       this.sampleRate = sampleRate;
/*      */     }
/*      */ 
/*      */     
/*      */     AudioTrack(QuicktimeParser this$0, QuicktimeParser.TrakList trakInfo) {
/* 2490 */       super(this$0, trakInfo); this.this$0 = this$0; this.sampleOffsetInChunk = -1; this.useSampleOffsetInChunk = 0;
/* 2491 */       if (trakInfo != null) {
/* 2492 */         this.channels = ((QuicktimeParser.Audio)trakInfo.media).channels;
/* 2493 */         this.encoding = trakInfo.media.encoding;
/* 2494 */         this.frameSizeInBytes = ((QuicktimeParser.Audio)trakInfo.media).frameSizeInBits / 8;
/* 2495 */         this.samplesPerBlock = ((QuicktimeParser.Audio)trakInfo.media).samplesPerBlock;
/* 2496 */         this.sampleRate = ((QuicktimeParser.Audio)trakInfo.media).sampleRate;
/*      */       } 
/*      */     }
/*      */     
/*      */     synchronized void setChunkNumberAndSampleOffset(int number, int offset) {
/* 2501 */       this.chunkNumber = number;
/* 2502 */       this.sampleOffsetInChunk = offset;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void doReadFrame(Buffer buffer) {
/*      */       int i;
/*      */       long l;
/*      */       int j, k;
/*      */       byte[] arrayOfByte;
/* 2513 */       synchronized (this) {
/* 2514 */         if (this.sampleOffsetInChunk == -1) {
/* 2515 */           this.useSampleOffsetInChunk = 0;
/*      */         } else {
/* 2517 */           this.useSampleOffsetInChunk = this.sampleOffsetInChunk;
/* 2518 */           this.sampleOffsetInChunk = -1;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2526 */       if (this.constantSamplesPerChunk != -1) {
/* 2527 */         i = this.constantSamplesPerChunk;
/* 2528 */         l = (this.constantSamplesPerChunk * this.useChunkNumber);
/* 2529 */       } else if (this.useChunkNumber > 0) {
/* 2530 */         i = this.samplesPerChunk[this.useChunkNumber] - this.samplesPerChunk[this.useChunkNumber - 1];
/*      */         
/* 2532 */         l = this.samplesPerChunk[this.useChunkNumber];
/*      */       } else {
/* 2534 */         i = this.samplesPerChunk[this.useChunkNumber];
/* 2535 */         l = 0L;
/*      */       } 
/*      */ 
/*      */       
/* 2539 */       if (this.samplesPerBlock > 1) {
/* 2540 */         k = this.useSampleOffsetInChunk / this.samplesPerBlock;
/* 2541 */         this.useSampleOffsetInChunk = k * this.samplesPerBlock;
/* 2542 */         j = this.frameSizeInBytes * k;
/*      */       } else {
/* 2544 */         j = this.useSampleOffsetInChunk * this.frameSizeInBytes;
/*      */       } 
/*      */       
/* 2547 */       i -= this.useSampleOffsetInChunk;
/* 2548 */       l += this.useSampleOffsetInChunk;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2557 */       if (this.encoding.equals("ima4")) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2566 */         k = i / this.samplesPerBlock * 34 * this.channels;
/* 2567 */       } else if (this.encoding.equals("agsm")) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2573 */         k = i / 160 * this.samplesPerBlock;
/*      */       } else {
/* 2575 */         k = i * ((AudioFormat)this.format).getSampleSizeInBits() / 8 * this.channels;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2580 */       Object obj = buffer.getData();
/*      */ 
/*      */       
/* 2583 */       if (obj == null || !(obj instanceof byte[]) || ((byte[])obj).length < k) {
/*      */ 
/*      */         
/* 2586 */         arrayOfByte = new byte[k];
/* 2587 */         buffer.setData(arrayOfByte);
/*      */       } else {
/* 2589 */         arrayOfByte = (byte[])obj;
/*      */       } 
/*      */       
/*      */       try {
/*      */         int actualBytesRead;
/* 2594 */         synchronized (this.this$0.seekSync) {
/* 2595 */           int offset = this.trakInfo.chunkOffsets[this.useChunkNumber];
/*      */ 
/*      */           
/* 2598 */           if (this.sampleIndex != this.useSampleIndex) {
/*      */             
/* 2600 */             buffer.setDiscard(true);
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/* 2605 */           if (this.cacheStream != null && this.listener != null)
/*      */           {
/* 2607 */             if (this.cacheStream.willReadBytesBlock((offset + j), k))
/*      */             {
/* 2609 */               this.listener.readHasBlocked(this);
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2618 */           long pos = this.this$0.seekableStream.seek((offset + j));
/* 2619 */           if (pos == -2L) {
/* 2620 */             buffer.setDiscard(true);
/*      */             return;
/*      */           } 
/* 2623 */           actualBytesRead = this.parser.readBytes(this.this$0.stream, arrayOfByte, k);
/*      */           
/* 2625 */           if (actualBytesRead == -2) {
/* 2626 */             buffer.setDiscard(true);
/*      */             return;
/*      */           } 
/*      */         } 
/* 2630 */         buffer.setLength(actualBytesRead);
/*      */         
/* 2632 */         buffer.setSequenceNumber(++this.sequenceNumber);
/* 2633 */         if (this.sampleRate > 0) {
/* 2634 */           long timeStamp = l * 1000000000L / this.sampleRate;
/*      */ 
/*      */           
/* 2637 */           buffer.setTimeStamp(timeStamp);
/* 2638 */           buffer.setDuration(-1L);
/*      */         } 
/*      */       } catch (IOException e) {
/*      */         
/* 2642 */         buffer.setLength(0);
/* 2643 */         buffer.setEOM(true);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2649 */       synchronized (this) {
/* 2650 */         if (this.chunkNumber == this.useChunkNumber)
/*      */         {
/* 2652 */           this.chunkNumber++; } 
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private class VideoTrack extends MediaTrack {
/*      */     int needBufferSize;
/*      */     boolean variableSampleSize;
/*      */     private final QuicktimeParser this$0;
/*      */     
/*      */     VideoTrack(QuicktimeParser this$0, QuicktimeParser.TrakList trakInfo) {
/* 2663 */       super(this$0, trakInfo); this.this$0 = this$0; this.variableSampleSize = true;
/* 2664 */       if (trakInfo != null && 
/* 2665 */         trakInfo.sampleSize != 0) {
/* 2666 */         this.variableSampleSize = false;
/* 2667 */         this.needBufferSize = trakInfo.sampleSize;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void doReadFrame(Buffer buffer) {
/*      */       byte[] arrayOfByte;
/* 2678 */       if (this.useSampleIndex >= this.trakInfo.numberOfSamples) {
/* 2679 */         buffer.setLength(0);
/* 2680 */         buffer.setEOM(true);
/*      */         return;
/*      */       } 
/* 2683 */       if (this.variableSampleSize) {
/* 2684 */         if (this.useSampleIndex >= this.trakInfo.sampleSizeArray.length) {
/* 2685 */           buffer.setLength(0);
/* 2686 */           buffer.setEOM(true);
/*      */           return;
/*      */         } 
/* 2689 */         this.needBufferSize = this.trakInfo.sampleSizeArray[this.useSampleIndex];
/*      */       } 
/*      */ 
/*      */       
/* 2693 */       long offset = this.trakInfo.sampleOffsetTable[this.useSampleIndex];
/* 2694 */       Object obj = buffer.getData();
/*      */ 
/*      */       
/* 2697 */       if (obj == null || !(obj instanceof byte[]) || ((byte[])obj).length < this.needBufferSize) {
/*      */ 
/*      */         
/* 2700 */         arrayOfByte = new byte[this.needBufferSize];
/* 2701 */         buffer.setData(arrayOfByte);
/*      */       } else {
/* 2703 */         arrayOfByte = (byte[])obj;
/*      */       } 
/*      */       try {
/*      */         int actualBytesRead;
/* 2707 */         synchronized (this.this$0.seekSync) {
/*      */ 
/*      */           
/* 2710 */           if (this.sampleIndex != this.useSampleIndex) {
/*      */             
/* 2712 */             buffer.setDiscard(true);
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/* 2717 */           if (this.cacheStream != null && this.listener != null && 
/* 2718 */             this.cacheStream.willReadBytesBlock(offset, this.needBufferSize))
/*      */           {
/*      */             
/* 2721 */             this.listener.readHasBlocked(this);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2730 */           long pos = this.this$0.seekableStream.seek(offset);
/*      */           
/* 2732 */           if (pos == -2L) {
/* 2733 */             buffer.setDiscard(true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             return;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2790 */           actualBytesRead = this.parser.readBytes(this.this$0.stream, arrayOfByte, this.needBufferSize);
/*      */           
/* 2792 */           if (actualBytesRead == -2) {
/* 2793 */             buffer.setDiscard(true);
/*      */             
/*      */             return;
/*      */           } 
/*      */         } 
/* 2798 */         buffer.setLength(actualBytesRead);
/*      */         
/* 2800 */         int[] syncSampleMapping = this.trakInfo.syncSampleMapping;
/* 2801 */         boolean keyFrame = true;
/* 2802 */         if (syncSampleMapping != null) {
/* 2803 */           keyFrame = (syncSampleMapping[this.useSampleIndex] == this.useSampleIndex);
/*      */         }
/*      */         
/* 2806 */         if (keyFrame) {
/* 2807 */           buffer.setFlags(buffer.getFlags() | 0x10);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 2812 */         buffer.setSequenceNumber(++this.sequenceNumber);
/* 2813 */         QuicktimeParser.TimeAndDuration td = this.trakInfo.index2TimeAndDuration(this.useSampleIndex);
/*      */ 
/*      */         
/* 2816 */         buffer.setTimeStamp((long)(td.startTime * 1.0E9D));
/* 2817 */         buffer.setDuration((long)(td.duration * 1.0E9D));
/*      */       }
/*      */       catch (IOException e) {
/*      */         
/* 2821 */         buffer.setLength(0);
/* 2822 */         buffer.setEOM(true);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2828 */       synchronized (this) {
/* 2829 */         if (this.sampleIndex == this.useSampleIndex)
/* 2830 */           this.sampleIndex++; 
/*      */       } 
/*      */     }
/*      */     
/*      */     public int mapTimeToFrame(Time t) {
/* 2835 */       double time = t.getSeconds();
/*      */       
/* 2837 */       if (time < 0.0D) {
/* 2838 */         return Integer.MAX_VALUE;
/*      */       }
/* 2840 */       int index = this.trakInfo.time2Index(time);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2848 */       if (index < 0) {
/* 2849 */         return this.trakInfo.numberOfSamples - 1;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2856 */       return index;
/*      */     }
/*      */     
/*      */     public Time mapFrameToTime(int frameNumber) {
/* 2860 */       if (frameNumber < 0 || frameNumber >= this.trakInfo.numberOfSamples) {
/* 2861 */         return Track.TIME_UNKNOWN;
/*      */       }
/*      */ 
/*      */       
/* 2865 */       double time = (frameNumber / this.trakInfo.media.frameRate);
/*      */ 
/*      */       
/* 2868 */       return new Time(time);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class HintAudioTrack
/*      */     extends AudioTrack
/*      */   {
/*      */     int hintSampleSize;
/*      */     
/*      */     int indexOfTrackBeingHinted;
/*      */     
/*      */     int maxPacketSize;
/*      */     
/*      */     int currentPacketNumber;
/*      */     int numPacketsInSample;
/*      */     long offsetToStartOfPacketInfo;
/*      */     QuicktimeParser.TrakList sampleTrakInfo;
/*      */     boolean variableSampleSize;
/*      */     private final QuicktimeParser this$0;
/*      */     
/*      */     HintAudioTrack(QuicktimeParser this$0, QuicktimeParser.TrakList trakInfo, int channels, String encoding, int frameSizeInBytes, int samplesPerBlock, int sampleRate) {
/* 2890 */       super(this$0, trakInfo, channels, encoding, frameSizeInBytes, samplesPerBlock, sampleRate); this.this$0 = this$0; this.indexOfTrackBeingHinted = this.trakInfo.indexOfTrackBeingHinted; this.currentPacketNumber = 0; this.numPacketsInSample = -1; this.offsetToStartOfPacketInfo = -1L;
/*      */       this.variableSampleSize = true;
/* 2892 */       this.format = ((QuicktimeParser.Hint)trakInfo.media).format;
/*      */       
/* 2894 */       this.maxPacketSize = trakInfo.maxPacketSize;
/*      */       
/* 2896 */       if (this.indexOfTrackBeingHinted >= 0) {
/* 2897 */         this.sampleTrakInfo = this$0.trakList[this.indexOfTrackBeingHinted];
/*      */       }
/* 2899 */       else if (this$0.debug) {
/* 2900 */         System.out.println("sampleTrakInfo is not set " + this.indexOfTrackBeingHinted);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2910 */       if (trakInfo.sampleSize != 0) {
/* 2911 */         this.variableSampleSize = false;
/* 2912 */         this.hintSampleSize = trakInfo.sampleSize;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void readFrame(Buffer buffer) {
/* 2924 */       if (buffer == null) {
/*      */         return;
/*      */       }
/* 2927 */       if (!this.enabled) {
/* 2928 */         buffer.setDiscard(true);
/*      */         
/*      */         return;
/*      */       } 
/* 2932 */       synchronized (this) {
/* 2933 */         this.useChunkNumber = this.chunkNumber;
/* 2934 */         this.useSampleIndex = this.sampleIndex;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2945 */       buffer.setFormat(this.format);
/* 2946 */       doReadFrame(buffer);
/*      */     }
/*      */ 
/*      */     
/*      */     synchronized void setSampleIndex(int index) {
/* 2951 */       this.chunkNumber = index;
/* 2952 */       this.sampleIndex = index;
/*      */     }
/*      */ 
/*      */     
/*      */     void doReadFrame(Buffer buffer) {
/*      */       byte[] arrayOfByte;
/* 2958 */       if (this.this$0.debug1) {
/* 2959 */         System.out.println("audio: hint doReadFrame: " + this.useChunkNumber + " : " + this.sampleOffsetInChunk);
/*      */       }
/*      */ 
/*      */       
/* 2963 */       boolean rtpMarkerSet = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2969 */       if (this.indexOfTrackBeingHinted < 0) {
/* 2970 */         buffer.setDiscard(true);
/*      */         
/*      */         return;
/*      */       } 
/* 2974 */       int rtpOffset = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2981 */       if (this.variableSampleSize) {
/* 2982 */         if (this.useSampleIndex >= this.trakInfo.sampleSizeArray.length) {
/* 2983 */           this.hintSampleSize = this.trakInfo.sampleSizeArray[this.trakInfo.sampleSizeArray.length - 1];
/*      */         } else {
/* 2985 */           this.hintSampleSize = this.trakInfo.sampleSizeArray[this.useSampleIndex];
/*      */         } 
/*      */       }
/*      */       
/* 2989 */       int remainingHintSampleSize = this.hintSampleSize;
/*      */       
/* 2991 */       if (this.this$0.debug1) {
/* 2992 */         System.out.println("hintSampleSize is " + this.hintSampleSize);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 2997 */       Object obj = buffer.getData();
/*      */ 
/*      */       
/* 3000 */       if (obj == null || !(obj instanceof byte[]) || ((byte[])obj).length < this.maxPacketSize) {
/*      */ 
/*      */         
/* 3003 */         arrayOfByte = new byte[this.maxPacketSize];
/* 3004 */         buffer.setData(arrayOfByte);
/*      */       } else {
/* 3006 */         arrayOfByte = (byte[])obj;
/*      */       } 
/*      */       
/*      */       try {
/*      */         int rtpSequenceNumber, actualBytesRead;
/* 3011 */         synchronized (this.this$0.seekSync) {
/*      */ 
/*      */           
/* 3014 */           if (this.sampleIndex != this.useSampleIndex) {
/*      */ 
/*      */             
/* 3017 */             buffer.setDiscard(true);
/* 3018 */             this.currentPacketNumber = 0;
/* 3019 */             this.numPacketsInSample = -1;
/* 3020 */             this.offsetToStartOfPacketInfo = -1L;
/* 3021 */             rtpOffset = 0;
/*      */ 
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/* 3027 */           long offset = this.trakInfo.index2Offset(this.useChunkNumber);
/* 3028 */           if (this.this$0.debug) {
/* 3029 */             System.out.println("audio: Calling index2Offset on hint track with arg " + this.useChunkNumber);
/*      */             
/* 3031 */             System.out.println("offset is " + offset);
/*      */           } 
/*      */ 
/*      */           
/* 3035 */           if (offset == -2L) {
/* 3036 */             buffer.setLength(0);
/* 3037 */             buffer.setEOM(true);
/*      */             
/*      */             return;
/*      */           } 
/* 3041 */           if (this.cacheStream != null && this.listener != null)
/*      */           {
/* 3043 */             if (this.cacheStream.willReadBytesBlock(offset, this.hintSampleSize))
/*      */             {
/*      */               
/* 3046 */               this.listener.readHasBlocked(this);
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3054 */           if (this.this$0.debug1) {
/* 3055 */             System.out.println("currentPacketNumber is " + this.currentPacketNumber);
/*      */           }
/* 3057 */           if (this.offsetToStartOfPacketInfo < 0L) {
/* 3058 */             if (this.this$0.debug1) {
/* 3059 */               System.out.println("NEW SEEK");
/*      */             }
/* 3061 */             long pos = this.this$0.seekableStream.seek(offset);
/*      */             
/* 3063 */             if (pos == -2L) {
/* 3064 */               buffer.setDiscard(true);
/*      */               
/*      */               return;
/*      */             } 
/* 3068 */             this.numPacketsInSample = this.parser.readShort(this.this$0.stream);
/* 3069 */             if (this.this$0.debug) {
/* 3070 */               System.out.println("num packets in sample " + this.numPacketsInSample);
/*      */             }
/*      */             
/* 3073 */             if (this.numPacketsInSample < 1) {
/* 3074 */               buffer.setDiscard(true);
/*      */               
/*      */               return;
/*      */             } 
/* 3078 */             remainingHintSampleSize -= 2;
/* 3079 */             this.parser.readShort(this.this$0.stream);
/* 3080 */             remainingHintSampleSize -= 2;
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/* 3086 */             long l = this.this$0.seekableStream.seek(this.offsetToStartOfPacketInfo);
/* 3087 */             if (l == -2L) {
/* 3088 */               buffer.setDiscard(true);
/*      */ 
/*      */               
/*      */               return;
/*      */             } 
/*      */           } 
/*      */           
/* 3095 */           int relativeTransmissionTime = this.parser.readInt(this.this$0.stream);
/* 3096 */           remainingHintSampleSize -= 4;
/*      */ 
/*      */           
/* 3099 */           int rtpHeaderInfo = this.parser.readShort(this.this$0.stream);
/* 3100 */           if (this.this$0.debug) {
/* 3101 */             System.out.println("rtpHeaderInfo is " + Integer.toHexString(rtpHeaderInfo));
/*      */           }
/*      */           
/* 3104 */           rtpMarkerSet = ((rtpHeaderInfo & 0x80) > 0);
/*      */ 
/*      */           
/* 3107 */           remainingHintSampleSize -= 2;
/* 3108 */           rtpSequenceNumber = this.parser.readShort(this.this$0.stream);
/* 3109 */           remainingHintSampleSize -= 2;
/*      */           
/* 3111 */           boolean paddingPresent = ((rtpHeaderInfo & 0x2000) > 0);
/* 3112 */           boolean extensionHeaderPresent = ((rtpHeaderInfo & 0x1000) > 0);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3117 */           if (paddingPresent);
/*      */ 
/*      */ 
/*      */           
/* 3121 */           if (extensionHeaderPresent);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3126 */           int flags = this.parser.readShort(this.this$0.stream);
/*      */           
/* 3128 */           if (this.this$0.debug) {
/*      */ 
/*      */ 
/*      */             
/* 3132 */             System.out.println("rtp marker present? " + rtpMarkerSet);
/* 3133 */             System.out.println("rtp payload type " + (rtpHeaderInfo & 0x7F));
/*      */ 
/*      */             
/* 3136 */             System.out.println("padding? " + paddingPresent);
/* 3137 */             System.out.println("extension header? " + extensionHeaderPresent);
/* 3138 */             System.out.println("audio hint: flags is " + Integer.toHexString(flags));
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3144 */           remainingHintSampleSize -= 2;
/*      */           
/* 3146 */           int entriesInDataTable = this.parser.readShort(this.this$0.stream);
/* 3147 */           remainingHintSampleSize -= 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3157 */           boolean extraInfoTLVPresent = ((flags & 0x4) > 0);
/*      */           
/* 3159 */           if (extraInfoTLVPresent) {
/* 3160 */             int tlvTableSize = this.parser.readInt(this.this$0.stream);
/*      */             
/* 3162 */             this.this$0.skip(this.this$0.stream, tlvTableSize - 4);
/*      */             
/* 3164 */             if (this.this$0.debug) {
/* 3165 */               System.err.println("audio: extraInfoTLVPresent: Skipped");
/* 3166 */               System.out.println("tlvTableSize is " + tlvTableSize);
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 3172 */           if (this.this$0.debug) {
/* 3173 */             System.out.println("Packet # " + this.currentPacketNumber);
/* 3174 */             System.out.println("  relativeTransmissionTime is " + relativeTransmissionTime);
/*      */             
/* 3176 */             System.out.println("  rtpSequenceNumber is " + rtpSequenceNumber);
/* 3177 */             System.out.println("  entriesInDataTable is " + entriesInDataTable);
/*      */           } 
/*      */           
/* 3180 */           for (int j = 0; j < entriesInDataTable; j++) {
/* 3181 */             int dataBlockSource = this.parser.readByte(this.this$0.stream);
/* 3182 */             remainingHintSampleSize--;
/* 3183 */             if (this.this$0.debug1) {
/* 3184 */               System.out.println("    dataBlockSource is " + dataBlockSource);
/*      */             }
/*      */             
/* 3187 */             if (dataBlockSource == 1) {
/* 3188 */               int length = this.parser.readByte(this.this$0.stream);
/*      */ 
/*      */               
/* 3191 */               remainingHintSampleSize--;
/*      */ 
/*      */               
/* 3194 */               this.parser.readBytes(this.this$0.stream, arrayOfByte, rtpOffset, length);
/* 3195 */               rtpOffset += length;
/* 3196 */               this.parser.skip(this.this$0.stream, 14 - length);
/* 3197 */               remainingHintSampleSize -= 14;
/* 3198 */             } else if (dataBlockSource == 2) {
/* 3199 */               QuicktimeParser.TrakList trakList; long l2; int trackRefIndex = this.parser.readByte(this.this$0.stream);
/* 3200 */               if (this.this$0.debug1) {
/* 3201 */                 System.out.println("     audio:trackRefIndex is " + trackRefIndex);
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 3207 */               if (trackRefIndex > 0) {
/* 3208 */                 System.err.println("     Currently we don't support hint tracks that refer to multiple media tracks: " + trackRefIndex);
/* 3209 */                 buffer.setDiscard(true);
/*      */                 
/*      */                 return;
/*      */               } 
/* 3213 */               int numBytesToCopy = this.parser.readShort(this.this$0.stream);
/* 3214 */               int sampleNumber = this.parser.readInt(this.this$0.stream);
/* 3215 */               int byteOffset = this.parser.readInt(this.this$0.stream);
/* 3216 */               int bytesPerCompresionBlock = this.parser.readShort(this.this$0.stream);
/* 3217 */               int samplesPerCompresionBlock = this.parser.readShort(this.this$0.stream);
/*      */               
/* 3219 */               if (this.this$0.debug1) {
/* 3220 */                 System.out.println("     sample Number is " + sampleNumber);
/* 3221 */                 System.out.println("     numBytesToCopy is " + numBytesToCopy);
/* 3222 */                 System.out.println("     byteOffset is " + byteOffset);
/* 3223 */                 System.out.println("     bytesPerCompresionBlock is " + bytesPerCompresionBlock);
/* 3224 */                 System.out.println("     samplesPerCompresionBlock is " + samplesPerCompresionBlock);
/*      */               } 
/* 3226 */               remainingHintSampleSize -= 15;
/* 3227 */               long saveCurrentPos = this.parser.getLocation(this.this$0.stream);
/*      */ 
/*      */ 
/*      */               
/* 3231 */               if (trackRefIndex == 0) {
/* 3232 */                 trakList = this.sampleTrakInfo;
/* 3233 */                 if (this.this$0.debug2) {
/* 3234 */                   System.out.println("set useTrakInfo as sampleTrakInfo");
/*      */                 
/*      */                 }
/*      */               
/*      */               }
/*      */               else {
/*      */                 
/* 3241 */                 trakList = this.trakInfo;
/*      */               } 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 3247 */               if (this.this$0.debug1) {
/* 3248 */                 System.out.println("useTrakInfo is " + trakList);
/* 3249 */                 System.out.println("useTrakInfo.sampleOffsetTable is " + trakList.sampleOffsetTable);
/*      */               } 
/*      */ 
/*      */ 
/*      */               
/* 3254 */               if (trakList.sampleOffsetTable == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 3262 */                 l2 = trakList.index2Offset(sampleNumber - 1);
/* 3263 */                 if (this.this$0.debug1) {
/* 3264 */                   System.out.println("chunkOffsets size is " + trakList.chunkOffsets.length);
/*      */                   
/* 3266 */                   System.out.println("sampleOffset from index2Offset " + l2);
/*      */                 } 
/*      */               } else {
/*      */                 
/* 3270 */                 l2 = trakList.sampleOffsetTable[sampleNumber - 1];
/*      */               } 
/*      */ 
/*      */ 
/*      */               
/* 3275 */               l2 += byteOffset;
/*      */ 
/*      */               
/* 3278 */               long l1 = this.this$0.seekableStream.seek(l2);
/* 3279 */               if (l1 == -2L) {
/* 3280 */                 buffer.setDiscard(true);
/*      */                 
/* 3282 */                 this.offsetToStartOfPacketInfo = -1L;
/*      */                 
/*      */                 return;
/*      */               } 
/* 3286 */               if (this.this$0.debug1) {
/* 3287 */                 System.out.println("Audio: Seek to " + l2 + " and read " + numBytesToCopy + " bytes into buffer with offset " + rtpOffset);
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 3302 */               this.parser.readBytes(this.this$0.stream, arrayOfByte, rtpOffset, numBytesToCopy);
/* 3303 */               rtpOffset += numBytesToCopy;
/*      */ 
/*      */               
/* 3306 */               l1 = this.this$0.seekableStream.seek(saveCurrentPos);
/* 3307 */               if (l1 == -2L) {
/* 3308 */                 buffer.setDiscard(true);
/*      */                 
/* 3310 */                 this.offsetToStartOfPacketInfo = -1L;
/*      */                 return;
/*      */               } 
/* 3313 */             } else if (dataBlockSource == 0) {
/*      */               
/* 3315 */               int length = this.parser.readByte(this.this$0.stream);
/* 3316 */               this.parser.skip(this.this$0.stream, length);
/* 3317 */               remainingHintSampleSize -= length;
/*      */             }
/*      */             else {
/*      */               
/* 3321 */               System.err.println("DISCARD: dataBlockSource " + dataBlockSource + " not supported");
/*      */               
/* 3323 */               buffer.setDiscard(true);
/* 3324 */               this.offsetToStartOfPacketInfo = -1L;
/*      */               return;
/*      */             } 
/*      */           } 
/* 3328 */           actualBytesRead = rtpOffset;
/* 3329 */           if (this.this$0.debug1) {
/* 3330 */             System.out.println("Actual size of packet sent " + rtpOffset);
/*      */           }
/* 3332 */           rtpOffset = 0;
/*      */ 
/*      */ 
/*      */           
/* 3336 */           this.offsetToStartOfPacketInfo = this.parser.getLocation(this.this$0.stream);
/*      */ 
/*      */ 
/*      */           
/* 3340 */           if (actualBytesRead == -2) {
/*      */ 
/*      */             
/* 3343 */             buffer.setDiscard(true);
/*      */             return;
/*      */           } 
/*      */         } 
/* 3347 */         buffer.setLength(actualBytesRead);
/*      */         
/* 3349 */         if (rtpMarkerSet) {
/* 3350 */           if (this.this$0.debug)
/* 3351 */             System.out.println("rtpMarkerSet: true"); 
/* 3352 */           buffer.setFlags(buffer.getFlags() | 0x800);
/*      */         } else {
/* 3354 */           if (this.this$0.debug)
/* 3355 */             System.out.println("rtpMarkerSet: false"); 
/* 3356 */           buffer.setFlags(buffer.getFlags() & 0xFFFFF7FF);
/*      */         } 
/* 3358 */         buffer.setSequenceNumber(rtpSequenceNumber);
/*      */ 
/*      */         
/* 3361 */         double startTime = (this.trakInfo.index2TimeAndDuration(this.useChunkNumber)).startTime;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3366 */         long timeStamp = (long)(startTime * 1.0E9D);
/*      */         
/* 3368 */         buffer.setTimeStamp(timeStamp);
/*      */         
/* 3370 */         buffer.setDuration(-1L);
/*      */       } catch (IOException e) {
/*      */         
/* 3373 */         buffer.setLength(0);
/* 3374 */         buffer.setEOM(true);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3380 */       synchronized (this) {
/* 3381 */         if (this.chunkNumber != this.useChunkNumber) {
/*      */ 
/*      */ 
/*      */           
/* 3385 */           this.currentPacketNumber = 0;
/* 3386 */           this.numPacketsInSample = -1;
/* 3387 */           this.offsetToStartOfPacketInfo = -1L;
/* 3388 */           rtpOffset = 0;
/*      */         }
/*      */         else {
/*      */           
/* 3392 */           this.currentPacketNumber++;
/* 3393 */           if (this.currentPacketNumber >= this.numPacketsInSample) {
/* 3394 */             this.chunkNumber++;
/* 3395 */             this.currentPacketNumber = 0;
/* 3396 */             this.numPacketsInSample = -1;
/* 3397 */             this.offsetToStartOfPacketInfo = -1L;
/* 3398 */             rtpOffset = 0;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class HintVideoTrack
/*      */     extends VideoTrack
/*      */   {
/*      */     int hintSampleSize;
/*      */     
/*      */     int indexOfTrackBeingHinted;
/*      */     
/*      */     int maxPacketSize;
/*      */     int currentPacketNumber;
/*      */     int numPacketsInSample;
/*      */     long offsetToStartOfPacketInfo;
/*      */     QuicktimeParser.TrakList sampleTrakInfo;
/*      */     private final QuicktimeParser this$0;
/*      */     
/*      */     HintVideoTrack(QuicktimeParser this$0, QuicktimeParser.TrakList trakInfo) {
/* 3421 */       super(this$0, trakInfo); this.this$0 = this$0; this.indexOfTrackBeingHinted = this.trakInfo.indexOfTrackBeingHinted; this.currentPacketNumber = 0; this.numPacketsInSample = -1; this.offsetToStartOfPacketInfo = -1L; this.sampleTrakInfo = null;
/* 3422 */       this.format = ((QuicktimeParser.Hint)trakInfo.media).format;
/* 3423 */       this.hintSampleSize = this.needBufferSize;
/* 3424 */       this.maxPacketSize = trakInfo.maxPacketSize;
/*      */       
/* 3426 */       if (this$0.debug1) {
/* 3427 */         System.out.println("HintVideoTrack: Index of hinted track: " + trakInfo.indexOfTrackBeingHinted);
/*      */         
/* 3429 */         System.out.println("HintVideoTrack: packet size is " + this.maxPacketSize);
/*      */       } 
/*      */       
/* 3432 */       if (this.indexOfTrackBeingHinted >= 0) {
/* 3433 */         this.sampleTrakInfo = this$0.trakList[this.indexOfTrackBeingHinted];
/*      */       }
/* 3435 */       else if (this$0.debug) {
/* 3436 */         System.out.println("sampleTrakInfo is not set " + this.indexOfTrackBeingHinted);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void doReadFrame(Buffer buffer) {
/*      */       byte[] arrayOfByte;
/* 3444 */       boolean rtpMarkerSet = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3450 */       if (this.indexOfTrackBeingHinted < 0) {
/* 3451 */         buffer.setDiscard(true);
/*      */         
/*      */         return;
/*      */       } 
/* 3455 */       if (this.useSampleIndex >= this.trakInfo.numberOfSamples) {
/* 3456 */         buffer.setLength(0);
/* 3457 */         buffer.setEOM(true);
/*      */         
/*      */         return;
/*      */       } 
/* 3461 */       int rtpOffset = 0;
/*      */ 
/*      */       
/* 3464 */       if (this.variableSampleSize) {
/* 3465 */         this.hintSampleSize = this.trakInfo.sampleSizeArray[this.useSampleIndex];
/*      */       }
/* 3467 */       int remainingHintSampleSize = this.hintSampleSize;
/* 3468 */       long offset = this.trakInfo.sampleOffsetTable[this.useSampleIndex];
/*      */       
/* 3470 */       if (this.this$0.debug1) {
/* 3471 */         System.out.println("hintSampleSize is " + this.hintSampleSize);
/* 3472 */         System.out.println("useSampleIndex, offset " + this.useSampleIndex + " : " + offset);
/*      */       } 
/*      */ 
/*      */       
/* 3476 */       Object obj = buffer.getData();
/*      */ 
/*      */       
/* 3479 */       if (obj == null || !(obj instanceof byte[]) || ((byte[])obj).length < this.maxPacketSize) {
/*      */ 
/*      */         
/* 3482 */         arrayOfByte = new byte[this.maxPacketSize];
/* 3483 */         buffer.setData(arrayOfByte);
/*      */       } else {
/* 3485 */         arrayOfByte = (byte[])obj;
/*      */       } 
/*      */       
/*      */       try {
/*      */         int rtpSequenceNumber, actualBytesRead;
/* 3490 */         synchronized (this.this$0.seekSync) {
/*      */           
/* 3492 */           if (this.sampleIndex != this.useSampleIndex) {
/*      */             
/* 3494 */             buffer.setDiscard(true);
/* 3495 */             this.currentPacketNumber = 0;
/* 3496 */             this.numPacketsInSample = -1;
/* 3497 */             this.offsetToStartOfPacketInfo = -1L;
/* 3498 */             rtpOffset = 0;
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/* 3503 */           if (this.cacheStream != null && this.listener != null && 
/* 3504 */             this.cacheStream.willReadBytesBlock(offset, this.hintSampleSize))
/*      */           {
/*      */             
/* 3507 */             this.listener.readHasBlocked(this);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3515 */           if (this.offsetToStartOfPacketInfo < 0L) {
/* 3516 */             long pos = this.this$0.seekableStream.seek(offset);
/*      */             
/* 3518 */             if (pos == -2L) {
/* 3519 */               buffer.setDiscard(true);
/*      */               
/*      */               return;
/*      */             } 
/* 3523 */             this.numPacketsInSample = this.parser.readShort(this.this$0.stream);
/* 3524 */             if (this.this$0.debug) {
/* 3525 */               System.out.println("video: num packets in sample " + this.numPacketsInSample);
/*      */             }
/*      */             
/* 3528 */             if (this.numPacketsInSample < 1) {
/* 3529 */               buffer.setDiscard(true);
/*      */               
/*      */               return;
/*      */             } 
/* 3533 */             remainingHintSampleSize -= 2;
/* 3534 */             this.parser.readShort(this.this$0.stream);
/* 3535 */             remainingHintSampleSize -= 2;
/*      */           } else {
/*      */             
/* 3538 */             long l = this.this$0.seekableStream.seek(this.offsetToStartOfPacketInfo);
/* 3539 */             if (l == -2L) {
/* 3540 */               buffer.setDiscard(true);
/*      */ 
/*      */               
/*      */               return;
/*      */             } 
/*      */           } 
/*      */           
/* 3547 */           int relativeTransmissionTime = this.parser.readInt(this.this$0.stream);
/* 3548 */           remainingHintSampleSize -= 4;
/*      */           
/* 3550 */           int rtpHeaderInfo = (short)this.parser.readShort(this.this$0.stream);
/* 3551 */           rtpMarkerSet = ((rtpHeaderInfo & 0x80) > 0);
/* 3552 */           remainingHintSampleSize -= 2;
/* 3553 */           rtpSequenceNumber = this.parser.readShort(this.this$0.stream);
/* 3554 */           remainingHintSampleSize -= 2;
/*      */           
/* 3556 */           boolean paddingPresent = ((rtpHeaderInfo & 0x2000) > 0);
/* 3557 */           boolean extensionHeaderPresent = ((rtpHeaderInfo & 0x1000) > 0);
/*      */           
/* 3559 */           if (paddingPresent);
/*      */ 
/*      */ 
/*      */           
/* 3563 */           if (extensionHeaderPresent);
/*      */ 
/*      */ 
/*      */           
/* 3567 */           int flags = this.parser.readShort(this.this$0.stream);
/*      */           
/* 3569 */           if (this.this$0.debug) {
/*      */ 
/*      */             
/* 3572 */             System.out.println("rtp marker present? " + rtpMarkerSet);
/* 3573 */             System.out.println("rtp payload type " + (rtpHeaderInfo & 0x7F));
/*      */ 
/*      */             
/* 3576 */             System.out.println("padding? " + paddingPresent);
/* 3577 */             System.out.println("extension header? " + extensionHeaderPresent);
/*      */ 
/*      */             
/* 3580 */             System.out.println("video hint: flags is " + Integer.toHexString(flags));
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 3585 */           remainingHintSampleSize -= 2;
/*      */           
/* 3587 */           int entriesInDataTable = this.parser.readShort(this.this$0.stream);
/* 3588 */           remainingHintSampleSize -= 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3598 */           boolean extraInfoTLVPresent = ((flags & 0x4) > 0);
/* 3599 */           if (extraInfoTLVPresent) {
/* 3600 */             int tlvTableSize = this.parser.readInt(this.this$0.stream);
/*      */             
/* 3602 */             this.this$0.skip(this.this$0.stream, tlvTableSize - 4);
/* 3603 */             if (this.this$0.debug) {
/* 3604 */               System.err.println("video: extraInfoTLVPresent: Skipped");
/* 3605 */               System.out.println("tlvTableSize is " + tlvTableSize);
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/* 3610 */           if (this.this$0.debug) {
/* 3611 */             System.out.println("Packet # " + this.currentPacketNumber);
/* 3612 */             System.out.println("  relativeTransmissionTime is " + relativeTransmissionTime);
/*      */             
/* 3614 */             System.out.println("$$$ relativeTransmissionTime is in timescale " + this.trakInfo.mediaTimeScale);
/*      */ 
/*      */             
/* 3617 */             System.out.println("  rtpSequenceNumber is " + rtpSequenceNumber);
/* 3618 */             System.out.println("  entriesInDataTable is " + entriesInDataTable);
/*      */           } 
/*      */           
/* 3621 */           for (int j = 0; j < entriesInDataTable; j++) {
/* 3622 */             int dataBlockSource = this.parser.readByte(this.this$0.stream);
/* 3623 */             remainingHintSampleSize--;
/* 3624 */             if (this.this$0.debug1) {
/* 3625 */               System.out.println("    dataBlockSource is " + dataBlockSource);
/*      */             }
/*      */             
/* 3628 */             if (dataBlockSource == 1) {
/* 3629 */               int length = this.parser.readByte(this.this$0.stream);
/*      */ 
/*      */               
/* 3632 */               remainingHintSampleSize--;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 3637 */               this.parser.readBytes(this.this$0.stream, arrayOfByte, rtpOffset, length);
/* 3638 */               rtpOffset += length;
/* 3639 */               this.parser.skip(this.this$0.stream, 14 - length);
/* 3640 */               remainingHintSampleSize -= 14;
/* 3641 */             } else if (dataBlockSource == 2) {
/* 3642 */               QuicktimeParser.TrakList trakList; int trackRefIndex = this.parser.readByte(this.this$0.stream);
/* 3643 */               if (this.this$0.debug1) {
/* 3644 */                 System.out.println("     video: trackRefIndex is " + trackRefIndex);
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 3650 */               if (trackRefIndex > 0) {
/* 3651 */                 System.err.println("     Currently we don't support hint tracks that refer to multiple media tracks");
/* 3652 */                 buffer.setDiscard(true);
/*      */                 
/*      */                 return;
/*      */               } 
/* 3656 */               int numBytesToCopy = this.parser.readShort(this.this$0.stream);
/* 3657 */               int sampleNumber = this.parser.readInt(this.this$0.stream);
/* 3658 */               int byteOffset = this.parser.readInt(this.this$0.stream);
/* 3659 */               int bytesPerCompresionBlock = this.parser.readShort(this.this$0.stream);
/* 3660 */               int samplesPerCompresionBlock = this.parser.readShort(this.this$0.stream);
/*      */               
/* 3662 */               if (this.this$0.debug1) {
/* 3663 */                 System.out.println("     sample Number is " + sampleNumber);
/* 3664 */                 System.out.println("     numBytesToCopy is " + numBytesToCopy);
/* 3665 */                 System.out.println("     byteOffset is " + byteOffset);
/* 3666 */                 System.out.println("     bytesPerCompresionBlock is " + bytesPerCompresionBlock);
/* 3667 */                 System.out.println("     samplesPerCompresionBlock is " + samplesPerCompresionBlock);
/*      */               } 
/* 3669 */               remainingHintSampleSize -= 15;
/* 3670 */               long saveCurrentPos = this.parser.getLocation(this.this$0.stream);
/*      */ 
/*      */ 
/*      */               
/* 3674 */               if (trackRefIndex == 0) {
/* 3675 */                 trakList = this.sampleTrakInfo;
/*      */ 
/*      */               
/*      */               }
/*      */               else {
/*      */ 
/*      */                 
/* 3682 */                 trakList = this.trakInfo;
/*      */               } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 3691 */               long sampleOffset = trakList.sampleOffsetTable[sampleNumber - 1];
/*      */ 
/*      */               
/* 3694 */               sampleOffset += byteOffset;
/*      */ 
/*      */               
/* 3697 */               long l1 = this.this$0.seekableStream.seek(sampleOffset);
/* 3698 */               if (l1 == -2L) {
/* 3699 */                 buffer.setDiscard(true);
/* 3700 */                 this.offsetToStartOfPacketInfo = -1L;
/*      */                 
/*      */                 return;
/*      */               } 
/* 3704 */               if (this.this$0.debug1) {
/* 3705 */                 System.out.println("     read " + numBytesToCopy + " bytes from offset " + rtpOffset);
/*      */               }
/* 3707 */               this.parser.readBytes(this.this$0.stream, arrayOfByte, rtpOffset, numBytesToCopy);
/* 3708 */               rtpOffset += numBytesToCopy;
/*      */ 
/*      */               
/* 3711 */               l1 = this.this$0.seekableStream.seek(saveCurrentPos);
/* 3712 */               if (l1 == -2L) {
/* 3713 */                 buffer.setDiscard(true);
/* 3714 */                 this.offsetToStartOfPacketInfo = -1L;
/*      */ 
/*      */ 
/*      */                 
/*      */                 return;
/*      */               } 
/*      */             } else {
/* 3721 */               buffer.setDiscard(true);
/* 3722 */               this.offsetToStartOfPacketInfo = -1L;
/*      */               return;
/*      */             } 
/*      */           } 
/* 3726 */           actualBytesRead = rtpOffset;
/* 3727 */           if (this.this$0.debug1) {
/* 3728 */             System.out.println("Actual size of packet sent " + rtpOffset);
/*      */           }
/* 3730 */           rtpOffset = 0;
/*      */ 
/*      */ 
/*      */           
/* 3734 */           this.offsetToStartOfPacketInfo = this.parser.getLocation(this.this$0.stream);
/*      */           
/* 3736 */           if (actualBytesRead == -2) {
/* 3737 */             buffer.setDiscard(true);
/*      */             return;
/*      */           } 
/*      */         } 
/* 3741 */         buffer.setLength(actualBytesRead);
/*      */         
/* 3743 */         if (rtpMarkerSet) {
/* 3744 */           if (this.this$0.debug)
/* 3745 */             System.out.println("rtpMarkerSet: true"); 
/* 3746 */           buffer.setFlags(buffer.getFlags() | 0x800);
/*      */         } else {
/* 3748 */           if (this.this$0.debug)
/* 3749 */             System.out.println("rtpMarkerSet: false"); 
/* 3750 */           buffer.setFlags(buffer.getFlags() & 0xFFFFF7FF);
/*      */         } 
/* 3752 */         buffer.setSequenceNumber(rtpSequenceNumber);
/*      */ 
/*      */         
/* 3755 */         QuicktimeParser.TimeAndDuration td = this.trakInfo.index2TimeAndDuration(this.useSampleIndex);
/* 3756 */         double startTime = td.startTime;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3775 */         long timeStamp = (long)(startTime * 1.0E9D);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3780 */         buffer.setTimeStamp(timeStamp);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3789 */         buffer.setDuration((long)(td.duration * 1.0E9D));
/*      */       } catch (IOException e) {
/*      */         
/* 3792 */         buffer.setLength(0);
/* 3793 */         buffer.setEOM(true);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3799 */       synchronized (this) {
/* 3800 */         if (this.sampleIndex != this.useSampleIndex) {
/* 3801 */           this.currentPacketNumber = 0;
/* 3802 */           this.numPacketsInSample = -1;
/* 3803 */           this.offsetToStartOfPacketInfo = -1L;
/* 3804 */           rtpOffset = 0;
/*      */         }
/*      */         else {
/*      */           
/* 3808 */           this.currentPacketNumber++;
/*      */ 
/*      */ 
/*      */           
/* 3812 */           if (this.currentPacketNumber >= this.numPacketsInSample) {
/* 3813 */             this.sampleIndex++;
/* 3814 */             this.currentPacketNumber = 0;
/* 3815 */             this.numPacketsInSample = -1;
/* 3816 */             this.offsetToStartOfPacketInfo = -1L;
/* 3817 */             rtpOffset = 0;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } }
/*      */   private class TimeAndDuration { double startTime; double duration;
/*      */     private final QuicktimeParser this$0;
/*      */     
/*      */     private TimeAndDuration(QuicktimeParser this$0) {
/* 3826 */       QuicktimeParser.this = QuicktimeParser.this;
/*      */     } }
/*      */ 
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\parser\video\QuicktimeParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */