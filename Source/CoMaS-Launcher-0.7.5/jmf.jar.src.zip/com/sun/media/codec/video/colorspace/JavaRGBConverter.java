/*     */ package com.sun.media.codec.video.colorspace;
/*     */ 
/*     */ import javax.media.Format;
/*     */ import javax.media.format.RGBFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaRGBConverter
/*     */   extends RGBConverter
/*     */ {
/*     */   private static final String PLUGIN_NAME = "RGB Converter";
/*     */   
/*     */   public JavaRGBConverter() {
/*  20 */     this.inputFormats = new Format[] { (Format)new RGBFormat() };
/*  21 */     this.outputFormats = new Format[] { (Format)new RGBFormat() };
/*     */   }
/*     */   
/*     */   public String getName() {
/*  25 */     return "RGB Converter";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void componentToComponent(Object inData, int inPS, int inLS, int inBPP, int inRed, int inGreen, int inBlue, boolean inPacked, int inEndian, Object outData, int outPS, int outLS, int outBPP, int outRed, int outGreen, int outBlue, boolean outPacked, int outEndian, int width, int height, boolean flip) {
/*  35 */     int srcPtr = 0;
/*  36 */     int dstPtr = 0;
/*  37 */     int srcInc = inLS - width * inPS;
/*  38 */     int dstInc = outLS - width * outPS;
/*     */     
/*  40 */     if (flip) {
/*     */       
/*  42 */       dstPtr = outLS * (height - 1);
/*  43 */       dstInc = -(3 * outLS - width * outPS);
/*     */     } 
/*     */     
/*  46 */     if (inPacked && outPacked) {
/*  47 */       int[] in = (int[])inData;
/*  48 */       int[] out = (int[])outData;
/*  49 */       if (inRed == outRed && inGreen == outGreen && inBlue == outBlue) {
/*  50 */         for (int y = 0; y < height; y++) {
/*  51 */           for (int x = 0; x < width; x++) {
/*  52 */             out[dstPtr] = in[srcPtr];
/*  53 */             srcPtr += inPS;
/*  54 */             dstPtr += outPS;
/*     */           } 
/*  56 */           srcPtr += srcInc;
/*  57 */           dstPtr += dstInc;
/*     */         } 
/*     */       } else {
/*  60 */         int inrs = getShift(inRed);
/*  61 */         int ings = getShift(inGreen);
/*  62 */         int inbs = getShift(inBlue);
/*  63 */         int outrs = getShift(outRed);
/*  64 */         int outgs = getShift(outGreen);
/*  65 */         int outbs = getShift(outBlue);
/*  66 */         for (byte b = 0; b < height; b++) {
/*  67 */           for (byte b1 = 0; b1 < width; b1++) {
/*  68 */             int inPixel = in[srcPtr];
/*  69 */             int outPixel = (inPixel >> inrs & 0xFF) << outrs | (inPixel >> ings & 0xFF) << outgs | (inPixel >> inbs & 0xFF) << outbs;
/*     */ 
/*     */             
/*  72 */             out[dstPtr] = outPixel;
/*  73 */             srcPtr += inPS;
/*  74 */             dstPtr += outPS;
/*     */           } 
/*  76 */           srcPtr += srcInc;
/*  77 */           dstPtr += dstInc;
/*     */         } 
/*     */       } 
/*  80 */     } else if (inPacked && !outPacked) {
/*  81 */       int[] in = (int[])inData;
/*  82 */       byte[] out = (byte[])outData;
/*  83 */       int redShift = getShift(inRed);
/*  84 */       int greenShift = getShift(inGreen);
/*  85 */       int blueShift = getShift(inBlue);
/*  86 */       for (byte b = 0; b < height; b++) {
/*  87 */         for (byte b1 = 0; b1 < width; b1++) {
/*  88 */           int pixel = in[srcPtr];
/*  89 */           byte red = (byte)(pixel >> redShift & 0xFF);
/*  90 */           byte green = (byte)(pixel >> greenShift & 0xFF);
/*  91 */           byte blue = (byte)(pixel >> blueShift & 0xFF);
/*  92 */           out[dstPtr + outRed - 1] = red;
/*  93 */           out[dstPtr + outGreen - 1] = green;
/*  94 */           out[dstPtr + outBlue - 1] = blue;
/*  95 */           srcPtr += inPS;
/*  96 */           dstPtr += outPS;
/*     */         } 
/*  98 */         srcPtr += srcInc;
/*  99 */         dstPtr += dstInc;
/*     */       } 
/* 101 */     } else if (!inPacked && outPacked) {
/* 102 */       byte[] in = (byte[])inData;
/* 103 */       int[] out = (int[])outData;
/* 104 */       int redShift = getShift(outRed);
/* 105 */       int greenShift = getShift(outGreen);
/* 106 */       int blueShift = getShift(outBlue);
/* 107 */       for (byte b = 0; b < height; b++) {
/* 108 */         for (byte b1 = 0; b1 < width; b1++) {
/* 109 */           byte red = in[srcPtr + inRed - 1];
/* 110 */           byte green = in[srcPtr + inGreen - 1];
/* 111 */           byte blue = in[srcPtr + inBlue - 1];
/* 112 */           int pixel = (red & 0xFF) << redShift | (green & 0xFF) << greenShift | (blue & 0xFF) << blueShift;
/*     */ 
/*     */           
/* 115 */           out[dstPtr] = pixel;
/* 116 */           srcPtr += inPS;
/* 117 */           dstPtr += outPS;
/*     */         } 
/* 119 */         srcPtr += srcInc;
/* 120 */         dstPtr += dstInc;
/*     */       } 
/* 122 */     } else if (!inPacked && !outPacked) {
/* 123 */       byte[] in = (byte[])inData;
/* 124 */       byte[] out = (byte[])outData;
/* 125 */       for (byte b = 0; b < height; b++) {
/* 126 */         for (byte b1 = 0; b1 < width; b1++) {
/* 127 */           out[dstPtr + outRed - 1] = in[srcPtr + inRed - 1];
/* 128 */           out[dstPtr + outGreen - 1] = in[srcPtr + inGreen - 1];
/* 129 */           out[dstPtr + outBlue - 1] = in[srcPtr + inBlue - 1];
/* 130 */           srcPtr += inPS;
/* 131 */           dstPtr += outPS;
/*     */         } 
/* 133 */         srcPtr += srcInc;
/* 134 */         dstPtr += dstInc;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void componentToSixteen(Object inData, int inPS, int inLS, int inBPP, int inRed, int inGreen, int inBlue, boolean inPacked, int inEndian, Object outData, int outPS, int outLS, int outBPP, int outRed, int outGreen, int outBlue, boolean outPacked, int outEndian, int width, int height, boolean flip) {
/* 146 */     int srcPtr = 0;
/* 147 */     int dstPtr = 0;
/* 148 */     int srcInc = inLS - width * inPS;
/* 149 */     int dstInc = outLS - width * outPS;
/*     */     
/* 151 */     int outrs = getShift(outRed) - 3;
/* 152 */     int outgs = getShift(outGreen) - ((outGreen == 2016) ? 2 : 3);
/* 153 */     int inrs = getShift(inRed);
/* 154 */     int ings = getShift(inGreen);
/* 155 */     int inbs = getShift(inBlue);
/* 156 */     int outfs = 0;
/* 157 */     int outss = 0;
/*     */     
/* 159 */     if (!outPacked) {
/* 160 */       if (outEndian == 0) {
/* 161 */         outfs = 8;
/* 162 */         outss = 0;
/*     */       } else {
/* 164 */         outfs = 0;
/* 165 */         outss = 8;
/*     */       } 
/*     */     }
/*     */     
/* 169 */     if (flip) {
/*     */       
/* 171 */       dstPtr = outLS * (height - 1);
/* 172 */       dstInc = -(3 * outLS - width * outPS);
/*     */     } 
/*     */     
/* 175 */     if (inPacked && outPacked) {
/* 176 */       int[] in = (int[])inData;
/* 177 */       short[] out = (short[])outData;
/*     */       
/* 179 */       for (int y = 0; y < height; y++) {
/* 180 */         for (int x = 0; x < width; x++) {
/* 181 */           int pixel = in[srcPtr];
/* 182 */           out[dstPtr] = (short)(pixel >> inrs << outrs & outRed | pixel >> ings << outgs & outGreen | (pixel >> inbs & 0xFF) >> 3);
/*     */ 
/*     */           
/* 185 */           srcPtr += inPS;
/* 186 */           dstPtr += outPS;
/*     */         } 
/* 188 */         srcPtr += srcInc;
/* 189 */         dstPtr += dstInc;
/*     */       } 
/* 191 */     } else if (!inPacked && outPacked) {
/* 192 */       byte[] in = (byte[])inData;
/* 193 */       short[] out = (short[])outData;
/*     */       
/* 195 */       for (byte b = 0; b < height; b++) {
/* 196 */         for (byte b1 = 0; b1 < width; b1++) {
/* 197 */           out[dstPtr] = (short)(in[srcPtr + inRed - 1] << outrs & outRed | in[srcPtr + inGreen - 1] << outgs & outGreen | (in[srcPtr + inBlue - 1] & 0xFF) >> 3);
/*     */ 
/*     */ 
/*     */           
/* 201 */           srcPtr += inPS;
/* 202 */           dstPtr += outPS;
/*     */         } 
/* 204 */         srcPtr += srcInc;
/* 205 */         dstPtr += dstInc;
/*     */       } 
/* 207 */     } else if (!inPacked && !outPacked) {
/* 208 */       byte[] in = (byte[])inData;
/* 209 */       byte[] out = (byte[])outData;
/*     */       
/* 211 */       for (byte b = 0; b < height; b++) {
/* 212 */         for (byte b1 = 0; b1 < width; b1++) {
/* 213 */           int pixel = in[srcPtr + inRed - 1] << outrs & outRed | in[srcPtr + inGreen - 1] << outgs & outGreen | (in[srcPtr + inBlue - 1] & 0xFF) >> 3;
/*     */ 
/*     */           
/* 216 */           out[dstPtr] = (byte)(pixel >> outfs);
/* 217 */           out[dstPtr + 1] = (byte)(pixel >> outss);
/* 218 */           srcPtr += inPS;
/* 219 */           dstPtr += outPS;
/*     */         } 
/* 221 */         srcPtr += srcInc;
/* 222 */         dstPtr += dstInc;
/*     */       } 
/*     */     } else {
/* 225 */       int[] in = (int[])inData;
/* 226 */       byte[] out = (byte[])outData;
/*     */       
/* 228 */       for (byte b = 0; b < height; b++) {
/* 229 */         for (byte b1 = 0; b1 < width; b1++) {
/* 230 */           int pixel = in[srcPtr];
/* 231 */           pixel = pixel >> inrs << outrs & outRed | pixel >> ings << outgs & outGreen | (pixel >> inbs & 0xFF) >> 3;
/*     */ 
/*     */           
/* 234 */           out[dstPtr] = (byte)(pixel >> outfs);
/* 235 */           out[dstPtr + 1] = (byte)(pixel >> outss);
/* 236 */           srcPtr += inPS;
/* 237 */           dstPtr += outPS;
/*     */         } 
/* 239 */         srcPtr += srcInc;
/* 240 */         dstPtr += dstInc;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sixteenToComponent(Object inData, int inPS, int inLS, int inBPP, int inRed, int inGreen, int inBlue, boolean inPacked, int inEndian, Object outData, int outPS, int outLS, int outBPP, int outRed, int outGreen, int outBlue, boolean outPacked, int outEndian, int width, int height, boolean flip) {
/* 252 */     int srcPtr = 0;
/* 253 */     int dstPtr = 0;
/* 254 */     int srcInc = inLS - width * inPS;
/* 255 */     int dstInc = outLS - width * outPS;
/*     */     
/* 257 */     if (flip) {
/*     */       
/* 259 */       dstPtr = outLS * (height - 1);
/* 260 */       dstInc = -(3 * outLS - width * outPS);
/*     */     } 
/*     */     
/* 263 */     int inrs = getShift(inRed) - 3;
/* 264 */     int ings = getShift(inGreen) - ((inGreen == 2016) ? 2 : 3);
/* 265 */     int outrs = getShift(outRed);
/* 266 */     int outgs = getShift(outGreen);
/* 267 */     int outbs = getShift(outBlue);
/*     */     
/* 269 */     if (inPacked && outPacked) {
/* 270 */       short[] in = (short[])inData;
/* 271 */       int[] out = (int[])outData;
/*     */       
/* 273 */       for (int y = 0; y < height; y++) {
/* 274 */         for (int x = 0; x < width; x++) {
/* 275 */           int pixel = in[srcPtr] & 0xFFFF;
/* 276 */           int outpixel = (pixel & inRed) >> inrs << outrs | (pixel & inGreen) >> ings << outgs | (pixel & inBlue) << 3 << outbs;
/*     */ 
/*     */           
/* 279 */           out[dstPtr] = outpixel;
/* 280 */           srcPtr += inPS;
/* 281 */           dstPtr += outPS;
/*     */         } 
/* 283 */         srcPtr += srcInc;
/* 284 */         dstPtr += dstInc;
/*     */       } 
/* 286 */     } else if (!inPacked && outPacked) {
/* 287 */       byte b2, b3; byte[] in = (byte[])inData;
/* 288 */       int[] out = (int[])outData;
/*     */ 
/*     */       
/* 291 */       if (inEndian == 0) {
/* 292 */         b2 = 8;
/* 293 */         b3 = 0;
/*     */       } else {
/* 295 */         b2 = 0;
/* 296 */         b3 = 8;
/*     */       } 
/*     */       
/* 299 */       for (byte b1 = 0; b1 < height; b1++) {
/* 300 */         for (byte b = 0; b < width; b++) {
/* 301 */           int pixel = (in[srcPtr] & 0xFF) << b2 | (in[srcPtr + 1] & 0xFF) << b3;
/*     */           
/* 303 */           int outpixel = (pixel & inRed) >> inrs << outrs | (pixel & inGreen) >> ings << outgs | (pixel & inBlue) << 3 << outbs;
/*     */ 
/*     */           
/* 306 */           out[dstPtr] = outpixel;
/* 307 */           srcPtr += inPS;
/* 308 */           dstPtr += outPS;
/*     */         } 
/* 310 */         srcPtr += srcInc;
/* 311 */         dstPtr += dstInc;
/*     */       } 
/* 313 */     } else if (inPacked && !outPacked) {
/* 314 */       short[] in = (short[])inData;
/* 315 */       byte[] out = (byte[])outData;
/*     */       
/* 317 */       for (byte b = 0; b < height; b++) {
/* 318 */         for (byte b1 = 0; b1 < width; b1++) {
/* 319 */           int pixel = in[srcPtr];
/* 320 */           out[dstPtr + outRed - 1] = (byte)((pixel & inRed) >> inrs);
/* 321 */           out[dstPtr + outGreen - 1] = (byte)((pixel & inGreen) >> ings);
/* 322 */           out[dstPtr + outBlue - 1] = (byte)((pixel & inBlue) << 3);
/* 323 */           srcPtr += inPS;
/* 324 */           dstPtr += outPS;
/*     */         } 
/* 326 */         srcPtr += srcInc;
/* 327 */         dstPtr += dstInc;
/*     */       } 
/*     */     } else {
/* 330 */       byte b2, b3; byte[] in = (byte[])inData;
/* 331 */       byte[] out = (byte[])outData;
/*     */ 
/*     */       
/* 334 */       if (inEndian == 0) {
/* 335 */         b2 = 8;
/* 336 */         b3 = 0;
/*     */       } else {
/* 338 */         b2 = 0;
/* 339 */         b3 = 8;
/*     */       } 
/*     */       
/* 342 */       for (byte b1 = 0; b1 < height; b1++) {
/* 343 */         for (byte b = 0; b < width; b++) {
/* 344 */           int pixel = (in[srcPtr] & 0xFF) << b2 | (in[srcPtr + 1] & 0xFF) << b3;
/*     */           
/* 346 */           out[dstPtr + outRed - 1] = (byte)((pixel & inRed) >> inrs);
/* 347 */           out[dstPtr + outGreen - 1] = (byte)((pixel & inGreen) >> ings);
/* 348 */           out[dstPtr + outBlue - 1] = (byte)((pixel & inBlue) << 3);
/* 349 */           srcPtr += inPS;
/* 350 */           dstPtr += outPS;
/*     */         } 
/* 352 */         srcPtr += srcInc;
/* 353 */         dstPtr += dstInc;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sixteenToSixteen(Object inData, int inPS, int inLS, int inBPP, int inRed, int inGreen, int inBlue, boolean inPacked, int inEndian, Object outData, int outPS, int outLS, int outBPP, int outRed, int outGreen, int outBlue, boolean outPacked, int outEndian, int width, int height, boolean flip) {
/* 365 */     int srcPtr = 0;
/* 366 */     int dstPtr = 0;
/* 367 */     int srcInc = inLS - width * inPS;
/* 368 */     int dstInc = outLS - width * outPS;
/*     */     
/* 370 */     int shift = 0;
/* 371 */     int infs = 0;
/* 372 */     int inss = 0;
/* 373 */     int outfs = 0;
/* 374 */     int outss = 0;
/*     */     
/* 376 */     if (flip) {
/*     */       
/* 378 */       dstPtr = outLS * (height - 1);
/* 379 */       dstInc = -(3 * outLS - width * outPS);
/*     */     } 
/*     */     
/* 382 */     if (!inPacked) {
/* 383 */       if (inEndian == 0) {
/* 384 */         infs = 8;
/* 385 */         inss = 0;
/*     */       } else {
/* 387 */         infs = 0;
/* 388 */         inss = 8;
/*     */       } 
/*     */     }
/*     */     
/* 392 */     if (!outPacked) {
/* 393 */       if (outEndian == 0) {
/* 394 */         outfs = 8;
/* 395 */         outss = 0;
/*     */       } else {
/* 397 */         outfs = 0;
/* 398 */         outss = 8;
/*     */       } 
/*     */     }
/*     */     
/* 402 */     if (inRed != outRed || inGreen != outGreen) {
/* 403 */       if (inRed > outRed) {
/* 404 */         shift = 1;
/*     */       } else {
/* 406 */         shift = -1;
/*     */       } 
/*     */     }
/* 409 */     if (inPacked && outPacked) {
/* 410 */       short[] in = (short[])inData;
/* 411 */       short[] out = (short[])outData;
/*     */       
/* 413 */       if (shift == 0) {
/* 414 */         for (int y = 0; y < height; y++) {
/* 415 */           for (int x = 0; x < width; x++) {
/* 416 */             out[dstPtr] = in[srcPtr];
/* 417 */             srcPtr += inPS;
/* 418 */             dstPtr += outPS;
/*     */           } 
/* 420 */           srcPtr += srcInc;
/* 421 */           dstPtr += dstInc;
/*     */         } 
/* 423 */       } else if (shift == 1) {
/* 424 */         for (byte b = 0; b < height; b++) {
/* 425 */           for (byte b1 = 0; b1 < width; b1++) {
/* 426 */             int pixel = in[srcPtr];
/* 427 */             out[dstPtr] = (short)(pixel >> 1 & (outGreen | outRed) | pixel & outBlue);
/*     */             
/* 429 */             srcPtr += inPS;
/* 430 */             dstPtr += outPS;
/*     */           } 
/* 432 */           srcPtr += srcInc;
/* 433 */           dstPtr += dstInc;
/*     */         } 
/*     */       } else {
/* 436 */         for (byte b = 0; b < height; b++) {
/* 437 */           for (byte b1 = 0; b1 < width; b1++) {
/* 438 */             int pixel = in[srcPtr];
/* 439 */             out[dstPtr] = (short)((pixel & (inGreen | inRed)) << 1 | pixel & outBlue);
/*     */             
/* 441 */             srcPtr += inPS;
/* 442 */             dstPtr += outPS;
/*     */           } 
/* 444 */           srcPtr += srcInc;
/* 445 */           dstPtr += dstInc;
/*     */         } 
/*     */       } 
/* 448 */     } else if (!inPacked && outPacked) {
/* 449 */       byte[] in = (byte[])inData;
/* 450 */       short[] out = (short[])outData;
/*     */       
/* 452 */       if (shift == 0) {
/* 453 */         for (byte b = 0; b < height; b++) {
/* 454 */           for (byte b1 = 0; b1 < width; b1++) {
/* 455 */             int pixel = (in[srcPtr] & 0xFF) << infs | (in[srcPtr + 1] & 0xFF) << inss;
/*     */             
/* 457 */             out[dstPtr] = (short)pixel;
/* 458 */             srcPtr += inPS;
/* 459 */             dstPtr += outPS;
/*     */           } 
/* 461 */           srcPtr += srcInc;
/* 462 */           dstPtr += dstInc;
/*     */         } 
/* 464 */       } else if (shift == 1) {
/* 465 */         for (byte b = 0; b < height; b++) {
/* 466 */           for (byte b1 = 0; b1 < width; b1++) {
/* 467 */             int pixel = (in[srcPtr] & 0xFF) << infs | (in[srcPtr + 1] & 0xFF) << inss;
/*     */             
/* 469 */             out[dstPtr] = (short)(pixel >> 1 & (outGreen | outRed) | pixel & outBlue);
/*     */             
/* 471 */             srcPtr += inPS;
/* 472 */             dstPtr += outPS;
/*     */           } 
/* 474 */           srcPtr += srcInc;
/* 475 */           dstPtr += dstInc;
/*     */         } 
/*     */       } else {
/* 478 */         for (byte b = 0; b < height; b++) {
/* 479 */           for (byte b1 = 0; b1 < width; b1++) {
/* 480 */             int pixel = (in[srcPtr] & 0xFF) << infs | (in[srcPtr + 1] & 0xFF) << inss;
/*     */             
/* 482 */             out[dstPtr] = (short)((pixel & (inGreen | inRed)) << 1 | pixel & outBlue);
/*     */             
/* 484 */             srcPtr += inPS;
/* 485 */             dstPtr += outPS;
/*     */           } 
/* 487 */           srcPtr += srcInc;
/* 488 */           dstPtr += dstInc;
/*     */         } 
/*     */       } 
/* 491 */     } else if (!inPacked && !outPacked) {
/* 492 */       byte[] in = (byte[])inData;
/* 493 */       byte[] out = (byte[])outData;
/*     */       
/* 495 */       if (shift == 0) {
/* 496 */         if (inEndian == outEndian) {
/* 497 */           for (byte b = 0; b < height; b++) {
/* 498 */             for (byte b1 = 0; b1 < width; b1++) {
/* 499 */               out[dstPtr] = in[srcPtr];
/* 500 */               out[dstPtr + 1] = in[srcPtr + 1];
/* 501 */               srcPtr += inPS;
/* 502 */               dstPtr += outPS;
/*     */             } 
/* 504 */             srcPtr += srcInc;
/* 505 */             dstPtr += dstInc;
/*     */           } 
/*     */         } else {
/* 508 */           for (byte b = 0; b < height; b++) {
/* 509 */             for (byte b1 = 0; b1 < width; b1++) {
/* 510 */               int pixel = (in[srcPtr] & 0xFF) << infs | (in[srcPtr + 1] & 0xFF) << inss;
/*     */               
/* 512 */               out[dstPtr] = (byte)(pixel >> outfs);
/* 513 */               out[dstPtr + 1] = (byte)(pixel >> outss);
/* 514 */               srcPtr += inPS;
/* 515 */               dstPtr += outPS;
/*     */             } 
/* 517 */             srcPtr += srcInc;
/* 518 */             dstPtr += dstInc;
/*     */           } 
/*     */         } 
/* 521 */       } else if (shift == 1) {
/* 522 */         for (byte b = 0; b < height; b++) {
/* 523 */           for (byte b1 = 0; b1 < width; b1++) {
/* 524 */             int pixel = (in[srcPtr] & 0xFF) << infs | (in[srcPtr + 1] & 0xFF) << inss;
/*     */             
/* 526 */             pixel = pixel >> 1 & (outGreen | outRed) | pixel & outBlue;
/*     */             
/* 528 */             out[dstPtr] = (byte)(pixel >> outfs);
/* 529 */             out[dstPtr + 1] = (byte)(pixel >> outss);
/* 530 */             srcPtr += inPS;
/* 531 */             dstPtr += outPS;
/*     */           } 
/* 533 */           srcPtr += srcInc;
/* 534 */           dstPtr += dstInc;
/*     */         } 
/*     */       } else {
/* 537 */         for (byte b = 0; b < height; b++) {
/* 538 */           for (byte b1 = 0; b1 < width; b1++) {
/* 539 */             int pixel = (in[srcPtr] & 0xFF) << infs | (in[srcPtr + 1] & 0xFF) << inss;
/*     */             
/* 541 */             pixel = pixel >> 1 & (outGreen | outRed) | pixel & outBlue;
/*     */             
/* 543 */             out[dstPtr] = (byte)(pixel >> outfs);
/* 544 */             out[dstPtr + 1] = (byte)(pixel >> outss);
/* 545 */             srcPtr += inPS;
/* 546 */             dstPtr += outPS;
/*     */           } 
/* 548 */           srcPtr += srcInc;
/* 549 */           dstPtr += dstInc;
/*     */         } 
/*     */       } 
/*     */     } else {
/* 553 */       short[] in = (short[])inData;
/* 554 */       byte[] out = (byte[])outData;
/*     */       
/* 556 */       if (shift == 0) {
/* 557 */         for (byte b = 0; b < height; b++) {
/* 558 */           for (byte b1 = 0; b1 < width; b1++) {
/* 559 */             int pixel = in[srcPtr];
/* 560 */             out[dstPtr] = (byte)(pixel >> outfs);
/* 561 */             out[dstPtr + 1] = (byte)(pixel >> outss);
/* 562 */             srcPtr += inPS;
/* 563 */             dstPtr += outPS;
/*     */           } 
/* 565 */           srcPtr += srcInc;
/* 566 */           dstPtr += dstInc;
/*     */         } 
/* 568 */       } else if (shift == 1) {
/* 569 */         for (byte b = 0; b < height; b++) {
/* 570 */           for (byte b1 = 0; b1 < width; b1++) {
/* 571 */             int pixel = in[srcPtr];
/* 572 */             pixel = pixel >> 1 & (outGreen | outRed) | pixel & outBlue;
/*     */             
/* 574 */             out[dstPtr] = (byte)(pixel >> outfs);
/* 575 */             out[dstPtr + 1] = (byte)(pixel >> outss);
/* 576 */             srcPtr += inPS;
/* 577 */             dstPtr += outPS;
/*     */           } 
/* 579 */           srcPtr += srcInc;
/* 580 */           dstPtr += dstInc;
/*     */         } 
/*     */       } else {
/* 583 */         for (byte b = 0; b < height; b++) {
/* 584 */           for (byte b1 = 0; b1 < width; b1++) {
/* 585 */             int pixel = in[srcPtr];
/* 586 */             pixel = pixel >> 1 & (outGreen | outRed) | pixel & outBlue;
/*     */             
/* 588 */             out[dstPtr] = (byte)(pixel >> outfs);
/* 589 */             out[dstPtr + 1] = (byte)(pixel >> outss);
/* 590 */             srcPtr += inPS;
/* 591 */             dstPtr += outPS;
/*     */           } 
/* 593 */           srcPtr += srcInc;
/* 594 */           dstPtr += dstInc;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\codec\video\colorspace\JavaRGBConverter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */