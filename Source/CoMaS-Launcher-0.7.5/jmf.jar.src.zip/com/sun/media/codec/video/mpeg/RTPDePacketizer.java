/*     */ package com.sun.media.codec.video.mpeg;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Vector;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RTPDePacketizer
/*     */ {
/*  44 */   public static float[] RATE_TABLE = new float[] { 0.0F, 23.976F, 24.0F, 25.0F, 29.97F, 30.0F, 50.0F, 59.94F, 60.0F };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   private static char[] hexChar = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   private long discardtimestamp = -1L;
/*  55 */   private MPEGFrame currentframe = null;
/*     */   private boolean newframe = true;
/*     */   private boolean gotSequenceHeader = false;
/*     */   private boolean sequenceSent = false;
/*  59 */   private byte[] sequenceHeader = null;
/*     */   private boolean gopset = false;
/*  61 */   private int closedGop = 0;
/*  62 */   private int ref_pic_temp = -1;
/*  63 */   private int dep_pic_temp = -1;
/*  64 */   private int sequenceNumber = 0;
/*  65 */   private int width = 352;
/*  66 */   private int height = 240;
/*  67 */   private float frameRate = -1.0F;
/*  68 */   private VideoFormat outFormat = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean allowHeadless = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fullFrameOnly = true;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean droppedPFrame = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean droppedIFrame = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean capture = false;
/*     */ 
/*     */ 
/*     */   
/*  93 */   private OutputStream captureFile = null;
/*     */   
/*     */   private static final boolean debug = false;
/*     */   
/*     */   RTPDePacketizer() {
/*  98 */     if (this.capture) {
/*     */       try {
/* 100 */         this.captureFile = new BufferedOutputStream(new FileOutputStream("/tmp/rtpstream.mpg"));
/*     */       } catch (IOException ioe) {
/*     */         
/* 103 */         System.err.println("RTPDePacketizer: unable to open file " + ioe);
/*     */         
/* 105 */         this.capture = false;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void finalize() {
/* 117 */     if (this.capture) {
/*     */       try {
/* 119 */         this.captureFile.flush();
/* 120 */         this.captureFile.close();
/* 121 */         System.err.println("RTPDePacketizer: closed file");
/*     */       } catch (IOException ioe) {
/* 123 */         System.err.println("RTPDePacketizer: unable to close file " + ioe);
/*     */         
/* 125 */         this.capture = false;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int process(Buffer inBuffer, Buffer outBuffer) {
/* 145 */     if (inBuffer.getTimeStamp() == this.discardtimestamp && this.discardtimestamp != -1L)
/*     */     {
/* 147 */       return 4;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 154 */     if (!this.newframe && this.currentframe != null && inBuffer.getTimeStamp() != this.currentframe.rtptimestamp) {
/*     */       
/* 156 */       if (this.allowHeadless || firstPacket(inBuffer)) {
/* 157 */         boolean haveframe = false;
/* 158 */         if (this.fullFrameOnly) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 163 */           dropFrame();
/*     */         } else {
/* 165 */           haveframe = constructFrame(outBuffer);
/*     */         } 
/* 167 */         this.currentframe = createNewFrame(inBuffer);
/* 168 */         if (haveframe) {
/* 169 */           return 0;
/*     */         }
/*     */         
/* 172 */         if ((this.currentframe.getFirst().getFlags() & 0x800) != 0)
/*     */         {
/*     */           
/* 175 */           if (constructFrame(outBuffer)) {
/* 176 */             return 0;
/*     */           }
/*     */         }
/* 179 */         return 4;
/*     */       } 
/*     */ 
/*     */       
/* 183 */       this.discardtimestamp = inBuffer.getTimeStamp();
/* 184 */       if (this.fullFrameOnly) {
/*     */ 
/*     */ 
/*     */         
/* 188 */         dropFrame();
/* 189 */         dropBufferFrame(inBuffer);
/* 190 */       } else if (compareSequenceNumbers(this.currentframe.seqno, inBuffer.getSequenceNumber()) > 0) {
/*     */ 
/*     */         
/* 193 */         if (constructFrame(outBuffer)) {
/* 194 */           return 0;
/*     */         }
/*     */       } 
/*     */       
/* 198 */       return 4;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 204 */     if (this.newframe) {
/* 205 */       if (firstPacket(inBuffer)) {
/* 206 */         this.newframe = false;
/* 207 */         this.currentframe = createNewFrame(inBuffer);
/*     */         
/* 209 */         if ((this.currentframe.getFirst().getFlags() & 0x800) != 0)
/*     */         {
/*     */           
/* 212 */           if (constructFrame(outBuffer)) {
/* 213 */             return 0;
/*     */           }
/*     */         }
/* 216 */         return 4;
/*     */       } 
/* 218 */       if (this.fullFrameOnly)
/*     */       {
/*     */ 
/*     */         
/* 222 */         dropBufferFrame(inBuffer);
/*     */       }
/* 224 */       this.discardtimestamp = inBuffer.getTimeStamp();
/* 225 */       this.newframe = true;
/* 226 */       return 4;
/*     */     } 
/*     */     
/* 229 */     int ret = addToFrame(inBuffer, outBuffer);
/* 230 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String toHex(byte[] inData, int inOffset) {
/* 235 */     String hex = new String();
/* 236 */     for (int i = 0; i < 4; i++) {
/* 237 */       hex = hex + hexChar[inData[inOffset + i] >> 4 & 0xF];
/* 238 */       hex = hex + hexChar[inData[inOffset + i] & 0xF];
/*     */     } 
/* 240 */     return hex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int addToFrame(Buffer inBuffer, Buffer outBuffer) {
/* 247 */     Buffer b = copyInto(inBuffer);
/*     */     
/* 249 */     this.currentframe.add(b);
/*     */     
/* 251 */     if ((b.getFlags() & 0x800) != 0)
/*     */     {
/* 253 */       if (constructFrame(outBuffer)) {
/* 254 */         return 0;
/*     */       }
/*     */     }
/* 257 */     return 4;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void constructGop(Buffer outBuffer) {
/* 263 */     byte[] dest = (byte[])outBuffer.getData();
/* 264 */     int outoffset = outBuffer.getLength();
/* 265 */     if (this.sequenceHeader != null) {
/* 266 */       System.arraycopy(this.sequenceHeader, 0, dest, outoffset, this.sequenceHeader.length);
/*     */       
/* 268 */       outBuffer.setLength(outBuffer.getLength() + this.sequenceHeader.length);
/* 269 */       outoffset += this.sequenceHeader.length;
/* 270 */       this.sequenceSent = true;
/*     */     } 
/* 272 */     dest[outoffset] = 0;
/* 273 */     dest[outoffset + 1] = 0;
/* 274 */     dest[outoffset + 2] = 1;
/* 275 */     dest[outoffset + 3] = -72;
/*     */ 
/*     */     
/* 278 */     dest[outoffset + 4] = Byte.MIN_VALUE;
/*     */     
/* 280 */     dest[outoffset + 5] = 8;
/*     */     
/* 282 */     dest[outoffset + 6] = 0;
/*     */     
/* 284 */     dest[outoffset + 7] = (byte)(this.closedGop | 0x20);
/*     */     
/* 286 */     outBuffer.setLength(outBuffer.getLength() + 8);
/* 287 */     this.ref_pic_temp = 0;
/* 288 */     this.dep_pic_temp = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void constructPicture(Buffer inBuffer, Buffer outBuffer) {
/* 294 */     byte[] payload = (byte[])inBuffer.getData();
/* 295 */     int offset = inBuffer.getOffset();
/* 296 */     byte[] dest = (byte[])outBuffer.getData();
/* 297 */     int outoffset = outBuffer.getLength();
/* 298 */     int next = 0;
/* 299 */     dest[outoffset] = 0;
/* 300 */     dest[outoffset + 1] = 0;
/* 301 */     dest[outoffset + 2] = 1;
/* 302 */     dest[outoffset + 3] = 0;
/*     */ 
/*     */     
/* 305 */     dest[outoffset + 4] = (byte)((payload[offset] & 0x3) << 6 | (payload[offset + 1] & 0xFC) >> 2);
/*     */ 
/*     */     
/* 308 */     int ptype = payload[offset + 2] & 0x7;
/* 309 */     int back = (payload[offset + 3] & 0xF0) >> 4;
/* 310 */     int fwd = payload[offset + 3] & 0xF;
/*     */ 
/*     */ 
/*     */     
/* 314 */     dest[outoffset + 5] = (byte)((payload[offset + 1] & 0x2) << 6 | ptype << 3);
/*     */     
/* 316 */     dest[outoffset + 6] = 0;
/* 317 */     if (ptype == 1) {
/* 318 */       dest[outoffset + 7] = 0;
/* 319 */       outBuffer.setLength(outBuffer.getLength() + 8);
/*     */     }
/*     */     else {
/*     */       
/* 323 */       next = fwd >> 1;
/* 324 */       dest[outoffset + 7] = (byte)next;
/*     */       
/* 326 */       next = (fwd & 0x1) << 7;
/* 327 */       if (ptype > 2)
/*     */       {
/*     */         
/* 330 */         next |= back << 3;
/*     */       }
/* 332 */       dest[outoffset + 8] = (byte)next;
/* 333 */       outBuffer.setLength(outBuffer.getLength() + 9);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void constructHeaders(Buffer outBuffer) {
/* 342 */     boolean havePicture = false;
/*     */     
/* 344 */     int outoffset = 0;
/* 345 */     byte[] dest = (byte[])outBuffer.getData();
/* 346 */     Buffer src = this.currentframe.data.elementAt(0);
/* 347 */     byte[] payload = (byte[])src.getData();
/* 348 */     int offset = src.getOffset();
/* 349 */     int tr = (payload[offset] & 0x3) << 8 | payload[offset + 1] & 0xFF;
/* 350 */     int type = payload[offset + 2] & 0x7;
/*     */ 
/*     */     
/* 353 */     if (src.getLength() >= 8 && (payload[offset + 2] & 0x10) == 16 && payload[offset + 4] == 0 && payload[offset + 5] == 0 && payload[offset + 6] == 1) {
/*     */ 
/*     */ 
/*     */       
/* 357 */       int startCode = payload[offset + 7] & 0xFF;
/* 358 */       if (startCode == 179) {
/*     */         
/* 360 */         this.sequenceSent = true;
/* 361 */         this.ref_pic_temp = tr;
/* 362 */         this.dep_pic_temp = -1; return;
/*     */       } 
/* 364 */       if (startCode == 184) {
/*     */         
/* 366 */         if (this.sequenceHeader != null) {
/* 367 */           System.arraycopy(this.sequenceHeader, 0, dest, outBuffer.getLength(), this.sequenceHeader.length);
/*     */ 
/*     */           
/* 370 */           outBuffer.setLength(outBuffer.getLength() + this.sequenceHeader.length);
/*     */           
/* 372 */           this.sequenceSent = true;
/*     */         } 
/* 374 */         this.ref_pic_temp = tr;
/* 375 */         this.dep_pic_temp = -1; return;
/*     */       } 
/* 377 */       if (startCode == 0)
/* 378 */         havePicture = true; 
/*     */     } 
/* 380 */     this.ref_pic_temp++;
/* 381 */     this.dep_pic_temp++;
/* 382 */     if (type < 3) {
/*     */       
/* 384 */       if (tr < this.ref_pic_temp) {
/* 385 */         constructGop(outBuffer);
/*     */       }
/* 387 */       this.ref_pic_temp = tr;
/*     */     } else {
/*     */       
/* 390 */       if (tr < this.dep_pic_temp) {
/* 391 */         constructGop(outBuffer);
/*     */       }
/* 393 */       this.dep_pic_temp = tr;
/*     */     } 
/* 395 */     if (!havePicture) {
/* 396 */       constructPicture(src, outBuffer);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void dropFrame() {
/* 402 */     Buffer src = this.currentframe.data.firstElement();
/* 403 */     dropBufferFrame(src);
/*     */   }
/*     */   
/*     */   private void dropBufferFrame(Buffer src) {
/* 407 */     int type = ((byte[])src.getData())[src.getOffset() + 2] & 0x7;
/* 408 */     if (type == 1) {
/* 409 */       this.droppedIFrame = true;
/* 410 */     } else if (type == 2) {
/* 411 */       this.droppedPFrame = true;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 418 */     this.newframe = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 424 */     this.currentframe = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean constructFrame(Buffer outBuffer) {
/* 431 */     Buffer src = this.currentframe.data.lastElement();
/* 432 */     int type = ((byte[])src.getData())[src.getOffset() + 2] & 0x7;
/* 433 */     if (this.fullFrameOnly) {
/* 434 */       if (type >= 2 && (this.droppedIFrame || this.droppedPFrame)) {
/*     */ 
/*     */ 
/*     */         
/* 438 */         dropFrame();
/* 439 */         return false;
/* 440 */       }  if (type == 1) {
/* 441 */         this.droppedIFrame = false;
/* 442 */         this.droppedPFrame = false;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 448 */       if ((src.getFlags() & 0x800) == 0) {
/*     */ 
/*     */ 
/*     */         
/* 452 */         dropFrame();
/* 453 */         return false;
/*     */       } 
/*     */       
/* 456 */       for (int j = this.currentframe.data.size() - 2; j >= 0; j--) {
/* 457 */         Buffer prev = this.currentframe.data.elementAt(j);
/* 458 */         if (compareSequenceNumbers(prev.getSequenceNumber(), src.getSequenceNumber()) != 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 463 */           dropFrame();
/* 464 */           return false;
/*     */         } 
/* 466 */         src = prev;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 471 */     boolean noslices = true;
/* 472 */     byte[] dest = (byte[])outBuffer.getData();
/* 473 */     if (dest == null || dest.length < this.currentframe.datalength + this.sequenceHeader.length + 16)
/*     */     {
/* 475 */       dest = new byte[this.currentframe.datalength + this.sequenceHeader.length + 16];
/*     */     }
/* 477 */     outBuffer.setData(dest);
/* 478 */     outBuffer.setOffset(0);
/* 479 */     outBuffer.setLength(0);
/*     */ 
/*     */     
/* 482 */     constructHeaders(outBuffer);
/* 483 */     if (!this.sequenceSent) {
/*     */ 
/*     */ 
/*     */       
/* 487 */       dropFrame();
/* 488 */       return false;
/*     */     } 
/*     */     
/* 491 */     int outoffset = outBuffer.getLength();
/*     */ 
/*     */     
/* 494 */     for (int i = 0; i < this.currentframe.data.size(); i++) {
/* 495 */       src = this.currentframe.data.elementAt(i);
/* 496 */       byte[] payload = (byte[])src.getData();
/* 497 */       int offset = src.getOffset();
/* 498 */       if ((payload[offset + 2] & 0x10) == 16)
/*     */       {
/* 500 */         if ((payload[offset + 2] & 0x8) == 8) {
/*     */           
/* 502 */           System.arraycopy(payload, offset + 4, dest, outoffset, src.getLength() - 4);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 507 */           outoffset += src.getLength() - 4;
/* 508 */           noslices = false;
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 514 */           long seq = src.getSequenceNumber();
/*     */           int j;
/* 516 */           for (j = i + 1; j < this.currentframe.data.size(); j++) {
/* 517 */             Buffer next = this.currentframe.data.elementAt(j);
/* 518 */             if (compareSequenceNumbers(seq, next.getSequenceNumber()) != 1) {
/*     */               
/* 520 */               if (i == 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 525 */                 offset += 4;
/* 526 */                 int len = src.getLength() - 4;
/* 527 */                 int off = offset;
/* 528 */                 while (len > 4 && (
/* 529 */                   payload[off + 0] != 0 || payload[off + 1] != 0 || payload[off + 2] != 1 || (payload[off + 3] & 0xFF) <= 0 || (payload[off + 3] & 0xFF) > 175)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 535 */                   off++;
/* 536 */                   len--;
/*     */                 } 
/* 538 */                 if (off == offset)
/*     */                   // Byte code: goto -> 702 
/* 540 */                 System.arraycopy(payload, offset, dest, outoffset, off - offset);
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 545 */                 outoffset += off - offset; // Byte code: goto -> 702
/*     */               } 
/*     */               // Byte code: goto -> 702
/*     */             } 
/* 549 */             seq = next.getSequenceNumber();
/* 550 */             if ((((byte[])next.getData())[next.getOffset() + 2] & 0x8) == 8) {
/*     */               break;
/*     */             }
/*     */           } 
/*     */           
/* 555 */           if (j == this.currentframe.data.size()) {
/*     */             break;
/*     */           }
/* 558 */           for (int k = i; k <= j; k++) {
/* 559 */             src = this.currentframe.data.elementAt(k);
/* 560 */             System.arraycopy(src.getData(), src.getOffset() + 4, dest, outoffset, src.getLength() - 4);
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 565 */             outoffset += src.getLength() - 4;
/*     */           } 
/* 567 */           noslices = false;
/* 568 */           i = j;
/*     */         }  } 
/* 570 */     }  if (this.outFormat == null || (this.outFormat.getSize()).width != this.width || (this.outFormat.getSize()).height != this.height || this.outFormat.getFrameRate() != this.frameRate) {
/*     */ 
/*     */       
/* 573 */       Dimension d = new Dimension(this.width, this.height);
/* 574 */       this.outFormat = new VideoFormat("mpeg", d, -1, Format.byteArray, this.frameRate);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 582 */     outBuffer.setLength(outoffset);
/* 583 */     outBuffer.setFormat((Format)this.outFormat);
/*     */     
/* 585 */     if (noslices) {
/* 586 */       outBuffer.setFlags(2);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 591 */     outBuffer.setTimeStamp(this.currentframe.rtptimestamp);
/* 592 */     outBuffer.setSequenceNumber(this.sequenceNumber++);
/*     */     
/* 594 */     this.newframe = true;
/* 595 */     this.currentframe = null;
/* 596 */     if (noslices)
/* 597 */       return false; 
/* 598 */     if (this.capture) {
/*     */       try {
/* 600 */         this.captureFile.write((byte[])outBuffer.getData(), outBuffer.getOffset(), outBuffer.getLength());
/*     */       } catch (IOException ioe) {
/*     */         
/* 603 */         System.err.println("RTPDePacketizer: write error for sequence number " + outBuffer.getSequenceNumber() + " : " + ioe);
/*     */ 
/*     */         
/* 606 */         this.capture = false;
/*     */       } 
/*     */     }
/* 609 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean firstPacket(Buffer inBuffer) {
/* 614 */     if (inBuffer == null)
/* 615 */       return false; 
/* 616 */     byte[] payload = (byte[])inBuffer.getData();
/* 617 */     if (payload == null)
/* 618 */       return false; 
/* 619 */     int offset = inBuffer.getOffset();
/* 620 */     int len = inBuffer.getLength();
/* 621 */     if (len < 12) {
/* 622 */       return false;
/*     */     }
/*     */     
/* 625 */     if (!this.gotSequenceHeader) {
/*     */       
/* 627 */       if ((payload[offset + 2] & 0x20) == 32 && payload[offset + 4] == 0 && payload[offset + 5] == 0 && payload[offset + 6] == 1 && (payload[offset + 7] & 0xFF) == 179) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 635 */         this.width = (payload[offset + 8] & 0xFF) << 4 | (payload[offset + 9] & 0xF0) >> 4;
/*     */ 
/*     */         
/* 638 */         this.height = (payload[offset + 9] & 0xF) << 8 | payload[offset + 10] & 0xFF;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 644 */         this.gotSequenceHeader = true;
/* 645 */         offset += 4;
/* 646 */         len -= 4;
/* 647 */         int off = offset;
/* 648 */         while (len > 8) {
/* 649 */           if (payload[off + 0] == 0 && payload[off + 1] == 0 && payload[off + 2] == 1)
/*     */           {
/* 651 */             if ((payload[off + 3] & 0xFF) == 184) {
/* 652 */               this.gopset = true;
/* 653 */               this.closedGop = payload[off + 7] & 0x40;
/*     */               
/* 655 */               payload[off + 7] = (byte)(payload[off + 7] & 0x20);
/* 656 */               this.sequenceHeader = new byte[off - offset];
/* 657 */               System.arraycopy(payload, offset, this.sequenceHeader, 0, this.sequenceHeader.length);
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 662 */               return true;
/*     */             } 
/*     */           }
/* 665 */           off++;
/* 666 */           len--;
/*     */         } 
/* 668 */         return true;
/*     */       } 
/* 670 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 675 */     if ((payload[offset + 2] & 0x10) != 16)
/* 676 */       return false; 
/* 677 */     offset += 4;
/* 678 */     len -= 4;
/* 679 */     while (len > 8) {
/* 680 */       if (payload[offset + 0] == 0 && payload[offset + 1] == 0 && payload[offset + 2] == 1) {
/*     */         
/* 682 */         if (payload[offset + 3] == 0)
/* 683 */           return true; 
/* 684 */         if ((payload[offset + 3] & 0xFF) == 184) {
/* 685 */           this.gopset = true;
/* 686 */           this.closedGop = payload[offset + 7] & 0x40;
/*     */           
/* 688 */           payload[offset + 7] = (byte)(payload[offset + 7] | 0x20);
/* 689 */           return true;
/*     */         } 
/* 691 */         if ((payload[offset + 3] & 0xFF) <= 175)
/* 692 */           return false; 
/*     */       } 
/* 694 */       offset++;
/* 695 */       len--;
/*     */     } 
/* 697 */     return false;
/*     */   }
/*     */   
/* 700 */   private static int MAX_SEQ = 65535;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int compareSequenceNumbers(long p, long c) {
/* 710 */     if (c > p)
/* 711 */       return (int)(c - p); 
/* 712 */     if (c == p)
/* 713 */       return 0; 
/* 714 */     if (p > (MAX_SEQ - 100) && c < 100L)
/*     */     {
/* 716 */       return (int)(MAX_SEQ - p + c + 1L);
/*     */     }
/* 718 */     return -1;
/*     */   }
/*     */   
/*     */   private MPEGFrame createNewFrame(Buffer inBuffer) {
/* 722 */     Buffer b = copyInto(inBuffer);
/*     */     
/* 724 */     MPEGFrame newframe = new MPEGFrame(this, b);
/* 725 */     newframe.add(b);
/* 726 */     return newframe;
/*     */   }
/*     */   
/*     */   private Buffer copyInto(Buffer src) {
/* 730 */     Buffer dest = new Buffer();
/* 731 */     dest.copy(src);
/* 732 */     src.setData(null);
/* 733 */     src.setHeader(null);
/* 734 */     src.setLength(0);
/* 735 */     src.setOffset(0);
/* 736 */     return dest;
/*     */   }
/*     */ 
/*     */   
/*     */   class MPEGFrame
/*     */   {
/*     */     public long rtptimestamp;
/*     */     public long seqno;
/*     */     private int datalength;
/*     */     private Vector data;
/*     */     private final RTPDePacketizer this$0;
/*     */     
/*     */     public MPEGFrame(RTPDePacketizer this$0, Buffer buffer) {
/* 749 */       this.this$0 = this$0; this.rtptimestamp = -1L; this.seqno = -1L; this.datalength = 0;
/* 750 */       this.data = new Vector();
/* 751 */       this.rtptimestamp = buffer.getTimeStamp();
/*     */     }
/*     */     
/*     */     public void add(Buffer buffer) {
/* 755 */       if (buffer == null || buffer.getData() == null || buffer.getLength() < 4) {
/*     */         return;
/*     */       }
/* 758 */       if (this.this$0.compareSequenceNumbers(this.seqno, buffer.getSequenceNumber()) > 0) {
/* 759 */         this.data.addElement(buffer);
/* 760 */         this.seqno = buffer.getSequenceNumber();
/*     */       } else {
/* 762 */         long sq = buffer.getSequenceNumber();
/* 763 */         for (int i = 0; i < this.data.size(); i++) {
/* 764 */           long bsq = ((Buffer)this.data.elementAt(i)).getSequenceNumber();
/* 765 */           if (this.this$0.compareSequenceNumbers(bsq, sq) < 0) {
/* 766 */             this.data.insertElementAt(buffer, i); break;
/*     */           } 
/* 768 */           if (sq == bsq) {
/*     */             return;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 774 */       this.datalength += buffer.getLength() - 4;
/*     */     }
/*     */     public Vector getData() {
/* 777 */       return this.data;
/*     */     }
/*     */     public Buffer getFirst() {
/* 780 */       if (this.data.size() > 0) {
/* 781 */         return this.data.firstElement();
/*     */       }
/* 783 */       return null;
/*     */     }
/*     */     public int getLength() {
/* 786 */       return this.datalength;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\codec\video\mpeg\RTPDePacketizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */