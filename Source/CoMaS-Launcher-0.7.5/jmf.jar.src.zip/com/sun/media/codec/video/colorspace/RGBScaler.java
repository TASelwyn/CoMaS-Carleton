/*     */ package com.sun.media.codec.video.colorspace;
/*     */ 
/*     */ import com.sun.media.BasicCodec;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import java.awt.Dimension;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.RGBFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RGBScaler
/*     */   extends BasicCodec
/*     */ {
/*  23 */   protected float quality = 0.5F;
/*     */   
/*  25 */   private int nativeData = 0;
/*     */   
/*     */   private static boolean nativeAvailable = true;
/*     */   
/*     */   static {
/*     */     try {
/*  31 */       JMFSecurityManager.loadLibrary("jmutil");
/*  32 */     } catch (Throwable t) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public RGBScaler() {
/*  37 */     this(null);
/*     */   }
/*     */   
/*     */   public RGBScaler(Dimension sizeOut) {
/*  41 */     this.inputFormats = new Format[] { (Format)new RGBFormat(null, -1, Format.byteArray, -1.0F, 24, 3, 2, 1, 3, -1, 0, -1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  53 */     if (sizeOut != null)
/*  54 */       setOutputSize(sizeOut); 
/*     */   }
/*     */   
/*     */   public void setOutputSize(Dimension sizeOut) {
/*  58 */     this.outputFormats = new Format[] { (Format)new RGBFormat(sizeOut, sizeOut.width * sizeOut.height * 3, Format.byteArray, -1.0F, 24, 3, 2, 1, 3, sizeOut.width * 3, 0, -1) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  72 */     return "RGB Scaler";
/*     */   }
/*     */   
/*     */   public Format[] getSupportedOutputFormats(Format input) {
/*  76 */     if (input == null) {
/*  77 */       return this.outputFormats;
/*     */     }
/*     */     
/*  80 */     if (BasicPlugIn.matches(input, this.inputFormats) != null) {
/*     */       
/*  82 */       float frameRate = ((VideoFormat)input).getFrameRate();
/*  83 */       VideoFormat frameRateFormat = new VideoFormat(null, null, -1, null, frameRate);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  89 */       return new Format[] { this.outputFormats[0].intersects((Format)frameRateFormat) };
/*     */     } 
/*  91 */     return new Format[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public Format setInputFormat(Format input) {
/*  96 */     if (BasicPlugIn.matches(input, this.inputFormats) == null) {
/*  97 */       return null;
/*     */     }
/*  99 */     return input;
/*     */   }
/*     */   
/*     */   public Format setOutputFormat(Format output) {
/* 103 */     if (output == null || BasicPlugIn.matches(output, this.outputFormats) == null)
/* 104 */       return null; 
/* 105 */     RGBFormat incoming = (RGBFormat)output;
/*     */     
/* 107 */     Dimension size = incoming.getSize();
/* 108 */     int maxDataLength = incoming.getMaxDataLength();
/* 109 */     int lineStride = incoming.getLineStride();
/* 110 */     float frameRate = incoming.getFrameRate();
/* 111 */     int flipped = incoming.getFlipped();
/* 112 */     int endian = incoming.getEndian();
/*     */     
/* 114 */     if (size == null)
/* 115 */       return null; 
/* 116 */     if (maxDataLength < size.width * size.height * 3)
/* 117 */       maxDataLength = size.width * size.height * 3; 
/* 118 */     if (lineStride < size.width * 3)
/* 119 */       lineStride = size.width * 3; 
/* 120 */     if (flipped != 0) {
/* 121 */       flipped = 0;
/*     */     }
/* 123 */     this.outputFormat = this.outputFormats[0].intersects((Format)new RGBFormat(size, maxDataLength, null, frameRate, -1, -1, -1, -1, -1, lineStride, -1, -1));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     return this.outputFormat;
/*     */   }
/*     */ 
/*     */   
/*     */   public int process(Buffer inBuffer, Buffer outBuffer) {
/* 140 */     int outputDataLength = ((VideoFormat)this.outputFormat).getMaxDataLength();
/*     */     
/* 142 */     outBuffer.setLength(outputDataLength);
/* 143 */     outBuffer.setFormat(this.outputFormat);
/*     */     
/* 145 */     if (this.quality <= 0.5F) {
/* 146 */       nearestNeighbour(inBuffer, outBuffer);
/*     */     }
/*     */ 
/*     */     
/* 150 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 155 */     super.close();
/* 156 */     if (nativeAvailable && this.nativeData != 0) {
/*     */       try {
/* 158 */         nativeClose();
/* 159 */       } catch (Throwable t) {}
/*     */     }
/*     */   }
/*     */   
/*     */   protected void nearestNeighbour(Buffer inBuffer, Buffer outBuffer) {
/*     */     Object object1, object2;
/* 165 */     RGBFormat vfIn = (RGBFormat)inBuffer.getFormat();
/* 166 */     Dimension sizeIn = vfIn.getSize();
/* 167 */     RGBFormat vfOut = (RGBFormat)outBuffer.getFormat();
/* 168 */     Dimension sizeOut = vfOut.getSize();
/* 169 */     int pixStrideIn = vfIn.getPixelStride();
/* 170 */     int pixStrideOut = vfOut.getPixelStride();
/* 171 */     int lineStrideIn = vfIn.getLineStride();
/* 172 */     int lineStrideOut = vfOut.getLineStride();
/* 173 */     float horRatio = sizeIn.width / sizeOut.width;
/* 174 */     float verRatio = sizeIn.height / sizeOut.height;
/*     */ 
/*     */     
/* 177 */     long inBytes = 0L;
/* 178 */     long outBytes = 0L;
/*     */     
/* 180 */     if (nativeAvailable) {
/* 181 */       object1 = getInputData(inBuffer);
/* 182 */       object2 = validateData(outBuffer, 0, true);
/* 183 */       inBytes = getNativeData(object1);
/* 184 */       outBytes = getNativeData(object2);
/*     */     } else {
/* 186 */       object1 = inBuffer.getData();
/* 187 */       object2 = outBuffer.getData();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 193 */     if (nativeAvailable) {
/*     */       try {
/* 195 */         nativeScale(object1, inBytes, object2, outBytes, pixStrideIn, lineStrideIn, sizeIn.width, sizeIn.height, pixStrideOut, lineStrideOut, sizeOut.width, sizeOut.height);
/*     */       
/*     */       }
/*     */       catch (Throwable t) {
/*     */ 
/*     */         
/* 201 */         nativeAvailable = false;
/*     */       } 
/*     */     }
/*     */     
/* 205 */     if (!nativeAvailable) {
/* 206 */       byte[] inData = (byte[])object1;
/* 207 */       byte[] outData = (byte[])object2;
/* 208 */       for (int y = 0; y < sizeOut.height; y++) {
/* 209 */         int ptrOut = y * lineStrideOut;
/* 210 */         int ptrIn = (int)(y * verRatio) * lineStrideIn;
/* 211 */         for (int x = 0; x < sizeOut.width; x++) {
/* 212 */           int ptrIn2 = ptrIn + (int)(x * horRatio) * pixStrideIn;
/* 213 */           outData[ptrOut] = inData[ptrIn2];
/* 214 */           outData[ptrOut + 1] = inData[ptrIn2 + 1];
/* 215 */           outData[ptrOut + 2] = inData[ptrIn2 + 2];
/* 216 */           ptrOut += pixStrideOut;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private native void nativeScale(Object paramObject1, long paramLong1, Object paramObject2, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8);
/*     */   
/*     */   private native void nativeClose();
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\codec\video\colorspace\RGBScaler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */