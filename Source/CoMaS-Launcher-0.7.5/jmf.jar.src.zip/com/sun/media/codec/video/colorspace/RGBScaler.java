package com.sun.media.codec.video.colorspace;

import com.sun.media.BasicCodec;
import com.sun.media.BasicPlugIn;
import com.sun.media.JMFSecurityManager;
import java.awt.Dimension;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.format.RGBFormat;
import javax.media.format.VideoFormat;

public class RGBScaler extends BasicCodec {
  protected float quality = 0.5F;
  
  private int nativeData = 0;
  
  private static boolean nativeAvailable = true;
  
  static {
    try {
      JMFSecurityManager.loadLibrary("jmutil");
    } catch (Throwable t) {}
  }
  
  public RGBScaler() {
    this(null);
  }
  
  public RGBScaler(Dimension sizeOut) {
    this.inputFormats = new Format[] { (Format)new RGBFormat(null, -1, Format.byteArray, -1.0F, 24, 3, 2, 1, 3, -1, 0, -1) };
    if (sizeOut != null)
      setOutputSize(sizeOut); 
  }
  
  public void setOutputSize(Dimension sizeOut) {
    this.outputFormats = new Format[] { (Format)new RGBFormat(sizeOut, sizeOut.width * sizeOut.height * 3, Format.byteArray, -1.0F, 24, 3, 2, 1, 3, sizeOut.width * 3, 0, -1) };
  }
  
  public String getName() {
    return "RGB Scaler";
  }
  
  public Format[] getSupportedOutputFormats(Format input) {
    if (input == null)
      return this.outputFormats; 
    if (BasicPlugIn.matches(input, this.inputFormats) != null) {
      float frameRate = ((VideoFormat)input).getFrameRate();
      VideoFormat frameRateFormat = new VideoFormat(null, null, -1, null, frameRate);
      return new Format[] { this.outputFormats[0].intersects((Format)frameRateFormat) };
    } 
    return new Format[0];
  }
  
  public Format setInputFormat(Format input) {
    if (BasicPlugIn.matches(input, this.inputFormats) == null)
      return null; 
    return input;
  }
  
  public Format setOutputFormat(Format output) {
    if (output == null || BasicPlugIn.matches(output, this.outputFormats) == null)
      return null; 
    RGBFormat incoming = (RGBFormat)output;
    Dimension size = incoming.getSize();
    int maxDataLength = incoming.getMaxDataLength();
    int lineStride = incoming.getLineStride();
    float frameRate = incoming.getFrameRate();
    int flipped = incoming.getFlipped();
    int endian = incoming.getEndian();
    if (size == null)
      return null; 
    if (maxDataLength < size.width * size.height * 3)
      maxDataLength = size.width * size.height * 3; 
    if (lineStride < size.width * 3)
      lineStride = size.width * 3; 
    if (flipped != 0)
      flipped = 0; 
    this.outputFormat = this.outputFormats[0].intersects((Format)new RGBFormat(size, maxDataLength, null, frameRate, -1, -1, -1, -1, -1, lineStride, -1, -1));
    return this.outputFormat;
  }
  
  public int process(Buffer inBuffer, Buffer outBuffer) {
    int outputDataLength = ((VideoFormat)this.outputFormat).getMaxDataLength();
    outBuffer.setLength(outputDataLength);
    outBuffer.setFormat(this.outputFormat);
    if (this.quality <= 0.5F)
      nearestNeighbour(inBuffer, outBuffer); 
    return 0;
  }
  
  public void close() {
    super.close();
    if (nativeAvailable && this.nativeData != 0)
      try {
        nativeClose();
      } catch (Throwable t) {} 
  }
  
  protected void nearestNeighbour(Buffer inBuffer, Buffer outBuffer) {
    Object object1, object2;
    RGBFormat vfIn = (RGBFormat)inBuffer.getFormat();
    Dimension sizeIn = vfIn.getSize();
    RGBFormat vfOut = (RGBFormat)outBuffer.getFormat();
    Dimension sizeOut = vfOut.getSize();
    int pixStrideIn = vfIn.getPixelStride();
    int pixStrideOut = vfOut.getPixelStride();
    int lineStrideIn = vfIn.getLineStride();
    int lineStrideOut = vfOut.getLineStride();
    float horRatio = sizeIn.width / sizeOut.width;
    float verRatio = sizeIn.height / sizeOut.height;
    long inBytes = 0L;
    long outBytes = 0L;
    if (nativeAvailable) {
      object1 = getInputData(inBuffer);
      object2 = validateData(outBuffer, 0, true);
      inBytes = getNativeData(object1);
      outBytes = getNativeData(object2);
    } else {
      object1 = inBuffer.getData();
      object2 = outBuffer.getData();
    } 
    if (nativeAvailable)
      try {
        nativeScale(object1, inBytes, object2, outBytes, pixStrideIn, lineStrideIn, sizeIn.width, sizeIn.height, pixStrideOut, lineStrideOut, sizeOut.width, sizeOut.height);
      } catch (Throwable t) {
        nativeAvailable = false;
      }  
    if (!nativeAvailable) {
      byte[] inData = (byte[])object1;
      byte[] outData = (byte[])object2;
      for (int y = 0; y < sizeOut.height; y++) {
        int ptrOut = y * lineStrideOut;
        int ptrIn = (int)(y * verRatio) * lineStrideIn;
        for (int x = 0; x < sizeOut.width; x++) {
          int ptrIn2 = ptrIn + (int)(x * horRatio) * pixStrideIn;
          outData[ptrOut] = inData[ptrIn2];
          outData[ptrOut + 1] = inData[ptrIn2 + 1];
          outData[ptrOut + 2] = inData[ptrIn2 + 2];
          ptrOut += pixStrideOut;
        } 
      } 
    } 
  }
  
  private native void nativeScale(Object paramObject1, long paramLong1, Object paramObject2, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8);
  
  private native void nativeClose();
}
