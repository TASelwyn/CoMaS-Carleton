/*      */ package com.sun.media.codec.video.cinepak;
/*      */ 
/*      */ import javax.media.Buffer;
/*      */ import javax.media.format.VideoFormat;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CPChunk
/*      */ {
/*      */   int fChunkType;
/*      */   int fChunkLen;
/*      */   int[] lookup;
/*      */   static int[] fBounding24;
/*      */   static int firstFlag;
/*      */   
/*      */   public CPChunk() {
/*   44 */     firstFlag = 1;
/*      */   }
/*      */ 
/*      */   
/*      */   public CPChunk(int[] l) {
/*   49 */     this.lookup = l;
/*   50 */     firstFlag = 1;
/*      */   }
/*      */   
/*      */   public void setLookup(int[] l) {
/*   54 */     this.lookup = l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void processChunk(byte[] inData, CineStore myStor, int whichStrip, int ChunkStart, Buffer outBuffer) {
/*   69 */     fBounding24 = CineStore.BOUNDING24;
/*      */ 
/*      */ 
/*      */     
/*   73 */     this.fChunkType = (inData[ChunkStart] & 0xFF) * 256 + (inData[ChunkStart + 1] & 0xFF);
/*      */ 
/*      */ 
/*      */     
/*   77 */     this.fChunkLen = (inData[ChunkStart + 2] & 0xFF) * 256 + (inData[ChunkStart + 3] & 0xFF);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   87 */     switch (this.fChunkType) {
/*      */ 
/*      */       
/*      */       case 8192:
/*   91 */         doCFUpdate(inData, ChunkStart + 4, (myStor.StripVec[whichStrip]).Detail);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 8704:
/*   99 */         doCFUpdate(inData, ChunkStart + 4, (myStor.StripVec[whichStrip]).Smooth);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 8448:
/*  107 */         doCPUpdate(inData, ChunkStart + 4, (myStor.StripVec[whichStrip]).Detail);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 8960:
/*  115 */         doCPUpdate(inData, ChunkStart + 4, (myStor.StripVec[whichStrip]).Smooth);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 12288:
/*  123 */         doFKUpdate(inData, ChunkStart + 4, myStor, whichStrip, outBuffer);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 12800:
/*  129 */         doFSKUpdate(inData, ChunkStart + 4, myStor, whichStrip, outBuffer);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 12544:
/*  135 */         doIUpdate(inData, ChunkStart + 4, myStor, whichStrip, outBuffer);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 9216:
/*  141 */         doGFUpdate(inData, ChunkStart + 4, (myStor.StripVec[whichStrip]).Detail);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 9728:
/*  149 */         doGFUpdate(inData, ChunkStart + 4, (myStor.StripVec[whichStrip]).Smooth);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 9472:
/*  157 */         doGPUpdate(inData, ChunkStart + 4, (myStor.StripVec[whichStrip]).Detail);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 9984:
/*  165 */         doGPUpdate(inData, ChunkStart + 4, (myStor.StripVec[whichStrip]).Smooth);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getChunkType() {
/*  183 */     switch (this.fChunkType) {
/*      */ 
/*      */       
/*      */       case 8704:
/*  187 */         return "color full    smooth codebook update";
/*      */ 
/*      */       
/*      */       case 8192:
/*  191 */         return "color full    detail codebook update";
/*      */ 
/*      */       
/*      */       case 8960:
/*  195 */         return "color partial smooth codebook update";
/*      */ 
/*      */       
/*      */       case 8448:
/*  199 */         return "color partial detail codebook update";
/*      */ 
/*      */       
/*      */       case 12288:
/*  203 */         return "full key frame update";
/*      */ 
/*      */       
/*      */       case 12800:
/*  207 */         return "full smooth key frame update";
/*      */ 
/*      */       
/*      */       case 12544:
/*  211 */         return "interframe update";
/*      */ 
/*      */       
/*      */       case 9216:
/*  215 */         return "greyscale full smooth codebook update";
/*      */ 
/*      */       
/*      */       case 9728:
/*  219 */         return "greyscale full detail codebook update";
/*      */ 
/*      */       
/*      */       case 9472:
/*  223 */         return "greyscale partial smooth codebook update";
/*      */ 
/*      */       
/*      */       case 9984:
/*  227 */         return "greyscale partial detail codebook update";
/*      */     } 
/*      */ 
/*      */     
/*  231 */     return "WARNING******* unknown atom chunk type...*******";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getChunkLength() {
/*  245 */     return this.fChunkLen;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doCFUpdate(byte[] ChunkArray, int ChunkDataStart, CodeEntry[] codebook) {
/*  261 */     int numberOfCodes = ((ChunkArray[ChunkDataStart - 2] & 0xFF) * 256 + (ChunkArray[ChunkDataStart - 1] & 0xFF) - 4) / 6;
/*      */ 
/*      */ 
/*      */     
/*  265 */     for (int i = 0; i < numberOfCodes; i++) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  291 */       int Y0 = ChunkArray[ChunkDataStart + i * 6] & 0xFF;
/*      */       
/*  293 */       int Y1 = ChunkArray[ChunkDataStart + i * 6 + 1] & 0xFF;
/*      */       
/*  295 */       int Y2 = ChunkArray[ChunkDataStart + i * 6 + 2] & 0xFF;
/*      */       
/*  297 */       int Y3 = ChunkArray[ChunkDataStart + i * 6 + 3] & 0xFF;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  303 */       int U = ChunkArray[ChunkDataStart + i * 6 + 4];
/*      */       
/*  305 */       int V = ChunkArray[ChunkDataStart + i * 6 + 5];
/*      */ 
/*      */ 
/*      */       
/*  309 */       int delR = 2 * U + 128;
/*      */       
/*  311 */       int delB = 2 * V + 128;
/*      */       
/*  313 */       int delG = -(U / 2) - V + 128;
/*      */ 
/*      */ 
/*      */       
/*  317 */       (codebook[i]).aRGB0 = (fBounding24[Y0 + delR] << 16) + (fBounding24[Y0 + delG] << 8) + fBounding24[Y0 + delB];
/*      */       
/*  319 */       (codebook[i]).aRGB1 = (fBounding24[Y1 + delR] << 16) + (fBounding24[Y1 + delG] << 8) + fBounding24[Y1 + delB];
/*      */       
/*  321 */       (codebook[i]).aRGB2 = (fBounding24[Y2 + delR] << 16) + (fBounding24[Y2 + delG] << 8) + fBounding24[Y2 + delB];
/*      */       
/*  323 */       (codebook[i]).aRGB3 = (fBounding24[Y3 + delR] << 16) + (fBounding24[Y3 + delG] << 8) + fBounding24[Y3 + delB];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doCPUpdate(byte[] ChunkArray, int ChunkDataStart, CodeEntry[] codebook) {
/*  343 */     int ByteCounter = ChunkDataStart;
/*      */     
/*  345 */     int CodeCount = 0;
/*      */     
/*  347 */     int len = (ChunkArray[ChunkDataStart - 2] & 0xFF) * 256 + (ChunkArray[ChunkDataStart - 1] & 0xFF) - 4 + ByteCounter;
/*      */ 
/*      */ 
/*      */     
/*  351 */     while (ByteCounter < len && CodeCount < 256) {
/*      */ 
/*      */ 
/*      */       
/*  355 */       int Map = ChunkArray[ByteCounter++] & 0xFF;
/*      */       
/*  357 */       Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
/*      */       
/*  359 */       Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
/*      */       
/*  361 */       Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
/*      */ 
/*      */ 
/*      */       
/*  365 */       int Mask = Integer.MIN_VALUE;
/*      */       
/*  367 */       for (int i = 0; i < 32 && ByteCounter < len && CodeCount < 256; i++) {
/*      */ 
/*      */ 
/*      */         
/*  371 */         if ((Mask & Map) != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  397 */           int Y0 = ChunkArray[ByteCounter++] & 0xFF;
/*      */           
/*  399 */           int Y1 = ChunkArray[ByteCounter++] & 0xFF;
/*      */           
/*  401 */           int Y2 = ChunkArray[ByteCounter++] & 0xFF;
/*      */           
/*  403 */           int Y3 = ChunkArray[ByteCounter++] & 0xFF;
/*      */ 
/*      */ 
/*      */           
/*  407 */           int U = ChunkArray[ByteCounter++];
/*      */           
/*  409 */           int V = ChunkArray[ByteCounter++];
/*      */ 
/*      */ 
/*      */           
/*  413 */           int delR = 2 * U + 128;
/*      */           
/*  415 */           int delB = 2 * V + 128;
/*      */           
/*  417 */           int delG = -(U / 2) - V + 128;
/*      */ 
/*      */ 
/*      */           
/*  421 */           (codebook[CodeCount]).aRGB0 = (fBounding24[Y0 + delR] << 16) + (fBounding24[Y0 + delG] << 8) + fBounding24[Y0 + delB];
/*      */           
/*  423 */           (codebook[CodeCount]).aRGB1 = (fBounding24[Y1 + delR] << 16) + (fBounding24[Y1 + delG] << 8) + fBounding24[Y1 + delB];
/*      */           
/*  425 */           (codebook[CodeCount]).aRGB2 = (fBounding24[Y2 + delR] << 16) + (fBounding24[Y2 + delG] << 8) + fBounding24[Y2 + delB];
/*      */           
/*  427 */           (codebook[CodeCount]).aRGB3 = (fBounding24[Y3 + delR] << 16) + (fBounding24[Y3 + delG] << 8) + fBounding24[Y3 + delB];
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  433 */         Mask >>>= 1;
/*      */         
/*  435 */         CodeCount++;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doFKUpdate(byte[] ChunkArray, int ChunkDataStart, CineStore myStor, int thisStrip, Buffer outBuffer) {
/*  461 */     int[] outData = (int[])outBuffer.getData();
/*      */     
/*  463 */     VideoFormat outFmt = (VideoFormat)outBuffer.getFormat();
/*      */     
/*  465 */     int outWidth = (outFmt.getSize()).width;
/*      */     
/*  467 */     CpStrip theStrip = myStor.StripVec[thisStrip];
/*      */     
/*  469 */     CodeEntry[] detailBook = theStrip.Detail;
/*      */     
/*  471 */     CodeEntry[] smoothBook = theStrip.Smooth;
/*      */ 
/*      */ 
/*      */     
/*  475 */     int len = (ChunkArray[ChunkDataStart - 2] & 0xFF) * 256 + (ChunkArray[ChunkDataStart - 1] & 0xFF) - 4 + ChunkDataStart;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  483 */     int xdraw = myStor.ImagePosX + myStor.StripPosX;
/*      */     
/*  485 */     int ydraw = myStor.ImagePosY + myStor.StripPosY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  501 */     int ByteCounter = ChunkDataStart;
/*      */     
/*  503 */     int CodeCount = 0;
/*      */     
/*  505 */     while (ByteCounter < len && ydraw < myStor.ImagePosY + myStor.ImageSizeY) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  513 */       int Map = ChunkArray[ByteCounter++] & 0xFF;
/*      */       
/*  515 */       Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
/*      */       
/*  517 */       Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
/*      */       
/*  519 */       Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  533 */       int Mask = Integer.MIN_VALUE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  539 */       for (int i = 0; i < 32 && ByteCounter < len && ydraw < myStor.ImagePosY + myStor.ImageSizeY; i++) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  545 */         if ((Mask & Map) != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  551 */           CodeEntry thisCode = detailBook[ChunkArray[ByteCounter++] & 0xFF];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  557 */           int color = thisCode.aRGB0;
/*      */           
/*  559 */           int startLocation = xdraw + outWidth * ydraw;
/*      */           
/*  561 */           int location = startLocation;
/*      */           
/*  563 */           outData[location] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  569 */           color = thisCode.aRGB1;
/*      */           
/*  571 */           location = startLocation + 1;
/*      */           
/*  573 */           outData[location] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  579 */           color = thisCode.aRGB2;
/*      */           
/*  581 */           location = startLocation + outWidth;
/*      */           
/*  583 */           outData[location] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  589 */           color = thisCode.aRGB3;
/*      */           
/*  591 */           location++;
/*      */           
/*  593 */           outData[location] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  599 */           thisCode = detailBook[ChunkArray[ByteCounter++] & 0xFF];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  605 */           color = thisCode.aRGB0;
/*      */           
/*  607 */           startLocation = xdraw + 2 + outWidth * ydraw;
/*      */           
/*  609 */           location = startLocation;
/*      */           
/*  611 */           outData[location] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  617 */           color = thisCode.aRGB1;
/*      */           
/*  619 */           location = startLocation + 1;
/*      */           
/*  621 */           outData[location] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  627 */           color = thisCode.aRGB2;
/*      */           
/*  629 */           location = startLocation + outWidth;
/*      */           
/*  631 */           outData[location] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  637 */           color = thisCode.aRGB3;
/*      */           
/*  639 */           location++;
/*      */           
/*  641 */           outData[location] = color;
/*      */ 
/*      */ 
/*      */           
/*  645 */           thisCode = detailBook[ChunkArray[ByteCounter++] & 0xFF];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  651 */           color = thisCode.aRGB0;
/*      */           
/*  653 */           startLocation = xdraw + outWidth * (ydraw + 2);
/*      */           
/*  655 */           location = startLocation;
/*      */           
/*  657 */           outData[location] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  663 */           color = thisCode.aRGB1;
/*      */           
/*  665 */           location = startLocation + 1;
/*      */           
/*  667 */           outData[location] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  673 */           color = thisCode.aRGB2;
/*      */           
/*  675 */           location = startLocation + outWidth;
/*      */           
/*  677 */           outData[location] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  683 */           color = thisCode.aRGB3;
/*      */           
/*  685 */           location++;
/*      */           
/*  687 */           outData[location] = color;
/*      */ 
/*      */ 
/*      */           
/*  691 */           thisCode = detailBook[ChunkArray[ByteCounter++] & 0xFF];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  697 */           color = thisCode.aRGB0;
/*      */           
/*  699 */           startLocation = xdraw + 2 + outWidth * (ydraw + 2);
/*      */           
/*  701 */           location = startLocation;
/*      */           
/*  703 */           outData[location] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  709 */           color = thisCode.aRGB1;
/*      */           
/*  711 */           location = startLocation + 1;
/*      */           
/*  713 */           outData[location] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  719 */           color = thisCode.aRGB2;
/*      */           
/*  721 */           location = startLocation + outWidth;
/*      */           
/*  723 */           outData[location] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  729 */           color = thisCode.aRGB3;
/*      */           
/*  731 */           outData[location + 1] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  747 */           CodeEntry codeEntry = smoothBook[ChunkArray[ByteCounter++] & 0xFF];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  755 */           int j = codeEntry.aRGB0;
/*      */           
/*  757 */           int k = xdraw + outWidth * ydraw;
/*      */           
/*  759 */           int m = k;
/*      */ 
/*      */ 
/*      */           
/*  763 */           outData[m] = j;
/*      */           
/*  765 */           outData[m + 1] = j;
/*      */           
/*  767 */           m += outWidth;
/*      */           
/*  769 */           outData[m] = j;
/*      */           
/*  771 */           outData[m + 1] = j;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  779 */           j = codeEntry.aRGB1;
/*      */           
/*  781 */           m = k + 2;
/*      */ 
/*      */ 
/*      */           
/*  785 */           outData[m] = j;
/*      */           
/*  787 */           outData[m + 1] = j;
/*      */           
/*  789 */           m += outWidth;
/*      */           
/*  791 */           outData[m] = j;
/*      */           
/*  793 */           outData[m + 1] = j;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  799 */           j = codeEntry.aRGB2;
/*      */           
/*  801 */           m = k += outWidth * 2;
/*      */ 
/*      */ 
/*      */           
/*  805 */           outData[m] = j;
/*      */           
/*  807 */           outData[m + 1] = j;
/*      */           
/*  809 */           m += outWidth;
/*      */           
/*  811 */           outData[m] = j;
/*      */           
/*  813 */           outData[m + 1] = j;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  821 */           j = codeEntry.aRGB3;
/*      */           
/*  823 */           m = k + 2;
/*      */ 
/*      */ 
/*      */           
/*  827 */           outData[m] = j;
/*      */           
/*  829 */           outData[m + 1] = j;
/*      */           
/*  831 */           m += outWidth;
/*      */           
/*  833 */           outData[m] = j;
/*      */           
/*  835 */           outData[m + 1] = j;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  843 */         xdraw += 4;
/*      */ 
/*      */ 
/*      */         
/*  847 */         Mask >>>= 1;
/*      */ 
/*      */ 
/*      */         
/*  851 */         CodeCount++;
/*      */         
/*  853 */         if (xdraw > myStor.ImageSizeX - 4) {
/*      */ 
/*      */ 
/*      */           
/*  857 */           xdraw = myStor.ImagePosX + myStor.StripPosX;
/*      */           
/*  859 */           ydraw += 4;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doFSKUpdate(byte[] ChunkArray, int ChunkDataStart, CineStore myStor, int thisStrip, Buffer outBuffer) {
/*  889 */     int[] outData = (int[])outBuffer.getData();
/*      */ 
/*      */     
/*  892 */     VideoFormat outFmt = (VideoFormat)outBuffer.getFormat();
/*      */     
/*  894 */     int outWidth = (outFmt.getSize()).width;
/*      */     
/*  896 */     CpStrip theStrip = myStor.StripVec[thisStrip];
/*      */     
/*  898 */     CodeEntry[] detailBook = theStrip.Detail;
/*      */     
/*  900 */     CodeEntry[] smoothBook = theStrip.Smooth;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  908 */     int len = (ChunkArray[ChunkDataStart - 2] & 0xFF) * 256 + (ChunkArray[ChunkDataStart - 1] & 0xFF) - 4 + ChunkDataStart;
/*      */ 
/*      */ 
/*      */     
/*  912 */     int xdraw = myStor.ImagePosX + myStor.StripPosX;
/*      */     
/*  914 */     int ydraw = myStor.ImagePosY + myStor.StripPosY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  926 */     int ByteCounter = ChunkDataStart;
/*      */     
/*  928 */     while (ByteCounter < len) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  934 */       CodeEntry thisCode = smoothBook[ChunkArray[ByteCounter++] & 0xFF];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  940 */       int color = thisCode.aRGB0;
/*      */       
/*  942 */       int startLocation = xdraw + outWidth * ydraw;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  947 */       if (startLocation >= outData.length) {
/*      */         break;
/*      */       }
/*  950 */       int location = startLocation;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  961 */       outData[location] = color;
/*      */ 
/*      */       
/*  964 */       outData[location + 1] = color;
/*      */       
/*  966 */       location += outWidth;
/*      */       
/*  968 */       outData[location] = color;
/*      */       
/*  970 */       outData[location + 1] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  978 */       color = thisCode.aRGB1;
/*      */       
/*  980 */       location = startLocation + 2;
/*      */ 
/*      */ 
/*      */       
/*  984 */       outData[location] = color;
/*      */       
/*  986 */       outData[location + 1] = color;
/*      */       
/*  988 */       location += outWidth;
/*      */       
/*  990 */       outData[location] = color;
/*      */       
/*  992 */       outData[location + 1] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  998 */       color = thisCode.aRGB2;
/*      */       
/* 1000 */       location = startLocation += outWidth * 2;
/*      */ 
/*      */ 
/*      */       
/* 1004 */       outData[location] = color;
/*      */       
/* 1006 */       outData[location + 1] = color;
/*      */       
/* 1008 */       location += outWidth;
/*      */       
/* 1010 */       outData[location] = color;
/*      */       
/* 1012 */       outData[location + 1] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1020 */       color = thisCode.aRGB3;
/*      */       
/* 1022 */       location = startLocation + 2;
/*      */ 
/*      */ 
/*      */       
/* 1026 */       outData[location] = color;
/*      */       
/* 1028 */       outData[location + 1] = color;
/*      */       
/* 1030 */       location += outWidth;
/*      */       
/* 1032 */       outData[location] = color;
/*      */       
/* 1034 */       outData[location + 1] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1040 */       xdraw += 4;
/*      */ 
/*      */ 
/*      */       
/* 1044 */       if (xdraw > myStor.ImageSizeX - 4) {
/*      */ 
/*      */ 
/*      */         
/* 1048 */         xdraw = myStor.ImagePosX + myStor.StripPosX;
/*      */         
/* 1050 */         ydraw += 4;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doIUpdate(byte[] ChunkArray, int ChunkDataStart, CineStore myStor, int thisStrip, Buffer outBuffer) {
/* 1076 */     int[] outData = (int[])outBuffer.getData();
/*      */     
/* 1078 */     VideoFormat outFmt = (VideoFormat)outBuffer.getFormat();
/*      */     
/* 1080 */     int outWidth = (outFmt.getSize()).width;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1092 */     CodeEntry[] detailBook = (myStor.StripVec[thisStrip]).Detail;
/*      */     
/* 1094 */     CodeEntry[] smoothBook = (myStor.StripVec[thisStrip]).Smooth;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1100 */     int len = (ChunkArray[ChunkDataStart - 2] & 0xFF) * 256 + (ChunkArray[ChunkDataStart - 1] & 0xFF) - 4 + ChunkDataStart;
/*      */ 
/*      */ 
/*      */     
/* 1104 */     int xdraw = myStor.ImagePosX + myStor.StripPosX;
/*      */     
/* 1106 */     int ydraw = myStor.ImagePosY + myStor.StripPosY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1112 */     int ByteCounter = ChunkDataStart;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1120 */     int Map = 0;
/*      */     
/* 1122 */     int Mask = 0;
/*      */     
/* 1124 */     int FinishY = myStor.ImagePosY + myStor.StripPosY + myStor.StripPosY1;
/*      */ 
/*      */ 
/*      */     
/* 1128 */     while (ByteCounter < len && ydraw < FinishY) {
/*      */ 
/*      */ 
/*      */       
/* 1132 */       Mask >>>= 1;
/*      */       
/* 1134 */       if (Mask == 0) {
/*      */ 
/*      */ 
/*      */         
/* 1138 */         Map = ChunkArray[ByteCounter++] & 0xFF;
/*      */         
/* 1140 */         Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
/*      */         
/* 1142 */         Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
/*      */         
/* 1144 */         Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
/*      */ 
/*      */ 
/*      */         
/* 1148 */         Mask = Integer.MIN_VALUE;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1156 */       if ((Mask & Map) != 0 && ByteCounter < len) {
/*      */ 
/*      */ 
/*      */         
/* 1160 */         Mask >>>= 1;
/*      */         
/* 1162 */         if (Mask == 0) {
/*      */ 
/*      */ 
/*      */           
/* 1166 */           Map = ChunkArray[ByteCounter++] & 0xFF;
/*      */           
/* 1168 */           Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
/*      */           
/* 1170 */           Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
/*      */           
/* 1172 */           Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
/*      */ 
/*      */ 
/*      */           
/* 1176 */           Mask = Integer.MIN_VALUE;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1182 */         if ((Mask & Map) != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1190 */           int startLocation = xdraw + outWidth * ydraw;
/*      */           
/* 1192 */           CodeEntry thisCode = detailBook[ChunkArray[ByteCounter++] & 0xFF];
/*      */           
/* 1194 */           outData[startLocation] = thisCode.aRGB0;
/*      */           
/* 1196 */           outData[startLocation + 1] = thisCode.aRGB1;
/*      */           
/* 1198 */           outData[startLocation + outWidth] = thisCode.aRGB2;
/*      */           
/* 1200 */           outData[startLocation + outWidth + 1] = thisCode.aRGB3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1206 */           startLocation = xdraw + 2 + outWidth * ydraw;
/*      */           
/* 1208 */           thisCode = detailBook[ChunkArray[ByteCounter++] & 0xFF];
/*      */           
/* 1210 */           outData[startLocation] = thisCode.aRGB0;
/*      */           
/* 1212 */           outData[startLocation + 1] = thisCode.aRGB1;
/*      */           
/* 1214 */           outData[startLocation + outWidth] = thisCode.aRGB2;
/*      */           
/* 1216 */           outData[startLocation + outWidth + 1] = thisCode.aRGB3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1222 */           thisCode = detailBook[ChunkArray[ByteCounter++] & 0xFF];
/*      */           
/* 1224 */           startLocation = xdraw + outWidth * (ydraw + 2);
/*      */           
/* 1226 */           outData[startLocation] = thisCode.aRGB0;
/*      */           
/* 1228 */           outData[startLocation + 1] = thisCode.aRGB1;
/*      */           
/* 1230 */           outData[startLocation + outWidth] = thisCode.aRGB2;
/*      */           
/* 1232 */           outData[startLocation + outWidth + 1] = thisCode.aRGB3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1238 */           thisCode = detailBook[ChunkArray[ByteCounter++] & 0xFF];
/*      */           
/* 1240 */           startLocation = xdraw + 2 + outWidth * (ydraw + 2);
/*      */           
/* 1242 */           outData[startLocation] = thisCode.aRGB0;
/*      */           
/* 1244 */           outData[startLocation + 1] = thisCode.aRGB1;
/*      */           
/* 1246 */           outData[startLocation + outWidth] = thisCode.aRGB2;
/*      */           
/* 1248 */           outData[startLocation + outWidth + 1] = thisCode.aRGB3;
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1258 */           CodeEntry codeEntry = smoothBook[ChunkArray[ByteCounter++] & 0xFF];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1264 */           int color = codeEntry.aRGB0;
/*      */           
/* 1266 */           int i = xdraw + outWidth * ydraw;
/*      */           
/* 1268 */           int location = i;
/*      */ 
/*      */ 
/*      */           
/* 1272 */           outData[location] = color;
/*      */           
/* 1274 */           outData[location + 1] = color;
/*      */           
/* 1276 */           location += outWidth;
/*      */           
/* 1278 */           outData[location] = color;
/*      */           
/* 1280 */           outData[location + 1] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1288 */           color = codeEntry.aRGB1;
/*      */           
/* 1290 */           location = i + 2;
/*      */ 
/*      */ 
/*      */           
/* 1294 */           outData[location] = color;
/*      */           
/* 1296 */           outData[location + 1] = color;
/*      */           
/* 1298 */           location += outWidth;
/*      */           
/* 1300 */           outData[location] = color;
/*      */           
/* 1302 */           outData[location + 1] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1308 */           color = codeEntry.aRGB2;
/*      */           
/* 1310 */           i += outWidth * 2;
/*      */           
/* 1312 */           location = i;
/*      */           
/* 1314 */           outData[location] = color;
/*      */           
/* 1316 */           outData[location + 1] = color;
/*      */           
/* 1318 */           location += outWidth;
/*      */           
/* 1320 */           outData[location] = color;
/*      */           
/* 1322 */           outData[location + 1] = color;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1328 */           color = codeEntry.aRGB3;
/*      */           
/* 1330 */           location = i + 2;
/*      */ 
/*      */ 
/*      */           
/* 1334 */           outData[location] = color;
/*      */           
/* 1336 */           outData[location + 1] = color;
/*      */           
/* 1338 */           location += outWidth;
/*      */           
/* 1340 */           outData[location] = color;
/*      */           
/* 1342 */           outData[location + 1] = color;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1366 */       xdraw += 4;
/*      */ 
/*      */ 
/*      */       
/* 1370 */       if (xdraw > myStor.ImageSizeX - 4) {
/*      */         
/* 1372 */         xdraw = myStor.ImagePosX + myStor.StripPosX;
/*      */         
/* 1374 */         ydraw += 4;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doGFUpdate(byte[] ChunkArray, int ChunkDataStart, CodeEntry[] codebook) {
/* 1408 */     int ByteCounter = ChunkDataStart;
/*      */ 
/*      */ 
/*      */     
/* 1412 */     int numberOfCodes = ((ChunkArray[ChunkDataStart - 2] & 0xFF) * 256 + (ChunkArray[ChunkDataStart - 1] & 0xFF) - 4) / 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1421 */     if (this.lookup == null) {
/* 1422 */       for (int i = 0; i < numberOfCodes; i++)
/*      */       {
/* 1424 */         if (firstFlag == 1)
/*      */         {
/* 1426 */           int anInt = ChunkArray[ByteCounter++] & 0xFF;
/*      */ 
/*      */ 
/*      */           
/* 1430 */           (codebook[i]).aRGB0 = (anInt << 16) + (anInt << 8) + anInt;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1438 */           anInt = ChunkArray[ByteCounter++] & 0xFF;
/*      */           
/* 1440 */           (codebook[i]).aRGB1 = (anInt << 16) + (anInt << 8) + anInt;
/*      */ 
/*      */ 
/*      */           
/* 1444 */           anInt = ChunkArray[ByteCounter++] & 0xFF;
/*      */           
/* 1446 */           (codebook[i]).aRGB2 = (anInt << 16) + (anInt << 8) + anInt;
/*      */ 
/*      */ 
/*      */           
/* 1450 */           anInt = ChunkArray[ByteCounter++] & 0xFF;
/*      */           
/* 1452 */           (codebook[i]).aRGB3 = (anInt << 16) + (anInt << 8) + anInt;
/*      */         
/*      */         }
/*      */         else
/*      */         {
/*      */           
/* 1458 */           int j = ChunkArray[ByteCounter++] & 0xFF;
/*      */ 
/*      */ 
/*      */           
/* 1462 */           (codebook[i]).aRGB0 = j << 16 | j << 8 | j;
/*      */ 
/*      */ 
/*      */           
/* 1466 */           j = ChunkArray[ByteCounter++] & 0xFF;
/*      */           
/* 1468 */           (codebook[i]).aRGB1 = j << 16 | j << 8 | j;
/*      */ 
/*      */ 
/*      */           
/* 1472 */           j = ChunkArray[ByteCounter++] & 0xFF;
/*      */           
/* 1474 */           (codebook[i]).aRGB2 = j << 16 | j << 8 | j;
/*      */ 
/*      */ 
/*      */           
/* 1478 */           j = ChunkArray[ByteCounter++] & 0xFF;
/*      */           
/* 1480 */           (codebook[i]).aRGB3 = j << 16 | j << 8 | j;
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1494 */       for (byte b = 0; b < numberOfCodes; b++) {
/*      */         
/* 1496 */         if (firstFlag == 1) {
/*      */           
/* 1498 */           int i = ChunkArray[ByteCounter++] & 0xFF;
/*      */           
/* 1500 */           (codebook[b]).aRGB0 = this.lookup[i];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1508 */           i = ChunkArray[ByteCounter++] & 0xFF;
/*      */           
/* 1510 */           (codebook[b]).aRGB1 = this.lookup[i];
/*      */ 
/*      */ 
/*      */           
/* 1514 */           i = ChunkArray[ByteCounter++] & 0xFF;
/*      */           
/* 1516 */           (codebook[b]).aRGB2 = this.lookup[i];
/*      */ 
/*      */ 
/*      */           
/* 1520 */           i = ChunkArray[ByteCounter++] & 0xFF;
/*      */           
/* 1522 */           (codebook[b]).aRGB3 = this.lookup[i];
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 1528 */           int i = ChunkArray[ByteCounter++] & 0xFF;
/*      */ 
/*      */ 
/*      */           
/* 1532 */           (codebook[b]).aRGB0 = this.lookup[i];
/*      */ 
/*      */ 
/*      */           
/* 1536 */           i = ChunkArray[ByteCounter++] & 0xFF;
/*      */           
/* 1538 */           (codebook[b]).aRGB1 = this.lookup[i];
/*      */ 
/*      */ 
/*      */           
/* 1542 */           i = ChunkArray[ByteCounter++] & 0xFF;
/*      */           
/* 1544 */           (codebook[b]).aRGB2 = this.lookup[i];
/*      */ 
/*      */ 
/*      */           
/* 1548 */           i = ChunkArray[ByteCounter++] & 0xFF;
/*      */           
/* 1550 */           (codebook[b]).aRGB3 = this.lookup[i];
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1565 */     firstFlag = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doGPUpdate(byte[] ChunkArray, int ChunkDataStart, CodeEntry[] codebook) {
/* 1581 */     int ByteCounter = ChunkDataStart;
/*      */     
/* 1583 */     int CodeCount = 0;
/*      */ 
/*      */ 
/*      */     
/* 1587 */     int len = (ChunkArray[ChunkDataStart - 2] & 0xFF) * 256 + (ChunkArray[ChunkDataStart - 1] & 0xFF) - 4 + ChunkDataStart;
/*      */ 
/*      */ 
/*      */     
/* 1591 */     if (this.lookup == null) {
/* 1592 */       while (ByteCounter < len && CodeCount < 256) {
/*      */ 
/*      */ 
/*      */         
/* 1596 */         int Map = ChunkArray[ByteCounter++] & 0xFF;
/*      */         
/* 1598 */         Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
/*      */         
/* 1600 */         Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
/*      */         
/* 1602 */         Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
/*      */ 
/*      */ 
/*      */         
/* 1606 */         int Mask = Integer.MIN_VALUE;
/*      */ 
/*      */ 
/*      */         
/* 1610 */         for (int i = 0; i < 32 && ByteCounter < len && CodeCount < 256; i++)
/*      */         {
/*      */ 
/*      */           
/* 1614 */           if ((Mask & Map) != 0) {
/*      */             
/* 1616 */             int anInt = ChunkArray[ByteCounter++] & 0xFF;
/*      */             
/* 1618 */             (codebook[CodeCount]).aRGB0 = anInt << 16 | anInt << 8 | anInt;
/*      */             
/* 1620 */             anInt = ChunkArray[ByteCounter++] & 0xFF;
/*      */             
/* 1622 */             (codebook[CodeCount]).aRGB1 = anInt << 16 | anInt << 8 | anInt;
/*      */             
/* 1624 */             anInt = ChunkArray[ByteCounter++] & 0xFF;
/*      */             
/* 1626 */             (codebook[CodeCount]).aRGB2 = anInt << 16 | anInt << 8 | anInt;
/*      */             
/* 1628 */             anInt = ChunkArray[ByteCounter++] & 0xFF;
/*      */             
/* 1630 */             (codebook[CodeCount]).aRGB3 = anInt << 16 | anInt << 8 | anInt;
/*      */           } 
/*      */ 
/*      */           
/* 1634 */           Mask >>>= 1;
/*      */           
/* 1636 */           CodeCount++;
/*      */         }
/*      */       
/*      */       } 
/*      */     } else {
/*      */       
/* 1642 */       while (ByteCounter < len && CodeCount < 256) {
/*      */ 
/*      */ 
/*      */         
/* 1646 */         int Map = ChunkArray[ByteCounter++] & 0xFF;
/*      */         
/* 1648 */         Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
/*      */         
/* 1650 */         Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
/*      */         
/* 1652 */         Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
/*      */ 
/*      */ 
/*      */         
/* 1656 */         int Mask = Integer.MIN_VALUE;
/*      */ 
/*      */ 
/*      */         
/* 1660 */         for (int i = 0; i < 32 && ByteCounter < len && CodeCount < 256; i++) {
/*      */ 
/*      */ 
/*      */           
/* 1664 */           if ((Mask & Map) != 0) {
/*      */             
/* 1666 */             int anInt = ChunkArray[ByteCounter++] & 0xFF;
/*      */             
/* 1668 */             (codebook[CodeCount]).aRGB0 = this.lookup[anInt];
/*      */             
/* 1670 */             anInt = ChunkArray[ByteCounter++] & 0xFF;
/*      */             
/* 1672 */             (codebook[CodeCount]).aRGB1 = this.lookup[anInt];
/*      */             
/* 1674 */             anInt = ChunkArray[ByteCounter++] & 0xFF;
/*      */             
/* 1676 */             (codebook[CodeCount]).aRGB2 = this.lookup[anInt];
/*      */             
/* 1678 */             anInt = ChunkArray[ByteCounter++] & 0xFF;
/*      */             
/* 1680 */             (codebook[CodeCount]).aRGB3 = this.lookup[anInt];
/*      */           } 
/*      */ 
/*      */           
/* 1684 */           Mask >>>= 1;
/*      */           
/* 1686 */           CodeCount++;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\codec\video\cinepak\CPChunk.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */