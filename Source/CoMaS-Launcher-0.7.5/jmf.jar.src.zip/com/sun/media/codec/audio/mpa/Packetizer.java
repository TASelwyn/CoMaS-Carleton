/*     */ package com.sun.media.codec.audio.mpa;
/*     */ 
/*     */ import com.sun.media.BasicCodec;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.codec.audio.AudioCodec;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Codec;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Packetizer
/*     */   extends AudioCodec
/*     */ {
/*     */   private static final int NEW_FRAME = 0;
/*     */   private static final int CONT_FRAME = 1;
/*     */   private static final int CONT_BUFFER = 2;
/*     */   private static final int FILL_BUFFER = 3;
/*  56 */   private int state = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int MAX_MPA_FRAMESIZE = 1729;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int MAX_FRAMESIZE = 1456;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int MIN_FRAMESIZE = 110;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_FRAMESIZE = 1456;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final boolean debug = false;
/*     */ 
/*     */ 
/*     */   
/*  82 */   private byte[] pendingData = new byte[131072];
/*  83 */   private int pendingDataSize = 0;
/*  84 */   private int pendingDataOffset = 0;
/*     */   
/*     */   private boolean expectingSameInputBuffer = false;
/*     */   private boolean inputEOM = false;
/*     */   private boolean setMark = true;
/*     */   private boolean resetTime = true;
/*  90 */   private int frameSize = 0;
/*  91 */   private int frameOffset = 0;
/*  92 */   private long frameCount = 0L;
/*     */   
/*  94 */   private int packetSize = 0;
/*  95 */   private long packetSeq = 0L;
/*  96 */   private long currentTime = 1L;
/*  97 */   private long deltaTime = 0L;
/*     */   
/*  99 */   private MPAHeader mpaHeader = null;
/* 100 */   private MPAParse mpaParse = new MPAParse();
/*     */ 
/*     */   
/*     */   public Packetizer() {
/* 104 */     this.packetSize = 1456;
/* 105 */     ((BasicCodec)this).inputFormats = (Format[])new AudioFormat[] { new AudioFormat("mpeglayer3", 16000.0D, -1, -1, -1, 1), new AudioFormat("mpeglayer3", 22050.0D, -1, -1, -1, 1), new AudioFormat("mpeglayer3", 24000.0D, -1, -1, -1, 1), new AudioFormat("mpeglayer3", 32000.0D, -1, -1, -1, 1), new AudioFormat("mpeglayer3", 44100.0D, -1, -1, -1, 1), new AudioFormat("mpeglayer3", 48000.0D, -1, -1, -1, 1), new AudioFormat("mpegaudio", 16000.0D, -1, -1, -1, 1), new AudioFormat("mpegaudio", 22050.0D, -1, -1, -1, 1), new AudioFormat("mpegaudio", 24000.0D, -1, -1, -1, 1), new AudioFormat("mpegaudio", 32000.0D, -1, -1, -1, 1), new AudioFormat("mpegaudio", 44100.0D, -1, -1, -1, 1), new AudioFormat("mpegaudio", 48000.0D, -1, -1, -1, 1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 179 */     ((BasicCodec)this).outputFormats = (Format[])new AudioFormat[] { new AudioFormat("mpegaudio/rtp", -1.0D, -1, -1, -1, 1) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 191 */     return "MPEG Audio Packetizer";
/*     */   }
/*     */   
/*     */   public Format[] getSupportedOutputFormats(Format in) {
/* 195 */     if (in == null) {
/* 196 */       return new Format[] { (Format)new AudioFormat("mpegaudio/rtp") };
/*     */     }
/*     */     
/* 199 */     if (BasicPlugIn.matches(in, ((BasicCodec)this).inputFormats) == null) {
/* 200 */       return new Format[1];
/*     */     }
/*     */     
/* 203 */     if (!(in instanceof AudioFormat)) {
/* 204 */       return new Format[] { (Format)new AudioFormat("mpegaudio/rtp") };
/*     */     }
/*     */     
/* 207 */     return getMatchingOutputFormats(in);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Format[] getMatchingOutputFormats(Format in) {
/* 213 */     AudioFormat af = (AudioFormat)in;
/*     */     
/* 215 */     ((BasicCodec)this).outputFormats = (Format[])new AudioFormat[] { new AudioFormat("mpegaudio/rtp", af.getSampleRate(), af.getSampleSizeInBits(), af.getChannels(), af.getEndian(), 1, af.getFrameSizeInBits(), af.getFrameRate(), Format.byteArray) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 226 */     return ((BasicCodec)this).outputFormats;
/*     */   }
/*     */   
/*     */   public void open() throws ResourceUnavailableException {
/* 230 */     setPacketSize(this.packetSize);
/* 231 */     reset();
/* 232 */     this.currentTime = 1L;
/* 233 */     this.packetSeq = 0L;
/* 234 */     this.resetTime = true;
/*     */   }
/*     */   
/*     */   public synchronized void reset() {
/* 238 */     super.reset();
/* 239 */     this.mpaParse.reset();
/* 240 */     resetPendingData();
/* 241 */     this.state = 0;
/* 242 */     this.setMark = true;
/* 243 */     this.expectingSameInputBuffer = false;
/* 244 */     this.frameSize = 0;
/* 245 */     this.frameOffset = 0;
/* 246 */     this.frameCount = 0L;
/* 247 */     this.resetTime = true;
/* 248 */     this.deltaTime = 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int process(Buffer inputBuffer, Buffer outputBuffer) {
/* 259 */     if (inputBuffer.isDiscard()) {
/* 260 */       updateOutput(outputBuffer, ((BasicCodec)this).outputFormat, 0, 0);
/* 261 */       outputBuffer.setDiscard(true);
/* 262 */       return 0;
/*     */     } 
/*     */     try {
/* 265 */       int rc = doProcess(inputBuffer, outputBuffer);
/* 266 */       if (rc != 4) {
/* 267 */         outputBuffer.setSequenceNumber(this.packetSeq++);
/* 268 */         outputBuffer.setTimeStamp(this.currentTime);
/*     */       } 
/* 270 */       if (this.inputEOM) {
/* 271 */         if (outputBuffer.getLength() == 0) {
/* 272 */           propagateEOM(outputBuffer);
/* 273 */           outputBuffer.setSequenceNumber(this.packetSeq++);
/* 274 */           this.mpaParse.reset();
/* 275 */           resetPendingData();
/* 276 */           this.state = 0;
/* 277 */           return 0;
/*     */         } 
/* 279 */         if (rc == 4) {
/* 280 */           outputBuffer.setSequenceNumber(this.packetSeq++);
/* 281 */           outputBuffer.setTimeStamp(this.currentTime);
/*     */         } 
/* 283 */         rc = 2;
/* 284 */         this.expectingSameInputBuffer = true;
/*     */       }
/* 286 */       else if (this.pendingDataSize <= 1738) {
/* 287 */         rc &= 0xFFFFFFFD;
/* 288 */         shiftPendingData();
/*     */       } 
/* 290 */       return rc;
/*     */     } catch (Exception ex) {
/* 292 */       ex.printStackTrace();
/*     */       
/* 294 */       return 1;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected int doProcess(Buffer inputBuffer, Buffer outputBuffer) {
/* 299 */     if (!checkInputBuffer(inputBuffer)) {
/* 300 */       return 1;
/*     */     }
/*     */     
/* 303 */     this.inputEOM = false;
/* 304 */     if (isEOM(inputBuffer)) {
/* 305 */       if (this.pendingDataSize == 0) {
/* 306 */         propagateEOM(outputBuffer);
/* 307 */         this.mpaParse.reset();
/* 308 */         resetPendingData();
/* 309 */         this.state = 0;
/* 310 */         return 0;
/*     */       } 
/* 312 */       this.inputEOM = true;
/*     */     } 
/*     */     
/* 315 */     byte[] inData = (byte[])inputBuffer.getData();
/* 316 */     int inOffset = inputBuffer.getOffset();
/* 317 */     int inLength = inputBuffer.getLength();
/* 318 */     if (!this.expectingSameInputBuffer) {
/* 319 */       if (inLength > 0 && inData != null) {
/* 320 */         if (this.resetTime) {
/*     */ 
/*     */           
/* 323 */           this.currentTime = inputBuffer.getTimeStamp();
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 328 */           if (this.currentTime == 0L)
/* 329 */             this.currentTime = 1L; 
/* 330 */           this.resetTime = false;
/*     */         } 
/* 332 */         if (inLength > this.pendingData.length - this.pendingDataSize) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 338 */           this.mpaParse.reset();
/* 339 */           resetPendingData();
/*     */         } 
/* 341 */         System.arraycopy(inData, inOffset, this.pendingData, this.pendingDataOffset + this.pendingDataSize, inLength);
/*     */ 
/*     */         
/* 344 */         this.pendingDataSize += inLength;
/* 345 */       } else if (!this.inputEOM) {
/*     */         
/* 347 */         return 4;
/*     */       } 
/* 349 */       this.expectingSameInputBuffer = true;
/*     */     } 
/* 351 */     if (this.mpaHeader == null) {
/* 352 */       this.mpaHeader = getMPAHeader(this.pendingData, this.pendingDataOffset, this.pendingDataSize);
/*     */     }
/* 354 */     switch (this.state) {
/*     */       case 0:
/* 356 */         return newFrameNewBuffer(outputBuffer);
/*     */       case 1:
/* 358 */         return continueFrameInBuffer(outputBuffer);
/*     */       case 2:
/* 360 */         return continueFrameNewBuffer(outputBuffer);
/*     */       case 3:
/* 362 */         return newFrameInBuffer(outputBuffer);
/*     */     } 
/* 364 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int continueFrameNewBuffer(Buffer outputBuffer) {
/* 370 */     int copyLen = Math.min(this.pendingDataSize, this.frameSize - this.frameOffset);
/* 371 */     checkMPAHeader(this.pendingData, this.pendingDataOffset, this.pendingDataSize);
/* 372 */     if (this.mpaHeader != null && 
/* 373 */       this.mpaHeader.headerOffset == this.pendingDataOffset) {
/*     */       
/* 375 */       this.state = 0;
/* 376 */       return newFrameNewBuffer(outputBuffer);
/*     */     } 
/*     */     
/* 379 */     copyLen = Math.min(copyLen, this.packetSize - 4);
/* 380 */     setStartOfBuffer(outputBuffer, this.frameOffset);
/*     */     
/* 382 */     if (!copyBuffer(this.pendingData, this.pendingDataOffset, copyLen, outputBuffer)) {
/*     */       
/* 384 */       this.state = 0;
/* 385 */       return 1;
/*     */     } 
/*     */     
/* 388 */     this.frameOffset += copyLen;
/* 389 */     outputBuffer.setTimeStamp(this.currentTime);
/* 390 */     outputBuffer.setFormat(((BasicCodec)this).outputFormat);
/*     */ 
/*     */     
/* 393 */     if (copyLen < this.pendingDataSize) {
/* 394 */       this.pendingDataOffset += copyLen;
/* 395 */       this.pendingDataSize -= copyLen;
/* 396 */       if (this.frameOffset >= this.frameSize || (this.mpaHeader != null && this.mpaHeader.headerOffset == this.pendingDataOffset))
/*     */       {
/*     */         
/* 399 */         this.state = 0; } 
/* 400 */       return 2;
/*     */     } 
/*     */     
/* 403 */     this.pendingDataOffset += copyLen;
/* 404 */     this.pendingDataSize -= copyLen;
/* 405 */     shiftPendingData();
/* 406 */     if (!isOutputBufferFull(outputBuffer)) {
/* 407 */       this.state = 1;
/* 408 */       return 4;
/*     */     } 
/* 410 */     return 0;
/*     */   }
/*     */   
/*     */   protected int continueFrameInBuffer(Buffer outputBuffer) {
/* 414 */     checkMPAHeader(this.pendingData, this.pendingDataOffset, this.pendingDataSize);
/* 415 */     int copyLen = Math.min(this.pendingDataSize, this.frameSize - this.frameOffset);
/* 416 */     if (this.mpaHeader != null && 
/* 417 */       this.mpaHeader.headerOffset == this.pendingDataOffset) {
/*     */       
/* 419 */       this.state = 3;
/* 420 */       return newFrameInBuffer(outputBuffer);
/*     */     } 
/*     */     
/* 423 */     copyLen = Math.min(copyLen, this.packetSize - outputBuffer.getLength());
/*     */     
/* 425 */     if (!copyBuffer(this.pendingData, this.pendingDataOffset, copyLen, outputBuffer)) {
/*     */       
/* 427 */       this.state = 0;
/* 428 */       return 1;
/*     */     } 
/* 430 */     this.frameOffset += copyLen;
/*     */     
/* 432 */     outputBuffer.setTimeStamp(this.currentTime);
/* 433 */     outputBuffer.setFormat(((BasicCodec)this).outputFormat);
/*     */ 
/*     */     
/* 436 */     if (copyLen < this.pendingDataSize) {
/* 437 */       this.pendingDataOffset += copyLen;
/* 438 */       this.pendingDataSize -= copyLen;
/* 439 */       if (this.mpaHeader != null && this.mpaHeader.headerOffset == this.pendingDataOffset) {
/*     */ 
/*     */         
/* 442 */         this.state = 3;
/* 443 */         return newFrameInBuffer(outputBuffer);
/*     */       } 
/* 445 */       this.state = 2;
/* 446 */       return 2;
/*     */     } 
/* 448 */     this.pendingDataOffset += copyLen;
/* 449 */     this.pendingDataSize -= copyLen;
/*     */     
/* 451 */     shiftPendingData();
/* 452 */     if (!isOutputBufferFull(outputBuffer)) {
/* 453 */       this.state = 1;
/* 454 */       return 4;
/*     */     } 
/* 456 */     return 0;
/*     */   }
/*     */   
/*     */   protected int newFrameNewBuffer(Buffer outputBuffer) {
/* 460 */     if (this.mpaHeader == null) {
/*     */       
/* 462 */       shiftPendingData();
/* 463 */       return 4;
/*     */     } 
/* 465 */     if (this.mpaHeader.headerOffset != this.pendingDataOffset) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 472 */       this.pendingDataSize += this.pendingDataOffset - this.mpaHeader.headerOffset;
/* 473 */       this.pendingDataOffset = this.mpaHeader.headerOffset;
/*     */     } 
/* 475 */     this.frameSize = this.mpaHeader.bitsInFrame >> 3;
/* 476 */     String encoding = "mpegaudio/rtp";
/* 477 */     AudioFormat af = (AudioFormat)((BasicCodec)this).outputFormat;
/* 478 */     if (af == null || af.getEncoding() != encoding || af.getSampleRate() != this.mpaHeader.samplingRate || af.getChannels() != this.mpaHeader.nChannels) {
/*     */ 
/*     */ 
/*     */       
/* 482 */       int endian = 1;
/* 483 */       if (af != null)
/* 484 */         endian = af.getEndian(); 
/* 485 */       ((BasicCodec)this).outputFormat = (Format)new AudioFormat(encoding, this.mpaHeader.samplingRate, 16, this.mpaHeader.nChannels, endian, 1);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 491 */     setStartOfBuffer(outputBuffer, 0);
/* 492 */     int copyLen = Math.min(this.mpaHeader.bitsInFrame >> 3, this.pendingDataSize);
/* 493 */     copyLen = Math.min(copyLen, this.packetSize - 4);
/*     */     
/* 495 */     if (!copyBuffer(this.pendingData, this.pendingDataOffset, copyLen, outputBuffer)) {
/*     */       
/* 497 */       this.state = 0;
/* 498 */       return 1;
/*     */     } 
/* 500 */     this.frameOffset = copyLen;
/* 501 */     this.frameCount++;
/* 502 */     this.currentTime += this.deltaTime;
/* 503 */     this.deltaTime = this.mpaHeader.nSamples * 1000L * 1000000L / this.mpaHeader.samplingRate;
/*     */     
/* 505 */     outputBuffer.setFormat(((BasicCodec)this).outputFormat);
/* 506 */     outputBuffer.setTimeStamp(this.currentTime);
/*     */     
/* 508 */     if (copyLen < this.pendingDataSize) {
/* 509 */       this.pendingDataOffset += copyLen;
/* 510 */       this.pendingDataSize -= copyLen;
/* 511 */       if (copyLen == this.mpaHeader.bitsInFrame >> 3) {
/*     */         
/* 513 */         this.state = 3;
/* 514 */         this.mpaHeader = getMPAHeader(this.pendingData, this.pendingDataOffset, this.pendingDataSize);
/*     */         
/* 516 */         return newFrameInBuffer(outputBuffer);
/*     */       } 
/* 518 */       this.state = 2;
/* 519 */       this.mpaHeader = null;
/* 520 */       return 2;
/*     */     } 
/* 522 */     this.pendingDataOffset += copyLen;
/* 523 */     this.pendingDataSize -= copyLen;
/* 524 */     if (copyLen == this.mpaHeader.bitsInFrame >> 3) {
/*     */       
/* 526 */       shiftPendingData();
/* 527 */       if (isOutputBufferFull(outputBuffer)) {
/* 528 */         this.state = 0;
/* 529 */         return 0;
/*     */       } 
/* 531 */       this.state = 3;
/* 532 */       return 4;
/*     */     } 
/* 534 */     if (!isOutputBufferFull(outputBuffer)) {
/* 535 */       this.state = 1;
/* 536 */       shiftPendingData();
/* 537 */       return 4;
/*     */     } 
/* 539 */     this.state = 2;
/* 540 */     shiftPendingData();
/* 541 */     return 0;
/*     */   }
/*     */   
/*     */   protected int newFrameInBuffer(Buffer outputBuffer) {
/* 545 */     if (this.mpaHeader == null) {
/*     */       
/* 547 */       this.state = 0;
/* 548 */       shiftPendingData();
/* 549 */       return 0;
/*     */     } 
/*     */     
/* 552 */     if (this.pendingDataSize <= 1738 && !this.inputEOM) {
/* 553 */       this.state = 3;
/* 554 */       shiftPendingData();
/* 555 */       return 4;
/*     */     } 
/* 557 */     if (this.mpaHeader.headerOffset != this.pendingDataOffset) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 564 */       this.pendingDataSize += this.pendingDataOffset - this.mpaHeader.headerOffset;
/* 565 */       this.pendingDataOffset = this.mpaHeader.headerOffset;
/*     */     } 
/* 567 */     int copyLen = this.mpaHeader.bitsInFrame >> 3;
/* 568 */     if (copyLen > this.pendingDataSize) {
/*     */       
/* 570 */       this.state = 3;
/* 571 */       shiftPendingData();
/* 572 */       return 4;
/*     */     } 
/* 574 */     if (copyLen > this.packetSize - outputBuffer.getLength()) {
/*     */       
/* 576 */       this.state = 0;
/* 577 */       return 2;
/*     */     } 
/*     */     
/* 580 */     if (!copyBuffer(this.pendingData, this.pendingDataOffset, copyLen, outputBuffer)) {
/*     */       
/* 582 */       this.state = 0;
/* 583 */       return 2;
/*     */     } 
/* 585 */     this.frameCount++;
/* 586 */     this.deltaTime += this.mpaHeader.nSamples * 1000L * 1000000L / this.mpaHeader.samplingRate;
/*     */ 
/*     */ 
/*     */     
/* 590 */     this.pendingDataOffset += copyLen;
/* 591 */     this.pendingDataSize -= copyLen;
/*     */     
/* 593 */     if (this.pendingDataSize == 0) {
/*     */       
/* 595 */       this.state = 3;
/* 596 */       shiftPendingData();
/* 597 */       return 4;
/*     */     } 
/* 599 */     this.state = 3;
/* 600 */     this.mpaHeader = getMPAHeader(this.pendingData, this.pendingDataOffset, this.pendingDataSize);
/*     */     
/* 602 */     return newFrameInBuffer(outputBuffer);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void shiftPendingData() {
/* 607 */     if (this.pendingDataOffset != 0 && this.pendingDataSize > 0) {
/* 608 */       System.arraycopy(this.pendingData, this.pendingDataOffset, this.pendingData, 0, this.pendingDataSize);
/*     */     }
/* 610 */     this.pendingDataOffset = 0;
/* 611 */     this.expectingSameInputBuffer = false;
/* 612 */     this.mpaHeader = null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void resetPendingData() {
/* 617 */     this.pendingDataSize = 0;
/* 618 */     this.pendingDataOffset = 0;
/* 619 */     this.expectingSameInputBuffer = false;
/* 620 */     this.mpaHeader = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkMPAHeader(byte[] inData, int inOffset, int inLength) {
/* 631 */     int off = inOffset + this.frameSize - this.frameOffset;
/* 632 */     if (this.mpaHeader == null || this.mpaHeader.headerOffset == off) {
/*     */       return;
/*     */     }
/* 635 */     int len = inLength - this.frameSize - this.frameOffset;
/* 636 */     this.mpaHeader = getMPAHeader(inData, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected MPAHeader getMPAHeader(byte[] inData, int inOffset, int inLength) {
/* 642 */     MPAHeader header = new MPAHeader();
/* 643 */     int rc = this.mpaParse.getHeader(header, inData, inOffset, inLength);
/* 644 */     this; if (rc == MPAParse.MPA_OK) {
/* 645 */       return header;
/*     */     }
/* 647 */     this; if (this.inputEOM && rc == MPAParse.MPA_HDR_DOUBTED) {
/* 648 */       return header;
/*     */     }
/* 650 */     return null;
/*     */   }
/*     */   
/*     */   public Object[] getControls() {
/* 654 */     if (((BasicPlugIn)this).controls == null) {
/* 655 */       ((BasicPlugIn)this).controls = (Object[])new javax.media.Control[1];
/* 656 */       ((BasicPlugIn)this).controls[0] = new PacketSizeAdapter((Codec)this, this.packetSize, true);
/*     */     } 
/* 658 */     return ((BasicPlugIn)this).controls;
/*     */   }
/*     */   
/*     */   public synchronized void setPacketSize(int newPacketSize) {
/* 662 */     this.packetSize = newPacketSize;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isOutputBufferFull(Buffer outputBuffer) {
/* 667 */     if (this.packetSize > outputBuffer.getLength() + 40) {
/* 668 */       return false;
/*     */     }
/* 670 */     return true;
/*     */   }
/*     */   
/*     */   private void setStartOfBuffer(Buffer outputBuffer, int frameOff) {
/* 674 */     byte[] outData = (byte[])outputBuffer.getData();
/* 675 */     if (outData == null || this.packetSize > outData.length) {
/*     */       
/* 677 */       outData = new byte[this.packetSize];
/* 678 */       outputBuffer.setData(outData);
/*     */     } 
/* 680 */     outData[0] = 0;
/* 681 */     outData[1] = 0;
/* 682 */     outData[2] = (byte)(frameOff >> 8);
/* 683 */     outData[3] = (byte)frameOff;
/* 684 */     outputBuffer.setOffset(0);
/* 685 */     outputBuffer.setLength(4);
/* 686 */     if (this.setMark) {
/* 687 */       outputBuffer.setFlags(2048);
/* 688 */       this.setMark = false;
/*     */     } else {
/* 690 */       outputBuffer.setFlags(0);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean copyBuffer(byte[] inData, int inOff, int inLen, Buffer outputBuffer) {
/* 696 */     byte[] outData = (byte[])outputBuffer.getData();
/* 697 */     int outOff = outputBuffer.getLength();
/* 698 */     if (outOff + inLen > outData.length) {
/*     */       
/* 700 */       if (outOff + inLen > this.packetSize)
/*     */       {
/* 702 */         return false;
/*     */       }
/* 704 */       byte[] newData = new byte[this.packetSize];
/* 705 */       if (outOff > 0) {
/* 706 */         System.arraycopy(outData, 0, newData, 0, outOff);
/*     */       }
/* 708 */       outData = newData;
/* 709 */       outputBuffer.setData(outData);
/*     */     } 
/* 711 */     System.arraycopy(inData, inOff, outData, outOff, inLen);
/* 712 */     outputBuffer.setLength(outOff + inLen);
/*     */     
/* 714 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\codec\audio\mpa\Packetizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */