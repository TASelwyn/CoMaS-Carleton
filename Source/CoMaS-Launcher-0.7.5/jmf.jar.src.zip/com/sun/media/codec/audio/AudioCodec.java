/*    */ package com.sun.media.codec.audio;
/*    */ 
/*    */ import com.sun.media.BasicCodec;
/*    */ import com.sun.media.BasicPlugIn;
/*    */ import javax.media.Format;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AudioCodec
/*    */   extends BasicCodec
/*    */ {
/*    */   public Format setInputFormat(Format format) {
/* 17 */     if (BasicPlugIn.matches(format, this.inputFormats) == null)
/* 18 */       return null; 
/* 19 */     this.inputFormat = format;
/* 20 */     return format;
/*    */   }
/*    */ 
/*    */   
/*    */   public Format setOutputFormat(Format format) {
/* 25 */     if (BasicPlugIn.matches(format, getSupportedOutputFormats(this.inputFormat)) == null)
/* 26 */       return null; 
/* 27 */     if (!(format instanceof javax.media.format.AudioFormat))
/* 28 */       return null; 
/* 29 */     this.outputFormat = format;
/* 30 */     return format;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean checkFormat(Format format) {
/* 40 */     if (this.inputFormat == null || this.outputFormat == null || format != this.inputFormat || !format.equals(this.inputFormat)) {
/*    */ 
/*    */ 
/*    */       
/* 44 */       this.inputFormat = format;
/* 45 */       Format[] fs = getSupportedOutputFormats(format);
/* 46 */       this.outputFormat = fs[0];
/*    */     } 
/* 48 */     return (this.outputFormat != null);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\codec\audio\AudioCodec.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */