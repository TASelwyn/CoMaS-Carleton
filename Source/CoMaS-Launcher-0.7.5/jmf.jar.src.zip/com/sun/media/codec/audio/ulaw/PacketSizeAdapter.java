package com.sun.media.codec.audio.ulaw;

import com.sun.media.controls.PacketSizeAdapter;
import javax.media.Codec;

class PacketSizeAdapter extends PacketSizeAdapter {
  public PacketSizeAdapter(Codec newOwner, int newPacketSize, boolean newIsSetable) {
    super(newOwner, newPacketSize, newIsSetable);
  }
  
  public int setPacketSize(int numBytes) {
    int numOfPackets = numBytes;
    if (numOfPackets < 10)
      numOfPackets = 10; 
    if (numOfPackets > 8000)
      numOfPackets = 8000; 
    this.packetSize = numOfPackets;
    ((Packetizer)this.owner).setPacketSize(this.packetSize);
    return this.packetSize;
  }
}
