package com.sun.media.codec.audio.msadpcm;

class MsAdpcmState {
  int index;
  
  int bpred;
  
  int sample1;
  
  int sample2;
}
