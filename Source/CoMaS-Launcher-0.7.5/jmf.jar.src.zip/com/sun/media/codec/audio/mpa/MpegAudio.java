package com.sun.media.codec.audio.mpa;

public class MpegAudio {
  public static native boolean nGetHeader(byte[] paramArrayOfbyte, int paramInt, MPAHeader paramMPAHeader);
  
  public static native int nOpen(int[] paramArrayOfint);
  
  public static native boolean nClose(int paramInt);
  
  public static native boolean nConvert(int paramInt1, byte[] paramArrayOfbyte1, int paramInt2, int paramInt3, byte[] paramArrayOfbyte2, int paramInt4, int paramInt5, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt6, int[] paramArrayOfint3);
}
