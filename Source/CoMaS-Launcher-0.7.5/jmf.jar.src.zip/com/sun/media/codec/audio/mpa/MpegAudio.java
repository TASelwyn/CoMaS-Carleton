package com.sun.media.codec.audio.mpa;

public class MpegAudio {
  public static native boolean nGetHeader(byte[] paramArrayOfbyte, int paramInt, MPAHeader paramMPAHeader);
  
  public static native int nOpen(int[] paramArrayOfint);
  
  public static native boolean nClose(int paramInt);
  
  public static native boolean nConvert(int paramInt1, byte[] paramArrayOfbyte1, int paramInt2, int paramInt3, byte[] paramArrayOfbyte2, int paramInt4, int paramInt5, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt6, int[] paramArrayOfint3);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\codec\audio\mpa\MpegAudio.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */