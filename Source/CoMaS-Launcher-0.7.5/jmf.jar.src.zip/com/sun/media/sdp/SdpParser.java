/*    */ package com.sun.media.sdp;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SdpParser
/*    */   extends Parser
/*    */ {
/*    */   public SessionDescription sessionDescription;
/*    */   public Vector mediaDescriptions;
/*    */   
/*    */   public SdpParser(byte[] data) {
/* 17 */     init();
/*    */     
/* 19 */     ByteArrayInputStream bin = new ByteArrayInputStream(data);
/*    */     
/* 21 */     parseData(bin);
/*    */   }
/*    */   
/*    */   public void parseData(ByteArrayInputStream bin) {
/* 25 */     if (getToken(bin, "v=", true)) {
/* 26 */       this.sessionDescription = new SessionDescription(bin);
/*    */       
/* 28 */       this.mediaDescriptions = new Vector();
/*    */       
/* 30 */       boolean found = getToken(bin, "m=", false);
/*    */       
/* 32 */       while (found) {
/* 33 */         MediaDescription mediaDescription = new MediaDescription(bin, this.sessionDescription.connectionIncluded);
/*    */ 
/*    */         
/* 36 */         this.mediaDescriptions.addElement(mediaDescription);
/*    */         
/* 38 */         found = getToken(bin, "m=", false);
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public MediaAttribute getSessionAttribute(String name) {
/* 44 */     MediaAttribute attribute = null;
/*    */     
/* 46 */     if (this.sessionDescription != null) {
/* 47 */       attribute = this.sessionDescription.getSessionAttribute(name);
/*    */     }
/*    */     
/* 50 */     return attribute;
/*    */   }
/*    */   
/*    */   public MediaDescription getMediaDescription(String name) {
/* 54 */     MediaDescription description = null;
/*    */     
/* 56 */     if (this.mediaDescriptions != null) {
/* 57 */       for (int i = 0; i < this.mediaDescriptions.size(); i++) {
/* 58 */         MediaDescription entry = this.mediaDescriptions.elementAt(i);
/*    */ 
/*    */         
/* 61 */         if (entry.name.equals(name)) {
/* 62 */           description = entry;
/*    */           
/*    */           break;
/*    */         } 
/*    */       } 
/*    */     }
/* 68 */     return description;
/*    */   }
/*    */   
/*    */   public Vector getMediaDescriptions() {
/* 72 */     return this.mediaDescriptions;
/*    */   }
/*    */   
/* 75 */   static String input = "v=0\r\no=mhandley 2890844526 2890842807 IN IP4 126.16.64.4\r\ns=SDP Seminar\r\ni=A Seminar on the session description protocol\r\nu=http://www.cs.ucl.ac.uk/staff/M.Handley/sdp.03.ps\r\ne=mjb@isi.edu (Mark Handley)\r\nc=IN IP4 224.2.17.12/127\r\nt=2873397496 2873404696\r\na=recvonly\r\nm=audio 49170 RTP/AVP 0\r\nm=video 51372 RTP/AVP 31\r\nm=application 32416 udp wbr\na=orient:portrait\r\n";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 86 */     new SdpParser(input.getBytes());
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\sdp\SdpParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */