/*     */ package com.sun.media.sdp;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MediaDescription
/*     */   extends Parser
/*     */ {
/*     */   public String name;
/*     */   public String port;
/*     */   public String protocol;
/*     */   public int payload_type;
/*     */   public String payload;
/*     */   public String mediaTitle;
/*     */   public String connectionInfo;
/*     */   public String bandwidthInfo;
/*     */   public String encryptionKey;
/*     */   public Vector mediaAttributes;
/*     */   
/*     */   public MediaDescription(ByteArrayInputStream bin, boolean connectionIncluded) {
/*  28 */     String line = getLine(bin);
/*     */     
/*  30 */     int end = line.indexOf(' ');
/*     */     
/*  32 */     this.name = line.substring(0, end);
/*     */ 
/*     */     
/*  35 */     int start = end + 1;
/*     */     
/*  37 */     end = line.indexOf(' ', start);
/*     */     
/*  39 */     this.port = line.substring(start, end);
/*     */ 
/*     */     
/*  42 */     start = end + 1;
/*     */     
/*  44 */     end = line.indexOf(' ', start);
/*     */     
/*  46 */     this.protocol = line.substring(start, end);
/*     */     
/*  48 */     start = end + 1;
/*     */     
/*  50 */     this.payload = line.substring(start);
/*     */     
/*     */     try {
/*  53 */       this.payload_type = (new Integer(this.payload)).intValue();
/*     */     } catch (Exception e) {
/*  55 */       this.payload_type = -1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  60 */     if (getToken(bin, "i=", false)) {
/*  61 */       this.mediaTitle = getLine(bin);
/*     */       
/*  63 */       System.out.println("media title: " + this.mediaTitle);
/*     */     } 
/*     */ 
/*     */     
/*  67 */     boolean mandatory = true;
/*     */     
/*  69 */     if (connectionIncluded) {
/*  70 */       mandatory = false;
/*     */     }
/*     */     
/*  73 */     if (getToken(bin, "c=", mandatory)) {
/*  74 */       this.connectionInfo = getLine(bin);
/*     */       
/*  76 */       System.out.println("connection info: " + this.connectionInfo);
/*     */     } 
/*     */ 
/*     */     
/*  80 */     if (getToken(bin, "b=", false)) {
/*  81 */       this.bandwidthInfo = getLine(bin);
/*     */       
/*  83 */       System.out.println("bandwidth info: " + this.bandwidthInfo);
/*     */     } 
/*     */ 
/*     */     
/*  87 */     if (getToken(bin, "k=", false)) {
/*  88 */       this.encryptionKey = getLine(bin);
/*     */       
/*  90 */       System.out.println("encryption key: " + this.encryptionKey);
/*     */     } 
/*     */ 
/*     */     
/*  94 */     this.mediaAttributes = new Vector();
/*     */     
/*  96 */     boolean found = getToken(bin, "a=", false);
/*     */     
/*  98 */     while (found) {
/*  99 */       String mediaAttribute = getLine(bin);
/*     */       
/* 101 */       int index = mediaAttribute.indexOf(':');
/*     */       
/* 103 */       if (index > 0) {
/* 104 */         String name = mediaAttribute.substring(0, index);
/* 105 */         String value = mediaAttribute.substring(index + 1);
/*     */         
/* 107 */         MediaAttribute attribute = new MediaAttribute(name, value);
/*     */         
/* 109 */         this.mediaAttributes.addElement(attribute);
/*     */       } 
/*     */       
/* 112 */       found = getToken(bin, "a=", false);
/*     */     } 
/*     */   }
/*     */   
/*     */   public MediaAttribute getMediaAttribute(String name) {
/* 117 */     MediaAttribute attribute = null;
/*     */     
/* 119 */     if (this.mediaAttributes != null) {
/* 120 */       for (int i = 0; i < this.mediaAttributes.size(); i++) {
/* 121 */         MediaAttribute entry = this.mediaAttributes.elementAt(i);
/*     */         
/* 123 */         if (entry.getName().equals(name)) {
/* 124 */           attribute = entry;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/* 130 */     return attribute;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\sdp\MediaDescription.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */