/*     */ package com.sun.media.sdp;
/*     */ 
/*     */ import com.sun.media.Log;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Parser
/*     */ {
/*     */   private static Vector buffer;
/*     */   
/*     */   public void init() {
/*  18 */     buffer = new Vector();
/*     */   }
/*     */   
/*     */   public void ungetToken(String tokenStr) {
/*  22 */     byte[] token = tokenStr.getBytes();
/*     */     
/*  24 */     for (int i = 0; i < token.length; i++) {
/*  25 */       buffer.insertElementAt(new Integer(token[token.length - i - 1]), 0);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean getToken(ByteArrayInputStream bin, String tokenString) {
/*  30 */     boolean found = false;
/*     */     
/*  32 */     ByteArrayOutputStream bout = new ByteArrayOutputStream();
/*     */     
/*  34 */     skipWhitespace(bin);
/*     */     
/*  36 */     if (bin.available() > 0) {
/*  37 */       int ch = readChar(bin);
/*     */       
/*  39 */       while (ch != 61 && ch != 10 && ch != 13 && ch != -1) {
/*  40 */         bout.write(ch);
/*     */         
/*  42 */         ch = readChar(bin);
/*     */       } 
/*     */       
/*  45 */       bout.write(ch);
/*     */     } 
/*     */     
/*  48 */     String token = new String(bout.toByteArray());
/*     */     
/*  50 */     if (tokenString.equals(token)) {
/*  51 */       found = true;
/*     */     } else {
/*  53 */       ungetToken(token);
/*     */     } 
/*     */     
/*  56 */     return found;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getToken(ByteArrayInputStream bin, String tokenString, boolean mandatory) {
/*  61 */     boolean found = getToken(bin, tokenString);
/*     */     
/*  63 */     if (!found && 
/*  64 */       mandatory) {
/*  65 */       Log.warning("[SDP Parser] Token missing: " + tokenString);
/*     */     }
/*     */ 
/*     */     
/*  69 */     return found;
/*     */   }
/*     */   
/*     */   public String getLine(ByteArrayInputStream bin) {
/*  73 */     ByteArrayOutputStream bout = new ByteArrayOutputStream();
/*     */     
/*  75 */     if (bin.available() > 0) {
/*  76 */       int ch = readChar(bin);
/*     */       
/*  78 */       while (ch != 10 && ch != 13 && ch != -1) {
/*  79 */         bout.write(ch);
/*     */         
/*  81 */         ch = readChar(bin);
/*     */       } 
/*     */     } 
/*     */     
/*  85 */     String line = new String(bout.toByteArray());
/*     */     
/*  87 */     return line;
/*     */   }
/*     */   
/*     */   private void skipWhitespace(ByteArrayInputStream bin) {
/*  91 */     int ch = readChar(bin);
/*     */     
/*  93 */     while (ch == 32 || ch == 10 || ch == 13) {
/*  94 */       ch = readChar(bin);
/*     */     }
/*     */     
/*  97 */     buffer.insertElementAt(new Integer(ch), 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int readChar(ByteArrayInputStream bin) {
/*     */     int i;
/* 103 */     if (buffer.size() > 0) {
/* 104 */       i = ((Integer)buffer.elementAt(0)).intValue();
/*     */       
/* 106 */       buffer.removeElementAt(0);
/*     */     } else {
/* 108 */       i = bin.read();
/*     */     } 
/*     */     
/* 111 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\sdp\Parser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */