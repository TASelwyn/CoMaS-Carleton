/*     */ package com.sun.media;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Button;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Label;
/*     */ import java.awt.Panel;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.PlugIn;
/*     */ 
/*     */ public final class BasicJMD extends Panel implements JMD, WindowListener {
/*  21 */   Vector modList = new Vector();
/*  22 */   Vector conList = new Vector();
/*     */   boolean graphic = true;
/*     */   Panel center;
/*     */   Label status;
/*  26 */   Frame frame = null;
/*     */   boolean activated = false;
/*  28 */   Button button = null;
/*  29 */   Dimension preferredSize = new Dimension(512, 140);
/*     */   
/*     */   int ro;
/*     */   
/*     */   int col;
/*     */   
/*     */   int colMax;
/*     */   
/*     */   int roMax;
/*     */   
/*     */   int wrapWidth;
/*     */   int wrapHeight;
/*     */   int offX;
/*     */   int offY;
/*     */   int fill;
/*     */   int cSize;
/*     */   
/*     */   public Component getControlComponent() {
/*  47 */     if (this.button == null) {
/*  48 */       this.button = new Button(this, "PlugIn Viewer") { private final BasicJMD this$0;
/*     */           public void removeNotify() {
/*  50 */             super.removeNotify();
/*  51 */             this.this$0.dispose();
/*     */           } }
/*     */         ;
/*  54 */       this.button.setName("PlugIns");
/*  55 */       this.button.addActionListener(new ActionListener(this) { private final BasicJMD this$0;
/*     */             public void actionPerformed(ActionEvent ae) {
/*  57 */               this.this$0.setVisible(true);
/*     */             } }
/*     */         );
/*     */     } 
/*  61 */     return this.button;
/*     */   }
/*     */   
/*     */   public synchronized void dispose() {
/*  65 */     if (this.frame != null) {
/*  66 */       this.frame.dispose();
/*  67 */       this.frame = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized void setVisible(boolean visible) {
/*  72 */     if (getParent() == null) {
/*  73 */       if (visible && 
/*  74 */         this.frame == null) {
/*  75 */         this.frame = new Frame("PlugIn Viewer");
/*  76 */         this.frame.setLayout(new BorderLayout());
/*  77 */         this.frame.add("Center", this);
/*  78 */         this.frame.addWindowListener(this);
/*  79 */         this.frame.pack();
/*  80 */         this.frame.setVisible(true);
/*     */       }
/*     */     
/*  83 */     } else if (getParent() == this.frame) {
/*  84 */       this.frame.setVisible(visible);
/*     */     } else {
/*  86 */       super.setVisible(visible);
/*     */     } 
/*     */   }
/*     */   
/*  90 */   public BasicJMD(String title) { this.colMax = 1;
/*  91 */     this.roMax = 1;
/*  92 */     this.wrapWidth = 200;
/*  93 */     this.wrapHeight = 50;
/*  94 */     this.offX = 0; this.offY = 0;
/*  95 */     this.fill = 10;
/*  96 */     this.cSize = 10; setLayout(new BorderLayout()); setBackground(Color.lightGray); this.center = new Panel(this) { private final BasicJMD this$0; public Dimension getPreferredSize() { return this.this$0.preferredSize; } }
/*     */       ; this.center.setLayout(null); add("North", this.center); this.status = new Label();
/*     */     add("South", this.status);
/*  99 */     setSize(512, 200); } public void initGraph(BasicModule source) { this.center.removeAll();
/* 100 */     this.modList = new Vector();
/* 101 */     this.conList = new Vector();
/* 102 */     drawGraph(source);
/* 103 */     this.ro = 0;
/* 104 */     this.col = 0;
/* 105 */     this.preferredSize = new Dimension((this.colMax + 1) * this.wrapWidth + this.offX * 2, this.roMax * this.wrapHeight + this.offY * 2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawGraph(BasicModule source) {
/* 116 */     String[] names = source.getOutputConnectorNames();
/* 117 */     int height = names.length;
/* 118 */     if (height == 0)
/* 119 */       height = 1; 
/* 120 */     createModuleWrap(source, this.ro, this.col, height);
/* 121 */     if (this.roMax < names.length)
/* 122 */       this.roMax = names.length; 
/* 123 */     for (int i = 0; i < names.length; i++) {
/* 124 */       OutputConnector oc = source.getOutputConnector(names[i]); InputConnector ic;
/* 125 */       if ((ic = oc.getInputConnector()) == null) {
/* 126 */         if (this.col == 0)
/* 127 */           this.ro++; 
/*     */       } else {
/*     */         Module m;
/* 130 */         if ((m = ic.getModule()) == null) {
/* 131 */           if (this.col == 0) {
/* 132 */             this.ro++;
/*     */           }
/*     */         } else {
/* 135 */           this.col++;
/* 136 */           if (this.col > this.colMax)
/* 137 */             this.colMax = this.col; 
/* 138 */           drawGraph((BasicModule)m);
/* 139 */           this.col--;
/* 140 */           if (this.col == 0)
/* 141 */             this.ro++; 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public void createModuleWrap(BasicModule m, int row, int column, int h) {
/* 147 */     Object plugin = m;
/* 148 */     if (m instanceof BasicSourceModule) {
/* 149 */       plugin = ((BasicSourceModule)m).getDemultiplexer();
/* 150 */     } else if (m instanceof BasicFilterModule) {
/* 151 */       plugin = ((BasicFilterModule)m).getCodec();
/* 152 */     } else if (m instanceof BasicRendererModule) {
/* 153 */       plugin = ((BasicRendererModule)m).getRenderer();
/* 154 */     } else if (m instanceof BasicMuxModule) {
/* 155 */       plugin = ((BasicMuxModule)m).getMultiplexer();
/*     */     } 
/* 157 */     String name = ((PlugIn)plugin).getName();
/*     */     
/* 159 */     Button b = new ModButton(this, name, m, (PlugIn)plugin);
/* 160 */     b.setName("M" + m.hashCode());
/* 161 */     this.modList.addElement(b);
/* 162 */     b.setBackground(new Color(192, 192, 128));
/* 163 */     b.setForeground(Color.black);
/* 164 */     this.center.add(b);
/* 165 */     b.setBounds(this.offX + column * this.wrapWidth + this.fill, this.offY + row * this.wrapHeight + this.fill, this.wrapWidth - this.fill * 2, h * this.wrapHeight - this.fill * 2);
/*     */ 
/*     */     
/* 168 */     b.setVisible(true);
/* 169 */     this.center.invalidate();
/*     */   }
/*     */   
/*     */   public void moduleIn(BasicModule bm, int index, Buffer d, boolean here) {
/* 173 */     updateConnector(bm, index, d, here, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateConnector(BasicModule bm, int index, Buffer d, boolean here, int inOut) {
/* 179 */     if (!this.activated)
/*     */       return; 
/* 181 */     Con c = findConnector(bm, index, inOut);
/* 182 */     if (c == null)
/*     */       return; 
/* 184 */     c.setData(d);
/*     */ 
/*     */     
/* 187 */     if (here)
/* 188 */     { if (d.isEOM()) {
/* 189 */         c.flash(Color.red);
/* 190 */       } else if (d.isDiscard()) {
/* 191 */         c.flash(Color.yellow);
/*     */       } else {
/* 193 */         c.flash(Color.green);
/*     */       }  }
/* 195 */     else { c.flash(Color.gray); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void moduleOut(BasicModule bm, int index, Buffer d, boolean here) {
/* 202 */     updateConnector(bm, index, d, here, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Con findConnector(BasicModule bm, int index, int inOut) {
/* 208 */     String name = "C" + bm.hashCode() + index + inOut;
/* 209 */     Enumeration e = this.conList.elements();
/* 210 */     while (e.hasMoreElements()) {
/* 211 */       Con con = e.nextElement();
/* 212 */       if (con.getName().equals(name)) {
/* 213 */         return con;
/*     */       }
/*     */     } 
/* 216 */     Component m = findModule(bm);
/* 217 */     if (m == null)
/* 218 */       return null; 
/* 219 */     Point p = m.getLocation();
/* 220 */     Con c = new Con(this);
/* 221 */     this.center.add(c);
/* 222 */     c.setBounds(p.x - this.fill + (this.wrapWidth - this.fill) * inOut, p.y + (this.wrapHeight - 2 * this.fill - this.cSize) / 2 + this.wrapHeight * index, this.cSize, this.cSize);
/*     */ 
/*     */     
/* 225 */     c.setName(name);
/* 226 */     this.conList.addElement(c);
/* 227 */     return c;
/*     */   }
/*     */   
/*     */   public Component findModule(BasicModule bm) {
/* 231 */     String name = "M" + bm.hashCode();
/* 232 */     Enumeration e = this.modList.elements();
/* 233 */     while (e.hasMoreElements()) {
/* 234 */       Component c = e.nextElement();
/* 235 */       if (c.getName().equals(name))
/* 236 */         return c; 
/*     */     } 
/* 238 */     return null;
/*     */   }
/*     */   
/*     */   public void windowActivated(WindowEvent we) {
/* 242 */     this.activated = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void windowOpened(WindowEvent we) {}
/*     */ 
/*     */   
/*     */   public void windowIconified(WindowEvent we) {}
/*     */ 
/*     */   
/*     */   public void windowDeiconified(WindowEvent we) {}
/*     */   
/*     */   public void windowClosing(WindowEvent we) {
/* 255 */     setVisible(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void windowClosed(WindowEvent we) {}
/*     */   
/*     */   public void windowDeactivated(WindowEvent we) {
/* 262 */     this.activated = false;
/*     */   }
/*     */ 
/*     */   
/*     */   class ModButton
/*     */     extends Button
/*     */   {
/*     */     BasicModule module;
/*     */     
/*     */     boolean mouseHere;
/*     */     PlugIn plugin;
/*     */     private final BasicJMD this$0;
/*     */     
/*     */     public String cropName(String name) {
/*     */       boolean bool;
/* 277 */       int box_width = 120;
/*     */       
/* 279 */       FontMetrics fm = getFontMetrics(new Font("Dialog", 0, 11));
/*     */       
/* 281 */       String cropped = name;
/*     */       
/* 283 */       int width = fm.stringWidth(cropped);
/*     */       
/* 285 */       if (width > box_width) {
/* 286 */         bool = true;
/*     */       } else {
/* 288 */         bool = false;
/*     */       } 
/*     */       
/* 291 */       while (width > box_width) {
/* 292 */         int length = cropped.length();
/*     */         
/* 294 */         cropped = name.substring(0, length - 1);
/*     */         
/* 296 */         width = fm.stringWidth(cropped);
/*     */       } 
/*     */       
/* 299 */       if (bool) {
/* 300 */         cropped = cropped + "...";
/*     */       }
/*     */       
/* 303 */       return cropped;
/*     */     }
/*     */     public ModButton(BasicJMD this$0, String name, BasicModule m, PlugIn p) {
/* 306 */       this.this$0 = this$0;
/*     */       
/*     */       this.mouseHere = false;
/* 309 */       name = cropName(name);
/*     */       
/* 311 */       setLabel(name);
/*     */       
/* 313 */       this.module = m;
/* 314 */       this.plugin = p;
/*     */       
/* 316 */       addMouseListener((MouseListener)new Object(this));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void updateStatus() {
/* 331 */       this.this$0.status.setText(this.plugin.getClass().getName() + " , " + this.plugin.getName());
/*     */     } }
/*     */   
/*     */   class Con extends Button {
/*     */     Graphics g;
/*     */     Buffer data;
/*     */     boolean mouseHere;
/*     */     private final BasicJMD this$0;
/*     */     
/*     */     public Con(BasicJMD this$0) {
/* 341 */       this.this$0 = this$0; this.g = null; this.data = null; this.mouseHere = false;
/* 342 */       addMouseListener((MouseListener)new Object(this));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void flash(Color c) {
/* 355 */       Graphics g = getGraphics();
/* 356 */       if (g == null)
/*     */         return; 
/* 358 */       g.setColor(c);
/* 359 */       g.fillRect(1, 1, this.this$0.cSize - 2, this.this$0.cSize - 2);
/*     */     }
/*     */ 
/*     */     
/*     */     public Graphics getGraphics() {
/* 364 */       this.g = super.getGraphics();
/* 365 */       return this.g;
/*     */     }
/*     */     
/*     */     public void paint(Graphics g) {
/* 369 */       g.setColor(Color.black);
/* 370 */       g.drawRect(0, 0, this.this$0.cSize - 1, this.this$0.cSize - 1);
/* 371 */       g.setColor(Color.gray);
/* 372 */       g.fillRect(1, 1, this.this$0.cSize - 2, this.this$0.cSize - 2);
/*     */     }
/*     */     
/*     */     public void setData(Buffer d) {
/* 376 */       if (this.mouseHere)
/* 377 */         updateStatus(); 
/* 378 */       this.data = d;
/*     */     }
/*     */     
/*     */     void updateStatus() {
/*     */       String str;
/* 383 */       Format f = this.data.getFormat();
/* 384 */       if (f == null) {
/* 385 */         str = "null";
/*     */       } else {
/* 387 */         str = f.toString();
/* 388 */       }  this.this$0.status.setText(str + ", Length = " + this.data.getLength());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\BasicJMD.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */