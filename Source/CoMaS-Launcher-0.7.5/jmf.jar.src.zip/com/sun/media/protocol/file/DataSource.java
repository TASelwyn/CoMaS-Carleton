package com.sun.media.protocol.file;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import com.sun.media.JMFSecurity;
import com.sun.media.JMFSecurityManager;
import com.sun.media.MimeManager;
import com.sun.media.util.ContentType;
import com.sun.media.util.JMFI18N;
import com.sun.media.util.jdk12;
import com.sun.media.util.jdk12RandomAccessFileAction;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Hashtable;
import javax.media.Duration;
import javax.media.MediaLocator;
import javax.media.Time;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.PullDataSource;
import javax.media.protocol.PullSourceStream;
import javax.media.protocol.Seekable;
import javax.media.protocol.SourceCloneable;

public class DataSource extends PullDataSource implements SourceCloneable {
  private RandomAccessFile raf;
  
  private boolean connected = false;
  
  private long length = -1L;
  
  private String contentType = null;
  
  private PullSourceStream[] pssArray = new PullSourceStream[1];
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] m = new Method[1];
  
  private Class[] cl = new Class[1];
  
  private Object[][] args = new Object[1][0];
  
  private static Hashtable mimeTable;
  
  static {
    try {
      jmfSecurity = JMFSecurityManager.getJMFSecurity();
      securityPrivelege = true;
      mimeTable = MimeManager.getDefaultMimeTable();
    } catch (SecurityException e) {}
  }
  
  public String getContentType() {
    if (!this.connected)
      return null; 
    return this.contentType;
  }
  
  public void connect() throws IOException {
    URL url;
    if (this.connected)
      return; 
    MediaLocator locator = getLocator();
    if (locator == null) {
      System.err.println("medialocator is null");
      throw new IOException(this + ": connect() failed");
    } 
    try {
      url = locator.getURL();
    } catch (MalformedURLException e) {
      System.err.println(getLocator() + ": Don't know how to deal with non-URL locator yet!");
      throw new IOException(this + ": connect() failed");
    } 
    String fileName = getFileName(locator);
    if (jmfSecurity != null) {
      int i = fileName.lastIndexOf(".");
      if (i != -1) {
        String ext = fileName.substring(i + 1).toLowerCase();
        if (!mimeTable.containsKey(ext))
          if (!ext.equalsIgnoreCase("aif"))
            throw new IOException("Permission Denied: From an applet cannot read media file with extension " + ext);  
      } else {
        throw new IOException("For security reasons, from an applet, cannot read a media file with no extension");
      } 
    } 
    try {
      if (jmfSecurity != null)
        try {
          if (jmfSecurity.getName().startsWith("jmf-security")) {
            jmfSecurity.requestPermission(this.m, this.cl, this.args, 2);
            this.m[0].invoke(this.cl[0], this.args[0]);
          } else if (jmfSecurity.getName().startsWith("internet")) {
            PolicyEngine.checkPermission(PermissionID.FILEIO);
            PolicyEngine.assertPermission(PermissionID.FILEIO);
          } 
        } catch (Throwable e) {
          jmfSecurity.permissionFailureNotification(2);
          throw new IOException("No permissions to read file");
        }  
      if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
        try {
          Constructor cons = jdk12RandomAccessFileAction.cons;
          this.raf = (RandomAccessFile)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { fileName, "r" }) });
        } catch (Throwable e) {
          throw new IOException(JMFI18N.getResource("error.filenotfound"));
        } 
      } else {
        this.raf = new RandomAccessFile(fileName, "r");
      } 
      this.length = this.raf.length();
      if (this.length < 0L)
        this.length = -1L; 
      PullSourceStream pss = new RAFPullSourceStream(this);
      this.pssArray[0] = pss;
      URLConnection urlC = url.openConnection();
      try {
        this.contentType = urlC.getContentType();
      } catch (Throwable t) {
        this.contentType = null;
      } 
      this.contentType = ContentType.getCorrectedContentType(this.contentType, locator.getRemainder());
      this.contentType = ContentDescriptor.mimeTypeToPackageName(this.contentType);
      this.connected = true;
    } catch (Throwable e) {
      throw new IOException(JMFI18N.getResource("error.filenotfound"));
    } 
  }
  
  public void disconnect() {
    try {
      if (this.raf != null)
        this.raf.close(); 
    } catch (IOException e) {}
    if (this.pssArray != null)
      this.pssArray[0] = null; 
    this.connected = false;
  }
  
  public void start() throws IOException {}
  
  public void stop() throws IOException {}
  
  public void setLocator(MediaLocator ml) {
    if (ml != null && ml.getProtocol() != null && ml.getProtocol().equals("file")) {
      MediaLocator saved = ml;
      String file = ml.getRemainder();
      boolean changed = false;
      if (file == null) {
        super.setLocator(ml);
        return;
      } 
      try {
        int idx = 0;
        while ((idx = file.indexOf("%", idx)) >= 0) {
          if (file.length() > idx + 2) {
            byte[] bytes = new byte[1];
            try {
              bytes[0] = (byte)Integer.valueOf(file.substring(idx + 1, idx + 3), 16).intValue();
              file = file.substring(0, idx) + new String(bytes) + file.substring(idx + 3);
              changed = true;
            } catch (NumberFormatException ne) {}
          } 
          idx++;
        } 
        if (changed)
          ml = new MediaLocator(ml.getProtocol() + ":" + file); 
      } catch (Exception e) {
        ml = saved;
      } 
    } 
    super.setLocator(ml);
  }
  
  public PullSourceStream[] getStreams() {
    return this.pssArray;
  }
  
  public Time getDuration() {
    return Duration.DURATION_UNKNOWN;
  }
  
  public Object[] getControls() {
    return new Object[0];
  }
  
  public Object getControl(String controlType) {
    return null;
  }
  
  public javax.media.protocol.DataSource createClone() {
    DataSource ds = new DataSource();
    ds.setLocator(getLocator());
    if (this.connected)
      try {
        ds.connect();
      } catch (IOException e) {
        return null;
      }  
    return (javax.media.protocol.DataSource)ds;
  }
  
  class RAFPullSourceStream implements PullSourceStream, Seekable {
    private final DataSource this$0;
    
    RAFPullSourceStream(DataSource this$0) {
      this.this$0 = this$0;
    }
    
    public long seek(long where) {
      try {
        this.this$0.raf.seek(where);
        return tell();
      } catch (IOException e) {
        System.out.println("seek: " + e);
        return -1L;
      } 
    }
    
    public long tell() {
      try {
        return this.this$0.raf.getFilePointer();
      } catch (IOException e) {
        System.out.println("tell: " + e);
        return -1L;
      } 
    }
    
    public boolean isRandomAccess() {
      return true;
    }
    
    public boolean willReadBlock() {
      return false;
    }
    
    public int read(byte[] buffer, int offset, int length) throws IOException {
      return this.this$0.raf.read(buffer, offset, length);
    }
    
    public ContentDescriptor getContentDescriptor() {
      return null;
    }
    
    public long getContentLength() {
      return this.this$0.length;
    }
    
    public boolean endOfStream() {
      return false;
    }
    
    public Object[] getControls() {
      return new Object[0];
    }
    
    public Object getControl(String controlType) {
      return null;
    }
  }
  
  public static String getFileName(MediaLocator locator) {
    try {
      URL url = locator.getURL();
      String fileName = locator.getRemainder();
      String saved = fileName;
      try {
        int idx = 0;
        while ((idx = fileName.indexOf("%", idx)) >= 0) {
          if (fileName.length() > idx + 2) {
            byte[] bytes = new byte[1];
            try {
              bytes[0] = (byte)Integer.valueOf(fileName.substring(idx + 1, idx + 3), 16).intValue();
              fileName = fileName.substring(0, idx) + new String(bytes) + fileName.substring(idx + 3);
            } catch (NumberFormatException ne) {}
          } 
          idx++;
        } 
        idx = 0;
        while ((idx = fileName.indexOf("|")) >= 0) {
          if (idx > 0) {
            fileName = fileName.substring(0, idx) + ":" + fileName.substring(idx + 1);
            continue;
          } 
          fileName = fileName.substring(1);
        } 
        while (fileName.startsWith("///"))
          fileName = fileName.substring(2); 
        if (System.getProperty("os.name").startsWith("Windows"))
          while (fileName.charAt(0) == '/' && fileName.charAt(2) == ':')
            fileName = fileName.substring(1);  
      } catch (Exception e) {
        fileName = saved;
      } 
      return fileName;
    } catch (Throwable t) {
      return null;
    } 
  }
}
