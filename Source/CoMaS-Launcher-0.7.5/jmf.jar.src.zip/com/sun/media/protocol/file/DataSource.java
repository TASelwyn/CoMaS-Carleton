/*     */ package com.sun.media.protocol.file;
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.MimeManager;
/*     */ import com.sun.media.util.ContentType;
/*     */ import com.sun.media.util.JMFI18N;
/*     */ import com.sun.media.util.jdk12;
/*     */ import com.sun.media.util.jdk12RandomAccessFileAction;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.Hashtable;
/*     */ import javax.media.Duration;
/*     */ import javax.media.MediaLocator;
/*     */ import javax.media.Time;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.PullSourceStream;
/*     */ import javax.media.protocol.Seekable;
/*     */ import javax.media.protocol.SourceCloneable;
/*     */ 
/*     */ public class DataSource extends PullDataSource implements SourceCloneable {
/*     */   private RandomAccessFile raf;
/*  28 */   private long length = -1L; private boolean connected = false;
/*  29 */   private String contentType = null;
/*  30 */   private PullSourceStream[] pssArray = new PullSourceStream[1];
/*     */   
/*  32 */   private static JMFSecurity jmfSecurity = null;
/*     */   private static boolean securityPrivelege = false;
/*  34 */   private Method[] m = new Method[1];
/*  35 */   private Class[] cl = new Class[1];
/*  36 */   private Object[][] args = new Object[1][0];
/*     */ 
/*     */ 
/*     */   
/*     */   private static Hashtable mimeTable;
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/*  46 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  47 */       securityPrivelege = true;
/*     */       
/*  49 */       mimeTable = MimeManager.getDefaultMimeTable();
/*  50 */     } catch (SecurityException e) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentType() {
/*  55 */     if (!this.connected)
/*  56 */       return null; 
/*  57 */     return this.contentType;
/*     */   }
/*     */   public void connect() throws IOException {
/*     */     URL url;
/*  61 */     if (this.connected) {
/*     */       return;
/*     */     }
/*  64 */     MediaLocator locator = getLocator();
/*  65 */     if (locator == null) {
/*  66 */       System.err.println("medialocator is null");
/*  67 */       throw new IOException(this + ": connect() failed");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  75 */       url = locator.getURL();
/*     */     } catch (MalformedURLException e) {
/*  77 */       System.err.println(getLocator() + ": Don't know how to deal with non-URL locator yet!");
/*     */       
/*  79 */       throw new IOException(this + ": connect() failed");
/*     */     } 
/*     */     
/*  82 */     String fileName = getFileName(locator);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     if (jmfSecurity != null) {
/*  92 */       int i = fileName.lastIndexOf(".");
/*  93 */       if (i != -1) {
/*  94 */         String ext = fileName.substring(i + 1).toLowerCase();
/*  95 */         if (!mimeTable.containsKey(ext))
/*     */         {
/*  97 */           if (!ext.equalsIgnoreCase("aif"))
/*  98 */             throw new IOException("Permission Denied: From an applet cannot read media file with extension " + ext); 
/*     */         }
/*     */       } else {
/* 101 */         throw new IOException("For security reasons, from an applet, cannot read a media file with no extension");
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 107 */       if (jmfSecurity != null) {
/*     */         try {
/* 109 */           if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 110 */             jmfSecurity.requestPermission(this.m, this.cl, this.args, 2);
/* 111 */             this.m[0].invoke(this.cl[0], this.args[0]);
/* 112 */           } else if (jmfSecurity.getName().startsWith("internet")) {
/* 113 */             PolicyEngine.checkPermission(PermissionID.FILEIO);
/* 114 */             PolicyEngine.assertPermission(PermissionID.FILEIO);
/*     */           }
/*     */         
/* 117 */         } catch (Throwable e) {
/*     */ 
/*     */ 
/*     */           
/* 121 */           jmfSecurity.permissionFailureNotification(2);
/* 122 */           throw new IOException("No permissions to read file");
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 128 */       if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*     */         try {
/* 130 */           Constructor cons = jdk12RandomAccessFileAction.cons;
/*     */           
/* 132 */           this.raf = (RandomAccessFile)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { fileName, "r" }) });
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */         catch (Throwable e) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 142 */           throw new IOException(JMFI18N.getResource("error.filenotfound"));
/*     */         } 
/*     */       } else {
/* 145 */         this.raf = new RandomAccessFile(fileName, "r");
/*     */       } 
/*     */       
/* 148 */       this.length = this.raf.length();
/* 149 */       if (this.length < 0L)
/* 150 */         this.length = -1L; 
/* 151 */       PullSourceStream pss = new RAFPullSourceStream(this);
/* 152 */       this.pssArray[0] = pss;
/*     */ 
/*     */ 
/*     */       
/* 156 */       URLConnection urlC = url.openConnection();
/*     */       try {
/* 158 */         this.contentType = urlC.getContentType();
/*     */       } catch (Throwable t) {
/* 160 */         this.contentType = null;
/*     */       } 
/* 162 */       this.contentType = ContentType.getCorrectedContentType(this.contentType, locator.getRemainder());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 178 */       this.contentType = ContentDescriptor.mimeTypeToPackageName(this.contentType);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 183 */       this.connected = true;
/*     */     } catch (Throwable e) {
/* 185 */       throw new IOException(JMFI18N.getResource("error.filenotfound"));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void disconnect() {
/*     */     try {
/* 193 */       if (this.raf != null) {
/* 194 */         this.raf.close();
/*     */       }
/* 196 */     } catch (IOException e) {}
/*     */     
/* 198 */     if (this.pssArray != null) {
/* 199 */       this.pssArray[0] = null;
/*     */     }
/* 201 */     this.connected = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() throws IOException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() throws IOException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocator(MediaLocator ml) {
/* 215 */     if (ml != null && ml.getProtocol() != null && ml.getProtocol().equals("file")) {
/*     */       
/* 217 */       MediaLocator saved = ml;
/* 218 */       String file = ml.getRemainder();
/* 219 */       boolean changed = false;
/*     */       
/* 221 */       if (file == null) {
/* 222 */         super.setLocator(ml);
/*     */         return;
/*     */       } 
/*     */       try {
/* 226 */         int idx = 0;
/* 227 */         while ((idx = file.indexOf("%", idx)) >= 0) {
/* 228 */           if (file.length() > idx + 2) {
/* 229 */             byte[] bytes = new byte[1];
/*     */             try {
/* 231 */               bytes[0] = (byte)Integer.valueOf(file.substring(idx + 1, idx + 3), 16).intValue();
/*     */               
/* 233 */               file = file.substring(0, idx) + new String(bytes) + file.substring(idx + 3);
/*     */               
/* 235 */               changed = true;
/* 236 */             } catch (NumberFormatException ne) {}
/*     */           } 
/*     */           
/* 239 */           idx++;
/*     */         } 
/* 241 */         if (changed)
/* 242 */           ml = new MediaLocator(ml.getProtocol() + ":" + file); 
/*     */       } catch (Exception e) {
/* 244 */         ml = saved;
/*     */       } 
/*     */     } 
/*     */     
/* 248 */     super.setLocator(ml);
/*     */   }
/*     */   
/*     */   public PullSourceStream[] getStreams() {
/* 252 */     return this.pssArray;
/*     */   }
/*     */   
/*     */   public Time getDuration() {
/* 256 */     return Duration.DURATION_UNKNOWN;
/*     */   }
/*     */   
/*     */   public Object[] getControls() {
/* 260 */     return new Object[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getControl(String controlType) {
/* 265 */     return null;
/*     */   }
/*     */   
/*     */   public javax.media.protocol.DataSource createClone() {
/* 269 */     DataSource ds = new DataSource();
/* 270 */     ds.setLocator(getLocator());
/* 271 */     if (this.connected) {
/*     */       try {
/* 273 */         ds.connect();
/*     */       } catch (IOException e) {
/* 275 */         return null;
/*     */       } 
/*     */     }
/* 278 */     return (javax.media.protocol.DataSource)ds;
/*     */   }
/*     */   class RAFPullSourceStream implements PullSourceStream, Seekable { private final DataSource this$0;
/*     */     RAFPullSourceStream(DataSource this$0) {
/* 282 */       this.this$0 = this$0;
/*     */     }
/*     */     public long seek(long where) {
/*     */       try {
/* 286 */         this.this$0.raf.seek(where);
/* 287 */         return tell();
/*     */       } catch (IOException e) {
/* 289 */         System.out.println("seek: " + e);
/* 290 */         return -1L;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public long tell() {
/*     */       try {
/* 297 */         return this.this$0.raf.getFilePointer();
/*     */       } catch (IOException e) {
/* 299 */         System.out.println("tell: " + e);
/* 300 */         return -1L;
/*     */       } 
/*     */     }
/*     */     
/*     */     public boolean isRandomAccess() {
/* 305 */       return true;
/*     */     }
/*     */     
/*     */     public boolean willReadBlock() {
/* 309 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public int read(byte[] buffer, int offset, int length) throws IOException {
/* 314 */       return this.this$0.raf.read(buffer, offset, length);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ContentDescriptor getContentDescriptor() {
/* 320 */       return null;
/*     */     }
/*     */     
/*     */     public long getContentLength() {
/* 324 */       return this.this$0.length;
/*     */     }
/*     */     
/*     */     public boolean endOfStream() {
/* 328 */       return false;
/*     */     }
/*     */     
/*     */     public Object[] getControls() {
/* 332 */       return new Object[0];
/*     */     }
/*     */     
/*     */     public Object getControl(String controlType) {
/* 336 */       return null;
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getFileName(MediaLocator locator) {
/*     */     try {
/* 343 */       URL url = locator.getURL();
/*     */       
/* 345 */       String fileName = locator.getRemainder();
/*     */       
/* 347 */       String saved = fileName;
/*     */       
/*     */       try {
/* 350 */         int idx = 0;
/* 351 */         while ((idx = fileName.indexOf("%", idx)) >= 0) {
/* 352 */           if (fileName.length() > idx + 2) {
/* 353 */             byte[] bytes = new byte[1];
/*     */             try {
/* 355 */               bytes[0] = (byte)Integer.valueOf(fileName.substring(idx + 1, idx + 3), 16).intValue();
/*     */               
/* 357 */               fileName = fileName.substring(0, idx) + new String(bytes) + fileName.substring(idx + 3);
/*     */             
/*     */             }
/* 360 */             catch (NumberFormatException ne) {}
/*     */           } 
/*     */           
/* 363 */           idx++;
/*     */         } 
/*     */ 
/*     */         
/* 367 */         idx = 0;
/* 368 */         while ((idx = fileName.indexOf("|")) >= 0) {
/* 369 */           if (idx > 0) {
/* 370 */             fileName = fileName.substring(0, idx) + ":" + fileName.substring(idx + 1);
/*     */             continue;
/*     */           } 
/* 373 */           fileName = fileName.substring(1);
/*     */         } 
/*     */ 
/*     */         
/* 377 */         while (fileName.startsWith("///")) {
/* 378 */           fileName = fileName.substring(2);
/*     */         }
/*     */         
/* 381 */         if (System.getProperty("os.name").startsWith("Windows"))
/*     */         {
/* 383 */           while (fileName.charAt(0) == '/' && fileName.charAt(2) == ':') {
/* 384 */             fileName = fileName.substring(1);
/*     */           }
/*     */         }
/*     */       } catch (Exception e) {
/* 388 */         fileName = saved;
/*     */       } 
/* 390 */       return fileName;
/*     */     } catch (Throwable t) {
/* 392 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\protocol\file\DataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */