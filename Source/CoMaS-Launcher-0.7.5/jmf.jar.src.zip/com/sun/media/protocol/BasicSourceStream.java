/*    */ package com.sun.media.protocol;
/*    */ 
/*    */ import javax.media.protocol.ContentDescriptor;
/*    */ import javax.media.protocol.SourceStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BasicSourceStream
/*    */   implements SourceStream
/*    */ {
/* 15 */   protected ContentDescriptor contentDescriptor = null;
/* 16 */   protected long contentLength = -1L;
/* 17 */   protected Object[] controls = new Object[0];
/*    */   
/*    */   public static final int LENGTH_DISCARD = -2;
/*    */   
/*    */   public BasicSourceStream() {}
/*    */   
/*    */   public BasicSourceStream(ContentDescriptor cd, long contentLength) {
/* 24 */     this.contentDescriptor = cd;
/* 25 */     this.contentLength = contentLength;
/*    */   }
/*    */   
/*    */   public ContentDescriptor getContentDescriptor() {
/* 29 */     return this.contentDescriptor;
/*    */   }
/*    */   
/*    */   public long getContentLength() {
/* 33 */     return this.contentLength;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean endOfStream() {
/* 38 */     return false;
/*    */   }
/*    */   
/*    */   public Object[] getControls() {
/* 42 */     return this.controls;
/*    */   }
/*    */   
/*    */   public Object getControl(String controlType) {
/*    */     try {
/* 47 */       Class cls = Class.forName(controlType);
/* 48 */       Object[] cs = getControls();
/* 49 */       for (int i = 0; i < cs.length; i++) {
/* 50 */         if (cls.isInstance(cs[i]))
/* 51 */           return cs[i]; 
/*    */       } 
/* 53 */       return null;
/*    */     } catch (Exception e) {
/*    */       
/* 56 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\protocol\BasicSourceStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */