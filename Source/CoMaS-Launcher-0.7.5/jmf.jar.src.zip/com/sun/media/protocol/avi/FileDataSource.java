/*     */ package com.sun.media.protocol.avi;
/*     */ 
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import com.sun.media.util.ContentType;
/*     */ import com.sun.media.util.JMFI18N;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.media.MediaLocator;
/*     */ import javax.media.Time;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.PullDataSource;
/*     */ import javax.media.protocol.PullSourceStream;
/*     */ import javax.media.protocol.Seekable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FileDataSource
/*     */   extends PullDataSource
/*     */ {
/*     */   private String fileName;
/*     */   private RandomAccessFile raf;
/*     */   private boolean connected = false;
/* 231 */   private long length = -1L;
/* 232 */   private String contentType = null;
/* 233 */   private PullSourceStream[] pssArray = new PullSourceStream[1];
/*     */   
/* 235 */   private static JMFSecurity jmfSecurity = null;
/*     */   private static boolean securityPrivelege = false;
/* 237 */   private Method[] m = new Method[1];
/* 238 */   private Class[] cl = new Class[1];
/* 239 */   private Object[][] args = new Object[1][0];
/*     */   
/*     */   static {
/*     */     try {
/* 243 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/* 244 */       securityPrivelege = true;
/* 245 */     } catch (SecurityException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FileDataSource(String fileName) throws IOException {
/* 251 */     this.fileName = fileName;
/*     */   }
/*     */   
/*     */   public String getContentType() {
/* 255 */     if (!this.connected)
/* 256 */       return null; 
/* 257 */     return this.contentType;
/*     */   }
/*     */   
/*     */   public void connect() throws IOException {
/* 261 */     if (this.connected) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 271 */       if (securityPrivelege && jmfSecurity != null) {
/*     */         try {
/* 273 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 2);
/* 274 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*     */         } catch (Exception e) {
/*     */           
/* 277 */           System.err.println("Unable to get read file privilege  " + e);
/*     */           
/* 279 */           securityPrivelege = false;
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 285 */       this.contentType = ContentType.getCorrectedContentType("content/unknown", this.fileName);
/*     */       
/* 287 */       this.contentType = ContentType.getCorrectedContentType("content/unknown", this.fileName);
/*     */       
/* 289 */       this.contentType = ContentDescriptor.mimeTypeToPackageName(this.contentType);
/*     */       
/* 291 */       System.out.println("contentType is " + this.contentType);
/*     */       
/* 293 */       this.raf = new RandomAccessFile(this.fileName, "r");
/* 294 */       this.length = this.raf.length();
/* 295 */       if (this.length < 0L)
/* 296 */         this.length = -1L; 
/* 297 */       PullSourceStream pss = new RAFPullSourceStream(this);
/* 298 */       this.pssArray[0] = pss;
/*     */       
/* 300 */       this.connected = true;
/*     */     } catch (IOException ioe) {
/* 302 */       throw new IOException(JMFI18N.getResource("error.filenotfound"));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void disconnect() {
/*     */     try {
/* 309 */       if (this.raf != null) {
/* 310 */         this.raf.close();
/*     */       }
/* 312 */     } catch (IOException e) {}
/*     */     
/* 314 */     if (this.pssArray != null) {
/* 315 */       this.pssArray[0] = null;
/*     */     }
/* 317 */     this.connected = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() throws IOException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() throws IOException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocator(MediaLocator ml) {
/* 331 */     if (ml != null && ml.getProtocol() != null && ml.getProtocol().equals("file")) {
/*     */       
/* 333 */       MediaLocator saved = ml;
/* 334 */       String file = ml.getRemainder();
/* 335 */       boolean changed = false;
/*     */       
/* 337 */       if (file == null) {
/* 338 */         super.setLocator(ml);
/*     */         return;
/*     */       } 
/*     */       try {
/* 342 */         int idx = 0;
/* 343 */         while ((idx = file.indexOf("%", idx)) >= 0) {
/* 344 */           if (file.length() > idx + 2) {
/* 345 */             byte[] bytes = new byte[1];
/*     */             try {
/* 347 */               bytes[0] = (byte)Integer.valueOf(file.substring(idx + 1, idx + 3), 16).intValue();
/*     */               
/* 349 */               file = file.substring(0, idx) + new String(bytes) + file.substring(idx + 3);
/*     */               
/* 351 */               changed = true;
/* 352 */             } catch (NumberFormatException ne) {}
/*     */           } 
/*     */           
/* 355 */           idx++;
/*     */         } 
/* 357 */         if (changed)
/* 358 */           ml = new MediaLocator(ml.getProtocol() + ":" + file); 
/*     */       } catch (Exception e) {
/* 360 */         ml = saved;
/*     */       } 
/*     */     } 
/*     */     
/* 364 */     super.setLocator(ml);
/*     */   }
/*     */   
/*     */   public PullSourceStream[] getStreams() {
/* 368 */     return this.pssArray;
/*     */   }
/*     */   
/*     */   public Time getDuration() {
/* 372 */     return null;
/*     */   }
/*     */   
/*     */   public Object[] getControls() {
/* 376 */     return new Object[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getControl(String controlType) {
/* 381 */     return null;
/*     */   }
/*     */   
/*     */   protected String getCorrectedContentType(String contentType) {
/* 385 */     if (contentType != null) {
/* 386 */       if (contentType.equals("audio/wav")) {
/* 387 */         contentType = "audio/x-wav";
/*     */       }
/* 389 */       else if (contentType.equals("audio/aiff")) {
/* 390 */         contentType = "audio/x-aiff";
/*     */       }
/* 392 */       else if (contentType.equals("application/x-troff-msvideo")) {
/*     */ 
/*     */ 
/*     */         
/* 396 */         contentType = "video/x-msvideo";
/* 397 */       } else if (contentType.equals("video/msvideo")) {
/* 398 */         contentType = "video/x-msvideo";
/* 399 */       } else if (contentType.equals("audio/x-mpegaudio")) {
/* 400 */         contentType = "audio/mpeg";
/* 401 */       } else if (contentType.equals("content/unknown")) {
/*     */ 
/*     */         
/* 404 */         String type = guessContentType(getLocator());
/* 405 */         if (type != null)
/* 406 */           contentType = type; 
/*     */       } 
/*     */     } else {
/* 409 */       contentType = "content/unknown";
/*     */     } 
/* 411 */     return contentType;
/*     */   }
/*     */ 
/*     */   
/*     */   private String guessContentType(MediaLocator locator) {
/* 416 */     String path = locator.getRemainder();
/* 417 */     int i = path.lastIndexOf(".");
/* 418 */     if (i != -1) {
/* 419 */       String ext = path.substring(i + 1).toLowerCase();
/*     */       
/* 421 */       if (ext.equals("mov"))
/* 422 */         return "video/quicktime"; 
/* 423 */       if (ext.equals("avi"))
/* 424 */         return "video/x_msvideo"; 
/* 425 */       if (ext.equals("mpg"))
/* 426 */         return "video/mpeg"; 
/* 427 */       if (ext.equals("mpv"))
/* 428 */         return "video/mpeg"; 
/* 429 */       if (ext.equals("viv"))
/* 430 */         return "video/vivo"; 
/* 431 */       if (ext.equals("au"))
/* 432 */         return "audio/basic"; 
/* 433 */       if (ext.equals("wav"))
/* 434 */         return "audio/x_wav"; 
/* 435 */       if (ext.equals("mid") || ext.equals("midi"))
/* 436 */         return "audio/midi"; 
/* 437 */       if (ext.equals("rmf"))
/* 438 */         return "audio/rmf"; 
/* 439 */       if (ext.equals("gsm"))
/* 440 */         return "audio/x_gsm"; 
/* 441 */       if (ext.equals("mp2"))
/* 442 */         return "audio/mpeg"; 
/* 443 */       if (ext.equals("mp3"))
/* 444 */         return "audio/mpeg"; 
/* 445 */       if (ext.equals("mpa"))
/* 446 */         return "audio/mpeg"; 
/* 447 */       if (ext.equals("swf"))
/* 448 */         return "application/x-shockwave-flash"; 
/* 449 */       if (ext.equals("spl"))
/* 450 */         return "application/futuresplash"; 
/*     */     } 
/* 452 */     return null;
/*     */   }
/*     */   class RAFPullSourceStream implements PullSourceStream, Seekable { RAFPullSourceStream(FileDataSource this$0) {
/* 455 */       this.this$0 = this$0;
/*     */     } private final FileDataSource this$0;
/*     */     public long seek(long where) {
/*     */       try {
/* 459 */         this.this$0.raf.seek(where);
/* 460 */         return tell();
/*     */       } catch (IOException e) {
/* 462 */         System.out.println("seek: " + e);
/* 463 */         return -1L;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public long tell() {
/*     */       try {
/* 470 */         return this.this$0.raf.getFilePointer();
/*     */       } catch (IOException e) {
/* 472 */         System.out.println("tell: " + e);
/* 473 */         return -1L;
/*     */       } 
/*     */     }
/*     */     
/*     */     public boolean isRandomAccess() {
/* 478 */       return true;
/*     */     }
/*     */     
/*     */     public boolean willReadBlock() {
/* 482 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public int read(byte[] buffer, int offset, int length) throws IOException {
/* 487 */       return this.this$0.raf.read(buffer, offset, length);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ContentDescriptor getContentDescriptor() {
/* 493 */       return null;
/*     */     }
/*     */     
/*     */     public long getContentLength() {
/* 497 */       return this.this$0.length;
/*     */     }
/*     */     
/*     */     public boolean endOfStream() {
/* 501 */       return false;
/*     */     }
/*     */     
/*     */     public Object[] getControls() {
/* 505 */       return new Object[0];
/*     */     }
/*     */     
/*     */     public Object getControl(String controlType) {
/* 509 */       return null;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\protocol\avi\FileDataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */