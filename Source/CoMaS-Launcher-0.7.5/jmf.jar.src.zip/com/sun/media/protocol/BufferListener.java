package com.sun.media.protocol;

import javax.media.protocol.DataSource;

public interface BufferListener {
  void minThresholdReached(DataSource paramDataSource);
}
