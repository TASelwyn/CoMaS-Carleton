package com.sun.media.protocol.javasound;

import com.sun.media.CircularBuffer;
import com.sun.media.util.LoopThread;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.SystemTimeBase;
import javax.media.protocol.BufferTransferHandler;

class PushThread extends LoopThread {
  private JavaSoundSourceStream sourceStream;
  
  private SystemTimeBase systemTimeBase = new SystemTimeBase();
  
  private long seqNo = 0L;
  
  public PushThread() {
    setName("JavaSound PushThread");
  }
  
  void setSourceStream(JavaSoundSourceStream ss) {
    this.sourceStream = ss;
  }
  
  protected boolean process() {
    Buffer buffer;
    byte[] arrayOfByte;
    CircularBuffer cb = this.sourceStream.cb;
    BufferTransferHandler transferHandler = this.sourceStream.transferHandler;
    synchronized (cb) {
      while (!cb.canWrite()) {
        try {
          cb.wait();
        } catch (Exception e) {}
      } 
      buffer = cb.getEmptyBuffer();
    } 
    if (buffer.getData() instanceof byte[]) {
      arrayOfByte = (byte[])buffer.getData();
    } else {
      arrayOfByte = null;
    } 
    if (arrayOfByte == null || arrayOfByte.length < this.sourceStream.bufSize) {
      arrayOfByte = new byte[this.sourceStream.bufSize];
      buffer.setData(arrayOfByte);
    } 
    int len = this.sourceStream.dataLine.read(arrayOfByte, 0, this.sourceStream.bufSize);
    buffer.setOffset(0);
    buffer.setLength(len);
    buffer.setFormat((Format)this.sourceStream.format);
    buffer.setFlags(0x80 | 0x8000);
    buffer.setSequenceNumber(this.seqNo++);
    buffer.setTimeStamp(this.systemTimeBase.getNanoseconds());
    synchronized (cb) {
      cb.writeReport();
      cb.notify();
      if (transferHandler != null)
        transferHandler.transferData(this.sourceStream); 
    } 
    return true;
  }
}
