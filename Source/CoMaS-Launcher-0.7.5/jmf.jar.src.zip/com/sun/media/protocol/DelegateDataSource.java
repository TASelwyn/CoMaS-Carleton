/*     */ package com.sun.media.protocol;
/*     */ 
/*     */ import com.sun.media.Log;
/*     */ import java.io.IOException;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Duration;
/*     */ import javax.media.Format;
/*     */ import javax.media.MediaLocator;
/*     */ import javax.media.Time;
/*     */ import javax.media.protocol.BufferTransferHandler;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PushBufferDataSource;
/*     */ import javax.media.protocol.PushBufferStream;
/*     */ 
/*     */ 
/*     */ public class DelegateDataSource
/*     */   extends PushBufferDataSource
/*     */   implements Streamable
/*     */ {
/*  21 */   protected String contentType = "raw";
/*     */   
/*     */   protected PushBufferDataSource master;
/*     */   
/*     */   protected DelegateStream[] streams;
/*     */   protected boolean started = false;
/*     */   protected boolean connected = false;
/*     */   
/*     */   public DelegateDataSource(Format[] format) {
/*  30 */     this.streams = new DelegateStream[format.length];
/*  31 */     for (int i = 0; i < format.length; i++) {
/*  32 */       this.streams[i] = new DelegateStream(this, format[i]);
/*     */     }
/*     */     try {
/*  35 */       connect();
/*  36 */     } catch (IOException e) {}
/*     */   }
/*     */   
/*     */   public void setMaster(PushBufferDataSource ds) throws IOException {
/*  40 */     this.master = ds;
/*     */     
/*  42 */     PushBufferStream[] mstrms = ds.getStreams();
/*  43 */     for (int i = 0; i < mstrms.length; i++) {
/*  44 */       for (int k = 0; k < this.streams.length; k++) {
/*  45 */         if (this.streams[k].getFormat().matches(mstrms[i].getFormat())) {
/*  46 */           this.streams[k].setMaster(mstrms[i]);
/*     */         }
/*     */       } 
/*     */     } 
/*  50 */     for (int j = 0; j < mstrms.length; j++) {
/*  51 */       if (this.streams[j].getMaster() == null) {
/*  52 */         Log.error("DelegateDataSource: cannot not find a matching track from the master with this format: " + this.streams[j].getFormat());
/*     */       }
/*     */     } 
/*     */     
/*  56 */     if (this.connected)
/*  57 */       this.master.connect(); 
/*  58 */     if (this.started)
/*  59 */       this.master.start(); 
/*     */   }
/*     */   
/*     */   public DataSource getMaster() {
/*  63 */     return (DataSource)this.master;
/*     */   }
/*     */   
/*     */   public PushBufferStream[] getStreams() {
/*  67 */     return (PushBufferStream[])this.streams;
/*     */   }
/*     */   
/*     */   public MediaLocator getLocator() {
/*  71 */     if (this.master != null)
/*  72 */       return this.master.getLocator(); 
/*  73 */     return null;
/*     */   }
/*     */   
/*     */   public String getContentType() {
/*  77 */     if (!this.connected) {
/*  78 */       System.err.println("Error: DataSource not connected");
/*  79 */       return null;
/*     */     } 
/*  81 */     return this.contentType;
/*     */   }
/*     */   
/*     */   public void connect() throws IOException {
/*  85 */     if (this.connected)
/*     */       return; 
/*  87 */     if (this.master != null)
/*  88 */       this.master.connect(); 
/*  89 */     this.connected = true;
/*     */   }
/*     */   
/*     */   public void disconnect() {
/*     */     try {
/*  94 */       if (this.started)
/*  95 */         stop(); 
/*  96 */     } catch (IOException e) {}
/*  97 */     if (this.master != null)
/*  98 */       this.master.disconnect(); 
/*  99 */     this.connected = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void start() throws IOException {
/* 104 */     if (!this.connected)
/* 105 */       throw new Error("DataSource must be connected before it can be started"); 
/* 106 */     if (this.started)
/*     */       return; 
/* 108 */     if (this.master != null)
/* 109 */       this.master.start(); 
/* 110 */     this.started = true;
/*     */   }
/*     */   
/*     */   public void stop() throws IOException {
/* 114 */     if (!this.connected || !this.started)
/*     */       return; 
/* 116 */     if (this.master != null)
/* 117 */       this.master.stop(); 
/* 118 */     this.started = false;
/*     */   }
/*     */   
/*     */   public Object[] getControls() {
/* 122 */     if (this.master != null)
/* 123 */       return this.master.getControls(); 
/* 124 */     return new Object[0];
/*     */   }
/*     */   
/*     */   public Object getControl(String controlType) {
/* 128 */     if (this.master != null)
/* 129 */       return this.master.getControl(controlType); 
/* 130 */     return null;
/*     */   }
/*     */   
/*     */   public Time getDuration() {
/* 134 */     if (this.master != null)
/* 135 */       return this.master.getDuration(); 
/* 136 */     return Duration.DURATION_UNKNOWN;
/*     */   }
/*     */   
/*     */   public boolean isPrefetchable() {
/* 140 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   class DelegateStream
/*     */     implements PushBufferStream, BufferTransferHandler
/*     */   {
/*     */     Format format;
/*     */     
/*     */     PushBufferStream master;
/*     */     
/*     */     BufferTransferHandler th;
/*     */     private final DelegateDataSource this$0;
/*     */     
/*     */     public DelegateStream(DelegateDataSource this$0, Format format) {
/* 155 */       this.this$0 = this$0;
/* 156 */       this.format = format;
/*     */     }
/*     */     
/*     */     public void setMaster(PushBufferStream master) {
/* 160 */       this.master = master;
/* 161 */       master.setTransferHandler(this);
/*     */     }
/*     */     
/*     */     public PushBufferStream getMaster() {
/* 165 */       return this.master;
/*     */     }
/*     */     
/*     */     public Format getFormat() {
/* 169 */       if (this.master != null)
/* 170 */         return this.master.getFormat(); 
/* 171 */       return this.format;
/*     */     }
/*     */     
/*     */     public ContentDescriptor getContentDescriptor() {
/* 175 */       if (this.master != null)
/* 176 */         return this.master.getContentDescriptor(); 
/* 177 */       return new ContentDescriptor("raw");
/*     */     }
/*     */     
/*     */     public long getContentLength() {
/* 181 */       if (this.master != null)
/* 182 */         return this.master.getContentLength(); 
/* 183 */       return -1L;
/*     */     }
/*     */     
/*     */     public boolean endOfStream() {
/* 187 */       if (this.master != null)
/* 188 */         return this.master.endOfStream(); 
/* 189 */       return false;
/*     */     }
/*     */     
/*     */     public void read(Buffer buffer) throws IOException {
/* 193 */       if (this.master != null)
/* 194 */         this.master.read(buffer); 
/* 195 */       throw new IOException("No data available");
/*     */     }
/*     */     
/*     */     public void setTransferHandler(BufferTransferHandler transferHandler) {
/* 199 */       this.th = transferHandler;
/*     */     }
/*     */     
/*     */     public void transferData(PushBufferStream stream) {
/* 203 */       if (this.th != null)
/* 204 */         this.th.transferData(stream); 
/*     */     }
/*     */     
/*     */     public Object[] getControls() {
/* 208 */       if (this.master != null)
/* 209 */         return this.master.getControls(); 
/* 210 */       return new Object[0];
/*     */     }
/*     */     
/*     */     public Object getControl(String controlType) {
/* 214 */       if (this.master != null)
/* 215 */         return this.master.getControl(controlType); 
/* 216 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\protocol\DelegateDataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */