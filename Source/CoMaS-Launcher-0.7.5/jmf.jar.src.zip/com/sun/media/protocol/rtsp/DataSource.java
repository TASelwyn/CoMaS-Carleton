/*     */ package com.sun.media.protocol.rtsp;
/*     */ 
/*     */ import com.sun.media.protocol.BasicPushBufferDataSource;
/*     */ import java.io.IOException;
/*     */ import javax.media.MediaLocator;
/*     */ import javax.media.Player;
/*     */ import javax.media.protocol.PushBufferStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSource
/*     */   extends BasicPushBufferDataSource
/*     */ {
/*  26 */   private PushBufferStream[] srcStreams = null;
/*     */   private boolean stopped = true;
/*  28 */   Player streamplayer = null;
/*     */ 
/*     */   
/*     */   public DataSource() {
/*  32 */     this.srcStreams = new PushBufferStream[1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PushBufferStream[] getStreams() {
/*  47 */     if (!this.connected)
/*  48 */       return null; 
/*  49 */     return this.srcStreams;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPlayer(Player player) {
/*  54 */     this.streamplayer = player;
/*     */   }
/*     */   
/*     */   public Player getPlayer() {
/*  58 */     return this.streamplayer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSourceStream(PushBufferStream stream) {
/*  63 */     if (this.srcStreams != null) {
/*  64 */       this.srcStreams[0] = stream;
/*     */     }
/*     */   }
/*     */   
/*     */   public void setLocator(MediaLocator mrl) {
/*  69 */     super.setLocator(mrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() throws IOException {
/*  81 */     super.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() throws IOException {
/*  92 */     super.stop();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentType() {
/*  97 */     return "rtsp";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isStarted() {
/* 102 */     return this.started;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect() throws IOException {
/* 115 */     this.connected = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disconnect() {
/* 128 */     this.connected = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getControls() {
/* 140 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setControl(Object control) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getControl(String controlName) {
/* 155 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\protocol\rtsp\DataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */