package com.sun.media.controls;

public interface SliderRegionControl extends AtomicControl {
  long setMaxValue(long paramLong);
  
  long getMaxValue();
  
  long setMinValue(long paramLong);
  
  long getMinValue();
  
  boolean isEnable();
  
  void setEnable(boolean paramBoolean);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\controls\SliderRegionControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */