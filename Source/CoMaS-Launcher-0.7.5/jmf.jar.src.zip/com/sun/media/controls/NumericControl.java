package com.sun.media.controls;

public interface NumericControl extends AtomicControl {
  float getLowerLimit();
  
  float getUpperLimit();
  
  float getValue();
  
  float setValue(float paramFloat);
  
  float getDefaultValue();
  
  float setDefaultValue(float paramFloat);
  
  float getGranularity();
  
  boolean isLogarithmic();
  
  float getLogarithmicBase();
}
