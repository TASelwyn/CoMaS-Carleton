/*     */ package com.sun.media.controls;
/*     */ 
/*     */ import javax.media.Control;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProgressControlAdapter
/*     */   extends AtomicControlAdapter
/*     */   implements ProgressControl
/*     */ {
/*  21 */   Control[] controls = null;
/*  22 */   StringControl frc = null;
/*  23 */   StringControl brc = null;
/*  24 */   StringControl vpc = null;
/*  25 */   StringControl apc = null;
/*  26 */   StringControl ac = null;
/*  27 */   StringControl vc = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProgressControlAdapter(StringControl frameRate, StringControl bitRate, StringControl videoProps, StringControl audioProps, StringControl videoCodec, StringControl audioCodec) {
/*  42 */     super(null, true, null);
/*  43 */     this.frc = frameRate;
/*  44 */     this.brc = bitRate;
/*  45 */     this.vpc = videoProps;
/*  46 */     this.apc = audioProps;
/*  47 */     this.vc = videoCodec;
/*  48 */     this.ac = audioCodec;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringControl getFrameRate() {
/*  59 */     return this.frc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringControl getBitRate() {
/*  66 */     return this.brc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringControl getAudioProperties() {
/*  73 */     return this.apc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringControl getVideoProperties() {
/*  80 */     return this.vpc;
/*     */   }
/*     */   
/*     */   public StringControl getVideoCodec() {
/*  84 */     return this.vc;
/*     */   }
/*     */   
/*     */   public StringControl getAudioCodec() {
/*  88 */     return this.ac;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Control[] getControls() {
/* 100 */     if (this.controls == null) {
/* 101 */       this.controls = new Control[6];
/* 102 */       this.controls[0] = this.frc;
/* 103 */       this.controls[1] = this.brc;
/* 104 */       this.controls[2] = this.vpc;
/* 105 */       this.controls[3] = this.apc;
/* 106 */       this.controls[4] = this.ac;
/* 107 */       this.controls[5] = this.vc;
/*     */     } 
/* 109 */     return this.controls;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\controls\ProgressControlAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */