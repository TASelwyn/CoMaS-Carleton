package com.sun.media.controls;

public interface AudioControl extends GroupControl {
  AtomicControl getOutputPort();
  
  NumericControl getTreble();
  
  NumericControl getBass();
  
  NumericControl getBalance();
}
