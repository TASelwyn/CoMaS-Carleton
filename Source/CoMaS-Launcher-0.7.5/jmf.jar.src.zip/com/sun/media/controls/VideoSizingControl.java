package com.sun.media.controls;

import java.awt.Dimension;
import java.awt.Rectangle;
import javax.media.Control;

public interface VideoSizingControl extends Control {
  boolean supportsAnyScale();
  
  Dimension setVideoSize(Dimension paramDimension);
  
  Dimension getVideoSize();
  
  Dimension getInputVideoSize();
  
  boolean supportsZoom();
  
  float[] getValidZoomFactors();
  
  NumericControl getZoomControl();
  
  boolean supportsClipping();
  
  Rectangle setClipRegion(Rectangle paramRectangle);
  
  Rectangle getClipRegion();
  
  BooleanControl getVideoMute();
}
