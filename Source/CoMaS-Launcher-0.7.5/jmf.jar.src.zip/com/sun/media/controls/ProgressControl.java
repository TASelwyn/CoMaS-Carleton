package com.sun.media.controls;

public interface ProgressControl extends GroupControl {
  StringControl getFrameRate();
  
  StringControl getBitRate();
  
  StringControl getVideoProperties();
  
  StringControl getVideoCodec();
  
  StringControl getAudioCodec();
  
  StringControl getAudioProperties();
}
