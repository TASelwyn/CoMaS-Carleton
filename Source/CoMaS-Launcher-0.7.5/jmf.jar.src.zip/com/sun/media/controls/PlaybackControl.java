package com.sun.media.controls;

public interface PlaybackControl extends GroupControl {
  BooleanControl getPlay();
  
  BooleanControl getStop();
  
  ActionControl getStepForward();
  
  ActionControl getStepBackward();
  
  NumericControl getPlayRate();
  
  NumericControl getSeek();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\controls\PlaybackControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */