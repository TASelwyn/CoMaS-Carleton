package com.sun.media.controls;

public interface VideoFrameControl extends GroupControl {}
