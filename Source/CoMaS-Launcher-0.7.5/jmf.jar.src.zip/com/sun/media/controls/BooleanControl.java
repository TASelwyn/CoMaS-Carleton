package com.sun.media.controls;

public interface BooleanControl extends AtomicControl {
  boolean getValue();
  
  boolean setValue(boolean paramBoolean);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\controls\BooleanControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */