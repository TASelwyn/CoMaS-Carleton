/*    */ package com.sun.media.controls;
/*    */ 
/*    */ import com.sun.media.ui.TextComp;
/*    */ import java.awt.Component;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.media.control.KeyFrameControl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyFrameAdapter
/*    */   implements KeyFrameControl, ActionListener
/*    */ {
/*    */   int preferred;
/*    */   int value;
/*    */   boolean settable;
/* 20 */   TextComp textComp = null;
/*    */   
/*    */   public KeyFrameAdapter(int preferredInterval, boolean settable) {
/* 23 */     this.preferred = preferredInterval;
/* 24 */     this.settable = settable;
/* 25 */     this.value = this.preferred;
/*    */   }
/*    */   
/*    */   public int getKeyFrameInterval() {
/* 29 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public int setKeyFrameInterval(int newValue) {
/* 34 */     if (this.settable) {
/* 35 */       if (newValue < 1) {
/* 36 */         newValue = 1;
/*    */       }
/* 38 */       this.value = newValue;
/* 39 */       if (this.textComp != null) {
/* 40 */         this.textComp.setValue(Integer.toString(this.value));
/*    */       }
/*    */       
/* 43 */       return this.value;
/*    */     } 
/* 45 */     return -1;
/*    */   }
/*    */   
/*    */   public int getPreferredKeyFrameInterval() {
/* 49 */     return this.preferred;
/*    */   }
/*    */   
/*    */   protected String getName() {
/* 53 */     return "Key Frames Every";
/*    */   }
/*    */   
/*    */   public Component getControlComponent() {
/* 57 */     if (this.textComp == null) {
/* 58 */       this.textComp = new TextComp(getName(), Integer.toString(this.value), 3, this.settable);
/*    */ 
/*    */       
/* 61 */       this.textComp.setActionListener(this);
/*    */     } 
/*    */     
/* 64 */     return (Component)this.textComp;
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent ae) {
/* 68 */     int newValue = this.textComp.getIntValue();
/* 69 */     setKeyFrameInterval(newValue);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\controls\KeyFrameAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */