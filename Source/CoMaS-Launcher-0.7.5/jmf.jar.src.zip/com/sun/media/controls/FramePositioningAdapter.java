/*     */ package com.sun.media.controls;
/*     */ 
/*     */ import com.sun.media.Reparentable;
/*     */ import java.awt.Component;
/*     */ import javax.media.Format;
/*     */ import javax.media.Player;
/*     */ import javax.media.Time;
/*     */ import javax.media.Track;
/*     */ import javax.media.control.FramePositioningControl;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FramePositioningAdapter
/*     */   implements FramePositioningControl, Reparentable
/*     */ {
/*     */   Object owner;
/*     */   Player player;
/*     */   
/*     */   public static Track getMasterTrack(Track[] tracks) {
/*  28 */     Track master = null;
/*     */     
/*  30 */     float rate = -1.0F;
/*     */     
/*  32 */     for (int i = 0; i < tracks.length; i++) {
/*     */       Format f;
/*  34 */       if (tracks[i] != null && (f = tracks[i].getFormat()) != null)
/*     */       {
/*     */         
/*  37 */         if (f instanceof VideoFormat) {
/*     */ 
/*     */           
/*  40 */           master = tracks[i];
/*     */           
/*  42 */           if ((rate = ((VideoFormat)f).getFrameRate()) != -1.0F && rate != 0.0F)
/*     */           {
/*     */             
/*  45 */             return master; } 
/*     */         } 
/*     */       }
/*     */     } 
/*  49 */     if (master != null && master.mapTimeToFrame(new Time(0L)) != Integer.MAX_VALUE)
/*     */     {
/*  51 */       return master;
/*     */     }
/*  53 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   Track master = null;
/*  60 */   long frameStep = -1L;
/*     */ 
/*     */   
/*     */   public FramePositioningAdapter(Player p, Track track) {
/*  64 */     this.player = p;
/*  65 */     this.master = track;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  70 */     Format f = track.getFormat();
/*  71 */     if (f instanceof VideoFormat) {
/*  72 */       float rate = ((VideoFormat)f).getFrameRate();
/*  73 */       if (rate != -1.0F && rate != 0.0F) {
/*  74 */         this.frameStep = (long)(1.0E9F / rate);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int seek(int frameNumber) {
/*  85 */     Time seekTo = this.master.mapFrameToTime(frameNumber);
/*  86 */     if (seekTo != null && seekTo != FramePositioningControl.TIME_UNKNOWN) {
/*  87 */       this.player.setMediaTime(seekTo);
/*  88 */       return this.master.mapTimeToFrame(seekTo);
/*     */     } 
/*     */     
/*  91 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int skip(int framesToSkip) {
/* 105 */     if (this.frameStep != -1L) {
/*     */       
/* 107 */       long t = this.player.getMediaNanoseconds() + framesToSkip * this.frameStep;
/* 108 */       this.player.setMediaTime(new Time(t));
/* 109 */       return framesToSkip;
/*     */     } 
/*     */     
/* 112 */     int currentFrame = this.master.mapTimeToFrame(this.player.getMediaTime());
/* 113 */     if (currentFrame != 0 && currentFrame != Integer.MAX_VALUE) {
/*     */       
/* 115 */       int newFrame = seek(currentFrame + framesToSkip);
/* 116 */       return newFrame - currentFrame;
/*     */     } 
/*     */     
/* 119 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Time mapFrameToTime(int frameNumber) {
/* 132 */     return this.master.mapFrameToTime(frameNumber);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int mapTimeToFrame(Time mediaTime) {
/* 146 */     return this.master.mapTimeToFrame(mediaTime);
/*     */   }
/*     */ 
/*     */   
/*     */   public Component getControlComponent() {
/* 151 */     return null;
/*     */   }
/*     */   
/*     */   public Object getOwner() {
/* 155 */     if (this.owner == null) {
/* 156 */       return this;
/*     */     }
/* 158 */     return this.owner;
/*     */   }
/*     */   
/*     */   public void setOwner(Object newOwner) {
/* 162 */     this.owner = newOwner;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\controls\FramePositioningAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */