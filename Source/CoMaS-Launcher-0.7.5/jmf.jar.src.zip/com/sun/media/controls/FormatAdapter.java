/*    */ package com.sun.media.controls;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.media.Format;
/*    */ import javax.media.control.FormatControl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FormatAdapter
/*    */   implements FormatControl, ActionListener
/*    */ {
/*    */   protected Format currentFormat;
/*    */   protected Format[] supportedFormats;
/*    */   protected boolean enabled;
/*    */   protected boolean formattable;
/*    */   protected boolean enableable;
/*    */   
/*    */   public FormatAdapter(Format format, Format[] supported, boolean enabled, boolean formattable, boolean enableable) {
/* 27 */     this.currentFormat = format;
/* 28 */     this.supportedFormats = supported;
/* 29 */     this.enabled = enabled;
/* 30 */     this.formattable = formattable;
/* 31 */     this.enableable = enableable;
/*    */   }
/*    */   
/*    */   public Format getFormat() {
/* 35 */     return this.currentFormat;
/*    */   }
/*    */   
/*    */   public Format setFormat(Format newFormat) {
/* 39 */     if (this.formattable) {
/* 40 */       this.currentFormat = newFormat;
/*    */     }
/* 42 */     return this.currentFormat;
/*    */   }
/*    */   
/*    */   public Format[] getSupportedFormats() {
/* 46 */     return this.supportedFormats;
/*    */   }
/*    */   
/*    */   public boolean isEnabled() {
/* 50 */     return this.enabled;
/*    */   }
/*    */   
/*    */   public void setEnabled(boolean newEnable) {
/* 54 */     if (this.enableable)
/* 55 */       this.enabled = newEnable; 
/*    */   }
/*    */   
/*    */   protected String getName() {
/* 59 */     return "Format";
/*    */   }
/*    */ 
/*    */   
/*    */   public Component getControlComponent() {
/* 64 */     return null;
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent ae) {}
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\controls\FormatAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */