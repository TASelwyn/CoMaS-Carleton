package com.sun.media.controls;

public interface ColorControl extends GroupControl {
  NumericControl getBrightness();
  
  NumericControl getContrast();
  
  NumericControl getSaturation();
  
  NumericControl getHue();
  
  BooleanControl getGrayscale();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\controls\ColorControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */