package com.sun.media.controls;

public interface ColorControl extends GroupControl {
  NumericControl getBrightness();
  
  NumericControl getContrast();
  
  NumericControl getSaturation();
  
  NumericControl getHue();
  
  BooleanControl getGrayscale();
}
