package com.sun.media.controls;

public interface ActionControl extends AtomicControl {
  boolean performAction();
}
