package com.sun.media;

import javax.media.Buffer;

public interface InputConnector extends Connector {
  OutputConnector getOutputConnector();
  
  void setOutputConnector(OutputConnector paramOutputConnector);
  
  boolean isValidBufferAvailable();
  
  Buffer getValidBuffer();
  
  void readReport();
}
