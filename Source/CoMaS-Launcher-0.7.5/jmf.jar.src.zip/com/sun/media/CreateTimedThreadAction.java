/*    */ package com.sun.media;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CreateTimedThreadAction
/*    */   implements PrivilegedAction
/*    */ {
/*    */   private Class objclass;
/*    */   private Class baseClass;
/*    */   private Object arg1;
/*    */   private long nanoseconds;
/*    */   static Constructor cons;
/*    */   
/*    */   static {
/*    */     try {
/* 30 */       cons = CreateTimedThreadAction.class.getConstructor(new Class[] { Class.class, Class.class, Object.class, long.class });
/*    */     }
/* 32 */     catch (Throwable e) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CreateTimedThreadAction(Class objclass, Class baseClass, Object arg1, long nanoseconds) {
/*    */     try {
/* 40 */       this.objclass = objclass;
/* 41 */       this.baseClass = baseClass;
/* 42 */       this.arg1 = arg1;
/* 43 */       this.nanoseconds = nanoseconds;
/* 44 */     } catch (Throwable e) {}
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object run() {
/*    */     try {
/* 51 */       Constructor cons = this.objclass.getConstructor(new Class[] { this.baseClass, long.class });
/* 52 */       Object object = cons.newInstance(new Object[] { this.arg1, new Long(this.nanoseconds) });
/*    */       
/* 54 */       return object;
/*    */     } catch (Throwable e) {
/* 56 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\CreateTimedThreadAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */