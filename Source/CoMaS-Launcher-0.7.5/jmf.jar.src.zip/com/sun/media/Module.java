package com.sun.media;

import javax.media.Controls;
import javax.media.Format;

public interface Module extends Controls {
  String[] getInputConnectorNames();
  
  String[] getOutputConnectorNames();
  
  InputConnector getInputConnector(String paramString);
  
  OutputConnector getOutputConnector(String paramString);
  
  void registerInputConnector(String paramString, InputConnector paramInputConnector);
  
  void registerOutputConnector(String paramString, OutputConnector paramOutputConnector);
  
  void reset();
  
  void connectorPushed(InputConnector paramInputConnector);
  
  String getName();
  
  void setName(String paramString);
  
  void setFormat(Connector paramConnector, Format paramFormat);
  
  void setModuleListener(ModuleListener paramModuleListener);
  
  boolean isInterrupted();
  
  void setJMD(JMD paramJMD);
}
