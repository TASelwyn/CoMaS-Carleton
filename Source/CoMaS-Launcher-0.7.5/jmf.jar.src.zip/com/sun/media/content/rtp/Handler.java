package com.sun.media.content.rtp;

import com.sun.media.BasicController;
import com.sun.media.BasicPlayer;
import com.sun.media.JMFSecurity;
import com.sun.media.Log;
import com.sun.media.protocol.BufferListener;
import com.sun.media.protocol.rtp.DataSource;
import com.sun.media.rtp.RTPMediaLocator;
import com.sun.media.rtp.RTPSessionMgr;
import java.awt.Component;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.util.Vector;
import javax.media.CachingControl;
import javax.media.ClockStartedError;
import javax.media.Control;
import javax.media.Controller;
import javax.media.ControllerEvent;
import javax.media.ControllerListener;
import javax.media.Format;
import javax.media.IncompatibleSourceException;
import javax.media.IncompatibleTimeBaseException;
import javax.media.Manager;
import javax.media.MediaLocator;
import javax.media.NotRealizedError;
import javax.media.Owned;
import javax.media.Player;
import javax.media.SystemTimeBase;
import javax.media.Time;
import javax.media.TimeBase;
import javax.media.control.BufferControl;
import javax.media.format.AudioFormat;
import javax.media.format.FormatChangeEvent;
import javax.media.protocol.DataSource;
import javax.media.rtp.RTPControl;
import javax.media.rtp.RTPManager;
import javax.media.rtp.RTPPushDataSource;
import javax.media.rtp.RTPSocket;
import javax.media.rtp.ReceiveStream;
import javax.media.rtp.ReceiveStreamListener;
import javax.media.rtp.SessionAddress;
import javax.media.rtp.event.NewReceiveStreamEvent;
import javax.media.rtp.event.ReceiveStreamEvent;

public class Handler extends BasicPlayer implements ReceiveStreamListener, BufferListener {
  RTPSessionMgr[] mgrs = null;
  
  DataSource[] sources = null;
  
  Player[] players = null;
  
  Format[] formats = null;
  
  Format[] formatChanged = null;
  
  boolean[] realized = null;
  
  boolean[] dataReady = null;
  
  Vector locators = null;
  
  ControllerListener listener = new PlayerListener(this, this);
  
  boolean playersRealized = false;
  
  Object realizedSync = new Object();
  
  Object closeSync = new Object();
  
  Object dataSync = new Object();
  
  Object stateLock = new Object();
  
  private boolean closed = false;
  
  private boolean audioEnabled = false;
  
  private boolean videoEnabled = false;
  
  private boolean prebuffer = false;
  
  private boolean dataAllReady = false;
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] m = new Method[1];
  
  private Class[] cl = new Class[1];
  
  private Object[][] args = new Object[1][0];
  
  String sessionError;
  
  public Handler() {
    this.sessionError = "cannot create and initialize the RTP session.";
    this.framePositioning = false;
    this.bufferControl = new BC(this);
    ((BasicController)this).stopThreadEnabled = true;
  }
  
  protected boolean doRealize() {
    super.doRealize();
    try {
      if (this.source instanceof RTPSocket) {
        this.mgrs = new RTPSessionMgr[1];
        this.mgrs[1] = new RTPSessionMgr((RTPPushDataSource)this.source);
        this.mgrs[1].addReceiveStreamListener(this);
        this.sources = new DataSource[1];
        this.players = new Player[1];
        this.formats = new Format[1];
        this.realized = new boolean[1];
        this.dataReady = new boolean[1];
        this.formatChanged = new Format[1];
        this.sources[0] = this.source;
        this.dataReady[0] = false;
      } else {
        SessionAddress localAddr = new SessionAddress();
        this.mgrs = new RTPSessionMgr[this.locators.size()];
        this.sources = new DataSource[this.locators.size()];
        this.players = new Player[this.locators.size()];
        this.formats = new Format[this.locators.size()];
        this.realized = new boolean[this.locators.size()];
        this.dataReady = new boolean[this.locators.size()];
        this.formatChanged = new Format[this.locators.size()];
        for (int i = 0; i < this.locators.size(); i++) {
          SessionAddress sessionAddress;
          RTPMediaLocator rml = this.locators.elementAt(i);
          this.realized[i] = false;
          this.mgrs[i] = (RTPSessionMgr)RTPManager.newInstance();
          this.mgrs[i].addReceiveStreamListener(this);
          InetAddress ipAddr = InetAddress.getByName(rml.getSessionAddress());
          if (ipAddr.isMulticastAddress()) {
            localAddr = new SessionAddress(ipAddr, rml.getSessionPort(), rml.getTTL());
            sessionAddress = new SessionAddress(ipAddr, rml.getSessionPort(), rml.getTTL());
          } else {
            localAddr = new SessionAddress(InetAddress.getLocalHost(), rml.getSessionPort());
            sessionAddress = new SessionAddress(ipAddr, rml.getSessionPort());
          } 
          this.mgrs[i].initialize(localAddr);
          if (this.prebuffer) {
            BufferControl bc = (BufferControl)this.mgrs[i].getControl("javax.media.control.BufferControl");
            bc.setBufferLength(this.bufferControl.getBufferLength());
            bc.setMinimumThreshold(this.bufferControl.getMinimumThreshold());
          } 
          this.mgrs[i].addTarget(sessionAddress);
        } 
      } 
    } catch (Exception e) {
      Log.error("Cannot create the RTP Session: " + e.getMessage());
      ((BasicController)this).processError = this.sessionError;
      return false;
    } 
    try {
      synchronized (this.realizedSync) {
        while (!this.playersRealized && !isInterrupted() && !this.closed)
          this.realizedSync.wait(); 
      } 
    } catch (Exception e) {}
    if (this.closed || isInterrupted()) {
      resetInterrupt();
      ((BasicController)this).processError = "no RTP data was received.";
      return false;
    } 
    return true;
  }
  
  protected void completeRealize() {
    ((BasicController)this).state = 300;
    super.completeRealize();
  }
  
  protected void doStart() {
    super.doStart();
    synchronized (this.dataSync) {
      if (this.prebuffer) {
        this.dataAllReady = false;
        for (int j = 0; j < this.dataReady.length; j++) {
          this.dataReady[j] = false;
          ((DataSource)this.sources[j]).flush();
          ((DataSource)this.sources[j]).prebuffer();
        } 
        if (!this.dataAllReady && !this.closed)
          try {
            this.dataSync.wait(3000L);
          } catch (Exception e) {} 
      } 
    } 
    for (int i = 0; i < this.players.length; i++) {
      try {
        if (this.players[i] != null)
          waitForStart(this.players[i]); 
      } catch (Exception e) {}
    } 
  }
  
  protected void doStop() {
    super.doStop();
    synchronized (this.dataSync) {
      if (this.prebuffer)
        this.dataSync.notify(); 
    } 
    for (int i = 0; i < this.players.length; i++) {
      try {
        if (this.players[i] != null)
          waitForStop(this.players[i]); 
      } catch (Exception e) {}
    } 
  }
  
  protected void doDeallocate() {
    for (int i = 0; i < this.players.length; i++) {
      try {
        if (this.players[i] != null)
          this.players[i].deallocate(); 
      } catch (Exception e) {}
    } 
    synchronized (this.realizedSync) {
      this.realizedSync.notify();
    } 
  }
  
  protected void doFailedRealize() {
    synchronized (this.closeSync) {
      for (int i = 0; i < this.mgrs.length; i++) {
        if (this.mgrs[i] != null) {
          this.mgrs[i].removeTargets("Closing session from the RTP Handler");
          this.mgrs[i].dispose();
          this.mgrs[i] = null;
        } 
      } 
    } 
    super.doFailedRealize();
  }
  
  protected void doClose() {
    this.closed = true;
    synchronized (this.realizedSync) {
      this.realizedSync.notify();
    } 
    synchronized (this.dataSync) {
      this.dataSync.notifyAll();
    } 
    stop();
    for (int i = 0; i < this.players.length; i++) {
      try {
        if (this.players[i] != null)
          this.players[i].close(); 
      } catch (Exception e) {}
    } 
    synchronized (this.closeSync) {
      for (int j = 0; j < this.mgrs.length; j++) {
        if (this.mgrs[j] != null) {
          this.mgrs[j].removeTargets("Closing session from the RTP Handler");
          this.mgrs[j].dispose();
          this.mgrs[j] = null;
        } 
      } 
    } 
    super.doClose();
  }
  
  public void setTimeBase(TimeBase tb) throws IncompatibleTimeBaseException {}
  
  protected TimeBase getMasterTimeBase() {
    return (TimeBase)new SystemTimeBase();
  }
  
  public float setRate(float rate) {
    if (getState() < 300)
      throwError((Error)new NotRealizedError("Cannot set rate on an unrealized Player.")); 
    return 1.0F;
  }
  
  public void setStopTime(Time t) {
    controllerSetStopTime(t);
  }
  
  protected void stopAtTime() {
    controllerStopAtTime();
  }
  
  public synchronized void addController(Controller newController) throws IncompatibleTimeBaseException {
    int playerState = getState();
    if (playerState == 600)
      throwError((Error)new ClockStartedError("Cannot add controller to a started player")); 
    if (playerState == 100 || playerState == 200)
      throwError((Error)new NotRealizedError("A Controller cannot be added to an Unrealized Player")); 
    throw new IncompatibleTimeBaseException();
  }
  
  protected boolean audioEnabled() {
    return this.audioEnabled;
  }
  
  protected boolean videoEnabled() {
    return this.videoEnabled;
  }
  
  private void sendMyEvent(ControllerEvent e) {
    sendEvent(e);
  }
  
  public void update(ReceiveStreamEvent event) {
    RTPSessionMgr mgr = (RTPSessionMgr)event.getSource();
    int idx;
    for (idx = 0; idx < this.mgrs.length && 
      this.mgrs[idx] != mgr; idx++);
    if (idx >= this.mgrs.length) {
      System.err.println("Unknown manager: " + mgr);
      return;
    } 
    if (event instanceof javax.media.rtp.event.RemotePayloadChangeEvent) {
      Log.comment("Received an RTP PayloadChangeEvent");
      RTPControl ctl = (RTPControl)this.sources[idx].getControl("javax.media.rtp.RTPControl");
      if (ctl != null)
        this.formatChanged[idx] = ctl.getFormat(); 
      if (this.players[idx] != null) {
        stop();
        waitForClose(this.players[idx]);
      } 
      try {
        this.sources[idx].connect();
        this.players[idx] = Manager.createPlayer(this.sources[idx]);
        if (this.players[idx] == null) {
          Log.error("Could not create player for the new RTP payload.");
          return;
        } 
        this.players[idx].addControllerListener(this.listener);
        this.players[idx].realize();
      } catch (Exception e) {
        Log.error("Could not create player for the new payload.");
      } 
    } 
    if (event instanceof NewReceiveStreamEvent) {
      if (this.players[idx] != null)
        return; 
      ReceiveStream stream = null;
      try {
        stream = ((NewReceiveStreamEvent)event).getReceiveStream();
        this.sources[idx] = stream.getDataSource();
        RTPControl ctl = (RTPControl)this.sources[idx].getControl("javax.media.rtp.RTPControl");
        if (ctl != null) {
          this.formats[idx] = ctl.getFormat();
          if (this.formats[idx] instanceof AudioFormat) {
            this.audioEnabled = true;
          } else if (this.formats[idx] instanceof javax.media.format.VideoFormat) {
            this.videoEnabled = true;
          } 
        } 
        if (this.source instanceof RTPSocket) {
          ((RTPSocket)this.source).setChild(this.sources[idx]);
        } else {
          ((DataSource)this.source).setChild((DataSource)this.sources[idx]);
        } 
        this.players[idx] = Manager.createPlayer(this.sources[idx]);
        if (this.players[idx] == null)
          return; 
        this.players[idx].addControllerListener(this.listener);
        this.players[idx].realize();
        if (this.prebuffer)
          ((DataSource)this.sources[idx]).setBufferListener(this); 
      } catch (Exception e) {
        Log.error("NewReceiveStreamEvent exception " + e.getMessage());
        return;
      } 
    } 
  }
  
  private void waitForStart(Player p) {
    (new StateWaiter(this)).waitForStart(p, true);
  }
  
  private void waitForStop(Player p) {
    (new StateWaiter(this)).waitForStart(p, false);
  }
  
  private void waitForClose(Player p) {
    (new StateWaiter(this)).waitForClose(p);
  }
  
  class StateWaiter implements ControllerListener {
    boolean closeDown;
    
    Object stateLock;
    
    private final Handler this$0;
    
    StateWaiter(Handler this$0) {
      this.this$0 = this$0;
      this.closeDown = false;
      this.stateLock = new Object();
    }
    
    public void waitForStart(Player p, boolean startOn) {
      p.addControllerListener(this);
      if (startOn) {
        p.start();
      } else {
        p.stop();
      } 
      synchronized (this.stateLock) {
        while (((startOn && p.getState() != 600) || (!startOn && p.getState() == 600)) && !this.closeDown) {
          try {
            this.stateLock.wait(1000L);
          } catch (InterruptedException ie) {
            break;
          } 
        } 
      } 
      p.removeControllerListener(this);
    }
    
    public void waitForClose(Player p) {
      p.addControllerListener(this);
      p.close();
      synchronized (this.stateLock) {
        while (!this.closeDown) {
          try {
            this.stateLock.wait(1000L);
          } catch (InterruptedException ie) {
            break;
          } 
        } 
      } 
      p.removeControllerListener(this);
    }
    
    public void controllerUpdate(ControllerEvent ce) {
      if (ce instanceof javax.media.ControllerClosedEvent || ce instanceof javax.media.ControllerErrorEvent)
        this.closeDown = true; 
      synchronized (this.stateLock) {
        this.stateLock.notify();
      } 
    }
  }
  
  public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
    super.setSource(source);
    if (source instanceof DataSource) {
      MediaLocator ml = source.getLocator();
      String mlStr = ml.getRemainder();
      int start = 0;
      while (mlStr.charAt(start) == '/')
        start++; 
      this.locators = new Vector();
      try {
        String str;
        int idx;
        while (start < mlStr.length() && (idx = mlStr.indexOf("&", start)) != -1) {
          str = mlStr.substring(start, idx);
          RTPMediaLocator rml = new RTPMediaLocator("rtp://" + str);
          this.locators.addElement(rml);
          start = idx + 1;
        } 
        if (start != 0) {
          str = mlStr.substring(start);
        } else {
          str = mlStr;
        } 
        RTPMediaLocator rTPMediaLocator = new RTPMediaLocator("rtp://" + str);
        this.locators.addElement(rTPMediaLocator);
      } catch (Exception e) {
        throw new IncompatibleSourceException();
      } 
      if (this.locators.size() > 1)
        this.prebuffer = true; 
    } else if (!(source instanceof RTPSocket)) {
      throw new IncompatibleSourceException();
    } 
    RTPControl ctl = (RTPControl)source.getControl("javax.media.rtp.RTPControl");
    if (ctl != null)
      ctl.addFormat((Format)new AudioFormat("dvi/rtp", 44100.0D, 4, 1), 18); 
  }
  
  private void invalidateComp() {
    this.controlComp = null;
    this.controls = null;
  }
  
  public Component getVisualComponent() {
    super.getVisualComponent();
    for (int i = 0; i < this.players.length; i++) {
      if (this.players[i] != null && this.players[i].getVisualComponent() != null)
        return this.players[i].getVisualComponent(); 
    } 
    return null;
  }
  
  public Control[] getControls() {
    if (this.controls != null)
      return this.controls; 
    Vector cv = new Vector();
    if (this.cachingControl != null)
      cv.addElement(this.cachingControl); 
    if (this.bufferControl != null)
      cv.addElement(this.bufferControl); 
    int size = this.players.length;
    int i;
    for (i = 0; i < size; i++) {
      Player player = this.players[i];
      Control[] arrayOfControl = player.getControls();
      if (arrayOfControl != null)
        for (int j = 0; j < arrayOfControl.length; j++)
          cv.addElement(arrayOfControl[j]);  
    } 
    size = cv.size();
    Control[] ctrls = new Control[size];
    for (i = 0; i < size; i++)
      ctrls[i] = (Control)cv.elementAt(i); 
    if (getState() >= 300)
      this.controls = ctrls; 
    return ctrls;
  }
  
  public void updateStats() {
    for (int i = 0; i < this.players.length; i++) {
      if (this.players[i] != null)
        ((BasicPlayer)this.players[i]).updateStats(); 
    } 
  }
  
  public void minThresholdReached(DataSource ds) {
    boolean ready = true;
    synchronized (this.dataSync) {
      for (int i = 0; i < this.sources.length; i++) {
        if (this.sources[i] == ds) {
          this.dataReady[i] = true;
        } else if (!this.dataReady[i]) {
          ready = false;
        } 
      } 
      if (!ready)
        return; 
      this.dataAllReady = true;
      this.dataSync.notify();
    } 
  }
  
  class PlayerListener implements ControllerListener {
    Handler handler;
    
    private final Handler this$0;
    
    public PlayerListener(Handler this$0, Handler handler) {
      this.this$0 = this$0;
      this.handler = handler;
    }
    
    public synchronized void controllerUpdate(ControllerEvent ce) {
      Player p = (Player)ce.getSourceController();
      if (p == null)
        return; 
      int idx;
      for (idx = 0; idx < this.this$0.players.length && 
        this.this$0.players[idx] != p; idx++);
      if (idx >= this.this$0.players.length) {
        System.err.println("Unknown player: " + p);
        return;
      } 
      if (ce instanceof javax.media.RealizeCompleteEvent) {
        if (this.this$0.formatChanged[idx] != null)
          try {
            this.this$0.invalidateComp();
            FormatChangeEvent f = new FormatChangeEvent((Controller)this.handler, this.this$0.formats[idx], this.this$0.formatChanged[idx]);
            this.handler.sendMyEvent((ControllerEvent)f);
            this.this$0.formats[idx] = this.this$0.formatChanged[idx];
            this.this$0.formatChanged[idx] = null;
          } catch (Exception e) {
            e.getMessage();
          }  
        this.this$0.realized[idx] = true;
        for (int i = 0; i < this.this$0.realized.length; i++) {
          if (!this.this$0.realized[i])
            return; 
        } 
        synchronized (this.this$0.realizedSync) {
          this.this$0.playersRealized = true;
          this.this$0.realizedSync.notifyAll();
        } 
      } 
      if (ce instanceof javax.media.ControllerErrorEvent) {
        this.this$0.players[idx].removeControllerListener(this);
        Log.error("RTP Handler internal error: " + ce);
        this.this$0.players[idx] = null;
      } 
    }
  }
  
  class BC implements BufferControl, Owned {
    long len;
    
    long min;
    
    private final Handler this$0;
    
    BC(Handler this$0) {
      this.this$0 = this$0;
      this.len = -1L;
      this.min = -1L;
    }
    
    public long getBufferLength() {
      if (this.len < 0L)
        return this.this$0.prebuffer ? 750L : 125L; 
      return this.len;
    }
    
    public long setBufferLength(long time) {
      this.len = time;
      Log.comment("RTP Handler buffer length set: " + this.len);
      return this.len;
    }
    
    public long getMinimumThreshold() {
      if (this.min < 0L)
        return this.this$0.prebuffer ? 125L : 0L; 
      return this.min;
    }
    
    public long setMinimumThreshold(long time) {
      this.min = time;
      Log.comment("RTP Handler buffer minimum threshold: " + this.min);
      return this.min;
    }
    
    public void setEnabledThreshold(boolean b) {}
    
    public boolean getEnabledThreshold() {
      return (getMinimumThreshold() > 0L);
    }
    
    public Component getControlComponent() {
      return null;
    }
    
    public Object getOwner() {
      return this.this$0;
    }
  }
}
