/*     */ package com.sun.media.content.audio.midi;
/*     */ import com.sun.media.BasicController;
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.controls.GainControlAdapter;
/*     */ import java.io.IOException;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Control;
/*     */ import javax.media.Controller;
/*     */ import javax.media.ControllerEvent;
/*     */ import javax.media.Duration;
/*     */ import javax.media.IncompatibleSourceException;
/*     */ import javax.media.Time;
/*     */ import javax.media.TimeBase;
/*     */ import javax.media.Track;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PullSourceStream;
/*     */ import javax.sound.midi.InvalidMidiDataException;
/*     */ import javax.sound.midi.MetaMessage;
/*     */ import javax.sound.midi.MidiUnavailableException;
/*     */ import javax.sound.midi.Synthesizer;
/*     */ 
/*     */ public class Handler extends BasicPlayer {
/*  23 */   protected DataSource datasource = null; private MidiController controller;
/*     */   private boolean closed = false;
/*  25 */   private int META_EVENT_END_OF_MEDIA = 47;
/*  26 */   private Control[] controls = null;
/*     */   
/*     */   public Handler() {
/*  29 */     this.controller = new MidiController(this);
/*  30 */     manageController((Controller)this.controller);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
/*  36 */     super.setSource(source);
/*  37 */     this.controller.setSource(source);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean audioEnabled() {
/*  43 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean videoEnabled() {
/*  47 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected TimeBase getMasterTimeBase() {
/*  52 */     return this.controller.getMasterTimeBase();
/*     */   }
/*     */   public void updateStats() {}
/*     */   class MidiController extends BasicController implements MetaEventListener { private Handler.MidiParser midiParser; private Track track; private Buffer buffer; private PullSourceStream stream; private Sequencer sequencer; private Synthesizer synthesizer; protected MidiChannel[] channels; private Sequence sequence; private byte[] mididata; private Handler.MidiFileInputStream is; private Time duration;
/*     */     private GCA gc;
/*     */     private final Handler this$0;
/*     */     
/*     */     MidiController(Handler this$0) {
/*  60 */       this.this$0 = this$0;
/*     */ 
/*     */ 
/*     */       
/*  64 */       this.track = null;
/*  65 */       this.buffer = new Buffer();
/*     */       
/*  67 */       this.sequencer = null;
/*  68 */       this.synthesizer = null;
/*     */       
/*  70 */       this.sequence = null;
/*  71 */       this.mididata = null;
/*  72 */       this.is = null;
/*  73 */       this.duration = Duration.DURATION_UNKNOWN;
/*     */     }
/*     */     
/*     */     protected boolean isConfigurable() {
/*  77 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
/*  84 */       this.midiParser = new Handler.MidiParser(this.this$0);
/*  85 */       this.midiParser.setSource(source);
/*  86 */       this.this$0.datasource = source;
/*     */     }
/*     */ 
/*     */     
/*     */     protected TimeBase getMasterTimeBase() {
/*  91 */       return (TimeBase)new SystemTimeBase();
/*     */     }
/*     */     protected boolean doRealize() {
/*     */       long l1;
/*     */       int i;
/*  96 */       if (this.this$0.datasource == null) {
/*  97 */         return false;
/*     */       }
/*     */       try {
/* 100 */         this.this$0.datasource.start();
/*     */       } catch (IOException e) {
/* 102 */         return false;
/*     */       } 
/* 104 */       this.stream = this.midiParser.getStream();
/*     */       
/* 106 */       long contentLength = this.stream.getContentLength();
/* 107 */       long minLocation = 0L;
/*     */ 
/*     */ 
/*     */       
/* 111 */       minLocation = 0L;
/* 112 */       if (contentLength != -1L) {
/*     */         
/* 114 */         l1 = contentLength;
/* 115 */         i = (int)contentLength;
/*     */       } else {
/* 117 */         l1 = Long.MAX_VALUE;
/* 118 */         i = (int)l1;
/*     */       } 
/*     */       
/* 121 */       int numBuffers = 1;
/* 122 */       this.track = (Track)new BasicTrack(this.midiParser, null, true, Duration.DURATION_UNKNOWN, new Time(0L), numBuffers, i, this.stream, minLocation, l1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 134 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean doPrefetch() {
/* 139 */       if (this.track == null) {
/* 140 */         return false;
/*     */       }
/* 142 */       if (this.sequencer == null) {
/*     */         try {
/* 144 */           this.sequencer = MidiSystem.getSequencer();
/*     */ 
/*     */           
/* 147 */           if (this.sequencer instanceof Synthesizer) {
/* 148 */             this.synthesizer = (Synthesizer)this.sequencer;
/* 149 */             this.channels = this.synthesizer.getChannels();
/*     */           } 
/*     */         } catch (MidiUnavailableException e) {
/*     */           
/* 153 */           return false;
/*     */         } 
/* 155 */         this.sequencer.addMetaEventListener(this);
/*     */       } 
/*     */       
/* 158 */       if (this.buffer.getLength() == 0) {
/*     */         
/* 160 */         this.track.readFrame(this.buffer);
/*     */         
/* 162 */         if (this.buffer.isDiscard() || this.buffer.isEOM()) {
/* 163 */           this.buffer.setLength(0);
/* 164 */           return false;
/*     */         } 
/* 166 */         this.mididata = (byte[])this.buffer.getData();
/*     */         
/* 168 */         this.is = new Handler.MidiFileInputStream(this.this$0, this.mididata, this.buffer.getLength());
/*     */       } 
/*     */ 
/*     */       
/* 172 */       synchronized (this) {
/* 173 */         if (this.is != null) {
/*     */           try {
/* 175 */             this.is.rewind();
/* 176 */           } catch (Exception e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 197 */           return false;
/*     */         } 
/*     */       } 
/*     */       
/*     */       try {
/* 202 */         this.sequencer.open();
/*     */       }
/*     */       catch (MidiUnavailableException e) {
/*     */         
/* 206 */         Log.error("Cannot open sequencer " + e + "\n");
/* 207 */         return false;
/*     */       } catch (Exception e) {
/* 209 */         Log.error("Cannot open sequencer " + e + "\n");
/* 210 */         return false;
/*     */       } 
/*     */       
/*     */       try {
/* 214 */         this.sequencer.setSequence(new BufferedInputStream(this.is));
/* 215 */         long durationNano = this.sequencer.getMicrosecondLength() * 1000L;
/*     */         
/* 217 */         this.duration = new Time(durationNano);
/*     */       } catch (InvalidMidiDataException e) {
/*     */         
/* 220 */         Log.error("Invalid Midi Data " + e + "\n");
/* 221 */         this.sequencer.close();
/* 222 */         return false;
/*     */       } catch (Exception e) {
/* 224 */         Log.error("Error setting sequence " + e + "\n");
/* 225 */         this.sequencer.close();
/* 226 */         return false;
/*     */       } 
/*     */       
/* 229 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void abortRealize() {}
/*     */     
/*     */     protected void abortPrefetch() {
/* 236 */       if (this.sequencer != null && this.sequencer.isOpen()) {
/* 237 */         this.sequencer.close();
/*     */       }
/*     */     }
/*     */     
/*     */     protected void doStart() {
/* 242 */       if (this.sequencer == null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 247 */       if (!this.sequencer.isOpen())
/*     */         return; 
/* 249 */       this.sequencer.start();
/*     */     }
/*     */     
/*     */     protected void doStop() {
/* 253 */       if (this.sequencer == null) {
/*     */         return;
/*     */       }
/* 256 */       this.sequencer.stop();
/*     */       
/* 258 */       sendEvent((ControllerEvent)new StopByRequestEvent((Controller)this, 600, 500, getTargetState(), getMediaTime()));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void doDeallocate() {
/* 267 */       if (this.sequencer == null) {
/*     */         return;
/*     */       }
/* 270 */       synchronized (this) {
/*     */         try {
/* 272 */           this.sequencer.close();
/*     */         
/*     */         }
/*     */         catch (Exception e) {
/*     */ 
/*     */           
/* 278 */           Log.error("Exception when deallocating: " + e + "\n");
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     protected void doClose() {
/* 284 */       if (this.this$0.closed) {
/*     */         return;
/*     */       }
/* 287 */       doDeallocate();
/*     */       
/* 289 */       if (this.this$0.datasource != null) {
/* 290 */         this.this$0.datasource.disconnect();
/*     */       }
/* 292 */       this.this$0.datasource = null;
/* 293 */       this.sequencer.removeMetaEventListener(this);
/* 294 */       this.this$0.closed = true;
/* 295 */       super.doClose();
/*     */     }
/*     */ 
/*     */     
/*     */     protected float doSetRate(float factor) {
/* 300 */       if (this.sequencer != null) {
/* 301 */         this.sequencer.setTempoFactor(factor);
/* 302 */         return this.sequencer.getTempoFactor();
/*     */       } 
/* 304 */       return 1.0F;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected void doSetMediaTime(Time when) {
/* 310 */       if (when != null && this.sequencer != null) {
/* 311 */         this.sequencer.setMicrosecondPosition(when.getNanoseconds() / 1000L);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void meta(MetaMessage me) {
/* 319 */       if (me.getType() != this.this$0.META_EVENT_END_OF_MEDIA) {
/*     */         return;
/*     */       }
/* 322 */       if (this.sequencer != null && this.sequencer.isOpen()) {
/*     */         
/* 324 */         stopControllerOnly();
/* 325 */         this.sequencer.stop();
/* 326 */         if (this.duration == Duration.DURATION_UNKNOWN) {
/* 327 */           this.duration = getMediaTime();
/* 328 */           sendEvent((ControllerEvent)new DurationUpdateEvent((Controller)this, this.duration));
/*     */         } 
/*     */ 
/*     */         
/* 332 */         sendEvent((ControllerEvent)new EndOfMediaEvent((Controller)this, 600, 500, getTargetState(), getMediaTime()));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Time getDuration() {
/* 344 */       return this.duration;
/*     */     }
/*     */     
/*     */     public Control[] getControls() {
/* 348 */       if (this.this$0.controls == null) {
/* 349 */         this.this$0.controls = new Control[1];
/* 350 */         this.gc = new GCA(this);
/* 351 */         this.this$0.controls[0] = (Control)this.gc;
/*     */       } 
/* 353 */       return this.this$0.controls;
/*     */     }
/*     */     
/*     */     public void gainChange(float g) {
/* 357 */       if (this.channels == null || this.gc == null) {
/*     */         return;
/*     */       }
/* 360 */       float level = this.gc.getLevel();
/*     */       
/* 362 */       for (int i = 0; i < this.channels.length; i++) {
/* 363 */         this.channels[i].controlChange(7, (int)(level * 127.0D));
/*     */       }
/*     */     }
/*     */     
/*     */     public void muteChange(boolean muted) {
/* 368 */       if (this.channels == null) {
/*     */         return;
/*     */       }
/* 371 */       for (int i = 0; i < this.channels.length; i++)
/* 372 */         this.channels[i].setMute(muted); 
/*     */     }
/*     */     
/*     */     class GCA extends GainControlAdapter {
/*     */       private final Handler.MidiController this$1;
/*     */       
/*     */       GCA(Handler.MidiController this$1) {
/* 379 */         super(1.0F);
/*     */         this.this$1 = this$1;
/*     */       }
/*     */       public void setMute(boolean mute) {
/* 383 */         super.setMute(mute);
/* 384 */         this.this$1.muteChange(mute);
/*     */       }
/*     */       
/*     */       public float setLevel(float g) {
/* 388 */         float level = super.setLevel(g);
/* 389 */         this.this$1.gainChange(g);
/* 390 */         return level;
/*     */       } } }
/*     */   
/*     */   class MidiParser extends BasicPullParser { private final Handler this$0;
/*     */     
/*     */     MidiParser(Handler this$0) {
/* 396 */       this.this$0 = this$0;
/*     */     }
/*     */     public ContentDescriptor[] getSupportedInputContentDescriptors() {
/* 399 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PullSourceStream getStream() {
/* 408 */       PullSourceStream stream = (PullSourceStream)this.streams[0];
/* 409 */       return stream;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Track[] getTracks() throws IOException, BadHeaderException {
/* 415 */       return null;
/*     */     }
/*     */     
/*     */     public Time setPosition(Time where, int rounding) {
/* 419 */       return null;
/*     */     }
/*     */     
/*     */     public Time getMediaTime() {
/* 423 */       return null;
/*     */     }
/*     */     
/*     */     public Time getDuration() {
/* 427 */       return null;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 431 */       return "Parser for MIDI file format";
/*     */     } }
/*     */ 
/*     */   
/*     */   class MidiFileInputStream
/*     */     extends InputStream {
/*     */     private int length;
/*     */     private int index;
/*     */     private byte[] data;
/*     */     private int markpos;
/*     */     private final Handler this$0;
/*     */     
/*     */     MidiFileInputStream(Handler this$0, byte[] data, int length) {
/* 444 */       this.this$0 = this$0; this.index = 0; this.markpos = 0;
/* 445 */       this.data = data;
/* 446 */       this.length = length;
/*     */     }
/*     */     
/*     */     public void rewind() {
/* 450 */       this.index = 0;
/* 451 */       this.markpos = 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int read() throws IOException {
/* 472 */       if (this.index >= this.length) {
/* 473 */         return -1;
/*     */       }
/* 475 */       return this.data[this.index++];
/*     */     }
/*     */ 
/*     */     
/*     */     public int available() throws IOException {
/* 480 */       return this.length - this.index;
/*     */     }
/*     */ 
/*     */     
/*     */     public int read(byte[] b) throws IOException {
/* 485 */       return read(b, 0, b.length);
/*     */     }
/*     */ 
/*     */     
/*     */     public int read(byte[] b, int off, int len) throws IOException {
/* 490 */       if (len > available())
/* 491 */         len = available(); 
/* 492 */       if (len == 0)
/* 493 */         return -1; 
/* 494 */       System.arraycopy(this.data, this.index, b, off, len);
/* 495 */       this.index += len;
/* 496 */       return len;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\content\audio\midi\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */