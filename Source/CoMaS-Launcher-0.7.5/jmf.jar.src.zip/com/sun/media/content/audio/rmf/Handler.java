package com.sun.media.content.audio.rmf;

import com.sun.media.content.audio.midi.Handler;

public class Handler extends Handler {}
