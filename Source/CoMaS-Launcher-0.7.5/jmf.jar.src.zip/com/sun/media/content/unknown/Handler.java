package com.sun.media.content.unknown;

import com.sun.media.MediaPlayer;

public class Handler extends MediaPlayer {}
