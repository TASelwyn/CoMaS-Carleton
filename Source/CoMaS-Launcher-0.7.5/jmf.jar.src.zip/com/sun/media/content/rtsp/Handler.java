/*     */ package com.sun.media.content.rtsp;
/*     */ import com.sun.media.BasicController;
/*     */ import com.sun.media.BasicPlayer;
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.controls.RtspAdapter;
/*     */ import com.sun.media.protocol.rtp.DataSource;
/*     */ import com.sun.media.rtsp.Timer;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Panel;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.util.Vector;
/*     */ import javax.media.ClockStartedError;
/*     */ import javax.media.Control;
/*     */ import javax.media.Controller;
/*     */ import javax.media.ControllerEvent;
/*     */ import javax.media.GainControl;
/*     */ import javax.media.IncompatibleSourceException;
/*     */ import javax.media.IncompatibleTimeBaseException;
/*     */ import javax.media.Manager;
/*     */ import javax.media.MediaLocator;
/*     */ import javax.media.NotRealizedError;
/*     */ import javax.media.Player;
/*     */ import javax.media.SystemTimeBase;
/*     */ import javax.media.Time;
/*     */ import javax.media.TimeBase;
/*     */ import javax.media.control.BufferControl;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.renderer.VisualContainer;
/*     */ import javax.media.rtp.RTPManager;
/*     */ import javax.media.rtp.ReceiveStream;
/*     */ import javax.media.rtp.ReceiveStreamListener;
/*     */ import javax.media.rtp.SessionAddress;
/*     */ import javax.media.rtp.event.NewReceiveStreamEvent;
/*     */ import javax.media.rtp.event.ReceiveStreamEvent;
/*     */ 
/*     */ public class Handler extends BasicPlayer implements ReceiveStreamListener, TimerListener, BufferListener {
/*  40 */   private final int INITIALIZED = 0;
/*  41 */   private final int REALIZED = 1;
/*  42 */   private final int PLAYING = 2;
/*  43 */   private final int PAUSING = 3;
/*     */   
/*     */   private RtspUtil rtspUtil;
/*     */   
/*     */   private Player[] players;
/*     */   private Vector playerList;
/*     */   private boolean dataReceived;
/*     */   private DataSource[] data_sources;
/*     */   private boolean[] track_ready;
/*     */   private String url;
/*  53 */   private Object readySync = new Object();
/*     */ 
/*     */ 
/*     */   
/*  57 */   private Object stateSync = new Object();
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean waitFailed;
/*     */ 
/*     */ 
/*     */   
/*     */   private int state;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean first_pass = true;
/*     */ 
/*     */ 
/*     */   
/*     */   private Timer timer;
/*     */ 
/*     */   
/*     */   private Container container;
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized boolean doRealize() {
/*  81 */     boolean realized = super.doRealize();
/*     */     
/*  83 */     if (realized) {
/*  84 */       realized = initRtspSession();
/*     */       
/*  86 */       if (!realized) {
/*  87 */         ((BasicController)this).processError = this.rtspUtil.getProcessError();
/*     */       } else {
/*  89 */         long duration = this.rtspUtil.getDuration();
/*     */         
/*  91 */         if (duration > 0L) {
/*  92 */           sendEvent((ControllerEvent)new DurationUpdateEvent((Controller)this, new Time(duration)));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  97 */     return realized;
/*     */   }
/*     */   
/*     */   private boolean initRtspSession() {
/* 101 */     boolean realized = false;
/*     */     
/* 103 */     this.rtspUtil.setUrl(this.url);
/*     */     
/* 105 */     String ipAddress = this.rtspUtil.getServerIpAddress();
/*     */     
/* 107 */     if (ipAddress == null) {
/* 108 */       Log.error("Invalid server address");
/*     */       
/* 110 */       this.rtspUtil.setProcessError("Invalid server address");
/*     */       
/* 112 */       realized = false;
/*     */     } else {
/* 114 */       realized = this.rtspUtil.createConnection();
/*     */       
/* 116 */       if (realized) {
/* 117 */         realized = this.rtspUtil.rtspSetup();
/*     */         
/*     */         try {
/* 120 */           InetAddress destaddr = InetAddress.getByName(ipAddress);
/*     */           
/* 122 */           int numberOfTracks = this.rtspUtil.getNumberOfTracks();
/* 123 */           int[] server_ports = this.rtspUtil.getServerPorts();
/*     */           
/* 125 */           for (int i = 0; i < numberOfTracks; i++) {
/* 126 */             SessionAddress remoteAddress = new SessionAddress(destaddr, server_ports[i]);
/*     */ 
/*     */             
/* 129 */             RTPManager mgr = this.rtspUtil.getRTPManager(i);
/*     */             
/* 131 */             mgr.addTarget(remoteAddress);
/*     */ 
/*     */             
/* 134 */             BufferControl bc = (BufferControl)mgr.getControl("javax.media.control.BufferControl");
/*     */             
/* 136 */             String mediaType = this.rtspUtil.getMediaType(i);
/*     */             
/* 138 */             if (mediaType.equals("audio")) {
/* 139 */               bc.setBufferLength(250L);
/* 140 */               bc.setMinimumThreshold(125L);
/* 141 */             } else if (mediaType.equals("video")) {
/* 142 */               bc.setBufferLength(1500L);
/* 143 */               bc.setMinimumThreshold(250L);
/*     */             } 
/*     */           } 
/*     */         } catch (Exception e) {
/* 147 */           Log.error(e.getMessage());
/*     */           
/* 149 */           return realized;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 154 */     if (realized) {
/* 155 */       this.state = 1;
/*     */       
/* 157 */       int size = this.rtspUtil.getNumberOfTracks();
/*     */       
/* 159 */       this.players = new Player[size];
/* 160 */       this.data_sources = new DataSource[size];
/* 161 */       this.track_ready = new boolean[size];
/*     */       
/* 163 */       this.dataReceived = false;
/*     */ 
/*     */       
/* 166 */       if (!this.rtspUtil.rtspStart()) {
/* 167 */         if (this.first_pass && this.rtspUtil.getStatusCode() == 454) {
/*     */ 
/*     */ 
/*     */           
/* 171 */           this.first_pass = false;
/*     */           
/* 173 */           this.playerList = new Vector();
/*     */           
/* 175 */           return initRtspSession();
/*     */         } 
/*     */         
/* 178 */         return false;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 183 */       waitForData();
/*     */       
/* 185 */       if (this.playerList.size() > 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 191 */         rtspStop();
/* 192 */         this.rtspUtil.setStartPos(0.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 197 */         for (int i = 0; i < this.rtspUtil.getNumberOfTracks(); i++) {
/* 198 */           this.data_sources[i].flush();
/*     */         }
/*     */       } else {
/* 201 */         this.rtspUtil.setProcessError("Media tracks not supported");
/* 202 */         realized = false;
/*     */       } 
/*     */     } 
/*     */     
/* 206 */     return realized;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean doPrefetch() {
/* 213 */     boolean prefetched = super.doPrefetch();
/*     */     
/* 215 */     return prefetched;
/*     */   }
/*     */   
/*     */   public void doStart() {
/* 219 */     if (this.state >= 1 && this.state != 2) {
/*     */       
/* 221 */       for (int i = 0; i < this.rtspUtil.getNumberOfTracks(); i++) {
/* 222 */         this.track_ready[i] = (this.rtspUtil.getRTPManager(i) == null);
/* 223 */         this.data_sources[i].prebuffer();
/*     */       } 
/*     */       
/* 226 */       boolean success = this.rtspUtil.rtspStart();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 231 */       synchronized (this.readySync) {
/* 232 */         boolean ready = true;
/*     */         
/* 234 */         for (int j = 0; j < this.rtspUtil.getNumberOfTracks(); j++) {
/* 235 */           if (!this.track_ready[j]) {
/* 236 */             ready = false;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 241 */         if (!ready) {
/*     */           try {
/* 243 */             this.readySync.wait(3000L);
/* 244 */           } catch (Exception e) {}
/*     */         }
/*     */       } 
/*     */       
/* 248 */       if (success) {
/* 249 */         super.doStart();
/*     */         
/* 251 */         startPlayers();
/*     */         
/* 253 */         this.state = 2;
/*     */ 
/*     */ 
/*     */         
/* 257 */         long duration = this.rtspUtil.getDuration();
/*     */         
/* 259 */         if (duration > 0L) {
/* 260 */           this.timer = new Timer(this, duration + 500000000L - getMediaTime().getNanoseconds());
/*     */ 
/*     */           
/* 263 */           this.timer.start();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void doSetMediaTime(Time now) {
/* 270 */     super.doSetMediaTime(now);
/*     */     
/* 272 */     this.rtspUtil.setStartPos(now.getNanoseconds());
/*     */ 
/*     */     
/* 275 */     for (int i = 0; i < this.rtspUtil.getNumberOfTracks(); i++) {
/* 276 */       this.data_sources[i].flush();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Time getMediaTime() {
/* 283 */     Time time = super.getMediaTime();
/*     */     
/* 285 */     return time;
/*     */   }
/*     */   
/*     */   public void timerExpired() {
/* 289 */     this.timer = null;
/*     */     
/* 291 */     processEndOfMedia();
/*     */   }
/*     */   
/*     */   public void doStop() {
/* 295 */     if (this.state == 2) {
/* 296 */       super.doStop();
/*     */       
/* 298 */       if (this.timer != null) {
/* 299 */         this.timer.stopTimer();
/* 300 */         this.timer.removeListener(this);
/*     */         
/* 302 */         this.timer = null;
/*     */       } 
/*     */       
/* 305 */       stopPlayers();
/*     */       
/* 307 */       rtspStop();
/*     */       
/* 309 */       this.state = 3;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void rtspStop() {
/* 314 */     this.rtspUtil.setStartPos(getMediaTime().getNanoseconds());
/* 315 */     this.rtspUtil.rtspStop();
/*     */   }
/*     */   
/*     */   public void doClose() {
/* 319 */     stopPlayers();
/*     */     
/* 321 */     closePlayers();
/*     */     
/* 323 */     if (this.timer != null) {
/* 324 */       this.timer.stopTimer();
/* 325 */       this.timer.removeListener(this);
/*     */       
/* 327 */       this.timer = null;
/*     */     } 
/*     */     
/* 330 */     if (this.state == 2) {
/* 331 */       this.rtspUtil.rtspTeardown();
/*     */     }
/*     */     
/* 334 */     this.state = 0;
/*     */     
/* 336 */     this.rtspUtil.closeConnection();
/*     */     
/* 338 */     for (int i = 0; i < this.rtspUtil.getNumberOfTracks(); i++) {
/* 339 */       RTPManager mgr = this.rtspUtil.getRTPManager(i);
/* 340 */       mgr.removeTargets("server down.");
/* 341 */       mgr.dispose();
/*     */     } 
/*     */     
/* 344 */     super.doClose();
/*     */   }
/*     */   
/*     */   public float setRate(float rate) {
/* 348 */     if (getState() < 300) {
/* 349 */       throwError((Error)new NotRealizedError("Cannot set rate on an unrealized Player."));
/*     */     }
/*     */ 
/*     */     
/* 353 */     return 1.0F;
/*     */   }
/*     */   
/*     */   public void setStopTime(Time t) {
/* 357 */     controllerSetStopTime(t);
/*     */   }
/*     */   
/*     */   protected void stopAtTime() {
/* 361 */     controllerStopAtTime();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void addController(Controller newController) throws IncompatibleTimeBaseException {
/* 366 */     int playerState = getState();
/*     */     
/* 368 */     if (playerState == 600) {
/* 369 */       throwError((Error)new ClockStartedError("Cannot add controller to a started player"));
/*     */     }
/*     */     
/* 372 */     if (playerState == 100 || playerState == 200) {
/* 373 */       throwError((Error)new NotRealizedError("A Controller cannot be added to an Unrealized Player"));
/*     */     }
/*     */     
/* 376 */     throw new IncompatibleTimeBaseException();
/*     */   }
/*     */   
/*     */   public boolean audioEnabled() {
/* 380 */     boolean enabled = true;
/*     */     
/* 382 */     return enabled;
/*     */   }
/*     */   
/*     */   public boolean videoEnabled() {
/* 386 */     boolean enabled = true;
/*     */     
/* 388 */     return enabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateStats() {}
/*     */ 
/*     */   
/*     */   protected TimeBase getMasterTimeBase() {
/* 396 */     return (TimeBase)new SystemTimeBase();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void update(ReceiveStreamEvent event) {
/* 401 */     RTPManager source = (RTPManager)event.getSource();
/*     */ 
/*     */     
/* 404 */     if (event instanceof NewReceiveStreamEvent) {
/*     */       
/* 406 */       ReceiveStream stream = ((NewReceiveStreamEvent)event).getReceiveStream();
/*     */       
/* 408 */       Participant part = stream.getParticipant();
/*     */       
/* 410 */       int numberOfTracks = this.rtspUtil.getNumberOfTracks();
/*     */       
/* 412 */       for (int i = 0; i < numberOfTracks; i++) {
/* 413 */         if (source == this.rtspUtil.getRTPManager(i)) {
/* 414 */           DataSource ds = (DataSource)stream.getDataSource();
/*     */           
/*     */           try {
/* 417 */             this.players[i] = Manager.createPlayer((DataSource)ds);
/*     */           } catch (Exception e) {
/* 419 */             System.err.println("Failed to create a player from the given Data Source: " + e);
/*     */           } 
/*     */ 
/*     */           
/*     */           try {
/* 424 */             this.waitFailed = false;
/*     */             
/* 426 */             this.players[i].addControllerListener(new StateListener(this));
/* 427 */             this.players[i].realize();
/*     */             
/* 429 */             waitForState(this.players[i], 300);
/* 430 */           } catch (Exception e) {}
/*     */ 
/*     */ 
/*     */           
/* 434 */           if (this.players[i].getState() == 300) {
/* 435 */             this.playerList.addElement(this.players[i]);
/*     */             
/* 437 */             ds.setBufferListener(this);
/*     */             
/* 439 */             this.data_sources[i] = ds; break;
/*     */           } 
/* 441 */           this.players[i].close();
/* 442 */           this.players[i] = null;
/*     */           
/* 444 */           this.rtspUtil.removeTrack(i);
/*     */ 
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 452 */       if (this.playerList.size() == this.rtspUtil.getNumberOfTracks()) {
/* 453 */         this.dataReceived = true;
/*     */         
/* 455 */         synchronized (this) {
/* 456 */           notifyAll();
/*     */         } 
/*     */       } 
/* 459 */     } else if (event instanceof javax.media.rtp.event.ByeEvent) {
/*     */     
/*     */     } 
/*     */   }
/*     */   public void minThresholdReached(DataSource ds) {
/* 464 */     synchronized (this.readySync) {
/* 465 */       for (int i = 0; i < this.rtspUtil.getNumberOfTracks(); i++) {
/* 466 */         if (ds == this.data_sources[i]) {
/* 467 */           this.track_ready[i] = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 472 */       boolean all_ready = true;
/*     */       
/* 474 */       for (int j = 0; j < this.rtspUtil.getNumberOfTracks(); j++) {
/* 475 */         if (!this.track_ready[j]) {
/* 476 */           all_ready = false;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 481 */       if (all_ready) {
/* 482 */         this.readySync.notifyAll();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public long getMediaNanoseconds() {
/* 488 */     long value = super.getMediaNanoseconds();
/*     */     
/* 490 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public Time getDuration() {
/* 495 */     long t = this.rtspUtil.getDuration();
/*     */     
/* 497 */     if (t <= 0L) {
/* 498 */       return Duration.DURATION_UNKNOWN;
/*     */     }
/* 500 */     return new Time(t);
/*     */   }
/*     */   
/*     */   private synchronized void waitForState(Player p, int state) {
/* 504 */     while (p.getState() < state && !this.waitFailed) {
/* 505 */       synchronized (this.stateSync) {
/*     */         try {
/* 507 */           this.stateSync.wait();
/* 508 */         } catch (InterruptedException ie) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */   class StateListener implements ControllerListener { private final Handler this$0;
/*     */     StateListener(Handler this$0) {
/* 514 */       this.this$0 = this$0;
/*     */     } public void controllerUpdate(ControllerEvent ce) {
/* 516 */       if (ce instanceof javax.media.ControllerClosedEvent);
/*     */ 
/*     */       
/* 519 */       if (ce instanceof javax.media.ResourceUnavailableEvent) {
/* 520 */         this.this$0.waitFailed = true;
/*     */         
/* 522 */         synchronized (this.this$0.stateSync) {
/* 523 */           this.this$0.stateSync.notify();
/*     */         } 
/*     */       } 
/*     */       
/* 527 */       if (ce instanceof javax.media.RealizeCompleteEvent) {
/* 528 */         synchronized (this.this$0.stateSync) {
/* 529 */           this.this$0.stateSync.notify();
/*     */         } 
/*     */       }
/*     */       
/* 533 */       if (ce instanceof ControllerEvent) {
/* 534 */         synchronized (this.this$0.stateSync) {
/* 535 */           this.this$0.stateSync.notify();
/*     */         } 
/*     */       }
/*     */       
/* 539 */       if (ce instanceof javax.media.EndOfMediaEvent);
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized boolean waitForData() {
/*     */     try {
/* 546 */       synchronized (this) {
/* 547 */         while (!this.dataReceived) {
/* 548 */           wait();
/*     */         }
/*     */       } 
/*     */     } catch (InterruptedException e) {
/* 552 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 555 */     return this.dataReceived;
/*     */   }
/*     */   
/* 558 */   public Handler() { this.container = null; this.rtspUtil = new RtspUtil(this); this.framePositioning = false;
/*     */     this.playerList = new Vector();
/*     */     this.state = 0;
/* 561 */     ((BasicController)this).stopThreadEnabled = true; } public Component getVisualComponent() { Vector visuals = new Vector(1);
/*     */     
/* 563 */     for (int i = 0; i < this.rtspUtil.getNumberOfTracks(); i++) {
/* 564 */       if (this.players[i] != null) {
/* 565 */         Component comp = this.players[i].getVisualComponent();
/*     */         
/* 567 */         if (comp != null) {
/* 568 */           visuals.addElement(comp);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 573 */     if (visuals.size() == 0)
/* 574 */       return null; 
/* 575 */     if (visuals.size() == 1) {
/* 576 */       return visuals.elementAt(0);
/*     */     }
/* 578 */     return createVisualContainer(visuals); }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Component createVisualContainer(Vector visuals) {
/* 583 */     Boolean hint = (Boolean)Manager.getHint(3);
/*     */     
/* 585 */     if (this.container == null) {
/* 586 */       if (hint == null || !hint.booleanValue()) {
/* 587 */         this.container = new HeavyPanel(this, visuals);
/*     */       } else {
/* 589 */         this.container = new LightPanel(this, visuals);
/*     */       } 
/*     */       
/* 592 */       this.container.setLayout(new FlowLayout());
/* 593 */       this.container.setBackground(Color.black);
/*     */       
/* 595 */       for (int i = 0; i < visuals.size(); i++) {
/* 596 */         Component c = visuals.elementAt(i);
/* 597 */         this.container.add(c);
/* 598 */         c.setSize(c.getPreferredSize());
/*     */       } 
/*     */     } 
/*     */     
/* 602 */     return this.container;
/*     */   }
/*     */   class HeavyPanel extends Panel implements VisualContainer { private final Handler this$0;
/*     */     public HeavyPanel(Handler this$0, Vector visuals) {
/* 606 */       this.this$0 = this$0;
/*     */     } }
/*     */   class LightPanel extends Container implements VisualContainer { private final Handler this$0;
/*     */     
/*     */     public LightPanel(Handler this$0, Vector visuals) {
/* 611 */       this.this$0 = this$0;
/*     */     } }
/*     */ 
/*     */   
/*     */   public GainControl getGainControl() {
/* 616 */     GainControl gainControl = null;
/*     */     
/* 618 */     for (int i = 0; i < this.playerList.size(); i++) {
/* 619 */       Player player = this.playerList.elementAt(i);
/*     */       
/* 621 */       gainControl = player.getGainControl();
/*     */       
/* 623 */       if (gainControl != null) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 628 */     return gainControl;
/*     */   }
/*     */   
/*     */   public Control[] getControls() {
/* 632 */     int size = 0;
/*     */     
/* 634 */     for (int i = 0; i < this.playerList.size(); i++) {
/* 635 */       Control[] controls = ((Player)this.playerList.elementAt(i)).getControls();
/*     */       
/* 637 */       size += controls.length;
/*     */     } 
/*     */     
/* 640 */     size++;
/*     */     
/* 642 */     Control[] rtspControls = new Control[size];
/*     */     
/* 644 */     RtspAdapter rtspAdapter = new RtspAdapter();
/*     */     
/* 646 */     rtspAdapter.setRTPManagers(this.rtspUtil.getRTPManagers());
/* 647 */     rtspAdapter.setMediaTypes(this.rtspUtil.getMediaTypes());
/*     */     
/* 649 */     int counter = 0;
/*     */     
/* 651 */     rtspControls[counter++] = (Control)rtspAdapter;
/*     */     
/* 653 */     for (int j = 0; j < this.playerList.size(); j++) {
/* 654 */       Control[] controls = ((Player)this.playerList.elementAt(j)).getControls();
/*     */       
/* 656 */       for (int k = 0; k < controls.length; k++) {
/* 657 */         rtspControls[counter++] = controls[k];
/*     */       }
/*     */     } 
/*     */     
/* 661 */     return rtspControls;
/*     */   }
/*     */   
/*     */   private void startPlayers() {
/* 665 */     for (int i = 0; i < this.playerList.size(); i++) {
/* 666 */       Player player = this.playerList.elementAt(i);
/*     */       
/* 668 */       player.start();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void stopPlayers() {
/* 673 */     for (int i = 0; i < this.playerList.size(); i++) {
/* 674 */       Player player = this.playerList.elementAt(i);
/*     */       
/* 676 */       player.stop();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void closePlayers() {
/* 681 */     for (int i = 0; i < this.playerList.size(); i++) {
/* 682 */       Player player = this.playerList.elementAt(i);
/*     */       
/* 684 */       player.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
/* 691 */     if (source instanceof com.sun.media.protocol.rtsp.DataSource) {
/* 692 */       MediaLocator ml = source.getLocator();
/*     */       
/*     */       try {
/* 695 */         this.url = ml.toString();
/*     */       } catch (Exception e) {
/* 697 */         throw new IncompatibleSourceException();
/*     */       } 
/*     */     } else {
/* 700 */       throw new IncompatibleSourceException();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\content\rtsp\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */