/*     */ package com.sun.media.ui;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Panel;
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TabField
/*     */ {
/* 610 */   Panel panelPage = null;
/* 611 */   String strTitle = null;
/* 612 */   Image image = null;
/* 613 */   Dimension dim = new Dimension();
/* 614 */   Rectangle rect = new Rectangle();
/* 615 */   int nRowIndex = 0;
/*     */   
/*     */   Component compOwner;
/* 618 */   int MARGIN_TAB_VERT = 5;
/* 619 */   int MARGIN_TAB_HORZ = 8;
/*     */   
/* 621 */   public static final Color COLOR_BG = Color.lightGray;
/* 622 */   public static final Color COLOR_FG = Color.black;
/* 623 */   public static final Color COLOR_SHADOW_TOP = Color.white;
/* 624 */   public static final Color COLOR_SHADOW_BOTTOM = Color.darkGray;
/* 625 */   public static final Color COLOR_TAB_BG = new Color(128, 128, 128);
/* 626 */   public static final Color COLOR_TAB_FG = Color.black;
/* 627 */   public static final Color COLOR_TAB_SHADOW_TOP = Color.lightGray;
/* 628 */   public static final Color COLOR_TAB_SHADOW_BOTTOM = Color.darkGray;
/*     */ 
/*     */   
/*     */   public TabField(Component compOwner, Panel panelPage, String strTitle, Image image) {
/* 632 */     this.compOwner = compOwner;
/* 633 */     this.panelPage = panelPage;
/* 634 */     this.strTitle = strTitle;
/* 635 */     this.image = image;
/*     */   }
/*     */ 
/*     */   
/*     */   public void calculateTabDimension(FontMetrics fontMetrics) {
/* 640 */     this.dim.width = fontMetrics.stringWidth(this.strTitle);
/* 641 */     this.dim.height = fontMetrics.getHeight();
/*     */     
/* 643 */     if (this.image != null) {
/* 644 */       this.dim.width += this.image.getWidth(this.compOwner) + this.MARGIN_TAB_HORZ;
/* 645 */       this.dim.height = Math.max(this.image.getHeight(this.compOwner), this.dim.height);
/*     */     } 
/*     */     
/* 648 */     this.dim.width += 2 * this.MARGIN_TAB_HORZ;
/* 649 */     this.dim.height += 2 * this.MARGIN_TAB_VERT;
/* 650 */     this.rect.width = this.dim.width;
/* 651 */     this.rect.height = this.dim.height;
/*     */   }
/*     */   
/*     */   public void drawTabTop(Graphics graphics) {
/* 655 */     int[] arrX = new int[5];
/* 656 */     int[] arrY = new int[5];
/*     */     
/* 658 */     graphics.setColor(COLOR_TAB_BG);
/* 659 */     arrX[0] = this.rect.x + 6;
/* 660 */     arrY[0] = this.rect.y + 2;
/* 661 */     arrX[1] = this.rect.x + this.rect.width - 0;
/* 662 */     arrY[1] = this.rect.y + 2;
/* 663 */     arrX[2] = this.rect.x + this.rect.width - 0;
/* 664 */     arrY[2] = this.rect.y + this.rect.height - 2;
/* 665 */     arrX[3] = this.rect.x + 2;
/* 666 */     arrY[3] = this.rect.y + this.rect.height - 2;
/* 667 */     arrX[4] = this.rect.x + 2;
/* 668 */     arrY[4] = this.rect.y + 6;
/* 669 */     graphics.fillPolygon(arrX, arrY, 5);
/*     */     
/* 671 */     graphics.setColor(COLOR_TAB_SHADOW_BOTTOM);
/* 672 */     graphics.drawLine(this.rect.x, this.rect.y + this.rect.height - 2, this.rect.x, this.rect.y + 6);
/* 673 */     graphics.drawLine(this.rect.x, this.rect.y + 6, this.rect.x + 6, this.rect.y);
/* 674 */     graphics.drawLine(this.rect.x + 6, this.rect.y, this.rect.x + this.rect.width - 1, this.rect.y);
/* 675 */     graphics.drawLine(this.rect.x + this.rect.width, this.rect.y + 1, this.rect.x + this.rect.width, this.rect.y + this.rect.height - 2);
/*     */     
/* 677 */     graphics.setColor(COLOR_TAB_SHADOW_TOP);
/* 678 */     graphics.drawLine(this.rect.x + 1, this.rect.y + this.rect.height - 3, this.rect.x + 1, this.rect.y + 6);
/* 679 */     graphics.drawLine(this.rect.x + 1, this.rect.y + 6, this.rect.x + 6, this.rect.y + 1);
/* 680 */     graphics.drawLine(this.rect.x + 6, this.rect.y + 1, this.rect.x + this.rect.width - 1, this.rect.y + 1);
/*     */   }
/*     */   
/*     */   public void drawTabLeft(Graphics graphics) {
/* 684 */     int[] arrX = new int[5];
/* 685 */     int[] arrY = new int[5];
/*     */     
/* 687 */     graphics.setColor(COLOR_TAB_BG);
/* 688 */     arrX[0] = this.rect.x + 2;
/* 689 */     arrY[0] = this.rect.y + 6;
/* 690 */     arrX[1] = this.rect.x + 2;
/* 691 */     arrY[1] = this.rect.y + this.rect.height - 0;
/* 692 */     arrX[2] = this.rect.x + this.rect.width - 2;
/* 693 */     arrY[2] = this.rect.y + this.rect.height - 0;
/* 694 */     arrX[3] = this.rect.x + this.rect.width - 2;
/* 695 */     arrY[3] = this.rect.y + 2;
/* 696 */     arrX[4] = this.rect.x + 6;
/* 697 */     arrY[4] = this.rect.y + 2;
/* 698 */     graphics.fillPolygon(arrX, arrY, 5);
/*     */     
/* 700 */     graphics.setColor(COLOR_TAB_SHADOW_BOTTOM);
/* 701 */     graphics.drawLine(this.rect.x + this.rect.width - 2, this.rect.y, this.rect.x + 6, this.rect.y);
/* 702 */     graphics.drawLine(this.rect.x + 6, this.rect.y, this.rect.x, this.rect.y + 6);
/* 703 */     graphics.drawLine(this.rect.x, this.rect.y + 6, this.rect.x, this.rect.y + this.rect.height - 1);
/* 704 */     graphics.drawLine(this.rect.x + 1, this.rect.y + this.rect.height, this.rect.x + this.rect.width - 2, this.rect.y + this.rect.height);
/*     */     
/* 706 */     graphics.setColor(COLOR_TAB_SHADOW_TOP);
/* 707 */     graphics.drawLine(this.rect.x + this.rect.width - 3, this.rect.y + 1, this.rect.x + 6, this.rect.y + 1);
/* 708 */     graphics.drawLine(this.rect.x + 6, this.rect.y + 1, this.rect.x + 1, this.rect.y + 6);
/* 709 */     graphics.drawLine(this.rect.x + 1, this.rect.y + 6, this.rect.x + 1, this.rect.y + this.rect.height - 1);
/*     */   }
/*     */   
/*     */   public void drawCurrentTabTop(Graphics graphics) {
/* 713 */     int[] arrX = new int[5];
/* 714 */     int[] arrY = new int[5];
/*     */     
/* 716 */     graphics.setColor(COLOR_BG);
/* 717 */     arrX[0] = this.rect.x + 6;
/* 718 */     arrY[0] = this.rect.y + 2;
/* 719 */     arrX[1] = this.rect.x + this.rect.width - 0;
/* 720 */     arrY[1] = this.rect.y + 2;
/* 721 */     arrX[2] = this.rect.x + this.rect.width - 0;
/* 722 */     arrY[2] = this.rect.y + this.rect.height - 0;
/* 723 */     arrX[3] = this.rect.x + 2;
/* 724 */     arrY[3] = this.rect.y + this.rect.height - 0;
/* 725 */     arrX[4] = this.rect.x + 2;
/* 726 */     arrY[4] = this.rect.y + 6;
/*     */     
/* 728 */     graphics.fillPolygon(arrX, arrY, 5);
/*     */     
/* 730 */     graphics.setColor(COLOR_SHADOW_BOTTOM);
/* 731 */     graphics.drawLine(this.rect.x, this.rect.y + this.rect.height - 2, this.rect.x, this.rect.y + 6);
/* 732 */     graphics.drawLine(this.rect.x, this.rect.y + 6, this.rect.x + 6, this.rect.y);
/* 733 */     graphics.drawLine(this.rect.x + 6, this.rect.y, this.rect.x + this.rect.width - 1, this.rect.y);
/* 734 */     graphics.drawLine(this.rect.x + this.rect.width, this.rect.y + 1, this.rect.x + this.rect.width, this.rect.y + this.rect.height - 2);
/*     */     
/* 736 */     graphics.setColor(COLOR_SHADOW_TOP);
/* 737 */     graphics.drawLine(this.rect.x + 1, this.rect.y + this.rect.height - 2, this.rect.x + 1, this.rect.y + 6);
/* 738 */     graphics.drawLine(this.rect.x + 1, this.rect.y + 6, this.rect.x + 6, this.rect.y + 1);
/* 739 */     graphics.drawLine(this.rect.x + 6, this.rect.y + 1, this.rect.x + this.rect.width - 1, this.rect.y + 1);
/*     */   }
/*     */   
/*     */   public void drawCurrentTabLeft(Graphics graphics) {
/* 743 */     int[] arrX = new int[5];
/* 744 */     int[] arrY = new int[5];
/*     */     
/* 746 */     graphics.setColor(COLOR_BG);
/* 747 */     arrX[0] = this.rect.x + 2;
/* 748 */     arrY[0] = this.rect.y + 6;
/* 749 */     arrX[1] = this.rect.x + 2;
/* 750 */     arrY[1] = this.rect.y + this.rect.height - 0;
/* 751 */     arrX[2] = this.rect.x + this.rect.width - 0;
/* 752 */     arrY[2] = this.rect.y + this.rect.height - 0;
/* 753 */     arrX[3] = this.rect.x + this.rect.width - 0;
/* 754 */     arrY[3] = this.rect.y + 2;
/* 755 */     arrX[4] = this.rect.x + 6;
/* 756 */     arrY[4] = this.rect.y + 2;
/* 757 */     graphics.fillPolygon(arrX, arrY, 5);
/*     */     
/* 759 */     graphics.setColor(COLOR_SHADOW_BOTTOM);
/* 760 */     graphics.drawLine(this.rect.x + this.rect.width - 2, this.rect.y, this.rect.x + 6, this.rect.y);
/* 761 */     graphics.drawLine(this.rect.x + 6, this.rect.y, this.rect.x, this.rect.y + 6);
/* 762 */     graphics.drawLine(this.rect.x, this.rect.y + 6, this.rect.x, this.rect.y + this.rect.height - 1);
/* 763 */     graphics.drawLine(this.rect.x + 1, this.rect.y + this.rect.height, this.rect.x + this.rect.width - 2, this.rect.y + this.rect.height);
/*     */     
/* 765 */     graphics.setColor(COLOR_SHADOW_TOP);
/* 766 */     graphics.drawLine(this.rect.x + this.rect.width - 2, this.rect.y + 1, this.rect.x + 6, this.rect.y + 1);
/* 767 */     graphics.drawLine(this.rect.x + 6, this.rect.y + 1, this.rect.x + 1, this.rect.y + 6);
/* 768 */     graphics.drawLine(this.rect.x + 1, this.rect.y + 6, this.rect.x + 1, this.rect.y + this.rect.height - 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\TabField.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */