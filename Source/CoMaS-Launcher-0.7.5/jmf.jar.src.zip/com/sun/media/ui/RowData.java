package com.sun.media.ui;

import java.util.Vector;

class RowData {
  private Vector vectorValues = new Vector();
  
  public RowData(Object[] arrValues) {
    if (arrValues != null) {
      int nCount = arrValues.length;
      for (int i = 0; i < nCount; i++)
        this.vectorValues.addElement(arrValues[i]); 
    } 
  }
  
  void setValue(Object value, int nColumn) {
    this.vectorValues.setElementAt(value, nColumn);
  }
  
  Object getValue(int nColumn) {
    Object value = this.vectorValues.elementAt(nColumn);
    return value;
  }
}
