/*     */ package com.sun.media.ui;
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.util.MediaThread;
/*     */ import com.sun.media.util.jdk12;
/*     */ import com.sun.media.util.jdk12CreateThreadRunnableAction;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.ComponentListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.media.CachingControl;
/*     */ import javax.media.CachingControlEvent;
/*     */ import javax.media.ControllerEvent;
/*     */ import javax.media.ControllerListener;
/*     */ import javax.media.Duration;
/*     */ import javax.media.Player;
/*     */ import javax.media.Time;
/*     */ 
/*     */ public class ProgressSlider extends BasicComp implements MouseListener, MouseMotionListener, Runnable, ComponentListener, ControllerListener {
/*     */   Image imageGrabber;
/*     */   Image imageGrabberDown;
/*     */   int grabberWidth;
/*     */   int grabberHeight;
/*     */   boolean grabbed;
/*     */   boolean entered;
/*     */   int grabberPosition;
/*  36 */   int leftBorder = 0;
/*  37 */   int rightBorder = 0;
/*     */   int sliderWidth;
/*  39 */   MediaThread timer = null;
/*     */   
/*     */   protected boolean justSeeked = false;
/*     */   protected boolean stopTimer = false;
/*  43 */   private static JMFSecurity jmfSecurity = null;
/*     */   private static boolean securityPrivelege = false;
/*  45 */   private Method[] m = new Method[1];
/*  46 */   private Class[] cl = new Class[1];
/*  47 */   private Object[][] args = new Object[1][0];
/*     */   
/*     */   private Player player;
/*     */   private DefaultControlPanel controlPanel;
/*  51 */   private ToolTip toolTip = null;
/*  52 */   private double progressCaching = 1.0D; private boolean resetMediaTime = false;
/*     */   Object disposeLock;
/*     */   Object syncStop;
/*     */   
/*     */   static {
/*     */     try {
/*  58 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  59 */       securityPrivelege = true;
/*  60 */     } catch (SecurityException e) {}
/*     */   }
/*     */   
/*     */   public ProgressSlider(String label, DefaultControlPanel cp, Player p)
/*     */   {
/*  65 */     super(label);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 167 */     this.disposeLock = new Object();
/* 168 */     this.syncStop = new Object(); this.player = p; this.controlPanel = cp; this.imageGrabber = BasicComp.fetchImage("grabber.gif"); this.imageGrabberDown = BasicComp.fetchImage("grabber-pressed.gif"); this.grabberWidth = this.imageGrabber.getWidth(this); this.grabberHeight = this.imageGrabber.getHeight(this); this.leftBorder = this.grabberWidth / 2; this.rightBorder = this.leftBorder; addMouseListener(this); addMouseMotionListener(this); this.grabberPosition = 0; this.grabbed = false; this.entered = false; this.height = 18; this.width = 20;
/*     */     this.sliderWidth = this.width - this.leftBorder - this.rightBorder;
/*     */     addComponentListener(this);
/* 171 */     this.player.addControllerListener(this); } public void removeNotify() { if (this.timer != null) {
/* 172 */       synchronized (this.syncStop) {
/* 173 */         this.stopTimer = true;
/* 174 */         this.timer = null;
/*     */       } 
/*     */     }
/* 177 */     synchronized (this.disposeLock) {
/* 178 */       if (this.toolTip != null) {
/* 179 */         this.toolTip.setVisible(false);
/*     */       }
/*     */     } 
/*     */     
/* 183 */     super.removeNotify(); }
/*     */   public void addNotify() { super.addNotify(); if (jmfSecurity != null) { String permission = null; try { if (jmfSecurity.getName().startsWith("jmf-security")) { permission = "thread"; jmfSecurity.requestPermission(this.m, this.cl, this.args, 16); this.m[0].invoke(this.cl[0], this.args[0]); permission = "thread group"; jmfSecurity.requestPermission(this.m, this.cl, this.args, 32); this.m[0].invoke(this.cl[0], this.args[0]); } else if (jmfSecurity.getName().startsWith("internet")) { PolicyEngine.checkPermission(PermissionID.THREAD); PolicyEngine.assertPermission(PermissionID.THREAD); }  } catch (Throwable e) { securityPrivelege = false; }  }  if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) { try { ProgressSlider slider = this; Constructor cons = jdk12CreateThreadRunnableAction.cons; this.timer = (MediaThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { MediaThread.class, this }) }); this.timer.setName("Progress Slider thread"); cons = jdk12PriorityAction.cons; (new Object[2])[0] = this.timer; this; jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { null, new Integer(MediaThread.getControlPriority()) }) }); this.stopTimer = false; this.timer.start(); }
/*     */       catch (Exception e) {} }
/*     */     else { this.timer = new MediaThread(this); this.timer.setName("Progress Slider thread"); this.timer.useControlPriority(); this.stopTimer = false; this.timer.start(); }
/* 187 */      } public synchronized void dispose() { synchronized (this.syncStop) {
/* 188 */       if (this.timer != null) {
/* 189 */         this.stopTimer = true;
/*     */       }
/*     */     } 
/* 192 */     removeMouseListener(this);
/* 193 */     removeMouseMotionListener(this);
/* 194 */     removeComponentListener(this);
/* 195 */     synchronized (this.disposeLock) {
/* 196 */       if (this.toolTip != null) {
/* 197 */         this.toolTip.dispose();
/* 198 */         this.toolTip = null;
/*     */       } 
/*     */     } 
/* 201 */     this.timer = null;
/* 202 */     this.player = null; }
/*     */ 
/*     */   
/*     */   public void run() {
/* 206 */     int counter = 0;
/* 207 */     int pausecnt = -1;
/*     */     
/* 209 */     boolean doUpdate = true;
/*     */     
/* 211 */     while (!this.stopTimer) {
/*     */       try {
/* 213 */         if (this.player != null && this.player.getState() == 600) {
/* 214 */           doUpdate = true;
/* 215 */           pausecnt = -1;
/* 216 */         } else if (this.player != null && pausecnt < 5) {
/* 217 */           pausecnt++;
/* 218 */           doUpdate = true;
/* 219 */         } else if (this.resetMediaTime) {
/* 220 */           doUpdate = true;
/* 221 */           this.resetMediaTime = false;
/*     */         } else {
/* 223 */           doUpdate = false;
/*     */         } 
/*     */         
/*     */         try {
/* 227 */           if (doUpdate) {
/* 228 */             long nanoDuration = this.player.getDuration().getNanoseconds();
/*     */             
/* 230 */             if (nanoDuration > 0L) {
/* 231 */               long nanoTime = this.player.getMediaNanoseconds();
/*     */ 
/*     */               
/* 234 */               seek((float)nanoTime / (float)nanoDuration);
/* 235 */               if (!this.grabbed)
/* 236 */                 updateToolTip(nanoTime); 
/*     */             } 
/*     */           } 
/* 239 */         } catch (Exception e) {}
/*     */         
/* 241 */         int sleepTime = isEnabled() ? 200 : 1000;
/*     */         
/* 243 */         try { Thread.sleep(sleepTime); } catch (Exception e) {}
/*     */         
/* 245 */         counter++;
/* 246 */         if (counter == 1000 / sleepTime) {
/* 247 */           counter = 0;
/* 248 */           this.controlPanel.update();
/*     */         } 
/*     */         
/* 251 */         if (this.justSeeked) {
/* 252 */           this.justSeeked = false; 
/* 253 */           try { Thread.sleep(1000L); } catch (Exception e) {}
/*     */         } 
/* 255 */       } catch (Exception e) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics g) {
/* 271 */     if (isEnabled()) {
/* 272 */       int y = this.height / 2 - 2;
/* 273 */       int grabberY = this.height / 2 - this.grabberHeight / 2;
/* 274 */       g.setColor(getBackground().darker());
/* 275 */       g.drawRect(this.leftBorder, y, this.sliderWidth, 3);
/* 276 */       g.setColor(getBackground());
/* 277 */       int downloadCredit = this.grabberWidth;
/* 278 */       g.draw3DRect(this.leftBorder, y, (int)((this.sliderWidth - downloadCredit) * this.progressCaching + downloadCredit), 3, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 301 */       if (this.grabbed || this.entered) {
/* 302 */         g.drawImage(this.imageGrabberDown, this.grabberPosition + this.leftBorder - this.grabberWidth / 2, grabberY, this);
/*     */       }
/*     */       else {
/*     */         
/* 306 */         g.drawImage(this.imageGrabber, this.grabberPosition + this.leftBorder - this.grabberWidth / 2, grabberY, this);
/*     */       }
/*     */     
/*     */     }
/* 310 */     else if (this.player != null) {
/* 311 */       String strTime = formatTime(this.player.getMediaNanoseconds());
/* 312 */       Font font = getFont();
/* 313 */       g.setFont(font);
/* 314 */       FontMetrics fontMetrics = getFontMetrics(font);
/* 315 */       g.drawString(strTime, 2, 2 + fontMetrics.getAscent());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void sliderSeek(float fraction) {
/* 320 */     if (this.player == null)
/*     */       return; 
/* 322 */     long value = (long)(fraction * (float)this.player.getDuration().getNanoseconds());
/* 323 */     this.justSeeked = true;
/* 324 */     if (value >= 0L) {
/* 325 */       this.player.setMediaTime(new Time(value));
/* 326 */       this.controlPanel.resetPauseCount();
/* 327 */       this.controlPanel.update();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void seek(float fraction) {
/* 332 */     if (this.justSeeked)
/*     */       return; 
/* 334 */     if (!this.grabbed) {
/* 335 */       int newPosition = (int)(fraction * this.sliderWidth);
/* 336 */       if (newPosition > this.sliderWidth)
/* 337 */         newPosition = this.sliderWidth; 
/* 338 */       if (newPosition < 0)
/* 339 */         newPosition = 0; 
/* 340 */       if (this.grabberPosition != newPosition || !isEnabled()) {
/* 341 */         this.grabberPosition = newPosition;
/* 342 */         repaint();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Dimension getPreferredSize() {
/* 348 */     return new Dimension(20, this.height);
/*     */   }
/*     */   
/*     */   public float sliderToSeek(int x) {
/* 352 */     float s = x / this.sliderWidth;
/* 353 */     return s;
/*     */   }
/*     */   
/*     */   public int mouseToSlider(int x) {
/* 357 */     if (x < this.leftBorder)
/* 358 */       x = this.leftBorder; 
/* 359 */     if (x > this.width - this.rightBorder) {
/* 360 */       x = this.width - this.rightBorder;
/*     */     }
/* 362 */     x -= this.leftBorder;
/* 363 */     return x;
/*     */   }
/*     */   
/*     */   public void mousePressed(MouseEvent me) {
/* 367 */     if (!isEnabled())
/*     */       return; 
/* 369 */     this.grabbed = true;
/* 370 */     this.grabberPosition = mouseToSlider(me.getX());
/* 371 */     repaint();
/*     */   }
/*     */   
/*     */   public synchronized void mouseReleased(MouseEvent me) {
/* 375 */     if (!isEnabled())
/*     */       return; 
/* 377 */     this.grabbed = false;
/* 378 */     this.grabberPosition = mouseToSlider(me.getX());
/* 379 */     float seek = sliderToSeek(this.grabberPosition);
/* 380 */     sliderSeek(seek);
/* 381 */     if (this.toolTip != null && !this.entered) {
/* 382 */       this.toolTip.dispose();
/* 383 */       this.toolTip = null;
/*     */     } 
/* 385 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseClicked(MouseEvent me) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void mouseEntered(MouseEvent me) {
/* 395 */     this.entered = true;
/* 396 */     if (this.toolTip == null && isEnabled() && this.player != null) {
/* 397 */       this.toolTip = new ToolTip("time/duration");
/* 398 */       updateToolTip(this.player.getMediaNanoseconds());
/* 399 */       if (isShowing()) {
/* 400 */         Point pointScreen = getLocationOnScreen();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 405 */         pointScreen.y += this.height + 4;
/* 406 */         this.toolTip.setLocation(pointScreen);
/* 407 */         this.toolTip.show();
/*     */       } 
/*     */     } 
/* 410 */     repaint();
/*     */   }
/*     */   
/*     */   public synchronized void mouseExited(MouseEvent me) {
/* 414 */     if (this.toolTip != null && !this.grabbed) {
/* 415 */       this.toolTip.dispose();
/* 416 */       this.toolTip = null;
/*     */     } 
/* 418 */     if (!isEnabled())
/*     */       return; 
/* 420 */     this.entered = false;
/* 421 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void mouseMoved(MouseEvent me) {
/* 428 */     if (this.toolTip != null && isShowing()) {
/* 429 */       Dimension dim = this.toolTip.getSize();
/* 430 */       Point pointScreen = getLocationOnScreen();
/* 431 */       pointScreen.x += me.getX() - dim.width - 2;
/* 432 */       pointScreen.y += me.getY();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void mouseDragged(MouseEvent me) {
/* 441 */     if (!isEnabled() || this.player == null)
/*     */       return; 
/* 443 */     int newPosition = mouseToSlider(me.getX());
/* 444 */     if (newPosition != this.grabberPosition) {
/* 445 */       this.grabberPosition = newPosition;
/* 446 */       float seek = sliderToSeek(this.grabberPosition);
/* 447 */       if (this.player.getState() != 600)
/* 448 */         sliderSeek(seek); 
/* 449 */       long value = (long)(seek * (float)this.player.getDuration().getNanoseconds());
/* 450 */       updateToolTip(value);
/* 451 */       repaint();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void componentResized(ComponentEvent event) {
/* 458 */     Dimension dim = getSize();
/* 459 */     if (dim.width - this.leftBorder - this.rightBorder < 1) {
/*     */       return;
/*     */     }
/* 462 */     this.grabberPosition = (int)(this.grabberPosition * (dim.width - this.leftBorder - this.rightBorder) / (this.width - this.leftBorder - this.rightBorder));
/* 463 */     this.width = dim.width;
/* 464 */     this.sliderWidth = this.width - this.leftBorder - this.rightBorder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void componentMoved(ComponentEvent event) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void componentShown(ComponentEvent event) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void componentHidden(ComponentEvent event) {}
/*     */ 
/*     */   
/*     */   public synchronized void controllerUpdate(ControllerEvent event) {
/* 481 */     if (event instanceof CachingControlEvent) {
/* 482 */       CachingControl cachingControl = ((CachingControlEvent)event).getCachingControl();
/* 483 */       long length = cachingControl.getContentLength();
/* 484 */       long progress = cachingControl.getContentProgress();
/* 485 */       this.progressCaching = progress / length;
/* 486 */       repaint();
/* 487 */     } else if (event instanceof javax.media.MediaTimeSetEvent) {
/* 488 */       this.resetMediaTime = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private String formatTime(Time time) {
/* 494 */     String strTime = new String("<unknown>");
/*     */     
/* 496 */     if (time == null || time == Time.TIME_UNKNOWN || time == Duration.DURATION_UNKNOWN) {
/* 497 */       return strTime;
/*     */     }
/* 499 */     long nano = time.getNanoseconds();
/* 500 */     strTime = formatTime(nano);
/* 501 */     return strTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String formatTime(long nanoSeconds) {
/* 514 */     int seconds = (int)(nanoSeconds / 1000000000L);
/* 515 */     int hours = seconds / 3600;
/* 516 */     int minutes = (seconds - hours * 3600) / 60;
/* 517 */     seconds = seconds - hours * 3600 - minutes * 60;
/* 518 */     nanoSeconds = nanoSeconds % 1000000000L / 10000000L;
/*     */     
/* 520 */     int hours10 = hours / 10;
/* 521 */     hours %= 10;
/* 522 */     int minutes10 = minutes / 10;
/* 523 */     minutes %= 10;
/* 524 */     int seconds10 = seconds / 10;
/* 525 */     seconds %= 10;
/* 526 */     long nano10 = nanoSeconds / 10L;
/* 527 */     nanoSeconds %= 10L;
/*     */     
/* 529 */     String strTime = new String("" + hours10 + hours + ":" + minutes10 + minutes + ":" + seconds10 + seconds + "." + nano10 + nanoSeconds);
/* 530 */     return strTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateToolTip(long nanoMedia) {
/* 537 */     if (this.toolTip == null || this.player == null) {
/*     */       return;
/*     */     }
/* 540 */     Time timeDuration = this.player.getDuration();
/* 541 */     String strTool = new String(formatTime(nanoMedia) + " / " + formatTime(timeDuration));
/* 542 */     this.toolTip.setText(strTool);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\ProgressSlider.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */