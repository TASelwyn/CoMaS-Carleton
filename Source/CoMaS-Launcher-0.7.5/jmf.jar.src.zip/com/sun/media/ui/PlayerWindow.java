/*     */ package com.sun.media.ui;
/*     */ 
/*     */ import com.sun.media.util.JMFI18N;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Insets;
/*     */ import java.awt.MenuItem;
/*     */ import java.awt.Panel;
/*     */ import java.awt.PopupMenu;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ComponentAdapter;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.ComponentListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.awt.event.WindowListener;
/*     */ import javax.media.CachingControl;
/*     */ import javax.media.CachingControlEvent;
/*     */ import javax.media.Control;
/*     */ import javax.media.ControllerEvent;
/*     */ import javax.media.ControllerListener;
/*     */ import javax.media.Player;
/*     */ import javax.media.SizeChangeEvent;
/*     */ import javax.media.Time;
/*     */ import javax.media.control.MonitorControl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlayerWindow
/*     */   extends Frame
/*     */   implements ControllerListener
/*     */ {
/*  47 */   private static final String MENU_ZOOM_1_2 = JMFI18N.getResource("mediaplayer.zoom.1:2");
/*  48 */   private static final String MENU_ZOOM_1_1 = JMFI18N.getResource("mediaplayer.zoom.1:1");
/*  49 */   private static final String MENU_ZOOM_2_1 = JMFI18N.getResource("mediaplayer.zoom.2:1");
/*  50 */   private static final String MENU_ZOOM_4_1 = JMFI18N.getResource("mediaplayer.zoom.4:1");
/*  51 */   private static final String MENU_ZOOM = JMFI18N.getResource("mediaplayer.menu.zoom");
/*     */   
/*     */   Player player;
/*     */   
/*     */   Panel framePanel;
/*     */   ComponentListener cl;
/*     */   ComponentListener fcl;
/*     */   WindowListener wl;
/*     */   MouseListener ml;
/*  60 */   Component controlComp = null;
/*  61 */   Component visualComp = null;
/*     */   Insets insets;
/*  63 */   PopupMenu zoomMenu = null;
/*     */   boolean windowCreated = false;
/*     */   boolean newVideo = true;
/*     */   boolean panelResized = false;
/*     */   boolean autoStart = true;
/*     */   boolean autoLoop = true;
/*  69 */   Component progressBar = null;
/*  70 */   private Integer playerLock = new Integer(1);
/*     */   
/*     */   public PlayerWindow(Player player) {
/*  73 */     this(player, JMFI18N.getResource("mediaplayer.windowtitle"), true, true);
/*     */   }
/*     */   
/*     */   public PlayerWindow(Player player, String title) {
/*  77 */     this(player, title, true, true);
/*     */   }
/*     */   
/*     */   public PlayerWindow(Player player, String title, boolean autoStart) {
/*  81 */     this(player, title, autoStart, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public PlayerWindow(Player player, String title, boolean autoStart, boolean autoLoop) {
/*  86 */     super(title);
/*  87 */     this.autoStart = autoStart;
/*  88 */     this.autoLoop = autoLoop;
/*  89 */     this.player = player;
/*  90 */     setLayout(new BorderLayout());
/*     */     
/*  92 */     this.framePanel = new Panel();
/*  93 */     this.framePanel.setLayout(null);
/*  94 */     add(this.framePanel, "Center");
/*     */     
/*  96 */     this.insets = getInsets();
/*  97 */     setSize(this.insets.left + this.insets.right + 320, this.insets.top + this.insets.bottom + 30);
/*     */ 
/*     */     
/* 100 */     setVisible(true);
/*     */ 
/*     */     
/* 103 */     addWindowListener(this.wl = new WindowAdapter(this) {
/*     */           public void windowClosing(WindowEvent we) {
/* 105 */             this.this$0.killThePlayer();
/*     */           }
/*     */           private final PlayerWindow this$0;
/*     */         });
/* 109 */     this.framePanel.addComponentListener(this.fcl = new ComponentAdapter(this) {
/*     */           public void componentResized(ComponentEvent ce) {
/* 111 */             this.this$0.panelResized = true;
/* 112 */             this.this$0.doResize();
/*     */           }
/*     */           private final PlayerWindow this$0;
/*     */         });
/* 116 */     addComponentListener(this.fcl = new ComponentAdapter(this) {
/*     */           public void componentResized(ComponentEvent ce) {
/* 118 */             this.this$0.insets = this.this$0.getInsets();
/* 119 */             Dimension dim = this.this$0.getSize();
/* 120 */             this.this$0.framePanel.setSize(dim.width - this.this$0.insets.left - this.this$0.insets.right, dim.height - this.this$0.insets.top - this.this$0.insets.bottom);
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           private final PlayerWindow this$0;
/*     */         });
/* 134 */     player.addControllerListener(this);
/* 135 */     player.realize();
/*     */   }
/*     */ 
/*     */   
/*     */   void sleep(long time) {
/*     */     try {
/* 141 */       Thread.currentThread(); Thread.sleep(time);
/* 142 */     } catch (Exception e) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public void addNotify() {
/* 147 */     super.addNotify();
/* 148 */     this.windowCreated = true;
/* 149 */     invalidate();
/*     */   }
/*     */   
/*     */   public void doResize() {
/* 153 */     Dimension d = this.framePanel.getSize();
/* 154 */     int videoHeight = d.height;
/* 155 */     if (this.controlComp != null) {
/* 156 */       videoHeight -= (this.controlComp.getPreferredSize()).height;
/* 157 */       if (videoHeight < 2)
/* 158 */         videoHeight = 2; 
/* 159 */       if (d.width < 80)
/* 160 */         d.width = 80; 
/* 161 */       this.controlComp.setBounds(0, videoHeight, d.width, (this.controlComp.getPreferredSize()).height);
/*     */       
/* 163 */       this.controlComp.invalidate();
/*     */     } 
/*     */     
/* 166 */     if (this.visualComp != null) {
/* 167 */       this.visualComp.setBounds(0, 0, d.width, videoHeight);
/*     */     }
/* 169 */     this.framePanel.validate();
/*     */   }
/*     */   
/*     */   public void killThePlayer() {
/* 173 */     synchronized (this.playerLock) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 181 */       if (this.visualComp != null) {
/* 182 */         this.framePanel.remove(this.visualComp);
/* 183 */         this.visualComp = null;
/*     */       } 
/* 185 */       if (this.controlComp != null) {
/* 186 */         this.framePanel.remove(this.controlComp);
/* 187 */         this.controlComp = null;
/*     */       } 
/* 189 */       if (this.player != null)
/* 190 */         this.player.close(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void controllerUpdate(ControllerEvent ce) {
/* 195 */     synchronized (this.playerLock) {
/* 196 */       if (ce instanceof javax.media.RealizeCompleteEvent) {
/* 197 */         int width = 320;
/* 198 */         int height = 0;
/* 199 */         this.insets = getInsets();
/*     */         
/* 201 */         if (this.progressBar != null) {
/* 202 */           this.framePanel.remove(this.progressBar);
/*     */         }
/* 204 */         if ((this.visualComp = this.player.getVisualComponent()) != null) {
/* 205 */           width = (this.visualComp.getPreferredSize()).width;
/* 206 */           height = (this.visualComp.getPreferredSize()).height;
/* 207 */           this.framePanel.add(this.visualComp);
/* 208 */           this.visualComp.setBounds(0, 0, width, height);
/* 209 */           addPopupMenu(this.visualComp);
/*     */         } else {
/* 211 */           MonitorControl mc = (MonitorControl)this.player.getControl("javax.media.control.MonitorControl");
/*     */           
/* 213 */           if (mc != null) {
/* 214 */             Control[] controls = this.player.getControls();
/* 215 */             Panel mainPanel = new Panel(new BorderLayout());
/* 216 */             Panel currentPanel = mainPanel;
/* 217 */             for (int i = 0; i < controls.length; i++) {
/* 218 */               if (controls[i] instanceof MonitorControl) {
/* 219 */                 mc = (MonitorControl)controls[i];
/* 220 */                 mc.setEnabled(true);
/* 221 */                 if (mc.getControlComponent() != null) {
/* 222 */                   currentPanel.add("North", mc.getControlComponent());
/* 223 */                   Panel newPanel = new Panel(new BorderLayout());
/* 224 */                   currentPanel.add("South", newPanel);
/* 225 */                   currentPanel = newPanel;
/*     */                 } 
/*     */               } 
/*     */             } 
/* 229 */             this.visualComp = mainPanel;
/* 230 */             width = (this.visualComp.getPreferredSize()).width;
/* 231 */             height = (this.visualComp.getPreferredSize()).height;
/* 232 */             this.framePanel.add(this.visualComp);
/* 233 */             this.visualComp.setBounds(0, 0, width, height);
/*     */           } 
/*     */         } 
/*     */         
/* 237 */         if ((this.controlComp = this.player.getControlPanelComponent()) != null) {
/* 238 */           int prefHeight = (this.controlComp.getPreferredSize()).height;
/* 239 */           this.framePanel.add(this.controlComp);
/* 240 */           this.controlComp.setBounds(0, height, width, prefHeight);
/* 241 */           height += prefHeight;
/*     */         } 
/*     */         
/* 244 */         setSize(width + this.insets.left + this.insets.right, height + this.insets.top + this.insets.bottom);
/*     */         
/* 246 */         if (this.autoStart) {
/* 247 */           this.player.prefetch();
/*     */         }
/* 249 */       } else if (ce instanceof javax.media.PrefetchCompleteEvent) {
/* 250 */         if (this.visualComp != null) {
/* 251 */           Dimension vSize = this.visualComp.getPreferredSize();
/* 252 */           if (this.controlComp != null) {
/* 253 */             vSize.height += (this.controlComp.getPreferredSize()).height;
/*     */           }
/* 255 */           this.panelResized = false;
/* 256 */           setSize(vSize.width + this.insets.left + this.insets.right, vSize.height + this.insets.top + this.insets.bottom);
/*     */           
/* 258 */           int waited = 0;
/* 259 */           while (!this.panelResized && waited < 2000) {
/*     */             try {
/* 261 */               waited += 50;
/* 262 */               Thread.currentThread(); Thread.sleep(50L);
/* 263 */               Thread.currentThread(); Thread.yield();
/* 264 */             } catch (Exception e) {}
/*     */           } 
/*     */         } else {
/* 267 */           int height = 1;
/* 268 */           if (this.controlComp != null)
/* 269 */             height = (this.controlComp.getPreferredSize()).height; 
/* 270 */           setSize(320 + this.insets.left + this.insets.right, height + this.insets.top + this.insets.bottom);
/*     */         } 
/*     */ 
/*     */         
/* 274 */         if (this.autoStart && 
/* 275 */           this.player != null && this.player.getTargetState() != 600)
/*     */         {
/* 277 */           this.player.start();
/*     */         
/*     */         }
/*     */       }
/* 281 */       else if (ce instanceof javax.media.EndOfMediaEvent) {
/* 282 */         if (this.autoLoop) {
/* 283 */           this.player.setMediaTime(new Time(0L));
/* 284 */           this.player.start();
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 292 */       else if (ce instanceof javax.media.ControllerErrorEvent) {
/* 293 */         System.err.println("Received controller error");
/* 294 */         killThePlayer();
/* 295 */         dispose();
/* 296 */       } else if (ce instanceof SizeChangeEvent) {
/*     */         
/* 298 */         if (this.framePanel != null) {
/* 299 */           SizeChangeEvent sce = (SizeChangeEvent)ce;
/* 300 */           int nooWidth = sce.getWidth();
/* 301 */           int nooHeight = sce.getHeight();
/*     */           
/* 303 */           if (this.controlComp != null)
/* 304 */             nooHeight += (this.controlComp.getPreferredSize()).height; 
/* 305 */           if ((this.framePanel.getSize()).width != nooWidth || (this.framePanel.getSize()).height != nooHeight) {
/*     */             
/* 307 */             setSize(nooWidth + this.insets.left + this.insets.right, nooHeight + this.insets.top + this.insets.bottom);
/*     */           }
/*     */           else {
/*     */             
/* 311 */             doResize();
/*     */           } 
/* 313 */           if (this.controlComp != null)
/* 314 */             this.controlComp.invalidate(); 
/*     */         } 
/* 316 */       } else if (ce instanceof javax.media.format.FormatChangeEvent) {
/* 317 */         Dimension vSize = new Dimension(320, 0);
/* 318 */         Component oldVisualComp = this.visualComp;
/* 319 */         if ((this.visualComp = this.player.getVisualComponent()) != null && 
/* 320 */           oldVisualComp != this.visualComp) {
/* 321 */           if (oldVisualComp != null && this.zoomMenu != null)
/* 322 */             oldVisualComp.remove(this.zoomMenu); 
/* 323 */           this.framePanel.remove(oldVisualComp);
/* 324 */           vSize = this.visualComp.getPreferredSize();
/* 325 */           this.framePanel.add(this.visualComp);
/* 326 */           this.visualComp.setBounds(0, 0, vSize.width, vSize.height);
/* 327 */           addPopupMenu(this.visualComp);
/*     */         } 
/*     */         
/* 330 */         Component oldComp = this.controlComp;
/* 331 */         if ((this.controlComp = this.player.getControlPanelComponent()) != null && 
/* 332 */           oldComp != this.controlComp) {
/* 333 */           this.framePanel.remove(oldComp);
/* 334 */           this.framePanel.add(this.controlComp);
/* 335 */           if (this.controlComp != null) {
/* 336 */             int prefHeight = (this.controlComp.getPreferredSize()).height;
/* 337 */             this.controlComp.setBounds(0, vSize.height, vSize.width, prefHeight);
/*     */           }
/*     */         
/*     */         } 
/* 341 */       } else if (ce instanceof javax.media.ControllerClosedEvent) {
/* 342 */         if (this.visualComp != null) {
/* 343 */           if (this.zoomMenu != null)
/* 344 */             this.visualComp.remove(this.zoomMenu); 
/* 345 */           this.visualComp.removeMouseListener(this.ml);
/*     */         } 
/* 347 */         removeWindowListener(this.wl);
/* 348 */         removeComponentListener(this.cl);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 353 */         if (this.framePanel != null)
/* 354 */           this.framePanel.removeAll(); 
/* 355 */         this.player = null;
/* 356 */         this.visualComp = null;
/* 357 */         this.controlComp = null;
/* 358 */         sleep(200L);
/* 359 */         dispose();
/* 360 */       } else if (ce instanceof CachingControlEvent) {
/* 361 */         CachingControl cc = ((CachingControlEvent)ce).getCachingControl();
/* 362 */         if (cc != null && this.progressBar == null) {
/* 363 */           this.progressBar = cc.getControlComponent();
/* 364 */           if (this.progressBar == null)
/* 365 */             this.progressBar = cc.getProgressBarComponent(); 
/* 366 */           if (this.progressBar != null) {
/* 367 */             this.framePanel.add(this.progressBar);
/* 368 */             Dimension prefSize = this.progressBar.getPreferredSize();
/* 369 */             this.progressBar.setBounds(0, 0, prefSize.width, prefSize.height);
/* 370 */             this.insets = getInsets();
/* 371 */             this.framePanel.setSize(prefSize.width, prefSize.height);
/* 372 */             setSize(this.insets.left + this.insets.right + prefSize.width, this.insets.top + this.insets.bottom + prefSize.height);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void zoomTo(float z) {
/* 381 */     if (this.visualComp != null) {
/* 382 */       this.insets = getInsets();
/* 383 */       Dimension d = this.visualComp.getPreferredSize();
/* 384 */       d.width = (int)(d.width * z);
/* 385 */       d.height = (int)(d.height * z);
/* 386 */       if (this.controlComp != null) {
/* 387 */         d.height += (this.controlComp.getPreferredSize()).height;
/*     */       }
/* 389 */       setSize(d.width + this.insets.left + this.insets.right, d.height + this.insets.top + this.insets.bottom);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addPopupMenu(Component visual) {
/* 399 */     this.zoomMenu = new PopupMenu(MENU_ZOOM);
/*     */     
/* 401 */     ActionListener zoomSelect = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent ae) {
/* 403 */           String action = ae.getActionCommand();
/* 404 */           if (action.equals(PlayerWindow.MENU_ZOOM_1_2)) {
/* 405 */             this.this$0.zoomTo(0.5F);
/* 406 */           } else if (action.equals(PlayerWindow.MENU_ZOOM_1_1)) {
/* 407 */             this.this$0.zoomTo(1.0F);
/* 408 */           } else if (action.equals(PlayerWindow.MENU_ZOOM_2_1)) {
/* 409 */             this.this$0.zoomTo(2.0F);
/* 410 */           } else if (action.equals(PlayerWindow.MENU_ZOOM_4_1)) {
/* 411 */             this.this$0.zoomTo(4.0F);
/*     */           }  } private final PlayerWindow this$0;
/*     */       };
/* 414 */     visual.add(this.zoomMenu);
/* 415 */     MenuItem mi = new MenuItem(MENU_ZOOM_1_2);
/* 416 */     this.zoomMenu.add(mi);
/* 417 */     mi.addActionListener(zoomSelect);
/* 418 */     mi = new MenuItem(MENU_ZOOM_1_1);
/* 419 */     this.zoomMenu.add(mi);
/* 420 */     mi.addActionListener(zoomSelect);
/* 421 */     mi = new MenuItem(MENU_ZOOM_2_1);
/* 422 */     this.zoomMenu.add(mi);
/* 423 */     mi.addActionListener(zoomSelect);
/* 424 */     mi = new MenuItem(MENU_ZOOM_4_1);
/* 425 */     this.zoomMenu.add(mi);
/* 426 */     mi.addActionListener(zoomSelect);
/*     */     
/* 428 */     visual.addMouseListener(this.ml = new MouseAdapter(this) { private final PlayerWindow this$0;
/*     */           public void mousePressed(MouseEvent me) {
/* 430 */             if (me.isPopupTrigger())
/* 431 */               this.this$0.zoomMenu.show(this.this$0.visualComp, me.getX(), me.getY()); 
/*     */           }
/*     */           
/*     */           public void mouseReleased(MouseEvent me) {
/* 435 */             if (me.isPopupTrigger())
/* 436 */               this.this$0.zoomMenu.show(this.this$0.visualComp, me.getX(), me.getY()); 
/*     */           }
/*     */           
/*     */           public void mouseClicked(MouseEvent me) {
/* 440 */             if (me.isPopupTrigger())
/* 441 */               this.this$0.zoomMenu.show(this.this$0.visualComp, me.getX(), me.getY()); 
/*     */           } }
/*     */       );
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\PlayerWindow.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */