/*    */ package com.sun.media.ui;
/*    */ 
/*    */ import java.awt.Image;
/*    */ import java.awt.Toolkit;
/*    */ import java.awt.image.DirectColorModel;
/*    */ import java.awt.image.IndexColorModel;
/*    */ import java.awt.image.MemoryImageSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenerateImage
/*    */ {
/* 14 */   private IndexColorModel icm = null;
/* 15 */   private DirectColorModel dcm = null;
/*    */   
/* 17 */   private Image image = null;
/* 18 */   private byte[] data = null;
/*    */   private int width;
/*    */   private int height;
/* 21 */   byte[] reds = new byte[256];
/* 22 */   byte[] greens = new byte[256];
/* 23 */   byte[] blues = new byte[256];
/*    */ 
/*    */   
/*    */   private native int getColors(byte[] paramArrayOfbyte, int paramInt);
/*    */   
/*    */   public GenerateImage() {
/* 29 */     int ncolors = getColors(this.reds, 0);
/* 30 */     getColors(this.greens, 1);
/* 31 */     getColors(this.blues, 2);
/* 32 */     this.icm = new IndexColorModel(8, 256, this.reds, this.greens, this.blues, 0);
/*    */   }
/*    */   private native boolean generateImage(String paramString);
/*    */   public Image getImage(String imageName) {
/* 36 */     this.image = null;
/* 37 */     this.data = null;
/* 38 */     if (generateImage(imageName)) {
/* 39 */       createImage();
/* 40 */       return this.image;
/*    */     } 
/* 42 */     return null;
/*    */   }
/*    */   
/*    */   protected synchronized void createBuffer(int w, int h) {
/* 46 */     this.width = w;
/* 47 */     this.height = h;
/* 48 */     this.data = new byte[w * h];
/*    */   }
/*    */   
/*    */   protected synchronized void createImage() {
/* 52 */     MemoryImageSource mis = new MemoryImageSource(this.width, this.height, this.icm, this.data, 0, this.width);
/*    */     
/* 54 */     Toolkit tk = Toolkit.getDefaultToolkit();
/* 55 */     this.image = tk.createImage(mis);
/* 56 */     tk.prepareImage(this.image, this.width, this.height, null);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\GenerateImage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */