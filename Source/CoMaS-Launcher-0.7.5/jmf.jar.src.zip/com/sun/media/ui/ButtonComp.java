/*     */ package com.sun.media.ui;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.PopupMenu;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ButtonComp
/*     */   extends BasicComp
/*     */   implements MouseListener
/*     */ {
/*     */   Image[] imageNormal;
/*     */   Image[] imageActive;
/*     */   Image[] imageDown;
/*     */   Image[] imageDisabled;
/*     */   static final int NORMAL = 1;
/*     */   static final int ACTIVE = 2;
/*     */   static final int DOWN = 4;
/*     */   static final int DISABLED = 8;
/*     */   int width;
/*     */   int height;
/*     */   boolean state = false;
/*     */   boolean mouseIn = false;
/*     */   boolean mouseDown = false;
/*     */   boolean mouseUp = false;
/*     */   boolean mouseClick = false;
/*  31 */   int visualState = 1;
/*     */   
/*  33 */   private PopupMenu menuPopup = null;
/*  34 */   private ContPressThread threadContPress = null;
/*     */ 
/*     */   
/*     */   private boolean boolContPress = false;
/*     */ 
/*     */   
/*     */   private boolean boolPopup = false;
/*     */ 
/*     */   
/*     */   private boolean boolDoAction = false;
/*     */ 
/*     */   
/*     */   private static final int POPUP_DELAY = 1000;
/*     */ 
/*     */ 
/*     */   
/*     */   public ButtonComp(String label, String imgNormal0, String imgActive0, String imgDown0, String imgDisabled0, String imgNormal1, String imgActive1, String imgDown1, String imgDisabled1) {
/*  51 */     super(label);
/*     */ 
/*     */     
/*  54 */     this.imageNormal = new Image[2];
/*  55 */     this.imageActive = new Image[2];
/*  56 */     this.imageDown = new Image[2];
/*  57 */     this.imageDisabled = new Image[2];
/*     */ 
/*     */     
/*  60 */     this.imageNormal[0] = BasicComp.fetchImage(imgNormal0);
/*  61 */     this.imageNormal[1] = BasicComp.fetchImage(imgNormal1);
/*  62 */     this.imageActive[0] = BasicComp.fetchImage(imgActive0);
/*  63 */     this.imageActive[1] = BasicComp.fetchImage(imgActive1);
/*  64 */     this.imageDown[0] = BasicComp.fetchImage(imgDown0);
/*  65 */     this.imageDown[1] = BasicComp.fetchImage(imgDown1);
/*  66 */     this.imageDisabled[0] = BasicComp.fetchImage(imgDisabled0);
/*  67 */     this.imageDisabled[1] = BasicComp.fetchImage(imgDisabled1);
/*     */     
/*  69 */     this.width = this.imageNormal[0].getWidth(this);
/*  70 */     this.height = this.imageNormal[0].getHeight(this);
/*  71 */     this.visualState = 1;
/*  72 */     setSize(this.width, this.height);
/*  73 */     setVisible(true);
/*  74 */     addMouseListener(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseActivity() {
/*  79 */     if (isEnabled()) {
/*  80 */       if (this.mouseIn) {
/*  81 */         if (this.mouseDown) {
/*  82 */           this.visualState = 4;
/*  83 */           if (this.mouseUp) {
/*  84 */             action();
/*  85 */             this.visualState = 2;
/*     */           } 
/*     */         } else {
/*     */           
/*  89 */           this.visualState = 2;
/*     */         } 
/*     */       } else {
/*     */         
/*  93 */         this.visualState = 1;
/*     */       } 
/*     */     } else {
/*     */       
/*  97 */       this.visualState = 8;
/*     */     } 
/*  99 */     repaint();
/*     */   }
/*     */   
/*     */   public void action() {
/* 103 */     if (!this.boolDoAction)
/*     */       return; 
/* 105 */     this.state = !this.state;
/* 106 */     informListener();
/*     */   }
/*     */   
/*     */   public void paint(Graphics g) {
/* 110 */     int index = this.state ? 1 : 0;
/* 111 */     Image image = null;
/*     */     
/* 113 */     switch (this.visualState) {
/*     */       case 1:
/* 115 */         image = this.imageNormal[index];
/*     */         break;
/*     */       case 2:
/* 118 */         image = this.imageActive[index];
/*     */         break;
/*     */       case 4:
/* 121 */         image = this.imageDown[index];
/*     */         break;
/*     */       case 8:
/* 124 */         image = this.imageDisabled[index];
/*     */         break;
/*     */     } 
/* 127 */     if (image != null)
/* 128 */       g.drawImage(image, 0, 0, this); 
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean value) {
/* 132 */     super.setEnabled(value);
/* 133 */     if (!value) {
/* 134 */       this.visualState = 8;
/*     */ 
/*     */     
/*     */     }
/* 138 */     else if (this.mouseIn) {
/* 139 */       if (this.mouseDown) {
/* 140 */         this.visualState = 4;
/*     */       } else {
/* 142 */         this.visualState = 2;
/*     */       } 
/*     */     } else {
/* 145 */       this.visualState = 1;
/*     */     } 
/*     */ 
/*     */     
/* 149 */     repaint();
/*     */   }
/*     */   
/*     */   public boolean getValue() {
/* 153 */     return this.state;
/*     */   }
/*     */   
/*     */   public void setValue(boolean newState) {
/* 157 */     if (this.state != newState) {
/* 158 */       this.state = newState;
/* 159 */       repaint();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setPopupMenu(PopupMenu menuPopup) {
/* 164 */     if (menuPopup != null) {
/* 165 */       setMousePopup(true);
/* 166 */       this.menuPopup = menuPopup;
/* 167 */       add(menuPopup);
/* 168 */     } else if (this.menuPopup != null) {
/* 169 */       setMousePopup(false);
/* 170 */       remove(this.menuPopup);
/* 171 */       this.menuPopup = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setMousePopup(boolean boolPopup) {
/* 176 */     this.boolPopup = boolPopup;
/*     */   }
/*     */   
/*     */   public void setContMousePress(boolean boolSet) {
/* 180 */     this.boolContPress = boolSet;
/*     */   }
/*     */   
/*     */   public void mouseEntered(MouseEvent e) {
/* 184 */     this.mouseIn = true;
/* 185 */     mouseActivity();
/*     */   }
/*     */   
/*     */   public void mouseExited(MouseEvent e) {
/* 189 */     this.mouseIn = false;
/* 190 */     mouseActivity();
/*     */     
/* 192 */     if (this.threadContPress != null) {
/* 193 */       this.threadContPress.stopNormaly();
/* 194 */       this.threadContPress = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void mousePressed(MouseEvent e) {
/* 199 */     int modifier = e.getModifiers();
/* 200 */     if ((modifier & 0x8) == 0 && (modifier & 0x4) == 0) {
/*     */       
/* 202 */       this.mouseDown = true;
/* 203 */       this.mouseUp = false;
/* 204 */       mouseActivity();
/*     */       
/* 206 */       if (this.boolContPress == true || this.boolPopup == true) {
/* 207 */         if (this.threadContPress != null)
/* 208 */           this.threadContPress.stopNormaly(); 
/* 209 */         this.threadContPress = new ContPressThread(this, this);
/* 210 */         if (this.boolPopup == true)
/* 211 */           this.threadContPress.setDelayedPress(1000L); 
/* 212 */         this.threadContPress.start();
/*     */       } 
/* 214 */       this.boolDoAction = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void mouseReleased(MouseEvent e) {
/* 219 */     int modifier = e.getModifiers();
/* 220 */     if ((modifier & 0x8) == 0 && (modifier & 0x4) == 0) {
/*     */       
/* 222 */       this.mouseUp = true;
/* 223 */       mouseActivity();
/* 224 */       this.mouseUp = false;
/* 225 */       this.mouseDown = false;
/*     */       
/* 227 */       if (this.threadContPress != null) {
/* 228 */         this.threadContPress.stopNormaly();
/* 229 */         this.threadContPress = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void mouseClicked(MouseEvent e) {
/* 235 */     int modifier = e.getModifiers();
/* 236 */     if ((modifier & 0x8) == 0 && (modifier & 0x4) == 0) {
/*     */       
/* 238 */       this.mouseClick = true;
/* 239 */       mouseActivity();
/* 240 */       this.mouseClick = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public Dimension getPreferredSize() {
/* 245 */     return new Dimension(this.width, this.height);
/*     */   }
/*     */   
/*     */   protected void processMouseEvent(MouseEvent event) {
/* 249 */     super.processMouseEvent(event);
/*     */     
/* 251 */     if (event.isPopupTrigger()) {
/* 252 */       processMousePopup();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processMousePopup() {
/* 259 */     if (this.menuPopup != null)
/*     */     {
/* 261 */       this.menuPopup.show(this, 0, this.height);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void processContPress() {
/* 266 */     if (this.boolContPress == true) {
/* 267 */       informListener();
/* 268 */     } else if (this.boolPopup == true && this.mouseIn && this.mouseDown) {
/* 269 */       this.boolDoAction = false;
/* 270 */       processMousePopup();
/*     */     } 
/*     */   }
/*     */   
/*     */   class ContPressThread
/*     */     extends Thread
/*     */   {
/*     */     protected ButtonComp button;
/*     */     protected boolean boolContinueRun;
/*     */     protected boolean boolIgnoreFirst;
/*     */     protected boolean boolDelayedPress;
/*     */     protected long lMills;
/*     */     private final ButtonComp this$0;
/*     */     
/*     */     public ContPressThread(ButtonComp this$0, ButtonComp button) {
/* 285 */       this.this$0 = this$0; this.button = null; this.boolContinueRun = true; this.boolIgnoreFirst = true; this.boolDelayedPress = false; this.lMills = 500L;
/* 286 */       this.button = button;
/*     */     }
/*     */     
/*     */     public void setDelayedPress(long lMills) {
/* 290 */       this.boolDelayedPress = true;
/* 291 */       this.lMills = lMills;
/*     */     }
/*     */     
/*     */     public void stopNormaly() {
/* 295 */       this.boolContinueRun = false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 300 */       if (this.boolDelayedPress == true) {
/* 301 */         this.boolIgnoreFirst = false;
/*     */       } else {
/* 303 */         this.boolIgnoreFirst = true;
/*     */       } 
/* 305 */       while (this.boolContinueRun) {
/*     */         try {
/* 307 */           Thread.sleep(this.lMills);
/*     */         }
/* 309 */         catch (Exception exception) {}
/*     */         
/* 311 */         if (this.button != null && !this.boolIgnoreFirst)
/* 312 */           this.button.processContPress(); 
/* 313 */         this.boolIgnoreFirst = false;
/* 314 */         if (this.boolDelayedPress == true) {
/* 315 */           this.boolContinueRun = false;
/*     */         }
/*     */       } 
/* 318 */       this.boolDelayedPress = false;
/* 319 */       this.lMills = 250L;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\ButtonComp.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */