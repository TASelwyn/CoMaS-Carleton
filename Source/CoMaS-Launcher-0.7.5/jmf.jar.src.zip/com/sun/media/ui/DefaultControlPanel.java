/*     */ package com.sun.media.ui;
/*     */ import com.sun.media.util.JMFI18N;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.CheckboxMenuItem;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Insets;
/*     */ import java.awt.ItemSelectable;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.peer.ComponentPeer;
/*     */ import java.util.Vector;
/*     */ import javax.media.Control;
/*     */ import javax.media.ControllerEvent;
/*     */ import javax.media.Duration;
/*     */ import javax.media.Format;
/*     */ import javax.media.Player;
/*     */ import javax.media.Time;
/*     */ import javax.media.control.TrackControl;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ public class DefaultControlPanel extends BufferedPanelLight implements ActionListener, ItemListener, ControllerListener, GainChangeListener, ComponentListener {
/*  28 */   static final Color colorBackground = new Color(192, 192, 192);
/*     */   
/*  30 */   private static final String MENU_PROPERTIES = JMFI18N.getResource("mediaplayer.properties");
/*  31 */   private static final String MENU_RATE_1_4 = JMFI18N.getResource("mediaplayer.rate.1:4");
/*  32 */   private static final String MENU_RATE_1_2 = JMFI18N.getResource("mediaplayer.rate.1:2");
/*  33 */   private static final String MENU_RATE_1_1 = JMFI18N.getResource("mediaplayer.rate.1:1");
/*  34 */   private static final String MENU_RATE_2_1 = JMFI18N.getResource("mediaplayer.rate.2:1");
/*  35 */   private static final String MENU_RATE_4_1 = JMFI18N.getResource("mediaplayer.rate.4:1");
/*  36 */   private static final String MENU_RATE_8_1 = JMFI18N.getResource("mediaplayer.rate.8:1");
/*  37 */   private static final String MENU_MEDIA = JMFI18N.getResource("mediaplayer.menu.media");
/*  38 */   private static final String MENU_AUDIO = JMFI18N.getResource("mediaplayer.menu.audio");
/*  39 */   private static final String MENU_VIDEO = JMFI18N.getResource("mediaplayer.menu.video");
/*     */   
/*     */   Player player;
/*     */   
/*  43 */   Frame parentFrame = null;
/*     */   
/*  45 */   Container container = null;
/*     */   
/*     */   TransparentPanel panelLeft;
/*     */   TransparentPanel panelRight;
/*     */   TransparentPanel panelProgress;
/*     */   boolean boolAdded = false;
/*  51 */   ButtonComp buttonPlay = null;
/*  52 */   ButtonComp buttonStepBack = null;
/*  53 */   ButtonComp buttonStepFwd = null;
/*  54 */   AudioButton buttonAudio = null;
/*  55 */   ButtonComp buttonMedia = null;
/*  56 */   ProgressSlider progressSlider = null;
/*  57 */   CheckboxMenuItem menuItemCheck = null;
/*  58 */   PopupMenu menuPopup = null;
/*     */   
/*  60 */   WindowListener wl = null;
/*     */   private boolean firstTime = true;
/*     */   private boolean started = false;
/*  63 */   private Integer localLock = new Integer(0);
/*     */   
/*  65 */   GainControlComponent audioControls = null;
/*  66 */   PropertySheet propsSheet = null;
/*     */ 
/*     */ 
/*     */   
/*  70 */   FramePositioningControl controlFrame = null;
/*  71 */   ProgressControl progressControl = null;
/*  72 */   GainControl gainControl = null;
/*  73 */   SliderRegionControl regionControl = null;
/*  74 */   String urlName = null;
/*     */   
/*  76 */   long lFrameStep = 0L;
/*     */   
/*  78 */   private CheckboxMenuItem menuRate_1_4 = null;
/*  79 */   private CheckboxMenuItem menuRate_1_2 = null;
/*  80 */   private CheckboxMenuItem menuRate_1_1 = null;
/*  81 */   private CheckboxMenuItem menuRate_2_1 = null;
/*  82 */   private CheckboxMenuItem menuRate_4_1 = null;
/*  83 */   private CheckboxMenuItem menuRate_8_1 = null;
/*     */   
/*  85 */   private Vector vectorTracksAudio = new Vector();
/*  86 */   private Vector vectorTracksVideo = new Vector();
/*     */   
/*  88 */   private int pausecnt = -1;
/*     */ 
/*     */   
/*     */   private boolean resetMediaTimeinPause = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultControlPanel(Player player) {
/*  96 */     this.player = player;
/*     */     try {
/*  98 */       init();
/*     */     } catch (Exception exception) {
/*     */       
/* 101 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addNotify() {
/* 106 */     boolean boolLightweight = true;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     if (!this.boolAdded) {
/*     */       
/* 113 */       Container containerParent = getParent();
/* 114 */       while (containerParent != null && boolLightweight == true) {
/* 115 */         ComponentPeer compPeer = containerParent.getPeer();
/* 116 */         containerParent = containerParent.getParent();
/* 117 */         if (containerParent == null)
/*     */           break; 
/* 119 */         if (compPeer != null && !(compPeer instanceof java.awt.peer.LightweightPeer)) {
/* 120 */           boolLightweight = false;
/*     */         }
/*     */       } 
/* 123 */       if (this.container != null) {
/* 124 */         this.container.remove(this.panelLeft);
/* 125 */         this.container.remove(this.panelRight);
/* 126 */         this.container.remove(this.panelProgress);
/* 127 */         if (this.container != this) {
/* 128 */           remove(this.container);
/*     */         }
/*     */       } 
/* 131 */       if (boolLightweight == true) {
/* 132 */         this.container = this;
/*     */       } else {
/*     */         
/* 135 */         this.container = new BufferedPanel(new BorderLayout());
/* 136 */         this.container.setBackground(colorBackground);
/* 137 */         ((BufferedPanel)this.container).setBackgroundTile(BasicComp.fetchImage("texture3.gif"));
/* 138 */         add(this.container, "Center");
/*     */       } 
/* 140 */       this.container.add(this.panelLeft, "West");
/* 141 */       this.container.add(this.panelRight, "East");
/* 142 */       this.container.add(this.panelProgress, "Center");
/*     */       
/* 144 */       this.boolAdded = true;
/*     */     } 
/*     */     
/* 147 */     setVisible(true);
/* 148 */     super.addNotify();
/* 149 */     validate();
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeNotify() {
/* 154 */     super.removeNotify();
/* 155 */     if (this.boolAdded == true)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 161 */       this.boolAdded = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void removePlayButton() {
/* 167 */     this.panelLeft.remove(this.buttonPlay);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() throws Exception {
/* 184 */     getPlayerControls();
/* 185 */     if (this.gainControl != null) {
/* 186 */       this.gainControl.addGainChangeListener(this);
/*     */     }
/* 188 */     setBackground(colorBackground);
/* 189 */     setLayout(new BorderLayout());
/* 190 */     addComponentListener(this);
/*     */     
/* 192 */     this.container = this;
/* 193 */     this.panelLeft = new TransparentPanel(new GridLayout(1, 0));
/* 194 */     this.container.add(this.panelLeft, "West");
/* 195 */     this.panelRight = new TransparentPanel(new GridLayout(1, 0));
/* 196 */     this.container.add(this.panelRight, "East");
/* 197 */     this.panelProgress = new TransparentPanel(new BorderLayout());
/* 198 */     this.container.add(this.panelProgress, "Center");
/*     */     
/* 200 */     this.buttonPlay = new ButtonComp("Play", "play.gif", "play-active.gif", "play-pressed.gif", "play-disabled.gif", "pause.gif", "pause-active.gif", "pause-pressed.gif", "pause-disabled.gif");
/*     */ 
/*     */     
/* 203 */     this.buttonPlay.setActionListener(this);
/* 204 */     this.panelLeft.add(this.buttonPlay);
/*     */ 
/*     */ 
/*     */     
/* 208 */     if (this.controlFrame != null) {
/* 209 */       this.buttonStepBack = new ButtonComp("StepBack", "step-back.gif", "step-back-active.gif", "step-back-pressed.gif", "step-back-disabled.gif", "step-back.gif", "step-back-active.gif", "step-back-pressed.gif", "step-back-disabled.gif");
/*     */ 
/*     */       
/* 212 */       this.buttonStepBack.setActionListener(this);
/* 213 */       this.buttonStepBack.setContMousePress(true);
/* 214 */       this.panelLeft.add(this.buttonStepBack);
/*     */       
/* 216 */       this.buttonStepFwd = new ButtonComp("StepForward", "step-fwd.gif", "step-fwd-active.gif", "step-fwd-pressed.gif", "step-fwd-disabled.gif", "step-fwd.gif", "step-fwd-active.gif", "step-fwd-pressed.gif", "step-fwd-disabled.gif");
/*     */ 
/*     */       
/* 219 */       this.buttonStepFwd.setActionListener(this);
/* 220 */       this.buttonStepFwd.setContMousePress(true);
/* 221 */       this.panelLeft.add(this.buttonStepFwd);
/*     */     } 
/*     */     
/* 224 */     if (this.gainControl != null) {
/* 225 */       this.buttonAudio = new AudioButton(this.gainControl);
/* 226 */       this.buttonAudio.setActionListener(this);
/* 227 */       this.panelRight.add(this.buttonAudio);
/*     */     } 
/*     */     
/* 230 */     this.buttonMedia = new ButtonComp("Media", "media.gif", "media-active.gif", "media-pressed.gif", "media-disabled.gif", "media.gif", "media-active.gif", "media-pressed.gif", "media-disabled.gif");
/*     */ 
/*     */     
/* 233 */     this.buttonMedia.setActionListener(this);
/* 234 */     this.panelRight.add(this.buttonMedia);
/*     */     
/* 236 */     this.progressSlider = new ProgressSlider("mediatime", this, this.player);
/* 237 */     this.progressSlider.setActionListener(this);
/* 238 */     this.panelProgress.add(this.progressSlider, "Center");
/* 239 */     Time duration = this.player.getDuration();
/* 240 */     if (duration == Duration.DURATION_UNBOUNDED || duration == Duration.DURATION_UNKNOWN) {
/* 241 */       this.progressSlider.setEnabled(false);
/*     */     }
/* 243 */     updateButtonState();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 254 */     validate();
/* 255 */     Dimension dim = getPreferredSize();
/* 256 */     setSize(dim);
/* 257 */     setVisible(true);
/* 258 */     setBackgroundTile(BasicComp.fetchImage("texture3.gif"));
/* 259 */     this.player.addControllerListener(this);
/*     */     
/* 261 */     Control[] arrControls = this.player.getControls();
/* 262 */     int nCount = arrControls.length; int i;
/* 263 */     for (i = 0; i < nCount; i++) {
/* 264 */       if (arrControls[i] instanceof TrackControl) {
/*     */         
/* 266 */         TrackControl trackControl = (TrackControl)arrControls[i];
/* 267 */         Format format = trackControl.getFormat();
/*     */         
/* 269 */         if (format instanceof javax.media.format.AudioFormat) {
/* 270 */           this.vectorTracksAudio.addElement(trackControl);
/*     */         }
/* 272 */         else if (format instanceof VideoFormat) {
/* 273 */           this.vectorTracksVideo.addElement(trackControl);
/* 274 */           VideoFormat formatVideo = (VideoFormat)format;
/* 275 */           float frameRate = formatVideo.getFrameRate();
/* 276 */           this.lFrameStep = (long)(1.0E9F / frameRate);
/*     */         } 
/*     */       } 
/*     */     } 
/* 280 */     this.menuPopup = new PopupMenu(MENU_MEDIA);
/* 281 */     this.buttonMedia.setPopupMenu(this.menuPopup);
/*     */     
/* 283 */     nCount = this.vectorTracksAudio.size();
/*     */ 
/*     */ 
/*     */     
/* 287 */     boolean aTrackAudioIconEnabled = false;
/* 288 */     if (nCount > 1) {
/* 289 */       for (i = 0; i < nCount; i++) {
/* 290 */         TrackControl trackControl = this.vectorTracksAudio.elementAt(i);
/* 291 */         boolean boolEnable = false;
/* 292 */         if (!aTrackAudioIconEnabled && trackControl.isEnabled()) {
/* 293 */           aTrackAudioIconEnabled = true;
/* 294 */           boolEnable = true;
/*     */         } 
/* 296 */         this.menuItemCheck = new CheckboxMenuItem(MENU_AUDIO + " " + i, boolEnable);
/* 297 */         muteAudioTrack(trackControl, !boolEnable);
/* 298 */         this.menuItemCheck.addItemListener(this);
/* 299 */         this.menuPopup.add(this.menuItemCheck);
/*     */       } 
/* 301 */       this.menuPopup.addSeparator();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 314 */     this.menuRate_1_4 = new CheckboxMenuItem(MENU_RATE_1_4, false);
/* 315 */     this.menuRate_1_4.addItemListener(this);
/* 316 */     this.menuPopup.add(this.menuRate_1_4);
/* 317 */     this.menuRate_1_2 = new CheckboxMenuItem(MENU_RATE_1_2, false);
/* 318 */     this.menuRate_1_2.addItemListener(this);
/* 319 */     this.menuPopup.add(this.menuRate_1_2);
/* 320 */     this.menuRate_1_1 = new CheckboxMenuItem(MENU_RATE_1_1, true);
/* 321 */     this.menuRate_1_1.addItemListener(this);
/* 322 */     this.menuPopup.add(this.menuRate_1_1);
/* 323 */     this.menuRate_2_1 = new CheckboxMenuItem(MENU_RATE_2_1, false);
/* 324 */     this.menuRate_2_1.addItemListener(this);
/* 325 */     this.menuPopup.add(this.menuRate_2_1);
/* 326 */     this.menuRate_4_1 = new CheckboxMenuItem(MENU_RATE_4_1, false);
/* 327 */     this.menuRate_4_1.addItemListener(this);
/* 328 */     this.menuPopup.add(this.menuRate_4_1);
/* 329 */     this.menuRate_8_1 = new CheckboxMenuItem(MENU_RATE_8_1, false);
/* 330 */     this.menuRate_8_1.addItemListener(this);
/* 331 */     this.menuPopup.add(this.menuRate_8_1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateButtonState() {
/* 340 */     if (this.player == null) {
/* 341 */       this.buttonPlay.setEnabled(false);
/*     */     } else {
/*     */       
/* 344 */       this.buttonPlay.setEnabled(true);
/* 345 */       if (this.player.getState() == 600) {
/* 346 */         this.buttonPlay.setValue(true);
/*     */       } else {
/* 348 */         this.buttonPlay.setValue(false);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public void minicleanUp() {
/* 353 */     synchronized (this.localLock) {
/* 354 */       this.firstTime = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void dispose() {
/* 359 */     synchronized (this.localLock) {
/*     */       
/* 361 */       if (this.player == null) {
/*     */         return;
/*     */       }
/* 364 */       if (this.propsSheet != null) {
/* 365 */         this.propsSheet.dispose();
/* 366 */         this.propsSheet = null;
/*     */       } 
/* 368 */       if (this.progressSlider != null) {
/* 369 */         this.progressSlider.dispose();
/* 370 */         this.progressSlider = null;
/*     */       } 
/* 372 */       if (this.audioControls != null) {
/* 373 */         remove(this.audioControls);
/* 374 */         this.audioControls = null;
/*     */       } 
/* 376 */       if (this.buttonAudio != null) {
/* 377 */         this.buttonAudio.dispose();
/* 378 */         this.buttonAudio = null;
/*     */       } 
/*     */       
/* 381 */       this.player = null;
/* 382 */       this.gainControl = null;
/* 383 */       this.controlFrame = null;
/*     */       
/* 385 */       if (this.parentFrame != null && this.wl != null) {
/* 386 */         this.parentFrame.removeWindowListener(this.wl);
/* 387 */         this.parentFrame = null;
/* 388 */         this.wl = null;
/*     */       } 
/*     */       
/* 391 */       this.vectorTracksAudio.removeAllElements();
/* 392 */       this.vectorTracksVideo.removeAllElements();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 399 */       if (this.menuItemCheck != null)
/* 400 */         this.menuItemCheck.removeItemListener(this); 
/* 401 */       this.menuRate_1_4.removeItemListener(this);
/* 402 */       this.menuRate_1_2.removeItemListener(this);
/* 403 */       this.menuRate_8_1.removeItemListener(this);
/* 404 */       this.menuRate_4_1.removeItemListener(this);
/* 405 */       this.menuRate_2_1.removeItemListener(this);
/* 406 */       this.menuRate_1_1.removeItemListener(this);
/* 407 */       this.buttonMedia.setPopupMenu(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void getPlayerControls() {
/* 414 */     if (this.player == null)
/*     */       return; 
/* 416 */     this.gainControl = this.player.getGainControl();
/*     */     
/* 418 */     Control control = this.player.getControl("javax.media.control.FramePositioningControl");
/* 419 */     if (control != null && control instanceof FramePositioningControl) {
/* 420 */       this.controlFrame = (FramePositioningControl)control;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void actionPerformed(ActionEvent ae) {
/* 435 */     String command = ae.getActionCommand();
/* 436 */     if (command.equalsIgnoreCase(this.buttonPlay.getLabel())) {
/* 437 */       playStop();
/*     */     }
/* 439 */     if (this.buttonAudio != null && command.equalsIgnoreCase(this.buttonAudio.getLabel())) {
/* 440 */       audioMute();
/*     */     }
/* 442 */     else if (command.equalsIgnoreCase(this.buttonMedia.getLabel()) || command.equalsIgnoreCase(MENU_PROPERTIES)) {
/*     */       
/* 444 */       showPropsSheet();
/*     */     }
/* 446 */     else if (this.buttonStepBack != null && command.equalsIgnoreCase(this.buttonStepBack.getLabel())) {
/* 447 */       playStep(false);
/*     */     }
/* 449 */     else if (this.buttonStepFwd != null && command.equalsIgnoreCase(this.buttonStepFwd.getLabel())) {
/* 450 */       playStep(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void itemStateChanged(ItemEvent event) {
/* 464 */     ItemSelectable item = event.getItemSelectable();
/* 465 */     int nState = event.getStateChange();
/* 466 */     Object objectItem = event.getItem();
/* 467 */     if (item == this.menuRate_1_4 && nState == 1) {
/* 468 */       this.menuRate_1_4.setState(false);
/* 469 */       this.player.setRate(0.25F);
/*     */     }
/* 471 */     else if (item == this.menuRate_1_2 && nState == 1) {
/* 472 */       this.menuRate_1_2.setState(false);
/* 473 */       this.player.setRate(0.5F);
/*     */     }
/* 475 */     else if (item == this.menuRate_1_1 && nState == 1) {
/* 476 */       this.menuRate_1_1.setState(false);
/* 477 */       this.player.setRate(1.0F);
/*     */     }
/* 479 */     else if (item == this.menuRate_2_1 && nState == 1) {
/* 480 */       this.menuRate_2_1.setState(false);
/* 481 */       this.player.setRate(2.0F);
/*     */     }
/* 483 */     else if (item == this.menuRate_4_1 && nState == 1) {
/* 484 */       this.menuRate_4_1.setState(false);
/* 485 */       this.player.setRate(4.0F);
/*     */     }
/* 487 */     else if (item == this.menuRate_8_1 && nState == 1) {
/* 488 */       this.menuRate_8_1.setState(false);
/* 489 */       this.player.setRate(8.0F);
/*     */     }
/* 491 */     else if (objectItem instanceof String) {
/* 492 */       String strItem = (String)objectItem;
/* 493 */       if (strItem.substring(0, 5).equalsIgnoreCase(MENU_AUDIO)) {
/* 494 */         int nIndex = Integer.valueOf(strItem.substring(6)).intValue();
/* 495 */         TrackControl trackControl = this.vectorTracksAudio.elementAt(nIndex);
/* 496 */         boolean boolEnabled = (event.getStateChange() == 1);
/* 497 */         muteAudioTrack(trackControl, !boolEnabled);
/*     */       }
/* 499 */       else if (strItem.substring(0, 5).equalsIgnoreCase(MENU_VIDEO)) {
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */   void update() {
/* 505 */     if (this.propsSheet == null || this.player == null) {
/*     */       return;
/*     */     }
/* 508 */     if (this.player.getState() == 600) {
/* 509 */       this.pausecnt = -1;
/* 510 */       this.propsSheet.update();
/*     */     
/*     */     }
/* 513 */     else if (this.pausecnt < 5) {
/* 514 */       this.pausecnt++;
/* 515 */       this.propsSheet.update();
/*     */     }
/* 517 */     else if (this.pausecnt == 5) {
/* 518 */       this.pausecnt++;
/* 519 */       this.propsSheet.clearBRFR();
/*     */     }
/* 521 */     else if (this.resetMediaTimeinPause) {
/* 522 */       this.resetMediaTimeinPause = false;
/* 523 */       this.propsSheet.updateMediaTime();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void resetPauseCount() {
/* 530 */     this.pausecnt = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void playStop() {
/* 538 */     boolean state = this.buttonPlay.getValue();
/*     */     
/* 540 */     synchronized (this.localLock) {
/* 541 */       if (this.player == null || this.buttonPlay == null)
/*     */         return; 
/* 543 */       if (state) {
/* 544 */         if (this.player.getTargetState() != 600)
/*     */         {
/*     */ 
/*     */           
/* 548 */           this.buttonPlay.setEnabled(false);
/*     */           
/* 550 */           long lDuration = this.player.getDuration().getNanoseconds();
/* 551 */           long lMedia = this.player.getMediaNanoseconds();
/* 552 */           if (lMedia >= lDuration)
/* 553 */             this.player.setMediaTime(new Time(0L)); 
/* 554 */           this.player.start();
/*     */         }
/*     */       
/*     */       }
/* 558 */       else if (this.player.getTargetState() == 600) {
/* 559 */         this.buttonPlay.setEnabled(false);
/* 560 */         this.player.stop();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void audioMute() {
/* 572 */     if (this.gainControl == null) {
/*     */       return;
/*     */     }
/* 575 */     boolean boolState = this.buttonAudio.getValue();
/* 576 */     this.gainControl.setMute(boolState);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void playStep(boolean boolFwd) {
/* 582 */     if (this.controlFrame == null) {
/*     */       return;
/*     */     }
/* 585 */     if (this.player.getTargetState() == 600) {
/* 586 */       this.buttonPlay.setEnabled(false);
/* 587 */       this.player.stop();
/*     */     } 
/* 589 */     this.controlFrame.skip(boolFwd ? 1 : -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void controllerUpdate(ControllerEvent ce) {
/* 596 */     synchronized (this.localLock) {
/* 597 */       if (this.player == null)
/*     */         return; 
/* 599 */       if (ce instanceof javax.media.StartEvent) {
/* 600 */         this.buttonPlay.setValue(true);
/* 601 */         this.buttonPlay.setEnabled(true);
/* 602 */         if (this.buttonStepFwd != null)
/* 603 */           this.buttonStepFwd.setEnabled(true); 
/* 604 */         if (this.buttonStepBack != null) {
/* 605 */           this.buttonStepBack.setEnabled(true);
/*     */         }
/* 607 */       } else if (ce instanceof javax.media.StopEvent || ce instanceof javax.media.ResourceUnavailableEvent) {
/*     */         
/* 609 */         this.buttonPlay.setValue(false);
/* 610 */         this.buttonPlay.setEnabled(true);
/*     */         
/* 612 */         Thread.yield();
/* 613 */         long lDuration = this.player.getDuration().getNanoseconds();
/* 614 */         long lMedia = this.player.getMediaNanoseconds();
/* 615 */         if (this.buttonStepFwd != null)
/* 616 */           if (lMedia < lDuration - 1L) {
/* 617 */             this.buttonStepFwd.setEnabled(true);
/*     */           } else {
/* 619 */             this.buttonStepFwd.setEnabled(false);
/*     */           }  
/* 621 */         if (this.buttonStepBack != null) {
/* 622 */           if (lMedia > 0L) {
/* 623 */             this.buttonStepBack.setEnabled(true);
/*     */           } else {
/* 625 */             this.buttonStepBack.setEnabled(false);
/*     */           } 
/*     */         }
/* 628 */       } else if (ce instanceof javax.media.DurationUpdateEvent) {
/* 629 */         Time duration = this.player.getDuration();
/* 630 */         if (duration == Duration.DURATION_UNKNOWN || duration == Duration.DURATION_UNBOUNDED) {
/* 631 */           this.progressSlider.setEnabled(false);
/*     */         } else {
/* 633 */           this.progressSlider.setEnabled(true);
/*     */         } 
/* 635 */         if (this.propsSheet != null) {
/* 636 */           this.propsSheet.updateDuration();
/*     */         }
/* 638 */       } else if (ce instanceof javax.media.MediaTimeSetEvent) {
/* 639 */         Thread.yield();
/* 640 */         long l1 = this.player.getDuration().getNanoseconds();
/* 641 */         long l2 = this.player.getMediaNanoseconds();
/* 642 */         if (this.buttonStepFwd != null)
/* 643 */           if (l2 < l1 - 1L) {
/* 644 */             this.buttonStepFwd.setEnabled(true);
/*     */           } else {
/* 646 */             this.buttonStepFwd.setEnabled(false);
/*     */           }  
/* 648 */         if (this.buttonStepBack != null) {
/* 649 */           if (l2 > 0L) {
/* 650 */             this.buttonStepBack.setEnabled(true);
/*     */           } else {
/* 652 */             this.buttonStepBack.setEnabled(false);
/*     */           } 
/*     */         }
/* 655 */         this.resetMediaTimeinPause = true;
/*     */       }
/* 657 */       else if (ce instanceof javax.media.RateChangeEvent) {
/*     */ 
/*     */         
/* 660 */         this.menuRate_1_4.setState(false);
/* 661 */         this.menuRate_1_2.setState(false);
/* 662 */         this.menuRate_1_1.setState(false);
/* 663 */         this.menuRate_2_1.setState(false);
/* 664 */         this.menuRate_4_1.setState(false);
/* 665 */         this.menuRate_8_1.setState(false);
/*     */         
/* 667 */         float fRate = this.player.getRate();
/* 668 */         if (fRate < 0.5D) {
/* 669 */           this.menuRate_1_4.removeItemListener(this);
/* 670 */           this.menuRate_1_4.setState(true);
/* 671 */           this.menuRate_1_4.addItemListener(this);
/*     */         }
/* 673 */         else if (fRate < 1.0D) {
/* 674 */           this.menuRate_1_2.removeItemListener(this);
/* 675 */           this.menuRate_1_2.setState(true);
/* 676 */           this.menuRate_1_2.addItemListener(this);
/*     */         }
/* 678 */         else if (fRate > 4.0D) {
/* 679 */           this.menuRate_8_1.removeItemListener(this);
/* 680 */           this.menuRate_8_1.setState(true);
/* 681 */           this.menuRate_8_1.addItemListener(this);
/*     */         }
/* 683 */         else if (fRate > 2.0D) {
/* 684 */           this.menuRate_4_1.removeItemListener(this);
/* 685 */           this.menuRate_4_1.setState(true);
/* 686 */           this.menuRate_4_1.addItemListener(this);
/*     */         }
/* 688 */         else if (fRate > 1.0D) {
/* 689 */           this.menuRate_2_1.removeItemListener(this);
/* 690 */           this.menuRate_2_1.setState(true);
/* 691 */           this.menuRate_2_1.addItemListener(this);
/*     */         } else {
/*     */           
/* 694 */           this.menuRate_1_1.removeItemListener(this);
/* 695 */           this.menuRate_1_1.setState(true);
/* 696 */           this.menuRate_1_1.addItemListener(this);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void gainChange(GainChangeEvent event) {
/* 705 */     boolean boolMute = this.gainControl.getMute();
/* 706 */     this.buttonAudio.setValue(boolMute);
/*     */   }
/*     */   
/*     */   public void componentResized(ComponentEvent e) {
/* 710 */     validate();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void componentMoved(ComponentEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void componentShown(ComponentEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void componentHidden(ComponentEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics g) {
/* 728 */     if (this.firstTime) {
/* 729 */       findFrame();
/*     */     }
/* 731 */     super.paint(g);
/*     */   }
/*     */   
/*     */   protected void findFrame() {
/* 735 */     synchronized (this.localLock) {
/* 736 */       if (this.firstTime) {
/* 737 */         this.firstTime = false;
/* 738 */         Component c = getParent();
/* 739 */         while (!(c instanceof Frame) && c != null) {
/* 740 */           c = c.getParent();
/*     */         }
/* 742 */         if (c instanceof Frame) {
/* 743 */           this.parentFrame = (Frame)c;
/* 744 */           ((Frame)c).addWindowListener(this.wl = new WindowAdapter(this) { private final DefaultControlPanel this$0;
/*     */                 public void windowClosing(WindowEvent we) {
/* 746 */                   this.this$0.minicleanUp();
/*     */                 } }
/*     */             );
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Insets getInsets() {
/* 758 */     Insets insets = new Insets(1, 0, 0, 0);
/* 759 */     return insets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void showPropsSheet() {
/* 766 */     if (this.propsSheet == null) {
/*     */       try {
/* 768 */         this.propsSheet = new PropertySheet(this.parentFrame, this.player);
/* 769 */         if (isShowing()) {
/* 770 */           Point point = getLocationOnScreen();
/* 771 */           Dimension dim = getSize();
/* 772 */           point.y += dim.height;
/* 773 */           this.propsSheet.setLocation(point);
/*     */         } 
/*     */       } catch (Exception e) {
/*     */         
/* 777 */         this.propsSheet = null;
/*     */       } 
/*     */     }
/*     */     
/* 781 */     if (this.propsSheet != null) {
/* 782 */       this.propsSheet.setVisible(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void muteAudioTrack(TrackControl trackControl, boolean boolMute) {
/* 792 */     Object[] arrControls = trackControl.getControls();
/* 793 */     int nCount = arrControls.length;
/* 794 */     for (int i = 0; i < nCount; i++) {
/* 795 */       if (arrControls[i] instanceof GainControl)
/* 796 */         ((GainControl)arrControls[i]).setMute(boolMute); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\DefaultControlPanel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */