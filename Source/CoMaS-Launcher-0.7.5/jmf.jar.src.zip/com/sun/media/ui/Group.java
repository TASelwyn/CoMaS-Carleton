/*    */ package com.sun.media.ui;
/*    */ 
/*    */ import java.awt.Container;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Insets;
/*    */ import java.awt.LayoutManager;
/*    */ 
/*    */ public class Group
/*    */   extends Container {
/*    */   protected int border;
/*    */   
/*    */   public Group() {
/* 14 */     this(null, 0);
/*    */   }
/*    */   
/*    */   public Group(LayoutManager layout) {
/* 18 */     this(layout, 0);
/*    */   }
/*    */   
/*    */   public Group(LayoutManager layout, int border) {
/* 22 */     setLayout(layout);
/* 23 */     this.border = border;
/*    */   }
/*    */   
/*    */   public void paint(Graphics g) {
/* 27 */     Dimension size = getSize();
/*    */     
/* 29 */     super.paint(g);
/* 30 */     if (this.border > 0) {
/* 31 */       g.setColor(getBackground());
/* 32 */       g.drawRect(0, 0, size.width - 1, size.height - 1);
/* 33 */       g.draw3DRect(this.border - 2, this.border - 2, size.width - 1 - 2 * (this.border - 2), size.height - 1 - 2 * (this.border - 2), false);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Insets getInsets() {
/* 40 */     return new Insets(this.border, this.border, this.border, this.border);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\Group.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */