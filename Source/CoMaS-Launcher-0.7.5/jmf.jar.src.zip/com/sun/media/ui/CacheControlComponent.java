/*    */ package com.sun.media.ui;
/*    */ 
/*    */ import com.sun.media.util.JMFI18N;
/*    */ import java.awt.Component;
/*    */ import java.awt.GridBagConstraints;
/*    */ import java.awt.GridBagLayout;
/*    */ import java.awt.Label;
/*    */ import javax.media.CachingControl;
/*    */ import javax.media.ExtendedCachingControl;
/*    */ import javax.media.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheControlComponent
/*    */   extends BufferedPanel
/*    */ {
/*    */   protected CachingControl ctrl;
/*    */   private ExtendedCachingControl xtdctrl;
/*    */   protected Player player;
/*    */   protected ButtonComp cancelButton;
/*    */   protected ProgressBar progressBar;
/*    */   
/*    */   public void addNotify() {
/*    */     super.addNotify();
/*    */     setSize(getPreferredSize());
/*    */   }
/*    */   
/*    */   public Component getProgressBar() {
/*    */     return this.progressBar;
/*    */   }
/*    */   
/*    */   public CacheControlComponent(CachingControl ctrl, Player player) {
/* 58 */     this.ctrl = null;
/* 59 */     this.xtdctrl = null;
/* 60 */     this.player = null;
/* 61 */     this.cancelButton = null;
/* 62 */     this.progressBar = null; this.ctrl = ctrl; this.player = player; if (ctrl instanceof ExtendedCachingControl)
/*    */       this.xtdctrl = (ExtendedCachingControl)ctrl;  setBackground(DefaultControlPanel.colorBackground); setBackgroundTile(BasicComp.fetchImage("texture3.gif")); GridBagLayout gbl; setLayout(gbl = new GridBagLayout()); GridBagConstraints gbc = new GridBagConstraints(); gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 0; Label label = new Label(JMFI18N.getResource("mediaplayer.download"), 1); add(label); gbl.setConstraints(label, gbc); gbc.gridy++; gbc.gridwidth = 1; this.cancelButton = new CancelButton(this); add(this.cancelButton); gbl.setConstraints(this.cancelButton, gbc);
/*    */     gbc.gridx++;
/*    */     this.progressBar = new ProgressBar(ctrl);
/*    */     add(this.progressBar);
/* 67 */     gbl.setConstraints(this.progressBar, gbc); } class CancelButton extends ButtonComp { public CancelButton(CacheControlComponent this$0) { super("Suspend download", "pause.gif", "pause-active.gif", "pause-pressed.gif", "pause-disabled.gif", "play.gif", "play-active.gif", "play-pressed.gif", "play-disabled.gif");
/*    */       this.this$0 = this$0; }
/*    */     
/*    */     private final CacheControlComponent this$0;
/*    */     
/*    */     public void action() {
/* 73 */       super.action();
/* 74 */       if (this.this$0.player != null);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 85 */       if (this.this$0.xtdctrl != null)
/* 86 */         if (this.state) {
/* 87 */           this.this$0.xtdctrl.pauseDownload();
/*    */         } else {
/* 89 */           this.this$0.xtdctrl.resumeDownload();
/*    */         }  
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\CacheControlComponent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */