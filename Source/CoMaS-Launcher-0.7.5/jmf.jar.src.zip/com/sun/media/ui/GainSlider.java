/*      */ package com.sun.media.ui;
/*      */ 
/*      */ import java.awt.Button;
/*      */ import java.awt.Color;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Frame;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Image;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Window;
/*      */ import java.awt.event.FocusEvent;
/*      */ import java.awt.event.FocusListener;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.event.MouseListener;
/*      */ import java.awt.event.MouseMotionListener;
/*      */ import javax.media.GainChangeEvent;
/*      */ import javax.media.GainChangeListener;
/*      */ import javax.media.GainControl;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class GainSlider
/*      */   extends Window
/*      */   implements GainChangeListener, MouseListener, MouseMotionListener, FocusListener
/*      */ {
/*      */   private GainControl gainControl;
/*  890 */   private Image imageGrabber = null;
/*  891 */   private Dimension dimGrabber = new Dimension();
/*      */   private Button buttonFocus;
/*      */   private boolean boolFocus = false;
/*      */   private boolean pressed = false;
/*  895 */   private PopupThread threadPopup = null;
/*  896 */   private Image imageBackground = null;
/*      */   
/*      */   private static final int WIDTH = 80;
/*      */   private static final int HEIGHT = 20;
/*      */   
/*      */   public GainSlider(GainControl gainControl) {
/*  902 */     this(gainControl, new Frame());
/*      */   }
/*      */   
/*      */   public GainSlider(GainControl gainControl, Frame frame) {
/*  906 */     super(frame);
/*      */     
/*  908 */     this.gainControl = gainControl;
/*      */     try {
/*  910 */       init();
/*      */     }
/*  912 */     catch (Exception exception) {}
/*      */   }
/*      */ 
/*      */   
/*      */   public void dispose() {
/*  917 */     this.gainControl = null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addNotify() {
/*  923 */     super.addNotify();
/*  924 */     Insets insets = getInsets();
/*  925 */     setSize(80 + insets.left + insets.right, 20 + insets.top + insets.bottom);
/*      */   }
/*      */   
/*      */   private void init() throws Exception {
/*  929 */     this.gainControl.addGainChangeListener(this);
/*  930 */     addMouseListener(this);
/*  931 */     addMouseMotionListener(this);
/*  932 */     setLayout(null);
/*  933 */     this.imageBackground = BasicComp.fetchImage("texture3.gif");
/*      */     
/*  935 */     this.buttonFocus = new Button("Focus");
/*  936 */     this.buttonFocus.setBounds(-100, -100, 80, 24);
/*  937 */     add(this.buttonFocus);
/*  938 */     this.buttonFocus.addFocusListener(this);
/*      */     
/*  940 */     this.imageGrabber = BasicComp.fetchImage("grabber.gif");
/*  941 */     setBackground(Color.lightGray);
/*  942 */     setSize(80, 20);
/*      */   }
/*      */   
/*      */   public void setVisible(boolean boolVisible) {
/*  946 */     super.setVisible(boolVisible);
/*      */     
/*  948 */     if (boolVisible == true) {
/*  949 */       this.buttonFocus.requestFocus();
/*  950 */       if (this.threadPopup != null) {
/*  951 */         this.threadPopup.stopNormaly();
/*      */       }
/*  953 */       this.threadPopup = new PopupThread(this);
/*  954 */       this.threadPopup.resetCounter(3);
/*  955 */       this.threadPopup.start();
/*      */     }
/*  957 */     else if (this.threadPopup != null) {
/*  958 */       this.threadPopup.stopNormaly();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void update(Graphics g) {
/*      */     Graphics graphics;
/*  967 */     Rectangle rectClient = getBounds();
/*  968 */     Image image = createImage(rectClient.width, rectClient.height);
/*  969 */     if (image != null) {
/*  970 */       graphics = image.getGraphics();
/*      */     } else {
/*  972 */       graphics = g;
/*      */     } 
/*  974 */     paint(graphics);
/*      */     
/*  976 */     if (image != null) {
/*  977 */       g.drawImage(image, 0, 0, this);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void paint(Graphics graphics) {
/*  989 */     paintBackground(graphics);
/*      */     
/*  991 */     Dimension dimSize = getSize();
/*  992 */     Insets insets = getInsets();
/*  993 */     Rectangle rect = new Rectangle(insets.left, insets.top, dimSize.width - insets.left - insets.right, dimSize.height - insets.top - insets.bottom);
/*      */ 
/*      */ 
/*      */     
/*  997 */     graphics.setColor(getBackground());
/*  998 */     graphics.draw3DRect(rect.x, rect.y, rect.width - 1, rect.height - 1, true);
/*  999 */     graphics.draw3DRect(rect.x + 4, rect.y + rect.height / 2 - 2, rect.width - 9, 3, false);
/*      */     
/* 1001 */     if (this.dimGrabber.width < 1)
/* 1002 */       this.dimGrabber.width = this.imageGrabber.getWidth(this); 
/* 1003 */     if (this.dimGrabber.height < 1) {
/* 1004 */       this.dimGrabber.height = this.imageGrabber.getHeight(this);
/*      */     }
/* 1006 */     float levelGain = this.gainControl.getLevel();
/* 1007 */     int x = rect.x + (int)(2.0F + levelGain * (rect.width - 5 - this.dimGrabber.width));
/* 1008 */     int y = rect.y + (rect.height - this.dimGrabber.height) / 2;
/* 1009 */     graphics.drawImage(this.imageGrabber, x, y, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void paintBackground(Graphics graphics) {
/* 1017 */     Dimension dimSize = getSize();
/* 1018 */     if (this.imageBackground == null) {
/* 1019 */       graphics.setColor(getBackground());
/* 1020 */       graphics.fillRect(0, 0, dimSize.width, dimSize.height);
/*      */     } else {
/*      */       
/* 1023 */       Rectangle rectTile = new Rectangle(0, 0, this.imageBackground.getWidth(this), this.imageBackground.getHeight(this));
/* 1024 */       Rectangle rectClip = graphics.getClipBounds();
/*      */       
/* 1026 */       while (rectTile.y < dimSize.height) {
/* 1027 */         while (rectTile.x < dimSize.width) {
/* 1028 */           if (rectClip == null || rectClip.intersects(rectTile)) {
/* 1029 */             graphics.drawImage(this.imageBackground, rectTile.x, rectTile.y, this);
/*      */           }
/* 1031 */           rectTile.x += rectTile.width;
/*      */         } 
/* 1033 */         rectTile.x = 0;
/* 1034 */         rectTile.y += rectTile.height;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void gainChange(GainChangeEvent event) {
/* 1040 */     repaint();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void mouseClicked(MouseEvent event) {}
/*      */ 
/*      */   
/*      */   public void mousePressed(MouseEvent event) {
/* 1049 */     if (this.threadPopup != null)
/* 1050 */       this.threadPopup.resetCounter(3); 
/* 1051 */     Point pointMouse = event.getPoint();
/* 1052 */     setLevelToMouse(pointMouse);
/* 1053 */     this.pressed = true;
/*      */   }
/*      */   
/*      */   public void mouseReleased(MouseEvent event) {
/* 1057 */     this.pressed = false;
/* 1058 */     if (!this.boolFocus)
/* 1059 */       setVisible(false); 
/*      */   }
/*      */   
/*      */   public void mouseEntered(MouseEvent event) {
/* 1063 */     this.boolFocus = true;
/* 1064 */     if (this.threadPopup != null)
/* 1065 */       this.threadPopup.stopNormaly(); 
/*      */   }
/*      */   
/*      */   public void mouseExited(MouseEvent event) {
/* 1069 */     if (this.boolFocus == true && !this.pressed)
/* 1070 */       setVisible(false); 
/* 1071 */     this.boolFocus = false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void mouseDragged(MouseEvent event) {
/* 1077 */     if (this.threadPopup != null)
/* 1078 */       this.threadPopup.resetCounter(3); 
/* 1079 */     Point pointMouse = event.getPoint();
/* 1080 */     setLevelToMouse(pointMouse);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void mouseMoved(MouseEvent event) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void focusLost(FocusEvent event) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void focusGained(FocusEvent event) {}
/*      */ 
/*      */ 
/*      */   
/*      */   private void setLevelToMouse(Point pointMouse) {
/* 1099 */     if (this.gainControl == null) {
/*      */       return;
/*      */     }
/* 1102 */     Dimension dimSize = getSize();
/* 1103 */     Insets insets = getInsets();
/*      */     
/* 1105 */     int nPos = pointMouse.x - 2 - insets.left;
/* 1106 */     int nWidth = dimSize.width - insets.left - insets.right - 5;
/* 1107 */     if (nPos > nWidth)
/* 1108 */       nPos = nWidth; 
/* 1109 */     if (nPos < 0)
/* 1110 */       nPos = 0; 
/* 1111 */     float levelGain = nPos / nWidth;
/* 1112 */     this.gainControl.setMute(false);
/* 1113 */     this.gainControl.setLevel(levelGain);
/*      */   }
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\GainSlider.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */