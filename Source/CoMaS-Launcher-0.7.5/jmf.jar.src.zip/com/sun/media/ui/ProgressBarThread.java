package com.sun.media.ui;

import java.awt.Component;
import javax.media.CachingControl;

class ProgressBarThread extends Thread {
  private Component progressBar;
  
  private CachingControl cachingControl;
  
  private long lengthContent;
  
  public ProgressBarThread(Component progressBar, CachingControl cachingControl) {
    this.progressBar = progressBar;
    this.cachingControl = cachingControl;
    this.lengthContent = cachingControl.getContentLength();
  }
  
  public void run() {
    long lengthProgress = 0L;
    while (lengthProgress < this.lengthContent) {
      try {
        Thread.sleep(300L);
      } catch (Exception exception) {}
      lengthProgress = this.cachingControl.getContentProgress();
      this.progressBar.repaint();
    } 
  }
}
