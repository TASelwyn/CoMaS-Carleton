package com.sun.media.ui;

import java.awt.Color;
import java.awt.Graphics;
import javax.media.CachingControl;

public class ProgressBar extends Slider {
  private CachingControl cc = null;
  
  private Color cb;
  
  private Color cd;
  
  private Color cm;
  
  private ProgressBarThread threadUpdate;
  
  public ProgressBar(CachingControl cc) {
    this.cc = cc;
    setGrabberVisible(false);
    setBackground(DefaultControlPanel.colorBackground);
    this.threadUpdate = new ProgressBarThread(this, cc);
    this.threadUpdate.start();
  }
  
  public void update(Graphics g) {
    paint(g);
  }
  
  public void paint(Graphics g) {
    if (this.cc == null) {
      super.paint(g);
    } else {
      long len = this.cc.getContentLength();
      long progress = this.cc.getContentProgress();
      if (len < 1L)
        return; 
      if (progress > len)
        len = progress; 
      setDisplayPercent((int)(100L * progress / len));
      super.paint(g);
    } 
  }
}
