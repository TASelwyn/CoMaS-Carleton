/*    */ package com.sun.media.ui;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Graphics;
/*    */ import javax.media.CachingControl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProgressBar
/*    */   extends Slider
/*    */ {
/* 14 */   private CachingControl cc = null;
/*    */   private Color cb;
/*    */   private Color cd;
/*    */   
/*    */   public ProgressBar(CachingControl cc) {
/* 19 */     this.cc = cc;
/* 20 */     setGrabberVisible(false);
/* 21 */     setBackground(DefaultControlPanel.colorBackground);
/*    */     
/* 23 */     this.threadUpdate = new ProgressBarThread(this, cc);
/* 24 */     this.threadUpdate.start();
/*    */   }
/*    */   private Color cm; private ProgressBarThread threadUpdate;
/*    */   public void update(Graphics g) {
/* 28 */     paint(g);
/*    */   }
/*    */   
/*    */   public void paint(Graphics g) {
/* 32 */     if (this.cc == null) {
/* 33 */       super.paint(g);
/*    */     } else {
/* 35 */       long len = this.cc.getContentLength();
/* 36 */       long progress = this.cc.getContentProgress();
/*    */       
/* 38 */       if (len < 1L) {
/*    */         return;
/*    */       }
/*    */       
/* 42 */       if (progress > len) {
/* 43 */         len = progress;
/*    */       }
/* 45 */       setDisplayPercent((int)(100L * progress / len));
/* 46 */       super.paint(g);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\ProgressBar.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */