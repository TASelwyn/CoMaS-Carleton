/*     */ package com.sun.media.ui;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.Panel;
/*     */ import java.awt.Rectangle;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.util.Enumeration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BufferedPanel
/*     */   extends Panel
/*     */ {
/*     */   protected boolean buffered;
/*     */   protected boolean autoFlushing;
/*     */   protected Image background;
/*     */   protected boolean windowCreated;
/*     */   protected transient Image buffer;
/*     */   protected transient Graphics bufferGraphics;
/*     */   protected transient Region damage;
/*     */   protected Object lock;
/*     */   
/*     */   public BufferedPanel(LayoutManager layout) {
/* 236 */     this.lock = new Object(); setLayout(layout); this.buffered = true; this.autoFlushing = true;
/*     */     this.background = null;
/*     */     this.windowCreated = false;
/*     */     this.buffer = null;
/*     */     this.bufferGraphics = null;
/* 241 */     this.damage = new Region(); } private void readObject(ObjectInputStream is) throws IOException, ClassNotFoundException { is.defaultReadObject();
/* 242 */     this.damage = new Region(); }
/*     */ 
/*     */   
/*     */   public BufferedPanel() {
/*     */     this(null);
/*     */   }
/*     */   
/*     */   public boolean isBuffered() {
/*     */     return this.buffered;
/*     */   }
/*     */   
/*     */   public void setBuffered(boolean buffered) {
/*     */     if (buffered != this.buffered) {
/*     */       this.buffered = buffered;
/*     */       if (buffered)
/*     */         repaint(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isAutoFlushing() {
/*     */     return this.autoFlushing;
/*     */   }
/*     */   
/*     */   public void setAutoFlushing(boolean flushing) {
/*     */     if (flushing != this.autoFlushing)
/*     */       this.autoFlushing = flushing; 
/*     */   }
/*     */   
/*     */   public Image getBackgroundTile() {
/*     */     return this.background;
/*     */   }
/*     */   
/*     */   public void setBackgroundTile(Image background) {
/*     */     this.background = background;
/*     */     repaint();
/*     */   }
/*     */   
/*     */   public void addNotify() {
/*     */     super.addNotify();
/*     */     this.windowCreated = true;
/*     */     if (this.buffered) {
/*     */       createBufferImage();
/*     */       repaint();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void reshape(int x, int y, int width, int height) {
/*     */     Rectangle old = getBounds();
/*     */     super.reshape(x, y, width, height);
/*     */     if (this.windowCreated && (width != old.width || height != old.height))
/*     */       if (this.buffered) {
/*     */         createBufferImage();
/*     */         repaint();
/*     */       }  
/*     */   }
/*     */   
/*     */   public void flushBuffer() {
/*     */     Dimension size = getSize();
/*     */     super.repaint(0L, 0, 0, size.width, size.height);
/*     */   }
/*     */   
/*     */   void createBufferImage() {
/*     */     Dimension size = getSize();
/*     */     if (size.width > 0 && size.height > 0) {
/*     */       this.buffer = createImage(size.width, size.height);
/*     */       if (this.buffer != null)
/*     */         this.bufferGraphics = this.buffer.getGraphics(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void renderBuffer() {
/*     */     Region rects;
/*     */     if (this.damage.isEmpty())
/*     */       return; 
/*     */     if (this.buffer == null)
/*     */       return; 
/*     */     synchronized (this.damage) {
/*     */       rects = this.damage;
/*     */       this.damage = new Region();
/*     */     } 
/*     */     for (Enumeration e = rects.rectangles(); e.hasMoreElements(); ) {
/*     */       Rectangle rect = e.nextElement();
/*     */       render(rect);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void render(Rectangle rect) {
/*     */     Component[] children = getComponents();
/*     */     synchronized (this.buffer) {
/*     */       this.bufferGraphics.setClip(rect);
/*     */       paintBackground(this.bufferGraphics);
/*     */       this.bufferGraphics.setColor(getForeground());
/*     */       for (int c = children.length - 1; c >= 0; c--) {
/*     */         Component child = children[c];
/*     */         if (isLightweight(child) && child.isVisible()) {
/*     */           Rectangle clip = child.getBounds();
/*     */           if (clip.intersects(rect)) {
/*     */             Graphics g = this.bufferGraphics.create(clip.x, clip.y, clip.width, clip.height);
/*     */             child.paint(g);
/*     */             g.dispose();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       this.bufferGraphics.setClip(0, 0, (getSize()).width, (getSize()).height);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void paintBackground(Graphics g) {
/*     */     Dimension size = getSize();
/*     */     if (this.background == null) {
/*     */       g.setColor(getBackground());
/*     */       g.fillRect(0, 0, size.width, size.height);
/*     */     } else {
/*     */       Rectangle tile = new Rectangle(0, 0, this.background.getWidth(this), this.background.getHeight(this));
/*     */       Rectangle clip = g.getClipBounds();
/*     */       while (tile.y < size.height) {
/*     */         while (tile.x < size.width) {
/*     */           if (clip == null || clip.intersects(tile))
/*     */             g.drawImage(this.background, tile.x, tile.y, this); 
/*     */           tile.x += tile.width;
/*     */         } 
/*     */         tile.x = 0;
/*     */         tile.y += tile.height;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean isLightweight(Component comp) {
/*     */     return comp.getPeer() instanceof java.awt.peer.LightweightPeer;
/*     */   }
/*     */   
/*     */   public void repaint(long time, int x, int y, int width, int height) {
/*     */     if (this.buffered) {
/*     */       synchronized (this.damage) {
/*     */         this.damage.addRectangle(new Rectangle(x, y, width, height));
/*     */       } 
/*     */       if (this.autoFlushing)
/*     */         flushBuffer(); 
/*     */     } else {
/*     */       super.repaint(time, x, y, width, height);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void update(Graphics g) {
/*     */     if (this.buffered) {
/*     */       paint(g);
/*     */     } else {
/*     */       super.update(g);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paint(Graphics g) {
/*     */     if (this.buffered && this.buffer != null) {
/*     */       renderBuffer();
/*     */       g.drawImage(this.buffer, 0, 0, this);
/*     */     } else {
/*     */       super.paint(g);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\BufferedPanel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */