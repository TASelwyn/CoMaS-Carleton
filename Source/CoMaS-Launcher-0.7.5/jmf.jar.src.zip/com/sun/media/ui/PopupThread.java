package com.sun.media.ui;

import java.awt.Window;

class PopupThread extends Thread {
  private Window window;
  
  private int nTimeCounter = 3;
  
  private boolean boolRun = true;
  
  public PopupThread(Window window) {
    this.window = window;
  }
  
  public void resetCounter(int nTimeCounter) {
    this.nTimeCounter = nTimeCounter;
  }
  
  public void stopNormaly() {
    this.boolRun = false;
  }
  
  public void run() {
    while (this.boolRun) {
      if (this.nTimeCounter < 1)
        this.window.setVisible(false); 
      try {
        Thread.sleep(1000L);
      } catch (Exception exception) {}
      this.nTimeCounter--;
    } 
  }
}
