/*     */ package com.sun.media.ui;
/*     */ 
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import java.awt.Container;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.media.GainChangeEvent;
/*     */ import javax.media.GainChangeListener;
/*     */ import javax.media.GainControl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GainControlComponent
/*     */   extends Container
/*     */   implements GainChangeListener
/*     */ {
/*  24 */   private static JMFSecurity jmfSecurity = null;
/*     */   private static boolean securityPrivelege = false;
/*  26 */   private Method[] m = new Method[1];
/*  27 */   private Class[] cl = new Class[1];
/*  28 */   private Object[][] args = new Object[1][0]; protected GainControl gain; protected MuteButton muteButton; protected VolumeButton upButton; protected VolumeButton downButton; protected boolean fUseVolumeControl; protected static final float VolumeIncrement = 0.05F; protected static final int RepeatDelay = 100;
/*     */   
/*     */   static {
/*     */     try {
/*  32 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  33 */       securityPrivelege = true;
/*  34 */     } catch (SecurityException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gainChange(GainChangeEvent e) {
/*  87 */     if (this.fUseVolumeControl == true) {
/*  88 */       float level = e.getLevel();
/*  89 */       this.upButton.setEnabled((level < 1.0F));
/*  90 */       this.downButton.setEnabled((level > 0.0F));
/*     */     } 
/*  92 */     this.muteButton.setValue(e.getMute());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean canChangeVolume() {
/*  97 */     if (this.gain == null || this.gain.getLevel() < 0.0F) {
/*  98 */       return false;
/*     */     }
/*     */     
/* 101 */     return true;
/*     */   }
/*     */   
/* 104 */   public GainControlComponent(GainControl gain) { this.gain = null;
/* 105 */     this.muteButton = null;
/* 106 */     this.upButton = null;
/* 107 */     this.downButton = null;
/* 108 */     this.fUseVolumeControl = true; GridBagConstraints gbc = new GridBagConstraints(); this.gain = gain; gain.addGainChangeListener(this); GridBagLayout gbl; setLayout(gbl = new GridBagLayout()); if (canChangeVolume()) { gbc.insets = new Insets(0, 0, 0, 0); gbc.gridheight = 2; this.muteButton = new MuteButton(this); add(this.muteButton); gbl.setConstraints(this.muteButton, gbc); gbc.gridx = 1; gbc.gridheight = 1; this.upButton = new VolumeButton(this, "volumeUp.gif", "volumeUp-active.gif", "volumeUp-pressed.gif", "volumeUp-disabled.gif", "Increase volume", 0.05F); add(this.upButton); gbl.setConstraints(this.upButton, gbc); gbc.gridy = 1; this.downButton = new VolumeButton(this, "volumeDown.gif", "volumeDown-active.gif", "volumeDown-pressed.gif", "volumeDown-disabled.gif", "Decrease volume", -0.05F); add(this.downButton); gbl.setConstraints(this.downButton, gbc); }
/*     */     else
/*     */     { this.fUseVolumeControl = false; this.muteButton = new MuteButton(this); add(this.muteButton); }
/*     */      } class VolumeButton extends ButtonComp
/*     */   {
/*     */     protected float increment; Thread repeater; private final GainControlComponent this$0; public void action() { if (this.this$0.gain != null) {
/*     */         float level = this.this$0.gain.getLevel() + this.increment; if (level < 0.0F) {
/*     */           level = 0.0F;
/*     */         } else if (level > 1.0F) {
/*     */           level = 1.0F;
/*     */         }  this.this$0.gain.setLevel(level); this.this$0.gain.setMute(false);
/*     */       }  } public void mousePressed(MouseEvent e) { super.mousePressed(e); if (this.repeater == null) {
/*     */         this.repeater = (Thread)new Object(this); this.repeater.start();
/* 121 */       }  } public VolumeButton(GainControlComponent this$0, String imgNormal, String imgActive, String imgDown, String imgDisabled, String tip, float increment) { super(tip, imgNormal, imgActive, imgDown, imgDisabled, imgNormal, imgActive, imgDown, imgDisabled);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       this.this$0 = this$0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 224 */       this.repeater = null; this.increment = increment; } public void mouseReleased(MouseEvent e) { super.mouseReleased(e); if (this.repeater != null) { Thread killIt = this.repeater; this.repeater = null; boolean permission = true; if (GainControlComponent.securityPrivelege) { if (GainControlComponent.jmfSecurity != null)
/*     */             try { GainControlComponent.jmfSecurity.requestPermission(this.this$0.m, this.this$0.cl, this.this$0.args, 16); this.this$0.m[0].invoke(this.this$0.cl[0], this.this$0.args[0]); } catch (Exception ex) { permission = false; }   } else { permission = false; }  if (permission)
/*     */           killIt.interrupt();  }
/*     */        } public void setEnabled(boolean enabled) { if (enabled != isEnabled()) { super.setEnabled(enabled); mouseActivity(); }
/*     */        }
/*     */   } class MuteButton extends ButtonComp {
/* 230 */     public MuteButton(GainControlComponent this$0) { super("Mute audio", "audio.gif", "audio-active.gif", "audio-pressed.gif", "audio-disabled.gif", "mute.gif", "mute-active.gif", "mute-pressed.gif", "audio-disabled.gif");
/*     */       this.this$0 = this$0; }
/*     */ 
/*     */ 
/*     */     
/*     */     private final GainControlComponent this$0;
/*     */     
/*     */     public void action() {
/* 238 */       if (this.this$0.gain != null)
/* 239 */         this.this$0.gain.setMute(!this.this$0.gain.getMute()); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\GainControlComponent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */