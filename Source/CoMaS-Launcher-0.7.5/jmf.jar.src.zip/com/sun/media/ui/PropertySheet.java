/*     */ package com.sun.media.ui;
/*     */ import com.sun.media.BasicPlayer;
/*     */ import com.sun.media.util.JMFI18N;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Canvas;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.Label;
/*     */ import java.awt.Panel;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.util.Vector;
/*     */ import javax.media.Control;
/*     */ import javax.media.Format;
/*     */ import javax.media.MediaLocator;
/*     */ import javax.media.Owned;
/*     */ import javax.media.Time;
/*     */ import javax.media.control.BitRateControl;
/*     */ import javax.media.control.FrameRateControl;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ public class PropertySheet extends Dialog implements WindowListener, ActionListener {
/*  24 */   private Vector vectorControlBitRate = new Vector(1); private Player player;
/*  25 */   private Vector vectorLabelBitRate = new Vector(1);
/*  26 */   private FrameRateControl controlFrameRate = null;
/*     */   
/*  28 */   private Vector vectorTrackFormats = new Vector();
/*  29 */   private int nAudioTrackCount = 0;
/*  30 */   private int nVideoTrackCount = 0;
/*  31 */   private Vector vectorMiscControls = new Vector();
/*     */   
/*     */   private Button buttonClose;
/*  34 */   private Label labelDuration = null;
/*  35 */   private Label labelPosition = null;
/*  36 */   private Label labelBitRate = null;
/*  37 */   private Label labelFrameRate = null;
/*     */   
/*     */   private ColumnList columnListAudio;
/*     */   
/*     */   private ColumnList columnListVideo;
/*     */   
/*  43 */   private static final String STR_UNKNOWN = JMFI18N.getResource("propertysheet.unknown");
/*  44 */   private static final String STR_UNBOUNDED = JMFI18N.getResource("propertysheet.unbounded");
/*     */ 
/*     */   
/*     */   public PropertySheet(Frame parent, Player player) {
/*  48 */     super(parent, JMFI18N.getResource("propertysheet.title"), false);
/*     */     
/*  50 */     this.player = player;
/*     */     try {
/*  52 */       init();
/*     */     } catch (Exception e) {
/*     */       
/*  55 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() throws Exception {
/*  65 */     setLayout(new BorderLayout(5, 5));
/*  66 */     setBackground(Color.lightGray);
/*     */     
/*  68 */     Panel panel = createPanelButtons();
/*  69 */     add(panel, "South");
/*     */     
/*  71 */     panel = createPanelProperties();
/*  72 */     add(panel, "Center");
/*     */ 
/*     */ 
/*     */     
/*  76 */     Canvas canvas = new Canvas();
/*  77 */     add(canvas, "North");
/*  78 */     canvas = new Canvas();
/*  79 */     add(canvas, "East");
/*  80 */     canvas = new Canvas();
/*  81 */     add(canvas, "West");
/*     */     
/*  83 */     pack();
/*  84 */     addWindowListener(this);
/*  85 */     setResizable(false);
/*  86 */     Dimension dim = getPreferredSize();
/*  87 */     if (dim.width > 480)
/*  88 */       dim.width = 480; 
/*  89 */     setBounds(100, 100, dim.width, dim.height);
/*  90 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Panel createPanelProperties() throws Exception {
/* 103 */     TabControl tabControl = new TabControl(0);
/*     */     
/* 105 */     Panel panel = createPanelGeneral();
/* 106 */     tabControl.addPage(panel, JMFI18N.getResource("propertysheet.tab.general"));
/*     */     
/* 108 */     if (this.nVideoTrackCount > 0) {
/* 109 */       panel = createPanelVideo(this.vectorTrackFormats);
/* 110 */       tabControl.addPage(panel, JMFI18N.getResource("propertysheet.tab.video"));
/*     */     } 
/*     */     
/* 113 */     if (this.nAudioTrackCount > 0) {
/* 114 */       panel = createPanelAudio(this.vectorTrackFormats);
/* 115 */       tabControl.addPage(panel, JMFI18N.getResource("propertysheet.tab.audio"));
/*     */     } 
/*     */     
/* 118 */     if (!this.vectorMiscControls.isEmpty()) {
/* 119 */       panel = createPanelMisc();
/* 120 */       tabControl.addPage(panel, JMFI18N.getResource("propertysheet.tab.misc"));
/*     */     } 
/*     */     
/* 123 */     update();
/* 124 */     return tabControl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Panel createPanelGeneral() throws Exception {
/* 139 */     String strValue = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     Panel panelGeneral = new Panel(new BorderLayout());
/*     */     
/* 146 */     Panel panel = new Panel(new BorderLayout(8, 4));
/* 147 */     panelGeneral.add(panel, "North");
/*     */     
/* 149 */     Panel panelLabels = new Panel(new GridLayout(0, 1, 4, 4));
/* 150 */     panel.add(panelLabels, "West");
/* 151 */     Panel panelData = new Panel(new GridLayout(0, 1, 4, 4));
/* 152 */     panel.add(panelData, "Center");
/*     */     
/* 154 */     if (this.player instanceof BasicPlayer) {
/* 155 */       BasicPlayer playerBasic = (BasicPlayer)this.player;
/*     */       
/* 157 */       MediaLocator mediaLocator = playerBasic.getMediaLocator();
/* 158 */       if (mediaLocator != null)
/* 159 */         strValue = mediaLocator.toString(); 
/* 160 */       if (strValue != null) {
/* 161 */         Label label1 = new Label(JMFI18N.getResource("propertysheet.general.medialocation"), 2);
/* 162 */         panelLabels.add(label1);
/* 163 */         UrlLabel labelUrl = new UrlLabel(strValue);
/* 164 */         panelData.add(labelUrl);
/*     */       } 
/*     */       
/* 167 */       strValue = playerBasic.getContentType();
/* 168 */       if (strValue != null) {
/* 169 */         strValue = (new ContentDescriptor(strValue)).toString();
/* 170 */         Label label1 = new Label(JMFI18N.getResource("propertysheet.general.contenttype"), 2);
/* 171 */         panelLabels.add(label1);
/* 172 */         label1 = new Label(strValue);
/* 173 */         panelData.add(label1);
/*     */       } 
/*     */     } 
/*     */     
/* 177 */     Label label = new Label(JMFI18N.getResource("propertysheet.general.duration"), 2);
/* 178 */     panelLabels.add(label);
/* 179 */     this.labelDuration = new Label();
/* 180 */     panelData.add(this.labelDuration);
/*     */     
/* 182 */     label = new Label(JMFI18N.getResource("propertysheet.general.position"), 2);
/* 183 */     panelLabels.add(label);
/* 184 */     this.labelPosition = new Label();
/* 185 */     panelData.add(this.labelPosition);
/*     */     
/* 187 */     this.nAudioTrackCount = 0;
/* 188 */     this.nVideoTrackCount = 0;
/* 189 */     Control[] arrControls = this.player.getControls();
/* 190 */     for (int i = 0; i < arrControls.length; i++) {
/* 191 */       if (arrControls[i] != null) {
/*     */ 
/*     */         
/* 194 */         if (arrControls[i] instanceof FormatControl && (
/* 195 */           !(arrControls[i] instanceof Owned) || (!(((Owned)arrControls[i]).getOwner() instanceof javax.media.protocol.SourceStream) && !(((Owned)arrControls[i]).getOwner() instanceof javax.media.protocol.DataSource)))) {
/*     */ 
/*     */           
/* 198 */           Format format = ((FormatControl)arrControls[i]).getFormat();
/* 199 */           this.vectorTrackFormats.addElement(format);
/* 200 */           if (format instanceof AudioFormat) {
/* 201 */             this.nAudioTrackCount++;
/* 202 */           } else if (format instanceof VideoFormat) {
/* 203 */             this.nVideoTrackCount++;
/*     */           } 
/*     */         } 
/*     */         
/* 207 */         if (!(arrControls[i] instanceof javax.media.control.TrackControl))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 213 */           if (arrControls[i] instanceof BitRateControl) {
/* 214 */             BitRateControl controlBitRateTemp = (BitRateControl)arrControls[i];
/* 215 */             if (controlBitRateTemp instanceof Owned && ((Owned)controlBitRateTemp).getOwner() instanceof javax.media.Controller) {
/*     */               
/* 217 */               this.vectorControlBitRate.addElement(controlBitRateTemp);
/* 218 */               label = new Label(JMFI18N.getResource("propertysheet.general.bitrate"), 2);
/* 219 */               panelLabels.add(label);
/* 220 */               this.labelBitRate = new Label();
/* 221 */               this.vectorLabelBitRate.addElement(this.labelBitRate);
/* 222 */               panelData.add(this.labelBitRate);
/*     */             } else {
/*     */               
/* 225 */               this.vectorMiscControls.addElement(arrControls[i]);
/*     */             }
/*     */           
/* 228 */           } else if (arrControls[i] instanceof FrameRateControl) {
/* 229 */             FrameRateControl controlFrameRateTemp = (FrameRateControl)arrControls[i];
/* 230 */             if (controlFrameRateTemp instanceof Owned && ((Owned)controlFrameRateTemp).getOwner() instanceof javax.media.Controller) {
/*     */               
/* 232 */               this.controlFrameRate = controlFrameRateTemp;
/* 233 */               label = new Label(JMFI18N.getResource("propertysheet.general.framerate"), 2);
/* 234 */               panelLabels.add(label);
/* 235 */               this.labelFrameRate = new Label();
/* 236 */               panelData.add(this.labelFrameRate);
/*     */             } else {
/*     */               
/* 239 */               this.vectorMiscControls.addElement(arrControls[i]);
/*     */             }
/*     */           
/* 242 */           } else if (!(arrControls[i] instanceof javax.media.GainControl)) {
/*     */ 
/*     */             
/* 245 */             if (!(arrControls[i] instanceof javax.media.control.MonitorControl))
/*     */             {
/*     */               
/* 248 */               if (!(arrControls[i] instanceof Owned) || (!(((Owned)arrControls[i]).getOwner() instanceof javax.media.protocol.CaptureDevice) && !(((Owned)arrControls[i]).getOwner() instanceof javax.media.protocol.SourceStream) && !(((Owned)arrControls[i]).getOwner() instanceof javax.media.protocol.DataSource)))
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 254 */                 if (!(arrControls[i] instanceof javax.media.CachingControl))
/*     */                 {
/*     */ 
/*     */                   
/* 258 */                   this.vectorMiscControls.addElement(arrControls[i]); }  }  } 
/*     */           }  } 
/*     */       } 
/*     */     } 
/* 262 */     return panelGeneral;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Panel createPanelVideo(Vector vectorFormats) throws Exception {
/* 275 */     String[] arrColumnNames = { JMFI18N.getResource("propertysheet.video.track"), JMFI18N.getResource("propertysheet.video.encoding"), JMFI18N.getResource("propertysheet.video.size"), JMFI18N.getResource("propertysheet.video.framerate") };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 282 */     Panel panelVideo = new Panel(new BorderLayout());
/*     */     
/* 284 */     this.columnListVideo = new ColumnList(arrColumnNames);
/* 285 */     String[] arrValues = new String[arrColumnNames.length];
/* 286 */     int nCount = vectorFormats.size();
/* 287 */     int nTrackIndex = 0;
/* 288 */     for (int i = 0; i < nCount; i++) {
/* 289 */       Object objectFormat = vectorFormats.elementAt(i);
/* 290 */       if (objectFormat instanceof VideoFormat) {
/*     */         
/* 292 */         VideoFormat formatVideo = (VideoFormat)objectFormat;
/* 293 */         nTrackIndex++;
/*     */         
/* 295 */         arrValues[0] = new String("" + nTrackIndex);
/* 296 */         arrValues[1] = formatVideo.getEncoding();
/*     */         
/* 298 */         Dimension dimSize = formatVideo.getSize();
/* 299 */         if (dimSize == null) {
/* 300 */           arrValues[2] = new String(STR_UNKNOWN);
/*     */         } else {
/* 302 */           arrValues[2] = new String("" + dimSize.width + " x " + dimSize.height);
/*     */         } 
/* 304 */         float fValue = formatVideo.getFrameRate();
/* 305 */         if (fValue == -1.0F) {
/* 306 */           arrValues[3] = STR_UNKNOWN;
/*     */         } else {
/* 308 */           arrValues[3] = "" + fValue;
/*     */         } 
/* 310 */         this.columnListVideo.addRow((Object[])arrValues);
/*     */       } 
/* 312 */     }  this.columnListVideo.setColumnWidthAsPreferred();
/* 313 */     panelVideo.add(this.columnListVideo, "Center");
/* 314 */     return panelVideo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Panel createPanelAudio(Vector vectorFormats) throws Exception {
/* 327 */     String[] arrColumnNames = { JMFI18N.getResource("propertysheet.audio.track"), JMFI18N.getResource("propertysheet.audio.encoding"), JMFI18N.getResource("propertysheet.audio.samplerate"), JMFI18N.getResource("propertysheet.audio.bitspersample"), JMFI18N.getResource("propertysheet.audio.channels") };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 335 */     Panel panelAudio = new Panel(new BorderLayout());
/*     */     
/* 337 */     this.columnListAudio = new ColumnList(arrColumnNames);
/* 338 */     String[] arrValues = new String[arrColumnNames.length];
/* 339 */     int nCount = vectorFormats.size();
/* 340 */     int nTrackIndex = 0;
/* 341 */     for (int i = 0; i < nCount; i++) {
/* 342 */       Object objectFormat = vectorFormats.elementAt(i);
/* 343 */       if (objectFormat instanceof AudioFormat) {
/*     */         
/* 345 */         AudioFormat formatAudio = (AudioFormat)objectFormat;
/* 346 */         nTrackIndex++;
/*     */         
/* 348 */         arrValues[0] = new String("" + nTrackIndex);
/* 349 */         arrValues[1] = formatAudio.getEncoding();
/*     */         
/* 351 */         double dValue = formatAudio.getSampleRate();
/* 352 */         if (dValue == -1.0D) {
/* 353 */           arrValues[2] = STR_UNKNOWN;
/*     */         } else {
/* 355 */           arrValues[2] = "" + dValue;
/*     */         } 
/* 357 */         int nValue = formatAudio.getSampleSizeInBits();
/* 358 */         if (nValue == -1) {
/* 359 */           arrValues[3] = STR_UNKNOWN;
/*     */         } else {
/* 361 */           arrValues[3] = "" + nValue;
/*     */         } 
/* 363 */         nValue = formatAudio.getChannels();
/* 364 */         if (nValue == -1) {
/* 365 */           arrValues[4] = STR_UNKNOWN;
/* 366 */         } else if (nValue == 1) {
/* 367 */           arrValues[4] = "" + nValue + " (" + JMFI18N.getResource("propertysheet.audio.channels.mono") + ")";
/* 368 */         } else if (nValue == 2) {
/* 369 */           arrValues[4] = "" + nValue + " (" + JMFI18N.getResource("propertysheet.audio.channels.stereo") + ")";
/*     */         } else {
/* 371 */           arrValues[4] = "" + nValue;
/*     */         } 
/* 373 */         this.columnListAudio.addRow((Object[])arrValues);
/*     */       } 
/* 375 */     }  this.columnListAudio.setColumnWidthAsPreferred();
/* 376 */     panelAudio.add(this.columnListAudio, "Center");
/* 377 */     return panelAudio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Panel createPanelMisc() throws Exception {
/* 390 */     Panel panelMisc = new Panel(new BorderLayout(6, 6));
/* 391 */     Panel panel = panelMisc;
/* 392 */     int nSize = this.vectorMiscControls.size();
/* 393 */     for (int i = 0; i < nSize; i++) {
/* 394 */       Control control = this.vectorMiscControls.elementAt(i);
/* 395 */       Component comp = control.getControlComponent();
/* 396 */       if (comp != null && comp.getParent() == null) {
/* 397 */         Panel panelControl = new Panel(new BorderLayout(6, 6));
/* 398 */         panelControl.add(comp, "West");
/* 399 */         Panel panelNext = new Panel(new BorderLayout(6, 6));
/* 400 */         panelNext.add(panelControl, "North");
/* 401 */         panel.add(panelNext, "Center");
/* 402 */         panel = panelNext;
/*     */       } 
/*     */     } 
/* 405 */     return panelMisc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Panel createPanelButtons() throws Exception {
/* 412 */     Panel panelButtons = new Panel(new FlowLayout(2));
/*     */     
/* 414 */     Panel panel = new Panel(new GridLayout(1, 0, 6, 6));
/* 415 */     panelButtons.add(panel);
/*     */     
/* 417 */     this.buttonClose = new Button(JMFI18N.getResource("propertysheet.close"));
/* 418 */     this.buttonClose.addActionListener(this);
/* 419 */     panel.add(this.buttonClose);
/*     */     
/* 421 */     return panelButtons;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void actionPerformed(ActionEvent e) {
/* 427 */     String strCmd = e.getActionCommand();
/* 428 */     if (strCmd.equals(this.buttonClose.getLabel())) {
/* 429 */       setVisible(false);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void windowOpened(WindowEvent e) {}
/*     */   
/*     */   public void windowClosing(WindowEvent e) {
/* 437 */     setVisible(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void windowClosed(WindowEvent e) {}
/*     */ 
/*     */   
/*     */   public void windowIconified(WindowEvent e) {}
/*     */ 
/*     */   
/*     */   public void windowDeiconified(WindowEvent e) {}
/*     */ 
/*     */   
/*     */   public void windowActivated(WindowEvent e) {}
/*     */ 
/*     */   
/*     */   public void windowDeactivated(WindowEvent e) {}
/*     */   
/*     */   void update() {
/* 456 */     updateBitRate();
/* 457 */     updateFrameRate();
/* 458 */     updateMediaTime();
/* 459 */     updateDuration();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void updateDuration() {
/* 465 */     if (this.labelDuration != null) {
/* 466 */       Time timeDuration = this.player.getDuration();
/* 467 */       this.labelDuration.setText(formatTime(timeDuration));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void updateBitRate() {
/* 474 */     if (this.vectorLabelBitRate.size() > 0) {
/* 475 */       for (int i = 0; i < this.vectorLabelBitRate.size(); i++) {
/* 476 */         Label labelBitRate = this.vectorLabelBitRate.elementAt(i);
/*     */         
/* 478 */         BitRateControl controlBitRate = this.vectorControlBitRate.elementAt(i);
/*     */         
/* 480 */         int bitRate = controlBitRate.getBitRate();
/* 481 */         labelBitRate.setText(Float.toString(bitRate / 1000.0F) + " " + JMFI18N.getResource("propertysheet.kbps"));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void updateFrameRate() {
/* 490 */     if (this.labelFrameRate != null && this.controlFrameRate != null) {
/* 491 */       float frameRate = this.controlFrameRate.getFrameRate();
/* 492 */       this.labelFrameRate.setText(Float.toString(frameRate) + " " + JMFI18N.getResource("propertysheet.fps"));
/*     */     } 
/*     */   }
/*     */   
/*     */   void clearBRFR() {
/* 497 */     if (this.labelFrameRate != null) {
/* 498 */       this.labelFrameRate.setText("0.0 " + JMFI18N.getResource("propertysheet.fps"));
/*     */     }
/* 500 */     if (this.labelBitRate != null) {
/* 501 */       this.labelBitRate.setText("0.0 " + JMFI18N.getResource("propertysheet.kbps"));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void updateMediaTime() {
/* 507 */     if (this.labelPosition != null) {
/* 508 */       Time timeMedia = this.player.getMediaTime();
/* 509 */       this.labelPosition.setText(formatTime(timeMedia));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String formatTime(Time time) {
/* 522 */     String strTime = new String(STR_UNKNOWN);
/*     */     
/* 524 */     if (time == null || time == Time.TIME_UNKNOWN || time == Duration.DURATION_UNKNOWN) {
/* 525 */       return strTime;
/*     */     }
/* 527 */     if (time == Duration.DURATION_UNBOUNDED) {
/* 528 */       return STR_UNBOUNDED;
/*     */     }
/* 530 */     long nano = time.getNanoseconds();
/* 531 */     int seconds = (int)(nano / 1000000000L);
/* 532 */     int hours = seconds / 3600;
/* 533 */     int minutes = (seconds - hours * 3600) / 60;
/* 534 */     seconds = seconds - hours * 3600 - minutes * 60;
/* 535 */     nano = nano % 1000000000L / 10000000L;
/*     */     
/* 537 */     int hours10 = hours / 10;
/* 538 */     hours %= 10;
/* 539 */     int minutes10 = minutes / 10;
/* 540 */     minutes %= 10;
/* 541 */     int seconds10 = seconds / 10;
/* 542 */     seconds %= 10;
/* 543 */     long nano10 = nano / 10L;
/* 544 */     nano %= 10L;
/*     */     
/* 546 */     strTime = new String("" + hours10 + hours + ":" + minutes10 + minutes + ":" + seconds10 + seconds + "." + nano10 + nano);
/* 547 */     return strTime;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\PropertySheet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */