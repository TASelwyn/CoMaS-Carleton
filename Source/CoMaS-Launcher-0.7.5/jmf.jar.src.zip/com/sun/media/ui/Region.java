/*     */ package com.sun.media.ui;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.io.Serializable;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Region
/*     */   implements Cloneable, Serializable
/*     */ {
/*     */   protected Vector rects;
/*     */   
/*     */   public Region() {
/*  26 */     this.rects = new Vector();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Region(Rectangle r) {
/*  33 */     this.rects = new Vector();
/*  34 */     addRectangle(r);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Region(Rectangle r1, Rectangle r2) {
/*  42 */     this.rects = new Vector();
/*  43 */     addRectangle(r1);
/*  44 */     addRectangle(r2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  51 */     return this.rects.isEmpty();
/*     */   }
/*     */   
/*     */   public int getNumRectangles() {
/*  55 */     return this.rects.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration rectangles() {
/*  62 */     return this.rects.elements();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/*  69 */     Region r = new Region();
/*     */     
/*  71 */     r.rects = (Vector)this.rects.clone();
/*     */     
/*  73 */     return r;
/*     */   }
/*     */   
/*     */   public Rectangle getBounds() {
/*  77 */     Rectangle r = new Rectangle();
/*     */     
/*  79 */     for (int i = 0; i < this.rects.size(); i++) {
/*  80 */       r = r.union(this.rects.elementAt(i));
/*     */     }
/*  82 */     return r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addRectangle(Rectangle r) {
/*  93 */     int position = 0;
/*     */     
/*  95 */     while (position < this.rects.size()) {
/*     */       
/*  97 */       Rectangle current = this.rects.elementAt(position);
/*     */ 
/*     */ 
/*     */       
/* 101 */       if (r.x > current.x && r.y > current.y && right(r) <= right(current) && bottom(r) <= bottom(current)) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 106 */       if (r.intersects(current)) {
/*     */         
/* 108 */         r = r.union(current);
/* 109 */         this.rects.removeElementAt(position); continue;
/*     */       } 
/* 111 */       position++;
/*     */     } 
/*     */ 
/*     */     
/* 115 */     this.rects.addElement(r);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean intersects(Rectangle r) {
/* 125 */     int position = 0;
/*     */     
/* 127 */     while (position < this.rects.size()) {
/* 128 */       Rectangle rect = this.rects.elementAt(position);
/* 129 */       if (rect.intersects(r)) {
/* 130 */         return true;
/*     */       }
/* 132 */       position++;
/*     */     } 
/* 134 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void intersect(Rectangle r) {
/* 144 */     int position = 0;
/*     */     
/* 146 */     while (position < this.rects.size()) {
/* 147 */       Rectangle rect = this.rects.elementAt(position);
/* 148 */       rect = rect.intersection(r);
/* 149 */       if (rect.isEmpty()) {
/* 150 */         this.rects.removeElementAt(position); continue;
/*     */       } 
/* 152 */       this.rects.setElementAt(rect, position);
/* 153 */       position++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addRegion(Region r) {
/* 163 */     for (Enumeration e = r.rectangles(); e.hasMoreElements();)
/*     */     {
/* 165 */       addRectangle(e.nextElement());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void translate(int dx, int dy) {
/* 176 */     for (int p = 0; p < this.rects.size(); p++) {
/* 177 */       Rectangle r = this.rects.elementAt(p);
/* 178 */       r.translate(dx, dy);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 186 */     String s = getClass().getName() + " = [\n";
/*     */     
/* 188 */     for (Enumeration e = rectangles(); e.hasMoreElements();)
/*     */     {
/* 190 */       s = s + "(" + (Rectangle)e.nextElement() + ")\n";
/*     */     }
/* 192 */     return s + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int right(Rectangle r) {
/* 199 */     return r.x + r.width - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int bottom(Rectangle r) {
/* 206 */     return r.y + r.height - 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\Region.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */