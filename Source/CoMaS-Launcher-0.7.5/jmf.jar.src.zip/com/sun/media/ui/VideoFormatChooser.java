/*     */ package com.sun.media.ui;
/*     */ 
/*     */ import com.sun.media.util.JMFI18N;
/*     */ import java.awt.Checkbox;
/*     */ import java.awt.Choice;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Label;
/*     */ import java.awt.Panel;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.util.Vector;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.RGBFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ import javax.media.format.YUVFormat;
/*     */ 
/*     */ 
/*     */ public class VideoFormatChooser
/*     */   extends Panel
/*     */   implements ItemListener, ActionListener
/*     */ {
/*     */   public static final String ACTION_TRACK_ENABLED = "ACTION_VIDEO_TRACK_ENABLED";
/*     */   public static final String ACTION_TRACK_DISABLED = "ACTION_VIDEO_TRACK_DISABLED";
/*     */   private VideoFormat formatOld;
/*  27 */   private Format[] arrSupportedFormats = null;
/*  28 */   private float[] customFrameRates = null;
/*  29 */   private Vector vectorContSuppFormats = new Vector();
/*     */   
/*     */   private boolean boolDisplayEnableTrack;
/*     */   
/*     */   private ActionListener listenerEnableTrack;
/*     */   private boolean boolEnableTrackSaved = true;
/*     */   private Checkbox checkEnableTrack;
/*     */   private Label labelEncoding;
/*     */   private Choice comboEncoding;
/*     */   private Label labelSize;
/*     */   private VideoSizeControl controlSize;
/*     */   private Label labelFrameRate;
/*     */   private Choice comboFrameRate;
/*     */   private Label labelExtra;
/*     */   private Choice comboExtra;
/*  44 */   private int nWidthLabel = 0;
/*  45 */   private int nWidthData = 0;
/*     */   
/*     */   private static final int MARGINH = 12;
/*     */   
/*     */   private static final int MARGINV = 6;
/*     */   
/*  51 */   private static final float[] standardCaptureRates = new float[] { 15.0F, 1.0F, 2.0F, 5.0F, 7.5F, 10.0F, 12.5F, 20.0F, 24.0F, 25.0F, 30.0F };
/*     */ 
/*     */ 
/*     */   
/*  55 */   private static final String DEFAULT_STRING = JMFI18N.getResource("formatchooser.default");
/*     */ 
/*     */ 
/*     */   
/*     */   public VideoFormatChooser(Format[] arrFormats, VideoFormat formatDefault, float[] frameRates) {
/*  60 */     this(arrFormats, formatDefault, false, (ActionListener)null, frameRates);
/*     */   }
/*     */   
/*     */   public VideoFormatChooser(Format[] arrFormats, VideoFormat formatDefault) {
/*  64 */     this(arrFormats, formatDefault, false, (ActionListener)null, (float[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public VideoFormatChooser(Format[] arrFormats, VideoFormat formatDefault, boolean boolDisplayEnableTrack, ActionListener listenerEnableTrack) {
/*  70 */     this(arrFormats, formatDefault, boolDisplayEnableTrack, listenerEnableTrack, (float[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VideoFormatChooser(Format[] arrFormats, VideoFormat formatDefault, boolean boolDisplayEnableTrack, ActionListener listenerEnableTrack, boolean capture) {
/*  77 */     this(arrFormats, formatDefault, boolDisplayEnableTrack, listenerEnableTrack, capture ? standardCaptureRates : null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VideoFormatChooser(Format[] arrFormats, VideoFormat formatDefault, boolean boolDisplayEnableTrack, ActionListener listenerEnableTrack, float[] frameRates) {
/*  88 */     this.arrSupportedFormats = arrFormats;
/*  89 */     this.boolDisplayEnableTrack = boolDisplayEnableTrack;
/*  90 */     this.listenerEnableTrack = listenerEnableTrack;
/*  91 */     this.customFrameRates = frameRates;
/*     */     
/*  93 */     int nCount = this.arrSupportedFormats.length;
/*  94 */     for (int i = 0; i < nCount; i++) {
/*  95 */       if (this.arrSupportedFormats[i] instanceof VideoFormat) {
/*  96 */         this.vectorContSuppFormats.addElement(this.arrSupportedFormats[i]);
/*     */       }
/*     */     } 
/*  99 */     if (isFormatSupported(formatDefault)) {
/* 100 */       this.formatOld = formatDefault;
/*     */     } else {
/* 102 */       this.formatOld = null;
/*     */     } 
/*     */     try {
/* 105 */       init();
/*     */     } catch (Exception e) {
/*     */       
/* 108 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean boolEnable) {
/* 113 */     super.setEnabled(boolEnable);
/*     */     
/* 115 */     if (this.checkEnableTrack != null)
/* 116 */       this.checkEnableTrack.setEnabled(boolEnable); 
/* 117 */     enableControls(boolEnable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format getFormat() {
/* 127 */     String strYuvType = null;
/*     */     
/* 129 */     VideoFormat formatVideo = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     String strEncoding = this.comboEncoding.getSelectedItem();
/*     */     
/* 137 */     int nSize = this.vectorContSuppFormats.size();
/* 138 */     for (int i = 0; i < nSize; i++) {
/* 139 */       Object objectFormat = this.vectorContSuppFormats.elementAt(i);
/* 140 */       if (!(objectFormat instanceof VideoFormat))
/*     */         continue; 
/* 142 */       formatVideo = (VideoFormat)objectFormat;
/*     */       
/* 144 */       if (!isFormatGoodForEncoding(formatVideo))
/*     */         continue; 
/* 146 */       if (!isFormatGoodForVideoSize(formatVideo))
/*     */         continue; 
/* 148 */       if (!isFormatGoodForFrameRate(formatVideo)) {
/*     */         continue;
/*     */       }
/* 151 */       if (strEncoding.equalsIgnoreCase("rgb") && formatVideo instanceof RGBFormat) {
/* 152 */         RGBFormat formatRGB = (RGBFormat)formatVideo;
/* 153 */         Integer integerBitsPerPixel = new Integer(formatRGB.getBitsPerPixel());
/* 154 */         String strBitsPerPixel = integerBitsPerPixel.toString();
/* 155 */         if (!this.comboExtra.getSelectedItem().equals(strBitsPerPixel))
/*     */           continue;  break;
/*     */       } 
/* 158 */       if (strEncoding.equalsIgnoreCase("yuv") && formatVideo instanceof YUVFormat) {
/* 159 */         YUVFormat formatYUV = (YUVFormat)formatVideo;
/* 160 */         int nYuvType = formatYUV.getYuvType();
/* 161 */         strYuvType = getYuvType(nYuvType);
/* 162 */         if (strYuvType == null || !this.comboExtra.getSelectedItem().equals(strYuvType)) {
/*     */           continue;
/*     */         }
/*     */       } 
/*     */       break;
/*     */     } 
/* 168 */     if (i >= nSize) {
/* 169 */       return null;
/*     */     }
/* 171 */     if (formatVideo.getSize() == null) {
/* 172 */       VideoFormat formatVideoNew = new VideoFormat(null, this.controlSize.getVideoSize(), -1, null, -1.0F);
/* 173 */       formatVideo = (VideoFormat)formatVideoNew.intersects((Format)formatVideo);
/*     */     } 
/* 175 */     if (this.customFrameRates != null && formatVideo != null) {
/* 176 */       VideoFormat videoFormat = new VideoFormat(null, null, -1, null, getFrameRate());
/* 177 */       formatVideo = (VideoFormat)videoFormat.intersects((Format)formatVideo);
/*     */     } 
/*     */     
/* 180 */     return (Format)formatVideo;
/*     */   }
/*     */   
/*     */   public float getFrameRate() {
/* 184 */     String selection = this.comboFrameRate.getSelectedItem();
/* 185 */     if (selection != null) {
/* 186 */       if (selection.equals(DEFAULT_STRING))
/* 187 */         return -1.0F; 
/*     */       try {
/* 189 */         float fr = Float.valueOf(selection).floatValue();
/* 190 */         return fr;
/*     */       }
/* 192 */       catch (NumberFormatException nfe) {}
/*     */     } 
/*     */     
/* 195 */     return -1.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCurrentFormat(VideoFormat formatDefault) {
/* 200 */     if (isFormatSupported(formatDefault))
/* 201 */       this.formatOld = formatDefault; 
/* 202 */     updateFields(this.formatOld);
/*     */   }
/*     */   
/*     */   public void setFrameRate(float frameRate) {
/* 206 */     for (int i = 0; i < this.comboFrameRate.getItemCount(); i++) {
/* 207 */       float value = Float.valueOf(this.comboFrameRate.getItem(i)).floatValue();
/* 208 */       if (Math.abs(frameRate - value) < 0.5D) {
/* 209 */         this.comboFrameRate.select(i);
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSupportedFormats(Format[] arrFormats, VideoFormat formatDefault) {
/* 219 */     this.arrSupportedFormats = arrFormats;
/*     */     
/* 221 */     this.vectorContSuppFormats.removeAllElements();
/* 222 */     int nCount = this.arrSupportedFormats.length;
/* 223 */     for (int i = 0; i < nCount; i++) {
/* 224 */       if (this.arrSupportedFormats[i] instanceof VideoFormat)
/* 225 */         this.vectorContSuppFormats.addElement(this.arrSupportedFormats[i]); 
/*     */     } 
/* 227 */     if (isFormatSupported(formatDefault)) {
/* 228 */       this.formatOld = formatDefault;
/*     */     } else {
/* 230 */       this.formatOld = null;
/* 231 */     }  setSupportedFormats(this.vectorContSuppFormats);
/*     */   }
/*     */   
/*     */   public void setSupportedFormats(Vector vectorContSuppFormats) {
/* 235 */     this.vectorContSuppFormats = vectorContSuppFormats;
/*     */     
/* 237 */     if (vectorContSuppFormats.isEmpty()) {
/* 238 */       this.checkEnableTrack.setState(false);
/* 239 */       this.checkEnableTrack.setEnabled(false);
/* 240 */       onEnableTrack(true);
/*     */       
/*     */       return;
/*     */     } 
/* 244 */     this.checkEnableTrack.setEnabled(true);
/* 245 */     this.checkEnableTrack.setState(this.boolEnableTrackSaved);
/* 246 */     onEnableTrack(true);
/*     */ 
/*     */     
/* 249 */     if (!isFormatSupported(this.formatOld)) {
/* 250 */       this.formatOld = null;
/*     */     }
/* 252 */     updateFields(this.formatOld);
/*     */   }
/*     */   
/*     */   public void setTrackEnabled(boolean boolEnable) {
/* 256 */     this.boolEnableTrackSaved = boolEnable;
/* 257 */     if (this.checkEnableTrack == null)
/*     */       return; 
/* 259 */     this.checkEnableTrack.setState(boolEnable);
/* 260 */     onEnableTrack(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTrackEnabled() {
/* 266 */     boolean boolEnabled = this.checkEnableTrack.getState();
/* 267 */     return boolEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize() {
/* 275 */     Dimension dim = new Dimension();
/* 276 */     if (this.boolDisplayEnableTrack == true) {
/* 277 */       Dimension dimControl = this.checkEnableTrack.getPreferredSize();
/* 278 */       dim.width = Math.max(dim.width, dimControl.width);
/* 279 */       dim.height += dimControl.height + 6;
/*     */     } 
/*     */     
/* 282 */     Dimension dimLabel = this.labelEncoding.getPreferredSize();
/* 283 */     this.nWidthLabel = Math.max(this.nWidthLabel, dimLabel.width);
/* 284 */     Dimension dimension1 = this.comboEncoding.getPreferredSize();
/* 285 */     this.nWidthData = Math.max(this.nWidthData, dimension1.width);
/* 286 */     dim.height += Math.max(dimLabel.height, dimension1.height) + 6;
/*     */     
/* 288 */     dimLabel = this.labelSize.getPreferredSize();
/* 289 */     this.nWidthLabel = Math.max(this.nWidthLabel, dimLabel.width);
/* 290 */     dimension1 = this.controlSize.getPreferredSize();
/* 291 */     this.nWidthData = Math.max(this.nWidthData, dimension1.width);
/* 292 */     dim.height += Math.max(dimLabel.height, dimension1.height) + 6;
/*     */     
/* 294 */     dimLabel = this.labelFrameRate.getPreferredSize();
/* 295 */     this.nWidthLabel = Math.max(this.nWidthLabel, dimLabel.width);
/* 296 */     dimension1 = this.comboFrameRate.getPreferredSize();
/* 297 */     this.nWidthData = Math.max(this.nWidthData, dimension1.width);
/* 298 */     dim.height += Math.max(dimLabel.height, dimension1.height) + 6;
/*     */     
/* 300 */     dimLabel = this.labelExtra.getPreferredSize();
/* 301 */     this.nWidthLabel = Math.max(this.nWidthLabel, dimLabel.width);
/* 302 */     dimension1 = this.comboExtra.getPreferredSize();
/* 303 */     this.nWidthData = Math.max(this.nWidthData, dimension1.width);
/* 304 */     dim.height += Math.max(dimLabel.height, dimension1.height);
/*     */     
/* 306 */     dim.width = Math.max(dim.width, this.nWidthLabel + 12 + this.nWidthData);
/* 307 */     return dim;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doLayout() {
/* 318 */     getPreferredSize();
/* 319 */     int nOffsetY = 0;
/* 320 */     int nLabelOffsetX = 0;
/* 321 */     int nDataOffsetX = this.nWidthLabel + 12;
/* 322 */     Dimension dimThis = getSize();
/*     */     
/* 324 */     if (this.boolDisplayEnableTrack == true) {
/* 325 */       Dimension dimControl = this.checkEnableTrack.getPreferredSize();
/* 326 */       this.checkEnableTrack.setBounds(nLabelOffsetX, nOffsetY, dimControl.width, dimControl.height);
/* 327 */       nOffsetY += dimControl.height + 6;
/*     */     } 
/*     */     
/* 330 */     Dimension dimLabel = this.labelEncoding.getPreferredSize();
/* 331 */     Dimension dimension1 = this.comboEncoding.getPreferredSize();
/* 332 */     this.labelEncoding.setBounds(nLabelOffsetX, nOffsetY, this.nWidthLabel, dimLabel.height);
/* 333 */     this.comboEncoding.setBounds(nDataOffsetX, nOffsetY, dimThis.width - nDataOffsetX, dimension1.height);
/* 334 */     nOffsetY += Math.max(dimLabel.height, dimension1.height) + 6;
/*     */     
/* 336 */     dimLabel = this.labelSize.getPreferredSize();
/* 337 */     dimension1 = this.controlSize.getPreferredSize();
/* 338 */     this.labelSize.setBounds(nLabelOffsetX, nOffsetY, this.nWidthLabel, dimLabel.height);
/* 339 */     this.controlSize.setBounds(nDataOffsetX, nOffsetY, dimThis.width - nDataOffsetX, dimension1.height);
/* 340 */     nOffsetY += Math.max(dimLabel.height, dimension1.height) + 6;
/*     */     
/* 342 */     dimLabel = this.labelFrameRate.getPreferredSize();
/* 343 */     dimension1 = this.comboFrameRate.getPreferredSize();
/* 344 */     this.labelFrameRate.setBounds(nLabelOffsetX, nOffsetY, this.nWidthLabel, dimLabel.height);
/* 345 */     this.comboFrameRate.setBounds(nDataOffsetX, nOffsetY, dimThis.width - nDataOffsetX, dimension1.height);
/* 346 */     nOffsetY += Math.max(dimLabel.height, dimension1.height) + 6;
/*     */     
/* 348 */     dimLabel = this.labelExtra.getPreferredSize();
/* 349 */     dimension1 = this.comboExtra.getPreferredSize();
/* 350 */     this.labelExtra.setBounds(nLabelOffsetX, nOffsetY, this.nWidthLabel, dimLabel.height);
/* 351 */     this.comboExtra.setBounds(nDataOffsetX, nOffsetY, dimThis.width - nDataOffsetX, dimension1.height);
/* 352 */     nOffsetY += Math.max(dimLabel.height, dimension1.height) + 6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() throws Exception {
/* 362 */     setLayout(null);
/*     */     
/* 364 */     this.checkEnableTrack = new Checkbox(JMFI18N.getResource("formatchooser.enabletrack"), true);
/* 365 */     this.checkEnableTrack.addItemListener(this);
/* 366 */     if (this.boolDisplayEnableTrack == true) {
/* 367 */       add(this.checkEnableTrack);
/*     */     }
/*     */     
/* 370 */     this.labelEncoding = new Label(JMFI18N.getResource("formatchooser.encoding"), 2);
/* 371 */     add(this.labelEncoding);
/* 372 */     this.comboEncoding = new Choice();
/* 373 */     this.comboEncoding.addItemListener(this);
/* 374 */     add(this.comboEncoding);
/*     */     
/* 376 */     this.labelSize = new Label(JMFI18N.getResource("formatchooser.videosize"), 2);
/* 377 */     add(this.labelSize);
/*     */     
/* 379 */     if (this.formatOld == null) {
/* 380 */       this.controlSize = new VideoSizeControl();
/*     */     } else {
/*     */       
/* 383 */       VideoSize sizeVideo = new VideoSize(this.formatOld.getSize());
/* 384 */       this.controlSize = new VideoSizeControl(sizeVideo);
/*     */     } 
/*     */     
/* 387 */     this.controlSize.addActionListener(this);
/* 388 */     add(this.controlSize);
/*     */     
/* 390 */     this.labelFrameRate = new Label(JMFI18N.getResource("formatchooser.framerate"), 2);
/* 391 */     add(this.labelFrameRate);
/* 392 */     this.comboFrameRate = new Choice();
/* 393 */     this.comboFrameRate.addItemListener(this);
/* 394 */     add(this.comboFrameRate);
/*     */     
/* 396 */     this.labelExtra = new Label("Extra:", 2);
/* 397 */     this.labelExtra.setVisible(false);
/* 398 */     add(this.labelExtra);
/* 399 */     this.comboExtra = new Choice();
/* 400 */     this.comboExtra.setVisible(false);
/* 401 */     add(this.comboExtra);
/*     */     
/* 403 */     updateFields(this.formatOld);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateFields(VideoFormat formatDefault) {
/* 410 */     String strEncodingPref = null;
/*     */ 
/*     */     
/* 413 */     Vector vectorEncoding = new Vector();
/*     */ 
/*     */     
/* 416 */     boolean boolEnable = this.comboEncoding.isEnabled();
/* 417 */     this.comboEncoding.setEnabled(false);
/* 418 */     this.comboEncoding.removeAll();
/*     */     
/* 420 */     int nSize = this.vectorContSuppFormats.size();
/* 421 */     for (int i = 0; i < nSize; i++) {
/* 422 */       Object objectFormat = this.vectorContSuppFormats.elementAt(i);
/* 423 */       if (objectFormat instanceof VideoFormat) {
/*     */         
/* 425 */         VideoFormat formatVideo = (VideoFormat)objectFormat;
/*     */         
/* 427 */         String strEncoding = formatVideo.getEncoding().toUpperCase();
/* 428 */         if (strEncodingPref == null) {
/* 429 */           strEncodingPref = strEncoding;
/*     */         }
/* 431 */         if (!vectorEncoding.contains(strEncoding)) {
/*     */           
/* 433 */           this.comboEncoding.addItem(strEncoding);
/* 434 */           vectorEncoding.addElement(strEncoding);
/*     */         } 
/*     */       } 
/* 437 */     }  if (formatDefault != null) {
/* 438 */       String str = formatDefault.getEncoding().toUpperCase();
/* 439 */       this.comboEncoding.select(str);
/*     */     }
/* 441 */     else if (strEncodingPref != null) {
/* 442 */       this.comboEncoding.select(strEncodingPref);
/*     */     }
/* 444 */     else if (this.comboEncoding.getItemCount() > 0) {
/* 445 */       this.comboEncoding.select(0);
/*     */     } 
/* 447 */     updateFieldsFromEncoding(formatDefault);
/* 448 */     this.comboEncoding.setEnabled(boolEnable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateFieldsFromEncoding(VideoFormat formatDefault) {
/* 455 */     VideoSize sizeVideoPref = null;
/* 456 */     boolean boolVideoSizePref = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 463 */     boolean boolEnable = this.controlSize.isEnabled();
/* 464 */     this.controlSize.setEnabled(false);
/* 465 */     this.controlSize.removeAll();
/*     */     
/* 467 */     int nSize = this.vectorContSuppFormats.size();
/* 468 */     for (int i = 0; i < nSize; i++) {
/* 469 */       Object objectFormat = this.vectorContSuppFormats.elementAt(i);
/* 470 */       if (objectFormat instanceof VideoFormat) {
/*     */         
/* 472 */         VideoFormat formatVideo = (VideoFormat)objectFormat;
/* 473 */         if (isFormatGoodForEncoding(formatVideo)) {
/*     */           VideoSize videoSize;
/* 475 */           Dimension formatVideoSize = formatVideo.getSize();
/* 476 */           if (formatVideoSize == null) {
/*     */             
/* 478 */             videoSize = null;
/*     */           } else {
/* 480 */             videoSize = new VideoSize(formatVideoSize);
/* 481 */           }  if (!boolVideoSizePref) {
/* 482 */             boolVideoSizePref = true;
/* 483 */             sizeVideoPref = videoSize;
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 489 */           this.controlSize.addItem(videoSize);
/*     */         } 
/*     */       } 
/*     */     } 
/* 493 */     if (formatDefault != null && isFormatGoodForEncoding(formatDefault)) {
/* 494 */       VideoSize videoSize; Dimension dimension = formatDefault.getSize();
/* 495 */       if (dimension == null) {
/* 496 */         videoSize = null;
/*     */       } else {
/*     */         
/* 499 */         videoSize = new VideoSize(dimension);
/*     */       } 
/* 501 */       this.controlSize.select(videoSize);
/*     */     }
/* 503 */     else if (boolVideoSizePref == true) {
/*     */       
/* 505 */       this.controlSize.select(sizeVideoPref);
/*     */     }
/* 507 */     else if (this.controlSize.getItemCount() > 0) {
/* 508 */       this.controlSize.select(0);
/*     */     } 
/* 510 */     updateFieldsFromSize(formatDefault);
/* 511 */     this.controlSize.setEnabled(boolEnable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateFieldsFromSize(VideoFormat formatDefault) {
/* 518 */     Float floatFrameRatePref = null;
/*     */ 
/*     */     
/* 521 */     Vector vectorRates = new Vector();
/*     */ 
/*     */     
/* 524 */     boolean boolEnable = this.comboFrameRate.isEnabled();
/* 525 */     this.comboFrameRate.setEnabled(false);
/* 526 */     if (this.customFrameRates == null) {
/* 527 */       this.comboFrameRate.removeAll();
/* 528 */     } else if (this.comboFrameRate.getItemCount() < 1) {
/*     */       
/* 530 */       for (int i = 0; i < this.customFrameRates.length; i++) {
/* 531 */         this.comboFrameRate.addItem(Float.toString(this.customFrameRates[i]));
/*     */       }
/*     */     } 
/* 534 */     int nSize = this.vectorContSuppFormats.size();
/* 535 */     for (byte b = 0; b < nSize; b++) {
/* 536 */       Object objectFormat = this.vectorContSuppFormats.elementAt(b);
/* 537 */       if (objectFormat instanceof VideoFormat) {
/*     */         
/* 539 */         VideoFormat formatVideo = (VideoFormat)objectFormat;
/* 540 */         if (isFormatGoodForEncoding(formatVideo))
/*     */         {
/* 542 */           if (isFormatGoodForVideoSize(formatVideo))
/*     */           {
/*     */             
/* 545 */             if (this.customFrameRates == null) {
/*     */ 
/*     */ 
/*     */               
/* 549 */               Float floatFrameRate = new Float(formatVideo.getFrameRate());
/* 550 */               if (floatFrameRatePref == null) {
/* 551 */                 floatFrameRatePref = floatFrameRate;
/*     */               }
/* 553 */               if (!vectorRates.contains(floatFrameRate))
/*     */               
/* 555 */               { if (floatFrameRate.floatValue() == -1.0F) {
/* 556 */                   this.comboFrameRate.addItem(DEFAULT_STRING);
/*     */                 } else {
/* 558 */                   this.comboFrameRate.addItem(floatFrameRate.toString());
/* 559 */                 }  vectorRates.addElement(floatFrameRate); } 
/*     */             }  }  } 
/*     */       } 
/* 562 */     }  if (formatDefault != null && this.customFrameRates == null && isFormatGoodForEncoding(formatDefault) && isFormatGoodForVideoSize(formatDefault)) {
/*     */ 
/*     */       
/* 565 */       Float float_ = new Float(formatDefault.getFrameRate());
/* 566 */       if (float_.floatValue() == -1.0F) {
/* 567 */         this.comboFrameRate.select(DEFAULT_STRING);
/*     */       } else {
/* 569 */         this.comboFrameRate.select(float_.toString());
/*     */       } 
/* 571 */     } else if (floatFrameRatePref != null) {
/* 572 */       if (floatFrameRatePref.floatValue() == -1.0F) {
/* 573 */         this.comboFrameRate.select(DEFAULT_STRING);
/*     */       } else {
/* 575 */         this.comboFrameRate.select(floatFrameRatePref.toString());
/*     */       } 
/* 577 */     } else if (this.comboFrameRate.getItemCount() > 0) {
/* 578 */       this.comboFrameRate.select(0);
/*     */     } 
/* 580 */     updateFieldsFromRate(formatDefault);
/* 581 */     this.comboFrameRate.setEnabled(boolEnable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateFieldsFromRate(VideoFormat formatDefault) {
/* 590 */     String strYuvType = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 595 */     Vector vectorExtra = new Vector();
/* 596 */     boolean boolRGB = false;
/* 597 */     boolean boolYUV = false;
/*     */ 
/*     */ 
/*     */     
/* 601 */     String strEncoding = this.comboEncoding.getSelectedItem();
/* 602 */     if (strEncoding == null) {
/*     */       return;
/*     */     }
/* 605 */     if (strEncoding.equalsIgnoreCase("rgb")) {
/* 606 */       this.labelExtra.setText(JMFI18N.getResource("formatchooser.bitsperpixel"));
/* 607 */       this.labelExtra.setVisible(true);
/* 608 */       this.comboExtra.setVisible(true);
/* 609 */       boolRGB = true;
/*     */     }
/* 611 */     else if (strEncoding.equalsIgnoreCase("yuv")) {
/* 612 */       this.labelExtra.setText(JMFI18N.getResource("formatchooser.yuvtype"));
/* 613 */       this.labelExtra.setVisible(true);
/* 614 */       this.comboExtra.setVisible(true);
/* 615 */       boolYUV = true;
/*     */     } else {
/*     */       
/* 618 */       this.labelExtra.setVisible(false);
/* 619 */       this.comboExtra.setVisible(false);
/*     */       
/*     */       return;
/*     */     } 
/* 623 */     boolean boolEnable = this.comboExtra.isEnabled();
/* 624 */     this.comboExtra.setEnabled(false);
/* 625 */     this.comboExtra.removeAll();
/*     */     
/* 627 */     int nSize = this.vectorContSuppFormats.size();
/* 628 */     for (int i = 0; i < nSize; i++) {
/* 629 */       Object objectFormat = this.vectorContSuppFormats.elementAt(i);
/* 630 */       if (objectFormat instanceof VideoFormat) {
/*     */         
/* 632 */         VideoFormat formatVideo = (VideoFormat)objectFormat;
/* 633 */         if (isFormatGoodForEncoding(formatVideo))
/*     */         {
/* 635 */           if (isFormatGoodForVideoSize(formatVideo))
/*     */           {
/* 637 */             if (isFormatGoodForFrameRate(formatVideo))
/*     */             {
/*     */               
/* 640 */               if (boolRGB == true && formatVideo instanceof RGBFormat) {
/* 641 */                 RGBFormat formatRGB = (RGBFormat)formatVideo;
/* 642 */                 Integer integerBitsPerPixel = new Integer(formatRGB.getBitsPerPixel());
/* 643 */                 if (!vectorExtra.contains(integerBitsPerPixel)) {
/* 644 */                   this.comboExtra.addItem(integerBitsPerPixel.toString());
/* 645 */                   vectorExtra.addElement(integerBitsPerPixel);
/*     */                 }
/*     */               
/* 648 */               } else if (boolYUV == true && formatVideo instanceof YUVFormat) {
/* 649 */                 YUVFormat formatYUV = (YUVFormat)formatVideo;
/* 650 */                 int nYuvType = formatYUV.getYuvType();
/* 651 */                 strYuvType = getYuvType(nYuvType);
/* 652 */                 if (strYuvType != null && !vectorExtra.contains(strYuvType)) {
/* 653 */                   this.comboExtra.addItem(strYuvType);
/* 654 */                   vectorExtra.addElement(strYuvType);
/*     */                 } 
/*     */               }  }  }  } 
/*     */       } 
/*     */     } 
/* 659 */     if (formatDefault != null && isFormatGoodForEncoding(formatDefault) && isFormatGoodForVideoSize(formatDefault) && isFormatGoodForFrameRate(formatDefault)) {
/*     */ 
/*     */       
/* 662 */       if (boolRGB == true && formatDefault instanceof RGBFormat) {
/* 663 */         RGBFormat rGBFormat = (RGBFormat)formatDefault;
/* 664 */         Integer integer = new Integer(rGBFormat.getBitsPerPixel());
/* 665 */         this.comboExtra.select(integer.toString());
/*     */       }
/* 667 */       else if (boolYUV == true && formatDefault instanceof YUVFormat) {
/* 668 */         YUVFormat yUVFormat = (YUVFormat)formatDefault;
/* 669 */         int j = yUVFormat.getYuvType();
/* 670 */         strYuvType = getYuvType(j);
/* 671 */         if (strYuvType != null) {
/* 672 */           this.comboExtra.select(strYuvType);
/*     */         }
/* 674 */       } else if (this.comboExtra.getItemCount() > 0) {
/* 675 */         this.comboExtra.select(0);
/*     */       } 
/* 677 */     } else if (this.comboExtra.getItemCount() > 0) {
/* 678 */       this.comboExtra.select(0);
/*     */     } 
/* 680 */     this.comboExtra.setEnabled(boolEnable);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isFormatGoodForEncoding(VideoFormat format) {
/* 685 */     boolean boolResult = false;
/*     */     
/* 687 */     String strEncoding = this.comboEncoding.getSelectedItem();
/* 688 */     if (strEncoding != null) {
/* 689 */       boolResult = format.getEncoding().equalsIgnoreCase(strEncoding);
/*     */     }
/* 691 */     return boolResult;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isFormatGoodForVideoSize(VideoFormat format) {
/* 696 */     boolean boolResult = false;
/*     */ 
/*     */ 
/*     */     
/* 700 */     VideoSize sizeVideo = this.controlSize.getVideoSize();
/* 701 */     Dimension formatVideoSize = format.getSize();
/* 702 */     if (formatVideoSize == null) {
/* 703 */       boolResult = true;
/*     */     } else {
/* 705 */       boolResult = sizeVideo.equals(formatVideoSize);
/*     */     } 
/* 707 */     return boolResult;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isFormatGoodForFrameRate(VideoFormat format) {
/* 714 */     boolean boolResult = false;
/*     */ 
/*     */     
/* 717 */     if (this.customFrameRates != null) {
/* 718 */       return true;
/*     */     }
/* 720 */     String strFrameRate = this.comboFrameRate.getSelectedItem();
/* 721 */     if (strFrameRate.equals(DEFAULT_STRING)) {
/* 722 */       return true;
/*     */     }
/* 724 */     float fFrameRate2 = format.getFrameRate();
/* 725 */     if (fFrameRate2 == -1.0F) {
/* 726 */       return true;
/*     */     }
/* 728 */     if (strFrameRate != null) {
/* 729 */       float fFrameRate1 = Float.valueOf(strFrameRate).floatValue();
/* 730 */       boolResult = (fFrameRate1 == fFrameRate2);
/*     */     } 
/* 732 */     return boolResult;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isFormatSupported(VideoFormat format) {
/* 740 */     boolean boolSupported = false;
/*     */     
/* 742 */     if (format == null) {
/* 743 */       return boolSupported;
/*     */     }
/* 745 */     int nCount = this.vectorContSuppFormats.size();
/* 746 */     for (int i = 0; i < nCount && !boolSupported; i++) {
/* 747 */       VideoFormat formatVideo = this.vectorContSuppFormats.elementAt(i);
/* 748 */       if (formatVideo.matches((Format)format))
/* 749 */         boolSupported = true; 
/*     */     } 
/* 751 */     return boolSupported;
/*     */   }
/*     */   
/*     */   public void actionPerformed(ActionEvent event) {
/* 755 */     if (event.getActionCommand().equals("Size Changed")) {
/* 756 */       updateFieldsFromSize(this.formatOld);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void itemStateChanged(ItemEvent event) {
/* 763 */     Object objectSource = event.getSource();
/* 764 */     if (objectSource == this.checkEnableTrack) {
/* 765 */       this.boolEnableTrackSaved = this.checkEnableTrack.getState();
/* 766 */       onEnableTrack(true);
/*     */     }
/* 768 */     else if (objectSource == this.comboEncoding) {
/* 769 */       updateFieldsFromEncoding(this.formatOld);
/*     */     }
/* 771 */     else if (objectSource == this.controlSize) {
/* 772 */       updateFieldsFromSize(this.formatOld);
/*     */     }
/* 774 */     else if (objectSource == this.comboFrameRate) {
/* 775 */       updateFieldsFromRate(this.formatOld);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void onEnableTrack(boolean notifyListener) {
/* 783 */     boolean boolEnable = this.checkEnableTrack.getState();
/* 784 */     enableControls((boolEnable && isEnabled()));
/*     */     
/* 786 */     if (notifyListener == true && this.listenerEnableTrack != null) {
/* 787 */       ActionEvent actionEvent; if (boolEnable == true) {
/* 788 */         actionEvent = new ActionEvent(this, 1001, "ACTION_VIDEO_TRACK_ENABLED");
/*     */       } else {
/* 790 */         actionEvent = new ActionEvent(this, 1001, "ACTION_VIDEO_TRACK_DISABLED");
/* 791 */       }  this.listenerEnableTrack.actionPerformed(actionEvent);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void enableControls(boolean boolEnable) {
/* 796 */     this.labelEncoding.setEnabled(boolEnable);
/* 797 */     this.comboEncoding.setEnabled(boolEnable);
/* 798 */     this.labelSize.setEnabled(boolEnable);
/* 799 */     this.controlSize.setEnabled(boolEnable);
/* 800 */     this.labelFrameRate.setEnabled(boolEnable);
/* 801 */     this.comboFrameRate.setEnabled(boolEnable);
/* 802 */     this.labelExtra.setEnabled(boolEnable);
/* 803 */     this.comboExtra.setEnabled(boolEnable);
/*     */   }
/*     */   
/*     */   private String getYuvType(int nType) {
/* 807 */     String strType = null;
/*     */     
/* 809 */     if ((nType & 0x2) == 2) {
/* 810 */       strType = JMFI18N.getResource("formatchooser.yuv.4:2:0");
/* 811 */     } else if ((nType & 0x4) == 4) {
/* 812 */       strType = JMFI18N.getResource("formatchooser.yuv.4:2:2");
/* 813 */     } else if ((nType & 0x20) == 32) {
/* 814 */       strType = JMFI18N.getResource("formatchooser.yuv.YUYV");
/* 815 */     } else if ((nType & 0x8) == 8) {
/* 816 */       strType = JMFI18N.getResource("formatchooser.yuv.1:1:1");
/* 817 */     } else if ((nType & 0x1) == 1) {
/* 818 */       strType = JMFI18N.getResource("formatchooser.yuv.4:1:1");
/* 819 */     } else if ((nType & 0x10) == 16) {
/* 820 */       strType = JMFI18N.getResource("formatchooser.yuv.YVU9");
/*     */     } else {
/* 822 */       strType = null;
/*     */     } 
/* 824 */     return strType;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\VideoFormatChooser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */