package com.sun.media.ui;

import com.sun.media.util.JMFI18N;
import java.awt.Checkbox;
import java.awt.Choice;
import java.awt.Dimension;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Vector;
import javax.media.Format;
import javax.media.format.RGBFormat;
import javax.media.format.VideoFormat;
import javax.media.format.YUVFormat;

public class VideoFormatChooser extends Panel implements ItemListener, ActionListener {
  public static final String ACTION_TRACK_ENABLED = "ACTION_VIDEO_TRACK_ENABLED";
  
  public static final String ACTION_TRACK_DISABLED = "ACTION_VIDEO_TRACK_DISABLED";
  
  private VideoFormat formatOld;
  
  private Format[] arrSupportedFormats = null;
  
  private float[] customFrameRates = null;
  
  private Vector vectorContSuppFormats = new Vector();
  
  private boolean boolDisplayEnableTrack;
  
  private ActionListener listenerEnableTrack;
  
  private boolean boolEnableTrackSaved = true;
  
  private Checkbox checkEnableTrack;
  
  private Label labelEncoding;
  
  private Choice comboEncoding;
  
  private Label labelSize;
  
  private VideoSizeControl controlSize;
  
  private Label labelFrameRate;
  
  private Choice comboFrameRate;
  
  private Label labelExtra;
  
  private Choice comboExtra;
  
  private int nWidthLabel = 0;
  
  private int nWidthData = 0;
  
  private static final int MARGINH = 12;
  
  private static final int MARGINV = 6;
  
  private static final float[] standardCaptureRates = new float[] { 
      15.0F, 1.0F, 2.0F, 5.0F, 7.5F, 10.0F, 12.5F, 20.0F, 24.0F, 25.0F, 
      30.0F };
  
  private static final String DEFAULT_STRING = JMFI18N.getResource("formatchooser.default");
  
  public VideoFormatChooser(Format[] arrFormats, VideoFormat formatDefault, float[] frameRates) {
    this(arrFormats, formatDefault, false, (ActionListener)null, frameRates);
  }
  
  public VideoFormatChooser(Format[] arrFormats, VideoFormat formatDefault) {
    this(arrFormats, formatDefault, false, (ActionListener)null, (float[])null);
  }
  
  public VideoFormatChooser(Format[] arrFormats, VideoFormat formatDefault, boolean boolDisplayEnableTrack, ActionListener listenerEnableTrack) {
    this(arrFormats, formatDefault, boolDisplayEnableTrack, listenerEnableTrack, (float[])null);
  }
  
  public VideoFormatChooser(Format[] arrFormats, VideoFormat formatDefault, boolean boolDisplayEnableTrack, ActionListener listenerEnableTrack, boolean capture) {
    this(arrFormats, formatDefault, boolDisplayEnableTrack, listenerEnableTrack, capture ? standardCaptureRates : null);
  }
  
  public VideoFormatChooser(Format[] arrFormats, VideoFormat formatDefault, boolean boolDisplayEnableTrack, ActionListener listenerEnableTrack, float[] frameRates) {
    this.arrSupportedFormats = arrFormats;
    this.boolDisplayEnableTrack = boolDisplayEnableTrack;
    this.listenerEnableTrack = listenerEnableTrack;
    this.customFrameRates = frameRates;
    int nCount = this.arrSupportedFormats.length;
    for (int i = 0; i < nCount; i++) {
      if (this.arrSupportedFormats[i] instanceof VideoFormat)
        this.vectorContSuppFormats.addElement(this.arrSupportedFormats[i]); 
    } 
    if (isFormatSupported(formatDefault)) {
      this.formatOld = formatDefault;
    } else {
      this.formatOld = null;
    } 
    try {
      init();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void setEnabled(boolean boolEnable) {
    super.setEnabled(boolEnable);
    if (this.checkEnableTrack != null)
      this.checkEnableTrack.setEnabled(boolEnable); 
    enableControls(boolEnable);
  }
  
  public Format getFormat() {
    String strYuvType = null;
    VideoFormat formatVideo = null;
    String strEncoding = this.comboEncoding.getSelectedItem();
    int nSize = this.vectorContSuppFormats.size();
    for (int i = 0; i < nSize; i++) {
      Object objectFormat = this.vectorContSuppFormats.elementAt(i);
      if (!(objectFormat instanceof VideoFormat))
        continue; 
      formatVideo = (VideoFormat)objectFormat;
      if (!isFormatGoodForEncoding(formatVideo))
        continue; 
      if (!isFormatGoodForVideoSize(formatVideo))
        continue; 
      if (!isFormatGoodForFrameRate(formatVideo))
        continue; 
      if (strEncoding.equalsIgnoreCase("rgb") && formatVideo instanceof RGBFormat) {
        RGBFormat formatRGB = (RGBFormat)formatVideo;
        Integer integerBitsPerPixel = new Integer(formatRGB.getBitsPerPixel());
        String strBitsPerPixel = integerBitsPerPixel.toString();
        if (!this.comboExtra.getSelectedItem().equals(strBitsPerPixel))
          continue; 
        break;
      } 
      if (strEncoding.equalsIgnoreCase("yuv") && formatVideo instanceof YUVFormat) {
        YUVFormat formatYUV = (YUVFormat)formatVideo;
        int nYuvType = formatYUV.getYuvType();
        strYuvType = getYuvType(nYuvType);
        if (strYuvType == null || !this.comboExtra.getSelectedItem().equals(strYuvType))
          continue; 
      } 
      break;
    } 
    if (i >= nSize)
      return null; 
    if (formatVideo.getSize() == null) {
      VideoFormat formatVideoNew = new VideoFormat(null, this.controlSize.getVideoSize(), -1, null, -1.0F);
      formatVideo = (VideoFormat)formatVideoNew.intersects((Format)formatVideo);
    } 
    if (this.customFrameRates != null && formatVideo != null) {
      VideoFormat videoFormat = new VideoFormat(null, null, -1, null, getFrameRate());
      formatVideo = (VideoFormat)videoFormat.intersects((Format)formatVideo);
    } 
    return (Format)formatVideo;
  }
  
  public float getFrameRate() {
    String selection = this.comboFrameRate.getSelectedItem();
    if (selection != null) {
      if (selection.equals(DEFAULT_STRING))
        return -1.0F; 
      try {
        float fr = Float.valueOf(selection).floatValue();
        return fr;
      } catch (NumberFormatException nfe) {}
    } 
    return -1.0F;
  }
  
  public void setCurrentFormat(VideoFormat formatDefault) {
    if (isFormatSupported(formatDefault))
      this.formatOld = formatDefault; 
    updateFields(this.formatOld);
  }
  
  public void setFrameRate(float frameRate) {
    for (int i = 0; i < this.comboFrameRate.getItemCount(); i++) {
      float value = Float.valueOf(this.comboFrameRate.getItem(i)).floatValue();
      if (Math.abs(frameRate - value) < 0.5D) {
        this.comboFrameRate.select(i);
        return;
      } 
    } 
  }
  
  public void setSupportedFormats(Format[] arrFormats, VideoFormat formatDefault) {
    this.arrSupportedFormats = arrFormats;
    this.vectorContSuppFormats.removeAllElements();
    int nCount = this.arrSupportedFormats.length;
    for (int i = 0; i < nCount; i++) {
      if (this.arrSupportedFormats[i] instanceof VideoFormat)
        this.vectorContSuppFormats.addElement(this.arrSupportedFormats[i]); 
    } 
    if (isFormatSupported(formatDefault)) {
      this.formatOld = formatDefault;
    } else {
      this.formatOld = null;
    } 
    setSupportedFormats(this.vectorContSuppFormats);
  }
  
  public void setSupportedFormats(Vector vectorContSuppFormats) {
    this.vectorContSuppFormats = vectorContSuppFormats;
    if (vectorContSuppFormats.isEmpty()) {
      this.checkEnableTrack.setState(false);
      this.checkEnableTrack.setEnabled(false);
      onEnableTrack(true);
      return;
    } 
    this.checkEnableTrack.setEnabled(true);
    this.checkEnableTrack.setState(this.boolEnableTrackSaved);
    onEnableTrack(true);
    if (!isFormatSupported(this.formatOld))
      this.formatOld = null; 
    updateFields(this.formatOld);
  }
  
  public void setTrackEnabled(boolean boolEnable) {
    this.boolEnableTrackSaved = boolEnable;
    if (this.checkEnableTrack == null)
      return; 
    this.checkEnableTrack.setState(boolEnable);
    onEnableTrack(true);
  }
  
  public boolean isTrackEnabled() {
    boolean boolEnabled = this.checkEnableTrack.getState();
    return boolEnabled;
  }
  
  public Dimension getPreferredSize() {
    Dimension dim = new Dimension();
    if (this.boolDisplayEnableTrack == true) {
      Dimension dimControl = this.checkEnableTrack.getPreferredSize();
      dim.width = Math.max(dim.width, dimControl.width);
      dim.height += dimControl.height + 6;
    } 
    Dimension dimLabel = this.labelEncoding.getPreferredSize();
    this.nWidthLabel = Math.max(this.nWidthLabel, dimLabel.width);
    Dimension dimension1 = this.comboEncoding.getPreferredSize();
    this.nWidthData = Math.max(this.nWidthData, dimension1.width);
    dim.height += Math.max(dimLabel.height, dimension1.height) + 6;
    dimLabel = this.labelSize.getPreferredSize();
    this.nWidthLabel = Math.max(this.nWidthLabel, dimLabel.width);
    dimension1 = this.controlSize.getPreferredSize();
    this.nWidthData = Math.max(this.nWidthData, dimension1.width);
    dim.height += Math.max(dimLabel.height, dimension1.height) + 6;
    dimLabel = this.labelFrameRate.getPreferredSize();
    this.nWidthLabel = Math.max(this.nWidthLabel, dimLabel.width);
    dimension1 = this.comboFrameRate.getPreferredSize();
    this.nWidthData = Math.max(this.nWidthData, dimension1.width);
    dim.height += Math.max(dimLabel.height, dimension1.height) + 6;
    dimLabel = this.labelExtra.getPreferredSize();
    this.nWidthLabel = Math.max(this.nWidthLabel, dimLabel.width);
    dimension1 = this.comboExtra.getPreferredSize();
    this.nWidthData = Math.max(this.nWidthData, dimension1.width);
    dim.height += Math.max(dimLabel.height, dimension1.height);
    dim.width = Math.max(dim.width, this.nWidthLabel + 12 + this.nWidthData);
    return dim;
  }
  
  public void doLayout() {
    getPreferredSize();
    int nOffsetY = 0;
    int nLabelOffsetX = 0;
    int nDataOffsetX = this.nWidthLabel + 12;
    Dimension dimThis = getSize();
    if (this.boolDisplayEnableTrack == true) {
      Dimension dimControl = this.checkEnableTrack.getPreferredSize();
      this.checkEnableTrack.setBounds(nLabelOffsetX, nOffsetY, dimControl.width, dimControl.height);
      nOffsetY += dimControl.height + 6;
    } 
    Dimension dimLabel = this.labelEncoding.getPreferredSize();
    Dimension dimension1 = this.comboEncoding.getPreferredSize();
    this.labelEncoding.setBounds(nLabelOffsetX, nOffsetY, this.nWidthLabel, dimLabel.height);
    this.comboEncoding.setBounds(nDataOffsetX, nOffsetY, dimThis.width - nDataOffsetX, dimension1.height);
    nOffsetY += Math.max(dimLabel.height, dimension1.height) + 6;
    dimLabel = this.labelSize.getPreferredSize();
    dimension1 = this.controlSize.getPreferredSize();
    this.labelSize.setBounds(nLabelOffsetX, nOffsetY, this.nWidthLabel, dimLabel.height);
    this.controlSize.setBounds(nDataOffsetX, nOffsetY, dimThis.width - nDataOffsetX, dimension1.height);
    nOffsetY += Math.max(dimLabel.height, dimension1.height) + 6;
    dimLabel = this.labelFrameRate.getPreferredSize();
    dimension1 = this.comboFrameRate.getPreferredSize();
    this.labelFrameRate.setBounds(nLabelOffsetX, nOffsetY, this.nWidthLabel, dimLabel.height);
    this.comboFrameRate.setBounds(nDataOffsetX, nOffsetY, dimThis.width - nDataOffsetX, dimension1.height);
    nOffsetY += Math.max(dimLabel.height, dimension1.height) + 6;
    dimLabel = this.labelExtra.getPreferredSize();
    dimension1 = this.comboExtra.getPreferredSize();
    this.labelExtra.setBounds(nLabelOffsetX, nOffsetY, this.nWidthLabel, dimLabel.height);
    this.comboExtra.setBounds(nDataOffsetX, nOffsetY, dimThis.width - nDataOffsetX, dimension1.height);
    nOffsetY += Math.max(dimLabel.height, dimension1.height) + 6;
  }
  
  private void init() throws Exception {
    setLayout(null);
    this.checkEnableTrack = new Checkbox(JMFI18N.getResource("formatchooser.enabletrack"), true);
    this.checkEnableTrack.addItemListener(this);
    if (this.boolDisplayEnableTrack == true)
      add(this.checkEnableTrack); 
    this.labelEncoding = new Label(JMFI18N.getResource("formatchooser.encoding"), 2);
    add(this.labelEncoding);
    this.comboEncoding = new Choice();
    this.comboEncoding.addItemListener(this);
    add(this.comboEncoding);
    this.labelSize = new Label(JMFI18N.getResource("formatchooser.videosize"), 2);
    add(this.labelSize);
    if (this.formatOld == null) {
      this.controlSize = new VideoSizeControl();
    } else {
      VideoSize sizeVideo = new VideoSize(this.formatOld.getSize());
      this.controlSize = new VideoSizeControl(sizeVideo);
    } 
    this.controlSize.addActionListener(this);
    add(this.controlSize);
    this.labelFrameRate = new Label(JMFI18N.getResource("formatchooser.framerate"), 2);
    add(this.labelFrameRate);
    this.comboFrameRate = new Choice();
    this.comboFrameRate.addItemListener(this);
    add(this.comboFrameRate);
    this.labelExtra = new Label("Extra:", 2);
    this.labelExtra.setVisible(false);
    add(this.labelExtra);
    this.comboExtra = new Choice();
    this.comboExtra.setVisible(false);
    add(this.comboExtra);
    updateFields(this.formatOld);
  }
  
  private void updateFields(VideoFormat formatDefault) {
    String strEncodingPref = null;
    Vector vectorEncoding = new Vector();
    boolean boolEnable = this.comboEncoding.isEnabled();
    this.comboEncoding.setEnabled(false);
    this.comboEncoding.removeAll();
    int nSize = this.vectorContSuppFormats.size();
    for (int i = 0; i < nSize; i++) {
      Object objectFormat = this.vectorContSuppFormats.elementAt(i);
      if (objectFormat instanceof VideoFormat) {
        VideoFormat formatVideo = (VideoFormat)objectFormat;
        String strEncoding = formatVideo.getEncoding().toUpperCase();
        if (strEncodingPref == null)
          strEncodingPref = strEncoding; 
        if (!vectorEncoding.contains(strEncoding)) {
          this.comboEncoding.addItem(strEncoding);
          vectorEncoding.addElement(strEncoding);
        } 
      } 
    } 
    if (formatDefault != null) {
      String str = formatDefault.getEncoding().toUpperCase();
      this.comboEncoding.select(str);
    } else if (strEncodingPref != null) {
      this.comboEncoding.select(strEncodingPref);
    } else if (this.comboEncoding.getItemCount() > 0) {
      this.comboEncoding.select(0);
    } 
    updateFieldsFromEncoding(formatDefault);
    this.comboEncoding.setEnabled(boolEnable);
  }
  
  private void updateFieldsFromEncoding(VideoFormat formatDefault) {
    VideoSize sizeVideoPref = null;
    boolean boolVideoSizePref = false;
    boolean boolEnable = this.controlSize.isEnabled();
    this.controlSize.setEnabled(false);
    this.controlSize.removeAll();
    int nSize = this.vectorContSuppFormats.size();
    for (int i = 0; i < nSize; i++) {
      Object objectFormat = this.vectorContSuppFormats.elementAt(i);
      if (objectFormat instanceof VideoFormat) {
        VideoFormat formatVideo = (VideoFormat)objectFormat;
        if (isFormatGoodForEncoding(formatVideo)) {
          VideoSize videoSize;
          Dimension formatVideoSize = formatVideo.getSize();
          if (formatVideoSize == null) {
            videoSize = null;
          } else {
            videoSize = new VideoSize(formatVideoSize);
          } 
          if (!boolVideoSizePref) {
            boolVideoSizePref = true;
            sizeVideoPref = videoSize;
          } 
          this.controlSize.addItem(videoSize);
        } 
      } 
    } 
    if (formatDefault != null && isFormatGoodForEncoding(formatDefault)) {
      VideoSize videoSize;
      Dimension dimension = formatDefault.getSize();
      if (dimension == null) {
        videoSize = null;
      } else {
        videoSize = new VideoSize(dimension);
      } 
      this.controlSize.select(videoSize);
    } else if (boolVideoSizePref == true) {
      this.controlSize.select(sizeVideoPref);
    } else if (this.controlSize.getItemCount() > 0) {
      this.controlSize.select(0);
    } 
    updateFieldsFromSize(formatDefault);
    this.controlSize.setEnabled(boolEnable);
  }
  
  private void updateFieldsFromSize(VideoFormat formatDefault) {
    Float floatFrameRatePref = null;
    Vector vectorRates = new Vector();
    boolean boolEnable = this.comboFrameRate.isEnabled();
    this.comboFrameRate.setEnabled(false);
    if (this.customFrameRates == null) {
      this.comboFrameRate.removeAll();
    } else if (this.comboFrameRate.getItemCount() < 1) {
      for (int i = 0; i < this.customFrameRates.length; i++)
        this.comboFrameRate.addItem(Float.toString(this.customFrameRates[i])); 
    } 
    int nSize = this.vectorContSuppFormats.size();
    for (byte b = 0; b < nSize; b++) {
      Object objectFormat = this.vectorContSuppFormats.elementAt(b);
      if (objectFormat instanceof VideoFormat) {
        VideoFormat formatVideo = (VideoFormat)objectFormat;
        if (isFormatGoodForEncoding(formatVideo))
          if (isFormatGoodForVideoSize(formatVideo))
            if (this.customFrameRates == null) {
              Float floatFrameRate = new Float(formatVideo.getFrameRate());
              if (floatFrameRatePref == null)
                floatFrameRatePref = floatFrameRate; 
              if (!vectorRates.contains(floatFrameRate)) {
                if (floatFrameRate.floatValue() == -1.0F) {
                  this.comboFrameRate.addItem(DEFAULT_STRING);
                } else {
                  this.comboFrameRate.addItem(floatFrameRate.toString());
                } 
                vectorRates.addElement(floatFrameRate);
              } 
            }   
      } 
    } 
    if (formatDefault != null && this.customFrameRates == null && isFormatGoodForEncoding(formatDefault) && isFormatGoodForVideoSize(formatDefault)) {
      Float float_ = new Float(formatDefault.getFrameRate());
      if (float_.floatValue() == -1.0F) {
        this.comboFrameRate.select(DEFAULT_STRING);
      } else {
        this.comboFrameRate.select(float_.toString());
      } 
    } else if (floatFrameRatePref != null) {
      if (floatFrameRatePref.floatValue() == -1.0F) {
        this.comboFrameRate.select(DEFAULT_STRING);
      } else {
        this.comboFrameRate.select(floatFrameRatePref.toString());
      } 
    } else if (this.comboFrameRate.getItemCount() > 0) {
      this.comboFrameRate.select(0);
    } 
    updateFieldsFromRate(formatDefault);
    this.comboFrameRate.setEnabled(boolEnable);
  }
  
  private void updateFieldsFromRate(VideoFormat formatDefault) {
    String strYuvType = null;
    Vector vectorExtra = new Vector();
    boolean boolRGB = false;
    boolean boolYUV = false;
    String strEncoding = this.comboEncoding.getSelectedItem();
    if (strEncoding == null)
      return; 
    if (strEncoding.equalsIgnoreCase("rgb")) {
      this.labelExtra.setText(JMFI18N.getResource("formatchooser.bitsperpixel"));
      this.labelExtra.setVisible(true);
      this.comboExtra.setVisible(true);
      boolRGB = true;
    } else if (strEncoding.equalsIgnoreCase("yuv")) {
      this.labelExtra.setText(JMFI18N.getResource("formatchooser.yuvtype"));
      this.labelExtra.setVisible(true);
      this.comboExtra.setVisible(true);
      boolYUV = true;
    } else {
      this.labelExtra.setVisible(false);
      this.comboExtra.setVisible(false);
      return;
    } 
    boolean boolEnable = this.comboExtra.isEnabled();
    this.comboExtra.setEnabled(false);
    this.comboExtra.removeAll();
    int nSize = this.vectorContSuppFormats.size();
    for (int i = 0; i < nSize; i++) {
      Object objectFormat = this.vectorContSuppFormats.elementAt(i);
      if (objectFormat instanceof VideoFormat) {
        VideoFormat formatVideo = (VideoFormat)objectFormat;
        if (isFormatGoodForEncoding(formatVideo))
          if (isFormatGoodForVideoSize(formatVideo))
            if (isFormatGoodForFrameRate(formatVideo))
              if (boolRGB == true && formatVideo instanceof RGBFormat) {
                RGBFormat formatRGB = (RGBFormat)formatVideo;
                Integer integerBitsPerPixel = new Integer(formatRGB.getBitsPerPixel());
                if (!vectorExtra.contains(integerBitsPerPixel)) {
                  this.comboExtra.addItem(integerBitsPerPixel.toString());
                  vectorExtra.addElement(integerBitsPerPixel);
                } 
              } else if (boolYUV == true && formatVideo instanceof YUVFormat) {
                YUVFormat formatYUV = (YUVFormat)formatVideo;
                int nYuvType = formatYUV.getYuvType();
                strYuvType = getYuvType(nYuvType);
                if (strYuvType != null && !vectorExtra.contains(strYuvType)) {
                  this.comboExtra.addItem(strYuvType);
                  vectorExtra.addElement(strYuvType);
                } 
              }    
      } 
    } 
    if (formatDefault != null && isFormatGoodForEncoding(formatDefault) && isFormatGoodForVideoSize(formatDefault) && isFormatGoodForFrameRate(formatDefault)) {
      if (boolRGB == true && formatDefault instanceof RGBFormat) {
        RGBFormat rGBFormat = (RGBFormat)formatDefault;
        Integer integer = new Integer(rGBFormat.getBitsPerPixel());
        this.comboExtra.select(integer.toString());
      } else if (boolYUV == true && formatDefault instanceof YUVFormat) {
        YUVFormat yUVFormat = (YUVFormat)formatDefault;
        int j = yUVFormat.getYuvType();
        strYuvType = getYuvType(j);
        if (strYuvType != null)
          this.comboExtra.select(strYuvType); 
      } else if (this.comboExtra.getItemCount() > 0) {
        this.comboExtra.select(0);
      } 
    } else if (this.comboExtra.getItemCount() > 0) {
      this.comboExtra.select(0);
    } 
    this.comboExtra.setEnabled(boolEnable);
  }
  
  private boolean isFormatGoodForEncoding(VideoFormat format) {
    boolean boolResult = false;
    String strEncoding = this.comboEncoding.getSelectedItem();
    if (strEncoding != null)
      boolResult = format.getEncoding().equalsIgnoreCase(strEncoding); 
    return boolResult;
  }
  
  private boolean isFormatGoodForVideoSize(VideoFormat format) {
    boolean boolResult = false;
    VideoSize sizeVideo = this.controlSize.getVideoSize();
    Dimension formatVideoSize = format.getSize();
    if (formatVideoSize == null) {
      boolResult = true;
    } else {
      boolResult = sizeVideo.equals(formatVideoSize);
    } 
    return boolResult;
  }
  
  private boolean isFormatGoodForFrameRate(VideoFormat format) {
    boolean boolResult = false;
    if (this.customFrameRates != null)
      return true; 
    String strFrameRate = this.comboFrameRate.getSelectedItem();
    if (strFrameRate.equals(DEFAULT_STRING))
      return true; 
    float fFrameRate2 = format.getFrameRate();
    if (fFrameRate2 == -1.0F)
      return true; 
    if (strFrameRate != null) {
      float fFrameRate1 = Float.valueOf(strFrameRate).floatValue();
      boolResult = (fFrameRate1 == fFrameRate2);
    } 
    return boolResult;
  }
  
  private boolean isFormatSupported(VideoFormat format) {
    boolean boolSupported = false;
    if (format == null)
      return boolSupported; 
    int nCount = this.vectorContSuppFormats.size();
    for (int i = 0; i < nCount && !boolSupported; i++) {
      VideoFormat formatVideo = this.vectorContSuppFormats.elementAt(i);
      if (formatVideo.matches((Format)format))
        boolSupported = true; 
    } 
    return boolSupported;
  }
  
  public void actionPerformed(ActionEvent event) {
    if (event.getActionCommand().equals("Size Changed"))
      updateFieldsFromSize(this.formatOld); 
  }
  
  public void itemStateChanged(ItemEvent event) {
    Object objectSource = event.getSource();
    if (objectSource == this.checkEnableTrack) {
      this.boolEnableTrackSaved = this.checkEnableTrack.getState();
      onEnableTrack(true);
    } else if (objectSource == this.comboEncoding) {
      updateFieldsFromEncoding(this.formatOld);
    } else if (objectSource == this.controlSize) {
      updateFieldsFromSize(this.formatOld);
    } else if (objectSource == this.comboFrameRate) {
      updateFieldsFromRate(this.formatOld);
    } 
  }
  
  private void onEnableTrack(boolean notifyListener) {
    boolean boolEnable = this.checkEnableTrack.getState();
    enableControls((boolEnable && isEnabled()));
    if (notifyListener == true && this.listenerEnableTrack != null) {
      ActionEvent actionEvent;
      if (boolEnable == true) {
        actionEvent = new ActionEvent(this, 1001, "ACTION_VIDEO_TRACK_ENABLED");
      } else {
        actionEvent = new ActionEvent(this, 1001, "ACTION_VIDEO_TRACK_DISABLED");
      } 
      this.listenerEnableTrack.actionPerformed(actionEvent);
    } 
  }
  
  private void enableControls(boolean boolEnable) {
    this.labelEncoding.setEnabled(boolEnable);
    this.comboEncoding.setEnabled(boolEnable);
    this.labelSize.setEnabled(boolEnable);
    this.controlSize.setEnabled(boolEnable);
    this.labelFrameRate.setEnabled(boolEnable);
    this.comboFrameRate.setEnabled(boolEnable);
    this.labelExtra.setEnabled(boolEnable);
    this.comboExtra.setEnabled(boolEnable);
  }
  
  private String getYuvType(int nType) {
    String strType = null;
    if ((nType & 0x2) == 2) {
      strType = JMFI18N.getResource("formatchooser.yuv.4:2:0");
    } else if ((nType & 0x4) == 4) {
      strType = JMFI18N.getResource("formatchooser.yuv.4:2:2");
    } else if ((nType & 0x20) == 32) {
      strType = JMFI18N.getResource("formatchooser.yuv.YUYV");
    } else if ((nType & 0x8) == 8) {
      strType = JMFI18N.getResource("formatchooser.yuv.1:1:1");
    } else if ((nType & 0x1) == 1) {
      strType = JMFI18N.getResource("formatchooser.yuv.4:1:1");
    } else if ((nType & 0x10) == 16) {
      strType = JMFI18N.getResource("formatchooser.yuv.YVU9");
    } else {
      strType = null;
    } 
    return strType;
  }
}
