/*    */ package com.sun.media.ui;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Label;
/*    */ import java.awt.TextField;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ 
/*    */ 
/*    */ public class TextComp
/*    */   extends BasicComp
/*    */   implements ActionListener
/*    */ {
/*    */   String value;
/*    */   int size;
/*    */   boolean mutable;
/*    */   Label compLabel;
/*    */   TextField compText;
/*    */   
/*    */   public TextComp(String label, String initial, int size, boolean mutable) {
/* 21 */     super(label);
/* 22 */     this.value = initial;
/* 23 */     this.size = size;
/* 24 */     this.mutable = mutable;
/*    */     
/* 26 */     setLayout(new BorderLayout());
/* 27 */     Label lab = new Label(label, 0);
/* 28 */     add("West", lab);
/* 29 */     if (!mutable) {
/* 30 */       this.compLabel = new Label(initial, 0);
/* 31 */       add("Center", this.compLabel);
/*    */     } else {
/* 33 */       this.compText = new TextField(initial, size);
/* 34 */       add("Center", this.compText);
/* 35 */       this.compText.addActionListener(this);
/*    */     } 
/*    */   }
/*    */   
/*    */   public float getFloatValue() {
/* 40 */     this.value = getValue();
/*    */     try {
/* 42 */       float retVal = Float.valueOf(this.value).floatValue();
/* 43 */       return retVal;
/*    */     } catch (NumberFormatException nfe) {
/* 45 */       return 0.0F;
/*    */     } 
/*    */   }
/*    */   
/*    */   public int getIntValue() {
/* 50 */     this.value = getValue();
/*    */     try {
/* 52 */       int retVal = Integer.valueOf(this.value).intValue();
/* 53 */       return retVal;
/*    */     } catch (NumberFormatException nfe) {
/* 55 */       return 0;
/*    */     } 
/*    */   }
/*    */   
/*    */   public String getValue() {
/* 60 */     if (this.mutable) {
/* 61 */       return this.compText.getText();
/*    */     }
/* 63 */     return this.compLabel.getText();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(String s) {
/* 68 */     this.value = s;
/* 69 */     if (this.mutable) {
/* 70 */       this.compText.setText(s);
/*    */     } else {
/* 72 */       this.compLabel.setText(s);
/*    */     } 
/* 74 */     repaint();
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent ae) {
/* 78 */     informListener();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\TextComp.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */