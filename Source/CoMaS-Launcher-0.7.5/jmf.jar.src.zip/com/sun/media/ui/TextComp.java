package com.sun.media.ui;

import java.awt.BorderLayout;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TextComp extends BasicComp implements ActionListener {
  String value;
  
  int size;
  
  boolean mutable;
  
  Label compLabel;
  
  TextField compText;
  
  public TextComp(String label, String initial, int size, boolean mutable) {
    super(label);
    this.value = initial;
    this.size = size;
    this.mutable = mutable;
    setLayout(new BorderLayout());
    Label lab = new Label(label, 0);
    add("West", lab);
    if (!mutable) {
      this.compLabel = new Label(initial, 0);
      add("Center", this.compLabel);
    } else {
      this.compText = new TextField(initial, size);
      add("Center", this.compText);
      this.compText.addActionListener(this);
    } 
  }
  
  public float getFloatValue() {
    this.value = getValue();
    try {
      float retVal = Float.valueOf(this.value).floatValue();
      return retVal;
    } catch (NumberFormatException nfe) {
      return 0.0F;
    } 
  }
  
  public int getIntValue() {
    this.value = getValue();
    try {
      int retVal = Integer.valueOf(this.value).intValue();
      return retVal;
    } catch (NumberFormatException nfe) {
      return 0;
    } 
  }
  
  public String getValue() {
    if (this.mutable)
      return this.compText.getText(); 
    return this.compLabel.getText();
  }
  
  public void setValue(String s) {
    this.value = s;
    if (this.mutable) {
      this.compText.setText(s);
    } else {
      this.compLabel.setText(s);
    } 
    repaint();
  }
  
  public void actionPerformed(ActionEvent ae) {
    informListener();
  }
}
