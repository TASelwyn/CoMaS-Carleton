/*     */ package com.sun.media;
/*     */ 
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicOutputConnector
/*     */   extends BasicConnector
/*     */   implements OutputConnector
/*     */ {
/*  17 */   protected InputConnector inputConnector = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean reset = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format connectTo(InputConnector inputConnector, Format useThisFormat) {
/*  27 */     Format format = canConnectTo(inputConnector, useThisFormat);
/*     */ 
/*     */ 
/*     */     
/*  31 */     this.inputConnector = inputConnector;
/*  32 */     inputConnector.setOutputConnector(this);
/*  33 */     int bufferSize = Math.max(getSize(), inputConnector.getSize());
/*     */     
/*  35 */     this.circularBuffer = new CircularBuffer(bufferSize);
/*  36 */     inputConnector.setCircularBuffer(this.circularBuffer);
/*  37 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format canConnectTo(InputConnector inputConnector, Format useThisFormat) {
/*  44 */     if (getProtocol() != inputConnector.getProtocol())
/*  45 */       throw new RuntimeException("protocols do not match:: "); 
/*  46 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputConnector getInputConnector() {
/*  54 */     return this.inputConnector;
/*     */   }
/*     */   
/*     */   public void reset() {
/*  58 */     synchronized (this.circularBuffer) {
/*  59 */       this.reset = true;
/*  60 */       super.reset();
/*  61 */       if (this.inputConnector != null)
/*  62 */         this.inputConnector.reset(); 
/*  63 */       this.circularBuffer.notifyAll();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmptyBufferAvailable() {
/*  71 */     return this.circularBuffer.canWrite();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Buffer getEmptyBuffer() {
/*  80 */     switch (this.protocol) {
/*     */       case 0:
/*  82 */         if (!isEmptyBufferAvailable() && this.reset)
/*  83 */           return null; 
/*  84 */         this.reset = false;
/*  85 */         return this.circularBuffer.getEmptyBuffer();
/*     */       case 1:
/*  87 */         synchronized (this.circularBuffer) {
/*  88 */           this.reset = false;
/*  89 */           while (!this.reset && !isEmptyBufferAvailable()) {
/*     */             try {
/*  91 */               this.circularBuffer.wait();
/*  92 */             } catch (Exception e) {}
/*     */           } 
/*  94 */           if (this.reset)
/*  95 */             return null; 
/*  96 */           Buffer buffer = this.circularBuffer.getEmptyBuffer();
/*  97 */           this.circularBuffer.notifyAll();
/*  98 */           return buffer;
/*     */         } 
/*     */     } 
/*     */     
/* 102 */     throw new RuntimeException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeReport() {
/* 113 */     switch (this.protocol) {
/*     */       case 0:
/* 115 */         synchronized (this.circularBuffer) {
/* 116 */           if (this.reset)
/*     */             return; 
/* 118 */           this.circularBuffer.writeReport();
/*     */         } 
/* 120 */         getInputConnector().getModule().connectorPushed(getInputConnector());
/*     */         return;
/*     */       case 1:
/* 123 */         synchronized (this.circularBuffer) {
/* 124 */           if (this.reset)
/*     */             return; 
/* 126 */           this.circularBuffer.writeReport();
/* 127 */           this.circularBuffer.notifyAll();
/*     */           return;
/*     */         } 
/*     */     } 
/* 131 */     throw new RuntimeException();
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\BasicOutputConnector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */