/*     */ package com.sun.media;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Vector;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.PlugIn;
/*     */ import javax.media.PlugInManager;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BasicPlugIn
/*     */   implements PlugIn
/*     */ {
/*     */   private static final boolean DEBUG = false;
/*  19 */   protected Object[] controls = (Object[])new javax.media.Control[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean jdkInit = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Method forName3ArgsM;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Method getSystemClassLoaderM;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ClassLoader systemClassLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Method getContextClassLoaderM;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void error() {
/*  52 */     throw new RuntimeException(getClass().getName() + " PlugIn error");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getControls() {
/*  59 */     return this.controls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getControl(String controlType) {
/*     */     try {
/*  67 */       Class cls = Class.forName(controlType);
/*  68 */       Object[] cs = getControls();
/*  69 */       for (int i = 0; i < cs.length; i++) {
/*  70 */         if (cls.isInstance(cs[i]))
/*  71 */           return cs[i]; 
/*     */       } 
/*  73 */       return null;
/*     */     } catch (Exception e) {
/*     */       
/*  76 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Format matches(Format in, Format[] outs) {
/*  84 */     for (int i = 0; i < outs.length; i++) {
/*  85 */       if (in.matches(outs[i])) {
/*  86 */         return outs[i];
/*     */       }
/*     */     } 
/*  89 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected byte[] validateByteArraySize(Buffer buffer, int newSize) {
/*     */     byte[] arrayOfByte;
/* 100 */     Object objectArray = buffer.getData();
/*     */ 
/*     */     
/* 103 */     if (objectArray instanceof byte[]) {
/* 104 */       arrayOfByte = (byte[])objectArray;
/* 105 */       if (arrayOfByte.length >= newSize) {
/* 106 */         return arrayOfByte;
/*     */       }
/*     */       
/* 109 */       byte[] tempArray = new byte[newSize];
/* 110 */       System.arraycopy(arrayOfByte, 0, tempArray, 0, arrayOfByte.length);
/* 111 */       arrayOfByte = tempArray;
/*     */     } else {
/* 113 */       arrayOfByte = new byte[newSize];
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     buffer.setData(arrayOfByte);
/* 120 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected short[] validateShortArraySize(Buffer buffer, int newSize) {
/*     */     short[] arrayOfShort;
/* 128 */     Object objectArray = buffer.getData();
/*     */ 
/*     */     
/* 131 */     if (objectArray instanceof short[]) {
/* 132 */       arrayOfShort = (short[])objectArray;
/* 133 */       if (arrayOfShort.length >= newSize) {
/* 134 */         return arrayOfShort;
/*     */       }
/*     */       
/* 137 */       short[] tempArray = new short[newSize];
/* 138 */       System.arraycopy(arrayOfShort, 0, tempArray, 0, arrayOfShort.length);
/* 139 */       arrayOfShort = tempArray;
/*     */     } else {
/* 141 */       arrayOfShort = new short[newSize];
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     buffer.setData(arrayOfShort);
/* 148 */     return arrayOfShort;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int[] validateIntArraySize(Buffer buffer, int newSize) {
/*     */     int[] arrayOfInt;
/* 155 */     Object objectArray = buffer.getData();
/*     */ 
/*     */     
/* 158 */     if (objectArray instanceof int[]) {
/* 159 */       arrayOfInt = (int[])objectArray;
/* 160 */       if (arrayOfInt.length >= newSize) {
/* 161 */         return arrayOfInt;
/*     */       }
/*     */       
/* 164 */       int[] tempArray = new int[newSize];
/* 165 */       System.arraycopy(arrayOfInt, 0, tempArray, 0, arrayOfInt.length);
/* 166 */       arrayOfInt = tempArray;
/*     */     } else {
/* 168 */       arrayOfInt = new int[newSize];
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 174 */     buffer.setData(arrayOfInt);
/* 175 */     return arrayOfInt;
/*     */   }
/*     */   
/*     */   protected final long getNativeData(Object data) {
/* 179 */     if (data instanceof NBA) {
/* 180 */       return ((NBA)data).getNativeData();
/*     */     }
/* 182 */     return 0L;
/*     */   }
/*     */   
/*     */   protected Object getInputData(Buffer inBuffer) {
/* 186 */     Object inData = null;
/* 187 */     if (inBuffer instanceof ExtBuffer) {
/* 188 */       ((ExtBuffer)inBuffer).setNativePreferred(true);
/* 189 */       inData = ((ExtBuffer)inBuffer).getNativeData();
/*     */     } 
/* 191 */     if (inData == null)
/* 192 */       inData = inBuffer.getData(); 
/* 193 */     return inData;
/*     */   }
/*     */   
/*     */   protected Object getOutputData(Buffer buffer) {
/* 197 */     Object data = null;
/* 198 */     if (buffer instanceof ExtBuffer) {
/* 199 */       data = ((ExtBuffer)buffer).getNativeData();
/*     */     }
/* 201 */     if (data == null)
/* 202 */       data = buffer.getData(); 
/* 203 */     return data;
/*     */   }
/*     */   
/*     */   protected Object validateData(Buffer buffer, int length, boolean allowNative) {
/* 207 */     Format format = buffer.getFormat();
/* 208 */     Class dataType = format.getDataType();
/*     */     
/* 210 */     if (length < 1 && format != null && 
/* 211 */       format instanceof VideoFormat) {
/* 212 */       length = ((VideoFormat)format).getMaxDataLength();
/*     */     }
/*     */     
/* 215 */     if (allowNative && buffer instanceof ExtBuffer && ((ExtBuffer)buffer).isNativePreferred()) {
/*     */       
/* 217 */       ExtBuffer extb = (ExtBuffer)buffer;
/* 218 */       if (extb.getNativeData() == null || extb.getNativeData().getSize() < length)
/*     */       {
/* 220 */         extb.setNativeData(new NBA(format.getDataType(), length)); } 
/* 221 */       return extb.getNativeData();
/*     */     } 
/* 223 */     if (dataType == Format.byteArray)
/* 224 */       return validateByteArraySize(buffer, length); 
/* 225 */     if (dataType == Format.shortArray)
/* 226 */       return validateShortArraySize(buffer, length); 
/* 227 */     if (dataType == Format.intArray) {
/* 228 */       return validateIntArraySize(buffer, length);
/*     */     }
/* 230 */     System.err.println("Error in validateData");
/* 231 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean checkIfJDK12() {
/* 237 */     if (jdkInit)
/* 238 */       return (forName3ArgsM != null); 
/* 239 */     jdkInit = true;
/*     */     try {
/* 241 */       forName3ArgsM = Class.class.getMethod("forName", new Class[] { String.class, boolean.class, ClassLoader.class });
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 246 */       getSystemClassLoaderM = ClassLoader.class.getMethod("getSystemClassLoader", null);
/*     */ 
/*     */       
/* 249 */       systemClassLoader = (ClassLoader)getSystemClassLoaderM.invoke(ClassLoader.class, null);
/*     */       
/* 251 */       getContextClassLoaderM = Thread.class.getMethod("getContextClassLoader", null);
/*     */       
/* 253 */       return true;
/*     */     } catch (Throwable t) {
/* 255 */       forName3ArgsM = null;
/* 256 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class getClassForName(String className) throws ClassNotFoundException {
/*     */     try {
/* 271 */       return Class.forName(className);
/*     */     } catch (Exception e) {
/* 273 */       if (!checkIfJDK12()) {
/* 274 */         throw new ClassNotFoundException(e.getMessage());
/*     */       }
/*     */     } catch (Error e) {
/* 277 */       if (!checkIfJDK12()) {
/* 278 */         throw e;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 288 */       return (Class)forName3ArgsM.invoke(Class.class, new Object[] { className, new Boolean(true), systemClassLoader });
/*     */     }
/* 290 */     catch (Throwable e) {
/*     */ 
/*     */       
/*     */       try {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 300 */         ClassLoader contextClassLoader = (ClassLoader)getContextClassLoaderM.invoke(Thread.currentThread(), null);
/*     */         
/* 302 */         return (Class)forName3ArgsM.invoke(Class.class, new Object[] { className, new Boolean(true), contextClassLoader });
/*     */       } catch (Exception exception) {
/*     */         
/* 305 */         throw new ClassNotFoundException(exception.getMessage());
/*     */       } catch (Error error) {
/* 307 */         throw error;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean plugInExists(String name, int type) {
/* 315 */     Vector cnames = PlugInManager.getPlugInList(null, null, type);
/* 316 */     for (int i = 0; i < cnames.size(); i++) {
/* 317 */       if (name.equals(cnames.elementAt(i)))
/* 318 */         return true; 
/*     */     } 
/* 320 */     return false;
/*     */   }
/*     */   
/*     */   public abstract void reset();
/*     */   
/*     */   public abstract void close();
/*     */   
/*     */   public abstract void open() throws ResourceUnavailableException;
/*     */   
/*     */   public abstract String getName();
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\BasicPlugIn.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */