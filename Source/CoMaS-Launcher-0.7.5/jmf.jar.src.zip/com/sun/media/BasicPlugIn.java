package com.sun.media;

import java.lang.reflect.Method;
import java.util.Vector;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.PlugIn;
import javax.media.PlugInManager;
import javax.media.ResourceUnavailableException;
import javax.media.format.VideoFormat;

public abstract class BasicPlugIn implements PlugIn {
  private static final boolean DEBUG = false;
  
  protected Object[] controls = (Object[])new javax.media.Control[0];
  
  private static boolean jdkInit = false;
  
  private static Method forName3ArgsM;
  
  private static Method getSystemClassLoaderM;
  
  private static ClassLoader systemClassLoader;
  
  private static Method getContextClassLoaderM;
  
  protected void error() {
    throw new RuntimeException(getClass().getName() + " PlugIn error");
  }
  
  public Object[] getControls() {
    return this.controls;
  }
  
  public Object getControl(String controlType) {
    try {
      Class cls = Class.forName(controlType);
      Object[] cs = getControls();
      for (int i = 0; i < cs.length; i++) {
        if (cls.isInstance(cs[i]))
          return cs[i]; 
      } 
      return null;
    } catch (Exception e) {
      return null;
    } 
  }
  
  public static Format matches(Format in, Format[] outs) {
    for (int i = 0; i < outs.length; i++) {
      if (in.matches(outs[i]))
        return outs[i]; 
    } 
    return null;
  }
  
  protected byte[] validateByteArraySize(Buffer buffer, int newSize) {
    byte[] arrayOfByte;
    Object objectArray = buffer.getData();
    if (objectArray instanceof byte[]) {
      arrayOfByte = (byte[])objectArray;
      if (arrayOfByte.length >= newSize)
        return arrayOfByte; 
      byte[] tempArray = new byte[newSize];
      System.arraycopy(arrayOfByte, 0, tempArray, 0, arrayOfByte.length);
      arrayOfByte = tempArray;
    } else {
      arrayOfByte = new byte[newSize];
    } 
    buffer.setData(arrayOfByte);
    return arrayOfByte;
  }
  
  protected short[] validateShortArraySize(Buffer buffer, int newSize) {
    short[] arrayOfShort;
    Object objectArray = buffer.getData();
    if (objectArray instanceof short[]) {
      arrayOfShort = (short[])objectArray;
      if (arrayOfShort.length >= newSize)
        return arrayOfShort; 
      short[] tempArray = new short[newSize];
      System.arraycopy(arrayOfShort, 0, tempArray, 0, arrayOfShort.length);
      arrayOfShort = tempArray;
    } else {
      arrayOfShort = new short[newSize];
    } 
    buffer.setData(arrayOfShort);
    return arrayOfShort;
  }
  
  protected int[] validateIntArraySize(Buffer buffer, int newSize) {
    int[] arrayOfInt;
    Object objectArray = buffer.getData();
    if (objectArray instanceof int[]) {
      arrayOfInt = (int[])objectArray;
      if (arrayOfInt.length >= newSize)
        return arrayOfInt; 
      int[] tempArray = new int[newSize];
      System.arraycopy(arrayOfInt, 0, tempArray, 0, arrayOfInt.length);
      arrayOfInt = tempArray;
    } else {
      arrayOfInt = new int[newSize];
    } 
    buffer.setData(arrayOfInt);
    return arrayOfInt;
  }
  
  protected final long getNativeData(Object data) {
    if (data instanceof NBA)
      return ((NBA)data).getNativeData(); 
    return 0L;
  }
  
  protected Object getInputData(Buffer inBuffer) {
    Object inData = null;
    if (inBuffer instanceof ExtBuffer) {
      ((ExtBuffer)inBuffer).setNativePreferred(true);
      inData = ((ExtBuffer)inBuffer).getNativeData();
    } 
    if (inData == null)
      inData = inBuffer.getData(); 
    return inData;
  }
  
  protected Object getOutputData(Buffer buffer) {
    Object data = null;
    if (buffer instanceof ExtBuffer)
      data = ((ExtBuffer)buffer).getNativeData(); 
    if (data == null)
      data = buffer.getData(); 
    return data;
  }
  
  protected Object validateData(Buffer buffer, int length, boolean allowNative) {
    Format format = buffer.getFormat();
    Class dataType = format.getDataType();
    if (length < 1 && format != null && 
      format instanceof VideoFormat)
      length = ((VideoFormat)format).getMaxDataLength(); 
    if (allowNative && buffer instanceof ExtBuffer && ((ExtBuffer)buffer).isNativePreferred()) {
      ExtBuffer extb = (ExtBuffer)buffer;
      if (extb.getNativeData() == null || extb.getNativeData().getSize() < length)
        extb.setNativeData(new NBA(format.getDataType(), length)); 
      return extb.getNativeData();
    } 
    if (dataType == Format.byteArray)
      return validateByteArraySize(buffer, length); 
    if (dataType == Format.shortArray)
      return validateShortArraySize(buffer, length); 
    if (dataType == Format.intArray)
      return validateIntArraySize(buffer, length); 
    System.err.println("Error in validateData");
    return null;
  }
  
  private static boolean checkIfJDK12() {
    if (jdkInit)
      return (forName3ArgsM != null); 
    jdkInit = true;
    try {
      forName3ArgsM = Class.class.getMethod("forName", new Class[] { String.class, boolean.class, ClassLoader.class });
      getSystemClassLoaderM = ClassLoader.class.getMethod("getSystemClassLoader", null);
      systemClassLoader = (ClassLoader)getSystemClassLoaderM.invoke(ClassLoader.class, null);
      getContextClassLoaderM = Thread.class.getMethod("getContextClassLoader", null);
      return true;
    } catch (Throwable t) {
      forName3ArgsM = null;
      return false;
    } 
  }
  
  public static Class getClassForName(String className) throws ClassNotFoundException {
    try {
      return Class.forName(className);
    } catch (Exception e) {
      if (!checkIfJDK12())
        throw new ClassNotFoundException(e.getMessage()); 
    } catch (Error e) {
      if (!checkIfJDK12())
        throw e; 
    } 
    try {
      return (Class)forName3ArgsM.invoke(Class.class, new Object[] { className, new Boolean(true), systemClassLoader });
    } catch (Throwable e) {
      try {
        ClassLoader contextClassLoader = (ClassLoader)getContextClassLoaderM.invoke(Thread.currentThread(), null);
        return (Class)forName3ArgsM.invoke(Class.class, new Object[] { className, new Boolean(true), contextClassLoader });
      } catch (Exception exception) {
        throw new ClassNotFoundException(exception.getMessage());
      } catch (Error error) {
        throw error;
      } 
    } 
  }
  
  public static boolean plugInExists(String name, int type) {
    Vector cnames = PlugInManager.getPlugInList(null, null, type);
    for (int i = 0; i < cnames.size(); i++) {
      if (name.equals(cnames.elementAt(i)))
        return true; 
    } 
    return false;
  }
  
  public abstract void reset();
  
  public abstract void close();
  
  public abstract void open() throws ResourceUnavailableException;
  
  public abstract String getName();
}
