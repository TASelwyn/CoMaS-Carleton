package com.sun.media.rtsp;

public interface RtspAppListener {
  void streamsReceivedEvent();
  
  void postStatusMessage(int paramInt, String paramString);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\RtspAppListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */