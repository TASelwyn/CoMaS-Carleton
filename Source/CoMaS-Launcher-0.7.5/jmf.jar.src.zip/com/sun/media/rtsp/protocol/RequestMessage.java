/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RequestMessage
/*    */ {
/*    */   private byte[] data;
/*    */   private Request request;
/*    */   
/*    */   public RequestMessage() {}
/*    */   
/*    */   public RequestMessage(byte[] data) {
/* 21 */     this.data = data;
/*    */     
/* 23 */     parseRequest();
/*    */   }
/*    */   
/*    */   private void parseRequest() {
/* 27 */     this.request = new Request(new ByteArrayInputStream(this.data));
/*    */   }
/*    */   
/*    */   public Request getRequest() {
/* 31 */     return this.request;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\protocol\RequestMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */