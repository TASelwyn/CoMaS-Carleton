package com.sun.media.rtsp.protocol;

import java.io.ByteArrayInputStream;

public class RequestMessage {
  private byte[] data;
  
  private Request request;
  
  public RequestMessage() {}
  
  public RequestMessage(byte[] data) {
    this.data = data;
    parseRequest();
  }
  
  private void parseRequest() {
    this.request = new Request(new ByteArrayInputStream(this.data));
  }
  
  public Request getRequest() {
    return this.request;
  }
}
