package com.sun.media.rtsp.protocol;

public class RangeHeader {
  private long startPos;
  
  public RangeHeader(String str) {
    int start = str.indexOf('=') + 1;
    int end = str.indexOf('-');
    String startPosStr = str.substring(start, end);
    this.startPos = (new Long(startPosStr)).longValue();
  }
  
  public long getStartPos() {
    return this.startPos;
  }
}
