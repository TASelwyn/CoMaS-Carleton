package com.sun.media.rtsp.protocol;

public class CSeqHeader {
  private String sequence_number;
  
  public CSeqHeader(String number) {
    this.sequence_number = number;
  }
  
  public String getSequenceNumber() {
    return this.sequence_number;
  }
}
