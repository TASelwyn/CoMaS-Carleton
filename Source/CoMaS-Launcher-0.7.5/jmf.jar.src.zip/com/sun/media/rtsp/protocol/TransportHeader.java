/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransportHeader
/*    */ {
/*    */   private String transportProtocol;
/*    */   private String profile;
/*    */   private String lowerTransport;
/*    */   private int server_data_port;
/*    */   private int server_control_port;
/*    */   
/*    */   public TransportHeader(String str) {
/* 22 */     int end = str.indexOf('/');
/*    */     
/* 24 */     this.transportProtocol = str.substring(0, end);
/*    */ 
/*    */ 
/*    */     
/* 28 */     int start = str.indexOf("client_port");
/*    */     
/* 30 */     if (start > 0);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 35 */     start = str.indexOf("server_port");
/*    */     
/* 37 */     if (start > 0) {
/*    */       String str1;
/*    */       
/* 40 */       start = str.indexOf("=", start) + 1;
/*    */       
/* 42 */       end = str.indexOf("-", start);
/*    */       
/* 44 */       String data_str = str.substring(start, end);
/*    */       
/* 46 */       this.server_data_port = (new Integer(data_str)).intValue();
/*    */ 
/*    */       
/* 49 */       start = end + 1;
/*    */       
/* 51 */       end = str.indexOf(";", start);
/*    */ 
/*    */ 
/*    */       
/* 55 */       if (end > 0) {
/*    */         
/* 57 */         str1 = str.substring(start, end);
/*    */       }
/*    */       else {
/*    */         
/* 61 */         str1 = str.substring(start);
/*    */       } 
/*    */       
/* 64 */       this.server_control_port = (new Integer(str1)).intValue();
/*    */     } 
/*    */   }
/*    */   
/*    */   public String getTransportProtocol() {
/* 69 */     return this.transportProtocol;
/*    */   }
/*    */   
/*    */   public int getServerDataPort() {
/* 73 */     return this.server_data_port;
/*    */   }
/*    */   
/*    */   public int getServerControlPort() {
/* 77 */     return this.server_control_port;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\protocol\TransportHeader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */