/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ import com.sun.media.sdp.SdpParser;
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Response
/*    */   extends Parser
/*    */ {
/*    */   public StatusLine statusLine;
/*    */   public Vector headers;
/*    */   public SdpParser sdp;
/*    */   
/*    */   public Response(ByteArrayInputStream bin) {
/* 21 */     String line = getLine(bin);
/*    */     
/* 23 */     this.statusLine = new StatusLine(line);
/*    */     
/* 25 */     this.headers = new Vector();
/*    */     
/* 27 */     line = getLine(bin);
/*    */     
/* 29 */     int contentLength = 0;
/*    */     
/* 31 */     while (line.length() > 0) {
/* 32 */       if (line.length() > 0) {
/* 33 */         Header header = new Header(line);
/*    */         
/* 35 */         if (header.type == 10) {
/* 36 */           contentLength = header.contentLength;
/*    */         }
/*    */         
/* 39 */         this.headers.addElement(header);
/*    */         
/* 41 */         line = getLine(bin);
/*    */       } 
/*    */     } 
/*    */     
/* 45 */     if (contentLength > 0) {
/* 46 */       byte[] data = new byte[bin.available()];
/*    */       
/*    */       try {
/* 49 */         bin.read(data);
/*    */         
/* 51 */         this.sdp = new SdpParser(data);
/*    */       } catch (IOException e) {
/* 53 */         e.printStackTrace();
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public Header getHeader(int type) {
/* 59 */     Header header = null;
/*    */     
/* 61 */     for (int i = 0; i < this.headers.size(); i++) {
/* 62 */       Header tmpHeader = this.headers.elementAt(i);
/*    */       
/* 64 */       if (tmpHeader.type == type) {
/* 65 */         header = tmpHeader;
/*    */         
/*    */         break;
/*    */       } 
/*    */     } 
/*    */     
/* 71 */     return header;
/*    */   }
/*    */   
/*    */   public StatusLine getStatusLine() {
/* 75 */     return this.statusLine;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\protocol\Response.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */