package com.sun.media.rtsp.protocol;

public class StatusCode {
  public static final int CONTINUE = 100;
  
  public static final int OK = 200;
  
  public static final int CREATED = 201;
  
  public static final int LOW_ON_STORAGE_SPACE = 250;
  
  public static final int MULTIPLE_CHOICES = 300;
  
  public static final int MOVED_PERMANENTLY = 301;
  
  public static final int MOVED_TEMPORARILY = 302;
  
  public static final int SEE_OTHER = 303;
  
  public static final int NOT_MODIFIED = 304;
  
  public static final int USE_PROXY = 305;
  
  public static final int BAD_REQUEST = 400;
  
  public static final int UNAUTHORIZED = 401;
  
  public static final int PAYMENT_REQUIRED = 402;
  
  public static final int FORBIDDEN = 403;
  
  public static final int NOT_FOUND = 404;
  
  public static final int METHOD_NOT_ALLOWED = 405;
  
  public static final int NOT_ACCEPTABLE = 406;
  
  public static final int PROXY_AUTHENTICATION_REQUIRED = 407;
  
  public static final int REQUEST_TIMED_OUT = 408;
  
  public static final int GONE = 410;
  
  public static final int LENGTH_REQUIRED = 411;
  
  public static final int PRECONDITION_FAILED = 412;
  
  public static final int REQUEST_ENTITY_TOO_LARGE = 413;
  
  public static final int REQUEST_URI_TOO_LARGE = 414;
  
  public static final int UNSUPPORTED_MEDIA_TYPE = 415;
  
  public static final int PARAMETER_NOT_UNDERSTOOD = 451;
  
  public static final int CONFERENCE_NOT_FOUND = 452;
  
  public static final int NOT_ENOUGH_BANDWIDTH = 453;
  
  public static final int SESSION_NOT_FOUND = 454;
  
  public static final int METHOD_NOT_VALID_IN_THIS_STATE = 455;
  
  public static final int HEADER_FIELD_NOT_VALID = 456;
  
  public static final int INVALID_RANGE = 457;
  
  public static final int PARAMETER_IS_READ_ONLY = 458;
  
  public static final int AGGREGATE_OPERATION_NOT_ALLOWED = 459;
  
  public static final int ONLY_AGGREGATE_OPERATION_ALLOWED = 460;
  
  public static final int UNSUPPORTED_TRANSPORT = 461;
  
  public static final int DESTINATION_UNREACHABLE = 462;
  
  public static final int INTERNAL_SERVER_ERROR = 500;
  
  public static final int NOT_IMPLEMENTED = 501;
  
  public static final int BAD_GATEWAY = 502;
  
  public static final int SERVICE_UNAVAILABLE = 503;
  
  public static final int GATEWAY_TIME_OUT = 504;
  
  public static final int RTSP_VERSION_NOT_SUPPORTED = 505;
  
  public static final int OPTION_NOT_SUPPORTED = 551;
  
  private int code;
  
  public StatusCode(int code) {
    this.code = code;
  }
  
  public static String getStatusText(int code) {
    switch (code) {
      case 100:
        text = "Continue";
        return text;
      case 200:
        text = "Ok";
        return text;
      case 201:
        text = "Created";
        return text;
      case 250:
        text = "Low on storage space";
        return text;
      case 300:
        text = "Multiple choices";
        return text;
      case 301:
        text = "Moved permanently";
        return text;
      case 302:
        text = "Moved temporarily";
        return text;
      case 303:
        text = "See other";
        return text;
      case 304:
        text = "Not modified";
        return text;
      case 305:
        text = "Use proxy";
        return text;
      case 400:
        text = "Bad request";
        return text;
      case 401:
        text = "Unauthorized";
        return text;
      case 402:
        text = "Payment required";
        return text;
      case 403:
        text = "Forbidden";
        return text;
      case 404:
        text = "Not found";
        return text;
      case 405:
        text = "Method not allowed";
        return text;
      case 406:
        text = "Not acceptable";
        return text;
      case 407:
        text = "Proxy authentication required";
        return text;
      case 408:
        text = "Request timed out";
        return text;
      case 410:
        text = "Gone";
        return text;
      case 411:
        text = "Length required";
        return text;
      case 412:
        text = "Precondition failed";
        return text;
      case 413:
        text = "Request entity too large";
        return text;
      case 414:
        text = "Request URI too large";
        return text;
      case 415:
        text = "Unsupported media type";
        return text;
      case 451:
        text = "Parameter not understood";
        return text;
      case 452:
        text = "Conference not found";
        return text;
      case 453:
        text = "Not enough bandwidth";
        return text;
      case 454:
        text = "Session not found";
        return text;
      case 455:
        text = "Method not valid in this state";
        return text;
      case 456:
        text = "Header field not valid";
        return text;
      case 457:
        text = "Invalid range";
        return text;
      case 458:
        text = "Parameter is read only";
        return text;
      case 459:
        text = "Aggregate operation not allowed";
        return text;
      case 460:
        text = "Only aggregate operation allowed";
        return text;
      case 461:
        text = "Unsupported transport";
        return text;
      case 462:
        text = "Destination unreachable";
        return text;
      case 500:
        text = "Internal server error";
        return text;
      case 501:
        text = "Not implemented";
        return text;
      case 502:
        text = "Bad gateway";
        return text;
      case 503:
        text = "Service unavailable";
        return text;
      case 504:
        text = "Gateway time-out";
        return text;
      case 505:
        text = "RTSP version not supported";
        return text;
      case 551:
        text = "Option not supported";
        return text;
    } 
    String text = "Unknown status code: " + code;
    return text;
  }
}
