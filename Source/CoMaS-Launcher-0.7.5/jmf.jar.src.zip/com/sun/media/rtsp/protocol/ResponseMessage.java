/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResponseMessage
/*    */ {
/*    */   private byte[] data;
/*    */   private Response response;
/*    */   
/*    */   public ResponseMessage(byte[] data) {
/* 17 */     this.data = data;
/*    */     
/* 19 */     parseResponse();
/*    */   }
/*    */   
/*    */   private void parseResponse() {
/* 23 */     this.response = new Response(new ByteArrayInputStream(this.data));
/*    */   }
/*    */   
/*    */   public Response getResponse() {
/* 27 */     return this.response;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\protocol\ResponseMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */