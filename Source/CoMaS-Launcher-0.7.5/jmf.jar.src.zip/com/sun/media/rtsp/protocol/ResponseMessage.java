package com.sun.media.rtsp.protocol;

import java.io.ByteArrayInputStream;

public class ResponseMessage {
  private byte[] data;
  
  private Response response;
  
  public ResponseMessage(byte[] data) {
    this.data = data;
    parseResponse();
  }
  
  private void parseResponse() {
    this.response = new Response(new ByteArrayInputStream(this.data));
  }
  
  public Response getResponse() {
    return this.response;
  }
}
