package com.sun.media.rtsp.protocol;

import java.io.ByteArrayInputStream;

public class RequestLine extends Parser {
  private String url;
  
  private String version;
  
  public RequestLine(String input) {
    ByteArrayInputStream bin = new ByteArrayInputStream(input.getBytes());
    String method = getToken(bin);
    Debug.println("method  : " + method);
    this.url = getToken(bin);
    Debug.println("url     : " + this.url);
    this.version = getToken(bin);
    Debug.println("version : " + this.version);
  }
  
  public String getUrl() {
    return this.url;
  }
  
  public String getVersion() {
    return this.version;
  }
}
