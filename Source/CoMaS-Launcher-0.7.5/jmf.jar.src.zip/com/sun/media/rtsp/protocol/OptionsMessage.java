/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OptionsMessage
/*    */   extends RequestMessage
/*    */ {
/*    */   public OptionsMessage(byte[] data) {
/* 14 */     super(data);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\protocol\OptionsMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */