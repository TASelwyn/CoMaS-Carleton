package com.sun.media.rtsp.protocol;

public class OptionsMessage extends RequestMessage {
  public OptionsMessage(byte[] data) {
    super(data);
  }
}
