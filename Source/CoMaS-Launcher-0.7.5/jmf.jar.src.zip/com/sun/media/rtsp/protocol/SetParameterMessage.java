/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SetParameterMessage
/*    */   extends RequestMessage
/*    */ {
/*    */   public SetParameterMessage(byte[] data) {
/* 14 */     super(data);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\protocol\SetParameterMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */