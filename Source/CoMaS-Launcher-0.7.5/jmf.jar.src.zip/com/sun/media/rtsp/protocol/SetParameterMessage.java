package com.sun.media.rtsp.protocol;

public class SetParameterMessage extends RequestMessage {
  public SetParameterMessage(byte[] data) {
    super(data);
  }
}
