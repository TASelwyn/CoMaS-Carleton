package com.sun.media.rtsp;

public abstract class RtspPort {
  public static final int RTSP_DEFAULT_PORT = 1554;
  
  public static int port = 1554;
  
  public static void setPort(int current_port) {
    port = current_port;
  }
  
  public static int getPort() {
    return port;
  }
}
