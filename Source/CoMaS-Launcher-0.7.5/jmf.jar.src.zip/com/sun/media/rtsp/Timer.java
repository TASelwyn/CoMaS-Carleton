/*    */ package com.sun.media.rtsp;
/*    */ 
/*    */ import java.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Timer
/*    */   extends Thread
/*    */   implements Runnable
/*    */ {
/*    */   private Vector listeners;
/*    */   private long duration;
/*    */   private boolean stopped;
/*    */   
/*    */   public Timer(TimerListener listener, long duration) {
/* 25 */     this.listeners = new Vector();
/*    */     
/* 27 */     this.duration = duration / 1000000L;
/*    */     
/* 29 */     addListener(listener);
/*    */     
/* 31 */     this.stopped = false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void reset() {}
/*    */ 
/*    */   
/*    */   public void stopTimer() {
/* 40 */     this.stopped = true;
/*    */     
/* 42 */     synchronized (this) {
/* 43 */       notify();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
/* 50 */     synchronized (this) {
/*    */       try {
/* 52 */         wait(this.duration);
/*    */       } catch (Exception e) {
/* 54 */         e.printStackTrace();
/*    */       } 
/*    */     } 
/*    */     
/* 58 */     if (!this.stopped) {
/* 59 */       for (int i = 0; i < this.listeners.size(); i++) {
/* 60 */         TimerListener listener = this.listeners.elementAt(i);
/*    */         
/* 62 */         listener.timerExpired();
/*    */       } 
/*    */     }
/*    */   }
/*    */   
/*    */   public void addListener(TimerListener listener) {
/* 68 */     this.listeners.addElement(listener);
/*    */   }
/*    */   
/*    */   public void removeListener(TimerListener listener) {
/* 72 */     this.listeners.removeElement(listener);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\Timer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */