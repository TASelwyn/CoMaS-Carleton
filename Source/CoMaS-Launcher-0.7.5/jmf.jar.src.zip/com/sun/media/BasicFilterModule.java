/*     */ package com.sun.media;
/*     */ 
/*     */ import java.awt.Frame;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Codec;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.control.FrameProcessingControl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicFilterModule
/*     */   extends BasicModule
/*     */ {
/*     */   protected Codec codec;
/*     */   protected InputConnector ic;
/*     */   protected OutputConnector oc;
/*  27 */   protected FrameProcessingControl frameControl = null;
/*  28 */   protected float curFramesBehind = 0.0F;
/*  29 */   protected float prevFramesBehind = 0.0F;
/*     */   
/*     */   protected Frame controlFrame;
/*     */   
/*     */   protected final boolean VERBOSE_CONTROL = false;
/*     */   
/*     */   protected Buffer storedInputBuffer;
/*     */   
/*     */   protected Buffer storedOutputBuffer;
/*     */   
/*     */   protected boolean readPendingFlag;
/*     */   
/*     */   protected boolean writePendingFlag;
/*     */   private boolean failed;
/*     */   private boolean markerSet;
/*     */   private Object lastHdr;
/*     */   
/*     */   public boolean doRealize() {
/*  47 */     if (this.codec != null) {
/*     */       try {
/*  49 */         this.codec.open();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */       catch (ResourceUnavailableException rue) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  66 */         return false;
/*     */       } 
/*     */     }
/*     */     
/*  70 */     return true;
/*     */   }
/*     */   
/*     */   public boolean doPrefetch() {
/*  74 */     return super.doPrefetch();
/*     */   }
/*     */   
/*     */   public void doClose() {
/*  78 */     if (this.codec != null) {
/*  79 */       this.codec.close();
/*     */     }
/*  81 */     if (this.controlFrame != null) {
/*  82 */       this.controlFrame.dispose();
/*  83 */       this.controlFrame = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFormat(Connector c, Format f) {
/*  92 */     if (c == this.ic) {
/*     */       
/*  94 */       if (this.codec != null)
/*  95 */         this.codec.setInputFormat(f); 
/*  96 */     } else if (c == this.oc && 
/*  97 */       this.codec != null) {
/*  98 */       this.codec.setOutputFormat(f);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setCodec(String codec) {
/* 108 */     return true;
/*     */   }
/*     */   
/*     */   public boolean setCodec(Codec codec) {
/* 112 */     this.codec = codec;
/* 113 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Codec getCodec() {
/* 121 */     return this.codec;
/*     */   }
/*     */   
/*     */   public boolean isThreaded() {
/* 125 */     if (getProtocol() == 1)
/* 126 */       return true; 
/* 127 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getControls() {
/* 132 */     return this.codec.getControls();
/*     */   }
/*     */   
/*     */   public Object getControl(String s) {
/* 136 */     return this.codec.getControl(s);
/*     */   }
/*     */   
/*     */   protected void setFramesBehind(float framesBehind) {
/* 140 */     this.curFramesBehind = framesBehind;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean reinitCodec(Format input) {
/* 150 */     if (this.codec != null) {
/* 151 */       if (this.codec.setInputFormat(input) != null)
/*     */       {
/* 153 */         return true;
/*     */       }
/*     */       
/* 156 */       this.codec.close();
/* 157 */       this.codec = null;
/*     */     } 
/*     */     
/*     */     Codec c;
/*     */     
/* 162 */     if ((c = SimpleGraphBuilder.findCodec(input, null, null, null)) == null) {
/* 163 */       return false;
/*     */     }
/* 165 */     setCodec(c);
/* 166 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public BasicFilterModule(Codec c) {
/* 171 */     this.readPendingFlag = false;
/* 172 */     this.writePendingFlag = false;
/* 173 */     this.failed = false;
/* 174 */     this.markerSet = false;
/*     */     
/* 176 */     this.lastHdr = null; this.ic = new BasicInputConnector();
/*     */     registerInputConnector("input", this.ic);
/*     */     this.oc = new BasicOutputConnector();
/*     */     registerOutputConnector("output", this.oc);
/*     */     setCodec(c);
/*     */     this.protocol = 0;
/*     */     Object control = c.getControl("javax.media.control.FrameProcessingControl");
/*     */     if (control instanceof FrameProcessingControl)
/*     */       this.frameControl = (FrameProcessingControl)control;  } public void process() { do {
/*     */       Buffer buffer1, buffer2;
/* 186 */       if (this.readPendingFlag) {
/* 187 */         buffer1 = this.storedInputBuffer;
/*     */       } else {
/*     */         
/* 190 */         buffer1 = this.ic.getValidBuffer();
/* 191 */         Format incomingFormat = buffer1.getFormat();
/*     */         
/* 193 */         if (incomingFormat == null) {
/*     */ 
/*     */           
/* 196 */           incomingFormat = this.ic.getFormat();
/* 197 */           buffer1.setFormat(incomingFormat);
/*     */         } 
/*     */         
/* 200 */         if (incomingFormat != this.ic.getFormat() && incomingFormat != null && !incomingFormat.equals(this.ic.getFormat()) && !buffer1.isDiscard()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 206 */           if (this.writePendingFlag) {
/*     */             
/* 208 */             this.storedOutputBuffer.setDiscard(true);
/* 209 */             this.oc.writeReport();
/* 210 */             this.writePendingFlag = false;
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 215 */           if (!reinitCodec(buffer1.getFormat())) {
/*     */             
/* 217 */             buffer1.setDiscard(true);
/* 218 */             this.ic.readReport();
/* 219 */             this.failed = true;
/*     */             
/* 221 */             if (this.moduleListener != null) {
/* 222 */               this.moduleListener.formatChangedFailure(this, this.ic.getFormat(), buffer1.getFormat());
/*     */             }
/*     */             
/*     */             return;
/*     */           } 
/* 227 */           Format oldFormat = this.ic.getFormat();
/* 228 */           this.ic.setFormat(buffer1.getFormat());
/* 229 */           if (this.moduleListener != null) {
/* 230 */             this.moduleListener.formatChanged(this, oldFormat, buffer1.getFormat());
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 240 */         if ((buffer1.getFlags() & 0x400) != 0) {
/* 241 */           this.markerSet = true;
/*     */         }
/*     */         
/* 244 */         if (PlaybackEngine.DEBUG && buffer1 != null) {
/* 245 */           this.jmd.moduleIn(this, 0, buffer1, true);
/*     */         }
/*     */       } 
/* 248 */       if (this.writePendingFlag) {
/* 249 */         buffer2 = this.storedOutputBuffer;
/*     */       } else {
/* 251 */         buffer2 = this.oc.getEmptyBuffer();
/* 252 */         if (buffer2 != null) {
/* 253 */           if (PlaybackEngine.DEBUG)
/* 254 */             this.jmd.moduleOut(this, 0, buffer2, true); 
/* 255 */           buffer2.setLength(0);
/* 256 */           buffer2.setOffset(0);
/* 257 */           this.lastHdr = buffer2.getHeader();
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 262 */       buffer2.setTimeStamp(buffer1.getTimeStamp());
/* 263 */       buffer2.setDuration(buffer1.getDuration());
/* 264 */       buffer2.setSequenceNumber(buffer1.getSequenceNumber());
/* 265 */       buffer2.setFlags(buffer1.getFlags());
/* 266 */       buffer2.setHeader(buffer1.getHeader());
/*     */ 
/*     */       
/* 269 */       if (this.resetted) {
/*     */ 
/*     */ 
/*     */         
/* 273 */         if ((buffer1.getFlags() & 0x200) != 0) {
/* 274 */           this.codec.reset();
/* 275 */           this.resetted = false;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 280 */         this.readPendingFlag = this.writePendingFlag = false;
/* 281 */         this.ic.readReport();
/* 282 */         this.oc.writeReport();
/*     */         
/*     */         return;
/*     */       } 
/* 286 */       if (this.failed || buffer1.isDiscard()) {
/*     */ 
/*     */         
/* 289 */         if (this.markerSet) {
/* 290 */           buffer2.setFlags(buffer2.getFlags() & 0xFFFFFBFF);
/*     */           
/* 292 */           this.markerSet = false;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 299 */         this.curFramesBehind = 0.0F;
/*     */         
/* 301 */         this.ic.readReport();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 306 */         if (!this.writePendingFlag) {
/* 307 */           this.oc.writeReport();
/*     */         }
/*     */         
/*     */         return;
/*     */       } 
/* 312 */       if (this.frameControl != null && this.curFramesBehind != this.prevFramesBehind && (buffer1.getFlags() & 0x20) == 0) {
/*     */         
/* 314 */         this.frameControl.setFramesBehind(this.curFramesBehind);
/* 315 */         this.prevFramesBehind = this.curFramesBehind;
/*     */       } 
/*     */       
/* 318 */       int rc = 0;
/*     */ 
/*     */       
/*     */       try {
/* 322 */         rc = this.codec.process(buffer1, buffer2);
/*     */       } catch (Throwable e) {
/*     */         
/* 325 */         Log.dumpStack(e);
/* 326 */         if (this.moduleListener != null) {
/* 327 */           this.moduleListener.internalErrorOccurred(this);
/*     */         }
/*     */       } 
/* 330 */       if (PlaybackEngine.TRACE_ON && !verifyBuffer(buffer2)) {
/* 331 */         System.err.println("verify buffer failed: " + this.codec);
/* 332 */         Thread.dumpStack();
/* 333 */         if (this.moduleListener != null) {
/* 334 */           this.moduleListener.internalErrorOccurred(this);
/*     */         }
/*     */       } 
/* 337 */       if ((rc & 0x8) != 0) {
/* 338 */         this.failed = true;
/* 339 */         if (this.moduleListener != null)
/* 340 */           this.moduleListener.pluginTerminated(this); 
/* 341 */         this.readPendingFlag = this.writePendingFlag = false;
/* 342 */         this.ic.readReport();
/* 343 */         this.oc.writeReport();
/*     */         
/*     */         return;
/*     */       } 
/* 347 */       if (this.curFramesBehind > 0.0F && buffer2.isDiscard()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 356 */         this.curFramesBehind--;
/* 357 */         if (this.curFramesBehind < 0.0F) {
/* 358 */           this.curFramesBehind = 0.0F;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 365 */         this; rc &= 0x4 ^ 0xFFFFFFFF;
/*     */       } 
/*     */       
/* 368 */       this; if ((rc & 0x1) != 0) {
/* 369 */         buffer2.setDiscard(true);
/*     */         
/* 371 */         if (this.markerSet) {
/* 372 */           buffer2.setFlags(buffer2.getFlags() & 0xFFFFFBFF);
/*     */           
/* 374 */           this.markerSet = false;
/*     */         } 
/* 376 */         if (PlaybackEngine.DEBUG) this.jmd.moduleIn(this, 0, buffer1, false); 
/* 377 */         this.ic.readReport();
/* 378 */         if (PlaybackEngine.DEBUG) this.jmd.moduleOut(this, 0, buffer2, false); 
/* 379 */         this.oc.writeReport();
/* 380 */         this.readPendingFlag = this.writePendingFlag = false;
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 386 */       this; this; if (buffer2.isEOM() && ((rc & 0x2) != 0 || (rc & 0x4) != 0))
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 391 */         buffer2.setEOM(false);
/*     */       }
/*     */       
/* 394 */       this; if ((rc & 0x4) != 0) {
/* 395 */         this.writePendingFlag = true;
/* 396 */         this.storedOutputBuffer = buffer2;
/*     */       } else {
/* 398 */         if (PlaybackEngine.DEBUG) this.jmd.moduleOut(this, 0, buffer2, false); 
/* 399 */         if (this.markerSet) {
/* 400 */           buffer2.setFlags(buffer2.getFlags() | 0x400);
/*     */           
/* 402 */           this.markerSet = false;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 408 */         this.oc.writeReport();
/* 409 */         this.writePendingFlag = false;
/*     */       } 
/*     */ 
/*     */       
/* 413 */       this; if ((rc & 0x2) != 0 || (buffer1.isEOM() && !buffer2.isEOM())) {
/*     */         
/* 415 */         this.readPendingFlag = true;
/* 416 */         this.storedInputBuffer = buffer1;
/*     */       } else {
/* 418 */         if (PlaybackEngine.DEBUG) this.jmd.moduleIn(this, 0, buffer1, false); 
/* 419 */         buffer1.setHeader(this.lastHdr);
/* 420 */         this.ic.readReport();
/* 421 */         this.readPendingFlag = false;
/*     */       }
/*     */     
/* 424 */     } while (this.readPendingFlag); }
/*     */ 
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\BasicFilterModule.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */