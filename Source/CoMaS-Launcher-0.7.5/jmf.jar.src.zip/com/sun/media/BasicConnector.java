/*     */ package com.sun.media;
/*     */ 
/*     */ import javax.media.Format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BasicConnector
/*     */   implements Connector
/*     */ {
/*  17 */   protected Module module = null;
/*     */   
/*  19 */   protected int minSize = 1;
/*     */   
/*  21 */   protected Format format = null;
/*     */   
/*  23 */   protected CircularBuffer circularBuffer = null;
/*     */   
/*  25 */   protected String name = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  31 */   protected int protocol = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getCircularBuffer() {
/*  37 */     return this.circularBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCircularBuffer(Object cicularBuffer) {
/*  45 */     this.circularBuffer = (CircularBuffer)cicularBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFormat(Format format) {
/*  53 */     this.module.setFormat(this, format);
/*  54 */     this.format = format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format getFormat() {
/*  62 */     return this.format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Module getModule() {
/*  70 */     return this.module;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setModule(Module module) {
/*  78 */     this.module = module;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSize(int numOfBufferObjects) {
/*  88 */     this.minSize = numOfBufferObjects;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize() {
/*  96 */     return this.minSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 104 */     this.circularBuffer.reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 111 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/* 118 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProtocol(int protocol) {
/* 125 */     this.protocol = protocol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getProtocol() {
/* 132 */     return this.protocol;
/*     */   }
/*     */   
/*     */   public void print() {
/* 136 */     this.circularBuffer.print();
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\BasicConnector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */