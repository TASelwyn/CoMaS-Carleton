/*    */ package com.sun.media;
/*    */ 
/*    */ import javax.media.SystemTimeBase;
/*    */ import javax.media.Time;
/*    */ import javax.media.TimeBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MediaTimeBase
/*    */   implements TimeBase
/*    */ {
/* 25 */   long origin = 0L;
/* 26 */   long offset = 0L;
/* 27 */   long time = 0L;
/* 28 */   TimeBase systemTimeBase = null;
/*    */   
/*    */   public MediaTimeBase() {
/* 31 */     mediaStopped();
/*    */   }
/*    */   
/*    */   public Time getTime() {
/* 35 */     return new Time(getNanoseconds());
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized long getNanoseconds() {
/* 40 */     if (this.systemTimeBase != null) {
/* 41 */       this.time = this.origin + this.systemTimeBase.getNanoseconds() - this.offset;
/*    */     } else {
/* 43 */       this.time = this.origin + getMediaTime() - this.offset;
/* 44 */     }  return this.time;
/*    */   }
/*    */   
/*    */   public abstract long getMediaTime();
/*    */   
/*    */   public synchronized void mediaStarted() {
/* 50 */     this.systemTimeBase = null;
/* 51 */     this.offset = getMediaTime();
/* 52 */     this.origin = this.time;
/*    */   }
/*    */   
/*    */   public synchronized void mediaStopped() {
/* 56 */     this.systemTimeBase = (TimeBase)new SystemTimeBase();
/* 57 */     this.offset = this.systemTimeBase.getNanoseconds();
/* 58 */     this.origin = this.time;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\MediaTimeBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */