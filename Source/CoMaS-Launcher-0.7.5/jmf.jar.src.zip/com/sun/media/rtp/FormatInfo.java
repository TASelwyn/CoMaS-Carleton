/*     */ package com.sun.media.rtp;
/*     */ 
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormatInfo
/*     */ {
/*  17 */   private SSRCCache cache = null;
/*     */   
/*     */   public static final int PAYLOAD_NOTFOUND = -1;
/*  20 */   Format[] formatList = new Format[64];
/*     */ 
/*     */   
/*  23 */   static AudioFormat mpegAudio = new AudioFormat("mpegaudio/rtp");
/*     */   
/*     */   public FormatInfo() {
/*  26 */     initFormats();
/*     */   }
/*     */   
/*     */   public void setCache(SSRCCache cache) {
/*  30 */     this.cache = cache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(int payload, Format fmt) {
/*  37 */     if (payload >= this.formatList.length)
/*  38 */       expandTable(payload); 
/*     */     Format located;
/*  40 */     if ((located = this.formatList[payload]) != null) {
/*     */       return;
/*     */     }
/*  43 */     this.formatList[payload] = fmt;
/*     */     
/*  45 */     if (this.cache != null && fmt instanceof VideoFormat) {
/*  46 */       this.cache.clockrate[payload] = 90000;
/*     */     }
/*  48 */     if (this.cache != null && fmt instanceof AudioFormat) {
/*  49 */       if (mpegAudio.matches(fmt)) {
/*  50 */         this.cache.clockrate[payload] = 90000;
/*     */       } else {
/*  52 */         this.cache.clockrate[payload] = (int)((AudioFormat)fmt).getSampleRate();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void expandTable(int num) {
/*  59 */     Format[] newList = new Format[num + 1];
/*  60 */     for (int i = 0; i < this.formatList.length; i++)
/*  61 */       newList[i] = this.formatList[i]; 
/*  62 */     this.formatList = newList;
/*     */   }
/*     */   
/*     */   public Format get(int payload) {
/*  66 */     return (payload >= this.formatList.length) ? null : this.formatList[payload];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPayload(Format fmt) {
/*     */     AudioFormat audioFormat;
/*  72 */     if (fmt.getEncoding() != null && fmt.getEncoding().equals("g729a/rtp"))
/*     */     {
/*     */       
/*  75 */       audioFormat = new AudioFormat("g729/rtp");
/*     */     }
/*     */     
/*  78 */     for (int i = 0; i < this.formatList.length; i++) {
/*  79 */       if (audioFormat.matches(this.formatList[i])) {
/*  80 */         return i;
/*     */       }
/*     */     } 
/*  83 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public void initFormats() {
/*  88 */     this.formatList[0] = (Format)new AudioFormat("ULAW/rtp", 8000.0D, 8, 1);
/*     */ 
/*     */ 
/*     */     
/*  92 */     this.formatList[3] = (Format)new AudioFormat("gsm/rtp", 8000.0D, -1, 1);
/*     */ 
/*     */ 
/*     */     
/*  96 */     this.formatList[4] = (Format)new AudioFormat("g723/rtp", 8000.0D, -1, 1);
/*     */ 
/*     */ 
/*     */     
/* 100 */     this.formatList[5] = (Format)new AudioFormat("dvi/rtp", 8000.0D, 4, 1);
/*     */ 
/*     */ 
/*     */     
/* 104 */     this.formatList[14] = (Format)new AudioFormat("mpegaudio/rtp", -1.0D, -1, -1);
/*     */ 
/*     */ 
/*     */     
/* 108 */     this.formatList[15] = (Format)new AudioFormat("g728/rtp", 8000.0D, -1, 1);
/*     */ 
/*     */ 
/*     */     
/* 112 */     this.formatList[16] = (Format)new AudioFormat("dvi/rtp", 11025.0D, 4, 1);
/*     */ 
/*     */ 
/*     */     
/* 116 */     this.formatList[17] = (Format)new AudioFormat("dvi/rtp", 22050.0D, 4, 1);
/*     */ 
/*     */ 
/*     */     
/* 120 */     this.formatList[18] = (Format)new AudioFormat("g729/rtp", 8000.0D, -1, 1);
/*     */ 
/*     */ 
/*     */     
/* 124 */     this.formatList[26] = (Format)new VideoFormat("jpeg/rtp");
/* 125 */     this.formatList[31] = (Format)new VideoFormat("h261/rtp");
/* 126 */     this.formatList[32] = (Format)new VideoFormat("mpeg/rtp");
/* 127 */     this.formatList[34] = (Format)new VideoFormat("h263/rtp");
/* 128 */     this.formatList[42] = (Format)new VideoFormat("h263-1998/rtp");
/*     */   }
/*     */   
/*     */   public static boolean isSupported(int payload) {
/* 132 */     switch (payload) {
/*     */       
/*     */       case 0:
/*     */       case 3:
/*     */       case 4:
/*     */       case 5:
/*     */       case 6:
/*     */       case 14:
/*     */       case 15:
/*     */       case 16:
/*     */       case 17:
/*     */       case 18:
/*     */       case 26:
/*     */       case 31:
/*     */       case 32:
/*     */       case 34:
/* 148 */         return true;
/*     */     } 
/* 150 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\FormatInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */