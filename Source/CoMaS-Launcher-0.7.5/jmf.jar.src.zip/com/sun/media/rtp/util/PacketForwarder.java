/*     */ package com.sun.media.rtp.util;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import com.sun.media.util.MediaThread;
/*     */ import com.sun.media.util.jdk12;
/*     */ import com.sun.media.util.jdk12CreateThreadRunnableAction;
/*     */ import com.sun.media.util.jdk12PriorityAction;
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PacketForwarder
/*     */   implements Runnable
/*     */ {
/*  37 */   PacketSource source = null;
/*  38 */   PacketConsumer consumer = null;
/*     */   
/*     */   RTPMediaThread thread;
/*     */   
/*     */   boolean closed = false;
/*     */   
/*     */   private boolean paused;
/*     */   
/*  46 */   public IOException exception = null;
/*     */ 
/*     */   
/*  49 */   private static JMFSecurity jmfSecurity = null;
/*     */   private static boolean securityPrivelege = false;
/*  51 */   private Method[] m = new Method[1];
/*  52 */   private Class[] cl = new Class[1];
/*  53 */   private Object[][] args = new Object[1][0];
/*     */   
/*     */   static {
/*     */     try {
/*  57 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  58 */       securityPrivelege = true;
/*  59 */     } catch (SecurityException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PacketForwarder(PacketSource s, PacketConsumer c) {
/*  77 */     this.source = s;
/*  78 */     this.consumer = c;
/*  79 */     this.closed = false;
/*  80 */     this.exception = null;
/*     */   }
/*     */   
/*     */   public void startPF() {
/*  84 */     startPF(null);
/*     */   }
/*     */   public void startPF(String threadname) {
/*  87 */     if (this.thread != null) {
/*  88 */       throw new IllegalArgumentException("Called start more than once");
/*     */     }
/*  90 */     if (jmfSecurity != null) {
/*  91 */       String permission = null;
/*     */       try {
/*  93 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  94 */           permission = "thread";
/*  95 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/*  96 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*     */           
/*  98 */           permission = "thread group";
/*  99 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/* 100 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*     */         }
/* 102 */         else if (jmfSecurity.getName().startsWith("internet")) {
/* 103 */           PolicyEngine.checkPermission(PermissionID.THREAD);
/* 104 */           PolicyEngine.assertPermission(PermissionID.THREAD);
/*     */         }
/*     */       
/* 107 */       } catch (Throwable e) {
/*     */ 
/*     */ 
/*     */         
/* 111 */         if (permission.endsWith("group")) {
/* 112 */           jmfSecurity.permissionFailureNotification(32);
/*     */         } else {
/* 114 */           jmfSecurity.permissionFailureNotification(16);
/*     */         } 
/*     */       } 
/*     */     } 
/* 118 */     if (threadname == null) {
/* 119 */       threadname = "RTPMediaThread";
/*     */     }
/* 121 */     if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*     */       try {
/* 123 */         Constructor cons = jdk12CreateThreadRunnableAction.cons;
/*     */         
/* 125 */         this.thread = (RTPMediaThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { RTPMediaThread.class, this }) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 134 */         this.thread.setName(threadname);
/*     */         
/* 136 */         cons = jdk12PriorityAction.cons;
/* 137 */         jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { this.thread, new Integer(MediaThread.getNetworkPriority()) }) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 145 */       catch (Exception e) {}
/*     */     } else {
/*     */       
/* 148 */       this.thread = new RTPMediaThread(this, threadname);
/* 149 */       this.thread.useNetworkPriority();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 154 */     this.thread.setDaemon(true);
/* 155 */     this.thread.start();
/*     */   }
/*     */   public void setVideoPriority() {
/* 158 */     this.thread.useVideoNetworkPriority();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PacketSource getSource() {
/* 164 */     return this.source;
/*     */   }
/*     */   public PacketConsumer getConsumer() {
/* 167 */     return this.consumer;
/*     */   }
/*     */   
/*     */   public String getId() {
/* 171 */     if (this.thread == null) {
/* 172 */       System.err.println("the packetforwarders thread is null");
/* 173 */       return null;
/*     */     } 
/* 175 */     return this.thread.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 184 */     if (this.closed || this.exception != null) {
/* 185 */       if (this.source != null) {
/* 186 */         this.source.closeSource();
/*     */       }
/*     */       return;
/*     */     } 
/* 190 */     if (jmfSecurity != null) {
/*     */       try {
/* 192 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 193 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 128);
/* 194 */           this.m[0].invoke(this.cl[0], this.args[0]);
/* 195 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/* 196 */           PolicyEngine.checkPermission(PermissionID.NETIO);
/* 197 */           PolicyEngine.assertPermission(PermissionID.NETIO);
/*     */         }
/*     */       
/* 200 */       } catch (Throwable e) {
/*     */ 
/*     */ 
/*     */         
/* 204 */         jmfSecurity.permissionFailureNotification(128);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*     */       while (true) {
/*     */         try {
/* 218 */           Packet p = this.source.receiveFrom();
/* 219 */           if (checkForClose())
/*     */             return; 
/* 221 */           if (p != null)
/* 222 */             this.consumer.sendTo(p); 
/* 223 */           if (checkForClose()) {
/*     */             return;
/*     */           }
/*     */         } catch (InterruptedIOException e) {
/* 227 */           if (checkForClose()) {
/*     */             return;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } catch (IOException e) {
/*     */       
/* 234 */       if (checkForClose())
/*     */         return; 
/* 236 */       this.exception = e;
/*     */     }
/*     */     finally {
/*     */       
/* 240 */       this.consumer.closeConsumer();
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean checkForClose() {
/* 245 */     if (this.closed && this.thread != null) {
/* 246 */       if (this.source != null)
/* 247 */         this.source.closeSource(); 
/* 248 */       return true;
/*     */     } 
/* 250 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 260 */     this.closed = true;
/* 261 */     if (this.consumer != null)
/* 262 */       this.consumer.closeConsumer(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rt\\util\PacketForwarder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */