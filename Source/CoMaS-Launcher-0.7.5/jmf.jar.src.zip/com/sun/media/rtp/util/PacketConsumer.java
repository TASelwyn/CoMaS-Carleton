package com.sun.media.rtp.util;

import java.io.IOException;

public interface PacketConsumer {
  void sendTo(Packet paramPacket) throws IOException;
  
  void closeConsumer();
  
  String consumerString();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rt\\util\PacketConsumer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */