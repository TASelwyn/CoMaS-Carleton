package com.sun.media.rtp.util;

import java.io.IOException;

public interface PacketConsumer {
  void sendTo(Packet paramPacket) throws IOException;
  
  void closeConsumer();
  
  String consumerString();
}
