/*    */ package com.sun.media.rtp.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClosedException
/*    */   extends IOException
/*    */ {
/*    */   public ClosedException() {}
/*    */   
/*    */   public ClosedException(String m) {
/* 13 */     super(m);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rt\\util\ClosedException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */