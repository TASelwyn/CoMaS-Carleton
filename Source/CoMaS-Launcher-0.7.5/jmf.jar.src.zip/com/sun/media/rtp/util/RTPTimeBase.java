/*     */ package com.sun.media.rtp.util;
/*     */ 
/*     */ import com.sun.media.Log;
/*     */ import java.util.Vector;
/*     */ import javax.media.Time;
/*     */ import javax.media.TimeBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RTPTimeBase
/*     */   implements TimeBase
/*     */ {
/*  15 */   static Vector timeBases = new Vector();
/*  16 */   static int SSRC_UNDEFINED = 0;
/*     */ 
/*     */   
/*     */   String cname;
/*     */ 
/*     */   
/*     */   public static RTPTimeBase find(RTPTimeReporter r, String cname) {
/*  23 */     synchronized (timeBases) {
/*  24 */       RTPTimeBase result = null;
/*  25 */       for (int i = 0; i < timeBases.size(); i++) {
/*  26 */         RTPTimeBase tb = timeBases.elementAt(i);
/*  27 */         if (tb.cname.equals(cname)) {
/*  28 */           result = tb;
/*     */           break;
/*     */         } 
/*     */       } 
/*  32 */       if (result == null) {
/*  33 */         Log.comment("Created RTP time base for session: " + cname + "\n");
/*  34 */         result = new RTPTimeBase(cname);
/*  35 */         timeBases.addElement(result);
/*     */       } 
/*  37 */       if (r != null) {
/*  38 */         if (result.getMaster() == null)
/*  39 */           result.setMaster(r); 
/*  40 */         result.reporters.addElement(r);
/*     */       } 
/*  42 */       return result;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void remove(RTPTimeReporter r, String cname) {
/*  51 */     synchronized (timeBases) {
/*     */       
/*  53 */       for (int i = 0; i < timeBases.size(); i++) {
/*  54 */         RTPTimeBase tb = timeBases.elementAt(i);
/*  55 */         if (tb.cname.equals(cname)) {
/*  56 */           tb.reporters.removeElement(r);
/*  57 */           if (tb.reporters.size() == 0) {
/*  58 */             tb.master = null;
/*  59 */             timeBases.removeElement(tb);
/*     */             
/*     */             break;
/*     */           } 
/*  63 */           synchronized (tb) {
/*  64 */             if (tb.master == r) {
/*  65 */               tb.setMaster(tb.reporters.elementAt(0));
/*     */             }
/*     */           } 
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static RTPTimeBase getMapper(String cname) {
/*  75 */     synchronized (timeBases) {
/*  76 */       return find(null, cname);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static RTPTimeBase getMapperUpdatable(String cname) {
/*  81 */     synchronized (timeBases) {
/*  82 */       RTPTimeBase tb = find(null, cname);
/*  83 */       if (tb.offsetUpdatable) {
/*  84 */         tb.offsetUpdatable = false;
/*  85 */         return tb;
/*     */       } 
/*  87 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void returnMapperUpdatable(RTPTimeBase tb) {
/*  92 */     synchronized (timeBases) {
/*  93 */       tb.offsetUpdatable = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*  98 */   RTPTimeReporter master = null;
/*  99 */   Vector reporters = new Vector();
/* 100 */   long origin = 0L;
/* 101 */   long offset = 0L;
/*     */   boolean offsetUpdatable = true;
/*     */   
/*     */   RTPTimeBase(String cname) {
/* 105 */     this.cname = cname;
/*     */   }
/*     */   
/*     */   public Time getTime() {
/* 109 */     return new Time(getNanoseconds());
/*     */   }
/*     */   
/*     */   public synchronized long getNanoseconds() {
/* 113 */     return (this.master != null) ? this.master.getRTPTime() : 0L;
/*     */   }
/*     */   
/*     */   public synchronized void setMaster(RTPTimeReporter r) {
/* 117 */     this.master = r;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized RTPTimeReporter getMaster() {
/* 122 */     return this.master;
/*     */   }
/*     */   
/*     */   public synchronized void setOrigin(long orig) {
/* 126 */     this.origin = orig;
/*     */   }
/*     */   
/*     */   public long getOrigin() {
/* 130 */     return this.origin;
/*     */   }
/*     */   
/*     */   public synchronized void setOffset(long off) {
/* 134 */     this.offset = off;
/*     */   }
/*     */   
/*     */   public long getOffset() {
/* 138 */     return this.offset;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rt\\util\RTPTimeBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */