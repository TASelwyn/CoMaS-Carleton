package com.sun.media.rtp.util;

import java.io.IOException;

public interface PacketSource {
  Packet receiveFrom() throws IOException;
  
  void closeSource();
  
  String sourceString();
}
