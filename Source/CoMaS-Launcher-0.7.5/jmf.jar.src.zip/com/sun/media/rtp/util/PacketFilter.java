package com.sun.media.rtp.util;

import java.io.IOException;
import java.util.Vector;
import javax.media.rtp.SessionAddress;

public abstract class PacketFilter implements PacketSource, PacketConsumer {
  PacketSource source;
  
  PacketConsumer consumer;
  
  public Vector destAddressList = null;
  
  public Vector peerlist = null;
  
  public boolean control = false;
  
  public abstract Packet handlePacket(Packet paramPacket);
  
  public abstract Packet handlePacket(Packet paramPacket, int paramInt);
  
  public abstract Packet handlePacket(Packet paramPacket, SessionAddress paramSessionAddress);
  
  public Packet receiveFrom() throws IOException {
    Packet p = null;
    Packet rawp = this.source.receiveFrom();
    if (rawp != null)
      p = handlePacket(rawp); 
    return p;
  }
  
  public void sendTo(Packet p) throws IOException {
    Packet origpacket = p;
    if (this.peerlist != null) {
      p = handlePacket(origpacket);
      for (int i = 0; i < this.peerlist.size(); i++) {
        SessionAddress a = this.peerlist.elementAt(i);
        if (!this.control) {
          ((UDPPacket)p).remoteAddress = a.getDataAddress();
          ((UDPPacket)p).remotePort = a.getDataPort();
        } else {
          ((UDPPacket)p).remoteAddress = a.getControlAddress();
          ((UDPPacket)p).remotePort = a.getControlPort();
        } 
        if (p != null && this.consumer != null)
          this.consumer.sendTo(p); 
      } 
    } else if (this.destAddressList != null) {
      for (int i = 0; i < this.destAddressList.size(); i++) {
        SessionAddress sa = this.destAddressList.elementAt(i);
        p = handlePacket(origpacket, sa);
        if (p != null && this.consumer != null)
          this.consumer.sendTo(p); 
      } 
    } else if (this.destAddressList == null) {
      p = handlePacket(p);
      if (p != null && this.consumer != null)
        this.consumer.sendTo(p); 
    } 
  }
  
  public void close() {}
  
  public void closeSource() {
    close();
    if (this.source != null)
      this.source.closeSource(); 
  }
  
  public void closeConsumer() {
    close();
    if (this.consumer != null)
      this.consumer.closeConsumer(); 
  }
  
  public PacketConsumer getConsumer() {
    return this.consumer;
  }
  
  public PacketSource getSource() {
    return this.source;
  }
  
  public Vector getDestList() {
    return null;
  }
  
  public void setConsumer(PacketConsumer c) {
    this.consumer = c;
  }
  
  public void setSource(PacketSource s) {
    this.source = s;
  }
  
  public String filtername() {
    return getClass().getName();
  }
  
  public String consumerString() {
    if (this.consumer == null)
      return filtername(); 
    return filtername() + " connected to " + this.consumer.consumerString();
  }
  
  public String sourceString() {
    if (this.source == null)
      return filtername(); 
    return filtername() + " attached to " + this.source.sourceString();
  }
}
