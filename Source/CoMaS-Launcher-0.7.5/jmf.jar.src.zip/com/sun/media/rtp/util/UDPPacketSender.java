/*     */ package com.sun.media.rtp.util;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.DatagramPacket;
/*     */ import java.net.DatagramSocket;
/*     */ import java.net.InetAddress;
/*     */ import java.net.MulticastSocket;
/*     */ import java.net.SocketException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UDPPacketSender
/*     */   implements PacketConsumer
/*     */ {
/*     */   private DatagramSocket sock;
/*     */   private InetAddress address;
/*     */   private int port;
/*     */   private int ttl;
/*  36 */   private static JMFSecurity jmfSecurity = null;
/*     */   private static boolean securityPrivelege = false;
/*  38 */   private Method[] m = new Method[1];
/*  39 */   private Class[] cl = new Class[1];
/*  40 */   private Object[][] args = new Object[1][0];
/*     */   
/*     */   static {
/*     */     try {
/*  44 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  45 */       securityPrivelege = true;
/*  46 */     } catch (SecurityException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UDPPacketSender(DatagramSocket sock) {
/*  56 */     this.sock = sock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UDPPacketSender() throws IOException {
/*  63 */     this(new DatagramSocket());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UDPPacketSender(int localPort) throws IOException {
/*  71 */     this(new DatagramSocket(localPort));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UDPPacketSender(InetAddress remoteAddress, int remotePort) throws IOException {
/*  83 */     if (remoteAddress.isMulticastAddress()) {
/*  84 */       MulticastSocket sock = new MulticastSocket();
/*  85 */       this.sock = sock;
/*     */     } else {
/*  87 */       this.sock = new DatagramSocket();
/*     */     } 
/*     */     
/*  90 */     setRemoteAddress(remoteAddress, remotePort);
/*     */   }
/*     */   
/*     */   public InetAddress getLocalAddress() {
/*  94 */     return this.sock.getLocalAddress();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UDPPacketSender(int localPort, InetAddress localAddress, InetAddress remoteAddress, int remotePort) throws IOException {
/* 108 */     if (remoteAddress.isMulticastAddress()) {
/* 109 */       MulticastSocket sock = new MulticastSocket(localPort);
/*     */       
/* 111 */       if (localAddress != null) {
/* 112 */         sock.setInterface(localAddress);
/*     */       }
/*     */       
/* 115 */       this.sock = sock;
/*     */     }
/* 117 */     else if (localAddress != null) {
/*     */       try {
/* 119 */         this.sock = new DatagramSocket(localPort, localAddress);
/*     */       }
/*     */       catch (SocketException e) {
/*     */         
/* 123 */         System.out.println(e);
/* 124 */         System.out.println("localPort: " + localPort);
/* 125 */         System.out.println("localAddress: " + localAddress);
/*     */         
/* 127 */         throw e;
/*     */       } 
/*     */     } else {
/* 130 */       this.sock = new DatagramSocket(localPort);
/*     */     } 
/*     */ 
/*     */     
/* 134 */     setRemoteAddress(remoteAddress, remotePort);
/*     */   }
/*     */   
/*     */   public DatagramSocket getSocket() {
/* 138 */     return this.sock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRemoteAddress(InetAddress remoteAddress, int remotePort) {
/* 149 */     this.address = remoteAddress;
/* 150 */     this.port = remotePort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setttl(int ttl) throws IOException {
/* 158 */     this.ttl = ttl;
/* 159 */     if (this.sock instanceof MulticastSocket) {
/* 160 */       ((MulticastSocket)this.sock).setTTL((byte)this.ttl);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLocalPort() {
/* 167 */     return this.sock.getLocalPort();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendTo(Packet p) throws IOException {
/* 183 */     InetAddress addr = null;
/* 184 */     int port = 0;
/* 185 */     if (p instanceof UDPPacket) {
/* 186 */       UDPPacket udpp = (UDPPacket)p;
/* 187 */       addr = udpp.remoteAddress;
/* 188 */       port = udpp.remotePort;
/* 189 */       if (jmfSecurity != null) {
/* 190 */         String permission = null;
/*     */         try {
/* 192 */           if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 193 */             if (udpp.remoteAddress.isMulticastAddress()) {
/* 194 */               permission = "multicast";
/* 195 */               jmfSecurity.requestPermission(this.m, this.cl, this.args, 512);
/* 196 */               this.m[0].invoke(this.cl[0], this.args[0]);
/*     */             } 
/* 198 */             permission = "connect";
/* 199 */             jmfSecurity.requestPermission(this.m, this.cl, this.args, 128);
/* 200 */             this.m[0].invoke(this.cl[0], this.args[0]);
/* 201 */           } else if (jmfSecurity.getName().startsWith("internet")) {
/* 202 */             PolicyEngine.checkPermission(PermissionID.NETIO);
/* 203 */             PolicyEngine.assertPermission(PermissionID.NETIO);
/*     */           }
/*     */         
/* 206 */         } catch (Throwable e) {
/*     */ 
/*     */ 
/*     */           
/* 210 */           if (permission.startsWith("multicast")) {
/* 211 */             jmfSecurity.permissionFailureNotification(512);
/*     */           } else {
/* 213 */             jmfSecurity.permissionFailureNotification(128);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 218 */     if (addr == null)
/* 219 */       throw new IllegalArgumentException("No address set"); 
/* 220 */     send(p, addr, port);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(Packet p, InetAddress addr, int port) throws IOException {
/* 232 */     byte[] data = p.data;
/* 233 */     if (p.offset > 0) {
/* 234 */       System.arraycopy(data, p.offset, data = new byte[p.length], 0, p.length);
/*     */     }
/* 236 */     DatagramPacket dp = new DatagramPacket(data, p.length, addr, port);
/* 237 */     this.sock.send(dp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeConsumer() {
/* 247 */     if (this.sock != null) {
/* 248 */       this.sock.close();
/* 249 */       this.sock = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String consumerString() {
/* 258 */     String s = "UDP Datagram Packet Sender on port " + this.sock.getLocalPort();
/*     */     
/* 260 */     if (this.address != null) {
/* 261 */       s = s + " sending to address " + this.address + ", port " + this.port + ", ttl" + this.ttl;
/*     */     }
/*     */     
/* 264 */     return s;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rt\\util\UDPPacketSender.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */