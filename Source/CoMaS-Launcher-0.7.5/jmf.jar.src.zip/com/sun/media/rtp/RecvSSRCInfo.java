/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import java.util.Vector;
/*    */ import javax.media.protocol.DataSource;
/*    */ import javax.media.rtp.LocalParticipant;
/*    */ import javax.media.rtp.Participant;
/*    */ import javax.media.rtp.RTPStream;
/*    */ import javax.media.rtp.ReceiveStream;
/*    */ import javax.media.rtp.ReceptionStats;
/*    */ import javax.media.rtp.rtcp.Feedback;
/*    */ import javax.media.rtp.rtcp.Report;
/*    */ import javax.media.rtp.rtcp.SenderReport;
/*    */ 
/*    */ 
/*    */ public class RecvSSRCInfo
/*    */   extends SSRCInfo
/*    */   implements ReceiveStream, SenderReport
/*    */ {
/*    */   RecvSSRCInfo(SSRCCache cache, int ssrc) {
/* 20 */     super(cache, ssrc);
/*    */   }
/*    */   RecvSSRCInfo(SSRCInfo info) {
/* 23 */     super(info);
/*    */   }
/*    */   
/*    */   public Participant getParticipant() {
/* 27 */     SSRCCache cache = getSSRCCache();
/* 28 */     if (this.sourceInfo instanceof LocalParticipant && cache.sm.IsNonParticipating())
/*    */     {
/* 30 */       return null; } 
/* 31 */     return this.sourceInfo;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SenderReport getSenderReport() {
/* 38 */     return this;
/*    */   }
/*    */   public long getSSRC() {
/* 41 */     return this.ssrc;
/*    */   }
/*    */   
/*    */   public DataSource getDataSource() {
/* 45 */     return (DataSource)this.dsource;
/*    */   }
/*    */   
/*    */   public long getSenderPacketCount() {
/* 49 */     return this.lastSRpacketcount;
/*    */   }
/*    */   public long getSenderByteCount() {
/* 52 */     return this.lastSRoctetcount;
/*    */   }
/*    */   public long getNTPTimeStampMSW() {
/* 55 */     return this.lastSRntptimestamp >> 32L & 0xFFFFFFFFL;
/*    */   }
/*    */   
/*    */   public long getNTPTimeStampLSW() {
/* 59 */     return this.lastSRntptimestamp & 0xFFFFFFFFL;
/*    */   }
/*    */   public long getRTPTimeStamp() {
/* 62 */     return this.lastSRrtptimestamp;
/*    */   }
/*    */   public Feedback getSenderFeedback() {
/* 65 */     SSRCCache cache = getSSRCCache();
/* 66 */     Report report = null;
/*    */     
/* 68 */     Vector reports = null;
/* 69 */     Vector feedback = null;
/* 70 */     Feedback reportblk = null;
/*    */     try {
/* 72 */       LocalParticipant localpartc = cache.sm.getLocalParticipant();
/* 73 */       reports = localpartc.getReports();
/* 74 */       for (int i = 0; i < reports.size(); i++) {
/* 75 */         report = reports.elementAt(i);
/* 76 */         feedback = report.getFeedbackReports();
/* 77 */         for (int j = 0; j < feedback.size(); j++) {
/* 78 */           reportblk = feedback.elementAt(j);
/*    */           
/* 80 */           long ssrc = reportblk.getSSRC();
/* 81 */           if (ssrc == getSSRC())
/* 82 */             return reportblk; 
/*    */         } 
/*    */       } 
/* 85 */       return null;
/*    */     } catch (NullPointerException e) {
/* 87 */       return null;
/*    */     } 
/*    */   }
/*    */   
/*    */   public RTPStream getStream() {
/* 92 */     return (RTPStream)this;
/*    */   }
/*    */   
/*    */   public ReceptionStats getSourceReceptionStats() {
/* 96 */     return this.stats;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RecvSSRCInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */