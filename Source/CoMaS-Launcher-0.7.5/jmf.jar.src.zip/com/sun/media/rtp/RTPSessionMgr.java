/*      */ package com.sun.media.rtp;
/*      */ import com.ms.security.PermissionID;
/*      */ import com.ms.security.PolicyEngine;
/*      */ import com.sun.media.protocol.rtp.DataSource;
/*      */ import com.sun.media.rtp.util.PacketConsumer;
/*      */ import com.sun.media.rtp.util.PacketForwarder;
/*      */ import com.sun.media.rtp.util.PacketSource;
/*      */ import com.sun.media.rtp.util.RTPPacketSender;
/*      */ import com.sun.media.rtp.util.UDPPacketSender;
/*      */ import com.sun.media.util.jdk12;
/*      */ import com.sun.media.util.jdk12InetAddressAction;
/*      */ import java.io.IOException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.net.DatagramSocket;
/*      */ import java.net.InetAddress;
/*      */ import java.net.SocketException;
/*      */ import java.net.UnknownHostException;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Vector;
/*      */ import javax.media.Format;
/*      */ import javax.media.format.UnsupportedFormatException;
/*      */ import javax.media.protocol.DataSource;
/*      */ import javax.media.protocol.PushBufferStream;
/*      */ import javax.media.rtp.EncryptionInfo;
/*      */ import javax.media.rtp.InvalidSessionAddressException;
/*      */ import javax.media.rtp.Participant;
/*      */ import javax.media.rtp.RTPConnector;
/*      */ import javax.media.rtp.RTPControl;
/*      */ import javax.media.rtp.RTPPushDataSource;
/*      */ import javax.media.rtp.RTPStream;
/*      */ import javax.media.rtp.ReceiveStreamListener;
/*      */ import javax.media.rtp.RemoteListener;
/*      */ import javax.media.rtp.SSRCInUseException;
/*      */ import javax.media.rtp.SendStream;
/*      */ import javax.media.rtp.SendStreamListener;
/*      */ import javax.media.rtp.SessionAddress;
/*      */ import javax.media.rtp.SessionListener;
/*      */ import javax.media.rtp.SessionManagerException;
/*      */ import javax.media.rtp.rtcp.SourceDescription;
/*      */ 
/*      */ public class RTPSessionMgr extends RTPManager implements SessionManager {
/*      */   boolean bindtome = false;
/*   44 */   private SSRCCache cache = null;
/*      */   
/*      */   int ttl;
/*      */   
/*   48 */   int sendercount = 0;
/*   49 */   InetAddress localDataAddress = null;
/*   50 */   int localDataPort = 0;
/*   51 */   InetAddress localControlAddress = null;
/*   52 */   int localControlPort = 0;
/*      */ 
/*      */   
/*   55 */   InetAddress dataaddress = null;
/*   56 */   InetAddress controladdress = null;
/*   57 */   int dataport = 0;
/*   58 */   int controlport = 0;
/*   59 */   RTPPushDataSource rtpsource = null;
/*   60 */   RTPPushDataSource rtcpsource = null;
/*   61 */   long defaultSSRC = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SessionAddress localSenderAddress;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SessionAddress localReceiverAddress;
/*      */ 
/*      */ 
/*      */   
/*   75 */   UDPPacketSender udpsender = null;
/*   76 */   RTPPacketSender rtpsender = null;
/*   77 */   RTCPRawSender sender = null;
/*      */ 
/*      */   
/*   80 */   SSRCCacheCleaner cleaner = null;
/*      */ 
/*      */   
/*      */   private boolean unicast = false;
/*      */ 
/*      */   
/*      */   private boolean startedparticipating = false;
/*      */ 
/*      */   
/*      */   private boolean nonparticipating = false;
/*      */ 
/*      */   
/*      */   private boolean nosockets = false;
/*      */ 
/*      */   
/*      */   private boolean started = false;
/*      */   
/*      */   private boolean initialized = false;
/*      */   
/*   99 */   protected Vector sessionlistener = new Vector();
/*      */ 
/*      */   
/*  102 */   protected Vector remotelistener = new Vector();
/*  103 */   protected Vector streamlistener = new Vector();
/*  104 */   protected Vector sendstreamlistener = new Vector();
/*      */   
/*      */   private static final int GET_ALL_PARTICIPANTS = -1;
/*      */   
/*      */   boolean encryption = false;
/*      */   
/*  110 */   SSRCTable dslist = new SSRCTable();
/*      */   
/*      */   StreamSynch streamSynch;
/*      */   
/*  114 */   FormatInfo formatinfo = null;
/*  115 */   DataSource defaultsource = null;
/*  116 */   PushBufferStream defaultstream = null;
/*  117 */   Format defaultformat = null;
/*  118 */   BufferControl buffercontrol = null;
/*  119 */   OverallStats defaultstats = null;
/*  120 */   OverallTransStats transstats = null;
/*      */   
/*  122 */   int defaultsourceid = 0;
/*      */   
/*  124 */   Vector sendstreamlist = new Vector(1);
/*  125 */   RTPTransmitter rtpTransmitter = null;
/*      */   
/*      */   boolean bds = false;
/*  128 */   private static JMFSecurity jmfSecurity = null;
/*      */   private static boolean securityPrivelege = false;
/*  130 */   private Method[] m = new Method[1];
/*  131 */   private Class[] cl = new Class[1];
/*  132 */   private Object[][] args = new Object[1][0];
/*  133 */   Vector peerlist = new Vector();
/*      */   boolean multi_unicast = false;
/*  135 */   Hashtable peerrtplist = new Hashtable(5);
/*  136 */   Hashtable peerrtcplist = new Hashtable(5);
/*      */   
/*      */   static {
/*      */     try {
/*  140 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  141 */       securityPrivelege = true;
/*  142 */     } catch (SecurityException e) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object[] getControls() {
/*  162 */     Object[] c = new Object[1];
/*  163 */     c[0] = this.buffercontrol;
/*  164 */     return c;
/*      */   }
/*      */   
/*      */   public Object getControl(String controlname) {
/*  168 */     if (controlname.equals("javax.media.control.BufferControl"))
/*  169 */       return this.buffercontrol; 
/*  170 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int initSession(SessionAddress localAddress, long defaultSSRC, SourceDescription[] defaultUserDesc, double rtcp_bw_fraction, double rtcp_sender_bw_fraction) throws InvalidSessionAddressException {
/*      */     InetAddress inetAddress;
/*  186 */     if (this.initialized) {
/*  187 */       return -1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  194 */     if (rtcp_bw_fraction == 0.0D) {
/*  195 */       this.nonparticipating = true;
/*      */     }
/*  197 */     this.defaultSSRC = defaultSSRC;
/*  198 */     this.localDataAddress = localAddress.getDataAddress();
/*  199 */     this.localControlAddress = localAddress.getControlAddress();
/*  200 */     this.localDataPort = localAddress.getDataPort();
/*  201 */     this.localControlPort = localAddress.getControlPort();
/*      */ 
/*      */ 
/*      */     
/*  205 */     InetAddress[] addrlist = null;
/*      */ 
/*      */ 
/*      */     
/*  209 */     if (jmfSecurity != null) {
/*      */       try {
/*  211 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  212 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 128);
/*  213 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*  214 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/*  215 */           PolicyEngine.checkPermission(PermissionID.NETIO);
/*  216 */           PolicyEngine.assertPermission(PermissionID.NETIO);
/*      */         }
/*      */       
/*  219 */       } catch (Throwable e) {
/*      */ 
/*      */ 
/*      */         
/*  223 */         jmfSecurity.permissionFailureNotification(128);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/*  229 */       if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*  230 */         Constructor cons = jdk12InetAddressAction.cons;
/*      */         
/*  232 */         inetAddress = (InetAddress)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { null, "getLocalHost", null }) });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  242 */         String hostname = (String)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { inetAddress, "getHostName", null }) });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  252 */         addrlist = (InetAddress[])jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { null, "getAllByName", hostname }) });
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  263 */         inetAddress = InetAddress.getLocalHost();
/*  264 */         String str = inetAddress.getHostName();
/*  265 */         addrlist = InetAddress.getAllByName(str);
/*      */       } 
/*      */     } catch (Throwable e) {
/*      */       
/*  269 */       System.err.println("InitSession : UnknownHostExcpetion " + e.getMessage());
/*      */       
/*  271 */       e.printStackTrace();
/*  272 */       return -1;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  287 */     if (this.localDataAddress == null) {
/*  288 */       this.localDataAddress = inetAddress;
/*      */     }
/*  290 */     if (this.localControlAddress == null) {
/*  291 */       this.localControlAddress = inetAddress;
/*      */     }
/*  293 */     boolean dataok = false;
/*  294 */     boolean ctlok = false;
/*      */     
/*  296 */     int i = 0;
/*  297 */     while (i < addrlist.length && (!dataok || !ctlok)) {
/*  298 */       if (addrlist[i].equals(this.localDataAddress))
/*  299 */         dataok = true; 
/*  300 */       if (addrlist[i].equals(this.localControlAddress))
/*  301 */         ctlok = true; 
/*  302 */       i++;
/*      */     } 
/*      */     
/*  305 */     String s = "Does not belong to any of this hosts local interfaces";
/*      */     
/*  307 */     if (!dataok) {
/*  308 */       throw new InvalidSessionAddressException("Local Data Address" + s);
/*      */     }
/*  310 */     if (!ctlok) {
/*  311 */       throw new InvalidSessionAddressException("Local Control Address" + s);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  320 */     this.cache = new SSRCCache(this);
/*  321 */     this.formatinfo.setCache(this.cache);
/*  322 */     this.cache.rtcp_bw_fraction = rtcp_bw_fraction;
/*  323 */     this.cache.rtcp_sender_bw_fraction = rtcp_sender_bw_fraction;
/*  324 */     this.cache.ourssrc = this.cache.get((int)defaultSSRC, inetAddress, 0, 2);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  329 */     this.cache.ourssrc.setAlive(true);
/*      */     
/*  331 */     if (!isCNAME(defaultUserDesc)) {
/*  332 */       SourceDescription[] newUserDesc = setCNAME(defaultUserDesc);
/*  333 */       this.cache.ourssrc.setSourceDescription(newUserDesc);
/*      */     } else {
/*      */       
/*  336 */       this.cache.ourssrc.setSourceDescription(defaultUserDesc);
/*      */     } 
/*  338 */     this.cache.ourssrc.ssrc = (int)defaultSSRC;
/*  339 */     this.cache.ourssrc.setOurs(true);
/*      */ 
/*      */     
/*  342 */     this.initialized = true;
/*  343 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int initSession(SessionAddress localAddress, SourceDescription[] defaultUserDesc, double rtcp_bw_fraction, double rtcp_sender_bw_fraction) throws InvalidSessionAddressException {
/*  352 */     long defaultSSRC = generateSSRC();
/*      */     
/*  354 */     return initSession(localAddress, defaultSSRC, defaultUserDesc, rtcp_bw_fraction, rtcp_sender_bw_fraction);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int startSession(SessionAddress destAddress, int mcastScope, EncryptionInfo encryptionInfo) throws IOException, InvalidSessionAddressException {
/*  368 */     if (this.started) {
/*  369 */       return -1;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  374 */     if (mcastScope < 1)
/*  375 */       mcastScope = 1; 
/*  376 */     this.ttl = mcastScope;
/*  377 */     if (this.ttl <= 16) {
/*  378 */       this.cache.sessionbandwidth = 384000;
/*  379 */     } else if (this.ttl <= 64) {
/*  380 */       this.cache.sessionbandwidth = 128000;
/*  381 */     } else if (this.ttl <= 128) {
/*  382 */       this.cache.sessionbandwidth = 16000;
/*  383 */     } else if (this.ttl <= 192) {
/*  384 */       this.cache.sessionbandwidth = 6625;
/*      */     } else {
/*  386 */       this.cache.sessionbandwidth = 4000;
/*      */     } 
/*  388 */     this.controlport = destAddress.getControlPort();
/*  389 */     this.dataport = destAddress.getDataPort();
/*      */     
/*  391 */     CheckRTPPorts(this.dataport, this.controlport);
/*      */     
/*  393 */     this.dataaddress = destAddress.getDataAddress();
/*  394 */     this.controladdress = destAddress.getControlAddress();
/*      */     
/*  396 */     if (jmfSecurity != null) {
/*  397 */       String permission = null;
/*      */       try {
/*  399 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  400 */           permission = "read property";
/*  401 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 1);
/*  402 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*      */           
/*  404 */           permission = "connect";
/*  405 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 128);
/*  406 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*  407 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/*  408 */           PolicyEngine.checkPermission(PermissionID.PROPERTY);
/*  409 */           PolicyEngine.assertPermission(PermissionID.PROPERTY);
/*      */           
/*  411 */           PolicyEngine.checkPermission(PermissionID.NETIO);
/*  412 */           PolicyEngine.assertPermission(PermissionID.NETIO);
/*      */         }
/*      */       
/*  415 */       } catch (Throwable e) {
/*      */ 
/*      */ 
/*      */         
/*  419 */         if (permission.startsWith("read")) {
/*  420 */           jmfSecurity.permissionFailureNotification(1);
/*      */         } else {
/*  422 */           jmfSecurity.permissionFailureNotification(128);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  427 */     CheckRTPAddress(this.dataaddress, this.controladdress);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  432 */     RTCPRawReceiver rtcpr = null;
/*  433 */     RTPRawReceiver rtpr = null;
/*  434 */     InetAddress mine = null;
/*      */     
/*      */     try {
/*  437 */       if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*  438 */         Constructor cons = jdk12InetAddressAction.cons;
/*      */         
/*  440 */         mine = (InetAddress)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { null, "getLocalHost", null }) });
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  451 */         mine = InetAddress.getLocalHost();
/*      */       } 
/*      */     } catch (Throwable e) {
/*  454 */       System.err.println("InitSession : UnknownHostExcpetion " + e.getMessage());
/*      */       
/*  456 */       e.printStackTrace();
/*  457 */       return -1;
/*      */     } 
/*      */     
/*  460 */     if (this.dataaddress.equals(mine)) {
/*  461 */       this.unicast = true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  485 */     if (!this.dataaddress.isMulticastAddress() && !this.dataaddress.equals(mine))
/*      */     {
/*  487 */       if (isBroadcast(this.dataaddress) && !Win32()) {
/*  488 */         this.bindtome = false;
/*      */       } else {
/*  490 */         this.bindtome = true;
/*      */       } 
/*      */     }
/*  493 */     if (!this.bindtome) {
/*      */       try {
/*  495 */         rtcpr = new RTCPRawReceiver(this.controlport, this.controladdress.getHostAddress(), this.defaultstats, this.streamSynch);
/*      */ 
/*      */ 
/*      */         
/*  499 */         if (this.dataaddress != null) {
/*  500 */           rtpr = new RTPRawReceiver(this.dataport, this.dataaddress.getHostAddress(), this.defaultstats);
/*      */         }
/*      */       }
/*      */       catch (SocketException e) {
/*      */         
/*  505 */         throw new IOException(e.getMessage());
/*      */       } finally {
/*      */         
/*  508 */         if (this.dataaddress != null && rtpr == null && rtcpr != null) {
/*      */           
/*  510 */           System.err.println("could not create RTCP/RTP raw receivers");
/*  511 */           rtcpr.closeSource();
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  519 */         rtcpr = new RTCPRawReceiver(this.controlport, mine.getHostAddress(), this.defaultstats, this.streamSynch);
/*      */ 
/*      */ 
/*      */         
/*  523 */         if (this.dataaddress != null)
/*      */         {
/*  525 */           rtpr = new RTPRawReceiver(this.dataport, mine.getHostAddress(), this.defaultstats);
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */       catch (SocketException e) {
/*      */         
/*  532 */         throw new IOException(e.getMessage());
/*      */       } finally {
/*      */         
/*  535 */         if (this.dataaddress != null && rtpr == null && rtcpr != null) {
/*      */           
/*  537 */           System.err.println("could not create RTCP/RTP raw receivers");
/*  538 */           rtcpr.closeSource();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  544 */     this.rtpDemultiplexer = new RTPDemultiplexer(this.cache, rtpr, this.streamSynch);
/*  545 */     this.rtcpForwarder = new PacketForwarder((PacketSource)rtcpr, new RTCPReceiver(this.cache));
/*  546 */     if (rtpr != null) {
/*  547 */       this.rtpForwarder = new PacketForwarder((PacketSource)rtpr, (PacketConsumer)new RTPReceiver(this.cache, this.rtpDemultiplexer));
/*      */     }
/*  549 */     this.rtcpForwarder.startPF("RTCP Forwarder for address" + this.controladdress.toString() + "port " + this.controlport);
/*      */     
/*  551 */     if (this.rtpForwarder != null) {
/*  552 */       this.rtpForwarder.startPF("RTP Forwarder for address " + this.dataaddress.toString() + "port " + this.dataport);
/*      */     }
/*      */ 
/*      */     
/*  556 */     this.cleaner = new SSRCCacheCleaner(this.cache, this.streamSynch);
/*      */     
/*  558 */     if (!this.nonparticipating && !this.unicast)
/*      */     {
/*  560 */       if (this.cache.ourssrc != null)
/*      */       {
/*  562 */         this.cache.ourssrc.reporter = startParticipating(this.controlport, this.dataaddress.getHostAddress(), this.cache.ourssrc);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  569 */     this.started = true;
/*  570 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int startSession(SessionAddress localDestAddress, SessionAddress localSenderAddress, SessionAddress remoteDestAddress, EncryptionInfo encryptionInfo) throws IOException, InvalidSessionAddressException {
/*  582 */     if (this.started) {
/*  583 */       return -1;
/*      */     }
/*  585 */     this.localSenderAddress = localSenderAddress;
/*      */     
/*  587 */     this.cache.sessionbandwidth = 384000;
/*      */     
/*  589 */     this.controlport = localDestAddress.getControlPort();
/*  590 */     this.dataport = localDestAddress.getDataPort();
/*      */     
/*  592 */     CheckRTPPorts(this.dataport, this.controlport);
/*      */     
/*  594 */     this.dataaddress = localDestAddress.getDataAddress();
/*  595 */     this.controladdress = localDestAddress.getControlAddress();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  600 */     if (jmfSecurity != null) {
/*  601 */       String permission = null;
/*      */       
/*      */       try {
/*  604 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  605 */           permission = "read property";
/*  606 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 1);
/*  607 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*      */           
/*  609 */           permission = "connect";
/*  610 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 128);
/*  611 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*  612 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/*  613 */           PolicyEngine.checkPermission(PermissionID.PROPERTY);
/*  614 */           PolicyEngine.assertPermission(PermissionID.PROPERTY);
/*      */           
/*  616 */           PolicyEngine.checkPermission(PermissionID.NETIO);
/*  617 */           PolicyEngine.assertPermission(PermissionID.NETIO);
/*      */         }
/*      */       
/*  620 */       } catch (Throwable e) {
/*      */ 
/*      */ 
/*      */         
/*  624 */         if (permission.startsWith("read")) {
/*  625 */           jmfSecurity.permissionFailureNotification(1);
/*      */         } else {
/*  627 */           jmfSecurity.permissionFailureNotification(128);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  632 */     if (this.dataaddress.isMulticastAddress() || this.controladdress.isMulticastAddress() || isBroadcast(this.dataaddress) || isBroadcast(this.controladdress))
/*      */     {
/*      */ 
/*      */       
/*  636 */       throw new InvalidSessionAddressException("Local Address must be UNICAST IP addresses");
/*      */     }
/*  638 */     CheckRTPAddress(this.dataaddress, this.controladdress);
/*      */ 
/*      */ 
/*      */     
/*  642 */     RTCPRawReceiver rtcpr = null;
/*  643 */     RTPRawReceiver rtpr = null;
/*  644 */     InetAddress mine = null;
/*      */     
/*      */     try {
/*  647 */       if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*  648 */         Constructor cons = jdk12InetAddressAction.cons;
/*      */         
/*  650 */         mine = (InetAddress)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { null, "getLocalHost", null }) });
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  661 */         mine = InetAddress.getLocalHost();
/*      */       } 
/*      */     } catch (Throwable e) {
/*  664 */       System.err.println("InitSession : UnknownHostExcpetion " + e.getMessage());
/*      */       
/*  666 */       e.printStackTrace();
/*  667 */       return -1;
/*      */     } 
/*      */     
/*      */     try {
/*  671 */       rtcpr = new RTCPRawReceiver(this.controlport, this.controladdress.getHostAddress(), this.defaultstats, this.streamSynch);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  676 */       if (this.dataaddress != null) {
/*  677 */         rtpr = new RTPRawReceiver(this.dataport, this.dataaddress.getHostAddress(), this.defaultstats);
/*      */       }
/*      */     }
/*      */     catch (SocketException e) {
/*      */       
/*  682 */       throw new IOException(e.getMessage());
/*      */     } finally {
/*  684 */       if (this.dataaddress != null && rtpr == null && rtcpr != null) {
/*      */         
/*  686 */         System.err.println("could not create RTCP/RTP raw receivers");
/*  687 */         rtcpr.closeSource();
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  692 */     this.rtpDemultiplexer = new RTPDemultiplexer(this.cache, rtpr, this.streamSynch);
/*  693 */     this.rtcpForwarder = new PacketForwarder((PacketSource)rtcpr, new RTCPReceiver(this.cache));
/*      */     
/*  695 */     if (rtpr != null) {
/*  696 */       this.rtpForwarder = new PacketForwarder((PacketSource)rtpr, (PacketConsumer)new RTPReceiver(this.cache, this.rtpDemultiplexer));
/*      */     }
/*      */     
/*  699 */     this.rtcpForwarder.startPF("RTCP Forwarder for address" + this.controladdress.toString() + "port " + this.controlport);
/*      */ 
/*      */     
/*  702 */     if (this.rtpForwarder != null) {
/*  703 */       this.rtpForwarder.startPF("RTP Forwarder for address " + this.dataaddress.toString() + "port " + this.dataport);
/*      */     }
/*      */ 
/*      */     
/*  707 */     this.controlport = remoteDestAddress.getControlPort();
/*  708 */     this.dataport = remoteDestAddress.getDataPort();
/*  709 */     CheckRTPPorts(this.dataport, this.controlport);
/*  710 */     this.dataaddress = remoteDestAddress.getDataAddress();
/*  711 */     this.controladdress = remoteDestAddress.getControlAddress();
/*  712 */     if (this.dataaddress.isMulticastAddress() || this.controladdress.isMulticastAddress() || isBroadcast(this.dataaddress) || isBroadcast(this.controladdress))
/*      */     {
/*      */ 
/*      */       
/*  716 */       throw new InvalidSessionAddressException("Remote Address must be UNICAST IP addresses");
/*      */     }
/*  718 */     CheckRTPAddress(this.dataaddress, this.controladdress);
/*      */ 
/*      */     
/*  721 */     this.cleaner = new SSRCCacheCleaner(this.cache, this.streamSynch);
/*      */     
/*  723 */     if (!this.nonparticipating && !this.unicast && 
/*  724 */       this.cache.ourssrc != null) {
/*  725 */       this.cache.ourssrc.reporter = startParticipating(localDestAddress, localSenderAddress, this.cache.ourssrc, rtcpr.socket);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  733 */     this.started = true;
/*  734 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public void addSessionListener(SessionListener listener) {
/*  739 */     if (!this.sessionlistener.contains(listener))
/*  740 */       this.sessionlistener.addElement(listener); 
/*      */   }
/*      */   
/*      */   public void addRemoteListener(RemoteListener listener) {
/*  744 */     if (!this.remotelistener.contains(listener))
/*  745 */       this.remotelistener.addElement(listener); 
/*      */   }
/*      */   
/*      */   public void addReceiveStreamListener(ReceiveStreamListener listener) {
/*  749 */     if (!this.streamlistener.contains(listener))
/*  750 */       this.streamlistener.addElement(listener); 
/*      */   }
/*      */   
/*      */   public void addSendStreamListener(SendStreamListener listener) {
/*  754 */     if (!this.sendstreamlistener.contains(listener))
/*  755 */       this.sendstreamlistener.addElement(listener); 
/*      */   }
/*      */   
/*      */   public void removeSessionListener(SessionListener listener) {
/*  759 */     this.sessionlistener.removeElement(listener);
/*      */   }
/*      */   
/*      */   public void removeRemoteListener(RemoteListener listener) {
/*  763 */     this.remotelistener.removeElement(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeReceiveStreamListener(ReceiveStreamListener listener) {
/*  768 */     this.streamlistener.removeElement(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeSendStreamListener(SendStreamListener listener) {}
/*      */ 
/*      */   
/*      */   public long getDefaultSSRC() {
/*  777 */     return this.defaultSSRC;
/*      */   }
/*      */ 
/*      */   
/*      */   public Vector getRemoteParticipants() {
/*  782 */     Vector participantlist = new Vector();
/*  783 */     RTPSourceInfoCache sic = this.cache.getRTPSICache();
/*  784 */     Hashtable hash = sic.getCacheTable();
/*      */     
/*  786 */     Enumeration elements = hash.elements();
/*  787 */     while (elements.hasMoreElements()) {
/*  788 */       Participant participant = elements.nextElement();
/*  789 */       if (participant != null && participant instanceof javax.media.rtp.RemoteParticipant)
/*      */       {
/*  791 */         participantlist.addElement(participant); } 
/*      */     } 
/*  793 */     return participantlist;
/*      */   }
/*      */ 
/*      */   
/*      */   public Vector getActiveParticipants() {
/*  798 */     Vector participantlist = new Vector();
/*  799 */     RTPSourceInfoCache sic = this.cache.getRTPSICache();
/*  800 */     Hashtable hash = sic.getCacheTable();
/*      */     
/*  802 */     Enumeration elements = hash.elements();
/*  803 */     while (elements.hasMoreElements()) {
/*  804 */       Participant participant = elements.nextElement();
/*  805 */       if (participant != null && participant instanceof LocalParticipant && this.nonparticipating) {
/*      */         continue;
/*      */       }
/*      */       
/*  809 */       Vector streams = participant.getStreams();
/*  810 */       if (streams.size() > 0)
/*  811 */         participantlist.addElement(participant); 
/*      */     } 
/*  813 */     return participantlist;
/*      */   }
/*      */ 
/*      */   
/*      */   public Vector getPassiveParticipants() {
/*  818 */     Vector participantlist = new Vector();
/*  819 */     RTPSourceInfoCache sic = this.cache.getRTPSICache();
/*  820 */     Hashtable hash = sic.getCacheTable();
/*      */     
/*  822 */     Enumeration elements = hash.elements();
/*  823 */     while (elements.hasMoreElements()) {
/*  824 */       Participant participant = elements.nextElement();
/*  825 */       if (participant != null && participant instanceof LocalParticipant && this.nonparticipating) {
/*      */         continue;
/*      */       }
/*      */       
/*  829 */       Vector streams = participant.getStreams();
/*  830 */       if (streams.size() == 0)
/*  831 */         participantlist.addElement(participant); 
/*      */     } 
/*  833 */     return participantlist;
/*      */   }
/*      */   
/*      */   public LocalParticipant getLocalParticipant() {
/*  837 */     RTPSourceInfoCache sic = this.cache.getRTPSICache();
/*  838 */     Hashtable hash = sic.getCacheTable();
/*      */     
/*  840 */     Enumeration elements = hash.elements();
/*  841 */     while (elements.hasMoreElements()) {
/*  842 */       Participant participant = elements.nextElement();
/*  843 */       if (participant != null && !this.nonparticipating && participant instanceof LocalParticipant)
/*      */       {
/*      */         
/*  846 */         return (LocalParticipant)participant; } 
/*      */     } 
/*  848 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Vector getAllParticipants() {
/*  853 */     Vector participantlist = new Vector();
/*  854 */     RTPSourceInfoCache sic = this.cache.getRTPSICache();
/*  855 */     Hashtable hash = sic.getCacheTable();
/*      */     
/*  857 */     Enumeration elements = hash.elements();
/*  858 */     while (elements.hasMoreElements()) {
/*  859 */       Participant participant = elements.nextElement();
/*  860 */       if (participant == null || (
/*  861 */         participant instanceof LocalParticipant && this.nonparticipating))
/*      */         continue; 
/*  863 */       participantlist.addElement(participant);
/*      */     } 
/*      */     
/*  866 */     return participantlist;
/*      */   }
/*      */   
/*      */   public Vector getReceiveStreams() {
/*  870 */     Vector smstreamlist = new Vector();
/*      */ 
/*      */     
/*  873 */     Vector participantlist = getAllParticipants();
/*  874 */     for (int i = 0; i < participantlist.size(); i++) {
/*  875 */       Participant part = participantlist.elementAt(i);
/*      */       
/*  877 */       Vector partstreams = part.getStreams();
/*  878 */       for (int j = 0; j < partstreams.size(); j++) {
/*  879 */         RTPStream stream = partstreams.elementAt(j);
/*      */         
/*  881 */         if (stream instanceof javax.media.rtp.ReceiveStream)
/*  882 */           smstreamlist.addElement(stream); 
/*      */       } 
/*      */     } 
/*  885 */     smstreamlist.trimToSize();
/*  886 */     return smstreamlist;
/*      */   }
/*      */   
/*      */   public Vector getSendStreams() {
/*  890 */     return null;
/*      */   }
/*      */   
/*      */   public RTPStream getStream(long filterssrc) {
/*  894 */     Vector participantlist = null;
/*  895 */     participantlist = getAllParticipants();
/*  896 */     if (participantlist == null)
/*  897 */       return null; 
/*  898 */     for (int i = 0; i < participantlist.size(); i++) {
/*  899 */       RTPSourceInfo si = participantlist.elementAt(i);
/*      */ 
/*      */       
/*  902 */       RTPStream stream = si.getSSRCStream(filterssrc);
/*  903 */       if (stream != null)
/*  904 */         return stream; 
/*      */     } 
/*  906 */     return null;
/*      */   }
/*      */   
/*      */   public int getMulticastScope() {
/*  910 */     return this.ttl;
/*      */   }
/*      */   
/*      */   public void setMulticastScope(int multicastScope) {
/*  914 */     if (multicastScope < 1)
/*  915 */       multicastScope = 1; 
/*  916 */     this.ttl = multicastScope;
/*  917 */     if (this.ttl <= 16) {
/*  918 */       this.cache.sessionbandwidth = 384000;
/*  919 */     } else if (this.ttl <= 64) {
/*  920 */       this.cache.sessionbandwidth = 128000;
/*  921 */     } else if (this.ttl <= 128) {
/*  922 */       this.cache.sessionbandwidth = 16000;
/*  923 */     } else if (this.ttl <= 192) {
/*  924 */       this.cache.sessionbandwidth = 6625;
/*      */     } else {
/*  926 */       this.cache.sessionbandwidth = 4000;
/*      */     } 
/*  928 */     if (this.udpsender != null) {
/*      */       try {
/*  930 */         this.udpsender.setttl(this.ttl);
/*      */       } catch (IOException e) {
/*  932 */         System.err.println("setMulticastScope Exception " + e.getMessage());
/*  933 */         e.printStackTrace();
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   public void closeSession(String reason) {
/*  939 */     stopParticipating(reason, this.cache.ourssrc);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  945 */     if (this.defaultsource != null) {
/*  946 */       this.defaultsource.disconnect();
/*      */     }
/*  948 */     if (this.cache != null) {
/*  949 */       Enumeration e = this.cache.cache.elements();
/*      */       
/*  951 */       while (e.hasMoreElements()) {
/*  952 */         SSRCInfo s = e.nextElement();
/*      */         
/*  954 */         if (s.dstream != null) {
/*  955 */           s.dstream.close();
/*      */         }
/*  957 */         if (s instanceof SendSSRCInfo) {
/*  958 */           ((SendSSRCInfo)s).close();
/*      */         }
/*  960 */         stopParticipating(reason, s);
/*      */       } 
/*      */     } 
/*      */     
/*  964 */     for (int i = 0; i < this.sendstreamlist.size(); i++) {
/*  965 */       removeSendStream(this.sendstreamlist.elementAt(i));
/*      */     }
/*      */     
/*  968 */     if (this.rtpTransmitter != null) {
/*  969 */       this.rtpTransmitter.close();
/*      */     }
/*  971 */     if (this.rtcpForwarder != null) {
/*  972 */       RTCPRawReceiver rtcpr = (RTCPRawReceiver)this.rtcpForwarder.getSource();
/*  973 */       this.rtcpForwarder.close();
/*  974 */       if (rtcpr != null) {
/*  975 */         rtcpr.close();
/*      */       }
/*      */     } 
/*  978 */     if (this.cleaner != null) {
/*  979 */       this.cleaner.stop();
/*      */     }
/*  981 */     if (this.cache != null) {
/*  982 */       this.cache.destroy();
/*      */     }
/*  984 */     if (this.rtpForwarder != null) {
/*  985 */       RTPRawReceiver rtpr = (RTPRawReceiver)this.rtpForwarder.getSource();
/*  986 */       this.rtpForwarder.close();
/*  987 */       if (rtpr != null) {
/*  988 */         rtpr.close();
/*      */       }
/*      */     } 
/*  991 */     if (this.multi_unicast) {
/*  992 */       removeAllPeers();
/*      */     }
/*      */   }
/*      */   
/*      */   public String generateCNAME() {
/*  997 */     return SourceDescription.generateCNAME();
/*      */   }
/*      */ 
/*      */   
/*      */   public long generateSSRC() {
/* 1002 */     long ssrc = TrueRandom.rand();
/* 1003 */     return ssrc;
/*      */   }
/*      */   
/*      */   public SessionAddress getSessionAddress() {
/* 1007 */     SessionAddress destAddress = new SessionAddress(this.dataaddress, this.dataport, this.controladdress, this.controlport);
/*      */ 
/*      */ 
/*      */     
/* 1011 */     return destAddress;
/*      */   }
/*      */   
/*      */   public SessionAddress getLocalSessionAddress() {
/* 1015 */     if (this.newRtpInterface) {
/* 1016 */       return this.localAddress;
/*      */     }
/* 1018 */     SessionAddress localAddr = new SessionAddress(this.localDataAddress, this.localDataPort, this.localControlAddress, this.localControlPort);
/*      */ 
/*      */ 
/*      */     
/* 1022 */     return localAddr;
/*      */   }
/*      */ 
/*      */   
/*      */   public SessionAddress getLocalReceiverAddress() {
/* 1027 */     return this.localReceiverAddress;
/*      */   }
/*      */   
/*      */   public GlobalReceptionStats getGlobalReceptionStats() {
/* 1031 */     return this.defaultstats;
/*      */   }
/*      */   
/*      */   public GlobalTransmissionStats getGlobalTransmissionStats() {
/* 1035 */     return this.transstats;
/*      */   }
/*      */   
/*      */   public void addFormat(Format info, int payload) {
/* 1039 */     if (this.formatinfo != null) {
/* 1040 */       this.formatinfo.add(payload, info);
/*      */     }
/*      */ 
/*      */     
/* 1044 */     if (info != null) {
/* 1045 */       addedList.addElement(info);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1059 */   static FormatInfo supportedList = null;
/* 1060 */   static Vector addedList = new Vector(); private boolean newRtpInterface; private SessionAddress remoteAddress; private SessionAddress localAddress; private RTCPRawReceiver rtcpRawReceiver; private RTPRawReceiver rtpRawReceiver; private PacketForwarder rtpForwarder; private PacketForwarder rtcpForwarder; private RTPDemultiplexer rtpDemultiplexer; private OverallStats overallStats; private boolean participating; private UDPPacketSender udpPacketSender; private Vector remoteAddresses; private RTCPTransmitter rtcpTransmitter; private RTPConnector rtpConnector; private DatagramSocket dataSocket; private DatagramSocket controlSocket; private final int MAX_PORT = 65535;
/*      */   
/*      */   public static boolean formatSupported(Format format) {
/* 1063 */     if (supportedList == null) {
/* 1064 */       supportedList = new FormatInfo();
/*      */     }
/* 1066 */     if (supportedList.getPayload(format) != -1) {
/* 1067 */       return true;
/*      */     }
/*      */     
/* 1070 */     for (int i = 0; i < addedList.size(); i++) {
/* 1071 */       Format fmt = addedList.elementAt(i);
/* 1072 */       if (fmt.matches(format))
/* 1073 */         return true; 
/*      */     } 
/* 1075 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SendStream createSendStream(int ssrc, DataSource ds, int streamindex) throws UnsupportedFormatException, IOException, SSRCInUseException {
/* 1085 */     SSRCInfo i = this.cache.lookup(ssrc);
/* 1086 */     if (i != null) {
/* 1087 */       throw new SSRCInUseException("SSRC supplied is already in use");
/*      */     }
/* 1089 */     int newSSRC = ssrc;
/*      */     
/* 1091 */     if (this.cache.rtcp_bw_fraction == 0.0D) {
/* 1092 */       throw new IOException("Initialized with zero RTP/RTCP outgoing bandwidth. Cannot create a sending stream ");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1098 */     PushBufferStream[] streams = ((PushBufferDataSource)ds).getStreams();
/* 1099 */     PushBufferStream sendstream = streams[streamindex];
/* 1100 */     Format fmt = sendstream.getFormat();
/*      */     
/* 1102 */     int payload = this.formatinfo.getPayload(fmt);
/* 1103 */     if (payload == -1) {
/* 1104 */       throw new UnsupportedFormatException("Format of Stream not supported in RTP Session Manager", fmt);
/*      */     }
/* 1106 */     SSRCInfo info = null;
/*      */ 
/*      */ 
/*      */     
/* 1110 */     if (this.sendercount == 0) {
/* 1111 */       info = new SendSSRCInfo(this.cache.ourssrc);
/* 1112 */       info.ours = true;
/* 1113 */       this.cache.ourssrc = info;
/* 1114 */       this.cache.getMainCache().put(info.ssrc, info);
/*      */     } else {
/*      */       
/* 1117 */       info = this.cache.get(newSSRC, this.dataaddress, this.dataport, 3);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1122 */       info.ours = true;
/*      */ 
/*      */       
/* 1125 */       if (!this.nosockets) {
/* 1126 */         info.reporter = startParticipating(this.controlport, this.controladdress.getHostAddress(), info);
/*      */       }
/*      */       else {
/*      */         
/* 1130 */         info.reporter = startParticipating(this.rtcpsource, info);
/*      */       } 
/*      */     } 
/* 1133 */     info.payloadType = payload;
/*      */     
/* 1135 */     info.sinkstream.setSSRCInfo((SendSSRCInfo)info);
/*      */ 
/*      */ 
/*      */     
/* 1139 */     ((SendSSRCInfo)info).setFormat(fmt);
/*      */     
/* 1141 */     if (fmt instanceof javax.media.format.VideoFormat) {
/* 1142 */       info.clockrate = 90000;
/*      */     }
/* 1144 */     else if (fmt instanceof AudioFormat) {
/* 1145 */       info.clockrate = (int)((AudioFormat)fmt).getSampleRate();
/*      */     } else {
/* 1147 */       throw new UnsupportedFormatException("Format not supported", fmt);
/*      */     } 
/* 1149 */     info.pds = ds;
/* 1150 */     sendstream.setTransferHandler(info.sinkstream);
/*      */     
/* 1152 */     if (this.multi_unicast) {
/* 1153 */       if (this.peerlist.size() > 0) {
/* 1154 */         SessionAddress a = this.peerlist.firstElement();
/* 1155 */         this.dataport = a.getDataPort();
/* 1156 */         this.dataaddress = a.getDataAddress();
/*      */       } else {
/* 1158 */         throw new IOException("At least one peer must be added");
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1163 */     if (this.rtpTransmitter == null) {
/*      */       
/* 1165 */       if (this.rtpConnector != null) {
/*      */ 
/*      */         
/* 1168 */         this.rtpTransmitter = startDataTransmission(this.rtpConnector);
/*      */       }
/* 1170 */       else if (this.nosockets) {
/*      */ 
/*      */         
/* 1173 */         this.rtpTransmitter = startDataTransmission(this.rtpsource);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1178 */         if (this.newRtpInterface) {
/* 1179 */           this.dataport = this.remoteAddress.getDataPort();
/* 1180 */           this.dataaddress = this.remoteAddress.getDataAddress();
/*      */         } 
/*      */         
/* 1183 */         this.rtpTransmitter = startDataTransmission(this.dataport, this.dataaddress.getHostAddress());
/*      */       } 
/*      */ 
/*      */       
/* 1187 */       if (this.rtpTransmitter == null) {
/* 1188 */         throw new IOException("Cannot create a transmitter");
/*      */       }
/*      */     } 
/*      */     
/* 1192 */     info.sinkstream.setTransmitter(this.rtpTransmitter);
/* 1193 */     addSendStream((SendStream)info);
/*      */     
/* 1195 */     if (this.multi_unicast)
/*      */     {
/* 1197 */       for (int j = 0; j < this.peerlist.size(); j++) {
/*      */         
/* 1199 */         SessionAddress peerAddress = this.peerlist.elementAt(j);
/*      */         
/* 1201 */         if (info.sinkstream.transmitter.sender.peerlist == null)
/*      */         {
/* 1203 */           info.sinkstream.transmitter.sender.peerlist = new Vector();
/*      */         }
/*      */         
/* 1206 */         info.sinkstream.transmitter.sender.peerlist.addElement(peerAddress);
/*      */         
/* 1208 */         if (this.cache != null) {
/*      */           
/* 1210 */           Enumeration e = this.cache.cache.elements();
/*      */           
/* 1212 */           while (e.hasMoreElements()) {
/*      */             
/* 1214 */             SSRCInfo s = e.nextElement();
/*      */             
/* 1216 */             if (s instanceof SendSSRCInfo) {
/*      */               
/* 1218 */               s.reporter.transmit.sender.control = true;
/*      */               
/* 1220 */               if (s.reporter.transmit.sender.peerlist == null)
/*      */               {
/* 1222 */                 s.reporter.transmit.sender.peerlist = new Vector();
/*      */               }
/*      */               
/* 1225 */               s.reporter.transmit.sender.peerlist.addElement(peerAddress);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1233 */     info.sinkstream.startStream();
/*      */     
/* 1235 */     NewSendStreamEvent evt = new NewSendStreamEvent(this, (SendStream)info);
/*      */     
/* 1237 */     this.cache.eventhandler.postEvent((RTPEvent)evt);
/*      */     
/* 1239 */     return (SendStream)info;
/*      */   }
/*      */   
/*      */   public SSRCInfo getSSRCInfo(int ssrc) {
/* 1243 */     SSRCInfo info = this.cache.lookup(ssrc);
/* 1244 */     return info;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SendStream createSendStream(DataSource ds, int streamindex) throws IOException, UnsupportedFormatException {
/* 1251 */     int newSSRC = 0;
/*      */ 
/*      */     
/*      */     do {
/* 1255 */       newSSRC = (int)generateSSRC();
/* 1256 */     } while (this.cache.lookup(newSSRC) != null);
/*      */     
/* 1258 */     SendStream s = null;
/*      */ 
/*      */     
/*      */     try {
/* 1262 */       s = createSendStream(newSSRC, ds, streamindex);
/*      */       
/* 1264 */       if (this.newRtpInterface) {
/* 1265 */         setRemoteAddresses();
/*      */       
/*      */       }
/*      */     }
/* 1269 */     catch (SSRCInUseException e) {}
/*      */ 
/*      */     
/* 1272 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int startSession(int mcastScope, EncryptionInfo encryptionInfo) throws IOException {
/* 1278 */     this.multi_unicast = true;
/* 1279 */     if (mcastScope < 1)
/* 1280 */       mcastScope = 1; 
/* 1281 */     this.ttl = mcastScope;
/* 1282 */     if (this.ttl <= 16) {
/* 1283 */       this.cache.sessionbandwidth = 384000;
/* 1284 */     } else if (this.ttl <= 64) {
/* 1285 */       this.cache.sessionbandwidth = 128000;
/* 1286 */     } else if (this.ttl <= 128) {
/* 1287 */       this.cache.sessionbandwidth = 16000;
/* 1288 */     } else if (this.ttl <= 192) {
/* 1289 */       this.cache.sessionbandwidth = 6625;
/*      */     } else {
/* 1291 */       this.cache.sessionbandwidth = 4000;
/*      */     } 
/* 1293 */     this.cleaner = new SSRCCacheCleaner(this.cache, this.streamSynch);
/* 1294 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addPeer(SessionAddress peerAddress) throws IOException, InvalidSessionAddressException {
/* 1300 */     for (int i = 0; i < this.peerlist.size(); i++) {
/*      */       
/* 1302 */       SessionAddress a = this.peerlist.elementAt(i);
/* 1303 */       if (a.equals(peerAddress)) {
/*      */         return;
/*      */       }
/*      */     } 
/* 1307 */     this.peerlist.addElement(peerAddress);
/*      */     
/* 1309 */     CheckRTPPorts(peerAddress.getDataPort(), peerAddress.getControlPort());
/*      */ 
/*      */     
/* 1312 */     if (jmfSecurity != null) {
/* 1313 */       String permission = null;
/*      */       try {
/* 1315 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 1316 */           permission = "read property";
/* 1317 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 1);
/* 1318 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*      */           
/* 1320 */           permission = "connect";
/* 1321 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 128);
/* 1322 */           this.m[0].invoke(this.cl[0], this.args[0]);
/* 1323 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/* 1324 */           PolicyEngine.checkPermission(PermissionID.PROPERTY);
/* 1325 */           PolicyEngine.assertPermission(PermissionID.PROPERTY);
/*      */           
/* 1327 */           PolicyEngine.checkPermission(PermissionID.NETIO);
/* 1328 */           PolicyEngine.assertPermission(PermissionID.NETIO);
/*      */         }
/*      */       
/* 1331 */       } catch (Throwable e) {
/*      */ 
/*      */ 
/*      */         
/* 1335 */         if (permission.startsWith("read")) {
/* 1336 */           jmfSecurity.permissionFailureNotification(1);
/*      */         } else {
/* 1338 */           jmfSecurity.permissionFailureNotification(128);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1346 */     RTCPRawReceiver rtcpr = null;
/* 1347 */     RTPRawReceiver rtpr = null;
/* 1348 */     InetAddress dataadd = peerAddress.getDataAddress();
/* 1349 */     InetAddress controladd = peerAddress.getControlAddress();
/* 1350 */     int datap = peerAddress.getDataPort();
/* 1351 */     int controlp = peerAddress.getControlPort();
/* 1352 */     CheckRTPAddress(dataadd, controladd);
/*      */     
/* 1354 */     InetAddress mine = null;
/*      */ 
/*      */     
/*      */     try {
/* 1358 */       if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/* 1359 */         Constructor cons = jdk12InetAddressAction.cons;
/*      */         
/* 1361 */         mine = (InetAddress)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { null, "getLocalHost", null }) });
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1371 */         mine = InetAddress.getLocalHost();
/*      */       } 
/*      */     } catch (Throwable e) {
/* 1374 */       System.err.println("InitSession : UnknownHostExcpetion " + e.getMessage());
/*      */       
/* 1376 */       e.printStackTrace();
/*      */     } 
/*      */     
/* 1379 */     if (!dataadd.isMulticastAddress() && !dataadd.equals(mine))
/*      */     {
/* 1381 */       if (isBroadcast(dataadd) && !Win32()) {
/* 1382 */         this.bindtome = false;
/*      */       } else {
/* 1384 */         this.bindtome = true;
/*      */       } 
/*      */     }
/* 1387 */     if (!this.bindtome) {
/*      */       try {
/* 1389 */         rtcpr = new RTCPRawReceiver(controlp, controladd.getHostAddress(), this.defaultstats, this.streamSynch);
/*      */ 
/*      */ 
/*      */         
/* 1393 */         if (dataadd != null) {
/* 1394 */           rtpr = new RTPRawReceiver(datap, dataadd.getHostAddress(), this.defaultstats);
/*      */         }
/*      */       }
/*      */       catch (SocketException e) {
/*      */         
/* 1399 */         throw new IOException(e.getMessage());
/*      */       } finally {
/*      */         
/* 1402 */         if (dataadd != null && rtpr == null && rtcpr != null) {
/*      */           
/* 1404 */           System.err.println("could not create RTCP/RTP raw receivers");
/* 1405 */           rtcpr.closeSource();
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */       try {
/* 1410 */         rtcpr = new RTCPRawReceiver(controlp, mine.getHostAddress(), this.defaultstats, this.streamSynch);
/*      */ 
/*      */ 
/*      */         
/* 1414 */         if (dataadd != null) {
/* 1415 */           rtpr = new RTPRawReceiver(datap, mine.getHostAddress(), this.defaultstats);
/*      */         }
/*      */       }
/*      */       catch (SocketException e) {
/*      */         
/* 1420 */         throw new IOException(e.getMessage());
/*      */       } finally {
/*      */         
/* 1423 */         if (dataadd != null && rtpr == null && rtcpr != null) {
/*      */           
/* 1425 */           System.err.println("could not create RTCP/RTP raw receivers");
/* 1426 */           rtcpr.closeSource();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1431 */     PacketForwarder rtcpf = new PacketForwarder((PacketSource)rtcpr, new RTCPReceiver(this.cache));
/*      */     
/* 1433 */     PacketForwarder rtpf = null;
/* 1434 */     if (rtpr != null) {
/* 1435 */       rtpf = new PacketForwarder((PacketSource)rtpr, (PacketConsumer)new RTPReceiver(this.cache, this.rtpDemultiplexer));
/*      */     }
/* 1437 */     rtcpf.startPF("RTCP Forwarder for address" + controladd.toString() + "port " + controlp);
/*      */     
/* 1439 */     if (rtpf != null) {
/* 1440 */       rtpf.startPF("RTP Forwarder for address " + dataadd.toString() + "port " + datap);
/*      */     }
/*      */     
/* 1443 */     this.peerrtplist.put(peerAddress, rtpf);
/* 1444 */     this.peerrtcplist.put(peerAddress, rtcpf);
/*      */     
/* 1446 */     if (this.cache.ourssrc != null) {
/* 1447 */       if (this.cache.ourssrc.reporter == null) {
/* 1448 */         this.controladdress = controladd;
/* 1449 */         this.controlport = controlp;
/*      */         
/* 1451 */         this.cache.ourssrc.reporter = startParticipating(controlp, dataadd.getHostAddress(), this.cache.ourssrc);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1456 */       if (this.cache.ourssrc.reporter.transmit.sender.peerlist == null) {
/* 1457 */         this.cache.ourssrc.reporter.transmit.sender.peerlist = new Vector();
/*      */       }
/*      */     } 
/* 1460 */     this.cache.ourssrc.reporter.transmit.sender.peerlist.addElement(peerAddress);
/*      */ 
/*      */ 
/*      */     
/* 1464 */     if (this.cache != null) {
/* 1465 */       Enumeration e = this.cache.cache.elements();
/* 1466 */       while (e.hasMoreElements()) {
/* 1467 */         SSRCInfo s = e.nextElement();
/* 1468 */         if (s instanceof SendSSRCInfo) {
/* 1469 */           s.reporter.transmit.sender.control = true;
/* 1470 */           if (s.reporter.transmit.sender.peerlist == null) {
/* 1471 */             s.reporter.transmit.sender.peerlist = new Vector();
/* 1472 */             s.reporter.transmit.sender.peerlist.addElement(peerAddress);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1478 */     for (int j = 0; j < this.sendstreamlist.size(); j++) {
/* 1479 */       SendSSRCInfo sendSSRCInfo = this.sendstreamlist.elementAt(j);
/* 1480 */       if (sendSSRCInfo.sinkstream.transmitter.sender.peerlist == null) {
/* 1481 */         sendSSRCInfo.sinkstream.transmitter.sender.peerlist = new Vector();
/* 1482 */         sendSSRCInfo.sinkstream.transmitter.sender.peerlist.addElement(peerAddress);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void removePeer(SessionAddress peerAddress) {
/* 1489 */     PacketForwarder rtpf = (PacketForwarder)this.peerrtplist.get(peerAddress);
/* 1490 */     PacketForwarder rtcpf = (PacketForwarder)this.peerrtplist.get(peerAddress);
/* 1491 */     if (rtpf != null)
/* 1492 */       rtpf.close(); 
/* 1493 */     if (rtcpf != null)
/* 1494 */       rtcpf.close(); 
/* 1495 */     for (int i = 0; i < this.peerlist.size(); i++) {
/* 1496 */       SessionAddress a = this.peerlist.elementAt(i);
/* 1497 */       if (a.equals(peerAddress))
/* 1498 */         this.peerlist.removeElementAt(i); 
/*      */     } 
/*      */   }
/*      */   public void removeAllPeers() {
/* 1502 */     for (int i = 0; i < this.peerlist.size(); i++)
/* 1503 */       removePeer(this.peerlist.elementAt(i)); 
/*      */   }
/*      */   public Vector getPeers() {
/* 1506 */     return this.peerlist;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void addSendStream(SendStream s) {
/* 1513 */     this.sendstreamlist.addElement(s);
/*      */   }
/*      */ 
/*      */   
/*      */   void removeSendStream(SendStream s) {
/* 1518 */     this.sendstreamlist.removeElement(s);
/*      */     
/* 1520 */     if (((SendSSRCInfo)s).sinkstream != null) {
/*      */       
/* 1522 */       ((SendSSRCInfo)s).sinkstream.close();
/* 1523 */       StreamClosedEvent evt = new StreamClosedEvent(this, s);
/*      */       
/* 1525 */       this.cache.eventhandler.postEvent((RTPEvent)evt);
/* 1526 */       stopParticipating("Closed Stream", (SendSSRCInfo)s);
/*      */     } 
/*      */     
/* 1529 */     if (this.sendstreamlist.size() == 0)
/*      */     {
/*      */ 
/*      */       
/* 1533 */       if (this.cache.ourssrc != null) {
/*      */         
/* 1535 */         SSRCInfo info = new PassiveSSRCInfo((getSSRCCache()).ourssrc);
/* 1536 */         this.cache.ourssrc = info;
/* 1537 */         this.cache.getMainCache().put(info.ssrc, info);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private RTPTransmitter startDataTransmission(int port, String address) throws IOException {
/* 1545 */     RTPTransmitter transmitter = null;
/* 1546 */     RTPRawSender sender = null;
/*      */     
/* 1548 */     if (this.localDataPort == -1) {
/* 1549 */       this.udpsender = new UDPPacketSender(this.dataaddress, this.dataport);
/*      */     }
/* 1551 */     else if (this.newRtpInterface) {
/* 1552 */       this.udpsender = new UDPPacketSender(this.rtpRawReceiver.socket);
/*      */     } else {
/* 1554 */       int localDataPort = this.localSenderAddress.getDataPort();
/* 1555 */       InetAddress localDataAddress = this.localSenderAddress.getDataAddress();
/*      */       
/* 1557 */       this.udpsender = new UDPPacketSender(localDataPort, localDataAddress, this.dataaddress, this.dataport);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1564 */     if (this.ttl != 1) {
/* 1565 */       this.udpsender.setttl(this.ttl);
/*      */     }
/*      */     
/* 1568 */     sender = new RTPRawSender(this.dataport, address, this.udpsender);
/*      */ 
/*      */ 
/*      */     
/* 1572 */     transmitter = new RTPTransmitter(this.cache, sender);
/*      */     
/* 1574 */     return transmitter;
/*      */   }
/*      */   
/*      */   private RTPTransmitter startDataTransmission(RTPPushDataSource s) {
/* 1578 */     RTPRawSender sender = null;
/* 1579 */     RTPTransmitter transmitter = null;
/* 1580 */     this.rtpsender = new RTPPacketSender(s);
/* 1581 */     sender = new RTPRawSender(this.rtpsender);
/* 1582 */     transmitter = new RTPTransmitter(this.cache, sender);
/* 1583 */     return transmitter;
/*      */   }
/*      */   
/*      */   private RTPTransmitter startDataTransmission(RTPConnector connector) {
/*      */     try {
/* 1588 */       RTPRawSender sender = null;
/* 1589 */       RTPTransmitter transmitter = null;
/* 1590 */       this.rtpsender = new RTPPacketSender(connector);
/* 1591 */       sender = new RTPRawSender(this.rtpsender);
/* 1592 */       transmitter = new RTPTransmitter(this.cache, sender);
/* 1593 */       return transmitter;
/*      */     } catch (IOException e) {
/* 1595 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void UpdateEncodings(DataSource source) {
/* 1600 */     RTPControlImpl control = (RTPControlImpl)source.getControl("javax.media.rtp.RTPControl");
/*      */ 
/*      */     
/* 1603 */     if (control != null && control.codeclist != null) {
/* 1604 */       Enumeration e = control.codeclist.keys();
/* 1605 */       while (e.hasMoreElements()) {
/* 1606 */         Integer p = e.nextElement();
/* 1607 */         this.formatinfo.add(p.intValue(), (Format)control.codeclist.get(p));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int startSession(RTPPushDataSource rtpsource, RTPPushDataSource rtcpsource, EncryptionInfo info) {
/* 1615 */     if (!this.initialized) {
/* 1616 */       return -1;
/*      */     }
/* 1618 */     if (this.started) {
/* 1619 */       return -1;
/*      */     }
/* 1621 */     this.cache.sessionbandwidth = 384000;
/* 1622 */     RTPRawReceiver rtpr = new RTPRawReceiver(rtpsource, this.defaultstats);
/* 1623 */     RTCPRawReceiver rtcpr = new RTCPRawReceiver(rtcpsource, this.defaultstats, this.streamSynch);
/* 1624 */     this.rtpDemultiplexer = new RTPDemultiplexer(this.cache, rtpr, this.streamSynch);
/* 1625 */     this.rtpForwarder = new PacketForwarder((PacketSource)rtpr, (PacketConsumer)new RTPReceiver(this.cache, this.rtpDemultiplexer));
/*      */ 
/*      */     
/* 1628 */     if (this.rtpForwarder != null) {
/* 1629 */       this.rtpForwarder.startPF("RTP Forwarder " + rtpsource);
/*      */     }
/* 1631 */     this.rtcpForwarder = new PacketForwarder((PacketSource)rtcpr, new RTCPReceiver(this.cache));
/*      */     
/* 1633 */     if (this.rtcpForwarder != null) {
/* 1634 */       this.rtcpForwarder.startPF("RTCP Forwarder " + rtpsource);
/*      */     }
/* 1636 */     this.cleaner = new SSRCCacheCleaner(this.cache, this.streamSynch);
/* 1637 */     if (!this.nonparticipating && 
/* 1638 */       this.cache.ourssrc != null) {
/* 1639 */       this.cache.ourssrc.reporter = startParticipating(rtcpsource, this.cache.ourssrc);
/*      */     }
/* 1641 */     this.started = true;
/* 1642 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addMRL(RTPMediaLocator mrl) {
/* 1758 */     int ssrc = (int)mrl.getSSRC();
/* 1759 */     if (ssrc == 0) {
/*      */       return;
/*      */     }
/*      */     
/* 1763 */     DataSource reqsource = (DataSource)this.dslist.get(ssrc);
/* 1764 */     if (reqsource != null)
/*      */       return; 
/* 1766 */     DataSource newSource = createNewDS(mrl);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isDefaultDSassigned() {
/* 1771 */     return this.bds;
/*      */   }
/*      */   
/*      */   public Format getFormat(int payload) {
/* 1775 */     return this.formatinfo.get(payload);
/*      */   }
/*      */   
/*      */   public void setDefaultDSassigned(int ssrc) {
/* 1779 */     this.bds = true;
/* 1780 */     this.defaultsourceid = ssrc;
/* 1781 */     this.dslist.put(ssrc, this.defaultsource);
/* 1782 */     this.defaultsource.setSSRC(ssrc);
/* 1783 */     this.defaultsource.setMgr(this);
/*      */   }
/*      */   
/*      */   public DataSource createNewDS(int ssrcid) {
/* 1787 */     DataSource source = new DataSource();
/* 1788 */     source.setContentType("raw");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1795 */       source.connect();
/*      */     } catch (IOException e) {
/*      */       
/* 1798 */       e.printStackTrace();
/*      */     } 
/*      */     
/* 1801 */     RTPSourceStream stream = new RTPSourceStream(source);
/* 1802 */     ((BufferControlImpl)this.buffercontrol).addSourceStream(stream);
/* 1803 */     this.dslist.put(ssrcid, source);
/* 1804 */     source.setSSRC(ssrcid);
/* 1805 */     source.setMgr(this);
/* 1806 */     return source;
/*      */   }
/*      */   
/*      */   public DataSource createNewDS(RTPMediaLocator mrl) {
/* 1810 */     DataSource source = new DataSource();
/* 1811 */     source.setContentType("raw");
/*      */     try {
/* 1813 */       source.connect();
/*      */     } catch (IOException e) {
/*      */       
/* 1816 */       System.err.println("IOException in createNewDS() " + e.getMessage());
/* 1817 */       e.printStackTrace();
/*      */     } 
/*      */     
/* 1820 */     RTPSourceStream stream = new RTPSourceStream(source);
/* 1821 */     ((BufferControlImpl)this.buffercontrol).addSourceStream(stream);
/* 1822 */     if (mrl != null && (int)mrl.getSSRC() != 0) {
/* 1823 */       this.dslist.put((int)mrl.getSSRC(), source);
/* 1824 */       source.setSSRC((int)mrl.getSSRC());
/* 1825 */       source.setMgr(this);
/*      */     } else {
/* 1827 */       this.defaultsource = source;
/* 1828 */       this.defaultstream = stream;
/*      */     } 
/*      */     
/* 1831 */     return source;
/*      */   }
/*      */   
/*      */   public DataSource getDataSource(RTPMediaLocator mrl) {
/* 1835 */     if (mrl == null)
/* 1836 */       return this.defaultsource; 
/* 1837 */     int ssrc = (int)mrl.getSSRC();
/* 1838 */     if (ssrc == 0) {
/* 1839 */       return this.defaultsource;
/*      */     }
/* 1841 */     return (DataSource)this.dslist.get(ssrc);
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/*      */     String str;
/* 1847 */     if (this.newRtpInterface) {
/* 1848 */       int controlPort = 0;
/* 1849 */       int dataPort = 0;
/* 1850 */       String address = "";
/*      */       
/* 1852 */       if (this.localAddress != null) {
/* 1853 */         controlPort = this.localAddress.getControlPort();
/* 1854 */         dataPort = this.localAddress.getDataPort();
/* 1855 */         address = this.localAddress.getDataHostAddress();
/*      */       } 
/*      */       
/* 1858 */       str = "RTPManager \n\tSSRCCache  " + this.cache + "\n\tDataport  " + dataPort + "\n\tControlport  " + controlPort + "\n\tAddress  " + address + "\n\tRTPForwarder  " + this.rtpForwarder + "\n\tRTPDemux  " + this.rtpDemultiplexer;
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/* 1866 */       str = "RTPSession Manager  \n\tSSRCCache  " + this.cache + "\n\tDataport  " + this.dataport + "\n\tControlport  " + this.controlport + "\n\tAddress  " + this.dataaddress + "\n\tRTPForwarder  " + this.rtpForwarder + "\n\tRTPDEmux  " + this.rtpDemultiplexer;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1875 */     return str;
/*      */   }
/*      */   
/*      */   public boolean IsNonParticipating() {
/* 1879 */     return this.nonparticipating;
/*      */   }
/*      */   
/*      */   public void startSession() throws IOException {
/* 1883 */     SessionAddress destaddress = new SessionAddress(this.dataaddress, this.dataport, this.controladdress, this.controlport);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1889 */       startSession(destaddress, this.ttl, (EncryptionInfo)null);
/*      */     } catch (SessionManagerException e) {
/*      */       
/* 1892 */       throw new IOException("SessionManager exception " + e.getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void closeSession() {
/* 1902 */     if (this.dslist.isEmpty() || this.nosockets) {
/* 1903 */       closeSession("DataSource disconnected");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeDataSource(DataSource source) {
/* 1909 */     if (source == this.defaultsource) {
/* 1910 */       this.defaultsource = null;
/* 1911 */       this.defaultstream = null;
/* 1912 */       this.defaultsourceid = 0;
/* 1913 */       this.bds = false;
/*      */     } 
/* 1915 */     this.dslist.removeObj(source);
/*      */   }
/*      */ 
/*      */   
/*      */   void startRTCPReports(InetAddress remoteAddress) {
/* 1920 */     if (!this.nonparticipating && !this.startedparticipating) {
/*      */       
/*      */       try {
/*      */         
/* 1924 */         if (this.cache.ourssrc != null)
/*      */         {
/* 1926 */           this.cache.ourssrc.reporter = startParticipating(this.controlport, remoteAddress.getHostAddress(), this.cache.ourssrc);
/*      */         }
/*      */       } catch (IOException e) {
/*      */         
/* 1930 */         System.err.println("startRTCPReports " + e.getMessage());
/* 1931 */         e.printStackTrace();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isUnicast() {
/* 1940 */     return this.unicast;
/*      */   }
/*      */   
/*      */   public void addUnicastAddr(InetAddress destAddress) {
/* 1944 */     if (this.sender != null)
/* 1945 */       this.sender.addDestAddr(destAddress); 
/*      */   }
/*      */   
/*      */   public boolean isSenderDefaultAddr(InetAddress destAddress) {
/* 1949 */     if (this.sender == null)
/* 1950 */       return false; 
/* 1951 */     InetAddress defaultaddr = this.sender.getRemoteAddr();
/* 1952 */     if (defaultaddr.equals(destAddress))
/* 1953 */       return true; 
/* 1954 */     return false;
/*      */   }
/*      */   
/*      */   SSRCCache getSSRCCache() {
/* 1958 */     return this.cache;
/*      */   }
/*      */   
/*      */   void setSessionBandwidth(int bw) {
/* 1962 */     this.cache.sessionbandwidth = bw;
/*      */   }
/*      */ 
/*      */   
/*      */   private String getProperty(String prop) {
/* 1967 */     String value = null;
/* 1968 */     if (jmfSecurity != null) {
/*      */       try {
/* 1970 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 1971 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 1);
/* 1972 */           this.m[0].invoke(this.cl[0], this.args[0]);
/* 1973 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/* 1974 */           PolicyEngine.checkPermission(PermissionID.PROPERTY);
/* 1975 */           PolicyEngine.assertPermission(PermissionID.PROPERTY);
/*      */         }
/*      */       
/* 1978 */       } catch (Throwable e) {
/*      */ 
/*      */ 
/*      */         
/* 1982 */         jmfSecurity.permissionFailureNotification(1);
/*      */       } 
/*      */     }
/*      */     
/*      */     try {
/* 1987 */       if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/* 1988 */         Constructor cons = jdk12PropertyAction.cons;
/* 1989 */         value = (String)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { prop }) });
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/* 1997 */         value = System.getProperty(prop);
/*      */       } 
/* 1999 */     } catch (Throwable e) {}
/*      */     
/* 2001 */     return value;
/*      */   }
/*      */   
/*      */   private SourceDescription[] setSDES() {
/* 2005 */     SourceDescription[] desclist = new SourceDescription[3];
/* 2006 */     if (desclist == null) {
/* 2007 */       return null;
/*      */     }
/* 2009 */     desclist[0] = new SourceDescription(2, getProperty("user.name"), 1, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2015 */     desclist[1] = new SourceDescription(1, SourceDescription.generateCNAME(), 1, false);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2020 */     desclist[2] = new SourceDescription(6, "JMF RTP Player v1.0", 1, false);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2025 */     return desclist;
/*      */   }
/*      */ 
/*      */   
/*      */   private SourceDescription[] setCNAME(SourceDescription[] desclist) {
/* 2030 */     String descval = null;
/* 2031 */     boolean cname = false;
/*      */     
/* 2033 */     if (desclist == null) {
/* 2034 */       desclist = new SourceDescription[1];
/* 2035 */       descval = SourceDescription.generateCNAME();
/* 2036 */       desclist[0] = new SourceDescription(1, descval, 1, false);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2041 */       return desclist;
/*      */     } 
/*      */ 
/*      */     
/* 2045 */     for (int i = 0; i < desclist.length; i++) {
/* 2046 */       int type = desclist[i].getType();
/* 2047 */       descval = desclist[i].getDescription();
/* 2048 */       if (type == 1 && descval == null) {
/*      */         
/* 2050 */         descval = SourceDescription.generateCNAME();
/* 2051 */         cname = true;
/*      */         break;
/*      */       } 
/*      */     } 
/* 2055 */     if (cname) {
/* 2056 */       return desclist;
/*      */     }
/* 2058 */     SourceDescription[] newdesclist = new SourceDescription[desclist.length + 1];
/*      */     
/* 2060 */     newdesclist[0] = new SourceDescription(1, SourceDescription.generateCNAME(), 1, false);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2065 */     int curr = 1;
/* 2066 */     for (int j = 0; j < desclist.length; j++) {
/* 2067 */       newdesclist[curr] = new SourceDescription(desclist[j].getType(), desclist[j].getDescription(), 1, false);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2072 */       curr++;
/*      */     } 
/* 2074 */     return newdesclist;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isCNAME(SourceDescription[] desclist) {
/* 2081 */     String descval = null;
/* 2082 */     boolean cname = false;
/*      */     
/* 2084 */     if (desclist == null)
/* 2085 */       return cname; 
/* 2086 */     for (int i = 0; i < desclist.length; i++) {
/*      */       try {
/* 2088 */         int type = desclist[i].getType();
/* 2089 */         descval = desclist[i].getDescription();
/* 2090 */         if (type == 1 && descval != null)
/*      */         {
/* 2092 */           cname = true;
/*      */         }
/* 2094 */       } catch (Exception e) {}
/*      */     } 
/*      */     
/* 2097 */     return cname;
/*      */   }
/*      */ 
/*      */   
/*      */   private void CheckRTPPorts(int dataport, int controlport) throws InvalidSessionAddressException {
/* 2102 */     if (dataport == 0 || dataport == -1)
/* 2103 */       dataport = controlport - 1; 
/* 2104 */     if (controlport == 0 || controlport == -1)
/* 2105 */       controlport = dataport + 1; 
/* 2106 */     if (dataport != 0 && dataport % 2 != 0)
/* 2107 */       throw new InvalidSessionAddressException("Data Port must be valid and even"); 
/* 2108 */     if (controlport != 0 && controlport % 2 != 1)
/* 2109 */       throw new InvalidSessionAddressException("Control Port must be valid and odd"); 
/* 2110 */     if (controlport != dataport + 1)
/* 2111 */       throw new InvalidSessionAddressException("Control Port must be one higher than the Data Port"); 
/*      */   }
/*      */   
/*      */   private void CheckRTPAddress(InetAddress dataaddress, InetAddress controladdress) throws InvalidSessionAddressException {
/* 2115 */     if (dataaddress == null && controladdress == null) {
/* 2116 */       throw new InvalidSessionAddressException("Data and control addresses are null");
/*      */     }
/* 2118 */     if (controladdress == null && dataaddress != null)
/* 2119 */       controladdress = dataaddress; 
/* 2120 */     if (dataaddress == null && controladdress != null) {
/* 2121 */       dataaddress = controladdress;
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized RTCPReporter startParticipating(RTPPushDataSource dest, SSRCInfo info) {
/* 2126 */     this.startedparticipating = true;
/* 2127 */     this.rtpsender = new RTPPacketSender(dest);
/* 2128 */     RTCPRawSender sender = new RTCPRawSender(this.rtpsender);
/* 2129 */     RTCPTransmitter transmitter = new RTCPTransmitter(this.cache, sender);
/* 2130 */     transmitter.setSSRCInfo(info);
/* 2131 */     RTCPReporter reporter = new RTCPReporter(this.cache, transmitter);
/* 2132 */     return reporter;
/*      */   }
/*      */ 
/*      */   
/*      */   private synchronized RTCPReporter startParticipating(RTPConnector rtpConnector, SSRCInfo info) {
/* 2137 */     this.startedparticipating = true;
/*      */     
/*      */     try {
/* 2140 */       this.rtpsender = new RTPPacketSender(rtpConnector.getControlOutputStream());
/*      */     } catch (IOException e) {
/* 2142 */       e.printStackTrace();
/*      */     } 
/*      */     
/* 2145 */     RTCPRawSender sender = new RTCPRawSender(this.rtpsender);
/* 2146 */     RTCPTransmitter transmitter = new RTCPTransmitter(this.cache, sender);
/* 2147 */     transmitter.setSSRCInfo(info);
/* 2148 */     RTCPReporter reporter = new RTCPReporter(this.cache, transmitter);
/* 2149 */     return reporter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized RTCPReporter startParticipating(int port, String address, SSRCInfo info) throws IOException {
/* 2156 */     this.startedparticipating = true;
/* 2157 */     UDPPacketSender udpsender = null;
/*      */     
/* 2159 */     if (this.localControlPort == -1) {
/* 2160 */       udpsender = new UDPPacketSender(this.controladdress, this.controlport);
/* 2161 */       this.localControlPort = udpsender.getLocalPort();
/* 2162 */       this.localControlAddress = udpsender.getLocalAddress();
/*      */     } else {
/* 2164 */       udpsender = new UDPPacketSender(this.localControlPort, this.localControlAddress, this.controladdress, this.controlport);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2170 */     if (this.ttl != 1) {
/* 2171 */       udpsender.setttl(this.ttl);
/*      */     }
/*      */     
/* 2174 */     RTCPRawSender sender = new RTCPRawSender(port, address, udpsender);
/* 2175 */     RTCPTransmitter transmitter = new RTCPTransmitter(this.cache, sender);
/* 2176 */     transmitter.setSSRCInfo(info);
/* 2177 */     RTCPReporter reporter = new RTCPReporter(this.cache, transmitter);
/* 2178 */     return reporter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized RTCPReporter startParticipating(SessionAddress localReceiverAddress, SessionAddress localSenderAddress, SSRCInfo info, DatagramSocket rtcpSocket) throws IOException {
/* 2186 */     this.localReceiverAddress = localReceiverAddress;
/*      */     
/* 2188 */     this.startedparticipating = true;
/* 2189 */     UDPPacketSender udpsender = null;
/*      */     
/* 2191 */     int localSenderControlPort = localSenderAddress.getControlPort();
/* 2192 */     InetAddress localSenderControlAddress = localSenderAddress.getControlAddress();
/*      */     
/* 2194 */     int localReceiverControlPort = localReceiverAddress.getControlPort();
/* 2195 */     InetAddress localReceiverControlAddress = localReceiverAddress.getControlAddress();
/*      */     
/* 2197 */     if (localSenderControlPort == -1) {
/* 2198 */       udpsender = new UDPPacketSender(localSenderControlAddress, localSenderControlPort);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 2206 */     else if (localSenderControlPort == localReceiverControlPort) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2211 */       udpsender = new UDPPacketSender(rtcpSocket);
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 2218 */       udpsender = new UDPPacketSender(localSenderControlPort, localSenderControlAddress, this.controladdress, this.controlport);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2225 */     if (this.ttl != 1)
/*      */     {
/* 2227 */       udpsender.setttl(this.ttl);
/*      */     }
/*      */     
/* 2230 */     RTCPRawSender sender = new RTCPRawSender(this.controlport, this.controladdress.getHostName(), udpsender);
/*      */ 
/*      */ 
/*      */     
/* 2234 */     RTCPTransmitter transmitter = new RTCPTransmitter(this.cache, sender);
/* 2235 */     transmitter.setSSRCInfo(info);
/*      */     
/* 2237 */     RTCPReporter reporter = new RTCPReporter(this.cache, transmitter);
/*      */     
/* 2239 */     return reporter;
/*      */   }
/*      */ 
/*      */   
/*      */   private synchronized void stopParticipating(String reason, SSRCInfo info) {
/* 2244 */     if (info.reporter != null) {
/*      */       
/* 2246 */       info.reporter.close(reason);
/* 2247 */       info.reporter = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int initSession(SourceDescription[] defaultUserDesc, double rtcp_bw_fraction, double rtcp_sender_bw_fraction) {
/* 2257 */     if (this.initialized) {
/* 2258 */       return -1;
/*      */     }
/* 2260 */     InetAddress host = null;
/*      */     
/* 2262 */     if (rtcp_bw_fraction == 0.0D) {
/* 2263 */       this.nonparticipating = true;
/*      */     }
/*      */     
/* 2266 */     this.defaultSSRC = generateSSRC();
/* 2267 */     this.cache = new SSRCCache(this);
/* 2268 */     this.formatinfo.setCache(this.cache);
/* 2269 */     this.cache.rtcp_bw_fraction = rtcp_bw_fraction;
/* 2270 */     this.cache.rtcp_sender_bw_fraction = rtcp_sender_bw_fraction;
/*      */     
/* 2272 */     if (jmfSecurity != null) {
/*      */       try {
/* 2274 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 2275 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 128);
/* 2276 */           this.m[0].invoke(this.cl[0], this.args[0]);
/* 2277 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/* 2278 */           PolicyEngine.checkPermission(PermissionID.NETIO);
/* 2279 */           PolicyEngine.assertPermission(PermissionID.NETIO);
/*      */         }
/*      */       
/* 2282 */       } catch (Throwable e) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2287 */         jmfSecurity.permissionFailureNotification(128);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 2293 */       if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/* 2294 */         Constructor cons = jdk12InetAddressAction.cons;
/*      */         
/* 2296 */         host = (InetAddress)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { null, "getLocalHost", null }) });
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2306 */         host = InetAddress.getLocalHost();
/*      */       } 
/*      */     } catch (Throwable e) {
/* 2309 */       System.err.println("InitSession : UnknownHostExcpetion " + e.getMessage());
/*      */       
/* 2311 */       e.printStackTrace();
/* 2312 */       return -1;
/*      */     } 
/*      */     
/* 2315 */     this.cache.ourssrc = this.cache.get((int)this.defaultSSRC, null, 0, 2);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2320 */     this.cache.ourssrc.setAlive(true);
/*      */     
/* 2322 */     if (!isCNAME(defaultUserDesc)) {
/* 2323 */       SourceDescription[] newUserDesc = setCNAME(defaultUserDesc);
/* 2324 */       this.cache.ourssrc.setSourceDescription(newUserDesc);
/*      */     } else {
/*      */       
/* 2327 */       this.cache.ourssrc.setSourceDescription(defaultUserDesc);
/*      */     } 
/*      */     
/* 2330 */     this.cache.ourssrc.ssrc = (int)this.defaultSSRC;
/* 2331 */     this.cache.ourssrc.setOurs(true);
/*      */     
/* 2333 */     this.initialized = true;
/* 2334 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isBroadcast(InetAddress checkaddr) {
/* 2343 */     InetAddress mine = null;
/*      */     
/*      */     try {
/* 2346 */       mine = InetAddress.getLocalHost();
/* 2347 */       byte[] addr = mine.getAddress();
/*      */ 
/*      */       
/* 2350 */       int address = addr[3] & 0xFF;
/* 2351 */       address |= addr[2] << 8 & 0xFF00;
/* 2352 */       address |= addr[1] << 16 & 0xFF0000;
/* 2353 */       address |= addr[0] << 24 & 0xFF000000;
/* 2354 */       byte[] dataaddr = checkaddr.getAddress();
/*      */       
/* 2356 */       int daddress = dataaddr[3] & 0xFF;
/* 2357 */       daddress |= dataaddr[2] << 8 & 0xFF00;
/* 2358 */       daddress |= dataaddr[1] << 16 & 0xFF0000;
/* 2359 */       daddress |= dataaddr[0] << 24 & 0xFF000000;
/* 2360 */       if ((address | 0xFF) == daddress) {
/* 2361 */         return true;
/*      */       }
/*      */     } catch (UnknownHostException e) {
/*      */       
/* 2365 */       System.err.println(e.getMessage());
/*      */     } 
/* 2367 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean Win32() {
/* 2372 */     if (System.getProperty("os.name").startsWith("Windows"))
/* 2373 */       return true; 
/* 2374 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RTPSessionMgr()
/*      */   {
/* 2382 */     this.newRtpInterface = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2976 */     this.MAX_PORT = 65535; this.formatinfo = new FormatInfo(); this.buffercontrol = new BufferControlImpl(); this.defaultstats = new OverallStats(); this.transstats = new OverallTransStats(); this.streamSynch = new StreamSynch(); } public RTPSessionMgr(RTPPushDataSource netdatasource) { this.newRtpInterface = false; this.MAX_PORT = 65535; this.nosockets = true; this.rtpsource = netdatasource; if (this.rtpsource instanceof RTPSocket) this.rtcpsource = ((RTPSocket)this.rtpsource).getControlChannel();  this.formatinfo = new FormatInfo(); this.buffercontrol = new BufferControlImpl(); this.defaultstats = new OverallStats(); this.transstats = new OverallTransStats(); DataSource newsource = createNewDS((RTPMediaLocator)null); UpdateEncodings((DataSource)netdatasource); RTPControl contrl = (RTPControl)netdatasource.getControl("javax.media.rtp.RTPControl"); newsource.setControl(contrl); initSession(setSDES(), 0.05D, 0.25D); startSession(this.rtpsource, this.rtcpsource, (EncryptionInfo)null); } public RTPSessionMgr(DataSource configds) throws IOException { this.newRtpInterface = false; this.MAX_PORT = 65535; this.formatinfo = new FormatInfo(); this.buffercontrol = new BufferControlImpl(); this.defaultstats = new OverallStats(); this.transstats = new OverallTransStats(); UpdateEncodings((DataSource)configds); RTPMediaLocator mrl = null; try { mrl = new RTPMediaLocator(configds.getLocator().toString()); } catch (MalformedURLException e) { throw new IOException("RTP URL is Malformed " + e.getMessage()); }  DataSource newsource = createNewDS(mrl); RTPControl contrl = (RTPControl)configds.getControl("javax.media.rtp.RTPControl"); newsource.setControl(contrl); String address = mrl.getSessionAddress(); this.dataport = mrl.getSessionPort(); this.controlport = this.dataport + 1; this.ttl = mrl.getTTL(); if (jmfSecurity != null)
/*      */       try { if (jmfSecurity.getName().startsWith("jmf-security")) { jmfSecurity.requestPermission(this.m, this.cl, this.args, 128); this.m[0].invoke(this.cl[0], this.args[0]); } else if (jmfSecurity.getName().startsWith("internet")) { PolicyEngine.checkPermission(PermissionID.NETIO); PolicyEngine.assertPermission(PermissionID.NETIO); }  } catch (Throwable e) { jmfSecurity.permissionFailureNotification(128); }   try { if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) { Constructor cons = jdk12InetAddressAction.cons; this.dataaddress = (InetAddress)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { null, "getByName", address }) }); } else { this.dataaddress = InetAddress.getByName(address); }  } catch (Throwable e) { e.printStackTrace(); }  this.controladdress = this.dataaddress; SessionAddress localaddr = new SessionAddress(); try { initSession(localaddr, setSDES(), 0.05D, 0.25D); }
/*      */     catch (SessionManagerException e) { throw new IOException("SessionManager exception " + e.getMessage()); }
/* 2979 */      } private int findLocalPorts() { boolean found = false;
/*      */     
/* 2981 */     int port = -1;
/*      */     
/* 2983 */     while (!found) {
/*      */       do {
/* 2985 */         double num = Math.random();
/*      */         
/* 2987 */         port = (int)(num * 65535.0D);
/*      */         
/* 2989 */         if (port % 2 == 0)
/* 2990 */           continue;  port++;
/*      */       }
/* 2992 */       while (port < 1024 || port > 65534);
/*      */ 
/*      */       
/*      */       try {
/* 2996 */         DatagramSocket datagramSocket = new DatagramSocket(port);
/* 2997 */         datagramSocket.close();
/*      */ 
/*      */         
/* 3000 */         datagramSocket = new DatagramSocket(port + 1);
/* 3001 */         datagramSocket.close();
/*      */         
/* 3003 */         found = true;
/*      */       } catch (SocketException e) {
/* 3005 */         found = false;
/*      */       } 
/*      */     } 
/*      */     
/* 3009 */     return port; }
/*      */ 
/*      */   
/*      */   public void initialize(RTPConnector connector) {
/*      */     this.rtpConnector = connector;
/*      */     this.newRtpInterface = true;
/*      */     String cname = SourceDescription.generateCNAME();
/*      */     SourceDescription[] sourceDescription = { new SourceDescription(3, "jmf-user@sun.com", 1, false), new SourceDescription(1, cname, 1, false), new SourceDescription(6, "JMF RTP Player v2.0", 1, false) };
/*      */     int ssrc = (int)generateSSRC();
/*      */     this.ttl = 1;
/*      */     if (this.rtpConnector.getRTCPBandwidthFraction() == 0.0D) {
/*      */       this.participating = false;
/*      */     } else {
/*      */       this.participating = true;
/*      */     } 
/*      */     this.cache = new SSRCCache(this);
/*      */     this.cache.sessionbandwidth = 384000;
/*      */     this.formatinfo.setCache(this.cache);
/*      */     if (this.rtpConnector.getRTCPBandwidthFraction() > 0.0D) {
/*      */       this.cache.rtcp_bw_fraction = this.rtpConnector.getRTCPBandwidthFraction();
/*      */     } else {
/*      */       this.cache.rtcp_bw_fraction = 0.05D;
/*      */     } 
/*      */     if (this.rtpConnector.getRTCPSenderBandwidthFraction() > 0.0D) {
/*      */       this.cache.rtcp_sender_bw_fraction = this.rtpConnector.getRTCPSenderBandwidthFraction();
/*      */     } else {
/*      */       this.cache.rtcp_sender_bw_fraction = 0.25D;
/*      */     } 
/*      */     this.cache.ourssrc = this.cache.get(ssrc, null, 0, 2);
/*      */     this.cache.ourssrc.setAlive(true);
/*      */     if (!isCNAME(sourceDescription)) {
/*      */       SourceDescription[] newUserDesc = setCNAME(sourceDescription);
/*      */       this.cache.ourssrc.setSourceDescription(newUserDesc);
/*      */     } else {
/*      */       this.cache.ourssrc.setSourceDescription(sourceDescription);
/*      */     } 
/*      */     this.cache.ourssrc.ssrc = ssrc;
/*      */     this.cache.ourssrc.setOurs(true);
/*      */     this.initialized = true;
/*      */     this.rtpRawReceiver = new RTPRawReceiver(this.rtpConnector, this.defaultstats);
/*      */     this.rtcpRawReceiver = new RTCPRawReceiver(this.rtpConnector, this.defaultstats, this.streamSynch);
/*      */     this.rtpDemultiplexer = new RTPDemultiplexer(this.cache, this.rtpRawReceiver, this.streamSynch);
/*      */     this.rtpForwarder = new PacketForwarder((PacketSource)this.rtpRawReceiver, (PacketConsumer)new RTPReceiver(this.cache, this.rtpDemultiplexer));
/*      */     if (this.rtpForwarder != null)
/*      */       this.rtpForwarder.startPF("RTP Forwarder: " + this.rtpConnector); 
/*      */     this.rtcpForwarder = new PacketForwarder((PacketSource)this.rtcpRawReceiver, new RTCPReceiver(this.cache));
/*      */     if (this.rtcpForwarder != null)
/*      */       this.rtcpForwarder.startPF("RTCP Forwarder: " + this.rtpConnector); 
/*      */     this.cleaner = new SSRCCacheCleaner(this.cache, this.streamSynch);
/*      */     if (this.participating && this.cache.ourssrc != null)
/*      */       this.cache.ourssrc.reporter = startParticipating(this.rtpConnector, this.cache.ourssrc); 
/*      */   }
/*      */   
/*      */   public void initialize(SessionAddress localAddress) throws InvalidSessionAddressException {
/*      */     String cname = SourceDescription.generateCNAME();
/*      */     SourceDescription[] sourceDescription = { new SourceDescription(3, "jmf-user@sun.com", 1, false), new SourceDescription(1, cname, 1, false), new SourceDescription(6, "JMF RTP Player v2.0", 1, false) };
/*      */     double rtcp_bw_fraction = 0.05D;
/*      */     double rtcp_sender_bw_fraction = 0.25D;
/*      */     SessionAddress[] localAddresses = new SessionAddress[1];
/*      */     localAddresses[0] = localAddress;
/*      */     initialize(localAddresses, sourceDescription, rtcp_bw_fraction, rtcp_sender_bw_fraction, null);
/*      */   }
/*      */   
/*      */   public void initialize(SessionAddress[] localAddresses, SourceDescription[] sourceDescription, double rtcp_bw_fraction, double rtcp_sender_bw_fraction, EncryptionInfo encryptionInfo) throws InvalidSessionAddressException {
/*      */     InetAddress inetAddress;
/*      */     if (this.initialized)
/*      */       return; 
/*      */     this.newRtpInterface = true;
/*      */     this.remoteAddresses = new Vector();
/*      */     int ssrc = (int)generateSSRC();
/*      */     this.ttl = 1;
/*      */     if (rtcp_bw_fraction == 0.0D) {
/*      */       this.participating = false;
/*      */     } else {
/*      */       this.participating = true;
/*      */     } 
/*      */     if (localAddresses.length == 0)
/*      */       throw new InvalidSessionAddressException("At least one local address is required!"); 
/*      */     this.localAddress = localAddresses[0];
/*      */     if (this.localAddress == null)
/*      */       throw new InvalidSessionAddressException("Invalid local address: null"); 
/*      */     InetAddress[] addrlist = null;
/*      */     if (jmfSecurity != null)
/*      */       try {
/*      */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/*      */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 128);
/*      */           this.m[0].invoke(this.cl[0], this.args[0]);
/*      */         } else if (jmfSecurity.getName().startsWith("internet")) {
/*      */           PolicyEngine.checkPermission(PermissionID.NETIO);
/*      */           PolicyEngine.assertPermission(PermissionID.NETIO);
/*      */         } 
/*      */       } catch (Throwable e) {
/*      */         jmfSecurity.permissionFailureNotification(128);
/*      */       }  
/*      */     try {
/*      */       if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*      */         Constructor cons = jdk12InetAddressAction.cons;
/*      */         inetAddress = (InetAddress)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { null, "getLocalHost", null }) });
/*      */         String hostname = (String)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { inetAddress, "getHostName", null }) });
/*      */         addrlist = (InetAddress[])jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { null, "getAllByName", hostname }) });
/*      */       } else {
/*      */         inetAddress = InetAddress.getLocalHost();
/*      */         String str = inetAddress.getHostName();
/*      */         addrlist = InetAddress.getAllByName(str);
/*      */       } 
/*      */     } catch (Throwable e) {
/*      */       System.err.println("Initialize : UnknownHostExcpetion " + e.getMessage());
/*      */       e.printStackTrace();
/*      */       return;
/*      */     } 
/*      */     if (this.localAddress.getDataAddress() == null)
/*      */       this.localAddress.setDataHostAddress(inetAddress); 
/*      */     if (this.localAddress.getControlAddress() == null)
/*      */       this.localAddress.setControlHostAddress(inetAddress); 
/*      */     if (this.localAddress.getDataAddress().isMulticastAddress()) {
/*      */       if (this.localAddress.getControlAddress().isMulticastAddress()) {
/*      */         this.ttl = this.localAddress.getTimeToLive();
/*      */       } else {
/*      */         throw new InvalidSessionAddressException("Invalid multicast address");
/*      */       } 
/*      */     } else {
/*      */       boolean dataOk = false;
/*      */       boolean ctrlOk = false;
/*      */       int i = 0;
/*      */       while (i < addrlist.length && (!dataOk || !ctrlOk)) {
/*      */         if (addrlist[i].equals(this.localAddress.getDataAddress()))
/*      */           dataOk = true; 
/*      */         if (addrlist[i].equals(this.localAddress.getControlAddress()))
/*      */           ctrlOk = true; 
/*      */         i++;
/*      */       } 
/*      */       if (!dataOk) {
/*      */         String s = "Does not belong to any of this hosts local interfaces";
/*      */         throw new InvalidSessionAddressException("Local Data Address" + s);
/*      */       } 
/*      */       if (!ctrlOk) {
/*      */         String s = "Does not belong to any of this hosts local interfaces";
/*      */         throw new InvalidSessionAddressException("Local Control Address" + s);
/*      */       } 
/*      */       if (this.localAddress.getDataPort() == -1) {
/*      */         int dataPort = findLocalPorts();
/*      */         this.localAddress.setDataPort(dataPort);
/*      */         this.localAddress.setControlPort(dataPort + 1);
/*      */       } 
/*      */       if (!this.localAddress.getDataAddress().isMulticastAddress())
/*      */         try {
/*      */           this.dataSocket = new DatagramSocket(this.localAddress.getDataPort(), this.localAddress.getDataAddress());
/*      */         } catch (SocketException e) {
/*      */           throw new InvalidSessionAddressException("Can't open local data port: " + this.localAddress.getDataPort());
/*      */         }  
/*      */       if (!this.localAddress.getControlAddress().isMulticastAddress())
/*      */         try {
/*      */           this.controlSocket = new DatagramSocket(this.localAddress.getControlPort(), this.localAddress.getControlAddress());
/*      */         } catch (SocketException e) {
/*      */           if (this.dataSocket != null)
/*      */             this.dataSocket.close(); 
/*      */           throw new InvalidSessionAddressException("Can't open local control port: " + this.localAddress.getControlPort());
/*      */         }  
/*      */     } 
/*      */     this.cache = new SSRCCache(this);
/*      */     if (this.ttl <= 16) {
/*      */       this.cache.sessionbandwidth = 384000;
/*      */     } else if (this.ttl <= 64) {
/*      */       this.cache.sessionbandwidth = 128000;
/*      */     } else if (this.ttl <= 128) {
/*      */       this.cache.sessionbandwidth = 16000;
/*      */     } else if (this.ttl <= 192) {
/*      */       this.cache.sessionbandwidth = 6625;
/*      */     } else {
/*      */       this.cache.sessionbandwidth = 4000;
/*      */     } 
/*      */     this.formatinfo.setCache(this.cache);
/*      */     this.cache.rtcp_bw_fraction = rtcp_bw_fraction;
/*      */     this.cache.rtcp_sender_bw_fraction = rtcp_sender_bw_fraction;
/*      */     this.cache.ourssrc = this.cache.get(ssrc, inetAddress, 0, 2);
/*      */     this.cache.ourssrc.setAlive(true);
/*      */     if (!isCNAME(sourceDescription)) {
/*      */       SourceDescription[] newUserDesc = setCNAME(sourceDescription);
/*      */       this.cache.ourssrc.setSourceDescription(newUserDesc);
/*      */     } else {
/*      */       this.cache.ourssrc.setSourceDescription(sourceDescription);
/*      */     } 
/*      */     this.cache.ourssrc.ssrc = ssrc;
/*      */     this.cache.ourssrc.setOurs(true);
/*      */     this.initialized = true;
/*      */   }
/*      */   
/*      */   public void addTarget(SessionAddress remoteAddress) throws IOException {
/*      */     this.remoteAddresses.addElement(remoteAddress);
/*      */     if (this.remoteAddresses.size() > 1) {
/*      */       setRemoteAddresses();
/*      */       return;
/*      */     } 
/*      */     this.remoteAddress = remoteAddress;
/*      */     if (jmfSecurity != null) {
/*      */       String permission = null;
/*      */       try {
/*      */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/*      */           permission = "read property";
/*      */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 1);
/*      */           this.m[0].invoke(this.cl[0], this.args[0]);
/*      */           permission = "connect";
/*      */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 128);
/*      */           this.m[0].invoke(this.cl[0], this.args[0]);
/*      */         } else if (jmfSecurity.getName().startsWith("internet")) {
/*      */           PolicyEngine.checkPermission(PermissionID.PROPERTY);
/*      */           PolicyEngine.assertPermission(PermissionID.PROPERTY);
/*      */           PolicyEngine.checkPermission(PermissionID.NETIO);
/*      */           PolicyEngine.assertPermission(PermissionID.NETIO);
/*      */         } 
/*      */       } catch (Throwable e) {
/*      */         if (permission.startsWith("read")) {
/*      */           jmfSecurity.permissionFailureNotification(1);
/*      */         } else {
/*      */           jmfSecurity.permissionFailureNotification(128);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     try {
/*      */       this.rtcpRawReceiver = new RTCPRawReceiver(this.localAddress, remoteAddress, this.defaultstats, this.streamSynch, this.controlSocket);
/*      */       this.rtpRawReceiver = new RTPRawReceiver(this.localAddress, remoteAddress, this.defaultstats, this.dataSocket);
/*      */     } catch (SocketException e) {
/*      */       throw new IOException(e.getMessage());
/*      */     } catch (UnknownHostException e) {
/*      */       throw new IOException(e.getMessage());
/*      */     } 
/*      */     this.rtpDemultiplexer = new RTPDemultiplexer(this.cache, this.rtpRawReceiver, this.streamSynch);
/*      */     this.rtcpForwarder = new PacketForwarder((PacketSource)this.rtcpRawReceiver, new RTCPReceiver(this.cache));
/*      */     if (this.rtpRawReceiver != null)
/*      */       this.rtpForwarder = new PacketForwarder((PacketSource)this.rtpRawReceiver, (PacketConsumer)new RTPReceiver(this.cache, this.rtpDemultiplexer)); 
/*      */     this.rtcpForwarder.startPF("RTCP Forwarder for address" + remoteAddress.getControlHostAddress() + " port " + remoteAddress.getControlPort());
/*      */     if (this.rtpForwarder != null)
/*      */       this.rtpForwarder.startPF("RTP Forwarder for address " + remoteAddress.getDataHostAddress() + " port " + remoteAddress.getDataPort()); 
/*      */     this.cleaner = new SSRCCacheCleaner(this.cache, this.streamSynch);
/*      */     if (this.cache.ourssrc != null && this.participating)
/*      */       this.cache.ourssrc.reporter = startParticipating(this.rtcpRawReceiver.socket); 
/*      */   }
/*      */   
/*      */   private synchronized RTCPReporter startParticipating(DatagramSocket rtcpSocket) throws IOException {
/*      */     UDPPacketSender udpsender = new UDPPacketSender(rtcpSocket);
/*      */     this.udpPacketSender = udpsender;
/*      */     if (this.ttl != 1)
/*      */       udpsender.setttl(this.ttl); 
/*      */     RTCPRawSender sender = new RTCPRawSender(this.remoteAddress.getControlPort(), this.remoteAddress.getControlAddress().getHostName(), udpsender);
/*      */     this.rtcpTransmitter = new RTCPTransmitter(this.cache, sender);
/*      */     this.rtcpTransmitter.setSSRCInfo(this.cache.ourssrc);
/*      */     RTCPReporter reporter = new RTCPReporter(this.cache, this.rtcpTransmitter);
/*      */     this.startedparticipating = true;
/*      */     return reporter;
/*      */   }
/*      */   
/*      */   public void removeTargets(String reason) {
/*      */     if (this.cache != null)
/*      */       stopParticipating(reason, this.cache.ourssrc); 
/*      */     if (this.remoteAddresses != null)
/*      */       this.remoteAddresses.removeAllElements(); 
/*      */     setRemoteAddresses();
/*      */   }
/*      */   
/*      */   public void removeTarget(SessionAddress remoteAddress, String reason) {
/*      */     this.remoteAddresses.removeElement(remoteAddress);
/*      */     setRemoteAddresses();
/*      */     if (this.remoteAddresses.size() == 0 && this.cache != null)
/*      */       stopParticipating(reason, this.cache.ourssrc); 
/*      */   }
/*      */   
/*      */   private void setRemoteAddresses() {
/*      */     if (this.rtpTransmitter != null) {
/*      */       RTPRawSender rtpRawSender = this.rtpTransmitter.getSender();
/*      */       rtpRawSender.setDestAddresses(this.remoteAddresses);
/*      */     } 
/*      */     if (this.rtcpTransmitter != null) {
/*      */       RTCPRawSender rtcpRawSender = this.rtcpTransmitter.getSender();
/*      */       rtcpRawSender.setDestAddresses(this.remoteAddresses);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void dispose() {
/*      */     if (this.rtpConnector != null)
/*      */       this.rtpConnector.close(); 
/*      */     if (this.defaultsource != null)
/*      */       this.defaultsource.disconnect(); 
/*      */     if (this.cache != null) {
/*      */       Enumeration e = this.cache.cache.elements();
/*      */       while (e.hasMoreElements()) {
/*      */         SSRCInfo s = e.nextElement();
/*      */         if (s.dstream != null)
/*      */           s.dstream.close(); 
/*      */         if (s instanceof SendSSRCInfo)
/*      */           ((SendSSRCInfo)s).close(); 
/*      */         stopParticipating("dispose", s);
/*      */       } 
/*      */     } 
/*      */     for (int i = 0; i < this.sendstreamlist.size(); i++)
/*      */       removeSendStream(this.sendstreamlist.elementAt(i)); 
/*      */     if (this.rtpTransmitter != null)
/*      */       this.rtpTransmitter.close(); 
/*      */     if (this.rtcpTransmitter != null)
/*      */       this.rtcpTransmitter.close(); 
/*      */     if (this.rtcpForwarder != null) {
/*      */       RTCPRawReceiver rtcpRawReceiver = (RTCPRawReceiver)this.rtcpForwarder.getSource();
/*      */       this.rtcpForwarder.close();
/*      */       if (rtcpRawReceiver != null)
/*      */         rtcpRawReceiver.close(); 
/*      */     } 
/*      */     if (this.cleaner != null)
/*      */       this.cleaner.stop(); 
/*      */     if (this.cache != null)
/*      */       this.cache.destroy(); 
/*      */     if (this.rtpForwarder != null) {
/*      */       RTPRawReceiver rtpRawReceiver = (RTPRawReceiver)this.rtpForwarder.getSource();
/*      */       this.rtpForwarder.close();
/*      */       if (rtpRawReceiver != null)
/*      */         rtpRawReceiver.close(); 
/*      */     } 
/*      */   }
/*      */   
/*      */   public SessionAddress getRemoteSessionAddress() {
/*      */     return this.remoteAddress;
/*      */   }
/*      */   
/*      */   public int getSSRC() {
/*      */     return 0;
/*      */   }
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTPSessionMgr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */