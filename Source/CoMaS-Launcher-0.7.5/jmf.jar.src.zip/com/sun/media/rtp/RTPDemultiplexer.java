/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import com.sun.media.rtp.util.Packet;
/*    */ import com.sun.media.rtp.util.RTPPacket;
/*    */ import javax.media.Buffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RTPDemultiplexer
/*    */ {
/*    */   private SSRCCache cache;
/*    */   private RTPRawReceiver rtpr;
/*    */   private Buffer buffer;
/*    */   private StreamSynch streamSynch;
/*    */   
/*    */   public RTPDemultiplexer(SSRCCache c, RTPRawReceiver r, StreamSynch streamSynch) {
/* 28 */     this.cache = c;
/* 29 */     this.rtpr = r;
/*    */     
/* 31 */     this.streamSynch = streamSynch;
/*    */     
/* 33 */     this.buffer = new Buffer();
/*    */   }
/*    */   
/*    */   public String consumerString() {
/* 37 */     return "RTP DeMultiplexer";
/*    */   }
/*    */   
/*    */   public void demuxpayload(Packet p) {
/* 41 */     demuxpayload(p);
/*    */   }
/*    */   
/*    */   public void demuxpayload(SourceRTPPacket sp) {
/* 45 */     SSRCInfo info = sp.ssrcinfo;
/* 46 */     RTPPacket p = sp.p;
/*    */     
/* 48 */     info.payloadType = p.payloadType;
/* 49 */     if (info.dstream != null) {
/* 50 */       this.buffer.setData(p.base.data);
/*    */       
/* 52 */       this.buffer.setFlags(0);
/* 53 */       if (p.marker == 1)
/* 54 */         this.buffer.setFlags(this.buffer.getFlags() | 0x800); 
/* 55 */       this.buffer.setLength(p.payloadlength);
/* 56 */       this.buffer.setOffset(p.payloadoffset);
/*    */       
/* 58 */       if (info.dstream.getFormat() instanceof javax.media.format.AudioFormat) {
/*    */         
/* 60 */         long ts = this.streamSynch.calcTimestamp(info.ssrc, p.payloadType, p.timestamp);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 66 */         this.buffer.setTimeStamp(ts);
/*    */       
/*    */       }
/*    */       else {
/*    */         
/* 71 */         long ts = this.streamSynch.calcTimestamp(info.ssrc, p.payloadType, p.timestamp);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 77 */         this.buffer.setTimeStamp(ts);
/*    */       } 
/*    */ 
/*    */ 
/*    */       
/* 82 */       this; this.buffer.setFlags(this.buffer.getFlags() | 0x1000);
/* 83 */       this.buffer.setSequenceNumber(p.seqnum);
/* 84 */       this.buffer.setFormat(info.dstream.getFormat());
/* 85 */       info.dstream.add(this.buffer, info.wrapped, this.rtpr);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTPDemultiplexer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */