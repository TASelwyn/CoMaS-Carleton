package com.sun.media.rtp;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import com.sun.media.JMFSecurity;
import com.sun.media.JMFSecurityManager;
import com.sun.media.rtp.util.UDPPacketSender;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.Vector;

public class RTCPTransmitter {
  RTCPRawSender sender;
  
  OverallStats stats = null;
  
  SSRCCache cache;
  
  int sdescounter = 0;
  
  SSRCInfo ssrcInfo = null;
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] m = new Method[1];
  
  private Class[] cl = new Class[1];
  
  private Object[][] args = new Object[1][0];
  
  static {
    try {
      jmfSecurity = JMFSecurityManager.getJMFSecurity();
      securityPrivelege = true;
    } catch (SecurityException e) {}
  }
  
  public RTCPTransmitter(SSRCCache cache) {
    this.cache = cache;
    this.stats = cache.sm.defaultstats;
  }
  
  public RTCPTransmitter(SSRCCache cache, RTCPRawSender sender) {
    this(cache);
    setSender(sender);
    this.stats = cache.sm.defaultstats;
  }
  
  public RTCPTransmitter(SSRCCache cache, int port, String address) throws UnknownHostException, IOException {
    this(cache, new RTCPRawSender(port, address));
  }
  
  public RTCPTransmitter(SSRCCache cache, int port, String address, UDPPacketSender sender) throws UnknownHostException, IOException {
    this(cache, new RTCPRawSender(port, address, sender));
  }
  
  public void setSender(RTCPRawSender s) {
    this.sender = s;
  }
  
  public void setSSRCInfo(SSRCInfo info) {
    this.ssrcInfo = info;
  }
  
  public RTCPRawSender getSender() {
    return this.sender;
  }
  
  public void close() {
    if (this.sender != null)
      this.sender.closeConsumer(); 
  }
  
  protected void transmit(RTCPCompoundPacket p) {
    try {
      this.sender.sendTo(p);
      if (this.ssrcInfo instanceof SendSSRCInfo) {
        ((SendSSRCInfo)this.ssrcInfo).stats.total_rtcp++;
        this.cache.sm.transstats.rtcp_sent++;
      } 
      this.cache.updateavgrtcpsize(p.length);
      if (this.cache.initial)
        this.cache.initial = false; 
      if (!this.cache.rtcpsent)
        this.cache.rtcpsent = true; 
    } catch (IOException e) {
      this.stats.update(6, 1);
      this.cache.sm.transstats.transmit_failed++;
    } 
  }
  
  public void report() {
    Vector repvec = makereports();
    RTCPPacket[] packets = new RTCPPacket[repvec.size()];
    repvec.copyInto((Object[])packets);
    RTCPCompoundPacket cp = new RTCPCompoundPacket(packets);
    transmit(cp);
  }
  
  public void bye(String reason) {
    if (reason != null) {
      bye(this.ssrcInfo.ssrc, reason.getBytes());
    } else {
      bye(this.ssrcInfo.ssrc, null);
    } 
  }
  
  public void bye(int ssrc, byte[] reason) {
    double d;
    if (!this.cache.rtcpsent)
      return; 
    this.cache.byestate = true;
    Vector repvec = makereports();
    RTCPPacket[] packets = new RTCPPacket[repvec.size() + 1];
    repvec.copyInto((Object[])packets);
    int[] ssrclist = new int[1];
    ssrclist[0] = ssrc;
    RTCPBYEPacket byep = new RTCPBYEPacket(ssrclist, reason);
    packets[packets.length - 1] = byep;
    RTCPCompoundPacket cp = new RTCPCompoundPacket(packets);
    if (jmfSecurity != null)
      try {
        if (jmfSecurity.getName().startsWith("jmf-security")) {
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 128);
          this.m[0].invoke(this.cl[0], this.args[0]);
        } else if (jmfSecurity.getName().startsWith("internet")) {
          PolicyEngine.checkPermission(PermissionID.NETIO);
          PolicyEngine.assertPermission(PermissionID.NETIO);
        } 
      } catch (Throwable e) {
        jmfSecurity.permissionFailureNotification(128);
      }  
    this;
    if (this.cache.aliveCount() > 50) {
      this.cache.reset(byep.length);
      d = this.cache.calcReportInterval(this.ssrcInfo.sender, false);
    } else {
      d = 0.0D;
    } 
    try {
      Thread.sleep((long)d);
    } catch (InterruptedException e) {
      e.printStackTrace();
    } 
    transmit(cp);
    this.sdescounter = 0;
  }
  
  protected Vector makereports() {
    Vector packets = new Vector();
    SSRCInfo ourinfo = this.ssrcInfo;
    boolean senderreport = false;
    if (ourinfo.sender == true)
      senderreport = true; 
    long time = System.currentTimeMillis();
    RTCPReportBlock[] reports = makerecreports(time);
    RTCPReportBlock[] firstrep = reports;
    if (reports.length > 31) {
      firstrep = new RTCPReportBlock[31];
      System.arraycopy(reports, 0, firstrep, 0, 31);
    } 
    if (senderreport) {
      RTCPSRPacket srp = new RTCPSRPacket(ourinfo.ssrc, firstrep);
      packets.addElement(srp);
      long systime = (ourinfo.systime != 0L) ? ourinfo.systime : System.currentTimeMillis();
      long secs = systime / 1000L;
      double msecs = (systime - secs * 1000L) / 1000.0D;
      srp.ntptimestamplsw = (int)(msecs * 4.294967296E9D);
      srp.ntptimestampmsw = secs;
      srp.rtptimestamp = (int)ourinfo.rtptime;
      srp.packetcount = (ourinfo.maxseq - ourinfo.baseseq);
      srp.octetcount = ourinfo.bytesreceived;
    } else {
      RTCPRRPacket rrp = new RTCPRRPacket(ourinfo.ssrc, firstrep);
      packets.addElement(rrp);
    } 
    if (firstrep != reports) {
      int offset = 31;
      while (offset < reports.length) {
        if (reports.length - offset < 31)
          firstrep = new RTCPReportBlock[reports.length - offset]; 
        System.arraycopy(reports, offset, firstrep, 0, firstrep.length);
        RTCPRRPacket rrp = new RTCPRRPacket(ourinfo.ssrc, firstrep);
        packets.addElement(rrp);
        offset += 31;
      } 
    } 
    RTCPSDESPacket sp = new RTCPSDESPacket(new RTCPSDES[1]);
    sp.sdes[0] = new RTCPSDES();
    (sp.sdes[0]).ssrc = this.ssrcInfo.ssrc;
    Vector itemvec = new Vector();
    itemvec.addElement(new RTCPSDESItem(1, ourinfo.sourceInfo.getCNAME()));
    if (this.sdescounter % 3 == 0) {
      if (ourinfo.name != null && ourinfo.name.getDescription() != null)
        itemvec.addElement(new RTCPSDESItem(2, ourinfo.name.getDescription())); 
      if (ourinfo.email != null && ourinfo.email.getDescription() != null)
        itemvec.addElement(new RTCPSDESItem(3, ourinfo.email.getDescription())); 
      if (ourinfo.phone != null && ourinfo.phone.getDescription() != null)
        itemvec.addElement(new RTCPSDESItem(4, ourinfo.phone.getDescription())); 
      if (ourinfo.loc != null && ourinfo.loc.getDescription() != null)
        itemvec.addElement(new RTCPSDESItem(5, ourinfo.loc.getDescription())); 
      if (ourinfo.tool != null && ourinfo.tool.getDescription() != null)
        itemvec.addElement(new RTCPSDESItem(6, ourinfo.tool.getDescription())); 
      if (ourinfo.note != null && ourinfo.note.getDescription() != null)
        itemvec.addElement(new RTCPSDESItem(7, ourinfo.note.getDescription())); 
    } 
    this.sdescounter++;
    (sp.sdes[0]).items = new RTCPSDESItem[itemvec.size()];
    itemvec.copyInto((Object[])(sp.sdes[0]).items);
    packets.addElement(sp);
    return packets;
  }
  
  protected RTCPReportBlock[] makerecreports(long time) {
    Vector reports = new Vector();
    Enumeration enum = this.cache.cache.elements();
    while (enum.hasMoreElements()) {
      SSRCInfo info = enum.nextElement();
      if (info.ours || !info.sender)
        continue; 
      RTCPReportBlock rep = new RTCPReportBlock();
      rep.ssrc = info.ssrc;
      rep.lastseq = (info.maxseq + info.cycles);
      rep.jitter = (int)info.jitter;
      rep.lsr = (int)(info.lastSRntptimestamp >> 32L);
      rep.dlsr = (int)((time - info.lastSRreceiptTime) * 65.536D);
      rep.packetslost = (int)(rep.lastseq - info.baseseq + 1L - info.received);
      if (rep.packetslost < 0)
        rep.packetslost = 0; 
      double frac = (rep.packetslost - info.prevlost) / (rep.lastseq - info.prevmaxseq);
      if (frac < 0.0D)
        frac = 0.0D; 
      rep.fractionlost = (int)(frac * 256.0D);
      info.prevmaxseq = (int)rep.lastseq;
      info.prevlost = rep.packetslost;
      reports.addElement(rep);
    } 
    RTCPReportBlock[] reportsarr = new RTCPReportBlock[reports.size()];
    reports.copyInto((Object[])reportsarr);
    return reportsarr;
  }
}
