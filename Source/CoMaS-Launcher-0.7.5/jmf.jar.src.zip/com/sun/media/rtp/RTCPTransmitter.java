/*     */ package com.sun.media.rtp;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import com.sun.media.rtp.util.UDPPacketSender;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RTCPTransmitter
/*     */ {
/*     */   RTCPRawSender sender;
/*  25 */   OverallStats stats = null;
/*     */   SSRCCache cache;
/*  27 */   int sdescounter = 0;
/*  28 */   SSRCInfo ssrcInfo = null;
/*  29 */   private static JMFSecurity jmfSecurity = null;
/*     */   private static boolean securityPrivelege = false;
/*  31 */   private Method[] m = new Method[1];
/*  32 */   private Class[] cl = new Class[1];
/*  33 */   private Object[][] args = new Object[1][0];
/*     */   
/*     */   static {
/*     */     try {
/*  37 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  38 */       securityPrivelege = true;
/*  39 */     } catch (SecurityException e) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public RTCPTransmitter(SSRCCache cache) {
/*  44 */     this.cache = cache;
/*  45 */     this.stats = cache.sm.defaultstats;
/*     */   }
/*     */   
/*     */   public RTCPTransmitter(SSRCCache cache, RTCPRawSender sender) {
/*  49 */     this(cache);
/*  50 */     setSender(sender);
/*  51 */     this.stats = cache.sm.defaultstats;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RTCPTransmitter(SSRCCache cache, int port, String address) throws UnknownHostException, IOException {
/*  57 */     this(cache, new RTCPRawSender(port, address));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RTCPTransmitter(SSRCCache cache, int port, String address, UDPPacketSender sender) throws UnknownHostException, IOException {
/*  64 */     this(cache, new RTCPRawSender(port, address, sender));
/*     */   }
/*     */   
/*     */   public void setSender(RTCPRawSender s) {
/*  68 */     this.sender = s;
/*     */   }
/*     */   
/*     */   public void setSSRCInfo(SSRCInfo info) {
/*  72 */     this.ssrcInfo = info;
/*     */   }
/*     */   
/*     */   public RTCPRawSender getSender() {
/*  76 */     return this.sender;
/*     */   }
/*     */   
/*     */   public void close() {
/*  80 */     if (this.sender != null)
/*  81 */       this.sender.closeConsumer(); 
/*     */   }
/*     */   
/*     */   protected void transmit(RTCPCompoundPacket p) {
/*     */     try {
/*  86 */       this.sender.sendTo(p);
/*     */       
/*  88 */       if (this.ssrcInfo instanceof SendSSRCInfo) {
/*  89 */         ((SendSSRCInfo)this.ssrcInfo).stats.total_rtcp++;
/*  90 */         this.cache.sm.transstats.rtcp_sent++;
/*     */       } 
/*     */       
/*  93 */       this.cache.updateavgrtcpsize(p.length);
/*     */       
/*  95 */       if (this.cache.initial)
/*  96 */         this.cache.initial = false; 
/*  97 */       if (!this.cache.rtcpsent)
/*  98 */         this.cache.rtcpsent = true; 
/*     */     } catch (IOException e) {
/* 100 */       this.stats.update(6, 1);
/* 101 */       this.cache.sm.transstats.transmit_failed++;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void report() {
/* 106 */     Vector repvec = makereports();
/* 107 */     RTCPPacket[] packets = new RTCPPacket[repvec.size()];
/* 108 */     repvec.copyInto((Object[])packets);
/* 109 */     RTCPCompoundPacket cp = new RTCPCompoundPacket(packets);
/* 110 */     transmit(cp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bye(String reason) {
/* 117 */     if (reason != null) {
/*     */       
/* 119 */       bye(this.ssrcInfo.ssrc, reason.getBytes());
/*     */     } else {
/* 121 */       bye(this.ssrcInfo.ssrc, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bye(int ssrc, byte[] reason) {
/*     */     double d;
/* 130 */     if (!this.cache.rtcpsent) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 135 */     this.cache.byestate = true;
/* 136 */     Vector repvec = makereports();
/* 137 */     RTCPPacket[] packets = new RTCPPacket[repvec.size() + 1];
/* 138 */     repvec.copyInto((Object[])packets);
/* 139 */     int[] ssrclist = new int[1];
/* 140 */     ssrclist[0] = ssrc;
/* 141 */     RTCPBYEPacket byep = new RTCPBYEPacket(ssrclist, reason);
/* 142 */     packets[packets.length - 1] = byep;
/* 143 */     RTCPCompoundPacket cp = new RTCPCompoundPacket(packets);
/*     */     
/* 145 */     if (jmfSecurity != null) {
/*     */       try {
/* 147 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 148 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 128);
/* 149 */           this.m[0].invoke(this.cl[0], this.args[0]);
/* 150 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/* 151 */           PolicyEngine.checkPermission(PermissionID.NETIO);
/* 152 */           PolicyEngine.assertPermission(PermissionID.NETIO);
/*     */         }
/*     */       
/* 155 */       } catch (Throwable e) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 160 */         jmfSecurity.permissionFailureNotification(128);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 171 */     this; if (this.cache.aliveCount() > 50) {
/* 172 */       this.cache.reset(byep.length);
/*     */       
/* 174 */       d = this.cache.calcReportInterval(this.ssrcInfo.sender, false);
/*     */     } else {
/* 176 */       d = 0.0D;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 182 */       Thread.sleep((long)d);
/*     */     } catch (InterruptedException e) {
/* 184 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 187 */     transmit(cp);
/* 188 */     this.sdescounter = 0;
/*     */   }
/*     */   
/*     */   protected Vector makereports() {
/* 192 */     Vector packets = new Vector();
/*     */ 
/*     */     
/* 195 */     SSRCInfo ourinfo = this.ssrcInfo;
/*     */ 
/*     */     
/* 198 */     boolean senderreport = false;
/*     */     
/* 200 */     if (ourinfo.sender == true) {
/* 201 */       senderreport = true;
/*     */     }
/*     */     
/* 204 */     long time = System.currentTimeMillis();
/*     */     
/* 206 */     RTCPReportBlock[] reports = makerecreports(time);
/* 207 */     RTCPReportBlock[] firstrep = reports;
/*     */     
/* 209 */     if (reports.length > 31) {
/* 210 */       firstrep = new RTCPReportBlock[31];
/* 211 */       System.arraycopy(reports, 0, firstrep, 0, 31);
/*     */     } 
/*     */     
/* 214 */     if (senderreport) {
/* 215 */       RTCPSRPacket srp = new RTCPSRPacket(ourinfo.ssrc, firstrep);
/* 216 */       packets.addElement(srp);
/* 217 */       long systime = (ourinfo.systime != 0L) ? ourinfo.systime : System.currentTimeMillis();
/* 218 */       long secs = systime / 1000L;
/* 219 */       double msecs = (systime - secs * 1000L) / 1000.0D;
/* 220 */       srp.ntptimestamplsw = (int)(msecs * 4.294967296E9D);
/* 221 */       srp.ntptimestampmsw = secs;
/* 222 */       srp.rtptimestamp = (int)ourinfo.rtptime;
/* 223 */       srp.packetcount = (ourinfo.maxseq - ourinfo.baseseq);
/* 224 */       srp.octetcount = ourinfo.bytesreceived;
/*     */     } else {
/* 226 */       RTCPRRPacket rrp = new RTCPRRPacket(ourinfo.ssrc, firstrep);
/*     */       
/* 228 */       packets.addElement(rrp);
/*     */     } 
/*     */     
/* 231 */     if (firstrep != reports) {
/* 232 */       int offset = 31;
/*     */       
/* 234 */       while (offset < reports.length) {
/* 235 */         if (reports.length - offset < 31) {
/* 236 */           firstrep = new RTCPReportBlock[reports.length - offset];
/*     */         }
/* 238 */         System.arraycopy(reports, offset, firstrep, 0, firstrep.length);
/*     */ 
/*     */         
/* 241 */         RTCPRRPacket rrp = new RTCPRRPacket(ourinfo.ssrc, firstrep);
/*     */         
/* 243 */         packets.addElement(rrp);
/* 244 */         offset += 31;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 250 */     RTCPSDESPacket sp = new RTCPSDESPacket(new RTCPSDES[1]);
/* 251 */     sp.sdes[0] = new RTCPSDES();
/*     */ 
/*     */ 
/*     */     
/* 255 */     (sp.sdes[0]).ssrc = this.ssrcInfo.ssrc;
/* 256 */     Vector itemvec = new Vector();
/*     */     
/* 258 */     itemvec.addElement(new RTCPSDESItem(1, ourinfo.sourceInfo.getCNAME()));
/*     */     
/* 260 */     if (this.sdescounter % 3 == 0) {
/*     */       
/* 262 */       if (ourinfo.name != null && ourinfo.name.getDescription() != null) {
/* 263 */         itemvec.addElement(new RTCPSDESItem(2, ourinfo.name.getDescription()));
/*     */       }
/*     */       
/* 266 */       if (ourinfo.email != null && ourinfo.email.getDescription() != null) {
/* 267 */         itemvec.addElement(new RTCPSDESItem(3, ourinfo.email.getDescription()));
/*     */       }
/* 269 */       if (ourinfo.phone != null && ourinfo.phone.getDescription() != null) {
/* 270 */         itemvec.addElement(new RTCPSDESItem(4, ourinfo.phone.getDescription()));
/*     */       }
/* 272 */       if (ourinfo.loc != null && ourinfo.loc.getDescription() != null) {
/* 273 */         itemvec.addElement(new RTCPSDESItem(5, ourinfo.loc.getDescription()));
/*     */       }
/* 275 */       if (ourinfo.tool != null && ourinfo.tool.getDescription() != null) {
/* 276 */         itemvec.addElement(new RTCPSDESItem(6, ourinfo.tool.getDescription()));
/*     */       }
/* 278 */       if (ourinfo.note != null && ourinfo.note.getDescription() != null) {
/* 279 */         itemvec.addElement(new RTCPSDESItem(7, ourinfo.note.getDescription()));
/*     */       }
/*     */     } 
/*     */     
/* 283 */     this.sdescounter++;
/* 284 */     (sp.sdes[0]).items = new RTCPSDESItem[itemvec.size()];
/* 285 */     itemvec.copyInto((Object[])(sp.sdes[0]).items);
/* 286 */     packets.addElement(sp);
/* 287 */     return packets;
/*     */   }
/*     */   
/*     */   protected RTCPReportBlock[] makerecreports(long time) {
/* 291 */     Vector reports = new Vector();
/* 292 */     Enumeration enum = this.cache.cache.elements();
/* 293 */     while (enum.hasMoreElements()) {
/* 294 */       SSRCInfo info = enum.nextElement();
/* 295 */       if (info.ours || !info.sender) {
/*     */         continue;
/*     */       }
/* 298 */       RTCPReportBlock rep = new RTCPReportBlock();
/* 299 */       rep.ssrc = info.ssrc;
/* 300 */       rep.lastseq = (info.maxseq + info.cycles);
/* 301 */       rep.jitter = (int)info.jitter;
/* 302 */       rep.lsr = (int)(info.lastSRntptimestamp >> 32L);
/* 303 */       rep.dlsr = (int)((time - info.lastSRreceiptTime) * 65.536D);
/*     */       
/* 305 */       rep.packetslost = (int)(rep.lastseq - info.baseseq + 1L - info.received);
/*     */       
/* 307 */       if (rep.packetslost < 0)
/* 308 */         rep.packetslost = 0; 
/* 309 */       double frac = (rep.packetslost - info.prevlost) / (rep.lastseq - info.prevmaxseq);
/*     */ 
/*     */       
/* 312 */       if (frac < 0.0D) frac = 0.0D; 
/* 313 */       rep.fractionlost = (int)(frac * 256.0D);
/* 314 */       info.prevmaxseq = (int)rep.lastseq;
/* 315 */       info.prevlost = rep.packetslost;
/* 316 */       reports.addElement(rep);
/*     */     } 
/*     */     
/* 319 */     RTCPReportBlock[] reportsarr = new RTCPReportBlock[reports.size()];
/*     */ 
/*     */     
/* 322 */     reports.copyInto((Object[])reportsarr);
/*     */     
/* 324 */     return reportsarr;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTCPTransmitter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */