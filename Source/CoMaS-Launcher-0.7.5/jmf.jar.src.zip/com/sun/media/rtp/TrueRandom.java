/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TrueRandom
/*    */ {
/*    */   public void TrueRandom() {}
/*    */   
/*    */   public static long rand() {
/* 29 */     return System.currentTimeMillis();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\TrueRandom.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */