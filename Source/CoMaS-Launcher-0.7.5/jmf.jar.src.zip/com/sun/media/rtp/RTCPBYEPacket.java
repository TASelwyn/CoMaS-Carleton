/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RTCPBYEPacket
/*    */   extends RTCPPacket
/*    */ {
/*    */   int[] ssrc;
/*    */   byte[] reason;
/*    */   
/*    */   public RTCPBYEPacket(RTCPPacket parent) {
/* 17 */     super(parent);
/* 18 */     this.type = 203;
/*    */   }
/*    */ 
/*    */   
/*    */   public RTCPBYEPacket(int[] ssrc, byte[] reason) {
/* 23 */     this.ssrc = ssrc;
/* 24 */     if (reason != null) {
/* 25 */       this.reason = reason;
/*    */     } else {
/* 27 */       this.reason = new byte[0];
/* 28 */     }  if (ssrc.length > 31)
/* 29 */       throw new IllegalArgumentException("Too many SSRCs"); 
/*    */   }
/*    */   
/*    */   public String toString() {
/* 33 */     return "\tRTCP BYE packet for sync source(s) " + toString(this.ssrc) + " for " + ((this.reason.length > 0) ? ("reason " + new String(this.reason)) : "no reason") + "\n";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString(int[] ints) {
/* 39 */     if (ints.length == 0)
/* 40 */       return "(none)"; 
/* 41 */     String s = "" + ints[0];
/* 42 */     for (int i = 1; i < ints.length; i++)
/* 43 */       s = s + ", " + ints[i]; 
/* 44 */     return s;
/*    */   }
/*    */   
/*    */   public int calcLength() {
/* 48 */     return 4 + (this.ssrc.length << 2) + ((this.reason.length > 0) ? (this.reason.length + 4 & 0xFFFFFFFC) : 0);
/*    */   }
/*    */ 
/*    */   
/*    */   void assemble(DataOutputStream out) throws IOException {
/* 53 */     out.writeByte(128 + this.ssrc.length);
/* 54 */     out.writeByte(203);
/* 55 */     out.writeShort(this.ssrc.length + ((this.reason.length > 0) ? (this.reason.length + 4 >> 2) : 0));
/*    */     
/* 57 */     for (int i = 0; i < this.ssrc.length; i++)
/* 58 */       out.writeInt(this.ssrc[i]); 
/* 59 */     if (this.reason.length > 0) {
/*    */       
/* 61 */       out.writeByte(this.reason.length);
/* 62 */       out.write(this.reason);
/* 63 */       for (int j = (this.reason.length + 4 & 0xFFFFFFFC) - this.reason.length - 1; j > 0; j--)
/* 64 */         out.writeByte(0); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTCPBYEPacket.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */