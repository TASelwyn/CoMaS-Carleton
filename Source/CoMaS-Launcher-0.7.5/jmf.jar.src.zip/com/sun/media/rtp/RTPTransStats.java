/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import javax.media.rtp.TransmissionStats;
/*    */ 
/*    */ public class RTPTransStats implements TransmissionStats {
/*  6 */   protected int total_pdu = 0;
/*  7 */   protected int total_bytes = 0;
/*  8 */   protected int total_rtcp = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getPDUTransmitted() {
/* 17 */     return this.total_pdu;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getBytesTransmitted() {
/* 26 */     return this.total_bytes;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getRTCPSent() {
/* 34 */     return this.total_rtcp;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTPTransStats.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */