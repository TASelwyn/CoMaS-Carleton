package com.sun.media.rtp;

import javax.media.Buffer;
import javax.media.Format;
import javax.media.PlugIn;

public interface Depacketizer extends PlugIn {
  public static final int DEPACKETIZER = 6;
  
  Format[] getSupportedInputFormats();
  
  Format setInputFormat(Format paramFormat);
  
  Format parse(Buffer paramBuffer);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\Depacketizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */