/*     */ package com.sun.media.rtp;
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.rtp.util.Packet;
/*     */ import com.sun.media.rtp.util.PacketConsumer;
/*     */ import com.sun.media.rtp.util.PacketFilter;
/*     */ import com.sun.media.rtp.util.RTPPacket;
/*     */ import com.sun.media.rtp.util.RTPPacketSender;
/*     */ import com.sun.media.rtp.util.UDPPacket;
/*     */ import com.sun.media.rtp.util.UDPPacketSender;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.DatagramSocket;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Vector;
/*     */ import javax.media.rtp.RTPConnector;
/*     */ import javax.media.rtp.SessionAddress;
/*     */ 
/*     */ public class RTPRawSender extends PacketFilter {
/*     */   private InetAddress destaddr;
/*  21 */   private DatagramSocket socket = null; private int destport;
/*  22 */   private RTPConnector rtpConnector = null;
/*     */   
/*     */   public String filtername() {
/*  25 */     return "RTP Raw Packet Sender";
/*     */   }
/*     */ 
/*     */   
/*     */   public RTPRawSender(int port, String address) throws UnknownHostException, IOException {
/*  30 */     this.destaddr = InetAddress.getByName(address);
/*  31 */     this.destport = port;
/*  32 */     this.destAddressList = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public RTPRawSender(int port, String address, UDPPacketSender sender) throws UnknownHostException, IOException {
/*  37 */     this(port, address);
/*     */     
/*  39 */     this.socket = sender.getSocket();
/*  40 */     setConsumer((PacketConsumer)sender);
/*     */     
/*  42 */     this.destAddressList = null;
/*     */   }
/*     */   
/*     */   public RTPRawSender(RTPPacketSender sender) {
/*  46 */     this.rtpConnector = sender.getConnector();
/*  47 */     setConsumer((PacketConsumer)sender);
/*     */   }
/*     */   
/*     */   public InetAddress getRemoteAddr() {
/*  51 */     return this.destaddr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSendBufSize(int size) {
/*     */     try {
/*  60 */       if (this.socket != null) {
/*  61 */         Class cls = this.socket.getClass();
/*  62 */         Method m = cls.getMethod("setSendBufferSize", new Class[] { int.class });
/*     */         
/*  64 */         m.invoke(this.socket, new Object[] { new Integer(size) });
/*     */       
/*     */       }
/*  67 */       else if (this.rtpConnector != null) {
/*  68 */         this.rtpConnector.setSendBufferSize(size);
/*     */       } 
/*     */     } catch (Exception e) {
/*     */       
/*  72 */       Log.comment("Cannot set send buffer size: " + e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSendBufSize() {
/*     */     try {
/*  83 */       if (this.socket != null) {
/*  84 */         Class cls = this.socket.getClass();
/*  85 */         Method m = cls.getMethod("getSendBufferSize", null);
/*  86 */         Integer res = (Integer)m.invoke(this.socket, null);
/*     */ 
/*     */         
/*  89 */         return res.intValue();
/*  90 */       }  if (this.rtpConnector != null) {
/*  91 */         return this.rtpConnector.getSendBufferSize();
/*     */       }
/*  93 */     } catch (Exception e) {}
/*     */ 
/*     */     
/*  96 */     return -1;
/*     */   }
/*     */   
/*     */   public Packet handlePacket(Packet p, int i) {
/* 100 */     return null;
/*     */   }
/*     */   
/*     */   public Packet handlePacket(Packet p, SessionAddress sessionAddress) {
/* 104 */     assemble((RTPPacket)p);
/* 105 */     PacketConsumer consumer = getConsumer();
/* 106 */     if (consumer instanceof RTPPacketSender)
/* 107 */       return p; 
/* 108 */     UDPPacket udpp = new UDPPacket();
/* 109 */     ((Packet)udpp).received = false;
/* 110 */     ((Packet)udpp).data = p.data;
/* 111 */     ((Packet)udpp).offset = p.offset;
/* 112 */     ((Packet)udpp).length = p.length;
/* 113 */     udpp.remoteAddress = sessionAddress.getDataAddress();
/* 114 */     udpp.remotePort = sessionAddress.getDataPort();
/* 115 */     return (Packet)udpp;
/*     */   }
/*     */   
/*     */   public Packet handlePacket(Packet p) {
/* 119 */     assemble((RTPPacket)p);
/* 120 */     PacketConsumer consumer = getConsumer();
/* 121 */     if (consumer instanceof RTPPacketSender)
/* 122 */       return p; 
/* 123 */     UDPPacket udpp = new UDPPacket();
/* 124 */     ((Packet)udpp).received = false;
/* 125 */     ((Packet)udpp).data = p.data;
/* 126 */     ((Packet)udpp).offset = p.offset;
/* 127 */     ((Packet)udpp).length = p.length;
/* 128 */     udpp.remoteAddress = this.destaddr;
/* 129 */     udpp.remotePort = this.destport;
/* 130 */     return (Packet)udpp;
/*     */   }
/*     */   
/*     */   public void assemble(RTPPacket p) {
/* 134 */     int len = p.calcLength();
/* 135 */     p.assemble(len, false);
/*     */   }
/*     */   
/*     */   public void setDestAddresses(Vector destAddresses) {
/* 139 */     this.destAddressList = destAddresses;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTPRawSender.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */