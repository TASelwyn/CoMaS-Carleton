/*     */ package com.sun.media.rtp;
/*     */ 
/*     */ import javax.media.rtp.ReceptionStats;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RTPStats
/*     */   implements ReceptionStats
/*     */ {
/*     */   public static final int PDULOST = 0;
/*     */   public static final int PDUPROCSD = 1;
/*     */   public static final int PDUMISORD = 2;
/*     */   public static final int PDUINVALID = 3;
/*     */   public static final int PDUDUP = 4;
/*     */   public static final int PAYLOAD = 5;
/*     */   public static final int ENCODE = 6;
/*     */   public static final int QSIZE = 7;
/*     */   public static final int PDUDROP = 8;
/*     */   public static final int ADUDROP = 9;
/*  23 */   private int numLost = 0;
/*  24 */   private int numProc = 0;
/*  25 */   private int numMisord = 0;
/*  26 */   private int numInvalid = 0;
/*  27 */   private int numDup = 0;
/*     */   
/*     */   private int payload;
/*     */   private String encodeName;
/*  31 */   private int qSize = 0;
/*  32 */   private int PDUDrop = 0;
/*  33 */   private int ADUDrop = 0;
/*     */ 
/*     */   
/*     */   public synchronized void update(int which) {
/*  37 */     switch (which) {
/*     */       case 0:
/*  39 */         this.numLost++;
/*     */         break;
/*     */       case 1:
/*  42 */         this.numProc++;
/*     */         break;
/*     */       case 2:
/*  45 */         this.numMisord++;
/*     */         break;
/*     */       case 3:
/*  48 */         this.numInvalid++;
/*     */         break;
/*     */       case 4:
/*  51 */         this.numDup++;
/*     */         break;
/*     */     } 
/*     */   }
/*     */   public synchronized void update(int which, int amount) {
/*  56 */     switch (which) {
/*     */       case 0:
/*  58 */         this.numLost += amount;
/*     */         break;
/*     */       
/*     */       case 5:
/*  62 */         this.payload = amount;
/*     */         break;
/*     */       case 7:
/*  65 */         this.qSize = amount;
/*     */         break;
/*     */       case 8:
/*  68 */         this.PDUDrop = amount;
/*     */         break;
/*     */       case 9:
/*  71 */         this.ADUDrop = amount;
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void update(int which, String name) {
/*  79 */     if (which == 6) {
/*  80 */       this.encodeName = name;
/*     */     }
/*     */   }
/*     */   
/*     */   public int getPDUlost() {
/*  85 */     return this.numLost;
/*     */   }
/*     */   
/*     */   public int getPDUProcessed() {
/*  89 */     return this.numProc;
/*     */   }
/*     */   
/*     */   public int getPDUMisOrd() {
/*  93 */     return this.numMisord;
/*     */   }
/*     */   
/*     */   public int getPDUInvalid() {
/*  97 */     return this.numInvalid;
/*     */   }
/*     */   
/*     */   public int getPDUDuplicate() {
/* 101 */     return this.numDup;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPayloadType() {
/* 106 */     return this.payload;
/*     */   }
/*     */   
/*     */   public String getEncodingName() {
/* 110 */     return this.encodeName;
/*     */   }
/*     */   
/*     */   public int getBufferSize() {
/* 114 */     return this.qSize;
/*     */   }
/*     */   
/*     */   public int getPDUDrop() {
/* 118 */     return this.PDUDrop;
/*     */   }
/*     */   
/*     */   public int getADUDrop() {
/* 122 */     return this.ADUDrop;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 126 */     String s = "PDULost " + getPDUlost() + "\nPDUProcessed " + getPDUProcessed() + "\nPDUMisord " + getPDUMisOrd() + "\nPDUInvalid " + getPDUInvalid() + "\nPDUDuplicate " + getPDUDuplicate();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 131 */     return s;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTPStats.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */