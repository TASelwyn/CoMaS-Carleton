/*     */ package com.sun.media.rtp;
/*     */ import com.sun.media.rtp.util.BadFormatException;
/*     */ import com.sun.media.rtp.util.Packet;
/*     */ import com.sun.media.rtp.util.PacketSource;
/*     */ import com.sun.media.rtp.util.RTPPacketReceiver;
/*     */ import com.sun.media.rtp.util.UDPPacketReceiver;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.DatagramSocket;
/*     */ import java.net.SocketException;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Vector;
/*     */ import javax.media.rtp.RTPConnector;
/*     */ import javax.media.rtp.RTPPushDataSource;
/*     */ import javax.media.rtp.SessionAddress;
/*     */ 
/*     */ public class RTCPRawReceiver extends PacketFilter {
/*     */   public DatagramSocket socket;
/*     */   private StreamSynch streamSynch;
/*  21 */   private OverallStats stats = null;
/*     */   
/*     */   public String filtername() {
/*  24 */     return "RTCP Raw Receiver";
/*     */   }
/*     */ 
/*     */   
/*     */   public RTCPRawReceiver() {}
/*     */ 
/*     */   
/*     */   public RTCPRawReceiver(DatagramSocket sock, OverallStats stats, StreamSynch streamSynch) {
/*  32 */     setSource((PacketSource)new UDPPacketReceiver(sock, 1000));
/*  33 */     this.stats = stats;
/*  34 */     this.streamSynch = streamSynch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RTCPRawReceiver(SessionAddress localAddress, SessionAddress remoteAddress, OverallStats stats, StreamSynch streamSynch, DatagramSocket controlSocket) throws UnknownHostException, IOException, SocketException {
/*  44 */     this.streamSynch = streamSynch;
/*  45 */     this.stats = stats;
/*     */     
/*  47 */     UDPPacketReceiver recv = new UDPPacketReceiver(localAddress.getControlPort(), localAddress.getControlHostAddress(), remoteAddress.getControlPort(), remoteAddress.getControlHostAddress(), 1000, controlSocket);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  54 */     setSource((PacketSource)recv);
/*     */     
/*  56 */     this.socket = recv.getSocket();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RTCPRawReceiver(int localPort, String localAddress, OverallStats stats, StreamSynch streamSynch) throws UnknownHostException, IOException, SocketException {
/*  65 */     this.streamSynch = streamSynch;
/*  66 */     this.stats = stats;
/*     */     
/*  68 */     UDPPacketReceiver recv = new UDPPacketReceiver(localPort, localAddress, -1, null, 1000, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  75 */     setSource((PacketSource)recv);
/*     */     
/*  77 */     this.socket = recv.getSocket();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RTCPRawReceiver(RTPPushDataSource networkdatasource, OverallStats stats, StreamSynch streamSynch) {
/*  83 */     this.streamSynch = streamSynch;
/*     */     
/*  85 */     setSource((PacketSource)new RTPPacketReceiver(networkdatasource));
/*     */     
/*  87 */     this.stats = stats;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RTCPRawReceiver(RTPConnector rtpConnector, OverallStats stats, StreamSynch streamSynch) {
/*  93 */     this.streamSynch = streamSynch;
/*     */     
/*     */     try {
/*  96 */       setSource((PacketSource)new RTPPacketReceiver(rtpConnector.getControlInputStream()));
/*     */     } catch (IOException e) {
/*  98 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 101 */     this.stats = stats;
/*     */   }
/*     */   
/*     */   public void close() {
/* 105 */     if (this.socket != null)
/* 106 */       this.socket.close(); 
/* 107 */     if (getSource() instanceof RTPPacketReceiver)
/* 108 */       getSource().closeSource(); 
/*     */   }
/*     */   
/*     */   public Packet handlePacket(Packet p, int i) {
/* 112 */     return null;
/*     */   }
/*     */   
/*     */   public Packet handlePacket(Packet p, SessionAddress a, boolean control) {
/* 116 */     return null;
/*     */   }
/*     */   
/*     */   public Packet handlePacket(Packet p, SessionAddress a) {
/* 120 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Packet handlePacket(Packet p) {
/*     */     RTCPPacket result;
/* 126 */     this.stats.update(0, 1);
/*     */ 
/*     */     
/* 129 */     this.stats.update(11, 1);
/*     */ 
/*     */     
/* 132 */     this.stats.update(1, p.length);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 137 */       result = parse(p);
/*     */     } catch (BadFormatException e) {
/* 139 */       this.stats.update(13, 1);
/*     */       
/* 141 */       return null;
/*     */     } 
/*     */     
/* 144 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public RTCPPacket parse(Packet packet) throws BadFormatException {
/* 149 */     RTCPCompoundPacket base = new RTCPCompoundPacket(packet);
/* 150 */     Vector subpackets = new Vector(2);
/*     */     
/* 152 */     DataInputStream in = new DataInputStream(new ByteArrayInputStream(base.data, base.offset, base.length));
/*     */ 
/*     */     
/*     */     try {
/* 156 */       for (int offset = 0; offset < base.length; offset += length) {
/*     */         RTCPPacket p; RTCPSRPacket srp; int i; RTCPRRPacket rrp; int j; RTCPSDESPacket sdesp; int sdesoff, k; RTCPBYEPacket byep; int m, n; RTCPAPPPacket appp;
/* 158 */         int firstbyte = in.readUnsignedByte();
/* 159 */         if ((firstbyte & 0xC0) != 128) {
/* 160 */           throw new BadFormatException();
/*     */         }
/* 162 */         int type = in.readUnsignedByte();
/* 163 */         int length = in.readUnsignedShort();
/*     */         
/* 165 */         length = length + 1 << 2;
/* 166 */         int padlen = 0;
/* 167 */         if (offset + length > base.length) {
/* 168 */           throw new BadFormatException();
/*     */         }
/* 170 */         if (offset + length == base.length) {
/* 171 */           if ((firstbyte & 0x20) != 0) {
/* 172 */             padlen = base.data[base.offset + base.length - 1] & 0xFF;
/*     */             
/* 174 */             if (padlen == 0) {
/* 175 */               throw new BadFormatException();
/*     */             }
/*     */           } 
/* 178 */         } else if ((firstbyte & 0x20) != 0) {
/* 179 */           throw new BadFormatException();
/*     */         } 
/* 181 */         int inlength = length - padlen;
/* 182 */         firstbyte &= 0x1F;
/*     */ 
/*     */         
/* 185 */         switch (type) {
/*     */           
/*     */           case 200:
/* 188 */             this.stats.update(12, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 193 */             if (inlength != 28 + 24 * firstbyte) {
/*     */               
/* 195 */               this.stats.update(18, 1);
/*     */               
/* 197 */               System.out.println("bad format.");
/* 198 */               throw new BadFormatException();
/*     */             } 
/*     */ 
/*     */             
/* 202 */             srp = new RTCPSRPacket(base);
/* 203 */             p = srp;
/* 204 */             srp.ssrc = in.readInt();
/* 205 */             srp.ntptimestampmsw = in.readInt() & 0xFFFFFFFFL;
/*     */             
/* 207 */             srp.ntptimestamplsw = in.readInt() & 0xFFFFFFFFL;
/*     */             
/* 209 */             srp.rtptimestamp = in.readInt() & 0xFFFFFFFFL;
/*     */             
/* 211 */             srp.packetcount = in.readInt() & 0xFFFFFFFFL;
/* 212 */             srp.octetcount = in.readInt() & 0xFFFFFFFFL;
/*     */             
/* 214 */             srp.reports = new RTCPReportBlock[firstbyte];
/*     */             
/* 216 */             this.streamSynch.update(srp.ssrc, srp.rtptimestamp, srp.ntptimestampmsw, srp.ntptimestamplsw);
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 221 */             for (i = 0; i < srp.reports.length; i++) {
/* 222 */               RTCPReportBlock report = new RTCPReportBlock();
/*     */               
/* 224 */               srp.reports[i] = report;
/* 225 */               report.ssrc = in.readInt();
/*     */               
/* 227 */               long val = in.readInt();
/*     */               
/* 229 */               val &= 0xFFFFFFFFL;
/*     */               
/* 231 */               report.fractionlost = (int)(val >> 24L);
/*     */               
/* 233 */               report.packetslost = (int)(val & 0xFFFFFFL);
/*     */               
/* 235 */               report.lastseq = in.readInt() & 0xFFFFFFFFL;
/* 236 */               report.jitter = in.readInt();
/* 237 */               report.lsr = in.readInt() & 0xFFFFFFFFL;
/* 238 */               report.dlsr = in.readInt() & 0xFFFFFFFFL;
/*     */             } 
/*     */             break;
/*     */           case 201:
/* 242 */             if (inlength != 8 + 24 * firstbyte) {
/*     */               
/* 244 */               this.stats.update(15, 1);
/* 245 */               throw new BadFormatException();
/*     */             } 
/*     */             
/* 248 */             rrp = new RTCPRRPacket(base);
/* 249 */             p = rrp;
/* 250 */             rrp.ssrc = in.readInt();
/* 251 */             rrp.reports = new RTCPReportBlock[firstbyte];
/*     */             
/* 253 */             for (j = 0; j < rrp.reports.length; j++) {
/* 254 */               RTCPReportBlock report = new RTCPReportBlock();
/* 255 */               rrp.reports[j] = report;
/* 256 */               report.ssrc = in.readInt();
/*     */               
/* 258 */               long val = in.readInt();
/*     */               
/* 260 */               val &= 0xFFFFFFFFL;
/*     */               
/* 262 */               report.fractionlost = (int)(val >> 24L);
/*     */               
/* 264 */               report.packetslost = (int)(val & 0xFFFFFFL);
/*     */               
/* 266 */               report.lastseq = in.readInt() & 0xFFFFFFFFL;
/* 267 */               report.jitter = in.readInt();
/* 268 */               report.lsr = in.readInt() & 0xFFFFFFFFL;
/* 269 */               report.dlsr = in.readInt() & 0xFFFFFFFFL;
/*     */             } 
/*     */             break;
/*     */           case 202:
/* 273 */             sdesp = new RTCPSDESPacket(base);
/* 274 */             p = sdesp;
/* 275 */             sdesp.sdes = new RTCPSDES[firstbyte];
/* 276 */             sdesoff = 4;
/* 277 */             for (k = 0; k < sdesp.sdes.length; k++) {
/* 278 */               RTCPSDES chunk = new RTCPSDES();
/* 279 */               sdesp.sdes[k] = chunk;
/* 280 */               chunk.ssrc = in.readInt();
/* 281 */               sdesoff += 5;
/* 282 */               Vector items = new Vector();
/*     */               
/* 284 */               boolean gotcname = false;
/*     */               
/* 286 */               while ((n = in.readUnsignedByte()) != 0) {
/* 287 */                 if (n < 1 || n > 8) {
/*     */                   
/* 289 */                   this.stats.update(16, 1);
/* 290 */                   throw new BadFormatException();
/*     */                 } 
/*     */                 
/* 293 */                 if (n == 1) {
/* 294 */                   gotcname = true;
/*     */                 }
/* 296 */                 RTCPSDESItem item = new RTCPSDESItem();
/* 297 */                 items.addElement(item);
/* 298 */                 item.type = n;
/* 299 */                 int sdeslen = in.readUnsignedByte();
/* 300 */                 item.data = new byte[sdeslen];
/* 301 */                 in.readFully(item.data);
/* 302 */                 sdesoff += 2 + sdeslen;
/*     */               } 
/*     */               
/* 305 */               if (!gotcname) {
/* 306 */                 this.stats.update(16, 1);
/* 307 */                 throw new BadFormatException();
/*     */               } 
/*     */               
/* 310 */               chunk.items = new RTCPSDESItem[items.size()];
/* 311 */               items.copyInto((Object[])chunk.items);
/* 312 */               if ((sdesoff & 0x3) != 0) {
/* 313 */                 in.skip((4 - (sdesoff & 0x3)));
/* 314 */                 sdesoff = sdesoff + 3 & 0xFFFFFFFC;
/*     */               } 
/*     */             } 
/* 317 */             if (inlength != sdesoff) {
/* 318 */               this.stats.update(16, 1);
/* 319 */               throw new BadFormatException();
/*     */             } 
/*     */             break;
/*     */           case 203:
/* 323 */             byep = new RTCPBYEPacket(base);
/* 324 */             p = byep;
/* 325 */             byep.ssrc = new int[firstbyte];
/*     */             
/* 327 */             for (m = 0; m < byep.ssrc.length; m++) {
/* 328 */               byep.ssrc[m] = in.readInt();
/*     */             }
/*     */             
/* 331 */             if (inlength > 4 + 4 * firstbyte) {
/* 332 */               n = in.readUnsignedByte();
/* 333 */               byep.reason = new byte[n];
/* 334 */               n++;
/*     */             } else {
/*     */               
/* 337 */               n = 0;
/* 338 */               byep.reason = new byte[0];
/*     */             } 
/*     */             
/* 341 */             n = n + 3 & 0xFFFFFFFC;
/*     */             
/* 343 */             if (inlength != 4 + 4 * firstbyte + n) {
/* 344 */               this.stats.update(17, 1);
/* 345 */               throw new BadFormatException();
/*     */             } 
/* 347 */             in.readFully(byep.reason);
/* 348 */             in.skip((n - byep.reason.length));
/*     */             break;
/*     */           case 204:
/* 351 */             if (inlength < 12) {
/* 352 */               throw new BadFormatException();
/*     */             }
/* 354 */             appp = new RTCPAPPPacket(base);
/* 355 */             p = appp;
/* 356 */             appp.ssrc = in.readInt();
/* 357 */             appp.name = in.readInt();
/* 358 */             appp.subtype = firstbyte;
/* 359 */             appp.data = new byte[inlength - 12];
/* 360 */             in.readFully(appp.data);
/* 361 */             in.skip((inlength - 12 - appp.data.length));
/*     */             break;
/*     */ 
/*     */           
/*     */           default:
/* 366 */             this.stats.update(14, 1);
/* 367 */             throw new BadFormatException();
/*     */         } 
/* 369 */         p.offset = offset;
/* 370 */         p.length = length;
/* 371 */         subpackets.addElement(p);
/* 372 */         in.skipBytes(padlen);
/*     */       } 
/*     */     } catch (EOFException e) {
/*     */       
/* 376 */       throw new BadFormatException("Unexpected end of RTCP packet");
/*     */     } catch (IOException e) {
/*     */       
/* 379 */       throw new IllegalArgumentException("Impossible Exception");
/*     */     } 
/*     */     
/* 382 */     base.packets = new RTCPPacket[subpackets.size()];
/* 383 */     subpackets.copyInto((Object[])base.packets);
/*     */     
/* 385 */     return base;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTCPRawReceiver.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */