/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import javax.media.rtp.LocalParticipant;
/*    */ import javax.media.rtp.rtcp.SourceDescription;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RTPLocalSourceInfo
/*    */   extends RTPSourceInfo
/*    */   implements LocalParticipant
/*    */ {
/*    */   public RTPLocalSourceInfo(String cname, RTPSourceInfoCache sic) {
/* 17 */     super(cname, sic);
/*    */   }
/*    */   
/*    */   public void setSourceDescription(SourceDescription[] sdeslist) {
/* 21 */     this.sic.ssrccache.ourssrc.setSourceDescription(sdeslist);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTPLocalSourceInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */