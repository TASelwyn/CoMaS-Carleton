/*     */ package com.sun.media.rtp;
/*     */ 
/*     */ import javax.media.rtp.GlobalReceptionStats;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OverallStats
/*     */   implements GlobalReceptionStats
/*     */ {
/*     */   public static final int PACKETRECD = 0;
/*     */   public static final int BYTESRECD = 1;
/*     */   public static final int BADRTPPACKET = 2;
/*     */   public static final int LOCALCOLL = 3;
/*     */   public static final int REMOTECOLL = 4;
/*     */   public static final int PACKETSLOOPED = 5;
/*     */   public static final int TRANSMITFAILED = 6;
/*     */   public static final int RTCPRECD = 11;
/*     */   public static final int SRRECD = 12;
/*     */   public static final int BADRTCPPACKET = 13;
/*     */   public static final int UNKNOWNTYPE = 14;
/*     */   public static final int MALFORMEDRR = 15;
/*     */   public static final int MALFORMEDSDES = 16;
/*     */   public static final int MALFORMEDBYE = 17;
/*     */   public static final int MALFORMEDSR = 18;
/*  35 */   private int numPackets = 0;
/*  36 */   private int numBytes = 0;
/*  37 */   private int numBadRTPPkts = 0;
/*  38 */   private int numLocalColl = 0;
/*  39 */   private int numRemoteColl = 0;
/*  40 */   private int numPktsLooped = 0;
/*  41 */   private int numTransmitFailed = 0;
/*  42 */   private int numRTCPRecd = 0;
/*  43 */   private int numSRRecd = 0;
/*  44 */   private int numBadRTCPPkts = 0;
/*  45 */   private int numUnknownTypes = 0;
/*  46 */   private int numMalformedRR = 0;
/*  47 */   private int numMalformedSDES = 0;
/*  48 */   private int numMalformedBye = 0;
/*  49 */   private int numMalformedSR = 0;
/*     */ 
/*     */   
/*     */   public synchronized void update(int which, int num) {
/*  53 */     switch (which) {
/*     */       case 0:
/*  55 */         this.numPackets += num;
/*     */         break;
/*     */       case 1:
/*  58 */         this.numBytes += num;
/*     */         break;
/*     */       case 2:
/*  61 */         this.numBadRTPPkts += num;
/*     */         break;
/*     */       case 3:
/*  64 */         this.numLocalColl += num;
/*     */         break;
/*     */       case 4:
/*  67 */         this.numRemoteColl += num;
/*     */         break;
/*     */       case 5:
/*  70 */         this.numPktsLooped += num;
/*     */         break;
/*     */       case 6:
/*  73 */         this.numTransmitFailed += num;
/*     */         break;
/*     */       case 11:
/*  76 */         this.numRTCPRecd += num;
/*     */         break;
/*     */       case 12:
/*  79 */         this.numSRRecd += num;
/*     */         break;
/*     */       case 13:
/*  82 */         this.numBadRTPPkts += num;
/*     */         break;
/*     */       case 14:
/*  85 */         this.numUnknownTypes += num;
/*     */         break;
/*     */       case 15:
/*  88 */         this.numMalformedRR += num;
/*     */         break;
/*     */       case 16:
/*  91 */         this.numMalformedSDES += num;
/*     */         break;
/*     */       case 17:
/*  94 */         this.numMalformedBye += num;
/*     */         break;
/*     */       case 18:
/*  97 */         this.numMalformedSR += num;
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPacketsRecd() {
/* 105 */     return this.numPackets;
/*     */   }
/*     */   
/*     */   public int getBytesRecd() {
/* 109 */     return this.numBytes;
/*     */   }
/*     */   
/*     */   public int getBadRTPkts() {
/* 113 */     return this.numBadRTPPkts;
/*     */   }
/*     */   
/*     */   public int getLocalColls() {
/* 117 */     return this.numLocalColl;
/*     */   }
/*     */   
/*     */   public int getRemoteColls() {
/* 121 */     return this.numRemoteColl;
/*     */   }
/*     */   
/*     */   public int getPacketsLooped() {
/* 125 */     return this.numPktsLooped;
/*     */   }
/*     */   
/*     */   public int getTransmitFailed() {
/* 129 */     return this.numTransmitFailed;
/*     */   }
/*     */   
/*     */   public int getRTCPRecd() {
/* 133 */     return this.numRTCPRecd;
/*     */   }
/*     */   
/*     */   public int getSRRecd() {
/* 137 */     return this.numSRRecd;
/*     */   }
/*     */   
/*     */   public int getBadRTCPPkts() {
/* 141 */     return this.numBadRTCPPkts;
/*     */   }
/*     */   
/*     */   public int getUnknownTypes() {
/* 145 */     return this.numUnknownTypes;
/*     */   }
/*     */   
/*     */   public int getMalformedRR() {
/* 149 */     return this.numMalformedRR;
/*     */   }
/*     */   
/*     */   public int getMalformedSDES() {
/* 153 */     return this.numMalformedSDES;
/*     */   }
/*     */   
/*     */   public int getMalformedBye() {
/* 157 */     return this.numMalformedBye;
/*     */   }
/*     */   
/*     */   public int getMalformedSR() {
/* 161 */     return this.numMalformedSR;
/*     */   }
/*     */   public String toString() {
/* 164 */     String s = "Packets Recd " + getPacketsRecd() + "\nBytes Recd " + getBytesRecd() + "\ngetBadRTP " + getBadRTPkts() + "\nLocalColl " + getLocalColls() + "\nRemoteColl " + getRemoteColls() + "\nPacketsLooped " + getPacketsLooped() + "\ngetTransmitFailed " + getTransmitFailed() + "\nRTCPRecd " + getTransmitFailed() + "\nSRRecd " + getSRRecd() + "\nBadRTCPPkts " + getBadRTCPPkts() + "\nUnknown " + getUnknownTypes() + "\nMalformedRR " + getMalformedRR() + "\nMalformedSDES " + getMalformedSDES() + "\nMalformedBye " + getMalformedBye() + "\nMalformedSR " + getMalformedSR();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 179 */     return s;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\OverallStats.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */