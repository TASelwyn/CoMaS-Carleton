/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RTCPAPPPacket
/*    */   extends RTCPPacket
/*    */ {
/*    */   int ssrc;
/*    */   int name;
/*    */   int subtype;
/*    */   byte[] data;
/*    */   
/*    */   public RTCPAPPPacket(RTCPPacket parent) {
/* 19 */     super(parent);
/* 20 */     this.type = 204;
/*    */   }
/*    */ 
/*    */   
/*    */   public RTCPAPPPacket(int ssrc, int name, int subtype, byte[] data) {
/* 25 */     this.ssrc = ssrc;
/* 26 */     this.name = name;
/* 27 */     this.subtype = subtype;
/* 28 */     this.data = data;
/* 29 */     this.type = 204;
/* 30 */     this.received = false;
/* 31 */     if ((data.length & 0x3) != 0)
/* 32 */       throw new IllegalArgumentException("Bad data length"); 
/* 33 */     if (subtype < 0 || subtype > 31)
/* 34 */       throw new IllegalArgumentException("Bad subtype"); 
/*    */   }
/*    */   
/*    */   public String toString() {
/* 38 */     return "\tRTCP APP Packet from SSRC " + this.ssrc + " with name " + nameString(this.name) + " and subtype " + this.subtype + "\n\tData (length " + this.data.length + "): " + new String(this.data) + "\n";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String nameString(int name) {
/* 44 */     return "" + (char)(name >>> 24) + (char)(name >>> 16 & 0xFF) + (char)(name >>> 8 & 0xFF) + (char)(name & 0xFF);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int calcLength() {
/* 51 */     return 12 + this.data.length;
/*    */   }
/*    */   
/*    */   void assemble(DataOutputStream out) throws IOException {
/* 55 */     out.writeByte(128 + this.subtype);
/* 56 */     out.writeByte(204);
/* 57 */     out.writeShort(2 + (this.data.length >> 2));
/* 58 */     out.writeInt(this.ssrc);
/* 59 */     out.writeInt(this.name);
/* 60 */     out.write(this.data);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTCPAPPPacket.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */