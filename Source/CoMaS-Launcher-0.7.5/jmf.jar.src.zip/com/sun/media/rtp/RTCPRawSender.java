/*     */ package com.sun.media.rtp;
/*     */ 
/*     */ import com.sun.media.rtp.util.Packet;
/*     */ import com.sun.media.rtp.util.PacketConsumer;
/*     */ import com.sun.media.rtp.util.PacketFilter;
/*     */ import com.sun.media.rtp.util.RTPPacketSender;
/*     */ import com.sun.media.rtp.util.UDPPacket;
/*     */ import com.sun.media.rtp.util.UDPPacketSender;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Vector;
/*     */ import javax.media.rtp.SessionAddress;
/*     */ 
/*     */ 
/*     */ public class RTCPRawSender
/*     */   extends PacketFilter
/*     */ {
/*     */   private InetAddress destaddr;
/*     */   private int destport;
/*     */   
/*     */   public String filtername() {
/*  23 */     return "RTCP Raw Packet Sender";
/*     */   }
/*     */ 
/*     */   
/*     */   public RTCPRawSender(int port, String address) throws UnknownHostException, IOException {
/*  28 */     this.destaddr = InetAddress.getByName(address);
/*  29 */     this.destport = port | 0x1;
/*  30 */     this.destAddressList = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public RTCPRawSender(int port, String address, UDPPacketSender sender) throws UnknownHostException, IOException {
/*  35 */     this(port, address);
/*  36 */     setConsumer((PacketConsumer)sender);
/*  37 */     this.destAddressList = null;
/*     */   }
/*     */   
/*     */   public RTCPRawSender(RTPPacketSender sender) {
/*  41 */     setConsumer((PacketConsumer)sender);
/*     */   }
/*     */   
/*     */   public void addDestAddr(InetAddress newaddr) {
/*  45 */     int i = 0;
/*  46 */     if (this.destAddressList == null) {
/*  47 */       this.destAddressList = new Vector();
/*     */       
/*  49 */       this.destAddressList.addElement(this.destaddr);
/*     */     } 
/*  51 */     for (i = 0; i < this.destAddressList.size(); i++) {
/*  52 */       InetAddress curraddr = this.destAddressList.elementAt(i);
/*  53 */       if (curraddr.equals(newaddr))
/*     */         break; 
/*     */     } 
/*  56 */     if (i == this.destAddressList.size())
/*  57 */       this.destAddressList.addElement(newaddr); 
/*     */   }
/*     */   
/*     */   public InetAddress getRemoteAddr() {
/*  61 */     return this.destaddr;
/*     */   }
/*     */   
/*     */   public Packet handlePacket(Packet p, SessionAddress sessionAddress) {
/*  65 */     assemble((RTCPCompoundPacket)p);
/*  66 */     PacketConsumer consumer = getConsumer();
/*  67 */     if (consumer instanceof RTPPacketSender)
/*  68 */       return p; 
/*  69 */     UDPPacket udpp = new UDPPacket();
/*  70 */     ((Packet)udpp).received = false;
/*  71 */     ((Packet)udpp).data = p.data;
/*  72 */     ((Packet)udpp).offset = p.offset;
/*  73 */     ((Packet)udpp).length = p.length;
/*  74 */     udpp.remoteAddress = sessionAddress.getControlAddress();
/*  75 */     udpp.remotePort = sessionAddress.getControlPort();
/*     */     
/*  77 */     return (Packet)udpp;
/*     */   }
/*     */   
/*     */   public Packet handlePacket(Packet p, int index) {
/*  81 */     assemble((RTCPCompoundPacket)p);
/*  82 */     UDPPacket udpp = new UDPPacket();
/*  83 */     ((Packet)udpp).received = false;
/*  84 */     ((Packet)udpp).data = p.data;
/*  85 */     ((Packet)udpp).offset = p.offset;
/*  86 */     ((Packet)udpp).length = p.length;
/*  87 */     udpp.remoteAddress = this.destAddressList.elementAt(index);
/*  88 */     udpp.remotePort = this.destport;
/*  89 */     return (Packet)udpp;
/*     */   }
/*     */   
/*     */   public Packet handlePacket(Packet p) {
/*  93 */     assemble((RTCPCompoundPacket)p);
/*  94 */     PacketConsumer consumer = getConsumer();
/*  95 */     if (consumer instanceof RTPPacketSender)
/*  96 */       return p; 
/*  97 */     UDPPacket udpp = new UDPPacket();
/*  98 */     ((Packet)udpp).received = false;
/*  99 */     ((Packet)udpp).data = p.data;
/* 100 */     ((Packet)udpp).offset = p.offset;
/* 101 */     ((Packet)udpp).length = p.length;
/* 102 */     udpp.remoteAddress = this.destaddr;
/* 103 */     udpp.remotePort = this.destport;
/* 104 */     return (Packet)udpp;
/*     */   }
/*     */   
/*     */   public void assemble(RTCPCompoundPacket p) {
/* 108 */     int len = p.calcLength();
/* 109 */     p.assemble(len, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDestAddresses(Vector destAddresses) {
/* 119 */     this.destAddressList = destAddresses;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTCPRawSender.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */