/*     */ package com.sun.media.rtp;
/*     */ 
/*     */ import com.sun.media.rtp.util.SSRCTable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamSynch
/*     */ {
/*     */   private static SSRCTable sources;
/*     */   
/*     */   public StreamSynch() {
/*  18 */     if (sources == null) {
/*  19 */       sources = new SSRCTable();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void update(int ssrc, long rtpTimestamp, long ntpTimestampMSW, long ntpTimestampLSW) {
/*  29 */     double fraction = ntpTimestampLSW / 4.294967296E9D;
/*     */     
/*  31 */     long ntpTimestamp = ntpTimestampMSW * 1000000000L + (long)(fraction * 1.0E9D);
/*     */ 
/*     */     
/*  34 */     SynchSource source = (SynchSource)sources.get(ssrc);
/*     */     
/*  36 */     if (source == null) {
/*  37 */       sources.put(ssrc, new SynchSource(ssrc, rtpTimestamp, ntpTimestamp));
/*     */     } else {
/*     */       
/*  40 */       source.factor = ((rtpTimestamp - source.rtpTimestamp) * (ntpTimestamp - source.ntpTimestamp));
/*     */       
/*  42 */       source.rtpTimestamp = rtpTimestamp;
/*  43 */       source.ntpTimestamp = ntpTimestamp;
/*     */     } 
/*     */   }
/*     */   
/*     */   public long calcTimestamp(int ssrc, int pt, long rtpTimestamp) {
/*  48 */     long timestamp = -1L;
/*     */     
/*  50 */     SynchSource source = (SynchSource)sources.get(ssrc);
/*     */     
/*  52 */     if (source != null) {
/*     */ 
/*     */       
/*  55 */       long rate = 1L;
/*  56 */       if (pt >= 0 && pt <= 5) {
/*     */         
/*  58 */         rate = 8000L;
/*  59 */       } else if (pt == 5) {
/*     */         
/*  61 */         rate = 8000L;
/*  62 */       } else if (pt == 6) {
/*     */         
/*  64 */         rate = 16000L;
/*  65 */       } else if (pt >= 7 && pt <= 9) {
/*     */         
/*  67 */         rate = 8000L;
/*  68 */       } else if (pt >= 10 && pt <= 11) {
/*     */         
/*  70 */         rate = 44100L;
/*  71 */       } else if (pt == 14) {
/*     */         
/*  73 */         rate = 90000L;
/*  74 */       } else if (pt == 15) {
/*     */         
/*  76 */         rate = 8000L;
/*  77 */       } else if (pt == 16) {
/*     */         
/*  79 */         rate = 11025L;
/*  80 */       } else if (pt == 17) {
/*     */         
/*  82 */         rate = 22050L;
/*  83 */       } else if (pt >= 25 && pt <= 26) {
/*     */         
/*  85 */         rate = 90000L;
/*  86 */       } else if (pt == 28) {
/*     */         
/*  88 */         rate = 90000L;
/*  89 */       } else if (pt >= 31 && pt <= 34) {
/*     */         
/*  91 */         rate = 90000L;
/*  92 */       } else if (pt == 42) {
/*     */         
/*  94 */         rate = 90000L;
/*     */       } 
/*     */       
/*  97 */       timestamp = source.ntpTimestamp + (rtpTimestamp - source.rtpTimestamp) * 1000000000L / rate;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     return timestamp;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(int ssrc) {
/* 109 */     if (sources != null)
/* 110 */       sources.remove(ssrc); 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\StreamSynch.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */