/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ import javax.media.rtp.SessionAddress;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RTPSessionMgrList
/*    */ {
/* 13 */   private static Hashtable list = new Hashtable(5);
/*    */ 
/*    */   
/*    */   public static void addRTPSM(RTPSessionMgr sm) {
/* 17 */     SessionAddress destaddr = sm.getSessionAddress();
/* 18 */     RTPSessionMgr mgr = (RTPSessionMgr)list.get(destaddr);
/* 19 */     if (mgr == null) {
/* 20 */       list.put(destaddr, sm);
/*    */     }
/*    */   }
/*    */   
/*    */   public static RTPSessionMgr getRTPSM(SessionAddress destaddr) {
/* 25 */     RTPSessionMgr mgr = (RTPSessionMgr)list.get(destaddr);
/* 26 */     return mgr;
/*    */   }
/*    */   public static void removeRTPSM(RTPSessionMgr sm) {
/* 29 */     SessionAddress destaddr = sm.getSessionAddress();
/* 30 */     list.remove(destaddr);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTPSessionMgrList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */