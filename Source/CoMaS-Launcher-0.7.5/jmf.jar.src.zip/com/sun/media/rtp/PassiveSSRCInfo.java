/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import javax.media.rtp.rtcp.ReceiverReport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PassiveSSRCInfo
/*    */   extends SSRCInfo
/*    */   implements ReceiverReport
/*    */ {
/*    */   PassiveSSRCInfo(SSRCCache cache, int ssrc) {
/* 16 */     super(cache, ssrc);
/*    */   }
/*    */   
/*    */   PassiveSSRCInfo(SSRCInfo info) {
/* 20 */     super(info);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\PassiveSSRCInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */