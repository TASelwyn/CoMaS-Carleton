/*     */ package com.sun.media.rtp;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import com.sun.media.rtp.util.RTPMediaThread;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ import javax.media.protocol.BufferTransferHandler;
/*     */ import javax.media.protocol.PushBufferStream;
/*     */ import javax.media.rtp.event.LocalPayloadChangeEvent;
/*     */ import javax.media.rtp.event.RTPEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RTPSinkStream
/*     */   implements BufferTransferHandler
/*     */ {
/*  31 */   private RTPMediaThread thread = null;
/*     */   
/*  33 */   Buffer current = new Buffer();
/*     */   
/*     */   boolean started = false;
/*  36 */   Object startReq = new Integer(0);
/*  37 */   RTPTransmitter transmitter = null;
/*  38 */   RTPRawSender sender = null;
/*  39 */   SendSSRCInfo info = null;
/*     */   
/*  41 */   private static JMFSecurity jmfSecurity = null;
/*     */   private static boolean securityPrivelege = false;
/*  43 */   private Method[] m = new Method[1];
/*  44 */   private Class[] cl = new Class[1];
/*  45 */   private Object[][] args = new Object[1][0];
/*     */ 
/*     */   
/*  48 */   static AudioFormat mpegAudio = new AudioFormat("mpegaudio/rtp");
/*  49 */   static VideoFormat mpegVideo = new VideoFormat("mpeg/rtp");
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/*  55 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  56 */       securityPrivelege = true;
/*     */     
/*     */     }
/*  59 */     catch (SecurityException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startStream() {
/*  65 */     if (jmfSecurity != null) {
/*  66 */       String permission = null;
/*     */       
/*     */       try {
/*  69 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  70 */           permission = "thread";
/*  71 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/*  72 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*     */           
/*  74 */           permission = "thread group";
/*  75 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/*  76 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*     */         }
/*  78 */         else if (jmfSecurity.getName().startsWith("internet")) {
/*  79 */           PolicyEngine.checkPermission(PermissionID.THREAD);
/*  80 */           PolicyEngine.assertPermission(PermissionID.THREAD);
/*     */         }
/*     */       
/*     */       }
/*  84 */       catch (Throwable e) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  89 */         if (permission.endsWith("group")) {
/*  90 */           jmfSecurity.permissionFailureNotification(32);
/*     */         } else {
/*  92 */           jmfSecurity.permissionFailureNotification(16);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setSSRCInfo(SendSSRCInfo info) {
/* 104 */     this.info = info;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setTransmitter(RTPTransmitter t) {
/* 109 */     this.transmitter = t;
/* 110 */     if (this.transmitter != null) {
/* 111 */       this.sender = this.transmitter.getSender();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void transferData(PushBufferStream stream) {
/*     */     try {
/* 120 */       synchronized (this.startReq) {
/*     */         
/* 122 */         while (!this.started) {
/*     */           
/* 124 */           this.startPT = -1L;
/* 125 */           this.startReq.wait();
/*     */         } 
/*     */       } 
/*     */       
/* 129 */       stream.read(this.current);
/*     */       
/* 131 */       if (!this.current.getFormat().matches(this.info.myformat)) {
/*     */ 
/*     */         
/* 134 */         int payload = this.transmitter.cache.sm.formatinfo.getPayload(this.current.getFormat());
/*     */         
/* 136 */         if (payload == -1) {
/*     */           return;
/*     */         }
/*     */         
/* 140 */         LocalPayloadChangeEvent evt = new LocalPayloadChangeEvent(this.transmitter.cache.sm, this.info, this.info.payloadType, payload);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 146 */         this.transmitter.cache.eventhandler.postEvent((RTPEvent)evt);
/* 147 */         this.info.payloadType = payload;
/* 148 */         this.info.myformat = this.current.getFormat();
/*     */       } 
/*     */       
/* 151 */       if (this.info.myformat instanceof VideoFormat) {
/* 152 */         transmitVideo();
/* 153 */       } else if (this.info.myformat instanceof AudioFormat) {
/* 154 */         transmitAudio();
/*     */       } 
/* 156 */     } catch (Exception e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 162 */     if (this.started) {
/*     */       return;
/*     */     }
/* 165 */     this.started = true;
/*     */     
/* 167 */     synchronized (this.startReq) {
/*     */       
/* 169 */       this.startReq.notifyAll();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void stop() {
/* 174 */     this.started = false;
/* 175 */     this.startPT = -1L;
/*     */     
/* 177 */     synchronized (this.startReq) {
/* 178 */       this.startReq.notifyAll();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void close() {
/* 184 */     stop();
/*     */   }
/*     */ 
/*     */   
/* 188 */   long startTime = 0L;
/* 189 */   long startPT = -1L;
/*     */   
/*     */   int rate;
/*     */   
/*     */   boolean mpegBFrame = false;
/*     */   
/*     */   boolean mpegPFrame = false;
/*     */   boolean bufSizeSet = false;
/*     */   
/*     */   private void transmitVideo() {
/* 199 */     if (this.current.isEOM() || this.current.isDiscard()) {
/* 200 */       this.startPT = -1L;
/* 201 */       this.mpegBFrame = false;
/* 202 */       this.mpegPFrame = false;
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 208 */     if (this.startPT == -1L) {
/*     */       
/* 210 */       this.startTime = System.currentTimeMillis();
/* 211 */       this.startPT = this.current.getTimeStamp() / 1000000L;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 221 */     if (this.current.getTimeStamp() > 0L && (this.current.getFlags() & 0x60) == 0 && (this.current.getFlags() & 0x800) != 0)
/*     */     {
/*     */ 
/*     */       
/* 225 */       if (mpegVideo.matches(this.info.myformat)) {
/* 226 */         byte[] payload = (byte[])this.current.getData();
/* 227 */         int offset = this.current.getOffset();
/* 228 */         int ptype = payload[offset + 2] & 0x7;
/* 229 */         if (ptype > 2) {
/*     */           
/* 231 */           this.mpegBFrame = true;
/* 232 */         } else if (ptype == 2) {
/*     */           
/* 234 */           this.mpegPFrame = true;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 245 */         if (ptype > 2 || (ptype == 2 && !this.mpegBFrame) || (ptype == 1 && (this.mpegBFrame | this.mpegPFrame) == 0))
/*     */         {
/* 247 */           waitForPT(this.startTime, this.startPT, this.current.getTimeStamp() / 1000000L);
/*     */         }
/*     */       } else {
/*     */         
/* 251 */         waitForPT(this.startTime, this.startPT, this.current.getTimeStamp() / 1000000L);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 280 */     this.transmitter.TransmitPacket(this.current, this.info);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 285 */   long audioPT = 0L;
/*     */ 
/*     */   
/*     */   private void transmitAudio() {
/* 289 */     if (this.current.isEOM() || this.current.isDiscard()) {
/* 290 */       this.startPT = -1L;
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 296 */     if (this.startPT == -1L) {
/* 297 */       this.startTime = System.currentTimeMillis();
/* 298 */       this.startPT = (this.current.getTimeStamp() > 0L) ? (this.current.getTimeStamp() / 1000000L) : 0L;
/* 299 */       this.audioPT = this.startPT;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 308 */     if ((this.current.getFlags() & 0x60) == 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 320 */       if (mpegAudio.matches(this.current.getFormat())) {
/* 321 */         this.audioPT = this.current.getTimeStamp() / 1000000L;
/*     */       } else {
/* 323 */         this.audioPT += ((AudioFormat)this.info.myformat).computeDuration(this.current.getLength()) / 1000000L;
/*     */       } 
/* 325 */       waitForPT(this.startTime, this.startPT, this.audioPT);
/*     */     } 
/*     */     
/* 328 */     this.transmitter.TransmitPacket(this.current, this.info);
/*     */   }
/*     */   
/* 331 */   static int THRESHOLD = 80;
/* 332 */   static int LEEWAY = 5;
/*     */ 
/*     */ 
/*     */   
/*     */   private void waitForPT(long start, long startPT, long pt) {
/* 337 */     long delay = pt - startPT - System.currentTimeMillis() - start;
/*     */     
/* 339 */     while (delay > LEEWAY) {
/* 340 */       if (delay > THRESHOLD) {
/* 341 */         delay = THRESHOLD;
/*     */       }
/*     */       try {
/* 344 */         Thread.currentThread(); Thread.sleep(delay);
/*     */       }
/* 346 */       catch (Exception e) {
/*     */         break;
/*     */       } 
/* 349 */       delay = pt - startPT - System.currentTimeMillis() - start;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTPSinkStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */