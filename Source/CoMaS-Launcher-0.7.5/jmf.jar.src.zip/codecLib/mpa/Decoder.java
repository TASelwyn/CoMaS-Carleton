package codecLib.mpa;

public class Decoder implements Constants {
  private m cn = new m();
  
  private c cs;
  
  private l ck = new l();
  
  private k cm;
  
  private j cl;
  
  private i cj;
  
  private byte[] cv = new byte[2547];
  
  private boolean cp = false;
  
  private static final short[][][] cr = new short[][][] { { { 
          -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
          -1, -1, -1, -1, -1, -1 }, { 
          0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 
          96, 112, 128, 144, 160, -1 }, { 
          0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 
          96, 112, 128, 144, 160, -1 }, { 
          0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 
          160, 176, 192, 224, 256, -1 } }, { { 
          -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
          -1, -1, -1, -1, -1, -1 }, { 
          0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 
          160, 192, 224, 256, 320, -1 }, { 
          0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 
          192, 224, 256, 320, 384, -1 }, { 
          0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 
          320, 352, 384, 416, 448, -1 } } };
  
  private static final int[][] co = new int[][] { { 22050, 24000, 16000, 0 }, { 44100, 48000, 32000, 0 } };
  
  private static final short[] ct = new short[] { 0, 11520, 13824, 5376 };
  
  private static final byte[] cu = new byte[] { 0, 7, 7, 31 };
  
  private static final short[][] cq = new short[][] { { 0, 576, 1152, 384 }, { 0, 1152, 1152, 384 } };
  
  public Decoder() {
    this.cn.bw[1] = a(9, 1024);
    this.cn.bw[2] = a(3, 32);
    this.cn.bw[3] = a(5, 128);
    this.cn.bx = new a();
    this.cs = new c(this.cn, this.cn.bx);
  }
  
  public Decoder(boolean paramBoolean, int paramInt) {
    this.cn.bw[1] = a(9, 1024);
    this.cn.bw[2] = a(3, 32);
    this.cn.bw[3] = a(5, 128);
    this.cn.bx = new a();
    this.cs = new c(this.cn, this.cn.bx);
    this.cn.br = !paramBoolean ? 1 : 0;
    if (paramInt >= 0 && paramInt <= 2)
      this.cn.bz = paramInt; 
  }
  
  public void setQuality(int paramInt) {
    if (paramInt >= 0 && paramInt <= 2)
      this.cn.bz = paramInt; 
  }
  
  public int getQuality() {
    return this.cn.bz;
  }
  
  public int decode(float[][] paramArrayOffloat, int[] paramArrayOfint, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws MPADException {
    int i3;
    int i4;
    l l1 = this.cn.bn;
    if (this.cn.bz < 0 || this.cn.bz > 2)
      this.cn.bz = 0; 
    int i1 = a(l1, paramArrayOfbyte, paramInt1, paramInt2);
    l1.b = i1;
    l1.char >>= this.cn.bz;
    int n = l1.case;
    if (paramInt2 - n < 13)
      throw new MPADException(-3); 
    n += l1.if >> 3;
    paramInt1 += n;
    paramInt2 -= n;
    int i2 = l1.do >> 3;
    if (l1.l == 1) {
      i3 = (paramInt1 > 511) ? (paramInt1 - 511) : 0;
      i4 = (paramInt2 > i2 + 8) ? (i2 + 8) : paramInt2;
      System.arraycopy(paramArrayOfbyte, i3, this.cv, 0, i4 + paramInt1 - i3);
    } else {
      i3 = paramInt1;
      i4 = (paramInt2 > i2) ? i2 : paramInt2;
      System.arraycopy(paramArrayOfbyte, i3, this.cv, 0, i4);
    } 
    paramArrayOfbyte = this.cv;
    if (this.cp)
      i4 = i2 + 8; 
    this.cn.bv.a(paramArrayOfbyte, paramInt1 - i3, i4);
    this.cn.bm = paramArrayOffloat;
    this.cn.bo = paramArrayOfint;
    this.cs.ao = this.cn.bx;
    this.cs.au = this.cn.bl;
    this.cn.bk = this.cn.bx.cw;
    this.cn.bx.cA = 0;
    this.cn.by = 0;
    switch (l1.l) {
      case 3:
        if (this.cm == null)
          this.cm = new k(this.cn, this.cs); 
        this.cm.do();
        this.cn.bx.cw = this.cn.bk;
        return l1.case + (l1.do >> 3);
      case 2:
        if (this.cl == null)
          this.cl = new j(this.cn, this.cs); 
        this.cl.a();
        return l1.case + (l1.do >> 3);
      case 1:
        throw new MPADException(-10);
    } 
    throw new MPADException(-1);
  }
  
  public int decodeLast(float[][] paramArrayOffloat, int[] paramArrayOfint, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws MPADException {
    this.cp = true;
    int n = decode(paramArrayOffloat, paramArrayOfint, paramArrayOfbyte, paramInt1, paramInt2);
    this.cp = false;
    return n;
  }
  
  public void setMultiChannelRequest(int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3) {
    this.cn.bx.cz = paramInt1;
    this.cn.bx.cB = paramArrayOfbyte;
    this.cn.bx.cJ = paramInt2;
    this.cn.bx.cG = paramInt3;
  }
  
  public void getMultiChannelInfo(MultiChannelInfo paramMultiChannelInfo) {
    paramMultiChannelInfo.status = this.cn.bx.cE;
    paramMultiChannelInfo.presentChannels = this.cn.bx.cC;
    paramMultiChannelInfo.extFrameLength = this.cn.bx.cA;
    paramMultiChannelInfo.numberOfArrangementChannels = this.cn.bx.cK;
    paramMultiChannelInfo.numberOfLanguageChannels = this.cn.bx.cF;
    paramMultiChannelInfo.MLSamplingRate = this.cn.bx.cM;
    paramMultiChannelInfo.numberOfMLSamples = this.cn.bx.cx;
    for (byte b = 0; b < 12; b++)
      paramMultiChannelInfo.LFESamples[b] = this.cn.bx.cI[b]; 
  }
  
  public void setCheckCRC(boolean paramBoolean) {
    this.cn.br = !paramBoolean ? 1 : 0;
  }
  
  public boolean getCheckCRC() {
    return (this.cn.br == 0);
  }
  
  public void getNextFrameInfo(FrameInfo paramFrameInfo, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws MPADException {
    l l1 = null;
    if (paramArrayOfbyte != null && paramInt2 >= 4) {
      a(this.ck, paramArrayOfbyte, paramInt1, paramInt2);
      l1 = this.ck;
    } 
    if (l1 == null)
      throw new MPADException(-1); 
    paramFrameInfo.mpegId = 2 - l1.long;
    paramFrameInfo.layerId = 4 - l1.l;
    paramFrameInfo.modeId = l1.goto;
    paramFrameInfo.headerOffset = l1.case;
    paramFrameInfo.frameLength = l1.do >> 3;
    paramFrameInfo.bitRate = l1.try;
    paramFrameInfo.samplingRate = l1.g;
    paramFrameInfo.numberOfChannels = l1.k;
    paramFrameInfo.numberOfSamples = l1.char;
    paramFrameInfo.negativeOffset = l1.byte;
  }
  
  public void getCurrFrameInfo(FrameInfo paramFrameInfo) throws MPADException {
    l l1 = null;
    if (this.cn.bn.l == 0)
      throw new MPADException(-1); 
    l1 = this.cn.bn;
    paramFrameInfo.mpegId = 2 - l1.long;
    paramFrameInfo.layerId = 4 - l1.l;
    paramFrameInfo.modeId = l1.goto;
    paramFrameInfo.headerOffset = l1.case;
    paramFrameInfo.frameLength = l1.do >> 3;
    paramFrameInfo.bitRate = l1.try;
    paramFrameInfo.samplingRate = l1.g;
    paramFrameInfo.numberOfChannels = l1.k;
    paramFrameInfo.numberOfSamples = l1.char;
    paramFrameInfo.negativeOffset = l1.byte;
  }
  
  public void reset() {
    this.cm = null;
    this.cl = null;
    this.cj = null;
  }
  
  private int a(l paraml, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws MPADException {
    // Byte code:
    //   0: iconst_0
    //   1: istore #5
    //   3: iconst_0
    //   4: istore #6
    //   6: bipush #-7
    //   8: istore #7
    //   10: iconst_0
    //   11: istore #8
    //   13: iload #4
    //   15: iconst_4
    //   16: if_icmpge -> 72
    //   19: new codecLib/mpa/MPADException
    //   22: dup
    //   23: bipush #-7
    //   25: invokespecial <init> : (I)V
    //   28: athrow
    //   29: goto -> 72
    //   32: iinc #5, 1
    //   35: iload #5
    //   37: iconst_3
    //   38: iadd
    //   39: iload #4
    //   41: if_icmplt -> 72
    //   44: iload #8
    //   46: ifeq -> 52
    //   49: goto -> 672
    //   52: iload #7
    //   54: bipush #-7
    //   56: if_icmpne -> 69
    //   59: new codecLib/mpa/MPADException
    //   62: dup
    //   63: bipush #-7
    //   65: invokespecial <init> : (I)V
    //   68: athrow
    //   69: iload #7
    //   71: ireturn
    //   72: aload_2
    //   73: iload_3
    //   74: iload #5
    //   76: iadd
    //   77: baload
    //   78: sipush #255
    //   81: iand
    //   82: sipush #255
    //   85: if_icmpne -> 32
    //   88: aload_2
    //   89: iload_3
    //   90: iload #5
    //   92: iadd
    //   93: iconst_1
    //   94: iadd
    //   95: baload
    //   96: sipush #246
    //   99: iand
    //   100: sipush #240
    //   103: if_icmple -> 32
    //   106: aload_2
    //   107: iload_3
    //   108: iload #5
    //   110: iadd
    //   111: iconst_2
    //   112: iadd
    //   113: baload
    //   114: sipush #240
    //   117: iand
    //   118: sipush #240
    //   121: if_icmpeq -> 32
    //   124: aload_2
    //   125: iload_3
    //   126: iload #5
    //   128: iadd
    //   129: iconst_2
    //   130: iadd
    //   131: baload
    //   132: bipush #12
    //   134: iand
    //   135: bipush #12
    //   137: if_icmpeq -> 32
    //   140: aload_2
    //   141: iload_3
    //   142: iload #5
    //   144: iadd
    //   145: iconst_3
    //   146: iadd
    //   147: baload
    //   148: iconst_3
    //   149: iand
    //   150: iconst_2
    //   151: if_icmpeq -> 32
    //   154: aload_2
    //   155: iload_3
    //   156: iload #5
    //   158: iadd
    //   159: iconst_1
    //   160: iadd
    //   161: baload
    //   162: iconst_3
    //   163: ishr
    //   164: iconst_1
    //   165: iand
    //   166: istore #9
    //   168: aload_2
    //   169: iload_3
    //   170: iload #5
    //   172: iadd
    //   173: iconst_1
    //   174: iadd
    //   175: baload
    //   176: iconst_1
    //   177: ishr
    //   178: iconst_3
    //   179: iand
    //   180: istore #10
    //   182: aload_2
    //   183: iload_3
    //   184: iload #5
    //   186: iadd
    //   187: iconst_2
    //   188: iadd
    //   189: baload
    //   190: iconst_4
    //   191: ishr
    //   192: bipush #15
    //   194: iand
    //   195: istore #11
    //   197: aload_2
    //   198: iload_3
    //   199: iload #5
    //   201: iadd
    //   202: iconst_2
    //   203: iadd
    //   204: baload
    //   205: iconst_2
    //   206: ishr
    //   207: iconst_3
    //   208: iand
    //   209: istore #13
    //   211: aload_2
    //   212: iload_3
    //   213: iload #5
    //   215: iadd
    //   216: iconst_2
    //   217: iadd
    //   218: baload
    //   219: iconst_1
    //   220: ishr
    //   221: iconst_1
    //   222: iand
    //   223: istore #15
    //   225: iload #11
    //   227: ifeq -> 490
    //   230: getstatic codecLib/mpa/Decoder.cr : [[[S
    //   233: iload #9
    //   235: aaload
    //   236: iload #10
    //   238: aaload
    //   239: iload #11
    //   241: saload
    //   242: istore #12
    //   244: getstatic codecLib/mpa/Decoder.co : [[I
    //   247: iload #9
    //   249: aaload
    //   250: iload #13
    //   252: iaload
    //   253: istore #14
    //   255: getstatic codecLib/mpa/Decoder.cq : [[S
    //   258: iload #9
    //   260: aaload
    //   261: iload #10
    //   263: saload
    //   264: istore #17
    //   266: iload #12
    //   268: sipush #1000
    //   271: imul
    //   272: iload #17
    //   274: imul
    //   275: iload #14
    //   277: idiv
    //   278: getstatic codecLib/mpa/Decoder.cu : [B
    //   281: iload #10
    //   283: baload
    //   284: iconst_m1
    //   285: ixor
    //   286: iand
    //   287: istore #16
    //   289: iload #15
    //   291: ifeq -> 307
    //   294: iload #16
    //   296: getstatic codecLib/mpa/Decoder.cu : [B
    //   299: iload #10
    //   301: baload
    //   302: iconst_1
    //   303: iadd
    //   304: iadd
    //   305: istore #16
    //   307: iload #5
    //   309: iload #16
    //   311: iconst_3
    //   312: ishr
    //   313: iadd
    //   314: istore #6
    //   316: iload #6
    //   318: iconst_1
    //   319: iadd
    //   320: iload #4
    //   322: if_icmpge -> 432
    //   325: aload_2
    //   326: iload_3
    //   327: iload #6
    //   329: iadd
    //   330: baload
    //   331: sipush #255
    //   334: iand
    //   335: sipush #255
    //   338: if_icmpne -> 380
    //   341: aload_2
    //   342: iload_3
    //   343: iload #6
    //   345: iadd
    //   346: iconst_1
    //   347: iadd
    //   348: baload
    //   349: sipush #254
    //   352: iand
    //   353: aload_2
    //   354: iload_3
    //   355: iload #5
    //   357: iadd
    //   358: iconst_1
    //   359: iadd
    //   360: baload
    //   361: sipush #254
    //   364: iand
    //   365: if_icmpne -> 380
    //   368: aload_1
    //   369: iload #5
    //   371: putfield case : I
    //   374: iconst_0
    //   375: istore #7
    //   377: goto -> 672
    //   380: iload #5
    //   382: ifne -> 426
    //   385: iload #9
    //   387: aload_1
    //   388: getfield long : I
    //   391: if_icmpne -> 426
    //   394: iload #10
    //   396: aload_1
    //   397: getfield l : I
    //   400: if_icmpne -> 426
    //   403: aload_1
    //   404: getfield i : I
    //   407: iload #13
    //   409: if_icmpne -> 426
    //   412: aload_1
    //   413: iconst_0
    //   414: putfield case : I
    //   417: iconst_1
    //   418: istore #8
    //   420: iconst_1
    //   421: istore #7
    //   423: goto -> 672
    //   426: iinc #5, 1
    //   429: goto -> 72
    //   432: iload #8
    //   434: ifne -> 443
    //   437: aload_1
    //   438: iload #5
    //   440: putfield case : I
    //   443: iconst_1
    //   444: istore #8
    //   446: iconst_1
    //   447: istore #7
    //   449: iload #5
    //   451: ifne -> 484
    //   454: iload #9
    //   456: aload_1
    //   457: getfield long : I
    //   460: if_icmpne -> 484
    //   463: iload #10
    //   465: aload_1
    //   466: getfield l : I
    //   469: if_icmpne -> 484
    //   472: aload_1
    //   473: getfield i : I
    //   476: iload #13
    //   478: if_icmpne -> 484
    //   481: goto -> 672
    //   484: iinc #5, 1
    //   487: goto -> 72
    //   490: getstatic codecLib/mpa/Decoder.ct : [S
    //   493: iload #10
    //   495: saload
    //   496: iconst_3
    //   497: ishr
    //   498: istore #18
    //   500: bipush #48
    //   502: istore #6
    //   504: goto -> 558
    //   507: iinc #6, 1
    //   510: iload #6
    //   512: iload #18
    //   514: if_icmple -> 523
    //   517: iinc #5, 1
    //   520: goto -> 72
    //   523: iload #5
    //   525: iload #6
    //   527: iadd
    //   528: iconst_3
    //   529: iadd
    //   530: iload #4
    //   532: if_icmplt -> 558
    //   535: iload #8
    //   537: ifne -> 546
    //   540: aload_1
    //   541: iload #5
    //   543: putfield case : I
    //   546: iconst_1
    //   547: istore #8
    //   549: iconst_1
    //   550: istore #7
    //   552: iinc #5, 1
    //   555: goto -> 72
    //   558: aload_2
    //   559: iload_3
    //   560: iload #5
    //   562: iadd
    //   563: iload #6
    //   565: iadd
    //   566: baload
    //   567: sipush #255
    //   570: iand
    //   571: sipush #255
    //   574: if_icmpne -> 507
    //   577: aload_2
    //   578: iload_3
    //   579: iload #5
    //   581: iadd
    //   582: iload #6
    //   584: iadd
    //   585: iconst_1
    //   586: iadd
    //   587: baload
    //   588: sipush #254
    //   591: iand
    //   592: aload_2
    //   593: iload_3
    //   594: iload #5
    //   596: iadd
    //   597: iconst_1
    //   598: iadd
    //   599: baload
    //   600: sipush #254
    //   603: iand
    //   604: if_icmpne -> 507
    //   607: aload_2
    //   608: iload_3
    //   609: iload #5
    //   611: iadd
    //   612: iload #6
    //   614: iadd
    //   615: iconst_2
    //   616: iadd
    //   617: baload
    //   618: sipush #252
    //   621: iand
    //   622: aload_2
    //   623: iload_3
    //   624: iload #5
    //   626: iadd
    //   627: iconst_2
    //   628: iadd
    //   629: baload
    //   630: sipush #252
    //   633: iand
    //   634: if_icmpne -> 507
    //   637: aload_2
    //   638: iload_3
    //   639: iload #5
    //   641: iadd
    //   642: iload #6
    //   644: iadd
    //   645: iconst_3
    //   646: iadd
    //   647: baload
    //   648: iconst_3
    //   649: iand
    //   650: iconst_2
    //   651: if_icmpeq -> 507
    //   654: iload #6
    //   656: iconst_3
    //   657: ishl
    //   658: istore #16
    //   660: aload_1
    //   661: iload #5
    //   663: putfield case : I
    //   666: iconst_0
    //   667: istore #7
    //   669: goto -> 672
    //   672: aload_1
    //   673: getfield case : I
    //   676: istore #5
    //   678: aload_1
    //   679: aload_2
    //   680: iload_3
    //   681: iload #5
    //   683: iadd
    //   684: iconst_1
    //   685: iadd
    //   686: baload
    //   687: iconst_3
    //   688: ishr
    //   689: iconst_1
    //   690: iand
    //   691: putfield long : I
    //   694: aload_1
    //   695: aload_2
    //   696: iload_3
    //   697: iload #5
    //   699: iadd
    //   700: iconst_1
    //   701: iadd
    //   702: baload
    //   703: iconst_1
    //   704: ishr
    //   705: iconst_3
    //   706: iand
    //   707: putfield l : I
    //   710: aload_1
    //   711: aload_2
    //   712: iload_3
    //   713: iload #5
    //   715: iadd
    //   716: iconst_1
    //   717: iadd
    //   718: baload
    //   719: iconst_1
    //   720: iand
    //   721: putfield c : I
    //   724: aload_1
    //   725: aload_2
    //   726: iload_3
    //   727: iload #5
    //   729: iadd
    //   730: iconst_2
    //   731: iadd
    //   732: baload
    //   733: iconst_4
    //   734: ishr
    //   735: bipush #15
    //   737: iand
    //   738: putfield d : I
    //   741: aload_1
    //   742: aload_2
    //   743: iload_3
    //   744: iload #5
    //   746: iadd
    //   747: iconst_2
    //   748: iadd
    //   749: baload
    //   750: iconst_2
    //   751: ishr
    //   752: iconst_3
    //   753: iand
    //   754: putfield i : I
    //   757: aload_2
    //   758: iload_3
    //   759: iload #5
    //   761: iadd
    //   762: iconst_2
    //   763: iadd
    //   764: baload
    //   765: iconst_1
    //   766: ishr
    //   767: iconst_1
    //   768: iand
    //   769: istore #15
    //   771: aload_1
    //   772: getstatic codecLib/mpa/Decoder.cr : [[[S
    //   775: aload_1
    //   776: getfield long : I
    //   779: aaload
    //   780: aload_1
    //   781: getfield l : I
    //   784: aaload
    //   785: aload_1
    //   786: getfield d : I
    //   789: saload
    //   790: putfield try : I
    //   793: aload_1
    //   794: getstatic codecLib/mpa/Decoder.co : [[I
    //   797: aload_1
    //   798: getfield long : I
    //   801: aaload
    //   802: aload_1
    //   803: getfield i : I
    //   806: iaload
    //   807: putfield g : I
    //   810: aload_1
    //   811: getstatic codecLib/mpa/Decoder.cq : [[S
    //   814: aload_1
    //   815: getfield long : I
    //   818: aaload
    //   819: aload_1
    //   820: getfield l : I
    //   823: saload
    //   824: putfield char : I
    //   827: aload_1
    //   828: getfield d : I
    //   831: ifeq -> 916
    //   834: aload_1
    //   835: getstatic codecLib/mpa/Decoder.cr : [[[S
    //   838: aload_1
    //   839: getfield long : I
    //   842: aaload
    //   843: aload_1
    //   844: getfield l : I
    //   847: aaload
    //   848: aload_1
    //   849: getfield d : I
    //   852: saload
    //   853: putfield try : I
    //   856: aload_1
    //   857: aload_1
    //   858: getfield try : I
    //   861: sipush #1000
    //   864: imul
    //   865: aload_1
    //   866: getfield char : I
    //   869: imul
    //   870: aload_1
    //   871: getfield g : I
    //   874: idiv
    //   875: getstatic codecLib/mpa/Decoder.cu : [B
    //   878: aload_1
    //   879: getfield l : I
    //   882: baload
    //   883: iconst_m1
    //   884: ixor
    //   885: iand
    //   886: putfield do : I
    //   889: iload #15
    //   891: ifeq -> 943
    //   894: aload_1
    //   895: dup
    //   896: getfield do : I
    //   899: getstatic codecLib/mpa/Decoder.cu : [B
    //   902: aload_1
    //   903: getfield l : I
    //   906: baload
    //   907: iconst_1
    //   908: iadd
    //   909: iadd
    //   910: putfield do : I
    //   913: goto -> 943
    //   916: iload #7
    //   918: ifne -> 932
    //   921: aload_1
    //   922: iload #6
    //   924: iconst_3
    //   925: ishl
    //   926: putfield do : I
    //   929: goto -> 943
    //   932: aload_1
    //   933: iload #4
    //   935: iload #5
    //   937: isub
    //   938: iconst_3
    //   939: ishl
    //   940: putfield do : I
    //   943: aload_1
    //   944: aload_2
    //   945: iload_3
    //   946: iload #5
    //   948: iadd
    //   949: iconst_2
    //   950: iadd
    //   951: baload
    //   952: iconst_1
    //   953: iand
    //   954: putfield for : I
    //   957: aload_1
    //   958: aload_2
    //   959: iload_3
    //   960: iload #5
    //   962: iadd
    //   963: iconst_3
    //   964: iadd
    //   965: baload
    //   966: bipush #6
    //   968: ishr
    //   969: iconst_3
    //   970: iand
    //   971: putfield goto : I
    //   974: aload_1
    //   975: aload_2
    //   976: iload_3
    //   977: iload #5
    //   979: iadd
    //   980: iconst_3
    //   981: iadd
    //   982: baload
    //   983: iconst_4
    //   984: ishr
    //   985: iconst_3
    //   986: iand
    //   987: putfield else : I
    //   990: aload_1
    //   991: aload_2
    //   992: iload_3
    //   993: iload #5
    //   995: iadd
    //   996: iconst_3
    //   997: iadd
    //   998: baload
    //   999: iconst_3
    //   1000: ishr
    //   1001: iconst_1
    //   1002: iand
    //   1003: putfield a : I
    //   1006: aload_1
    //   1007: aload_2
    //   1008: iload_3
    //   1009: iload #5
    //   1011: iadd
    //   1012: iconst_3
    //   1013: iadd
    //   1014: baload
    //   1015: iconst_2
    //   1016: ishr
    //   1017: iconst_1
    //   1018: iand
    //   1019: putfield int : I
    //   1022: aload_1
    //   1023: aload_2
    //   1024: iload_3
    //   1025: iload #5
    //   1027: iadd
    //   1028: iconst_3
    //   1029: iadd
    //   1030: baload
    //   1031: iconst_3
    //   1032: iand
    //   1033: putfield void : I
    //   1036: aload_1
    //   1037: aload_1
    //   1038: getfield goto : I
    //   1041: iconst_3
    //   1042: if_icmpeq -> 1049
    //   1045: iconst_2
    //   1046: goto -> 1050
    //   1049: iconst_1
    //   1050: putfield k : I
    //   1053: aload_1
    //   1054: getfield c : I
    //   1057: ifne -> 1133
    //   1060: aload_1
    //   1061: aload_2
    //   1062: iload_3
    //   1063: iload #5
    //   1065: iadd
    //   1066: iconst_4
    //   1067: iadd
    //   1068: baload
    //   1069: sipush #255
    //   1072: iand
    //   1073: bipush #8
    //   1075: ishl
    //   1076: aload_2
    //   1077: iload_3
    //   1078: iload #5
    //   1080: iadd
    //   1081: iconst_5
    //   1082: iadd
    //   1083: baload
    //   1084: sipush #255
    //   1087: iand
    //   1088: ior
    //   1089: putfield h : I
    //   1092: aload_1
    //   1093: aload_2
    //   1094: iload_3
    //   1095: iload #5
    //   1097: iadd
    //   1098: iconst_2
    //   1099: iadd
    //   1100: baload
    //   1101: sipush #255
    //   1104: iand
    //   1105: bipush #8
    //   1107: ishl
    //   1108: aload_2
    //   1109: iload_3
    //   1110: iload #5
    //   1112: iadd
    //   1113: iconst_3
    //   1114: iadd
    //   1115: baload
    //   1116: sipush #255
    //   1119: iand
    //   1120: ior
    //   1121: putfield e : I
    //   1124: aload_1
    //   1125: bipush #48
    //   1127: putfield if : I
    //   1130: goto -> 1139
    //   1133: aload_1
    //   1134: bipush #32
    //   1136: putfield if : I
    //   1139: aload_1
    //   1140: getfield l : I
    //   1143: iconst_1
    //   1144: if_icmpne -> 1224
    //   1147: aload_1
    //   1148: getfield if : I
    //   1151: iconst_3
    //   1152: ishr
    //   1153: istore #6
    //   1155: aload_1
    //   1156: getfield long : I
    //   1159: iconst_1
    //   1160: if_icmpne -> 1204
    //   1163: aload_1
    //   1164: aload_2
    //   1165: iload_3
    //   1166: iload #5
    //   1168: iadd
    //   1169: iload #6
    //   1171: iadd
    //   1172: baload
    //   1173: sipush #255
    //   1176: iand
    //   1177: iconst_1
    //   1178: ishl
    //   1179: aload_2
    //   1180: iload_3
    //   1181: iload #5
    //   1183: iadd
    //   1184: iload #6
    //   1186: iadd
    //   1187: iconst_1
    //   1188: iadd
    //   1189: baload
    //   1190: sipush #255
    //   1193: iand
    //   1194: bipush #7
    //   1196: ishr
    //   1197: ior
    //   1198: putfield byte : I
    //   1201: goto -> 1229
    //   1204: aload_1
    //   1205: aload_2
    //   1206: iload_3
    //   1207: iload #5
    //   1209: iadd
    //   1210: iload #6
    //   1212: iadd
    //   1213: baload
    //   1214: sipush #255
    //   1217: iand
    //   1218: putfield byte : I
    //   1221: goto -> 1229
    //   1224: aload_1
    //   1225: iconst_0
    //   1226: putfield byte : I
    //   1229: iload #7
    //   1231: bipush #-7
    //   1233: if_icmpne -> 1246
    //   1236: new codecLib/mpa/MPADException
    //   1239: dup
    //   1240: bipush #-7
    //   1242: invokespecial <init> : (I)V
    //   1245: athrow
    //   1246: iload #7
    //   1248: ireturn
  }
  
  private byte[] a(int paramInt1, int paramInt2) {
    byte[] arrayOfByte = new byte[3 * paramInt2];
    byte b1 = 0;
    for (byte b = 0; b < paramInt1; b = (byte)(b + 1)) {
      for (byte b2 = 0; b2 < paramInt1; b2 = (byte)(b2 + 1)) {
        for (byte b3 = 0; b3 < paramInt1; b3 = (byte)(b3 + 1)) {
          arrayOfByte[b1++] = b3;
          arrayOfByte[b1++] = b2;
          arrayOfByte[b1++] = b;
        } 
      } 
    } 
    return arrayOfByte;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\codecLib\mpa\Decoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */