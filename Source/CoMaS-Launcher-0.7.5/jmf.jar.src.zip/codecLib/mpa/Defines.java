package codecLib.mpa;

class Defines implements Constants {
  protected static final int LAYER = 4;
  
  protected static final int BITRATE_INDEX = 16;
  
  protected static final int SAMPFREQ_INDEX = 4;
  
  protected static final int MPEG_INDEX = 2;
  
  protected static final int SUBBAND = 32;
  
  protected static final int LAYER1 = 3;
  
  protected static final int LAYER2 = 2;
  
  protected static final int LAYER3 = 1;
  
  protected static final int MPEG1 = 1;
  
  protected static final int MPEG2 = 0;
  
  protected static final int STEREO = 0;
  
  protected static final int JOINT_STEREO = 1;
  
  protected static final int DUAL_CHANNEL = 2;
  
  protected static final int SINGLE_CHANNEL = 3;
  
  protected static final int NORMAL_STEREO = 0;
  
  protected static final int INTENSITY_ONLY = 1;
  
  protected static final int MS_ONLY = 2;
  
  protected static final int INTENSITY_MS = 3;
  
  protected static final int ML_CHAN = 7;
  
  protected static final int MC_CHAN = 5;
  
  protected static final int LFE_CHAN = 1;
  
  protected static final int MCL_CHAN = 7;
  
  protected static final int PREDDEL = 9;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\codecLib\mpa\Defines.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */