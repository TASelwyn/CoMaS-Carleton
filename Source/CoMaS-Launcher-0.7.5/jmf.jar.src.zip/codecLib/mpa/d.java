package codecLib.mpa;

class d implements Constants {
  int case;
  
  int g;
  
  int byte;
  
  int b;
  
  int d;
  
  int i;
  
  int c;
  
  int[] long = new int[3];
  
  int[] goto = new int[3];
  
  int a;
  
  int char;
  
  int e;
  
  int new;
  
  int if;
  
  int try;
  
  int[] else = new int[3];
  
  int int;
  
  short[] void;
  
  int h;
  
  int do;
  
  int[] f = new int[4];
  
  int[] for = new int[4];
  
  int null;
}
