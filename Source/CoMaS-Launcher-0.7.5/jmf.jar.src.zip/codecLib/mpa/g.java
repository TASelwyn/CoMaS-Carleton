package codecLib.mpa;

class g {
  private b a = new b();
  
  static int a(b paramb, int paramInt1, int paramInt2) {
    int i = paramInt1 << 16;
    int j = -2147155968;
    byte b1;
    for (b1 = 0; b1 < paramInt2 - 15; b1 += 16) {
      int k = paramb.a();
      for (byte b2 = 0; b2 < 16; b2++) {
        int m = (i ^ k) >> 31;
        m &= j;
        i <<= 1;
        i ^= m;
        k <<= 1;
      } 
    } 
    while (b1 < paramInt2) {
      int k = (i ^ paramb.do()) >> 31;
      k &= j;
      i <<= 1;
      i ^= k;
      b1++;
    } 
    return i >>> 16;
  }
  
  static int a(int paramInt1, int paramInt2, int paramInt3) {
    int i = paramInt2 << 16;
    int j = paramInt1 << 32 - paramInt3;
    int k = -2147155968;
    for (byte b1 = 0; b1 < paramInt3; b1++) {
      int m = (i ^ j) >> 31;
      m &= k;
      i <<= 1;
      i ^= m;
      j <<= 1;
    } 
    return i >>> 16;
  }
  
  int a(b paramb, l paraml, int paramInt) {
    b.a(this.a, paramb);
    int i = a(paraml.e, 65535, 16);
    i = a(this.a, i, paramInt);
    return i - paraml.h;
  }
  
  int if(b paramb, l paraml, int paramInt) {
    int i = a(paraml.e, 65535, 16);
    i = a(paramb, i, paramInt);
    return i - paraml.h;
  }
  
  int do(b paramb, l paraml, int paramInt) {
    if (paraml.c == 1) {
      paraml.h = 0;
      return 0;
    } 
    b.a(this.a, paramb);
    int i = a(paraml.e, 65535, 16);
    i = a(this.a, i, paramInt);
    return i - paraml.h;
  }
}
