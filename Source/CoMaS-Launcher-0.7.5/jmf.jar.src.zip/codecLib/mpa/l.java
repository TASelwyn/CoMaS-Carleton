package codecLib.mpa;

class l {
  int long;
  
  int l;
  
  int c;
  
  int d;
  
  int i;
  
  int f;
  
  int for;
  
  int goto;
  
  int else;
  
  int a;
  
  int int;
  
  int void;
  
  int case;
  
  int do;
  
  int try;
  
  int g;
  
  int k;
  
  int char;
  
  int byte;
  
  int h;
  
  int null;
  
  int j;
  
  int if;
  
  int e;
  
  int new;
  
  int b;
}
