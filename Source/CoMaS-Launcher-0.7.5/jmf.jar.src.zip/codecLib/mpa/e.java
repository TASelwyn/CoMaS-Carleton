package codecLib.mpa;

import java.util.ResourceBundle;

class e {
  static String a(String paramString) {
    return ResourceBundle.getBundle("com.sun.medialib.codec.mpad.MPADExceptionStrings").getString(paramString);
  }
}
