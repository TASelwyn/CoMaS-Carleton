package codecLib.mpa;

interface Tables {
  public static final float[] t_multiple = new float[] { 
      65536.0F, 52015.957F, 41285.094F, 32768.0F, 26007.979F, 20642.547F, 16384.0F, 13003.989F, 10321.273F, 8192.0F, 
      6501.9946F, 5160.6367F, 4096.0F, 3250.9973F, 2580.3184F, 2048.0F, 1625.4987F, 1290.1592F, 1024.0F, 812.7493F, 
      645.0796F, 512.0F, 406.37466F, 322.5398F, 256.0F, 203.18733F, 161.2699F, 128.0F, 101.593666F, 80.63495F, 
      64.0F, 50.796833F, 40.317474F, 32.0F, 25.398417F, 20.158737F, 16.0F, 12.699208F, 10.079369F, 8.0F, 
      6.349604F, 5.0396843F, 4.0F, 3.174802F, 2.5198421F, 2.0F, 1.587401F, 1.2599211F, 1.0F, 0.7937005F, 
      0.62996054F, 0.5F, 0.39685026F, 0.31498027F, 0.25F, 0.19842513F, 0.15749013F, 0.125F, 0.099212565F, 0.07874507F, 
      0.0625F, 0.049606282F, 0.039372534F, 1.0E-20F };
  
  public static final float[] t_c = new float[] { 
      1.3333334F, 1.6F, 1.1428572F, 1.7777778F, 1.0666667F, 1.032258F, 1.0158731F, 1.007874F, 1.0039216F, 1.0019569F, 
      1.0009775F, 1.0004885F, 1.0002443F, 1.0001221F, 1.000061F, 1.0000305F, 1.0000153F };
  
  public static final float[] t_d = new float[] { 
      0.6666667F, 0.8F, 0.2857143F, 0.8888889F, 0.13333334F, 0.06451613F, 0.031746034F, 0.015748031F, 0.007843138F, 0.0039138943F, 
      0.0019550342F, 9.770396E-4F, 4.884005E-4F, 2.4417043E-4F, 1.2207776E-4F, 6.1037026E-5F, 3.0518047E-5F };
  
  public static final float[] t_finv_alloc = new float[] { 
      0.6666667F, 0.4F, 0.2857143F, 0.22222222F, 0.13333334F, 0.06451613F, 0.031746034F, 0.015748031F, 0.007843138F, 0.0039138943F, 
      0.0019550342F, 9.770396E-4F, 4.884005E-4F, 2.4417043E-4F, 1.2207776E-4F, 6.103702E-5F, 3.0518044E-5F };
  
  public static final int[] t_alloc = new int[] { 
      2, 4, 4, 8, 8, 16, 32, 64, 128, 256, 
      512, 1024, 2048, 4096, 8192, 16384, 32768 };
  
  public static final byte[] p_0 = new byte[] { 0 };
  
  public static final byte[] a_0 = new byte[] { 0 };
  
  public static final byte[] p_2 = new byte[] { 0, 0, 1, 16 };
  
  public static final byte[] a_2 = new byte[] { 0, -5, -7, 16 };
  
  public static final byte[] p_3a = new byte[] { 0, 0, 1, 3, 4, 5, 6, 7 };
  
  public static final byte[] a_3a = new byte[] { 0, -5, -7, -10, 4, 5, 6, 7 };
  
  public static final byte[] p_3b = new byte[] { 0, 0, 1, 2, 3, 4, 5, 16 };
  
  public static final byte[] a_3b = new byte[] { 0, -5, -7, 3, -10, 4, 5, 16 };
  
  public static final byte[] p_4a = new byte[] { 
      0, 0, 1, 3, 4, 5, 6, 7, 8, 9, 
      10, 11, 12, 13, 14, 15 };
  
  public static final byte[] a_4a = new byte[] { 
      0, -5, -7, -10, 4, 5, 6, 7, 8, 9, 
      10, 11, 12, 13, 14, 15 };
  
  public static final byte[] p_4b = new byte[] { 
      0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 
      9, 10, 11, 12, 13, 16 };
  
  public static final byte[] a_4b = new byte[] { 
      0, -5, -7, 3, -10, 4, 5, 6, 7, 8, 
      9, 10, 11, 12, 13, 16 };
  
  public static final byte[] p_4c = new byte[] { 
      0, 0, 2, 4, 5, 6, 7, 8, 9, 10, 
      11, 12, 13, 14, 15, 16 };
  
  public static final byte[] a_4c = new byte[] { 
      0, -5, 3, 4, 5, 6, 7, 8, 9, 10, 
      11, 12, 13, 14, 15, 16 };
  
  public static final byte[] p_4d = new byte[] { 
      0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 
      9, 10, 11, 12, 13, 14 };
  
  public static final byte[] a_4d = new byte[] { 
      0, -5, -7, 3, -10, 4, 5, 6, 7, 8, 
      9, 10, 11, 12, 13, 14 };
  
  public static final byte[] p_2a = new byte[] { 0, 0, 1, 3 };
  
  public static final byte[] a_2a = new byte[] { 0, -5, -7, -10 };
  
  public static final byte[] t_bal_00 = new byte[] { 
      4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 
      4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
      3, 3, 3, 2, 2, 2, 2, 0, 0, 0, 
      0, 0 };
  
  public static final byte[][] t_bal_01 = new byte[][] { 
      p_4c, p_4c, p_4c, p_4b, p_4b, p_4b, p_4b, p_4b, p_4b, p_4b, 
      p_4b, p_3b, p_3b, p_3b, p_3b, p_3b, p_3b, p_3b, p_3b, p_3b, 
      p_3b, p_3b, p_3b, p_2, p_2, p_2, p_2, p_0, p_0, p_0, 
      p_0, p_0 };
  
  public static final byte[][] t_bal_02 = new byte[][] { 
      a_4c, a_4c, a_4c, a_4b, a_4b, a_4b, a_4b, a_4b, a_4b, a_4b, 
      a_4b, a_3b, a_3b, a_3b, a_3b, a_3b, a_3b, a_3b, a_3b, a_3b, 
      a_3b, a_3b, a_3b, a_2, a_2, a_2, a_2, a_0, a_0, a_0, 
      a_0, a_0 };
  
  public static final byte[] t_bal_10 = new byte[] { 
      4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 
      4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
      3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 
      0, 0 };
  
  public static final byte[][] t_bal_11 = new byte[][] { 
      p_4c, p_4c, p_4c, p_4b, p_4b, p_4b, p_4b, p_4b, p_4b, p_4b, 
      p_4b, p_3b, p_3b, p_3b, p_3b, p_3b, p_3b, p_3b, p_3b, p_3b, 
      p_3b, p_3b, p_3b, p_2, p_2, p_2, p_2, p_2, p_2, p_2, 
      p_0, p_0 };
  
  public static final byte[][] t_bal_12 = new byte[][] { 
      a_4c, a_4c, a_4c, a_4b, a_4b, a_4b, a_4b, a_4b, a_4b, a_4b, 
      a_4b, a_3b, a_3b, a_3b, a_3b, a_3b, a_3b, a_3b, a_3b, a_3b, 
      a_3b, a_3b, a_3b, a_2, a_2, a_2, a_2, a_2, a_2, a_2, 
      a_0, a_0 };
  
  public static final byte[] t_bal_20 = new byte[] { 
      4, 4, 3, 3, 3, 3, 3, 3, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0 };
  
  public static final byte[][] t_bal_21 = new byte[][] { 
      p_4a, p_4a, p_3a, p_3a, p_3a, p_3a, p_3a, p_3a, p_0, p_0, 
      p_0, p_0, p_0, p_0, p_0, p_0, p_0, p_0, p_0, p_0, 
      p_0, p_0, p_0, p_0, p_0, p_0, p_0, p_0, p_0, p_0, 
      p_0, p_0 };
  
  public static final byte[][] t_bal_22 = new byte[][] { 
      a_4a, a_4a, a_3a, a_3a, a_3a, a_3a, a_3a, a_3a, a_0, a_0, 
      a_0, a_0, a_0, a_0, a_0, a_0, a_0, a_0, a_0, a_0, 
      a_0, a_0, a_0, a_0, a_0, a_0, a_0, a_0, a_0, a_0, 
      a_0, a_0 };
  
  public static final byte[] t_bal_30 = new byte[] { 
      4, 4, 3, 3, 3, 3, 3, 3, 3, 3, 
      3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0 };
  
  public static final byte[][] t_bal_31 = new byte[][] { 
      p_4a, p_4a, p_3a, p_3a, p_3a, p_3a, p_3a, p_3a, p_3a, p_3a, 
      p_3a, p_3a, p_0, p_0, p_0, p_0, p_0, p_0, p_0, p_0, 
      p_0, p_0, p_0, p_0, p_0, p_0, p_0, p_0, p_0, p_0, 
      p_0, p_0 };
  
  public static final byte[][] t_bal_32 = new byte[][] { 
      a_4a, a_4a, a_3a, a_3a, a_3a, a_3a, a_3a, a_3a, a_3a, a_3a, 
      a_3a, a_3a, a_0, a_0, a_0, a_0, a_0, a_0, a_0, a_0, 
      a_0, a_0, a_0, a_0, a_0, a_0, a_0, a_0, a_0, a_0, 
      a_0, a_0 };
  
  public static final byte[] t_bal_40 = new byte[] { 
      4, 4, 4, 4, 3, 3, 3, 3, 3, 3, 
      3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
      2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
      0, 0 };
  
  public static final byte[][] t_bal_41 = new byte[][] { 
      p_4d, p_4d, p_4d, p_4d, p_3a, p_3a, p_3a, p_3a, p_3a, p_3a, 
      p_3a, p_2a, p_2a, p_2a, p_2a, p_2a, p_2a, p_2a, p_2a, p_2a, 
      p_2a, p_2a, p_2a, p_2a, p_2a, p_2a, p_2a, p_2a, p_2a, p_2a, 
      p_0, p_0 };
  
  public static final byte[][] t_bal_42 = new byte[][] { 
      a_4d, a_4d, a_4d, a_4d, a_3a, a_3a, a_3a, a_3a, a_3a, a_3a, 
      a_3a, a_2a, a_2a, a_2a, a_2a, a_2a, a_2a, a_2a, a_2a, a_2a, 
      a_2a, a_2a, a_2a, a_2a, a_2a, a_2a, a_2a, a_2a, a_2a, a_2a, 
      a_0, a_0 };
  
  public static final f[] t_bal = new f[] { new f(27, 88, t_bal_00, t_bal_01, t_bal_02), new f(30, 94, t_bal_10, t_bal_11, t_bal_12), new f(8, 26, t_bal_20, t_bal_21, t_bal_22), new f(12, 38, t_bal_30, t_bal_31, t_bal_32), new f(30, 75, t_bal_40, t_bal_41, t_bal_42) };
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\codecLib\mpa\Tables.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */