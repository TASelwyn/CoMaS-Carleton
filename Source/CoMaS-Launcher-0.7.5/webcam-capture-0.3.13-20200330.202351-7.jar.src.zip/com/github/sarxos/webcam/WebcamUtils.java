/*    */ package com.github.sarxos.webcam;
/*    */ 
/*    */ import com.github.sarxos.webcam.util.ImageUtils;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.Locale;
/*    */ import java.util.PropertyResourceBundle;
/*    */ import java.util.ResourceBundle;
/*    */ import javax.imageio.ImageIO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebcamUtils
/*    */ {
/*    */   public static final void capture(Webcam webcam, File file) {
/* 18 */     if (!webcam.isOpen()) {
/* 19 */       webcam.open();
/*    */     }
/*    */     try {
/* 22 */       ImageIO.write(webcam.getImage(), "JPG", file);
/* 23 */     } catch (IOException e) {
/* 24 */       throw new WebcamException(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static final void capture(Webcam webcam, File file, String format) {
/* 29 */     if (!webcam.isOpen()) {
/* 30 */       webcam.open();
/*    */     }
/*    */     try {
/* 33 */       ImageIO.write(webcam.getImage(), format, file);
/* 34 */     } catch (IOException e) {
/* 35 */       throw new WebcamException(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static final void capture(Webcam webcam, String filename) {
/* 40 */     if (!filename.endsWith(".jpg")) {
/* 41 */       filename = filename + ".jpg";
/*    */     }
/* 43 */     capture(webcam, new File(filename));
/*    */   }
/*    */   
/*    */   public static final void capture(Webcam webcam, String filename, String format) {
/* 47 */     String ext = "." + format.toLowerCase();
/* 48 */     if (!filename.endsWith(ext)) {
/* 49 */       filename = filename + ext;
/*    */     }
/* 51 */     capture(webcam, new File(filename), format);
/*    */   }
/*    */   
/*    */   public static final byte[] getImageBytes(Webcam webcam, String format) {
/* 55 */     return ImageUtils.toByteArray(webcam.getImage(), format);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final ByteBuffer getImageByteBuffer(Webcam webcam, String format) {
/* 66 */     return ByteBuffer.wrap(getImageBytes(webcam, format));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final ResourceBundle loadRB(Class<?> clazz, Locale locale) {
/* 77 */     String pkg = WebcamUtils.class.getPackage().getName().replaceAll("\\.", "/");
/* 78 */     return PropertyResourceBundle.getBundle(String.format("%s/i18n/%s", new Object[] { pkg, clazz.getSimpleName() }));
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */