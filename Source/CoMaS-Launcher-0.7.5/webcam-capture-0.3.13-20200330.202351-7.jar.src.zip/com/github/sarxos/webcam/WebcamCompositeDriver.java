/*    */ package com.github.sarxos.webcam;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class WebcamCompositeDriver
/*    */   implements WebcamDriver, WebcamDiscoverySupport
/*    */ {
/*  9 */   private List<WebcamDriver> drivers = new ArrayList<>();
/*    */   
/* 11 */   private int scanInterval = -1;
/*    */   
/*    */   public WebcamCompositeDriver(WebcamDriver... drivers) {
/* 14 */     for (WebcamDriver driver : drivers) {
/* 15 */       this.drivers.add(driver);
/*    */     }
/*    */   }
/*    */   
/*    */   public void add(WebcamDriver driver) {
/* 20 */     this.drivers.add(driver);
/*    */   }
/*    */   
/*    */   public List<WebcamDriver> getDrivers() {
/* 24 */     return this.drivers;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<WebcamDevice> getDevices() {
/* 29 */     List<WebcamDevice> all = new ArrayList<>();
/* 30 */     for (WebcamDriver driver : this.drivers) {
/* 31 */       all.addAll(driver.getDevices());
/*    */     }
/* 33 */     return all;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isThreadSafe() {
/* 38 */     boolean safe = true;
/* 39 */     for (WebcamDriver driver : this.drivers) {
/* 40 */       safe &= driver.isThreadSafe();
/* 41 */       if (!safe) {
/*    */         break;
/*    */       }
/*    */     } 
/* 45 */     return safe;
/*    */   }
/*    */   
/*    */   public void setScanInterval(int scanInterval) {
/* 49 */     this.scanInterval = scanInterval;
/*    */   }
/*    */ 
/*    */   
/*    */   public long getScanInterval() {
/* 54 */     if (this.scanInterval <= 0) {
/* 55 */       return 3000L;
/*    */     }
/* 57 */     return this.scanInterval;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isScanPossible() {
/* 62 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamCompositeDriver.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */