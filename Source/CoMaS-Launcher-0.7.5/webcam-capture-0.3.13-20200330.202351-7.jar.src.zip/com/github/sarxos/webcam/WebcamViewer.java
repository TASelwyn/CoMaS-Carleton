/*     */ package com.github.sarxos.webcam;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.awt.event.WindowListener;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.SwingUtilities;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebcamViewer
/*     */   extends JFrame
/*     */   implements Runnable, WebcamListener, WindowListener, Thread.UncaughtExceptionHandler, ItemListener
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  26 */   private static final Logger LOG = LoggerFactory.getLogger(WebcamViewer.class);
/*     */   
/*  28 */   private Webcam webcam = null;
/*  29 */   private WebcamPanel panel = null;
/*  30 */   private WebcamPicker picker = null;
/*     */   
/*     */   public WebcamViewer() {
/*  33 */     SwingUtilities.invokeLater(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*  39 */     setTitle("Webcam Capture Viewer");
/*  40 */     setDefaultCloseOperation(3);
/*  41 */     setLayout(new BorderLayout());
/*     */     
/*  43 */     addWindowListener(this);
/*     */     
/*  45 */     this.picker = new WebcamPicker();
/*  46 */     this.picker.addItemListener(this);
/*     */     
/*  48 */     this.webcam = this.picker.getSelectedWebcam();
/*     */     
/*  50 */     if (this.webcam == null) {
/*  51 */       LOG.error("No webcams found");
/*  52 */       System.exit(1);
/*     */     } 
/*     */     
/*  55 */     this.webcam.setViewSize(WebcamResolution.VGA.getSize());
/*  56 */     this.webcam.addWebcamListener(this);
/*     */     
/*  58 */     this.panel = new WebcamPanel(this.webcam, false);
/*  59 */     this.panel.setFPSDisplayed(true);
/*     */     
/*  61 */     add(this.picker, "North");
/*  62 */     add(this.panel, "Center");
/*     */     
/*  64 */     pack();
/*  65 */     setVisible(true);
/*     */     
/*  67 */     Thread t = new Thread()
/*     */       {
/*     */         public void run()
/*     */         {
/*  71 */           WebcamViewer.this.panel.start();
/*     */         }
/*     */       };
/*  74 */     t.setName("webcam-viewer-starter");
/*  75 */     t.setDaemon(true);
/*  76 */     t.setUncaughtExceptionHandler(this);
/*  77 */     t.start();
/*     */   }
/*     */ 
/*     */   
/*     */   public void webcamOpen(WebcamEvent we) {
/*  82 */     LOG.info("Webcam open");
/*     */   }
/*     */ 
/*     */   
/*     */   public void webcamClosed(WebcamEvent we) {
/*  87 */     LOG.info("Webcam closed");
/*     */   }
/*     */ 
/*     */   
/*     */   public void webcamDisposed(WebcamEvent we) {
/*  92 */     LOG.info("Webcam disposed");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void webcamImageObtained(WebcamEvent we) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void windowActivated(WindowEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void windowClosed(WindowEvent e) {
/* 106 */     this.webcam.close();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void windowClosing(WindowEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void windowOpened(WindowEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void windowDeactivated(WindowEvent e) {}
/*     */ 
/*     */   
/*     */   public void windowDeiconified(WindowEvent e) {
/* 123 */     LOG.info("Webcam viewer resumed");
/* 124 */     this.panel.resume();
/*     */   }
/*     */ 
/*     */   
/*     */   public void windowIconified(WindowEvent e) {
/* 129 */     LOG.info("Webcam viewer paused");
/* 130 */     this.panel.pause();
/*     */   }
/*     */ 
/*     */   
/*     */   public void uncaughtException(Thread t, Throwable e) {
/* 135 */     e.printStackTrace();
/* 136 */     LOG.error(String.format("Exception in thread %s", new Object[] { t.getName() }), e);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void itemStateChanged(ItemEvent e) {
/* 142 */     if (e.getItem() == this.webcam) {
/*     */       return;
/*     */     }
/*     */     
/* 146 */     if (this.webcam == null) {
/*     */       return;
/*     */     }
/*     */     
/* 150 */     final WebcamPanel tmp = this.panel;
/*     */     
/* 152 */     remove(this.panel);
/*     */     
/* 154 */     this.webcam.removeWebcamListener(this);
/*     */     
/* 156 */     this.webcam = (Webcam)e.getItem();
/* 157 */     this.webcam.setViewSize(WebcamResolution.VGA.getSize());
/* 158 */     this.webcam.addWebcamListener(this);
/*     */     
/* 160 */     System.out.println("selected " + this.webcam.getName());
/*     */     
/* 162 */     this.panel = new WebcamPanel(this.webcam, false);
/*     */     
/* 164 */     add(this.panel, "Center");
/*     */     
/* 166 */     Thread t = new Thread()
/*     */       {
/*     */         public void run()
/*     */         {
/* 170 */           tmp.stop();
/* 171 */           WebcamViewer.this.panel.start();
/*     */         }
/*     */       };
/* 174 */     t.setDaemon(true);
/* 175 */     t.setUncaughtExceptionHandler(this);
/* 176 */     t.start();
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamViewer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */