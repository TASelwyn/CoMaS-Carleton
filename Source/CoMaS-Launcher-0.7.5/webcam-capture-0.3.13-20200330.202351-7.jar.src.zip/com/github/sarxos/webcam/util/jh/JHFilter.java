/*    */ package com.github.sarxos.webcam.util.jh;
/*    */ 
/*    */ import java.awt.Rectangle;
/*    */ import java.awt.RenderingHints;
/*    */ import java.awt.geom.Point2D;
/*    */ import java.awt.geom.Rectangle2D;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.awt.image.BufferedImageOp;
/*    */ import java.awt.image.ColorModel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JHFilter
/*    */   implements BufferedImageOp
/*    */ {
/*    */   public BufferedImage createCompatibleDestImage(BufferedImage src, ColorModel dstCM) {
/* 35 */     if (dstCM == null) {
/* 36 */       dstCM = src.getColorModel();
/*    */     }
/* 38 */     return new BufferedImage(dstCM, dstCM.createCompatibleWritableRaster(src.getWidth(), src.getHeight()), dstCM.isAlphaPremultiplied(), null);
/*    */   }
/*    */ 
/*    */   
/*    */   public Rectangle2D getBounds2D(BufferedImage src) {
/* 43 */     return new Rectangle(0, 0, src.getWidth(), src.getHeight());
/*    */   }
/*    */ 
/*    */   
/*    */   public Point2D getPoint2D(Point2D srcPt, Point2D dstPt) {
/* 48 */     if (dstPt == null) {
/* 49 */       dstPt = new Point2D.Double();
/*    */     }
/* 51 */     dstPt.setLocation(srcPt.getX(), srcPt.getY());
/* 52 */     return dstPt;
/*    */   }
/*    */ 
/*    */   
/*    */   public RenderingHints getRenderingHints() {
/* 57 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int[] getRGB(BufferedImage image, int x, int y, int width, int height, int[] pixels) {
/* 74 */     int type = image.getType();
/* 75 */     if (type == 2 || type == 1) {
/* 76 */       return (int[])image.getRaster().getDataElements(x, y, width, height, pixels);
/*    */     }
/* 78 */     return image.getRGB(x, y, width, height, pixels, 0, width);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRGB(BufferedImage image, int x, int y, int width, int height, int[] pixels) {
/* 94 */     int type = image.getType();
/* 95 */     if (type == 2 || type == 1) {
/* 96 */       image.getRaster().setDataElements(x, y, width, height, pixels);
/*    */     } else {
/* 98 */       image.setRGB(x, y, width, height, pixels, 0, width);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webca\\util\jh\JHFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */