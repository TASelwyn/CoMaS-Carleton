/*    */ package com.github.sarxos.webcam.util.jh;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.awt.image.WritableRaster;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JHGrayFilter
/*    */   extends JHFilter
/*    */ {
/*    */   protected boolean canFilterIndexColorModel = true;
/*    */   
/*    */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/* 30 */     int width = src.getWidth();
/* 31 */     int height = src.getHeight();
/* 32 */     int type = src.getType();
/*    */     
/* 34 */     WritableRaster srcRaster = src.getRaster();
/*    */     
/* 36 */     if (dst == null) {
/* 37 */       dst = createCompatibleDestImage(src, null);
/*    */     }
/*    */     
/* 40 */     WritableRaster dstRaster = dst.getRaster();
/*    */     
/* 42 */     int[] inPixels = new int[width];
/* 43 */     for (int y = 0; y < height; y++) {
/* 44 */       if (type == 2) {
/* 45 */         srcRaster.getDataElements(0, y, width, 1, inPixels);
/* 46 */         for (int x = 0; x < width; x++) {
/* 47 */           inPixels[x] = filterRGB(inPixels[x]);
/*    */         }
/* 49 */         dstRaster.setDataElements(0, y, width, 1, inPixels);
/*    */       } else {
/* 51 */         src.getRGB(0, y, width, 1, inPixels, 0, width);
/* 52 */         for (int x = 0; x < width; x++) {
/* 53 */           inPixels[x] = filterRGB(inPixels[x]);
/*    */         }
/* 55 */         dst.setRGB(0, y, width, 1, inPixels, 0, width);
/*    */       } 
/*    */     } 
/*    */     
/* 59 */     return dst;
/*    */   }
/*    */   
/*    */   private int filterRGB(int rgb) {
/* 63 */     int a = rgb & 0xFF000000;
/* 64 */     int r = rgb >> 16 & 0xFF;
/* 65 */     int g = rgb >> 8 & 0xFF;
/* 66 */     int b = rgb & 0xFF;
/* 67 */     rgb = r * 77 + g * 151 + b * 28 >> 8;
/* 68 */     return a | rgb << 16 | rgb << 8 | rgb;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webca\\util\jh\JHGrayFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */