/*     */ package com.github.sarxos.webcam.util;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import javax.imageio.ImageIO;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MjpegInputStream
/*     */   extends DataInputStream
/*     */ {
/*  25 */   private static final Logger LOG = LoggerFactory.getLogger(MjpegInputStream.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  30 */   private final byte[] SOI_MARKER = new byte[] { -1, -40 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  35 */   private final byte[] EOI_MARKER = new byte[] { -1, -39 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   private final String CONTENT_LENGTH = "Content-Length".toLowerCase();
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int HEADER_MAX_LENGTH = 100;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int FRAME_MAX_LENGTH = 100100;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean open = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MjpegInputStream(InputStream in) {
/*  58 */     super(new BufferedInputStream(in, 100100));
/*     */   }
/*     */   
/*     */   private int getEndOfSeqeunce(DataInputStream in, byte[] sequence) throws IOException {
/*  62 */     int s = 0;
/*     */     
/*  64 */     for (int i = 0; i < 100100; i++) {
/*  65 */       byte c = (byte)in.readUnsignedByte();
/*  66 */       if (c == sequence[s]) {
/*  67 */         s++;
/*  68 */         if (s == sequence.length) {
/*  69 */           return i + 1;
/*     */         }
/*     */       } else {
/*  72 */         s = 0;
/*     */       } 
/*     */     } 
/*  75 */     return -1;
/*     */   }
/*     */   
/*     */   private int getStartOfSequence(DataInputStream in, byte[] sequence) throws IOException {
/*  79 */     int end = getEndOfSeqeunce(in, sequence);
/*  80 */     return (end < 0) ? -1 : (end - sequence.length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int parseContentLength(byte[] headerBytes) throws IOException, NumberFormatException {
/*  86 */     try(ByteArrayInputStream bais = new ByteArrayInputStream(headerBytes); 
/*  87 */         InputStreamReader isr = new InputStreamReader(bais); 
/*  88 */         BufferedReader br = new BufferedReader(isr)) {
/*     */       
/*  90 */       String line = null;
/*  91 */       while ((line = br.readLine()) != null) {
/*  92 */         if (line.toLowerCase().startsWith(this.CONTENT_LENGTH)) {
/*  93 */           String[] parts = line.split(":");
/*  94 */           if (parts.length == 2) {
/*  95 */             return Integer.parseInt(parts[1].trim());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 101 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage readFrame() throws IOException {
/* 112 */     if (!this.open) {
/* 113 */       return null;
/*     */     }
/*     */     
/* 116 */     mark(100100);
/*     */     
/* 118 */     int n = getStartOfSequence(this, this.SOI_MARKER);
/*     */     
/* 120 */     reset();
/*     */     
/* 122 */     byte[] header = new byte[n];
/*     */     
/* 124 */     readFully(header);
/*     */     
/* 126 */     int length = -1;
/*     */     try {
/* 128 */       length = parseContentLength(header);
/* 129 */     } catch (NumberFormatException e) {
/* 130 */       length = getEndOfSeqeunce(this, this.EOI_MARKER);
/*     */     } 
/*     */     
/* 133 */     if (length == 0) {
/* 134 */       LOG.error("Invalid MJPEG stream, EOI (0xFF,0xD9) not found!");
/*     */     }
/*     */     
/* 137 */     reset();
/*     */     
/* 139 */     byte[] frame = new byte[length];
/*     */     
/* 141 */     skipBytes(n);
/*     */     
/* 143 */     readFully(frame);
/*     */     
/* 145 */     try (ByteArrayInputStream bais = new ByteArrayInputStream(frame)) {
/* 146 */       return ImageIO.read(bais);
/* 147 */     } catch (IOException e) {
/* 148 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*     */     try {
/* 155 */       super.close();
/*     */     } finally {
/* 157 */       this.open = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isClosed() {
/* 162 */     return !this.open;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webca\\util\MjpegInputStream.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */