/*    */ package com.github.sarxos.webcam.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum OsUtils
/*    */ {
/* 14 */   WIN,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 19 */   NIX,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 24 */   OSX;
/*    */   static {
/* 26 */     os = null;
/*    */   }
/*    */ 
/*    */   
/*    */   private static OsUtils os;
/*    */ 
/*    */   
/*    */   public static final OsUtils getOS() {
/* 34 */     if (os == null) {
/* 35 */       String osp = System.getProperty("os.name").toLowerCase();
/* 36 */       if (osp.indexOf("win") >= 0) {
/* 37 */         os = WIN;
/* 38 */       } else if (osp.indexOf("mac") >= 0) {
/* 39 */         os = OSX;
/* 40 */       } else if (osp.indexOf("nix") >= 0 || osp.indexOf("nux") >= 0) {
/* 41 */         os = NIX;
/*    */       } else {
/* 43 */         throw new RuntimeException(osp + " is not supported");
/*    */       } 
/*    */     } 
/* 46 */     return os;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webca\\util\OsUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */