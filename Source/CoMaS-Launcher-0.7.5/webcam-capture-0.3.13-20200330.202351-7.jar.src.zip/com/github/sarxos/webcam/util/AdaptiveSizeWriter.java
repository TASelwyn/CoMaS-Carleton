/*    */ package com.github.sarxos.webcam.util;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import javax.imageio.IIOImage;
/*    */ import javax.imageio.ImageIO;
/*    */ import javax.imageio.ImageWriter;
/*    */ import javax.imageio.plugins.jpeg.JPEGImageWriteParam;
/*    */ import javax.imageio.stream.MemoryCacheImageOutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AdaptiveSizeWriter
/*    */ {
/*    */   private static final float INITIAL_QUALITY = 1.0F;
/*    */   private volatile int size;
/* 25 */   private final ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 26 */   private float quality = 1.0F;
/*    */   
/*    */   public AdaptiveSizeWriter(int size) {
/* 29 */     this.size = size;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] write(BufferedImage bi) {
/* 37 */     int m = this.size;
/* 38 */     int s = 0;
/* 39 */     int i = 0;
/*    */     do {
/* 41 */       if ((s = compress(bi, this.quality)) <= m)
/* 42 */         continue;  this.quality = (float)(this.quality * 0.75D);
/* 43 */       if (i++ >= 20) {
/*    */         break;
/*    */       }
/*    */     }
/* 47 */     while (s > m);
/*    */     
/* 49 */     return this.baos.toByteArray();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private int compress(BufferedImage bi, float quality) {
/* 61 */     this.baos.reset();
/*    */     
/* 63 */     JPEGImageWriteParam params = new JPEGImageWriteParam(null);
/* 64 */     params.setCompressionMode(2);
/* 65 */     params.setCompressionQuality(quality);
/*    */     
/* 67 */     try (MemoryCacheImageOutputStream mcios = new MemoryCacheImageOutputStream(this.baos)) {
/* 68 */       ImageWriter writer = ImageIO.getImageWritersByFormatName("jpg").next();
/* 69 */       writer.setOutput(mcios);
/* 70 */       writer.write(null, new IIOImage(bi, null, null), params);
/* 71 */     } catch (IOException e) {
/* 72 */       throw new IllegalStateException(e);
/*    */     } 
/*    */     
/* 75 */     return this.baos.size();
/*    */   }
/*    */   
/*    */   public int getSize() {
/* 79 */     return this.size;
/*    */   }
/*    */   
/*    */   public void setSize(int size) {
/* 83 */     if (this.size != size) {
/* 84 */       this.size = size;
/* 85 */       this.quality = 1.0F;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webca\\util\AdaptiveSizeWriter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */