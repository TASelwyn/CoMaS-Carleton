/*     */ package com.github.sarxos.webcam.util.jh;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JHBlurFilter
/*     */   extends JHFilter
/*     */ {
/*     */   private float hRadius;
/*     */   private float vRadius;
/*  31 */   private int iterations = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean premultiplyAlpha = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JHBlurFilter() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JHBlurFilter(float hRadius, float vRadius, int iterations) {
/*  48 */     this.hRadius = hRadius;
/*  49 */     this.vRadius = vRadius;
/*  50 */     this.iterations = iterations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPremultiplyAlpha(boolean premultiplyAlpha) {
/*  60 */     this.premultiplyAlpha = premultiplyAlpha;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getPremultiplyAlpha() {
/*  70 */     return this.premultiplyAlpha;
/*     */   }
/*     */ 
/*     */   
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/*  75 */     int width = src.getWidth();
/*  76 */     int height = src.getHeight();
/*     */     
/*  78 */     if (dst == null) {
/*  79 */       dst = createCompatibleDestImage(src, null);
/*     */     }
/*     */     
/*  82 */     int[] inPixels = new int[width * height];
/*  83 */     int[] outPixels = new int[width * height];
/*  84 */     getRGB(src, 0, 0, width, height, inPixels);
/*     */     
/*  86 */     if (this.premultiplyAlpha) {
/*  87 */       premultiply(inPixels, 0, inPixels.length);
/*     */     }
/*  89 */     for (int i = 0; i < this.iterations; i++) {
/*  90 */       blur(inPixels, outPixels, width, height, this.hRadius);
/*  91 */       blur(outPixels, inPixels, height, width, this.vRadius);
/*     */     } 
/*  93 */     blurFractional(inPixels, outPixels, width, height, this.hRadius);
/*  94 */     blurFractional(outPixels, inPixels, height, width, this.vRadius);
/*  95 */     if (this.premultiplyAlpha) {
/*  96 */       unpremultiply(inPixels, 0, inPixels.length);
/*     */     }
/*     */     
/*  99 */     setRGB(dst, 0, 0, width, height, inPixels);
/* 100 */     return dst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void blur(int[] in, int[] out, int width, int height, float radius) {
/* 113 */     int widthMinus1 = width - 1;
/* 114 */     int r = (int)radius;
/* 115 */     int tableSize = 2 * r + 1;
/* 116 */     int[] divide = new int[256 * tableSize];
/*     */     
/* 118 */     for (int i = 0; i < 256 * tableSize; i++) {
/* 119 */       divide[i] = i / tableSize;
/*     */     }
/*     */     
/* 122 */     int inIndex = 0;
/*     */     
/* 124 */     for (int y = 0; y < height; y++) {
/* 125 */       int outIndex = y;
/* 126 */       int ta = 0, tr = 0, tg = 0, tb = 0;
/*     */       
/* 128 */       for (int j = -r; j <= r; j++) {
/* 129 */         int rgb = in[inIndex + clamp(j, 0, width - 1)];
/* 130 */         ta += rgb >> 24 & 0xFF;
/* 131 */         tr += rgb >> 16 & 0xFF;
/* 132 */         tg += rgb >> 8 & 0xFF;
/* 133 */         tb += rgb & 0xFF;
/*     */       } 
/*     */       
/* 136 */       for (int x = 0; x < width; x++) {
/* 137 */         out[outIndex] = divide[ta] << 24 | divide[tr] << 16 | divide[tg] << 8 | divide[tb];
/*     */         
/* 139 */         int i1 = x + r + 1;
/* 140 */         if (i1 > widthMinus1) {
/* 141 */           i1 = widthMinus1;
/*     */         }
/* 143 */         int i2 = x - r;
/* 144 */         if (i2 < 0) {
/* 145 */           i2 = 0;
/*     */         }
/* 147 */         int rgb1 = in[inIndex + i1];
/* 148 */         int rgb2 = in[inIndex + i2];
/*     */         
/* 150 */         ta += (rgb1 >> 24 & 0xFF) - (rgb2 >> 24 & 0xFF);
/* 151 */         tr += (rgb1 & 0xFF0000) - (rgb2 & 0xFF0000) >> 16;
/* 152 */         tg += (rgb1 & 0xFF00) - (rgb2 & 0xFF00) >> 8;
/* 153 */         tb += (rgb1 & 0xFF) - (rgb2 & 0xFF);
/* 154 */         outIndex += height;
/*     */       } 
/* 156 */       inIndex += width;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void blurFractional(int[] in, int[] out, int width, int height, float radius) {
/* 161 */     radius -= (int)radius;
/* 162 */     float f = 1.0F / (1.0F + 2.0F * radius);
/* 163 */     int inIndex = 0;
/*     */     
/* 165 */     for (int y = 0; y < height; y++) {
/* 166 */       int outIndex = y;
/*     */       
/* 168 */       out[outIndex] = in[0];
/* 169 */       outIndex += height;
/* 170 */       for (int x = 1; x < width - 1; x++) {
/* 171 */         int i = inIndex + x;
/* 172 */         int rgb1 = in[i - 1];
/* 173 */         int rgb2 = in[i];
/* 174 */         int rgb3 = in[i + 1];
/*     */         
/* 176 */         int a1 = rgb1 >> 24 & 0xFF;
/* 177 */         int r1 = rgb1 >> 16 & 0xFF;
/* 178 */         int g1 = rgb1 >> 8 & 0xFF;
/* 179 */         int b1 = rgb1 & 0xFF;
/* 180 */         int a2 = rgb2 >> 24 & 0xFF;
/* 181 */         int r2 = rgb2 >> 16 & 0xFF;
/* 182 */         int g2 = rgb2 >> 8 & 0xFF;
/* 183 */         int b2 = rgb2 & 0xFF;
/* 184 */         int a3 = rgb3 >> 24 & 0xFF;
/* 185 */         int r3 = rgb3 >> 16 & 0xFF;
/* 186 */         int g3 = rgb3 >> 8 & 0xFF;
/* 187 */         int b3 = rgb3 & 0xFF;
/* 188 */         a1 = a2 + (int)((a1 + a3) * radius);
/* 189 */         r1 = r2 + (int)((r1 + r3) * radius);
/* 190 */         g1 = g2 + (int)((g1 + g3) * radius);
/* 191 */         b1 = b2 + (int)((b1 + b3) * radius);
/* 192 */         a1 = (int)(a1 * f);
/* 193 */         r1 = (int)(r1 * f);
/* 194 */         g1 = (int)(g1 * f);
/* 195 */         b1 = (int)(b1 * f);
/* 196 */         out[outIndex] = a1 << 24 | r1 << 16 | g1 << 8 | b1;
/* 197 */         outIndex += height;
/*     */       } 
/* 199 */       out[outIndex] = in[width - 1];
/* 200 */       inIndex += width;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHRadius(float hRadius) {
/* 211 */     this.hRadius = hRadius;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getHRadius() {
/* 221 */     return this.hRadius;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVRadius(float vRadius) {
/* 231 */     this.vRadius = vRadius;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getVRadius() {
/* 241 */     return this.vRadius;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRadius(float radius) {
/* 251 */     this.hRadius = this.vRadius = radius;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getRadius() {
/* 261 */     return this.hRadius;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIterations(int iterations) {
/* 271 */     this.iterations = iterations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIterations() {
/* 281 */     return this.iterations;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 286 */     return "Blur/Box Blur...";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void premultiply(int[] p, int offset, int length) {
/* 297 */     length += offset;
/* 298 */     for (int i = offset; i < length; i++) {
/* 299 */       int rgb = p[i];
/* 300 */       int a = rgb >> 24 & 0xFF;
/* 301 */       int r = rgb >> 16 & 0xFF;
/* 302 */       int g = rgb >> 8 & 0xFF;
/* 303 */       int b = rgb & 0xFF;
/* 304 */       float f = a * 0.003921569F;
/* 305 */       r = (int)(r * f);
/* 306 */       g = (int)(g * f);
/* 307 */       b = (int)(b * f);
/* 308 */       p[i] = a << 24 | r << 16 | g << 8 | b;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void unpremultiply(int[] p, int offset, int length) {
/* 320 */     length += offset;
/* 321 */     for (int i = offset; i < length; i++) {
/* 322 */       int rgb = p[i];
/* 323 */       int a = rgb >> 24 & 0xFF;
/* 324 */       int r = rgb >> 16 & 0xFF;
/* 325 */       int g = rgb >> 8 & 0xFF;
/* 326 */       int b = rgb & 0xFF;
/* 327 */       if (a != 0 && a != 255) {
/* 328 */         float f = 255.0F / a;
/* 329 */         r = (int)(r * f);
/* 330 */         g = (int)(g * f);
/* 331 */         b = (int)(b * f);
/* 332 */         if (r > 255) {
/* 333 */           r = 255;
/*     */         }
/* 335 */         if (g > 255) {
/* 336 */           g = 255;
/*     */         }
/* 338 */         if (b > 255) {
/* 339 */           b = 255;
/*     */         }
/* 341 */         p[i] = a << 24 | r << 16 | g << 8 | b;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int clamp(int x, int a, int b) {
/* 355 */     return (x < a) ? a : ((x > b) ? b : x);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webca\\util\jh\JHBlurFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */