/*    */ package com.github.sarxos.webcam.util;
/*    */ 
/*    */ import com.github.sarxos.webcam.WebcamException;
/*    */ import java.util.concurrent.CountDownLatch;
/*    */ import java.util.concurrent.atomic.AtomicBoolean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebcamInitializer
/*    */ {
/*    */   private final Initializable initializable;
/* 17 */   private final AtomicBoolean initialized = new AtomicBoolean(false);
/* 18 */   private final CountDownLatch latch = new CountDownLatch(1);
/*    */   
/*    */   public WebcamInitializer(Initializable initializable) {
/* 21 */     this.initializable = initializable;
/*    */   }
/*    */   
/*    */   public void initialize() {
/* 25 */     if (this.initialized.compareAndSet(false, true)) {
/*    */       try {
/* 27 */         this.initializable.initialize();
/* 28 */       } catch (Exception e) {
/* 29 */         throw new WebcamException(e);
/*    */       } finally {
/* 31 */         this.latch.countDown();
/*    */       } 
/*    */     } else {
/*    */       try {
/* 35 */         this.latch.await();
/* 36 */       } catch (InterruptedException e) {
/*    */         return;
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public void teardown() {
/* 43 */     if (this.initialized.compareAndSet(true, false)) {
/*    */       try {
/* 45 */         this.initializable.teardown();
/* 46 */       } catch (Exception e) {
/* 47 */         throw new WebcamException(e);
/*    */       } 
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isInitialized() {
/* 53 */     return this.initialized.get();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webca\\util\WebcamInitializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */