/*    */ package com.github.sarxos.webcam.util.jh;
/*    */ 
/*    */ import com.github.sarxos.webcam.util.ImageUtils;
/*    */ import java.awt.image.BufferedImage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JHNormalizeFilter
/*    */   extends JHFilter
/*    */ {
/*    */   public BufferedImage filter(BufferedImage src, BufferedImage dest) {
/* 13 */     int w = src.getWidth();
/* 14 */     int h = src.getHeight();
/*    */     
/* 16 */     int max = 1;
/*    */     int x;
/* 18 */     for (x = 0; x < w; x++) {
/* 19 */       for (int y = 0; y < h; y++) {
/*    */         
/* 21 */         int c = src.getRGB(x, y);
/* 22 */         int a = ImageUtils.clamp(c >> 24 & 0xFF);
/* 23 */         int r = ImageUtils.clamp(c >> 16 & 0xFF);
/* 24 */         int g = ImageUtils.clamp(c >> 8 & 0xFF);
/* 25 */         int b = ImageUtils.clamp(c & 0xFF);
/* 26 */         int i = a << 24 | r << 16 | g << 8 | b;
/*    */         
/* 28 */         if (i > max) {
/* 29 */           max = i;
/*    */         }
/*    */       } 
/*    */     } 
/*    */     
/* 34 */     for (x = 0; x < w; x++) {
/* 35 */       for (int y = 0; y < h; y++) {
/* 36 */         int c = src.getRGB(x, y);
/* 37 */         int i = c * 256 / max;
/* 38 */         dest.setRGB(x, y, i);
/*    */       } 
/*    */     } 
/*    */     
/* 42 */     return dest;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webca\\util\jh\JHNormalizeFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */