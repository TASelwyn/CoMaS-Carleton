/*     */ package com.github.sarxos.webcam.util;
/*     */ 
/*     */ import com.github.sarxos.webcam.WebcamException;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.DataBufferByte;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.imageio.ImageIO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageUtils
/*     */ {
/*     */   public static final String FORMAT_GIF = "GIF";
/*     */   public static final String FORMAT_PNG = "PNG";
/*     */   public static final String FORMAT_JPG = "JPG";
/*     */   public static final String FORMAT_BMP = "BMP";
/*     */   public static final String FORMAT_WBMP = "WBMP";
/*     */   
/*     */   public static byte[] toByteArray(BufferedImage image, String format) {
/*  50 */     byte[] bytes = null;
/*  51 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*     */     
/*     */     try {
/*  54 */       ImageIO.write(image, format, baos);
/*  55 */       bytes = baos.toByteArray();
/*  56 */     } catch (IOException e) {
/*  57 */       throw new WebcamException(e);
/*     */     } finally {
/*     */       try {
/*  60 */         baos.close();
/*  61 */       } catch (IOException e) {
/*  62 */         throw new WebcamException(e);
/*     */       } 
/*     */     } 
/*     */     
/*  66 */     return bytes;
/*     */   }
/*     */   
/*     */   public static BufferedImage readFromResource(String resource) {
/*  70 */     InputStream is = null;
/*     */     try {
/*  72 */       return ImageIO.read(is = ImageUtils.class.getClassLoader().getResourceAsStream(resource));
/*  73 */     } catch (IOException e) {
/*  74 */       throw new IllegalStateException(e);
/*     */     } finally {
/*  76 */       if (is != null) {
/*     */         try {
/*  78 */           is.close();
/*  79 */         } catch (IOException e) {
/*  80 */           throw new IllegalStateException(e);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static BufferedImage createEmptyImage(BufferedImage source) {
/*  87 */     return new BufferedImage(source.getWidth(), source.getHeight(), 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int clamp(int c) {
/*  94 */     if (c < 0) {
/*  95 */       return 0;
/*     */     }
/*  97 */     if (c > 255) {
/*  98 */       return 255;
/*     */     }
/* 100 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] imageToBytes(BufferedImage bi) {
/* 110 */     return ((DataBufferByte)bi.getData().getDataBuffer()).getData();
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webca\\util\ImageUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */