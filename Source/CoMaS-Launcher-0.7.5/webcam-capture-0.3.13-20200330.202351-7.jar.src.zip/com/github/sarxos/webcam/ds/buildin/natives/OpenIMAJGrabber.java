/*    */ package com.github.sarxos.webcam.ds.buildin.natives;
/*    */ 
/*    */ import org.bridj.BridJ;
/*    */ import org.bridj.Platform;
/*    */ import org.bridj.Pointer;
/*    */ import org.bridj.StructObject;
/*    */ import org.bridj.ann.Field;
/*    */ import org.bridj.ann.Library;
/*    */ import org.bridj.ann.Runtime;
/*    */ import org.bridj.cpp.CPPObject;
/*    */ import org.bridj.cpp.CPPRuntime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Library("OpenIMAJGrabber")
/*    */ @Runtime(CPPRuntime.class)
/*    */ public class OpenIMAJGrabber
/*    */   extends CPPObject
/*    */ {
/*    */   static {
/* 57 */     Platform.addEmbeddedLibraryResourceRoot("com/github/sarxos/webcam/ds/buildin/lib/");
/* 58 */     BridJ.register();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public OpenIMAJGrabber() {}
/*    */ 
/*    */   
/*    */   public OpenIMAJGrabber(Pointer pointer) {
/* 67 */     super(pointer, new Object[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Field(0)
/*    */   protected Pointer<?> data() {
/* 91 */     return this.io.getPointerField((StructObject)this, 0);
/*    */   }
/*    */ 
/*    */   
/*    */   @Field(0)
/*    */   protected OpenIMAJGrabber data(Pointer<?> data) {
/* 97 */     this.io.setPointerField((StructObject)this, 0, data);
/* 98 */     return this;
/*    */   }
/*    */   
/*    */   public native Pointer<DeviceList> getVideoDevices();
/*    */   
/*    */   public native Pointer<Byte> getImage();
/*    */   
/*    */   public native int nextFrame();
/*    */   
/*    */   public native void setTimeout(int paramInt);
/*    */   
/*    */   public native boolean startSession(int paramInt1, int paramInt2, int paramInt3);
/*    */   
/*    */   public native boolean startSession(int paramInt1, int paramInt2, int paramInt3, Pointer<Device> paramPointer);
/*    */   
/*    */   public native void stopSession();
/*    */   
/*    */   public native int getWidth();
/*    */   
/*    */   public native int getHeight();
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\ds\buildin\natives\OpenIMAJGrabber.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */