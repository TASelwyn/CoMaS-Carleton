/*     */ package com.github.sarxos.webcam.ds.buildin;
/*     */ 
/*     */ import com.github.sarxos.webcam.WebcamDevice;
/*     */ import com.github.sarxos.webcam.WebcamException;
/*     */ import com.github.sarxos.webcam.WebcamExceptionHandler;
/*     */ import com.github.sarxos.webcam.WebcamResolution;
/*     */ import com.github.sarxos.webcam.WebcamTask;
/*     */ import com.github.sarxos.webcam.ds.buildin.natives.Device;
/*     */ import com.github.sarxos.webcam.ds.buildin.natives.DeviceList;
/*     */ import com.github.sarxos.webcam.ds.buildin.natives.OpenIMAJGrabber;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.color.ColorSpace;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.ComponentColorModel;
/*     */ import java.awt.image.ComponentSampleModel;
/*     */ import java.awt.image.DataBufferByte;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.bridj.NativeObject;
/*     */ import org.bridj.Pointer;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebcamDefaultDevice
/*     */   implements WebcamDevice, WebcamDevice.BufferAccess, Runnable, WebcamDevice.FPSSource
/*     */ {
/*  38 */   private static final Logger LOG = LoggerFactory.getLogger(WebcamDefaultDevice.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int DEVICE_BUFFER_SIZE = 5;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   private static final Dimension[] DIMENSIONS = new Dimension[] { WebcamResolution.QQVGA
/*  50 */       .getSize(), WebcamResolution.QVGA
/*  51 */       .getSize(), WebcamResolution.VGA
/*  52 */       .getSize() };
/*     */   
/*     */   private class NextFrameTask
/*     */     extends WebcamTask
/*     */   {
/*  57 */     private final AtomicInteger result = new AtomicInteger(0);
/*     */     
/*     */     public NextFrameTask(WebcamDevice device) {
/*  60 */       super(device);
/*     */     }
/*     */     
/*     */     public int nextFrame() {
/*     */       try {
/*  65 */         process();
/*  66 */       } catch (InterruptedException e) {
/*  67 */         WebcamDefaultDevice.LOG.debug("Image buffer request interrupted", e);
/*     */       } 
/*  69 */       return this.result.get();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected void handle() {
/*  75 */       WebcamDefaultDevice device = (WebcamDefaultDevice)getDevice();
/*  76 */       if (!device.isOpen()) {
/*     */         return;
/*     */       }
/*     */       
/*  80 */       this.result.set(WebcamDefaultDevice.this.grabber.nextFrame());
/*  81 */       WebcamDefaultDevice.this.fresh.set(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   private static final int[] BAND_OFFSETS = new int[] { 0, 1, 2 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   private static final int[] BITS = new int[] { 8, 8, 8 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   private static final int[] OFFSET = new int[] { 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int DATA_TYPE = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   private static final ColorSpace COLOR_SPACE = ColorSpace.getInstance(1000);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   private int timeout = 5000;
/*     */   
/* 115 */   private OpenIMAJGrabber grabber = null;
/* 116 */   private Device device = null;
/* 117 */   private Dimension size = null;
/* 118 */   private ComponentSampleModel smodel = null;
/* 119 */   private ColorModel cmodel = null;
/*     */   
/*     */   private boolean failOnSizeMismatch = false;
/* 122 */   private final AtomicBoolean disposed = new AtomicBoolean(false);
/* 123 */   private final AtomicBoolean open = new AtomicBoolean(false);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   private final AtomicBoolean fresh = new AtomicBoolean(false);
/*     */   
/* 130 */   private Thread refresher = null;
/*     */   
/* 132 */   private String name = null;
/* 133 */   private String id = null;
/* 134 */   private String fullname = null;
/*     */   
/* 136 */   private long t1 = -1L;
/* 137 */   private long t2 = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   private volatile double fps = 0.0D;
/*     */   
/*     */   protected WebcamDefaultDevice(Device device) {
/* 145 */     this.device = device;
/* 146 */     this.name = device.getNameStr();
/* 147 */     this.id = device.getIdentifierStr();
/* 148 */     this.fullname = String.format("%s %s", new Object[] { this.name, this.id });
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 153 */     return this.fullname;
/*     */   }
/*     */   
/*     */   public String getDeviceName() {
/* 157 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getDeviceId() {
/* 161 */     return this.id;
/*     */   }
/*     */   
/*     */   public Device getDeviceRef() {
/* 165 */     return this.device;
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension[] getResolutions() {
/* 170 */     return DIMENSIONS;
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getResolution() {
/* 175 */     if (this.size == null) {
/* 176 */       this.size = getResolutions()[0];
/*     */     }
/* 178 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResolution(Dimension size) {
/* 184 */     if (size == null) {
/* 185 */       throw new IllegalArgumentException("Size cannot be null");
/*     */     }
/*     */     
/* 188 */     if (this.open.get()) {
/* 189 */       throw new IllegalStateException("Cannot change resolution when webcam is open, please close it first");
/*     */     }
/*     */     
/* 192 */     this.size = size;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer getImageBytes() {
/* 198 */     if (this.disposed.get()) {
/* 199 */       LOG.debug("Webcam is disposed, image will be null");
/* 200 */       return null;
/*     */     } 
/* 202 */     if (!this.open.get()) {
/* 203 */       LOG.debug("Webcam is closed, image will be null");
/* 204 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 209 */     if (this.fresh.compareAndSet(false, true)) {
/* 210 */       updateFrameBuffer();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 215 */     LOG.trace("Webcam grabber get image pointer");
/*     */     
/* 217 */     Pointer<Byte> image = this.grabber.getImage();
/* 218 */     this.fresh.set(false);
/*     */     
/* 220 */     if (image == null) {
/* 221 */       LOG.warn("Null array pointer found instead of image");
/* 222 */       return null;
/*     */     } 
/*     */     
/* 225 */     int length = this.size.width * this.size.height * 3;
/*     */     
/* 227 */     LOG.trace("Webcam device get buffer, read {} bytes", Integer.valueOf(length));
/*     */     
/* 229 */     return image.getByteBuffer(length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void getImageBytes(ByteBuffer target) {
/* 235 */     if (this.disposed.get()) {
/* 236 */       LOG.debug("Webcam is disposed, image will be null");
/*     */       return;
/*     */     } 
/* 239 */     if (!this.open.get()) {
/* 240 */       LOG.debug("Webcam is closed, image will be null");
/*     */       
/*     */       return;
/*     */     } 
/* 244 */     int minSize = this.size.width * this.size.height * 3;
/* 245 */     int curSize = target.remaining();
/*     */     
/* 247 */     if (minSize > curSize) {
/* 248 */       throw new IllegalArgumentException(String.format("Not enough remaining space in target buffer (%d necessary vs %d remaining)", new Object[] { Integer.valueOf(minSize), Integer.valueOf(curSize) }));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 253 */     if (this.fresh.compareAndSet(false, true)) {
/* 254 */       updateFrameBuffer();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 259 */     LOG.trace("Webcam grabber get image pointer");
/*     */     
/* 261 */     Pointer<Byte> image = this.grabber.getImage();
/* 262 */     this.fresh.set(false);
/*     */     
/* 264 */     if (image == null) {
/* 265 */       LOG.warn("Null array pointer found instead of image");
/*     */       
/*     */       return;
/*     */     } 
/* 269 */     LOG.trace("Webcam device read buffer {} bytes", Integer.valueOf(minSize));
/*     */     
/* 271 */     image = image.validBytes(minSize);
/* 272 */     image.getBytes(target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage getImage() {
/* 279 */     ByteBuffer buffer = getImageBytes();
/*     */     
/* 281 */     if (buffer == null) {
/* 282 */       LOG.error("Images bytes buffer is null!");
/* 283 */       return null;
/*     */     } 
/*     */     
/* 286 */     byte[] bytes = new byte[this.size.width * this.size.height * 3];
/* 287 */     byte[][] data = { bytes };
/*     */     
/* 289 */     buffer.get(bytes);
/*     */     
/* 291 */     DataBufferByte dbuf = new DataBufferByte(data, bytes.length, OFFSET);
/* 292 */     WritableRaster raster = Raster.createWritableRaster(this.smodel, dbuf, null);
/*     */     
/* 294 */     BufferedImage bi = new BufferedImage(this.cmodel, raster, false, null);
/* 295 */     bi.flush();
/*     */     
/* 297 */     return bi;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() {
/* 303 */     if (this.disposed.get()) {
/*     */       return;
/*     */     }
/*     */     
/* 307 */     LOG.debug("Opening webcam device {}", getName());
/*     */     
/* 309 */     if (this.size == null) {
/* 310 */       this.size = getResolutions()[0];
/*     */     }
/* 312 */     if (this.size == null) {
/* 313 */       throw new RuntimeException("The resolution size cannot be null");
/*     */     }
/*     */     
/* 316 */     LOG.debug("Webcam device {} starting session, size {}", this.device.getIdentifierStr(), this.size);
/*     */     
/* 318 */     this.grabber = new OpenIMAJGrabber();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 326 */     DeviceList list = (DeviceList)this.grabber.getVideoDevices().get();
/* 327 */     for (Device d : list.asArrayList()) {
/* 328 */       d.getNameStr();
/* 329 */       d.getIdentifierStr();
/*     */     } 
/*     */     
/* 332 */     boolean started = this.grabber.startSession(this.size.width, this.size.height, 50, Pointer.pointerTo((NativeObject)this.device));
/* 333 */     if (!started) {
/* 334 */       throw new WebcamException("Cannot start native grabber!");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 340 */     this.grabber.setTimeout(this.timeout);
/*     */     
/* 342 */     LOG.debug("Webcam device session started");
/*     */     
/* 344 */     Dimension size2 = new Dimension(this.grabber.getWidth(), this.grabber.getHeight());
/*     */     
/* 346 */     int w1 = this.size.width;
/* 347 */     int w2 = size2.width;
/* 348 */     int h1 = this.size.height;
/* 349 */     int h2 = size2.height;
/*     */     
/* 351 */     if (w1 != w2 || h1 != h2) {
/*     */       
/* 353 */       if (this.failOnSizeMismatch) {
/* 354 */         throw new WebcamException(String.format("Different size obtained vs requested - [%dx%d] vs [%dx%d]", new Object[] { Integer.valueOf(w1), Integer.valueOf(h1), Integer.valueOf(w2), Integer.valueOf(h2) }));
/*     */       }
/*     */       
/* 357 */       Object[] args = { Integer.valueOf(w1), Integer.valueOf(h1), Integer.valueOf(w2), Integer.valueOf(h2), Integer.valueOf(w2), Integer.valueOf(h2) };
/* 358 */       LOG.warn("Different size obtained vs requested - [{}x{}] vs [{}x{}]. Setting correct one. New size is [{}x{}]", args);
/*     */       
/* 360 */       this.size = new Dimension(w2, h2);
/*     */     } 
/*     */     
/* 363 */     this.smodel = new ComponentSampleModel(0, this.size.width, this.size.height, 3, this.size.width * 3, BAND_OFFSETS);
/* 364 */     this.cmodel = new ComponentColorModel(COLOR_SPACE, BITS, false, false, 1, 0);
/*     */ 
/*     */ 
/*     */     
/* 368 */     LOG.debug("Clear memory buffer");
/*     */     
/* 370 */     clearMemoryBuffer();
/*     */ 
/*     */ 
/*     */     
/* 374 */     LOG.debug("Webcam device {} is now open", this);
/*     */     
/* 376 */     this.open.set(true);
/*     */ 
/*     */ 
/*     */     
/* 380 */     this.refresher = startFramesRefresher();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void clearMemoryBuffer() {
/* 388 */     for (int i = 0; i < 5; i++) {
/* 389 */       this.grabber.nextFrame();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Thread startFramesRefresher() {
/* 399 */     Thread refresher = new Thread(this, String.format("frames-refresher-[%s]", new Object[] { this.id }));
/* 400 */     refresher.setUncaughtExceptionHandler((Thread.UncaughtExceptionHandler)WebcamExceptionHandler.getInstance());
/* 401 */     refresher.setDaemon(true);
/* 402 */     refresher.start();
/* 403 */     return refresher;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 409 */     if (!this.open.compareAndSet(true, false)) {
/*     */       return;
/*     */     }
/*     */     
/* 413 */     LOG.debug("Closing webcam device");
/*     */     
/* 415 */     this.grabber.stopSession();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 421 */     if (!this.disposed.compareAndSet(false, true)) {
/*     */       return;
/*     */     }
/*     */     
/* 425 */     LOG.debug("Disposing webcam device {}", getName());
/*     */     
/* 427 */     close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFailOnSizeMismatch(boolean fail) {
/* 437 */     this.failOnSizeMismatch = fail;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/* 442 */     return this.open.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTimeout() {
/* 451 */     return this.timeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeout(int timeout) {
/* 460 */     if (isOpen()) {
/* 461 */       throw new WebcamException("Timeout must be set before webcam is open");
/*     */     }
/* 463 */     this.timeout = timeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateFrameBuffer() {
/* 471 */     LOG.trace("Next frame");
/*     */     
/* 473 */     if (this.t1 == -1L || this.t2 == -1L) {
/* 474 */       this.t1 = System.currentTimeMillis();
/* 475 */       this.t2 = System.currentTimeMillis();
/*     */     } 
/*     */     
/* 478 */     int result = (new NextFrameTask(this)).nextFrame();
/*     */     
/* 480 */     this.t1 = this.t2;
/* 481 */     this.t2 = System.currentTimeMillis();
/*     */     
/* 483 */     this.fps = (4.0D * this.fps + (1000L / (this.t2 - this.t1 + 1L))) / 5.0D;
/*     */     
/* 485 */     if (result == -1) {
/* 486 */       LOG.error("Timeout when requesting image!");
/* 487 */     } else if (result < -1) {
/* 488 */       LOG.error("Error requesting new frame!");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     do {
/* 497 */       if (Thread.interrupted()) {
/* 498 */         LOG.debug("Refresher has been interrupted");
/*     */         
/*     */         return;
/*     */       } 
/* 502 */       if (!this.open.get()) {
/* 503 */         LOG.debug("Cancelling refresher");
/*     */         
/*     */         return;
/*     */       } 
/* 507 */       updateFrameBuffer();
/*     */     }
/* 509 */     while (this.open.get());
/*     */   }
/*     */ 
/*     */   
/*     */   public double getFPS() {
/* 514 */     return this.fps;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\ds\buildin\WebcamDefaultDevice.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */