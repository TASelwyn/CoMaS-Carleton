/*    */ package com.github.sarxos.webcam.ds.cgt;
/*    */ 
/*    */ import com.github.sarxos.webcam.WebcamDevice;
/*    */ import com.github.sarxos.webcam.WebcamDriver;
/*    */ import com.github.sarxos.webcam.WebcamTask;
/*    */ import java.awt.image.BufferedImage;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebcamGetImageTask
/*    */   extends WebcamTask
/*    */ {
/* 15 */   private static final Logger LOG = LoggerFactory.getLogger(WebcamGetImageTask.class);
/*    */   
/* 17 */   private volatile BufferedImage image = null;
/*    */   
/*    */   public WebcamGetImageTask(WebcamDriver driver, WebcamDevice device) {
/* 20 */     super(driver, device);
/*    */   }
/*    */ 
/*    */   
/*    */   public BufferedImage getImage() {
/*    */     try {
/* 26 */       process();
/* 27 */     } catch (InterruptedException e) {
/* 28 */       LOG.debug("Interrupted exception", e);
/* 29 */       return null;
/*    */     } 
/*    */     
/* 32 */     return this.image;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void handle() {
/* 38 */     WebcamDevice device = getDevice();
/* 39 */     if (!device.isOpen()) {
/*    */       return;
/*    */     }
/*    */     
/* 43 */     this.image = device.getImage();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\ds\cgt\WebcamGetImageTask.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */