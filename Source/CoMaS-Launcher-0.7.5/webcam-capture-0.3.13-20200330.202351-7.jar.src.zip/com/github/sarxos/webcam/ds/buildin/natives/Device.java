/*     */ package com.github.sarxos.webcam.ds.buildin.natives;
/*     */ 
/*     */ import org.bridj.Pointer;
/*     */ import org.bridj.StructObject;
/*     */ import org.bridj.ann.Field;
/*     */ import org.bridj.ann.Library;
/*     */ import org.bridj.ann.Runtime;
/*     */ import org.bridj.cpp.CPPObject;
/*     */ import org.bridj.cpp.CPPRuntime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Library("OpenIMAJGrabber")
/*     */ @Runtime(CPPRuntime.class)
/*     */ public final class Device
/*     */   extends CPPObject
/*     */ {
/*     */   public Device() {}
/*     */   
/*     */   public Device(Pointer pointer) {
/*  62 */     super(pointer, new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   @Field(0)
/*     */   protected Pointer<Byte> name() {
/*  68 */     return this.io.getPointerField((StructObject)this, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   @Field(0)
/*     */   protected Device name(Pointer<Byte> name) {
/*  74 */     this.io.setPointerField((StructObject)this, 0, name);
/*  75 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Field(1)
/*     */   protected Pointer<Byte> identifier() {
/*  81 */     return this.io.getPointerField((StructObject)this, 1);
/*     */   }
/*     */ 
/*     */   
/*     */   @Field(1)
/*     */   protected Device identifier(Pointer<Byte> identifier) {
/*  87 */     this.io.setPointerField((StructObject)this, 1, identifier);
/*  88 */     return this;
/*     */   }
/*     */   
/*     */   protected native Pointer<Byte> getName();
/*     */   
/*     */   public String getNameStr() {
/*  94 */     return getName().getCString();
/*     */   }
/*     */   
/*     */   protected native Pointer<Byte> getIdentifier();
/*     */   
/*     */   public String getIdentifierStr() {
/* 100 */     return getIdentifier().getCString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 109 */     return o.toString().equals(toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 118 */     return toString().hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 123 */     return String.format("Device[%s]=\"%s\"", new Object[] { getIdentifierStr(), getNameStr() });
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\ds\buildin\natives\Device.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */