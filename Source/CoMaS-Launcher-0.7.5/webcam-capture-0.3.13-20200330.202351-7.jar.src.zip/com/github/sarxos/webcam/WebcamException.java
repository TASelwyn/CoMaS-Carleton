/*    */ package com.github.sarxos.webcam;
/*    */ 
/*    */ public class WebcamException
/*    */   extends RuntimeException {
/*    */   private static final long serialVersionUID = 4305046981807594375L;
/*    */   
/*    */   public WebcamException(String message) {
/*  8 */     super(message);
/*    */   }
/*    */   
/*    */   public WebcamException(String message, Throwable cause) {
/* 12 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public WebcamException(Throwable cause) {
/* 16 */     super(cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */