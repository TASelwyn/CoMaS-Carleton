/*     */ package com.github.sarxos.webcam;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.EventObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebcamMotionEvent
/*     */   extends EventObject
/*     */ {
/*     */   private static final long serialVersionUID = -7245768099221999443L;
/*     */   private final double strength;
/*     */   private final Point cog;
/*     */   private final BufferedImage previousImage;
/*     */   private final BufferedImage currentImage;
/*     */   private ArrayList<Point> points;
/*     */   
/*     */   public WebcamMotionEvent(WebcamMotionDetector detector, double strength, Point cog) {
/*  31 */     this(detector, null, null, strength, cog);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebcamMotionEvent(WebcamMotionDetector detector, double strength, Point cog, ArrayList<Point> points) {
/*  43 */     this(detector, null, null, strength, cog, points);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebcamMotionEvent(WebcamMotionDetector detector, BufferedImage previousImage, BufferedImage currentImage, double strength, Point cog) {
/*  56 */     super(detector);
/*  57 */     this.previousImage = previousImage;
/*  58 */     this.currentImage = currentImage;
/*  59 */     this.strength = strength;
/*  60 */     this.cog = cog;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebcamMotionEvent(WebcamMotionDetector detector, BufferedImage previousImage, BufferedImage currentImage, double strength, Point cog, ArrayList<Point> points) {
/*  74 */     this(detector, previousImage, currentImage, strength, cog);
/*  75 */     this.points = points;
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayList<Point> getPoints() {
/*  80 */     return this.points;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getArea() {
/*  90 */     return this.strength;
/*     */   }
/*     */   
/*     */   public Point getCog() {
/*  94 */     return this.cog;
/*     */   }
/*     */   
/*     */   public Webcam getWebcam() {
/*  98 */     return getSource().getWebcam();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage getPreviousImage() {
/* 106 */     return this.previousImage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage getCurrentImage() {
/* 114 */     return this.currentImage;
/*     */   }
/*     */ 
/*     */   
/*     */   public WebcamMotionDetector getSource() {
/* 119 */     return (WebcamMotionDetector)super.getSource();
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamMotionEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */