package com.github.sarxos.webcam;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

public interface WebcamMotionDetectorAlgorithm {
  BufferedImage filter(BufferedImage paramBufferedImage);
  
  boolean detect(BufferedImage paramBufferedImage1, BufferedImage paramBufferedImage2);
  
  Point getCog();
  
  double getArea();
  
  void setPointRange(int paramInt);
  
  void setMaxPoints(int paramInt);
  
  int getPointRange();
  
  int getMaxPoints();
  
  ArrayList<Point> getPoints();
  
  void setDoNotEngageZones(List<Rectangle> paramList);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamMotionDetectorAlgorithm.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */