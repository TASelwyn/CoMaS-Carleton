/*      */ package com.github.sarxos.webcam;
/*      */ 
/*      */ import java.awt.AlphaComposite;
/*      */ import java.awt.BasicStroke;
/*      */ import java.awt.Color;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.GraphicsConfiguration;
/*      */ import java.awt.GraphicsEnvironment;
/*      */ import java.awt.RenderingHints;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.awt.image.ImageObserver;
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.util.HashMap;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.ResourceBundle;
/*      */ import java.util.concurrent.Executors;
/*      */ import java.util.concurrent.RejectedExecutionException;
/*      */ import java.util.concurrent.ScheduledExecutorService;
/*      */ import java.util.concurrent.ThreadFactory;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.SwingWorker;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WebcamPanel
/*      */   extends JPanel
/*      */   implements WebcamListener, PropertyChangeListener
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   
/*      */   public enum DrawMode
/*      */   {
/*   62 */     NONE,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   68 */     FILL,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   74 */     FIT;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class DefaultImageSupplier
/*      */     implements ImageSupplier
/*      */   {
/*      */     private final Webcam webcam;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public DefaultImageSupplier(Webcam webcam) {
/*  101 */       this.webcam = webcam;
/*      */     }
/*      */ 
/*      */     
/*      */     public BufferedImage get() {
/*  106 */       return this.webcam.getImage();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public class DefaultPainter
/*      */     implements Painter
/*      */   {
/*  146 */     private String name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  151 */     private long lastRepaintTime = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  156 */     private BufferedImage resizedImage = null;
/*      */ 
/*      */ 
/*      */     
/*      */     public void paintPanel(WebcamPanel owner, Graphics2D g2) {
/*  161 */       assert owner != null;
/*  162 */       assert g2 != null;
/*      */       
/*  164 */       Object antialiasing = g2.getRenderingHint(RenderingHints.KEY_ANTIALIASING);
/*      */       
/*  166 */       g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, WebcamPanel.this.isAntialiasingEnabled() ? RenderingHints.VALUE_ANTIALIAS_ON : RenderingHints.VALUE_ANTIALIAS_OFF);
/*  167 */       g2.setBackground(Color.BLACK);
/*  168 */       g2.fillRect(0, 0, WebcamPanel.this.getWidth(), WebcamPanel.this.getHeight());
/*      */       
/*  170 */       int cx = (WebcamPanel.this.getWidth() - 70) / 2;
/*  171 */       int cy = (WebcamPanel.this.getHeight() - 40) / 2;
/*      */       
/*  173 */       g2.setStroke(new BasicStroke(2.0F));
/*  174 */       g2.setColor(Color.LIGHT_GRAY);
/*  175 */       g2.fillRoundRect(cx, cy, 70, 40, 10, 10);
/*  176 */       g2.setColor(Color.WHITE);
/*  177 */       g2.fillOval(cx + 5, cy + 5, 30, 30);
/*  178 */       g2.setColor(Color.LIGHT_GRAY);
/*  179 */       g2.fillOval(cx + 10, cy + 10, 20, 20);
/*  180 */       g2.setColor(Color.WHITE);
/*  181 */       g2.fillOval(cx + 12, cy + 12, 16, 16);
/*  182 */       g2.fillRoundRect(cx + 50, cy + 5, 15, 10, 5, 5);
/*  183 */       g2.fillRect(cx + 63, cy + 25, 7, 2);
/*  184 */       g2.fillRect(cx + 63, cy + 28, 7, 2);
/*  185 */       g2.fillRect(cx + 63, cy + 31, 7, 2);
/*      */       
/*  187 */       g2.setColor(Color.DARK_GRAY);
/*  188 */       g2.setStroke(new BasicStroke(3.0F));
/*  189 */       g2.drawLine(0, 0, WebcamPanel.this.getWidth(), WebcamPanel.this.getHeight());
/*  190 */       g2.drawLine(0, WebcamPanel.this.getHeight(), WebcamPanel.this.getWidth(), 0);
/*      */ 
/*      */ 
/*      */       
/*  194 */       String strInitDevice = WebcamPanel.this.rb.getString("INITIALIZING_DEVICE");
/*  195 */       String strNoImage = WebcamPanel.this.rb.getString("NO_IMAGE");
/*  196 */       String strDeviceError = WebcamPanel.this.rb.getString("DEVICE_ERROR");
/*      */       
/*  198 */       if (WebcamPanel.this.errored) {
/*  199 */         str = strDeviceError;
/*      */       } else {
/*  201 */         str = WebcamPanel.this.starting ? strInitDevice : strNoImage;
/*      */       } 
/*      */       
/*  204 */       FontMetrics metrics = g2.getFontMetrics(WebcamPanel.this.getFont());
/*  205 */       int w = metrics.stringWidth(str);
/*  206 */       int h = metrics.getHeight();
/*      */       
/*  208 */       int x = (WebcamPanel.this.getWidth() - w) / 2;
/*  209 */       int y = cy - h;
/*      */       
/*  211 */       g2.setFont(WebcamPanel.this.getFont());
/*  212 */       g2.setColor(Color.WHITE);
/*  213 */       g2.drawString(str, x, y);
/*      */       
/*  215 */       if (this.name == null) {
/*  216 */         this.name = WebcamPanel.this.webcam.getName();
/*      */       }
/*      */       
/*  219 */       String str = this.name;
/*      */       
/*  221 */       w = metrics.stringWidth(str);
/*  222 */       h = metrics.getHeight();
/*      */       
/*  224 */       g2.drawString(str, (WebcamPanel.this.getWidth() - w) / 2, cy - 2 * h);
/*  225 */       g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, antialiasing);
/*      */     }
/*      */ 
/*      */     
/*      */     public void paintImage(WebcamPanel owner, BufferedImage image, Graphics2D g2) {
/*      */       double s, niw, nih, dx, dy;
/*  231 */       assert owner != null;
/*  232 */       assert image != null;
/*  233 */       assert g2 != null;
/*      */       
/*  235 */       int pw = WebcamPanel.this.getWidth();
/*  236 */       int ph = WebcamPanel.this.getHeight();
/*  237 */       int iw = image.getWidth();
/*  238 */       int ih = image.getHeight();
/*      */       
/*  240 */       Object antialiasing = g2.getRenderingHint(RenderingHints.KEY_ANTIALIASING);
/*  241 */       Object rendering = g2.getRenderingHint(RenderingHints.KEY_RENDERING);
/*      */       
/*  243 */       g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
/*  244 */       g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
/*  245 */       g2.setBackground(Color.BLACK);
/*  246 */       g2.setColor(Color.BLACK);
/*  247 */       g2.fillRect(0, 0, pw, ph);
/*      */ 
/*      */       
/*  250 */       int x = 0;
/*  251 */       int y = 0;
/*  252 */       int w = 0;
/*  253 */       int h = 0;
/*      */       
/*  255 */       switch (WebcamPanel.this.drawMode) {
/*      */         case NONE:
/*  257 */           w = image.getWidth();
/*  258 */           h = image.getHeight();
/*      */           break;
/*      */         case FILL:
/*  261 */           w = pw;
/*  262 */           h = ph;
/*      */           break;
/*      */         case FIT:
/*  265 */           s = Math.max(iw / pw, ih / ph);
/*  266 */           niw = iw / s;
/*  267 */           nih = ih / s;
/*  268 */           dx = (pw - niw) / 2.0D;
/*  269 */           dy = (ph - nih) / 2.0D;
/*  270 */           w = (int)niw;
/*  271 */           h = (int)nih;
/*  272 */           x = (int)dx;
/*  273 */           y = (int)dy;
/*      */           break;
/*      */       } 
/*      */       
/*  277 */       if (this.resizedImage != null) {
/*  278 */         this.resizedImage.flush();
/*      */       }
/*      */       
/*  281 */       if (w == image.getWidth() && h == image.getHeight() && !WebcamPanel.this.mirrored) {
/*  282 */         this.resizedImage = image;
/*      */       } else {
/*      */         
/*  285 */         GraphicsEnvironment genv = GraphicsEnvironment.getLocalGraphicsEnvironment();
/*  286 */         GraphicsConfiguration gc = genv.getDefaultScreenDevice().getDefaultConfiguration();
/*      */         
/*  288 */         Graphics2D gr = null;
/*      */         try {
/*      */           int sx1, sx2, sy1, sy2;
/*  291 */           this.resizedImage = gc.createCompatibleImage(pw, ph);
/*  292 */           gr = this.resizedImage.createGraphics();
/*  293 */           gr.setComposite(AlphaComposite.Src);
/*      */           
/*  295 */           for (Map.Entry<RenderingHints.Key, Object> hint : (Iterable<Map.Entry<RenderingHints.Key, Object>>)WebcamPanel.this.imageRenderingHints.entrySet()) {
/*  296 */             gr.setRenderingHint(hint.getKey(), hint.getValue());
/*      */           }
/*      */           
/*  299 */           gr.setBackground(Color.BLACK);
/*  300 */           gr.setColor(Color.BLACK);
/*  301 */           gr.fillRect(0, 0, pw, ph);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  306 */           int dx1 = x;
/*  307 */           int dy1 = y;
/*  308 */           int dx2 = x + w;
/*  309 */           int dy2 = y + h;
/*      */           
/*  311 */           if (WebcamPanel.this.mirrored) {
/*  312 */             sx1 = iw;
/*  313 */             sy1 = 0;
/*  314 */             sx2 = 0;
/*  315 */             sy2 = ih;
/*      */           } else {
/*  317 */             sx1 = 0;
/*  318 */             sy1 = 0;
/*  319 */             sx2 = iw;
/*  320 */             sy2 = ih;
/*      */           } 
/*      */           
/*  323 */           gr.drawImage(image, dx1, dy1, dx2, dy2, sx1, sy1, sx2, sy2, null);
/*      */         } finally {
/*      */           
/*  326 */           if (gr != null) {
/*  327 */             gr.dispose();
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/*  332 */       g2.drawImage(this.resizedImage, 0, 0, (ImageObserver)null);
/*      */       
/*  334 */       if (WebcamPanel.this.isFPSDisplayed()) {
/*      */         
/*  336 */         String str = String.format("FPS: %.1f", new Object[] { Double.valueOf(WebcamPanel.access$300(this.this$0).getFPS()) });
/*      */         
/*  338 */         int sx = 5;
/*  339 */         int sy = ph - 5;
/*      */         
/*  341 */         g2.setFont(WebcamPanel.this.getFont());
/*  342 */         g2.setColor(Color.BLACK);
/*  343 */         g2.drawString(str, sx + 1, sy + 1);
/*  344 */         g2.setColor(Color.WHITE);
/*  345 */         g2.drawString(str, sx, sy);
/*      */       } 
/*      */       
/*  348 */       if (WebcamPanel.this.isImageSizeDisplayed()) {
/*      */         
/*  350 */         String res = String.format("%d⨯%d px", new Object[] { Integer.valueOf(iw), Integer.valueOf(ih) });
/*      */         
/*  352 */         FontMetrics metrics = g2.getFontMetrics(WebcamPanel.this.getFont());
/*  353 */         int sw = metrics.stringWidth(res);
/*  354 */         int sx = pw - sw - 5;
/*  355 */         int sy = ph - 5;
/*      */         
/*  357 */         g2.setFont(WebcamPanel.this.getFont());
/*  358 */         g2.setColor(Color.BLACK);
/*  359 */         g2.drawString(res, sx + 1, sy + 1);
/*  360 */         g2.setColor(Color.WHITE);
/*  361 */         g2.drawString(res, sx, sy);
/*      */       } 
/*      */       
/*  364 */       if (WebcamPanel.this.isDisplayDebugInfo())
/*      */       {
/*  366 */         if (this.lastRepaintTime < 0L) {
/*  367 */           this.lastRepaintTime = System.currentTimeMillis();
/*      */         } else {
/*      */           
/*  370 */           long now = System.currentTimeMillis();
/*  371 */           String res = String.format("DEBUG: repaints per second: %.1f", new Object[] { Double.valueOf(1000.0D / (now - this.lastRepaintTime)) });
/*  372 */           this.lastRepaintTime = now;
/*  373 */           g2.setFont(WebcamPanel.this.getFont());
/*  374 */           g2.setColor(Color.BLACK);
/*  375 */           g2.drawString(res, 6, 16);
/*  376 */           g2.setColor(Color.WHITE);
/*  377 */           g2.drawString(res, 5, 15);
/*      */         } 
/*      */       }
/*      */       
/*  381 */       g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, antialiasing);
/*  382 */       g2.setRenderingHint(RenderingHints.KEY_RENDERING, rendering);
/*      */     } }
/*      */   
/*      */   private static final class PanelThreadFactory implements ThreadFactory {
/*      */     private PanelThreadFactory() {}
/*      */     
/*  388 */     private static final AtomicInteger number = new AtomicInteger(0);
/*      */ 
/*      */     
/*      */     public Thread newThread(Runnable r) {
/*  392 */       Thread t = new Thread(r, String.format("webcam-panel-scheduled-executor-%d", new Object[] { Integer.valueOf(number.incrementAndGet()) }));
/*  393 */       t.setUncaughtExceptionHandler(WebcamExceptionHandler.getInstance());
/*  394 */       t.setDaemon(true);
/*  395 */       return t;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class SwingRepainter
/*      */     implements Runnable
/*      */   {
/*  404 */     private WebcamPanel panel = null;
/*      */     
/*      */     public SwingRepainter(WebcamPanel panel) {
/*  407 */       this.panel = panel;
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/*  412 */       this.panel.repaint();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  424 */   private static final Logger LOG = LoggerFactory.getLogger(WebcamPanel.class);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final double MIN_FREQUENCY = 0.016D;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final double MAX_FREQUENCY = 50.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  439 */   private static final ThreadFactory THREAD_FACTORY = new PanelThreadFactory();
/*      */   
/*  441 */   public static final Map<RenderingHints.Key, Object> DEFAULT_IMAGE_RENDERING_HINTS = new HashMap<>();
/*      */   static {
/*  443 */     DEFAULT_IMAGE_RENDERING_HINTS.put(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/*  444 */     DEFAULT_IMAGE_RENDERING_HINTS.put(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
/*  445 */     DEFAULT_IMAGE_RENDERING_HINTS.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  451 */   private final Runnable repaint = new SwingRepainter(this);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  456 */   private Map<RenderingHints.Key, Object> imageRenderingHints = new HashMap<>(DEFAULT_IMAGE_RENDERING_HINTS);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  461 */   private ScheduledExecutorService executor = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class ImageUpdater
/*      */     implements Runnable
/*      */   {
/*      */     private class RepaintScheduler
/*      */       extends Thread
/*      */     {
/*      */       public RepaintScheduler() {
/*  481 */         setUncaughtExceptionHandler(WebcamExceptionHandler.getInstance());
/*  482 */         setName(String.format("repaint-scheduler-%s", new Object[] { WebcamPanel.access$300(this$0.this$0).getName() }));
/*  483 */         setDaemon(true);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public void run() {
/*  490 */         if (!WebcamPanel.ImageUpdater.this.running.get()) {
/*      */           return;
/*      */         }
/*      */         
/*  494 */         WebcamPanel.this.repaintPanel();
/*      */ 
/*      */         
/*  497 */         while (WebcamPanel.this.starting) {
/*      */           try {
/*  499 */             Thread.sleep(50L);
/*  500 */           } catch (InterruptedException e) {
/*  501 */             throw new RuntimeException(e);
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/*  514 */           if (WebcamPanel.this.webcam.isOpen()) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  519 */             if (WebcamPanel.this.isFPSLimited()) {
/*  520 */               WebcamPanel.this.executor.scheduleAtFixedRate(WebcamPanel.this.updater, 0L, (long)(1000.0D / WebcamPanel.this.frequency), TimeUnit.MILLISECONDS);
/*      */             } else {
/*  522 */               WebcamPanel.this.executor.scheduleWithFixedDelay(WebcamPanel.this.updater, 100L, 1L, TimeUnit.MILLISECONDS);
/*      */             } 
/*      */           } else {
/*  525 */             WebcamPanel.this.executor.schedule(this, 500L, TimeUnit.MILLISECONDS);
/*      */           } 
/*  527 */         } catch (RejectedExecutionException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  533 */           WebcamPanel.LOG.warn("Executor rejected paint update");
/*  534 */           WebcamPanel.LOG.trace("Executor rejected paint update because of", e);
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  542 */     private Thread scheduler = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  547 */     private AtomicBoolean running = new AtomicBoolean(false);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void start() {
/*  553 */       if (this.running.compareAndSet(false, true)) {
/*  554 */         WebcamPanel.this.executor = Executors.newScheduledThreadPool(1, WebcamPanel.THREAD_FACTORY);
/*  555 */         this.scheduler = new RepaintScheduler();
/*  556 */         this.scheduler.start();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void stop() throws InterruptedException {
/*  566 */       if (this.running.compareAndSet(true, false)) {
/*  567 */         WebcamPanel.this.executor.shutdown();
/*  568 */         WebcamPanel.this.executor.awaitTermination(5000L, TimeUnit.MILLISECONDS);
/*  569 */         this.scheduler.join();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/*      */       try {
/*  576 */         update();
/*  577 */       } catch (Throwable t) {
/*  578 */         WebcamPanel.this.errored = true;
/*  579 */         WebcamExceptionHandler.handle(t);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void update() {
/*  591 */       if (!this.running.get() || !WebcamPanel.this.webcam.isOpen() || WebcamPanel.this.paused) {
/*      */         return;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  597 */       BufferedImage tmp = WebcamPanel.this.supplier.get();
/*  598 */       boolean repaint = true;
/*      */       
/*  600 */       if (tmp != null) {
/*      */ 
/*      */         
/*  603 */         if (WebcamPanel.this.image == tmp) {
/*  604 */           repaint = false;
/*      */         }
/*      */         
/*  607 */         WebcamPanel.this.errored = false;
/*  608 */         WebcamPanel.this.image = tmp;
/*      */       } 
/*      */       
/*  611 */       if (repaint) {
/*  612 */         WebcamPanel.this.repaintPanel();
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     private ImageUpdater() {}
/*      */   }
/*      */   
/*  620 */   private ResourceBundle rb = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  628 */   private DrawMode drawMode = DrawMode.FIT;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  633 */   private double frequency = 5.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean frequencyLimit = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean frequencyDisplayed = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean imageSizeDisplayed = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean antialiasingEnabled = true;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Webcam webcam;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final ImageSupplier supplier;
/*      */ 
/*      */ 
/*      */   
/*      */   private final ImageUpdater updater;
/*      */ 
/*      */ 
/*      */   
/*  671 */   private BufferedImage image = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private volatile boolean starting = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private volatile boolean paused = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private volatile boolean errored = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  691 */   private final AtomicBoolean started = new AtomicBoolean(false);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  696 */   private final Painter defaultPainter = new DefaultPainter();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  704 */   private Painter painter = this.defaultPainter;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  709 */   private Dimension defaultSize = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean displayDebugInfo = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean mirrored = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WebcamPanel(Webcam webcam) {
/*  727 */     this(webcam, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WebcamPanel(Webcam webcam, boolean start) {
/*  737 */     this(webcam, (Dimension)null, start);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WebcamPanel(Webcam webcam, Dimension size, boolean start) {
/*  752 */     this(webcam, size, start, new DefaultImageSupplier(webcam));
/*      */   }
/*      */ 
/*      */   
/*      */   public WebcamPanel(Webcam webcam, Dimension size, boolean start, ImageSupplier supplier) {
/*  757 */     if (webcam == null) {
/*  758 */       throw new IllegalArgumentException(String.format("Webcam argument in %s constructor cannot be null!", new Object[] { getClass().getSimpleName() }));
/*      */     }
/*      */     
/*  761 */     this.defaultSize = size;
/*  762 */     this.webcam = webcam;
/*  763 */     this.updater = new ImageUpdater();
/*  764 */     this.supplier = supplier;
/*  765 */     this.rb = WebcamUtils.loadRB(WebcamPanel.class, getLocale());
/*      */     
/*  767 */     setDoubleBuffered(true);
/*      */     
/*  769 */     addPropertyChangeListener("locale", this);
/*      */     
/*  771 */     if (size == null) {
/*  772 */       Dimension r = webcam.getViewSize();
/*  773 */       if (r == null) {
/*  774 */         r = webcam.getViewSizes()[0];
/*      */       }
/*  776 */       setPreferredSize(r);
/*      */     } else {
/*  778 */       setPreferredSize(size);
/*      */     } 
/*      */     
/*  781 */     if (start) {
/*  782 */       start();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPainter(Painter painter) {
/*  792 */     this.painter = painter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Painter getPainter() {
/*  801 */     return this.painter;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void paintComponent(Graphics g) {
/*  807 */     super.paintComponent(g);
/*      */     
/*  809 */     if (this.image == null) {
/*  810 */       this.painter.paintPanel(this, (Graphics2D)g);
/*      */     } else {
/*  812 */       this.painter.paintImage(this, this.image, (Graphics2D)g);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void start() {
/*  821 */     if (!this.started.compareAndSet(false, true)) {
/*      */       return;
/*      */     }
/*      */     
/*  825 */     this.webcam.addWebcamListener(this);
/*      */     
/*  827 */     LOG.debug("Starting panel rendering and trying to open attached webcam");
/*      */     
/*  829 */     this.updater.start();
/*      */     
/*  831 */     this.starting = true;
/*      */     
/*  833 */     SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>()
/*      */       {
/*      */         
/*      */         protected Void doInBackground() throws Exception
/*      */         {
/*      */           try {
/*  839 */             if (!WebcamPanel.this.webcam.isOpen()) {
/*  840 */               WebcamPanel.this.errored = !WebcamPanel.this.webcam.open();
/*      */             }
/*  842 */           } catch (WebcamException e) {
/*  843 */             WebcamPanel.this.errored = true;
/*  844 */             throw e;
/*      */           } finally {
/*  846 */             WebcamPanel.this.starting = false;
/*  847 */             WebcamPanel.this.repaintPanel();
/*      */           } 
/*      */           
/*  850 */           return null;
/*      */         }
/*      */       };
/*  853 */     worker.execute();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void stop() {
/*  861 */     if (!this.started.compareAndSet(true, false)) {
/*      */       return;
/*      */     }
/*      */     
/*  865 */     this.webcam.removeWebcamListener(this);
/*      */     
/*  867 */     LOG.debug("Stopping panel rendering and closing attached webcam");
/*      */     
/*      */     try {
/*  870 */       this.updater.stop();
/*  871 */     } catch (InterruptedException e) {
/*  872 */       throw new RuntimeException(e);
/*      */     } 
/*      */     
/*  875 */     this.image = null;
/*      */     
/*  877 */     SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>()
/*      */       {
/*      */         
/*      */         protected Void doInBackground() throws Exception
/*      */         {
/*      */           try {
/*  883 */             if (WebcamPanel.this.webcam.isOpen()) {
/*  884 */               WebcamPanel.this.errored = !WebcamPanel.this.webcam.close();
/*      */             }
/*  886 */           } catch (WebcamException e) {
/*  887 */             WebcamPanel.this.errored = true;
/*  888 */             throw e;
/*      */           } finally {
/*  890 */             WebcamPanel.this.repaintPanel();
/*      */           } 
/*      */           
/*  893 */           return null;
/*      */         }
/*      */       };
/*  896 */     worker.execute();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void repaintPanel() {
/*  903 */     SwingUtilities.invokeLater(this.repaint);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pause() {
/*  910 */     if (this.paused) {
/*      */       return;
/*      */     }
/*      */     
/*  914 */     LOG.debug("Pausing panel rendering");
/*      */     
/*  916 */     this.paused = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resume() {
/*  924 */     if (!this.paused) {
/*      */       return;
/*      */     }
/*      */     
/*  928 */     LOG.debug("Resuming panel rendering");
/*      */     
/*  930 */     this.paused = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFPSLimited() {
/*  939 */     return this.frequencyLimit;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFPSLimited(boolean frequencyLimit) {
/*  951 */     this.frequencyLimit = frequencyLimit;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getFPSLimit() {
/*  960 */     return this.frequency;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFPSLimit(double fps) {
/*  970 */     if (fps > 50.0D) {
/*  971 */       fps = 50.0D;
/*      */     }
/*  973 */     if (fps < 0.016D) {
/*  974 */       fps = 0.016D;
/*      */     }
/*  976 */     this.frequency = fps;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDisplayDebugInfo() {
/*  985 */     return this.displayDebugInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDisplayDebugInfo(boolean displayDebugInfo) {
/*  994 */     this.displayDebugInfo = displayDebugInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFPSDisplayed() {
/* 1005 */     return this.frequencyDisplayed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFPSDisplayed(boolean displayed) {
/* 1014 */     this.frequencyDisplayed = displayed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isImageSizeDisplayed() {
/* 1024 */     return this.imageSizeDisplayed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setImageSizeDisplayed(boolean imageSizeDisplayed) {
/* 1033 */     this.imageSizeDisplayed = imageSizeDisplayed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAntialiasingEnabled(boolean antialiasing) {
/* 1042 */     this.antialiasingEnabled = antialiasing;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAntialiasingEnabled() {
/* 1049 */     return this.antialiasingEnabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isStarting() {
/* 1058 */     return this.starting;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isStarted() {
/* 1067 */     return this.started.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DrawMode getDrawMode() {
/* 1076 */     return this.drawMode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDrawMode(DrawMode drawMode) {
/* 1085 */     this.drawMode = drawMode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isErrored() {
/* 1094 */     return this.errored;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Map<RenderingHints.Key, Object> getImageRenderingHints() {
/* 1105 */     return this.imageRenderingHints;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public boolean isFitArea() {
/* 1110 */     return (this.drawMode == DrawMode.FIT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setFitArea(boolean fitArea) {
/* 1123 */     this.drawMode = fitArea ? DrawMode.FIT : DrawMode.NONE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setFillArea(boolean fillArea) {
/* 1135 */     this.drawMode = fillArea ? DrawMode.FILL : DrawMode.NONE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean isFillArea() {
/* 1147 */     return (this.drawMode == DrawMode.FILL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Painter getDefaultPainter() {
/* 1156 */     return this.defaultPainter;
/*      */   }
/*      */ 
/*      */   
/*      */   public void propertyChange(PropertyChangeEvent evt) {
/* 1161 */     Locale lc = (Locale)evt.getNewValue();
/* 1162 */     if (lc != null) {
/* 1163 */       this.rb = WebcamUtils.loadRB(WebcamPanel.class, lc);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void webcamOpen(WebcamEvent we) {
/* 1173 */     if (this.defaultSize == null) {
/* 1174 */       setPreferredSize(this.webcam.getViewSize());
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void webcamClosed(WebcamEvent we) {
/* 1180 */     stop();
/*      */   }
/*      */ 
/*      */   
/*      */   public void webcamDisposed(WebcamEvent we) {
/* 1185 */     stop();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void webcamImageObtained(WebcamEvent we) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isMirrored() {
/* 1199 */     return this.mirrored;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMirrored(boolean mirrored) {
/* 1209 */     this.mirrored = mirrored;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Webcam getWebcam() {
/* 1218 */     return this.webcam;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BufferedImage getImage() {
/* 1225 */     return this.image;
/*      */   }
/*      */   
/*      */   public static interface Painter {
/*      */     void paintPanel(WebcamPanel param1WebcamPanel, Graphics2D param1Graphics2D);
/*      */     
/*      */     void paintImage(WebcamPanel param1WebcamPanel, BufferedImage param1BufferedImage, Graphics2D param1Graphics2D);
/*      */   }
/*      */   
/*      */   public static interface ImageSupplier {
/*      */     BufferedImage get();
/*      */   }
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */