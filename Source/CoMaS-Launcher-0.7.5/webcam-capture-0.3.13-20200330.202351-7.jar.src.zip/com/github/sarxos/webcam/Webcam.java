/*      */ package com.github.sarxos.webcam;
/*      */ 
/*      */ import com.github.sarxos.webcam.ds.buildin.WebcamDefaultDriver;
/*      */ import com.github.sarxos.webcam.ds.cgt.WebcamCloseTask;
/*      */ import com.github.sarxos.webcam.ds.cgt.WebcamDisposeTask;
/*      */ import com.github.sarxos.webcam.ds.cgt.WebcamGetBufferTask;
/*      */ import com.github.sarxos.webcam.ds.cgt.WebcamGetImageTask;
/*      */ import com.github.sarxos.webcam.ds.cgt.WebcamOpenTask;
/*      */ import com.github.sarxos.webcam.ds.cgt.WebcamReadBufferTask;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.CopyOnWriteArrayList;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.Executors;
/*      */ import java.util.concurrent.ThreadFactory;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.TimeoutException;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Webcam
/*      */ {
/*      */   private static final class ImageNotification
/*      */     implements Runnable
/*      */   {
/*      */     private final Webcam webcam;
/*      */     private final BufferedImage image;
/*      */     
/*      */     public ImageNotification(Webcam webcam, BufferedImage image) {
/*   68 */       this.webcam = webcam;
/*   69 */       this.image = image;
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/*   74 */       if (this.image != null) {
/*   75 */         WebcamEvent we = new WebcamEvent(WebcamEventType.NEW_IMAGE, this.webcam, this.image);
/*   76 */         for (WebcamListener l : this.webcam.getWebcamListeners()) {
/*      */           try {
/*   78 */             l.webcamImageObtained(we);
/*   79 */           } catch (Exception e) {
/*   80 */             Webcam.LOG.error(String.format("Notify image acquired, exception when calling listener %s", new Object[] { l.getClass() }), e);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private final class NotificationThreadFactory implements ThreadFactory {
/*      */     private NotificationThreadFactory() {}
/*      */     
/*      */     public Thread newThread(Runnable r) {
/*   91 */       Thread t = new Thread(r, String.format("notificator-[%s]", new Object[] { this.this$0.getName() }));
/*   92 */       t.setUncaughtExceptionHandler(WebcamExceptionHandler.getInstance());
/*   93 */       t.setDaemon(true);
/*   94 */       return t;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  101 */   private static final Logger LOG = LoggerFactory.getLogger(Webcam.class);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  106 */   private static final List<String> DRIVERS_LIST = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  111 */   private static final List<Class<?>> DRIVERS_CLASS_LIST = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  116 */   private static final List<WebcamDiscoveryListener> DISCOVERY_LISTENERS = Collections.synchronizedList(new ArrayList<>());
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  121 */   private static volatile WebcamDriver driver = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  126 */   private static volatile WebcamDiscoveryService discovery = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean deallocOnTermSignal = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean autoOpen = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  141 */   private List<WebcamListener> listeners = new CopyOnWriteArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  146 */   private List<Dimension> customSizes = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  151 */   private WebcamShutdownHook hook = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  156 */   private WebcamDevice device = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  161 */   private AtomicBoolean open = new AtomicBoolean(false);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  166 */   private AtomicBoolean disposed = new AtomicBoolean(false);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private volatile boolean asynchronous = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  176 */   private volatile double fps = 0.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  181 */   private volatile WebcamUpdater updater = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  186 */   private volatile WebcamImageTransformer transformer = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  192 */   private WebcamLock lock = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  197 */   private ExecutorService notificator = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Webcam(WebcamDevice device) {
/*  206 */     if (device == null) {
/*  207 */       throw new IllegalArgumentException("Webcam device cannot be null");
/*      */     }
/*  209 */     this.device = device;
/*  210 */     this.lock = new WebcamLock(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyWebcamImageAcquired(BufferedImage image) {
/*  223 */     if (getWebcamListenersCount() > 0) {
/*  224 */       this.notificator.execute(new ImageNotification(this, image));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean open() {
/*  236 */     return open(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean open(boolean async) {
/*  250 */     return open(async, new WebcamUpdater.DefaultDelayCalculator());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean open(boolean async, WebcamUpdater.DelayCalculator delayCalculator) {
/*  281 */     if (this.open.compareAndSet(false, true)) {
/*      */       
/*  283 */       assert this.lock != null;
/*      */       
/*  285 */       this.notificator = Executors.newSingleThreadExecutor(new NotificationThreadFactory());
/*      */ 
/*      */ 
/*      */       
/*  289 */       this.lock.lock();
/*      */ 
/*      */ 
/*      */       
/*  293 */       WebcamOpenTask task = new WebcamOpenTask(driver, this.device);
/*      */       try {
/*  295 */         task.open();
/*  296 */       } catch (InterruptedException e) {
/*  297 */         this.lock.unlock();
/*  298 */         this.open.set(false);
/*  299 */         LOG.debug("Thread has been interrupted in the middle of webcam opening process!", e);
/*  300 */         return false;
/*  301 */       } catch (WebcamException e) {
/*  302 */         this.lock.unlock();
/*  303 */         this.open.set(false);
/*  304 */         LOG.debug("Webcam exception when opening", e);
/*  305 */         throw e;
/*      */       } 
/*      */       
/*  308 */       LOG.debug("Webcam is now open {}", getName());
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  313 */         Runtime.getRuntime().addShutdownHook(this.hook = new WebcamShutdownHook(this));
/*  314 */       } catch (IllegalStateException e) {
/*      */         
/*  316 */         LOG.debug("Shutdown in progress, do not open device");
/*  317 */         LOG.trace(e.getMessage(), e);
/*      */         
/*  319 */         close();
/*      */         
/*  321 */         return false;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  326 */       if (this.asynchronous = async) {
/*  327 */         if (this.updater == null) {
/*  328 */           this.updater = new WebcamUpdater(this, delayCalculator);
/*      */         }
/*  330 */         this.updater.start();
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  335 */       WebcamEvent we = new WebcamEvent(WebcamEventType.OPEN, this);
/*  336 */       Iterator<WebcamListener> wli = this.listeners.iterator();
/*  337 */       WebcamListener l = null;
/*      */       
/*  339 */       while (wli.hasNext()) {
/*  340 */         l = wli.next();
/*      */         try {
/*  342 */           l.webcamOpen(we);
/*  343 */         } catch (Exception e) {
/*  344 */           LOG.error(String.format("Notify webcam open, exception when calling listener %s", new Object[] { l.getClass() }), e);
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */       
/*  349 */       LOG.debug("Webcam is already open {}", getName());
/*      */     } 
/*      */     
/*  352 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean close() {
/*  362 */     if (this.open.compareAndSet(true, false)) {
/*      */       
/*  364 */       LOG.debug("Closing webcam {}", getName());
/*      */       
/*  366 */       assert this.lock != null;
/*      */ 
/*      */ 
/*      */       
/*  370 */       WebcamCloseTask task = new WebcamCloseTask(driver, this.device);
/*      */       try {
/*  372 */         task.close();
/*  373 */       } catch (InterruptedException e) {
/*  374 */         this.open.set(true);
/*  375 */         LOG.debug("Thread has been interrupted before webcam was closed!", e);
/*  376 */         return false;
/*  377 */       } catch (WebcamException e) {
/*  378 */         this.open.set(true);
/*  379 */         throw e;
/*      */       } 
/*      */ 
/*      */       
/*  383 */       if (this.asynchronous) {
/*  384 */         this.updater.stop();
/*      */       }
/*      */ 
/*      */       
/*  388 */       removeShutdownHook();
/*      */ 
/*      */       
/*  391 */       this.lock.unlock();
/*      */ 
/*      */ 
/*      */       
/*  395 */       WebcamEvent we = new WebcamEvent(WebcamEventType.CLOSED, this);
/*  396 */       Iterator<WebcamListener> wli = this.listeners.iterator();
/*  397 */       WebcamListener l = null;
/*      */       
/*  399 */       while (wli.hasNext()) {
/*  400 */         l = wli.next();
/*      */         try {
/*  402 */           l.webcamClosed(we);
/*  403 */         } catch (Exception e) {
/*  404 */           LOG.error(String.format("Notify webcam closed, exception when calling %s listener", new Object[] { l.getClass() }), e);
/*      */         } 
/*      */       } 
/*      */       
/*  408 */       this.notificator.shutdown();
/*  409 */       while (!this.notificator.isTerminated()) {
/*      */         try {
/*  411 */           this.notificator.awaitTermination(100L, TimeUnit.MILLISECONDS);
/*  412 */         } catch (InterruptedException e) {
/*  413 */           return false;
/*      */         } 
/*      */       } 
/*      */       
/*  417 */       LOG.debug("Webcam {} has been closed", getName());
/*      */     } else {
/*      */       
/*  420 */       LOG.debug("Webcam {} is already closed", getName());
/*      */     } 
/*      */     
/*  423 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WebcamDevice getDevice() {
/*  434 */     assert this.device != null;
/*  435 */     return this.device;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void dispose() {
/*  444 */     assert this.disposed != null;
/*  445 */     assert this.open != null;
/*  446 */     assert driver != null;
/*  447 */     assert this.device != null;
/*  448 */     assert this.listeners != null;
/*      */     
/*  450 */     if (!this.disposed.compareAndSet(false, true)) {
/*      */       return;
/*      */     }
/*      */     
/*  454 */     this.open.set(false);
/*      */     
/*  456 */     LOG.info("Disposing webcam {}", getName());
/*      */     
/*  458 */     WebcamDisposeTask task = new WebcamDisposeTask(driver, this.device);
/*      */     try {
/*  460 */       task.dispose();
/*  461 */     } catch (InterruptedException e) {
/*  462 */       LOG.error("Processor has been interrupted before webcam was disposed!", e);
/*      */       
/*      */       return;
/*      */     } 
/*  466 */     WebcamEvent we = new WebcamEvent(WebcamEventType.DISPOSED, this);
/*  467 */     Iterator<WebcamListener> wli = this.listeners.iterator();
/*  468 */     WebcamListener l = null;
/*      */     
/*  470 */     while (wli.hasNext()) {
/*  471 */       l = wli.next();
/*      */       try {
/*  473 */         l.webcamClosed(we);
/*  474 */         l.webcamDisposed(we);
/*  475 */       } catch (Exception e) {
/*  476 */         LOG.error(String.format("Notify webcam disposed, exception when calling %s listener", new Object[] { l.getClass() }), e);
/*      */       } 
/*      */     } 
/*      */     
/*  480 */     removeShutdownHook();
/*      */     
/*  482 */     LOG.debug("Webcam disposed {}", getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void removeShutdownHook() {
/*  490 */     if (this.hook != null) {
/*      */       try {
/*  492 */         Runtime.getRuntime().removeShutdownHook(this.hook);
/*  493 */       } catch (IllegalStateException e) {
/*  494 */         LOG.trace("Shutdown in progress, cannot remove hook");
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BufferedImage transform(BufferedImage image) {
/*  507 */     if (image != null) {
/*  508 */       WebcamImageTransformer tr = getImageTransformer();
/*  509 */       if (tr != null) {
/*  510 */         return tr.transform(image);
/*      */       }
/*      */     } 
/*  513 */     return image;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isOpen() {
/*  522 */     return this.open.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Dimension getViewSize() {
/*  531 */     return this.device.getResolution();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Dimension[] getViewSizes() {
/*  540 */     return this.device.getResolutions();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCustomViewSizes(Dimension... sizes) {
/*  550 */     assert this.customSizes != null;
/*  551 */     if (sizes == null) {
/*  552 */       this.customSizes.clear();
/*      */       return;
/*      */     } 
/*  555 */     this.customSizes = Arrays.asList(sizes);
/*      */   }
/*      */   
/*      */   public Dimension[] getCustomViewSizes() {
/*  559 */     assert this.customSizes != null;
/*  560 */     return this.customSizes.<Dimension>toArray(new Dimension[this.customSizes.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setViewSize(Dimension size) {
/*  573 */     if (size == null) {
/*  574 */       throw new IllegalArgumentException("Resolution cannot be null!");
/*      */     }
/*      */     
/*  577 */     if (this.open.get()) {
/*  578 */       throw new IllegalStateException("Cannot change resolution when webcam is open, please close it first");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  583 */     Dimension current = getViewSize();
/*  584 */     if (current != null && current.width == size.width && current.height == size.height) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  590 */     Dimension[] predefined = getViewSizes();
/*  591 */     Dimension[] custom = getCustomViewSizes();
/*      */     
/*  593 */     assert predefined != null;
/*  594 */     assert custom != null;
/*      */     
/*  596 */     boolean ok = false;
/*  597 */     for (Dimension d : predefined) {
/*  598 */       if (d.width == size.width && d.height == size.height) {
/*  599 */         ok = true;
/*      */         break;
/*      */       } 
/*      */     } 
/*  603 */     if (!ok) {
/*  604 */       for (Dimension d : custom) {
/*  605 */         if (d.width == size.width && d.height == size.height) {
/*  606 */           ok = true;
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     }
/*  612 */     if (!ok) {
/*  613 */       StringBuilder sb = new StringBuilder("Incorrect dimension [");
/*  614 */       sb.append(size.width).append("x").append(size.height).append("] ");
/*  615 */       sb.append("possible ones are ");
/*  616 */       for (Dimension d : predefined) {
/*  617 */         sb.append("[").append(d.width).append("x").append(d.height).append("] ");
/*      */       }
/*  619 */       for (Dimension d : custom) {
/*  620 */         sb.append("[").append(d.width).append("x").append(d.height).append("] ");
/*      */       }
/*  622 */       throw new IllegalArgumentException(sb.toString());
/*      */     } 
/*      */     
/*  625 */     LOG.debug("Setting new resolution {}x{}", Integer.valueOf(size.width), Integer.valueOf(size.height));
/*      */     
/*  627 */     this.device.setResolution(size);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BufferedImage getImage() {
/*  647 */     if (!isReady()) {
/*  648 */       return null;
/*      */     }
/*      */     
/*  651 */     long t1 = 0L;
/*  652 */     long t2 = 0L;
/*      */     
/*  654 */     if (this.asynchronous) {
/*  655 */       return this.updater.getImage();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  660 */     t1 = System.currentTimeMillis();
/*  661 */     BufferedImage image = transform((new WebcamGetImageTask(driver, this.device)).getImage());
/*  662 */     t2 = System.currentTimeMillis();
/*      */     
/*  664 */     if (image == null) {
/*  665 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  670 */     if (this.device instanceof WebcamDevice.FPSSource) {
/*  671 */       this.fps = ((WebcamDevice.FPSSource)this.device).getFPS();
/*      */     } else {
/*      */       
/*  674 */       this.fps = (4.0D * this.fps + (1000L / (t2 - t1 + 1L))) / 5.0D;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  679 */     notifyWebcamImageAcquired(image);
/*      */     
/*  681 */     return image;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isImageNew() {
/*  686 */     if (this.asynchronous) {
/*  687 */       return this.updater.isImageNew();
/*      */     }
/*  689 */     return true;
/*      */   }
/*      */   
/*      */   public double getFPS() {
/*  693 */     if (this.asynchronous) {
/*  694 */       return this.updater.getFPS();
/*      */     }
/*  696 */     return this.fps;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteBuffer getImageBytes() {
/*  713 */     if (!isReady()) {
/*  714 */       return null;
/*      */     }
/*      */     
/*  717 */     assert driver != null;
/*  718 */     assert this.device != null;
/*      */     
/*  720 */     long t1 = 0L;
/*  721 */     long t2 = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  727 */     if (this.device instanceof WebcamDevice.BufferAccess) {
/*  728 */       t1 = System.currentTimeMillis();
/*      */       try {
/*  730 */         return (new WebcamGetBufferTask(driver, this.device)).getBuffer();
/*      */       } finally {
/*  732 */         t2 = System.currentTimeMillis();
/*  733 */         if (this.device instanceof WebcamDevice.FPSSource) {
/*  734 */           this.fps = ((WebcamDevice.FPSSource)this.device).getFPS();
/*      */         } else {
/*  736 */           this.fps = (4.0D * this.fps + (1000L / (t2 - t1 + 1L))) / 5.0D;
/*      */         } 
/*      */       } 
/*      */     } 
/*  740 */     throw new IllegalStateException(String.format("Driver %s does not support buffer access", new Object[] { driver.getClass().getName() }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getImageBytes(ByteBuffer target) {
/*  757 */     if (!isReady()) {
/*      */       return;
/*      */     }
/*      */     
/*  761 */     assert driver != null;
/*  762 */     assert this.device != null;
/*      */     
/*  764 */     long t1 = 0L;
/*  765 */     long t2 = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  771 */     if (this.device instanceof WebcamDevice.BufferAccess) {
/*  772 */       t1 = System.currentTimeMillis();
/*      */       try {
/*  774 */         (new WebcamReadBufferTask(driver, this.device, target)).readBuffer();
/*      */       } finally {
/*  776 */         t2 = System.currentTimeMillis();
/*  777 */         if (this.device instanceof WebcamDevice.FPSSource) {
/*  778 */           this.fps = ((WebcamDevice.FPSSource)this.device).getFPS();
/*      */         } else {
/*  780 */           this.fps = (4.0D * this.fps + (1000L / (t2 - t1 + 1L))) / 5.0D;
/*      */         } 
/*      */       } 
/*      */     } else {
/*  784 */       throw new IllegalStateException(String.format("Driver %s does not support buffer access", new Object[] { driver.getClass().getName() }));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setParameters(Map<String, ?> parameters) {
/*  797 */     WebcamDevice device = getDevice();
/*  798 */     if (device instanceof WebcamDevice.Configurable) {
/*  799 */       ((WebcamDevice.Configurable)device).setParameters(parameters);
/*      */     } else {
/*  801 */       LOG.debug("Webcam device {} is not configurable", device);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isReady() {
/*  812 */     assert this.disposed != null;
/*  813 */     assert this.open != null;
/*      */     
/*  815 */     if (this.disposed.get()) {
/*  816 */       LOG.warn("Cannot get image, webcam has been already disposed");
/*  817 */       return false;
/*      */     } 
/*      */     
/*  820 */     if (!this.open.get()) {
/*  821 */       if (autoOpen) {
/*  822 */         open();
/*      */       } else {
/*  824 */         return false;
/*      */       } 
/*      */     }
/*      */     
/*  828 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Webcam> getWebcams() throws WebcamException {
/*      */     try {
/*  845 */       return getWebcams(Long.MAX_VALUE);
/*  846 */     } catch (TimeoutException e) {
/*  847 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Webcam> getWebcams(long timeout) throws TimeoutException, WebcamException {
/*  863 */     if (timeout < 0L) {
/*  864 */       throw new IllegalArgumentException(String.format("Timeout cannot be negative (%d)", new Object[] { Long.valueOf(timeout) }));
/*      */     }
/*  866 */     return getWebcams(timeout, TimeUnit.MILLISECONDS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized List<Webcam> getWebcams(long timeout, TimeUnit tunit) throws TimeoutException, WebcamException {
/*  882 */     if (timeout < 0L) {
/*  883 */       throw new IllegalArgumentException(String.format("Timeout cannot be negative (%d)", new Object[] { Long.valueOf(timeout) }));
/*      */     }
/*  885 */     if (tunit == null) {
/*  886 */       throw new IllegalArgumentException("Time unit cannot be null!");
/*      */     }
/*      */     
/*  889 */     WebcamDiscoveryService discovery = getDiscoveryService();
/*      */     
/*  891 */     assert discovery != null;
/*      */     
/*  893 */     List<Webcam> webcams = discovery.getWebcams(timeout, tunit);
/*  894 */     if (!discovery.isRunning()) {
/*  895 */       discovery.start();
/*      */     }
/*      */     
/*  898 */     return webcams;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Webcam getDefault() throws WebcamException {
/*      */     try {
/*  911 */       return getDefault(Long.MAX_VALUE);
/*  912 */     } catch (TimeoutException e) {
/*      */ 
/*      */       
/*  915 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Webcam getDefault(long timeout) throws TimeoutException, WebcamException {
/*  930 */     if (timeout < 0L) {
/*  931 */       throw new IllegalArgumentException(String.format("Timeout cannot be negative (%d)", new Object[] { Long.valueOf(timeout) }));
/*      */     }
/*  933 */     return getDefault(timeout, TimeUnit.MILLISECONDS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Webcam getDefault(long timeout, TimeUnit tunit) throws TimeoutException, WebcamException {
/*  949 */     if (timeout < 0L) {
/*  950 */       throw new IllegalArgumentException(String.format("Timeout cannot be negative (%d)", new Object[] { Long.valueOf(timeout) }));
/*      */     }
/*  952 */     if (tunit == null) {
/*  953 */       throw new IllegalArgumentException("Time unit cannot be null!");
/*      */     }
/*      */     
/*  956 */     List<Webcam> webcams = getWebcams(timeout, tunit);
/*      */     
/*  958 */     assert webcams != null;
/*      */     
/*  960 */     if (!webcams.isEmpty()) {
/*  961 */       return webcams.get(0);
/*      */     }
/*      */     
/*  964 */     LOG.warn("No webcam has been detected!");
/*      */     
/*  966 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  977 */     assert this.device != null;
/*  978 */     return this.device.getName();
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/*  983 */     return String.format("Webcam %s", new Object[] { getName() });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean addWebcamListener(WebcamListener l) {
/*  994 */     if (l == null) {
/*  995 */       throw new IllegalArgumentException("Webcam listener cannot be null!");
/*      */     }
/*  997 */     assert this.listeners != null;
/*  998 */     return this.listeners.add(l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WebcamListener[] getWebcamListeners() {
/* 1005 */     assert this.listeners != null;
/* 1006 */     return this.listeners.<WebcamListener>toArray(new WebcamListener[this.listeners.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getWebcamListenersCount() {
/* 1013 */     assert this.listeners != null;
/* 1014 */     return this.listeners.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean removeWebcamListener(WebcamListener l) {
/* 1024 */     assert this.listeners != null;
/* 1025 */     return this.listeners.remove(l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized WebcamDriver getDriver() {
/* 1037 */     if (driver != null) {
/* 1038 */       return driver;
/*      */     }
/*      */     
/* 1041 */     if (driver == null) {
/* 1042 */       driver = WebcamDriverUtils.findDriver(DRIVERS_LIST, DRIVERS_CLASS_LIST);
/*      */     }
/* 1044 */     if (driver == null) {
/* 1045 */       driver = (WebcamDriver)new WebcamDefaultDriver();
/*      */     }
/*      */     
/* 1048 */     LOG.info("{} capture driver will be used", driver.getClass().getSimpleName());
/*      */     
/* 1050 */     return driver;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setDriver(WebcamDriver wd) {
/* 1063 */     if (wd == null) {
/* 1064 */       throw new IllegalArgumentException("Webcam driver cannot be null!");
/*      */     }
/*      */     
/* 1067 */     LOG.debug("Setting new capture driver {}", wd);
/*      */     
/* 1069 */     resetDriver();
/*      */     
/* 1071 */     driver = wd;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setDriver(Class<? extends WebcamDriver> driverClass) {
/* 1086 */     if (driverClass == null) {
/* 1087 */       throw new IllegalArgumentException("Webcam driver class cannot be null!");
/*      */     }
/*      */     
/* 1090 */     resetDriver();
/*      */     
/*      */     try {
/* 1093 */       driver = driverClass.newInstance();
/* 1094 */     } catch (InstantiationException e) {
/* 1095 */       throw new WebcamException(e);
/* 1096 */     } catch (IllegalAccessException e) {
/* 1097 */       throw new WebcamException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void resetDriver() {
/* 1108 */     synchronized (DRIVERS_LIST) {
/* 1109 */       DRIVERS_LIST.clear();
/*      */     } 
/*      */     
/* 1112 */     if (discovery != null) {
/* 1113 */       discovery.shutdown();
/* 1114 */       discovery = null;
/*      */     } 
/*      */     
/* 1117 */     driver = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registerDriver(Class<? extends WebcamDriver> clazz) {
/* 1127 */     if (clazz == null) {
/* 1128 */       throw new IllegalArgumentException("Webcam driver class to register cannot be null!");
/*      */     }
/* 1130 */     DRIVERS_CLASS_LIST.add(clazz);
/* 1131 */     registerDriver(clazz.getCanonicalName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registerDriver(String clazzName) {
/* 1141 */     if (clazzName == null) {
/* 1142 */       throw new IllegalArgumentException("Webcam driver class name to register cannot be null!");
/*      */     }
/* 1144 */     DRIVERS_LIST.add(clazzName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setHandleTermSignal(boolean on) {
/* 1158 */     if (on) {
/* 1159 */       LOG.warn("Automated deallocation on TERM signal is now enabled! Make sure to not use it in production!");
/*      */     }
/* 1161 */     deallocOnTermSignal = on;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isHandleTermSignal() {
/* 1170 */     return deallocOnTermSignal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setAutoOpenMode(boolean on) {
/* 1183 */     autoOpen = on;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAutoOpenMode() {
/* 1195 */     return autoOpen;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean addDiscoveryListener(WebcamDiscoveryListener l) {
/* 1206 */     if (l == null) {
/* 1207 */       throw new IllegalArgumentException("Webcam discovery listener cannot be null!");
/*      */     }
/* 1209 */     return DISCOVERY_LISTENERS.add(l);
/*      */   }
/*      */   
/*      */   public static WebcamDiscoveryListener[] getDiscoveryListeners() {
/* 1213 */     return DISCOVERY_LISTENERS.<WebcamDiscoveryListener>toArray(new WebcamDiscoveryListener[DISCOVERY_LISTENERS.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean removeDiscoveryListener(WebcamDiscoveryListener l) {
/* 1223 */     return DISCOVERY_LISTENERS.remove(l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized WebcamDiscoveryService getDiscoveryService() {
/* 1232 */     if (discovery == null) {
/* 1233 */       discovery = new WebcamDiscoveryService(getDriver());
/*      */     }
/* 1235 */     return discovery;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized WebcamDiscoveryService getDiscoveryServiceRef() {
/* 1244 */     return discovery;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WebcamImageTransformer getImageTransformer() {
/* 1253 */     return this.transformer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setImageTransformer(WebcamImageTransformer transformer) {
/* 1262 */     this.transformer = transformer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WebcamLock getLock() {
/* 1271 */     return this.lock;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static void shutdown() {
/* 1281 */     WebcamDiscoveryService discovery = getDiscoveryServiceRef();
/* 1282 */     if (discovery != null) {
/* 1283 */       discovery.stop();
/*      */     }
/*      */ 
/*      */     
/* 1287 */     WebcamProcessor.getInstance().shutdown();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Webcam getWebcamByName(String name) {
/* 1301 */     if (name == null) {
/* 1302 */       throw new IllegalArgumentException("Webcam name cannot be null");
/*      */     }
/*      */     
/* 1305 */     for (Webcam webcam : getWebcams()) {
/* 1306 */       if (webcam.getName().equals(name)) {
/* 1307 */         return webcam;
/*      */       }
/*      */     } 
/*      */     
/* 1311 */     return null;
/*      */   }
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\Webcam.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */