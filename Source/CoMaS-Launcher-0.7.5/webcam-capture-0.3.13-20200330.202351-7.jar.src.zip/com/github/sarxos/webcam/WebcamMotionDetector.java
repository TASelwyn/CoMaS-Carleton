/*     */ package com.github.sarxos.webcam;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebcamMotionDetector
/*     */ {
/*  27 */   private static final Logger LOG = LoggerFactory.getLogger(WebcamMotionDetector.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  32 */   private static final AtomicInteger NT = new AtomicInteger(0);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  37 */   private static final ThreadFactory THREAD_FACTORY = new DetectorThreadFactory();
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_INTERVAL = 500;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class DetectorThreadFactory
/*     */     implements ThreadFactory
/*     */   {
/*     */     private DetectorThreadFactory() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public Thread newThread(Runnable runnable) {
/*  53 */       Thread t = new Thread(runnable, String.format("motion-detector-%d", new Object[] { Integer.valueOf(WebcamMotionDetector.access$100().incrementAndGet()) }));
/*  54 */       t.setUncaughtExceptionHandler(WebcamExceptionHandler.getInstance());
/*  55 */       t.setDaemon(true);
/*  56 */       return t;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class Runner
/*     */     implements Runnable
/*     */   {
/*     */     private Runner() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/*  70 */       WebcamMotionDetector.this.running.set(true);
/*     */       
/*  72 */       while (WebcamMotionDetector.this.running.get() && WebcamMotionDetector.this.webcam.isOpen()) {
/*     */         try {
/*  74 */           WebcamMotionDetector.this.detect();
/*  75 */           Thread.sleep(WebcamMotionDetector.this.interval);
/*  76 */         } catch (InterruptedException e) {
/*     */           break;
/*  78 */         } catch (Exception e) {
/*  79 */           WebcamExceptionHandler.handle(e);
/*     */         } 
/*     */       } 
/*     */       
/*  83 */       WebcamMotionDetector.this.running.set(false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class Inverter
/*     */     implements Runnable
/*     */   {
/*     */     private Inverter() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/*  97 */       int delay = 0;
/*     */       
/*  99 */       while (WebcamMotionDetector.this.running.get()) {
/*     */         
/*     */         try {
/* 102 */           Thread.sleep(10L);
/* 103 */         } catch (InterruptedException e) {
/*     */           break;
/*     */         } 
/*     */         
/* 107 */         delay = (WebcamMotionDetector.this.inertia != -1) ? WebcamMotionDetector.this.inertia : (2 * WebcamMotionDetector.this.interval);
/*     */         
/* 109 */         if (WebcamMotionDetector.this.lastMotionTimestamp + delay < System.currentTimeMillis()) {
/* 110 */           WebcamMotionDetector.this.motion = false;
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   private final ExecutorService executor = Executors.newFixedThreadPool(2, THREAD_FACTORY);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   private final List<WebcamMotionListener> listeners = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   private final AtomicBoolean running = new AtomicBoolean(false);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile boolean motion = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 139 */   private BufferedImage previousOriginal = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   private BufferedImage previousFiltered = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 149 */   private Webcam webcam = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   private volatile int interval = 500;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   private volatile int inertia = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 164 */   private volatile long lastMotionTimestamp = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final WebcamMotionDetectorAlgorithm algorithm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebcamMotionDetector(Webcam webcam, WebcamMotionDetectorAlgorithm algorithm, int interval) {
/* 179 */     this.webcam = webcam;
/* 180 */     this.algorithm = algorithm;
/* 181 */     setInterval(interval);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebcamMotionDetector(Webcam webcam, int pixelThreshold, double areaThreshold, int interval) {
/* 194 */     this(webcam, new WebcamMotionDetectorDefaultAlgorithm(pixelThreshold, areaThreshold), interval);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebcamMotionDetector(Webcam webcam, int pixelThreshold, double areaThreshold) {
/* 206 */     this(webcam, pixelThreshold, areaThreshold, 500);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebcamMotionDetector(Webcam webcam, int pixelThreshold) {
/* 217 */     this(webcam, pixelThreshold, 0.2D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebcamMotionDetector(Webcam webcam) {
/* 226 */     this(webcam, 25);
/*     */   }
/*     */   
/*     */   public void start() {
/* 230 */     if (this.running.compareAndSet(false, true)) {
/* 231 */       this.webcam.open();
/* 232 */       this.executor.submit(new Runner());
/* 233 */       this.executor.submit(new Inverter());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void stop() {
/* 238 */     if (this.running.compareAndSet(true, false)) {
/* 239 */       this.webcam.close();
/* 240 */       this.executor.shutdownNow();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void detect() {
/* 246 */     if (!this.webcam.isOpen()) {
/* 247 */       this.motion = false;
/*     */       
/*     */       return;
/*     */     } 
/* 251 */     BufferedImage currentOriginal = this.webcam.getImage();
/*     */     
/* 253 */     if (currentOriginal == null) {
/* 254 */       this.motion = false;
/*     */       
/*     */       return;
/*     */     } 
/* 258 */     BufferedImage currentFiltered = this.algorithm.filter(currentOriginal);
/* 259 */     boolean motionDetected = this.algorithm.detect(this.previousFiltered, currentFiltered);
/*     */     
/* 261 */     if (motionDetected) {
/* 262 */       this.motion = true;
/* 263 */       this.lastMotionTimestamp = System.currentTimeMillis();
/* 264 */       notifyMotionListeners(currentOriginal);
/*     */     } 
/*     */     
/* 267 */     this.previousOriginal = currentOriginal;
/* 268 */     this.previousFiltered = currentFiltered;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void notifyMotionListeners(BufferedImage currentOriginal) {
/* 277 */     WebcamMotionEvent wme = new WebcamMotionEvent(this, this.previousOriginal, currentOriginal, this.algorithm.getArea(), this.algorithm.getCog(), this.algorithm.getPoints());
/* 278 */     for (WebcamMotionListener l : this.listeners) {
/*     */       try {
/* 280 */         l.motionDetected(wme);
/* 281 */       } catch (Exception e) {
/* 282 */         WebcamExceptionHandler.handle(e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addMotionListener(WebcamMotionListener l) {
/* 294 */     return this.listeners.add(l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebcamMotionListener[] getMotionListeners() {
/* 301 */     return this.listeners.<WebcamMotionListener>toArray(new WebcamMotionListener[this.listeners.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeMotionListener(WebcamMotionListener l) {
/* 311 */     return this.listeners.remove(l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInterval() {
/* 318 */     return this.interval;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInterval(int interval) {
/* 330 */     if (interval < 100) {
/* 331 */       throw new IllegalArgumentException("Motion check interval cannot be less than 100 ms");
/*     */     }
/*     */     
/* 334 */     this.interval = interval;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPixelThreshold(int threshold) {
/* 346 */     ((WebcamMotionDetectorDefaultAlgorithm)this.algorithm).setPixelThreshold(threshold);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAreaThreshold(double threshold) {
/* 358 */     ((WebcamMotionDetectorDefaultAlgorithm)this.algorithm).setAreaThreshold(threshold);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInertia(int inertia) {
/* 369 */     if (inertia < 0) {
/* 370 */       throw new IllegalArgumentException("Inertia time must not be negative!");
/*     */     }
/* 372 */     this.inertia = inertia;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearInertia() {
/* 380 */     this.inertia = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Webcam getWebcam() {
/* 389 */     return this.webcam;
/*     */   }
/*     */   
/*     */   public boolean isMotion() {
/* 393 */     if (!this.running.get()) {
/* 394 */       LOG.warn("Motion cannot be detected when detector is not running!");
/*     */     }
/* 396 */     return this.motion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getMotionArea() {
/* 406 */     return this.algorithm.getArea();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point getMotionCog() {
/* 416 */     Point cog = this.algorithm.getCog();
/* 417 */     if (cog == null) {
/*     */       
/* 419 */       int w = (this.webcam.getViewSize()).width;
/* 420 */       int h = (this.webcam.getViewSize()).height;
/* 421 */       cog = new Point(w / 2, h / 2);
/*     */     } 
/* 423 */     return cog;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebcamMotionDetectorAlgorithm getDetectorAlgorithm() {
/* 430 */     return this.algorithm;
/*     */   }
/*     */   
/*     */   public void setMaxMotionPoints(int i) {
/* 434 */     this.algorithm.setMaxPoints(i);
/*     */   }
/*     */   
/*     */   public int getMaxMotionPoints() {
/* 438 */     return this.algorithm.getMaxPoints();
/*     */   }
/*     */   
/*     */   public void setPointRange(int i) {
/* 442 */     this.algorithm.setPointRange(i);
/*     */   }
/*     */   
/*     */   public int getPointRange() {
/* 446 */     return this.algorithm.getPointRange();
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamMotionDetector.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */