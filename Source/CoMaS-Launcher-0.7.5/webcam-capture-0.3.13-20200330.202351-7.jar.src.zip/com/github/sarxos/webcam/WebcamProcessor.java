/*     */ package com.github.sarxos.webcam;
/*     */ 
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.SynchronousQueue;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebcamProcessor
/*     */ {
/*  18 */   private static final Logger LOG = LoggerFactory.getLogger(WebcamProcessor.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class ProcessorThread
/*     */     extends Thread
/*     */   {
/*  27 */     private static final AtomicInteger N = new AtomicInteger(0);
/*     */     
/*     */     public ProcessorThread(Runnable r) {
/*  30 */       super(r, String.format("atomic-processor-%d", new Object[] { Integer.valueOf(N.incrementAndGet()) }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class ProcessorThreadFactory
/*     */     implements ThreadFactory
/*     */   {
/*     */     private ProcessorThreadFactory() {}
/*     */ 
/*     */     
/*     */     public Thread newThread(Runnable r) {
/*  43 */       Thread t = new WebcamProcessor.ProcessorThread(r);
/*  44 */       t.setUncaughtExceptionHandler(WebcamExceptionHandler.getInstance());
/*  45 */       t.setDaemon(true);
/*  46 */       return t;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class AtomicProcessor
/*     */     implements Runnable
/*     */   {
/*  58 */     private SynchronousQueue<WebcamTask> inbound = new SynchronousQueue<>(true);
/*  59 */     private SynchronousQueue<WebcamTask> outbound = new SynchronousQueue<>(true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void process(WebcamTask task) throws InterruptedException {
/*  68 */       this.inbound.put(task);
/*     */       
/*  70 */       Throwable t = ((WebcamTask)this.outbound.take()).getThrowable();
/*  71 */       if (t != null) {
/*  72 */         throw new WebcamException("Cannot execute task", t);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/*     */       while (true) {
/*  79 */         WebcamTask t = null;
/*     */         try {
/*  81 */           (t = this.inbound.take()).handle();
/*  82 */         } catch (InterruptedException e) {
/*     */           break;
/*  84 */         } catch (Throwable e) {
/*  85 */           if (t != null) {
/*  86 */             t.setThrowable(e);
/*     */           }
/*     */         } finally {
/*  89 */           if (t != null) {
/*     */             try {
/*  91 */               this.outbound.put(t);
/*  92 */             } catch (InterruptedException e) {
/*     */               break;
/*  94 */             } catch (Exception e) {
/*  95 */               throw new RuntimeException("Cannot put task into outbound queue", e);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private AtomicProcessor() {}
/*     */   }
/*     */   
/* 106 */   private static final AtomicBoolean started = new AtomicBoolean(false);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   private static ExecutorService runner = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   private static final AtomicProcessor processor = new AtomicProcessor();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   private static final WebcamProcessor INSTANCE = new WebcamProcessor();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void process(WebcamTask task) throws InterruptedException {
/* 134 */     if (started.compareAndSet(false, true)) {
/* 135 */       runner = Executors.newSingleThreadExecutor(new ProcessorThreadFactory());
/* 136 */       runner.execute(processor);
/*     */     } 
/*     */     
/* 139 */     if (!runner.isShutdown()) {
/* 140 */       processor.process(task);
/*     */     } else {
/* 142 */       throw new RejectedExecutionException("Cannot process because processor runner has been already shut down");
/*     */     } 
/*     */   }
/*     */   
/*     */   public void shutdown() {
/* 147 */     if (started.compareAndSet(true, false)) {
/*     */       
/* 149 */       LOG.debug("Shutting down webcam processor");
/*     */       
/* 151 */       runner.shutdown();
/*     */       
/* 153 */       LOG.debug("Awaiting tasks termination");
/*     */       
/* 155 */       while (runner.isTerminated()) {
/*     */         
/*     */         try {
/* 158 */           runner.awaitTermination(100L, TimeUnit.MILLISECONDS);
/* 159 */         } catch (InterruptedException e) {
/*     */           return;
/*     */         } 
/*     */         
/* 163 */         runner.shutdownNow();
/*     */       } 
/*     */       
/* 166 */       LOG.debug("All tasks has been terminated");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static synchronized WebcamProcessor getInstance() {
/* 172 */     return INSTANCE;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamProcessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */