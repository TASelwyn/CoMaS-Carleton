/*    */ package com.apple.concurrent;
/*    */ import java.util.concurrent.Executor;
/*    */ import java.util.concurrent.ExecutorService;
/*    */ 
/*    */ public final class Dispatch {
/*    */   public enum Priority {
/*  7 */     LOW(-2), NORMAL(0), HIGH(2);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static RuntimeException unimplemented() {
/* 13 */     return new RuntimeException("Unimplemented");
/*    */   }
/*    */   
/*    */   public static Dispatch getInstance() {
/* 17 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public Executor getAsyncExecutor(Priority paramPriority) {
/* 21 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public ExecutorService createSerialExecutor(String paramString) {
/* 25 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public Executor getNonBlockingMainQueueExecutor() {
/* 29 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public Executor getBlockingMainQueueExecutor() {
/* 33 */     throw unimplemented();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\applejavaextensions-1.4.jar!\com\apple\concurrent\Dispatch.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */