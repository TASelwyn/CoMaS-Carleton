package com.apple.eawt;

import java.util.EventObject;

public class ApplicationEvent extends EventObject {
  ApplicationEvent(Object paramObject) {
    super(paramObject);
    throw Application.unimplemented();
  }
  
  ApplicationEvent(Object paramObject, String paramString) {
    super(paramObject);
    throw Application.unimplemented();
  }
  
  public boolean isHandled() {
    throw Application.unimplemented();
  }
  
  public void setHandled(boolean paramBoolean) {
    throw Application.unimplemented();
  }
  
  public String getFilename() {
    throw Application.unimplemented();
  }
}
