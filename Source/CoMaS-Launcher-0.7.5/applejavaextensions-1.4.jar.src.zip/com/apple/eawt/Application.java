package com.apple.eawt;

import java.awt.Image;
import java.awt.Point;
import java.awt.PopupMenu;
import javax.swing.JMenuBar;

public class Application {
  static RuntimeException unimplemented() {
    return new RuntimeException("Unimplemented");
  }
  
  @Deprecated
  public Application() {
    throw unimplemented();
  }
  
  public static Application getApplication() {
    throw unimplemented();
  }
  
  public void addApplicationListener(ApplicationListener paramApplicationListener) {
    throw unimplemented();
  }
  
  public void removeApplicationListener(ApplicationListener paramApplicationListener) {
    throw unimplemented();
  }
  
  public void setEnabledPreferencesMenu(boolean paramBoolean) {
    throw unimplemented();
  }
  
  public void setEnabledAboutMenu(boolean paramBoolean) {
    throw unimplemented();
  }
  
  public boolean getEnabledPreferencesMenu() {
    throw unimplemented();
  }
  
  public boolean getEnabledAboutMenu() {
    throw unimplemented();
  }
  
  public boolean isAboutMenuItemPresent() {
    throw unimplemented();
  }
  
  public void addAboutMenuItem() {
    throw unimplemented();
  }
  
  public void removeAboutMenuItem() {
    throw unimplemented();
  }
  
  public boolean isPreferencesMenuItemPresent() {
    throw unimplemented();
  }
  
  public void addPreferencesMenuItem() {
    throw unimplemented();
  }
  
  public void removePreferencesMenuItem() {
    throw unimplemented();
  }
  
  @Deprecated
  public static Point getMouseLocationOnScreen() {
    throw unimplemented();
  }
  
  public void requestForeground(boolean paramBoolean) {
    throw unimplemented();
  }
  
  public void requestUserAttention(boolean paramBoolean) {
    throw unimplemented();
  }
  
  public void openHelpViewer() {
    throw unimplemented();
  }
  
  public void setDockMenu(PopupMenu paramPopupMenu) {
    throw unimplemented();
  }
  
  public PopupMenu getDockMenu() {
    throw unimplemented();
  }
  
  public void setDockIconImage(Image paramImage) {
    throw unimplemented();
  }
  
  public Image getDockIconImage() {
    throw unimplemented();
  }
  
  public void setDockIconBadge(String paramString) {
    throw unimplemented();
  }
  
  public void setDefaultMenuBar(JMenuBar paramJMenuBar) {
    throw unimplemented();
  }
}
