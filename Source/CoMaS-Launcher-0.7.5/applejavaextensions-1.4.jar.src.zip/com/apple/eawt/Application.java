/*     */ package com.apple.eawt;
/*     */ 
/*     */ import java.awt.Image;
/*     */ import java.awt.Point;
/*     */ import java.awt.PopupMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Application
/*     */ {
/*     */   static RuntimeException unimplemented() {
/*  14 */     return new RuntimeException("Unimplemented");
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public Application() {
/*  19 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public static Application getApplication() {
/*  23 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void addApplicationListener(ApplicationListener paramApplicationListener) {
/*  27 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void removeApplicationListener(ApplicationListener paramApplicationListener) {
/*  31 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void setEnabledPreferencesMenu(boolean paramBoolean) {
/*  35 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void setEnabledAboutMenu(boolean paramBoolean) {
/*  39 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public boolean getEnabledPreferencesMenu() {
/*  43 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public boolean getEnabledAboutMenu() {
/*  47 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public boolean isAboutMenuItemPresent() {
/*  51 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void addAboutMenuItem() {
/*  55 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void removeAboutMenuItem() {
/*  59 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public boolean isPreferencesMenuItemPresent() {
/*  63 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void addPreferencesMenuItem() {
/*  67 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void removePreferencesMenuItem() {
/*  71 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static Point getMouseLocationOnScreen() {
/*  76 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void requestForeground(boolean paramBoolean) {
/*  80 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void requestUserAttention(boolean paramBoolean) {
/*  84 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void openHelpViewer() {
/*  88 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void setDockMenu(PopupMenu paramPopupMenu) {
/*  92 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public PopupMenu getDockMenu() {
/*  96 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void setDockIconImage(Image paramImage) {
/* 100 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public Image getDockIconImage() {
/* 104 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void setDockIconBadge(String paramString) {
/* 108 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void setDefaultMenuBar(JMenuBar paramJMenuBar) {
/* 112 */     throw unimplemented();
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\applejavaextensions-1.4.jar!\com\apple\eawt\Application.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */