package com.apple.eawt.event;

public interface MagnificationListener extends GestureListener {
  void magnify(MagnificationEvent paramMagnificationEvent);
}
