/*   */ package com.apple.eawt.event;
/*   */ 
/*   */ public class GesturePhaseEvent
/*   */   extends GestureEvent {
/*   */   GesturePhaseEvent() {
/* 6 */     GestureUtilities.unimplemented();
/*   */   }
/*   */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\applejavaextensions-1.4.jar!\com\apple\eawt\event\GesturePhaseEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */