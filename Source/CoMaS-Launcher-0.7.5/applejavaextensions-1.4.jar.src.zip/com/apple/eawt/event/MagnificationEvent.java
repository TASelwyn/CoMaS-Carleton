/*    */ package com.apple.eawt.event;
/*    */ 
/*    */ public class MagnificationEvent
/*    */   extends GestureEvent {
/*    */   MagnificationEvent(double paramDouble) {
/*  6 */     GestureUtilities.unimplemented();
/*    */   }
/*    */   
/*    */   public double getMagnification() {
/* 10 */     GestureUtilities.unimplemented();
/* 11 */     return 0.0D;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\applejavaextensions-1.4.jar!\com\apple\eawt\event\MagnificationEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */