package com.apple.eawt;

public class ApplicationAdapter implements ApplicationListener {
  public void handleAbout(ApplicationEvent paramApplicationEvent) {
    throw Application.unimplemented();
  }
  
  public void handleOpenApplication(ApplicationEvent paramApplicationEvent) {
    throw Application.unimplemented();
  }
  
  public void handleOpenFile(ApplicationEvent paramApplicationEvent) {
    throw Application.unimplemented();
  }
  
  public void handlePreferences(ApplicationEvent paramApplicationEvent) {
    throw Application.unimplemented();
  }
  
  public void handlePrintFile(ApplicationEvent paramApplicationEvent) {
    throw Application.unimplemented();
  }
  
  public void handleQuit(ApplicationEvent paramApplicationEvent) {
    throw Application.unimplemented();
  }
  
  public void handleReOpenApplication(ApplicationEvent paramApplicationEvent) {
    throw Application.unimplemented();
  }
}
