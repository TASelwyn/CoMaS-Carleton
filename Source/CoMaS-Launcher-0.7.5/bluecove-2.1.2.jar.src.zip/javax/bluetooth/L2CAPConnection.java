package javax.bluetooth;

import java.io.IOException;
import javax.microedition.io.Connection;

public interface L2CAPConnection extends Connection {
  public static final int DEFAULT_MTU = 672;
  
  public static final int MINIMUM_MTU = 48;
  
  int getTransmitMTU() throws IOException;
  
  int getReceiveMTU() throws IOException;
  
  void send(byte[] paramArrayOfbyte) throws IOException;
  
  int receive(byte[] paramArrayOfbyte) throws IOException;
  
  boolean ready() throws IOException;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\javax\bluetooth\L2CAPConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */