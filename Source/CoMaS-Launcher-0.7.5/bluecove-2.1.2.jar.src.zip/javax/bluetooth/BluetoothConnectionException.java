/*     */ package javax.bluetooth;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BluetoothConnectionException
/*     */   extends IOException
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final int UNKNOWN_PSM = 1;
/*     */   public static final int SECURITY_BLOCK = 2;
/*     */   public static final int NO_RESOURCES = 3;
/*     */   public static final int FAILED_NOINFO = 4;
/*     */   public static final int TIMEOUT = 5;
/*     */   public static final int UNACCEPTABLE_PARAMS = 6;
/*     */   private int errorCode;
/*     */   
/*     */   public BluetoothConnectionException(int error) {
/* 106 */     if (error < 1 || error > 6) {
/* 107 */       throw new IllegalArgumentException();
/*     */     }
/* 109 */     this.errorCode = error;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BluetoothConnectionException(int error, String msg) {
/* 123 */     super(msg);
/* 124 */     if (error < 1 || error > 6) {
/* 125 */       throw new IllegalArgumentException();
/*     */     }
/* 127 */     this.errorCode = error;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getStatus() {
/* 137 */     return this.errorCode;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\javax\bluetooth\BluetoothConnectionException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */