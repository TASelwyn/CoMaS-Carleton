/*     */ package javax.bluetooth;
/*     */ 
/*     */ import com.intel.bluetooth.BluetoothStack;
/*     */ import com.intel.bluetooth.DebugLog;
/*     */ import com.intel.bluetooth.RemoteDeviceHelper;
/*     */ import com.intel.bluetooth.SelectServiceHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiscoveryAgent
/*     */ {
/*     */   public static final int NOT_DISCOVERABLE = 0;
/*     */   public static final int GIAC = 10390323;
/*     */   public static final int LIAC = 10390272;
/*     */   public static final int CACHED = 0;
/*     */   public static final int PREKNOWN = 1;
/*     */   private BluetoothStack bluetoothStack;
/*     */   
/*     */   private DiscoveryAgent() {}
/*     */   
/*     */   DiscoveryAgent(BluetoothStack bluetoothStack) {
/* 128 */     this();
/* 129 */     this.bluetoothStack = bluetoothStack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RemoteDevice[] retrieveDevices(int option) {
/* 169 */     return RemoteDeviceHelper.implRetrieveDevices(this.bluetoothStack, option);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean startInquiry(int accessCode, DiscoveryListener listener) throws BluetoothStateException {
/* 208 */     if (listener == null) {
/* 209 */       throw new NullPointerException("DiscoveryListener is null");
/*     */     }
/* 211 */     if (accessCode != 10390272 && accessCode != 10390323 && (accessCode < 10390272 || accessCode > 10390335)) {
/* 212 */       throw new IllegalArgumentException("Invalid accessCode " + accessCode);
/*     */     }
/* 214 */     return this.bluetoothStack.startInquiry(accessCode, listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean cancelInquiry(DiscoveryListener listener) {
/* 241 */     if (listener == null) {
/* 242 */       throw new NullPointerException("DiscoveryListener is null");
/*     */     }
/* 244 */     DebugLog.debug("cancelInquiry");
/* 245 */     return this.bluetoothStack.cancelInquiry(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int searchServices(int[] attrSet, UUID[] uuidSet, RemoteDevice btDev, DiscoveryListener discListener) throws BluetoothStateException {
/* 306 */     if (uuidSet == null) {
/* 307 */       throw new NullPointerException("uuidSet is null");
/*     */     }
/* 309 */     if (uuidSet.length == 0)
/*     */     {
/* 311 */       throw new IllegalArgumentException("uuidSet is empty");
/*     */     }
/* 313 */     for (int u1 = 0; u1 < uuidSet.length; u1++) {
/* 314 */       if (uuidSet[u1] == null) {
/* 315 */         throw new NullPointerException("uuidSet[" + u1 + "] is null");
/*     */       }
/* 317 */       for (int u2 = u1 + 1; u2 < uuidSet.length; u2++) {
/* 318 */         if (uuidSet[u1].equals(uuidSet[u2])) {
/* 319 */           throw new IllegalArgumentException("uuidSet has duplicate values " + uuidSet[u1].toString());
/*     */         }
/*     */       } 
/*     */     } 
/* 323 */     if (btDev == null) {
/* 324 */       throw new NullPointerException("RemoteDevice is null");
/*     */     }
/* 326 */     if (discListener == null) {
/* 327 */       throw new NullPointerException("DiscoveryListener is null");
/*     */     }
/* 329 */     for (int i = 0; attrSet != null && i < attrSet.length; i++) {
/* 330 */       if (attrSet[i] < 0 || attrSet[i] > 65535) {
/* 331 */         throw new IllegalArgumentException("attrSet[" + i + "] not in range");
/*     */       }
/*     */     } 
/* 334 */     return this.bluetoothStack.searchServices(attrSet, uuidSet, btDev, discListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean cancelServiceSearch(int transID) {
/* 355 */     DebugLog.debug("cancelServiceSearch", transID);
/* 356 */     return this.bluetoothStack.cancelServiceSearch(transID);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String selectService(UUID uuid, int security, boolean master) throws BluetoothStateException {
/* 412 */     return (new SelectServiceHandler(this)).selectService(uuid, security, master);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\javax\bluetooth\DiscoveryAgent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */