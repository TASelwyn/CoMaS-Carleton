package javax.bluetooth;

import java.io.IOException;

public interface ServiceRecord {
  public static final int NOAUTHENTICATE_NOENCRYPT = 0;
  
  public static final int AUTHENTICATE_NOENCRYPT = 1;
  
  public static final int AUTHENTICATE_ENCRYPT = 2;
  
  DataElement getAttributeValue(int paramInt);
  
  RemoteDevice getHostDevice();
  
  int[] getAttributeIDs();
  
  boolean populateRecord(int[] paramArrayOfint) throws IOException;
  
  String getConnectionURL(int paramInt, boolean paramBoolean);
  
  void setDeviceServiceClasses(int paramInt);
  
  boolean setAttributeValue(int paramInt, DataElement paramDataElement);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\javax\bluetooth\ServiceRecord.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */