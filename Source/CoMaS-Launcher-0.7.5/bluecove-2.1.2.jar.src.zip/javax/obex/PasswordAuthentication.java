/*    */ package javax.obex;
/*    */ 
/*    */ import com.intel.bluetooth.Utils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PasswordAuthentication
/*    */ {
/*    */   private byte[] userName;
/*    */   private byte[] password;
/*    */   
/*    */   public PasswordAuthentication(byte[] userName, byte[] password) {
/* 55 */     if (password == null) {
/* 56 */       throw new NullPointerException("password is null");
/*    */     }
/* 58 */     this.userName = Utils.clone(userName);
/* 59 */     this.password = Utils.clone(password);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getUserName() {
/* 69 */     return Utils.clone(this.userName);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getPassword() {
/* 78 */     return Utils.clone(this.password);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\javax\obex\PasswordAuthentication.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */