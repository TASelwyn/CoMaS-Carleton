package javax.obex;

import java.io.IOException;
import javax.microedition.io.ContentConnection;

public interface Operation extends ContentConnection {
  void abort() throws IOException;
  
  HeaderSet getReceivedHeaders() throws IOException;
  
  void sendHeaders(HeaderSet paramHeaderSet) throws IOException;
  
  int getResponseCode() throws IOException;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\javax\obex\Operation.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */