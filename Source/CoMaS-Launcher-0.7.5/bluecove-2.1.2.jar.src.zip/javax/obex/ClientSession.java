package javax.obex;

import java.io.IOException;
import javax.microedition.io.Connection;

public interface ClientSession extends Connection {
  void setAuthenticator(Authenticator paramAuthenticator);
  
  HeaderSet createHeaderSet();
  
  void setConnectionID(long paramLong);
  
  long getConnectionID();
  
  HeaderSet connect(HeaderSet paramHeaderSet) throws IOException;
  
  HeaderSet disconnect(HeaderSet paramHeaderSet) throws IOException;
  
  HeaderSet setPath(HeaderSet paramHeaderSet, boolean paramBoolean1, boolean paramBoolean2) throws IOException;
  
  HeaderSet delete(HeaderSet paramHeaderSet) throws IOException;
  
  Operation get(HeaderSet paramHeaderSet) throws IOException;
  
  Operation put(HeaderSet paramHeaderSet) throws IOException;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\javax\obex\ClientSession.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */