package javax.obex;

import java.io.IOException;

public interface HeaderSet {
  public static final int COUNT = 192;
  
  public static final int NAME = 1;
  
  public static final int TYPE = 66;
  
  public static final int LENGTH = 195;
  
  public static final int TIME_ISO_8601 = 68;
  
  public static final int TIME_4_BYTE = 196;
  
  public static final int DESCRIPTION = 5;
  
  public static final int TARGET = 70;
  
  public static final int HTTP = 71;
  
  public static final int WHO = 74;
  
  public static final int OBJECT_CLASS = 79;
  
  public static final int APPLICATION_PARAMETER = 76;
  
  void setHeader(int paramInt, Object paramObject);
  
  Object getHeader(int paramInt) throws IOException;
  
  int[] getHeaderList() throws IOException;
  
  void createAuthenticationChallenge(String paramString, boolean paramBoolean1, boolean paramBoolean2);
  
  int getResponseCode() throws IOException;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\javax\obex\HeaderSet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */