package javax.obex;

public interface Authenticator {
  PasswordAuthentication onAuthenticationChallenge(String paramString, boolean paramBoolean1, boolean paramBoolean2);
  
  byte[] onAuthenticationResponse(byte[] paramArrayOfbyte);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\javax\obex\Authenticator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */