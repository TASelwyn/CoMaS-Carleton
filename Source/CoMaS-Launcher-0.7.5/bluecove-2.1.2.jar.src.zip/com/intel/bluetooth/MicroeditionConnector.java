/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import com.intel.bluetooth.gcf.socket.ServerSocketConnection;
/*     */ import com.intel.bluetooth.gcf.socket.SocketConnection;
/*     */ import com.intel.bluetooth.obex.OBEXClientSessionImpl;
/*     */ import com.intel.bluetooth.obex.OBEXConnectionParams;
/*     */ import com.intel.bluetooth.obex.OBEXSessionNotifierImpl;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import javax.bluetooth.BluetoothConnectionException;
/*     */ import javax.bluetooth.UUID;
/*     */ import javax.microedition.io.Connection;
/*     */ import javax.microedition.io.ConnectionNotFoundException;
/*     */ import javax.microedition.io.InputConnection;
/*     */ import javax.microedition.io.OutputConnection;
/*     */ import javax.microedition.io.StreamConnection;
/*     */ import javax.microedition.io.StreamConnectionNotifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MicroeditionConnector
/*     */ {
/*     */   public static final int READ = 1;
/*     */   public static final int WRITE = 2;
/*     */   public static final int READ_WRITE = 3;
/*  76 */   private static Hashtable suportScheme = new Hashtable();
/*  77 */   private static Hashtable srvParams = new Hashtable();
/*  78 */   private static Hashtable cliParams = new Hashtable();
/*  79 */   private static Hashtable cliParamsL2CAP = new Hashtable();
/*  80 */   private static Hashtable srvParamsL2CAP = new Hashtable();
/*     */   
/*     */   private static final String AUTHENTICATE = "authenticate";
/*     */   private static final String AUTHORIZE = "authorize";
/*     */   private static final String ENCRYPT = "encrypt";
/*     */   private static final String MASTER = "master";
/*     */   private static final String NAME = "name";
/*     */   private static final String RECEIVE_MTU = "receivemtu";
/*     */   private static final String TRANSMIT_MTU = "transmitmtu";
/*     */   private static final String EXT_BLUECOVE_L2CAP_PSM = "bluecovepsm";
/*     */   private static final String ANDROID = "android";
/*     */   
/*     */   static {
/*  93 */     cliParams.put("authenticate", "authenticate");
/*  94 */     cliParams.put("encrypt", "encrypt");
/*  95 */     cliParams.put("master", "master");
/*     */ 
/*     */     
/*  98 */     copyAll(srvParams, cliParams);
/*  99 */     srvParams.put("authorize", "authorize");
/* 100 */     srvParams.put("name", "name");
/*     */     
/* 102 */     copyAll(cliParamsL2CAP, cliParams);
/*     */     
/* 104 */     cliParamsL2CAP.put("receivemtu", "receivemtu");
/* 105 */     cliParamsL2CAP.put("transmitmtu", "transmitmtu");
/*     */     
/* 107 */     copyAll(srvParamsL2CAP, cliParamsL2CAP);
/* 108 */     srvParamsL2CAP.put("authorize", "authorize");
/* 109 */     srvParamsL2CAP.put("name", "name");
/* 110 */     srvParamsL2CAP.put("bluecovepsm", "bluecovepsm");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     suportScheme.put("btspp", Boolean.TRUE);
/* 116 */     suportScheme.put("btgoep", Boolean.TRUE);
/* 117 */     suportScheme.put("tcpobex", Boolean.TRUE);
/* 118 */     suportScheme.put("btl2cap", Boolean.TRUE);
/* 119 */     suportScheme.put("socket", Boolean.TRUE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void copyAll(Hashtable dest, Hashtable src) {
/* 126 */     for (Enumeration en = src.keys(); en.hasMoreElements(); ) {
/* 127 */       Object key = en.nextElement();
/* 128 */       dest.put(key, src.get(key));
/*     */     } 
/*     */   }
/*     */   
/*     */   static String validParamName(Hashtable map, String paramName) {
/* 133 */     String validName = (String)map.get(paramName.toLowerCase());
/* 134 */     if (validName != null) {
/* 135 */       return validName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     if ("android".equals(paramName)) {
/* 142 */       return "android";
/*     */     }
/*     */ 
/*     */     
/* 146 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Connection open(String name) throws IOException {
/* 156 */     return openImpl(name, 3, false, true);
/*     */   }
/*     */   
/*     */   private static Connection openImpl(String name, int mode, boolean timeouts, boolean allowServer) throws IOException {
/*     */     boolean isServer;
/* 161 */     DebugLog.debug("connecting", name);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 167 */     String host = null;
/* 168 */     String portORuuid = null;
/*     */     
/* 170 */     Hashtable values = new Hashtable();
/*     */ 
/*     */     
/* 173 */     int schemeEnd = name.indexOf("://");
/* 174 */     if (schemeEnd == -1) {
/* 175 */       throw new ConnectionNotFoundException(name);
/*     */     }
/* 177 */     String scheme = name.substring(0, schemeEnd);
/* 178 */     if (!suportScheme.containsKey(scheme)) {
/* 179 */       throw new ConnectionNotFoundException(scheme);
/*     */     }
/* 181 */     boolean schemeBluetooth = (scheme.equals("btspp") || scheme.equals("btgoep") || scheme.equals("btl2cap"));
/*     */     
/* 183 */     boolean isL2CAP = scheme.equals("btl2cap");
/* 184 */     boolean isTCPOBEX = scheme.equals("tcpobex");
/*     */     
/* 186 */     BluetoothStack bluetoothStack = null;
/*     */     
/* 188 */     if (schemeBluetooth) {
/* 189 */       bluetoothStack = BlueCoveImpl.instance().getBluetoothStack();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 194 */     int hostEnd = name.indexOf(':', scheme.length() + 3);
/*     */     
/* 196 */     if (hostEnd > -1) {
/* 197 */       Hashtable params; host = name.substring(scheme.length() + 3, hostEnd);
/* 198 */       isServer = host.equals("localhost");
/*     */ 
/*     */       
/* 201 */       if (isTCPOBEX) {
/* 202 */         params = new Hashtable();
/* 203 */         isServer = (host.length() == 0);
/* 204 */       } else if (isL2CAP) {
/* 205 */         if (isServer) {
/* 206 */           params = srvParamsL2CAP;
/*     */         } else {
/* 208 */           params = cliParamsL2CAP;
/*     */         }
/*     */       
/* 211 */       } else if (isServer) {
/* 212 */         params = srvParams;
/*     */       } else {
/* 214 */         params = cliParams;
/*     */       } 
/*     */ 
/*     */       
/* 218 */       String paramsStr = name.substring(hostEnd + 1);
/* 219 */       UtilsStringTokenizer tok = new UtilsStringTokenizer(paramsStr, ";");
/* 220 */       if (tok.hasMoreTokens()) {
/* 221 */         portORuuid = tok.nextToken();
/*     */       } else {
/* 223 */         portORuuid = paramsStr;
/*     */       } 
/* 225 */       while (tok.hasMoreTokens()) {
/* 226 */         String t = tok.nextToken();
/* 227 */         int equals = t.indexOf('=');
/* 228 */         if (equals > -1) {
/* 229 */           String param = t.substring(0, equals);
/* 230 */           String value = t.substring(equals + 1);
/* 231 */           String validName = validParamName(params, param);
/* 232 */           if (validName != null) {
/* 233 */             String hasValue = (String)values.get(validName);
/* 234 */             if (hasValue != null && !hasValue.equals(value)) {
/* 235 */               throw new IllegalArgumentException("duplicate param [" + param + "] value [" + value + "]");
/*     */             }
/* 237 */             values.put(validName, value); continue;
/*     */           } 
/* 239 */           throw new IllegalArgumentException("invalid param [" + param + "] value [" + value + "]");
/*     */         } 
/*     */         
/* 242 */         throw new IllegalArgumentException("invalid param [" + t + "]");
/*     */       }
/*     */     
/* 245 */     } else if (isTCPOBEX) {
/* 246 */       host = name.substring(scheme.length() + 3);
/* 247 */       isServer = (host.length() == 0);
/*     */     } else {
/* 249 */       throw new IllegalArgumentException(name.substring(scheme.length() + 3));
/*     */     } 
/*     */     
/* 252 */     if (isTCPOBEX && (
/* 253 */       portORuuid == null || portORuuid.length() == 0)) {
/* 254 */       portORuuid = String.valueOf(650);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 270 */     if (host == null || portORuuid == null) {
/* 271 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 274 */     BluetoothConnectionNotifierParams notifierParams = null;
/*     */     
/* 276 */     BluetoothConnectionParams connectionParams = null;
/*     */     
/* 278 */     boolean isAndroid = values.containsKey("android");
/*     */     
/* 280 */     int channel = 0;
/* 281 */     if (isServer) {
/* 282 */       if (!allowServer) {
/* 283 */         throw new IllegalArgumentException("Can't use server connection URL");
/*     */       }
/* 285 */       if (values.get("name") == null) {
/* 286 */         values.put("name", "BlueCove");
/* 287 */       } else if (schemeBluetooth) {
/* 288 */         validateBluetoothServiceName((String)values.get("name"));
/*     */       } 
/* 290 */       if (schemeBluetooth) {
/* 291 */         notifierParams = new BluetoothConnectionNotifierParams(new UUID(portORuuid, false), paramBoolean(values, "authenticate"), paramBoolean(values, "encrypt"), paramBoolean(values, "authorize"), (String)values.get("name"), paramBoolean(values, "master"));
/*     */ 
/*     */         
/* 294 */         notifierParams.timeouts = timeouts;
/* 295 */         if (notifierParams.encrypt && !notifierParams.authenticate) {
/* 296 */           if (values.get("authenticate") == null) {
/* 297 */             notifierParams.authenticate = true;
/*     */           } else {
/* 299 */             throw new BluetoothConnectionException(6, "encryption requires authentication");
/*     */           } 
/*     */         }
/*     */         
/* 303 */         if (notifierParams.authorize && !notifierParams.authenticate) {
/* 304 */           if (values.get("authenticate") == null) {
/* 305 */             notifierParams.authenticate = true;
/*     */           } else {
/* 307 */             throw new BluetoothConnectionException(6, "authorization requires authentication");
/*     */           } 
/*     */         }
/*     */         
/* 311 */         if (isL2CAP) {
/* 312 */           String bluecove_ext_psm = (String)values.get("bluecovepsm");
/* 313 */           if (bluecove_ext_psm != null) {
/* 314 */             if ((bluetoothStack.getFeatureSet() & 0x10) == 0) {
/* 315 */               throw new IllegalArgumentException("bluecovepsm extension not supported on this stack");
/*     */             }
/* 317 */             int psm = Integer.parseInt(bluecove_ext_psm, 16);
/* 318 */             validateL2CAPPSM(psm, bluecove_ext_psm);
/* 319 */             notifierParams.bluecove_ext_psm = psm;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } else {
/* 324 */       if (!isAndroid) {
/*     */         try {
/* 326 */           channel = Integer.parseInt(portORuuid, isL2CAP ? 16 : 10);
/* 327 */         } catch (NumberFormatException e) {
/* 328 */           throw new IllegalArgumentException("channel " + portORuuid);
/*     */         } 
/* 330 */         if (channel < 0) {
/* 331 */           throw new IllegalArgumentException("channel " + portORuuid);
/*     */         }
/*     */       } 
/* 334 */       if (schemeBluetooth) {
/* 335 */         if (!isAndroid) {
/* 336 */           if (isL2CAP) {
/* 337 */             validateL2CAPPSM(channel, portORuuid);
/*     */           }
/* 339 */           else if (channel < 1 || channel > 30) {
/*     */             
/* 341 */             throw new IllegalArgumentException("RFCOMM channel " + portORuuid);
/*     */           } 
/*     */ 
/*     */           
/* 345 */           connectionParams = new BluetoothConnectionParams(RemoteDeviceHelper.getAddress(host), channel, paramBoolean(values, "authenticate"), paramBoolean(values, "encrypt"));
/*     */         } else {
/*     */ 
/*     */           
/*     */           try {
/* 350 */             connectionParams = Class.forName("com.intel.bluetooth.AndroidBluetoothConnectionParams").getConstructor(new Class[] { long.class, boolean.class, boolean.class }).newInstance(new Object[] { Long.valueOf(RemoteDeviceHelper.getAddress(host)), Boolean.valueOf(paramBoolean(values, "authenticate")), Boolean.valueOf(paramBoolean(values, "encrypt")) });
/*     */             
/* 352 */             connectionParams.getClass().getMethod("setServiceUUID", new Class[] { String.class }).invoke(connectionParams, new Object[] { portORuuid });
/* 353 */           } catch (Exception ex) {
/* 354 */             throw new BluetoothConnectionException(4, ex.toString());
/*     */           } 
/*     */         } 
/*     */         
/* 358 */         connectionParams.timeouts = timeouts;
/* 359 */         if (connectionParams.encrypt && !connectionParams.authenticate) {
/* 360 */           if (values.get("authenticate") == null) {
/* 361 */             connectionParams.authenticate = true;
/*     */           } else {
/* 363 */             throw new BluetoothConnectionException(6, "encryption requires authentication");
/*     */           } 
/*     */         }
/*     */         
/* 367 */         connectionParams.timeout = BlueCoveImpl.getConfigProperty("bluecove.connect.timeout", 120000);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 372 */     OBEXConnectionParams obexConnectionParams = null;
/*     */     
/* 374 */     if (scheme.equals("tcpobex") || scheme.equals("btgoep")) {
/*     */       
/* 376 */       obexConnectionParams = new OBEXConnectionParams();
/* 377 */       obexConnectionParams.timeouts = timeouts;
/* 378 */       obexConnectionParams.timeout = BlueCoveImpl.getConfigProperty("bluecove.obex.timeout", 120000);
/*     */       
/* 380 */       obexConnectionParams.mtu = BlueCoveImpl.getConfigProperty("bluecove.obex.mtu", 1024);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 387 */     if (scheme.equals("btspp")) {
/* 388 */       if (isServer) {
/* 389 */         return new BluetoothRFCommConnectionNotifier(bluetoothStack, notifierParams);
/*     */       }
/* 391 */       return (Connection)new BluetoothRFCommClientConnection(bluetoothStack, connectionParams);
/*     */     } 
/* 393 */     if (scheme.equals("btgoep")) {
/* 394 */       if (isServer) {
/* 395 */         notifierParams.obex = true;
/* 396 */         return (Connection)new OBEXSessionNotifierImpl(new BluetoothRFCommConnectionNotifier(bluetoothStack, notifierParams), obexConnectionParams);
/*     */       } 
/*     */       
/* 399 */       return (Connection)new OBEXClientSessionImpl(new BluetoothRFCommClientConnection(bluetoothStack, connectionParams), obexConnectionParams);
/*     */     } 
/*     */     
/* 402 */     if (scheme.equals("btl2cap")) {
/* 403 */       if (isServer) {
/* 404 */         return new BluetoothL2CAPConnectionNotifier(bluetoothStack, notifierParams, paramL2CAPMTU(values, "receivemtu"), paramL2CAPMTU(values, "transmitmtu"));
/*     */       }
/*     */       
/* 407 */       return (Connection)new BluetoothL2CAPClientConnection(bluetoothStack, connectionParams, paramL2CAPMTU(values, "receivemtu"), paramL2CAPMTU(values, "transmitmtu"));
/*     */     } 
/*     */     
/* 410 */     if (scheme.equals("tcpobex")) {
/* 411 */       if (isServer) {
/*     */         try {
/* 413 */           channel = Integer.parseInt(portORuuid);
/* 414 */         } catch (NumberFormatException e) {
/* 415 */           throw new IllegalArgumentException("port " + portORuuid);
/*     */         } 
/* 417 */         return (Connection)new OBEXSessionNotifierImpl((StreamConnectionNotifier)new ServerSocketConnection(channel), obexConnectionParams);
/*     */       } 
/* 419 */       return (Connection)new OBEXClientSessionImpl((StreamConnection)new SocketConnection(host, channel), obexConnectionParams);
/*     */     } 
/* 421 */     if (scheme.equals("socket")) {
/* 422 */       if (isServer) {
/*     */         try {
/* 424 */           channel = Integer.parseInt(portORuuid);
/* 425 */         } catch (NumberFormatException e) {
/* 426 */           throw new IllegalArgumentException("port " + portORuuid);
/*     */         } 
/* 428 */         return (Connection)new ServerSocketConnection(channel);
/*     */       } 
/* 430 */       return (Connection)new SocketConnection(host, channel);
/*     */     } 
/*     */     
/* 433 */     throw new ConnectionNotFoundException("scheme [" + scheme + "]");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void validateL2CAPPSM(int channel, String channelAsString) throws IllegalArgumentException {
/* 440 */     if (channel < 5 || channel > 65535)
/*     */     {
/* 442 */       throw new IllegalArgumentException("PCM " + channelAsString);
/*     */     }
/* 444 */     if (channel < 4097 && !BlueCoveImpl.getConfigProperty("bluecove.jsr82.psm_minimum_off", false))
/*     */     {
/* 446 */       throw new IllegalArgumentException("PCM " + channelAsString + ", PCM values restricted by JSR-82 to minimum " + 'ခ' + ", see BlueCoveConfigProperties.PROPERTY_JSR_82_PSM_MINIMUM_OFF");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 451 */     if ((channel & 0x100) != 0) {
/* 452 */       throw new IllegalArgumentException("9th bit set in PCM " + channelAsString);
/*     */     }
/*     */     
/* 455 */     byte lsByte = (byte)(0xFF & channel);
/* 456 */     if (lsByte % 2 == 0) {
/* 457 */       throw new IllegalArgumentException("PSM value " + channelAsString + " least significant byte must be odd");
/*     */     }
/* 459 */     byte msByte = (byte)((0xFF00 & channel) >> 8);
/* 460 */     if (msByte % 2 == 1) {
/* 461 */       throw new IllegalArgumentException("PSM value " + channelAsString + " most significant byte must be even");
/*     */     }
/*     */   }
/*     */   
/*     */   private static void validateBluetoothServiceName(String serviceName) {
/* 466 */     if (serviceName.length() == 0) {
/* 467 */       throw new IllegalArgumentException("zero length service name");
/*     */     }
/* 469 */     String allowNameCharactes = " -_";
/* 470 */     for (int i = 0; i < serviceName.length(); ) {
/* 471 */       char c = serviceName.charAt(i);
/* 472 */       if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || " -_".indexOf(c) != -1) {
/*     */         i++;
/*     */         continue;
/*     */       } 
/* 476 */       throw new IllegalArgumentException("Illegal character '" + c + "' in service name");
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean paramBoolean(Hashtable values, String name) {
/* 481 */     String v = (String)values.get(name);
/* 482 */     if (v == null)
/* 483 */       return false; 
/* 484 */     if ("true".equals(v))
/* 485 */       return true; 
/* 486 */     if ("false".equals(v)) {
/* 487 */       return false;
/*     */     }
/* 489 */     throw new IllegalArgumentException("invalid param value " + name + "=" + v);
/*     */   }
/*     */ 
/*     */   
/*     */   private static int paramL2CAPMTU(Hashtable values, String name) {
/* 494 */     String v = (String)values.get(name);
/* 495 */     if (v == null) {
/* 496 */       if (name.equals("transmitmtu"))
/*     */       {
/* 498 */         return -1;
/*     */       }
/* 500 */       return 672;
/*     */     } 
/*     */     
/*     */     try {
/* 504 */       int mtu = Integer.parseInt(v);
/* 505 */       if (mtu >= 48) {
/* 506 */         return mtu;
/*     */       }
/* 508 */       if (mtu > 0 && mtu < 48 && name.equals("transmitmtu")) {
/* 509 */         return 48;
/*     */       }
/* 511 */     } catch (NumberFormatException e) {
/* 512 */       throw new IllegalArgumentException("invalid MTU value " + v);
/*     */     } 
/* 514 */     throw new IllegalArgumentException("invalid MTU param value " + name + "=" + v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Connection open(String name, int mode) throws IOException {
/* 524 */     return openImpl(name, mode, false, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Connection open(String name, int mode, boolean timeouts) throws IOException {
/* 535 */     return openImpl(name, mode, timeouts, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DataInputStream openDataInputStream(String name) throws IOException {
/* 545 */     return new DataInputStream(openInputStream(name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DataOutputStream openDataOutputStream(String name) throws IOException {
/* 555 */     return new DataOutputStream(openOutputStream(name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InputStream openInputStream(String name) throws IOException {
/* 565 */     InputConnection con = (InputConnection)openImpl(name, 1, false, false);
/*     */     try {
/* 567 */       return con.openInputStream();
/*     */     } finally {
/* 569 */       con.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static OutputStream openOutputStream(String name) throws IOException {
/* 580 */     OutputConnection con = (OutputConnection)openImpl(name, 2, false, false);
/*     */     try {
/* 582 */       return con.openOutputStream();
/*     */     } finally {
/* 584 */       con.close();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\MicroeditionConnector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */