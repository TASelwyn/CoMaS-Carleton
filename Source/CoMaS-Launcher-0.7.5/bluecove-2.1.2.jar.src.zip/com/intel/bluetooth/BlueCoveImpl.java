/*      */ package com.intel.bluetooth;
/*      */ 
/*      */ import java.security.AccessControlContext;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Vector;
/*      */ import javax.bluetooth.BluetoothStateException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BlueCoveImpl
/*      */ {
/*      */   public static final String BLUETOOTH_API_VERSION = "1.1.1";
/*      */   public static final String OBEX_API_VERSION = "1.1.1";
/*      */   public static final int versionMajor1 = 2;
/*      */   public static final int versionMajor2 = 1;
/*      */   public static final int versionMinor = 1;
/*      */   public static final int versionBuild = 0;
/*      */   public static final String versionSufix = "-SNAPSHOT";
/*   86 */   public static final String version = String.valueOf(2) + "." + String.valueOf(1) + "." + String.valueOf(1) + "-SNAPSHOT";
/*      */ 
/*      */   
/*      */   public static final int nativeLibraryVersionExpected = 2010100;
/*      */ 
/*      */   
/*      */   public static final String STACK_WINSOCK = "winsock";
/*      */ 
/*      */   
/*      */   public static final String STACK_WIDCOMM = "widcomm";
/*      */ 
/*      */   
/*      */   public static final String STACK_BLUESOLEIL = "bluesoleil";
/*      */ 
/*      */   
/*      */   public static final String STACK_TOSHIBA = "toshiba";
/*      */ 
/*      */   
/*      */   public static final String STACK_BLUEZ = "bluez";
/*      */ 
/*      */   
/*      */   public static final String STACK_BLUEZ_DBUS = "bluez-dbus";
/*      */ 
/*      */   
/*      */   public static final String STACK_OSX = "mac";
/*      */ 
/*      */   
/*      */   public static final String STACK_EMULATOR = "emulator";
/*      */   
/*      */   public static final String STACK_ANDROID_2_X = "android_2.x";
/*      */   
/*      */   private static final boolean oneDLLbuild = false;
/*      */   
/*      */   public static final String NATIVE_LIB_MS = "intelbth";
/*      */   
/*      */   public static final String NATIVE_LIB_WIDCOMM = "bluecove";
/*      */   
/*      */   public static final String NATIVE_LIB_TOSHIBA = "bluecove";
/*      */   
/*      */   public static final String NATIVE_LIB_BLUEZ = "bluecove";
/*      */   
/*      */   public static final String NATIVE_LIB_OSX = "bluecove";
/*      */   
/*      */   public static final String NATIVE_LIB_BLUESOLEIL = "intelbth";
/*      */   
/*      */   static final int BLUECOVE_STACK_DETECT_MICROSOFT = 1;
/*      */   
/*      */   static final int BLUECOVE_STACK_DETECT_WIDCOMM = 2;
/*      */   
/*      */   static final int BLUECOVE_STACK_DETECT_BLUESOLEIL = 4;
/*      */   
/*      */   static final int BLUECOVE_STACK_DETECT_TOSHIBA = 8;
/*      */   
/*      */   static final int BLUECOVE_STACK_DETECT_OSX = 16;
/*      */   
/*      */   public static final int BLUECOVE_STACK_DETECT_BLUEZ = 32;
/*      */   
/*      */   public static final int BLUECOVE_STACK_DETECT_EMULATOR = 64;
/*      */   
/*      */   public static final int BLUECOVE_STACK_DETECT_BLUEZ_DBUS = 128;
/*      */   
/*      */   public static final int BLUECOVE_STACK_DETECT_ANDROID_1_X = 256;
/*      */   
/*      */   public static final int BLUECOVE_STACK_DETECT_ANDROID_2_X = 512;
/*      */   
/*      */   static final String TRUE = "true";
/*      */   
/*      */   static final String FALSE = "false";
/*      */   
/*  155 */   private static final String FQCN = BlueCoveImpl.class.getName();
/*      */   
/*  157 */   private static final Vector fqcnSet = new Vector();
/*      */ 
/*      */   
/*      */   private Object accessControlContext;
/*      */   
/*      */   private static ShutdownHookThread shutdownHookRegistered;
/*      */   
/*      */   private static BlueCoveImpl instance;
/*      */   
/*      */   private static BluetoothStackHolder singleStack;
/*      */   
/*      */   private static ThreadLocalWrapper threadStack;
/*      */   
/*      */   private static BluetoothStackHolder threadStackIDDefault;
/*      */   
/*  172 */   private static Hashtable resourceConfigProperties = new Hashtable();
/*      */   
/*  174 */   private static Hashtable stacks = new Hashtable();
/*      */   
/*  176 */   private static Vector initializationProperties = new Vector();
/*      */   
/*      */   static {
/*  179 */     fqcnSet.addElement(FQCN);
/*  180 */     for (int i = 0; i < BlueCoveConfigProperties.INITIALIZATION_PROPERTIES.length; i++) {
/*  181 */       initializationProperties.addElement(BlueCoveConfigProperties.INITIALIZATION_PROPERTIES[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class BluetoothStackHolder
/*      */   {
/*      */     private BluetoothStack bluetoothStack;
/*      */ 
/*      */     
/*  192 */     Hashtable configProperties = new Hashtable();
/*      */     
/*      */     private static BluetoothStack getBluetoothStack() throws BluetoothStateException {
/*  195 */       return BlueCoveImpl.instance().getBluetoothStack();
/*      */     }
/*      */     
/*      */     public String toString() {
/*  199 */       if (this.bluetoothStack == null) {
/*  200 */         return "not initialized";
/*      */       }
/*  202 */       return this.bluetoothStack.toString();
/*      */     }
/*      */     
/*      */     private BluetoothStackHolder() {}
/*      */   }
/*      */   
/*      */   private class AsynchronousShutdownThread
/*      */     extends Thread
/*      */   {
/*      */     final Object monitor;
/*      */     int shutdownStart;
/*      */     private final BlueCoveImpl this$0;
/*      */     
/*      */     AsynchronousShutdownThread(BlueCoveImpl this$0) {
/*  216 */       super("BluecoveAsynchronousShutdownThread");
/*      */       this.this$0 = this$0;
/*      */       this.monitor = new Object();
/*      */       this.shutdownStart = 0; } public void run() {
/*  220 */       synchronized (this.monitor) {
/*  221 */         while (this.shutdownStart == 0) {
/*      */           try {
/*  223 */             this.monitor.wait();
/*  224 */           } catch (InterruptedException e) {
/*      */             return;
/*      */           } 
/*      */         } 
/*      */       } 
/*  229 */       if (this.shutdownStart == -1) {
/*      */         return;
/*      */       }
/*  232 */       if (!BlueCoveImpl.stacks.isEmpty()) {
/*  233 */         for (Enumeration en = BlueCoveImpl.stacks.elements(); en.hasMoreElements(); ) {
/*  234 */           BlueCoveImpl.BluetoothStackHolder s = en.nextElement();
/*  235 */           if (s.bluetoothStack != null) {
/*      */             try {
/*  237 */               s.bluetoothStack.destroy();
/*      */             } finally {
/*  239 */               s.bluetoothStack = null;
/*      */             } 
/*      */           }
/*      */         } 
/*  243 */         BlueCoveImpl.stacks.clear();
/*  244 */         System.out.println("BlueCove stack shutdown completed");
/*      */       } 
/*  246 */       synchronized (this.monitor) {
/*  247 */         this.monitor.notifyAll();
/*      */       } 
/*      */     }
/*      */     
/*      */     void deRegister() {
/*  252 */       this.shutdownStart = -1;
/*  253 */       synchronized (this.monitor) {
/*  254 */         this.monitor.notifyAll();
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private class ShutdownHookThread extends Thread {
/*      */     BlueCoveImpl.AsynchronousShutdownThread shutdownHookThread;
/*      */     private final BlueCoveImpl this$0;
/*      */     
/*      */     ShutdownHookThread(BlueCoveImpl this$0, BlueCoveImpl.AsynchronousShutdownThread shutdownHookThread) {
/*  264 */       super("BluecoveShutdownHookThread"); this.this$0 = this$0;
/*  265 */       this.shutdownHookThread = shutdownHookThread;
/*      */     }
/*      */     
/*      */     public void run() {
/*  269 */       Object monitor = this.shutdownHookThread.monitor;
/*  270 */       synchronized (monitor) {
/*  271 */         this.shutdownHookThread.shutdownStart = 1;
/*  272 */         monitor.notifyAll();
/*  273 */         if (!BlueCoveImpl.stacks.isEmpty()) {
/*      */           try {
/*  275 */             monitor.wait(7000L);
/*  276 */           } catch (InterruptedException e) {}
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void deRegister() {
/*  283 */       BlueCoveImpl.shutdownHookRegistered = null;
/*  284 */       UtilsJavaSE.runtimeRemoveShutdownHook(this);
/*  285 */       this.shutdownHookThread.deRegister();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized BlueCoveImpl instance() {
/*  296 */     if (instance == null) {
/*  297 */       instance = new BlueCoveImpl();
/*      */     }
/*  299 */     return instance;
/*      */   }
/*      */   
/*      */   private BlueCoveImpl() {
/*      */     try {
/*  304 */       this.accessControlContext = AccessController.getContext();
/*  305 */     } catch (Throwable javaME) {}
/*      */ 
/*      */     
/*  308 */     DebugLog.isDebugEnabled();
/*  309 */     copySystemProperties(null);
/*      */   }
/*      */   
/*      */   static int getNativeLibraryVersion() {
/*  313 */     return 2010100;
/*      */   }
/*      */   
/*      */   private synchronized void createShutdownHook() {
/*  317 */     if (shutdownHookRegistered != null) {
/*      */       return;
/*      */     }
/*  320 */     AsynchronousShutdownThread shutdownHookThread = new AsynchronousShutdownThread(this);
/*  321 */     if (UtilsJavaSE.runtimeAddShutdownHook(shutdownHookRegistered = new ShutdownHookThread(this, shutdownHookThread))) {
/*  322 */       UtilsJavaSE.threadSetDaemon(shutdownHookThread);
/*  323 */       shutdownHookThread.start();
/*      */     } 
/*      */   }
/*      */   
/*      */   private int getStackId(String stack) {
/*  328 */     if ("widcomm".equalsIgnoreCase(stack))
/*  329 */       return 2; 
/*  330 */     if ("bluesoleil".equalsIgnoreCase(stack))
/*  331 */       return 4; 
/*  332 */     if ("toshiba".equalsIgnoreCase(stack))
/*  333 */       return 8; 
/*  334 */     if ("winsock".equalsIgnoreCase(stack))
/*  335 */       return 1; 
/*  336 */     if ("bluez".equalsIgnoreCase(stack))
/*  337 */       return 32; 
/*  338 */     if ("bluez-dbus".equalsIgnoreCase(stack))
/*  339 */       return 128; 
/*  340 */     if ("winsock".equalsIgnoreCase(stack))
/*  341 */       return 16; 
/*  342 */     if ("emulator".equalsIgnoreCase(stack)) {
/*  343 */       return 64;
/*      */     }
/*  345 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   private Class loadStackClass(String classPropertyName, String classNamesDefault) throws BluetoothStateException {
/*  350 */     String classNames = getConfigProperty(classPropertyName);
/*  351 */     if (classNames == null) {
/*  352 */       classNames = classNamesDefault;
/*      */     }
/*  354 */     UtilsStringTokenizer tok = new UtilsStringTokenizer(classNames, "|");
/*  355 */     while (tok.hasMoreTokens()) {
/*  356 */       String className = tok.nextToken();
/*      */       try {
/*  358 */         return Class.forName(className);
/*  359 */       } catch (ClassNotFoundException e) {
/*  360 */         DebugLog.error(className, e);
/*      */       } 
/*      */     } 
/*  363 */     throw new BluetoothStateException("BlueCove " + classNames + " not available");
/*      */   }
/*      */   
/*      */   private BluetoothStack newStackInstance(Class ctackClass) throws BluetoothStateException {
/*  367 */     String className = ctackClass.getName();
/*      */     try {
/*  369 */       return ctackClass.newInstance();
/*  370 */     } catch (InstantiationException e) {
/*  371 */       DebugLog.error(className, e);
/*  372 */     } catch (IllegalAccessException e) {
/*  373 */       DebugLog.error(className, e);
/*      */     } 
/*  375 */     throw new BluetoothStateException("BlueCove " + className + " can't instantiate");
/*      */   }
/*      */   
/*      */   private BluetoothStack loadStack(String classPropertyName, String classNameDefault) throws BluetoothStateException {
/*  379 */     return newStackInstance(loadStackClass(classPropertyName, classNameDefault));
/*      */   }
/*      */ 
/*      */   
/*      */   static void loadNativeLibraries(BluetoothStack stack) throws BluetoothStateException {
/*      */     try {
/*  385 */       if (UtilsJavaSE.canCallNotLoadedNativeMethod && stack.isNativeCodeLoaded()) {
/*      */         return;
/*      */       }
/*  388 */     } catch (Error e) {}
/*      */ 
/*      */     
/*  391 */     BluetoothStack.LibraryInformation[] libs = stack.requireNativeLibraries();
/*  392 */     if (libs == null || libs.length == 0) {
/*      */       return;
/*      */     }
/*      */     
/*  396 */     for (int i = 0; i < libs.length; i++) {
/*  397 */       Class c = (libs[i]).stackClass;
/*  398 */       if (c == null) {
/*  399 */         c = stack.getClass();
/*      */       }
/*  401 */       if (!NativeLibLoader.isAvailable((libs[i]).libraryName, c, (libs[i]).required)) {
/*  402 */         if ((libs[i]).required) {
/*  403 */           throw new BluetoothStateException("BlueCove library " + (libs[i]).libraryName + " not available;" + NativeLibLoader.getLoadErrors((libs[i]).libraryName));
/*      */         }
/*      */         
/*  406 */         DebugLog.debug("library " + (libs[i]).libraryName + " not available");
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean isNativeLibrariesAvailable(BluetoothStack stack) {
/*      */     try {
/*  414 */       if (UtilsJavaSE.canCallNotLoadedNativeMethod) {
/*  415 */         return stack.isNativeCodeLoaded();
/*      */       }
/*  417 */     } catch (Error e) {}
/*      */ 
/*      */     
/*  420 */     BluetoothStack.LibraryInformation[] libs = stack.requireNativeLibraries();
/*  421 */     if (libs == null || libs.length == 0)
/*      */     {
/*  423 */       return true;
/*      */     }
/*  425 */     for (int i = 0; i < libs.length; i++) {
/*  426 */       Class c = (libs[i]).stackClass;
/*  427 */       if (c == null) {
/*  428 */         c = stack.getClass();
/*      */       }
/*  430 */       if (!NativeLibLoader.isAvailable((libs[i]).libraryName, c)) {
/*  431 */         return false;
/*      */       }
/*      */     } 
/*  434 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   private BluetoothStack detectStack() throws BluetoothStateException {
/*  439 */     BluetoothStack detectorStack = null;
/*      */     
/*  441 */     String stackFirstDetector = getConfigProperty("bluecove.stack.first");
/*      */     
/*  443 */     String stackSelected = getConfigProperty("bluecove.stack");
/*      */     
/*  445 */     if (stackFirstDetector == null) {
/*  446 */       stackFirstDetector = stackSelected;
/*      */     }
/*  448 */     if ("emulator".equals(stackSelected)) {
/*  449 */       detectorStack = loadStack("bluecove.emulator.class", "com.intel.bluetooth.BluetoothEmulator");
/*      */     } else {
/*  451 */       Class stackClass; String androidBluetoothStack; switch (NativeLibLoader.getOS()) {
/*      */         case 1:
/*      */         case 5:
/*  454 */           stackClass = loadStackClass("bluecove.bluez.class", "com.intel.bluetooth.BluetoothStackBlueZ|com.intel.bluetooth.BluetoothStackBlueZDBus");
/*      */           
/*  456 */           detectorStack = newStackInstance(stackClass);
/*  457 */           loadNativeLibraries(detectorStack);
/*  458 */           stackSelected = detectorStack.getStackID();
/*      */           break;
/*      */         case 6:
/*  461 */           androidBluetoothStack = "com.intel.bluetooth.BluetoothStackAndroid";
/*      */           try {
/*  463 */             Class androidStackClass = Class.forName(androidBluetoothStack);
/*  464 */             detectorStack = newStackInstance(androidStackClass);
/*  465 */             stackSelected = detectorStack.getStackID();
/*      */           }
/*  467 */           catch (ClassNotFoundException ex) {
/*  468 */             throw new BluetoothStateException("BlueCove " + androidBluetoothStack + " not available");
/*      */           }  break;
/*      */         case 4:
/*  471 */           detectorStack = new BluetoothStackOSX();
/*  472 */           loadNativeLibraries(detectorStack);
/*  473 */           stackSelected = detectorStack.getStackID();
/*      */           break;
/*      */         case 2:
/*      */         case 3:
/*  477 */           detectorStack = createDetectorOnWindows(stackFirstDetector);
/*  478 */           if (DebugLog.isDebugEnabled()) {
/*  479 */             detectorStack.enableNativeDebug(DebugLog.class, true);
/*      */           }
/*      */           break;
/*      */         default:
/*  483 */           throw new BluetoothStateException("BlueCove not available");
/*      */       } 
/*      */     
/*      */     } 
/*  487 */     int libraryVersion = detectorStack.getLibraryVersion();
/*  488 */     if (2010100 != libraryVersion) {
/*  489 */       DebugLog.fatal("BlueCove native library version mismatch " + libraryVersion + " expected " + 2010100);
/*  490 */       throw new BluetoothStateException("BlueCove native library version mismatch");
/*      */     } 
/*      */     
/*  493 */     if (stackSelected == null) {
/*      */       
/*  495 */       int aval = detectorStack.detectBluetoothStack();
/*  496 */       DebugLog.debug("BluetoothStack detected", aval);
/*  497 */       int detectorID = getStackId(detectorStack.getStackID());
/*  498 */       if ((aval & detectorID) != 0) {
/*  499 */         stackSelected = detectorStack.getStackID();
/*  500 */       } else if ((aval & 0x1) != 0) {
/*  501 */         stackSelected = "winsock";
/*  502 */       } else if ((aval & 0x2) != 0) {
/*  503 */         stackSelected = "widcomm";
/*  504 */       } else if ((aval & 0x4) != 0) {
/*  505 */         stackSelected = "bluesoleil";
/*  506 */       } else if ((aval & 0x8) != 0) {
/*  507 */         stackSelected = "toshiba";
/*  508 */       } else if ((aval & 0x10) != 0) {
/*  509 */         stackSelected = "mac";
/*      */       } else {
/*  511 */         DebugLog.fatal("BluetoothStack not detected");
/*  512 */         throw new BluetoothStateException("BluetoothStack not detected");
/*      */       } 
/*      */     } else {
/*  515 */       DebugLog.debug("BluetoothStack selected", stackSelected);
/*      */     } 
/*      */     
/*  518 */     BluetoothStack stack = setBluetoothStack(stackSelected, detectorStack);
/*  519 */     stackSelected = stack.getStackID();
/*  520 */     copySystemProperties(stack);
/*  521 */     if (!stackSelected.equals("emulator")) {
/*  522 */       System.out.println("BlueCove version " + version + " on " + stackSelected);
/*      */     }
/*  524 */     return stack;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Vector getLocalDevicesID() throws BluetoothStateException {
/*  543 */     Vector v = new Vector();
/*  544 */     String ids = BluetoothStackHolder.getBluetoothStack().getLocalDeviceProperty("bluecove.local_devices_ids");
/*  545 */     if (ids != null) {
/*  546 */       UtilsStringTokenizer tok = new UtilsStringTokenizer(ids, ",");
/*  547 */       while (tok.hasMoreTokens()) {
/*  548 */         v.addElement(tok.nextToken());
/*      */       }
/*      */     } 
/*  551 */     return v;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void useThreadLocalBluetoothStack() {
/*  621 */     if (threadStack == null) {
/*  622 */       threadStack = new ThreadLocalWrapper();
/*      */     }
/*  624 */     BluetoothStackHolder s = (BluetoothStackHolder)threadStack.get();
/*  625 */     if (s == null) {
/*      */       
/*  627 */       if (singleStack != null) {
/*  628 */         s = singleStack;
/*  629 */         singleStack = null;
/*      */       } else {
/*  631 */         s = new BluetoothStackHolder();
/*      */       } 
/*  633 */       threadStack.set(s);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized Object getThreadBluetoothStackID() throws BluetoothStateException {
/*  647 */     useThreadLocalBluetoothStack();
/*  648 */     BluetoothStackHolder.getBluetoothStack();
/*  649 */     return threadStack.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized Object getCurrentThreadBluetoothStackID() {
/*  660 */     if (threadStack == null) {
/*  661 */       return null;
/*      */     }
/*  663 */     return threadStack.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void setThreadBluetoothStackID(Object stackID) {
/*  676 */     if (stackID != null && !(stackID instanceof BluetoothStackHolder)) {
/*  677 */       throw new IllegalArgumentException("stackID is not valid");
/*      */     }
/*  679 */     if (threadStack == null) {
/*  680 */       throw new IllegalArgumentException("ThreadLocal configuration is not initialized");
/*      */     }
/*  682 */     threadStack.set(stackID);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void releaseThreadBluetoothStack() {
/*  690 */     if (threadStack == null) {
/*  691 */       throw new IllegalArgumentException("ThreadLocal configuration is not initialized");
/*      */     }
/*  693 */     threadStack.set(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void setDefaultThreadBluetoothStackID(Object stackID) {
/*  706 */     if (stackID != null && !(stackID instanceof BluetoothStackHolder)) {
/*  707 */       throw new IllegalArgumentException("stackID is not valid");
/*      */     }
/*  709 */     if (threadStack == null) {
/*  710 */       throw new IllegalArgumentException("ThreadLocal configuration is not initialized");
/*      */     }
/*  712 */     threadStackIDDefault = (BluetoothStackHolder)stackID;
/*      */   }
/*      */   
/*      */   static synchronized void setThreadBluetoothStack(BluetoothStack bluetoothStack) {
/*  716 */     if (threadStack == null) {
/*      */       return;
/*      */     }
/*  719 */     BluetoothStackHolder s = (BluetoothStackHolder)threadStack.get();
/*  720 */     if (s != null && s.bluetoothStack == bluetoothStack) {
/*      */       return;
/*      */     }
/*      */     
/*  724 */     BluetoothStackHolder sh = (BluetoothStackHolder)stacks.get(bluetoothStack);
/*  725 */     if (sh == null) {
/*  726 */       throw new RuntimeException("ThreadLocal not found for BluetoothStack");
/*      */     }
/*  728 */     threadStack.set(sh);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void shutdownThreadBluetoothStack() {
/*  737 */     if (threadStack == null) {
/*      */       return;
/*      */     }
/*  740 */     BluetoothStackHolder s = (BluetoothStackHolder)threadStack.get();
/*  741 */     if (s == null) {
/*      */       return;
/*      */     }
/*  744 */     if (threadStackIDDefault == s) {
/*  745 */       threadStackIDDefault = null;
/*      */     }
/*  747 */     s.configProperties.clear();
/*  748 */     if (s.bluetoothStack != null) {
/*  749 */       BluetoothConnectionNotifierBase.shutdownConnections(s.bluetoothStack);
/*  750 */       RemoteDeviceHelper.shutdownConnections(s.bluetoothStack);
/*  751 */       s.bluetoothStack.destroy();
/*  752 */       stacks.remove(s.bluetoothStack);
/*  753 */       s.bluetoothStack = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void shutdown() {
/*  761 */     for (Enumeration en = stacks.elements(); en.hasMoreElements(); ) {
/*  762 */       BluetoothStackHolder s = en.nextElement();
/*  763 */       s.configProperties.clear();
/*  764 */       if (s.bluetoothStack != null) {
/*  765 */         BluetoothConnectionNotifierBase.shutdownConnections(s.bluetoothStack);
/*  766 */         RemoteDeviceHelper.shutdownConnections(s.bluetoothStack);
/*      */         try {
/*  768 */           s.bluetoothStack.destroy();
/*      */         } finally {
/*  770 */           s.bluetoothStack = null;
/*      */         } 
/*      */       } 
/*      */     } 
/*  774 */     stacks.clear();
/*  775 */     singleStack = null;
/*  776 */     threadStackIDDefault = null;
/*  777 */     if (shutdownHookRegistered != null) {
/*  778 */       shutdownHookRegistered.deRegister();
/*      */     }
/*  780 */     clearSystemProperties();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setConfigProperty(String name, String value) {
/*  801 */     setConfigObject(name, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setConfigObject(String name, Object value) {
/*  821 */     if (name == null) {
/*  822 */       throw new NullPointerException("key is null");
/*      */     }
/*  824 */     BluetoothStackHolder sh = currentStackHolder(true);
/*  825 */     if (sh.bluetoothStack != null && initializationProperties.contains(name)) {
/*  826 */       throw new IllegalArgumentException("BlueCove Stack already initialized");
/*      */     }
/*  828 */     if (value == null) {
/*  829 */       sh.configProperties.remove(name);
/*      */     } else {
/*  831 */       sh.configProperties.put(name, value);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static Object getConfigObject(String key) {
/*  836 */     if (key == null) {
/*  837 */       throw new NullPointerException("key is null");
/*      */     }
/*  839 */     Object value = null;
/*  840 */     BluetoothStackHolder sh = currentStackHolder(false);
/*  841 */     if (sh != null) {
/*  842 */       value = sh.configProperties.get(key);
/*      */     }
/*  844 */     if (value == null) {
/*      */       try {
/*  846 */         value = System.getProperty(key);
/*  847 */       } catch (SecurityException webstart) {}
/*      */     }
/*      */     
/*  850 */     if (value == null) {
/*  851 */       synchronized (resourceConfigProperties) {
/*  852 */         Object casheValue = resourceConfigProperties.get(key);
/*  853 */         if (casheValue != null) {
/*  854 */           if (casheValue instanceof String) {
/*  855 */             value = casheValue;
/*      */           }
/*      */         } else {
/*  858 */           value = Utils.getResourceProperty(BlueCoveImpl.class, key);
/*  859 */           if (value == null) {
/*  860 */             resourceConfigProperties.put(key, new Object());
/*      */           } else {
/*  862 */             resourceConfigProperties.put(key, value);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*  867 */     return value;
/*      */   }
/*      */   
/*      */   public static String getConfigProperty(String key) {
/*  871 */     return (String)getConfigObject(key);
/*      */   }
/*      */   
/*      */   public static boolean getConfigProperty(String key, boolean defaultValue) {
/*  875 */     String value = getConfigProperty(key);
/*  876 */     if (value != null) {
/*  877 */       return ("true".equals(value) || "1".equals(value));
/*      */     }
/*  879 */     return defaultValue;
/*      */   }
/*      */ 
/*      */   
/*      */   static int getConfigProperty(String key, int defaultValue) {
/*  884 */     String value = getConfigProperty(key);
/*  885 */     if (value != null) {
/*  886 */       return Integer.parseInt(value);
/*      */     }
/*  888 */     return defaultValue;
/*      */   }
/*      */ 
/*      */   
/*      */   static String[] getSystemPropertiesList() {
/*  893 */     String[] p = { "bluetooth.master.switch", "bluetooth.sd.attr.retrievable.max", "bluetooth.connected.devices.max", "bluetooth.l2cap.receiveMTU.max", "bluetooth.sd.trans.max", "bluetooth.connected.inquiry.scan", "bluetooth.connected.page.scan", "bluetooth.connected.inquiry", "bluetooth.connected.page" };
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  898 */     return p;
/*      */   }
/*      */   
/*      */   static void clearSystemProperties() {
/*  902 */     UtilsJavaSE.setSystemProperty("bluetooth.api.version", null);
/*  903 */     UtilsJavaSE.setSystemProperty("obex.api.version", null);
/*  904 */     String[] property = getSystemPropertiesList();
/*  905 */     for (int i = 0; i < property.length; i++) {
/*  906 */       UtilsJavaSE.setSystemProperty(property[i], null);
/*      */     }
/*      */   }
/*      */   
/*      */   void copySystemProperties(BluetoothStack bluetoothStack) {
/*  911 */     UtilsJavaSE.setSystemProperty("bluetooth.api.version", "1.1.1");
/*  912 */     UtilsJavaSE.setSystemProperty("obex.api.version", "1.1.1");
/*  913 */     if (bluetoothStack != null) {
/*  914 */       String[] property = getSystemPropertiesList();
/*  915 */       for (int i = 0; i < property.length; i++) {
/*  916 */         UtilsJavaSE.setSystemProperty(property[i], bluetoothStack.getLocalDeviceProperty(property[i]));
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public String getLocalDeviceFeature(int featureID) throws BluetoothStateException {
/*  922 */     return ((BluetoothStackHolder.getBluetoothStack().getFeatureSet() & featureID) != 0) ? "true" : "false";
/*      */   }
/*      */   
/*      */   private BluetoothStack createDetectorOnWindows(String stackFirst) throws BluetoothStateException {
/*  926 */     if (stackFirst != null) {
/*  927 */       DebugLog.debug("detector stack", stackFirst);
/*      */       
/*  929 */       if ("widcomm".equalsIgnoreCase(stackFirst)) {
/*  930 */         BluetoothStack detectorStack = new BluetoothStackWIDCOMM();
/*  931 */         if (isNativeLibrariesAvailable(detectorStack)) {
/*  932 */           return detectorStack;
/*      */         }
/*  934 */       } else if ("bluesoleil".equalsIgnoreCase(stackFirst)) {
/*  935 */         BluetoothStack detectorStack = new BluetoothStackBlueSoleil();
/*  936 */         if (isNativeLibrariesAvailable(detectorStack)) {
/*  937 */           return detectorStack;
/*      */         }
/*  939 */       } else if ("winsock".equalsIgnoreCase(stackFirst)) {
/*  940 */         BluetoothStack detectorStack = new BluetoothStackMicrosoft();
/*  941 */         if (isNativeLibrariesAvailable(detectorStack)) {
/*  942 */           return detectorStack;
/*      */         }
/*  944 */       } else if ("toshiba".equalsIgnoreCase(stackFirst)) {
/*  945 */         BluetoothStack detectorStack = new BluetoothStackToshiba();
/*  946 */         if (isNativeLibrariesAvailable(detectorStack)) {
/*  947 */           return detectorStack;
/*      */         }
/*      */       } else {
/*  950 */         throw new IllegalArgumentException("Invalid BlueCove detector stack [" + stackFirst + "]");
/*      */       } 
/*      */     } 
/*  953 */     BluetoothStack stack = new BluetoothStackMicrosoft();
/*  954 */     if (isNativeLibrariesAvailable(stack)) {
/*  955 */       return stack;
/*      */     }
/*      */     
/*  958 */     stack = new BluetoothStackWIDCOMM();
/*  959 */     if (isNativeLibrariesAvailable(stack)) {
/*  960 */       return stack;
/*      */     }
/*      */     
/*  963 */     throw new BluetoothStateException("BlueCove libraries not available");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String setBluetoothStack(String stack) throws BluetoothStateException {
/*  974 */     return setBluetoothStack(stack, null).getStackID();
/*      */   }
/*      */   private synchronized BluetoothStack setBluetoothStack(String stack, BluetoothStack detectorStack) throws BluetoothStateException {
/*      */     BluetoothStack newStack;
/*  978 */     if (singleStack != null) {
/*  979 */       if (singleStack.bluetoothStack != null) {
/*  980 */         singleStack.bluetoothStack.destroy();
/*  981 */         stacks.remove(singleStack.bluetoothStack);
/*  982 */         singleStack.bluetoothStack = null;
/*      */       } 
/*  984 */     } else if (threadStack != null) {
/*  985 */       BluetoothStackHolder s = (BluetoothStackHolder)threadStack.get();
/*  986 */       if (s != null && s.bluetoothStack != null) {
/*  987 */         s.bluetoothStack.destroy();
/*  988 */         stacks.remove(s.bluetoothStack);
/*  989 */         s.bluetoothStack = null;
/*      */       } 
/*      */     } 
/*      */     
/*  993 */     if (detectorStack != null && detectorStack.getStackID().equalsIgnoreCase(stack)) {
/*  994 */       newStack = detectorStack;
/*  995 */     } else if ("widcomm".equalsIgnoreCase(stack)) {
/*  996 */       newStack = new BluetoothStackWIDCOMM();
/*  997 */     } else if ("bluesoleil".equalsIgnoreCase(stack)) {
/*  998 */       newStack = new BluetoothStackBlueSoleil();
/*  999 */     } else if ("toshiba".equalsIgnoreCase(stack)) {
/* 1000 */       newStack = new BluetoothStackToshiba();
/*      */     } else {
/* 1002 */       newStack = new BluetoothStackMicrosoft();
/*      */     } 
/* 1004 */     loadNativeLibraries(newStack);
/* 1005 */     int libraryVersion = newStack.getLibraryVersion();
/* 1006 */     if (2010100 != libraryVersion) {
/* 1007 */       DebugLog.fatal("BlueCove native library version mismatch " + libraryVersion + " expected " + 2010100);
/* 1008 */       throw new BluetoothStateException("BlueCove native library version mismatch");
/*      */     } 
/*      */     
/* 1011 */     if (DebugLog.isDebugEnabled()) {
/* 1012 */       newStack.enableNativeDebug(DebugLog.class, true);
/*      */     }
/* 1014 */     newStack.initialize();
/* 1015 */     createShutdownHook();
/*      */ 
/*      */     
/* 1018 */     BluetoothStackHolder sh = currentStackHolder(true);
/* 1019 */     sh.bluetoothStack = newStack;
/* 1020 */     stacks.put(newStack, sh);
/* 1021 */     if (threadStack != null) {
/* 1022 */       threadStack.set(sh);
/*      */     }
/* 1024 */     return newStack;
/*      */   }
/*      */   
/*      */   public void enableNativeDebug(boolean on) {
/* 1028 */     BluetoothStackHolder s = currentStackHolder(false);
/* 1029 */     if (s != null && s.bluetoothStack != null) {
/* 1030 */       s.bluetoothStack.enableNativeDebug(DebugLog.class, on);
/*      */     }
/*      */   }
/*      */   
/*      */   private static BluetoothStackHolder currentStackHolder(boolean create) {
/* 1035 */     if (threadStack != null) {
/* 1036 */       BluetoothStackHolder s = (BluetoothStackHolder)threadStack.get();
/* 1037 */       if (s == null && threadStackIDDefault != null) {
/* 1038 */         return threadStackIDDefault;
/*      */       }
/* 1040 */       if (s == null && create) {
/* 1041 */         s = new BluetoothStackHolder();
/* 1042 */         threadStack.set(s);
/*      */       } 
/* 1044 */       return s;
/*      */     } 
/* 1046 */     if (singleStack == null && create) {
/* 1047 */       singleStack = new BluetoothStackHolder();
/*      */     }
/* 1049 */     return singleStack;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized BluetoothStack getBluetoothStack() throws BluetoothStateException {
/*      */     BluetoothStack stack;
/* 1064 */     Utils.isLegalAPICall(fqcnSet);
/* 1065 */     BluetoothStackHolder sh = currentStackHolder(false);
/* 1066 */     if (sh != null && sh.bluetoothStack != null)
/* 1067 */       return sh.bluetoothStack; 
/* 1068 */     if (sh == null && threadStack != null) {
/* 1069 */       throw new BluetoothStateException("No BluetoothStack or Adapter for current thread");
/*      */     }
/*      */ 
/*      */     
/* 1073 */     if (this.accessControlContext == null) {
/* 1074 */       stack = detectStack();
/*      */     } else {
/* 1076 */       stack = detectStackPrivileged();
/*      */     } 
/* 1078 */     return stack;
/*      */   }
/*      */   
/*      */   private BluetoothStack detectStackPrivileged() throws BluetoothStateException {
/*      */     try {
/* 1083 */       return AccessController.<BluetoothStack>doPrivileged(new PrivilegedExceptionAction(this) { private final BlueCoveImpl this$0;
/*      */             public Object run() throws BluetoothStateException {
/* 1085 */               return this.this$0.detectStack();
/*      */             }
/*      */           },  (AccessControlContext)this.accessControlContext);
/* 1088 */     } catch (PrivilegedActionException e) {
/* 1089 */       Throwable cause = UtilsJavaSE.getCause(e);
/* 1090 */       if (cause instanceof BluetoothStateException) {
/* 1091 */         throw (BluetoothStateException)cause;
/*      */       }
/* 1093 */       throw (BluetoothStateException)UtilsJavaSE.initCause(new BluetoothStateException(e.getMessage()), cause);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BlueCoveImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */