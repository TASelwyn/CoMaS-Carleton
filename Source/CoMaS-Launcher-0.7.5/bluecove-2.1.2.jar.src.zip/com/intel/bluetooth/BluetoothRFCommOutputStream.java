/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BluetoothRFCommOutputStream
/*     */   extends OutputStream
/*     */ {
/*     */   private volatile BluetoothRFCommConnection conn;
/*     */   
/*     */   public BluetoothRFCommOutputStream(BluetoothRFCommConnection conn) {
/*  34 */     this.conn = conn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int b) throws IOException {
/*  50 */     if (this.conn == null) {
/*  51 */       throw new IOException("Stream closed");
/*     */     }
/*  53 */     this.conn.bluetoothStack.connectionRfWrite(this.conn.handle, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/*  77 */     if (off < 0 || len < 0 || off + len > b.length) {
/*  78 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */     
/*  81 */     if (this.conn == null) {
/*  82 */       throw new IOException("Stream closed");
/*     */     }
/*  84 */     this.conn.bluetoothStack.connectionRfWrite(this.conn.handle, b, off, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/*  89 */     if (this.conn == null) {
/*  90 */       throw new IOException("Stream closed");
/*     */     }
/*  92 */     super.flush();
/*  93 */     this.conn.bluetoothStack.connectionRfFlush(this.conn.handle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 109 */     BluetoothRFCommConnection c = this.conn;
/* 110 */     if (c != null) {
/* 111 */       this.conn = null;
/* 112 */       c.streamClosed();
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean isClosed() {
/* 117 */     return (this.conn == null);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothRFCommOutputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */