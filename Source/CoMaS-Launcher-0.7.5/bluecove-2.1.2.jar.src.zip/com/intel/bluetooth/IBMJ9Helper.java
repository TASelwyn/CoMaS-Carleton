/*    */ package com.intel.bluetooth;
/*    */ 
/*    */ import com.ibm.oti.vm.VM;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IBMJ9Helper
/*    */ {
/*    */   static synchronized void loadLibrary(String libname) throws IOException {
/* 41 */     VM.loadLibrary(libname);
/*    */   }
/*    */   
/*    */   static void addShutdownClass(Runnable hook) {
/* 45 */     VM.addShutdownClass(hook);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\IBMJ9Helper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */