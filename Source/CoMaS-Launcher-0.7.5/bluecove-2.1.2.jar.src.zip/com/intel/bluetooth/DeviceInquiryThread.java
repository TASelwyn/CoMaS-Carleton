/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import javax.bluetooth.BluetoothStateException;
/*     */ import javax.bluetooth.DiscoveryListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DeviceInquiryThread
/*     */   extends Thread
/*     */ {
/*     */   private BluetoothStack stack;
/*     */   private DeviceInquiryRunnable inquiryRunnable;
/*     */   private int accessCode;
/*     */   private DiscoveryListener listener;
/*     */   private BluetoothStateException startException;
/*     */   private boolean started = false;
/*     */   private boolean terminated = false;
/*  52 */   private Object inquiryStartedEvent = new Object();
/*     */   
/*     */   private static int threadNumber;
/*     */   
/*     */   private static synchronized int nextThreadNum() {
/*  57 */     return threadNumber++;
/*     */   }
/*     */ 
/*     */   
/*     */   private DeviceInquiryThread(BluetoothStack stack, DeviceInquiryRunnable inquiryRunnable, int accessCode, DiscoveryListener listener) {
/*  62 */     super("DeviceInquiryThread-" + nextThreadNum());
/*  63 */     this.stack = stack;
/*  64 */     this.inquiryRunnable = inquiryRunnable;
/*  65 */     this.accessCode = accessCode;
/*  66 */     this.listener = listener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean startInquiry(BluetoothStack stack, DeviceInquiryRunnable inquiryRunnable, int accessCode, DiscoveryListener listener) throws BluetoothStateException {
/*  74 */     DeviceInquiryThread t = new DeviceInquiryThread(stack, inquiryRunnable, accessCode, listener);
/*     */     
/*  76 */     UtilsJavaSE.threadSetDaemon(t);
/*  77 */     synchronized (t.inquiryStartedEvent) {
/*  78 */       t.start();
/*  79 */       while (!t.started && !t.terminated) {
/*     */         try {
/*  81 */           t.inquiryStartedEvent.wait();
/*  82 */         } catch (InterruptedException e) {
/*  83 */           return false;
/*     */         } 
/*  85 */         if (t.startException != null) {
/*  86 */           throw t.startException;
/*     */         }
/*     */       } 
/*     */     } 
/*  90 */     DebugLog.debug("startInquiry return", t.started);
/*  91 */     return t.started;
/*     */   }
/*     */   
/*     */   public static int getConfigDeviceInquiryDuration() {
/*  95 */     return BlueCoveImpl.getConfigProperty("bluecove.inquiry.duration", 11);
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/* 100 */     int discType = 7;
/*     */     try {
/* 102 */       BlueCoveImpl.setThreadBluetoothStack(this.stack);
/* 103 */       discType = this.inquiryRunnable.runDeviceInquiry(this, this.accessCode, this.listener);
/* 104 */     } catch (BluetoothStateException e) {
/* 105 */       DebugLog.debug("runDeviceInquiry throw", (Throwable)e);
/* 106 */       this.startException = e;
/* 107 */     } catch (Throwable e) {
/* 108 */       DebugLog.error("runDeviceInquiry", e);
/*     */     } finally {
/*     */       
/* 111 */       this.terminated = true;
/* 112 */       synchronized (this.inquiryStartedEvent) {
/* 113 */         this.inquiryStartedEvent.notifyAll();
/*     */       } 
/* 115 */       DebugLog.debug("runDeviceInquiry ends");
/* 116 */       if (this.started) {
/* 117 */         Utils.j2meUsagePatternDellay();
/* 118 */         this.listener.inquiryCompleted(discType);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void deviceInquiryStartedCallback() {
/* 124 */     DebugLog.debug("deviceInquiryStartedCallback");
/* 125 */     this.started = true;
/* 126 */     synchronized (this.inquiryStartedEvent) {
/* 127 */       this.inquiryStartedEvent.notifyAll();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\DeviceInquiryThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */