/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.bluetooth.BluetoothConnectionException;
/*     */ import javax.bluetooth.BluetoothStateException;
/*     */ import javax.bluetooth.DataElement;
/*     */ import javax.bluetooth.DeviceClass;
/*     */ import javax.bluetooth.DiscoveryListener;
/*     */ import javax.bluetooth.RemoteDevice;
/*     */ import javax.bluetooth.ServiceRecord;
/*     */ import javax.bluetooth.ServiceRegistrationException;
/*     */ import javax.bluetooth.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BluetoothStackMicrosoft
/*     */   implements BluetoothStack
/*     */ {
/*     */   private static final int BTH_MODE_POWER_OFF = 1;
/*     */   private static final int BTH_MODE_CONNECTABLE = 2;
/*     */   private static final int BTH_MODE_DISCOVERABLE = 3;
/*  52 */   private static BluetoothStackMicrosoft singleInstance = null;
/*     */   
/*     */   private boolean peerInitialized = false;
/*     */   
/*     */   private boolean windowsCE;
/*     */   
/*  58 */   private long localBluetoothAddress = 0L;
/*     */   
/*     */   private DiscoveryListener currentDeviceDiscoveryListener;
/*     */   
/*     */   private Thread limitedDiscoverableTimer;
/*     */   
/*     */   private static final int ATTR_RETRIEVABLE_MAX = 256;
/*     */   
/*     */   private Hashtable deviceDiscoveryDevices;
/*     */   
/*     */   private static int connectThreadNumber;
/*     */ 
/*     */   
/*     */   private static synchronized int nextConnectThreadNum() {
/*  72 */     return connectThreadNumber++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStackID() {
/*  81 */     return "winsock";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BluetoothStack.LibraryInformation[] requireNativeLibraries() {
/*  97 */     return BluetoothStack.LibraryInformation.library("intelbth");
/*     */   }
/*     */   
/*     */   public String toString() {
/* 101 */     return getStackID();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize() throws BluetoothStateException {
/* 117 */     if (singleInstance != null) {
/* 118 */       throw new BluetoothStateException("Only one instance of " + getStackID() + " stack supported");
/*     */     }
/*     */     try {
/* 121 */       int status = initializationStatus();
/* 122 */       DebugLog.debug("initializationStatus", status);
/* 123 */       if (status == 1) {
/* 124 */         this.peerInitialized = true;
/*     */       }
/* 126 */       this.windowsCE = isWindowsCE();
/* 127 */       singleInstance = this;
/* 128 */     } catch (BluetoothStateException e) {
/* 129 */       throw e;
/* 130 */     } catch (IOException e) {
/* 131 */       DebugLog.fatal("initialization", e);
/* 132 */       throw new BluetoothStateException(e.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void destroy() {
/* 137 */     if (singleInstance != this) {
/* 138 */       throw new RuntimeException("Destroy invalid instance");
/*     */     }
/* 140 */     if (this.peerInitialized) {
/* 141 */       this.peerInitialized = false;
/* 142 */       uninitialize();
/*     */     } 
/* 144 */     cancelLimitedDiscoverableTimer();
/* 145 */     singleInstance = null;
/*     */   }
/*     */   
/*     */   private void initialized() throws BluetoothStateException {
/* 149 */     if (!this.peerInitialized) {
/* 150 */       throw new BluetoothStateException("Bluetooth system is unavailable");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFeatureSet() {
/* 160 */     return 0x2 | (this.windowsCE ? 0 : 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocalDeviceBluetoothAddress() {
/*     */     try {
/* 179 */       long socket = socket(false, false);
/* 180 */       bind(socket);
/* 181 */       this.localBluetoothAddress = getsockaddress(socket);
/* 182 */       String address = RemoteDeviceHelper.getBluetoothAddress(this.localBluetoothAddress);
/* 183 */       storesockopt(socket);
/* 184 */       close(socket);
/* 185 */       return address;
/* 186 */     } catch (IOException e) {
/* 187 */       DebugLog.error("get local bluetoothAddress", e);
/* 188 */       return "000000000000";
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getLocalDeviceName() {
/* 193 */     if (this.localBluetoothAddress == 0L) {
/* 194 */       getLocalDeviceBluetoothAddress();
/*     */     }
/* 196 */     return getradioname(this.localBluetoothAddress);
/*     */   }
/*     */   
/*     */   public String getRemoteDeviceFriendlyName(long address) throws IOException {
/* 200 */     return getpeername(address);
/*     */   }
/*     */   
/*     */   public DeviceClass getLocalDeviceClass() {
/* 204 */     return new DeviceClass(getDeviceClass(this.localBluetoothAddress));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocalDeviceServiceClasses(int classOfDevice) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void cancelLimitedDiscoverableTimer() {
/* 217 */     if (this.limitedDiscoverableTimer != null) {
/* 218 */       this.limitedDiscoverableTimer.interrupt();
/* 219 */       this.limitedDiscoverableTimer = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean setLocalDeviceDiscoverable(int mode) throws BluetoothStateException {
/* 224 */     switch (mode) {
/*     */       case 0:
/* 226 */         cancelLimitedDiscoverableTimer();
/* 227 */         DebugLog.debug("setDiscoverable(false)");
/* 228 */         setDiscoverable(false);
/* 229 */         return (0 == getLocalDeviceDiscoverable());
/*     */       case 10390323:
/* 231 */         cancelLimitedDiscoverableTimer();
/* 232 */         DebugLog.debug("setDiscoverable(true)");
/* 233 */         setDiscoverable(true);
/* 234 */         return (10390323 == getLocalDeviceDiscoverable());
/*     */       case 10390272:
/* 236 */         cancelLimitedDiscoverableTimer();
/* 237 */         DebugLog.debug("setDiscoverable(LIAC)");
/* 238 */         setDiscoverable(true);
/* 239 */         if (10390323 != getLocalDeviceDiscoverable()) {
/* 240 */           return false;
/*     */         }
/*     */         
/* 243 */         this.limitedDiscoverableTimer = Utils.schedule(60000L, new Runnable(this) { private final BluetoothStackMicrosoft this$0;
/*     */               public void run() {
/*     */                 try {
/* 246 */                   this.this$0.setDiscoverable(false);
/* 247 */                 } catch (BluetoothStateException e) {
/* 248 */                   DebugLog.debug("error setDiscoverable", (Throwable)e);
/*     */                 } finally {
/* 250 */                   this.this$0.limitedDiscoverableTimer = null;
/*     */                 } 
/*     */               } }
/*     */           );
/* 254 */         return true;
/*     */     } 
/* 256 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isLocalDevicePowerOn() {
/* 260 */     int mode = getBluetoothRadioMode();
/* 261 */     if (mode == 1) {
/* 262 */       return false;
/*     */     }
/* 264 */     return (mode == 2 || mode == 3);
/*     */   }
/*     */   
/*     */   public int getLocalDeviceDiscoverable() {
/* 268 */     int mode = getBluetoothRadioMode();
/* 269 */     if (mode == 3) {
/* 270 */       if (this.limitedDiscoverableTimer != null) {
/* 271 */         DebugLog.debug("Discoverable = LIAC");
/* 272 */         return 10390272;
/*     */       } 
/* 274 */       DebugLog.debug("Discoverable = GIAC");
/* 275 */       return 10390323;
/*     */     } 
/*     */     
/* 278 */     DebugLog.debug("Discoverable = NOT_DISCOVERABLE");
/* 279 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLocalDeviceProperty(String property) {
/* 284 */     if ("bluetooth.connected.devices.max".equals(property)) {
/* 285 */       return "7";
/*     */     }
/* 287 */     if ("bluetooth.sd.trans.max".equals(property)) {
/* 288 */       return "7";
/*     */     }
/* 290 */     if ("bluetooth.connected.inquiry.scan".equals(property)) {
/* 291 */       return "true";
/*     */     }
/* 293 */     if ("bluetooth.connected.page.scan".equals(property)) {
/* 294 */       return "true";
/*     */     }
/* 296 */     if ("bluetooth.connected.inquiry".equals(property)) {
/* 297 */       return "true";
/*     */     }
/* 299 */     if ("bluetooth.connected.page".equals(property)) {
/* 300 */       return "true";
/*     */     }
/*     */     
/* 303 */     if ("bluetooth.sd.attr.retrievable.max".equals(property)) {
/* 304 */       return String.valueOf(256);
/*     */     }
/* 306 */     if ("bluetooth.master.switch".equals(property)) {
/* 307 */       return "false";
/*     */     }
/* 309 */     if ("bluetooth.l2cap.receiveMTU.max".equals(property)) {
/* 310 */       return "0";
/*     */     }
/*     */     
/* 313 */     if ("bluecove.radio.version".equals(property)) {
/* 314 */       return String.valueOf(getDeviceVersion(this.localBluetoothAddress));
/*     */     }
/* 316 */     if ("bluecove.radio.manufacturer".equals(property)) {
/* 317 */       return String.valueOf(getDeviceManufacturer(this.localBluetoothAddress));
/*     */     }
/* 319 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCurrentThreadInterruptedCallback() {
/* 328 */     return UtilsJavaSE.isCurrentThreadInterrupted();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RemoteDevice[] retrieveDevices(int option) {
/* 334 */     if (this.windowsCE) {
/* 335 */       return null;
/*     */     }
/* 337 */     Vector devices = new Vector();
/* 338 */     RetrieveDevicesCallback retrieveDevicesCallback = new RetrieveDevicesCallback(this, devices) { private final Vector val$devices;
/*     */         public void deviceFoundCallback(long deviceAddr, int deviceClass, String deviceName, boolean paired) {
/* 340 */           DebugLog.debug("device found", deviceAddr);
/* 341 */           RemoteDevice remoteDevice = RemoteDeviceHelper.createRemoteDevice(this.this$0, deviceAddr, deviceName, paired);
/*     */           
/* 343 */           this.val$devices.add(remoteDevice);
/*     */         } private final BluetoothStackMicrosoft this$0; }
/*     */       ;
/* 346 */     if (retrieveDevicesImpl(option, retrieveDevicesCallback)) {
/* 347 */       return RemoteDeviceHelper.remoteDeviceListToArray(devices);
/*     */     }
/* 349 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean isRemoteDeviceTrusted(long address) {
/* 356 */     if (this.windowsCE) {
/* 357 */       return null;
/*     */     }
/* 359 */     return new Boolean(isRemoteDeviceTrustedImpl(address));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean isRemoteDeviceAuthenticated(long address) {
/* 365 */     if (this.windowsCE) {
/* 366 */       return null;
/*     */     }
/* 368 */     return new Boolean(isRemoteDeviceAuthenticatedImpl(address));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean authenticateRemoteDevice(long address) throws IOException {
/* 374 */     return authenticateRemoteDeviceImpl(address, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean authenticateRemoteDevice(long address, String passkey) throws IOException {
/* 383 */     return authenticateRemoteDeviceImpl(address, passkey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAuthenticationWithRemoteDevice(long address) throws IOException {
/* 394 */     removeAuthenticationWithRemoteDeviceImpl(address);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean startInquiry(int accessCode, DiscoveryListener listener) throws BluetoothStateException {
/* 406 */     initialized();
/* 407 */     if (this.currentDeviceDiscoveryListener != null) {
/* 408 */       throw new BluetoothStateException("Another inquiry already running");
/*     */     }
/* 410 */     this.currentDeviceDiscoveryListener = listener;
/*     */     
/* 412 */     DeviceInquiryRunnable inquiryRunnable = new DeviceInquiryRunnable(this) { private final BluetoothStackMicrosoft this$0;
/*     */         
/*     */         public int runDeviceInquiry(DeviceInquiryThread inquiryThread, int accessCode, DiscoveryListener listener) throws BluetoothStateException {
/*     */           try {
/* 416 */             this.this$0.deviceDiscoveryDevices = new Hashtable();
/* 417 */             int discType = this.this$0.runDeviceInquiryImpl(this, inquiryThread, accessCode, DeviceInquiryThread.getConfigDeviceInquiryDuration(), listener);
/*     */             
/* 419 */             if (discType == 0) {
/* 420 */               for (Enumeration en = this.this$0.deviceDiscoveryDevices.keys(); en.hasMoreElements(); ) {
/* 421 */                 RemoteDevice remoteDevice = en.nextElement();
/* 422 */                 DeviceClass deviceClass = (DeviceClass)this.this$0.deviceDiscoveryDevices.get(remoteDevice);
/* 423 */                 listener.deviceDiscovered(remoteDevice, deviceClass);
/*     */                 
/* 425 */                 if (this.this$0.currentDeviceDiscoveryListener == null) {
/* 426 */                   return 5;
/*     */                 }
/*     */               } 
/*     */             }
/* 430 */             return discType;
/*     */           } finally {
/* 432 */             this.this$0.deviceDiscoveryDevices = null;
/* 433 */             this.this$0.currentDeviceDiscoveryListener = null;
/*     */           } 
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void deviceDiscoveredCallback(DiscoveryListener listener, long deviceAddr, int deviceClass, String deviceName, boolean paired) {
/* 442 */           RemoteDevice remoteDevice = RemoteDeviceHelper.createRemoteDevice(this.this$0, deviceAddr, deviceName, paired);
/* 443 */           if (this.this$0.currentDeviceDiscoveryListener == null || this.this$0.deviceDiscoveryDevices == null || this.this$0.currentDeviceDiscoveryListener != listener) {
/*     */             return;
/*     */           }
/*     */           
/* 447 */           DeviceClass cod = new DeviceClass(deviceClass);
/* 448 */           DebugLog.debug("deviceDiscoveredCallback address", remoteDevice.getBluetoothAddress());
/* 449 */           DebugLog.debug("deviceDiscoveredCallback deviceClass", cod);
/* 450 */           this.this$0.deviceDiscoveryDevices.put(remoteDevice, cod);
/*     */         } }
/*     */       ;
/*     */     
/* 454 */     return DeviceInquiryThread.startInquiry(this, inquiryRunnable, accessCode, listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean cancelInquiry(DiscoveryListener listener) {
/* 463 */     if (this.currentDeviceDiscoveryListener != listener) {
/* 464 */       return false;
/*     */     }
/*     */     
/* 467 */     this.currentDeviceDiscoveryListener = null;
/* 468 */     return cancelInquiry();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int searchServices(int[] attrSet, UUID[] uuidSet, RemoteDevice device, DiscoveryListener listener) throws BluetoothStateException {
/* 486 */     SearchServicesRunnable searchRunnable = new SearchServicesRunnable(this) { private final BluetoothStackMicrosoft this$0;
/*     */         
/*     */         public int runSearchServices(SearchServicesThread sst, int[] attrSet, UUID[] uuidSet, RemoteDevice device, DiscoveryListener listener) throws BluetoothStateException {
/*     */           int[] handles;
/* 490 */           sst.searchServicesStartedCallback();
/*     */           
/*     */           try {
/* 493 */             handles = this.this$0.runSearchServicesImpl(uuidSet, RemoteDeviceHelper.getAddress(device));
/* 494 */           } catch (SearchServicesDeviceNotReachableException e) {
/* 495 */             return 6;
/* 496 */           } catch (SearchServicesTerminatedException e) {
/* 497 */             return 2;
/* 498 */           } catch (SearchServicesException e) {
/* 499 */             return 3;
/*     */           } 
/* 501 */           if (handles == null)
/* 502 */             return 3; 
/* 503 */           if (handles.length > 0) {
/* 504 */             ServiceRecordImpl[] arrayOfServiceRecordImpl = new ServiceRecordImpl[handles.length];
/* 505 */             int[] requiredAttrIDs = { 0, 1, 2, 3, 4 };
/*     */ 
/*     */             
/* 508 */             boolean hasError = false;
/* 509 */             for (int i = 0; i < handles.length; i++) {
/* 510 */               arrayOfServiceRecordImpl[i] = new ServiceRecordImpl(this.this$0, device, handles[i]);
/*     */               try {
/* 512 */                 arrayOfServiceRecordImpl[i].populateRecord(requiredAttrIDs);
/* 513 */                 if (attrSet != null) {
/* 514 */                   arrayOfServiceRecordImpl[i].populateRecord(attrSet);
/*     */                 }
/* 516 */               } catch (Exception e) {
/* 517 */                 DebugLog.debug("populateRecord error", e);
/* 518 */                 hasError = true;
/*     */               } 
/* 520 */               if (sst.isTerminated()) {
/* 521 */                 return 2;
/*     */               }
/*     */             } 
/* 524 */             listener.servicesDiscovered(sst.getTransID(), (ServiceRecord[])arrayOfServiceRecordImpl);
/* 525 */             if (hasError) {
/* 526 */               return 3;
/*     */             }
/* 528 */             return 1;
/*     */           } 
/*     */           
/* 531 */           return 4;
/*     */         } }
/*     */       ;
/*     */ 
/*     */     
/* 536 */     return SearchServicesThread.startSearchServices(this, searchRunnable, attrSet, uuidSet, device, listener);
/*     */   }
/*     */   
/*     */   public boolean cancelServiceSearch(int transID) {
/* 540 */     SearchServicesThread sst = SearchServicesThread.getServiceSearchThread(transID);
/* 541 */     if (sst != null) {
/* 542 */       return sst.setTerminated();
/*     */     }
/* 544 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean populateServicesRecordAttributeValues(ServiceRecordImpl serviceRecord, int[] attrIDs) throws IOException {
/* 550 */     if (attrIDs.length > 256) {
/* 551 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 556 */     byte[] blob = getServiceAttributes(attrIDs, RemoteDeviceHelper.getAddress(serviceRecord.getHostDevice()), (int)serviceRecord.getHandle());
/*     */ 
/*     */     
/* 559 */     if (blob.length > 0) {
/*     */       try {
/* 561 */         boolean anyRetrived = false;
/* 562 */         DataElement element = (new SDPInputStream(new ByteArrayInputStream(blob))).readElement();
/* 563 */         for (Enumeration e = (Enumeration)element.getValue(); e.hasMoreElements(); ) {
/* 564 */           int attrID = (int)((DataElement)e.nextElement()).getLong();
/* 565 */           serviceRecord.populateAttributeValue(attrID, e.nextElement());
/* 566 */           if (!anyRetrived) {
/* 567 */             for (int i = 0; i < attrIDs.length; i++) {
/* 568 */               if (attrIDs[i] == attrID) {
/* 569 */                 anyRetrived = true;
/*     */                 break;
/*     */               } 
/*     */             } 
/*     */           }
/*     */         } 
/* 575 */         return anyRetrived;
/* 576 */       } catch (IOException e) {
/* 577 */         throw e;
/* 578 */       } catch (Throwable e) {
/* 579 */         throw new IOException();
/*     */       } 
/*     */     }
/* 582 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ConnectThread
/*     */     extends Thread
/*     */   {
/*     */     final Object event;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final long socket;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final BluetoothConnectionParams params;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final int retryUnreachable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     volatile IOException error;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     volatile boolean success;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     volatile boolean connecting;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final BluetoothStackMicrosoft this$0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ConnectThread(BluetoothStackMicrosoft this$0, Object event, long socket, BluetoothConnectionParams params) {
/* 640 */       super("ConnectThread-" + BluetoothStackMicrosoft.nextConnectThreadNum()); this.this$0 = this$0; this.success = false; this.connecting = true;
/* 641 */       this.event = event;
/* 642 */       this.socket = socket;
/* 643 */       this.params = params;
/* 644 */       this.retryUnreachable = BlueCoveImpl.getConfigProperty("bluecove.connect.unreachable_retry", 2);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/*     */       try {
/* 651 */         this.this$0.connect(this.socket, this.params.address, this.params.channel, this.retryUnreachable);
/* 652 */         this.success = true;
/* 653 */       } catch (IOException e) {
/* 654 */         this.error = e;
/*     */       } finally {
/* 656 */         this.connecting = false;
/* 657 */         synchronized (this.event) {
/* 658 */           this.event.notifyAll();
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long connectionRfOpenClientConnection(BluetoothConnectionParams params) throws IOException {
/* 671 */     long socket = socket(params.authenticate, params.encrypt);
/*     */ 
/*     */     
/* 674 */     Object event = new Object();
/* 675 */     ConnectThread connectThread = new ConnectThread(this, event, socket, params);
/* 676 */     UtilsJavaSE.threadSetDaemon(connectThread);
/*     */     
/* 678 */     boolean timeoutHappend = false;
/*     */     
/* 680 */     synchronized (event) {
/* 681 */       connectThread.start();
/* 682 */       while (connectThread.connecting) {
/*     */         try {
/* 684 */           if (params.timeouts) {
/* 685 */             event.wait(params.timeout);
/* 686 */             timeoutHappend = connectThread.connecting;
/* 687 */             connectThread.interrupt();
/*     */             break;
/*     */           } 
/* 690 */           event.wait();
/*     */         }
/* 692 */         catch (InterruptedException e) {
/*     */           try {
/* 694 */             close(socket);
/* 695 */           } catch (Exception ignore) {}
/*     */           
/* 697 */           throw new InterruptedIOException();
/*     */         } 
/*     */       } 
/*     */     } 
/* 701 */     if (!connectThread.success) {
/*     */       try {
/* 703 */         close(socket);
/* 704 */       } catch (Exception ignore) {}
/*     */     }
/*     */     
/* 707 */     if (connectThread.error != null) {
/* 708 */       throw connectThread.error;
/*     */     }
/*     */     
/* 711 */     if (!connectThread.success) {
/* 712 */       if (timeoutHappend) {
/* 713 */         throw new BluetoothConnectionException(5);
/*     */       }
/* 715 */       throw new BluetoothConnectionException(4);
/*     */     } 
/*     */     
/* 718 */     return socket;
/*     */   }
/*     */   
/*     */   public void connectionRfCloseClientConnection(long handle) throws IOException {
/* 722 */     close(handle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long rfServerOpen(BluetoothConnectionNotifierParams params, ServiceRecordImpl serviceRecord) throws IOException {
/* 730 */     long socket = socket(params.authenticate, params.encrypt);
/* 731 */     boolean success = false;
/*     */     
/*     */     try {
/* 734 */       synchronized (this) {
/* 735 */         bind(socket);
/*     */       } 
/* 737 */       listen(socket);
/*     */       
/* 739 */       int channel = getsockchannel(socket);
/* 740 */       DebugLog.debug("service channel ", channel);
/*     */       
/* 742 */       long serviceRecordHandle = socket;
/* 743 */       serviceRecord.populateRFCOMMAttributes(serviceRecordHandle, channel, params.uuid, params.name, params.obex);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 748 */       serviceRecord.setHandle(registerService(serviceRecord.toByteArray(), serviceRecord.deviceServiceClasses));
/*     */       
/* 750 */       success = true;
/*     */     } finally {
/* 752 */       if (!success) {
/*     */         try {
/* 754 */           close(socket);
/* 755 */         } catch (IOException e) {
/* 756 */           DebugLog.debug("close on failure", e);
/*     */         } 
/*     */       }
/*     */     } 
/* 760 */     return socket;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rfServerClose(long handle, ServiceRecordImpl serviceRecord) throws IOException {
/*     */     try {
/* 768 */       close(handle);
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/* 773 */       unregisterService(serviceRecord.getHandle());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long rfServerAcceptAndOpenRfServerConnection(long handle) throws IOException {
/* 788 */     return accept(handle);
/*     */   }
/*     */   
/*     */   public void rfServerUpdateServiceRecord(long handle, ServiceRecordImpl serviceRecord, boolean acceptAndOpen) throws ServiceRegistrationException {
/*     */     byte[] blob;
/* 793 */     unregisterService(serviceRecord.getHandle());
/*     */     
/*     */     try {
/* 796 */       blob = serviceRecord.toByteArray();
/* 797 */     } catch (IOException e) {
/* 798 */       throw new ServiceRegistrationException(e.toString());
/*     */     } 
/* 800 */     serviceRecord.setHandle(registerService(blob, serviceRecord.deviceServiceClasses));
/* 801 */     DebugLog.debug("new serviceRecord", serviceRecord);
/*     */   }
/*     */   
/*     */   public void connectionRfCloseServerConnection(long handle) throws IOException {
/* 805 */     connectionRfCloseClientConnection(handle);
/*     */   }
/*     */   
/*     */   public long getConnectionRfRemoteAddress(long handle) throws IOException {
/* 809 */     return getpeeraddress(handle);
/*     */   }
/*     */   
/*     */   public int connectionRfRead(long handle) throws IOException {
/* 813 */     return recv(handle);
/*     */   }
/*     */   
/*     */   public int connectionRfRead(long handle, byte[] b, int off, int len) throws IOException {
/* 817 */     return recv(handle, b, off, len);
/*     */   }
/*     */   
/*     */   public int connectionRfReadAvailable(long handle) throws IOException {
/* 821 */     return recvAvailable(handle);
/*     */   }
/*     */   
/*     */   public void connectionRfWrite(long handle, int b) throws IOException {
/* 825 */     send(handle, b);
/*     */   }
/*     */   
/*     */   public void connectionRfWrite(long handle, byte[] b, int off, int len) throws IOException {
/* 829 */     send(handle, b, off, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public void connectionRfFlush(long handle) throws IOException {}
/*     */ 
/*     */   
/*     */   public int rfGetSecurityOpt(long handle, int expected) throws IOException {
/* 837 */     return expected;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean rfEncrypt(long address, long handle, boolean on) throws IOException {
/* 846 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long l2OpenClientConnection(BluetoothConnectionParams params, int receiveMTU, int transmitMTU) throws IOException {
/* 859 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void l2CloseClientConnection(long handle) throws IOException {
/* 868 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long l2ServerOpen(BluetoothConnectionNotifierParams params, int receiveMTU, int transmitMTU, ServiceRecordImpl serviceRecord) throws IOException {
/* 879 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void l2ServerUpdateServiceRecord(long handle, ServiceRecordImpl serviceRecord, boolean acceptAndOpen) throws ServiceRegistrationException {
/* 890 */     throw new ServiceRegistrationException("Not Supported on" + getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long l2ServerAcceptAndOpenServerConnection(long handle) throws IOException {
/* 899 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void l2CloseServerConnection(long handle) throws IOException {
/* 908 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void l2ServerClose(long handle, ServiceRecordImpl serviceRecord) throws IOException {
/* 917 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int l2GetSecurityOpt(long handle, int expected) throws IOException {
/* 926 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean l2Ready(long handle) throws IOException {
/* 935 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int l2Receive(long handle, byte[] inBuf) throws IOException {
/* 944 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void l2Send(long handle, byte[] data, int transmitMTU) throws IOException {
/* 953 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int l2GetReceiveMTU(long handle) throws IOException {
/* 962 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int l2GetTransmitMTU(long handle) throws IOException {
/* 971 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long l2RemoteAddress(long handle) throws IOException {
/* 980 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean l2Encrypt(long address, long handle, boolean on) throws IOException {
/* 989 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */   
/*     */   public native boolean isNativeCodeLoaded();
/*     */   
/*     */   public native int getLibraryVersion();
/*     */   
/*     */   public native int detectBluetoothStack();
/*     */   
/*     */   public native void enableNativeDebug(Class paramClass, boolean paramBoolean);
/*     */   
/*     */   private static native int initializationStatus() throws IOException;
/*     */   
/*     */   private native void uninitialize();
/*     */   
/*     */   private native boolean isWindowsCE();
/*     */   
/*     */   private native int getDeviceClass(long paramLong);
/*     */   
/*     */   private native void setDiscoverable(boolean paramBoolean) throws BluetoothStateException;
/*     */   
/*     */   private native int getBluetoothRadioMode();
/*     */   
/*     */   private native String getradioname(long paramLong);
/*     */   
/*     */   private native int getDeviceVersion(long paramLong);
/*     */   
/*     */   private native int getDeviceManufacturer(long paramLong);
/*     */   
/*     */   private native boolean retrieveDevicesImpl(int paramInt, RetrieveDevicesCallback paramRetrieveDevicesCallback);
/*     */   
/*     */   private native boolean isRemoteDeviceTrustedImpl(long paramLong);
/*     */   
/*     */   private native boolean isRemoteDeviceAuthenticatedImpl(long paramLong);
/*     */   
/*     */   private native boolean authenticateRemoteDeviceImpl(long paramLong, String paramString) throws IOException;
/*     */   
/*     */   private native void removeAuthenticationWithRemoteDeviceImpl(long paramLong) throws IOException;
/*     */   
/*     */   private native int runDeviceInquiryImpl(DeviceInquiryRunnable paramDeviceInquiryRunnable, DeviceInquiryThread paramDeviceInquiryThread, int paramInt1, int paramInt2, DiscoveryListener paramDiscoveryListener) throws BluetoothStateException;
/*     */   
/*     */   private native boolean cancelInquiry();
/*     */   
/*     */   private native int[] runSearchServicesImpl(UUID[] paramArrayOfUUID, long paramLong) throws SearchServicesException;
/*     */   
/*     */   public native byte[] getServiceAttributes(int[] paramArrayOfint, long paramLong, int paramInt) throws IOException;
/*     */   
/*     */   private native long socket(boolean paramBoolean1, boolean paramBoolean2) throws IOException;
/*     */   
/*     */   private native long getsockaddress(long paramLong) throws IOException;
/*     */   
/*     */   private native void storesockopt(long paramLong);
/*     */   
/*     */   private native int getsockchannel(long paramLong) throws IOException;
/*     */   
/*     */   private native void connect(long paramLong1, long paramLong2, int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private native void bind(long paramLong) throws IOException;
/*     */   
/*     */   private native void listen(long paramLong) throws IOException;
/*     */   
/*     */   private native long accept(long paramLong) throws IOException;
/*     */   
/*     */   private native int recvAvailable(long paramLong) throws IOException;
/*     */   
/*     */   private native int recv(long paramLong) throws IOException;
/*     */   
/*     */   private native int recv(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private native void send(long paramLong, int paramInt) throws IOException;
/*     */   
/*     */   private native void send(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private native void close(long paramLong) throws IOException;
/*     */   
/*     */   private native String getpeername(long paramLong) throws IOException;
/*     */   
/*     */   private native long getpeeraddress(long paramLong) throws IOException;
/*     */   
/*     */   private native long registerService(byte[] paramArrayOfbyte, int paramInt) throws ServiceRegistrationException;
/*     */   
/*     */   private native void unregisterService(long paramLong) throws ServiceRegistrationException;
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothStackMicrosoft.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */