/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UtilsJavaSE
/*     */ {
/*     */   static final boolean javaSECompiledOut = false;
/*     */   
/*     */   static interface JavaSE5Features
/*     */   {
/*     */     void clearProperty(String param1String);
/*     */   }
/*     */   
/*     */   static class StackTraceLocation
/*     */   {
/*     */     public String className;
/*     */     public String methodName;
/*     */     public String fileName;
/*     */     public int lineNumber;
/*     */   }
/*  59 */   static final int javaSpecificationVersion = getJavaSpecificationVersion();
/*     */   
/*     */   static boolean java13 = false;
/*     */   
/*     */   static boolean java14 = false;
/*     */   
/*     */   static boolean detectJava5Helper = true;
/*     */   
/*     */   static JavaSE5Features java5Helper;
/*     */   
/*  69 */   static final boolean ibmJ9midp = detectJ9midp();
/*     */   
/*  71 */   static final boolean canCallNotLoadedNativeMethod = !ibmJ9midp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean detectJ9midp() {
/*     */     String ibmJ9config;
/*     */     try {
/*  80 */       ibmJ9config = System.getProperty("com.ibm.oti.configuration");
/*  81 */     } catch (SecurityException webstart) {
/*  82 */       return false;
/*     */     } 
/*  84 */     return (ibmJ9config != null && ibmJ9config.indexOf("midp") != -1);
/*     */   }
/*     */   
/*     */   private static int getJavaSpecificationVersion() {
/*     */     try {
/*  89 */       String javaV = System.getProperty("java.specification.version");
/*  90 */       if (javaV == null || javaV.length() < 3) {
/*  91 */         return 0;
/*     */       }
/*  93 */       return Integer.valueOf(javaV.substring(2, 3)).intValue();
/*  94 */     } catch (Throwable e) {
/*  95 */       return 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void detectJava5Helper() {
/* 100 */     if (java13 || ibmJ9midp || !detectJava5Helper || javaSpecificationVersion < 5) {
/*     */       return;
/*     */     }
/* 103 */     detectJava5Helper = false;
/*     */     try {
/* 105 */       Class klass = Class.forName("com.intel.bluetooth.UtilsJavaSE5");
/* 106 */       java5Helper = (JavaSE5Features)klass.newInstance();
/* 107 */       DebugLog.debug("Use java 1.5+ features:", vmInfo());
/* 108 */     } catch (Throwable e) {}
/*     */   }
/*     */ 
/*     */   
/*     */   static StackTraceLocation getLocation(Vector fqcnSet) {
/* 113 */     if (java13 || ibmJ9midp) {
/* 114 */       return null;
/*     */     }
/*     */     
/* 117 */     if (!java14) {
/*     */       try {
/* 119 */         Class.forName("java.lang.StackTraceElement");
/* 120 */         java14 = true;
/* 121 */         DebugLog.debug("Java 1.4+ detected:", vmInfo());
/* 122 */       } catch (ClassNotFoundException e) {
/* 123 */         java13 = true;
/* 124 */         return null;
/*     */       } 
/*     */     }
/*     */     try {
/* 128 */       return getLocationJava14(fqcnSet);
/* 129 */     } catch (Throwable e) {
/* 130 */       java13 = true;
/*     */ 
/*     */       
/* 133 */       return null;
/*     */     } 
/*     */   }
/*     */   static String vmInfo() {
/*     */     try {
/* 138 */       return System.getProperty("java.version") + "; " + System.getProperty("java.vm.name") + "; " + System.getProperty("java.vendor");
/*     */     }
/* 140 */     catch (SecurityException ignore) {
/* 141 */       return "";
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static StackTraceLocation getLocationJava14(Vector fqcnSet) {
/* 147 */     StackTraceElement[] ste = (new Throwable()).getStackTrace();
/* 148 */     for (int i = 0; i < ste.length - 1; i++) {
/* 149 */       if (fqcnSet.contains(ste[i].getClassName())) {
/* 150 */         String nextClassName = ste[i + 1].getClassName();
/* 151 */         if (!nextClassName.startsWith("java.") && !nextClassName.startsWith("sun."))
/*     */         {
/*     */           
/* 154 */           if (!fqcnSet.contains(nextClassName)) {
/* 155 */             StackTraceElement st = ste[i + 1];
/* 156 */             StackTraceLocation loc = new StackTraceLocation();
/* 157 */             loc.className = st.getClassName();
/* 158 */             loc.methodName = st.getMethodName();
/* 159 */             loc.fileName = st.getFileName();
/* 160 */             loc.lineNumber = st.getLineNumber();
/* 161 */             return loc;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 166 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void threadSetDaemon(Thread thread) {
/*     */     try {
/* 177 */       if (!ibmJ9midp) {
/* 178 */         thread.setDaemon(true);
/*     */       }
/* 180 */     } catch (Throwable javaJ9) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean runtimeAddShutdownHook(Thread thread) {
/*     */     try {
/* 188 */       if (ibmJ9midp) {
/* 189 */         IBMJ9Helper.addShutdownClass(thread);
/* 190 */         return true;
/*     */       } 
/* 192 */       Runtime.getRuntime().addShutdownHook(thread);
/* 193 */       return true;
/*     */     
/*     */     }
/* 196 */     catch (Throwable java12) {
/*     */       
/* 198 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   static void runtimeRemoveShutdownHook(Thread thread) {
/*     */     try {
/* 204 */       if (!ibmJ9midp) {
/* 205 */         Runtime.getRuntime().removeShutdownHook(thread);
/*     */       }
/* 207 */     } catch (Throwable java12) {}
/*     */   }
/*     */ 
/*     */   
/*     */   static void setSystemProperty(String propertyName, String propertyValue) {
/* 212 */     if (ibmJ9midp) {
/*     */       return;
/*     */     }
/* 215 */     boolean propertySet = false;
/*     */     try {
/* 217 */       Properties props = System.getProperties();
/* 218 */       if (propertyValue != null) {
/* 219 */         props.put(propertyName, propertyValue);
/* 220 */         propertySet = propertyValue.equals(System.getProperty(propertyName));
/*     */       } else {
/* 222 */         props.remove(propertyName);
/* 223 */         propertySet = (System.getProperty(propertyName) == null);
/*     */       } 
/* 225 */     } catch (SecurityException e) {}
/*     */     
/* 227 */     if (!propertySet) {
/*     */       
/*     */       try {
/* 230 */         if (propertyValue != null) {
/* 231 */           System.setProperty(propertyName, propertyValue);
/*     */         } else {
/* 233 */           detectJava5Helper();
/* 234 */           if (java5Helper != null) {
/* 235 */             java5Helper.clearProperty(propertyName);
/*     */           }
/*     */         } 
/* 238 */       } catch (Throwable java11) {}
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static Throwable initCause(Throwable throwable, Throwable cause) {
/* 244 */     if (!java14 || cause == null) {
/* 245 */       return throwable;
/*     */     }
/*     */     try {
/* 248 */       return throwable.initCause(cause);
/* 249 */     } catch (Throwable j9pp10) {
/* 250 */       return throwable;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isCurrentThreadInterrupted() {
/* 259 */     if (ibmJ9midp) {
/* 260 */       return false;
/*     */     }
/* 262 */     return Thread.interrupted();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Throwable getCause(PrivilegedActionException e) {
/*     */     try {
/* 270 */       return e.getCause();
/* 271 */     } catch (Throwable j9pp10) {
/*     */ 
/*     */       
/*     */       try {
/* 275 */         return e.getException();
/* 276 */       } catch (Throwable ignore) {
/*     */         
/* 278 */         return null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\UtilsJavaSE.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */