/*    */ package com.intel.bluetooth;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BluetoothL2CAPServerConnection
/*    */   extends BluetoothL2CAPConnection
/*    */   implements BluetoothServerConnection
/*    */ {
/*    */   protected BluetoothL2CAPServerConnection(BluetoothStack bluetoothStack, long handle, int transmitMTU, int securityOpt) throws IOException {
/* 41 */     super(bluetoothStack, handle);
/* 42 */     boolean initOK = false;
/*    */     try {
/* 44 */       this.securityOpt = securityOpt;
/* 45 */       this.transmitMTU = getTransmitMTU();
/*    */       
/* 47 */       if (transmitMTU > 0 && transmitMTU < this.transmitMTU) {
/* 48 */         this.transmitMTU = transmitMTU;
/*    */       }
/* 50 */       RemoteDeviceHelper.connected(this);
/* 51 */       initOK = true;
/*    */     } finally {
/* 53 */       if (!initOK) {
/*    */         try {
/* 55 */           bluetoothStack.l2CloseServerConnection(this.handle);
/* 56 */         } catch (IOException e) {
/* 57 */           DebugLog.error("close error", e);
/*    */         } 
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void closeConnectionHandle(long handle) throws IOException {
/* 69 */     RemoteDeviceHelper.disconnected(this);
/* 70 */     this.bluetoothStack.l2CloseServerConnection(handle);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothL2CAPServerConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */