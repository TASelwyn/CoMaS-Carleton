/*    */ package com.intel.bluetooth;
/*    */ 
/*    */ import org.apache.log4j.Level;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.apache.log4j.Priority;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DebugLog4jAppender
/*    */   implements DebugLog.LoggerAppenderExt
/*    */ {
/* 37 */   private static final String FQCN = DebugLog.class.getName();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   private Logger logger = Logger.getLogger("com.intel.bluetooth");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void appendLog(int level, String message, Throwable throwable) {
/* 49 */     switch (level) {
/*    */       case 1:
/* 51 */         this.logger.log(FQCN, (Priority)Level.DEBUG, message, throwable);
/*    */         break;
/*    */       case 4:
/* 54 */         this.logger.log(FQCN, (Priority)Level.ERROR, message, throwable);
/*    */         break;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isLogEnabled(int level) {
/* 63 */     switch (level) {
/*    */       case 1:
/* 65 */         return this.logger.isDebugEnabled();
/*    */       case 4:
/* 67 */         return true;
/*    */     } 
/* 69 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\DebugLog4jAppender.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */