/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.bluetooth.BluetoothStateException;
/*     */ import javax.bluetooth.RemoteDevice;
/*     */ import javax.microedition.io.Connection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RemoteDeviceHelper
/*     */ {
/*     */   private static class RemoteDeviceWithExtendedInfo
/*     */     extends RemoteDevice
/*     */   {
/*     */     String name;
/*     */     long addressLong;
/*     */     BluetoothStack bluetoothStack;
/*     */     private Hashtable stackAttributes;
/*     */     private boolean paired;
/*     */     private WeakVectorFactory.WeakVector connections;
/*     */     
/*     */     private RemoteDeviceWithExtendedInfo(BluetoothStack bluetoothStack, long address, String name) {
/*  73 */       super(RemoteDeviceHelper.getBluetoothAddress(address));
/*  74 */       this.bluetoothStack = bluetoothStack;
/*  75 */       this.name = name;
/*  76 */       this.addressLong = address;
/*     */     }
/*     */     
/*     */     private void addConnection(Object connection) {
/*  80 */       synchronized (this) {
/*  81 */         if (this.connections == null) {
/*  82 */           this.connections = WeakVectorFactory.createWeakVector();
/*     */         }
/*     */       } 
/*  85 */       synchronized (this.connections) {
/*  86 */         this.connections.addElement(connection);
/*  87 */         DebugLog.debug("connection open, open now", this.connections.size());
/*     */       } 
/*     */     }
/*     */     
/*     */     private void removeConnection(Object connection) {
/*  92 */       if (this.connections == null) {
/*     */         return;
/*     */       }
/*  95 */       synchronized (this.connections) {
/*  96 */         this.connections.removeElement(connection);
/*  97 */         DebugLog.debug("connection closed, open now", this.connections.size());
/*     */       } 
/*     */     }
/*     */     
/*     */     void shutdownConnections() {
/* 102 */       if (!hasConnections()) {
/*     */         return;
/*     */       }
/* 105 */       Vector c2shutdown = new Vector();
/* 106 */       synchronized (this.connections) {
/* 107 */         c2shutdown = Utils.clone(this.connections.elements());
/*     */       } 
/* 109 */       for (Enumeration en = c2shutdown.elements(); en.hasMoreElements(); ) {
/* 110 */         BluetoothConnectionAccess c = en.nextElement();
/*     */         try {
/* 112 */           c.shutdown();
/* 113 */         } catch (IOException e) {
/* 114 */           DebugLog.debug("connection shutdown", e);
/*     */         } 
/*     */       } 
/* 117 */       synchronized (this.connections) {
/* 118 */         this.connections.removeAllElements();
/*     */       } 
/*     */     }
/*     */     
/*     */     private void setStackAttributes(Object key, Object value) {
/* 123 */       if (this.stackAttributes == null) {
/* 124 */         this.stackAttributes = new Hashtable();
/*     */       }
/* 126 */       if (value == null) {
/* 127 */         this.stackAttributes.remove(key);
/*     */       } else {
/* 129 */         this.stackAttributes.put(key, value);
/*     */       } 
/*     */     }
/*     */     
/*     */     private Object getStackAttributes(Object key) {
/* 134 */       if (this.stackAttributes == null) {
/* 135 */         return null;
/*     */       }
/* 137 */       return this.stackAttributes.get(key);
/*     */     }
/*     */     
/*     */     public String toString() {
/* 141 */       return getBluetoothAddress();
/*     */     }
/*     */     
/*     */     int connectionsCount() {
/* 145 */       if (this.connections == null) {
/* 146 */         return 0;
/*     */       }
/* 148 */       return this.connections.size();
/*     */     }
/*     */     
/*     */     boolean hasConnections() {
/* 152 */       return (connectionsCount() != 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean authenticate() throws IOException {
/* 159 */       if (!hasConnections()) {
/* 160 */         throw new IOException("No open connections to this RemoteDevice");
/*     */       }
/* 162 */       if (isAuthenticated())
/*     */       {
/* 164 */         return true;
/*     */       }
/* 166 */       boolean authenticated = this.bluetoothStack.authenticateRemoteDevice(this.addressLong);
/* 167 */       this.paired = authenticated;
/* 168 */       if (authenticated) {
/* 169 */         updateConnectionMarkAuthenticated();
/*     */       }
/* 171 */       return authenticated;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean authenticate(String passkey) throws IOException {
/* 179 */       boolean authenticated = this.bluetoothStack.authenticateRemoteDevice(this.addressLong, passkey);
/* 180 */       this.paired = authenticated;
/* 181 */       if (authenticated) {
/* 182 */         updateConnectionMarkAuthenticated();
/*     */       }
/* 184 */       return authenticated;
/*     */     }
/*     */     
/*     */     void removeAuthentication() throws IOException {
/* 188 */       this.bluetoothStack.removeAuthenticationWithRemoteDevice(this.addressLong);
/* 189 */       this.paired = false;
/*     */     }
/*     */     
/*     */     private void updateConnectionMarkAuthenticated() {
/* 193 */       if (this.connections == null) {
/*     */         return;
/*     */       }
/* 196 */       synchronized (this.connections) {
/* 197 */         for (Enumeration en = this.connections.elements(); en.hasMoreElements(); ) {
/* 198 */           BluetoothConnectionAccess c = en.nextElement();
/* 199 */           c.markAuthenticated();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean authorize(Connection conn) throws IOException {
/* 211 */       if (!(conn instanceof BluetoothConnectionAccess)) {
/* 212 */         throw new IllegalArgumentException("Connection is not a Bluetooth connection");
/*     */       }
/* 214 */       if (((BluetoothConnectionAccess)conn).isClosed()) {
/* 215 */         throw new IOException("Connection is already closed");
/*     */       }
/* 217 */       if (!(conn instanceof BluetoothServerConnection)) {
/* 218 */         throw new IllegalArgumentException("Connection is not an incomming Bluetooth connection");
/*     */       }
/* 220 */       return (isTrustedDevice() || isAuthenticated());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isAuthorized(Connection conn) throws IOException {
/* 228 */       if (!(conn instanceof BluetoothConnectionAccess)) {
/* 229 */         throw new IllegalArgumentException("Connection is not a Bluetooth connection");
/*     */       }
/* 231 */       if (((BluetoothConnectionAccess)conn).isClosed()) {
/* 232 */         throw new IOException("Connection is already closed");
/*     */       }
/* 234 */       if (!(conn instanceof BluetoothServerConnection)) {
/* 235 */         throw new IllegalArgumentException("Connection is not an incomming Bluetooth connection");
/*     */       }
/* 237 */       return isTrustedDevice();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean encrypt(Connection conn, boolean on) throws IOException {
/* 247 */       if (!(conn instanceof BluetoothConnectionAccess)) {
/* 248 */         throw new IllegalArgumentException("Connection is not a Bluetooth connection");
/*     */       }
/* 250 */       if (((BluetoothConnectionAccess)conn).getRemoteAddress() != this.addressLong) {
/* 251 */         throw new IllegalArgumentException("Connection is not to this device");
/*     */       }
/* 253 */       if (((((BluetoothConnectionAccess)conn).getSecurityOpt() == 2)) == on) {
/* 254 */         return true;
/*     */       }
/* 256 */       return ((BluetoothConnectionAccess)conn).encrypt(this.addressLong, on);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isAuthenticated() {
/* 265 */       if (!hasConnections()) {
/* 266 */         DebugLog.debug("no connections, Authenticated = false");
/* 267 */         return false;
/*     */       } 
/* 269 */       Boolean authenticated = this.bluetoothStack.isRemoteDeviceAuthenticated(this.addressLong);
/* 270 */       if (authenticated != null) {
/* 271 */         return authenticated.booleanValue();
/*     */       }
/* 273 */       synchronized (this.connections) {
/*     */         
/* 275 */         for (Enumeration en = this.connections.elements(); en.hasMoreElements(); ) {
/* 276 */           BluetoothConnectionAccess c = en.nextElement();
/* 277 */           if (c.getSecurityOpt() != 0) {
/* 278 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/* 282 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEncrypted() {
/* 291 */       if (!hasConnections()) {
/* 292 */         return false;
/*     */       }
/* 294 */       synchronized (this.connections) {
/*     */         
/* 296 */         for (Enumeration en = this.connections.elements(); en.hasMoreElements(); ) {
/* 297 */           BluetoothConnectionAccess c = en.nextElement();
/* 298 */           if (c.getSecurityOpt() == 2) {
/* 299 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/* 303 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isTrustedDevice() {
/* 312 */       Boolean trusted = this.bluetoothStack.isRemoteDeviceTrusted(this.addressLong);
/* 313 */       if (trusted == null) {
/* 314 */         return this.paired;
/*     */       }
/* 316 */       return trusted.booleanValue();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 321 */   private static Hashtable stackDevicesCashed = new Hashtable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static synchronized Hashtable devicesCashed(BluetoothStack bluetoothStack) {
/* 328 */     Hashtable devicesCashed = (Hashtable)stackDevicesCashed.get(bluetoothStack);
/* 329 */     if (devicesCashed == null) {
/* 330 */       devicesCashed = new Hashtable();
/* 331 */       stackDevicesCashed.put(bluetoothStack, devicesCashed);
/*     */     } 
/* 333 */     return devicesCashed;
/*     */   }
/*     */   
/*     */   private static RemoteDeviceWithExtendedInfo getCashedDeviceWithExtendedInfo(BluetoothStack bluetoothStack, long address) {
/* 337 */     Object key = new Long(address);
/* 338 */     return (RemoteDeviceWithExtendedInfo)devicesCashed(bluetoothStack).get(key);
/*     */   }
/*     */   
/*     */   static RemoteDevice getCashedDevice(BluetoothStack bluetoothStack, long address) {
/* 342 */     return getCashedDeviceWithExtendedInfo(bluetoothStack, address);
/*     */   }
/*     */   
/*     */   static RemoteDevice getStackBoundDevice(BluetoothStack bluetoothStack, RemoteDevice device) {
/* 346 */     if (device instanceof RemoteDeviceWithExtendedInfo && ((RemoteDeviceWithExtendedInfo)device).bluetoothStack == bluetoothStack) {
/* 347 */       return device;
/*     */     }
/* 349 */     return createRemoteDevice(bluetoothStack, getAddress(device), null, false);
/*     */   }
/*     */   
/*     */   static RemoteDevice createRemoteDevice(BluetoothStack bluetoothStack, long address, String name, boolean paired) {
/* 353 */     RemoteDeviceWithExtendedInfo dev = getCashedDeviceWithExtendedInfo(bluetoothStack, address);
/* 354 */     if (dev == null) {
/* 355 */       Object saveID = BlueCoveImpl.getCurrentThreadBluetoothStackID();
/*     */       try {
/* 357 */         BlueCoveImpl.setThreadBluetoothStack(bluetoothStack);
/* 358 */         dev = new RemoteDeviceWithExtendedInfo(bluetoothStack, address, name);
/*     */       } finally {
/* 360 */         if (saveID != null) {
/* 361 */           BlueCoveImpl.setThreadBluetoothStackID(saveID);
/*     */         }
/*     */       } 
/* 364 */       devicesCashed(bluetoothStack).put(new Long(address), dev);
/* 365 */       DebugLog.debug0x("new devicesCashed", address);
/* 366 */     } else if (!Utils.isStringSet(dev.name)) {
/*     */       
/* 368 */       dev.name = name;
/* 369 */     } else if (Utils.isStringSet(name)) {
/*     */       
/* 371 */       dev.name = name;
/*     */     } 
/* 373 */     if (paired) {
/* 374 */       dev.paired = paired;
/*     */     }
/* 376 */     return dev;
/*     */   }
/*     */   
/*     */   private static BluetoothStack getBluetoothStack() throws RuntimeException {
/*     */     try {
/* 381 */       return BlueCoveImpl.instance().getBluetoothStack();
/* 382 */     } catch (BluetoothStateException e) {
/* 383 */       throw (RuntimeException)UtilsJavaSE.initCause(new RuntimeException("Can't initialize bluetooth support"), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static RemoteDeviceWithExtendedInfo remoteDeviceImpl(RemoteDevice device) {
/* 388 */     return (RemoteDeviceWithExtendedInfo)createRemoteDevice(null, device);
/*     */   }
/*     */   
/*     */   static RemoteDevice createRemoteDevice(BluetoothStack bluetoothStack, RemoteDevice device) throws RuntimeException {
/* 392 */     if (device instanceof RemoteDeviceWithExtendedInfo) {
/* 393 */       return device;
/*     */     }
/* 395 */     if (bluetoothStack == null) {
/* 396 */       bluetoothStack = getBluetoothStack();
/*     */     }
/* 398 */     return createRemoteDevice(bluetoothStack, getAddress(device), null, false);
/*     */   }
/*     */ 
/*     */   
/*     */   static RemoteDevice[] remoteDeviceListToArray(Vector devices) {
/* 403 */     RemoteDevice[] devicesArray = new RemoteDevice[devices.size()];
/* 404 */     int i = 0;
/* 405 */     for (Enumeration en = devices.elements(); en.hasMoreElements();) {
/* 406 */       devicesArray[i++] = en.nextElement();
/*     */     }
/* 408 */     return devicesArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int openConnections() {
/* 417 */     int c = 0;
/* 418 */     Hashtable devicesCashed = devicesCashed(getBluetoothStack());
/* 419 */     synchronized (devicesCashed) {
/* 420 */       for (Enumeration en = devicesCashed.elements(); en.hasMoreElements();) {
/* 421 */         c += ((RemoteDeviceWithExtendedInfo)en.nextElement()).connectionsCount();
/*     */       }
/*     */     } 
/* 424 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int openConnections(long address) {
/* 433 */     RemoteDeviceWithExtendedInfo dev = getCashedDeviceWithExtendedInfo(getBluetoothStack(), address);
/* 434 */     if (dev == null) {
/* 435 */       return 0;
/*     */     }
/* 437 */     return dev.connectionsCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int connectedDevices() {
/* 446 */     int c = 0;
/* 447 */     Hashtable devicesCashed = devicesCashed(getBluetoothStack());
/* 448 */     synchronized (devicesCashed) {
/* 449 */       for (Enumeration en = devicesCashed.elements(); en.hasMoreElements();) {
/* 450 */         if (((RemoteDeviceWithExtendedInfo)en.nextElement()).hasConnections()) {
/* 451 */           c++;
/*     */         }
/*     */       } 
/*     */     } 
/* 455 */     return c;
/*     */   }
/*     */   
/*     */   static void shutdownConnections(BluetoothStack bluetoothStack) {
/* 459 */     Hashtable devicesCashed = devicesCashed(bluetoothStack);
/* 460 */     synchronized (devicesCashed) {
/* 461 */       for (Enumeration en = devicesCashed.elements(); en.hasMoreElements();) {
/* 462 */         ((RemoteDeviceWithExtendedInfo)en.nextElement()).shutdownConnections();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String formatBluetoothAddress(String address) {
/* 468 */     String s = address.toUpperCase();
/* 469 */     return "000000000000".substring(s.length()) + s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getBluetoothAddress(long address) {
/* 479 */     return formatBluetoothAddress(Utils.toHexString(address));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long getAddress(String bluetoothAddress) {
/* 489 */     if (bluetoothAddress.indexOf('-') != -1) {
/* 490 */       throw new IllegalArgumentException("Illegal bluetoothAddress {" + bluetoothAddress + "}");
/*     */     }
/*     */     try {
/* 493 */       return Long.parseLong(bluetoothAddress, 16);
/* 494 */     } catch (NumberFormatException e) {
/* 495 */       throw new IllegalArgumentException("Illegal bluetoothAddress {" + bluetoothAddress + "}; should be hex number");
/*     */     } 
/*     */   }
/*     */   
/*     */   static long getAddress(RemoteDevice device) {
/* 500 */     if (device instanceof RemoteDeviceWithExtendedInfo) {
/* 501 */       return ((RemoteDeviceWithExtendedInfo)device).addressLong;
/*     */     }
/* 503 */     return getAddress(device.getBluetoothAddress());
/*     */   }
/*     */ 
/*     */   
/*     */   static void setStackAttributes(BluetoothStack bluetoothStack, RemoteDevice device, Object key, Object value) {
/* 508 */     RemoteDeviceWithExtendedInfo devInfo = (RemoteDeviceWithExtendedInfo)createRemoteDevice(bluetoothStack, device);
/* 509 */     devInfo.setStackAttributes(key, value);
/*     */   }
/*     */   
/*     */   static Object getStackAttributes(BluetoothStack bluetoothStack, RemoteDevice device, Object key) {
/* 513 */     RemoteDeviceWithExtendedInfo devInfo = null;
/* 514 */     if (device instanceof RemoteDeviceWithExtendedInfo) {
/* 515 */       devInfo = (RemoteDeviceWithExtendedInfo)device;
/*     */     } else {
/* 517 */       devInfo = getCashedDeviceWithExtendedInfo(bluetoothStack, getAddress(device));
/*     */     } 
/*     */     
/* 520 */     if (devInfo != null) {
/* 521 */       return devInfo.getStackAttributes(key);
/*     */     }
/* 523 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static void connected(BluetoothConnectionAccess connection) throws IOException {
/* 528 */     RemoteDeviceWithExtendedInfo device = (RemoteDeviceWithExtendedInfo)implGetRemoteDevice((Connection)connection);
/* 529 */     connection.setRemoteDevice(device);
/* 530 */     device.addConnection(connection);
/*     */   }
/*     */   
/*     */   static void disconnected(BluetoothConnectionAccess connection) {
/* 534 */     RemoteDevice d = connection.getRemoteDevice();
/* 535 */     if (d != null) {
/* 536 */       ((RemoteDeviceWithExtendedInfo)d).removeConnection(connection);
/* 537 */       connection.setRemoteDevice(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int readRSSI(RemoteDevice device) throws IOException {
/* 566 */     RemoteDeviceWithExtendedInfo deviceImpl = remoteDeviceImpl(device);
/* 567 */     if (deviceImpl.bluetoothStack instanceof BluetoothStackExtension) {
/* 568 */       return ((BluetoothStackExtension)deviceImpl.bluetoothStack).readRemoteDeviceRSSI(deviceImpl.addressLong);
/*     */     }
/* 570 */     throw new NotSupportedIOException(deviceImpl.bluetoothStack.getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean authenticate(RemoteDevice device) throws IOException {
/* 585 */     return remoteDeviceImpl(device).authenticate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean authenticate(RemoteDevice device, String passkey) throws IOException {
/* 608 */     return remoteDeviceImpl(device).authenticate(passkey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeAuthentication(RemoteDevice device) throws IOException {
/* 625 */     remoteDeviceImpl(device).removeAuthentication();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String implGetFriendlyName(RemoteDevice device, long address, boolean alwaysAsk) throws IOException {
/* 640 */     if (!(device instanceof RemoteDeviceWithExtendedInfo)) {
/* 641 */       device = createRemoteDevice(null, device);
/*     */     }
/* 643 */     String name = ((RemoteDeviceWithExtendedInfo)device).name;
/* 644 */     if (alwaysAsk || name == null) {
/* 645 */       name = ((RemoteDeviceWithExtendedInfo)device).bluetoothStack.getRemoteDeviceFriendlyName(address);
/* 646 */       if (name != null) {
/* 647 */         ((RemoteDeviceWithExtendedInfo)device).name = name;
/*     */       }
/*     */     } 
/* 650 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RemoteDevice implGetRemoteDevice(Connection conn) throws IOException {
/* 664 */     if (!(conn instanceof BluetoothConnectionAccess)) {
/* 665 */       throw new IllegalArgumentException("Not a Bluetooth connection " + conn.getClass().getName());
/*     */     }
/* 667 */     return createRemoteDevice(((BluetoothConnectionAccess)conn).getBluetoothStack(), ((BluetoothConnectionAccess)conn).getRemoteAddress(), null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RemoteDevice[] implRetrieveDevices(BluetoothStack bluetoothStack, int option) {
/*     */     Vector devicesPaired;
/*     */     Enumeration en;
/*     */     RemoteDevice[] devices;
/*     */     int k;
/*     */     Enumeration enumeration;
/* 680 */     if (option != 1 && option != 0) {
/* 681 */       throw new IllegalArgumentException("invalid option");
/*     */     }
/* 683 */     RemoteDevice[] impl = bluetoothStack.retrieveDevices(option);
/* 684 */     if (impl != null) {
/* 685 */       if (impl.length == 0)
/*     */       {
/* 687 */         return null;
/*     */       }
/* 689 */       return impl;
/*     */     } 
/*     */ 
/*     */     
/* 693 */     Hashtable devicesCashed = devicesCashed(bluetoothStack);
/* 694 */     switch (option) {
/*     */       case 1:
/* 696 */         if (devicesCashed.size() == 0)
/*     */         {
/* 698 */           return null;
/*     */         }
/* 700 */         devicesPaired = new Vector();
/* 701 */         for (en = devicesCashed.elements(); en.hasMoreElements(); ) {
/* 702 */           RemoteDeviceWithExtendedInfo d = en.nextElement();
/* 703 */           if (d.isTrustedDevice()) {
/* 704 */             devicesPaired.addElement(d);
/*     */           }
/*     */         } 
/* 707 */         if (devicesPaired.size() == 0)
/*     */         {
/* 709 */           return null;
/*     */         }
/* 711 */         return remoteDeviceListToArray(devicesPaired);
/*     */       case 0:
/* 713 */         if (devicesCashed.size() == 0)
/*     */         {
/* 715 */           return null;
/*     */         }
/* 717 */         devices = new RemoteDevice[devicesCashed.size()];
/* 718 */         k = 0;
/* 719 */         for (enumeration = devicesCashed.elements(); enumeration.hasMoreElements();) {
/* 720 */           devices[k++] = enumeration.nextElement();
/*     */         }
/* 722 */         return devices;
/*     */     } 
/* 724 */     throw new IllegalArgumentException("invalid option");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean implAuthorize(RemoteDevice device, Connection conn) throws IOException {
/* 739 */     return remoteDeviceImpl(device).authorize(conn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean implEncrypt(RemoteDevice device, Connection conn, boolean on) throws IOException {
/* 753 */     return remoteDeviceImpl(device).encrypt(conn, on);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean implIsAuthenticated(RemoteDevice device) {
/* 776 */     return remoteDeviceImpl(device).isAuthenticated();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean implIsAuthorized(RemoteDevice device, Connection conn) throws IOException {
/* 788 */     return remoteDeviceImpl(device).isAuthorized(conn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean implIsEncrypted(RemoteDevice device) {
/* 812 */     return remoteDeviceImpl(device).isEncrypted();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean implIsTrustedDevice(RemoteDevice device) {
/* 823 */     return remoteDeviceImpl(device).isTrustedDevice();
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\RemoteDeviceHelper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */