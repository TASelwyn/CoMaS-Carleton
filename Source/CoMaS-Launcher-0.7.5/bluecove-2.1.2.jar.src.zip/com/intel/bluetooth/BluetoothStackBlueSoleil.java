/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.bluetooth.BluetoothStateException;
/*     */ import javax.bluetooth.DeviceClass;
/*     */ import javax.bluetooth.DiscoveryListener;
/*     */ import javax.bluetooth.RemoteDevice;
/*     */ import javax.bluetooth.ServiceRecord;
/*     */ import javax.bluetooth.ServiceRegistrationException;
/*     */ import javax.bluetooth.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BluetoothStackBlueSoleil
/*     */   implements BluetoothStack, DeviceInquiryRunnable, SearchServicesRunnable
/*     */ {
/*  39 */   private static BluetoothStackBlueSoleil singleInstance = null;
/*     */ 
/*     */   
/*     */   private boolean initialized = false;
/*     */ 
/*     */   
/*     */   private DiscoveryListener currentDeviceDiscoveryListener;
/*     */ 
/*     */   
/*     */   public String getStackID() {
/*  49 */     return "bluesoleil";
/*     */   }
/*     */   
/*     */   public String toString() {
/*  53 */     return getStackID();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native boolean isNativeCodeLoaded();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BluetoothStack.LibraryInformation[] requireNativeLibraries() {
/*  71 */     return BluetoothStack.LibraryInformation.library("intelbth");
/*     */   }
/*     */   
/*     */   public native int getLibraryVersion();
/*     */   
/*     */   public native int detectBluetoothStack();
/*     */   
/*     */   public native void enableNativeDebug(Class paramClass, boolean paramBoolean);
/*     */   
/*     */   public native boolean initializeImpl();
/*     */   
/*     */   public void initialize() throws BluetoothStateException {
/*  83 */     if (singleInstance != null) {
/*  84 */       throw new BluetoothStateException("Only one instance of " + getStackID() + " stack supported");
/*     */     }
/*  86 */     if (!initializeImpl()) {
/*  87 */       DebugLog.fatal("Can't initialize BlueSoleil");
/*  88 */       throw new BluetoothStateException("BlueSoleil BluetoothStack not found");
/*     */     } 
/*  90 */     this.initialized = true;
/*  91 */     singleInstance = this;
/*     */   }
/*     */   
/*     */   private native void uninitialize();
/*     */   
/*     */   public void destroy() {
/*  97 */     if (singleInstance != this) {
/*  98 */       throw new RuntimeException("Destroy invalid instance");
/*     */     }
/* 100 */     if (this.initialized) {
/* 101 */       uninitialize();
/* 102 */       this.initialized = false;
/* 103 */       DebugLog.debug("BlueSoleil destroyed");
/*     */     } 
/* 105 */     singleInstance = null;
/*     */   }
/*     */   
/*     */   protected void finalize() {
/* 109 */     destroy();
/*     */   }
/*     */ 
/*     */   
/*     */   public native String getLocalDeviceBluetoothAddress();
/*     */ 
/*     */   
/*     */   public native String getLocalDeviceName();
/*     */ 
/*     */   
/*     */   public native int getDeviceClassImpl();
/*     */   
/*     */   public DeviceClass getLocalDeviceClass() {
/* 122 */     return new DeviceClass(getDeviceClassImpl());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocalDeviceServiceClasses(int classOfDevice) {
/* 131 */     throw new NotSupportedRuntimeException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setLocalDeviceDiscoverable(int mode) throws BluetoothStateException {
/* 138 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   native boolean isBlueSoleilStarted(int paramInt);
/*     */ 
/*     */   
/*     */   private native boolean isBluetoothReady(int paramInt);
/*     */ 
/*     */   
/*     */   public int getLocalDeviceDiscoverable() {
/* 149 */     if (isBluetoothReady(2)) {
/* 150 */       return 10390323;
/*     */     }
/* 152 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLocalDevicePowerOn() {
/* 157 */     return isBluetoothReady(15);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   native int getStackVersionInfo();
/*     */ 
/*     */   
/*     */   native int getDeviceVersion();
/*     */ 
/*     */   
/*     */   native int getDeviceManufacturer();
/*     */ 
/*     */   
/*     */   public int getFeatureSet() {
/* 172 */     return 0;
/*     */   }
/*     */   
/*     */   public String getLocalDeviceProperty(String property) {
/* 176 */     if ("bluetooth.connected.devices.max".equals(property)) {
/* 177 */       return "7";
/*     */     }
/* 179 */     if ("bluetooth.sd.trans.max".equals(property)) {
/* 180 */       return "1";
/*     */     }
/* 182 */     if ("bluetooth.connected.inquiry.scan".equals(property)) {
/* 183 */       return "true";
/*     */     }
/* 185 */     if ("bluetooth.connected.page.scan".equals(property)) {
/* 186 */       return "true";
/*     */     }
/* 188 */     if ("bluetooth.connected.inquiry".equals(property)) {
/* 189 */       return "true";
/*     */     }
/*     */ 
/*     */     
/* 193 */     if ("bluetooth.sd.attr.retrievable.max".equals(property)) {
/* 194 */       return "0";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 203 */     if ("bluecove.stack.version".equals(property)) {
/* 204 */       return String.valueOf(getStackVersionInfo());
/*     */     }
/*     */     
/* 207 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCurrentThreadInterruptedCallback() {
/* 216 */     return UtilsJavaSE.isCurrentThreadInterrupted();
/*     */   }
/*     */   
/*     */   public RemoteDevice[] retrieveDevices(int option) {
/* 220 */     return null;
/*     */   }
/*     */   
/*     */   public Boolean isRemoteDeviceTrusted(long address) {
/* 224 */     return null;
/*     */   }
/*     */   
/*     */   public Boolean isRemoteDeviceAuthenticated(long address) {
/* 228 */     return null;
/*     */   }
/*     */   
/*     */   public boolean authenticateRemoteDevice(long address) throws IOException {
/* 232 */     return false;
/*     */   }
/*     */   
/*     */   public boolean authenticateRemoteDevice(long address, String passkey) throws IOException {
/* 236 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAuthenticationWithRemoteDevice(long address) throws IOException {
/* 245 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean startInquiry(int accessCode, DiscoveryListener listener) throws BluetoothStateException {
/* 251 */     if (this.currentDeviceDiscoveryListener != null) {
/* 252 */       throw new BluetoothStateException("Another inquiry already running");
/*     */     }
/* 254 */     this.currentDeviceDiscoveryListener = listener;
/* 255 */     return DeviceInquiryThread.startInquiry(this, this, accessCode, listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public int runDeviceInquiry(DeviceInquiryThread startedNotify, int accessCode, DiscoveryListener listener) throws BluetoothStateException {
/*     */     try {
/* 261 */       startedNotify.deviceInquiryStartedCallback();
/* 262 */       return runDeviceInquiryImpl(startedNotify, accessCode, listener);
/*     */     } finally {
/* 264 */       this.currentDeviceDiscoveryListener = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public native int runDeviceInquiryImpl(DeviceInquiryThread paramDeviceInquiryThread, int paramInt, DiscoveryListener paramDiscoveryListener) throws BluetoothStateException;
/*     */ 
/*     */   
/*     */   public void deviceDiscoveredCallback(DiscoveryListener listener, long deviceAddr, int deviceClass, String deviceName, boolean paired) {
/* 273 */     DebugLog.debug("deviceDiscoveredCallback", deviceName);
/* 274 */     RemoteDevice remoteDevice = RemoteDeviceHelper.createRemoteDevice(this, deviceAddr, deviceName, paired);
/* 275 */     if (this.currentDeviceDiscoveryListener == null || this.currentDeviceDiscoveryListener != listener) {
/*     */       return;
/*     */     }
/* 278 */     listener.deviceDiscovered(remoteDevice, new DeviceClass(deviceClass));
/*     */   }
/*     */   
/*     */   public native boolean cancelInquirympl();
/*     */   
/*     */   public boolean cancelInquiry(DiscoveryListener listener) {
/* 284 */     if (this.currentDeviceDiscoveryListener != listener) {
/* 285 */       return false;
/*     */     }
/*     */     
/* 288 */     this.currentDeviceDiscoveryListener = null;
/* 289 */     return cancelInquirympl();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getRemoteDeviceFriendlyName(long address) throws IOException {
/* 294 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int searchServices(int[] attrSet, UUID[] uuidSet, RemoteDevice device, DiscoveryListener listener) throws BluetoothStateException {
/* 301 */     return SearchServicesThread.startSearchServices(this, this, attrSet, uuidSet, device, listener);
/*     */   }
/*     */   
/*     */   public boolean cancelServiceSearch(int transID) {
/* 305 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private native int runSearchServicesImpl(SearchServicesThread paramSearchServicesThread, DiscoveryListener paramDiscoveryListener, byte[] paramArrayOfbyte, long paramLong, RemoteDevice paramRemoteDevice) throws BluetoothStateException;
/*     */ 
/*     */   
/*     */   public int runSearchServices(SearchServicesThread startedNotify, int[] attrSet, UUID[] uuidSet, RemoteDevice device, DiscoveryListener listener) throws BluetoothStateException {
/* 313 */     startedNotify.searchServicesStartedCallback();
/* 314 */     UUID uuid = null;
/* 315 */     if (uuidSet != null && uuidSet.length > 0) {
/* 316 */       uuid = uuidSet[uuidSet.length - 1];
/*     */     }
/* 318 */     return runSearchServicesImpl(startedNotify, listener, Utils.UUIDToByteArray(uuid), RemoteDeviceHelper.getAddress(device), device);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void servicesFoundCallback(SearchServicesThread startedNotify, DiscoveryListener listener, RemoteDevice device, String serviceName, byte[] uuidValue, int channel, long recordHanlde) {
/* 330 */     ServiceRecordImpl record = new ServiceRecordImpl(this, device, 0L);
/*     */     
/* 332 */     UUID uuid = new UUID(Utils.UUIDByteArrayToString(uuidValue), false);
/*     */     
/* 334 */     record.populateRFCOMMAttributes(recordHanlde, channel, uuid, serviceName, BluetoothConsts.obexUUIDs.contains(uuid));
/*     */     
/* 336 */     DebugLog.debug("servicesFoundCallback", record);
/*     */     
/* 338 */     RemoteDevice listedDevice = RemoteDeviceHelper.createRemoteDevice(this, device);
/* 339 */     RemoteDeviceHelper.setStackAttributes(this, listedDevice, "RFCOMM_channel" + channel, uuid);
/*     */     
/* 341 */     ServiceRecordImpl[] arrayOfServiceRecordImpl = new ServiceRecordImpl[1];
/* 342 */     arrayOfServiceRecordImpl[0] = record;
/* 343 */     listener.servicesDiscovered(startedNotify.getTransID(), (ServiceRecord[])arrayOfServiceRecordImpl);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean populateServicesRecordAttributeValues(ServiceRecordImpl serviceRecord, int[] attrIDs) throws IOException {
/* 348 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private native long connectionRfOpenImpl(long paramLong, byte[] paramArrayOfbyte) throws IOException;
/*     */ 
/*     */   
/*     */   public long connectionRfOpenClientConnection(BluetoothConnectionParams params) throws IOException {
/* 356 */     if (params.authenticate || params.encrypt) {
/* 357 */       throw new IOException("authenticate not supported on BlueSoleil");
/*     */     }
/* 359 */     RemoteDevice listedDevice = RemoteDeviceHelper.getCashedDevice(this, params.address);
/* 360 */     if (listedDevice == null) {
/* 361 */       throw new IOException("Device not discovered");
/*     */     }
/* 363 */     UUID uuid = (UUID)RemoteDeviceHelper.getStackAttributes(this, listedDevice, "RFCOMM_channel" + params.channel);
/* 364 */     if (uuid == null) {
/* 365 */       throw new IOException("Device service not discovered");
/*     */     }
/* 367 */     DebugLog.debug("Connect to service UUID", uuid);
/* 368 */     return connectionRfOpenImpl(params.address, Utils.UUIDToByteArray(uuid));
/*     */   }
/*     */ 
/*     */   
/*     */   public native void connectionRfCloseClientConnection(long paramLong) throws IOException;
/*     */ 
/*     */   
/*     */   private native long rfServerOpenImpl(byte[] paramArrayOfbyte, String paramString, boolean paramBoolean1, boolean paramBoolean2) throws IOException;
/*     */   
/*     */   private native int rfServerSCN(long paramLong) throws IOException;
/*     */   
/*     */   public long rfServerOpen(BluetoothConnectionNotifierParams params, ServiceRecordImpl serviceRecord) throws IOException {
/* 380 */     if (params.authenticate || params.encrypt) {
/* 381 */       throw new IOException("authenticate not supported on BlueSoleil");
/*     */     }
/* 383 */     byte[] uuidValue = Utils.UUIDToByteArray(params.uuid);
/* 384 */     long handle = rfServerOpenImpl(uuidValue, params.name, params.authenticate, params.encrypt);
/* 385 */     int channel = rfServerSCN(handle);
/* 386 */     DebugLog.debug("serverSCN", channel);
/* 387 */     int serviceRecordHandle = (int)handle;
/*     */     
/* 389 */     serviceRecord.populateRFCOMMAttributes(serviceRecordHandle, channel, params.uuid, params.name, false);
/*     */     
/* 391 */     return handle;
/*     */   }
/*     */ 
/*     */   
/*     */   public void rfServerUpdateServiceRecord(long handle, ServiceRecordImpl serviceRecord, boolean acceptAndOpen) throws ServiceRegistrationException {
/* 396 */     if (!acceptAndOpen) {
/* 397 */       throw new ServiceRegistrationException("Not Supported on " + getStackID());
/*     */     }
/*     */   }
/*     */   
/*     */   public native long rfServerAcceptAndOpenRfServerConnection(long paramLong) throws IOException;
/*     */   
/*     */   public void connectionRfCloseServerConnection(long handle) throws IOException {
/* 404 */     connectionRfCloseClientConnection(handle);
/*     */   }
/*     */   
/*     */   public native void rfServerClose(long paramLong, ServiceRecordImpl paramServiceRecordImpl) throws IOException;
/*     */   
/*     */   public native long getConnectionRfRemoteAddress(long paramLong) throws IOException;
/*     */   
/*     */   public native int connectionRfRead(long paramLong) throws IOException;
/*     */   
/*     */   public native int connectionRfRead(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   public native int connectionRfReadAvailable(long paramLong) throws IOException;
/*     */   
/*     */   public native void connectionRfWrite(long paramLong, int paramInt) throws IOException;
/*     */   
/*     */   public native void connectionRfWrite(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   public native void connectionRfFlush(long paramLong) throws IOException;
/*     */   
/*     */   public int rfGetSecurityOpt(long handle, int expected) throws IOException {
/* 424 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean rfEncrypt(long address, long handle, boolean on) throws IOException {
/* 433 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long l2OpenClientConnection(BluetoothConnectionParams params, int receiveMTU, int transmitMTU) throws IOException {
/* 446 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void l2CloseClientConnection(long handle) throws IOException {
/* 455 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long l2ServerOpen(BluetoothConnectionNotifierParams params, int receiveMTU, int transmitMTU, ServiceRecordImpl serviceRecord) throws IOException {
/* 466 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void l2ServerUpdateServiceRecord(long handle, ServiceRecordImpl serviceRecord, boolean acceptAndOpen) throws ServiceRegistrationException {
/* 477 */     throw new ServiceRegistrationException("Not Supported on" + getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long l2ServerAcceptAndOpenServerConnection(long handle) throws IOException {
/* 486 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void l2CloseServerConnection(long handle) throws IOException {
/* 495 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void l2ServerClose(long handle, ServiceRecordImpl serviceRecord) throws IOException {
/* 504 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int l2GetSecurityOpt(long handle, int expected) throws IOException {
/* 513 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean l2Ready(long handle) throws IOException {
/* 522 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int l2Receive(long handle, byte[] inBuf) throws IOException {
/* 531 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void l2Send(long handle, byte[] data, int transmitMTU) throws IOException {
/* 540 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int l2GetReceiveMTU(long handle) throws IOException {
/* 549 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int l2GetTransmitMTU(long handle) throws IOException {
/* 558 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long l2RemoteAddress(long handle) throws IOException {
/* 567 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean l2Encrypt(long address, long handle, boolean on) throws IOException {
/* 576 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothStackBlueSoleil.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */