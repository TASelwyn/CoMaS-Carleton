/*    */ package com.intel.bluetooth;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SearchServicesTerminatedException
/*    */   extends SearchServicesException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public SearchServicesTerminatedException() {}
/*    */   
/*    */   public SearchServicesTerminatedException(String s) {
/* 41 */     super(s);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\SearchServicesTerminatedException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */