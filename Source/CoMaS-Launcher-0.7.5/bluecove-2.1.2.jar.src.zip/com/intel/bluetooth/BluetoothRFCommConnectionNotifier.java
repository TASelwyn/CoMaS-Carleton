/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ import javax.bluetooth.ServiceRecord;
/*     */ import javax.bluetooth.ServiceRegistrationException;
/*     */ import javax.microedition.io.StreamConnection;
/*     */ import javax.microedition.io.StreamConnectionNotifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BluetoothRFCommConnectionNotifier
/*     */   extends BluetoothConnectionNotifierBase
/*     */   implements StreamConnectionNotifier
/*     */ {
/*  36 */   private int rfcommChannel = -1;
/*     */ 
/*     */   
/*     */   public BluetoothRFCommConnectionNotifier(BluetoothStack bluetoothStack, BluetoothConnectionNotifierParams params) throws IOException {
/*  40 */     super(bluetoothStack, params);
/*     */     
/*  42 */     this.handle = bluetoothStack.rfServerOpen(params, this.serviceRecord);
/*     */     
/*  44 */     this.rfcommChannel = this.serviceRecord.getChannel(BluetoothConsts.RFCOMM_PROTOCOL_UUID);
/*     */     
/*  46 */     this.serviceRecord.attributeUpdated = false;
/*     */     
/*  48 */     this.securityOpt = Utils.securityOpt(params.authenticate, params.encrypt);
/*     */     
/*  50 */     connectionCreated();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stackServerClose(long handle) throws IOException {
/*  59 */     this.bluetoothStack.rfServerClose(handle, this.serviceRecord);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StreamConnection acceptAndOpen() throws IOException {
/*  69 */     if (this.closed) {
/*  70 */       throw new IOException("Notifier is closed");
/*     */     }
/*  72 */     updateServiceRecord(true);
/*     */     try {
/*  74 */       long clientHandle = this.bluetoothStack.rfServerAcceptAndOpenRfServerConnection(this.handle);
/*  75 */       int clientSecurityOpt = this.bluetoothStack.rfGetSecurityOpt(clientHandle, this.securityOpt);
/*  76 */       return new BluetoothRFCommServerConnection(this.bluetoothStack, clientHandle, clientSecurityOpt);
/*  77 */     } catch (InterruptedIOException e) {
/*  78 */       throw e;
/*  79 */     } catch (IOException e) {
/*  80 */       if (this.closed) {
/*  81 */         throw new InterruptedIOException("Notifier has been closed; " + e.getMessage());
/*     */       }
/*  83 */       throw e;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void validateServiceRecord(ServiceRecord srvRecord) {
/*  88 */     if (this.rfcommChannel != this.serviceRecord.getChannel(BluetoothConsts.RFCOMM_PROTOCOL_UUID)) {
/*  89 */       throw new IllegalArgumentException("Must not change the RFCOMM server channel number");
/*     */     }
/*  91 */     super.validateServiceRecord(srvRecord);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateStackServiceRecord(ServiceRecordImpl serviceRecord, boolean acceptAndOpen) throws ServiceRegistrationException {
/* 102 */     this.bluetoothStack.rfServerUpdateServiceRecord(this.handle, serviceRecord, acceptAndOpen);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothRFCommConnectionNotifier.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */