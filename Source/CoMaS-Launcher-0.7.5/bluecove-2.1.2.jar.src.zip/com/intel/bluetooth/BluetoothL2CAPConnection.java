/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.bluetooth.L2CAPConnection;
/*     */ import javax.bluetooth.RemoteDevice;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BluetoothL2CAPConnection
/*     */   implements L2CAPConnection, BluetoothConnectionAccess
/*     */ {
/*     */   protected BluetoothStack bluetoothStack;
/*     */   protected volatile long handle;
/*     */   protected int transmitMTU;
/*     */   protected int securityOpt;
/*     */   private RemoteDevice remoteDevice;
/*     */   private boolean isClosed;
/*     */   
/*     */   protected BluetoothL2CAPConnection(BluetoothStack bluetoothStack, long handle) {
/*  52 */     this.bluetoothStack = bluetoothStack;
/*  53 */     this.handle = handle;
/*  54 */     this.isClosed = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getRemoteAddress() throws IOException {
/*  63 */     if (this.isClosed) {
/*  64 */       throw new IOException("Connection closed");
/*     */     }
/*  66 */     return this.bluetoothStack.l2RemoteAddress(this.handle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getReceiveMTU() throws IOException {
/*  75 */     if (this.isClosed) {
/*  76 */       throw new IOException("Connection closed");
/*     */     }
/*  78 */     return this.bluetoothStack.l2GetReceiveMTU(this.handle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTransmitMTU() throws IOException {
/*  87 */     if (this.isClosed) {
/*  88 */       throw new IOException("Connection closed");
/*     */     }
/*  90 */     return this.bluetoothStack.l2GetTransmitMTU(this.handle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean ready() throws IOException {
/*  99 */     if (this.isClosed) {
/* 100 */       throw new IOException("Connection closed");
/*     */     }
/* 102 */     return this.bluetoothStack.l2Ready(this.handle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int receive(byte[] inBuf) throws IOException {
/* 111 */     if (this.isClosed) {
/* 112 */       throw new IOException("Connection closed");
/*     */     }
/* 114 */     if (inBuf == null) {
/* 115 */       throw new NullPointerException("inBuf is null");
/*     */     }
/* 117 */     return this.bluetoothStack.l2Receive(this.handle, inBuf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(byte[] data) throws IOException {
/* 126 */     if (this.isClosed) {
/* 127 */       throw new IOException("Connection closed");
/*     */     }
/* 129 */     if (data == null) {
/* 130 */       throw new NullPointerException("data is null");
/*     */     }
/* 132 */     this.bluetoothStack.l2Send(this.handle, data, this.transmitMTU);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void closeConnectionHandle(long paramLong) throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 143 */     if (this.isClosed) {
/*     */       return;
/*     */     }
/*     */     
/* 147 */     this.isClosed = true;
/* 148 */     shutdown();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown() throws IOException {
/* 157 */     if (this.handle != 0L) {
/* 158 */       long synchronizedHandle; DebugLog.debug("closing L2CAP Connection", this.handle);
/*     */ 
/*     */       
/* 161 */       synchronized (this) {
/* 162 */         synchronizedHandle = this.handle;
/* 163 */         this.handle = 0L;
/*     */       } 
/* 165 */       if (synchronizedHandle != 0L) {
/* 166 */         closeConnectionHandle(synchronizedHandle);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void finalize() {
/*     */     try {
/* 173 */       close();
/* 174 */     } catch (IOException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isClosed() {
/* 184 */     return this.isClosed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markAuthenticated() {
/* 193 */     if (this.securityOpt == 0) {
/* 194 */       this.securityOpt = 1;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSecurityOpt() {
/*     */     try {
/* 205 */       this.securityOpt = this.bluetoothStack.l2GetSecurityOpt(this.handle, this.securityOpt);
/* 206 */     } catch (IOException notChanged) {}
/*     */     
/* 208 */     return this.securityOpt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean encrypt(long address, boolean on) throws IOException {
/* 218 */     if (this.isClosed) {
/* 219 */       throw new IOException("L2CAP Connection is already closed");
/*     */     }
/* 221 */     boolean changed = this.bluetoothStack.l2Encrypt(address, this.handle, on);
/* 222 */     if (changed) {
/* 223 */       if (on) {
/* 224 */         this.securityOpt = 2;
/*     */       } else {
/* 226 */         this.securityOpt = 1;
/*     */       } 
/*     */     }
/* 229 */     return changed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RemoteDevice getRemoteDevice() {
/* 238 */     return this.remoteDevice;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRemoteDevice(RemoteDevice remoteDevice) {
/* 247 */     this.remoteDevice = remoteDevice;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BluetoothStack getBluetoothStack() {
/* 256 */     return this.bluetoothStack;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothL2CAPConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */