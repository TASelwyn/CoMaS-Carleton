/*     */ package com.intel.bluetooth.obex;
/*     */ 
/*     */ import com.intel.bluetooth.BluetoothConnectionAccess;
/*     */ import com.intel.bluetooth.BluetoothStack;
/*     */ import com.intel.bluetooth.DebugLog;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ import javax.bluetooth.RemoteDevice;
/*     */ import javax.microedition.io.Connection;
/*     */ import javax.microedition.io.StreamConnection;
/*     */ import javax.obex.Authenticator;
/*     */ import javax.obex.HeaderSet;
/*     */ import javax.obex.ServerRequestHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class OBEXSessionBase
/*     */   implements Connection, BluetoothConnectionAccess
/*     */ {
/*     */   protected boolean isConnected;
/*     */   private StreamConnection conn;
/*     */   private InputStream is;
/*     */   private OutputStream os;
/*     */   protected long connectionID;
/*  65 */   protected int mtu = 1024;
/*     */ 
/*     */   
/*     */   protected Authenticator authenticator;
/*     */ 
/*     */   
/*     */   protected final OBEXConnectionParams obexConnectionParams;
/*     */   
/*     */   protected int packetsCountWrite;
/*     */   
/*     */   protected int packetsCountRead;
/*     */   
/*     */   private Vector authChallengesSent;
/*     */   
/*     */   protected boolean requestSent;
/*     */ 
/*     */   
/*     */   public OBEXSessionBase(StreamConnection conn, OBEXConnectionParams obexConnectionParams) throws IOException {
/*  83 */     if (obexConnectionParams == null) {
/*  84 */       throw new NullPointerException("obexConnectionParams is null");
/*     */     }
/*  86 */     this.isConnected = false;
/*  87 */     this.conn = conn;
/*  88 */     this.obexConnectionParams = obexConnectionParams;
/*  89 */     this.mtu = obexConnectionParams.mtu;
/*  90 */     this.connectionID = -1L;
/*  91 */     this.packetsCountWrite = 0;
/*  92 */     this.packetsCountRead = 0;
/*  93 */     boolean initOK = false;
/*     */     try {
/*  95 */       this.os = conn.openOutputStream();
/*  96 */       this.is = conn.openInputStream();
/*  97 */       initOK = true;
/*     */     } finally {
/*  99 */       if (!initOK) {
/*     */         try {
/* 101 */           close();
/* 102 */         } catch (IOException e) {
/* 103 */           DebugLog.error("close error", e);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 110 */     StreamConnection c = this.conn;
/* 111 */     this.conn = null;
/*     */     try {
/*     */       try {
/* 114 */         if (this.is != null) {
/* 115 */           this.is.close();
/* 116 */           this.is = null;
/*     */         } 
/*     */       } finally {
/*     */         
/* 120 */         if (this.os != null) {
/* 121 */           this.os.close();
/* 122 */           this.os = null;
/*     */         } 
/*     */       } 
/*     */     } finally {
/*     */       
/* 127 */       if (c != null) {
/* 128 */         c.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static OBEXHeaderSetImpl createOBEXHeaderSetImpl() {
/* 135 */     return new OBEXHeaderSetImpl();
/*     */   }
/*     */   
/*     */   public static HeaderSet createOBEXHeaderSet() {
/* 139 */     return createOBEXHeaderSetImpl();
/*     */   }
/*     */   
/*     */   static void validateCreatedHeaderSet(HeaderSet headers) {
/* 143 */     OBEXHeaderSetImpl.validateCreatedHeaderSet(headers);
/*     */   }
/*     */   
/*     */   protected void writePacket(int commId, OBEXHeaderSetImpl headers) throws IOException {
/* 147 */     writePacketWithFlags(commId, null, headers);
/*     */   }
/*     */   
/*     */   protected synchronized void writePacketWithFlags(int commId, byte[] headerFlagsData, OBEXHeaderSetImpl headers) throws IOException {
/* 151 */     if (this.requestSent) {
/* 152 */       throw new IOException("Write packet out of order");
/*     */     }
/* 154 */     this.requestSent = true;
/* 155 */     int len = 3;
/* 156 */     if (this.connectionID != -1L) {
/* 157 */       len += 5;
/*     */     }
/* 159 */     if (headerFlagsData != null) {
/* 160 */       len += headerFlagsData.length;
/*     */     }
/* 162 */     byte[] data = null;
/* 163 */     if (headers != null) {
/* 164 */       data = OBEXHeaderSetImpl.toByteArray(headers);
/* 165 */       len += data.length;
/*     */     } 
/* 167 */     if (len > this.mtu) {
/* 168 */       throw new IOException("Can't sent more data than in MTU, len=" + len + ", mtu=" + this.mtu);
/*     */     }
/* 170 */     this.packetsCountWrite++;
/* 171 */     ByteArrayOutputStream buf = new ByteArrayOutputStream();
/* 172 */     OBEXHeaderSetImpl.writeObexLen(buf, commId, len);
/* 173 */     if (headerFlagsData != null) {
/* 174 */       buf.write(headerFlagsData);
/*     */     }
/* 176 */     if (this.connectionID != -1L) {
/* 177 */       OBEXHeaderSetImpl.writeObexInt(buf, 203, this.connectionID);
/*     */     }
/* 179 */     if (data != null) {
/* 180 */       buf.write(data);
/*     */     }
/* 182 */     DebugLog.debug0x("obex send (" + this.packetsCountWrite + ")", OBEXUtils.toStringObexResponseCodes(commId), commId);
/* 183 */     this.os.write(buf.toByteArray());
/* 184 */     this.os.flush();
/* 185 */     DebugLog.debug("obex sent (" + this.packetsCountWrite + ") len", len);
/*     */     
/* 187 */     if (headers != null && headers.hasAuthenticationChallenge()) {
/* 188 */       if (this.authChallengesSent == null) {
/* 189 */         this.authChallengesSent = new Vector();
/*     */       }
/* 191 */       for (Enumeration iter = headers.getAuthenticationChallenges(); iter.hasMoreElements(); ) {
/* 192 */         byte[] authChallenge = iter.nextElement();
/* 193 */         OBEXAuthentication.Challenge challenge = new OBEXAuthentication.Challenge(authChallenge);
/* 194 */         this.authChallengesSent.addElement(challenge);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected synchronized byte[] readPacket() throws IOException {
/* 200 */     if (!this.requestSent) {
/* 201 */       throw new IOException("Read packet out of order");
/*     */     }
/* 203 */     this.requestSent = false;
/* 204 */     byte[] header = new byte[3];
/* 205 */     OBEXUtils.readFully(this.is, this.obexConnectionParams, header);
/* 206 */     this.packetsCountRead++;
/* 207 */     DebugLog.debug0x("obex received (" + this.packetsCountRead + ")", OBEXUtils.toStringObexResponseCodes(header[0]), (header[0] & 0xFF));
/* 208 */     int lenght = OBEXUtils.bytesToShort(header[1], header[2]);
/* 209 */     if (lenght == 3) {
/* 210 */       return header;
/*     */     }
/* 212 */     if (lenght < 3 || lenght > 65535) {
/* 213 */       throw new IOException("Invalid packet length " + lenght);
/*     */     }
/* 215 */     byte[] data = new byte[lenght];
/* 216 */     System.arraycopy(header, 0, data, 0, header.length);
/* 217 */     OBEXUtils.readFully(this.is, this.obexConnectionParams, data, header.length, lenght - header.length);
/* 218 */     if (this.is.available() > 0) {
/* 219 */       DebugLog.debug("has more data after read", this.is.available());
/*     */     }
/* 221 */     return data;
/*     */   }
/*     */   
/*     */   private void validateBluetoothConnection() {
/* 225 */     if (this.conn != null && !(this.conn instanceof BluetoothConnectionAccess)) {
/* 226 */       throw new IllegalArgumentException("Not a Bluetooth connection " + this.conn.getClass().getName());
/*     */     }
/*     */   }
/*     */   
/*     */   void validateAuthenticationResponse(OBEXHeaderSetImpl requestHeaders, OBEXHeaderSetImpl incomingHeaders) throws IOException {
/* 231 */     if (requestHeaders != null && requestHeaders.hasAuthenticationChallenge() && !incomingHeaders.hasAuthenticationResponses())
/*     */     {
/* 233 */       throw new IOException("Authentication response is missing");
/*     */     }
/* 235 */     handleAuthenticationResponse(incomingHeaders, null);
/*     */   }
/*     */   
/*     */   boolean handleAuthenticationResponse(OBEXHeaderSetImpl incomingHeaders, ServerRequestHandler serverHandler) throws IOException {
/* 239 */     if (incomingHeaders.hasAuthenticationResponses()) {
/* 240 */       if (this.authenticator == null) {
/* 241 */         throw new IOException("Authenticator required for authentication");
/*     */       }
/* 243 */       if (this.authChallengesSent == null && this.authChallengesSent.size() == 0) {
/* 244 */         throw new IOException("Authentication challenges had not been sent");
/*     */       }
/* 246 */       boolean authenticated = false;
/*     */       try {
/* 248 */         authenticated = OBEXAuthentication.handleAuthenticationResponse(incomingHeaders, this.authenticator, serverHandler, this.authChallengesSent);
/*     */       } finally {
/* 250 */         if (authenticated && this.authChallengesSent != null) {
/* 251 */           this.authChallengesSent.removeAllElements();
/*     */         }
/*     */       } 
/* 254 */       return authenticated;
/*     */     } 
/* 256 */     if (this.authChallengesSent != null && this.authChallengesSent.size() > 0) {
/* 257 */       throw new IOException("Authentication response is missing");
/*     */     }
/* 259 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   void handleAuthenticationChallenge(OBEXHeaderSetImpl incomingHeaders, OBEXHeaderSetImpl replyHeaders) throws IOException {
/* 264 */     if (incomingHeaders.hasAuthenticationChallenge()) {
/* 265 */       if (this.authenticator == null) {
/* 266 */         throw new IOException("Authenticator required for authentication");
/*     */       }
/* 268 */       OBEXAuthentication.handleAuthenticationChallenge(incomingHeaders, replyHeaders, this.authenticator);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getRemoteAddress() throws IOException {
/* 278 */     validateBluetoothConnection();
/* 279 */     if (this.conn == null) {
/* 280 */       throw new IOException("Connection closed");
/*     */     }
/* 282 */     return ((BluetoothConnectionAccess)this.conn).getRemoteAddress();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RemoteDevice getRemoteDevice() {
/* 291 */     validateBluetoothConnection();
/* 292 */     if (this.conn == null) {
/* 293 */       return null;
/*     */     }
/* 295 */     return ((BluetoothConnectionAccess)this.conn).getRemoteDevice();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isClosed() {
/* 304 */     if (this.conn == null) {
/* 305 */       return true;
/*     */     }
/* 307 */     if (this.conn instanceof BluetoothConnectionAccess) {
/* 308 */       return ((BluetoothConnectionAccess)this.conn).isClosed();
/*     */     }
/* 310 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown() throws IOException {
/* 320 */     if (this.conn instanceof BluetoothConnectionAccess) {
/* 321 */       ((BluetoothConnectionAccess)this.conn).shutdown();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markAuthenticated() {
/* 331 */     validateBluetoothConnection();
/* 332 */     if (this.conn != null) {
/* 333 */       ((BluetoothConnectionAccess)this.conn).markAuthenticated();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSecurityOpt() {
/* 343 */     validateBluetoothConnection();
/* 344 */     if (this.conn == null) {
/* 345 */       return 0;
/*     */     }
/* 347 */     return ((BluetoothConnectionAccess)this.conn).getSecurityOpt();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean encrypt(long address, boolean on) throws IOException {
/* 357 */     validateBluetoothConnection();
/* 358 */     if (this.conn == null) {
/* 359 */       throw new IOException("Connection closed");
/*     */     }
/* 361 */     return ((BluetoothConnectionAccess)this.conn).encrypt(address, on);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRemoteDevice(RemoteDevice remoteDevice) {
/* 371 */     validateBluetoothConnection();
/* 372 */     if (this.conn != null) {
/* 373 */       ((BluetoothConnectionAccess)this.conn).setRemoteDevice(remoteDevice);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BluetoothStack getBluetoothStack() {
/* 383 */     validateBluetoothConnection();
/* 384 */     if (this.conn == null) {
/* 385 */       return null;
/*     */     }
/* 387 */     return ((BluetoothConnectionAccess)this.conn).getBluetoothStack();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getPacketsCountWrite() {
/* 396 */     return this.packetsCountWrite;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getPacketsCountRead() {
/* 405 */     return this.packetsCountRead;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getPacketSize() {
/* 414 */     if (this.isConnected) {
/* 415 */       return this.mtu;
/*     */     }
/* 417 */     return this.obexConnectionParams.mtu;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setPacketSize(int mtu) throws IOException {
/* 428 */     if (this.isConnected) {
/* 429 */       throw new IOException("Session already connected");
/*     */     }
/* 431 */     this.obexConnectionParams.mtu = mtu;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXSessionBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */