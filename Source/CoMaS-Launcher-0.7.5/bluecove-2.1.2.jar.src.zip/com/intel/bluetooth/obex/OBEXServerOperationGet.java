/*     */ package com.intel.bluetooth.obex;
/*     */ 
/*     */ import com.intel.bluetooth.DebugLog;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.obex.HeaderSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OBEXServerOperationGet
/*     */   extends OBEXServerOperation
/*     */   implements OBEXOperationDelivery, OBEXOperationReceive
/*     */ {
/*     */   protected OBEXServerOperationGet(OBEXServerSessionImpl session, OBEXHeaderSetImpl receivedHeaders, boolean finalPacket) throws IOException {
/*  40 */     super(session, receivedHeaders);
/*  41 */     if (finalPacket) {
/*  42 */       this.requestEnded = true;
/*  43 */       this.finalPacketReceived = true;
/*     */     } 
/*  45 */     this.inputStream = new OBEXOperationInputStream(this);
/*  46 */     processIncommingData(receivedHeaders, finalPacket);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream openInputStream() throws IOException {
/*  55 */     if (this.isClosed) {
/*  56 */       throw new IOException("operation closed");
/*     */     }
/*  58 */     if (this.inputStreamOpened) {
/*  59 */       throw new IOException("input stream already open");
/*     */     }
/*  61 */     this.inputStreamOpened = true;
/*  62 */     return this.inputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream openOutputStream() throws IOException {
/*  71 */     if (this.isClosed) {
/*  72 */       throw new IOException("operation closed");
/*     */     }
/*  74 */     if (this.outputStream != null) {
/*  75 */       throw new IOException("output stream already open");
/*     */     }
/*  77 */     this.requestEnded = true;
/*  78 */     this.outputStream = new OBEXOperationOutputStream(this.session.mtu, this);
/*  79 */     this.session.writePacket(144, this.sendHeaders);
/*  80 */     this.sendHeaders = null;
/*  81 */     return this.outputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  90 */     if (this.outputStream != null) {
/*  91 */       this.outputStream.close();
/*  92 */       this.outputStream = null;
/*     */     } 
/*  94 */     this.inputStream.close();
/*  95 */     super.close();
/*     */   }
/*     */   protected boolean readRequestPacket() throws IOException {
/*     */     HeaderSet requestHeaders;
/*  99 */     byte[] b = this.session.readPacket();
/* 100 */     int opcode = b[0] & 0xFF;
/* 101 */     boolean finalPacket = ((opcode & 0x80) != 0);
/* 102 */     if (finalPacket) {
/* 103 */       DebugLog.debug("server operation got final packet");
/* 104 */       this.finalPacketReceived = true;
/*     */     } 
/* 106 */     switch (opcode)
/*     */     { case 3:
/*     */       case 131:
/* 109 */         if (finalPacket) {
/* 110 */           this.requestEnded = true;
/*     */         }
/* 112 */         requestHeaders = OBEXHeaderSetImpl.readHeaders(b[0], b, 3);
/* 113 */         OBEXHeaderSetImpl.appendHeaders(this.receivedHeaders, requestHeaders);
/* 114 */         processIncommingData(requestHeaders, finalPacket);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 124 */         return finalPacket;case 255: processAbort(); return finalPacket; }  this.errorReceived = true; DebugLog.debug0x("server operation invalid request", OBEXUtils.toStringObexResponseCodes(opcode), opcode); this.session.writePacket(192, null); return finalPacket;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receiveData(OBEXOperationInputStream is) throws IOException {
/* 133 */     if (this.requestEnded || this.errorReceived) {
/* 134 */       this.inputStream.appendData(null, true);
/*     */       return;
/*     */     } 
/* 137 */     DebugLog.debug("server operation reply continue");
/* 138 */     this.session.writePacket(144, this.sendHeaders);
/* 139 */     this.sendHeaders = null;
/* 140 */     readRequestPacket();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deliverPacket(boolean finalPacket, byte[] buffer) throws IOException {
/* 149 */     if (this.session.requestSent) {
/*     */       
/* 151 */       readRequestPacket();
/* 152 */       if (this.session.requestSent) {
/* 153 */         throw new IOException("Client not requesting data");
/*     */       }
/*     */     } 
/* 156 */     OBEXHeaderSetImpl dataHeaders = OBEXSessionBase.createOBEXHeaderSetImpl();
/* 157 */     int opcode = 144;
/* 158 */     int dataHeaderID = 72;
/* 159 */     if (finalPacket)
/*     */     {
/* 161 */       dataHeaderID = 73;
/*     */     }
/* 163 */     dataHeaders.setHeader(dataHeaderID, buffer);
/* 164 */     if (this.sendHeaders != null) {
/* 165 */       OBEXHeaderSetImpl.appendHeaders(dataHeaders, this.sendHeaders);
/* 166 */       this.sendHeaders = null;
/*     */     } 
/* 168 */     this.session.writePacket(opcode, dataHeaders);
/* 169 */     readRequestPacket();
/*     */   }
/*     */ 
/*     */   
/*     */   private void processAbort() throws IOException {
/* 174 */     this.finalPacketReceived = true;
/* 175 */     this.requestEnded = true;
/* 176 */     this.isAborted = true;
/* 177 */     this.session.writePacket(160, null);
/* 178 */     throw new IOException("Operation aborted");
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXServerOperationGet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */