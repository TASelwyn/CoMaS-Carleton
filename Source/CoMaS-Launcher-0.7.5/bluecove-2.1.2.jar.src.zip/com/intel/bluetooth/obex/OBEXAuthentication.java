/*     */ package com.intel.bluetooth.obex;
/*     */ 
/*     */ import com.intel.bluetooth.DebugLog;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ import javax.obex.Authenticator;
/*     */ import javax.obex.PasswordAuthentication;
/*     */ import javax.obex.ServerRequestHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OBEXAuthentication
/*     */ {
/*     */   private static byte[] privateKey;
/*  43 */   private static long uniqueTimestamp = 0L;
/*     */   
/*  45 */   private static final byte[] COLUMN = new byte[] { 58 };
/*     */ 
/*     */   
/*     */   static class Challenge
/*     */   {
/*     */     private String realm;
/*     */     
/*     */     private boolean isUserIdRequired;
/*     */     
/*     */     private boolean isFullAccess;
/*     */     byte[] nonce;
/*     */     
/*     */     Challenge(byte[] data) throws IOException {
/*  58 */       read(data);
/*     */     }
/*     */     
/*     */     Challenge(String realm, boolean isUserIdRequired, boolean isFullAccess, byte[] nonce) {
/*  62 */       this.realm = realm;
/*  63 */       this.isUserIdRequired = isUserIdRequired;
/*  64 */       this.isFullAccess = isFullAccess;
/*  65 */       this.nonce = nonce;
/*     */     }
/*     */     
/*     */     byte[] write() {
/*  69 */       ByteArrayOutputStream buf = new ByteArrayOutputStream();
/*     */       
/*  71 */       buf.write(0);
/*  72 */       buf.write(16);
/*  73 */       buf.write(this.nonce, 0, 16);
/*     */       
/*  75 */       byte options = (byte)((this.isUserIdRequired ? 1 : 0) | (!this.isFullAccess ? 2 : 0));
/*  76 */       buf.write(1);
/*  77 */       buf.write(1);
/*  78 */       buf.write(options);
/*     */       
/*  80 */       if (this.realm != null) {
/*     */         byte[] arrayOfByte;
/*     */         boolean bool;
/*     */         try {
/*  84 */           arrayOfByte = OBEXUtils.getUTF16Bytes(this.realm);
/*  85 */           bool = true;
/*  86 */         } catch (UnsupportedEncodingException e) {
/*     */           try {
/*  88 */             arrayOfByte = this.realm.getBytes("iso-8859-1");
/*  89 */           } catch (UnsupportedEncodingException e1) {
/*  90 */             arrayOfByte = new byte[0];
/*     */           } 
/*  92 */           bool = true;
/*     */         } 
/*  94 */         buf.write(2);
/*  95 */         buf.write(arrayOfByte.length + 1);
/*  96 */         buf.write(bool);
/*  97 */         buf.write(arrayOfByte, 0, arrayOfByte.length);
/*     */       } 
/*     */       
/* 100 */       return buf.toByteArray();
/*     */     }
/*     */     
/*     */     void read(byte[] data) throws IOException {
/* 104 */       DebugLog.debug("authChallenge", data);
/* 105 */       for (int i = 0; i < data.length; ) {
/* 106 */         byte options; int charSetCode; byte[] chars; int tag = data[i] & 0xFF;
/* 107 */         int len = data[i + 1] & 0xFF;
/* 108 */         i += 2;
/* 109 */         switch (tag) {
/*     */           case 0:
/* 111 */             if (len != 16) {
/* 112 */               throw new IOException("OBEX Digest Challenge error in tag Nonce");
/*     */             }
/* 114 */             this.nonce = new byte[16];
/* 115 */             System.arraycopy(data, i, this.nonce, 0, 16);
/*     */             break;
/*     */           case 1:
/* 118 */             options = data[i];
/* 119 */             DebugLog.debug("authChallenge options", options);
/* 120 */             this.isUserIdRequired = ((options & 0x1) != 0);
/* 121 */             this.isFullAccess = ((options & 0x2) == 0);
/*     */             break;
/*     */           case 2:
/* 124 */             charSetCode = data[i] & 0xFF;
/* 125 */             chars = new byte[len - 1];
/* 126 */             System.arraycopy(data, i + 1, chars, 0, chars.length);
/* 127 */             if (charSetCode == 255) {
/* 128 */               this.realm = OBEXUtils.newStringUTF16(chars); break;
/* 129 */             }  if (charSetCode == 0) {
/* 130 */               this.realm = new String(chars, "ASCII"); break;
/* 131 */             }  if (charSetCode <= 9) {
/* 132 */               this.realm = new String(chars, "ISO-8859-" + charSetCode); break;
/*     */             } 
/* 134 */             DebugLog.error("Unsupported charset code " + charSetCode + " in Challenge");
/*     */ 
/*     */ 
/*     */             
/* 138 */             this.realm = new String(chars, 0, len - 1, "ASCII");
/*     */             break;
/*     */           
/*     */           default:
/* 142 */             DebugLog.error("invalid authChallenge tag " + tag); break;
/*     */         } 
/* 144 */         i += len;
/*     */       } 
/*     */     }
/*     */     
/*     */     public boolean isUserIdRequired() {
/* 149 */       return this.isUserIdRequired;
/*     */     }
/*     */     
/*     */     public boolean isFullAccess() {
/* 153 */       return this.isFullAccess;
/*     */     }
/*     */     
/*     */     public String getRealm() {
/* 157 */       return this.realm;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class DigestResponse
/*     */   {
/*     */     byte[] requestDigest;
/*     */     
/*     */     byte[] userName;
/*     */     
/*     */     byte[] nonce;
/*     */     
/*     */     byte[] write() {
/* 171 */       ByteArrayOutputStream buf = new ByteArrayOutputStream();
/*     */       
/* 173 */       buf.write(0);
/* 174 */       buf.write(16);
/* 175 */       buf.write(this.requestDigest, 0, 16);
/*     */       
/* 177 */       if (this.userName != null) {
/* 178 */         buf.write(1);
/* 179 */         buf.write(this.userName.length);
/* 180 */         buf.write(this.userName, 0, this.userName.length);
/*     */       } 
/*     */       
/* 183 */       buf.write(2);
/* 184 */       buf.write(16);
/* 185 */       buf.write(this.nonce, 0, 16);
/*     */       
/* 187 */       return buf.toByteArray();
/*     */     }
/*     */     
/*     */     void read(byte[] data) throws IOException {
/* 191 */       for (int i = 0; i < data.length; ) {
/* 192 */         int tag = data[i] & 0xFF;
/* 193 */         int len = data[i + 1] & 0xFF;
/* 194 */         i += 2;
/* 195 */         switch (tag) {
/*     */           case 0:
/* 197 */             if (len != 16) {
/* 198 */               throw new IOException("OBEX Digest Response error in tag request-digest");
/*     */             }
/* 200 */             this.requestDigest = new byte[16];
/* 201 */             System.arraycopy(data, i, this.requestDigest, 0, 16);
/*     */             break;
/*     */           case 1:
/* 204 */             this.userName = new byte[len];
/* 205 */             System.arraycopy(data, i, this.userName, 0, this.userName.length);
/*     */             break;
/*     */           case 2:
/* 208 */             if (len != 16) {
/* 209 */               throw new IOException("OBEX Digest Response error in tag Nonce");
/*     */             }
/* 211 */             this.nonce = new byte[16];
/* 212 */             System.arraycopy(data, i, this.nonce, 0, 16);
/*     */             break;
/*     */         } 
/* 215 */         i += len;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static byte[] createChallenge(String realm, boolean isUserIdRequired, boolean isFullAccess) {
/* 221 */     Challenge challenge = new Challenge(realm, isUserIdRequired, isFullAccess, createNonce());
/* 222 */     return challenge.write();
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean handleAuthenticationResponse(OBEXHeaderSetImpl incomingHeaders, Authenticator authenticator, ServerRequestHandler serverHandler, Vector authChallengesSent) throws IOException {
/* 227 */     if (!incomingHeaders.hasAuthenticationResponses()) {
/* 228 */       return false;
/*     */     }
/* 230 */     for (Enumeration iter = incomingHeaders.getAuthenticationResponses(); iter.hasMoreElements(); ) {
/* 231 */       byte[] authResponse = iter.nextElement();
/* 232 */       DigestResponse dr = new DigestResponse();
/* 233 */       dr.read(authResponse);
/* 234 */       DebugLog.debug("got nonce", dr.nonce);
/*     */ 
/*     */       
/* 237 */       Challenge challengeSent = null;
/* 238 */       for (Enumeration challengeIter = authChallengesSent.elements(); challengeIter.hasMoreElements(); ) {
/* 239 */         Challenge c = challengeIter.nextElement();
/* 240 */         if (equals(c.nonce, dr.nonce)) {
/* 241 */           challengeSent = c;
/*     */           break;
/*     */         } 
/*     */       } 
/* 245 */       if (challengeSent == null) {
/* 246 */         throw new IOException("Authentication response for unknown challenge");
/*     */       }
/*     */       
/* 249 */       byte[] password = authenticator.onAuthenticationResponse(dr.userName);
/* 250 */       if (password == null) {
/* 251 */         throw new IOException("Authentication request failed, password is not supplied");
/*     */       }
/*     */ 
/*     */       
/* 255 */       MD5DigestWrapper md5 = new MD5DigestWrapper();
/* 256 */       md5.update(dr.nonce);
/* 257 */       md5.update(COLUMN);
/* 258 */       md5.update(password);
/* 259 */       byte[] claulated = md5.digest();
/* 260 */       if (!equals(dr.requestDigest, claulated)) {
/* 261 */         DebugLog.debug("got digest", dr.requestDigest);
/* 262 */         DebugLog.debug("  expected", claulated);
/* 263 */         if (serverHandler != null) {
/* 264 */           serverHandler.onAuthenticationFailure(dr.userName); continue;
/*     */         } 
/* 266 */         throw new IOException("Authentication failure");
/*     */       } 
/*     */       
/* 269 */       return true;
/*     */     } 
/*     */     
/* 272 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   static void handleAuthenticationChallenge(OBEXHeaderSetImpl incomingHeaders, OBEXHeaderSetImpl replyHeaders, Authenticator authenticator) throws IOException {
/* 277 */     if (!incomingHeaders.hasAuthenticationChallenge()) {
/*     */       return;
/*     */     }
/* 280 */     for (Enumeration iter = incomingHeaders.getAuthenticationChallenges(); iter.hasMoreElements(); ) {
/* 281 */       byte[] authChallenge = iter.nextElement();
/* 282 */       Challenge challenge = new Challenge(authChallenge);
/* 283 */       PasswordAuthentication pwd = authenticator.onAuthenticationChallenge(challenge.getRealm(), challenge.isUserIdRequired(), challenge.isFullAccess());
/*     */       
/* 285 */       DigestResponse dr = new DigestResponse();
/* 286 */       dr.nonce = challenge.nonce;
/* 287 */       DebugLog.debug("got nonce", dr.nonce);
/* 288 */       if (challenge.isUserIdRequired()) {
/* 289 */         dr.userName = pwd.getUserName();
/*     */       }
/* 291 */       MD5DigestWrapper md5 = new MD5DigestWrapper();
/* 292 */       md5.update(dr.nonce);
/* 293 */       md5.update(COLUMN);
/* 294 */       md5.update(pwd.getPassword());
/* 295 */       dr.requestDigest = md5.digest();
/*     */ 
/*     */       
/* 298 */       DebugLog.debug("send digest", dr.requestDigest);
/* 299 */       replyHeaders.addAuthenticationResponse(dr.write());
/*     */     } 
/*     */   }
/*     */   
/*     */   private static synchronized byte[] createNonce() {
/* 304 */     MD5DigestWrapper md5 = new MD5DigestWrapper();
/* 305 */     md5.update(createTimestamp());
/* 306 */     md5.update(COLUMN);
/* 307 */     md5.update(getPrivateKey());
/* 308 */     return md5.digest();
/*     */   }
/*     */   
/*     */   static boolean equals(byte[] digest1, byte[] digest2) {
/* 312 */     for (int i = 0; i < 16; i++) {
/* 313 */       if (digest1[i] != digest2[i]) {
/* 314 */         return false;
/*     */       }
/*     */     } 
/* 317 */     return true;
/*     */   }
/*     */   
/*     */   private static synchronized byte[] getPrivateKey() {
/* 321 */     if (privateKey != null) {
/* 322 */       return privateKey;
/*     */     }
/* 324 */     MD5DigestWrapper md5 = new MD5DigestWrapper();
/* 325 */     md5.update(createTimestamp());
/* 326 */     privateKey = md5.digest();
/* 327 */     return privateKey;
/*     */   }
/*     */   
/*     */   private static synchronized byte[] createTimestamp() {
/* 331 */     long t = System.currentTimeMillis();
/* 332 */     if (t <= uniqueTimestamp) {
/* 333 */       t = uniqueTimestamp + 1L;
/*     */     }
/* 335 */     uniqueTimestamp = t;
/* 336 */     byte[] buf = new byte[8];
/* 337 */     for (int i = 0; i < buf.length; i++) {
/* 338 */       buf[i] = (byte)(int)(t >> buf.length - 1 << 3);
/* 339 */       t <<= 8L;
/*     */     } 
/* 341 */     return buf;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXAuthentication.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */