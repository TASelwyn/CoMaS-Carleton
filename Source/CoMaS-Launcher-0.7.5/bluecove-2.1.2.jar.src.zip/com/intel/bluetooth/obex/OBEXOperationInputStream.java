/*     */ package com.intel.bluetooth.obex;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OBEXOperationInputStream
/*     */   extends InputStream
/*     */ {
/*     */   private final OBEXOperation operation;
/*     */   private byte[] buffer;
/*     */   private int readPos;
/*     */   private int appendPos;
/*     */   private Object lock;
/*     */   private boolean isClosed;
/*     */   private boolean eofReceived;
/*     */   
/*     */   OBEXOperationInputStream(OBEXOperation op) {
/*  37 */     this.buffer = new byte[256];
/*     */     
/*  39 */     this.readPos = 0;
/*     */     
/*  41 */     this.appendPos = 0;
/*     */     
/*  43 */     this.lock = new Object();
/*     */     
/*  45 */     this.isClosed = false;
/*     */     
/*  47 */     this.eofReceived = false;
/*     */     this.operation = op;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/*  55 */     if (this.isClosed) {
/*  56 */       throw new IOException("Stream closed");
/*     */     }
/*  58 */     if (this.operation.isClosed() && this.appendPos == this.readPos) {
/*  59 */       return -1;
/*     */     }
/*  61 */     synchronized (this.lock) {
/*     */       
/*  63 */       while (!this.eofReceived && this.operation instanceof OBEXOperationReceive && !this.isClosed && !this.operation.isClosed() && this.appendPos == this.readPos) {
/*  64 */         ((OBEXOperationReceive)this.operation).receiveData(this);
/*     */       }
/*  66 */       if (this.appendPos == this.readPos) {
/*  67 */         return -1;
/*     */       }
/*  69 */       return this.buffer[this.readPos++] & 0xFF;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/*  79 */     synchronized (this.lock) {
/*  80 */       return this.appendPos - this.readPos;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  90 */     this.isClosed = true;
/*  91 */     synchronized (this.lock) {
/*  92 */       this.lock.notifyAll();
/*     */     } 
/*     */   }
/*     */   
/*     */   void appendData(byte[] b, boolean eof) {
/*  97 */     if (this.isClosed || this.eofReceived) {
/*     */       return;
/*     */     }
/* 100 */     synchronized (this.lock) {
/* 101 */       if (eof) {
/* 102 */         this.eofReceived = true;
/*     */       }
/* 104 */       if (b != null && b.length != 0) {
/* 105 */         if (this.appendPos + b.length > this.buffer.length) {
/* 106 */           int newSize = (b.length + this.appendPos - this.readPos) * 2;
/* 107 */           if (newSize < this.buffer.length) {
/* 108 */             newSize = this.buffer.length;
/*     */           }
/* 110 */           byte[] newBuffer = new byte[newSize];
/* 111 */           System.arraycopy(this.buffer, this.readPos, newBuffer, 0, this.appendPos - this.readPos);
/* 112 */           this.buffer = newBuffer;
/* 113 */           this.appendPos -= this.readPos;
/* 114 */           this.readPos = 0;
/*     */         } 
/* 116 */         System.arraycopy(b, 0, this.buffer, this.appendPos, b.length);
/* 117 */         this.appendPos += b.length;
/*     */       } 
/* 119 */       this.lock.notifyAll();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXOperationInputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */