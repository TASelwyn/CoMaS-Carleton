/*     */ package com.intel.bluetooth.obex;
/*     */ 
/*     */ import com.intel.bluetooth.DebugLog;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OBEXServerOperationPut
/*     */   extends OBEXServerOperation
/*     */   implements OBEXOperationReceive, OBEXOperationDelivery
/*     */ {
/*     */   protected OBEXServerOperationPut(OBEXServerSessionImpl session, OBEXHeaderSetImpl receivedHeaders, boolean finalPacket) throws IOException {
/*  39 */     super(session, receivedHeaders);
/*  40 */     this.inputStream = new OBEXOperationInputStream(this);
/*  41 */     processIncommingData(receivedHeaders, finalPacket);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream openInputStream() throws IOException {
/*  50 */     if (this.isClosed) {
/*  51 */       throw new IOException("operation closed");
/*     */     }
/*  53 */     if (this.inputStreamOpened) {
/*  54 */       throw new IOException("input stream already open");
/*     */     }
/*  56 */     DebugLog.debug("openInputStream");
/*  57 */     this.inputStreamOpened = true;
/*  58 */     return this.inputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream openOutputStream() throws IOException {
/*  67 */     if (this.isClosed) {
/*  68 */       throw new IOException("operation closed");
/*     */     }
/*  70 */     if (this.outputStream != null) {
/*  71 */       throw new IOException("output stream already open");
/*     */     }
/*  73 */     this.outputStream = new OBEXOperationOutputStream(this.session.mtu, this);
/*  74 */     return this.outputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  83 */     DebugLog.debug("server close put operation");
/*  84 */     if (this.inputStream != null) {
/*  85 */       this.inputStream.close();
/*  86 */       this.inputStream = null;
/*     */     } 
/*  88 */     if (this.outputStream != null) {
/*  89 */       this.outputStream.close();
/*  90 */       this.outputStream = null;
/*     */     } 
/*  92 */     super.close();
/*     */   }
/*     */   protected boolean readRequestPacket() throws IOException {
/*     */     OBEXHeaderSetImpl requestHeaders;
/*  96 */     byte[] b = this.session.readPacket();
/*  97 */     int opcode = b[0] & 0xFF;
/*  98 */     boolean finalPacket = ((opcode & 0x80) != 0);
/*  99 */     if (finalPacket) {
/* 100 */       DebugLog.debug("server operation got final packet");
/* 101 */       this.finalPacketReceived = true;
/*     */     } 
/* 103 */     switch (opcode)
/*     */     { case 2:
/*     */       case 130:
/* 106 */         requestHeaders = OBEXHeaderSetImpl.readHeaders(b[0], b, 3);
/* 107 */         if (!this.session.handleAuthenticationResponse(requestHeaders)) {
/* 108 */           this.errorReceived = true;
/* 109 */           this.session.writePacket(193, null);
/*     */         } else {
/* 111 */           OBEXHeaderSetImpl.appendHeaders(this.receivedHeaders, requestHeaders);
/* 112 */           processIncommingData(requestHeaders, finalPacket);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 123 */         return finalPacket;case 255: processAbort(); return finalPacket; }  this.errorReceived = true; DebugLog.debug0x("server operation invalid request", OBEXUtils.toStringObexResponseCodes(opcode), opcode); this.session.writePacket(192, null); return finalPacket;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receiveData(OBEXOperationInputStream is) throws IOException {
/* 132 */     if (this.finalPacketReceived || this.errorReceived) {
/* 133 */       is.appendData(null, true);
/*     */       return;
/*     */     } 
/* 136 */     DebugLog.debug("server operation reply continue");
/* 137 */     this.session.writePacket(144, this.sendHeaders);
/* 138 */     this.sendHeaders = null;
/* 139 */     readRequestPacket();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deliverPacket(boolean finalPacket, byte[] buffer) throws IOException {
/* 148 */     if (this.session.requestSent) {
/*     */       
/* 150 */       readRequestPacket();
/* 151 */       if (this.session.requestSent) {
/* 152 */         throw new IOException("Client not requesting data");
/*     */       }
/*     */     } 
/* 155 */     OBEXHeaderSetImpl dataHeaders = OBEXSessionBase.createOBEXHeaderSetImpl();
/* 156 */     int opcode = 144;
/* 157 */     int dataHeaderID = 72;
/* 158 */     if (finalPacket)
/*     */     {
/* 160 */       dataHeaderID = 73;
/*     */     }
/* 162 */     dataHeaders.setHeader(dataHeaderID, buffer);
/* 163 */     if (this.sendHeaders != null) {
/* 164 */       OBEXHeaderSetImpl.appendHeaders(dataHeaders, this.sendHeaders);
/* 165 */       this.sendHeaders = null;
/*     */     } 
/* 167 */     this.session.writePacket(opcode, dataHeaders);
/* 168 */     readRequestPacket();
/*     */   }
/*     */   
/*     */   private void processAbort() throws IOException {
/* 172 */     this.isAborted = true;
/* 173 */     this.session.writePacket(160, null);
/* 174 */     close();
/* 175 */     throw new IOException("Operation aborted by client");
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXServerOperationPut.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */