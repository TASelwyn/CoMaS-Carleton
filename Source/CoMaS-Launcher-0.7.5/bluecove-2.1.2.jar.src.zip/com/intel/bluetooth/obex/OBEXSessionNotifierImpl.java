/*     */ package com.intel.bluetooth.obex;
/*     */ 
/*     */ import com.intel.bluetooth.BluetoothConnectionNotifierServiceRecordAccess;
/*     */ import com.intel.bluetooth.Utils;
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ import javax.bluetooth.ServiceRecord;
/*     */ import javax.bluetooth.ServiceRegistrationException;
/*     */ import javax.microedition.io.Connection;
/*     */ import javax.microedition.io.ServerSocketConnection;
/*     */ import javax.microedition.io.StreamConnectionNotifier;
/*     */ import javax.obex.Authenticator;
/*     */ import javax.obex.ServerRequestHandler;
/*     */ import javax.obex.SessionNotifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OBEXSessionNotifierImpl
/*     */   implements SessionNotifier, BluetoothConnectionNotifierServiceRecordAccess
/*     */ {
/*     */   private StreamConnectionNotifier notifier;
/*     */   private OBEXConnectionParams obexConnectionParams;
/*  57 */   private static final String FQCN = OBEXSessionNotifierImpl.class.getName();
/*     */   
/*  59 */   private static final Vector fqcnSet = new Vector();
/*     */   
/*     */   static {
/*  62 */     fqcnSet.addElement(FQCN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OBEXSessionNotifierImpl(StreamConnectionNotifier notifier, OBEXConnectionParams obexConnectionParams) throws IOException, Error {
/*  73 */     Utils.isLegalAPICall(fqcnSet);
/*  74 */     this.notifier = notifier;
/*  75 */     this.obexConnectionParams = obexConnectionParams;
/*     */   }
/*     */   
/*     */   public Connection acceptAndOpen(ServerRequestHandler handler) throws IOException {
/*  79 */     return acceptAndOpen(handler, null);
/*     */   }
/*     */   
/*     */   public synchronized Connection acceptAndOpen(ServerRequestHandler handler, Authenticator auth) throws IOException {
/*  83 */     if (this.notifier == null) {
/*  84 */       throw new IOException("Session closed");
/*     */     }
/*  86 */     if (handler == null) {
/*  87 */       throw new NullPointerException("handler is null");
/*     */     }
/*  89 */     OBEXServerSessionImpl sessionImpl = new OBEXServerSessionImpl(this.notifier.acceptAndOpen(), handler, auth, this.obexConnectionParams);
/*     */     
/*  91 */     sessionImpl.startSessionHandlerThread();
/*  92 */     return sessionImpl;
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/*  96 */     StreamConnectionNotifier n = this.notifier;
/*  97 */     this.notifier = null;
/*  98 */     if (n != null) {
/*  99 */       n.close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceRecord getServiceRecord() {
/* 109 */     if (this.notifier instanceof ServerSocketConnection) {
/* 110 */       return new OBEXTCPServiceRecordImpl((ServerSocketConnection)this.notifier);
/*     */     }
/* 112 */     if (!(this.notifier instanceof BluetoothConnectionNotifierServiceRecordAccess)) {
/* 113 */       throw new IllegalArgumentException("connection is not a Bluetooth notifier");
/*     */     }
/* 115 */     return ((BluetoothConnectionNotifierServiceRecordAccess)this.notifier).getServiceRecord();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateServiceRecord(boolean acceptAndOpen) throws ServiceRegistrationException {
/* 124 */     if (!(this.notifier instanceof BluetoothConnectionNotifierServiceRecordAccess)) {
/* 125 */       throw new IllegalArgumentException("connection is not a Bluetooth notifier");
/*     */     }
/* 127 */     ((BluetoothConnectionNotifierServiceRecordAccess)this.notifier).updateServiceRecord(acceptAndOpen);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXSessionNotifierImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */