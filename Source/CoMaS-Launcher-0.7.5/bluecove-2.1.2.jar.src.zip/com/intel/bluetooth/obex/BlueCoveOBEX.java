/*    */ package com.intel.bluetooth.obex;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.microedition.io.Connection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BlueCoveOBEX
/*    */ {
/*    */   public static int getPacketSize(Connection c) {
/* 49 */     if (c instanceof OBEXSessionBase) {
/* 50 */       return ((OBEXSessionBase)c).getPacketSize();
/*    */     }
/* 52 */     throw new IllegalArgumentException("Not a BlueCove OBEX Session " + c.getClass().getName());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void setPacketSize(Connection c, int mtu) throws IOException {
/* 66 */     if (c instanceof OBEXSessionBase) {
/* 67 */       ((OBEXSessionBase)c).setPacketSize(mtu);
/*    */     } else {
/* 69 */       throw new IllegalArgumentException("Not a BlueCove OBEX Session " + c.getClass().getName());
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String obexResponseCodes(int responseCode) {
/* 81 */     return OBEXUtils.toStringObexResponseCodes(responseCode);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\BlueCoveOBEX.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */