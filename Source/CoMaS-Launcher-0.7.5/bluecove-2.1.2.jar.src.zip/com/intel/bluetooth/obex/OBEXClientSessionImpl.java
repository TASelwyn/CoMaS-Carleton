/*     */ package com.intel.bluetooth.obex;
/*     */ 
/*     */ import com.intel.bluetooth.DebugLog;
/*     */ import com.intel.bluetooth.Utils;
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ import javax.microedition.io.StreamConnection;
/*     */ import javax.obex.Authenticator;
/*     */ import javax.obex.ClientSession;
/*     */ import javax.obex.HeaderSet;
/*     */ import javax.obex.Operation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OBEXClientSessionImpl
/*     */   extends OBEXSessionBase
/*     */   implements ClientSession
/*     */ {
/*     */   protected OBEXClientOperation operation;
/*  52 */   private static final String FQCN = OBEXClientSessionImpl.class.getName();
/*     */   
/*  54 */   private static final Vector fqcnSet = new Vector();
/*     */   
/*     */   static {
/*  57 */     fqcnSet.addElement(FQCN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OBEXClientSessionImpl(StreamConnection conn, OBEXConnectionParams obexConnectionParams) throws IOException, Error {
/*  68 */     super(conn, obexConnectionParams);
/*  69 */     Utils.isLegalAPICall(fqcnSet);
/*  70 */     this.requestSent = false;
/*  71 */     this.isConnected = false;
/*  72 */     this.operation = null;
/*     */   }
/*     */   
/*     */   public HeaderSet createHeaderSet() {
/*  76 */     return OBEXSessionBase.createOBEXHeaderSet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HeaderSet connect(HeaderSet headers) throws IOException {
/*  85 */     return connectImpl(headers, false);
/*     */   }
/*     */   
/*     */   private HeaderSet connectImpl(HeaderSet headers, boolean retry) throws IOException {
/*  89 */     OBEXSessionBase.validateCreatedHeaderSet(headers);
/*  90 */     if (this.isConnected) {
/*  91 */       throw new IOException("Session already connected");
/*     */     }
/*  93 */     byte[] connectRequest = new byte[4];
/*  94 */     connectRequest[0] = 16;
/*  95 */     connectRequest[1] = 0;
/*  96 */     connectRequest[2] = OBEXUtils.hiByte(this.obexConnectionParams.mtu);
/*  97 */     connectRequest[3] = OBEXUtils.loByte(this.obexConnectionParams.mtu);
/*  98 */     writePacketWithFlags(128, connectRequest, (OBEXHeaderSetImpl)headers);
/*     */     
/* 100 */     byte[] b = readPacket();
/* 101 */     if (b.length < 6) {
/* 102 */       if (b.length == 3) {
/* 103 */         throw new IOException("Invalid response from OBEX server " + OBEXUtils.toStringObexResponseCodes(b[0]));
/*     */       }
/* 105 */       throw new IOException("Invalid response from OBEX server");
/*     */     } 
/* 107 */     int serverMTU = OBEXUtils.bytesToShort(b[5], b[6]);
/* 108 */     if (serverMTU < 255) {
/* 109 */       throw new IOException("Invalid MTU " + serverMTU);
/*     */     }
/* 111 */     if (serverMTU < this.mtu) {
/* 112 */       this.mtu = serverMTU;
/*     */     }
/* 114 */     DebugLog.debug("mtu selected", this.mtu);
/*     */     
/* 116 */     OBEXHeaderSetImpl responseHeaders = OBEXHeaderSetImpl.readHeaders(b[0], b, 7);
/*     */     
/* 118 */     Object connID = responseHeaders.getHeader(203);
/* 119 */     if (connID != null) {
/* 120 */       this.connectionID = ((Long)connID).longValue();
/*     */     }
/*     */     
/* 123 */     validateAuthenticationResponse((OBEXHeaderSetImpl)headers, responseHeaders);
/* 124 */     if (!retry && responseHeaders.getResponseCode() == 193 && responseHeaders.hasAuthenticationChallenge()) {
/*     */       
/* 126 */       HeaderSet replyHeaders = OBEXHeaderSetImpl.cloneHeaders(headers);
/* 127 */       handleAuthenticationChallenge(responseHeaders, (OBEXHeaderSetImpl)replyHeaders);
/* 128 */       return connectImpl(replyHeaders, true);
/*     */     } 
/*     */     
/* 131 */     if (responseHeaders.getResponseCode() == 160) {
/* 132 */       this.isConnected = true;
/*     */     }
/* 134 */     return responseHeaders;
/*     */   }
/*     */   
/*     */   public HeaderSet disconnect(HeaderSet headers) throws IOException {
/* 138 */     OBEXSessionBase.validateCreatedHeaderSet(headers);
/* 139 */     canStartOperation();
/* 140 */     if (!this.isConnected) {
/* 141 */       throw new IOException("Session not connected");
/*     */     }
/* 143 */     writePacket(129, (OBEXHeaderSetImpl)headers);
/* 144 */     byte[] b = readPacket();
/* 145 */     this.isConnected = false;
/* 146 */     if (this.operation != null) {
/* 147 */       this.operation.close();
/* 148 */       this.operation = null;
/*     */     } 
/* 150 */     return OBEXHeaderSetImpl.readHeaders(b[0], b, 3);
/*     */   }
/*     */   
/*     */   public void setConnectionID(long id) {
/* 154 */     if (id < 0L || id > 4294967295L) {
/* 155 */       throw new IllegalArgumentException("Invalid connectionID " + id);
/*     */     }
/* 157 */     this.connectionID = id;
/*     */   }
/*     */   
/*     */   public long getConnectionID() {
/* 161 */     return this.connectionID;
/*     */   }
/*     */   
/*     */   protected void canStartOperation() throws IOException {
/* 165 */     if (!this.isConnected) {
/* 166 */       throw new IOException("Session not connected");
/*     */     }
/* 168 */     if (this.operation != null) {
/* 169 */       if (!this.operation.isClosed()) {
/* 170 */         throw new IOException("Client is already in an operation");
/*     */       }
/* 172 */       this.operation = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public HeaderSet setPath(HeaderSet headers, boolean backup, boolean create) throws IOException {
/* 177 */     OBEXSessionBase.validateCreatedHeaderSet(headers);
/* 178 */     canStartOperation();
/* 179 */     return setPathImpl(headers, backup, create, false);
/*     */   }
/*     */ 
/*     */   
/*     */   private HeaderSet setPathImpl(HeaderSet headers, boolean backup, boolean create, boolean authentRetry) throws IOException {
/* 184 */     byte[] request = new byte[2];
/* 185 */     request[0] = (byte)((backup ? true : false) | (create ? false : true));
/* 186 */     request[1] = 0;
/*     */     
/* 188 */     writePacketWithFlags(133, request, (OBEXHeaderSetImpl)headers);
/*     */     
/* 190 */     byte[] b = readPacket();
/* 191 */     OBEXHeaderSetImpl responseHeaders = OBEXHeaderSetImpl.readHeaders(b[0], b, 3);
/* 192 */     validateAuthenticationResponse((OBEXHeaderSetImpl)headers, responseHeaders);
/* 193 */     if (!authentRetry && responseHeaders.getResponseCode() == 193 && responseHeaders.hasAuthenticationChallenge()) {
/*     */       
/* 195 */       OBEXHeaderSetImpl retryHeaders = OBEXHeaderSetImpl.cloneHeaders(headers);
/* 196 */       handleAuthenticationChallenge(responseHeaders, retryHeaders);
/* 197 */       return setPathImpl(retryHeaders, backup, create, true);
/*     */     } 
/* 199 */     return responseHeaders;
/*     */   }
/*     */ 
/*     */   
/*     */   public Operation get(HeaderSet headers) throws IOException {
/* 204 */     OBEXSessionBase.validateCreatedHeaderSet(headers);
/* 205 */     canStartOperation();
/* 206 */     this.operation = new OBEXClientOperationGet(this, (OBEXHeaderSetImpl)headers);
/* 207 */     return this.operation;
/*     */   }
/*     */   
/*     */   public Operation put(HeaderSet headers) throws IOException {
/* 211 */     OBEXSessionBase.validateCreatedHeaderSet(headers);
/* 212 */     canStartOperation();
/* 213 */     this.operation = new OBEXClientOperationPut(this, (OBEXHeaderSetImpl)headers);
/* 214 */     return this.operation;
/*     */   }
/*     */   
/*     */   public HeaderSet delete(HeaderSet headers) throws IOException {
/* 218 */     OBEXSessionBase.validateCreatedHeaderSet(headers);
/* 219 */     canStartOperation();
/* 220 */     return deleteImp(headers, false);
/*     */   }
/*     */   
/*     */   HeaderSet deleteImp(HeaderSet headers, boolean authentRetry) throws IOException {
/* 224 */     writePacket(130, (OBEXHeaderSetImpl)headers);
/* 225 */     byte[] b = readPacket();
/* 226 */     OBEXHeaderSetImpl responseHeaders = OBEXHeaderSetImpl.readHeaders(b[0], b, 3);
/* 227 */     validateAuthenticationResponse((OBEXHeaderSetImpl)headers, responseHeaders);
/* 228 */     if (!authentRetry && responseHeaders.getResponseCode() == 193 && responseHeaders.hasAuthenticationChallenge()) {
/*     */       
/* 230 */       OBEXHeaderSetImpl retryHeaders = OBEXHeaderSetImpl.cloneHeaders(headers);
/* 231 */       handleAuthenticationChallenge(responseHeaders, retryHeaders);
/* 232 */       return deleteImp(retryHeaders, true);
/*     */     } 
/* 234 */     return responseHeaders;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAuthenticator(Authenticator auth) {
/* 239 */     if (auth == null) {
/* 240 */       throw new NullPointerException("auth is null");
/*     */     }
/* 242 */     this.authenticator = auth;
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/*     */     try {
/* 247 */       if (this.operation != null) {
/* 248 */         this.operation.close();
/* 249 */         this.operation = null;
/*     */       } 
/*     */     } finally {
/*     */       
/* 253 */       super.close();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXClientSessionImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */