/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.bluetooth.RemoteDevice;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BluetoothConnectionAccessAdapter
/*     */   implements BluetoothConnectionAccess
/*     */ {
/*     */   protected abstract BluetoothConnectionAccess getImpl();
/*     */   
/*     */   public long getRemoteAddress() throws IOException {
/*  45 */     return getImpl().getRemoteAddress();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RemoteDevice getRemoteDevice() {
/*  54 */     return getImpl().getRemoteDevice();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isClosed() {
/*  63 */     return getImpl().isClosed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown() throws IOException {
/*  72 */     getImpl().shutdown();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markAuthenticated() {
/*  81 */     getImpl().markAuthenticated();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSecurityOpt() {
/*  90 */     return getImpl().getSecurityOpt();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean encrypt(long address, boolean on) throws IOException {
/*  99 */     return getImpl().encrypt(address, on);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRemoteDevice(RemoteDevice remoteDevice) {
/* 108 */     getImpl().setRemoteDevice(remoteDevice);
/*     */   }
/*     */   
/*     */   public BluetoothStack getBluetoothStack() {
/* 112 */     return getImpl().getBluetoothStack();
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothConnectionAccessAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */