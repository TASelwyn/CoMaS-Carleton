/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.bluetooth.BluetoothStateException;
/*     */ import javax.bluetooth.DataElement;
/*     */ import javax.bluetooth.ServiceRecord;
/*     */ import javax.bluetooth.ServiceRegistrationException;
/*     */ import javax.microedition.io.Connection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BluetoothConnectionNotifierBase
/*     */   implements Connection, BluetoothConnectionNotifierServiceRecordAccess
/*     */ {
/*  43 */   private static Hashtable stackConnections = new Hashtable();
/*     */   
/*     */   protected BluetoothStack bluetoothStack;
/*     */   
/*     */   protected volatile long handle;
/*     */   
/*     */   protected ServiceRecordImpl serviceRecord;
/*     */   
/*     */   protected boolean closed;
/*     */   
/*     */   protected int securityOpt;
/*     */   
/*     */   static void shutdownConnections(BluetoothStack bluetoothStack) {
/*     */     Vector connections;
/*  57 */     synchronized (stackConnections) {
/*  58 */       connections = (Vector)stackConnections.get(bluetoothStack);
/*     */     } 
/*  60 */     if (connections == null) {
/*     */       return;
/*     */     }
/*  63 */     Vector c2shutdown = new Vector();
/*  64 */     c2shutdown = Utils.clone(connections.elements());
/*  65 */     for (Enumeration en = c2shutdown.elements(); en.hasMoreElements(); ) {
/*  66 */       BluetoothConnectionNotifierBase c = en.nextElement();
/*     */       try {
/*  68 */         c.shutdown();
/*  69 */       } catch (IOException e) {
/*  70 */         DebugLog.debug("connection shutdown", e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected BluetoothConnectionNotifierBase(BluetoothStack bluetoothStack, BluetoothConnectionNotifierParams params) throws BluetoothStateException, Error {
/*  77 */     this.bluetoothStack = bluetoothStack;
/*  78 */     this.closed = false;
/*  79 */     if (params.name == null) {
/*  80 */       throw new NullPointerException("Service name is null");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  85 */     this.serviceRecord = new ServiceRecordImpl(this.bluetoothStack, null, 0L);
/*     */   }
/*     */   
/*     */   protected void connectionCreated() {
/*     */     Vector connections;
/*  90 */     synchronized (stackConnections) {
/*  91 */       connections = (Vector)stackConnections.get(this.bluetoothStack);
/*  92 */       if (connections == null) {
/*  93 */         connections = new Vector();
/*  94 */         stackConnections.put(this.bluetoothStack, connections);
/*     */       } 
/*     */     } 
/*  97 */     connections.addElement(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void stackServerClose(long paramLong) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 118 */     if (!this.closed) {
/* 119 */       shutdown();
/*     */     }
/*     */   }
/*     */   
/*     */   public void shutdown() throws IOException {
/* 124 */     this.closed = true;
/* 125 */     if (this.handle != 0L) {
/* 126 */       Vector connections; long synchronizedHandle; DebugLog.debug("closing ConnectionNotifier", this.handle);
/*     */       
/* 128 */       synchronized (stackConnections) {
/* 129 */         connections = (Vector)stackConnections.get(this.bluetoothStack);
/*     */       } 
/* 131 */       connections.removeElement(this);
/*     */       
/* 133 */       synchronized (this) {
/* 134 */         synchronizedHandle = this.handle;
/* 135 */         this.handle = 0L;
/*     */       } 
/* 137 */       if (synchronizedHandle != 0L) {
/*     */         
/* 139 */         ServiceRecordsRegistry.unregister(this.serviceRecord);
/*     */         
/* 141 */         if (this.serviceRecord.deviceServiceClasses != 0 && (this.bluetoothStack.getFeatureSet() & 0x4) != 0)
/*     */         {
/* 143 */           this.bluetoothStack.setLocalDeviceServiceClasses(ServiceRecordsRegistry.getDeviceServiceClasses());
/*     */         }
/*     */         
/* 146 */         stackServerClose(synchronizedHandle);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceRecord getServiceRecord() {
/* 157 */     if (this.closed) {
/* 158 */       throw new IllegalArgumentException("ConnectionNotifier is closed");
/*     */     }
/* 160 */     ServiceRecordsRegistry.register(this, this.serviceRecord);
/* 161 */     return this.serviceRecord;
/*     */   }
/*     */   
/*     */   protected void validateServiceRecord(ServiceRecord srvRecord) {
/* 165 */     DataElement protocolDescriptor = srvRecord.getAttributeValue(4);
/* 166 */     if (protocolDescriptor == null || protocolDescriptor.getDataType() != 48) {
/* 167 */       throw new IllegalArgumentException("ProtocolDescriptorList is mandatory");
/*     */     }
/*     */     
/* 170 */     DataElement serviceClassIDList = srvRecord.getAttributeValue(1);
/* 171 */     if (serviceClassIDList == null || serviceClassIDList.getDataType() != 48 || serviceClassIDList.getSize() == 0)
/*     */     {
/* 173 */       throw new IllegalArgumentException("ServiceClassIDList is mandatory");
/*     */     }
/*     */     
/* 176 */     boolean isL2CAPpresent = false;
/* 177 */     Enumeration protocolsSeqEnum = (Enumeration)protocolDescriptor.getValue();
/* 178 */     while (protocolsSeqEnum.hasMoreElements()) {
/* 179 */       DataElement elementSeq = protocolsSeqEnum.nextElement();
/* 180 */       if (elementSeq.getDataType() == 48) {
/* 181 */         Enumeration elementSeqEnum = (Enumeration)elementSeq.getValue();
/* 182 */         if (elementSeqEnum.hasMoreElements()) {
/* 183 */           DataElement protocolElement = elementSeqEnum.nextElement();
/* 184 */           if (protocolElement.getDataType() == 24 && BluetoothConsts.L2CAP_PROTOCOL_UUID.equals(protocolElement.getValue())) {
/*     */             
/* 186 */             isL2CAPpresent = true;
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 192 */     if (!isL2CAPpresent) {
/* 193 */       throw new IllegalArgumentException("L2CAP UUID is mandatory in ProtocolDescriptorList");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void updateStackServiceRecord(ServiceRecordImpl paramServiceRecordImpl, boolean paramBoolean) throws ServiceRegistrationException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateServiceRecord(boolean acceptAndOpen) throws ServiceRegistrationException {
/* 206 */     if (this.serviceRecord.attributeUpdated || !acceptAndOpen) {
/*     */       try {
/* 208 */         validateServiceRecord(this.serviceRecord);
/* 209 */       } catch (IllegalArgumentException e) {
/* 210 */         if (acceptAndOpen) {
/* 211 */           throw new ServiceRegistrationException(e.getMessage());
/*     */         }
/* 213 */         throw e;
/*     */       } 
/*     */       
/*     */       try {
/* 217 */         updateStackServiceRecord(this.serviceRecord, acceptAndOpen);
/*     */       } finally {
/* 219 */         this.serviceRecord.attributeUpdated = false;
/*     */       } 
/*     */     } 
/* 222 */     if (this.serviceRecord.deviceServiceClasses != this.serviceRecord.deviceServiceClassesRegistered && (this.bluetoothStack.getFeatureSet() & 0x4) != 0) {
/*     */ 
/*     */       
/* 225 */       this.bluetoothStack.setLocalDeviceServiceClasses(ServiceRecordsRegistry.getDeviceServiceClasses());
/*     */       
/* 227 */       this.serviceRecord.deviceServiceClassesRegistered = this.serviceRecord.deviceServiceClasses;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothConnectionNotifierBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */