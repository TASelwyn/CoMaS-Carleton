/*    */ package com.intel.bluetooth;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BluetoothConnectionParams
/*    */ {
/*    */   public static final int DEFAULT_CONNECT_TIMEOUT = 120000;
/*    */   long address;
/*    */   int channel;
/*    */   boolean authenticate;
/*    */   boolean encrypt;
/*    */   boolean timeouts;
/* 58 */   public int timeout = 120000;
/*    */ 
/*    */   
/*    */   public BluetoothConnectionParams(long address, int channel, boolean authenticate, boolean encrypt) {
/* 62 */     this.address = address;
/* 63 */     this.channel = channel;
/* 64 */     this.authenticate = authenticate;
/* 65 */     this.encrypt = encrypt;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothConnectionParams.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */