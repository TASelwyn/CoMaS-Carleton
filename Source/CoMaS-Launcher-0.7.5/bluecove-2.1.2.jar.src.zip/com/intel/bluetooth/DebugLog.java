/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DebugLog
/*     */ {
/*     */   private static final boolean debugCompiledOut = false;
/*     */   public static final int DEBUG = 1;
/*     */   public static final int ERROR = 4;
/*     */   private static boolean debugEnabled = false;
/*     */   private static boolean initialized = false;
/*     */   private static boolean debugInternalEnabled = false;
/*  56 */   private static final String FQCN = DebugLog.class.getName();
/*     */   
/*  58 */   private static final Vector fqcnSet = new Vector();
/*     */   
/*     */   private static boolean java13 = false;
/*     */   
/*  62 */   private static Vector loggerAppenders = new Vector();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  77 */     fqcnSet.addElement(FQCN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static synchronized void initialize() {
/*  85 */     if (initialized) {
/*     */       return;
/*     */     }
/*  88 */     initialized = true;
/*  89 */     debugEnabled = BlueCoveImpl.getConfigProperty("bluecove.debug", false);
/*  90 */     if (debugEnabled);
/*     */ 
/*     */ 
/*     */     
/*  94 */     boolean useStdOut = BlueCoveImpl.getConfigProperty("bluecove.debug.stdout", true);
/*  95 */     debugInternalEnabled = (useStdOut && debugEnabled);
/*  96 */     boolean useLog4j = BlueCoveImpl.getConfigProperty("bluecove.debug.log4j", true);
/*  97 */     if (useLog4j) {
/*     */       try {
/*  99 */         LoggerAppenderExt log4jAppender = (LoggerAppenderExt)Class.forName("com.intel.bluetooth.DebugLog4jAppender").newInstance();
/*     */         
/* 101 */         System.out.println("BlueCove log redirected to log4j");
/* 102 */         addAppender(log4jAppender);
/* 103 */         if (log4jAppender.isLogEnabled(1)) {
/* 104 */           debugEnabled = true;
/*     */         }
/* 106 */       } catch (Throwable e) {}
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isDebugEnabled() {
/* 112 */     if (!initialized) {
/* 113 */       initialize();
/*     */     }
/* 115 */     return debugEnabled;
/*     */   }
/*     */   
/*     */   public static void setDebugEnabled(boolean debugEnabled) {
/* 119 */     if (!initialized) {
/* 120 */       initialize();
/*     */     }
/* 122 */     if (debugEnabled);
/*     */ 
/*     */ 
/*     */     
/* 126 */     BlueCoveImpl.instance().enableNativeDebug(debugEnabled);
/* 127 */     DebugLog.debugEnabled = debugEnabled;
/* 128 */     debugInternalEnabled = DebugLog.debugEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void debug(String message) {
/* 133 */     if (isDebugEnabled()) {
/* 134 */       log(message, null, null);
/* 135 */       printLocation();
/* 136 */       callAppenders(1, message, null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void debug(String message, String v) {
/* 141 */     if (isDebugEnabled()) {
/* 142 */       log(message, " ", v);
/* 143 */       printLocation();
/* 144 */       callAppenders(1, message + " " + v, null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void debug(String message, Throwable t) {
/* 149 */     if (isDebugEnabled()) {
/* 150 */       log(message, " ", t.toString());
/* 151 */       printLocation();
/*     */ 
/*     */       
/* 154 */       if (!UtilsJavaSE.ibmJ9midp) {
/* 155 */         t.printStackTrace(System.out);
/* 156 */       } else if (debugInternalEnabled) {
/* 157 */         t.printStackTrace();
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 162 */       callAppenders(1, message, t);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void debug(String message, Object obj) {
/* 167 */     if (isDebugEnabled()) {
/* 168 */       log(message, " ", obj.toString());
/* 169 */       printLocation();
/* 170 */       callAppenders(1, message + " " + obj.toString(), null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void debug(String message, String v, String v2) {
/* 175 */     if (isDebugEnabled()) {
/* 176 */       log(message, " ", v + " " + v2);
/* 177 */       printLocation();
/* 178 */       callAppenders(1, message + " " + v + " " + v2, null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void debug(String message, long v) {
/* 183 */     if (isDebugEnabled()) {
/* 184 */       log(message, " ", Long.toString(v));
/* 185 */       printLocation();
/* 186 */       callAppenders(1, message + " " + Long.toString(v), null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void debug0x(String message, long v) {
/* 191 */     if (isDebugEnabled()) {
/* 192 */       log(message, " 0x", Utils.toHexString(v));
/* 193 */       printLocation();
/* 194 */       callAppenders(1, message + " 0x" + Utils.toHexString(v), null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void debug0x(String message, String s, long v) {
/* 199 */     if (isDebugEnabled()) {
/* 200 */       log(message, " " + s + " 0x", Utils.toHexString(v));
/* 201 */       printLocation();
/* 202 */       callAppenders(1, message + " " + s + " 0x" + Utils.toHexString(v), null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void debug(String message, boolean v) {
/* 207 */     if (isDebugEnabled()) {
/* 208 */       log(message, " ", String.valueOf(v));
/* 209 */       printLocation();
/* 210 */       callAppenders(1, message + " " + v, null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void debug(String message, byte[] data) {
/* 215 */     debug(message, data, 0, (data == null) ? 0 : data.length);
/*     */   }
/*     */   
/*     */   public static void debug(String message, byte[] data, int off, int len) {
/* 219 */     if (isDebugEnabled()) {
/* 220 */       StringBuffer buf = new StringBuffer();
/* 221 */       if (data == null) {
/* 222 */         buf.append(" null byte[]");
/*     */       } else {
/* 224 */         buf.append(" [");
/* 225 */         for (int i = off; i < off + len; i++) {
/* 226 */           if (i != off) {
/* 227 */             buf.append(", ");
/*     */           }
/* 229 */           buf.append((new Byte(data[i])).toString());
/*     */         } 
/* 231 */         buf.append("]");
/* 232 */         if (len > 4) {
/* 233 */           buf.append(" ").append(len);
/*     */         }
/*     */       } 
/* 236 */       log(message, buf.toString(), null);
/* 237 */       printLocation();
/* 238 */       callAppenders(1, message + buf.toString(), null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void debug(String message, int[] data) {
/* 243 */     debug(message, data, 0, (data == null) ? 0 : data.length);
/*     */   }
/*     */   
/*     */   public static void debug(String message, int[] data, int off, int len) {
/* 247 */     if (isDebugEnabled()) {
/* 248 */       StringBuffer buf = new StringBuffer();
/* 249 */       if (data == null) {
/* 250 */         buf.append(" null int[]");
/*     */       } else {
/* 252 */         buf.append(" [");
/* 253 */         for (int i = off; i < off + len; i++) {
/* 254 */           if (i != off) {
/* 255 */             buf.append(", ");
/*     */           }
/* 257 */           buf.append(Integer.toString(data[i]));
/*     */         } 
/* 259 */         buf.append("]");
/* 260 */         if (len > 4) {
/* 261 */           buf.append(" ").append(len);
/*     */         }
/*     */       } 
/* 264 */       log(message, buf.toString(), null);
/* 265 */       printLocation();
/* 266 */       callAppenders(1, message + buf.toString(), null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void nativeDebugCallback(String fileName, int lineN, String message) {
/*     */     try {
/* 272 */       if (fileName != null && fileName.startsWith(".\\")) {
/* 273 */         fileName = fileName.substring(2);
/*     */       }
/* 275 */       debugNative(fileName + ":" + lineN, message);
/* 276 */     } catch (Throwable e) {
/*     */       try {
/* 278 */         System.out.println("Error when calling debug " + e);
/* 279 */       } catch (Throwable e2) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void debugNative(String location, String message) {
/* 286 */     if (isDebugEnabled()) {
/* 287 */       log(message, "\n\t  ", location);
/* 288 */       callAppenders(1, message, null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void error(String message) {
/* 293 */     if (isDebugEnabled()) {
/* 294 */       log("error ", message, null);
/* 295 */       printLocation();
/* 296 */       callAppenders(4, message, null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void error(String message, long v) {
/* 301 */     if (isDebugEnabled()) {
/* 302 */       log("error ", message, " " + v);
/* 303 */       printLocation();
/* 304 */       callAppenders(4, message + " " + v, null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void error(String message, String v) {
/* 309 */     if (isDebugEnabled()) {
/* 310 */       log("error ", message, " " + v);
/* 311 */       printLocation();
/* 312 */       callAppenders(4, message + " " + v, null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void error(String message, Throwable t) {
/* 317 */     if (isDebugEnabled()) {
/* 318 */       log("error ", message, " " + t);
/* 319 */       printLocation();
/*     */ 
/*     */       
/* 322 */       if (!UtilsJavaSE.ibmJ9midp) {
/* 323 */         t.printStackTrace(System.out);
/* 324 */       } else if (debugInternalEnabled) {
/* 325 */         t.printStackTrace();
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 331 */       callAppenders(4, message, t);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void fatal(String message) {
/* 336 */     log("error ", message, null);
/* 337 */     printLocation();
/* 338 */     callAppenders(4, message, null);
/*     */   }
/*     */   
/*     */   public static void fatal(String message, Throwable t) {
/* 342 */     log("error ", message, " " + t);
/* 343 */     printLocation();
/*     */ 
/*     */     
/* 346 */     if (!UtilsJavaSE.ibmJ9midp) {
/* 347 */       t.printStackTrace(System.out);
/* 348 */     } else if (debugInternalEnabled) {
/* 349 */       t.printStackTrace();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 355 */     callAppenders(4, message, t);
/*     */   }
/*     */   
/*     */   private static void callAppenders(int level, String message, Throwable throwable) {
/* 359 */     for (Enumeration iter = loggerAppenders.elements(); iter.hasMoreElements(); ) {
/* 360 */       LoggerAppender a = iter.nextElement();
/* 361 */       a.appendLog(level, message, throwable);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void addAppender(LoggerAppender newAppender) {
/* 366 */     loggerAppenders.addElement(newAppender);
/*     */   }
/*     */   
/*     */   public static void removeAppender(LoggerAppender newAppender) {
/* 370 */     loggerAppenders.removeElement(newAppender);
/*     */   }
/*     */   
/*     */   private static String d00(int i) {
/* 374 */     if (i > 9) {
/* 375 */       return String.valueOf(i);
/*     */     }
/* 377 */     return "0" + String.valueOf(i);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String d000(int i) {
/* 382 */     if (i > 99)
/* 383 */       return String.valueOf(i); 
/* 384 */     if (i > 9) {
/* 385 */       return "0" + String.valueOf(i);
/*     */     }
/* 387 */     return "00" + String.valueOf(i);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void log(String message, String va1, String va2) {
/* 392 */     if (!debugInternalEnabled) {
/*     */       return;
/*     */     }
/*     */     try {
/* 396 */       Calendar calendar = Calendar.getInstance();
/* 397 */       calendar.setTime(new Date(System.currentTimeMillis()));
/*     */ 
/*     */       
/* 400 */       StringBuffer sb = new StringBuffer();
/* 401 */       sb.append(d00(calendar.get(11))).append(":");
/* 402 */       sb.append(d00(calendar.get(12))).append(":");
/* 403 */       sb.append(d00(calendar.get(13))).append(".");
/* 404 */       sb.append(d000(calendar.get(14))).append(" ");
/*     */       
/* 406 */       sb.append(message);
/* 407 */       if (va1 != null) {
/* 408 */         sb.append(va1);
/*     */       }
/* 410 */       if (va2 != null) {
/* 411 */         sb.append(va2);
/*     */       }
/*     */       
/* 414 */       System.out.println(sb.toString());
/* 415 */     } catch (Throwable ignore) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private static void printLocation() {
/* 420 */     if (java13 || !debugInternalEnabled) {
/*     */       return;
/*     */     }
/*     */     try {
/* 424 */       UtilsJavaSE.StackTraceLocation ste = UtilsJavaSE.getLocation(fqcnSet);
/* 425 */       if (ste != null) {
/* 426 */         System.out.println("\t  " + formatLocation(ste));
/*     */       }
/* 428 */     } catch (Throwable e) {
/* 429 */       java13 = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String formatLocation(UtilsJavaSE.StackTraceLocation ste) {
/* 434 */     if (ste == null) {
/* 435 */       return "";
/*     */     }
/*     */     
/* 438 */     return ste.className + "." + ste.methodName + "(" + ste.fileName + ":" + ste.lineNumber + ")";
/*     */   }
/*     */   
/*     */   public static interface LoggerAppenderExt extends LoggerAppender {
/*     */     boolean isLogEnabled(int param1Int);
/*     */   }
/*     */   
/*     */   public static interface LoggerAppender {
/*     */     void appendLog(int param1Int, String param1String, Throwable param1Throwable);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\DebugLog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */