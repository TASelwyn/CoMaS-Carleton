/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.bluetooth.BluetoothConnectionException;
/*     */ import javax.bluetooth.BluetoothStateException;
/*     */ import javax.bluetooth.DataElement;
/*     */ import javax.bluetooth.DeviceClass;
/*     */ import javax.bluetooth.DiscoveryListener;
/*     */ import javax.bluetooth.RemoteDevice;
/*     */ import javax.bluetooth.ServiceRecord;
/*     */ import javax.bluetooth.ServiceRegistrationException;
/*     */ import javax.bluetooth.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BluetoothStackOSX
/*     */   implements BluetoothStack, BluetoothStackExtension
/*     */ {
/*     */   public static final boolean debug = false;
/*  48 */   private static BluetoothStackOSX singleInstance = null;
/*     */ 
/*     */   
/*     */   private static final int ATTR_RETRIEVABLE_MAX = 256;
/*     */   
/*  53 */   private final Vector deviceDiscoveryListeners = new Vector();
/*     */   
/*  55 */   private final Hashtable deviceDiscoveryListenerReportedDevices = new Hashtable();
/*     */   
/*  57 */   private int receive_mtu_max = -1;
/*     */   
/*     */   private int localDeviceSupportedSoftwareVersion;
/*     */   
/*  61 */   private long lastDeviceDiscoveryTime = 0L;
/*     */   
/*  63 */   private int localDeviceServiceClasses = 0;
/*     */   
/*  65 */   private Thread localDeviceServiceClassMaintainer = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int BLUETOOTH_SOFTWARE_VERSION_2_0_0 = 20000;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BluetoothStack.LibraryInformation[] requireNativeLibraries() {
/*  88 */     return BluetoothStack.LibraryInformation.library("bluecove");
/*     */   }
/*     */   
/*     */   public String getStackID() {
/*  92 */     return "mac";
/*     */   }
/*     */   
/*     */   public String toString() {
/*  96 */     return getStackID();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFeatureSet() {
/* 105 */     if (this.localDeviceSupportedSoftwareVersion >= 20000) {
/* 106 */       return 0x7 | (isLocalDeviceFeatureRSSI() ? 8 : 0);
/*     */     }
/* 108 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize() throws BluetoothStateException {
/* 119 */     if (singleInstance != null) {
/* 120 */       throw new BluetoothStateException("Only one instance of " + getStackID() + " stack supported");
/*     */     }
/*     */     
/* 123 */     String sysVersion = System.getProperty("os.version");
/* 124 */     String jreDataModel = System.getProperty("sun.arch.data.model");
/* 125 */     boolean osIsLeopard = (sysVersion != null && sysVersion.startsWith("10.5"));
/* 126 */     boolean jreIs64Bit = "64".equals(jreDataModel);
/* 127 */     if (osIsLeopard && jreIs64Bit) {
/* 128 */       throw new BluetoothStateException("Mac OS X 10.5 not supported with a 64 bit JRE");
/*     */     }
/*     */     
/* 131 */     this.localDeviceSupportedSoftwareVersion = getLocalDeviceSupportedSoftwareVersion();
/* 132 */     DebugLog.debug("localDeviceSupportedSoftwareVersion", this.localDeviceSupportedSoftwareVersion);
/* 133 */     if (!initializeImpl()) {
/* 134 */       throw new BluetoothStateException("OS X BluetoothStack not found");
/*     */     }
/* 136 */     singleInstance = this;
/*     */   }
/*     */   
/*     */   public void destroy() {
/* 140 */     if (this.localDeviceSupportedSoftwareVersion >= 20000) {
/* 141 */       setLocalDeviceServiceClassesImpl(0);
/*     */     }
/* 143 */     singleInstance = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCurrentThreadInterruptedCallback() {
/* 154 */     return UtilsJavaSE.isCurrentThreadInterrupted();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeviceClass getLocalDeviceClass() {
/* 166 */     return new DeviceClass(getDeviceClassImpl());
/*     */   }
/*     */   
/*     */   private class MaintainDeviceServiceClassesThread
/*     */     extends Thread {
/*     */     private final BluetoothStackOSX this$0;
/*     */     
/*     */     MaintainDeviceServiceClassesThread(BluetoothStackOSX this$0) {
/* 174 */       super("MaintainDeviceServiceClassesThread");
/*     */       this.this$0 = this$0;
/*     */     }
/*     */     public void run() {
/* 178 */       boolean updated = true;
/*     */       while (true) {
/*     */         try {
/* 181 */           int delay = 120000;
/* 182 */           if (!updated) {
/* 183 */             delay = 1000;
/*     */           }
/* 185 */           Thread.sleep(delay);
/* 186 */         } catch (InterruptedException e) {
/*     */           break;
/*     */         } 
/* 189 */         if (this.this$0.localDeviceServiceClasses != 0) {
/* 190 */           updated = this.this$0.setLocalDeviceServiceClassesImpl(this.this$0.localDeviceServiceClasses); continue;
/* 191 */         }  if (!updated) {
/* 192 */           updated = true;
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setLocalDeviceServiceClasses(int classOfDevice) {
/* 204 */     if (this.localDeviceSupportedSoftwareVersion < 20000) {
/*     */       return;
/*     */     }
/* 207 */     if (classOfDevice != this.localDeviceServiceClasses) {
/* 208 */       setLocalDeviceServiceClassesImpl(classOfDevice);
/*     */     }
/* 210 */     this.localDeviceServiceClasses = classOfDevice;
/* 211 */     if (classOfDevice != 0 && this.localDeviceServiceClassMaintainer == null) {
/* 212 */       this.localDeviceServiceClassMaintainer = new MaintainDeviceServiceClassesThread(this);
/* 213 */       UtilsJavaSE.threadSetDaemon(this.localDeviceServiceClassMaintainer);
/* 214 */       this.localDeviceServiceClassMaintainer.start();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocalDeviceProperty(String property) {
/* 237 */     if ("bluetooth.connected.devices.max".equals(property)) {
/* 238 */       return isLocalDeviceFeatureParkMode() ? "255" : "7";
/*     */     }
/* 240 */     if ("bluetooth.sd.trans.max".equals(property)) {
/* 241 */       return "7";
/*     */     }
/* 243 */     if ("bluetooth.connected.inquiry.scan".equals(property)) {
/* 244 */       return "true";
/*     */     }
/* 246 */     if ("bluetooth.connected.page.scan".equals(property)) {
/* 247 */       return "true";
/*     */     }
/* 249 */     if ("bluetooth.connected.inquiry".equals(property)) {
/* 250 */       return "true";
/*     */     }
/* 252 */     if ("bluetooth.connected.page".equals(property)) {
/* 253 */       return "true";
/*     */     }
/*     */     
/* 256 */     if ("bluetooth.sd.attr.retrievable.max".equals(property)) {
/* 257 */       return String.valueOf(256);
/*     */     }
/* 259 */     if ("bluetooth.master.switch".equals(property))
/*     */     {
/* 261 */       return "false";
/*     */     }
/* 263 */     if ("bluetooth.l2cap.receiveMTU.max".equals(property)) {
/* 264 */       return String.valueOf(receiveMTUMAX());
/*     */     }
/*     */     
/* 267 */     if ("bluecove.radio.version".equals(property)) {
/* 268 */       return getLocalDeviceVersion();
/*     */     }
/* 270 */     if ("bluecove.radio.manufacturer".equals(property)) {
/* 271 */       return String.valueOf(getLocalDeviceManufacturer());
/*     */     }
/* 273 */     if ("bluecove.stack.version".equals(property)) {
/* 274 */       return getLocalDeviceSoftwareVersionInfo();
/*     */     }
/*     */     
/* 277 */     return null;
/*     */   }
/*     */   
/*     */   private int receiveMTUMAX() {
/* 281 */     if (this.receive_mtu_max < 0) {
/* 282 */       this.receive_mtu_max = getLocalDeviceL2CAPMTUMaximum();
/*     */     }
/* 284 */     return this.receive_mtu_max;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLocalDeviceDiscoverable() {
/* 290 */     if (getLocalDeviceDiscoverableImpl()) {
/* 291 */       return 10390323;
/*     */     }
/* 293 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setLocalDeviceDiscoverable(int mode) throws BluetoothStateException {
/* 301 */     if (getLocalDeviceDiscoverable() == mode) {
/* 302 */       return true;
/*     */     }
/* 304 */     return false;
/*     */   }
/*     */   
/*     */   private void verifyDeviceReady() throws BluetoothStateException {
/* 308 */     if (!isLocalDevicePowerOn()) {
/* 309 */       throw new BluetoothStateException("Bluetooth Device is not ready");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RemoteDevice[] retrieveDevices(int option) {
/* 316 */     Vector devices = new Vector();
/* 317 */     RetrieveDevicesCallback retrieveDevicesCallback = new RetrieveDevicesCallback(this, devices) { private final Vector val$devices;
/*     */         public void deviceFoundCallback(long deviceAddr, int deviceClass, String deviceName, boolean paired) {
/* 319 */           DebugLog.debug("device found", deviceAddr);
/* 320 */           RemoteDevice remoteDevice = RemoteDeviceHelper.createRemoteDevice(this.this$0, deviceAddr, deviceName, paired);
/* 321 */           if (!this.val$devices.contains(remoteDevice))
/* 322 */             this.val$devices.add(remoteDevice); 
/*     */         }
/*     */         private final BluetoothStackOSX this$0; }
/*     */       ;
/* 326 */     if (retrieveDevicesImpl(option, retrieveDevicesCallback)) {
/* 327 */       return RemoteDeviceHelper.remoteDeviceListToArray(devices);
/*     */     }
/* 329 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean isRemoteDeviceTrusted(long address) {
/* 336 */     return new Boolean(isRemoteDeviceTrustedImpl(address));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean isRemoteDeviceAuthenticated(long address) {
/* 342 */     return new Boolean(isRemoteDeviceAuthenticatedImpl(address));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readRemoteDeviceRSSI(long address) throws IOException {
/* 353 */     return readRemoteDeviceRSSIImpl(address);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean authenticateRemoteDevice(long address) throws IOException {
/* 361 */     return authenticateRemoteDeviceImpl(address);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean authenticateRemoteDevice(long address, String passkey) throws IOException {
/* 371 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAuthenticationWithRemoteDevice(long address) throws IOException {
/* 380 */     throw new NotSupportedIOException(getStackID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean startInquiry(int accessCode, DiscoveryListener listener) throws BluetoothStateException {
/* 393 */     long sinceDiscoveryLast = System.currentTimeMillis() - this.lastDeviceDiscoveryTime;
/* 394 */     long acceptableInterval = 7000L;
/* 395 */     if (sinceDiscoveryLast < acceptableInterval) {
/*     */       try {
/* 397 */         Thread.sleep(acceptableInterval - sinceDiscoveryLast);
/* 398 */       } catch (InterruptedException e) {
/* 399 */         throw new BluetoothStateException();
/*     */       } 
/*     */     }
/*     */     
/* 403 */     this.deviceDiscoveryListeners.addElement(listener);
/* 404 */     this.deviceDiscoveryListenerReportedDevices.put(listener, new Vector());
/* 405 */     DeviceInquiryRunnable inquiryRunnable = new DeviceInquiryRunnable(this) { private final BluetoothStackOSX this$0;
/*     */         
/*     */         public int runDeviceInquiry(DeviceInquiryThread startedNotify, int accessCode, DiscoveryListener listener) throws BluetoothStateException {
/*     */           try {
/* 409 */             return this.this$0.runDeviceInquiryImpl(this, startedNotify, accessCode, DeviceInquiryThread.getConfigDeviceInquiryDuration(), listener);
/*     */           } finally {
/* 411 */             this.this$0.lastDeviceDiscoveryTime = System.currentTimeMillis();
/* 412 */             this.this$0.deviceDiscoveryListeners.removeElement(listener);
/* 413 */             this.this$0.deviceDiscoveryListenerReportedDevices.remove(listener);
/*     */           } 
/*     */         }
/*     */         
/*     */         public void deviceDiscoveredCallback(DiscoveryListener listener, long deviceAddr, int deviceClass, String deviceName, boolean paired) {
/* 418 */           if (!this.this$0.deviceDiscoveryListeners.contains(listener)) {
/*     */             return;
/*     */           }
/*     */           
/* 422 */           RemoteDevice remoteDevice = RemoteDeviceHelper.createRemoteDevice(this.this$0, deviceAddr, deviceName, paired);
/* 423 */           Vector reported = (Vector)this.this$0.deviceDiscoveryListenerReportedDevices.get(listener);
/* 424 */           if (reported == null || reported.contains(remoteDevice)) {
/*     */             return;
/*     */           }
/* 427 */           reported.addElement(remoteDevice);
/* 428 */           DeviceClass cod = new DeviceClass(deviceClass);
/* 429 */           DebugLog.debug("deviceDiscoveredCallback address", remoteDevice.getBluetoothAddress());
/* 430 */           DebugLog.debug("deviceDiscoveredCallback deviceClass", cod);
/* 431 */           listener.deviceDiscovered(remoteDevice, cod);
/*     */         } }
/*     */       ;
/* 434 */     return DeviceInquiryThread.startInquiry(this, inquiryRunnable, accessCode, listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean cancelInquiry(DiscoveryListener listener) {
/* 441 */     if (!this.deviceDiscoveryListeners.removeElement(listener)) {
/* 442 */       return false;
/*     */     }
/* 444 */     return deviceInquiryCancelImpl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int searchServices(int[] attrSet, UUID[] uuidSet, RemoteDevice device, DiscoveryListener listener) throws BluetoothStateException {
/* 453 */     SearchServicesRunnable searchRunnable = new SearchServicesRunnable(this) {
/*     */         private final BluetoothStackOSX this$0;
/*     */         
/*     */         public int runSearchServices(SearchServicesThread sst, int[] attrSet, UUID[] uuidSet, RemoteDevice device, DiscoveryListener listener) throws BluetoothStateException {
/*     */           int recordsSize;
/* 458 */           sst.searchServicesStartedCallback();
/*     */           
/*     */           try {
/* 461 */             recordsSize = this.this$0.runSearchServicesImpl(RemoteDeviceHelper.getAddress(device), sst.getTransID());
/* 462 */           } catch (SearchServicesDeviceNotReachableException e) {
/* 463 */             return 6;
/* 464 */           } catch (SearchServicesTerminatedException e) {
/* 465 */             return 2;
/* 466 */           } catch (SearchServicesException e) {
/* 467 */             return 3;
/*     */           } 
/* 469 */           if (sst.isTerminated()) {
/* 470 */             return 2;
/*     */           }
/* 472 */           if (recordsSize == 0) {
/* 473 */             return 4;
/*     */           }
/* 475 */           Vector records = new Vector();
/* 476 */           int[] uuidFilerAttrIDs = { 1, 4 };
/* 477 */           int[] requiredAttrIDs = { 0, 2, 3 }; int i;
/* 478 */           label38: for (i = 0; i < recordsSize; i++) {
/* 479 */             ServiceRecordImpl sr = new ServiceRecordImpl(this.this$0, device, i);
/*     */             try {
/* 481 */               sr.populateRecord(uuidFilerAttrIDs);
/*     */               
/* 483 */               for (int u = 0; u < uuidSet.length; u++) {
/* 484 */                 if (!sr.hasServiceClassUUID(uuidSet[u]) && !sr.hasProtocolClassUUID(uuidSet[u])) {
/*     */                   continue label38;
/*     */                 }
/*     */               } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 494 */               records.addElement(sr);
/* 495 */               sr.populateRecord(requiredAttrIDs);
/* 496 */               if (attrSet != null) {
/* 497 */                 sr.populateRecord(attrSet);
/*     */               }
/* 499 */               DebugLog.debug("ServiceRecord (" + i + ")", sr);
/* 500 */             } catch (Exception e) {
/* 501 */               DebugLog.debug("populateRecord error", e);
/*     */             } 
/*     */             
/* 504 */             if (sst.isTerminated()) {
/* 505 */               DebugLog.debug("SERVICE_SEARCH_TERMINATED " + sst.getTransID());
/* 506 */               return 2;
/*     */             } 
/*     */           } 
/* 509 */           if (records.size() != 0) {
/* 510 */             DebugLog.debug("SERVICE_SEARCH_COMPLETED " + sst.getTransID());
/* 511 */             ServiceRecord[] fileteredRecords = (ServiceRecord[])Utils.vector2toArray(records, (Object[])new ServiceRecord[records.size()]);
/* 512 */             listener.servicesDiscovered(sst.getTransID(), fileteredRecords);
/* 513 */             return 1;
/*     */           } 
/* 515 */           return 4;
/*     */         }
/*     */       };
/*     */ 
/*     */     
/* 520 */     return SearchServicesThread.startSearchServices(this, searchRunnable, attrSet, uuidSet, device, listener);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean cancelServiceSearch(int transID) {
/* 526 */     SearchServicesThread sst = SearchServicesThread.getServiceSearchThread(transID);
/* 527 */     if (sst != null) {
/* 528 */       synchronized (this) {
/* 529 */         if (!sst.isTerminated()) {
/* 530 */           sst.setTerminated();
/* 531 */           cancelServiceSearchImpl(transID);
/* 532 */           return true;
/*     */         } 
/*     */       } 
/*     */     }
/* 536 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean populateServicesRecordAttributeValues(ServiceRecordImpl serviceRecord, int[] attrIDs) throws IOException {
/* 542 */     if (attrIDs.length > 256) {
/* 543 */       throw new IllegalArgumentException();
/*     */     }
/* 545 */     boolean anyRetrived = false;
/* 546 */     long address = RemoteDeviceHelper.getAddress(serviceRecord.getHostDevice());
/* 547 */     for (int i = 0; i < attrIDs.length; i++) {
/* 548 */       int id = attrIDs[i];
/*     */       try {
/* 550 */         byte[] blob = getServiceAttributeImpl(address, serviceRecord.getHandle(), id);
/* 551 */         if (blob != null) {
/* 552 */           DataElement element = (new SDPInputStream(new ByteArrayInputStream(blob))).readElement();
/* 553 */           serviceRecord.populateAttributeValue(id, element);
/* 554 */           anyRetrived = true;
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 563 */       catch (Throwable e) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 569 */     return anyRetrived;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long connectionRfOpenClientConnection(BluetoothConnectionParams params) throws IOException {
/* 577 */     if (params.encrypt) {
/* 578 */       throw new BluetoothConnectionException(2, "encrypt mode not supported");
/*     */     }
/* 580 */     Object lock = RemoteDeviceHelper.createRemoteDevice(this, params.address, null, false);
/* 581 */     synchronized (lock) {
/* 582 */       return connectionRfOpenClientConnectionImpl(params.address, params.channel, params.authenticate, params.encrypt, params.timeout);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean rfEncrypt(long address, long handle, boolean on) throws IOException {
/* 596 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long rfServerOpen(BluetoothConnectionNotifierParams params, ServiceRecordImpl serviceRecord) throws IOException {
/* 608 */     verifyDeviceReady();
/* 609 */     if (params.encrypt) {
/* 610 */       throw new BluetoothConnectionException(2, "encrypt mode not supported");
/*     */     }
/* 612 */     byte[] uuidValue = Utils.UUIDToByteArray(params.uuid);
/* 613 */     long handle = rfServerCreateImpl(uuidValue, params.obex, params.name, params.authenticate, params.encrypt);
/* 614 */     boolean success = false;
/*     */     try {
/* 616 */       int channel = rfServerGetChannelID(handle);
/* 617 */       serviceRecord.populateRFCOMMAttributes(handle, channel, params.uuid, params.name, params.obex);
/* 618 */       success = true;
/*     */     } finally {
/* 620 */       if (!success) {
/* 621 */         rfServerCloseImpl(handle);
/*     */       }
/*     */     } 
/* 624 */     return handle;
/*     */   }
/*     */   
/*     */   public void rfServerClose(long handle, ServiceRecordImpl serviceRecord) throws IOException {
/* 628 */     rfServerCloseImpl(handle);
/*     */   }
/*     */   
/*     */   public void rfServerUpdateServiceRecord(long handle, ServiceRecordImpl serviceRecord, boolean acceptAndOpen) throws ServiceRegistrationException {
/* 632 */     sdpServiceUpdateServiceRecord(handle, 'R', serviceRecord);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void connectionRfCloseServerConnection(long handle) throws IOException {
/* 638 */     connectionRfCloseClientConnection(handle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void sdpServiceAddAttribute(long handle, char handleType, int attrID, DataElement element) throws ServiceRegistrationException {
/*     */     byte[] bs, bu;
/*     */     Enumeration e;
/* 651 */     int type = element.getDataType();
/* 652 */     switch (type) {
/*     */       case 0:
/* 654 */         sdpServiceAddAttribute(handle, handleType, attrID, type, 0L, null);
/*     */         return;
/*     */       case 40:
/* 657 */         sdpServiceAddAttribute(handle, handleType, attrID, type, element.getBoolean() ? 1L : 0L, null);
/*     */         return;
/*     */       case 8:
/*     */       case 9:
/*     */       case 10:
/*     */       case 16:
/*     */       case 17:
/*     */       case 18:
/*     */       case 19:
/* 666 */         sdpServiceAddAttribute(handle, handleType, attrID, type, element.getLong(), null);
/*     */         return;
/*     */       case 11:
/*     */       case 12:
/*     */       case 20:
/* 671 */         sdpServiceAddAttribute(handle, handleType, attrID, type, 0L, (byte[])element.getValue());
/*     */         return;
/*     */       case 24:
/* 674 */         sdpServiceAddAttribute(handle, handleType, attrID, type, 0L, Utils.UUIDToByteArray((UUID)element.getValue()));
/*     */         return;
/*     */       case 32:
/* 677 */         bs = Utils.getUTF8Bytes((String)element.getValue());
/* 678 */         sdpServiceAddAttribute(handle, handleType, attrID, type, 0L, bs);
/*     */         return;
/*     */       case 64:
/* 681 */         bu = Utils.getASCIIBytes((String)element.getValue());
/* 682 */         sdpServiceAddAttribute(handle, handleType, attrID, type, 0L, bu);
/*     */         return;
/*     */       case 48:
/*     */       case 56:
/* 686 */         sdpServiceSequenceAttributeStart(handle, handleType, attrID, type);
/* 687 */         for (e = (Enumeration)element.getValue(); e.hasMoreElements(); ) {
/* 688 */           DataElement child = e.nextElement();
/* 689 */           sdpServiceAddAttribute(handle, handleType, -1, child);
/*     */         } 
/* 691 */         sdpServiceSequenceAttributeEnd(handle, handleType, attrID);
/*     */         return;
/*     */     } 
/* 694 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   private void sdpServiceUpdateServiceRecord(long handle, char handleType, ServiceRecordImpl serviceRecord) throws ServiceRegistrationException {
/* 699 */     int[] ids = serviceRecord.getAttributeIDs();
/* 700 */     if (ids == null || ids.length == 0) {
/*     */       return;
/*     */     }
/* 703 */     for (int i = 0; i < ids.length; i++) {
/* 704 */       int attrID = ids[i];
/* 705 */       switch (attrID) {
/*     */         case 0:
/*     */         case 4:
/*     */         case 256:
/*     */           break;
/*     */         
/*     */         default:
/* 712 */           sdpServiceAddAttribute(handle, handleType, attrID, serviceRecord.getAttributeValue(attrID)); break;
/*     */       } 
/* 714 */     }  sdpServiceUpdateServiceRecordPublish(handle, handleType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connectionRfFlush(long handle) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connectionRfWrite(long handle, int b) throws IOException {
/* 730 */     byte[] buf = new byte[1];
/* 731 */     buf[0] = (byte)(b & 0xFF);
/* 732 */     connectionRfWrite(handle, buf, 0, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validateMTU(int receiveMTU, int transmitMTU) {
/* 742 */     if (receiveMTU > receiveMTUMAX()) {
/* 743 */       throw new IllegalArgumentException("invalid ReceiveMTU value " + receiveMTU);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long l2OpenClientConnection(BluetoothConnectionParams params, int receiveMTU, int transmitMTU) throws IOException {
/* 757 */     validateMTU(receiveMTU, transmitMTU);
/* 758 */     if (params.encrypt) {
/* 759 */       throw new BluetoothConnectionException(2, "encrypt mode not supported");
/*     */     }
/* 761 */     Object lock = RemoteDeviceHelper.createRemoteDevice(this, params.address, null, false);
/* 762 */     synchronized (lock) {
/* 763 */       return l2OpenClientConnectionImpl(params.address, params.channel, params.authenticate, params.encrypt, receiveMTU, transmitMTU, params.timeout);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long l2ServerOpen(BluetoothConnectionNotifierParams params, int receiveMTU, int transmitMTU, ServiceRecordImpl serviceRecord) throws IOException {
/* 786 */     verifyDeviceReady();
/* 787 */     validateMTU(receiveMTU, transmitMTU);
/* 788 */     if (params.encrypt) {
/* 789 */       throw new BluetoothConnectionException(2, "encrypt mode not supported");
/*     */     }
/* 791 */     byte[] uuidValue = Utils.UUIDToByteArray(params.uuid);
/* 792 */     long handle = l2ServerOpenImpl(uuidValue, params.authenticate, params.encrypt, params.name, receiveMTU, transmitMTU, params.bluecove_ext_psm);
/*     */     
/* 794 */     int channel = l2ServerPSM(handle);
/*     */     
/* 796 */     int serviceRecordHandle = (int)handle;
/*     */     
/* 798 */     serviceRecord.populateL2CAPAttributes(serviceRecordHandle, channel, params.uuid, params.name);
/*     */     
/* 800 */     return handle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void l2ServerUpdateServiceRecord(long handle, ServiceRecordImpl serviceRecord, boolean acceptAndOpen) throws ServiceRegistrationException {
/* 810 */     sdpServiceUpdateServiceRecord(handle, 'L', serviceRecord);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void l2CloseServerConnection(long handle) throws IOException {
/* 827 */     l2CloseClientConnection(handle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void l2ServerClose(long handle, ServiceRecordImpl serviceRecord) throws IOException {
/* 839 */     l2ServerCloseImpl(handle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean l2Encrypt(long address, long handle, boolean on) throws IOException {
/* 897 */     return false;
/*     */   }
/*     */   
/*     */   public native boolean isNativeCodeLoaded();
/*     */   
/*     */   public native int getLibraryVersion();
/*     */   
/*     */   public native int detectBluetoothStack();
/*     */   
/*     */   private native boolean initializeImpl();
/*     */   
/*     */   public native void enableNativeDebug(Class paramClass, boolean paramBoolean);
/*     */   
/*     */   public native String getLocalDeviceBluetoothAddress() throws BluetoothStateException;
/*     */   
/*     */   public native String getLocalDeviceName();
/*     */   
/*     */   private native int getDeviceClassImpl();
/*     */   
/*     */   private native boolean setLocalDeviceServiceClassesImpl(int paramInt);
/*     */   
/*     */   public native boolean isLocalDevicePowerOn();
/*     */   
/*     */   private native boolean isLocalDeviceFeatureSwitchRoles();
/*     */   
/*     */   private native boolean isLocalDeviceFeatureParkMode();
/*     */   
/*     */   private native boolean isLocalDeviceFeatureRSSI();
/*     */   
/*     */   private native int getLocalDeviceL2CAPMTUMaximum();
/*     */   
/*     */   private native int getLocalDeviceSupportedSoftwareVersion();
/*     */   
/*     */   private native String getLocalDeviceSoftwareVersionInfo();
/*     */   
/*     */   private native int getLocalDeviceManufacturer();
/*     */   
/*     */   private native String getLocalDeviceVersion();
/*     */   
/*     */   private native boolean getLocalDeviceDiscoverableImpl();
/*     */   
/*     */   private native boolean retrieveDevicesImpl(int paramInt, RetrieveDevicesCallback paramRetrieveDevicesCallback);
/*     */   
/*     */   private native boolean isRemoteDeviceTrustedImpl(long paramLong);
/*     */   
/*     */   private native boolean isRemoteDeviceAuthenticatedImpl(long paramLong);
/*     */   
/*     */   private native int readRemoteDeviceRSSIImpl(long paramLong) throws IOException;
/*     */   
/*     */   private native boolean authenticateRemoteDeviceImpl(long paramLong) throws IOException;
/*     */   
/*     */   public native String getRemoteDeviceFriendlyName(long paramLong) throws IOException;
/*     */   
/*     */   private native int runDeviceInquiryImpl(DeviceInquiryRunnable paramDeviceInquiryRunnable, DeviceInquiryThread paramDeviceInquiryThread, int paramInt1, int paramInt2, DiscoveryListener paramDiscoveryListener) throws BluetoothStateException;
/*     */   
/*     */   private native boolean deviceInquiryCancelImpl();
/*     */   
/*     */   private native int runSearchServicesImpl(long paramLong, int paramInt) throws BluetoothStateException, SearchServicesException;
/*     */   
/*     */   private native void cancelServiceSearchImpl(int paramInt);
/*     */   
/*     */   private native byte[] getServiceAttributeImpl(long paramLong1, long paramLong2, int paramInt);
/*     */   
/*     */   private native long connectionRfOpenClientConnectionImpl(long paramLong, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2) throws IOException;
/*     */   
/*     */   public native void connectionRfCloseClientConnection(long paramLong) throws IOException;
/*     */   
/*     */   public native int rfGetSecurityOpt(long paramLong, int paramInt) throws IOException;
/*     */   
/*     */   private native long rfServerCreateImpl(byte[] paramArrayOfbyte, boolean paramBoolean1, String paramString, boolean paramBoolean2, boolean paramBoolean3) throws IOException;
/*     */   
/*     */   private native int rfServerGetChannelID(long paramLong) throws IOException;
/*     */   
/*     */   private native void rfServerCloseImpl(long paramLong) throws IOException;
/*     */   
/*     */   public native long rfServerAcceptAndOpenRfServerConnection(long paramLong) throws IOException;
/*     */   
/*     */   private native void sdpServiceUpdateServiceRecordPublish(long paramLong, char paramChar) throws ServiceRegistrationException;
/*     */   
/*     */   private native void sdpServiceAddAttribute(long paramLong1, char paramChar, int paramInt1, int paramInt2, long paramLong2, byte[] paramArrayOfbyte) throws ServiceRegistrationException;
/*     */   
/*     */   private native void sdpServiceSequenceAttributeStart(long paramLong, char paramChar, int paramInt1, int paramInt2) throws ServiceRegistrationException;
/*     */   
/*     */   private native void sdpServiceSequenceAttributeEnd(long paramLong, char paramChar, int paramInt) throws ServiceRegistrationException;
/*     */   
/*     */   public native int connectionRfRead(long paramLong) throws IOException;
/*     */   
/*     */   public native int connectionRfRead(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   public native int connectionRfReadAvailable(long paramLong) throws IOException;
/*     */   
/*     */   public native void connectionRfWrite(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   public native long getConnectionRfRemoteAddress(long paramLong) throws IOException;
/*     */   
/*     */   private native long l2OpenClientConnectionImpl(long paramLong, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3, int paramInt4) throws IOException;
/*     */   
/*     */   public native void l2CloseClientConnection(long paramLong) throws IOException;
/*     */   
/*     */   private native long l2ServerOpenImpl(byte[] paramArrayOfbyte, boolean paramBoolean1, boolean paramBoolean2, String paramString, int paramInt1, int paramInt2, int paramInt3) throws IOException;
/*     */   
/*     */   public native int l2ServerPSM(long paramLong) throws IOException;
/*     */   
/*     */   public native long l2ServerAcceptAndOpenServerConnection(long paramLong) throws IOException;
/*     */   
/*     */   private native void l2ServerCloseImpl(long paramLong) throws IOException;
/*     */   
/*     */   public native int l2GetSecurityOpt(long paramLong, int paramInt) throws IOException;
/*     */   
/*     */   public native boolean l2Ready(long paramLong) throws IOException;
/*     */   
/*     */   public native int l2Receive(long paramLong, byte[] paramArrayOfbyte) throws IOException;
/*     */   
/*     */   public native void l2Send(long paramLong, byte[] paramArrayOfbyte, int paramInt) throws IOException;
/*     */   
/*     */   public native int l2GetReceiveMTU(long paramLong) throws IOException;
/*     */   
/*     */   public native int l2GetTransmitMTU(long paramLong) throws IOException;
/*     */   
/*     */   public native long l2RemoteAddress(long paramLong) throws IOException;
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothStackOSX.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */