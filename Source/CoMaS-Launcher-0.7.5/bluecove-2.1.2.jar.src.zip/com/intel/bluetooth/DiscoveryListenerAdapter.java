/*    */ package com.intel.bluetooth;
/*    */ 
/*    */ import javax.bluetooth.DeviceClass;
/*    */ import javax.bluetooth.DiscoveryListener;
/*    */ import javax.bluetooth.RemoteDevice;
/*    */ import javax.bluetooth.ServiceRecord;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DiscoveryListenerAdapter
/*    */   implements DiscoveryListener
/*    */ {
/*    */   public void deviceDiscovered(RemoteDevice btDevice, DeviceClass cod) {}
/*    */   
/*    */   public void inquiryCompleted(int discType) {
/* 53 */     DebugLog.debug("inquiryCompleted", discType);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void serviceSearchCompleted(int transID, int respCode) {
/* 62 */     DebugLog.debug("serviceSearchCompleted", respCode);
/*    */   }
/*    */   
/*    */   public void servicesDiscovered(int transID, ServiceRecord[] servRecord) {}
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\DiscoveryListenerAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */