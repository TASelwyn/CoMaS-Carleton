/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import javax.bluetooth.DeviceClass;
/*     */ import javax.bluetooth.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BluetoothConsts
/*     */ {
/*     */   public static final String SHORT_UUID_BASE = "00001000800000805F9B34FB";
/*     */   public static final String PROTOCOL_SCHEME_L2CAP = "btl2cap";
/*     */   public static final String PROTOCOL_SCHEME_RFCOMM = "btspp";
/*     */   public static final String PROTOCOL_SCHEME_BT_OBEX = "btgoep";
/*     */   public static final String PROTOCOL_SCHEME_TCP_OBEX = "tcpobex";
/*  48 */   public static final UUID L2CAP_PROTOCOL_UUID = new UUID(256L);
/*     */   
/*  50 */   public static final UUID RFCOMM_PROTOCOL_UUID = new UUID(3L);
/*     */   
/*  52 */   public static final UUID OBEX_PROTOCOL_UUID = new UUID(8L);
/*     */   
/*  54 */   public static final UUID OBEXFileTransferServiceClass_UUID = new UUID(4358L);
/*     */   
/*     */   public static final int RFCOMM_CHANNEL_MIN = 1;
/*     */   
/*     */   public static final int RFCOMM_CHANNEL_MAX = 30;
/*     */   
/*     */   public static final int L2CAP_PSM_MIN = 5;
/*     */   
/*     */   public static final int L2CAP_PSM_MIN_JSR_82 = 4097;
/*     */   
/*     */   public static final int L2CAP_PSM_MAX = 65535;
/*     */   
/*     */   public static final int TCP_OBEX_DEFAULT_PORT = 650;
/*     */   
/*     */   public static final String PROPERTY_BLUETOOTH_API_VERSION = "bluetooth.api.version";
/*     */   
/*     */   public static final String PROPERTY_OBEX_API_VERSION = "obex.api.version";
/*     */   
/*     */   public static final String PROPERTY_BLUETOOTH_MASTER_SWITCH = "bluetooth.master.switch";
/*     */   
/*     */   public static final String PROPERTY_BLUETOOTH_SD_ATTR_RETRIEVABLE_MAX = "bluetooth.sd.attr.retrievable.max";
/*     */   
/*     */   public static final String PROPERTY_BLUETOOTH_CONNECTED_DEVICES_MAX = "bluetooth.connected.devices.max";
/*     */   
/*     */   public static final String PROPERTY_BLUETOOTH_L2CAP_RECEIVEMTU_MAX = "bluetooth.l2cap.receiveMTU.max";
/*     */   
/*     */   public static final String PROPERTY_BLUETOOTH_SD_TRANS_MAX = "bluetooth.sd.trans.max";
/*     */   
/*     */   public static final String PROPERTY_BLUETOOTH_CONNECTED_INQUIRY_SCAN = "bluetooth.connected.inquiry.scan";
/*     */   
/*     */   public static final String PROPERTY_BLUETOOTH_CONNECTED_PAGE_SCAN = "bluetooth.connected.page.scan";
/*     */   
/*     */   public static final String PROPERTY_BLUETOOTH_CONNECTED_INQUIRY = "bluetooth.connected.inquiry";
/*     */   
/*     */   public static final String PROPERTY_BLUETOOTH_CONNECTED_PAGE = "bluetooth.connected.page";
/*     */   
/*  90 */   static Hashtable obexUUIDs = new Hashtable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void addObex(int uuid) {
/*  97 */     UUID u = new UUID(uuid);
/*  98 */     obexUUIDs.put(u, u);
/*     */   }
/*     */   
/*     */   static {
/* 102 */     addObex(4356);
/* 103 */     addObex(4357);
/* 104 */     addObex(4358);
/* 105 */     addObex(4359);
/* 106 */     addObex(4379);
/*     */   }
/*     */   
/* 109 */   public static final UUID SERIAL_PORT_UUID = new UUID(4353L);
/*     */   
/*     */   public static final int BluetoothProfileDescriptorList = 9;
/*     */   
/*     */   public static final int BrowseGroupList = 5;
/*     */   
/*     */   public static final int ClientExecutableURL = 11;
/*     */   
/*     */   public static final int DocumentationURL = 10;
/*     */   
/*     */   public static final int IconURL = 12;
/*     */   
/*     */   public static final int LanguageBasedAttributeIDList = 6;
/*     */   
/*     */   public static final int ProtocolDescriptorList = 4;
/*     */   
/*     */   public static final int ProviderName = 2;
/*     */   
/*     */   public static final int ServiceAvailability = 8;
/*     */   
/*     */   public static final int ServiceClassIDList = 1;
/*     */   
/*     */   public static final int ServiceDatabaseState = 513;
/*     */   
/*     */   public static final int ServiceDescription = 1;
/*     */   
/*     */   public static final int ServiceID = 3;
/*     */   
/*     */   public static final int ServiceInfoTimeToLive = 7;
/*     */   
/*     */   public static final int AttributeIDServiceName = 256;
/*     */   
/*     */   public static final int ServiceName = 0;
/*     */   
/*     */   public static final int ServiceRecordHandle = 0;
/*     */   
/*     */   public static final int ServiceRecordState = 2;
/*     */   
/*     */   public static final int VersionNumberList = 512;
/*     */   
/*     */   public static String toString(DeviceClass dc) {
/* 150 */     return DeviceClassConsts.toString(dc);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class DeviceClassConsts
/*     */   {
/*     */     public static final int SERVICE_MASK = 16769024;
/*     */ 
/*     */     
/*     */     public static final int MAJOR_MASK = 7936;
/*     */ 
/*     */     
/*     */     public static final int MINOR_MASK = 252;
/*     */ 
/*     */     
/*     */     public static final int FORMAT_VERSION_MASK = 3;
/*     */ 
/*     */     
/*     */     public static final int LIMITED_DISCOVERY_SERVICE = 8192;
/*     */ 
/*     */     
/*     */     public static final int RESERVED1_SERVICE = 16384;
/*     */ 
/*     */     
/*     */     public static final int RESERVED2_SERVICE = 32768;
/*     */ 
/*     */     
/*     */     public static final int POSITIONING_SERVICE = 65536;
/*     */ 
/*     */     
/*     */     public static final int NETWORKING_SERVICE = 131072;
/*     */ 
/*     */     
/*     */     public static final int RENDERING_SERVICE = 262144;
/*     */ 
/*     */     
/*     */     public static final int CAPTURING_SERVICE = 524288;
/*     */ 
/*     */     
/*     */     public static final int OBJECT_TRANSFER_SERVICE = 1048576;
/*     */ 
/*     */     
/*     */     public static final int AUDIO_SERVICE = 2097152;
/*     */     
/*     */     public static final int TELEPHONY_SERVICE = 4194304;
/*     */     
/*     */     public static final int INFORMATION_SERVICE = 8388608;
/*     */     
/*     */     public static final int MAJOR_MISCELLANEOUS = 0;
/*     */     
/*     */     public static final int MAJOR_COMPUTER = 256;
/*     */     
/*     */     public static final int MAJOR_PHONE = 512;
/*     */     
/*     */     public static final int MAJOR_LAN_ACCESS = 768;
/*     */     
/*     */     public static final int MAJOR_AUDIO = 1024;
/*     */     
/*     */     public static final int MAJOR_PERIPHERAL = 1280;
/*     */     
/*     */     public static final int MAJOR_IMAGING = 1536;
/*     */     
/*     */     public static final int MAJOR_UNCLASSIFIED = 7936;
/*     */     
/*     */     public static final int COMPUTER_MINOR_UNCLASSIFIED = 0;
/*     */     
/*     */     public static final int COMPUTER_MINOR_DESKTOP = 4;
/*     */     
/*     */     public static final int COMPUTER_MINOR_SERVER = 8;
/*     */     
/*     */     public static final int COMPUTER_MINOR_LAPTOP = 12;
/*     */     
/*     */     public static final int COMPUTER_MINOR_HANDHELD = 16;
/*     */     
/*     */     public static final int COMPUTER_MINOR_PALM = 20;
/*     */     
/*     */     public static final int COMPUTER_MINOR_WEARABLE = 24;
/*     */     
/*     */     public static final int PHONE_MINOR_UNCLASSIFIED = 0;
/*     */     
/*     */     public static final int PHONE_MINOR_CELLULAR = 4;
/*     */     
/*     */     public static final int PHONE_MINOR_CORDLESS = 8;
/*     */     
/*     */     public static final int PHONE_MINOR_SMARTPHONE = 12;
/*     */     
/*     */     public static final int PHONE_MINOR_WIRED_MODEM = 16;
/*     */     
/*     */     public static final int PHONE_MINOR_ISDN = 20;
/*     */     
/*     */     public static final int PHONE_MINOR_BANANA = 24;
/*     */     
/*     */     public static final int LAN_MINOR_TYPE_MASK = 28;
/*     */     
/*     */     public static final int LAN_MINOR_ACCESS_MASK = 224;
/*     */     
/*     */     public static final int LAN_MINOR_UNCLASSIFIED = 0;
/*     */     
/*     */     public static final int LAN_MINOR_ACCESS_0_USED = 0;
/*     */     
/*     */     public static final int LAN_MINOR_ACCESS_17_USED = 32;
/*     */     
/*     */     public static final int LAN_MINOR_ACCESS_33_USED = 64;
/*     */     
/*     */     public static final int LAN_MINOR_ACCESS_50_USED = 96;
/*     */     
/*     */     public static final int LAN_MINOR_ACCESS_67_USED = 128;
/*     */     
/*     */     public static final int LAN_MINOR_ACCESS_83_USED = 160;
/*     */     
/*     */     public static final int LAN_MINOR_ACCESS_99_USED = 192;
/*     */     
/*     */     public static final int LAN_MINOR_ACCESS_FULL = 224;
/*     */     
/*     */     public static final int AUDIO_MINOR_UNCLASSIFIED = 0;
/*     */     
/*     */     public static final int AUDIO_MINOR_HEADSET = 4;
/*     */     
/*     */     public static final int AUDIO_MINOR_HANDS_FREE = 8;
/*     */     
/*     */     public static final int AUDIO_MINOR_MICROPHONE = 16;
/*     */     
/*     */     public static final int AUDIO_MINOR_LOUDSPEAKER = 20;
/*     */     
/*     */     public static final int AUDIO_MINOR_HEADPHONES = 24;
/*     */     
/*     */     public static final int AUDIO_MINOR_PORTABLE_AUDIO = 28;
/*     */     
/*     */     public static final int AUDIO_MINOR_CAR_AUDIO = 32;
/*     */     
/*     */     public static final int AUDIO_MINOR_SET_TOP_BOX = 36;
/*     */     
/*     */     public static final int AUDIO_MINOR_HIFI_AUDIO = 40;
/*     */     
/*     */     public static final int AUDIO_MINOR_VCR = 44;
/*     */     
/*     */     public static final int AUDIO_MINOR_VIDEO_CAMERA = 48;
/*     */     
/*     */     public static final int AUDIO_MINOR_CAMCORDER = 52;
/*     */     
/*     */     public static final int AUDIO_MINOR_VIDEO_MONITOR = 56;
/*     */     
/*     */     public static final int AUDIO_MINOR_VIDEO_DISPLAY_LOUDSPEAKER = 60;
/*     */     
/*     */     public static final int AUDIO_MINOR_VIDEO_DISPLAY_CONFERENCING = 64;
/*     */     
/*     */     public static final int AUDIO_MINOR_GAMING_TOY = 72;
/*     */     
/*     */     public static final int PERIPHERAL_MINOR_TYPE_MASK = 60;
/*     */     
/*     */     public static final int PERIPHERAL_MINOR_KEYBOARD_MASK = 64;
/*     */     
/*     */     public static final int PERIPHERAL_MINOR_POINTER_MASK = 128;
/*     */     
/*     */     public static final int PERIPHERAL_MINOR_UNCLASSIFIED = 0;
/*     */     
/*     */     public static final int PERIPHERAL_MINOR_JOYSTICK = 4;
/*     */     
/*     */     public static final int PERIPHERAL_MINOR_GAMEPAD = 8;
/*     */     
/*     */     public static final int PERIPHERAL_MINOR_REMOTE_CONTROL = 12;
/*     */     
/*     */     public static final int PERIPHERAL_MINOR_SENSING = 16;
/*     */     
/*     */     public static final int PERIPHERAL_MINOR_DIGITIZER = 20;
/*     */     
/*     */     public static final int PERIPHERAL_MINOR_CARD_READER = 24;
/*     */     
/*     */     public static final int IMAGING_MINOR_DISPLAY_MASK = 16;
/*     */     
/*     */     public static final int IMAGING_MINOR_CAMERA_MASK = 32;
/*     */     
/*     */     public static final int IMAGING_MINOR_SCANNER_MASK = 64;
/*     */     
/*     */     public static final int IMAGING_MINOR_PRINTER_MASK = 128;
/*     */ 
/*     */     
/*     */     private static boolean append(StringBuffer buf, String str, boolean comma) {
/* 329 */       if (comma) {
/* 330 */         buf.append(',');
/*     */       }
/* 332 */       buf.append(str);
/* 333 */       return true;
/*     */     } public static String toString(DeviceClass dc) {
/*     */       int minor;
/*     */       boolean bool1;
/* 337 */       StringBuffer buf = new StringBuffer();
/*     */       
/* 339 */       switch (dc.getMajorDeviceClass()) {
/*     */         case 0:
/* 341 */           buf.append("Miscellaneous");
/*     */           break;
/*     */         case 256:
/* 344 */           buf.append("Computer");
/*     */           
/* 346 */           switch (dc.getMinorDeviceClass()) {
/*     */             case 0:
/* 348 */               buf.append("/Unclassified");
/*     */               break;
/*     */             case 4:
/* 351 */               buf.append("/Desktop");
/*     */               break;
/*     */             case 8:
/* 354 */               buf.append("/Server");
/*     */               break;
/*     */             case 12:
/* 357 */               buf.append("/Laptop");
/*     */               break;
/*     */             case 16:
/* 360 */               buf.append("/Handheld");
/*     */               break;
/*     */             case 20:
/* 363 */               buf.append("/Palm");
/*     */               break;
/*     */             case 24:
/* 366 */               buf.append("/Wearable");
/*     */               break;
/*     */           } 
/* 369 */           buf.append("/Unknown");
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         case 512:
/* 375 */           buf.append("Phone");
/*     */           
/* 377 */           switch (dc.getMinorDeviceClass()) {
/*     */             case 0:
/* 379 */               buf.append("/Unclassified");
/*     */               break;
/*     */             case 4:
/* 382 */               buf.append("/Cellular");
/*     */               break;
/*     */             case 8:
/* 385 */               buf.append("/Cordless");
/*     */               break;
/*     */             case 12:
/* 388 */               buf.append("/Smartphone");
/*     */               break;
/*     */             case 16:
/* 391 */               buf.append("/Wired Modem");
/*     */               break;
/*     */             case 20:
/* 394 */               buf.append("/ISDN");
/*     */               break;
/*     */             case 24:
/* 397 */               buf.append("/Ring ring ring ring ring ring ring");
/*     */               break;
/*     */           } 
/* 400 */           buf.append("/Unknown");
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         case 768:
/* 406 */           buf.append("LAN Access");
/*     */           
/* 408 */           minor = dc.getMinorDeviceClass();
/*     */           
/* 410 */           switch (minor & 0x1C) {
/*     */             case 0:
/* 412 */               buf.append("/Unclassified");
/*     */               break;
/*     */             default:
/* 415 */               buf.append("/Unknown");
/*     */               break;
/*     */           } 
/*     */           
/* 419 */           switch (minor & 0xE0) {
/*     */             case 0:
/* 421 */               buf.append("/0% used");
/*     */               break;
/*     */             case 32:
/* 424 */               buf.append("/1-17% used");
/*     */               break;
/*     */             case 64:
/* 427 */               buf.append("/18-33% used");
/*     */               break;
/*     */             case 96:
/* 430 */               buf.append("/34-50% used");
/*     */               break;
/*     */             case 128:
/* 433 */               buf.append("/51-67% used");
/*     */               break;
/*     */             case 160:
/* 436 */               buf.append("/68-83% used");
/*     */               break;
/*     */             case 192:
/* 439 */               buf.append("/84-99% used");
/*     */               break;
/*     */             case 224:
/* 442 */               buf.append("/100% used");
/*     */               break;
/*     */           } 
/*     */           
/*     */           break;
/*     */         
/*     */         case 1024:
/* 449 */           buf.append("Audio");
/*     */           
/* 451 */           switch (dc.getMinorDeviceClass()) {
/*     */             case 0:
/* 453 */               buf.append("/Unclassified");
/*     */               break;
/*     */             case 4:
/* 456 */               buf.append("/Headset");
/*     */               break;
/*     */             case 8:
/* 459 */               buf.append("/Hands-free");
/*     */               break;
/*     */             case 16:
/* 462 */               buf.append("/Microphone");
/*     */               break;
/*     */             case 20:
/* 465 */               buf.append("/Loudspeaker");
/*     */               break;
/*     */             case 24:
/* 468 */               buf.append("/Headphones");
/*     */               break;
/*     */             case 28:
/* 471 */               buf.append("/Portable");
/*     */               break;
/*     */             case 32:
/* 474 */               buf.append("/Car");
/*     */               break;
/*     */             case 36:
/* 477 */               buf.append("/Set-top Box");
/*     */               break;
/*     */             case 40:
/* 480 */               buf.append("/HiFi");
/*     */               break;
/*     */             case 44:
/* 483 */               buf.append("/VCR");
/*     */               break;
/*     */             case 48:
/* 486 */               buf.append("/Video Camera");
/*     */               break;
/*     */             case 52:
/* 489 */               buf.append("/Camcorder");
/*     */               break;
/*     */             case 56:
/* 492 */               buf.append("/Video Monitor");
/*     */               break;
/*     */             case 60:
/* 495 */               buf.append("/Video Display Loudspeaker");
/*     */               break;
/*     */             case 64:
/* 498 */               buf.append("/Video Display Conferencing");
/*     */               break;
/*     */             case 72:
/* 501 */               buf.append("/Gaming Toy");
/*     */               break;
/*     */           } 
/* 504 */           buf.append("/Unknown");
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         case 1280:
/* 510 */           buf.append("Peripheral");
/*     */           
/* 512 */           minor = dc.getMinorDeviceClass();
/*     */           
/* 514 */           switch (minor & 0xC0) {
/*     */             case 0:
/* 516 */               buf.append("/()");
/*     */               break;
/*     */             case 64:
/* 519 */               buf.append("/(Keyboard)");
/*     */               break;
/*     */             case 128:
/* 522 */               buf.append("/(Pointer)");
/*     */               break;
/*     */             case 192:
/* 525 */               buf.append("/(Keyboard,Pointer)");
/*     */               break;
/*     */           } 
/*     */           
/* 529 */           switch (minor & 0x3C) {
/*     */             case 0:
/* 531 */               buf.append("/Unclassified");
/*     */               break;
/*     */             case 4:
/* 534 */               buf.append("/Joystick");
/*     */               break;
/*     */             case 8:
/* 537 */               buf.append("/Gamepad");
/*     */               break;
/*     */             case 12:
/* 540 */               buf.append("/Remote Control");
/*     */               break;
/*     */             case 16:
/* 543 */               buf.append("/Sensing");
/*     */               break;
/*     */             case 20:
/* 546 */               buf.append("/Digitizer");
/*     */               break;
/*     */             case 24:
/* 549 */               buf.append("/Card Reader");
/*     */               break;
/*     */           } 
/* 552 */           buf.append("/Unknown");
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 1536:
/* 559 */           buf.append("Peripheral/(");
/*     */           
/* 561 */           minor = dc.getMinorDeviceClass();
/*     */           
/* 563 */           bool1 = false;
/*     */           
/* 565 */           if ((minor & 0x10) != 0) {
/* 566 */             bool1 = append(buf, "Display", bool1);
/*     */           }
/* 568 */           if ((minor & 0x20) != 0) {
/* 569 */             bool1 = append(buf, "Camera", bool1);
/*     */           }
/* 571 */           if ((minor & 0x40) != 0) {
/* 572 */             bool1 = append(buf, "Scanner", bool1);
/*     */           }
/* 574 */           if ((minor & 0x80) != 0) {
/* 575 */             append(buf, "Printer", bool1);
/*     */           }
/*     */           
/* 578 */           buf.append(')');
/*     */           break;
/*     */ 
/*     */         
/*     */         case 7936:
/* 583 */           buf.append("Unclassified");
/*     */           break;
/*     */         default:
/* 586 */           buf.append("Unknown");
/*     */           break;
/*     */       } 
/*     */       
/* 590 */       buf.append("/(");
/*     */       
/* 592 */       boolean comma = false;
/*     */       
/* 594 */       int record = dc.getServiceClasses();
/*     */       
/* 596 */       if ((record & 0x2000) != 0) {
/* 597 */         comma = append(buf, "Limited Discovery", comma);
/*     */       }
/* 599 */       if ((record & 0x10000) != 0) {
/* 600 */         comma = append(buf, "Positioning", comma);
/*     */       }
/* 602 */       if ((record & 0x20000) != 0) {
/* 603 */         comma = append(buf, "Networking", comma);
/*     */       }
/* 605 */       if ((record & 0x40000) != 0) {
/* 606 */         comma = append(buf, "Rendering", comma);
/*     */       }
/* 608 */       if ((record & 0x80000) != 0) {
/* 609 */         comma = append(buf, "Capturing", comma);
/*     */       }
/* 611 */       if ((record & 0x100000) != 0) {
/* 612 */         comma = append(buf, "Object Transfer", comma);
/*     */       }
/* 614 */       if ((record & 0x200000) != 0) {
/* 615 */         comma = append(buf, "Audio", comma);
/*     */       }
/* 617 */       if ((record & 0x400000) != 0) {
/* 618 */         comma = append(buf, "Telephony", comma);
/*     */       }
/* 620 */       if ((record & 0x800000) != 0) {
/* 621 */         append(buf, "Information", comma);
/*     */       }
/*     */       
/* 624 */       buf.append(')');
/*     */       
/* 626 */       return buf.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothConsts.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */