package com.intel.bluetooth;

import java.io.IOException;

public interface BluetoothStackExtension {
  int readRemoteDeviceRSSI(long paramLong) throws IOException;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothStackExtension.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */