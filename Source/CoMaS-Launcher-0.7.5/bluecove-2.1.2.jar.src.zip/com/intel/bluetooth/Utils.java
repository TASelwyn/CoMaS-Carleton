/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ import javax.bluetooth.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Utils
/*     */ {
/*  44 */   private static final String blueCoveImplPackage = getPackage(MicroeditionConnector.class.getName());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getPackage(String className) {
/*  51 */     int pStart = className.lastIndexOf('.');
/*  52 */     if (pStart == -1) {
/*  53 */       return "";
/*     */     }
/*  55 */     return className.substring(0, pStart);
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] UUIDToByteArray(String uuidStringValue) {
/*  60 */     byte[] uuidValue = new byte[16];
/*  61 */     if (uuidStringValue.indexOf('-') != -1) {
/*  62 */       throw new NumberFormatException("The '-' character is not allowed in UUID: " + uuidStringValue);
/*     */     }
/*  64 */     for (int i = 0; i < 16; i++) {
/*  65 */       uuidValue[i] = (byte)Integer.parseInt(uuidStringValue.substring(i * 2, i * 2 + 2), 16);
/*     */     }
/*  67 */     return uuidValue;
/*     */   }
/*     */   
/*     */   static byte[] UUIDToByteArray(UUID uuid) {
/*  71 */     return UUIDToByteArray(uuid.toString());
/*     */   }
/*     */   
/*     */   public static String UUIDByteArrayToString(byte[] uuidValue) {
/*  75 */     StringBuffer buf = new StringBuffer();
/*  76 */     for (int i = 0; i < uuidValue.length; i++) {
/*  77 */       buf.append(Integer.toHexString(uuidValue[i] >> 4 & 0xF));
/*  78 */       buf.append(Integer.toHexString(uuidValue[i] & 0xF));
/*     */     } 
/*  80 */     return buf.toString();
/*     */   }
/*     */   
/*     */   static long UUIDTo32Bit(UUID uuid) {
/*  84 */     if (uuid == null) {
/*  85 */       return -1L;
/*     */     }
/*  87 */     String str = uuid.toString().toUpperCase();
/*  88 */     int shortIdx = str.indexOf("00001000800000805F9B34FB");
/*  89 */     if (shortIdx != -1 && shortIdx + "00001000800000805F9B34FB".length() == str.length())
/*     */     {
/*  91 */       return Long.parseLong(str.substring(0, shortIdx), 16);
/*     */     }
/*  93 */     return -1L;
/*     */   }
/*     */   
/*     */   static boolean is32Bit(UUID uuid) {
/*  97 */     return (UUIDTo32Bit(uuid) != -1L);
/*     */   }
/*     */   
/*     */   public static int securityOpt(boolean authenticate, boolean encrypt) {
/* 101 */     int security = 0;
/* 102 */     if (authenticate) {
/* 103 */       if (encrypt) {
/* 104 */         security = 2;
/*     */       } else {
/* 106 */         security = 1;
/*     */       } 
/* 108 */     } else if (encrypt) {
/* 109 */       throw new IllegalArgumentException("Illegal encrypt configuration");
/*     */     } 
/* 111 */     return security;
/*     */   }
/*     */   
/*     */   static boolean isStringSet(String str) {
/* 115 */     return (str != null && str.length() > 0);
/*     */   }
/*     */   
/*     */   static String loadString(InputStream inputstream) {
/* 119 */     if (inputstream == null) {
/* 120 */       return null;
/*     */     }
/*     */     try {
/* 123 */       byte[] buf = new byte[256];
/* 124 */       int len = inputstream.read(buf);
/* 125 */       return new String(buf, 0, len);
/* 126 */     } catch (IOException e) {
/* 127 */       return null;
/*     */     } finally {
/*     */       try {
/* 130 */         inputstream.close();
/* 131 */       } catch (IOException ignore) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static String getResourceProperty(Class owner, String resourceName) {
/*     */     try {
/* 138 */       String value = loadString(owner.getResourceAsStream("/" + resourceName));
/* 139 */       if (value != null) {
/* 140 */         int cr = value.indexOf('\n');
/* 141 */         if (cr != -1) {
/* 142 */           value = value.substring(0, cr - 1);
/*     */         }
/*     */       } 
/* 145 */       return value;
/* 146 */     } catch (Throwable e) {
/* 147 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] clone(byte[] value) {
/* 159 */     if (value == null) {
/* 160 */       return null;
/*     */     }
/* 162 */     int length = value.length;
/* 163 */     byte[] bClone = new byte[length];
/* 164 */     System.arraycopy(value, 0, bClone, 0, length);
/* 165 */     return bClone;
/*     */   }
/*     */   
/*     */   public static Vector clone(Enumeration en) {
/* 169 */     Vector copy = new Vector();
/* 170 */     while (en.hasMoreElements()) {
/* 171 */       copy.addElement(en.nextElement());
/*     */     }
/* 173 */     return copy;
/*     */   }
/*     */   
/*     */   static String newStringUTF8(byte[] bytes) {
/*     */     try {
/* 178 */       return new String(bytes, "UTF-8");
/* 179 */     } catch (IllegalArgumentException e) {
/* 180 */       return new String(bytes);
/* 181 */     } catch (UnsupportedEncodingException e) {
/* 182 */       return new String(bytes);
/*     */     } 
/*     */   }
/*     */   
/*     */   static byte[] getUTF8Bytes(String str) {
/*     */     try {
/* 188 */       return str.getBytes("UTF-8");
/* 189 */     } catch (IllegalArgumentException e) {
/* 190 */       return str.getBytes();
/* 191 */     } catch (UnsupportedEncodingException e) {
/* 192 */       return str.getBytes();
/*     */     } 
/*     */   }
/*     */   
/*     */   static String newStringASCII(byte[] bytes) {
/*     */     try {
/* 198 */       return new String(bytes, "US-ASCII");
/* 199 */     } catch (IllegalArgumentException e) {
/* 200 */       return new String(bytes);
/* 201 */     } catch (UnsupportedEncodingException e) {
/* 202 */       return new String(bytes);
/*     */     } 
/*     */   }
/*     */   
/*     */   static byte[] getASCIIBytes(String str) {
/*     */     try {
/* 208 */       return str.getBytes("US-ASCII");
/* 209 */     } catch (IllegalArgumentException e) {
/* 210 */       return str.getBytes();
/* 211 */     } catch (UnsupportedEncodingException e) {
/* 212 */       return str.getBytes();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object[] vector2toArray(Vector vector, Object[] anArray) {
/* 221 */     vector.copyInto(anArray);
/* 222 */     return anArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toHexString(long l) {
/* 230 */     StringBuffer buf = new StringBuffer();
/* 231 */     String lo = Integer.toHexString((int)l);
/* 232 */     if (l > 4294967295L) {
/* 233 */       String hi = Integer.toHexString((int)(l >> 32L));
/* 234 */       buf.append(hi);
/* 235 */       for (int i = lo.length(); i < 8; i++) {
/* 236 */         buf.append('0');
/*     */       }
/*     */     } 
/* 239 */     buf.append(lo);
/* 240 */     return buf.toString();
/*     */   }
/*     */   
/*     */   static void j2meUsagePatternDellay() {
/*     */     try {
/* 245 */       Thread.sleep(100L);
/* 246 */     } catch (InterruptedException e) {}
/*     */   }
/*     */ 
/*     */   
/*     */   static class TimerThread
/*     */     extends Thread
/*     */   {
/*     */     long delay;
/*     */     Runnable run;
/*     */     
/*     */     public TimerThread(long delay, Runnable run) {
/* 257 */       this.delay = delay;
/* 258 */       this.run = run;
/*     */     }
/*     */     
/*     */     public void run() {
/*     */       try {
/* 263 */         Thread.sleep(this.delay);
/* 264 */         this.run.run();
/* 265 */       } catch (InterruptedException e) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static TimerThread schedule(long delay, Runnable run) {
/* 281 */     TimerThread t = new TimerThread(delay, run);
/* 282 */     UtilsJavaSE.threadSetDaemon(t);
/* 283 */     t.start();
/* 284 */     return t;
/*     */   }
/*     */   
/*     */   public static void isLegalAPICall(Vector fqcnSet) throws Error {
/* 288 */     UtilsJavaSE.StackTraceLocation ste = UtilsJavaSE.getLocation(fqcnSet);
/* 289 */     if (ste != null) {
/* 290 */       if (ste.className.startsWith("javax.bluetooth.")) {
/*     */         return;
/*     */       }
/* 293 */       if (ste.className.startsWith(blueCoveImplPackage + ".")) {
/*     */         return;
/*     */       }
/* 296 */       throw new Error("Illegal use of the JSR-82 API");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\Utils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */