/*      */ package com.intel.bluetooth;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Vector;
/*      */ import javax.bluetooth.BluetoothStateException;
/*      */ import javax.bluetooth.DataElement;
/*      */ import javax.bluetooth.DeviceClass;
/*      */ import javax.bluetooth.DiscoveryListener;
/*      */ import javax.bluetooth.RemoteDevice;
/*      */ import javax.bluetooth.ServiceRecord;
/*      */ import javax.bluetooth.ServiceRegistrationException;
/*      */ import javax.bluetooth.UUID;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class BluetoothStackWIDCOMM
/*      */   implements BluetoothStack, BluetoothStackExtension
/*      */ {
/*   45 */   private static BluetoothStackWIDCOMM singleInstance = null;
/*      */   
/*      */   private boolean initialized = false;
/*      */   
/*   49 */   private Vector deviceDiscoveryListeners = new Vector();
/*      */   
/*   51 */   private Hashtable deviceDiscoveryListenerFoundDevices = new Hashtable();
/*      */   
/*   53 */   private Hashtable deviceDiscoveryListenerReportedDevices = new Hashtable();
/*      */ 
/*      */   
/*      */   private static final int ATTR_RETRIEVABLE_MAX = 256;
/*      */ 
/*      */   
/*      */   private static final int RECEIVE_MTU_MAX = 1024;
/*      */   
/*      */   static final short NULL_DESC_TYPE = 0;
/*      */   
/*      */   static final short UINT_DESC_TYPE = 1;
/*      */   
/*      */   static final short TWO_COMP_INT_DESC_TYPE = 2;
/*      */   
/*      */   static final short UUID_DESC_TYPE = 3;
/*      */   
/*      */   static final short TEXT_STR_DESC_TYPE = 4;
/*      */   
/*      */   static final short BOOLEAN_DESC_TYPE = 5;
/*      */   
/*      */   static final short DATA_ELE_SEQ_DESC_TYPE = 6;
/*      */   
/*      */   static final short DATA_ELE_ALT_DESC_TYPE = 7;
/*      */   
/*      */   static final short URL_DESC_TYPE = 8;
/*      */   
/*      */   static Class class$com$intel$bluetooth$BluetoothStackWIDCOMM;
/*      */ 
/*      */   
/*      */   public String getStackID() {
/*   83 */     return "widcomm";
/*      */   }
/*      */   
/*      */   public String toString() {
/*   87 */     return getStackID();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFeatureSet() {
/*   98 */     int nativeBuildFeaturs = nativeBuildFeatures();
/*   99 */     return 0x13 | ((nativeBuildFeaturs > 0) ? 8 : 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BluetoothStack.LibraryInformation[] requireNativeLibraries() {
/*  117 */     return BluetoothStack.LibraryInformation.library("bluecove");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void initialize() throws BluetoothStateException {
/*  127 */     if (singleInstance != null) {
/*  128 */       throw new BluetoothStateException("Only one instance of " + getStackID() + " stack supported");
/*      */     }
/*  130 */     if (!initializeImpl()) {
/*  131 */       throw new RuntimeException("WIDCOMM BluetoothStack not found");
/*      */     }
/*  133 */     this.initialized = true;
/*  134 */     singleInstance = this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void destroy() {
/*  142 */     if (singleInstance != this) {
/*  143 */       throw new RuntimeException("Destroy invalid instance");
/*      */     }
/*  145 */     if (this.initialized) {
/*  146 */       uninitialize();
/*  147 */       this.initialized = false;
/*  148 */       DebugLog.debug("WIDCOMM destroyed");
/*      */     } 
/*  150 */     singleInstance = null;
/*      */   }
/*      */   
/*      */   protected void finalize() {
/*  154 */     destroy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeviceClass getLocalDeviceClass() {
/*  167 */     return new DeviceClass(getDeviceClassImpl());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLocalDeviceServiceClasses(int classOfDevice) {
/*  176 */     throw new NotSupportedRuntimeException(getStackID());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean setLocalDeviceDiscoverable(int mode) throws BluetoothStateException {
/*  187 */     int curentMode = getLocalDeviceDiscoverable();
/*  188 */     if (curentMode == mode) {
/*  189 */       return true;
/*      */     }
/*  191 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void verifyDeviceReady() throws BluetoothStateException {
/*  198 */     if (!isLocalDevicePowerOn()) {
/*  199 */       throw new BluetoothStateException("Bluetooth Device is not ready");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLocalDeviceDiscoverable() {
/*  206 */     if (isStackServerUp() && isLocalDeviceDiscoverable()) {
/*  207 */       return 10390323;
/*      */     }
/*  209 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getLocalDeviceProperty(String property) {
/*  222 */     if ("bluetooth.connected.devices.max".equals(property)) {
/*  223 */       return "7";
/*      */     }
/*  225 */     if ("bluetooth.sd.trans.max".equals(property)) {
/*  226 */       return "1";
/*      */     }
/*  228 */     if ("bluetooth.connected.inquiry.scan".equals(property)) {
/*  229 */       return "true";
/*      */     }
/*  231 */     if ("bluetooth.connected.page.scan".equals(property)) {
/*  232 */       return "true";
/*      */     }
/*  234 */     if ("bluetooth.connected.inquiry".equals(property)) {
/*  235 */       return "true";
/*      */     }
/*  237 */     if ("bluetooth.connected.page".equals(property)) {
/*  238 */       return "true";
/*      */     }
/*      */     
/*  241 */     if ("bluetooth.sd.attr.retrievable.max".equals(property)) {
/*  242 */       return String.valueOf(256);
/*      */     }
/*  244 */     if ("bluetooth.master.switch".equals(property)) {
/*  245 */       return "false";
/*      */     }
/*  247 */     if ("bluetooth.l2cap.receiveMTU.max".equals(property)) {
/*  248 */       return String.valueOf(1024);
/*      */     }
/*      */     
/*  251 */     if ("bluecove.radio.version".equals(property)) {
/*  252 */       return String.valueOf(getDeviceVersion());
/*      */     }
/*  254 */     if ("bluecove.radio.manufacturer".equals(property)) {
/*  255 */       return String.valueOf(getDeviceManufacturer());
/*      */     }
/*  257 */     if ("bluecove.stack.version".equals(property)) {
/*  258 */       return getBTWVersionInfo();
/*      */     }
/*      */     
/*  261 */     if (property.startsWith("bluecove.nativeFunction:")) {
/*  262 */       String functionDescr = property.substring(property.indexOf(':') + 1, property.length());
/*  263 */       int paramIdx = functionDescr.indexOf(':');
/*  264 */       if (paramIdx == -1) {
/*  265 */         throw new RuntimeException("Invalid native function " + functionDescr + "; arguments expected");
/*      */       }
/*  267 */       String function = functionDescr.substring(0, paramIdx);
/*  268 */       long address = RemoteDeviceHelper.getAddress(functionDescr.substring(function.length() + 1, functionDescr.length()));
/*      */       
/*  270 */       if ("getRemoteDeviceVersionInfo".equals(function))
/*  271 */         return getRemoteDeviceVersionInfo(address); 
/*  272 */       if ("cancelSniffMode".equals(function))
/*  273 */         return String.valueOf(cancelSniffMode(address)); 
/*  274 */       if ("setSniffMode".equals(function))
/*  275 */         return String.valueOf(setSniffMode(address)); 
/*  276 */       if ("getRemoteDeviceRSSI".equals(function))
/*  277 */         return String.valueOf(getRemoteDeviceRSSI(address)); 
/*  278 */       if ("getRemoteDeviceLinkMode".equals(function)) {
/*  279 */         if (isRemoteDeviceConnected(address)) {
/*  280 */           return getRemoteDeviceLinkMode(address);
/*      */         }
/*  282 */         return "disconnected";
/*      */       } 
/*      */     } 
/*      */     
/*  286 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCurrentThreadInterruptedCallback() {
/*  295 */     return UtilsJavaSE.isCurrentThreadInterrupted();
/*      */   }
/*      */   
/*      */   public RemoteDevice[] retrieveDevices(int option) {
/*  299 */     return null;
/*      */   }
/*      */   
/*      */   public Boolean isRemoteDeviceTrusted(long address) {
/*  303 */     return null;
/*      */   }
/*      */   
/*      */   public Boolean isRemoteDeviceAuthenticated(long address) {
/*  307 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int readRemoteDeviceRSSI(long address) throws IOException {
/*  316 */     return getRemoteDeviceRSSI(address);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean authenticateRemoteDevice(long address) throws IOException {
/*  322 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean authenticateRemoteDevice(long address, String passkey) throws IOException {
/*  333 */     return authenticateRemoteDeviceImpl(address, passkey);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAuthenticationWithRemoteDevice(long address) throws IOException {
/*  344 */     removeAuthenticationWithRemoteDeviceImpl(address);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean startInquiry(int accessCode, DiscoveryListener listener) throws BluetoothStateException {
/*  367 */     this.deviceDiscoveryListeners.addElement(listener);
/*  368 */     if (BlueCoveImpl.getConfigProperty("bluecove.inquiry.report_asap", false)) {
/*  369 */       this.deviceDiscoveryListenerFoundDevices.put(listener, new Hashtable());
/*      */     }
/*  371 */     this.deviceDiscoveryListenerReportedDevices.put(listener, new Vector());
/*  372 */     DeviceInquiryRunnable inquiryRunnable = new DeviceInquiryRunnable(this) { private final BluetoothStackWIDCOMM this$0;
/*      */         
/*      */         public int runDeviceInquiry(DeviceInquiryThread startedNotify, int accessCode, DiscoveryListener listener) throws BluetoothStateException {
/*      */           try {
/*  376 */             int discType = this.this$0.runDeviceInquiryImpl(this, startedNotify, accessCode, listener);
/*  377 */             if (discType == 0) {
/*      */               
/*  379 */               Hashtable previouslyFound = (Hashtable)this.this$0.deviceDiscoveryListenerFoundDevices.get(listener);
/*  380 */               if (previouslyFound != null) {
/*  381 */                 Vector reported = (Vector)this.this$0.deviceDiscoveryListenerReportedDevices.get(listener);
/*  382 */                 for (Enumeration en = previouslyFound.keys(); en.hasMoreElements(); ) {
/*  383 */                   RemoteDevice remoteDevice = en.nextElement();
/*  384 */                   if (reported.contains(remoteDevice)) {
/*      */                     continue;
/*      */                   }
/*  387 */                   reported.addElement(remoteDevice);
/*  388 */                   Integer deviceClassInt = (Integer)previouslyFound.get(remoteDevice);
/*  389 */                   DeviceClass deviceClass = new DeviceClass(deviceClassInt.intValue());
/*  390 */                   listener.deviceDiscovered(remoteDevice, deviceClass);
/*      */                   
/*  392 */                   if (!this.this$0.deviceDiscoveryListeners.contains(listener)) {
/*  393 */                     return 5;
/*      */                   }
/*      */                 } 
/*      */               } 
/*      */             } 
/*  398 */             return discType;
/*      */           } finally {
/*  400 */             this.this$0.deviceDiscoveryListeners.removeElement(listener);
/*  401 */             this.this$0.deviceDiscoveryListenerFoundDevices.remove(listener);
/*  402 */             this.this$0.deviceDiscoveryListenerReportedDevices.remove(listener);
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void deviceDiscoveredCallback(DiscoveryListener listener, long deviceAddr, int deviceClass, String deviceName, boolean paired) {
/*  412 */           DebugLog.debug("deviceDiscoveredCallback deviceName", deviceName);
/*  413 */           if (!this.this$0.deviceDiscoveryListeners.contains(listener)) {
/*      */             return;
/*      */           }
/*      */           
/*  417 */           RemoteDevice remoteDevice = RemoteDeviceHelper.createRemoteDevice(this.this$0, deviceAddr, deviceName, paired);
/*      */           
/*  419 */           Vector reported = (Vector)this.this$0.deviceDiscoveryListenerReportedDevices.get(listener);
/*  420 */           if (reported == null || reported.contains(remoteDevice)) {
/*      */             return;
/*      */           }
/*      */           
/*  424 */           Hashtable previouslyFound = (Hashtable)this.this$0.deviceDiscoveryListenerFoundDevices.get(listener);
/*  425 */           if (previouslyFound != null) {
/*  426 */             Integer deviceClassInt = (Integer)previouslyFound.get(remoteDevice);
/*  427 */             if (deviceClassInt == null) {
/*  428 */               previouslyFound.put(remoteDevice, new Integer(deviceClass));
/*  429 */             } else if (deviceClass != 0) {
/*  430 */               previouslyFound.put(remoteDevice, new Integer(deviceClass));
/*      */             } 
/*      */           } else {
/*  433 */             DeviceClass cod = new DeviceClass(deviceClass);
/*  434 */             reported.addElement(remoteDevice);
/*  435 */             DebugLog.debug("deviceDiscoveredCallback address", remoteDevice.getBluetoothAddress());
/*  436 */             DebugLog.debug("deviceDiscoveredCallback deviceClass", cod);
/*  437 */             listener.deviceDiscovered(remoteDevice, cod);
/*      */           } 
/*      */         } }
/*      */       ;
/*  441 */     return DeviceInquiryThread.startInquiry(this, inquiryRunnable, accessCode, listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean cancelInquiry(DiscoveryListener listener) {
/*  448 */     if (!this.deviceDiscoveryListeners.removeElement(listener)) {
/*  449 */       return false;
/*      */     }
/*  451 */     return deviceInquiryCancelImpl();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRemoteDeviceFriendlyName(long address) throws IOException {
/*  466 */     if (this.deviceDiscoveryListeners.size() != 0)
/*      */     {
/*  468 */       return peekRemoteDeviceFriendlyName(address);
/*      */     }
/*      */     
/*  471 */     DiscoveryListener listener = new DiscoveryListenerAdapter();
/*  472 */     if (startInquiry(10390323, listener)) {
/*  473 */       String name = peekRemoteDeviceFriendlyName(address);
/*  474 */       cancelInquiry(listener);
/*  475 */       return name;
/*      */     } 
/*      */     
/*  478 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int searchServices(int[] attrSet, UUID[] uuidSet, RemoteDevice device, DiscoveryListener listener) throws BluetoothStateException {
/*  489 */     SearchServicesRunnable searchRunnable = new SearchServicesRunnable(this)
/*      */       {
/*      */         private final BluetoothStackWIDCOMM this$0;
/*      */         
/*      */         public int runSearchServices(SearchServicesThread sst, int[] attrSet, UUID[] uuidSet, RemoteDevice device, DiscoveryListener listener) throws BluetoothStateException {
/*  494 */           synchronized ((BluetoothStackWIDCOMM.class$com$intel$bluetooth$BluetoothStackWIDCOMM == null) ? (BluetoothStackWIDCOMM.class$com$intel$bluetooth$BluetoothStackWIDCOMM = BluetoothStackWIDCOMM.class$("com.intel.bluetooth.BluetoothStackWIDCOMM")) : BluetoothStackWIDCOMM.class$com$intel$bluetooth$BluetoothStackWIDCOMM) {
/*  495 */             long[] handles; byte[] uuidValue = Utils.UUIDToByteArray(BluetoothConsts.L2CAP_PROTOCOL_UUID);
/*  496 */             for (int u = 0; u < uuidSet.length; u++) {
/*  497 */               if (!uuidSet[u].equals(BluetoothConsts.L2CAP_PROTOCOL_UUID))
/*      */               {
/*  499 */                 if (uuidSet[u].equals(BluetoothConsts.RFCOMM_PROTOCOL_UUID)) {
/*  500 */                   uuidValue = Utils.UUIDToByteArray(uuidSet[u]);
/*      */                 }
/*      */                 else {
/*      */                   
/*  504 */                   uuidValue = Utils.UUIDToByteArray(uuidSet[u]);
/*      */                   break;
/*      */                 } 
/*      */               }
/*      */             } 
/*      */             try {
/*  510 */               handles = this.this$0.runSearchServicesImpl(sst, uuidValue, RemoteDeviceHelper.getAddress(device));
/*  511 */             } catch (SearchServicesTerminatedException e) {
/*  512 */               DebugLog.debug("SERVICE_SEARCH_TERMINATED");
/*  513 */               return 2;
/*      */             } 
/*  515 */             if (handles == null) {
/*  516 */               DebugLog.debug("SERVICE_SEARCH_ERROR");
/*  517 */               return 3;
/*  518 */             }  if (handles.length > 0) {
/*  519 */               Vector records = new Vector();
/*  520 */               int[] uuidFilerAttrIDs = { 1, 4 };
/*      */               
/*  522 */               int[] requiredAttrIDs = { 0, 2, 3 };
/*      */               int i;
/*  524 */               label55: for (i = 0; i < handles.length; i++) {
/*  525 */                 ServiceRecordImpl sr = new ServiceRecordImpl(this.this$0, device, handles[i]);
/*      */                 try {
/*  527 */                   sr.populateRecord(uuidFilerAttrIDs);
/*      */                   
/*  529 */                   for (int j = 0; j < uuidSet.length; j++) {
/*  530 */                     if (!sr.hasServiceClassUUID(uuidSet[j]) && !sr.hasProtocolClassUUID(uuidSet[j])) {
/*      */                       continue label55;
/*      */                     }
/*      */                   } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/*  540 */                   if (!this.this$0.isServiceRecordDiscoverable(RemoteDeviceHelper.getAddress(device), sr.getHandle())) {
/*      */                     continue;
/*      */                   }
/*      */                   
/*  544 */                   records.addElement(sr);
/*  545 */                   sr.populateRecord(requiredAttrIDs);
/*  546 */                   if (attrSet != null) {
/*  547 */                     sr.populateRecord(attrSet);
/*      */                   }
/*  549 */                   DebugLog.debug("ServiceRecord (" + i + ") sr.handle", handles[i]);
/*  550 */                   DebugLog.debug("ServiceRecord (" + i + ")", sr);
/*  551 */                 } catch (Exception e) {
/*  552 */                   DebugLog.debug("populateRecord error", e);
/*      */                 } 
/*  554 */                 if (sst.isTerminated()) {
/*  555 */                   DebugLog.debug("SERVICE_SEARCH_TERMINATED");
/*  556 */                   return 2;
/*      */                 }  continue;
/*      */               } 
/*  559 */               if (records.size() != 0) {
/*  560 */                 DebugLog.debug("SERVICE_SEARCH_COMPLETED");
/*  561 */                 ServiceRecord[] fileteredRecords = (ServiceRecord[])Utils.vector2toArray(records, (Object[])new ServiceRecord[records.size()]);
/*      */                 
/*  563 */                 listener.servicesDiscovered(sst.getTransID(), fileteredRecords);
/*  564 */                 return 1;
/*      */               } 
/*      */             } 
/*  567 */             DebugLog.debug("SERVICE_SEARCH_NO_RECORDS");
/*  568 */             return 4;
/*      */           } 
/*      */         }
/*      */       };
/*  572 */     return SearchServicesThread.startSearchServices(this, searchRunnable, attrSet, uuidSet, device, listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean cancelServiceSearch(int transID) {
/*  581 */     SearchServicesThread sst = SearchServicesThread.getServiceSearchThread(transID);
/*  582 */     if (sst != null) {
/*  583 */       synchronized (this) {
/*  584 */         if (!sst.isTerminated()) {
/*  585 */           sst.setTerminated();
/*  586 */           cancelServiceSearchImpl();
/*  587 */           return true;
/*      */         } 
/*      */       } 
/*      */     }
/*  591 */     return false;
/*      */   } static Class class$(String x0) {
/*      */     try {
/*      */       return Class.forName(x0);
/*      */     } catch (ClassNotFoundException x1) {
/*      */       throw new NoClassDefFoundError(x1.getMessage());
/*      */     } 
/*      */   }
/*      */   public boolean populateServicesRecordAttributeValues(ServiceRecordImpl serviceRecord, int[] attrIDs) throws IOException {
/*  600 */     if (attrIDs.length > 256) {
/*  601 */       throw new IllegalArgumentException();
/*      */     }
/*  603 */     boolean anyRetrived = false;
/*  604 */     for (int i = 0; i < attrIDs.length; i++) {
/*  605 */       int id = attrIDs[i];
/*      */       try {
/*  607 */         byte[] sdpStruct = getServiceAttribute(id, serviceRecord.getHandle());
/*  608 */         if (sdpStruct != null)
/*      */         {
/*      */ 
/*      */           
/*  612 */           DataElement element = (new BluetoothStackWIDCOMMSDPInputStream(new ByteArrayInputStream(sdpStruct))).readElement();
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  617 */           if (id == 4) {
/*  618 */             Enumeration protocolsSeqEnum = (Enumeration)element.getValue();
/*  619 */             if (protocolsSeqEnum.hasMoreElements()) {
/*  620 */               DataElement protocolElement = protocolsSeqEnum.nextElement();
/*  621 */               if (protocolElement.getDataType() != 48) {
/*  622 */                 DataElement newMainSeq = new DataElement(48);
/*  623 */                 newMainSeq.addElement(element);
/*  624 */                 element = newMainSeq;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */           
/*  629 */           serviceRecord.populateAttributeValue(id, element);
/*  630 */           anyRetrived = true;
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*  636 */       catch (Throwable e) {}
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  642 */     return anyRetrived;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long connectionRfOpenClientConnection(BluetoothConnectionParams params) throws IOException {
/*  651 */     verifyDeviceReady();
/*  652 */     return connectionRfOpenClientConnectionImpl(params.address, params.channel, params.authenticate, params.encrypt, params.timeout);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void connectionRfCloseClientConnection(long handle) throws IOException {
/*  659 */     closeRfCommPortImpl(handle);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void connectionRfWrite(long handle, int b) throws IOException {
/*  673 */     byte[] buf = new byte[1];
/*  674 */     buf[0] = (byte)(b & 0xFF);
/*  675 */     connectionRfWriteImpl(handle, buf, 0, 1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void connectionRfWrite(long handle, byte[] b, int off, int len) throws IOException {
/*  680 */     int maxNativeBuffer = 65535;
/*  681 */     if (len < 65535) {
/*  682 */       connectionRfWriteImpl(handle, b, off, len);
/*      */     } else {
/*  684 */       int done = 0;
/*  685 */       while (done < len) {
/*  686 */         int l = len - done;
/*  687 */         if (l > 65535) {
/*  688 */           l = 65535;
/*      */         }
/*  690 */         connectionRfWriteImpl(handle, b, off + done, l);
/*  691 */         done += 65535;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void connectionRfFlush(long handle) throws IOException {}
/*      */ 
/*      */   
/*      */   public int rfGetSecurityOpt(long handle, int expected) throws IOException {
/*  701 */     return expected;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rfEncrypt(long address, long handle, boolean on) throws IOException {
/*  710 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long rfServerOpen(BluetoothConnectionNotifierParams params, ServiceRecordImpl serviceRecord) throws IOException {
/*  720 */     verifyDeviceReady();
/*  721 */     byte[] uuidValue = Utils.UUIDToByteArray(params.uuid);
/*  722 */     byte[] uuidValue2 = params.obex ? null : Utils.UUIDToByteArray(BluetoothConsts.SERIAL_PORT_UUID);
/*  723 */     long handle = rfServerOpenImpl(uuidValue, uuidValue2, params.obex, params.name, params.authenticate, params.encrypt);
/*      */     
/*  725 */     int channel = rfServerSCN(handle);
/*  726 */     DebugLog.debug("serverSCN", channel);
/*  727 */     long serviceRecordHandle = handle;
/*      */     
/*  729 */     serviceRecord.populateRFCOMMAttributes(serviceRecordHandle, channel, params.uuid, params.name, params.obex);
/*      */     
/*  731 */     return handle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private byte[] long2byte(long value, int len) {
/*  738 */     byte[] cvalue = new byte[len];
/*  739 */     long l = value;
/*  740 */     for (int i = len - 1; i >= 0; i--) {
/*  741 */       cvalue[i] = (byte)(int)(l & 0xFFL);
/*  742 */       l >>= 8L;
/*      */     } 
/*  744 */     return cvalue;
/*      */   }
/*      */ 
/*      */   
/*      */   public void rfServerUpdateServiceRecord(long handle, ServiceRecordImpl serviceRecord, boolean acceptAndOpen) throws ServiceRegistrationException {
/*  749 */     sdpServiceUpdateServiceRecord(handle, 'r', serviceRecord);
/*      */   }
/*      */   
/*      */   private byte[] sdpServiceSequenceAttribute(Enumeration en) throws ServiceRegistrationException {
/*  753 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/*  754 */     SDPOutputStream sdpOut = new SDPOutputStream(out);
/*      */     try {
/*  756 */       while (en.hasMoreElements()) {
/*  757 */         sdpOut.writeElement(en.nextElement());
/*      */       }
/*  759 */     } catch (IOException e) {
/*  760 */       throw new ServiceRegistrationException(e.getMessage());
/*      */     } 
/*  762 */     return out.toByteArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void sdpServiceUpdateServiceRecord(long handle, char handleType, ServiceRecordImpl serviceRecord) throws ServiceRegistrationException {
/*  770 */     int[] ids = serviceRecord.getAttributeIDs();
/*  771 */     if (ids == null || ids.length == 0) {
/*      */       return;
/*      */     }
/*      */     
/*  775 */     DataElement serviceClassIDList = serviceRecord.getAttributeValue(1);
/*  776 */     if (serviceClassIDList.getDataType() != 48) {
/*  777 */       throw new ServiceRegistrationException("Invalid serviceClassIDList");
/*      */     }
/*  779 */     Enumeration en = (Enumeration)serviceClassIDList.getValue();
/*  780 */     Vector uuids = new Vector();
/*  781 */     while (en.hasMoreElements()) {
/*  782 */       DataElement u = en.nextElement();
/*  783 */       if (u.getDataType() != 24) {
/*  784 */         throw new ServiceRegistrationException("Invalid serviceClassIDList element " + u);
/*      */       }
/*  786 */       uuids.add(u.getValue());
/*      */     } 
/*  788 */     if (uuids.size() > 0) {
/*  789 */       byte[][] uuidValues = new byte[uuids.size()][];
/*  790 */       for (int u = 0; u < uuidValues.length; u++) {
/*  791 */         uuidValues[u] = Utils.UUIDToByteArray((UUID)uuids.elementAt(u));
/*      */       }
/*  793 */       sdpServiceAddServiceClassIdList(handle, handleType, uuidValues);
/*      */     } 
/*      */ 
/*      */     
/*  797 */     for (int i = 0; i < ids.length; i++) {
/*  798 */       DataElement d; int id = ids[i];
/*  799 */       switch (id) {
/*      */         case 0:
/*      */         case 1:
/*      */         case 4:
/*      */         case 256:
/*      */           break;
/*      */         
/*      */         default:
/*  807 */           d = serviceRecord.getAttributeValue(id);
/*  808 */           switch (d.getDataType()) {
/*      */             case 8:
/*  810 */               sdpServiceAddAttribute(handle, handleType, id, (short)1, long2byte(d.getLong(), 1));
/*      */               break;
/*      */             case 9:
/*  813 */               sdpServiceAddAttribute(handle, handleType, id, (short)1, long2byte(d.getLong(), 2));
/*      */               break;
/*      */             case 10:
/*  816 */               sdpServiceAddAttribute(handle, handleType, id, (short)1, long2byte(d.getLong(), 4));
/*      */               break;
/*      */             case 11:
/*      */             case 12:
/*  820 */               sdpServiceAddAttribute(handle, handleType, id, (short)1, (byte[])d.getValue());
/*      */               break;
/*      */             case 16:
/*  823 */               sdpServiceAddAttribute(handle, handleType, id, (short)2, long2byte(d.getLong(), 1));
/*      */               break;
/*      */             case 17:
/*  826 */               sdpServiceAddAttribute(handle, handleType, id, (short)2, long2byte(d.getLong(), 2));
/*      */               break;
/*      */             case 18:
/*  829 */               sdpServiceAddAttribute(handle, handleType, id, (short)2, long2byte(d.getLong(), 4));
/*      */               break;
/*      */             case 19:
/*  832 */               sdpServiceAddAttribute(handle, handleType, id, (short)2, long2byte(d.getLong(), 8));
/*      */               break;
/*      */             case 20:
/*  835 */               sdpServiceAddAttribute(handle, handleType, id, (short)2, (byte[])d.getValue());
/*      */               break;
/*      */             case 64:
/*  838 */               sdpServiceAddAttribute(handle, handleType, id, (short)8, Utils.getASCIIBytes(d.getValue().toString()));
/*      */               break;
/*      */             
/*      */             case 32:
/*  842 */               sdpServiceAddAttribute(handle, handleType, id, (short)4, Utils.getUTF8Bytes(d.getValue().toString()));
/*      */               break;
/*      */             
/*      */             case 0:
/*  846 */               sdpServiceAddAttribute(handle, handleType, id, (short)0, null);
/*      */               break;
/*      */             case 40:
/*  849 */               sdpServiceAddAttribute(handle, handleType, id, (short)5, new byte[] { (byte)(d.getBoolean() ? 1 : 0) });
/*      */               break;
/*      */             
/*      */             case 24:
/*  853 */               sdpServiceAddAttribute(handle, handleType, id, (short)3, BluetoothStackWIDCOMMSDPInputStream.getUUIDHexBytes((UUID)d.getValue()));
/*      */               break;
/*      */             
/*      */             case 48:
/*  857 */               sdpServiceAddAttribute(handle, handleType, id, (short)6, sdpServiceSequenceAttribute((Enumeration)d.getValue()));
/*      */               break;
/*      */             
/*      */             case 56:
/*  861 */               sdpServiceAddAttribute(handle, handleType, id, (short)7, sdpServiceSequenceAttribute((Enumeration)d.getValue()));
/*      */               break;
/*      */           } 
/*      */           
/*  865 */           throw new ServiceRegistrationException("Invalid " + d.getDataType());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rfServerClose(long handle, ServiceRecordImpl serviceRecord) throws IOException {
/*  877 */     rfServerCloseImpl(handle);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void validateMTU(int receiveMTU, int transmitMTU) {
/*  883 */     if (receiveMTU > 1024) {
/*  884 */       throw new IllegalArgumentException("invalid ReceiveMTU value " + receiveMTU);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long l2OpenClientConnection(BluetoothConnectionParams params, int receiveMTU, int transmitMTU) throws IOException {
/*  913 */     verifyDeviceReady();
/*  914 */     validateMTU(receiveMTU, transmitMTU);
/*  915 */     return l2OpenClientConnectionImpl(params.address, params.channel, params.authenticate, params.encrypt, receiveMTU, transmitMTU, params.timeout);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long l2ServerOpen(BluetoothConnectionNotifierParams params, int receiveMTU, int transmitMTU, ServiceRecordImpl serviceRecord) throws IOException {
/*  939 */     verifyDeviceReady();
/*  940 */     validateMTU(receiveMTU, transmitMTU);
/*  941 */     byte[] uuidValue = Utils.UUIDToByteArray(params.uuid);
/*  942 */     long handle = l2ServerOpenImpl(uuidValue, params.authenticate, params.encrypt, params.name, receiveMTU, transmitMTU, params.bluecove_ext_psm);
/*      */ 
/*      */     
/*  945 */     int channel = l2ServerPSM(handle);
/*      */     
/*  947 */     int serviceRecordHandle = (int)handle;
/*      */     
/*  949 */     serviceRecord.populateL2CAPAttributes(serviceRecordHandle, channel, params.uuid, params.name);
/*      */     
/*  951 */     return handle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void l2ServerUpdateServiceRecord(long handle, ServiceRecordImpl serviceRecord, boolean acceptAndOpen) throws ServiceRegistrationException {
/*  962 */     sdpServiceUpdateServiceRecord(handle, 'l', serviceRecord);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void l2ServerClose(long handle, ServiceRecordImpl serviceRecord) throws IOException {
/*  987 */     l2ServerCloseImpl(handle);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int l2GetSecurityOpt(long handle, int expected) throws IOException {
/*  996 */     return expected;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean l2Encrypt(long address, long handle, boolean on) throws IOException {
/* 1047 */     return false;
/*      */   }
/*      */   
/*      */   private native int nativeBuildFeatures();
/*      */   
/*      */   public native boolean isNativeCodeLoaded();
/*      */   
/*      */   public native int getLibraryVersion();
/*      */   
/*      */   public native int detectBluetoothStack();
/*      */   
/*      */   public native void enableNativeDebug(Class paramClass, boolean paramBoolean);
/*      */   
/*      */   public native boolean initializeImpl();
/*      */   
/*      */   private native void uninitialize();
/*      */   
/*      */   public native String getLocalDeviceBluetoothAddress() throws BluetoothStateException;
/*      */   
/*      */   public native String getLocalDeviceName();
/*      */   
/*      */   private native int getDeviceClassImpl();
/*      */   
/*      */   private native boolean isStackServerUp();
/*      */   
/*      */   public native boolean isLocalDeviceDiscoverable();
/*      */   
/*      */   public native boolean isLocalDevicePowerOn();
/*      */   
/*      */   private native String getBTWVersionInfo();
/*      */   
/*      */   private native int getDeviceVersion();
/*      */   
/*      */   private native int getDeviceManufacturer();
/*      */   
/*      */   private native boolean authenticateRemoteDeviceImpl(long paramLong, String paramString) throws IOException;
/*      */   
/*      */   private native void removeAuthenticationWithRemoteDeviceImpl(long paramLong) throws IOException;
/*      */   
/*      */   private native boolean isRemoteDeviceConnected(long paramLong);
/*      */   
/*      */   private native String getRemoteDeviceLinkMode(long paramLong);
/*      */   
/*      */   private native String getRemoteDeviceVersionInfo(long paramLong);
/*      */   
/*      */   private native boolean setSniffMode(long paramLong);
/*      */   
/*      */   private native boolean cancelSniffMode(long paramLong);
/*      */   
/*      */   private native int getRemoteDeviceRSSI(long paramLong);
/*      */   
/*      */   private native int runDeviceInquiryImpl(DeviceInquiryRunnable paramDeviceInquiryRunnable, DeviceInquiryThread paramDeviceInquiryThread, int paramInt, DiscoveryListener paramDiscoveryListener) throws BluetoothStateException;
/*      */   
/*      */   private native boolean deviceInquiryCancelImpl();
/*      */   
/*      */   native String getRemoteDeviceFriendlyName(long paramLong, int paramInt1, int paramInt2) throws IOException;
/*      */   
/*      */   native String peekRemoteDeviceFriendlyName(long paramLong);
/*      */   
/*      */   private native long[] runSearchServicesImpl(SearchServicesThread paramSearchServicesThread, byte[] paramArrayOfbyte, long paramLong) throws BluetoothStateException, SearchServicesTerminatedException;
/*      */   
/*      */   private native void cancelServiceSearchImpl();
/*      */   
/*      */   private native byte[] getServiceAttribute(int paramInt, long paramLong) throws IOException;
/*      */   
/*      */   private native boolean isServiceRecordDiscoverable(long paramLong1, long paramLong2) throws IOException;
/*      */   
/*      */   private native long connectionRfOpenClientConnectionImpl(long paramLong, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2) throws IOException;
/*      */   
/*      */   private native void closeRfCommPortImpl(long paramLong) throws IOException;
/*      */   
/*      */   public native long getConnectionRfRemoteAddress(long paramLong) throws IOException;
/*      */   
/*      */   public native int connectionRfRead(long paramLong) throws IOException;
/*      */   
/*      */   public native int connectionRfRead(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
/*      */   
/*      */   public native int connectionRfReadAvailable(long paramLong) throws IOException;
/*      */   
/*      */   private native void connectionRfWriteImpl(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
/*      */   
/*      */   private synchronized native long rfServerOpenImpl(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, boolean paramBoolean1, String paramString, boolean paramBoolean2, boolean paramBoolean3) throws IOException;
/*      */   
/*      */   private native int rfServerSCN(long paramLong) throws IOException;
/*      */   
/*      */   private native void sdpServiceAddAttribute(long paramLong, char paramChar, int paramInt, short paramShort, byte[] paramArrayOfbyte) throws ServiceRegistrationException;
/*      */   
/*      */   private native void sdpServiceAddServiceClassIdList(long paramLong, char paramChar, byte[][] paramArrayOfbyte) throws ServiceRegistrationException;
/*      */   
/*      */   public native long rfServerAcceptAndOpenRfServerConnection(long paramLong) throws IOException;
/*      */   
/*      */   public native void connectionRfCloseServerConnection(long paramLong) throws IOException;
/*      */   
/*      */   private native void rfServerCloseImpl(long paramLong) throws IOException;
/*      */   
/*      */   private native long l2OpenClientConnectionImpl(long paramLong, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3, int paramInt4) throws IOException;
/*      */   
/*      */   public native void l2CloseClientConnection(long paramLong) throws IOException;
/*      */   
/*      */   private synchronized native long l2ServerOpenImpl(byte[] paramArrayOfbyte, boolean paramBoolean1, boolean paramBoolean2, String paramString, int paramInt1, int paramInt2, int paramInt3) throws IOException;
/*      */   
/*      */   public native int l2ServerPSM(long paramLong) throws IOException;
/*      */   
/*      */   public native long l2ServerAcceptAndOpenServerConnection(long paramLong) throws IOException;
/*      */   
/*      */   public native void l2CloseServerConnection(long paramLong) throws IOException;
/*      */   
/*      */   private native void l2ServerCloseImpl(long paramLong) throws IOException;
/*      */   
/*      */   public native int l2GetReceiveMTU(long paramLong) throws IOException;
/*      */   
/*      */   public native int l2GetTransmitMTU(long paramLong) throws IOException;
/*      */   
/*      */   public native boolean l2Ready(long paramLong) throws IOException;
/*      */   
/*      */   public native int l2Receive(long paramLong, byte[] paramArrayOfbyte) throws IOException;
/*      */   
/*      */   public native void l2Send(long paramLong, byte[] paramArrayOfbyte, int paramInt) throws IOException;
/*      */   
/*      */   public native long l2RemoteAddress(long paramLong) throws IOException;
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothStackWIDCOMM.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */