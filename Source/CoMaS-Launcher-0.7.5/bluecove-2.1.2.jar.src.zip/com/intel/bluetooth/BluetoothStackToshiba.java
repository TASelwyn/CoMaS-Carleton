/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.bluetooth.BluetoothStateException;
/*     */ import javax.bluetooth.DataElement;
/*     */ import javax.bluetooth.DeviceClass;
/*     */ import javax.bluetooth.DiscoveryListener;
/*     */ import javax.bluetooth.RemoteDevice;
/*     */ import javax.bluetooth.ServiceRecord;
/*     */ import javax.bluetooth.ServiceRegistrationException;
/*     */ import javax.bluetooth.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BluetoothStackToshiba
/*     */   implements BluetoothStack, DeviceInquiryRunnable, SearchServicesRunnable
/*     */ {
/*     */   private boolean initialized = false;
/*  47 */   private Vector deviceDiscoveryListeners = new Vector();
/*     */   
/*  49 */   private Hashtable deviceDiscoveryListenerFoundDevices = new Hashtable();
/*     */   
/*  51 */   private Hashtable deviceDiscoveryListenerReportedDevices = new Hashtable();
/*     */ 
/*     */   
/*     */   private static final int ATTR_RETRIEVABLE_MAX = 65535;
/*     */   
/*     */   private static final int RECEIVE_MTU_MAX = 1024;
/*     */ 
/*     */   
/*     */   private String getBTWVersionInfo() {
/*  60 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int getDeviceVersion() {
/*  66 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int getDeviceManufacturer() {
/*  72 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStackID() {
/*  82 */     return "toshiba";
/*     */   }
/*     */   
/*     */   public String toString() {
/*  86 */     return getStackID();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFeatureSet() {
/*  95 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native boolean isNativeCodeLoaded();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BluetoothStack.LibraryInformation[] requireNativeLibraries() {
/* 111 */     return BluetoothStack.LibraryInformation.library("bluecove");
/*     */   }
/*     */   
/*     */   public native int getLibraryVersion();
/*     */   
/*     */   public native int detectBluetoothStack();
/*     */   
/*     */   public native void enableNativeDebug(Class paramClass, boolean paramBoolean);
/*     */   
/*     */   private native boolean initializeImpl() throws BluetoothStateException;
/*     */   
/*     */   private native void destroyImpl();
/*     */   
/*     */   public void initialize() throws BluetoothStateException {
/* 125 */     if (!initializeImpl()) {
/* 126 */       throw new BluetoothStateException("TOSHIBA BluetoothStack not found");
/*     */     }
/* 128 */     this.initialized = true;
/*     */   }
/*     */   
/*     */   public void destroy() {
/* 132 */     if (this.initialized) {
/* 133 */       destroyImpl();
/* 134 */       this.initialized = false;
/* 135 */       DebugLog.debug("TOSHIBA destroyed");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCurrentThreadInterruptedCallback() {
/* 145 */     return UtilsJavaSE.isCurrentThreadInterrupted();
/*     */   }
/*     */   
/*     */   public RemoteDevice[] retrieveDevices(int option) {
/* 149 */     return null;
/*     */   }
/*     */   
/*     */   public Boolean isRemoteDeviceTrusted(long address) {
/* 153 */     return null;
/*     */   }
/*     */   
/*     */   public Boolean isRemoteDeviceAuthenticated(long address) {
/* 157 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAuthenticationWithRemoteDevice(long address) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public native String getLocalDeviceBluetoothAddress() throws BluetoothStateException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeviceClass getLocalDeviceClass() {
/* 174 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocalDeviceServiceClasses(int classOfDevice) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocalDeviceName() {
/* 188 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLocalDevicePowerOn() {
/* 193 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLocalDeviceProperty(String property) {
/* 198 */     if ("bluetooth.connected.devices.max".equals(property)) {
/* 199 */       return "7";
/*     */     }
/* 201 */     if ("bluetooth.sd.trans.max".equals(property)) {
/* 202 */       return "1";
/*     */     }
/* 204 */     if ("bluetooth.connected.inquiry.scan".equals(property)) {
/* 205 */       return "true";
/*     */     }
/* 207 */     if ("bluetooth.connected.page.scan".equals(property)) {
/* 208 */       return "true";
/*     */     }
/* 210 */     if ("bluetooth.connected.inquiry".equals(property)) {
/* 211 */       return "true";
/*     */     }
/* 213 */     if ("bluetooth.connected.page".equals(property)) {
/* 214 */       return "true";
/*     */     }
/*     */     
/* 217 */     if ("bluetooth.sd.attr.retrievable.max".equals(property)) {
/* 218 */       return String.valueOf(65535);
/*     */     }
/* 220 */     if ("bluetooth.master.switch".equals(property)) {
/* 221 */       return "false";
/*     */     }
/* 223 */     if ("bluetooth.l2cap.receiveMTU.max".equals(property)) {
/* 224 */       return String.valueOf(1024);
/*     */     }
/*     */     
/* 227 */     if ("bluecove.radio.version".equals(property)) {
/* 228 */       return String.valueOf(getDeviceVersion());
/*     */     }
/* 230 */     if ("bluecove.radio.manufacturer".equals(property)) {
/* 231 */       return String.valueOf(getDeviceManufacturer());
/*     */     }
/* 233 */     if ("bluecove.stack.version".equals(property)) {
/* 234 */       return getBTWVersionInfo();
/*     */     }
/*     */     
/* 237 */     if (property.startsWith("bluecove.nativeFunction:")) {
/* 238 */       String functionDescr = property.substring(property.indexOf(':') + 1, property.length());
/* 239 */       int paramIdx = functionDescr.indexOf(':');
/* 240 */       if (paramIdx == -1) {
/* 241 */         throw new RuntimeException("Invalid native function " + functionDescr + "; arguments expected");
/*     */       }
/* 243 */       String function = functionDescr.substring(0, paramIdx);
/* 244 */       long address = RemoteDeviceHelper.getAddress(functionDescr.substring(function.length() + 1, functionDescr.length()));
/*     */       
/* 246 */       if ("getRemoteDeviceVersionInfo".equals(function))
/* 247 */         return getRemoteDeviceVersionInfo(address); 
/* 248 */       if ("cancelSniffMode".equals(function))
/* 249 */         return String.valueOf(cancelSniffMode(address)); 
/* 250 */       if ("setSniffMode".equals(function))
/* 251 */         return String.valueOf(setSniffMode(address)); 
/* 252 */       if ("getRemoteDeviceRSSI".equals(function))
/* 253 */         return String.valueOf(getRemoteDeviceRSSI(address)); 
/* 254 */       if ("getRemoteDeviceLinkMode".equals(function)) {
/* 255 */         if (isRemoteDeviceConnected(address)) {
/* 256 */           return getRemoteDeviceLinkMode(address);
/*     */         }
/* 258 */         return "disconnected";
/*     */       } 
/*     */     } 
/*     */     
/* 262 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLocalDeviceDiscoverable() {
/* 267 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setLocalDeviceDiscoverable(int mode) throws BluetoothStateException {
/* 272 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean authenticateRemoteDevice(long address) throws IOException {
/* 278 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean authenticateRemoteDevice(long address, String passkey) throws IOException {
/* 288 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRemoteDeviceConnected(long address) {
/* 297 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getRemoteDeviceLinkMode(long address) {
/* 302 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getRemoteDeviceVersionInfo(long address) {
/* 307 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setSniffMode(long address) {
/* 312 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean cancelSniffMode(long address) {
/* 317 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRemoteDeviceRSSI(long address) {
/* 322 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private native int runDeviceInquiryImpl(DeviceInquiryThread paramDeviceInquiryThread, int paramInt, DiscoveryListener paramDiscoveryListener) throws BluetoothStateException;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean startInquiry(int accessCode, DiscoveryListener listener) throws BluetoothStateException {
/* 332 */     this.deviceDiscoveryListeners.addElement(listener);
/* 333 */     if (BlueCoveImpl.getConfigProperty("bluecove.inquiry.report_asap", false)) {
/* 334 */       this.deviceDiscoveryListenerFoundDevices.put(listener, new Hashtable());
/*     */     }
/* 336 */     this.deviceDiscoveryListenerReportedDevices.put(listener, new Vector());
/* 337 */     return DeviceInquiryThread.startInquiry(this, this, accessCode, listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public int runDeviceInquiry(DeviceInquiryThread startedNotify, int accessCode, DiscoveryListener listener) throws BluetoothStateException {
/*     */     try {
/* 343 */       int discType = runDeviceInquiryImpl(startedNotify, accessCode, listener);
/* 344 */       if (discType == 0) {
/*     */         
/* 346 */         Hashtable previouslyFound = (Hashtable)this.deviceDiscoveryListenerFoundDevices.get(listener);
/* 347 */         if (previouslyFound != null) {
/* 348 */           Vector reported = (Vector)this.deviceDiscoveryListenerReportedDevices.get(listener);
/* 349 */           for (Enumeration en = previouslyFound.keys(); en.hasMoreElements(); ) {
/* 350 */             RemoteDevice remoteDevice = en.nextElement();
/* 351 */             if (reported.contains(remoteDevice)) {
/*     */               continue;
/*     */             }
/* 354 */             reported.addElement(remoteDevice);
/* 355 */             Integer deviceClassInt = (Integer)previouslyFound.get(remoteDevice);
/* 356 */             DeviceClass deviceClass = new DeviceClass(deviceClassInt.intValue());
/* 357 */             listener.deviceDiscovered(remoteDevice, deviceClass);
/*     */             
/* 359 */             if (!this.deviceDiscoveryListeners.contains(listener)) {
/* 360 */               return 5;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 365 */       return discType;
/*     */     } finally {
/* 367 */       this.deviceDiscoveryListeners.removeElement(listener);
/* 368 */       this.deviceDiscoveryListenerFoundDevices.remove(listener);
/* 369 */       this.deviceDiscoveryListenerReportedDevices.remove(listener);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void deviceDiscoveredCallback(DiscoveryListener listener, long deviceAddr, int deviceClass, String deviceName, boolean paired) {
/* 376 */     DebugLog.debug("deviceDiscoveredCallback deviceName", deviceName);
/* 377 */     if (!this.deviceDiscoveryListeners.contains(listener)) {
/*     */       return;
/*     */     }
/*     */     
/* 381 */     RemoteDevice remoteDevice = RemoteDeviceHelper.createRemoteDevice(this, deviceAddr, deviceName, paired);
/* 382 */     Vector reported = (Vector)this.deviceDiscoveryListenerReportedDevices.get(listener);
/* 383 */     if (reported == null || reported.contains(remoteDevice)) {
/*     */       return;
/*     */     }
/*     */     
/* 387 */     Hashtable previouslyFound = (Hashtable)this.deviceDiscoveryListenerFoundDevices.get(listener);
/* 388 */     if (previouslyFound != null) {
/* 389 */       Integer deviceClassInt = (Integer)previouslyFound.get(remoteDevice);
/* 390 */       if (deviceClassInt == null) {
/* 391 */         previouslyFound.put(remoteDevice, new Integer(deviceClass));
/* 392 */       } else if (deviceClass != 0) {
/* 393 */         previouslyFound.put(remoteDevice, new Integer(deviceClass));
/*     */       } 
/*     */     } else {
/* 396 */       DeviceClass cod = new DeviceClass(deviceClass);
/* 397 */       reported.addElement(remoteDevice);
/* 398 */       DebugLog.debug("deviceDiscoveredCallback address", remoteDevice.getBluetoothAddress());
/* 399 */       DebugLog.debug("deviceDiscoveredCallback deviceClass", cod);
/* 400 */       listener.deviceDiscovered(remoteDevice, cod);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private native boolean deviceInquiryCancelImpl();
/*     */   
/*     */   public boolean cancelInquiry(DiscoveryListener listener) {
/* 408 */     if (!this.deviceDiscoveryListeners.removeElement(listener)) {
/* 409 */       return false;
/*     */     }
/* 411 */     return deviceInquiryCancelImpl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native String getRemoteDeviceFriendlyNameImpl(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRemoteDeviceFriendlyName(long address) throws IOException {
/* 423 */     return getRemoteDeviceFriendlyNameImpl(address);
/*     */   }
/*     */ 
/*     */   
/*     */   private native short connectSDPImpl(long paramLong);
/*     */ 
/*     */   
/*     */   private native void disconnectSDPImpl(short paramShort);
/*     */   
/*     */   private native long[] searchServicesImpl(SearchServicesThread paramSearchServicesThread, short paramShort, byte[][] paramArrayOfbyte);
/*     */   
/*     */   private native byte[] populateWorkerImpl(short paramShort, long paramLong, int[] paramArrayOfint);
/*     */   
/*     */   private boolean setAttributes(ServiceRecordImpl serviceRecord, int[] attrIDs, byte[] bytes) {
/* 437 */     boolean anyRetrived = false;
/*     */     
/* 439 */     ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
/*     */     
/* 441 */     BluetoothStackWIDCOMMSDPInputStream btis = null;
/*     */     try {
/* 443 */       btis = new BluetoothStackWIDCOMMSDPInputStream(bais);
/*     */     }
/* 445 */     catch (Exception e) {}
/*     */ 
/*     */     
/* 448 */     for (int i = 0; i < attrIDs.length; i++) {
/* 449 */       int id = attrIDs[i];
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 454 */         DataElement element = btis.readElement();
/*     */ 
/*     */ 
/*     */         
/* 458 */         if (id == 4) {
/* 459 */           Enumeration protocolsSeqEnum = (Enumeration)element.getValue();
/* 460 */           if (protocolsSeqEnum.hasMoreElements()) {
/* 461 */             DataElement protocolElement = protocolsSeqEnum.nextElement();
/* 462 */             if (protocolElement.getDataType() != 48) {
/* 463 */               DataElement newMainSeq = new DataElement(48);
/* 464 */               newMainSeq.addElement(element);
/* 465 */               element = newMainSeq;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 470 */         serviceRecord.populateAttributeValue(id, element);
/* 471 */         anyRetrived = true;
/* 472 */       } catch (Throwable e) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 478 */     return anyRetrived;
/*     */   }
/*     */ 
/*     */   
/*     */   public int runSearchServices(SearchServicesThread startedNotify, int[] attrSet, UUID[] uuidSet, RemoteDevice device, DiscoveryListener listener) throws BluetoothStateException {
/*     */     short cid;
/*     */     long[] handles;
/*     */     try {
/* 486 */       cid = connectSDPImpl(RemoteDeviceHelper.getAddress(device.getBluetoothAddress()));
/*     */     }
/* 488 */     catch (Exception e) {
/* 489 */       return 6;
/*     */     } 
/*     */     
/* 492 */     byte[][] uuidBytes = new byte[uuidSet.length][16];
/* 493 */     for (int i = 0; i < uuidSet.length; i++) {
/* 494 */       uuidBytes[i] = new byte[16];
/* 495 */       String full = uuidSet[i].toString();
/* 496 */       for (int k = 0; k < 16; k++) {
/* 497 */         String sub = full.substring(k * 2, k * 2 + 2).toUpperCase();
/* 498 */         uuidBytes[i][k] = (byte)Integer.parseInt(sub, 16);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 505 */       handles = searchServicesImpl(startedNotify, cid, uuidBytes);
/*     */     }
/* 507 */     catch (Exception e) {
/* 508 */       disconnectSDPImpl(cid);
/* 509 */       return 3;
/*     */     } 
/*     */     
/* 512 */     if (handles.length <= 0) {
/* 513 */       disconnectSDPImpl(cid);
/* 514 */       return 4;
/*     */     } 
/*     */     
/* 517 */     ServiceRecordImpl[] records = new ServiceRecordImpl[handles.length];
/*     */     
/* 519 */     for (int j = 0; j < handles.length; j++) {
/* 520 */       byte[] bytes; records[j] = new ServiceRecordImpl(this, device, handles[j]);
/*     */       
/*     */       try {
/* 523 */         bytes = populateWorkerImpl(cid, handles[j], attrSet);
/*     */       }
/* 525 */       catch (Exception e) {
/* 526 */         disconnectSDPImpl(cid);
/* 527 */         return 3;
/*     */       } 
/* 529 */       if (bytes != null) {
/* 530 */         setAttributes(records[j], attrSet, bytes);
/*     */       }
/*     */     } 
/*     */     
/* 534 */     listener.servicesDiscovered(startedNotify.getTransID(), (ServiceRecord[])records);
/*     */     
/* 536 */     disconnectSDPImpl(cid);
/*     */     
/* 538 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int searchServices(int[] attrSet, UUID[] uuidSet, RemoteDevice device, DiscoveryListener listener) throws BluetoothStateException {
/* 543 */     return SearchServicesThread.startSearchServices(this, this, attrSet, uuidSet, device, listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean cancelServiceSearch(int transID) {
/* 548 */     return false;
/*     */   }
/*     */   public boolean populateServicesRecordAttributeValues(ServiceRecordImpl serviceRecord, int[] attrIDs) throws IOException {
/*     */     short cid;
/*     */     byte[] bytes;
/* 553 */     if (attrIDs.length > 65535) {
/* 554 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 559 */       cid = connectSDPImpl(RemoteDeviceHelper.getAddress(serviceRecord.getHostDevice().getBluetoothAddress()));
/*     */     }
/* 561 */     catch (Exception e) {
/* 562 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 568 */       bytes = populateWorkerImpl(cid, serviceRecord.getHandle(), attrIDs);
/*     */     }
/* 570 */     catch (Exception e) {
/* 571 */       disconnectSDPImpl(cid);
/* 572 */       return false;
/*     */     } 
/*     */     
/* 575 */     if (bytes == null) {
/* 576 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 581 */     boolean ret = setAttributes(serviceRecord, attrIDs, bytes);
/*     */     
/* 583 */     disconnectSDPImpl(cid);
/*     */     
/* 585 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long connectionRfOpenClientConnection(BluetoothConnectionParams params) throws IOException {
/* 592 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void connectionRfCloseClientConnection(long handle) throws IOException {}
/*     */ 
/*     */   
/*     */   public int rfGetSecurityOpt(long handle, int expected) throws IOException {
/* 601 */     return expected;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean rfEncrypt(long address, long handle, boolean on) throws IOException {
/* 610 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long rfServerOpen(BluetoothConnectionNotifierParams params, ServiceRecordImpl serviceRecord) throws IOException {
/* 618 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rfServerClose(long handle, ServiceRecordImpl serviceRecord) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rfServerUpdateServiceRecord(long handle, ServiceRecordImpl serviceRecord, boolean acceptAndOpen) throws ServiceRegistrationException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public long rfServerAcceptAndOpenRfServerConnection(long handle) throws IOException {
/* 634 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connectionRfCloseServerConnection(long handle) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connectionRfFlush(long handle) throws IOException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public int connectionRfRead(long handle) throws IOException {
/* 650 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int connectionRfRead(long handle, byte[] b, int off, int len) throws IOException {
/* 655 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int connectionRfReadAvailable(long handle) throws IOException {
/* 660 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connectionRfWrite(long handle, int b) throws IOException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void connectionRfWrite(long handle, byte[] b, int off, int len) throws IOException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public long getConnectionRfRemoteAddress(long handle) throws IOException {
/* 675 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long l2OpenClientConnection(BluetoothConnectionParams params, int receiveMTU, int transmitMTU) throws IOException {
/* 689 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void l2CloseClientConnection(long handle) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long l2ServerOpen(BluetoothConnectionNotifierParams params, int receiveMTU, int transmitMTU, ServiceRecordImpl serviceRecord) throws IOException {
/* 710 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void l2ServerUpdateServiceRecord(long handle, ServiceRecordImpl serviceRecord, boolean acceptAndOpen) throws ServiceRegistrationException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long l2ServerAcceptAndOpenServerConnection(long handle) throws IOException {
/* 731 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void l2CloseServerConnection(long handle) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void l2ServerClose(long handle, ServiceRecordImpl serviceRecord) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int l2GetSecurityOpt(long handle, int expected) throws IOException {
/* 756 */     return expected;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean l2Ready(long handle) throws IOException {
/* 766 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int l2Receive(long handle, byte[] inBuf) throws IOException {
/* 776 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void l2Send(long handle, byte[] data, int transmitMTU) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int l2GetReceiveMTU(long handle) throws IOException {
/* 795 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int l2GetTransmitMTU(long handle) throws IOException {
/* 805 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long l2RemoteAddress(long handle) throws IOException {
/* 815 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean l2Encrypt(long address, long handle, boolean on) throws IOException {
/* 825 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothStackToshiba.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */