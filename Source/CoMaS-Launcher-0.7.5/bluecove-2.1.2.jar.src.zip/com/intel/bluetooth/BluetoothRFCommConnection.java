/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.bluetooth.RemoteDevice;
/*     */ import javax.microedition.io.StreamConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BluetoothRFCommConnection
/*     */   implements StreamConnection, BluetoothConnectionAccess
/*     */ {
/*     */   protected BluetoothStack bluetoothStack;
/*     */   protected volatile long handle;
/*     */   private BluetoothRFCommInputStream in;
/*     */   private BluetoothRFCommOutputStream out;
/*     */   private boolean isClosed;
/*     */   protected int securityOpt;
/*     */   RemoteDevice remoteDevice;
/*     */   
/*     */   protected BluetoothRFCommConnection(BluetoothStack bluetoothStack, long handle) {
/*  66 */     this.bluetoothStack = bluetoothStack;
/*  67 */     this.handle = handle;
/*  68 */     this.isClosed = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void closeConnectionHandle(long paramLong) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void streamClosed() throws IOException {
/*  86 */     if (!this.isClosed) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  91 */     if (this.in != null && !this.in.isClosed()) {
/*     */       return;
/*     */     }
/*     */     
/*  95 */     if (this.out != null && !this.out.isClosed()) {
/*     */       return;
/*     */     }
/*     */     
/*  99 */     shutdown();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown() throws IOException {
/* 108 */     if (this.handle != 0L) {
/* 109 */       long synchronizedHandle; DebugLog.debug("closing RFCOMM Connection", this.handle);
/*     */ 
/*     */       
/* 112 */       synchronized (this) {
/* 113 */         synchronizedHandle = this.handle;
/* 114 */         this.handle = 0L;
/*     */       } 
/* 116 */       if (synchronizedHandle != 0L) {
/* 117 */         closeConnectionHandle(synchronizedHandle);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream openInputStream() throws IOException {
/* 136 */     if (this.isClosed) {
/* 137 */       throw new IOException("RFCOMM Connection is already closed");
/*     */     }
/* 139 */     if (this.in == null) {
/* 140 */       this.in = new BluetoothRFCommInputStream(this);
/* 141 */       return this.in;
/* 142 */     }  if (this.in.isClosed()) {
/* 143 */       throw new IOException("Stream cannot be reopened");
/*     */     }
/* 145 */     throw new IOException("Another InputStream already opened");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataInputStream openDataInputStream() throws IOException {
/* 166 */     return new DataInputStream(openInputStream());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream openOutputStream() throws IOException {
/* 183 */     if (this.isClosed) {
/* 184 */       throw new IOException("RFCOMM Connection is already closed");
/*     */     }
/* 186 */     if (this.out == null) {
/* 187 */       this.out = new BluetoothRFCommOutputStream(this);
/* 188 */       return this.out;
/* 189 */     }  if (this.out.isClosed()) {
/* 190 */       throw new IOException("Stream cannot be reopened");
/*     */     }
/* 192 */     throw new IOException("Another OutputStream already opened");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataOutputStream openDataOutputStream() throws IOException {
/* 213 */     return new DataOutputStream(openOutputStream());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 231 */     if (this.isClosed) {
/*     */       return;
/*     */     }
/* 234 */     this.isClosed = true;
/* 235 */     streamClosed();
/*     */   }
/*     */   
/*     */   protected void finalize() {
/*     */     try {
/* 240 */       close();
/* 241 */     } catch (IOException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isClosed() {
/* 251 */     return this.isClosed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markAuthenticated() {
/* 260 */     if (this.securityOpt == 0) {
/* 261 */       this.securityOpt = 1;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSecurityOpt() {
/*     */     try {
/* 272 */       this.securityOpt = this.bluetoothStack.rfGetSecurityOpt(this.handle, this.securityOpt);
/* 273 */     } catch (IOException notChanged) {}
/*     */     
/* 275 */     return this.securityOpt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean encrypt(long address, boolean on) throws IOException {
/* 284 */     if (this.isClosed) {
/* 285 */       throw new IOException("RFCOMM Connection is already closed");
/*     */     }
/* 287 */     boolean changed = this.bluetoothStack.rfEncrypt(address, this.handle, on);
/* 288 */     if (changed) {
/* 289 */       if (on) {
/* 290 */         this.securityOpt = 2;
/*     */       } else {
/* 292 */         this.securityOpt = 1;
/*     */       } 
/*     */     }
/* 295 */     return changed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getRemoteAddress() throws IOException {
/* 304 */     if (this.isClosed) {
/* 305 */       throw new IOException("Connection closed");
/*     */     }
/* 307 */     return this.bluetoothStack.getConnectionRfRemoteAddress(this.handle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RemoteDevice getRemoteDevice() {
/* 316 */     return this.remoteDevice;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRemoteDevice(RemoteDevice remoteDevice) {
/* 325 */     this.remoteDevice = remoteDevice;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BluetoothStack getBluetoothStack() {
/* 334 */     return this.bluetoothStack;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothRFCommConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */