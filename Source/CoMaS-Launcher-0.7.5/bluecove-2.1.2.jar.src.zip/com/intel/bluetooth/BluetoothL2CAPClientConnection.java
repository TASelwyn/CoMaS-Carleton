/*    */ package com.intel.bluetooth;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BluetoothL2CAPClientConnection
/*    */   extends BluetoothL2CAPConnection
/*    */ {
/*    */   public BluetoothL2CAPClientConnection(BluetoothStack bluetoothStack, BluetoothConnectionParams params, int receiveMTU, int transmitMTU) throws IOException {
/* 35 */     super(bluetoothStack, bluetoothStack.l2OpenClientConnection(params, receiveMTU, transmitMTU));
/* 36 */     boolean initOK = false;
/*    */     try {
/* 38 */       this.securityOpt = bluetoothStack.l2GetSecurityOpt(this.handle, Utils.securityOpt(params.authenticate, params.encrypt));
/* 39 */       this.transmitMTU = getTransmitMTU();
/*    */       
/* 41 */       if (transmitMTU > 0 && transmitMTU < this.transmitMTU) {
/* 42 */         this.transmitMTU = transmitMTU;
/*    */       }
/* 44 */       RemoteDeviceHelper.connected(this);
/* 45 */       initOK = true;
/*    */     } finally {
/* 47 */       if (!initOK) {
/*    */         try {
/* 49 */           bluetoothStack.l2CloseClientConnection(this.handle);
/* 50 */         } catch (IOException e) {
/* 51 */           DebugLog.error("close error", e);
/*    */         } 
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void closeConnectionHandle(long handle) throws IOException {
/* 63 */     RemoteDeviceHelper.disconnected(this);
/* 64 */     this.bluetoothStack.l2CloseClientConnection(handle);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothL2CAPClientConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */