/*     */ package org.bridj;
/*     */ 
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.Buffer;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.bridj.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PointerIO<T>
/*     */ {
/*     */   final Type targetType;
/*     */   final Class<?> typedPointerClass;
/*     */   final int targetSize;
/*  48 */   final int targetAlignment = -1;
/*     */   
/*     */   public PointerIO(Type targetType, int targetSize, Class<?> typedPointerClass) {
/*  51 */     this.targetType = targetType;
/*  52 */     this.targetSize = targetSize;
/*  53 */     this.typedPointerClass = typedPointerClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getArray(Pointer<T> pointer, long byteOffset, int length) {
/*  58 */     return pointer.offset(byteOffset).toArray(length);
/*     */   }
/*     */   public <B extends Buffer> B getBuffer(Pointer<T> pointer, long byteOffset, int length) {
/*  61 */     throw new UnsupportedOperationException("Cannot create a Buffer instance of elements of type " + getTargetType());
/*     */   }
/*     */   public void setArray(Pointer<T> pointer, long byteOffset, Object array) {
/*  64 */     Object[] a = (Object[])array;
/*  65 */     for (int i = 0, n = a.length; i < n; i++)
/*  66 */       set(pointer, i, (T)a[i]); 
/*     */   }
/*     */   
/*     */   public T castTarget(long peer) {
/*  70 */     throw new UnsupportedOperationException("Cannot cast pointer to " + this.targetType);
/*     */   }
/*     */   
/*     */   PointerIO<Pointer<T>> getReferenceIO() {
/*  74 */     return new CommonPointerIOs.PointerPointerIO<T>(this);
/*     */   }
/*     */   public long getTargetSize() {
/*  77 */     return this.targetSize;
/*     */   }
/*     */   public long getTargetAlignment() {
/*  80 */     return getTargetSize();
/*     */   }
/*     */   public boolean isTypedPointer() {
/*  83 */     return (this.typedPointerClass != null);
/*     */   }
/*     */   public Class<?> getTypedPointerClass() {
/*  86 */     return this.typedPointerClass;
/*     */   }
/*     */   public Type getTargetType() {
/*  89 */     return this.targetType;
/*     */   }
/*     */   
/*     */   static Class<?> getClass(Type type) {
/*  93 */     if (type instanceof Class)
/*  94 */       return (Class)type; 
/*  95 */     if (type instanceof ParameterizedType)
/*  96 */       return getClass(((ParameterizedType)type).getRawType()); 
/*  97 */     return null;
/*     */   }
/*     */   
/* 100 */   private static final PointerIO<Pointer> PointerIO = (PointerIO)getPointerInstance((PointerIO)null);
/*     */   
/*     */   public static <T> PointerIO<Pointer<T>> getPointerInstance(Type target) {
/* 103 */     return getPointerInstance(getInstance(target));
/*     */   }
/*     */   public static <T> PointerIO<Pointer<T>> getPointerInstance(PointerIO<T> targetIO) {
/* 106 */     return new CommonPointerIOs.PointerPointerIO<T>(targetIO);
/*     */   }
/*     */   public static <T> PointerIO<Pointer<T>> getArrayInstance(PointerIO<T> targetIO, long[] dimensions, int iDimension) {
/* 109 */     return new CommonPointerIOs.PointerArrayIO<T>(targetIO, dimensions, iDimension);
/*     */   }
/*     */   
/*     */   static <T> PointerIO<T> getArrayIO(Object array) {
/* 113 */     if (array instanceof int[])
/* 114 */       return (PointerIO)CommonPointerIOs.intIO; 
/* 115 */     if (array instanceof long[])
/* 116 */       return (PointerIO)CommonPointerIOs.longIO; 
/* 117 */     if (array instanceof short[])
/* 118 */       return (PointerIO)CommonPointerIOs.shortIO; 
/* 119 */     if (array instanceof byte[])
/* 120 */       return (PointerIO)CommonPointerIOs.byteIO; 
/* 121 */     if (array instanceof char[])
/* 122 */       return (PointerIO)CommonPointerIOs.charIO; 
/* 123 */     if (array instanceof float[])
/* 124 */       return (PointerIO)CommonPointerIOs.floatIO; 
/* 125 */     if (array instanceof double[])
/* 126 */       return (PointerIO)CommonPointerIOs.doubleIO; 
/* 127 */     if (array instanceof boolean[])
/* 128 */       return (PointerIO)CommonPointerIOs.booleanIO; 
/* 129 */     return getInstance(array.getClass().getComponentType());
/*     */   }
/*     */   
/* 132 */   private static final ConcurrentHashMap<StructIO, PointerIO<?>> structIOs = new ConcurrentHashMap<StructIO, PointerIO<?>>();
/*     */   public static <S extends StructObject> PointerIO<S> getInstance(StructIO s) {
/* 134 */     PointerIO<StructObject> io = (PointerIO)structIOs.get(s);
/* 135 */     if (io == null) {
/* 136 */       io = new CommonPointerIOs.StructPointerIO<StructObject>(s);
/* 137 */       PointerIO<StructObject> previousIO = (PointerIO)structIOs.putIfAbsent(s, io);
/* 138 */       if (previousIO != null)
/* 139 */         io = previousIO; 
/*     */     } 
/* 141 */     return (PointerIO)io;
/*     */   }
/* 143 */   private static final ConcurrentHashMap<Type, PointerIO<?>> ios = new ConcurrentHashMap<Type, PointerIO<?>>();
/*     */   static {
/* 145 */     ios.put(Pointer.class, PointerIO);
/* 146 */     ios.put(SizeT.class, CommonPointerIOs.SizeTIO);
/* 147 */     ios.put(TimeT.class, CommonPointerIOs.TimeTIO);
/* 148 */     ios.put(CLong.class, CommonPointerIOs.CLongIO);
/*     */ 
/*     */     
/* 151 */     PointerIO<Integer> pointerIO6 = CommonPointerIOs.intIO;
/* 152 */     ios.put(int.class, pointerIO6);
/* 153 */     ios.put(Integer.class, pointerIO6);
/*     */ 
/*     */     
/* 156 */     PointerIO<Long> pointerIO5 = CommonPointerIOs.longIO;
/* 157 */     ios.put(long.class, pointerIO5);
/* 158 */     ios.put(Long.class, pointerIO5);
/*     */ 
/*     */     
/* 161 */     PointerIO<Short> pointerIO4 = CommonPointerIOs.shortIO;
/* 162 */     ios.put(short.class, pointerIO4);
/* 163 */     ios.put(Short.class, pointerIO4);
/*     */ 
/*     */     
/* 166 */     PointerIO<Byte> pointerIO3 = CommonPointerIOs.byteIO;
/* 167 */     ios.put(byte.class, pointerIO3);
/* 168 */     ios.put(Byte.class, pointerIO3);
/*     */ 
/*     */     
/* 171 */     PointerIO<Character> pointerIO2 = CommonPointerIOs.charIO;
/* 172 */     ios.put(char.class, pointerIO2);
/* 173 */     ios.put(Character.class, pointerIO2);
/*     */ 
/*     */     
/* 176 */     PointerIO<Float> pointerIO1 = CommonPointerIOs.floatIO;
/* 177 */     ios.put(float.class, pointerIO1);
/* 178 */     ios.put(Float.class, pointerIO1);
/*     */ 
/*     */     
/* 181 */     PointerIO<Double> pointerIO = CommonPointerIOs.doubleIO;
/* 182 */     ios.put(double.class, pointerIO);
/* 183 */     ios.put(Double.class, pointerIO);
/*     */ 
/*     */     
/* 186 */     PointerIO<Boolean> io = CommonPointerIOs.booleanIO;
/* 187 */     ios.put(boolean.class, io);
/* 188 */     ios.put(Boolean.class, io);
/*     */   }
/*     */   
/*     */   public static <P> PointerIO<P> getInstance(Type type) {
/* 192 */     if (type == null) {
/* 193 */       return null;
/*     */     }
/* 195 */     PointerIO<Pointer<?>> io = (PointerIO)ios.get(type);
/* 196 */     if (io == null) {
/* 197 */       Class<?> cl = Utils.getClass(type);
/* 198 */       if (cl != null)
/* 199 */         if (cl == Pointer.class) {
/* 200 */           io = getPointerInstance(((ParameterizedType)type).getActualTypeArguments()[0]);
/* 201 */         } else if (StructObject.class.isAssignableFrom(cl)) {
/* 202 */           io = getInstance(StructIO.getInstance(cl, type));
/* 203 */         } else if (Callback.class.isAssignableFrom(cl)) {
/* 204 */           io = new CommonPointerIOs.CallbackPointerIO(cl);
/* 205 */         } else if (NativeObject.class.isAssignableFrom(cl)) {
/* 206 */           io = new CommonPointerIOs.NativeObjectPointerIO<Pointer<?>>(type);
/* 207 */         } else if (IntValuedEnum.class.isAssignableFrom(cl)) {
/* 208 */           if (type instanceof ParameterizedType) {
/* 209 */             Type enumType = ((ParameterizedType)type).getActualTypeArguments()[0];
/* 210 */             if (enumType instanceof Class) {
/* 211 */               io = new CommonPointerIOs.IntValuedEnumPointerIO((Class)enumType);
/*     */             }
/*     */           } 
/* 214 */         } else if (TypedPointer.class.isAssignableFrom(cl)) {
/* 215 */           io = new CommonPointerIOs.TypedPointerPointerIO(cl);
/*     */         }  
/* 217 */       if (io != null) {
/* 218 */         PointerIO<Pointer<?>> previousIO = (PointerIO)ios.putIfAbsent(type, io);
/* 219 */         if (previousIO != null)
/* 220 */           io = previousIO; 
/*     */       } 
/*     */     } 
/* 223 */     return (PointerIO)io;
/*     */   }
/*     */ 
/*     */   
/*     */   public static PointerIO<Integer> getIntInstance() {
/* 228 */     return CommonPointerIOs.intIO;
/*     */   }
/*     */   public static PointerIO<Long> getLongInstance() {
/* 231 */     return CommonPointerIOs.longIO;
/*     */   }
/*     */   public static PointerIO<Short> getShortInstance() {
/* 234 */     return CommonPointerIOs.shortIO;
/*     */   }
/*     */   public static PointerIO<Byte> getByteInstance() {
/* 237 */     return CommonPointerIOs.byteIO;
/*     */   }
/*     */   public static PointerIO<Character> getCharInstance() {
/* 240 */     return CommonPointerIOs.charIO;
/*     */   }
/*     */   public static PointerIO<Float> getFloatInstance() {
/* 243 */     return CommonPointerIOs.floatIO;
/*     */   }
/*     */   public static PointerIO<Double> getDoubleInstance() {
/* 246 */     return CommonPointerIOs.doubleIO;
/*     */   }
/*     */   public static PointerIO<Boolean> getBooleanInstance() {
/* 249 */     return CommonPointerIOs.booleanIO;
/*     */   }
/*     */   public static PointerIO<CLong> getCLongInstance() {
/* 252 */     return CommonPointerIOs.CLongIO;
/*     */   }
/*     */   public static PointerIO<SizeT> getSizeTInstance() {
/* 255 */     return CommonPointerIOs.SizeTIO;
/*     */   }
/*     */   
/*     */   public static PointerIO<Pointer> getPointerInstance() {
/* 259 */     return PointerIO;
/*     */   }
/*     */   
/*     */   public static PointerIO<TimeT> getTimeTInstance() {
/* 263 */     return CommonPointerIOs.TimeTIO;
/*     */   }
/*     */   
/*     */   public static <P> PointerIO<P> getBufferPrimitiveInstance(Buffer buffer) {
/* 267 */     if (buffer instanceof java.nio.IntBuffer)
/* 268 */       return (PointerIO)CommonPointerIOs.intIO; 
/* 269 */     if (buffer instanceof java.nio.LongBuffer)
/* 270 */       return (PointerIO)CommonPointerIOs.longIO; 
/* 271 */     if (buffer instanceof java.nio.ShortBuffer)
/* 272 */       return (PointerIO)CommonPointerIOs.shortIO; 
/* 273 */     if (buffer instanceof java.nio.ByteBuffer)
/* 274 */       return (PointerIO)CommonPointerIOs.byteIO; 
/* 275 */     if (buffer instanceof java.nio.CharBuffer)
/* 276 */       return (PointerIO)CommonPointerIOs.charIO; 
/* 277 */     if (buffer instanceof java.nio.FloatBuffer)
/* 278 */       return (PointerIO)CommonPointerIOs.floatIO; 
/* 279 */     if (buffer instanceof java.nio.DoubleBuffer)
/* 280 */       return (PointerIO)CommonPointerIOs.doubleIO; 
/* 281 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   abstract T get(Pointer<T> paramPointer, long paramLong);
/*     */   
/*     */   abstract void set(Pointer<T> paramPointer, long paramLong, T paramT);
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\PointerIO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */