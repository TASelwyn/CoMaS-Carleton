/*     */ package org.bridj;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SignalError
/*     */   extends NativeError
/*     */ {
/*     */   final int signal;
/*     */   final int code;
/*     */   final long address;
/*     */   
/*     */   SignalError(int signal, int code, long address) {
/*  44 */     super(getFullSignalMessage(signal, code, address));
/*  45 */     this.signal = signal;
/*  46 */     this.code = code;
/*  47 */     this.address = address;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSignal() {
/*  54 */     return this.signal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCode() {
/*  61 */     return this.code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getAddress() {
/*  69 */     return this.address;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  74 */     if (!(obj instanceof SignalError)) {
/*  75 */       return false;
/*     */     }
/*  77 */     SignalError e = (SignalError)obj;
/*  78 */     return (this.signal == e.signal && this.code == e.code);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  83 */     return Integer.valueOf(this.signal).hashCode() ^ Integer.valueOf(this.code).hashCode() ^ Long.valueOf(this.address).hashCode();
/*     */   }
/*     */   
/*     */   public static String getFullSignalMessage(int signal, int code, long address) {
/*  87 */     String simple = getSignalMessage(signal, 0, address);
/*  88 */     if (code == 0) {
/*  89 */       return simple;
/*     */     }
/*  91 */     String sub = getSignalMessage(signal, code, address);
/*  92 */     if (sub.equals(simple)) {
/*  93 */       return simple;
/*     */     }
/*  95 */     return simple + " (" + sub + ")";
/*     */   }
/*     */   
/*     */   public static void throwNew(int signal, int code, long address) {
/*  99 */     throw new SignalError(signal, code, address);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getSignalMessage(int signal, int code, long address) {
/* 106 */     switch (signal) {
/*     */       case 11:
/* 108 */         switch (code) {
/*     */           case 1:
/* 110 */             return "Address not mapped to object";
/*     */           case 2:
/* 112 */             return "Invalid permission for mapped object";
/*     */         } 
/* 114 */         return "Segmentation fault : " + toHex(address);
/*     */       
/*     */       case 10:
/* 117 */         switch (code) {
/*     */           case 1:
/* 119 */             return "Invalid address alignment";
/*     */           case 2:
/* 121 */             return "Nonexistent physical address";
/*     */           case 3:
/* 123 */             return "Object-specific HW error";
/*     */         } 
/* 125 */         return "Bus error : " + toHex(address);
/*     */       
/*     */       case 6:
/* 128 */         return "Native exception (call to abort())";
/*     */       case 8:
/* 130 */         switch (code) {
/*     */           case 7:
/* 132 */             return "Integer divide by zero";
/*     */           case 8:
/* 134 */             return "Integer overflow";
/*     */           case 1:
/* 136 */             return "Floating point divide by zero";
/*     */           case 2:
/* 138 */             return "Floating point overflow";
/*     */           case 3:
/* 140 */             return "Floating point underflow";
/*     */           case 4:
/* 142 */             return "Floating point inexact result";
/*     */           case 5:
/* 144 */             return "Invalid floating point operation";
/*     */           case 6:
/* 146 */             return "Subscript out of range";
/*     */         } 
/* 148 */         return "Floating point error";
/*     */       
/*     */       case 12:
/* 151 */         return "Bad argument to system call";
/*     */       case 5:
/* 153 */         switch (code) {
/*     */           case 1:
/* 155 */             return "Process breakpoint";
/*     */           case 2:
/* 157 */             return "Process trace trap";
/*     */         } 
/* 159 */         return "Trace trap";
/*     */       
/*     */       case 4:
/* 162 */         switch (code) {
/*     */           case 1:
/* 164 */             return "Illegal opcode";
/*     */           case 2:
/* 166 */             return "Illegal trap";
/*     */           case 3:
/* 168 */             return "Privileged opcode";
/*     */           case 4:
/* 170 */             return "Illegal operand";
/*     */           case 5:
/* 172 */             return "Illegal addressing mode";
/*     */           case 6:
/* 174 */             return "Privileged register";
/*     */           case 7:
/* 176 */             return "Coprocessor error";
/*     */           case 8:
/* 178 */             return "Internal stack error";
/*     */         } 
/* 180 */         return "Illegal instruction";
/*     */     } 
/*     */     
/* 183 */     return "Native error";
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\SignalError.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */