/*     */ package org.bridj;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Type;
/*     */ import org.bridj.dyncall.DyncallLibrary;
/*     */ import org.bridj.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ interface CallIO
/*     */ {
/*     */   Object newInstance(long paramLong);
/*     */   
/*     */   long getDCStruct();
/*     */   
/*     */   long getPeer(Object paramObject);
/*     */   
/*     */   public static class Utils
/*     */   {
/*     */     public static CallIO createPointerCallIOToTargetType(Type targetType) {
/*  54 */       return new CallIO.GenericPointerHandler(targetType);
/*     */     }
/*     */     
/*     */     public static <EE extends Enum<EE>> CallIO createValuedEnumCallIO(final Class<EE> enumClass) {
/*  58 */       return new CallIO() {
/*     */           public Object newInstance(long value) {
/*  60 */             return FlagSet.fromValue(value, enumClass, new Enum[0]);
/*     */           }
/*     */           
/*     */           public long getDCStruct() {
/*  64 */             return 0L;
/*     */           }
/*     */           
/*     */           public long getPeer(Object o) {
/*  68 */             return 0L;
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static CallIO createPointerCallIO(Type type) {
/*  78 */       return createPointerCallIO(Utils.getClass(type), type);
/*     */     }
/*     */     
/*     */     public static CallIO createPointerCallIO(Class<?> cl, Type type) {
/*  82 */       if (cl == Pointer.class) {
/*  83 */         return createPointerCallIOToTargetType(Utils.getUniqueParameterizedTypeParameter(type));
/*     */       }
/*     */       
/*  86 */       assert TypedPointer.class.isAssignableFrom(cl);
/*  87 */       return new CallIO.TypedPointerIO((Class)cl);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class TypedPointerIO
/*     */     implements CallIO {
/*     */     Class<? extends TypedPointer> type;
/*     */     Constructor<?> constructor;
/*     */     
/*     */     public TypedPointerIO(Class<? extends TypedPointer> type) {
/*  97 */       this.type = type;
/*     */       try {
/*  99 */         this.constructor = type.getConstructor(new Class[] { long.class });
/* 100 */       } catch (Exception ex) {
/* 101 */         throw new RuntimeException("Failed to create " + CallIO.class.getName() + " for type " + type.getName(), ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Pointer<?> newInstance(long address) {
/*     */       try {
/* 108 */         return (address == 0L) ? null : (Pointer)this.constructor.newInstance(new Object[] { Long.valueOf(address) });
/* 109 */       } catch (Exception ex) {
/* 110 */         throw new RuntimeException("Failed to instantiate pointer of type " + this.type.getName(), ex);
/*     */       } 
/*     */     }
/*     */     
/*     */     public long getDCStruct() {
/* 115 */       return 0L;
/*     */     }
/*     */     
/*     */     public long getPeer(Object o) {
/* 119 */       return Pointer.getPeer((Pointer)o);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class NativeObjectHandler
/*     */     implements CallIO
/*     */   {
/*     */     final Class<? extends NativeObject> nativeClass;
/*     */     
/*     */     public NativeObjectHandler(Class<? extends NativeObject> type, Type t, Pointer<DyncallLibrary.DCstruct> pStruct) {
/* 130 */       this.nativeClass = type;
/* 131 */       this.nativeType = t;
/* 132 */       this.pStruct = pStruct;
/*     */     }
/*     */     final Type nativeType; final Pointer<DyncallLibrary.DCstruct> pStruct;
/*     */     
/*     */     public NativeObject newInstance(long address) {
/* 137 */       return Pointer.pointerToAddress(address).getNativeObject((Class)this.nativeClass);
/*     */     }
/*     */     
/*     */     public long getDCStruct() {
/* 141 */       return Pointer.getPeer(this.pStruct);
/*     */     }
/*     */     
/*     */     public long getPeer(Object o) {
/* 145 */       return Pointer.getAddress((NativeObject)o, this.nativeClass);
/*     */     } }
/*     */   
/*     */   public static final class GenericPointerHandler implements CallIO {
/*     */     private final Type targetType;
/*     */     private final PointerIO pointerIO;
/*     */     
/*     */     public GenericPointerHandler(Type targetType) {
/* 153 */       this.targetType = targetType;
/* 154 */       this.pointerIO = PointerIO.getInstance(targetType);
/*     */     }
/*     */ 
/*     */     
/*     */     public Pointer<?> newInstance(long address) {
/* 159 */       return Pointer.pointerToAddress(address, this.pointerIO);
/*     */     }
/*     */     
/*     */     public long getDCStruct() {
/* 163 */       return 0L;
/*     */     }
/*     */     
/*     */     public long getPeer(Object o) {
/* 167 */       return Pointer.getPeer((Pointer)o);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\CallIO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */