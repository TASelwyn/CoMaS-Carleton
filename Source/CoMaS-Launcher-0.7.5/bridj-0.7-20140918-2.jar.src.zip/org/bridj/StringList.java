/*    */ package org.bridj;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.IntBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class StringList
/*    */ {
/*    */   public final ByteBuffer stringsBuffer;
/*    */   public final IntBuffer offsetsBuffer;
/*    */   
/*    */   public StringList(String[] strings) {
/* 42 */     int n = strings.length;
/* 43 */     byte[][] bytes = new byte[n][];
/* 44 */     this.offsetsBuffer = ByteBuffer.allocateDirect(n * 4).asIntBuffer();
/* 45 */     int offset = 0; int i;
/* 46 */     for (i = 0; i < n; i++) {
/* 47 */       this.offsetsBuffer.put(i, offset);
/* 48 */       bytes[i] = strings[i].getBytes(); offset += (strings[i].getBytes()).length + 1;
/*    */     } 
/* 50 */     this.stringsBuffer = ByteBuffer.allocateDirect(offset);
/* 51 */     for (i = 0; i < n; i++) {
/* 52 */       byte[] str = bytes[i];
/* 53 */       this.stringsBuffer.put(str);
/* 54 */       this.stringsBuffer.put((byte)0);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\StringList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */