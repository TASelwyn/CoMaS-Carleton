package org.bridj.relocated.org.objectweb.asm;

final class AnnotationWriter extends AnnotationVisitor {
  private final ClassWriter a;
  
  private int b;
  
  private final boolean c;
  
  private final ByteVector d;
  
  private final ByteVector e;
  
  private final int f;
  
  AnnotationWriter g;
  
  AnnotationWriter h;
  
  AnnotationWriter(ClassWriter paramClassWriter, boolean paramBoolean, ByteVector paramByteVector1, ByteVector paramByteVector2, int paramInt) {
    super(262144);
    this.a = paramClassWriter;
    this.c = paramBoolean;
    this.d = paramByteVector1;
    this.e = paramByteVector2;
    this.f = paramInt;
  }
  
  public void visit(String paramString, Object paramObject) {
    this.b++;
    if (this.c)
      this.d.putShort(this.a.newUTF8(paramString)); 
    if (paramObject instanceof String) {
      this.d.b(115, this.a.newUTF8((String)paramObject));
    } else if (paramObject instanceof Byte) {
      this.d.b(66, (this.a.a(((Byte)paramObject).byteValue())).a);
    } else if (paramObject instanceof Boolean) {
      boolean bool = ((Boolean)paramObject).booleanValue() ? true : false;
      this.d.b(90, (this.a.a(bool)).a);
    } else if (paramObject instanceof Character) {
      this.d.b(67, (this.a.a(((Character)paramObject).charValue())).a);
    } else if (paramObject instanceof Short) {
      this.d.b(83, (this.a.a(((Short)paramObject).shortValue())).a);
    } else if (paramObject instanceof Type) {
      this.d.b(99, this.a.newUTF8(((Type)paramObject).getDescriptor()));
    } else if (paramObject instanceof byte[]) {
      byte[] arrayOfByte = (byte[])paramObject;
      this.d.b(91, arrayOfByte.length);
      for (byte b = 0; b < arrayOfByte.length; b++)
        this.d.b(66, (this.a.a(arrayOfByte[b])).a); 
    } else if (paramObject instanceof boolean[]) {
      boolean[] arrayOfBoolean = (boolean[])paramObject;
      this.d.b(91, arrayOfBoolean.length);
      for (byte b = 0; b < arrayOfBoolean.length; b++)
        this.d.b(90, (this.a.a(arrayOfBoolean[b] ? 1 : 0)).a); 
    } else if (paramObject instanceof short[]) {
      short[] arrayOfShort = (short[])paramObject;
      this.d.b(91, arrayOfShort.length);
      for (byte b = 0; b < arrayOfShort.length; b++)
        this.d.b(83, (this.a.a(arrayOfShort[b])).a); 
    } else if (paramObject instanceof char[]) {
      char[] arrayOfChar = (char[])paramObject;
      this.d.b(91, arrayOfChar.length);
      for (byte b = 0; b < arrayOfChar.length; b++)
        this.d.b(67, (this.a.a(arrayOfChar[b])).a); 
    } else if (paramObject instanceof int[]) {
      int[] arrayOfInt = (int[])paramObject;
      this.d.b(91, arrayOfInt.length);
      for (byte b = 0; b < arrayOfInt.length; b++)
        this.d.b(73, (this.a.a(arrayOfInt[b])).a); 
    } else if (paramObject instanceof long[]) {
      long[] arrayOfLong = (long[])paramObject;
      this.d.b(91, arrayOfLong.length);
      for (byte b = 0; b < arrayOfLong.length; b++)
        this.d.b(74, (this.a.a(arrayOfLong[b])).a); 
    } else if (paramObject instanceof float[]) {
      float[] arrayOfFloat = (float[])paramObject;
      this.d.b(91, arrayOfFloat.length);
      for (byte b = 0; b < arrayOfFloat.length; b++)
        this.d.b(70, (this.a.a(arrayOfFloat[b])).a); 
    } else if (paramObject instanceof double[]) {
      double[] arrayOfDouble = (double[])paramObject;
      this.d.b(91, arrayOfDouble.length);
      for (byte b = 0; b < arrayOfDouble.length; b++)
        this.d.b(68, (this.a.a(arrayOfDouble[b])).a); 
    } else {
      Item item = this.a.a(paramObject);
      this.d.b(".s.IFJDCS".charAt(item.b), item.a);
    } 
  }
  
  public void visitEnum(String paramString1, String paramString2, String paramString3) {
    this.b++;
    if (this.c)
      this.d.putShort(this.a.newUTF8(paramString1)); 
    this.d.b(101, this.a.newUTF8(paramString2)).putShort(this.a.newUTF8(paramString3));
  }
  
  public AnnotationVisitor visitAnnotation(String paramString1, String paramString2) {
    this.b++;
    if (this.c)
      this.d.putShort(this.a.newUTF8(paramString1)); 
    this.d.b(64, this.a.newUTF8(paramString2)).putShort(0);
    return new AnnotationWriter(this.a, true, this.d, this.d, this.d.b - 2);
  }
  
  public AnnotationVisitor visitArray(String paramString) {
    this.b++;
    if (this.c)
      this.d.putShort(this.a.newUTF8(paramString)); 
    this.d.b(91, 0);
    return new AnnotationWriter(this.a, false, this.d, this.d, this.d.b - 2);
  }
  
  public void visitEnd() {
    if (this.e != null) {
      byte[] arrayOfByte = this.e.a;
      arrayOfByte[this.f] = (byte)(this.b >>> 8);
      arrayOfByte[this.f + 1] = (byte)this.b;
    } 
  }
  
  int a() {
    int i = 0;
    for (AnnotationWriter annotationWriter = this; annotationWriter != null; annotationWriter = annotationWriter.g)
      i += annotationWriter.d.b; 
    return i;
  }
  
  void a(ByteVector paramByteVector) {
    byte b = 0;
    int i = 2;
    AnnotationWriter annotationWriter1 = this;
    AnnotationWriter annotationWriter2 = null;
    while (annotationWriter1 != null) {
      b++;
      i += annotationWriter1.d.b;
      annotationWriter1.visitEnd();
      annotationWriter1.h = annotationWriter2;
      annotationWriter2 = annotationWriter1;
      annotationWriter1 = annotationWriter1.g;
    } 
    paramByteVector.putInt(i);
    paramByteVector.putShort(b);
    for (annotationWriter1 = annotationWriter2; annotationWriter1 != null; annotationWriter1 = annotationWriter1.h)
      paramByteVector.putByteArray(annotationWriter1.d.a, 0, annotationWriter1.d.b); 
  }
  
  static void a(AnnotationWriter[] paramArrayOfAnnotationWriter, int paramInt, ByteVector paramByteVector) {
    int i = 1 + 2 * (paramArrayOfAnnotationWriter.length - paramInt);
    int j;
    for (j = paramInt; j < paramArrayOfAnnotationWriter.length; j++)
      i += (paramArrayOfAnnotationWriter[j] == null) ? 0 : paramArrayOfAnnotationWriter[j].a(); 
    paramByteVector.putInt(i).putByte(paramArrayOfAnnotationWriter.length - paramInt);
    for (j = paramInt; j < paramArrayOfAnnotationWriter.length; j++) {
      AnnotationWriter annotationWriter1 = paramArrayOfAnnotationWriter[j];
      AnnotationWriter annotationWriter2 = null;
      byte b = 0;
      while (annotationWriter1 != null) {
        b++;
        annotationWriter1.visitEnd();
        annotationWriter1.h = annotationWriter2;
        annotationWriter2 = annotationWriter1;
        annotationWriter1 = annotationWriter1.g;
      } 
      paramByteVector.putShort(b);
      for (annotationWriter1 = annotationWriter2; annotationWriter1 != null; annotationWriter1 = annotationWriter1.h)
        paramByteVector.putByteArray(annotationWriter1.d.a, 0, annotationWriter1.d.b); 
    } 
  }
}
