package org.bridj.func;

public interface Fun2<T, A1, A2> {
  T apply(A1 paramA1, A2 paramA2);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\func\Fun2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */