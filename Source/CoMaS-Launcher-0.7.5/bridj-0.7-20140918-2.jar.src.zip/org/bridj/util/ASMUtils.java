/*     */ package org.bridj.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import org.bridj.Pointer;
/*     */ import org.bridj.relocated.org.objectweb.asm.ClassReader;
/*     */ import org.bridj.relocated.org.objectweb.asm.ClassVisitor;
/*     */ import org.bridj.relocated.org.objectweb.asm.ClassWriter;
/*     */ import org.bridj.relocated.org.objectweb.asm.FieldVisitor;
/*     */ import org.bridj.relocated.org.objectweb.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ASMUtils
/*     */ {
/*     */   public static String typeDesc(Type t) {
/*  48 */     if (t instanceof Class) {
/*  49 */       Class<Pointer> c = (Class)t;
/*  50 */       if (c == Pointer.class) {
/*  51 */         return "Pointer";
/*     */       }
/*  53 */       if (c.isPrimitive()) {
/*  54 */         String s = c.getSimpleName();
/*  55 */         return Character.toUpperCase(s.charAt(0)) + s.substring(1);
/*  56 */       }  if (c.isArray()) {
/*  57 */         return typeDesc(c.getComponentType()) + "Array";
/*     */       }
/*  59 */       return c.getName().replace('.', '_');
/*     */     } 
/*  61 */     ParameterizedType p = (ParameterizedType)t;
/*  62 */     StringBuilder b = new StringBuilder(typeDesc(p.getRawType()));
/*  63 */     for (Type pp : p.getActualTypeArguments()) {
/*  64 */       b.append("_").append(typeDesc(pp));
/*     */     }
/*  66 */     return b.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void addSuperCall(ClassVisitor cv, String superClassInternalName) {
/*  71 */     MethodVisitor mv = cv.visitMethod(1, "<init>", "()V", null, null);
/*  72 */     mv.visitCode();
/*  73 */     mv.visitVarInsn(25, 0);
/*  74 */     mv.visitMethodInsn(183, superClassInternalName, "<init>", "()V");
/*  75 */     mv.visitInsn(177);
/*  76 */     mv.visitMaxs(1, 1);
/*  77 */     mv.visitEnd();
/*     */   }
/*     */   
/*     */   public static <T> Class<? extends T> createSubclassWithSynchronizedNativeMethodsAndNoStaticFields(Class<T> original, ClassDefiner classDefiner) throws IOException {
/*  81 */     String suffix = "$SynchronizedNative";
/*  82 */     final String originalInternalName = JNIUtils.getNativeName(original);
/*  83 */     String synchronizedName = original.getName() + suffix;
/*  84 */     final String synchronizedInternalName = originalInternalName + suffix;
/*     */     
/*  86 */     ClassWriter classWriter = new ClassWriter(0);
/*     */     
/*  88 */     ClassVisitor cv = new ClassVisitor(262144, (ClassVisitor)classWriter)
/*     */       {
/*     */         public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
/*  91 */           super.visit(version, access, synchronizedInternalName, null, originalInternalName, new String[0]);
/*  92 */           ASMUtils.addSuperCall(this.cv, originalInternalName);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public void visitInnerClass(String name, String outerName, String innerName, int access) {}
/*     */ 
/*     */ 
/*     */         
/*     */         public FieldVisitor visitField(int access, String name, String desc, String signature, Object value) {
/* 102 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
/* 107 */           if (!Modifier.isNative(access)) {
/* 108 */             return null;
/*     */           }
/*     */           
/* 111 */           return super.visitMethod(access | 0x20, name, desc, signature, exceptions);
/*     */         }
/*     */       };
/*     */     
/* 115 */     ClassReader classReader = new ClassReader(original.getName());
/* 116 */     classReader.accept(cv, 0);
/* 117 */     return (Class)classDefiner.defineClass(synchronizedName, classWriter.toByteArray());
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\brid\\util\ASMUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */