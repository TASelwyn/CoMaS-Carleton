package org.bridj.util;

public interface ClassDefiner {
  Class<?> defineClass(String paramString, byte[] paramArrayOfbyte) throws ClassFormatError;
}
