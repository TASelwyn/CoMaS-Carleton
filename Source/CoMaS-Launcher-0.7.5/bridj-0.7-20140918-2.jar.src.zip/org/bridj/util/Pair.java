package org.bridj.util;

import java.util.Map;

public class Pair<U, V> implements Comparable<Pair<U, V>>, Map.Entry<U, V> {
  private U first;
  
  private V second;
  
  public Pair(U first, V second) {
    this.first = first;
    this.second = second;
  }
  
  public Pair() {}
  
  public U getFirst() {
    return this.first;
  }
  
  public V getSecond() {
    return this.second;
  }
  
  public void setFirst(U first) {
    this.first = first;
  }
  
  public void setSecond(V second) {
    this.second = second;
  }
  
  public int compareTo(Pair<U, V> o) {
    Comparable<U> cu = (Comparable<U>)getFirst();
    if (cu == null) {
      if (this.first != null)
        return 1; 
    } else {
      int d = cu.compareTo(o.getFirst());
      if (d != 0)
        return d; 
    } 
    Comparable<V> cv = (Comparable<V>)getSecond();
    if (cv == null)
      return (this.second != null) ? 1 : -1; 
    return cv.compareTo(o.getSecond());
  }
  
  public String toString() {
    return "Pair(" + this.first + ", " + this.second + ")";
  }
  
  public U getKey() {
    return this.first;
  }
  
  public V getValue() {
    return this.second;
  }
  
  public V setValue(V value) {
    V oldValue = this.second;
    this.second = value;
    return oldValue;
  }
  
  public int hashCode() {
    int prime = 31;
    int result = 1;
    result = 31 * result + ((this.first == null) ? 0 : this.first.hashCode());
    result = 31 * result + ((this.second == null) ? 0 : this.second.hashCode());
    return result;
  }
  
  public boolean equals(Object obj) {
    if (this == obj)
      return true; 
    if (obj == null)
      return false; 
    if (getClass() != obj.getClass())
      return false; 
    Pair<?, ?> other = (Pair<?, ?>)obj;
    if (this.first == null) {
      if (other.first != null)
        return false; 
    } else if (!this.first.equals(other.first)) {
      return false;
    } 
    if (this.second == null) {
      if (other.second != null)
        return false; 
    } else if (!this.second.equals(other.second)) {
      return false;
    } 
    return true;
  }
  
  public boolean isFull() {
    return (getFirst() != null && getSecond() != null);
  }
  
  public boolean isEmpty() {
    return (getFirst() == null && getSecond() == null);
  }
}
