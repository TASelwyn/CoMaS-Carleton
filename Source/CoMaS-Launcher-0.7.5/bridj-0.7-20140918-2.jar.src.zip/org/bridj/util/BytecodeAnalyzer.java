/*     */ package org.bridj.util;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.bridj.Platform;
/*     */ import org.bridj.relocated.org.objectweb.asm.AnnotationVisitor;
/*     */ import org.bridj.relocated.org.objectweb.asm.Attribute;
/*     */ import org.bridj.relocated.org.objectweb.asm.ClassReader;
/*     */ import org.bridj.relocated.org.objectweb.asm.ClassVisitor;
/*     */ import org.bridj.relocated.org.objectweb.asm.FieldVisitor;
/*     */ import org.bridj.relocated.org.objectweb.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BytecodeAnalyzer
/*     */ {
/*     */   public static List<String[]> getNativeMethodSignatures(Class c) throws IOException {
/*  65 */     return getNativeMethodSignatures(getInternalName(c), Platform.getClassLoader(c));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String[]> getNativeMethodSignatures(String internalName, ClassLoader classLoader) throws IOException {
/*  73 */     return getNativeMethodSignatures(internalName, classLoader, (List)new ArrayList<String>());
/*     */   }
/*     */   
/*     */   private static List<String[]> getNativeMethodSignatures(final String internalName, ClassLoader classLoader, final List<String[]> ret) throws IOException {
/*  77 */     ClassReader r = new ClassReader(readByteCode(internalName, classLoader));
/*  78 */     String p = r.getSuperName();
/*  79 */     if (p != null && !p.equals("java/lang/Object")) {
/*  80 */       getNativeMethodSignatures(p, classLoader, ret);
/*     */     }
/*     */     
/*  83 */     r.accept(new EmptyVisitor()
/*     */         {
/*     */           public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
/*  86 */             if (Modifier.isNative(access)) {
/*  87 */               ret.add(new String[] { this.val$internalName, name, desc }, );
/*     */             }
/*  89 */             return null;
/*     */           }
/*     */         },  7);
/*     */     
/*  93 */     return ret;
/*     */   }
/*     */   
/*     */   private static List<String> getFieldNames(String internalName, String recurseToInternalName, ClassLoader classLoader, final List<String> ret) throws IOException {
/*  97 */     ClassReader r = new ClassReader(readByteCode(internalName, classLoader));
/*  98 */     String p = r.getSuperName();
/*  99 */     if (p != null && !p.equals("java/lang/Object") && !recurseToInternalName.equals(internalName)) {
/* 100 */       getFieldNames(p, recurseToInternalName, classLoader, ret);
/*     */     }
/*     */     
/* 103 */     r.accept(new EmptyVisitor()
/*     */         {
/*     */           public FieldVisitor visitField(int i, String name, String string1, String string2, Object o) {
/* 106 */             ret.add(name);
/* 107 */             return null;
/*     */           }
/*     */         },  7);
/*     */     
/* 111 */     return ret;
/*     */   }
/*     */   
/*     */   private static List<String> getMethodNames(String internalName, String recurseToInternalName, ClassLoader classLoader, final List<String> ret) throws IOException {
/* 115 */     ClassReader r = new ClassReader(readByteCode(internalName, classLoader));
/* 116 */     String p = r.getSuperName();
/* 117 */     if (p != null && !p.equals("java/lang/Object") && !recurseToInternalName.equals(internalName)) {
/* 118 */       getMethodNames(p, recurseToInternalName, classLoader, ret);
/*     */     }
/*     */     
/* 121 */     r.accept(new EmptyVisitor()
/*     */         {
/*     */           public MethodVisitor visitMethod(int i, String name, String string1, String string2, String[] strings) {
/* 124 */             ret.add(name);
/* 125 */             return null;
/*     */           }
/*     */         },  7);
/*     */     
/* 129 */     return ret;
/*     */   }
/*     */   
/*     */   static String getInternalName(Class c) {
/* 133 */     return c.getName().replace('.', '/');
/*     */   }
/*     */   
/*     */   static URL getClassResource(Class c) throws FileNotFoundException {
/* 137 */     return getClassResource(getInternalName(c), Platform.getClassLoader(c));
/*     */   }
/*     */   
/*     */   static URL getClassResource(String internalClassName, ClassLoader classLoader) throws FileNotFoundException {
/* 141 */     String p = internalClassName + ".class";
/* 142 */     URL u = classLoader.getResource(p);
/* 143 */     if (u == null) {
/* 144 */       throw new FileNotFoundException("Resource '" + p + "'");
/*     */     }
/* 146 */     return u;
/*     */   }
/*     */   
/*     */   static byte[] readByteCode(String classInternalName, ClassLoader classLoader) throws FileNotFoundException, IOException {
/* 150 */     return readBytes(getClassResource(classInternalName, classLoader).openStream(), true);
/*     */   }
/*     */   
/*     */   static byte[] readBytes(InputStream in, boolean close) throws IOException {
/* 154 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 155 */     byte[] b = new byte[1024];
/*     */     int len;
/* 157 */     while ((len = in.read(b)) > 0) {
/* 158 */       out.write(b, 0, len);
/*     */     }
/* 160 */     if (close) {
/* 161 */       in.close();
/*     */     }
/* 163 */     return out.toByteArray();
/*     */   }
/*     */   
/*     */   public static List<String> getFieldNames(Class c, Class recurseTo) throws IOException {
/* 167 */     return getFieldNames(getInternalName(c), getInternalName(recurseTo), Platform.getClassLoader(c), new ArrayList<String>());
/*     */   }
/*     */   
/*     */   public static List<String> getMethodNames(Class c, Class recurseTo) throws IOException {
/* 171 */     return getMethodNames(getInternalName(c), getInternalName(recurseTo), Platform.getClassLoader(c), new ArrayList<String>());
/*     */   }
/*     */   
/*     */   static class EmptyVisitor
/*     */     extends ClassVisitor {
/*     */     public EmptyVisitor() {
/* 177 */       super(262144);
/*     */     }
/*     */ 
/*     */     
/*     */     public void visit(int i, int i1, String string, String string1, String string2, String[] strings) {}
/*     */ 
/*     */     
/*     */     public void visitSource(String string, String string1) {}
/*     */ 
/*     */     
/*     */     public void visitOuterClass(String string, String string1, String string2) {}
/*     */     
/*     */     public AnnotationVisitor visitAnnotation(String string, boolean bln) {
/* 190 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void visitAttribute(Attribute atrbt) {}
/*     */ 
/*     */     
/*     */     public void visitInnerClass(String string, String string1, String string2, int i) {}
/*     */     
/*     */     public FieldVisitor visitField(int i, String string, String string1, String string2, Object o) {
/* 200 */       return null;
/*     */     }
/*     */     
/*     */     public MethodVisitor visitMethod(int i, String string, String string1, String string2, String[] strings) {
/* 204 */       return null;
/*     */     }
/*     */     
/*     */     public void visitEnd() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\brid\\util\BytecodeAnalyzer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */