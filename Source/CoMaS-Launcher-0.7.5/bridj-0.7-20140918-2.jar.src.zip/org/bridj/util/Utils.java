/*     */ package org.bridj.util;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.DoubleBuffer;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.nio.LongBuffer;
/*     */ import java.nio.ShortBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Utils
/*     */ {
/*     */   public static int getEnclosedConstructorParametersOffset(Constructor c) {
/*  52 */     Class<?> enclosingClass = c.getDeclaringClass().getEnclosingClass();
/*  53 */     Class[] params = c.getParameterTypes();
/*  54 */     int overrideOffset = (params.length > 0 && enclosingClass != null && enclosingClass == params[0]) ? 1 : 0;
/*  55 */     return overrideOffset;
/*     */   }
/*     */   
/*     */   public static boolean isDirect(Buffer b) {
/*  59 */     if (b instanceof ByteBuffer) {
/*  60 */       return ((ByteBuffer)b).isDirect();
/*     */     }
/*  62 */     if (b instanceof IntBuffer) {
/*  63 */       return ((IntBuffer)b).isDirect();
/*     */     }
/*  65 */     if (b instanceof LongBuffer) {
/*  66 */       return ((LongBuffer)b).isDirect();
/*     */     }
/*  68 */     if (b instanceof DoubleBuffer) {
/*  69 */       return ((DoubleBuffer)b).isDirect();
/*     */     }
/*  71 */     if (b instanceof FloatBuffer) {
/*  72 */       return ((FloatBuffer)b).isDirect();
/*     */     }
/*  74 */     if (b instanceof ShortBuffer) {
/*  75 */       return ((ShortBuffer)b).isDirect();
/*     */     }
/*  77 */     if (b instanceof CharBuffer) {
/*  78 */       return ((CharBuffer)b).isDirect();
/*     */     }
/*  80 */     return false;
/*     */   }
/*     */   
/*     */   public static Object[] takeRight(Object[] array, int n) {
/*  84 */     if (n == array.length) {
/*  85 */       return array;
/*     */     }
/*  87 */     Object[] res = new Object[n];
/*  88 */     System.arraycopy(array, array.length - n, res, 0, n);
/*  89 */     return res;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object[] takeLeft(Object[] array, int n) {
/*  94 */     if (n == array.length) {
/*  95 */       return array;
/*     */     }
/*  97 */     Object[] res = new Object[n];
/*  98 */     System.arraycopy(array, 0, res, 0, n);
/*  99 */     return res;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSignedIntegral(Type tpe) {
/* 104 */     return (tpe == int.class || tpe == Integer.class || tpe == long.class || tpe == Long.class || tpe == short.class || tpe == Short.class || tpe == byte.class || tpe == Byte.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(Type t) {
/* 111 */     if (t == null) {
/* 112 */       return "?";
/*     */     }
/* 114 */     if (t instanceof Class) {
/* 115 */       return ((Class)t).getName();
/*     */     }
/* 117 */     return t.toString();
/*     */   }
/*     */   
/*     */   public static String toString(Throwable th) {
/* 121 */     if (th == null)
/* 122 */       return "<no trace>"; 
/* 123 */     StringWriter sw = new StringWriter();
/* 124 */     PrintWriter pw = new PrintWriter(sw);
/* 125 */     th.printStackTrace(pw);
/* 126 */     return sw.toString();
/*     */   }
/*     */   
/*     */   public static boolean eq(Object a, Object b) {
/* 130 */     if (((a == null) ? true : false) != ((b == null) ? true : false)) {
/* 131 */       return false;
/*     */     }
/* 133 */     return (a == null || a.equals(b));
/*     */   }
/*     */   
/*     */   public static boolean containsTypeVariables(Type type) {
/* 137 */     if (type instanceof TypeVariable) {
/* 138 */       return true;
/*     */     }
/* 140 */     if (type instanceof ParameterizedType) {
/* 141 */       ParameterizedType pt = (ParameterizedType)type;
/* 142 */       for (Type t : pt.getActualTypeArguments()) {
/* 143 */         if (containsTypeVariables(t)) {
/* 144 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 148 */     return false;
/*     */   }
/*     */   
/*     */   public static <T> Class<T> getClass(Type type) {
/* 152 */     if (type == null) {
/* 153 */       return null;
/*     */     }
/* 155 */     if (type instanceof Class) {
/* 156 */       return (Class<T>)type;
/*     */     }
/* 158 */     if (type instanceof ParameterizedType) {
/* 159 */       return getClass(((ParameterizedType)type).getRawType());
/*     */     }
/* 161 */     if (type instanceof GenericArrayType) {
/* 162 */       return (Class)Array.newInstance(getClass(((GenericArrayType)type).getGenericComponentType()), 0).getClass();
/*     */     }
/* 164 */     if (type instanceof java.lang.reflect.WildcardType) {
/* 165 */       return null;
/*     */     }
/* 167 */     if (type instanceof TypeVariable) {
/* 168 */       Type[] bounds = ((TypeVariable)type).getBounds();
/* 169 */       return getClass(bounds[0]);
/*     */     } 
/* 171 */     throw new UnsupportedOperationException("Cannot infer class from type " + type);
/*     */   }
/*     */   
/*     */   public static Type getParent(Type type) {
/* 175 */     if (type instanceof Class) {
/* 176 */       return ((Class)type).getSuperclass();
/*     */     }
/*     */     
/* 179 */     return getParent(getClass(type));
/*     */   }
/*     */ 
/*     */   
/*     */   public static Class[] getClasses(Type[] types) {
/* 184 */     int n = types.length;
/* 185 */     Class[] ret = new Class[n];
/* 186 */     for (int i = 0; i < n; i++) {
/* 187 */       ret[i] = getClass(types[i]);
/*     */     }
/* 189 */     return ret;
/*     */   }
/*     */   
/*     */   public static Type getUniqueParameterizedTypeParameter(Type type) {
/* 193 */     return (type instanceof ParameterizedType) ? ((ParameterizedType)type).getActualTypeArguments()[0] : null;
/*     */   }
/*     */   
/*     */   public static boolean parametersComplyToSignature(Object[] values, Class[] parameterTypes) {
/* 197 */     if (values.length != parameterTypes.length) {
/* 198 */       return false;
/*     */     }
/* 200 */     for (int i = 0, n = values.length; i < n; i++) {
/* 201 */       Object value = values[i];
/* 202 */       Class parameterType = parameterTypes[i];
/* 203 */       if (!parameterType.isInstance(value)) {
/* 204 */         return false;
/*     */       }
/*     */     } 
/* 207 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\brid\\util\Utils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */