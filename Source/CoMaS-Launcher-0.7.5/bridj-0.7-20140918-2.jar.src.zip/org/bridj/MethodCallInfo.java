/*     */ package org.bridj;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import org.bridj.ann.CLong;
/*     */ import org.bridj.ann.Constructor;
/*     */ import org.bridj.ann.Convention;
/*     */ import org.bridj.ann.DisableDirect;
/*     */ import org.bridj.ann.Ptr;
/*     */ import org.bridj.ann.SetsLastError;
/*     */ import org.bridj.ann.Virtual;
/*     */ import org.bridj.dyncall.DyncallLibrary;
/*     */ import org.bridj.util.AnnotationUtils;
/*     */ import org.bridj.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodCallInfo
/*     */ {
/*     */   List<CallIO> callIOs;
/*     */   private Class<?> declaringClass;
/*     */   long nativeClass;
/*     */   int returnValueType;
/*     */   int[] paramsValueTypes;
/*     */   Method method;
/*     */   String methodName;
/*     */   String symbolName;
/*     */   private long forwardedPointer;
/*     */   String dcSignature;
/*     */   String javaSignature;
/*     */   String asmSignature;
/*     */   Object javaCallback;
/*     */   boolean isGenericCallback;
/*     */   boolean isObjCBlock;
/*  77 */   int virtualIndex = -1;
/*  78 */   int virtualTableOffset = 0;
/*  79 */   private int dcCallingConvention = 0;
/*     */   
/*     */   boolean isVarArgs;
/*     */   
/*     */   boolean isStatic;
/*     */   
/*     */   boolean isCPlusPlus;
/*     */   
/*     */   boolean direct;
/*     */   
/*     */   public MethodCallInfo(Method method) {
/*  90 */     this(method, method);
/*     */   }
/*     */   boolean startsWithThis; boolean bNeedsThisPointer; boolean throwsLastError; boolean setsLastError; boolean hasCC;
/*     */   static boolean derivesFrom(Class<?> c, String className) {
/*  94 */     while (c != null) {
/*  95 */       if (c.getName().equals(className)) {
/*  96 */         return true;
/*     */       }
/*  98 */       c = c.getSuperclass();
/*     */     } 
/* 100 */     return false;
/*     */   }
/*     */   
/*     */   public MethodCallInfo(Type genericReturnType, Type[] parameterTypes, boolean prependJNIPointers) {
/* 104 */     this(genericReturnType, new Annotation[0], parameterTypes, new Annotation[parameterTypes.length][], prependJNIPointers);
/*     */   }
/*     */   
/*     */   public MethodCallInfo(Type genericReturnType, Annotation[] returnAnnotations, Type[] parameterTypes, Annotation[][] paramsAnnotations, boolean prependJNIPointers) {
/* 108 */     init(null, Utils.getClass(genericReturnType), genericReturnType, returnAnnotations, Utils.getClasses(parameterTypes), parameterTypes, paramsAnnotations, prependJNIPointers, false, true);
/*     */   }
/*     */   
/*     */   public MethodCallInfo(Method method, Method definition) {
/* 112 */     setMethod(method);
/*     */     
/* 114 */     setDeclaringClass(method.getDeclaringClass());
/* 115 */     this.symbolName = this.methodName;
/*     */     
/* 117 */     int modifiers = method.getModifiers();
/* 118 */     this.isStatic = Modifier.isStatic(modifiers);
/* 119 */     this.isVarArgs = method.isVarArgs();
/* 120 */     boolean isNative = Modifier.isNative(modifiers);
/* 121 */     boolean isVirtual = AnnotationUtils.isAnnotationPresent(Virtual.class, definition, new Annotation[0]);
/* 122 */     boolean isDirectModeAllowed = (AnnotationUtils.getInheritableAnnotation(DisableDirect.class, definition, new Annotation[0]) == null && BridJ.isDirectModeEnabled());
/*     */ 
/*     */ 
/*     */     
/* 126 */     this.isCPlusPlus = (!this.isStatic && derivesFrom(method.getDeclaringClass(), "org.bridj.cpp.CPPObject"));
/* 127 */     this.isObjCBlock = (!this.isStatic && derivesFrom(method.getDeclaringClass(), "org.bridj.objc.ObjCBlock"));
/*     */     
/* 129 */     init(method, method.getReturnType(), method.getGenericReturnType(), method.getAnnotations(), method.getParameterTypes(), method.getGenericParameterTypes(), method.getParameterAnnotations(), isNative, isVirtual, isDirectModeAllowed);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 137 */     Convention cc = (Convention)AnnotationUtils.getInheritableAnnotation(Convention.class, definition, new Annotation[0]);
/* 138 */     if (cc != null) {
/* 139 */       setCallingConvention(cc.value());
/*     */     }
/* 141 */     List<Class<?>> exceptionTypes = Arrays.asList(definition.getExceptionTypes());
/* 142 */     if (!exceptionTypes.isEmpty()) {
/* 143 */       this.direct = false;
/* 144 */       if (exceptionTypes.contains(LastError.class)) {
/* 145 */         this.throwsLastError = true;
/* 146 */         this.setsLastError = true;
/*     */       } 
/*     */     } 
/* 149 */     if (AnnotationUtils.getInheritableAnnotation(SetsLastError.class, definition, new Annotation[0]) != null) {
/* 150 */       this.direct = false;
/* 151 */       this.setsLastError = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void init(AnnotatedElement annotatedElement, Class<?> returnType, Type genericReturnType, Annotation[] returnAnnotations, Class[] parameterTypes, Type[] genericParameterTypes, Annotation[][] paramsAnnotations, boolean prependJNIPointers, boolean isVirtual, boolean isDirectModeAllowed) {
/* 157 */     assert returnType != null;
/* 158 */     assert genericReturnType != null;
/* 159 */     assert parameterTypes != null;
/* 160 */     assert genericParameterTypes != null;
/* 161 */     assert returnAnnotations != null;
/* 162 */     assert parameterTypes.length == genericParameterTypes.length;
/* 163 */     assert paramsAnnotations.length == genericParameterTypes.length;
/*     */     
/* 165 */     int nParams = genericParameterTypes.length;
/* 166 */     this.paramsValueTypes = new int[nParams];
/*     */     
/* 168 */     this.direct = isDirectModeAllowed;
/*     */     
/* 170 */     StringBuilder javaSig = new StringBuilder(64);
/* 171 */     StringBuilder asmSig = new StringBuilder(64);
/* 172 */     StringBuilder dcSig = new StringBuilder(16);
/* 173 */     javaSig.append('(');
/* 174 */     asmSig.append('(');
/* 175 */     if (prependJNIPointers)
/*     */     {
/* 177 */       dcSig.append('p').append('p');
/*     */     }
/* 179 */     if (BridJ.debug) {
/* 180 */       BridJ.info("Analyzing " + ((this.declaringClass == null) ? "anonymous method" : (this.declaringClass.getName() + "." + this.methodName)));
/*     */     }
/*     */     
/* 183 */     if (this.isObjCBlock) {
/* 184 */       appendToSignature(0, NativeConstants.ValueType.ePointerValue, Pointer.class, Pointer.class, null, dcSig, null);
/*     */     }
/*     */     
/* 187 */     for (int iParam = 0; iParam < nParams; iParam++) {
/*     */       
/* 189 */       Type genericParameterType = genericParameterTypes[iParam];
/* 190 */       Class<?> parameterType = parameterTypes[iParam];
/*     */       
/* 192 */       NativeConstants.ValueType paramValueType = getValueType(iParam, nParams, parameterType, genericParameterType, null, paramsAnnotations[iParam]);
/* 193 */       if (BridJ.veryVerbose) {
/* 194 */         BridJ.info("\tparam " + paramValueType);
/*     */       }
/* 196 */       this.paramsValueTypes[iParam] = paramValueType.ordinal();
/*     */       
/* 198 */       appendToSignature(iParam, paramValueType, parameterType, genericParameterType, javaSig, dcSig, asmSig);
/*     */     } 
/* 200 */     javaSig.append(')');
/* 201 */     asmSig.append(')');
/* 202 */     dcSig.append(')');
/*     */     
/* 204 */     NativeConstants.ValueType retType = getValueType(-1, nParams, returnType, genericReturnType, annotatedElement, returnAnnotations);
/* 205 */     if (BridJ.veryVerbose) {
/* 206 */       BridJ.info("\treturns " + retType);
/*     */     }
/* 208 */     appendToSignature(-1, retType, returnType, genericReturnType, javaSig, dcSig, asmSig);
/* 209 */     this.returnValueType = retType.ordinal();
/*     */     
/* 211 */     this.javaSignature = javaSig.toString();
/* 212 */     this.asmSignature = asmSig.toString();
/* 213 */     this.dcSignature = dcSig.toString();
/*     */     
/* 215 */     this.isCPlusPlus = (this.isCPlusPlus || isVirtual);
/*     */     
/* 217 */     if (this.isCPlusPlus && !this.isStatic) {
/* 218 */       if (!this.startsWithThis) {
/* 219 */         this.direct = false;
/*     */       }
/* 221 */       this.bNeedsThisPointer = true;
/* 222 */       if (Platform.isWindows() && 
/* 223 */         !Platform.is64Bits()) {
/* 224 */         setDcCallingConvention(5);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 232 */     if (nParams > Platform.getMaxDirectMappingArgCount()) {
/* 233 */       this.direct = false;
/*     */     }
/*     */     
/* 236 */     if (BridJ.veryVerbose) {
/* 237 */       BridJ.info("\t-> direct " + this.direct);
/* 238 */       BridJ.info("\t-> javaSignature " + this.javaSignature);
/* 239 */       BridJ.info("\t-> callIOs " + this.callIOs);
/* 240 */       BridJ.info("\t-> asmSignature " + this.asmSignature);
/* 241 */       BridJ.info("\t-> dcSignature " + this.dcSignature);
/*     */     } 
/*     */     
/* 244 */     if (BridJ.veryVerbose) {
/* 245 */       BridJ.info((this.direct ? "[mappable as direct] " : "[not mappable as direct] ") + this.method);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasCallingConvention() {
/* 251 */     return this.hasCC;
/*     */   }
/*     */   
/*     */   public void setCallingConvention(Convention.Style style) {
/* 255 */     if (style == null) {
/*     */       return;
/*     */     }
/*     */     
/* 259 */     if (!Platform.isWindows() || Platform.is64Bits()) {
/*     */       return;
/*     */     }
/*     */     
/* 263 */     switch (style) {
/*     */       case eVoidValue:
/* 265 */         this.direct = false;
/* 266 */         setDcCallingConvention(Platform.isWindows() ? 3 : 0);
/*     */         break;
/*     */       case eIntValue:
/*     */       case eLongValue:
/* 270 */         this.direct = false;
/* 271 */         setDcCallingConvention(2);
/*     */         break;
/*     */       case eCLongValue:
/* 274 */         this.direct = false;
/* 275 */         setDcCallingConvention(Platform.isWindows() ? 5 : 0); break;
/*     */     } 
/* 277 */     if (BridJ.veryVerbose) {
/* 278 */       BridJ.info("Setting CC " + style + " (-> " + this.dcCallingConvention + ") for " + this.methodName);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void addCallIO(CallIO handler) {
/* 284 */     if (this.callIOs == null) {
/* 285 */       this.callIOs = new ArrayList<CallIO>();
/*     */     }
/* 287 */     assert handler != null;
/* 288 */     this.callIOs.add(handler);
/*     */   }
/*     */   
/*     */   public CallIO[] getCallIOs() {
/* 292 */     if (this.callIOs == null) {
/* 293 */       return new CallIO[0];
/*     */     }
/* 295 */     return this.callIOs.<CallIO>toArray(new CallIO[this.callIOs.size()]);
/*     */   }
/*     */   
/*     */   public void prependCallbackCC() {
/* 299 */     char cc = getDcCallbackConvention(getDcCallingConvention());
/* 300 */     if (cc == '\000') {
/*     */       return;
/*     */     }
/*     */     
/* 304 */     this.dcSignature = String.valueOf('_') + String.valueOf(cc) + this.dcSignature;
/*     */   }
/*     */   
/*     */   public String getDcSignature() {
/* 308 */     return this.dcSignature;
/*     */   }
/*     */   
/*     */   public String getJavaSignature() {
/* 312 */     return this.javaSignature;
/*     */   }
/*     */   
/*     */   public String getASMSignature() {
/* 316 */     return this.asmSignature;
/*     */   }
/*     */   
/*     */   boolean getBoolAnnotation(Class<? extends Annotation> ac, AnnotatedElement element, Annotation... directAnnotations) {
/* 320 */     Annotation ann = AnnotationUtils.getAnnotation(ac, element, directAnnotations);
/* 321 */     return (ann != null);
/*     */   }
/*     */   
/*     */   public NativeConstants.ValueType getValueType(int iParam, int nParams, Class<?> c, Type t, AnnotatedElement element, Annotation... directAnnotations) {
/* 325 */     boolean isPtr = AnnotationUtils.isAnnotationPresent(Ptr.class, element, directAnnotations);
/* 326 */     boolean isCLong = AnnotationUtils.isAnnotationPresent(CLong.class, element, directAnnotations);
/* 327 */     Constructor cons = (Constructor)AnnotationUtils.getAnnotation(Constructor.class, element, directAnnotations);
/*     */     
/* 329 */     if (isPtr || cons != null || isCLong) {
/* 330 */       if (c != Long.class && c != long.class) {
/* 331 */         throw new RuntimeException("Annotation should only be used on a long parameter, not on a " + c.getName());
/*     */       }
/*     */       
/* 334 */       if (isPtr) {
/* 335 */         if (!Platform.is64Bits()) {
/* 336 */           this.direct = false;
/*     */         }
/* 338 */       } else if (isCLong) {
/* 339 */         if (Platform.CLONG_SIZE != 8) {
/* 340 */           this.direct = false;
/*     */         }
/* 342 */       } else if (cons != null) {
/* 343 */         this.isCPlusPlus = true;
/* 344 */         this.startsWithThis = true;
/* 345 */         if (iParam != 0) {
/* 346 */           throw new RuntimeException("Annotation " + Constructor.class.getName() + " cannot have more than one (long) argument");
/*     */         }
/*     */       } 
/* 349 */       return isCLong ? NativeConstants.ValueType.eCLongValue : NativeConstants.ValueType.eSizeTValue;
/*     */     } 
/* 351 */     if (c == null || c.equals(void.class)) {
/* 352 */       return NativeConstants.ValueType.eVoidValue;
/*     */     }
/* 354 */     if (c == Integer.class || c == int.class) {
/* 355 */       return NativeConstants.ValueType.eIntValue;
/*     */     }
/* 357 */     if (c == Long.class || c == long.class) {
/* 358 */       return (!isPtr || Platform.is64Bits()) ? NativeConstants.ValueType.eLongValue : NativeConstants.ValueType.eIntValue;
/*     */     }
/* 360 */     if (c == Short.class || c == short.class) {
/* 361 */       return NativeConstants.ValueType.eShortValue;
/*     */     }
/* 363 */     if (c == Byte.class || c == byte.class) {
/* 364 */       return NativeConstants.ValueType.eByteValue;
/*     */     }
/* 366 */     if (c == Boolean.class || c == boolean.class) {
/* 367 */       return NativeConstants.ValueType.eBooleanValue;
/*     */     }
/* 369 */     if (c == Float.class || c == float.class) {
/* 370 */       usesFloats();
/* 371 */       return NativeConstants.ValueType.eFloatValue;
/*     */     } 
/* 373 */     if (c == char.class || c == char.class) {
/* 374 */       if (Platform.WCHAR_T_SIZE != 2) {
/* 375 */         this.direct = false;
/*     */       }
/* 377 */       return NativeConstants.ValueType.eWCharValue;
/*     */     } 
/* 379 */     if (c == Double.class || c == double.class) {
/* 380 */       usesFloats();
/* 381 */       return NativeConstants.ValueType.eDoubleValue;
/*     */     } 
/* 383 */     if (c == CLong.class) {
/* 384 */       this.direct = false;
/* 385 */       return NativeConstants.ValueType.eCLongObjectValue;
/*     */     } 
/* 387 */     if (c == SizeT.class) {
/* 388 */       this.direct = false;
/* 389 */       return NativeConstants.ValueType.eSizeTObjectValue;
/*     */     } 
/* 391 */     if (c == TimeT.class) {
/* 392 */       this.direct = false;
/* 393 */       return NativeConstants.ValueType.eTimeTObjectValue;
/*     */     } 
/* 395 */     if (Pointer.class.isAssignableFrom(c)) {
/* 396 */       this.direct = false;
/* 397 */       CallIO cio = CallIO.Utils.createPointerCallIO(c, t);
/* 398 */       if (BridJ.veryVerbose) {
/* 399 */         BridJ.info("CallIO : " + cio);
/*     */       }
/* 401 */       addCallIO(cio);
/* 402 */       return NativeConstants.ValueType.ePointerValue;
/*     */     } 
/* 404 */     if (c.isArray() && iParam == nParams - 1) {
/* 405 */       this.direct = false;
/* 406 */       return NativeConstants.ValueType.eEllipsis;
/*     */     } 
/* 408 */     if (ValuedEnum.class.isAssignableFrom(c)) {
/* 409 */       this.direct = false;
/* 410 */       CallIO cio = CallIO.Utils.createValuedEnumCallIO(Utils.getClass(Utils.getUniqueParameterizedTypeParameter(t)));
/* 411 */       if (BridJ.veryVerbose) {
/* 412 */         BridJ.info("CallIO : " + cio);
/*     */       }
/* 414 */       addCallIO(cio);
/*     */       
/* 416 */       return NativeConstants.ValueType.eIntFlagSet;
/*     */     } 
/* 418 */     if (NativeObject.class.isAssignableFrom(c)) {
/* 419 */       Pointer<DyncallLibrary.DCstruct> pStruct = null;
/* 420 */       if (StructObject.class.isAssignableFrom(c)) {
/* 421 */         StructIO io = StructIO.getInstance(c, t);
/*     */         try {
/* 423 */           pStruct = DyncallStructs.buildDCstruct(io.desc);
/* 424 */         } catch (Throwable th) {
/* 425 */           BridJ.error("Unable to create low-level struct metadata for " + Utils.toString(t) + " : won't be able to use it as a by-value function argument.", th);
/*     */         } 
/*     */       } 
/* 428 */       addCallIO(new CallIO.NativeObjectHandler((Class)c, t, pStruct));
/* 429 */       this.direct = false;
/* 430 */       return NativeConstants.ValueType.eNativeObjectValue;
/*     */     } 
/*     */     
/* 433 */     throw new NoSuchElementException("No " + NativeConstants.ValueType.class.getSimpleName() + " for class " + c.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void usesFloats() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendToSignature(int iParam, NativeConstants.ValueType type, Class<?> parameterType, Type genericParameterType, StringBuilder javaSig, StringBuilder dcSig, StringBuilder asmSig) {
/*     */     char dcChar;
/* 447 */     String javaChar, asmChar = null;
/* 448 */     switch (type) {
/*     */       case eVoidValue:
/* 450 */         dcChar = 'v';
/* 451 */         javaChar = "V";
/*     */         break;
/*     */       case eIntValue:
/* 454 */         dcChar = 'i';
/* 455 */         javaChar = "I";
/*     */         break;
/*     */       case eLongValue:
/* 458 */         dcChar = 'l';
/* 459 */         javaChar = "J";
/*     */         break;
/*     */       case eCLongValue:
/* 462 */         javaChar = "J";
/* 463 */         dcChar = 'j';
/* 464 */         if (Platform.CLONG_SIZE != 8) {
/* 465 */           this.direct = false;
/*     */         }
/*     */         break;
/*     */       case eSizeTValue:
/* 469 */         javaChar = "J";
/* 470 */         if (Platform.SIZE_T_SIZE == 8) {
/* 471 */           dcChar = 'l'; break;
/*     */         } 
/* 473 */         dcChar = 'i';
/* 474 */         this.direct = false;
/*     */         break;
/*     */       
/*     */       case eShortValue:
/* 478 */         dcChar = 's';
/* 479 */         javaChar = "S";
/*     */         break;
/*     */       case eDoubleValue:
/* 482 */         dcChar = 'd';
/* 483 */         javaChar = "D";
/*     */         break;
/*     */       case eFloatValue:
/* 486 */         dcChar = 'f';
/* 487 */         javaChar = "F";
/*     */         break;
/*     */       case eByteValue:
/* 490 */         dcChar = 'c';
/* 491 */         javaChar = "B";
/*     */         break;
/*     */       case eBooleanValue:
/* 494 */         dcChar = 'B';
/* 495 */         javaChar = "Z";
/*     */         break;
/*     */       case eWCharValue:
/* 498 */         switch (Platform.WCHAR_T_SIZE) {
/*     */           case 1:
/* 500 */             dcChar = 'c';
/* 501 */             this.direct = false;
/*     */             break;
/*     */           case 2:
/* 504 */             dcChar = 's';
/*     */             break;
/*     */           case 4:
/* 507 */             dcChar = 'i';
/* 508 */             this.direct = false;
/*     */             break;
/*     */           default:
/* 511 */             throw new RuntimeException("Unhandled sizeof(wchar_t) in GetJavaTypeSignature: " + Platform.WCHAR_T_SIZE);
/*     */         } 
/* 513 */         javaChar = "C";
/*     */         break;
/*     */       case eIntFlagSet:
/* 516 */         dcChar = 'i';
/* 517 */         javaChar = "L" + parameterType.getName().replace('.', '/') + ";";
/* 518 */         this.direct = false;
/*     */         break;
/*     */       case eCLongObjectValue:
/* 521 */         dcChar = 'p';
/* 522 */         javaChar = "Lorg/bridj/CLong;";
/* 523 */         this.direct = false;
/*     */         break;
/*     */       case eSizeTObjectValue:
/* 526 */         dcChar = 'p';
/* 527 */         javaChar = "Lorg/bridj/SizeT;";
/* 528 */         this.direct = false;
/*     */         break;
/*     */       case eTimeTObjectValue:
/* 531 */         dcChar = 'p';
/* 532 */         javaChar = "Lorg/bridj/TimeT;";
/* 533 */         this.direct = false;
/*     */         break;
/*     */       case ePointerValue:
/* 536 */         dcChar = 'p';
/* 537 */         javaChar = "L" + parameterType.getName().replace('.', '/') + ";";
/*     */         
/* 539 */         this.direct = false;
/*     */         break;
/*     */       case eNativeObjectValue:
/* 542 */         dcChar = 'T';
/* 543 */         javaChar = "L" + parameterType.getName().replace('.', '/') + ";";
/* 544 */         this.direct = false;
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case eEllipsis:
/* 550 */         javaChar = "[Ljava/lang/Object;";
/* 551 */         dcChar = '?';
/*     */         break;
/*     */       default:
/* 554 */         this.direct = false;
/* 555 */         throw new RuntimeException("Unhandled " + NativeConstants.ValueType.class.getSimpleName() + ": " + type);
/*     */     } 
/* 557 */     if (genericParameterType instanceof ParameterizedType && iParam < 0) {
/* 558 */       ParameterizedType pt = (ParameterizedType)genericParameterType;
/*     */       
/* 560 */       Type[] ts = pt.getActualTypeArguments();
/* 561 */       if (ts != null && ts.length == 1) {
/* 562 */         Type t = ts[0];
/* 563 */         if (t instanceof ParameterizedType) {
/* 564 */           t = ((ParameterizedType)t).getRawType();
/*     */         }
/* 566 */         if (t instanceof Class) {
/* 567 */           Class c = (Class)t;
/* 568 */           if (javaChar.endsWith(";")) {
/* 569 */             asmChar = javaChar.substring(0, javaChar.length() - 1) + "<*L" + c.getName().replace('.', '/') + ";>";
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 575 */     if (javaSig != null) {
/* 576 */       javaSig.append(javaChar);
/*     */     }
/* 578 */     if (asmChar == null) {
/* 579 */       asmChar = javaChar;
/*     */     }
/* 581 */     if (asmSig != null) {
/* 582 */       asmSig.append(asmChar);
/*     */     }
/* 584 */     if (dcSig != null) {
/* 585 */       dcSig.append(dcChar);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMethod(Method method) {
/* 599 */     this.method = method;
/* 600 */     if (method != null) {
/* 601 */       this.methodName = method.getName();
/*     */     }
/* 603 */     if (this.declaringClass == null) {
/* 604 */       setDeclaringClass(method.getDeclaringClass());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setJavaSignature(String javaSignature) {
/* 610 */     this.javaSignature = javaSignature;
/*     */   }
/*     */   
/*     */   public Method getMethod() {
/* 614 */     return this.method;
/*     */   }
/*     */   
/*     */   public void setDeclaringClass(Class<?> declaringClass) {
/* 618 */     this.declaringClass = declaringClass;
/*     */   }
/*     */   
/*     */   public Class<?> getDeclaringClass() {
/* 622 */     return this.declaringClass;
/*     */   }
/*     */   
/*     */   public void setForwardedPointer(long forwardedPointer) {
/* 626 */     this.forwardedPointer = forwardedPointer;
/*     */   }
/*     */   
/*     */   public long getForwardedPointer() {
/* 630 */     return this.forwardedPointer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVirtualIndex(int virtualIndex) {
/* 640 */     this.virtualIndex = virtualIndex;
/*     */     
/* 642 */     if (BridJ.veryVerbose) {
/* 643 */       BridJ.info("\t-> virtualIndex " + virtualIndex);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getVirtualIndex() {
/* 648 */     return this.virtualIndex;
/*     */   }
/*     */   
/*     */   public String getSymbolName() {
/* 652 */     return this.symbolName;
/*     */   }
/*     */   
/*     */   public void setSymbolName(String symbolName) {
/* 656 */     this.symbolName = symbolName;
/*     */   }
/*     */   
/*     */   static char getDcCallbackConvention(int dcCallingConvention) {
/* 660 */     switch (dcCallingConvention) {
/*     */       case 2:
/* 662 */         return 's';
/*     */       case 3:
/* 664 */         return 'F';
/*     */       case 4:
/* 666 */         return 'f';
/*     */       case 5:
/* 668 */         return '+';
/*     */     } 
/* 670 */     return Character.MIN_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDcCallingConvention(int dcCallingConvention) {
/* 675 */     this.hasCC = true;
/* 676 */     this.dcCallingConvention = dcCallingConvention;
/*     */   }
/*     */   
/*     */   public int getDcCallingConvention() {
/* 680 */     return this.dcCallingConvention;
/*     */   }
/*     */   
/*     */   public Object getJavaCallback() {
/* 684 */     return this.javaCallback;
/*     */   }
/*     */   
/*     */   public void setJavaCallback(Object javaCallback) {
/* 688 */     this.javaCallback = javaCallback;
/*     */   }
/*     */   
/*     */   public void setGenericCallback(boolean genericCallback) {
/* 692 */     this.isGenericCallback = genericCallback;
/*     */   }
/*     */   
/*     */   public boolean isGenericCallback() {
/* 696 */     return this.isGenericCallback;
/*     */   }
/*     */   
/*     */   public void setNativeClass(long nativeClass) {
/* 700 */     this.nativeClass = nativeClass;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\MethodCallInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */