/*     */ package org.bridj;
/*     */ 
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.bridj.ann.Alignment;
/*     */ import org.bridj.ann.Struct;
/*     */ import org.bridj.util.Pair;
/*     */ import org.bridj.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StructUtils
/*     */ {
/*     */   static long alignSize(long size, long alignment) {
/*  48 */     if (alignment > 1L) {
/*  49 */       long r = size % alignment;
/*  50 */       if (r != 0L) {
/*  51 */         size += alignment - r;
/*     */       }
/*     */     } 
/*  54 */     return size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void orderFields(List<StructFieldDeclaration> fields) {
/*  61 */     Collections.sort(fields, new Comparator<StructFieldDeclaration>()
/*     */         {
/*     */           public int compare(StructFieldDeclaration o1, StructFieldDeclaration o2) {
/*  64 */             long d = o1.index - o2.index;
/*  65 */             if (d != 0L) {
/*  66 */               return (d < 0L) ? -1 : ((d == 0L) ? 0 : 1);
/*     */             }
/*     */             
/*  69 */             if (o1.declaringClass.isAssignableFrom(o2.declaringClass)) {
/*  70 */               return -1;
/*     */             }
/*  72 */             if (o2.declaringClass.isAssignableFrom(o1.declaringClass)) {
/*  73 */               return 1;
/*     */             }
/*     */             
/*  76 */             throw new RuntimeException("Failed to order fields " + o2.desc.name + " and " + o2.desc.name);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   static long primTypeAlignment(Class<?> primType, long length) {
/*  82 */     if (isDouble(primType) && !BridJ.alignDoubles && Platform.isLinux() && !Platform.is64Bits())
/*     */     {
/*     */ 
/*     */       
/*  86 */       return 4L;
/*     */     }
/*  88 */     return length;
/*     */   }
/*     */   
/*     */   static boolean isDouble(Class<?> primType) {
/*  92 */     return (primType == Double.class || primType == double.class);
/*     */   }
/*     */   
/*     */   static int primTypeLength(Class<?> primType) {
/*  96 */     if (primType == Integer.class || primType == int.class)
/*  97 */       return 4; 
/*  98 */     if (primType == Long.class || primType == long.class)
/*  99 */       return 8; 
/* 100 */     if (primType == Short.class || primType == short.class)
/* 101 */       return 2; 
/* 102 */     if (primType == Byte.class || primType == byte.class)
/* 103 */       return 1; 
/* 104 */     if (primType == Character.class || primType == char.class)
/* 105 */       return 2; 
/* 106 */     if (primType == Boolean.class || primType == boolean.class)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 111 */       return 1; } 
/* 112 */     if (primType == Float.class || primType == float.class)
/* 113 */       return 4; 
/* 114 */     if (isDouble(primType))
/* 115 */       return 8; 
/* 116 */     if (Pointer.class.isAssignableFrom(primType)) {
/* 117 */       return Pointer.SIZE;
/*     */     }
/* 119 */     throw new UnsupportedOperationException("Field type " + primType.getName() + " not supported yet");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static long alignmentOf(Type tpe) {
/* 125 */     Class<?> c = PointerIO.getClass(tpe);
/* 126 */     if (StructObject.class.isAssignableFrom(c)) {
/* 127 */       return (StructIO.getInstance(c)).desc.getStructAlignment();
/*     */     }
/* 129 */     return BridJ.sizeOf(tpe);
/*     */   }
/*     */   
/*     */   static int compare(StructObject a, StructObject b, SolidRanges solidRanges) {
/* 133 */     Pointer<StructObject> pA = Pointer.getPointer(a), pB = Pointer.getPointer(b);
/* 134 */     if (pA == null || pB == null) {
/* 135 */       return (pA != null) ? 1 : ((pB != null) ? -1 : 0);
/*     */     }
/*     */     
/* 138 */     long[] offsets = solidRanges.offsets, lengths = solidRanges.lengths;
/* 139 */     for (int i = 0, n = offsets.length; i < n; i++) {
/* 140 */       long offset = offsets[i], length = lengths[i];
/* 141 */       int cmp = pA.compareBytesAtOffset(offset, pB, offset, length);
/* 142 */       if (cmp != 0) {
/* 143 */         return cmp;
/*     */       }
/*     */     } 
/* 146 */     return 0;
/*     */   }
/*     */   
/*     */   static String describe(StructObject struct, Type structType, StructFieldDescription[] fields) {
/* 150 */     StringBuilder b = new StringBuilder();
/* 151 */     b.append(describe(structType)).append(" { ");
/* 152 */     for (StructFieldDescription fd : fields) {
/* 153 */       b.append("\n\t").append(fd.name).append(" = ");
/*     */       try {
/*     */         Object value;
/* 156 */         if (fd.getter != null) {
/* 157 */           value = fd.getter.invoke(struct, new Object[0]);
/*     */         } else {
/* 159 */           value = fd.field.get(struct);
/*     */         } 
/*     */         
/* 162 */         if (value instanceof String) {
/* 163 */           b.append('"').append(value.toString().replaceAll("\"", "\\\"")).append('"');
/* 164 */         } else if (value instanceof Character) {
/* 165 */           b.append('\'').append(value).append('\'');
/* 166 */         } else if (value instanceof NativeObject) {
/* 167 */           String d = BridJ.describe((NativeObject)value);
/* 168 */           b.append(d.replaceAll("\n", "\n\t"));
/*     */         } else {
/* 170 */           b.append(value);
/*     */         } 
/* 172 */       } catch (Throwable th) {
/* 173 */         if (BridJ.debug) {
/* 174 */           th.printStackTrace();
/*     */         }
/* 176 */         b.append("?");
/*     */       } 
/* 178 */       b.append("; ");
/*     */     } 
/* 180 */     b.append("\n}");
/* 181 */     return b.toString();
/*     */   }
/*     */   
/*     */   static String describe(Type t) {
/* 185 */     if (t == null) {
/* 186 */       return "?";
/*     */     }
/* 188 */     if (t instanceof Class) {
/* 189 */       return ((Class)t).getSimpleName();
/*     */     }
/* 191 */     return t.toString().replaceAll("\\bjava\\.lang\\.", "").replaceAll("\\borg\\.bridj\\.cpp\\.com\\.", "").replaceAll("\\borg\\.bridj\\.Pointer\\b", "Pointer");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Pointer fixIntegralTypeIOToMatchLength(Pointer ptr, long byteLength, long arrayLength) {
/* 199 */     long targetSize = ptr.getTargetSize();
/* 200 */     if (targetSize * arrayLength == byteLength) {
/* 201 */       return ptr;
/*     */     }
/*     */     
/* 204 */     Type targetType = ptr.getTargetType();
/* 205 */     if (!Utils.isSignedIntegral(targetType)) {
/* 206 */       return ptr;
/*     */     }
/*     */ 
/*     */     
/* 210 */     switch ((int)byteLength) {
/*     */       case 1:
/* 212 */         return ptr.as(byte.class);
/*     */       case 2:
/* 214 */         return ptr.as(short.class);
/*     */       case 4:
/* 216 */         return ptr.as(int.class);
/*     */       case 8:
/* 218 */         return ptr.as(long.class);
/*     */     } 
/* 220 */     return ptr;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static void computeStructLayout(StructDescription desc, StructCustomizer customizer) {
/* 225 */     List<StructFieldDeclaration> fieldDecls = StructFieldDeclaration.listFields(desc.structClass);
/* 226 */     orderFields(fieldDecls);
/*     */     
/* 228 */     customizer.beforeAggregation(desc, fieldDecls);
/*     */     
/* 230 */     Map<Pair<Class<?>, Long>, List<StructFieldDeclaration>> fieldsMap = new LinkedHashMap<Pair<Class<?>, Long>, List<StructFieldDeclaration>>();
/* 231 */     for (StructFieldDeclaration field : fieldDecls) {
/* 232 */       if (field.index < 0L) {
/* 233 */         throw new RuntimeException("Negative field index not allowed for field " + field.desc.name);
/*     */       }
/*     */       
/* 236 */       long index = (field.unionWith >= 0L) ? field.unionWith : field.index;
/* 237 */       Pair<Class<?>, Long> key = new Pair(field.declaringClass, Long.valueOf(index));
/* 238 */       List<StructFieldDeclaration> siblings = fieldsMap.get(key);
/* 239 */       if (siblings == null) {
/* 240 */         fieldsMap.put(key, siblings = new ArrayList<StructFieldDeclaration>());
/*     */       }
/* 242 */       siblings.add(field);
/*     */     } 
/*     */     
/* 245 */     Alignment alignment = desc.structClass.<Alignment>getAnnotation(Alignment.class);
/* 246 */     desc.structAlignment = (alignment != null) ? alignment.value() : 1L;
/*     */     
/* 248 */     List<StructFieldDescription> aggregatedFields = new ArrayList<StructFieldDescription>();
/* 249 */     for (List<StructFieldDeclaration> fieldGroup : fieldsMap.values()) {
/* 250 */       StructFieldDescription aggregatedField = StructFieldDescription.aggregateDeclarations(desc.structType, fieldGroup);
/* 251 */       if (aggregatedField != null) {
/* 252 */         aggregatedFields.add(aggregatedField);
/*     */       }
/*     */     } 
/* 255 */     desc.setAggregatedFields(aggregatedFields);
/*     */ 
/*     */     
/* 258 */     customizer.beforeLayout(desc, aggregatedFields);
/*     */     
/* 260 */     performLayout(desc, aggregatedFields);
/* 261 */     customizer.afterLayout(desc, aggregatedFields);
/*     */     
/* 263 */     List<StructFieldDescription> fieldDescs = new ArrayList<StructFieldDescription>();
/* 264 */     SolidRanges.Builder rangesBuilder = new SolidRanges.Builder();
/* 265 */     for (StructFieldDescription aggregatedField : aggregatedFields) {
/* 266 */       for (StructFieldDeclaration field : aggregatedField.aggregatedFields) {
/*     */         
/* 268 */         StructFieldDescription fieldDesc = field.desc;
/* 269 */         fieldDesc.byteOffset = aggregatedField.byteOffset;
/*     */         
/* 271 */         if (fieldDesc.byteLength < 0L || fieldDesc.byteLength > aggregatedField.byteLength)
/* 272 */           fieldDesc.byteLength = aggregatedField.byteLength; 
/* 273 */         fieldDesc.bitOffset = aggregatedField.bitOffset;
/* 274 */         fieldDesc.bitMask = aggregatedField.bitMask;
/*     */         
/* 276 */         fieldDescs.add(fieldDesc);
/* 277 */         rangesBuilder.add(fieldDesc);
/*     */         
/* 279 */         desc.hasFieldFields = (desc.hasFieldFields || fieldDesc.field != null);
/*     */       } 
/*     */     } 
/* 282 */     desc.solidRanges = rangesBuilder.toSolidRanges();
/* 283 */     desc.fields = fieldDescs.<StructFieldDescription>toArray(new StructFieldDescription[fieldDescs.size()]);
/*     */   }
/*     */   
/*     */   static void performLayout(StructDescription desc, Iterable<StructFieldDescription> aggregatedFields) {
/* 287 */     long structSize = 0L;
/* 288 */     long structAlignment = -1L;
/*     */     
/* 290 */     Struct s = desc.structClass.<Struct>getAnnotation(Struct.class);
/* 291 */     int pack = (s != null) ? s.pack() : -1;
/*     */     
/* 293 */     if (desc.isVirtual()) {
/* 294 */       structSize += Pointer.SIZE;
/* 295 */       if (Pointer.SIZE >= structAlignment) {
/* 296 */         structAlignment = Pointer.SIZE;
/*     */       }
/*     */     } 
/*     */     
/* 300 */     int cumulativeBitOffset = 0;
/*     */     
/* 302 */     for (StructFieldDescription aggregatedField : aggregatedFields) {
/* 303 */       structAlignment = Math.max(structAlignment, aggregatedField.alignment);
/*     */       
/* 305 */       if (aggregatedField.bitLength < 0L) {
/*     */         
/* 307 */         if (cumulativeBitOffset != 0) {
/* 308 */           cumulativeBitOffset = 0;
/* 309 */           structSize++;
/*     */         } 
/*     */         
/* 312 */         structSize = alignSize(structSize, (pack > 0) ? pack : aggregatedField.alignment);
/*     */       } 
/* 314 */       long fieldByteOffset = structSize;
/* 315 */       long fieldBitOffset = cumulativeBitOffset;
/*     */       
/* 317 */       if (aggregatedField.bitLength >= 0L) {
/*     */         
/* 319 */         cumulativeBitOffset = (int)(cumulativeBitOffset + aggregatedField.bitLength);
/* 320 */         structSize += (cumulativeBitOffset >>> 3);
/* 321 */         cumulativeBitOffset &= 0x7;
/*     */       } else {
/* 323 */         structSize += aggregatedField.byteLength;
/*     */       } 
/*     */       
/* 326 */       aggregatedField.byteOffset = fieldByteOffset;
/* 327 */       aggregatedField.bitOffset = fieldBitOffset;
/* 328 */       aggregatedField.computeBitMask();
/*     */     } 
/*     */     
/* 331 */     if (cumulativeBitOffset > 0) {
/* 332 */       structSize = alignSize(structSize + 1L, structAlignment);
/* 333 */     } else if (structSize > 0L) {
/* 334 */       structSize = alignSize(structSize, (pack > 0) ? pack : structAlignment);
/*     */     } 
/*     */     
/* 337 */     desc.structSize = structSize;
/* 338 */     desc.structAlignment = structAlignment;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\StructUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */