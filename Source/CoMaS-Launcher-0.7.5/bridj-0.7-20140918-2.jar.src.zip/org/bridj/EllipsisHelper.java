/*    */ package org.bridj;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.IntBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EllipsisHelper
/*    */ {
/* 40 */   static ThreadLocal<IntBuffer[]> holders = new ThreadLocal<IntBuffer[]>() {
/*    */       protected IntBuffer[] initialValue() {
/* 42 */         return new IntBuffer[1];
/*    */       }
/*    */     };
/*    */   
/*    */   public static IntBuffer unrollEllipsis(Object[] args) {
/* 47 */     IntBuffer[] holder = holders.get();
/* 48 */     int n = args.length;
/* 49 */     IntBuffer buf = holder[0];
/* 50 */     if (buf == null || buf.capacity() < n) {
/* 51 */       buf = holder[0] = ByteBuffer.allocateDirect(n * 4).asIntBuffer();
/*    */     }
/* 53 */     for (int i = 0; i < n; i++) {
/* 54 */       NativeConstants.ValueType type; Object arg = args[i];
/*    */       
/* 56 */       if (arg == null || arg instanceof Pointer) {
/* 57 */         type = NativeConstants.ValueType.ePointerValue;
/* 58 */       } else if (arg instanceof Integer) {
/* 59 */         type = NativeConstants.ValueType.eIntValue;
/* 60 */       } else if (arg instanceof Long) {
/* 61 */         type = NativeConstants.ValueType.eLongValue;
/* 62 */       } else if (arg instanceof Short) {
/* 63 */         type = NativeConstants.ValueType.eShortValue;
/* 64 */       } else if (arg instanceof Double) {
/* 65 */         type = NativeConstants.ValueType.eDoubleValue;
/* 66 */       } else if (arg instanceof Float) {
/* 67 */         type = NativeConstants.ValueType.eFloatValue;
/* 68 */       } else if (arg instanceof Byte) {
/* 69 */         type = NativeConstants.ValueType.eByteValue;
/* 70 */       } else if (arg instanceof Boolean) {
/* 71 */         type = NativeConstants.ValueType.eBooleanValue;
/* 72 */       } else if (arg instanceof Character) {
/* 73 */         type = NativeConstants.ValueType.eWCharValue;
/* 74 */       } else if (arg instanceof SizeT) {
/* 75 */         type = NativeConstants.ValueType.eSizeTValue;
/* 76 */         args[i] = arg = Long.valueOf(((SizeT)arg).longValue());
/* 77 */       } else if (arg instanceof CLong) {
/* 78 */         type = NativeConstants.ValueType.eCLongValue;
/* 79 */         args[i] = arg = Long.valueOf(((CLong)arg).longValue());
/* 80 */       } else if (arg instanceof NativeObject) {
/* 81 */         type = NativeConstants.ValueType.eNativeObjectValue;
/*    */       } else {
/* 83 */         throw new IllegalArgumentException("Argument type not handled in variable argument calls  : " + arg + " (" + arg.getClass().getName() + ")");
/*    */       } 
/*    */       
/* 86 */       buf.put(i, type.ordinal());
/*    */     } 
/* 88 */     return buf;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\EllipsisHelper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */