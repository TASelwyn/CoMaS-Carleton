/*     */ package org.bridj.jawt;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.GraphicsEnvironment;
/*     */ import java.awt.HeadlessException;
/*     */ import org.bridj.JNI;
/*     */ import org.bridj.NativeObject;
/*     */ import org.bridj.Pointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JAWTUtils
/*     */ {
/*     */   public static JawtLibrary.JNIEnv getJNIEnv() {
/*  53 */     return new JawtLibrary.JNIEnv(JNI.getEnv());
/*     */   }
/*     */   
/*     */   public static JAWT getJAWT(JawtLibrary.JNIEnv env) {
/*  57 */     if (GraphicsEnvironment.isHeadless()) {
/*  58 */       throw new HeadlessException("No native peers in headless mode.");
/*     */     }
/*     */     
/*  61 */     JAWT awt = (new JAWT()).version(65540);
/*  62 */     Pointer<JAWT> pAwt = Pointer.getPointer((NativeObject)awt);
/*  63 */     if (!JawtLibrary.JAWT_GetAWT((Pointer<JawtLibrary.JNIEnv>)env, pAwt)) {
/*  64 */       throw new RuntimeException("Failed to get JAWT pointer !");
/*     */     }
/*     */     
/*  67 */     return (JAWT)pAwt.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void withLockedSurface(JawtLibrary.JNIEnv env, JAWT awt, Component component, LockedComponentRunnable runnable) {
/*  76 */     if (component.isLightweight()) {
/*  77 */       throw new IllegalArgumentException("Lightweight components do not have native peers.");
/*     */     }
/*     */     
/*  80 */     if (!component.isDisplayable()) {
/*  81 */       throw new IllegalArgumentException("Component that are not displayable do not have native peers.");
/*     */     }
/*     */     
/*  84 */     Pointer<?> componentPointer = JNI.getGlobalPointer(component);
/*     */     
/*  86 */     Pointer<JAWT_DrawingSurface> pSurface = ((JAWT.GetDrawingSurface_callback)awt.GetDrawingSurface().get()).invoke((Pointer<JawtLibrary.JNIEnv>)env, componentPointer).as(JAWT_DrawingSurface.class);
/*  87 */     if (pSurface == null) {
/*  88 */       throw new RuntimeException("Cannot get drawing surface from " + component);
/*     */     }
/*     */     
/*  91 */     JAWT_DrawingSurface surface = (JAWT_DrawingSurface)pSurface.get();
/*     */     
/*     */     try {
/*  94 */       int lock = ((JAWT_DrawingSurface.Lock_callback)surface.Lock().get()).invoke(pSurface);
/*  95 */       if ((lock & 0x1) != 0) {
/*  96 */         throw new RuntimeException("Cannot lock drawing surface of " + component);
/*     */       }
/*     */       try {
/*  99 */         Pointer<JAWT_DrawingSurface.GetDrawingSurfaceInfo_callback> cb = surface.GetDrawingSurfaceInfo().as(JAWT_DrawingSurface.GetDrawingSurfaceInfo_callback.class);
/* 100 */         Pointer<JAWT_DrawingSurfaceInfo> pInfo = ((JAWT_DrawingSurface.GetDrawingSurfaceInfo_callback)cb.get()).invoke(pSurface);
/* 101 */         if (pInfo != null) {
/* 102 */           pInfo = pInfo.as(JAWT_DrawingSurfaceInfo.class);
/*     */         }
/* 104 */         Pointer<?> platformInfo = ((JAWT_DrawingSurfaceInfo)pInfo.get()).platformInfo();
/* 105 */         long peer = platformInfo.getSizeT();
/* 106 */         runnable.run(component, peer);
/*     */       } finally {
/* 108 */         ((JAWT_DrawingSurface.Unlock_callback)surface.Unlock().get()).invoke(pSurface);
/*     */       } 
/*     */     } finally {
/* 111 */       ((JAWT.FreeDrawingSurface_callback)awt.FreeDrawingSurface().get()).invoke(pSurface);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long getNativePeerHandle(Component component) {
/*     */     try {
/* 120 */       JawtLibrary.JNIEnv env = getJNIEnv();
/* 121 */       JAWT awt = getJAWT(env);
/* 122 */       final long[] ret = new long[1];
/* 123 */       withLockedSurface(env, awt, component, new LockedComponentRunnable() {
/*     */             public void run(Component component, long peer) {
/* 125 */               ret[0] = peer;
/*     */             }
/*     */           });
/* 128 */       return ret[0];
/* 129 */     } catch (Throwable ex) {
/* 130 */       ex.printStackTrace();
/* 131 */       return 0L;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static interface LockedComponentRunnable {
/*     */     void run(Component param1Component, long param1Long);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\jawt\JAWTUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */