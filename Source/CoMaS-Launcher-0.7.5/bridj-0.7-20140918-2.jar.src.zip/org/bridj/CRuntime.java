/*     */ package org.bridj;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.bridj.ann.Convention;
/*     */ import org.bridj.ann.JNIBound;
/*     */ import org.bridj.ann.Optional;
/*     */ import org.bridj.demangling.Demangler;
/*     */ import org.bridj.util.AnnotationUtils;
/*     */ import org.bridj.util.ConcurrentCache;
/*     */ import org.bridj.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CRuntime
/*     */   extends AbstractBridJRuntime
/*     */ {
/*  70 */   static final Set<Type> registeredTypes = new HashSet<Type>();
/*  71 */   final AtomicReference<CallbackNativeImplementer> _callbackNativeImplementer = new AtomicReference<CallbackNativeImplementer>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CallbackNativeImplementer getCallbackNativeImplementer() {
/*  81 */     CallbackNativeImplementer impl = this._callbackNativeImplementer.get();
/*  82 */     if (impl == null) {
/*  83 */       CallbackNativeImplementer newImpl = new CallbackNativeImplementer(BridJ.getOrphanEntities(), this);
/*  84 */       if (this._callbackNativeImplementer.compareAndSet(null, newImpl)) {
/*  85 */         impl = newImpl;
/*     */       } else {
/*  87 */         impl = this._callbackNativeImplementer.get();
/*     */       } 
/*     */     } 
/*  90 */     return impl;
/*     */   }
/*     */   
/*     */   public boolean isAvailable() {
/*  94 */     return true;
/*     */   }
/*     */   
/*     */   public static CRuntime getInstance() {
/*  98 */     return BridJ.<CRuntime>getRuntimeByRuntimeClass(CRuntime.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends NativeObject> Class<? extends T> getActualInstanceClass(Pointer<T> pInstance, Type officialType) {
/* 103 */     return Utils.getClass(officialType);
/*     */   }
/*     */   
/*     */   protected boolean shouldWarnIfNoFieldsInStruct() {
/* 107 */     return true;
/*     */   }
/*     */   public class CTypeInfo<T extends NativeObject> implements BridJRuntime.TypeInfo<T> { protected final Type type;
/*     */     protected final Class<T> typeClass;
/*     */     
/*     */     public CTypeInfo(Type type) {
/* 113 */       this.type = type;
/* 114 */       this.typeClass = Utils.getClass(type);
/* 115 */       this.structIO = StructIO.getInstance(this.typeClass, type);
/* 116 */       if (this.structIO != null) {
/* 117 */         this.structIO.desc.build();
/* 118 */         if (BridJ.verbose && this.structIO.desc.getAggregatedFields().isEmpty() && CRuntime.this.shouldWarnIfNoFieldsInStruct())
/*     */         {
/*     */           
/* 121 */           BridJ.info("No fields found in " + Utils.toString(type) + " (maybe they weren't declared as public ?)");
/*     */         }
/*     */       } 
/* 124 */       this.pointerIO = PointerIO.getInstance(this.structIO);
/*     */       
/* 126 */       CRuntime.this.register(this.typeClass);
/*     */     }
/*     */ 
/*     */     
/*     */     protected final StructIO structIO;
/*     */     
/*     */     protected final PointerIO<T> pointerIO;
/*     */     protected volatile Class<T> castClass;
/*     */     
/*     */     public long sizeOf() {
/* 136 */       return this.structIO.desc.getStructSize();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equal(T instance, T other) {
/* 141 */       if (this.structIO != null) {
/* 142 */         if (((StructObject)instance).io != this.structIO) {
/* 143 */           throw new IllegalArgumentException("This is not this instance's StructIO");
/*     */         }
/*     */         
/* 146 */         if (((StructObject)other).io != this.structIO) {
/* 147 */           return false;
/*     */         }
/*     */         
/* 150 */         return this.structIO.equal((StructObject)instance, (StructObject)other);
/*     */       } 
/* 152 */       return ((NativeObject)instance).peer.equals(((NativeObject)other).peer);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int compare(T instance, T other) {
/* 158 */       if (this.structIO != null) {
/* 159 */         if (((StructObject)instance).io != this.structIO) {
/* 160 */           throw new IllegalArgumentException("This is not this instance's StructIO");
/*     */         }
/*     */         
/* 163 */         if (((StructObject)other).io != this.structIO) {
/* 164 */           return 1;
/*     */         }
/*     */         
/* 167 */         return this.structIO.compare((StructObject)instance, (StructObject)other);
/*     */       } 
/* 169 */       return ((NativeObject)instance).peer.compareTo(((NativeObject)other).peer);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public BridJRuntime getRuntime() {
/* 175 */       return CRuntime.this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Type getType() {
/* 180 */       return this.type;
/*     */     }
/*     */     
/*     */     protected Class<T> getCastClass() {
/* 184 */       if (this.castClass == null) {
/* 185 */         this.castClass = CRuntime.this.getTypeForCast(this.typeClass);
/*     */       }
/* 187 */       return this.castClass;
/*     */     }
/*     */     
/*     */     protected T newCastInstance() throws NoSuchMethodException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
/* 191 */       Class<?> cc = getCastClass();
/*     */       try {
/* 193 */         return (T)cc.newInstance();
/* 194 */       } catch (IllegalAccessException ex) {
/* 195 */         Constructor<T> constructor = (Constructor)cc.getConstructor(new Class[0]);
/* 196 */         constructor.setAccessible(true);
/* 197 */         return constructor.newInstance(new Object[0]);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public T cast(Pointer peer) {
/*     */       try {
/* 204 */         T instance = newCastInstance();
/*     */         
/* 206 */         initialize(instance, peer);
/* 207 */         return instance;
/* 208 */       } catch (Exception ex) {
/* 209 */         throw new RuntimeException("Failed to cast pointer " + peer + " to instance of type " + Utils.toString(this.type), ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public T createReturnInstance() {
/*     */       try {
/* 216 */         T instance = newCastInstance();
/* 217 */         initialize(instance);
/* 218 */         return instance;
/* 219 */       } catch (Exception ex) {
/* 220 */         throw new RuntimeException("Failed to create return instance for type " + Utils.toString(this.type), ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void writeToNative(T instance) {
/* 226 */       if (instance instanceof StructObject) {
/* 227 */         this.structIO.writeFieldsToNative((StructObject)instance);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void readFromNative(T instance) {
/* 233 */       if (instance instanceof StructObject) {
/* 234 */         this.structIO.readFieldsFromNative((StructObject)instance);
/*     */       }
/*     */     }
/*     */     
/*     */     public void copyNativeObjectToAddress(T instance, Pointer<T> ptr) {
/* 239 */       if (instance instanceof StructObject)
/*     */       {
/* 241 */         ((StructObject)instance).peer.copyBytesTo(ptr, this.structIO.desc.getStructSize());
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public String describe(T instance) {
/* 247 */       if (instance instanceof StructObject) {
/* 248 */         return this.structIO.describe((StructObject)instance);
/*     */       }
/* 250 */       return instance.toString();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String describe() {
/* 256 */       if (this.structIO != null) {
/* 257 */         return this.structIO.desc.describe();
/*     */       }
/* 259 */       return Utils.toString(this.typeClass);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void initialize(T instance) {
/* 265 */       if (!BridJ.isCastingNativeObjectInCurrentThread()) {
/* 266 */         if (instance instanceof CallbackInterface) {
/* 267 */           if (!(instance instanceof DynamicFunction)) {
/* 268 */             CRuntime.this.setNativeObjectPeer((NativeObjectInterface)instance, CRuntime.this.registerCallbackInstance((CallbackInterface)instance));
/*     */           }
/*     */         } else {
/* 271 */           initialize(instance, -1, new Object[0]);
/*     */         } 
/*     */         
/* 274 */         if (instance instanceof StructObject) {
/* 275 */           this.structIO.readFieldsFromNative((StructObject)instance);
/*     */         }
/* 277 */       } else if (instance instanceof StructObject) {
/* 278 */         ((StructObject)instance).io = this.structIO;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void initialize(T instance, Pointer<? extends NativeObject> peer) {
/* 284 */       ((NativeObject)instance).peer = peer;
/* 285 */       if (instance instanceof StructObject) {
/* 286 */         ((StructObject)instance).io = this.structIO;
/* 287 */         this.structIO.readFieldsFromNative((StructObject)instance);
/*     */       } 
/*     */     }
/*     */     
/*     */     protected <V> Pointer<V> allocateStructMemory(PointerIO<V> pointerIO) {
/* 292 */       return Pointer.allocate(pointerIO);
/*     */     }
/*     */ 
/*     */     
/*     */     public void initialize(T instance, int constructorId, Object... args) {
/* 297 */       StructObject s = (StructObject)instance;
/* 298 */       if (constructorId < 0) {
/* 299 */         s.io = this.structIO;
/* 300 */         if (((NativeObject)instance).peer == null) {
/* 301 */           ((NativeObject)instance).peer = allocateStructMemory(this.pointerIO);
/*     */         }
/*     */       } else {
/* 304 */         throw new UnsupportedOperationException("TODO implement structs constructors !");
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public T clone(T instance) throws CloneNotSupportedException {
/* 310 */       if (instance == null) {
/* 311 */         return null;
/*     */       }
/*     */       
/*     */       try {
/* 315 */         NativeObject nativeObject = (NativeObject)this.typeClass.newInstance();
/* 316 */         Pointer<T> p = (Pointer)allocateStructMemory(this.pointerIO);
/* 317 */         Pointer.<T>getPointer(instance).copyTo(p);
/* 318 */         initialize((T)nativeObject, p);
/* 319 */         return (T)nativeObject;
/* 320 */       } catch (Exception ex) {
/* 321 */         throw new RuntimeException("Failed to clone instance of type " + getType());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void destroy(T instance) {
/* 327 */       if (instance instanceof CallbackInterface) {
/*     */         return;
/*     */       }
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends NativeObject> BridJRuntime.TypeInfo<T> getTypeInfo(Type type) {
/* 336 */     return new CTypeInfo<T>(type);
/*     */   }
/*     */   
/*     */   public Type getType(Class<?> cls, Object[] targs, int[] typeParamCount) {
/* 340 */     return cls;
/*     */   }
/*     */ 
/*     */   
/*     */   public void register(Type type) {
/* 345 */     register(type, null, null);
/*     */   }
/*     */   
/*     */   public static class MethodCallInfoBuilder
/*     */   {
/*     */     public MethodCallInfo apply(Method method) throws FileNotFoundException {
/* 351 */       return new MethodCallInfo(method);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void unregister(Type type) {
/* 357 */     Class typeClass = Utils.getClass(type);
/* 358 */     registeredTypes.remove(typeClass);
/*     */   }
/*     */   
/*     */   synchronized void register(Type type, NativeLibrary forcedLibrary, MethodCallInfoBuilder methodCallInfoBuilder) {
/* 362 */     Class<?> typeClass = Utils.getClass(type);
/* 363 */     if (!BridJ.getRuntimeClass(typeClass).isInstance(this)) {
/* 364 */       BridJ.register(typeClass);
/*     */       return;
/*     */     } 
/* 367 */     synchronized (registeredTypes) {
/* 368 */       if (!registeredTypes.add(typeClass)) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */     
/* 373 */     if (methodCallInfoBuilder == null) {
/* 374 */       methodCallInfoBuilder = new MethodCallInfoBuilder();
/*     */     }
/*     */     
/* 377 */     if (BridJ.verbose) {
/* 378 */       BridJ.info("Registering type " + Utils.toString(type));
/*     */     }
/*     */     
/* 381 */     int typeModifiers = typeClass.getModifiers();
/*     */     
/* 383 */     NativeLibrary typeLibrary = null;
/*     */     try {
/* 385 */       typeLibrary = (forcedLibrary == null) ? getNativeLibrary(typeClass) : forcedLibrary;
/* 386 */     } catch (Throwable th) {}
/*     */ 
/*     */     
/* 389 */     ConcurrentCache<NativeEntities, NativeEntities.Builder> builders = new ConcurrentCache(NativeEntities.Builder.class);
/*     */     try {
/* 391 */       Set<Method> handledMethods = new HashSet<Method>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 420 */       if (CallbackInterface.class.isAssignableFrom(typeClass)) {
/* 421 */         if (this.rootCallbackClasses.contains(type)) {
/*     */           return;
/*     */         }
/*     */         
/* 425 */         if (Modifier.isAbstract(typeModifiers)) {
/* 426 */           getCallbackNativeImplementer().getCallbackImplType((Class<CallbackInterface>)type, forcedLibrary);
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 432 */       List<Method> nativeMethods = new ArrayList<Method>();
/* 433 */       for (Method method : typeClass.getDeclaredMethods()) {
/* 434 */         int modifiers = method.getModifiers();
/* 435 */         if (Modifier.isNative(modifiers) && 
/* 436 */           !AnnotationUtils.isAnnotationPresent(JNIBound.class, method, new java.lang.annotation.Annotation[0])) {
/* 437 */           nativeMethods.add(method);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 442 */       if (!nativeMethods.isEmpty()) {
/*     */         try {
/* 444 */           for (Method method : nativeMethods) {
/* 445 */             if (!handledMethods.add(method)) {
/*     */               continue;
/*     */             }
/*     */             
/*     */             try {
/* 450 */               NativeLibrary methodLibrary = (forcedLibrary == null) ? BridJ.getNativeLibrary(method) : forcedLibrary;
/* 451 */               NativeEntities nativeEntities = (methodLibrary == null) ? BridJ.getOrphanEntities() : methodLibrary.getNativeEntities();
/* 452 */               NativeEntities.Builder builder = (NativeEntities.Builder)builders.get(nativeEntities);
/*     */               
/* 454 */               registerNativeMethod(typeClass, typeLibrary, method, methodLibrary, builder, methodCallInfoBuilder);
/* 455 */             } catch (Exception ex) {
/* 456 */               if (BridJ.verbose) {
/* 457 */                 BridJ.error("Method " + method.toGenericString() + " cannot be mapped : " + ex, ex);
/*     */               }
/*     */             } 
/*     */           } 
/* 461 */         } catch (Exception ex) {
/* 462 */           throw new RuntimeException("Failed to register class " + Utils.toString(type), ex);
/*     */         } 
/*     */       }
/*     */     } finally {
/*     */       
/* 467 */       for (Map.Entry<NativeEntities, NativeEntities.Builder> e : (Iterable<Map.Entry<NativeEntities, NativeEntities.Builder>>)builders.entrySet()) {
/* 468 */         ((NativeEntities)e.getKey()).addDefinitions(typeClass, e.getValue());
/*     */       }
/* 470 */       registerFamily(type, forcedLibrary, methodCallInfoBuilder);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void registerFamily(Type type, NativeLibrary forcedLibrary, MethodCallInfoBuilder methodCallInfoBuilder) {
/* 475 */     Class<Object> typeClass = Utils.getClass(type);
/*     */     
/* 477 */     for (Class<?> child : typeClass.getClasses()) {
/* 478 */       register(child, forcedLibrary, methodCallInfoBuilder);
/*     */     }
/*     */     
/* 481 */     typeClass = typeClass.getSuperclass();
/* 482 */     if (typeClass != null && typeClass != Object.class) {
/* 483 */       register(typeClass, forcedLibrary, methodCallInfoBuilder);
/*     */     }
/*     */   }
/*     */   
/*     */   protected NativeLibrary getNativeLibrary(Class<?> type) throws IOException {
/* 488 */     return BridJ.getNativeLibrary(type);
/*     */   }
/*     */   
/*     */   protected boolean isSymbolOptional(Method method) {
/* 492 */     return (AnnotationUtils.getInheritableAnnotation(Optional.class, method, new java.lang.annotation.Annotation[0]) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerNativeMethod(Class<?> type, NativeLibrary typeLibrary, Method method, NativeLibrary methodLibrary, NativeEntities.Builder builder, MethodCallInfoBuilder methodCallInfoBuilder) throws FileNotFoundException {
/*     */     MethodCallInfo mci;
/*     */     try {
/* 504 */       mci = methodCallInfoBuilder.apply(method);
/* 505 */       if (mci == null) {
/*     */         return;
/*     */       }
/*     */     }
/* 509 */     catch (Throwable th) {
/* 510 */       BridJ.error("Unable to register " + method + " : " + th);
/* 511 */       th.printStackTrace();
/*     */       return;
/*     */     } 
/* 514 */     if (CallbackInterface.class.isAssignableFrom(type)) {
/* 515 */       if (BridJ.debug) {
/* 516 */         BridJ.info("Registering java -> native callback : " + method);
/*     */       }
/* 518 */       builder.addJavaToNativeCallback(mci);
/*     */     } else {
/* 520 */       Demangler.Symbol symbol = (methodLibrary == null) ? null : methodLibrary.getSymbol(method);
/* 521 */       if (symbol == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 529 */         if (!isSymbolOptional(method)) {
/* 530 */           BridJ.error("Failed to get address of method " + method);
/*     */         }
/*     */         
/*     */         return;
/*     */       } 
/* 535 */       mci.setForwardedPointer(symbol.getAddress());
/* 536 */       if (!mci.hasCallingConvention()) {
/* 537 */         Convention.Style cc = symbol.getInferredCallingConvention();
/* 538 */         if (cc != null) {
/* 539 */           mci.setCallingConvention(cc);
/*     */         }
/*     */       } 
/* 542 */       builder.addFunction(mci);
/* 543 */       if (BridJ.debug) {
/* 544 */         BridJ.info("Registering " + method + " as C function " + symbol.getName() + " (address = 0x" + Long.toHexString(symbol.getAddress()) + ")");
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public <T extends NativeObject> Pointer<T> allocate(Class<T> type, int constructorId, Object... args) {
/* 550 */     if (CallbackInterface.class.isAssignableFrom(type)) {
/* 551 */       if (constructorId != -1 || args.length != 0) {
/* 552 */         throw new RuntimeException("Callback should have a constructorId == -1 and no constructor args !");
/*     */       }
/* 554 */       return null;
/*     */     } 
/* 556 */     throw new RuntimeException("Cannot allocate instance of type " + type.getName() + " (unhandled NativeObject subclass)");
/*     */   }
/* 558 */   static final int defaultObjectSize = Platform.is64Bits() ? 8 : 4; public static final String PROPERTY_bridj_c_defaultObjectSize = "bridj.c.defaultObjectSize";
/*     */   protected Set<Class> rootCallbackClasses;
/*     */   
/*     */   public int getDefaultStructSize() {
/* 562 */     String s = System.getProperty("bridj.c.defaultObjectSize");
/* 563 */     if (s != null) {
/*     */       try {
/* 565 */         return Integer.parseInt(s);
/* 566 */       } catch (Throwable th) {
/* 567 */         BridJ.error("Invalid value for property bridj.c.defaultObjectSize : '" + s + "'");
/*     */       } 
/*     */     }
/* 570 */     return defaultObjectSize;
/*     */   }
/*     */   
/*     */   public long sizeOf(Type structType, StructIO io) {
/* 574 */     if (io == null) {
/* 575 */       io = StructIO.getInstance(Utils.getClass(structType), structType);
/*     */     }
/*     */     long size;
/* 578 */     if (io == null || (size = io.desc.getStructSize()) <= 0L) {
/* 579 */       return getDefaultStructSize();
/*     */     }
/* 581 */     return size; } @Deprecated
/*     */   public CRuntime() {
/* 583 */     this.rootCallbackClasses = (Set)new HashSet<Class<?>>(Arrays.asList(new Class[] { Callback.class, DynamicFunction.class }));
/*     */   }
/*     */   public Method getUniqueCallbackMethod(Class<?> type) {
/* 586 */     return getCallbackMethod(type, true);
/*     */   }
/*     */   public Method getFastestCallbackMethod(Class<?> type) {
/* 589 */     return getCallbackMethod(type, false);
/*     */   }
/*     */   
/*     */   private Method getSingleAbstractMethodMethod(Class type) {
/* 593 */     assert Modifier.isAbstract(type.getModifiers());
/* 594 */     Method method = null;
/* 595 */     Method[] declaredMethods = type.getDeclaredMethods();
/* 596 */     for (Method dm : declaredMethods) {
/* 597 */       int modifiers = dm.getModifiers();
/* 598 */       if (Modifier.isAbstract(modifiers))
/*     */       {
/*     */ 
/*     */         
/* 602 */         if (method == null) {
/* 603 */           method = dm;
/*     */         } else {
/* 605 */           throw new RuntimeException("Callback " + type.getName() + " has more than one abstract method (" + dm + " and " + method + ")");
/*     */         } 
/*     */       }
/*     */     } 
/* 609 */     return method;
/*     */   }
/*     */   
/*     */   private boolean sameBindings(Method m1, Method m2) {
/* 613 */     Class<?>[] params1 = m1.getParameterTypes(), params2 = m2.getParameterTypes();
/* 614 */     Class<?> r1 = m1.getReturnType(), r2 = m2.getReturnType();
/* 615 */     if (!sameBindings(r1, r2) || params1.length != params2.length) {
/* 616 */       return false;
/*     */     }
/* 618 */     for (int i = 0; i < params1.length; i++) {
/* 619 */       Class<?> p1 = params1[i], p2 = params2[i];
/* 620 */       if (!sameBindings(p1, p2)) {
/* 621 */         return false;
/*     */       }
/*     */     } 
/* 624 */     return true;
/*     */   }
/*     */   
/*     */   private static int getSignatureObjectCount(Class t) {
/* 628 */     return t.isPrimitive() ? 0 : 1;
/*     */   }
/*     */   private int getSignatureObjectCount(Method m) {
/* 631 */     int count = getSignatureObjectCount(m.getReturnType());
/* 632 */     for (Class<?> param : m.getParameterTypes()) {
/* 633 */       count += getSignatureObjectCount(param);
/*     */     }
/* 635 */     return count;
/*     */   }
/*     */   
/*     */   public List<Method> getApplyMethods(Class type) {
/* 639 */     List<Method> ret = new ArrayList<Method>();
/* 640 */     for (Method method : type.getDeclaredMethods()) {
/* 641 */       if (method.getName().equals("apply")) {
/* 642 */         ret.add(method);
/*     */       }
/*     */     } 
/* 645 */     return ret;
/*     */   }
/*     */   
/*     */   public Class<?> getAbstractCallback(Class<?> type) {
/* 649 */     Class<?> parent = null;
/* 650 */     while ((parent = type.getSuperclass()) != null && !this.rootCallbackClasses.contains(parent)) {
/* 651 */       type = parent;
/*     */     }
/* 653 */     if (!Modifier.isAbstract(type.getModifiers())) {
/* 654 */       throw new RuntimeException("Callback definition " + type.getName() + " must be abstract.");
/*     */     }
/* 656 */     return type;
/*     */   }
/*     */   
/*     */   public Method getCallbackMethod(Class<?> type, boolean expectUniqueMethod) {
/* 660 */     Class<?> abstractCallback = getAbstractCallback(type);
/* 661 */     Method singleAbstractMethod = getSingleAbstractMethodMethod(abstractCallback);
/* 662 */     if (singleAbstractMethod != null) {
/* 663 */       return singleAbstractMethod;
/*     */     }
/*     */     
/* 666 */     List<Method> applyList = getApplyMethods(type);
/* 667 */     if (applyList.isEmpty()) {
/* 668 */       throw new RuntimeException("Type doesn't have any abstract method nor any 'apply' method: " + abstractCallback.getName());
/*     */     }
/*     */     
/* 671 */     Method m0 = applyList.get(0);
/* 672 */     for (int i = 1, n = applyList.size(); i < n; i++) {
/* 673 */       Method mi = applyList.get(i);
/* 674 */       if (!sameBindings(m0, mi)) {
/* 675 */         throw new RuntimeException("Callback apply methods don't match: " + m0 + " vs. " + mi);
/*     */       }
/*     */     } 
/*     */     
/* 679 */     boolean overridesOnlyOneMethod = (applyList.size() == 1);
/* 680 */     if (expectUniqueMethod && 
/* 681 */       !overridesOnlyOneMethod) {
/* 682 */       throw new RuntimeException("Expected only one overridden apply method in " + type.getName() + ", but got " + applyList);
/*     */     }
/*     */     
/* 685 */     if (overridesOnlyOneMethod) {
/* 686 */       return applyList.get(0);
/*     */     }
/* 688 */     int bestCount = Integer.MAX_VALUE;
/* 689 */     Method best = null;
/* 690 */     for (Method m : applyList) {
/* 691 */       int count = getSignatureObjectCount(m);
/* 692 */       if (count < bestCount) {
/* 693 */         bestCount = count;
/* 694 */         best = m;
/*     */       } 
/*     */     } 
/* 697 */     return best;
/*     */   }
/*     */   
/*     */   private static boolean sameBindings(Class<long> t1, Class<?> t2) {
/* 701 */     return (t1.equals(t2) || (t1 == long.class && Pointer.class.isAssignableFrom(t2)) || (t2 == long.class && Pointer.class.isAssignableFrom(t1)) || (t1 == int.class && IntValuedEnum.class.isAssignableFrom(t2)) || (t2 == int.class && IntValuedEnum.class.isAssignableFrom(t1)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends NativeObject> Class<? extends T> getTypeForCast(Type type) {
/* 709 */     Class<?> typeClass = Utils.getClass(type);
/* 710 */     if (CallbackInterface.class.isAssignableFrom(typeClass)) {
/* 711 */       return (Class)getCallbackNativeImplementer().getCallbackImplType(typeClass, null);
/*     */     }
/* 713 */     return (Class)typeClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DynamicFunctionFactory getDynamicFunctionFactory(NativeLibrary library, Convention.Style callingConvention, Type returnType, Type... parameterTypes) {
/* 732 */     return getCallbackNativeImplementer().getDynamicCallback(library, callingConvention, returnType, parameterTypes);
/*     */   }
/*     */   
/*     */   public static <T> Pointer<T> createCToJavaCallback(MethodCallInfo mci, Type t) {
/* 736 */     mci.prependCallbackCC();
/* 737 */     final long handle = JNI.createCToJavaCallback(mci);
/* 738 */     long peer = JNI.getActualCToJavaCallback(handle);
/*     */     
/* 740 */     Throwable stackTrace = BridJ.debugPointers ? (new RuntimeException()).fillInStackTrace() : null;
/*     */ 
/*     */     
/* 743 */     return Pointer.pointerToAddress(peer, t, new Pointer.Releaser()
/*     */         {
/*     */           public void release(Pointer<?> p) {
/* 746 */             if (BridJ.debugPointers) {
/* 747 */               BridJ.info("Freeing callback pointer " + p + "\n(Creation trace = \n\t" + Utils.toString(p.creationTrace).replaceAll("\n", "\n\t") + "\n)", (new RuntimeException()).fillInStackTrace());
/*     */             }
/*     */             
/* 750 */             if (BridJ.debugNeverFree) {
/*     */               return;
/*     */             }
/*     */             
/* 754 */             JNI.freeCToJavaCallback(handle);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   protected <T extends CallbackInterface> Pointer<T> registerCallbackInstance(T instance) {
/*     */     try {
/* 761 */       Class<?> c = instance.getClass();
/* 762 */       MethodCallInfo mci = new MethodCallInfo(getFastestCallbackMethod(c));
/* 763 */       mci.setDeclaringClass(c);
/* 764 */       mci.setJavaCallback(instance);
/* 765 */       return createCToJavaCallback(mci, c);
/* 766 */     } catch (Exception e) {
/* 767 */       throw new RuntimeException("Failed to register callback instance of type " + instance.getClass().getName(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void setNativeObjectPeer(NativeObjectInterface instance, Pointer<? extends NativeObjectInterface> peer) {
/* 772 */     ((NativeObject)instance).peer = (Pointer)peer;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\CRuntime.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */