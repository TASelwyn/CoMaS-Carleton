/*     */ package org.bridj;
/*     */ 
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.bridj.ann.Field;
/*     */ import org.bridj.ann.Struct;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TimeT
/*     */   extends AbstractIntegral
/*     */ {
/*  45 */   public static final int SIZE = Platform.TIME_T_SIZE;
/*     */   
/*     */   static {
/*  48 */     BridJ.register();
/*     */   }
/*     */   
/*     */   public TimeT(long value) {
/*  52 */     super(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int byteSize() {
/*  57 */     return SIZE;
/*     */   }
/*     */   
/*     */   public Date toDate() {
/*  61 */     return new Date(this.value);
/*     */   }
/*     */   
/*     */   public static TimeT valueOf(long value) {
/*  65 */     return new TimeT(value);
/*     */   }
/*     */   
/*     */   public static TimeT valueOf(Date value) {
/*  69 */     return valueOf(value.getTime());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  74 */     return "TimeT(value = " + this.value + ", time = " + toDate() + ")";
/*     */   }
/*     */   
/*     */   @Struct(customizer = timeval_customizer.class)
/*     */   public static class timeval
/*     */     extends StructObject {
/*     */     public long getTime() {
/*  81 */       return seconds() * 1000L + milliseconds();
/*     */     }
/*     */     
/*     */     @Field(0)
/*     */     public long seconds() {
/*  86 */       return this.io.getCLongField(this, 0);
/*     */     }
/*     */     
/*     */     @Field(0)
/*     */     public timeval seconds(long seconds) {
/*  91 */       this.io.setCLongField(this, 0, seconds);
/*  92 */       return this;
/*     */     }
/*     */     
/*     */     public final long seconds_$eq(long seconds) {
/*  96 */       seconds(seconds);
/*  97 */       return seconds;
/*     */     }
/*     */     
/*     */     @Field(1)
/*     */     public int milliseconds() {
/* 102 */       return this.io.getIntField(this, 1);
/*     */     }
/*     */     
/*     */     @Field(1)
/*     */     public timeval milliseconds(int milliseconds) {
/* 107 */       this.io.setIntField(this, 1, milliseconds);
/* 108 */       return this;
/*     */     }
/*     */     
/*     */     public final int milliseconds_$eq(int milliseconds) {
/* 112 */       milliseconds(milliseconds);
/* 113 */       return milliseconds;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class timeval_customizer
/*     */     extends StructCustomizer
/*     */   {
/*     */     public void beforeLayout(StructDescription desc, List<StructFieldDescription> aggregatedFields) {
/* 121 */       StructFieldDescription secondsField = aggregatedFields.get(0);
/* 122 */       if (Platform.isWindows() || !Platform.is64Bits()) {
/* 123 */         secondsField.byteLength = 4L;
/*     */       } else {
/* 125 */         secondsField.byteLength = 8L;
/*     */       } 
/*     */       
/* 128 */       secondsField.alignment = secondsField.byteLength;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\TimeT.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */