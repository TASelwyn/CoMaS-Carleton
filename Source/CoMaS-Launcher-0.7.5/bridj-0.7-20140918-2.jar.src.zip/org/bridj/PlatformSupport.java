/*    */ package org.bridj;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.bridj.util.ClassDefiner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PlatformSupport
/*    */ {
/*    */   private static final PlatformSupport instance;
/*    */   
/*    */   public ClassDefiner getClassDefiner(ClassDefiner defaultDefiner, ClassLoader parentClassLoader) {
/* 42 */     return defaultDefiner;
/*    */   }
/*    */ 
/*    */   
/*    */   static {
/* 47 */     PlatformSupport _instance = null;
/* 48 */     if (Platform.isAndroid()) {
/*    */       try {
/* 50 */         _instance = (PlatformSupport)Class.forName("org.bridj.AndroidSupport").newInstance();
/* 51 */       } catch (Exception ex) {
/* 52 */         throw new RuntimeException("Failed to instantiate the Android support class... Was the BridJ jar tampered with / trimmed too much ?", ex);
/*    */       } 
/*    */     }
/*    */     
/* 56 */     if (_instance == null) {
/* 57 */       _instance = new PlatformSupport();
/*    */     }
/*    */     
/* 60 */     instance = _instance;
/*    */   }
/*    */   
/*    */   public static PlatformSupport getInstance() {
/* 64 */     return instance;
/*    */   }
/*    */   
/*    */   public NativeLibrary loadNativeLibrary(String name) throws IOException {
/* 68 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\PlatformSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */