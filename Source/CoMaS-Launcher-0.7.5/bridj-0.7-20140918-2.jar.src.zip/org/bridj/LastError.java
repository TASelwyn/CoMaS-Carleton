/*     */ package org.bridj;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LastError
/*     */   extends NativeError
/*     */ {
/*     */   final int code;
/*     */   final int kind;
/*     */   String description;
/*     */   static final int eLastErrorKindWindows = 1;
/*     */   static final int eLastErrorKindCLibrary = 2;
/*     */   
/*     */   LastError(int code, int kind) {
/*  75 */     super((String)null);
/*  76 */     this.code = code;
/*  77 */     this.kind = kind;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  85 */     return Integer.valueOf(this.code).hashCode() ^ Integer.valueOf(this.kind).hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/*  89 */     if (!(o instanceof LastError)) {
/*  90 */       return false;
/*     */     }
/*  92 */     LastError e = (LastError)o;
/*  93 */     return (this.code == e.code && this.kind == e.kind);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCode() {
/* 102 */     return this.code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 112 */     if (this.description == null) {
/* 113 */       this.description = getDescription(this.code, this.kind);
/*     */     }
/* 115 */     return this.description;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessage() {
/* 120 */     String description = getDescription();
/* 121 */     return ((description == null) ? "?" : description.trim()) + " (error code = " + this.code + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 126 */   private static final ThreadLocal<LastError> lastError = new ThreadLocal<LastError>();
/*     */   
/*     */   public static LastError getLastError() {
/* 129 */     return lastError.get();
/*     */   }
/*     */   private static native String getDescription(int paramInt1, int paramInt2);
/*     */   static LastError setLastError(int code, int kind) {
/* 133 */     if (code == 0) {
/* 134 */       lastError.set(null);
/* 135 */       return null;
/*     */     } 
/* 137 */     LastError err = new LastError(code, kind);
/* 138 */     err.fillInStackTrace();
/* 139 */     lastError.set(err);
/* 140 */     return err;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\LastError.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */