package org.bridj;

abstract class PointerLRUCache {
  private final Pointer<?>[] values;
  
  private int index;
  
  private final int tolerance;
  
  PointerLRUCache(int length, int tolerance) {
    assert tolerance >= 0;
    this.tolerance = tolerance;
    this.values = (Pointer<?>[])new Pointer[length];
  }
  
  protected abstract <T> Pointer<T> pointerToAddress(long paramLong, PointerIO<T> paramPointerIO);
  
  Pointer<?> get(long peer, PointerIO<?> pointerIO) {
    int idx = this.index;
    for (int i = 0, length = this.values.length; i < length; i++) {
      Pointer<?> pointer = this.values[idx];
      if (pointer == null) {
        this.values[idx] = pointer = pointerToAddress(peer, pointerIO);
        return pointer;
      } 
      if (pointer.getPeer() == peer && pointer.getIO() == pointerIO) {
        if (i > this.tolerance) {
          int idx2 = decrementedIndex();
          if (idx != idx2) {
            Pointer<?> temp = this.values[idx];
            this.values[idx] = this.values[idx2];
            this.values[idx2] = temp;
          } 
        } 
        return pointer;
      } 
      idx++;
      if (idx == length)
        idx = 0; 
    } 
    Pointer<?> ptr = pointerToAddress(peer, pointerIO);
    this.values[decrementedIndex()] = ptr;
    return ptr;
  }
  
  private int decrementedIndex() {
    int i = this.index;
    i--;
    if (i < 0)
      i = this.values.length - 1; 
    this.index = i;
    return i;
  }
}
