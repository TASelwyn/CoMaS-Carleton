/*     */ package org.bridj;
/*     */ 
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.List;
/*     */ import org.bridj.dyncall.DyncallLibrary;
/*     */ import org.bridj.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DyncallStructs
/*     */ {
/*     */   Pointer<DyncallLibrary.DCstruct> struct;
/*     */   
/*     */   static int toDCAlignment(long structIOAlignment) {
/*  45 */     return (structIOAlignment <= 0L) ? 0 : (int)structIOAlignment;
/*     */   }
/*     */   
/*     */   public static Pointer<DyncallLibrary.DCstruct> buildDCstruct(StructDescription desc) {
/*  49 */     if (!BridJ.Switch.StructsByValue.enabled) {
/*  50 */       return null;
/*     */     }
/*     */     
/*  53 */     List<StructFieldDescription> aggregatedFields = desc.getAggregatedFields();
/*  54 */     Pointer<DyncallLibrary.DCstruct> struct = DyncallLibrary.dcNewStruct(aggregatedFields.size(), toDCAlignment(desc.getStructAlignment())).withReleaser(new Pointer.Releaser() {
/*     */           public void release(Pointer<?> p) {
/*  56 */             DyncallLibrary.dcFreeStruct(p.as(DyncallLibrary.DCstruct.class));
/*     */           }
/*     */         });
/*  59 */     fillDCstruct(desc.structType, struct, aggregatedFields);
/*  60 */     DyncallLibrary.dcCloseStruct(struct);
/*     */     
/*  62 */     long expectedSize = desc.getStructSize();
/*  63 */     long size = DyncallLibrary.dcStructSize(struct);
/*     */     
/*  65 */     if (expectedSize != size) {
/*  66 */       BridJ.error("Struct size computed for " + Utils.toString(desc.structType) + " by BridJ (" + expectedSize + " bytes) and dyncall (" + size + " bytes) differ !");
/*  67 */       return null;
/*     */     } 
/*  69 */     return struct;
/*     */   }
/*     */   
/*     */   protected static void fillDCstruct(Type structType, Pointer<DyncallLibrary.DCstruct> struct, List<StructFieldDescription> aggregatedFields) {
/*  73 */     for (StructFieldDescription aggregatedField : aggregatedFields) {
/*  74 */       int dctype; StructFieldDeclaration field = aggregatedField.aggregatedFields.get(0);
/*  75 */       Type fieldType = field.desc.nativeTypeOrPointerTargetType;
/*  76 */       if (fieldType == null) {
/*  77 */         fieldType = field.desc.valueType;
/*     */       }
/*  79 */       Class<?> fieldClass = Utils.getClass(fieldType);
/*     */       
/*  81 */       int alignment = toDCAlignment(aggregatedField.alignment);
/*  82 */       long arrayLength = field.desc.arrayLength;
/*     */       
/*  84 */       if (StructObject.class.isAssignableFrom(fieldClass)) {
/*  85 */         StructIO subIO = StructIO.getInstance(fieldClass, fieldType);
/*  86 */         List<StructFieldDescription> subAggregatedFields = subIO.desc.getAggregatedFields();
/*     */         
/*  88 */         DyncallLibrary.dcSubStruct(struct, subAggregatedFields.size(), alignment, arrayLength);
/*     */         try {
/*  90 */           fillDCstruct(subIO.desc.structType, struct, subAggregatedFields);
/*     */         } finally {
/*  92 */           DyncallLibrary.dcCloseStruct(struct);
/*     */         } 
/*     */         continue;
/*     */       } 
/*  96 */       if (fieldClass == int.class) {
/*  97 */         dctype = 105;
/*  98 */       } else if (fieldClass == long.class || fieldClass == Long.class) {
/*     */         
/* 100 */         dctype = 108;
/* 101 */       } else if (fieldClass == short.class || fieldClass == char.class || fieldClass == Short.class || fieldClass == Character.class) {
/* 102 */         dctype = 115;
/* 103 */       } else if (fieldClass == byte.class || fieldClass == boolean.class || fieldClass == Byte.class || fieldClass == Boolean.class) {
/* 104 */         dctype = 99;
/* 105 */       } else if (fieldClass == float.class || fieldClass == Float.class) {
/* 106 */         dctype = 102;
/* 107 */       } else if (fieldClass == double.class || fieldClass == Double.class) {
/* 108 */         dctype = 100;
/* 109 */       } else if (Pointer.class.isAssignableFrom(fieldClass)) {
/* 110 */         dctype = 112;
/*     */       } else {
/* 112 */         throw new IllegalArgumentException("Unable to create dyncall struct field for type " + Utils.toString(fieldType) + " in struct " + Utils.toString(structType));
/*     */       } 
/*     */       
/* 115 */       DyncallLibrary.dcStructField(struct, dctype, alignment, arrayLength);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\DyncallStructs.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */