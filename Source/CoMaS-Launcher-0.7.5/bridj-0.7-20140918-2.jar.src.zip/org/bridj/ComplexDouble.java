/*    */ package org.bridj;
/*    */ 
/*    */ import org.bridj.ann.Field;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ComplexDouble
/*    */   extends StructObject
/*    */ {
/*    */   @Field(0)
/*    */   public double real() {
/* 39 */     return this.io.getDoubleField(this, 0);
/*    */   }
/*    */   
/*    */   @Field(0)
/*    */   public ComplexDouble real(double real) {
/* 44 */     this.io.setDoubleField(this, 0, real);
/* 45 */     return this;
/*    */   }
/*    */   
/*    */   @Field(1)
/*    */   public double imag() {
/* 50 */     return this.io.getDoubleField(this, 0);
/*    */   }
/*    */   
/*    */   @Field(1)
/*    */   public ComplexDouble imag(double imag) {
/* 55 */     this.io.setDoubleField(this, 0, imag);
/* 56 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\ComplexDouble.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */