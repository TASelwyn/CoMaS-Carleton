package org.bridj;

class NativeConstants {
  enum ValueType {
    eVoidValue, eWCharValue, eCLongValue, eCLongObjectValue, eSizeTValue, eSizeTObjectValue, eIntValue, eShortValue, eByteValue, eBooleanValue, eLongValue, eDoubleValue, eFloatValue, ePointerValue, eEllipsis, eIntFlagSet, eNativeObjectValue, eTimeTObjectValue;
  }
  
  enum CallbackType {
    eJavaCallbackToNativeFunction, eNativeToJavaCallback, eJavaToNativeFunction, eJavaToVirtualMethod;
  }
}
