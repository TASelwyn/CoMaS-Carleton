/*     */ package org.bridj;
/*     */ 
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.bridj.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StructIO
/*     */ {
/*  72 */   static Map<Type, StructIO> structIOs = new HashMap<Type, StructIO>(); protected PointerIO<?> pointerIO; public final StructDescription desc;
/*     */   
/*     */   public static StructIO getInstance(Type structType) {
/*  75 */     return getInstance(Utils.getClass(structType), structType);
/*     */   }
/*     */   public static StructIO getInstance(Class<?> structClass, Type structType) {
/*  78 */     synchronized (structIOs) {
/*  79 */       StructIO io = structIOs.get((structType == null) ? structClass : structType);
/*  80 */       if (io == null) {
/*  81 */         io = new StructIO(structClass, structType);
/*  82 */         if (io != null)
/*  83 */           registerStructIO(structClass, structType, io); 
/*     */       } 
/*  85 */       return io;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static synchronized StructIO registerStructIO(Class structClass, Type structType, StructIO io) {
/*  90 */     structIOs.put(structType, io);
/*  91 */     return io;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StructIO(Class<?> structClass, Type structType) {
/*  98 */     this.desc = new StructDescription(structClass, structType, StructCustomizer.getInstance(structClass));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 104 */     return "StructIO(" + this.desc + ")";
/*     */   }
/*     */   
/*     */   public boolean equal(StructObject a, StructObject b) {
/* 108 */     return (compare(a, b) == 0);
/*     */   }
/*     */   public int compare(StructObject a, StructObject b) {
/* 111 */     return StructUtils.compare(a, b, this.desc.getSolidRanges());
/*     */   }
/*     */   
/*     */   public final String describe(StructObject struct) {
/* 115 */     return this.desc.describe(struct);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void writeFieldsToNative(StructObject struct) {
/* 123 */     this.desc.build();
/* 124 */     if (!this.desc.hasFieldFields)
/*     */       return; 
/*     */     try {
/* 127 */       for (StructFieldDescription fd : this.desc.fields) {
/* 128 */         if (fd.field != null)
/*     */         {
/*     */           
/* 131 */           if (!fd.isArray)
/*     */           
/*     */           { 
/* 134 */             Object value = fd.field.get(struct);
/* 135 */             if (value instanceof NativeObject)
/* 136 */             { if (value != null) {
/* 137 */                 BridJ.writeToNative((NativeObject)value);
/*     */               } }
/*     */             else
/* 140 */             { Pointer<? extends NativeObject> ptr = struct.peer.offset(fd.byteOffset);
/* 141 */               Type tpe = (fd.isNativeObject || fd.isArray) ? fd.nativeTypeOrPointerTargetType : fd.field.getGenericType();
/* 142 */               ptr = ptr.as(tpe);
/* 143 */               ptr = StructUtils.fixIntegralTypeIOToMatchLength(ptr, fd.byteLength, fd.arrayLength);
/*     */               
/* 145 */               if ((fd.isCLong && CLong.SIZE == 4) || (fd.isSizeT && SizeT.SIZE == 4)) {
/* 146 */                 value = Integer.valueOf((int)((Long)value).longValue());
/*     */               }
/* 148 */               ptr.set(value); }  }  } 
/*     */       } 
/* 150 */     } catch (Throwable th) {
/* 151 */       throw new RuntimeException("Unexpected error while writing fields from struct " + Utils.toString(this.desc.structType) + " (" + Pointer.getPointer(struct) + ")", th);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void readFieldsFromNative(StructObject struct) {
/* 160 */     this.desc.build();
/* 161 */     if (!this.desc.hasFieldFields)
/*     */       return; 
/*     */     try {
/* 164 */       for (StructFieldDescription fd : this.desc.fields) {
/* 165 */         if (fd.field != null) {
/*     */           Object value;
/*     */           
/* 168 */           Pointer<? extends NativeObject> ptr = struct.peer.offset(fd.byteOffset);
/* 169 */           Type tpe = (fd.isNativeObject || fd.isArray) ? fd.nativeTypeOrPointerTargetType : fd.field.getGenericType();
/* 170 */           ptr = ptr.as(tpe);
/* 171 */           ptr = StructUtils.fixIntegralTypeIOToMatchLength(ptr, fd.byteLength, fd.arrayLength);
/*     */           
/* 173 */           if (fd.isArray) {
/* 174 */             ptr = ptr.validElements(fd.arrayLength);
/* 175 */             value = ptr;
/*     */           } else {
/* 177 */             value = ptr.get();
/*     */           } 
/* 179 */           fd.field.set(struct, value);
/*     */           
/* 181 */           if (value instanceof NativeObject && 
/* 182 */             value != null)
/* 183 */             BridJ.readFromNative((NativeObject)value); 
/*     */         } 
/*     */       } 
/* 186 */     } catch (Throwable th) {
/* 187 */       throw new RuntimeException("Unexpected error while reading fields from struct " + Utils.toString(this.desc.structType) + " (" + Pointer.getPointer(struct) + ") : " + th, th);
/*     */     } 
/*     */   } public final <T> Pointer<T> getPointerField(StructObject struct, int fieldIndex) {
/*     */     Pointer<T> p;
/* 191 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/*     */     
/* 193 */     if (fd.isArray) {
/* 194 */       p = struct.peer.offset(fd.byteOffset).as(fd.nativeTypeOrPointerTargetType);
/* 195 */       p = p.validElements(fd.arrayLength);
/*     */     } else {
/* 197 */       p = struct.peer.getPointerAtOffset(fd.byteOffset, fd.nativeTypeOrPointerTargetType);
/*     */     } 
/* 199 */     return p;
/*     */   }
/*     */   
/*     */   public final <T> void setPointerField(StructObject struct, int fieldIndex, Pointer<T> value) {
/* 203 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/* 204 */     struct.peer.setPointerAtOffset(fd.byteOffset, value);
/*     */   }
/*     */   
/*     */   public final <T extends TypedPointer> T getTypedPointerField(StructObject struct, int fieldIndex) {
/* 208 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/* 209 */     PointerIO<T> pio = PointerIO.getInstance(fd.nativeTypeOrPointerTargetType);
/* 210 */     return pio.castTarget(struct.peer.getSizeTAtOffset(fd.byteOffset));
/*     */   }
/*     */   public final <O extends NativeObject> O getNativeObjectField(StructObject struct, int fieldIndex) {
/* 213 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/* 214 */     return (O)struct.peer.offset(fd.byteOffset).getNativeObject(fd.nativeTypeOrPointerTargetType);
/*     */   }
/*     */   
/*     */   public final <O extends NativeObject> void setNativeObjectField(StructObject struct, int fieldIndex, O value) {
/* 218 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/* 219 */     struct.peer.offset(fd.byteOffset).setNativeObject(value, fd.nativeTypeOrPointerTargetType);
/*     */   }
/*     */   
/*     */   public final <E extends Enum<E>> IntValuedEnum<E> getEnumField(StructObject struct, int fieldIndex) {
/* 223 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/* 224 */     return FlagSet.fromValue(struct.peer.getIntAtOffset(fd.byteOffset), (Class<E>)fd.nativeTypeOrPointerTargetType);
/*     */   }
/*     */   
/*     */   public final void setEnumField(StructObject struct, int fieldIndex, ValuedEnum<?> value) {
/* 228 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/* 229 */     struct.peer.setIntAtOffset(fd.byteOffset, (int)value.value());
/*     */   }
/*     */   
/*     */   private void setSignedIntegral(Pointer<?> ptr, long byteOffset, long byteLength, long bitMask, long bitOffset, long value) {
/* 233 */     if (bitMask != -1L) {
/* 234 */       long previous = ptr.getSignedIntegralAtOffset(byteOffset, byteLength);
/* 235 */       value <<= (int)bitOffset;
/* 236 */       value = previous & (bitMask ^ 0xFFFFFFFFFFFFFFFFL) | value & bitMask;
/*     */     } 
/* 238 */     ptr.setSignedIntegralAtOffset(byteOffset, value, byteLength);
/*     */   }
/*     */   
/*     */   public final void setIntField(StructObject struct, int fieldIndex, int value) {
/* 242 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/* 243 */     if (4L != fd.byteLength || fd.bitMask != -1L) {
/* 244 */       setSignedIntegral(struct.peer, fd.byteOffset, fd.byteLength, fd.bitMask, fd.bitOffset, value);
/*     */     } else {
/* 246 */       struct.peer.setIntAtOffset(fd.byteOffset, value);
/*     */     }  } public final int getIntField(StructObject struct, int fieldIndex) {
/*     */     int value;
/* 249 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/*     */     
/* 251 */     if (4L != fd.byteLength) {
/* 252 */       value = (int)struct.peer.getSignedIntegralAtOffset(fd.byteOffset, fd.byteLength);
/*     */     } else {
/* 254 */       value = struct.peer.getIntAtOffset(fd.byteOffset);
/*     */     } 
/* 256 */     return (int)((value & fd.bitMask) >> (int)fd.bitOffset);
/*     */   }
/*     */   
/* 259 */   public final void setLongField(StructObject struct, int fieldIndex, long value) { StructFieldDescription fd = this.desc.fields[fieldIndex];
/* 260 */     if (8L != fd.byteLength || fd.bitMask != -1L) {
/* 261 */       setSignedIntegral(struct.peer, fd.byteOffset, fd.byteLength, fd.bitMask, fd.bitOffset, value);
/*     */     } else {
/* 263 */       struct.peer.setLongAtOffset(fd.byteOffset, value);
/*     */     }  } public final long getLongField(StructObject struct, int fieldIndex) {
/*     */     long value;
/* 266 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/*     */     
/* 268 */     if (8L != fd.byteLength) {
/* 269 */       value = struct.peer.getSignedIntegralAtOffset(fd.byteOffset, fd.byteLength);
/*     */     } else {
/* 271 */       value = struct.peer.getLongAtOffset(fd.byteOffset);
/*     */     } 
/* 273 */     return (value & fd.bitMask) >> (int)fd.bitOffset;
/*     */   }
/*     */   
/* 276 */   public final void setShortField(StructObject struct, int fieldIndex, short value) { StructFieldDescription fd = this.desc.fields[fieldIndex];
/* 277 */     if (2L != fd.byteLength || fd.bitMask != -1L) {
/* 278 */       setSignedIntegral(struct.peer, fd.byteOffset, fd.byteLength, fd.bitMask, fd.bitOffset, value);
/*     */     } else {
/* 280 */       struct.peer.setShortAtOffset(fd.byteOffset, value);
/*     */     }  } public final short getShortField(StructObject struct, int fieldIndex) {
/*     */     short value;
/* 283 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/*     */     
/* 285 */     if (2L != fd.byteLength) {
/* 286 */       value = (short)(int)struct.peer.getSignedIntegralAtOffset(fd.byteOffset, fd.byteLength);
/*     */     } else {
/* 288 */       value = struct.peer.getShortAtOffset(fd.byteOffset);
/*     */     } 
/* 290 */     return (short)(int)((value & fd.bitMask) >> (int)fd.bitOffset);
/*     */   }
/*     */   
/* 293 */   public final void setByteField(StructObject struct, int fieldIndex, byte value) { StructFieldDescription fd = this.desc.fields[fieldIndex];
/* 294 */     if (1L != fd.byteLength || fd.bitMask != -1L) {
/* 295 */       setSignedIntegral(struct.peer, fd.byteOffset, fd.byteLength, fd.bitMask, fd.bitOffset, value);
/*     */     } else {
/* 297 */       struct.peer.setByteAtOffset(fd.byteOffset, value);
/*     */     }  } public final byte getByteField(StructObject struct, int fieldIndex) {
/*     */     byte value;
/* 300 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/*     */     
/* 302 */     if (1L != fd.byteLength) {
/* 303 */       value = (byte)(int)struct.peer.getSignedIntegralAtOffset(fd.byteOffset, fd.byteLength);
/*     */     } else {
/* 305 */       value = struct.peer.getByteAtOffset(fd.byteOffset);
/*     */     } 
/* 307 */     return (byte)(int)((value & fd.bitMask) >> (int)fd.bitOffset);
/*     */   }
/*     */   public final void setCharField(StructObject struct, int fieldIndex, char value) {
/* 310 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/* 311 */     struct.peer.setCharAtOffset(fd.byteOffset, value);
/*     */   }
/*     */   public final char getCharField(StructObject struct, int fieldIndex) {
/* 314 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/*     */     
/* 316 */     char value = struct.peer.getCharAtOffset(fd.byteOffset);
/*     */ 
/*     */     
/* 319 */     return value;
/*     */   }
/*     */   public final void setFloatField(StructObject struct, int fieldIndex, float value) {
/* 322 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/* 323 */     struct.peer.setFloatAtOffset(fd.byteOffset, value);
/*     */   }
/*     */   public final float getFloatField(StructObject struct, int fieldIndex) {
/* 326 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/*     */     
/* 328 */     float value = struct.peer.getFloatAtOffset(fd.byteOffset);
/*     */ 
/*     */     
/* 331 */     return value;
/*     */   }
/*     */   public final void setDoubleField(StructObject struct, int fieldIndex, double value) {
/* 334 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/* 335 */     struct.peer.setDoubleAtOffset(fd.byteOffset, value);
/*     */   }
/*     */   public final double getDoubleField(StructObject struct, int fieldIndex) {
/* 338 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/*     */     
/* 340 */     double value = struct.peer.getDoubleAtOffset(fd.byteOffset);
/*     */ 
/*     */     
/* 343 */     return value;
/*     */   }
/*     */   public final void setBooleanField(StructObject struct, int fieldIndex, boolean value) {
/* 346 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/* 347 */     struct.peer.setBooleanAtOffset(fd.byteOffset, value);
/*     */   }
/*     */   public final boolean getBooleanField(StructObject struct, int fieldIndex) {
/* 350 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/*     */     
/* 352 */     boolean value = struct.peer.getBooleanAtOffset(fd.byteOffset);
/*     */ 
/*     */     
/* 355 */     return value;
/*     */   }
/*     */   
/*     */   public final void setSizeTField(StructObject struct, int fieldIndex, long value) {
/* 359 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/* 360 */     struct.peer.setSizeTAtOffset(fd.byteOffset, value);
/*     */   }
/*     */   public final long getSizeTField(StructObject struct, int fieldIndex) {
/* 363 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/* 364 */     return struct.peer.getSizeTAtOffset(fd.byteOffset);
/*     */   }
/*     */   public final void setCLongField(StructObject struct, int fieldIndex, long value) {
/* 367 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/* 368 */     struct.peer.setCLongAtOffset(fd.byteOffset, value);
/*     */   }
/*     */   public final long getCLongField(StructObject struct, int fieldIndex) {
/* 371 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/* 372 */     return struct.peer.getCLongAtOffset(fd.byteOffset);
/*     */   }
/*     */   
/*     */   public final void setTimeTField(StructObject struct, int fieldIndex, TimeT value) {
/* 376 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/* 377 */     struct.peer.setIntegralAtOffset(fd.byteOffset, value);
/*     */   }
/*     */   public final TimeT getTimeTField(StructObject struct, int fieldIndex) {
/* 380 */     StructFieldDescription fd = this.desc.fields[fieldIndex];
/* 381 */     return new TimeT(struct.peer.getIntegralAtOffset(fd.byteOffset, TimeT.SIZE));
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\StructIO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */