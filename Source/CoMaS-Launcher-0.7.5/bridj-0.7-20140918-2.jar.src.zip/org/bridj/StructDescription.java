/*     */ package org.bridj;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.List;
/*     */ import org.bridj.ann.Virtual;
/*     */ import org.bridj.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StructDescription
/*     */ {
/*     */   protected volatile StructFieldDescription[] fields;
/*  78 */   protected long structSize = -1L;
/*  79 */   protected long structAlignment = -1L;
/*     */   protected final Class<?> structClass;
/*     */   protected final Type structType;
/*     */   protected boolean hasFieldFields;
/*     */   
/*     */   public void prependBytes(long bytes) {
/*  85 */     build();
/*  86 */     for (StructFieldDescription field : this.fields) {
/*  87 */       field.offset(bytes);
/*     */     }
/*  89 */     this.structSize += bytes;
/*     */   }
/*     */   StructCustomizer customizer; private List<StructFieldDescription> aggregatedFields; SolidRanges solidRanges;
/*     */   public void appendBytes(long bytes) {
/*  93 */     build();
/*  94 */     this.structSize += bytes;
/*     */   }
/*     */   
/*     */   public void setFieldOffset(String fieldName, long fieldOffset, boolean propagateChanges) {
/*  98 */     build();
/*     */     
/* 100 */     long propagatedOffsetDelta = 0L;
/* 101 */     long originalOffset = 0L;
/* 102 */     for (StructFieldDescription field : this.fields) {
/* 103 */       if (field.name.equals(fieldName)) {
/* 104 */         originalOffset = field.byteOffset;
/* 105 */         propagatedOffsetDelta = fieldOffset - field.byteOffset;
/* 106 */         field.offset(propagatedOffsetDelta);
/* 107 */         if (!propagateChanges) {
/* 108 */           long minSize = fieldOffset + field.byteLength;
/* 109 */           this.structSize = (this.structSize < minSize) ? minSize : this.structSize;
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/* 114 */     this.structSize += propagatedOffsetDelta;
/* 115 */     for (StructFieldDescription field : this.fields) {
/* 116 */       if (!field.name.equals(fieldName) && field.byteOffset > originalOffset) {
/* 117 */         field.offset(propagatedOffsetDelta);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public StructDescription(Class<?> structClass, Type structType, StructCustomizer customizer) {
/* 124 */     this.structClass = structClass;
/* 125 */     this.structType = structType;
/* 126 */     this.customizer = customizer;
/* 127 */     if (Utils.containsTypeVariables(structType)) {
/* 128 */       throw new RuntimeException("Type " + structType + " contains unresolved type variables!");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isVirtual() {
/* 134 */     for (Method m : this.structClass.getMethods()) {
/* 135 */       if (m.getAnnotation(Virtual.class) != null) {
/* 136 */         return true;
/*     */       }
/*     */     } 
/* 139 */     return false;
/*     */   }
/*     */   
/*     */   public Class<?> getStructClass() {
/* 143 */     return this.structClass;
/*     */   }
/*     */   
/*     */   public Type getStructType() {
/* 147 */     return this.structType;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 152 */     return "StructDescription(" + Utils.toString(this.structType) + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   void build() {
/* 157 */     if (this.fields == null) {
/* 158 */       synchronized (this) {
/* 159 */         if (this.fields == null) {
/* 160 */           StructUtils.computeStructLayout(this, this.customizer);
/* 161 */           this.customizer.afterBuild(this);
/* 162 */           if (BridJ.debug) {
/* 163 */             BridJ.info(describe());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public final long getStructSize() {
/* 171 */     build();
/* 172 */     return this.structSize;
/*     */   }
/*     */   
/*     */   public final long getStructAlignment() {
/* 176 */     build();
/* 177 */     return this.structAlignment;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAggregatedFields(List<StructFieldDescription> aggregatedFields) {
/* 182 */     this.aggregatedFields = aggregatedFields;
/*     */   }
/*     */   
/*     */   public List<StructFieldDescription> getAggregatedFields() {
/* 186 */     build();
/* 187 */     return this.aggregatedFields;
/*     */   }
/*     */ 
/*     */   
/*     */   public SolidRanges getSolidRanges() {
/* 192 */     build();
/* 193 */     return this.solidRanges;
/*     */   }
/*     */   
/*     */   public final String describe(StructObject struct) {
/* 197 */     return StructUtils.describe(struct, this.structType, this.fields);
/*     */   }
/*     */   
/*     */   public final String describe() {
/* 201 */     StringBuilder b = new StringBuilder();
/* 202 */     b.append("// ");
/* 203 */     b.append("size = ").append(this.structSize).append(", ");
/* 204 */     b.append("alignment = ").append(this.structAlignment);
/* 205 */     b.append("\nstruct ");
/* 206 */     b.append(StructUtils.describe(this.structType)).append(" { ");
/* 207 */     for (int iField = 0, nFields = this.fields.length; iField < nFields; iField++) {
/* 208 */       StructFieldDescription fd = this.fields[iField];
/* 209 */       b.append("\n\t");
/* 210 */       b.append("@Field(").append(iField).append(") ");
/* 211 */       if (fd.isCLong) {
/* 212 */         b.append("@CLong ");
/* 213 */       } else if (fd.isSizeT) {
/* 214 */         b.append("@Ptr ");
/*     */       } 
/* 216 */       b.append(StructUtils.describe(fd.valueType)).append(" ").append(fd.name).append("; ");
/*     */       
/* 218 */       b.append("// ");
/* 219 */       b.append("offset = ").append(fd.byteOffset).append(", ");
/* 220 */       b.append("length = ").append(fd.byteLength).append(", ");
/* 221 */       if (fd.bitOffset != 0L) {
/* 222 */         b.append("bitOffset = ").append(fd.bitOffset).append(", ");
/*     */       }
/* 224 */       if (fd.bitLength != -1L) {
/* 225 */         b.append("bitLength = ").append(fd.bitLength).append(", ");
/*     */       }
/* 227 */       if (fd.arrayLength != 1L) {
/* 228 */         b.append("arrayLength = ").append(fd.arrayLength).append(", ");
/*     */       }
/* 230 */       if (fd.alignment != 1L) {
/* 231 */         b.append("alignment = ").append(fd.alignment);
/*     */       }
/*     */     } 
/* 234 */     b.append("\n}");
/* 235 */     return b.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\StructDescription.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */