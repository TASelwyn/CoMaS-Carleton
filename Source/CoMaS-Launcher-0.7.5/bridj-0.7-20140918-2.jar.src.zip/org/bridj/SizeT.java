/*    */ package org.bridj;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SizeT
/*    */   extends AbstractIntegral
/*    */ {
/* 41 */   public static final int SIZE = Platform.SIZE_T_SIZE;
/* 42 */   public static final SizeT ZERO = new SizeT(0L); public static final SizeT ONE = new SizeT(1L);
/*    */   private static final long serialVersionUID = 1547942367767922396L;
/*    */   
/*    */   public SizeT(long value) {
/* 46 */     super(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public int byteSize() {
/* 51 */     return SIZE;
/*    */   }
/*    */   
/*    */   public static SizeT valueOf(long value) {
/* 55 */     if (value == 0L) {
/* 56 */       return ZERO;
/*    */     }
/* 58 */     if (value == 1L) {
/* 59 */       return ONE;
/*    */     }
/* 61 */     return new SizeT(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\SizeT.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */