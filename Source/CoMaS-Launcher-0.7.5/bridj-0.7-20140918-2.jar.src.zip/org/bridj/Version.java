package org.bridj;

public final class Version {
  public static final String MAVEN_VERSION = "0.7-20140918";
  
  public static final String VERSION_SPECIFIC_SUB_PACKAGE = "v0_7_0";
}
