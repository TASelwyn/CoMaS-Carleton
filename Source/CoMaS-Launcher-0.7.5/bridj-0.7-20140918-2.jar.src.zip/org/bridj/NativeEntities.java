package org.bridj;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NativeEntities {
  static class CBInfo {
    long handle;
    
    int size;
    
    public CBInfo(long handle, int size) {
      this.handle = handle;
      this.size = size;
    }
  }
  
  Map<Class<?>, CBInfo> functions = new HashMap<Class<?>, CBInfo>();
  
  Map<Class<?>, CBInfo> virtualMethods = new HashMap<Class<?>, CBInfo>();
  
  Map<Class<?>, CBInfo> javaToNativeCallbacks = new HashMap<Class<?>, CBInfo>();
  
  Map<Class<?>, CBInfo> objcMethodInfos = new HashMap<Class<?>, CBInfo>();
  
  public static class Builder {
    List<MethodCallInfo> functionInfos = new ArrayList<MethodCallInfo>(), virtualMethods = new ArrayList<MethodCallInfo>(), javaToNativeCallbacks = new ArrayList<MethodCallInfo>(), cppMethodInfos = new ArrayList<MethodCallInfo>(), objcMethodInfos = new ArrayList<MethodCallInfo>();
    
    public void addFunction(MethodCallInfo info) {
      this.functionInfos.add(info);
    }
    
    public void addVirtualMethod(MethodCallInfo info) {
      this.virtualMethods.add(info);
    }
    
    public void addJavaToNativeCallback(MethodCallInfo info) {
      this.javaToNativeCallbacks.add(info);
    }
    
    public void addMethodFunction(MethodCallInfo info) {
      this.cppMethodInfos.add(info);
    }
    
    public void addObjCMethod(MethodCallInfo info) {
      this.objcMethodInfos.add(info);
    }
  }
  
  public void release() {
    if (BridJ.debugNeverFree)
      return; 
    for (CBInfo callbacks : this.functions.values())
      JNI.freeCFunctionBindings(callbacks.handle, callbacks.size); 
    for (CBInfo callbacks : this.javaToNativeCallbacks.values())
      JNI.freeJavaToCCallbacks(callbacks.handle, callbacks.size); 
    for (CBInfo callbacks : this.virtualMethods.values())
      JNI.freeVirtualMethodBindings(callbacks.handle, callbacks.size); 
    for (CBInfo callbacks : this.objcMethodInfos.values())
      JNI.freeObjCMethodBindings(callbacks.handle, callbacks.size); 
  }
  
  public void finalize() {
    release();
  }
  
  public void addDefinitions(Class<?> type, Builder builder) {
    try {
      int n = builder.functionInfos.size();
      if (n != 0)
        this.functions.put(type, new CBInfo(JNI.bindJavaMethodsToCFunctions(builder.functionInfos.<MethodCallInfo>toArray(new MethodCallInfo[n])), n)); 
      n = builder.virtualMethods.size();
      if (n != 0)
        this.virtualMethods.put(type, new CBInfo(JNI.bindJavaMethodsToVirtualMethods(builder.virtualMethods.<MethodCallInfo>toArray(new MethodCallInfo[n])), n)); 
      n = builder.javaToNativeCallbacks.size();
      if (n != 0)
        this.javaToNativeCallbacks.put(type, new CBInfo(JNI.bindJavaToCCallbacks(builder.javaToNativeCallbacks.<MethodCallInfo>toArray(new MethodCallInfo[n])), n)); 
      n = builder.objcMethodInfos.size();
      if (n != 0)
        this.objcMethodInfos.put(type, new CBInfo(JNI.bindJavaMethodsToObjCMethods(builder.objcMethodInfos.<MethodCallInfo>toArray(new MethodCallInfo[n])), n)); 
    } catch (Throwable th) {
      assert BridJ.error("Failed to add native definitions for class " + type.getName(), th);
    } 
  }
}
