/*    */ package org.bridj.objc;
/*    */ 
/*    */ import org.bridj.BridJ;
/*    */ import org.bridj.Pointer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjCClass
/*    */   extends ObjCObject
/*    */ {
/*    */   public native Pointer<ObjCObject> alloc();
/*    */   
/*    */   @Selector("new")
/*    */   public native Pointer<ObjCObject> new$();
/*    */   
/*    */   public native boolean instancesRespondTo(SEL paramSEL);
/*    */   
/*    */   public native IMP instanceMethodFor(SEL paramSEL);
/*    */   
/*    */   static {
/* 38 */     BridJ.register();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\objc\ObjCClass.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */