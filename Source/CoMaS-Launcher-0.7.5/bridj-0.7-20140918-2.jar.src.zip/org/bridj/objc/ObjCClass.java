package org.bridj.objc;

import org.bridj.BridJ;
import org.bridj.Pointer;

public class ObjCClass extends ObjCObject {
  public native Pointer<ObjCObject> alloc();
  
  @Selector("new")
  public native Pointer<ObjCObject> new$();
  
  public native boolean instancesRespondTo(SEL paramSEL);
  
  public native IMP instanceMethodFor(SEL paramSEL);
  
  static {
    BridJ.register();
  }
}
