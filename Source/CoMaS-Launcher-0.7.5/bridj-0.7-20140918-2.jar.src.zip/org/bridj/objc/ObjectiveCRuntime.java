/*     */ package org.bridj.objc;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.bridj.BridJ;
/*     */ import org.bridj.BridJRuntime;
/*     */ import org.bridj.CLong;
/*     */ import org.bridj.CRuntime;
/*     */ import org.bridj.CallbackInterface;
/*     */ import org.bridj.MethodCallInfo;
/*     */ import org.bridj.NativeEntities;
/*     */ import org.bridj.NativeLibrary;
/*     */ import org.bridj.NativeObject;
/*     */ import org.bridj.NativeObjectInterface;
/*     */ import org.bridj.Platform;
/*     */ import org.bridj.Pointer;
/*     */ import org.bridj.ann.Library;
/*     */ import org.bridj.ann.Ptr;
/*     */ import org.bridj.demangling.Demangler;
/*     */ import org.bridj.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Library("/usr/lib/libobjc.A.dylib")
/*     */ public class ObjectiveCRuntime
/*     */   extends CRuntime
/*     */ {
/*     */   public boolean isAvailable() {
/*  56 */     return Platform.isMacOSX();
/*     */   }
/*  58 */   Map<String, Pointer<? extends ObjCObject>> nativeClassesByObjCName = new HashMap<String, Pointer<? extends ObjCObject>>(); Map<String, Pointer<? extends ObjCObject>> nativeMetaClassesByObjCName = new HashMap<String, Pointer<? extends ObjCObject>>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   <T extends ObjCObject> T realCast(Pointer<? extends ObjCObject> id) {
/*  67 */     if (id == null) {
/*  68 */       return null;
/*     */     }
/*  70 */     Pointer<Byte> cn = object_getClassName(id);
/*  71 */     if (cn == null) {
/*  72 */       throw new RuntimeException("Null class name for this ObjectiveC object pointer !");
/*     */     }
/*     */     
/*  75 */     String n = cn.getCString();
/*     */     
/*  77 */     Class<? extends ObjCObject> c = this.bridjClassesByObjCName.get(n);
/*  78 */     if (c == null) {
/*  79 */       throw new RuntimeException("Class " + n + " was not registered yet in the BridJ runtime ! (TODO : auto create by scanning path, then reflection !)");
/*     */     }
/*  81 */     return (T)id.getNativeObject(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMethodSignature(Method method) {
/* 117 */     return getMethodSignature(method.getGenericReturnType(), method.getGenericParameterTypes());
/*     */   }
/*     */   
/*     */   public String getMethodSignature(Type returnType, Type... paramTypes) {
/* 121 */     StringBuilder b = new StringBuilder();
/*     */     
/* 123 */     b.append(getTypeSignature(returnType));
/* 124 */     b.append(getTypeSignature(Pointer.class));
/* 125 */     b.append(getTypeSignature(SEL.class));
/* 126 */     for (Type paramType : paramTypes) {
/* 127 */       b.append(getTypeSignature(paramType));
/*     */     }
/* 129 */     return b.toString();
/*     */   }
/*     */   
/*     */   char getTypeSignature(Type type) {
/* 133 */     Character c = signatureByType.get(type);
/* 134 */     if (c == null) {
/* 135 */       c = signatureByType.get(Utils.getClass(type));
/*     */     }
/* 137 */     if (c == null) {
/* 138 */       throw new RuntimeException("Unknown type for Objective-C signatures : " + Utils.toString(type));
/*     */     }
/* 140 */     return c.charValue();
/*     */   }
/* 142 */   static final Map<Type, Character> signatureByType = new HashMap<Type, Character>();
/* 143 */   static final Map<Character, List<Type>> typesBySignature = new HashMap<Character, List<Type>>(); Map<String, Class<? extends ObjCObject>> bridjClassesByObjCName;
/*     */   
/*     */   static {
/* 146 */     initSignatures();
/*     */   }
/*     */   
/*     */   static void addSignature(char sig, Type... types) {
/* 150 */     List<Type> typesList = typesBySignature.get(Character.valueOf(sig));
/* 151 */     if (typesList == null) {
/* 152 */       typesBySignature.put(Character.valueOf(sig), typesList = new ArrayList<Type>());
/*     */     }
/*     */     
/* 155 */     for (Type type : types) {
/* 156 */       signatureByType.put(type, Character.valueOf(sig));
/*     */       
/* 158 */       if (type != null && !typesList.contains(type)) {
/* 159 */         typesList.add(type);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   static void initSignatures() {
/* 165 */     boolean is32 = (CLong.SIZE == 4);
/* 166 */     addSignature('q', new Type[] { long.class, !is32 ? CLong.class : null });
/* 167 */     addSignature('i', new Type[] { int.class, is32 ? CLong.class : null });
/* 168 */     addSignature('I', new Type[] { int.class, is32 ? CLong.class : null });
/* 169 */     addSignature('s', new Type[] { short.class, char.class });
/* 170 */     addSignature('c', new Type[] { byte.class, boolean.class });
/* 171 */     addSignature('f', new Type[] { float.class });
/* 172 */     addSignature('d', new Type[] { double.class });
/* 173 */     addSignature('v', new Type[] { void.class });
/* 174 */     addSignature('@', new Type[] { Pointer.class });
/* 175 */     addSignature(':', new Type[] { SEL.class });
/*     */   }
/*     */   
/*     */   synchronized Pointer<? extends ObjCObject> getObjCClass(String name, boolean meta) throws ClassNotFoundException {
/* 179 */     if (name.equals("")) {
/* 180 */       return null;
/*     */     }
/* 182 */     Map<String, Pointer<? extends ObjCObject>> map = meta ? this.nativeMetaClassesByObjCName : this.nativeClassesByObjCName;
/* 183 */     Pointer<? extends ObjCObject> c = map.get(name);
/* 184 */     if (c == null) {
/* 185 */       Pointer<Byte> pName = Pointer.pointerToCString(name);
/* 186 */       c = meta ? objc_getMetaClass(pName) : objc_getClass(pName);
/* 187 */       if (c != null) {
/* 188 */         assert object_getClassName(c).getCString().equals(name);
/* 189 */         map.put(name, c);
/*     */       } 
/*     */     } 
/* 192 */     if (c == null) {
/* 193 */       throw new ClassNotFoundException("Objective C class not found : " + name);
/*     */     }
/*     */     
/* 196 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   protected NativeLibrary getNativeLibrary(Class<?> type) throws IOException {
/* 201 */     Library libAnn = type.<Library>getAnnotation(Library.class);
/* 202 */     if (libAnn != null) {
/*     */       try {
/* 204 */         String name = libAnn.value();
/* 205 */         return BridJ.getNativeLibrary(name, new File("/System/Library/Frameworks/" + name + ".framework/" + name));
/* 206 */       } catch (FileNotFoundException ex) {}
/*     */     }
/*     */ 
/*     */     
/* 210 */     return super.getNativeLibrary(type);
/*     */   } public ObjectiveCRuntime() {
/* 212 */     this.bridjClassesByObjCName = new HashMap<String, Class<? extends ObjCObject>>();
/*     */     BridJ.register();
/*     */     this.rootCallbackClasses.add(ObjCBlock.class);
/*     */   } public void register(Type type) {
/* 216 */     Class<?> typeClass = Utils.getClass(type);
/* 217 */     typeClass.getAnnotation(Library.class);
/* 218 */     Library libAnn = typeClass.<Library>getAnnotation(Library.class);
/* 219 */     if (libAnn != null) {
/* 220 */       String name = libAnn.value();
/* 221 */       File libraryFile = BridJ.getNativeLibraryFile(name);
/* 222 */       if (libraryFile != null) {
/* 223 */         System.load(libraryFile.toString());
/*     */       }
/* 225 */       if (ObjCObject.class.isAssignableFrom(typeClass)) {
/* 226 */         this.bridjClassesByObjCName.put(typeClass.getSimpleName(), typeClass);
/*     */       }
/*     */     } 
/*     */     
/* 230 */     super.register(type);
/*     */   }
/*     */   
/*     */   public String getSelector(Method method) {
/* 234 */     Selector selAnn = method.<Selector>getAnnotation(Selector.class);
/* 235 */     if (selAnn != null) {
/* 236 */       return selAnn.value();
/*     */     }
/*     */     
/* 239 */     String n = Demangler.getMethodName(method);
/* 240 */     if (n.endsWith("_")) {
/* 241 */       n = n.substring(0, n.length() - 1);
/*     */     }
/*     */     
/* 244 */     if ((method.getParameterTypes()).length > 0) {
/* 245 */       n = n + ":";
/*     */     }
/*     */     
/* 248 */     n = n.replace('_', ':');
/* 249 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerNativeMethod(Class<?> type, NativeLibrary typeLibrary, Method method, NativeLibrary methodLibrary, NativeEntities.Builder builder, CRuntime.MethodCallInfoBuilder methodCallInfoBuilder) throws FileNotFoundException {
/* 261 */     if (method == null) {
/*     */       return;
/*     */     }
/*     */     
/* 265 */     if (!ObjCObject.class.isAssignableFrom(type) || ObjCBlock.class.isAssignableFrom(type)) {
/* 266 */       super.registerNativeMethod(type, typeLibrary, method, methodLibrary, builder, methodCallInfoBuilder);
/*     */       
/*     */       return;
/*     */     } 
/*     */     try {
/* 271 */       MethodCallInfo mci = methodCallInfoBuilder.apply(method);
/* 272 */       boolean isStatic = Modifier.isStatic(method.getModifiers());
/*     */       
/* 274 */       if (isStatic) {
/* 275 */         Pointer<ObjCClass> pObjcClass = getObjCClass((Class)type).as(ObjCClass.class);
/* 276 */         ObjCClass objcClass = (ObjCClass)pObjcClass.get();
/* 277 */         mci.setNativeClass(pObjcClass.getPeer());
/*     */       } 
/*     */       
/* 280 */       mci.setSymbolName(getSelector(method));
/* 281 */       builder.addObjCMethod(mci);
/* 282 */     } catch (ClassNotFoundException ex) {
/* 283 */       throw new RuntimeException("Failed to register method " + method + " : " + ex, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static ObjectiveCRuntime getInstance() {
/* 288 */     return (ObjectiveCRuntime)BridJ.getRuntimeByRuntimeClass(ObjectiveCRuntime.class);
/*     */   }
/*     */   
/*     */   public static Type getBlockCallbackType(Class<?> blockClass) {
/* 292 */     if (!ObjCBlock.class.isAssignableFrom(blockClass) || ObjCBlock.class == blockClass) {
/* 293 */       throw new RuntimeException("Class " + blockClass.getName() + " should be a subclass of " + ObjCBlock.class.getName());
/*     */     }
/*     */     
/* 296 */     Type p = blockClass.getGenericSuperclass();
/* 297 */     if (Utils.getClass(p) == ObjCBlock.class) {
/* 298 */       Type callbackType = Utils.getUniqueParameterizedTypeParameter(p);
/* 299 */       if (callbackType == null || (!(callbackType instanceof Class) && !(callbackType instanceof java.lang.reflect.ParameterizedType))) {
/* 300 */         throw new RuntimeException("Class " + blockClass.getName() + " should inherit from " + ObjCBlock.class.getName() + " with a valid single type parameter (found " + Utils.toString(p) + ")");
/*     */       }
/*     */       
/* 303 */       return callbackType;
/*     */     } 
/* 305 */     throw new RuntimeException("Unexpected failure in getBlockCallbackType");
/*     */   }
/* 307 */   static final Pointer.Releaser ObjCBlockReleaser = new Pointer.Releaser() {
/*     */       public void release(Pointer p) {
/* 309 */         ObjCJNI.releaseObjCBlock(p.getPeer());
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   public <T extends NativeObject> BridJRuntime.TypeInfo<T> getTypeInfo(Type type) {
/* 315 */     return (BridJRuntime.TypeInfo<T>)new CRuntime.CTypeInfo<T>(type)
/*     */       {
/*     */         public void initialize(T instance) {
/* 318 */           if (!BridJ.isCastingNativeObjectInCurrentThread()) {
/* 319 */             if (instance instanceof ObjCBlock) {
/* 320 */               final Pointer<CallbackInterface> pcb = ObjectiveCRuntime.this.registerCallbackInstance((CallbackInterface)instance);
/* 321 */               ((ObjCBlock)instance).pCallback = pcb;
/*     */               
/* 323 */               Pointer<T> pBlock = Pointer.pointerToAddress(ObjCJNI.createObjCBlockWithFunctionPointer(pcb.getPeer()), this.type);
/* 324 */               pBlock = pBlock.withReleaser(new Pointer.Releaser() {
/*     */                     public void release(Pointer<?> p) {
/* 326 */                       pcb.release();
/* 327 */                       ObjCJNI.releaseObjCBlock(p.getPeer());
/*     */                     }
/*     */                   });
/*     */               
/* 331 */               ObjectiveCRuntime.this.setNativeObjectPeer((NativeObjectInterface)instance, pBlock);
/*     */             } else {
/* 333 */               super.initialize((NativeObject)instance);
/*     */             } 
/*     */           } else {
/* 336 */             super.initialize((NativeObject)instance);
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/*     */         public void initialize(T instance, Pointer peer) {
/* 342 */           if (instance instanceof ObjCClass) {
/* 343 */             ObjectiveCRuntime.this.setNativeObjectPeer((NativeObjectInterface)instance, peer);
/*     */ 
/*     */ 
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */ 
/*     */             
/* 352 */             super.initialize((NativeObject)instance, peer);
/*     */           } 
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void initialize(T instance, int constructorId, Object... args) {
/*     */           try {
/* 373 */             Pointer<? extends ObjCObject> c = ObjectiveCRuntime.this.getObjCClass(this.typeClass);
/* 374 */             if (c == null) {
/* 375 */               throw new RuntimeException("Failed to get Objective-C class for type " + this.typeClass.getName());
/*     */             }
/* 377 */             Pointer<ObjCClass> pc = c.as(ObjCClass.class);
/* 378 */             Pointer<ObjCObject> p = ((ObjCClass)pc.get()).new$();
/* 379 */             if (constructorId == -1) {
/* 380 */               p = ((ObjCObject)p.get()).init();
/*     */             } else {
/* 382 */               throw new UnsupportedOperationException("TODO handle constructors !");
/*     */             } 
/* 384 */             ObjectiveCRuntime.this.setNativeObjectPeer((NativeObjectInterface)instance, p);
/*     */           }
/* 386 */           catch (ClassNotFoundException ex) {
/* 387 */             throw new RuntimeException("Failed to initialize instance of type " + Utils.toString(this.type) + " : " + ex, ex);
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public static Pointer<? extends ObjCObject> getObjCClass(String name) throws ClassNotFoundException {
/* 394 */     return getInstance().getObjCClass(name, false);
/*     */   }
/*     */   
/*     */   private Pointer<? extends ObjCObject> getObjCClass(Class<? extends NativeObject> cls) throws ClassNotFoundException {
/* 398 */     if (cls == ObjCClass.class)
/* 399 */       return getObjCClass("NSObject", true); 
/* 400 */     if (cls == ObjCObject.class) {
/* 401 */       return getObjCClass("NSObject", false);
/*     */     }
/*     */     
/* 404 */     return getObjCClass(cls.getSimpleName(), false);
/*     */   }
/*     */   
/*     */   protected static native Pointer<? extends ObjCObject> object_getClass(Pointer<? extends ObjCObject> paramPointer);
/*     */   
/*     */   protected static native Pointer<? extends ObjCObject> objc_getClass(Pointer<Byte> paramPointer);
/*     */   
/*     */   protected static native Pointer<? extends ObjCObject> objc_getMetaClass(Pointer<Byte> paramPointer);
/*     */   
/*     */   protected static native Pointer<Byte> object_getClassName(Pointer<? extends ObjCObject> paramPointer);
/*     */   
/*     */   protected static native Pointer<? extends ObjCObject> class_createInstance(Pointer<? extends ObjCObject> paramPointer, @Ptr long paramLong);
/*     */   
/*     */   public static native Pointer<? extends ObjCObject> objc_getProtocol(Pointer<Byte> paramPointer);
/*     */   
/*     */   public static native boolean class_addProtocol(Pointer<? extends ObjCObject> paramPointer1, Pointer<? extends ObjCObject> paramPointer2);
/*     */   
/*     */   protected static native boolean class_respondsToSelector(Pointer<? extends ObjCObject> paramPointer, SEL paramSEL);
/*     */   
/*     */   protected static native SEL sel_registerName(Pointer<Byte> paramPointer);
/*     */   
/*     */   protected static native Pointer<Byte> sel_getName(SEL paramSEL);
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\objc\ObjectiveCRuntime.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */