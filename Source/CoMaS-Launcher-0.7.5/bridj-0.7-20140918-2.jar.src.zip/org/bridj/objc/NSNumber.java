/*    */ package org.bridj.objc;
/*    */ 
/*    */ import org.bridj.BridJ;
/*    */ import org.bridj.Pointer;
/*    */ import org.bridj.ann.Library;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Library("Foundation")
/*    */ public class NSNumber
/*    */   extends NSObject
/*    */ {
/*    */   static {
/* 48 */     BridJ.register();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 77 */     if (!(o instanceof NSNumber)) {
/* 78 */       return false;
/*    */     }
/*    */     
/* 81 */     NSNumber nn = (NSNumber)o;
/* 82 */     return isEqualToNumber(Pointer.getPointer(nn));
/*    */   }
/*    */   
/*    */   public native boolean isEqualToNumber(Pointer<NSNumber> paramPointer);
/*    */   
/*    */   public native int compare(Pointer<NSNumber> paramPointer);
/*    */   
/*    */   public native double doubleValue();
/*    */   
/*    */   public native float floatValue();
/*    */   
/*    */   public native long longValue();
/*    */   
/*    */   public native int intValue();
/*    */   
/*    */   public native short shortValue();
/*    */   
/*    */   public static native Pointer<NSNumber> numberWithFloat(float paramFloat);
/*    */   
/*    */   public static native Pointer<NSNumber> numberWithLong(long paramLong);
/*    */   
/*    */   public static native Pointer<NSNumber> numberWithDouble(double paramDouble);
/*    */   
/*    */   public static native Pointer<NSNumber> numberWithInt(int paramInt);
/*    */   
/*    */   public static native Pointer<NSNumber> numberWithBool(boolean paramBoolean);
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\objc\NSNumber.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */