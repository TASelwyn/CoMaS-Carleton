package org.bridj.objc;

import org.bridj.BridJ;
import org.bridj.Pointer;
import org.bridj.ann.Library;
import org.bridj.ann.Ptr;

@Library("Foundation")
public class NSInvocation extends NSObject {
  public native SEL selector();
  
  public native void setSelector(SEL paramSEL);
  
  public native Pointer<? extends ObjCObject> target();
  
  public native void setTarget(Pointer<? extends ObjCObject> paramPointer);
  
  public native void setArgument_atIndex(Pointer<?> paramPointer, @Ptr long paramLong);
  
  public native void getArgument_atIndex(Pointer<?> paramPointer, @Ptr long paramLong);
  
  public native void setReturnValue(Pointer<?> paramPointer);
  
  public native void getReturnValue(Pointer<?> paramPointer);
  
  static {
    BridJ.register();
  }
}
