/*     */ package org.bridj.objc;
/*     */ 
/*     */ import org.bridj.BridJ;
/*     */ import org.bridj.NativeObject;
/*     */ import org.bridj.Pointer;
/*     */ import org.bridj.ann.Runtime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Runtime(ObjectiveCRuntime.class)
/*     */ public class ObjCObject
/*     */   extends NativeObject
/*     */ {
/*     */   ObjCObject type;
/*     */   
/*     */   static {
/*  42 */     BridJ.register();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjCObject(Pointer<? extends NativeObject> peer) {
/*  76 */     super(peer, new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public ObjCObject() {}
/*     */ 
/*     */   
/*     */   public ObjCObject(int constructorId, Object... args) {
/*  84 */     super(constructorId, args);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  89 */     Pointer<NSString> p = description();
/*  90 */     if (p == null) {
/*  91 */       p = stringValue();
/*     */     }
/*     */     
/*  94 */     return ((NSString)p.get()).toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  99 */     if (!(o instanceof ObjCObject)) {
/* 100 */       return false;
/*     */     }
/*     */     
/* 103 */     Pointer<ObjCObject> p = Pointer.getPointer((ObjCObject)o);
/* 104 */     return isEqual(p);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 109 */     return hash();
/*     */   }
/*     */   
/*     */   public native Pointer<ObjCObject> init();
/*     */   
/*     */   public native Pointer<NSString> stringValue();
/*     */   
/*     */   public native Pointer<NSString> description();
/*     */   
/*     */   public native int hash();
/*     */   
/*     */   public native boolean isEqual(Pointer<? extends ObjCObject> paramPointer);
/*     */   
/*     */   public native boolean isKindOf(Pointer<? extends ObjCObject> paramPointer);
/*     */   
/*     */   public native boolean isMemberOf(Pointer<? extends ObjCObject> paramPointer);
/*     */   
/*     */   public native boolean isKindOfClassNamed(Pointer<Byte> paramPointer);
/*     */   
/*     */   public native boolean isMemberOfClassNamed(Pointer<Byte> paramPointer);
/*     */   
/*     */   public native boolean respondsTo(SEL paramSEL);
/*     */   
/*     */   public native IMP methodFor(SEL paramSEL);
/*     */   
/*     */   public native Pointer<?> perform(SEL paramSEL);
/*     */   
/*     */   public native Pointer<?> perform$with(SEL paramSEL, Pointer<?> paramPointer);
/*     */   
/*     */   public native Pointer<?> perform$with$with(SEL paramSEL, Pointer<?> paramPointer1, Pointer<?> paramPointer2);
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\objc\ObjCObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */