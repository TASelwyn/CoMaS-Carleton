/*    */ package org.bridj.objc;
/*    */ 
/*    */ import org.bridj.Pointer;
/*    */ import org.bridj.TypedPointer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SEL
/*    */   extends TypedPointer
/*    */ {
/*    */   protected volatile String name;
/*    */   
/*    */   public SEL(long peer) {
/* 40 */     super(peer);
/*    */   }
/*    */   
/*    */   public SEL(Pointer<?> ptr) {
/* 44 */     super(ptr);
/*    */   }
/*    */   
/*    */   public static SEL valueOf(String name) {
/* 48 */     return ObjectiveCRuntime.sel_registerName(pointerToCString(name));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 53 */     if (this.name == null) {
/* 54 */       this.name = ObjectiveCRuntime.sel_getName(this).getCString();
/*    */     }
/* 56 */     return this.name;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 60 */     return "@selector(" + getName() + ")";
/*    */   }
/*    */   
/*    */   public boolean equals(Object o) {
/* 64 */     if (!(o instanceof SEL)) {
/* 65 */       return false;
/*    */     }
/* 67 */     return getName().equals(((SEL)o).getName());
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 71 */     return getName().hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\objc\SEL.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */