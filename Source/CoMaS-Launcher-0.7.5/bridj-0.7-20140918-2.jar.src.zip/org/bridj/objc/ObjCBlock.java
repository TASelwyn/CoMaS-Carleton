package org.bridj.objc;

import org.bridj.CallbackInterface;
import org.bridj.Pointer;

public abstract class ObjCBlock extends ObjCObject implements CallbackInterface {
  Pointer<? extends CallbackInterface> pCallback;
}
