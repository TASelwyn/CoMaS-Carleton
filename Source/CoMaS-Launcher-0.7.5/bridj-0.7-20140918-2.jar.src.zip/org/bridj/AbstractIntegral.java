/*    */ package org.bridj;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractIntegral
/*    */   extends Number
/*    */ {
/*    */   protected final long value;
/*    */   private static final long HIGH_NEG = -4294967296L;
/*    */   
/*    */   public AbstractIntegral(long value) {
/* 43 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract int byteSize();
/*    */ 
/*    */   
/*    */   public static int safeIntCast(long value) {
/* 52 */     long high = value & 0xFFFFFFFF00000000L;
/* 53 */     if (high != 0L && high != -4294967296L)
/*    */     {
/* 55 */       throw new RuntimeException("Value " + value + " = 0x" + Long.toHexString(value) + " is not within the int range");
/*    */     }
/*    */     
/* 58 */     return (int)(value & 0xFFFFFFFFFFFFFFFFL);
/*    */   }
/*    */ 
/*    */   
/*    */   public int intValue() {
/* 63 */     return safeIntCast(this.value);
/*    */   }
/*    */ 
/*    */   
/*    */   public long longValue() {
/* 68 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public float floatValue() {
/* 73 */     return (float)this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public double doubleValue() {
/* 78 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 83 */     if (o == null || !(o instanceof AbstractIntegral)) {
/* 84 */       return false;
/*    */     }
/* 86 */     if (!o.getClass().equals(getClass())) {
/* 87 */       return false;
/*    */     }
/* 89 */     return (this.value == ((AbstractIntegral)o).value);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 94 */     return Long.valueOf(this.value).hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 99 */     return getClass().getSimpleName() + "(" + this.value + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\AbstractIntegral.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */