/*     */ package org.bridj;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.DoubleBuffer;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.nio.LongBuffer;
/*     */ import java.nio.ShortBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.bridj.cpp.CPPObject;
/*     */ import org.bridj.cpp.CPPType;
/*     */ import org.bridj.util.DefaultParameterizedType;
/*     */ import org.bridj.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StructFieldDescription
/*     */ {
/*  48 */   public final List<StructFieldDeclaration> aggregatedFields = new ArrayList<StructFieldDeclaration>();
/*  49 */   public long alignment = -1L;
/*  50 */   public long byteOffset = -1L, byteLength = -1L;
/*  51 */   public long bitOffset = 0L;
/*  52 */   public long bitLength = -1L;
/*  53 */   public long arrayLength = 1L;
/*  54 */   public long bitMask = -1L;
/*     */   
/*     */   public boolean isArray;
/*     */   
/*     */   public boolean isNativeObject;
/*     */   
/*     */   public Type nativeTypeOrPointerTargetType;
/*     */   public Field field;
/*     */   
/*     */   public void offset(long bytes) {
/*  64 */     this.byteOffset += bytes;
/*     */   }
/*     */   Type valueType; Method getter; String name; boolean isCLong; boolean isSizeT;
/*     */   
/*     */   public String toString() {
/*  69 */     return "Field(byteOffset = " + this.byteOffset + ", byteLength = " + this.byteLength + ", bitOffset = " + this.bitOffset + ", bitLength = " + this.bitLength + ((this.nativeTypeOrPointerTargetType == null) ? "" : (", ttype = " + this.nativeTypeOrPointerTargetType)) + ")";
/*     */   }
/*     */   static Type resolveType(Type tpe, Type structType) {
/*     */     Type ret;
/*  73 */     if (tpe == null || tpe instanceof java.lang.reflect.WildcardType) {
/*  74 */       return null;
/*     */     }
/*     */ 
/*     */     
/*  78 */     if (tpe instanceof ParameterizedType) {
/*  79 */       ParameterizedType pt = (ParameterizedType)tpe;
/*  80 */       Type[] actualTypeArguments = pt.getActualTypeArguments();
/*  81 */       Type[] resolvedActualTypeArguments = new Type[actualTypeArguments.length];
/*  82 */       for (int i = 0; i < actualTypeArguments.length; i++) {
/*  83 */         resolvedActualTypeArguments[i] = resolveType(actualTypeArguments[i], structType);
/*     */       }
/*  85 */       Type resolvedOwnerType = resolveType(pt.getOwnerType(), structType);
/*  86 */       Type rawType = pt.getRawType();
/*  87 */       if (tpe instanceof CPPType || CPPObject.class.isAssignableFrom(Utils.getClass(rawType))) {
/*     */         
/*  89 */         CPPType cPPType = new CPPType(resolvedOwnerType, rawType, (Object[])resolvedActualTypeArguments);
/*     */       } else {
/*  91 */         DefaultParameterizedType defaultParameterizedType = new DefaultParameterizedType(resolvedOwnerType, rawType, resolvedActualTypeArguments);
/*     */       } 
/*  93 */     } else if (tpe instanceof TypeVariable) {
/*  94 */       TypeVariable tv = (TypeVariable)tpe;
/*  95 */       Class<?> structClass = Utils.getClass(structType);
/*  96 */       TypeVariable[] typeParameters = (TypeVariable[])structClass.getTypeParameters();
/*  97 */       int i = Arrays.<TypeVariable>asList(typeParameters).indexOf(tv);
/*     */       
/*  99 */       if (i >= 0) {
/* 100 */         if (structType instanceof ParameterizedType) {
/* 101 */           ParameterizedType pt = (ParameterizedType)structType;
/*     */           
/* 103 */           ret = pt.getActualTypeArguments()[i];
/*     */         } else {
/* 105 */           throw new RuntimeException("Type " + structType + " does not have params, cannot resolve " + tpe);
/*     */         } 
/*     */       } else {
/* 108 */         throw new RuntimeException("Type param " + tpe + " not found in params of " + structType + " (" + Arrays.asList(typeParameters) + ")");
/*     */       } 
/*     */     } else {
/* 111 */       ret = tpe;
/*     */     } 
/*     */     
/* 114 */     assert !Utils.containsTypeVariables(ret);
/*     */ 
/*     */     
/* 117 */     return ret;
/*     */   }
/*     */   
/*     */   static StructFieldDescription aggregateDeclarations(Type structType, List<StructFieldDeclaration> fieldGroup) {
/* 121 */     StructFieldDescription aggregatedField = new StructFieldDescription();
/* 122 */     boolean isMultiFields = (fieldGroup.size() > 1);
/* 123 */     aggregatedField.aggregatedFields.addAll(fieldGroup);
/* 124 */     for (StructFieldDeclaration field : fieldGroup) {
/* 125 */       if (field.valueClass.isArray()) {
/* 126 */         throw new RuntimeException("Struct fields cannot be array types : please use a combination of Pointer and @Array (for instance, an int[10] is a @Array(10) Pointer<Integer>).");
/*     */       }
/* 128 */       if (field.valueClass.isPrimitive()) {
/* 129 */         if (field.desc.isCLong) {
/* 130 */           field.desc.byteLength = CLong.SIZE;
/* 131 */         } else if (field.desc.isSizeT) {
/* 132 */           field.desc.byteLength = SizeT.SIZE;
/*     */         } else {
/* 134 */           field.desc.byteLength = StructUtils.primTypeLength(field.valueClass);
/* 135 */           if (field.desc.alignment < 0L)
/* 136 */             field.desc.alignment = StructUtils.primTypeAlignment(field.valueClass, field.desc.byteLength); 
/*     */         } 
/* 138 */       } else if (field.valueClass == CLong.class) {
/* 139 */         field.desc.byteLength = CLong.SIZE;
/* 140 */       } else if (field.valueClass == SizeT.class) {
/* 141 */         field.desc.byteLength = SizeT.SIZE;
/* 142 */       } else if (StructObject.class.isAssignableFrom(field.valueClass)) {
/* 143 */         field.desc.nativeTypeOrPointerTargetType = resolveType(field.desc.valueType, structType);
/* 144 */         StructDescription desc = (StructIO.getInstance(field.valueClass, field.desc.valueType)).desc;
/* 145 */         field.desc.byteLength = desc.getStructSize();
/* 146 */         if (field.desc.alignment < 0L)
/* 147 */           field.desc.alignment = desc.getStructAlignment(); 
/* 148 */         field.desc.isNativeObject = true;
/* 149 */       } else if (ValuedEnum.class.isAssignableFrom(field.valueClass)) {
/* 150 */         field.desc.nativeTypeOrPointerTargetType = resolveType((field.desc.valueType instanceof ParameterizedType) ? PointerIO.getClass(((ParameterizedType)field.desc.valueType).getActualTypeArguments()[0]) : null, structType);
/* 151 */         Class<?> c = PointerIO.getClass(field.desc.nativeTypeOrPointerTargetType);
/* 152 */         if (IntValuedEnum.class.isAssignableFrom(c)) {
/* 153 */           field.desc.byteLength = 4L;
/*     */         } else {
/* 155 */           throw new RuntimeException("Enum type unknown : " + c);
/*     */         }
/*     */       
/* 158 */       } else if (TypedPointer.class.isAssignableFrom(field.valueClass)) {
/* 159 */         field.desc.nativeTypeOrPointerTargetType = resolveType(field.desc.valueType, structType);
/* 160 */         if (field.desc.isArray) {
/* 161 */           throw new RuntimeException("Typed pointer field cannot be an array : " + field.desc.name);
/*     */         }
/* 163 */         field.desc.byteLength = Pointer.SIZE;
/*     */       }
/* 165 */       else if (Pointer.class.isAssignableFrom(field.valueClass)) {
/* 166 */         Type tpe = (field.desc.valueType instanceof ParameterizedType) ? ((ParameterizedType)field.desc.valueType).getActualTypeArguments()[0] : null;
/* 167 */         field.desc.nativeTypeOrPointerTargetType = resolveType(tpe, structType);
/* 168 */         if (field.desc.isArray) {
/* 169 */           field.desc.byteLength = BridJ.sizeOf(field.desc.nativeTypeOrPointerTargetType);
/* 170 */           if (field.desc.alignment < 0L)
/* 171 */             field.desc.alignment = StructUtils.alignmentOf(field.desc.nativeTypeOrPointerTargetType); 
/*     */         } else {
/* 173 */           field.desc.byteLength = Pointer.SIZE;
/*     */         }
/*     */       
/* 176 */       } else if (Buffer.class.isAssignableFrom(field.valueClass)) {
/* 177 */         if (field.valueClass == IntBuffer.class) {
/* 178 */           field.desc.byteLength = 4L;
/* 179 */         } else if (field.valueClass == LongBuffer.class) {
/* 180 */           field.desc.byteLength = 8L;
/* 181 */         } else if (field.valueClass == ShortBuffer.class) {
/* 182 */           field.desc.byteLength = 2L;
/* 183 */         } else if (field.valueClass == ByteBuffer.class) {
/* 184 */           field.desc.byteLength = 1L;
/* 185 */         } else if (field.valueClass == FloatBuffer.class) {
/* 186 */           field.desc.byteLength = 4L;
/* 187 */         } else if (field.valueClass == DoubleBuffer.class) {
/* 188 */           field.desc.byteLength = 8L;
/*     */         } else {
/* 190 */           throw new UnsupportedOperationException("Field array type " + field.valueClass.getName() + " not supported yet");
/*     */         } 
/* 192 */       } else if (field.valueClass.isArray() && field.valueClass.getComponentType().isPrimitive()) {
/* 193 */         field.desc.byteLength = StructUtils.primTypeLength(field.valueClass.getComponentType());
/* 194 */         if (field.desc.alignment < 0L) {
/* 195 */           field.desc.alignment = StructUtils.primTypeAlignment(field.valueClass, field.desc.byteLength);
/*     */         }
/*     */       } else {
/* 198 */         StructDescription desc = (StructIO.getInstance(field.valueClass, field.desc.valueType)).desc;
/* 199 */         long s = desc.getStructSize();
/* 200 */         if (s > 0L) {
/* 201 */           field.desc.byteLength = s;
/*     */         } else {
/* 203 */           throw new UnsupportedOperationException("Field type " + field.valueClass.getName() + " not supported yet");
/*     */         } 
/*     */       } 
/*     */       
/* 207 */       aggregatedField.alignment = Math.max(aggregatedField.alignment, (field.desc.alignment >= 0L) ? field.desc.alignment : field.desc.byteLength);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 213 */       long length = field.desc.arrayLength * field.desc.byteLength;
/* 214 */       if (length >= aggregatedField.byteLength) {
/* 215 */         aggregatedField.byteLength = length;
/*     */       }
/*     */       
/* 218 */       if (field.desc.bitLength >= 0L) {
/* 219 */         if (isMultiFields) {
/* 220 */           throw new RuntimeException("No support for bit fields unions yet !");
/*     */         }
/* 222 */         aggregatedField.bitLength = field.desc.bitLength;
/* 223 */         aggregatedField.byteLength = (aggregatedField.bitLength >>> 3L) + (((aggregatedField.bitLength & 0x7L) != 0L) ? 1L : 0L);
/*     */       } 
/*     */     } 
/* 226 */     return aggregatedField;
/*     */   }
/*     */   
/*     */   void computeBitMask() {
/* 230 */     if (this.bitLength < 0L) {
/* 231 */       this.bitMask = -1L;
/*     */     } else {
/* 233 */       this.bitMask = 0L;
/* 234 */       for (int i = 0; i < this.bitLength; i++) {
/* 235 */         this.bitMask = this.bitMask << 1L | 0x1L;
/*     */       }
/* 237 */       this.bitMask <<= (int)this.bitOffset;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\StructFieldDescription.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */