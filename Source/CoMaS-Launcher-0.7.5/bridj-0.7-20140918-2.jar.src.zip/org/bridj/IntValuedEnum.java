package org.bridj;

public interface IntValuedEnum<E extends Enum<E>> extends ValuedEnum<E> {}
