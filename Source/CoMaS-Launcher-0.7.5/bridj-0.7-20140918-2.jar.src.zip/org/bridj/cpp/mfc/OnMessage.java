package org.bridj.cpp.mfc;

public @interface OnMessage {
  Type value();
  
  public enum Type {
    WM_KEYDOWN("OnKeyDown", AFXSignature.AfxSig_vwww),
    WM_LBUTTONDOWN("OnLButtonDown", AFXSignature.AfxSig_vwp);
    
    final String defaultName;
    
    final AFXSignature afxSig;
    
    Type(String defaultName, AFXSignature afxSig) {
      this.afxSig = afxSig;
      this.defaultName = defaultName;
    }
  }
}
