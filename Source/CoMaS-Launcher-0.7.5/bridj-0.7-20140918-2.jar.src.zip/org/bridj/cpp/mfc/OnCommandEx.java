package org.bridj.cpp.mfc;

public @interface OnCommandEx {
  int[] value();
}
