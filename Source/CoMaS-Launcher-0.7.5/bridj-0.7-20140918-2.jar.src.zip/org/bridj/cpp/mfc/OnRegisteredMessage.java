package org.bridj.cpp.mfc;

public @interface OnRegisteredMessage {
  String value();
}
