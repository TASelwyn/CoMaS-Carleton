/*    */ package org.bridj.cpp.mfc;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageMapBuilder
/*    */ {
/*    */   void add(Method method, OnCommand onCommand) {
/* 42 */     throw new UnsupportedOperationException("Not yet implemented");
/*    */   }
/*    */   
/*    */   void add(Method method, OnCommandEx onCommandEx) {
/* 46 */     throw new UnsupportedOperationException("Not yet implemented");
/*    */   }
/*    */   
/*    */   void add(Method method, OnUpdateCommand onUpdateCommand) {
/* 50 */     throw new UnsupportedOperationException("Not yet implemented");
/*    */   }
/*    */   
/*    */   void add(Method method, OnRegisteredMessage onRegisteredMessage) {
/* 54 */     throw new UnsupportedOperationException("Not yet implemented");
/*    */   }
/*    */   
/*    */   void add(Method method, OnMessage onMessage) {
/* 58 */     throw new UnsupportedOperationException("Not yet implemented");
/*    */   }
/*    */   
/*    */   boolean isEmpty() {
/* 62 */     throw new UnsupportedOperationException("Not yet implemented");
/*    */   }
/*    */   
/*    */   void register(MFCRuntime rt, Class<?> type) {
/* 66 */     throw new UnsupportedOperationException("Not yet implemented");
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\mfc\MessageMapBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */