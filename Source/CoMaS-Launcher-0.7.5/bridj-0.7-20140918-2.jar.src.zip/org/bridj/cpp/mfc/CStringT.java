package org.bridj.cpp.mfc;

import org.bridj.cpp.CPPObject;

public class CStringT<BaseType, StringTraits> extends CPPObject {
  Class<BaseType> BaseType;
  
  Class<StringTraits> StringTraits;
}
