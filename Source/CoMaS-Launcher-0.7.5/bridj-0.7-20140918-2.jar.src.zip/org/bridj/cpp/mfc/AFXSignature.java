/*    */ package org.bridj.cpp.mfc;
/*    */ 
/*    */ import org.bridj.Pointer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum AFXSignature
/*    */ {
/* 37 */   AfxSig_vwww(void.class, new Class[] { int.class, int.class, int.class }),
/* 38 */   AfxSig_vwp(void.class, new Class[] { Pointer.class, CPoint.class });
/*    */   
/*    */   AFXSignature(Class<?> returnType, Class<?>... paramTypes) {
/* 41 */     this.returnType = returnType;
/* 42 */     this.paramTypes = paramTypes;
/*    */   }
/*    */   
/*    */   final Class<?> returnType;
/*    */   final Class<?>[] paramTypes;
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\mfc\AFXSignature.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */