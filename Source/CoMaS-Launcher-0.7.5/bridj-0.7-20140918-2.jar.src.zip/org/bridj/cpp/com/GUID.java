/*     */ package org.bridj.cpp.com;
/*     */ 
/*     */ import org.bridj.CRuntime;
/*     */ import org.bridj.Pointer;
/*     */ import org.bridj.StructObject;
/*     */ import org.bridj.ann.Array;
/*     */ import org.bridj.ann.Field;
/*     */ import org.bridj.ann.Runtime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Runtime(CRuntime.class)
/*     */ public class GUID
/*     */   extends StructObject
/*     */ {
/*     */   @Field(0)
/*     */   public int Data1() {
/*  57 */     return this.io.getIntField(this, 0);
/*     */   }
/*     */   
/*     */   @Field(0)
/*     */   public GUID Data1(int Data1) {
/*  62 */     this.io.setIntField(this, 0, Data1);
/*  63 */     return this;
/*     */   }
/*     */   
/*     */   public final int Data1_$eq(int Data1) {
/*  67 */     Data1(Data1);
/*  68 */     return Data1;
/*     */   }
/*     */   
/*     */   @Field(1)
/*     */   public short Data2() {
/*  73 */     return this.io.getShortField(this, 1);
/*     */   }
/*     */   
/*     */   @Field(1)
/*     */   public GUID Data2(short Data2) {
/*  78 */     this.io.setShortField(this, 1, Data2);
/*  79 */     return this;
/*     */   }
/*     */   
/*     */   public final short Data2_$eq(short Data2) {
/*  83 */     Data2(Data2);
/*  84 */     return Data2;
/*     */   }
/*     */   
/*     */   @Field(2)
/*     */   public short Data3() {
/*  89 */     return this.io.getShortField(this, 2);
/*     */   }
/*     */   
/*     */   @Field(2)
/*     */   public GUID Data3(short Data3) {
/*  94 */     this.io.setShortField(this, 2, Data3);
/*  95 */     return this;
/*     */   }
/*     */   
/*     */   public final short Data3_$eq(short Data3) {
/*  99 */     Data3(Data3);
/* 100 */     return Data3;
/*     */   }
/*     */ 
/*     */   
/*     */   @Array({8L})
/*     */   @Field(3)
/*     */   public Pointer<Byte> Data4() {
/* 107 */     return this.io.getPointerField(this, 3);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\com\GUID.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */