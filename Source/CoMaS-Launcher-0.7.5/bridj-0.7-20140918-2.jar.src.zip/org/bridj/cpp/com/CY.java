/*    */ package org.bridj.cpp.com;
/*    */ 
/*    */ import org.bridj.CRuntime;
/*    */ import org.bridj.StructObject;
/*    */ import org.bridj.ann.Field;
/*    */ import org.bridj.ann.Runtime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Runtime(CRuntime.class)
/*    */ public class CY
/*    */   extends StructObject
/*    */ {
/*    */   @Field(0)
/*    */   public long int64() {
/* 55 */     return this.io.getLongField(this, 0);
/*    */   }
/*    */   
/*    */   @Field(0)
/*    */   public CY int64(long int64) {
/* 60 */     this.io.setLongField(this, 0, int64);
/* 61 */     return this;
/*    */   }
/*    */   
/*    */   public final long int64_$eq(long int64) {
/* 65 */     int64(int64);
/* 66 */     return int64;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\com\CY.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */