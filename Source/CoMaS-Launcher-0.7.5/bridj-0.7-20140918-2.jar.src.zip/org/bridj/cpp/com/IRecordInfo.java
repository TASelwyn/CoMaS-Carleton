package org.bridj.cpp.com;

import org.bridj.Pointer;
import org.bridj.ann.Virtual;

@IID("0000002F-0000-0000-C000-000000000046")
public class IRecordInfo extends IUnknown {
  @Virtual(0)
  public native int RecordInit(Pointer<?> paramPointer);
  
  @Virtual(1)
  public native int RecordClear(Pointer<?> paramPointer);
  
  @Virtual(2)
  public native int RecordCopy(Pointer<?> paramPointer1, Pointer<?> paramPointer2);
  
  @Virtual(3)
  public native int GetGuid(Pointer<GUID> paramPointer);
  
  @Virtual(4)
  public native int GetName(Pointer<Pointer<Byte>> paramPointer);
  
  @Virtual(5)
  public native int GetSize(Pointer<Integer> paramPointer);
  
  @Virtual(6)
  public native int GetTypeInfo(Pointer<Pointer<ITypeInfo>> paramPointer);
  
  @Virtual(7)
  public native int GetField(Pointer<?> paramPointer, Pointer<Byte> paramPointer1, Pointer<VARIANT> paramPointer2);
  
  @Virtual(8)
  public native int GetFieldNoCopy(Pointer<?> paramPointer, Pointer<Byte> paramPointer1, Pointer<VARIANT> paramPointer2, Pointer<Pointer<?>> paramPointer3);
  
  @Virtual(9)
  public native int PutField(int paramInt, Pointer<?> paramPointer, Pointer<Byte> paramPointer1, Pointer<VARIANT> paramPointer2);
  
  @Virtual(10)
  public native int PutFieldNoCopy(int paramInt, Pointer<?> paramPointer, Pointer<Byte> paramPointer1, Pointer<VARIANT> paramPointer2);
  
  @Virtual(11)
  public native int GetFieldNames(Pointer<Integer> paramPointer, Pointer<Pointer<Byte>> paramPointer1);
  
  @Virtual(12)
  public native boolean IsMatchingType(Pointer<IRecordInfo> paramPointer);
  
  @Virtual(13)
  public native Pointer<?> RecordCreate();
  
  @Virtual(14)
  public native int RecordCreateCopy(Pointer<?> paramPointer, Pointer<Pointer<?>> paramPointer1);
  
  @Virtual(15)
  public native int RecordDestroy(Pointer<?> paramPointer);
}
