package org.bridj.cpp.com;

import org.bridj.CRuntime;
import org.bridj.Pointer;
import org.bridj.StructObject;
import org.bridj.ann.Array;
import org.bridj.ann.Field;
import org.bridj.ann.Runtime;

@Runtime(CRuntime.class)
public class SAFEARRAY extends StructObject {
  @Field(0)
  public short cDims() {
    return this.io.getShortField(this, 0);
  }
  
  @Field(0)
  public SAFEARRAY cDims(short cDims) {
    this.io.setShortField(this, 0, cDims);
    return this;
  }
  
  public final short cDims_$eq(short cDims) {
    cDims(cDims);
    return cDims;
  }
  
  @Field(1)
  public short fFeatures() {
    return this.io.getShortField(this, 1);
  }
  
  @Field(1)
  public SAFEARRAY fFeatures(short fFeatures) {
    this.io.setShortField(this, 1, fFeatures);
    return this;
  }
  
  public final short fFeatures_$eq(short fFeatures) {
    fFeatures(fFeatures);
    return fFeatures;
  }
  
  @Field(2)
  public int cbElements() {
    return this.io.getIntField(this, 2);
  }
  
  @Field(2)
  public SAFEARRAY cbElements(int cbElements) {
    this.io.setIntField(this, 2, cbElements);
    return this;
  }
  
  public final int cbElements_$eq(int cbElements) {
    cbElements(cbElements);
    return cbElements;
  }
  
  @Field(3)
  public int cLocks() {
    return this.io.getIntField(this, 3);
  }
  
  @Field(3)
  public SAFEARRAY cLocks(int cLocks) {
    this.io.setIntField(this, 3, cLocks);
    return this;
  }
  
  public final int cLocks_$eq(int cLocks) {
    cLocks(cLocks);
    return cLocks;
  }
  
  @Field(4)
  public Pointer<?> pvData() {
    return this.io.getPointerField(this, 4);
  }
  
  @Field(4)
  public SAFEARRAY pvData(Pointer<?> pvData) {
    this.io.setPointerField(this, 4, pvData);
    return this;
  }
  
  public final Pointer<?> pvData_$eq(Pointer<?> pvData) {
    pvData(pvData);
    return pvData;
  }
  
  @Array({1L})
  @Field(5)
  public Pointer<SAFEARRAYBOUND> rgsabound() {
    return this.io.getPointerField(this, 5);
  }
}
