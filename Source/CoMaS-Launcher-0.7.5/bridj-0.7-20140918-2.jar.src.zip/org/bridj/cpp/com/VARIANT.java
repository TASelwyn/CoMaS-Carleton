/*      */ package org.bridj.cpp.com;
/*      */ 
/*      */ import org.bridj.NativeObject;
/*      */ import org.bridj.Pointer;
/*      */ import org.bridj.StructObject;
/*      */ import org.bridj.ann.CLong;
/*      */ import org.bridj.ann.Field;
/*      */ import org.bridj.ann.Runtime;
/*      */ import org.bridj.ann.Union;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Runtime(COMRuntime.class)
/*      */ public class VARIANT
/*      */   extends StructObject
/*      */ {
/*      */   public VARIANT(Object value) {
/*   51 */     setValue(value);
/*      */   }
/*      */ 
/*      */   
/*      */   public VARIANT() {}
/*      */ 
/*      */   
/*      */   public VARIANT clone() {
/*   59 */     return COMRuntime.clone(this);
/*      */   }
/*      */ 
/*      */   
/*      */   @Field(0)
/*      */   public __VARIANT_NAME_1_union __VARIANT_NAME_1() {
/*   65 */     return (__VARIANT_NAME_1_union)this.io.getNativeObjectField(this, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Union
/*      */   public static class __VARIANT_NAME_1_union
/*      */     extends StructObject
/*      */   {
/*      */     @Field(0)
/*      */     public __tagVARIANT __VARIANT_NAME_2() {
/*   82 */       return (__tagVARIANT)this.io.getNativeObjectField(this, 0);
/*      */     }
/*      */ 
/*      */     
/*      */     @Field(1)
/*      */     public DECIMAL decVal() {
/*   88 */       return (DECIMAL)this.io.getNativeObjectField(this, 1);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class __tagVARIANT
/*      */       extends StructObject
/*      */     {
/*      */       @Field(0)
/*      */       public short vt() {
/*  104 */         return this.io.getShortField(this, 0);
/*      */       }
/*      */ 
/*      */       
/*      */       @Field(0)
/*      */       public __tagVARIANT vt(short vt) {
/*  110 */         this.io.setShortField(this, 0, vt);
/*  111 */         return this;
/*      */       }
/*      */ 
/*      */       
/*      */       public final short vt_$eq(short vt) {
/*  116 */         vt(vt);
/*  117 */         return vt;
/*      */       }
/*      */       
/*      */       @Field(1)
/*      */       public short wReserved1() {
/*  122 */         return this.io.getShortField(this, 1);
/*      */       }
/*      */       
/*      */       @Field(1)
/*      */       public __tagVARIANT wReserved1(short wReserved1) {
/*  127 */         this.io.setShortField(this, 1, wReserved1);
/*  128 */         return this;
/*      */       }
/*      */       
/*      */       public final short wReserved1_$eq(short wReserved1) {
/*  132 */         wReserved1(wReserved1);
/*  133 */         return wReserved1;
/*      */       }
/*      */       
/*      */       @Field(2)
/*      */       public short wReserved2() {
/*  138 */         return this.io.getShortField(this, 2);
/*      */       }
/*      */       
/*      */       @Field(2)
/*      */       public __tagVARIANT wReserved2(short wReserved2) {
/*  143 */         this.io.setShortField(this, 2, wReserved2);
/*  144 */         return this;
/*      */       }
/*      */       
/*      */       public final short wReserved2_$eq(short wReserved2) {
/*  148 */         wReserved2(wReserved2);
/*  149 */         return wReserved2;
/*      */       }
/*      */       
/*      */       @Field(3)
/*      */       public short wReserved3() {
/*  154 */         return this.io.getShortField(this, 3);
/*      */       }
/*      */       
/*      */       @Field(3)
/*      */       public __tagVARIANT wReserved3(short wReserved3) {
/*  159 */         this.io.setShortField(this, 3, wReserved3);
/*  160 */         return this;
/*      */       }
/*      */       
/*      */       public final short wReserved3_$eq(short wReserved3) {
/*  164 */         wReserved3(wReserved3);
/*  165 */         return wReserved3;
/*      */       }
/*      */ 
/*      */       
/*      */       @Field(4)
/*      */       public __VARIANT_NAME_3_union __VARIANT_NAME_3() {
/*  171 */         return (__VARIANT_NAME_3_union)this.io.getNativeObjectField(this, 4);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Union
/*      */       public static class __VARIANT_NAME_3_union
/*      */         extends StructObject
/*      */       {
/*      */         @Field(0)
/*      */         public long llval() {
/*  188 */           return this.io.getLongField(this, 0);
/*      */         }
/*      */ 
/*      */         
/*      */         @Field(0)
/*      */         public __VARIANT_NAME_3_union llval(long llval) {
/*  194 */           this.io.setLongField(this, 0, llval);
/*  195 */           return this;
/*      */         }
/*      */         
/*      */         public final long llval_$eq(long llval) {
/*  199 */           llval(llval);
/*  200 */           return llval;
/*      */         }
/*      */ 
/*      */         
/*      */         @CLong
/*      */         @Field(1)
/*      */         public long lVal() {
/*  207 */           return this.io.getCLongField(this, 1);
/*      */         }
/*      */ 
/*      */         
/*      */         @CLong
/*      */         @Field(1)
/*      */         public __VARIANT_NAME_3_union lVal(long lVal) {
/*  214 */           this.io.setCLongField(this, 1, lVal);
/*  215 */           return this;
/*      */         }
/*      */         
/*      */         public final long lVal_$eq(long lVal) {
/*  219 */           lVal(lVal);
/*  220 */           return lVal;
/*      */         }
/*      */ 
/*      */         
/*      */         @Field(2)
/*      */         public byte bVal() {
/*  226 */           return this.io.getByteField(this, 2);
/*      */         }
/*      */ 
/*      */         
/*      */         @Field(2)
/*      */         public __VARIANT_NAME_3_union bVal(byte bVal) {
/*  232 */           this.io.setByteField(this, 2, bVal);
/*  233 */           return this;
/*      */         }
/*      */         
/*      */         public final byte bVal_$eq(byte bVal) {
/*  237 */           bVal(bVal);
/*  238 */           return bVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(3)
/*      */         public short iVal() {
/*  247 */           return this.io.getShortField(this, 3);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(3)
/*      */         public __VARIANT_NAME_3_union iVal(short iVal) {
/*  256 */           this.io.setShortField(this, 3, iVal);
/*  257 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final short iVal_$eq(short iVal) {
/*  262 */           iVal(iVal);
/*  263 */           return iVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(4)
/*      */         public float fltVal() {
/*  272 */           return this.io.getFloatField(this, 4);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(4)
/*      */         public __VARIANT_NAME_3_union fltVal(float fltVal) {
/*  281 */           this.io.setFloatField(this, 4, fltVal);
/*  282 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final float fltVal_$eq(float fltVal) {
/*  287 */           fltVal(fltVal);
/*  288 */           return fltVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(5)
/*      */         public double dblVal() {
/*  297 */           return this.io.getDoubleField(this, 5);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(5)
/*      */         public __VARIANT_NAME_3_union dblVal(double dblVal) {
/*  306 */           this.io.setDoubleField(this, 5, dblVal);
/*  307 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final double dblVal_$eq(double dblVal) {
/*  312 */           dblVal(dblVal);
/*  313 */           return dblVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(6)
/*      */         public int boolVal() {
/*  322 */           return this.io.getIntField(this, 6);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(6)
/*      */         public __VARIANT_NAME_3_union boolVal(int boolVal) {
/*  331 */           this.io.setIntField(this, 6, boolVal);
/*  332 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final int boolVal_$eq(int boolVal) {
/*  337 */           boolVal(boolVal);
/*  338 */           return boolVal;
/*      */         }
/*      */ 
/*      */         
/*      */         @Field(7)
/*      */         public int bool() {
/*  344 */           return this.io.getIntField(this, 7);
/*      */         }
/*      */ 
/*      */         
/*      */         @Field(7)
/*      */         public __VARIANT_NAME_3_union bool(int bool) {
/*  350 */           this.io.setIntField(this, 7, bool);
/*  351 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final int bool_$eq(int bool) {
/*  356 */           bool(bool);
/*  357 */           return bool;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(8)
/*      */         public int scode() {
/*  366 */           return this.io.getIntField(this, 8);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(8)
/*      */         public __VARIANT_NAME_3_union scode(int scode) {
/*  375 */           this.io.setIntField(this, 8, scode);
/*  376 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final int scode_$eq(int scode) {
/*  381 */           scode(scode);
/*  382 */           return scode;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(9)
/*      */         public CY cyVal() {
/*  391 */           return (CY)this.io.getNativeObjectField(this, 9);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(10)
/*      */         public double date() {
/*  400 */           return this.io.getDoubleField(this, 10);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(10)
/*      */         public __VARIANT_NAME_3_union date(double date) {
/*  409 */           this.io.setDoubleField(this, 10, date);
/*  410 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final double date_$eq(double date) {
/*  415 */           date(date);
/*  416 */           return date;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(11)
/*      */         public Pointer<Byte> bstrVal() {
/*  425 */           return this.io.getPointerField(this, 11);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(11)
/*      */         public __VARIANT_NAME_3_union bstrVal(Pointer<Byte> bstrVal) {
/*  434 */           this.io.setPointerField(this, 11, bstrVal);
/*  435 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Byte> bstrVal_$eq(Pointer<Byte> bstrVal) {
/*  440 */           bstrVal(bstrVal);
/*  441 */           return bstrVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(12)
/*      */         public Pointer<IUnknown> punkVal() {
/*  450 */           return this.io.getPointerField(this, 12);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(12)
/*      */         public __VARIANT_NAME_3_union punkVal(Pointer<IUnknown> punkVal) {
/*  459 */           this.io.setPointerField(this, 12, punkVal);
/*  460 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<IUnknown> punkVal_$eq(Pointer<IUnknown> punkVal) {
/*  465 */           punkVal(punkVal);
/*  466 */           return punkVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(13)
/*      */         public Pointer<IDispatch> pdispVal() {
/*  475 */           return this.io.getPointerField(this, 13);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(13)
/*      */         public __VARIANT_NAME_3_union pdispVal(Pointer<IDispatch> pdispVal) {
/*  484 */           this.io.setPointerField(this, 13, pdispVal);
/*  485 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<IDispatch> pdispVal_$eq(Pointer<IDispatch> pdispVal) {
/*  490 */           pdispVal(pdispVal);
/*  491 */           return pdispVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(14)
/*      */         public Pointer<SAFEARRAY> parray() {
/*  500 */           return this.io.getPointerField(this, 14);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(14)
/*      */         public __VARIANT_NAME_3_union parray(Pointer<SAFEARRAY> parray) {
/*  509 */           this.io.setPointerField(this, 14, parray);
/*  510 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<SAFEARRAY> parray_$eq(Pointer<SAFEARRAY> parray) {
/*  515 */           parray(parray);
/*  516 */           return parray;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(15)
/*      */         public Pointer<Byte> pbVal() {
/*  525 */           return this.io.getPointerField(this, 15);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(15)
/*      */         public __VARIANT_NAME_3_union pbVal(Pointer<Byte> pbVal) {
/*  534 */           this.io.setPointerField(this, 15, pbVal);
/*  535 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Byte> pbVal_$eq(Pointer<Byte> pbVal) {
/*  540 */           pbVal(pbVal);
/*  541 */           return pbVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(16)
/*      */         public Pointer<Short> piVal() {
/*  550 */           return this.io.getPointerField(this, 16);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(16)
/*      */         public __VARIANT_NAME_3_union piVal(Pointer<Short> piVal) {
/*  559 */           this.io.setPointerField(this, 16, piVal);
/*  560 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Short> piVal_$eq(Pointer<Short> piVal) {
/*  565 */           piVal(piVal);
/*  566 */           return piVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(17)
/*      */         public Pointer<CLong> plVal() {
/*  575 */           return this.io.getPointerField(this, 17);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(17)
/*      */         public __VARIANT_NAME_3_union plVal(Pointer<CLong> plVal) {
/*  584 */           this.io.setPointerField(this, 17, plVal);
/*  585 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<CLong> plVal_$eq(Pointer<CLong> plVal) {
/*  590 */           plVal(plVal);
/*  591 */           return plVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(18)
/*      */         public Pointer<Long> pllVal() {
/*  600 */           return this.io.getPointerField(this, 18);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(18)
/*      */         public __VARIANT_NAME_3_union pllVal(Pointer<Long> pllVal) {
/*  609 */           this.io.setPointerField(this, 18, pllVal);
/*  610 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Long> pllVal_$eq(Pointer<Long> pllVal) {
/*  615 */           pllVal(pllVal);
/*  616 */           return pllVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(19)
/*      */         public Pointer<Float> pfltVal() {
/*  625 */           return this.io.getPointerField(this, 19);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(19)
/*      */         public __VARIANT_NAME_3_union pfltVal(Pointer<Float> pfltVal) {
/*  634 */           this.io.setPointerField(this, 19, pfltVal);
/*  635 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Float> pfltVal_$eq(Pointer<Float> pfltVal) {
/*  640 */           pfltVal(pfltVal);
/*  641 */           return pfltVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(20)
/*      */         public Pointer<Double> pdblVal() {
/*  650 */           return this.io.getPointerField(this, 20);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(20)
/*      */         public __VARIANT_NAME_3_union pdblVal(Pointer<Double> pdblVal) {
/*  659 */           this.io.setPointerField(this, 20, pdblVal);
/*  660 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Double> pdblVal_$eq(Pointer<Double> pdblVal) {
/*  665 */           pdblVal(pdblVal);
/*  666 */           return pdblVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(21)
/*      */         public Pointer<Integer> pboolVal() {
/*  675 */           return this.io.getPointerField(this, 21);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(21)
/*      */         public __VARIANT_NAME_3_union pboolVal(Pointer<Integer> pboolVal) {
/*  684 */           this.io.setPointerField(this, 21, pboolVal);
/*  685 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Integer> pboolVal_$eq(Pointer<Integer> pboolVal) {
/*  690 */           pboolVal(pboolVal);
/*  691 */           return pboolVal;
/*      */         }
/*      */ 
/*      */         
/*      */         @Field(22)
/*      */         public Pointer<Integer> pbool() {
/*  697 */           return this.io.getPointerField(this, 22);
/*      */         }
/*      */ 
/*      */         
/*      */         @Field(22)
/*      */         public __VARIANT_NAME_3_union pbool(Pointer<Integer> pbool) {
/*  703 */           this.io.setPointerField(this, 22, pbool);
/*  704 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Integer> pbool_$eq(Pointer<Integer> pbool) {
/*  709 */           pbool(pbool);
/*  710 */           return pbool;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(23)
/*      */         public Pointer<Integer> pscode() {
/*  719 */           return this.io.getPointerField(this, 23);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(23)
/*      */         public __VARIANT_NAME_3_union pscode(Pointer<Integer> pscode) {
/*  728 */           this.io.setPointerField(this, 23, pscode);
/*  729 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Integer> pscode_$eq(Pointer<Integer> pscode) {
/*  734 */           pscode(pscode);
/*  735 */           return pscode;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(24)
/*      */         public Pointer<CY> pcyVal() {
/*  744 */           return this.io.getPointerField(this, 24);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(24)
/*      */         public __VARIANT_NAME_3_union pcyVal(Pointer<CY> pcyVal) {
/*  753 */           this.io.setPointerField(this, 24, pcyVal);
/*  754 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<CY> pcyVal_$eq(Pointer<CY> pcyVal) {
/*  759 */           pcyVal(pcyVal);
/*  760 */           return pcyVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(25)
/*      */         public Pointer<Double> pdate() {
/*  769 */           return this.io.getPointerField(this, 25);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(25)
/*      */         public __VARIANT_NAME_3_union pdate(Pointer<Double> pdate) {
/*  778 */           this.io.setPointerField(this, 25, pdate);
/*  779 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Double> pdate_$eq(Pointer<Double> pdate) {
/*  784 */           pdate(pdate);
/*  785 */           return pdate;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(26)
/*      */         public Pointer<Pointer<Byte>> pbstrVal() {
/*  794 */           return this.io.getPointerField(this, 26);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(26)
/*      */         public __VARIANT_NAME_3_union pbstrVal(Pointer<Pointer<Byte>> pbstrVal) {
/*  803 */           this.io.setPointerField(this, 26, pbstrVal);
/*  804 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Pointer<Byte>> pbstrVal_$eq(Pointer<Pointer<Byte>> pbstrVal) {
/*  809 */           pbstrVal(pbstrVal);
/*  810 */           return pbstrVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(27)
/*      */         public Pointer<Pointer<IUnknown>> ppunkVal() {
/*  819 */           return this.io.getPointerField(this, 27);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(27)
/*      */         public __VARIANT_NAME_3_union ppunkVal(Pointer<Pointer<IUnknown>> ppunkVal) {
/*  828 */           this.io.setPointerField(this, 27, ppunkVal);
/*  829 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Pointer<IUnknown>> ppunkVal_$eq(Pointer<Pointer<IUnknown>> ppunkVal) {
/*  834 */           ppunkVal(ppunkVal);
/*  835 */           return ppunkVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(28)
/*      */         public Pointer<Pointer<IDispatch>> ppdispVal() {
/*  844 */           return this.io.getPointerField(this, 28);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(28)
/*      */         public __VARIANT_NAME_3_union ppdispVal(Pointer<Pointer<IDispatch>> ppdispVal) {
/*  853 */           this.io.setPointerField(this, 28, ppdispVal);
/*  854 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Pointer<IDispatch>> ppdispVal_$eq(Pointer<Pointer<IDispatch>> ppdispVal) {
/*  859 */           ppdispVal(ppdispVal);
/*  860 */           return ppdispVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(29)
/*      */         public Pointer<Pointer<SAFEARRAY>> pparray() {
/*  869 */           return this.io.getPointerField(this, 29);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(29)
/*      */         public __VARIANT_NAME_3_union pparray(Pointer<Pointer<SAFEARRAY>> pparray) {
/*  878 */           this.io.setPointerField(this, 29, pparray);
/*  879 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Pointer<SAFEARRAY>> pparray_$eq(Pointer<Pointer<SAFEARRAY>> pparray) {
/*  884 */           pparray(pparray);
/*  885 */           return pparray;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(30)
/*      */         public Pointer<VARIANT> pvarVal() {
/*  894 */           return this.io.getPointerField(this, 30);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(30)
/*      */         public __VARIANT_NAME_3_union pvarVal(Pointer<VARIANT> pvarVal) {
/*  903 */           this.io.setPointerField(this, 30, pvarVal);
/*  904 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<VARIANT> pvarVal_$eq(Pointer<VARIANT> pvarVal) {
/*  909 */           pvarVal(pvarVal);
/*  910 */           return pvarVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(31)
/*      */         public Pointer<Pointer<?>> byref() {
/*  919 */           return this.io.getPointerField(this, 31);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(31)
/*      */         public __VARIANT_NAME_3_union byref(Pointer<Pointer<?>> byref) {
/*  928 */           this.io.setPointerField(this, 31, byref);
/*  929 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Pointer<?>> byref_$eq(Pointer<Pointer<?>> byref) {
/*  934 */           byref(byref);
/*  935 */           return byref;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(32)
/*      */         public byte cVal() {
/*  944 */           return this.io.getByteField(this, 32);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(32)
/*      */         public __VARIANT_NAME_3_union cVal(byte cVal) {
/*  953 */           this.io.setByteField(this, 32, cVal);
/*  954 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final byte cVal_$eq(byte cVal) {
/*  959 */           cVal(cVal);
/*  960 */           return cVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(33)
/*      */         public short uiVal() {
/*  969 */           return this.io.getShortField(this, 33);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(33)
/*      */         public __VARIANT_NAME_3_union uiVal(short uiVal) {
/*  978 */           this.io.setShortField(this, 33, uiVal);
/*  979 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final short uiVal_$eq(short uiVal) {
/*  984 */           uiVal(uiVal);
/*  985 */           return uiVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(34)
/*      */         public int ulVal() {
/*  994 */           return this.io.getIntField(this, 34);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(34)
/*      */         public __VARIANT_NAME_3_union ulVal(int ulVal) {
/* 1003 */           this.io.setIntField(this, 34, ulVal);
/* 1004 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final int ulVal_$eq(int ulVal) {
/* 1009 */           ulVal(ulVal);
/* 1010 */           return ulVal;
/*      */         }
/*      */ 
/*      */         
/*      */         @Field(35)
/*      */         public long ullVal() {
/* 1016 */           return this.io.getLongField(this, 35);
/*      */         }
/*      */ 
/*      */         
/*      */         @Field(35)
/*      */         public __VARIANT_NAME_3_union ullVal(long ullVal) {
/* 1022 */           this.io.setLongField(this, 35, ullVal);
/* 1023 */           return this;
/*      */         }
/*      */         
/*      */         public final long ullVal_$eq(long ullVal) {
/* 1027 */           ullVal(ullVal);
/* 1028 */           return ullVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(36)
/*      */         public int intVal() {
/* 1037 */           return this.io.getIntField(this, 36);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(36)
/*      */         public __VARIANT_NAME_3_union intVal(int intVal) {
/* 1046 */           this.io.setIntField(this, 36, intVal);
/* 1047 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final int intVal_$eq(int intVal) {
/* 1052 */           intVal(intVal);
/* 1053 */           return intVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(37)
/*      */         public int uintVal() {
/* 1062 */           return this.io.getIntField(this, 37);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(37)
/*      */         public __VARIANT_NAME_3_union uintVal(int uintVal) {
/* 1071 */           this.io.setIntField(this, 37, uintVal);
/* 1072 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final int uintVal_$eq(int uintVal) {
/* 1077 */           uintVal(uintVal);
/* 1078 */           return uintVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(38)
/*      */         public Pointer<DECIMAL> pdecVal() {
/* 1087 */           return this.io.getPointerField(this, 38);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(38)
/*      */         public __VARIANT_NAME_3_union pdecVal(Pointer<DECIMAL> pdecVal) {
/* 1096 */           this.io.setPointerField(this, 38, pdecVal);
/* 1097 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<DECIMAL> pdecVal_$eq(Pointer<DECIMAL> pdecVal) {
/* 1102 */           pdecVal(pdecVal);
/* 1103 */           return pdecVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(39)
/*      */         public Pointer<Byte> pcVal() {
/* 1112 */           return this.io.getPointerField(this, 39);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(39)
/*      */         public __VARIANT_NAME_3_union pcVal(Pointer<Byte> pcVal) {
/* 1121 */           this.io.setPointerField(this, 39, pcVal);
/* 1122 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Byte> pcVal_$eq(Pointer<Byte> pcVal) {
/* 1127 */           pcVal(pcVal);
/* 1128 */           return pcVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(40)
/*      */         public Pointer<Short> puiVal() {
/* 1137 */           return this.io.getPointerField(this, 40);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(40)
/*      */         public __VARIANT_NAME_3_union puiVal(Pointer<Short> puiVal) {
/* 1146 */           this.io.setPointerField(this, 40, puiVal);
/* 1147 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Short> puiVal_$eq(Pointer<Short> puiVal) {
/* 1152 */           puiVal(puiVal);
/* 1153 */           return puiVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(41)
/*      */         public Pointer<Integer> pulVal() {
/* 1162 */           return this.io.getPointerField(this, 41);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(41)
/*      */         public __VARIANT_NAME_3_union pulVal(Pointer<Integer> pulVal) {
/* 1171 */           this.io.setPointerField(this, 41, pulVal);
/* 1172 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Integer> pulVal_$eq(Pointer<Integer> pulVal) {
/* 1177 */           pulVal(pulVal);
/* 1178 */           return pulVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(42)
/*      */         public Pointer<Long> pullVal() {
/* 1187 */           return this.io.getPointerField(this, 42);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(42)
/*      */         public __VARIANT_NAME_3_union pullVal(Pointer<Long> pullVal) {
/* 1196 */           this.io.setPointerField(this, 42, pullVal);
/* 1197 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Long> pullVal_$eq(Pointer<Long> pullVal) {
/* 1202 */           pullVal(pullVal);
/* 1203 */           return pullVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(43)
/*      */         public Pointer<Integer> pintVal() {
/* 1212 */           return this.io.getPointerField(this, 43);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(43)
/*      */         public __VARIANT_NAME_3_union pintVal(Pointer<Integer> pintVal) {
/* 1221 */           this.io.setPointerField(this, 43, pintVal);
/* 1222 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Integer> pintVal_$eq(Pointer<Integer> pintVal) {
/* 1227 */           pintVal(pintVal);
/* 1228 */           return pintVal;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(44)
/*      */         public Pointer<Integer> puintVal() {
/* 1237 */           return this.io.getPointerField(this, 44);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Field(44)
/*      */         public __VARIANT_NAME_3_union puintVal(Pointer<Integer> puintVal) {
/* 1246 */           this.io.setPointerField(this, 44, puintVal);
/* 1247 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public final Pointer<Integer> puintVal_$eq(Pointer<Integer> puintVal) {
/* 1252 */           puintVal(puintVal);
/* 1253 */           return puintVal;
/*      */         }
/*      */ 
/*      */         
/*      */         @Field(45)
/*      */         public __tagBRECORD __VARIANT_NAME_4() {
/* 1259 */           return (__tagBRECORD)this.io.getNativeObjectField(this, 45);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public static class __tagBRECORD
/*      */           extends StructObject
/*      */         {
/*      */           @Field(0)
/*      */           public Pointer<?> pvRecord() {
/* 1275 */             return this.io.getPointerField(this, 0);
/*      */           }
/*      */ 
/*      */           
/*      */           @Field(0)
/*      */           public __tagBRECORD pvRecord(Pointer<?> pvRecord) {
/* 1281 */             this.io.setPointerField(this, 0, pvRecord);
/* 1282 */             return this;
/*      */           }
/*      */ 
/*      */           
/*      */           public final Pointer<?> pvRecord_$eq(Pointer<?> pvRecord) {
/* 1287 */             pvRecord(pvRecord);
/* 1288 */             return pvRecord;
/*      */           }
/*      */ 
/*      */           
/*      */           @Field(1)
/*      */           public Pointer<IRecordInfo> pRecInfo() {
/* 1294 */             return this.io.getPointerField(this, 1);
/*      */           }
/*      */ 
/*      */           
/*      */           @Field(1)
/*      */           public __tagBRECORD pRecInfo(Pointer<IRecordInfo> pRecInfo) {
/* 1300 */             this.io.setPointerField(this, 1, pRecInfo);
/* 1301 */             return this;
/*      */           }
/*      */ 
/*      */           
/*      */           public final Pointer<IRecordInfo> pRecInfo_$eq(Pointer<IRecordInfo> pRecInfo) {
/* 1306 */             pRecInfo(pRecInfo);
/* 1307 */             return pRecInfo;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public Object getValue() {
/* 1315 */     return COMRuntime.getValue(this);
/*      */   }
/*      */   
/*      */   public VARIANT setValue(Object value) {
/* 1319 */     return COMRuntime.setValue(this, value);
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1324 */     return COMRuntime.toString(this);
/*      */   }
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\com\VARIANT.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */