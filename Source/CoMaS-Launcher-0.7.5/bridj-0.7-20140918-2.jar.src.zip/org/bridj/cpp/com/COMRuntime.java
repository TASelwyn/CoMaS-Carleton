/*     */ package org.bridj.cpp.com;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import org.bridj.BridJ;
/*     */ import org.bridj.BridJRuntime;
/*     */ import org.bridj.CRuntime;
/*     */ import org.bridj.FlagSet;
/*     */ import org.bridj.NativeObject;
/*     */ import org.bridj.NativeObjectInterface;
/*     */ import org.bridj.Platform;
/*     */ import org.bridj.Pointer;
/*     */ import org.bridj.PointerIO;
/*     */ import org.bridj.StructObject;
/*     */ import org.bridj.ValuedEnum;
/*     */ import org.bridj.ann.Convention;
/*     */ import org.bridj.ann.Library;
/*     */ import org.bridj.ann.Ptr;
/*     */ import org.bridj.ann.Runtime;
/*     */ import org.bridj.cpp.CPPObject;
/*     */ import org.bridj.cpp.CPPRuntime;
/*     */ import org.bridj.util.Utils;
/*     */ 
/*     */ @Library("Ole32")
/*     */ @Runtime(CRuntime.class)
/*     */ @Convention(Convention.Style.StdCall)
/*     */ public class COMRuntime extends CPPRuntime {
/*     */   public static final int CLSCTX_INPROC_SERVER = 1;
/*     */   public static final int CLSCTX_INPROC_HANDLER = 2;
/*     */   public static final int CLSCTX_LOCAL_SERVER = 4;
/*     */   public static final int CLSCTX_INPROC_SERVER16 = 8;
/*     */   public static final int CLSCTX_REMOTE_SERVER = 16;
/*     */   public static final int CLSCTX_INPROC_HANDLER16 = 32;
/*     */   public static final int CLSCTX_RESERVED1 = 64;
/*     */   public static final int CLSCTX_RESERVED2 = 128;
/*     */   public static final int CLSCTX_RESERVED3 = 256;
/*     */   public static final int CLSCTX_RESERVED4 = 512;
/*     */   public static final int CLSCTX_NO_CODE_DOWNLOAD = 1024;
/*     */   public static final int CLSCTX_RESERVED5 = 2048;
/*     */   public static final int CLSCTX_NO_CUSTOM_MARSHAL = 4096;
/*     */   public static final int CLSCTX_ENABLE_CODE_DOWNLOAD = 8192;
/*     */   public static final int CLSCTX_NO_FAILURE_LOG = 16384;
/*     */   public static final int CLSCTX_DISABLE_AAA = 32768;
/*     */   public static final int CLSCTX_ENABLE_AAA = 65536;
/*     */   public static final int CLSCTX_FROM_DEFAULT_CONTEXT = 131072;
/*     */   public static final int CLSCTX_ACTIVATE_32_BIT_SERVER = 262144;
/*     */   public static final int CLSCTX_ACTIVATE_64_BIT_SERVER = 524288;
/*     */   public static final int CLSCTX_ENABLE_CLOAKING = 1048576;
/*     */   public static final int CLSCTX_PS_DLL = -2147483648;
/*     */   public static final int CLSCTX_INPROC = 3;
/*     */   public static final int CLSCTX_ALL = 23;
/*     */   public static final int CLSCTX_SERVER = 21;
/*     */   public static final int S_OK = 0;
/*     */   public static final int S_FALSE = 1;
/*     */   public static final int REGDB_E_CLASSNOTREG = -2147221164;
/*     */   public static final int CLASS_E_NOAGGREGATION = -2147221232;
/*     */   public static final int CO_E_NOTINITIALIZED = -2147221008;
/*     */   public static final int E_UNEXPECTED = -2147418113;
/*     */   public static final int E_NOTIMPL = -2147467263;
/*     */   public static final int E_OUTOFMEMORY = -2147024882;
/*     */   public static final int E_INVALIDARG = -2147024809;
/*     */   public static final int E_NOINTERFACE = -2147467262;
/*     */   public static final int E_POINTER = -2147467261;
/*     */   public static final int E_HANDLE = -2147024890;
/*     */   public static final int E_ABORT = -2147467260;
/*     */   public static final int E_FAIL = -2147467259;
/*     */   public static final int E_ACCESSDENIED = -2147024891;
/*     */   public static final int DISP_E_BADVARTYPE = -2147352568;
/*     */   public static final int DISP_E_NOTACOLLECTION = -2147352559;
/*     */   public static final int DISP_E_MEMBERNOTFOUND = -2147352573;
/*     */   public static final int DISP_E_ARRAYISLOCKED = -2147352563;
/*     */   public static final int DISP_E_EXCEPTION = -2147352567;
/*     */   public static final int DISP_E_TYPEMISMATCH = -2147352571;
/*     */   public static final int DISP_E_BADINDEX = -2147352565;
/*     */   public static final int DISP_E_BADCALLEE = -2147352560;
/*     */   public static final int DISP_E_OVERFLOW = -2147352566;
/*     */   public static final int DISP_E_UNKNOWNINTERFACE = -2147352575;
/*     */   public static final int DISP_E_DIVBYZERO = -2147352558;
/*     */   public static final int DISP_E_UNKNOWNLCID = -2147352564;
/*     */   public static final int DISP_E_PARAMNOTOPTIONAL = -2147352561;
/*     */   public static final int DISP_E_PARAMNOTFOUND = -2147352572;
/*     */   public static final int DISP_E_BADPARAMCOUNT = -2147352562;
/*     */   public static final int DISP_E_BUFFERTOOSMALL = -2147352557;
/*     */   public static final int DISP_E_UNKNOWNNAME = -2147352570;
/*     */   public static final int DISP_E_NONAMEDARGS = -2147352569;
/*     */   
/*     */   static {
/*  88 */     if (Platform.isWindows()) {
/*  89 */       BridJ.register();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void error(int err) {
/* 177 */     switch (err) {
/*     */       case 0:
/*     */         return;
/*     */       case -2147418113:
/* 181 */         throw new RuntimeException("Unexpected error");
/*     */       case -2147024882:
/* 183 */         throw new RuntimeException("Memory could not be allocated.");
/*     */       case -2147221008:
/* 185 */         throw new RuntimeException("CoInitialized wasn't called !!");
/*     */       case -2147467262:
/* 187 */         throw new RuntimeException("Interface does not inherit from class");
/*     */       case -2147467261:
/* 189 */         throw new RuntimeException("Allocated pointer pointer is null !!");
/*     */       case -2147352563:
/* 191 */         throw new RuntimeException("The variant contains an array that is locked.");
/*     */       case -2147352568:
/* 193 */         throw new RuntimeException("The variant type is not valid.");
/*     */       case -2147024809:
/* 195 */         throw new RuntimeException("One of the arguments is invalid.");
/*     */     } 
/* 197 */     throw new RuntimeException("Unexpected COM error code : " + err);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <I extends IUnknown> Pointer<Byte> getIID(Class<I> type) {
/* 207 */     IID id = type.<IID>getAnnotation(IID.class);
/* 208 */     if (id == null) {
/* 209 */       throw new RuntimeException("No " + IID.class.getName() + " annotation set on type " + type.getName() + " !");
/*     */     }
/*     */     
/* 212 */     return (Pointer)parseGUID(id.value());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <I extends IUnknown> Pointer<Byte> getCLSID(Class<I> type) {
/* 221 */     CLSID id = type.<CLSID>getAnnotation(CLSID.class);
/* 222 */     if (id == null) {
/* 223 */       throw new RuntimeException("No " + CLSID.class.getName() + " annotation set on type " + type.getName() + " !");
/*     */     }
/*     */     
/* 226 */     return (Pointer)parseGUID(id.value());
/*     */   }
/* 228 */   static ThreadLocal<Object> comInitializer = new ThreadLocal()
/*     */     {
/*     */       protected Object initialValue() {
/* 231 */         COMRuntime.error(COMRuntime.CoInitializeEx(0L, 0));
/* 232 */         return new Object()
/*     */           {
/*     */             protected void finalize() throws Throwable {
/* 235 */               COMRuntime.CoUninitialize();
/*     */             }
/*     */           };
/*     */       }
/*     */     };
/*     */   private static final String model = "00000000-0000-0000-0000-000000000000";
/*     */   
/*     */   protected boolean isSymbolOptional(Method method) {
/* 243 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initialize() {
/* 254 */     comInitializer.get();
/*     */   }
/*     */   
/*     */   public static <I extends IUnknown> I newInstance(Class<I> type) throws ClassNotFoundException {
/* 258 */     return newInstance(type, type);
/*     */   }
/*     */   
/*     */   public static <T extends IUnknown, I extends IUnknown> I newInstance(Class<T> instanceClass, Class<I> instanceInterface) throws ClassNotFoundException {
/* 262 */     initialize();
/*     */     
/* 264 */     Pointer<Pointer<?>> p = Pointer.allocatePointer();
/* 265 */     Pointer<Byte> clsid = getCLSID(instanceClass), uuid = getIID(instanceInterface);
/*     */     try {
/* 267 */       int ret = CoCreateInstance(clsid, (Pointer<IUnknown>)null, 23, uuid, p);
/* 268 */       if (ret == -2147221164) {
/* 269 */         throw new ClassNotFoundException("COM class is not registered : " + instanceClass.getSimpleName() + " (clsid = " + clsid.getCString() + ")");
/*     */       }
/* 271 */       error(ret);
/*     */       
/* 273 */       Pointer<?> inst = p.getPointer();
/* 274 */       if (inst == null) {
/* 275 */         throw new RuntimeException("Serious low-level issue : CoCreateInstance executed fine but we only retrieved a null pointer !");
/*     */       }
/*     */       
/* 278 */       IUnknown iUnknown = (IUnknown)inst.getNativeObject(instanceInterface);
/* 279 */       return (I)iUnknown;
/*     */     } finally {
/* 281 */       Pointer.release(new Pointer[] { p, clsid, uuid });
/*     */     } 
/*     */   }
/*     */   
/*     */   public class VARIANTTypeInfo extends CRuntime.CTypeInfo<VARIANT> { Pointer.Releaser VARIANTReleaser;
/*     */     
/*     */     public VARIANTTypeInfo() {
/* 288 */       super((CRuntime)COMRuntime.this, VARIANT.class);
/*     */       
/* 290 */       this.VARIANTReleaser = new Pointer.Releaser()
/*     */         {
/*     */           public void release(Pointer<?> p) {
/* 293 */             COMRuntime.error(OLEAutomationLibrary.VariantClear((Pointer)p));
/*     */           }
/*     */         };
/*     */     }
/*     */     
/*     */     public void initialize(VARIANT instance, int constructorId, Object... args) {
/* 299 */       assert constructorId < 0 && args.length == 0;
/* 300 */       Pointer<VARIANT> peer = COMRuntime.this.<V>allocateCOMMemory(this.pointerIO).withReleaser(this.VARIANTReleaser);
/* 301 */       COMRuntime.this.setNativeObjectPeer((NativeObjectInterface)instance, peer);
/* 302 */       OLEAutomationLibrary.VariantInit(peer);
/*     */     }
/*     */ 
/*     */     
/*     */     public VARIANT clone(VARIANT instance) throws CloneNotSupportedException {
/* 307 */       return COMRuntime.clone(instance);
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends NativeObject> BridJRuntime.TypeInfo<T> getTypeInfo(Type type) {
/* 313 */     if (type == VARIANT.class)
/* 314 */       return (BridJRuntime.TypeInfo<T>)new VARIANTTypeInfo(); 
/* 315 */     if (type instanceof Class) {
/* 316 */       if (CPPObject.class.isAssignableFrom((Class)type)) {
/* 317 */         return (BridJRuntime.TypeInfo)new CPPRuntime.CPPTypeInfo<CPPObject>(type)
/*     */           {
/*     */             protected <V> Pointer<V> allocateStructMemory(PointerIO<V> pointerIO) {
/* 320 */               return COMRuntime.this.allocateCOMMemory(pointerIO);
/*     */             }
/*     */           };
/*     */       }
/* 324 */       if (StructObject.class.isAssignableFrom((Class)type)) {
/* 325 */         return (BridJRuntime.TypeInfo<T>)new CRuntime.CTypeInfo<T>(type)
/*     */           {
/*     */             protected <V> Pointer<V> allocateStructMemory(PointerIO<V> pointerIO) {
/* 328 */               return COMRuntime.this.allocateCOMMemory(pointerIO);
/*     */             }
/*     */           };
/*     */       }
/*     */     } 
/* 333 */     return super.getTypeInfo(type);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Pointer<?> parseGUID(String descriptor) {
/* 339 */     Pointer<?> out = Pointer.allocateBytes(20L);
/* 340 */     descriptor = descriptor.replaceAll("-", "");
/* 341 */     if (descriptor.length() != 32) {
/* 342 */       throw new RuntimeException("Expected something like :\n00000000-0000-0000-0000-000000000000\nBut got instead :\n" + descriptor);
/*     */     }
/*     */     
/* 345 */     out.setIntAtOffset(0L, (int)Long.parseLong(descriptor.substring(0, 8), 16));
/* 346 */     out.setShortAtOffset(4L, (short)(int)Long.parseLong(descriptor.substring(8, 12), 16));
/* 347 */     out.setShortAtOffset(6L, (short)(int)Long.parseLong(descriptor.substring(12, 16), 16));
/* 348 */     for (int i = 0; i < 8; i++) {
/* 349 */       out.setByteAtOffset((8 + i), (byte)(int)Long.parseLong(descriptor.substring(16 + i * 2, 16 + i * 2 + 2), 16));
/*     */     }
/*     */     
/* 352 */     return out;
/*     */   }
/*     */   
/*     */   static ValuedEnum<VARENUM> getType(VARIANT v) {
/* 356 */     VARIANT.__VARIANT_NAME_1_union v1 = v.__VARIANT_NAME_1();
/* 357 */     VARIANT.__VARIANT_NAME_1_union.__tagVARIANT v2 = v1.__VARIANT_NAME_2();
/* 358 */     short vt = v2.vt();
/* 359 */     return (ValuedEnum<VARENUM>)FlagSet.fromValue(vt, VARENUM.class);
/*     */   }
/*     */   
/*     */   static VARIANT setType(VARIANT v, ValuedEnum<VARENUM> vt) {
/* 363 */     VARIANT.__VARIANT_NAME_1_union v1 = v.__VARIANT_NAME_1();
/* 364 */     VARIANT.__VARIANT_NAME_1_union.__tagVARIANT v2 = v1.__VARIANT_NAME_2();
/* 365 */     v2.vt((short)(int)vt.value());
/* 366 */     return v;
/*     */   }
/*     */   
/*     */   static VARIANT.__VARIANT_NAME_1_union.__tagVARIANT.__VARIANT_NAME_3_union getValues(VARIANT v) {
/* 370 */     VARIANT.__VARIANT_NAME_1_union v1 = v.__VARIANT_NAME_1();
/* 371 */     VARIANT.__VARIANT_NAME_1_union.__tagVARIANT v2 = v1.__VARIANT_NAME_2();
/* 372 */     VARIANT.__VARIANT_NAME_1_union.__tagVARIANT.__VARIANT_NAME_3_union v3 = v2.__VARIANT_NAME_3();
/* 373 */     return v3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getValue(VARIANT v) {
/* 385 */     FlagSet<VARENUM> vt = FlagSet.fromValue(getType(v));
/* 386 */     VARIANT.__VARIANT_NAME_1_union.__tagVARIANT.__VARIANT_NAME_3_union values = getValues(v);
/* 387 */     if (vt.has((Enum[])new VARENUM[] { VARENUM.VT_BYREF })) {
/* 388 */       switch ((VARENUM)vt.without((Enum[])new VARENUM[] { VARENUM.VT_BYREF }).toEnum()) {
/*     */         case VT_DISPATCH:
/* 390 */           return values.ppdispVal();
/*     */         case VT_UNKNOWN:
/* 392 */           return values.ppunkVal();
/*     */         case VT_VARIANT:
/* 394 */           return values.pvarVal();
/*     */         case VT_I1:
/*     */         case VT_UI1:
/* 397 */           return values.pbVal();
/*     */         
/*     */         case VT_I2:
/*     */         case VT_UI2:
/* 401 */           return values.piVal();
/*     */         
/*     */         case VT_I4:
/*     */         case VT_UI4:
/* 405 */           return values.plVal();
/*     */         case VT_R4:
/* 407 */           return values.pfltVal();
/*     */         case VT_R8:
/* 409 */           return values.pdblVal();
/*     */         
/*     */         case VT_I8:
/*     */         case VT_UI8:
/* 413 */           return values.pllVal();
/*     */         
/*     */         case VT_BOOL:
/* 416 */           return values.pbVal().as(Boolean.class);
/*     */         
/*     */         case VT_BSTR:
/* 419 */           return values.pbstrVal();
/*     */         case VT_LPSTR:
/* 421 */           return values.byref().getCString();
/*     */         case VT_LPWSTR:
/* 423 */           return values.byref().getWideCString();
/*     */       } 
/*     */       
/* 426 */       return values.byref();
/*     */     } 
/*     */     
/* 429 */     switch ((VARENUM)vt.toEnum()) {
/*     */       
/*     */       case VT_I1:
/*     */       case VT_UI1:
/* 433 */         return Byte.valueOf(values.bVal());
/*     */       
/*     */       case VT_I2:
/*     */       case VT_UI2:
/* 437 */         return Short.valueOf(values.uiVal());
/*     */       
/*     */       case VT_I4:
/*     */       case VT_UI4:
/* 441 */         return Integer.valueOf(values.ulVal());
/*     */       
/*     */       case VT_I8:
/*     */       case VT_UI8:
/* 445 */         return Long.valueOf(values.ullVal());
/*     */       
/*     */       case VT_BOOL:
/* 448 */         return Boolean.valueOf((values.bVal() != 0));
/*     */       case VT_R4:
/* 450 */         return Float.valueOf(values.fltVal());
/*     */       case VT_R8:
/* 452 */         return Double.valueOf(values.dblVal());
/*     */       case VT_BSTR:
/* 454 */         return values.bstrVal().getString(Pointer.StringType.BSTR);
/*     */       case VT_EMPTY:
/* 456 */         return null;
/*     */     } 
/* 458 */     throw new UnsupportedOperationException("Conversion not implemented yet from VARIANT type " + vt + " to Java !");
/*     */   }
/*     */ 
/*     */   
/*     */   static void change(VARIANT v, ValuedEnum<VARENUM> vt) {
/* 463 */     Pointer<VARIANT> pv = Pointer.getPointer((NativeObject)v);
/* 464 */     int res = OLEAutomationLibrary.VariantChangeType(pv, pv, (short)0, (short)(int)vt.value());
/* 465 */     assert res == 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public static VARIANT setValue(VARIANT v, Object value) {
/* 470 */     VARIANT.__VARIANT_NAME_1_union.__tagVARIANT.__VARIANT_NAME_3_union values = getValues(v);
/* 471 */     if (value == null) {
/* 472 */       change(v, (ValuedEnum<VARENUM>)VARENUM.VT_EMPTY);
/*     */     }
/* 474 */     else if (value instanceof Integer) {
/* 475 */       change(v, (ValuedEnum<VARENUM>)VARENUM.VT_I4);
/* 476 */       values.lVal(((Integer)value).intValue());
/* 477 */     } else if (value instanceof Long) {
/* 478 */       change(v, (ValuedEnum<VARENUM>)VARENUM.VT_I8);
/* 479 */       values.llval(((Long)value).longValue());
/* 480 */     } else if (value instanceof Short) {
/* 481 */       change(v, (ValuedEnum<VARENUM>)VARENUM.VT_I2);
/* 482 */       values.iVal(((Short)value).shortValue());
/* 483 */     } else if (value instanceof Byte) {
/* 484 */       change(v, (ValuedEnum<VARENUM>)VARENUM.VT_I1);
/* 485 */       values.bVal(((Byte)value).byteValue());
/* 486 */     } else if (value instanceof Float) {
/* 487 */       change(v, (ValuedEnum<VARENUM>)VARENUM.VT_R4);
/* 488 */       values.fltVal(((Float)value).floatValue());
/* 489 */     } else if (value instanceof Double) {
/* 490 */       change(v, (ValuedEnum<VARENUM>)VARENUM.VT_I8);
/* 491 */       values.dblVal(((Double)value).doubleValue());
/* 492 */     } else if (value instanceof Character) {
/* 493 */       change(v, (ValuedEnum<VARENUM>)VARENUM.VT_I2);
/* 494 */       values.iVal((short)((Character)value).charValue());
/* 495 */     } else if (value instanceof String) {
/* 496 */       change(v, (ValuedEnum<VARENUM>)VARENUM.VT_BSTR);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 505 */       values.bstrVal().setString((String)value, Pointer.StringType.BSTR);
/* 506 */     } else if (value instanceof Pointer) {
/* 507 */       Pointer ptr = (Pointer)value;
/* 508 */       Type targetType = ptr.getTargetType();
/* 509 */       Class<Integer> targetClass = Utils.getClass(targetType);
/* 510 */       if (targetClass == null) {
/* 511 */         change(v, (ValuedEnum<VARENUM>)VARENUM.VT_PTR);
/*     */       } else {
/*     */         VARENUM ve;
/* 514 */         if (targetClass == Integer.class || targetClass == int.class) {
/* 515 */           ve = VARENUM.VT_I4;
/* 516 */         } else if (targetClass == Long.class || targetClass == long.class) {
/* 517 */           ve = VARENUM.VT_I8;
/* 518 */         } else if (targetClass == Short.class || targetClass == short.class) {
/* 519 */           ve = VARENUM.VT_I2;
/* 520 */         } else if (targetClass == Byte.class || targetClass == byte.class) {
/* 521 */           ve = VARENUM.VT_I1;
/* 522 */         } else if (targetClass == Character.class || targetClass == char.class) {
/* 523 */           ve = VARENUM.VT_LPWSTR;
/* 524 */         } else if (targetClass == Boolean.class || targetClass == boolean.class) {
/* 525 */           ve = VARENUM.VT_BOOL;
/* 526 */         } else if (targetClass == Float.class || targetClass == float.class) {
/* 527 */           ve = VARENUM.VT_R4;
/* 528 */         } else if (targetClass == Double.class || targetClass == double.class) {
/* 529 */           ve = VARENUM.VT_R8;
/* 530 */         } else if (Pointer.class.isAssignableFrom(targetClass)) {
/* 531 */           ve = VARENUM.VT_PTR;
/*     */         } else {
/* 533 */           ve = null;
/*     */         } 
/* 535 */         change(v, (ValuedEnum<VARENUM>)FlagSet.fromValues((Enum[])new VARENUM[] { VARENUM.VT_BYREF, ve }));
/*     */       } 
/*     */     } else {
/* 538 */       throw new UnsupportedOperationException("Unable to convert an object of type " + value.getClass().getName() + " to a COM VARIANT object !");
/*     */     } 
/*     */ 
/*     */     
/* 542 */     return v;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean warnAboutMissingVTables() {
/* 547 */     return false;
/*     */   }
/*     */   
/*     */   public static String toString(VARIANT v) {
/* 551 */     StringBuilder b = new StringBuilder("Variant(value = ");
/*     */     try {
/* 553 */       b.append(getValue(v));
/* 554 */     } catch (Throwable th) {
/* 555 */       b.append("?");
/*     */     } 
/* 557 */     b.append(", type = ").append(getType(v)).append(")");
/*     */     
/* 559 */     return b.toString();
/*     */   }
/*     */   
/*     */   public static VARIANT clone(VARIANT instance) {
/* 563 */     if (instance == null) {
/* 564 */       return null;
/*     */     }
/* 566 */     VARIANT clone = new VARIANT();
/* 567 */     error(OLEAutomationLibrary.VariantCopy(Pointer.getPointer((NativeObject)clone), Pointer.getPointer((NativeObject)instance)));
/* 568 */     return clone;
/*     */   }
/*     */   
/*     */   protected <V> Pointer<V> allocateCOMMemory(PointerIO<V> pointerIO) {
/* 572 */     return allocateCOMMemory(pointerIO.getTargetSize(), pointerIO);
/*     */   }
/*     */   
/*     */   public static <V> Pointer<V> allocateCOMMemory(long byteCount, PointerIO<V> pointerIO) {
/* 576 */     if (byteCount <= 0L) {
/* 577 */       return null;
/*     */     }
/* 579 */     long peer = OLELibrary.CoTaskMemAlloc$raw(byteCount);
/* 580 */     if (peer == 0L) {
/* 581 */       throw new OutOfMemoryError("Failed to allocate " + byteCount + " bytes with CoTaskMemAlloc");
/*     */     }
/* 583 */     Pointer<V> p = Pointer.pointerToAddress(peer, byteCount, pointerIO, new Pointer.Releaser() {
/*     */           public void release(Pointer<?> p) {
/* 585 */             OLELibrary.CoTaskMemFree(p);
/*     */           }
/*     */         });
/* 588 */     if (p != null) {
/* 589 */       p.clearValidBytes();
/*     */     }
/* 591 */     return p;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static native int CoCreateInstance(Pointer<Byte> paramPointer1, Pointer<IUnknown> paramPointer, int paramInt, Pointer<Byte> paramPointer2, Pointer<Pointer<?>> paramPointer3);
/*     */   
/*     */   static native int CoInitializeEx(@Ptr long paramLong, int paramInt);
/*     */   
/*     */   static native int CoInitialize(@Ptr long paramLong);
/*     */   
/*     */   static native void CoUninitialize();
/*     */   
/*     */   public static interface COINIT {
/*     */     public static final int COINIT_APARTMENTTHREADED = 2;
/*     */     public static final int COINIT_MULTITHREADED = 0;
/*     */     public static final int COINIT_DISABLE_OLE1DDE = 4;
/*     */     public static final int COINIT_SPEED_OVER_MEMORY = 8;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\com\COMRuntime.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */