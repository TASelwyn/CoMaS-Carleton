package org.bridj.cpp.com;

@IID("00020401-0000-0000-C000-000000000046")
public class ITypeInfo extends IUnknown {}
