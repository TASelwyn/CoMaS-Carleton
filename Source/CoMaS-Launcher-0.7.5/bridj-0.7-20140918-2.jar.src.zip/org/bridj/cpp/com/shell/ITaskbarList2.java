package org.bridj.cpp.com.shell;

import org.bridj.Pointer;
import org.bridj.ann.Virtual;

public class ITaskbarList2 extends ITaskbarList {
  @Virtual(0)
  public native int MarkFullscreenWindow(Pointer<Integer> paramPointer, boolean paramBoolean);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\com\shell\ITaskbarList2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */