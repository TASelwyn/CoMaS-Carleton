/*    */ package org.bridj.cpp.com;
/*    */ 
/*    */ import org.bridj.Pointer;
/*    */ import org.bridj.ann.Virtual;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @IID("00000001-0000-0000-C000-000000000046")
/*    */ public class IClassFactory
/*    */   extends IUnknown
/*    */ {
/*    */   @Virtual(0)
/*    */   @Deprecated
/*    */   public native int CreateInstance(Pointer<IUnknown> paramPointer, Pointer<Byte> paramPointer1, Pointer<Pointer<IUnknown>> paramPointer2);
/*    */   
/*    */   public <I extends IUnknown> I CreateInstance(Class<I> type) {
/* 55 */     Pointer<Pointer<IUnknown>> p = Pointer.allocatePointer(IUnknown.class);
/* 56 */     int ret = CreateInstance(null, COMRuntime.getIID(type), p);
/* 57 */     if (ret != 0) {
/* 58 */       return null;
/*    */     }
/*    */     
/* 61 */     return (I)((Pointer)p.get()).getNativeObject(type);
/*    */   }
/*    */   
/*    */   @Virtual(1)
/*    */   public native int LockServer(boolean paramBoolean);
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\com\IClassFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */