/*     */ package org.bridj.cpp.std;
/*     */ 
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.NoSuchElementException;
/*     */ import org.bridj.BridJ;
/*     */ import org.bridj.NativeObject;
/*     */ import org.bridj.Pointer;
/*     */ import org.bridj.StructObject;
/*     */ import org.bridj.ann.Array;
/*     */ import org.bridj.ann.Field;
/*     */ import org.bridj.ann.Library;
/*     */ import org.bridj.ann.Ptr;
/*     */ import org.bridj.ann.Struct;
/*     */ import org.bridj.ann.Template;
/*     */ import org.bridj.cpp.CPPObject;
/*     */ import org.bridj.cpp.CPPRuntime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Template({Type.class})
/*     */ @Struct(customizer = STL.class)
/*     */ public class list<T>
/*     */   extends CPPObject
/*     */ {
/*     */   protected volatile Type _T;
/*     */   
/*     */   @Library("c")
/*     */   @Ptr
/*     */   protected static native long malloc(@Ptr long paramLong);
/*     */   
/*     */   @Library("c")
/*     */   protected static native void free(@Ptr long paramLong);
/*     */   
/*     */   @Template({Type.class})
/*     */   public static class list_node<T>
/*     */     extends CPPObject
/*     */   {
/*     */     @Deprecated
/*     */     @Field(0)
/*     */     public Pointer<list_node<T>> next() {
/*  77 */       return this.io.getPointerField((StructObject)this, 0);
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     @Field(0)
/*     */     public void next(Pointer<list_node<T>> value) {
/*  83 */       this.io.setPointerField((StructObject)this, 0, value);
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     @Field(1)
/*     */     public Pointer<list_node<T>> prev() {
/*  89 */       return this.io.getPointerField((StructObject)this, 1);
/*     */     }
/*     */     
/*     */     @Field(1)
/*     */     public void prev(Pointer<list_node<T>> value) {
/*  94 */       this.io.setPointerField((StructObject)this, 1, value);
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     @Field(2)
/*     */     @Array({1L})
/*     */     public Pointer<T> data() {
/* 101 */       return this.io.getPointerField((StructObject)this, 2);
/*     */     }
/*     */     
/*     */     public list_node(Type t) {
/* 105 */       super((Void)null, -2, new Object[] { t });
/*     */     }
/*     */     
/*     */     public list_node(Pointer<? extends list_node> peer, Type t) {
/* 109 */       super(peer, new Object[] { t });
/* 110 */       if (!isValid()) {
/* 111 */         throw new RuntimeException("Invalid list internal data ! Are you trying to use an unsupported version of the STL ?");
/*     */       }
/*     */     }
/*     */     
/*     */     protected boolean isValid() {
/* 116 */       long next = Pointer.getPeer(next());
/* 117 */       long prev = Pointer.getPeer(prev());
/* 118 */       if (next == 0L && prev == 0L) {
/* 119 */         return false;
/*     */       }
/* 121 */       return true;
/*     */     }
/*     */     
/*     */     public T get() {
/* 125 */       return (T)data().get();
/*     */     }
/*     */     
/*     */     public void set(T value) {
/* 129 */       data().set(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected Type T() {
/* 135 */     if (this._T == null) {
/* 136 */       CPPRuntime.getInstance(); this._T = (Type)CPPRuntime.getTemplateParameters(this, list.class)[0];
/*     */     } 
/* 138 */     return this._T;
/*     */   }
/*     */   
/*     */   protected list_node<T> createNode() {
/* 142 */     Type T = T();
/* 143 */     long size = BridJ.sizeOf(T);
/* 144 */     return new list_node<T>(Pointer.pointerToAddress(malloc(size)), T);
/*     */   }
/*     */   
/*     */   protected void deleteNode(list_node<T> node) {
/* 148 */     free(Pointer.getAddress((NativeObject)node, list_node.class));
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   @Field(0)
/*     */   public Pointer<list_node<T>> next() {
/* 154 */     return this.io.getPointerField((StructObject)this, 0);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   @Field(0)
/*     */   public void next(Pointer<list_node<T>> value) {
/* 160 */     this.io.setPointerField((StructObject)this, 0, value);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   @Field(1)
/*     */   public Pointer<list_node<T>> prev() {
/* 166 */     return this.io.getPointerField((StructObject)this, 1);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   @Field(1)
/*     */   public void prev(Pointer<list_node<T>> value) {
/* 172 */     this.io.setPointerField((StructObject)this, 1, value);
/*     */   }
/*     */   
/*     */   public list(Type t) {
/* 176 */     super((Void)null, -2, new Object[] { t });
/*     */   }
/*     */   public list(Pointer<? extends list<T>> peer, Type t) {
/* 179 */     super(peer, new Object[] { t });
/*     */   }
/*     */   private void checkNotEmpty() {
/* 182 */     if (isRoot(next()) && isRoot(prev()))
/* 183 */       throw new NoSuchElementException(); 
/*     */   }
/*     */   public boolean empty() {
/* 186 */     return (next() != null);
/*     */   }
/*     */   public T front() {
/* 189 */     checkNotEmpty();
/* 190 */     return ((list_node<T>)next().get()).get();
/*     */   }
/*     */   public T back() {
/* 193 */     checkNotEmpty();
/* 194 */     Pointer<list_node<T>> prev = prev(), next = next();
/* 195 */     Pointer<list_node<T>> nextPrev = (next == null) ? null : ((list_node<T>)next.get()).prev();
/* 196 */     Pointer<list_node<T>> prevNext = (prev == null) ? null : ((list_node<T>)prev.get()).next();
/* 197 */     int[] nextValues = (next == null) ? null : next.getInts(20);
/* 198 */     int[] prevValues = (prev == null) ? null : prev.getInts(20);
/*     */     
/* 200 */     list_node<T> n = (list_node<T>)prev.get();
/* 201 */     int[] values = Pointer.pointerTo((NativeObject)n).getInts(20);
/* 202 */     return n.get();
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean same(Pointer a, Pointer b) {
/* 207 */     return (Pointer.getPeer(a) == Pointer.getPeer(b));
/*     */   }
/*     */   
/*     */   private boolean isRoot(Pointer a) {
/* 211 */     return same(a, Pointer.getPointer((NativeObject)this));
/*     */   }
/*     */   
/*     */   protected void hook(Pointer<list_node<T>> prev, Pointer<list_node<T>> next, T value) {
/* 215 */     list_node<T> tmp = createNode();
/* 216 */     Pointer<list_node<T>> pTmp = Pointer.getPointer((NativeObject)tmp);
/* 217 */     tmp.set(value);
/* 218 */     tmp.next(next);
/* 219 */     tmp.prev(prev);
/* 220 */     if (!isRoot(next)) {
/* 221 */       ((list_node<T>)next.get()).prev(pTmp);
/*     */     }
/* 223 */     if (!isRoot(prev)) {
/* 224 */       ((list_node<T>)prev.get()).next(pTmp);
/*     */     }
/*     */   }
/*     */   
/*     */   public void push_back(T value) {
/* 229 */     hook(prev(), null, value);
/*     */   }
/*     */   
/*     */   public void push_front(T value) {
/* 233 */     hook(null, next(), value);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\std\list.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */