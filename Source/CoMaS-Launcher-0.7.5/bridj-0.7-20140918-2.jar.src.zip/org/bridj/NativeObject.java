/*    */ package org.bridj;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class NativeObject
/*    */   implements NativeObjectInterface
/*    */ {
/*    */   protected Pointer<? extends NativeObject> peer;
/*    */   protected BridJRuntime.TypeInfo typeInfo;
/*    */   
/*    */   protected NativeObject(Pointer<? extends NativeObject> peer, Object... targs) {
/* 46 */     BridJ.initialize(this, peer, targs);
/*    */   }
/*    */   
/*    */   protected NativeObject() {
/* 50 */     BridJ.initialize(this);
/*    */   }
/*    */   
/*    */   protected NativeObject(int constructorId, Object... args) {
/* 54 */     BridJ.initialize(this, constructorId, args);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NativeObject clone() throws CloneNotSupportedException {
/* 63 */     return BridJ.clone(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 68 */     if (!(o instanceof NativeObject)) {
/* 69 */       return false;
/*    */     }
/*    */     
/* 72 */     return this.typeInfo.equal(this, (NativeObject)o);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\NativeObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */