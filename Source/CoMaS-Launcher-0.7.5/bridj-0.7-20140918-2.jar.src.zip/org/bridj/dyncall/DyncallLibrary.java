/*    */ package org.bridj.dyncall;
/*    */ 
/*    */ import org.bridj.BridJ;
/*    */ import org.bridj.CRuntime;
/*    */ import org.bridj.Pointer;
/*    */ import org.bridj.ann.CLong;
/*    */ import org.bridj.ann.Library;
/*    */ import org.bridj.ann.Optional;
/*    */ import org.bridj.ann.Ptr;
/*    */ import org.bridj.ann.Runtime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Library("bridj")
/*    */ @Runtime(CRuntime.class)
/*    */ public class DyncallLibrary
/*    */ {
/*    */   public static final char DC_SIGCHAR_FLOAT = 'f';
/*    */   public static final int DC_CALL_C_DEFAULT = 0;
/*    */   public static final int DC_CALL_C_PPC32_OSX = 9;
/*    */   public static final int DC_CALL_C_PPC32_SYSV = 13;
/*    */   public static final int DC_CALL_C_PPC32_DARWIN = 9;
/*    */   public static final int DC_ERROR_UNSUPPORTED_MODE = -1;
/*    */   public static final int DC_CALL_C_ELLIPSIS_VARARGS = 101;
/*    */   public static final int DC_CALL_C_X86_WIN32_THIS_MS = 5;
/*    */   public static final int DC_CALL_C_ARM_ARM_EABI = 10;
/*    */   public static final int DC_CALL_SYS_X86_INT80H_BSD = 202;
/*    */   public static final char DC_SIGCHAR_CC_ELLIPSIS = 'e';
/*    */   public static final int DC_CALL_C_X64_SYSV = 8;
/*    */   public static final char DC_SIGCHAR_POINTER = 'p';
/*    */   public static final int DEFAULT_ALIGNMENT = 0;
/*    */   public static final char DC_SIGCHAR_CC_FASTCALL_GNU = 'f';
/*    */   public static final char DC_SIGCHAR_UINT = 'I';
/*    */   public static final char DC_SIGCHAR_ENDARG = ')';
/*    */   public static final char DC_SIGCHAR_VOID = 'v';
/*    */   public static final char DC_SIGCHAR_UCHAR = 'C';
/*    */   public static final int DC_CALL_C_MIPS32_O32 = 16;
/*    */   public static final char DC_SIGCHAR_INT = 'i';
/*    */   public static final int DC_CALL_SYS_X86_INT80H_LINUX = 201;
/*    */   
/*    */   static {
/* 58 */     BridJ.register();
/*    */   }
/*    */   
/*    */   public static final char DC_SIGCHAR_DOUBLE = 'd';
/*    */   public static final int DC_CALL_C_X64_WIN64 = 7;
/*    */   public static final int DC_CALL_C_SPARC32 = 20;
/*    */   public static final int DC_CALL_C_ARM_THUMB_EABI = 11;
/*    */   public static final char DC_SIGCHAR_STRUCT = 'T';
/*    */   public static final int DC_CALL_C_X86_WIN32_THIS_GNU = 6;
/*    */   public static final int DC_CALL_SYS_DEFAULT = 200;
/*    */   public static final char DC_SIGCHAR_CC_STDCALL = 's';
/*    */   public static final int DC_CALL_C_ELLIPSIS = 100;
/*    */   public static final int DC_CALL_C_X86_PLAN9 = 19;
/*    */   public static final int DC_CALL_C_ARM_THUMB = 15;
/*    */   public static final char DC_SIGCHAR_CC_FASTCALL_MS = 'F';
/*    */   public static final char DC_SIGCHAR_STRING = 'Z';
/*    */   public static final int DC_CALL_C_MIPS32_EABI = 12;
/*    */   public static final int DC_CALL_C_X86_WIN32_FAST_GNU = 4;
/*    */   public static final char DC_SIGCHAR_LONGLONG = 'l';
/*    */   public static final char DC_SIGCHAR_SHORT = 's';
/*    */   public static final char DC_SIGCHAR_ULONGLONG = 'L';
/*    */   public static final int DC_ERROR_NONE = 0;
/*    */   public static final int DC_CALL_C_SPARC64 = 21;
/*    */   public static final int DC_CALL_C_PPC32_LINUX = 13;
/*    */   public static final char DC_SIGCHAR_ULONG = 'J';
/*    */   public static final char DC_SIGCHAR_CHAR = 'c';
/*    */   public static final char DC_SIGCHAR_CC_PREFIX = '_';
/*    */   public static final char DC_SIGCHAR_LONG = 'j';
/*    */   public static final int DC_CALL_C_MIPS64_N32 = 17;
/*    */   public static final int DC_CALL_C_X86_WIN32_STD = 2;
/*    */   public static final char DC_SIGCHAR_CC_THISCALL_MS = '+';
/*    */   public static final int DC_CALL_C_X86_CDECL = 1;
/*    */   public static final int DC_CALL_C_X86_WIN32_FAST_MS = 3;
/*    */   public static final int DC_CALL_C_ARM_ARM = 14;
/*    */   public static final char DC_SIGCHAR_USHORT = 'S';
/*    */   public static final char DC_SIGCHAR_BOOL = 'B';
/*    */   public static final int DC_CALL_C_MIPS64_N64 = 18;
/*    */   
/*    */   public static native Pointer<DCCallVM> dcNewCallVM(@Ptr long paramLong);
/*    */   
/*    */   public static native void dcFree(Pointer<DCCallVM> paramPointer);
/*    */   
/*    */   public static native void dcReset(Pointer<DCCallVM> paramPointer);
/*    */   
/*    */   public static native void dcMode(Pointer<DCCallVM> paramPointer, int paramInt);
/*    */   
/*    */   public static native void dcArgBool(Pointer<DCCallVM> paramPointer, int paramInt);
/*    */   
/*    */   public static native void dcArgChar(Pointer<DCCallVM> paramPointer, byte paramByte);
/*    */   
/*    */   public static native void dcArgShort(Pointer<DCCallVM> paramPointer, short paramShort);
/*    */   
/*    */   public static native void dcArgInt(Pointer<DCCallVM> paramPointer, int paramInt);
/*    */   
/*    */   public static native void dcArgLong(Pointer<DCCallVM> paramPointer, @CLong long paramLong);
/*    */   
/*    */   public static native void dcArgLongLong(Pointer<DCCallVM> paramPointer, long paramLong);
/*    */   
/*    */   public static native void dcArgFloat(Pointer<DCCallVM> paramPointer, float paramFloat);
/*    */   
/*    */   public static native void dcArgDouble(Pointer<DCCallVM> paramPointer, double paramDouble);
/*    */   
/*    */   public static native void dcArgPointer(Pointer<DCCallVM> paramPointer, Pointer<?> paramPointer1);
/*    */   
/*    */   @Optional
/*    */   public static native void dcArgStruct(Pointer<DCCallVM> paramPointer, Pointer<DCstruct> paramPointer1, Pointer<?> paramPointer2);
/*    */   
/*    */   public static native void dcCallVoid(Pointer<DCCallVM> paramPointer, Pointer<?> paramPointer1);
/*    */   
/*    */   public static native int dcCallBool(Pointer<DCCallVM> paramPointer, Pointer<?> paramPointer1);
/*    */   
/*    */   public static native byte dcCallChar(Pointer<DCCallVM> paramPointer, Pointer<?> paramPointer1);
/*    */   
/*    */   public static native short dcCallShort(Pointer<DCCallVM> paramPointer, Pointer<?> paramPointer1);
/*    */   
/*    */   public static native int dcCallInt(Pointer<DCCallVM> paramPointer, Pointer<?> paramPointer1);
/*    */   
/*    */   @CLong
/*    */   public static native long dcCallLong(Pointer<DCCallVM> paramPointer, Pointer<?> paramPointer1);
/*    */   
/*    */   public static native long dcCallLongLong(Pointer<DCCallVM> paramPointer, Pointer<?> paramPointer1);
/*    */   
/*    */   public static native float dcCallFloat(Pointer<DCCallVM> paramPointer, Pointer<?> paramPointer1);
/*    */   
/*    */   public static native double dcCallDouble(Pointer<DCCallVM> paramPointer, Pointer<?> paramPointer1);
/*    */   
/*    */   public static native Pointer<?> dcCallPointer(Pointer<DCCallVM> paramPointer, Pointer<?> paramPointer1);
/*    */   
/*    */   @Optional
/*    */   public static native void dcCallStruct(Pointer<DCCallVM> paramPointer, Pointer<?> paramPointer1, Pointer<DCstruct> paramPointer2, Pointer<?> paramPointer3);
/*    */   
/*    */   public static native int dcGetError(Pointer<DCCallVM> paramPointer);
/*    */   
/*    */   @Optional
/*    */   public static native Pointer<DCstruct> dcNewStruct(@Ptr long paramLong, int paramInt);
/*    */   
/*    */   @Optional
/*    */   public static native void dcStructField(Pointer<DCstruct> paramPointer, int paramInt1, int paramInt2, @Ptr long paramLong);
/*    */   
/*    */   @Optional
/*    */   public static native void dcSubStruct(Pointer<DCstruct> paramPointer, @Ptr long paramLong1, int paramInt, @Ptr long paramLong2);
/*    */   
/*    */   @Optional
/*    */   public static native void dcCloseStruct(Pointer<DCstruct> paramPointer);
/*    */   
/*    */   @Optional
/*    */   @Ptr
/*    */   public static native long dcStructSize(Pointer<DCstruct> paramPointer);
/*    */   
/*    */   @Optional
/*    */   @Ptr
/*    */   public static native long dcStructAlignment(Pointer<DCstruct> paramPointer);
/*    */   
/*    */   @Optional
/*    */   public static native void dcFreeStruct(Pointer<DCstruct> paramPointer);
/*    */   
/*    */   @Optional
/*    */   public static native Pointer<DCstruct> dcDefineStruct(Pointer<Byte> paramPointer);
/*    */   
/*    */   public static interface DCCallVM {}
/*    */   
/*    */   public static interface DCstruct {}
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\dyncall\DyncallLibrary.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */