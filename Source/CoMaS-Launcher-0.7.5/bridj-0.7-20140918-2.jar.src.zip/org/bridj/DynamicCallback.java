package org.bridj;

public interface DynamicCallback<R> {
  R apply(Object... paramVarArgs);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\DynamicCallback.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */