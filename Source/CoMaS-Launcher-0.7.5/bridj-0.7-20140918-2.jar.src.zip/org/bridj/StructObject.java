package org.bridj;

import org.bridj.ann.Runtime;

@Runtime(CRuntime.class)
public abstract class StructObject extends NativeObject {
  protected StructIO io;
  
  protected StructObject() {}
  
  protected StructObject(Void voidArg, int constructorId, Object... args) {
    super(constructorId, args);
  }
  
  protected StructObject(Pointer<? extends StructObject> peer, Object... targs) {
    super((Pointer)peer, targs);
  }
  
  public String toString() {
    return BridJ.describe(this);
  }
  
  public static long offsetOfField(StructObject o, String name) {
    for (StructFieldDescription desc : o.io.desc.fields) {
      if (desc.name.equals(name))
        return desc.byteOffset; 
    } 
    throw new NoSuchFieldError(name);
  }
}
