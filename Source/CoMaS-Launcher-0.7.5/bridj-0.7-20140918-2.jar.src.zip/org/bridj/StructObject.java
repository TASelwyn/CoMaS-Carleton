/*    */ package org.bridj;
/*    */ 
/*    */ import org.bridj.ann.Runtime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Runtime(CRuntime.class)
/*    */ public abstract class StructObject
/*    */   extends NativeObject
/*    */ {
/*    */   protected StructIO io;
/*    */   
/*    */   protected StructObject() {}
/*    */   
/*    */   protected StructObject(Void voidArg, int constructorId, Object... args) {
/* 58 */     super(constructorId, args);
/*    */   }
/*    */   
/*    */   protected StructObject(Pointer<? extends StructObject> peer, Object... targs) {
/* 62 */     super((Pointer)peer, targs);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 71 */     return BridJ.describe(this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static long offsetOfField(StructObject o, String name) {
/* 78 */     for (StructFieldDescription desc : o.io.desc.fields) {
/* 79 */       if (desc.name.equals(name)) {
/* 80 */         return desc.byteOffset;
/*    */       }
/*    */     } 
/* 83 */     throw new NoSuchFieldError(name);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\StructObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */