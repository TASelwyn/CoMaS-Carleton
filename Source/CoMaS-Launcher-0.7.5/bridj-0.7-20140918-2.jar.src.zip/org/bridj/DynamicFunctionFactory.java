/*    */ package org.bridj;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DynamicFunctionFactory
/*    */ {
/*    */   final Constructor<? extends DynamicFunction> constructor;
/*    */   final Method method;
/*    */   final long callbackHandle;
/*    */   
/*    */   DynamicFunctionFactory(Class<? extends DynamicFunction> callbackClass, Method method, CRuntime.MethodCallInfoBuilder methodCallInfoBuilder) {
/*    */     try {
/* 52 */       this.constructor = callbackClass.getConstructor(new Class[0]);
/* 53 */       this.method = method;
/*    */       
/* 55 */       MethodCallInfo mci = methodCallInfoBuilder.apply(method);
/* 56 */       this.callbackHandle = JNI.bindJavaToCCallbacks(new MethodCallInfo[] { mci });
/* 57 */     } catch (Throwable th) {
/* 58 */       th.printStackTrace();
/* 59 */       throw new RuntimeException("Failed to instantiate callback : " + th, th);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected void finalize() throws Throwable {
/* 65 */     if (BridJ.debugNeverFree) {
/*    */       return;
/*    */     }
/*    */     
/* 69 */     JNI.freeJavaToCCallbacks(this.callbackHandle, 1);
/*    */   }
/*    */   
/*    */   public DynamicFunction newInstance(Pointer<?> functionPointer) {
/* 73 */     if (functionPointer == null) {
/* 74 */       return null;
/*    */     }
/*    */     
/*    */     try {
/* 78 */       DynamicFunction dcb = this.constructor.newInstance(new Object[0]);
/* 79 */       dcb.peer = (Pointer)functionPointer;
/* 80 */       dcb.method = this.method;
/* 81 */       dcb.factory = this;
/*    */       
/* 83 */       return dcb;
/* 84 */     } catch (Throwable th) {
/* 85 */       th.printStackTrace();
/* 86 */       throw new RuntimeException("Failed to instantiate callback : " + th, th);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 92 */     return getClass().getSimpleName() + "(" + this.method + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\DynamicFunctionFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */