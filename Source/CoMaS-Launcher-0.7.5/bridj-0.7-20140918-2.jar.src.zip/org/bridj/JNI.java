/*    */ package org.bridj;
/*    */ 
/*    */ import java.nio.Buffer;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class JNI
/*    */ {
/*    */   static {
/* 53 */     Platform.initLibrary();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static native void memset(long paramLong1, byte paramByte, long paramLong2);
/*    */ 
/*    */ 
/*    */   
/*    */   static native int memcmp(long paramLong1, long paramLong2, long paramLong3);
/*    */ 
/*    */ 
/*    */   
/*    */   static native long memmem_last(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/*    */ 
/*    */ 
/*    */   
/*    */   static native long memmem(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/*    */ 
/*    */   
/*    */   static native long memchr(long paramLong1, byte paramByte, long paramLong2);
/*    */ 
/*    */   
/*    */   static native void memmove(long paramLong1, long paramLong2, long paramLong3);
/*    */ 
/*    */   
/*    */   public static Pointer<?> getGlobalPointer(Object object) {
/* 80 */     return Pointer.pointerToAddress(newGlobalRef(object), new Pointer.Releaser() {
/*    */           public void release(Pointer<?> p) {
/* 82 */             JNI.deleteGlobalRef(p.getPeer());
/*    */           }
/*    */         });
/*    */   }
/*    */   
/*    */   static native void memcpy(long paramLong1, long paramLong2, long paramLong3);
/*    */   
/*    */   static native long wcslen(long paramLong);
/*    */   
/*    */   static native long strlen(long paramLong);
/*    */   
/*    */   static native void free(long paramLong);
/*    */   
/*    */   static native long malloc(long paramLong);
/*    */   
/*    */   static native long mallocNulledAligned(long paramLong, int paramInt);
/*    */   
/*    */   static native long mallocNulled(long paramLong);
/*    */   
/*    */   static native void deleteCallTempStruct(long paramLong);
/*    */   
/*    */   static native long createCallTempStruct();
/*    */   
/*    */   static native void freeVirtualMethodBindings(long paramLong, int paramInt);
/*    */   
/*    */   static native void freeCFunctionBindings(long paramLong, int paramInt);
/*    */   
/*    */   static native void freeJavaToCCallbacks(long paramLong, int paramInt);
/*    */   
/*    */   static native void freeObjCMethodBindings(long paramLong, int paramInt);
/*    */   
/*    */   static native void freeCToJavaCallback(long paramLong);
/*    */   
/*    */   static native long bindJavaMethodsToVirtualMethods(MethodCallInfo... paramVarArgs);
/*    */   
/*    */   static native long bindJavaMethodsToCFunctions(MethodCallInfo... paramVarArgs);
/*    */   
/*    */   static native long bindJavaToCCallbacks(MethodCallInfo... paramVarArgs);
/*    */   
/*    */   static native long bindJavaMethodsToObjCMethods(MethodCallInfo... paramVarArgs);
/*    */   
/*    */   static native long getActualCToJavaCallback(long paramLong);
/*    */   
/*    */   static native long createCToJavaCallback(MethodCallInfo paramMethodCallInfo);
/*    */   
/*    */   public static native void callSinglePointerArgVoidFunction(long paramLong1, long paramLong2, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_boolean_array(long paramLong, boolean[] paramArrayOfboolean, int paramInt1, int paramInt2);
/*    */   
/*    */   @Deprecated
/*    */   static native boolean[] get_boolean_array(long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_boolean(long paramLong, boolean paramBoolean);
/*    */   
/*    */   @Deprecated
/*    */   static native boolean get_boolean(long paramLong);
/*    */   
/*    */   @Deprecated
/*    */   static native void releaseBooleanArrayElements(boolean[] paramArrayOfboolean, long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native long getBooleanArrayElements(boolean[] paramArrayOfboolean1, boolean[] paramArrayOfboolean2);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_double_array_disordered(long paramLong, double[] paramArrayOfdouble, int paramInt1, int paramInt2);
/*    */   
/*    */   @Deprecated
/*    */   static native double[] get_double_array_disordered(long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_double_disordered(long paramLong, double paramDouble);
/*    */   
/*    */   @Deprecated
/*    */   static native double get_double_disordered(long paramLong);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_double_array(long paramLong, double[] paramArrayOfdouble, int paramInt1, int paramInt2);
/*    */   
/*    */   @Deprecated
/*    */   static native double[] get_double_array(long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_double(long paramLong, double paramDouble);
/*    */   
/*    */   @Deprecated
/*    */   static native double get_double(long paramLong);
/*    */   
/*    */   @Deprecated
/*    */   static native void releaseDoubleArrayElements(double[] paramArrayOfdouble, long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native long getDoubleArrayElements(double[] paramArrayOfdouble, boolean[] paramArrayOfboolean);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_float_array_disordered(long paramLong, float[] paramArrayOffloat, int paramInt1, int paramInt2);
/*    */   
/*    */   @Deprecated
/*    */   static native float[] get_float_array_disordered(long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_float_disordered(long paramLong, float paramFloat);
/*    */   
/*    */   @Deprecated
/*    */   static native float get_float_disordered(long paramLong);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_float_array(long paramLong, float[] paramArrayOffloat, int paramInt1, int paramInt2);
/*    */   
/*    */   @Deprecated
/*    */   static native float[] get_float_array(long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_float(long paramLong, float paramFloat);
/*    */   
/*    */   @Deprecated
/*    */   static native float get_float(long paramLong);
/*    */   
/*    */   @Deprecated
/*    */   static native void releaseFloatArrayElements(float[] paramArrayOffloat, long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native long getFloatArrayElements(float[] paramArrayOffloat, boolean[] paramArrayOfboolean);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_char_array_disordered(long paramLong, char[] paramArrayOfchar, int paramInt1, int paramInt2);
/*    */   
/*    */   @Deprecated
/*    */   static native char[] get_char_array_disordered(long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_char_disordered(long paramLong, char paramChar);
/*    */   
/*    */   @Deprecated
/*    */   static native char get_char_disordered(long paramLong);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_char_array(long paramLong, char[] paramArrayOfchar, int paramInt1, int paramInt2);
/*    */   
/*    */   @Deprecated
/*    */   static native char[] get_char_array(long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_char(long paramLong, char paramChar);
/*    */   
/*    */   @Deprecated
/*    */   static native char get_char(long paramLong);
/*    */   
/*    */   @Deprecated
/*    */   static native void releaseCharArrayElements(char[] paramArrayOfchar, long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native long getCharArrayElements(char[] paramArrayOfchar, boolean[] paramArrayOfboolean);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_byte_array(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
/*    */   
/*    */   @Deprecated
/*    */   static native byte[] get_byte_array(long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_byte(long paramLong, byte paramByte);
/*    */   
/*    */   @Deprecated
/*    */   static native byte get_byte(long paramLong);
/*    */   
/*    */   @Deprecated
/*    */   static native void releaseByteArrayElements(byte[] paramArrayOfbyte, long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native long getByteArrayElements(byte[] paramArrayOfbyte, boolean[] paramArrayOfboolean);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_short_array_disordered(long paramLong, short[] paramArrayOfshort, int paramInt1, int paramInt2);
/*    */   
/*    */   @Deprecated
/*    */   static native short[] get_short_array_disordered(long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_short_disordered(long paramLong, short paramShort);
/*    */   
/*    */   @Deprecated
/*    */   static native short get_short_disordered(long paramLong);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_short_array(long paramLong, short[] paramArrayOfshort, int paramInt1, int paramInt2);
/*    */   
/*    */   @Deprecated
/*    */   static native short[] get_short_array(long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_short(long paramLong, short paramShort);
/*    */   
/*    */   @Deprecated
/*    */   static native short get_short(long paramLong);
/*    */   
/*    */   @Deprecated
/*    */   static native void releaseShortArrayElements(short[] paramArrayOfshort, long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native long getShortArrayElements(short[] paramArrayOfshort, boolean[] paramArrayOfboolean);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_long_array_disordered(long paramLong, long[] paramArrayOflong, int paramInt1, int paramInt2);
/*    */   
/*    */   @Deprecated
/*    */   static native long[] get_long_array_disordered(long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_long_disordered(long paramLong1, long paramLong2);
/*    */   
/*    */   @Deprecated
/*    */   static native long get_long_disordered(long paramLong);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_long_array(long paramLong, long[] paramArrayOflong, int paramInt1, int paramInt2);
/*    */   
/*    */   @Deprecated
/*    */   static native long[] get_long_array(long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_long(long paramLong1, long paramLong2);
/*    */   
/*    */   @Deprecated
/*    */   static native long get_long(long paramLong);
/*    */   
/*    */   @Deprecated
/*    */   static native void releaseLongArrayElements(long[] paramArrayOflong, long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native long getLongArrayElements(long[] paramArrayOflong, boolean[] paramArrayOfboolean);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_int_array_disordered(long paramLong, int[] paramArrayOfint, int paramInt1, int paramInt2);
/*    */   
/*    */   @Deprecated
/*    */   static native int[] get_int_array_disordered(long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_int_disordered(long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native int get_int_disordered(long paramLong);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_int_array(long paramLong, int[] paramArrayOfint, int paramInt1, int paramInt2);
/*    */   
/*    */   @Deprecated
/*    */   static native int[] get_int_array(long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native void set_int(long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native int get_int(long paramLong);
/*    */   
/*    */   @Deprecated
/*    */   static native void releaseIntArrayElements(int[] paramArrayOfint, long paramLong, int paramInt);
/*    */   
/*    */   @Deprecated
/*    */   static native long getIntArrayElements(int[] paramArrayOfint, boolean[] paramArrayOfboolean);
/*    */   
/*    */   public static native long getDirectBufferCapacity(Buffer paramBuffer);
/*    */   
/*    */   public static native long getDirectBufferAddress(Buffer paramBuffer);
/*    */   
/*    */   public static native ByteBuffer newDirectByteBuffer(long paramLong1, long paramLong2);
/*    */   
/*    */   public static native void deleteWeakGlobalRef(long paramLong);
/*    */   
/*    */   public static native long newWeakGlobalRef(Object paramObject);
/*    */   
/*    */   public static native void deleteGlobalRef(long paramLong);
/*    */   
/*    */   public static native long newGlobalRef(Object paramObject);
/*    */   
/*    */   static native String findSymbolName(long paramLong1, long paramLong2, long paramLong3);
/*    */   
/*    */   static native String[] getLibrarySymbols(long paramLong1, long paramLong2);
/*    */   
/*    */   static native long findSymbolInLibrary(long paramLong, String paramString);
/*    */   
/*    */   static native void freeLibrarySymbols(long paramLong);
/*    */   
/*    */   static native long loadLibrarySymbols(String paramString);
/*    */   
/*    */   static native void freeLibrary(long paramLong);
/*    */   
/*    */   static native long loadLibrary(String paramString);
/*    */   
/*    */   @Deprecated
/*    */   public static native Object refToObject(long paramLong);
/*    */   
/*    */   @Deprecated
/*    */   public static native long getJVM();
/*    */   
/*    */   @Deprecated
/*    */   public static native long getEnv();
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\JNI.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */