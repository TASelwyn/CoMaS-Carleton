/*     */ package org.bridj;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ import org.bridj.util.ProcessUtils;
/*     */ import org.bridj.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Platform
/*     */ {
/*  71 */   static final String osName = System.getProperty("os.name", "");
/*     */ 
/*     */   
/*     */   private static boolean inited;
/*     */   
/*     */   static final String BridJLibraryName = "bridj";
/*     */   
/*     */   public static final int POINTER_SIZE;
/*     */   
/*     */   public static final int WCHAR_T_SIZE;
/*     */   
/*     */   public static final int SIZE_T_SIZE;
/*     */   
/*     */   public static final int TIME_T_SIZE;
/*     */   
/*     */   public static final int CLONG_SIZE;
/*     */   
/*     */   static final ClassLoader systemClassLoader;
/*     */ 
/*     */   
/*     */   public static ClassLoader getClassLoader() {
/*  92 */     return getClassLoader(BridJ.class);
/*     */   }
/*     */   
/*     */   public static ClassLoader getClassLoader(Class<?> cl) {
/*  96 */     ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
/*  97 */     if (contextClassLoader != null) {
/*  98 */       return contextClassLoader;
/*     */     }
/* 100 */     ClassLoader classLoader = (cl == null) ? null : cl.getClassLoader();
/* 101 */     return (classLoader == null) ? systemClassLoader : classLoader;
/*     */   }
/*     */   
/*     */   public static InputStream getResourceAsStream(String path) {
/* 105 */     URL url = getResource(path);
/*     */     try {
/* 107 */       return (url != null) ? url.openStream() : null;
/* 108 */     } catch (IOException ex) {
/* 109 */       if (BridJ.verbose) {
/* 110 */         BridJ.warning("Failed to get resource '" + path + "'", ex);
/*     */       }
/* 112 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static URL getResource(String path) {
/* 117 */     if (!path.startsWith("/")) {
/* 118 */       path = "/" + path;
/*     */     }
/*     */     
/* 121 */     URL in = BridJ.class.getResource(path);
/* 122 */     if (in != null) {
/* 123 */       return in;
/*     */     }
/*     */     
/* 126 */     ClassLoader[] cls = { BridJ.class.getClassLoader(), Thread.currentThread().getContextClassLoader(), systemClassLoader };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 131 */     for (ClassLoader cl : cls) {
/* 132 */       if (cl != null && (in = cl.getResource(path)) != null) {
/* 133 */         return in;
/*     */       }
/*     */     } 
/* 136 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 160 */   static final List<String> embeddedLibraryResourceRoots = new ArrayList<String>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void addEmbeddedLibraryResourceRoot(String root) {
/* 187 */     embeddedLibraryResourceRoots.add(0, root);
/*     */   }
/* 189 */   static Set<File> temporaryExtractedLibraryCanonicalFiles = Collections.synchronizedSet(new LinkedHashSet<File>());
/*     */   
/*     */   static void addTemporaryExtractedLibraryFileToDeleteOnExit(File file) throws IOException {
/* 192 */     File canonicalFile = file.getCanonicalFile();
/*     */ 
/*     */     
/* 195 */     temporaryExtractedLibraryCanonicalFiles.add(canonicalFile);
/*     */ 
/*     */     
/* 198 */     canonicalFile.deleteOnExit();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 205 */   private static final String arch = System.getProperty("os.arch");
/*     */   private static boolean is64Bits;
/* 207 */   private static File extractedLibrariesTempDir; private static List<NativeLibrary> nativeLibraries; public static boolean useUnicodeVersionOfWindowsAPIs; static final long DELETE_OLD_BINARIES_AFTER_MILLIS = 86400000L; static final int maxTempFileAttempts = 20; static void addNativeLibrary(NativeLibrary library) { synchronized (nativeLibraries) { nativeLibraries.add(library); }  } private static void shutdown() { deleteTemporaryExtractedLibraryFiles(); } private static void releaseNativeLibraries() { synchronized (nativeLibraries) { for (int iLibrary = nativeLibraries.size(); iLibrary-- != 0; ) { NativeLibrary lib = nativeLibraries.get(iLibrary); try { lib.release(); } catch (Throwable th) { BridJ.error("Failed to release library '" + lib.path + "' : " + th, th); }  }  }  } private static void deleteTemporaryExtractedLibraryFiles() { synchronized (temporaryExtractedLibraryCanonicalFiles) { temporaryExtractedLibraryCanonicalFiles.add(extractedLibrariesTempDir); List<File> filesToDeleteAfterExit = new ArrayList<File>(); for (File tempFile : temporaryExtractedLibraryCanonicalFiles) { if (tempFile.delete()) { if (BridJ.verbose) BridJ.info("Deleted temporary library file '" + tempFile + "'");  continue; }  filesToDeleteAfterExit.add(tempFile); }  if (!filesToDeleteAfterExit.isEmpty()) { if (BridJ.verbose) BridJ.info("Attempting to delete " + filesToDeleteAfterExit.size() + " files after JVM exit : " + StringUtils.implode(filesToDeleteAfterExit, ", "));  try { ProcessUtils.startJavaProcess(DeleteFiles.class, filesToDeleteAfterExit); } catch (Throwable ex) { BridJ.error("Failed to launch process to delete files after JVM exit : " + ex, ex); }  }  }  } static { String dataModel = System.getProperty("sun.arch.data.model", System.getProperty("com.ibm.vm.bitmode"));
/* 208 */     if ("32".equals(dataModel)) {
/* 209 */       is64Bits = false;
/* 210 */     } else if ("64".equals(dataModel)) {
/* 211 */       is64Bits = true;
/*     */     } else {
/* 213 */       is64Bits = (arch.contains("64") || arch.equalsIgnoreCase("sparcv9"));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 218 */     systemClassLoader = createClassLoader();
/*     */     
/* 220 */     addEmbeddedLibraryResourceRoot("libs/");
/* 221 */     if (!isAndroid()) {
/* 222 */       addEmbeddedLibraryResourceRoot("lib/");
/* 223 */       addEmbeddedLibraryResourceRoot("org/bridj/lib/");
/* 224 */       if (!"v0_7_0".equals("")) {
/* 225 */         addEmbeddedLibraryResourceRoot("org/bridj/v0_7_0/lib/");
/*     */       }
/*     */     } 
/*     */     
/*     */     try {
/* 230 */       extractedLibrariesTempDir = createTempDir("BridJExtractedLibraries");
/* 231 */       initLibrary();
/* 232 */     } catch (Throwable th) {
/* 233 */       th.printStackTrace();
/*     */     } 
/* 235 */     POINTER_SIZE = sizeOf_ptrdiff_t();
/* 236 */     WCHAR_T_SIZE = sizeOf_wchar_t();
/* 237 */     SIZE_T_SIZE = sizeOf_size_t();
/* 238 */     TIME_T_SIZE = sizeOf_time_t();
/* 239 */     CLONG_SIZE = sizeOf_long();
/*     */     
/* 241 */     is64Bits = (POINTER_SIZE == 8);
/*     */     
/* 243 */     Runtime.getRuntime().addShutdownHook(new Thread() {
/*     */           public void run() {
/* 245 */             Platform.shutdown();
/*     */           }
/*     */         });
/*     */     
/* 249 */     nativeLibraries = new ArrayList<NativeLibrary>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 499 */     useUnicodeVersionOfWindowsAPIs = (!"false".equals(System.getProperty("bridj.useUnicodeVersionOfWindowsAPIs")) && !"0".equals(System.getenv("BRIDJ_USE_UNICODE_VERSION_OF_WINDOWS_APIS"))); }
/*     */   public static class DeleteFiles {
/*     */     static final long TRY_DELETE_EVERY_MILLIS = 50L;
/*     */     static final long FAIL_AFTER_MILLIS = 10000L;
/* 503 */     static boolean delete(List<File> files) { for (Iterator<File> it = files.iterator(); it.hasNext(); ) { File file = it.next(); if (file.delete()) it.remove();  }  return files.isEmpty(); } public static void main(String[] args) { try { List<File> files = new LinkedList<File>(); for (String arg : args) files.add(new File(arg));  long start = System.currentTimeMillis(); while (!delete(files)) { long elapsed = System.currentTimeMillis() - start; if (elapsed > 10000L) { BridJ.error("Failed to delete the following files : " + StringUtils.implode(files)); System.exit(1); }  Thread.sleep(50L); }  } catch (Throwable th) { th.printStackTrace(); } finally { System.exit(0); }  } } static ClassLoader createClassLoader() { List<URL> urls = new ArrayList<URL>(); for (String propName : new String[] { "java.class.path", "sun.boot.class.path" }) { String prop = System.getProperty(propName); if (prop != null) for (String path : prop.split(File.pathSeparator)) { path = path.trim(); if (path.length() != 0) { URL uRL; try { uRL = new URL(path); } catch (MalformedURLException ex) { try { uRL = (new File(path)).toURI().toURL(); } catch (MalformedURLException ex2) { uRL = null; }  }  if (uRL != null) urls.add(uRL);  }  }   }  return new URLClassLoader(urls.<URL>toArray(new URL[urls.size()])); } static String getenvOrProperty(String envName, String javaName, String defaultValue) { String value = System.getenv(envName); if (value == null) value = System.getProperty(javaName);  if (value == null) value = defaultValue;  return value; } private static String getArch() { return arch; } public static synchronized void initLibrary() { if (inited) return;  inited = true; try { boolean loaded = false; String forceLibFile = getenvOrProperty("BRIDJ_LIBRARY", "bridj.library", null); String lib = null; if (forceLibFile != null) try { System.load(lib = forceLibFile); loaded = true; } catch (Throwable ex) { BridJ.error("Failed to load forced library " + forceLibFile, ex); }   if (!loaded) { if (!isAndroid()) try { File libFile = extractEmbeddedLibraryResource("bridj"); if (libFile == null) throw new FileNotFoundException("Failed to extract embedded library 'bridj' (could be a classloader issue, or missing binary in resource path " + StringUtils.implode(embeddedLibraryResourceRoots, ", ") + ")");  if (BridJ.veryVerbose) BridJ.info("Loading library " + libFile);  System.load(lib = libFile.toString()); BridJ.setNativeLibraryFile("bridj", libFile); loaded = true; } catch (IOException ex) { BridJ.error("Failed to load 'bridj'", ex); }   if (!loaded) System.loadLibrary("bridj");  }  if (BridJ.veryVerbose) BridJ.info("Loaded library " + lib);  init(); if (BridJ.logCalls) BridJ.info("Calls logs enabled");  } catch (Throwable ex) { throw new RuntimeException("Failed to initialize " + BridJ.class.getSimpleName() + " (" + ex + ")", ex); }  }
/*     */   public static boolean isLinux() { return (isUnix() && osName.toLowerCase().contains("linux")); }
/*     */   public static boolean isMacOSX() { return (isUnix() && (osName.startsWith("Mac") || osName.startsWith("Darwin"))); }
/*     */   public static boolean isSolaris() { return (isUnix() && (osName.startsWith("SunOS") || osName.startsWith("Solaris"))); }
/*     */   public static boolean isBSD() { return (isUnix() && (osName.contains("BSD") || isMacOSX())); }
/*     */   public static boolean isUnix() { return (File.separatorChar == '/'); }
/*     */   public static boolean isWindows() { return (File.separatorChar == '\\'); }
/*     */   public static boolean isWindows7() { return osName.equals("Windows 7"); }
/* 511 */   public static String getMachine() { String arch = getArch();
/* 512 */     if (arch.equals("amd64") || arch.equals("x86_64")) {
/* 513 */       if (is64Bits()) {
/* 514 */         return "x86_64";
/*     */       }
/* 516 */       return "i386";
/*     */     } 
/*     */     
/* 519 */     return arch; }
/*     */ 
/*     */   
/*     */   public static boolean isAndroid() {
/* 523 */     return ("dalvik".equalsIgnoreCase(System.getProperty("java.vm.name")) && isLinux());
/*     */   }
/*     */   
/*     */   public static boolean isArm() {
/* 527 */     String arch = getArch();
/* 528 */     return "arm".equals(arch);
/*     */   }
/*     */   
/*     */   public static boolean isSparc() {
/* 532 */     String arch = getArch();
/* 533 */     return ("sparc".equals(arch) || "sparcv9".equals(arch));
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean is64Bits() {
/* 538 */     return is64Bits;
/*     */   }
/*     */   
/*     */   public static boolean isAmd64Arch() {
/* 542 */     String arch = getArch();
/* 543 */     return arch.equals("x86_64");
/*     */   }
/*     */   
/*     */   static List<String> getPossibleFileNames(String name) {
/* 547 */     List<String> fileNames = new ArrayList<String>(1);
/* 548 */     if (isWindows()) {
/* 549 */       fileNames.add(name + ".dll");
/* 550 */       fileNames.add(name + ".drv");
/*     */     } else {
/* 552 */       String jniName = "lib" + name + ".jnilib";
/* 553 */       if (isMacOSX()) {
/* 554 */         fileNames.add("lib" + name + ".dylib");
/* 555 */         fileNames.add(jniName);
/*     */       } else {
/* 557 */         fileNames.add("lib" + name + ".so");
/* 558 */         fileNames.add(name + ".so");
/* 559 */         fileNames.add(jniName);
/*     */       } 
/*     */     } 
/*     */     
/* 563 */     assert !fileNames.isEmpty();
/* 564 */     if (name.contains(".")) {
/* 565 */       fileNames.add(name);
/*     */     }
/* 567 */     return fileNames;
/*     */   }
/*     */   
/*     */   static synchronized List<String> getEmbeddedLibraryPaths(String name) {
/* 571 */     List<String> paths = new ArrayList<String>(embeddedLibraryResourceRoots.size());
/* 572 */     for (String root : embeddedLibraryResourceRoots) {
/* 573 */       if (root == null) {
/*     */         continue;
/*     */       }
/*     */       
/* 577 */       if (isWindows()) {
/* 578 */         paths.add(root + (is64Bits() ? "win64/" : "win32/")); continue;
/* 579 */       }  if (isMacOSX()) {
/* 580 */         if (isArm()) {
/* 581 */           paths.add(root + "iphoneos_arm32_arm/"); continue;
/*     */         } 
/* 583 */         paths.add(root + "darwin_universal/");
/* 584 */         if (isAmd64Arch()) {
/* 585 */           paths.add(root + "darwin_x64/");
/*     */         }
/*     */         continue;
/*     */       } 
/* 589 */       if (isAndroid()) {
/* 590 */         assert root.equals("libs/");
/* 591 */         paths.add(root + "armeabi/"); continue;
/* 592 */       }  if (isLinux()) {
/* 593 */         if (isArm()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 606 */           paths.add(root + getARMLinuxLibDir());
/*     */           
/* 608 */           paths.add(root + getARMLinuxLibDir().replace("_arm", "_arm32_arm")); continue;
/*     */         } 
/* 610 */         paths.add(root + (is64Bits() ? "linux_x64/" : "linux_x86/")); continue;
/*     */       } 
/* 612 */       if (isSolaris()) {
/* 613 */         if (isSparc()) {
/* 614 */           paths.add(root + (is64Bits() ? "sunos_sparc64/" : "sunos_sparc/")); continue;
/*     */         } 
/* 616 */         paths.add(root + (is64Bits() ? "sunos_x64/" : "sunos_x86/"));
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 622 */     if (paths.isEmpty()) {
/* 623 */       throw new RuntimeException("Platform not supported ! (os.name='" + osName + "', os.arch='" + System.getProperty("os.arch") + "')");
/*     */     }
/* 625 */     return paths;
/*     */   }
/*     */   
/*     */   static synchronized List<String> getEmbeddedLibraryResource(String name) {
/* 629 */     List<String> paths = getEmbeddedLibraryPaths(name);
/* 630 */     List<String> fileNames = getPossibleFileNames(name);
/* 631 */     List<String> ret = new ArrayList<String>(paths.size() * fileNames.size());
/* 632 */     for (String path : paths) {
/* 633 */       for (String fileName : fileNames) {
/* 634 */         ret.add(path + fileName);
/*     */       }
/*     */     } 
/*     */     
/* 638 */     if (BridJ.veryVerbose) {
/* 639 */       BridJ.info("Embedded resource paths for library '" + name + "': " + ret);
/*     */     }
/* 641 */     return ret;
/*     */   }
/*     */   
/*     */   static void tryDeleteFilesInSameDirectory(final File legitFile, final Pattern fileNamePattern, long atLeastOlderThanMillis) {
/* 645 */     final long maxModifiedDateForDeletion = System.currentTimeMillis() - atLeastOlderThanMillis;
/* 646 */     (new Thread(new Runnable() {
/*     */           public void run() {
/* 648 */             File dir = legitFile.getParentFile();
/* 649 */             String legitFileName = legitFile.getName();
/*     */             try {
/* 651 */               for (String name : dir.list()) {
/* 652 */                 if (!name.equals(legitFileName))
/*     */                 {
/*     */ 
/*     */                   
/* 656 */                   if (fileNamePattern.matcher(name).matches()) {
/*     */ 
/*     */ 
/*     */                     
/* 660 */                     File file = new File(dir, name);
/* 661 */                     if (file.lastModified() <= maxModifiedDateForDeletion)
/*     */                     {
/*     */ 
/*     */                       
/* 665 */                       if (file.delete() && BridJ.verbose)
/* 666 */                         BridJ.info("Deleted old binary file '" + file + "'");  } 
/*     */                   }  } 
/*     */               } 
/* 669 */             } catch (SecurityException ex) {
/*     */               
/* 671 */               BridJ.warning("Failed to delete files matching '" + fileNamePattern + "' in directory '" + dir + "'", ex);
/* 672 */             } catch (Throwable ex) {
/* 673 */               BridJ.error("Unexpected error : " + ex, ex);
/*     */             } 
/*     */           }
/*     */         })).start();
/*     */   }
/*     */ 
/*     */   
/*     */   static File extractEmbeddedLibraryResource(String name) throws IOException {
/* 681 */     String firstLibraryResource = null;
/*     */     
/* 683 */     List<String> libraryResources = getEmbeddedLibraryResource(name);
/* 684 */     if (BridJ.veryVerbose) {
/* 685 */       BridJ.info("Library resources for " + name + ": " + libraryResources);
/*     */     }
/* 687 */     for (String libraryResource : libraryResources) {
/* 688 */       if (firstLibraryResource == null) {
/* 689 */         firstLibraryResource = libraryResource;
/*     */       }
/* 691 */       int i = libraryResource.lastIndexOf('.');
/*     */       
/* 693 */       byte[] b = new byte[8196];
/* 694 */       InputStream in = getResourceAsStream(libraryResource);
/* 695 */       if (in == null) {
/* 696 */         File f = new File(libraryResource);
/* 697 */         if (!f.exists()) {
/* 698 */           f = new File(f.getName());
/*     */         }
/* 700 */         if (f.exists()) {
/* 701 */           return f.getCanonicalFile();
/*     */         }
/*     */         continue;
/*     */       } 
/* 705 */       String fileName = (new File(libraryResource)).getName();
/* 706 */       File libFile = new File(extractedLibrariesTempDir, fileName);
/* 707 */       OutputStream out = new BufferedOutputStream(new FileOutputStream(libFile)); int len;
/* 708 */       while ((len = in.read(b)) > 0) {
/* 709 */         out.write(b, 0, len);
/*     */       }
/* 711 */       out.close();
/* 712 */       in.close();
/*     */       
/* 714 */       addTemporaryExtractedLibraryFileToDeleteOnExit(libFile);
/* 715 */       addTemporaryExtractedLibraryFileToDeleteOnExit(libFile.getParentFile());
/*     */       
/* 717 */       return libFile;
/*     */     } 
/* 719 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static File createTempDir(String prefix) throws IOException {
/* 725 */     for (int i = 0; i < 20; i++) {
/* 726 */       File dir = File.createTempFile(prefix, "");
/* 727 */       if (dir.delete() && dir.mkdirs()) {
/* 728 */         return dir;
/*     */       }
/*     */     } 
/* 731 */     throw new RuntimeException("Failed to create temp dir with prefix '" + prefix + "' despite " + '\024' + " attempts!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void open(URL url) throws NoSuchMethodException {
/* 742 */     if (url.getProtocol().equals("file")) {
/* 743 */       open(new File(url.getFile()));
/*     */     }
/* 745 */     else if (isMacOSX()) {
/* 746 */       execArgs(new String[] { "open", url.toString() });
/* 747 */     } else if (isWindows()) {
/* 748 */       execArgs(new String[] { "rundll32", "url.dll,FileProtocolHandler", url.toString() });
/* 749 */     } else if (isUnix() && hasUnixCommand("gnome-open")) {
/* 750 */       execArgs(new String[] { "gnome-open", url.toString() });
/* 751 */     } else if (isUnix() && hasUnixCommand("konqueror")) {
/* 752 */       execArgs(new String[] { "konqueror", url.toString() });
/* 753 */     } else if (isUnix() && hasUnixCommand("mozilla")) {
/* 754 */       execArgs(new String[] { "mozilla", url.toString() });
/*     */     } else {
/* 756 */       throw new NoSuchMethodException("Cannot open urls on this platform");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void open(File file) throws NoSuchMethodException {
/* 769 */     if (isMacOSX()) {
/* 770 */       execArgs(new String[] { "open", file.getAbsolutePath() });
/* 771 */     } else if (isWindows()) {
/* 772 */       if (file.isDirectory()) {
/* 773 */         execArgs(new String[] { "explorer", file.getAbsolutePath() });
/*     */       } else {
/* 775 */         execArgs(new String[] { "start", file.getAbsolutePath() });
/*     */       } 
/* 777 */     } else if (isUnix() && hasUnixCommand("gnome-open")) {
/* 778 */       execArgs(new String[] { "gnome-open", file.toString() });
/* 779 */     } else if (isUnix() && hasUnixCommand("konqueror")) {
/* 780 */       execArgs(new String[] { "konqueror", file.toString() });
/* 781 */     } else if (isSolaris() && file.isDirectory()) {
/* 782 */       execArgs(new String[] { "/usr/dt/bin/dtfile", "-folder", file.getAbsolutePath() });
/*     */     } else {
/* 784 */       throw new NoSuchMethodException("Cannot open files on this platform");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void show(File file) throws NoSuchMethodException, IOException {
/* 797 */     if (isWindows()) {
/* 798 */       exec("explorer /e,/select,\"" + file.getCanonicalPath() + "\"");
/*     */     } else {
/* 800 */       open(file.getAbsoluteFile().getParentFile());
/*     */     } 
/*     */   }
/*     */   
/*     */   static final void execArgs(String... cmd) throws NoSuchMethodException {
/*     */     try {
/* 806 */       Runtime.getRuntime().exec(cmd);
/* 807 */     } catch (Exception ex) {
/* 808 */       ex.printStackTrace();
/* 809 */       throw new NoSuchMethodException(ex.toString());
/*     */     } 
/*     */   }
/*     */   
/*     */   static final void exec(String cmd) throws NoSuchMethodException {
/*     */     try {
/* 815 */       Runtime.getRuntime().exec(cmd).waitFor();
/* 816 */     } catch (Exception ex) {
/* 817 */       ex.printStackTrace();
/* 818 */       throw new NoSuchMethodException(ex.toString());
/*     */     } 
/*     */   }
/*     */   
/*     */   static final boolean hasUnixCommand(String name) {
/*     */     try {
/* 824 */       Process p = Runtime.getRuntime().exec(new String[] { "which", name });
/* 825 */       return (p.waitFor() == 0);
/* 826 */     } catch (Exception ex) {
/* 827 */       ex.printStackTrace();
/* 828 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final boolean contains(String data, String[] search) {
/* 845 */     if (null != data && null != search) {
/* 846 */       for (int i = 0; i < search.length; i++) {
/* 847 */         if (data.indexOf(search[i]) >= 0) {
/* 848 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/* 852 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getBashVersionInfo() {
/* 862 */     String versionInfo = "";
/*     */ 
/*     */     
/* 865 */     try { String cmd = "bash --version";
/* 866 */       Process p = Runtime.getRuntime().exec(cmd);
/* 867 */       p.waitFor();
/* 868 */       BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
/* 869 */       String line = reader.readLine();
/* 870 */       if (p.exitValue() == 0) {
/* 871 */         while (line != null) {
/* 872 */           if (!line.isEmpty()) {
/* 873 */             versionInfo = line;
/*     */             break;
/*     */           } 
/* 876 */           line = reader.readLine();
/*     */         } 
/*     */       } }
/*     */     catch (IOException ioe)
/* 880 */     { ioe.printStackTrace(); }
/* 881 */     catch (InterruptedException ie) { ie.printStackTrace(); }
/* 882 */      return versionInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean hasReadElfTag(String tag) {
/* 892 */     String tagValue = getReadElfTag(tag);
/* 893 */     if (tagValue != null && !tagValue.isEmpty())
/* 894 */       return true; 
/* 895 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getReadElfTag(String tag) {
/* 905 */     String tagValue = null;
/*     */     
/* 907 */     try { String cmd = "/usr/bin/readelf -A /proc/self/exe";
/* 908 */       Process p = Runtime.getRuntime().exec(cmd);
/* 909 */       p.waitFor();
/* 910 */       if (p.exitValue() == 0) {
/* 911 */         BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
/* 912 */         String line = reader.readLine();
/* 913 */         while (line != null) {
/* 914 */           line = line.trim();
/* 915 */           if (line.startsWith(tag) && line.contains(":")) {
/* 916 */             String[] lineParts = line.split(":", 2);
/* 917 */             if (lineParts.length > 1)
/* 918 */               tagValue = lineParts[1].trim(); 
/*     */             break;
/*     */           } 
/* 921 */           line = reader.readLine();
/*     */         } 
/*     */       }  }
/*     */     catch (IOException ioe)
/* 925 */     { ioe.printStackTrace(); }
/* 926 */     catch (InterruptedException ie) { ie.printStackTrace(); }
/* 927 */      return tagValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String getARMLinuxLibDir() {
/* 944 */     boolean isHF = ((Boolean)AccessController.<Boolean>doPrivileged(new PrivilegedAction<Boolean>() {
/* 945 */           private final String[] gnueabihf = new String[] { "gnueabihf", "armhf" };
/*     */           public Boolean run() {
/* 947 */             if (Platform.contains(System.getProperty("sun.boot.library.path"), this.gnueabihf) || Platform.contains(System.getProperty("java.library.path"), this.gnueabihf) || Platform.contains(System.getProperty("java.home"), this.gnueabihf) || Platform.getBashVersionInfo().contains("gnueabihf") || Platform.hasReadElfTag("Tag_ABI_HardFP_use"))
/*     */             {
/*     */ 
/*     */ 
/*     */               
/* 952 */               return Boolean.valueOf(true);
/*     */             }
/* 954 */             return Boolean.valueOf(false);
/*     */           }
/*     */         })).booleanValue();
/* 957 */     return "linux_arm" + (isHF ? "hf" : "el") + "/";
/*     */   }
/*     */   
/*     */   private static native void init();
/*     */   
/*     */   static native int sizeOf_size_t();
/*     */   
/*     */   static native int sizeOf_time_t();
/*     */   
/*     */   static native int sizeOf_wchar_t();
/*     */   
/*     */   static native int sizeOf_ptrdiff_t();
/*     */   
/*     */   static native int sizeOf_long();
/*     */   
/*     */   static native int getMaxDirectMappingArgCount();
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\Platform.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */