/*     */ package edu.carleton.services;
/*     */ 
/*     */ import edu.carleton.encryption.AES;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.net.DatagramPacket;
/*     */ import java.net.DatagramSocket;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.NetworkInterface;
/*     */ import java.net.SocketAddress;
/*     */ import java.net.SocketException;
/*     */ import java.net.StandardSocketOptions;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.DatagramChannel;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.CopyOnWriteArraySet;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceLocator
/*     */   implements Closeable
/*     */ {
/*     */   private DatagramChannel datagramChannel;
/*     */   private InetSocketAddress inetSocketAddress;
/*     */   private UDPChannel returnChannel;
/*     */   private ServiceListener listener;
/*     */   private ConcurrentHashMap<String, CopyOnWriteArraySet<String>> map;
/*     */   
/*     */   public ServiceLocator(ServiceListener listener) {
/*  38 */     this.listener = listener;
/*  39 */     this.map = new ConcurrentHashMap<>();
/*  40 */     ServiceUtility.closeOnExit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() throws IOException {
/*  49 */     String i_f = ServiceUtility.findInterface();
/*  50 */     String i_ip = ServiceUtility.findIP();
/*  51 */     open(ServiceUtility.MULTICAST_IP, i_f, i_ip, ServiceUtility.MULTICAST_PORT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open(String ip, String iface, String i_ip, int port) throws IOException {
/*  63 */     this.datagramChannel = DatagramChannel.open();
/*  64 */     this.datagramChannel.bind((SocketAddress)null);
/*  65 */     NetworkInterface networkInterface = NetworkInterface.getByName(iface);
/*  66 */     if (networkInterface == null)
/*  67 */       networkInterface = NetworkInterface.getByInetAddress(InetAddress.getByName(i_ip)); 
/*  68 */     this.datagramChannel.setOption(StandardSocketOptions.IP_MULTICAST_IF, networkInterface);
/*  69 */     this.inetSocketAddress = new InetSocketAddress(ip, port);
/*     */     
/*  71 */     this.returnChannel = new UDPChannel(port + 1, this.listener);
/*  72 */     this.returnChannel.open();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CopyOnWriteArraySet<String> serviceProviders(String service) {
/*  82 */     CopyOnWriteArraySet<String> providers = this.map.get(service);
/*  83 */     if (providers == null) {
/*  84 */       providers = new CopyOnWriteArraySet<>();
/*  85 */       this.map.put(service, providers);
/*     */     } 
/*  87 */     return providers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addProvider(String service, String provider) {
/*  97 */     serviceProviders(service).add(provider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeProvider(String service, String provider) {
/* 107 */     serviceProviders(service).remove(provider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasProvider(String service) {
/* 117 */     return !serviceProviders(service).isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(String service) throws IOException {
/* 127 */     String address = ServiceUtility.findIP();
/* 128 */     send("subscribe" + ServiceUtility.DELIMETER + service + ServiceUtility.DELIMETER + address + 
/* 129 */         ServiceUtility.DELIMETER + ServiceUtility.MULTICAST_RETURN_PORT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsubscribe(String service) throws IOException {
/* 139 */     String address = ServiceUtility.findIP();
/* 140 */     send("unsubscribe" + ServiceUtility.DELIMETER + service + ServiceUtility.DELIMETER + address + 
/* 141 */         ServiceUtility.DELIMETER + ServiceUtility.MULTICAST_RETURN_PORT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(String message) throws IOException {
/* 151 */     if (this.datagramChannel != null) {
/* 152 */       String encryptedMessage = AES.encrypt(message);
/* 153 */       ByteBuffer byteBuffer = ByteBuffer.wrap(encryptedMessage.getBytes("UTF-8"));
/* 154 */       this.datagramChannel.send(byteBuffer, this.inetSocketAddress);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 163 */     unsubscribe("*");
/* 164 */     if (this.datagramChannel != null && 
/* 165 */       this.datagramChannel.isOpen())
/* 166 */       this.datagramChannel.close(); 
/* 167 */     if (this.returnChannel != null)
/* 168 */       this.returnChannel.close(); 
/* 169 */     this.map.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   private class UDPChannel
/*     */     implements Runnable
/*     */   {
/*     */     DatagramSocket socket;
/*     */     
/*     */     ServiceListener listener;
/*     */     
/*     */     Thread thread;
/*     */     
/*     */     AtomicBoolean isRunning;
/*     */ 
/*     */     
/*     */     public UDPChannel(int port, ServiceListener listener) throws SocketException {
/* 186 */       this.listener = listener;
/* 187 */       this.isRunning = new AtomicBoolean(false);
/* 188 */       this.socket = new DatagramSocket(port);
/*     */     }
/*     */     
/*     */     private synchronized void open() {
/* 192 */       this.thread = new Thread(this);
/* 193 */       this.thread.start();
/*     */     }
/*     */     
/*     */     private DatagramPacket read() throws IOException {
/* 197 */       DatagramPacket pkt = new DatagramPacket(new byte[1024], 1024);
/* 198 */       this.socket.receive(pkt);
/* 199 */       return pkt;
/*     */     }
/*     */     
/*     */     private void process(String msg) {
/* 203 */       if (ServiceUtility.DEBUG)
/* 204 */         System.out.println("ServiceLocator: [" + msg + "]"); 
/* 205 */       String[] fields = msg.split(ServiceUtility.DELIMETER);
/* 206 */       if (fields != null && 
/* 207 */         fields.length >= 2) {
/* 208 */         if (fields[0].equals("added")) {
/* 209 */           ServiceLocator.this.addProvider(fields[1], fields[2]);
/* 210 */           this.listener.onAdd(fields[1], fields[2]);
/*     */         } 
/* 212 */         if (fields[0].equals("removed")) {
/* 213 */           ServiceLocator.this.removeProvider(fields[1], fields[2]);
/* 214 */           this.listener.onRemove(fields[1], fields[2]);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private synchronized void close() {
/* 221 */       this.thread.interrupt();
/* 222 */       if (this.socket != null && 
/* 223 */         !this.socket.isClosed()) {
/* 224 */         this.socket.close();
/*     */       }
/*     */     }
/*     */     
/*     */     public void run() {
/* 229 */       this.isRunning.set(true);
/* 230 */       while (this.isRunning.get()) {
/*     */         try {
/* 232 */           DatagramPacket pkt = read();
/*     */ 
/*     */           
/* 235 */           String encryptedMessage = (new String(pkt.getData())).trim();
/* 236 */           if (ServiceUtility.DEBUG)
/* 237 */             System.out.println("ServiceLocator encryptedMessage: [" + encryptedMessage + "]"); 
/* 238 */           String msg = AES.decrypt(encryptedMessage);
/* 239 */           if (ServiceUtility.DEBUG)
/* 240 */             System.out.println("ServiceLocator msg: [" + msg + "]"); 
/* 241 */           process(msg);
/*     */         }
/* 243 */         catch (Exception e) {
/* 244 */           this.isRunning.set(false);
/* 245 */           if (ServiceUtility.DEBUG)
/* 246 */             System.out.println(e); 
/*     */         } 
/*     */       } 
/* 249 */       close();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\sd.jar!\edu\carleton\services\ServiceLocator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */