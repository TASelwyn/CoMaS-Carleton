/*     */ package edu.carleton.services;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.NetworkInterface;
/*     */ import java.net.SocketException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceUtility
/*     */ {
/*     */   public static final int PUBLISH = 1;
/*     */   public static final int UNPUBLISH = 2;
/*     */   public static final int SUBSCRIBE = 3;
/*     */   public static final int UNSUBSCRIBE = 4;
/*  26 */   protected static int MULTICAST_PORT = 4321;
/*  27 */   protected static int MULTICAST_BROWSER_PORT = MULTICAST_PORT - 1;
/*  28 */   protected static int MULTICAST_RETURN_PORT = MULTICAST_PORT + 1;
/*  29 */   protected static String MULTICAST_IP = "230.0.0.0";
/*     */   
/*  31 */   protected static String DELIMETER = "#";
/*  32 */   protected static String VALID_STRING_PATTERN = "^[A-Za-z0-9+/]+={0,2}$";
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean DEBUG = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setDebug(boolean debug) {
/*  42 */     DEBUG = debug;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setPort(int port) {
/*  51 */     MULTICAST_PORT = port;
/*  52 */     MULTICAST_RETURN_PORT = port + 1;
/*  53 */     MULTICAST_BROWSER_PORT = port - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setIP(String ip) {
/*  61 */     MULTICAST_IP = ip;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getPort() {
/*  70 */     return MULTICAST_PORT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getReturnPort() {
/*  78 */     return MULTICAST_RETURN_PORT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getBrowserPort() {
/*  87 */     return MULTICAST_BROWSER_PORT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getIP() {
/*  96 */     return MULTICAST_IP;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String findInterface() throws SocketException {
/* 106 */     String i_f = null;
/* 107 */     Enumeration<NetworkInterface> ni = NetworkInterface.getNetworkInterfaces();
/* 108 */     while (ni.hasMoreElements()) {
/* 109 */       NetworkInterface i = ni.nextElement();
/* 110 */       Enumeration<InetAddress> ia = i.getInetAddresses();
/* 111 */       while (ia.hasMoreElements()) {
/* 112 */         InetAddress a = ia.nextElement();
/* 113 */         if (DEBUG)
/* 114 */           System.out.println(String.valueOf(i.getDisplayName()) + " Up: " + i.isUp() + " Multi: " + 
/* 115 */               i.supportsMulticast() + " linkLocal: " + a.isLinkLocalAddress() + " address: " + 
/* 116 */               a.getHostAddress()); 
/* 117 */         if (i.supportsMulticast() && !a.isLoopbackAddress() && !a.isAnyLocalAddress() && 
/* 118 */           !a.isLinkLocalAddress()) {
/* 119 */           i_f = i.getDisplayName();
/*     */         }
/*     */       } 
/*     */     } 
/* 123 */     if (DEBUG)
/* 124 */       System.out.println("Interface: " + i_f); 
/* 125 */     return i_f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String findIP() throws SocketException {
/* 135 */     String i_f = null;
/* 136 */     Enumeration<NetworkInterface> ni = NetworkInterface.getNetworkInterfaces();
/* 137 */     while (ni.hasMoreElements()) {
/* 138 */       NetworkInterface i = ni.nextElement();
/* 139 */       Enumeration<InetAddress> ia = i.getInetAddresses();
/* 140 */       while (ia.hasMoreElements()) {
/* 141 */         InetAddress a = ia.nextElement();
/* 142 */         if (DEBUG)
/* 143 */           System.out.println(String.valueOf(i.getDisplayName()) + " Up: " + i.isUp() + " Multi: " + 
/* 144 */               i.supportsMulticast() + " linkLocal: " + a.isLinkLocalAddress() + " address: " + 
/* 145 */               a.getHostAddress()); 
/* 146 */         if (i.supportsMulticast() && !a.isLoopbackAddress() && !a.isAnyLocalAddress() && 
/* 147 */           !a.isLinkLocalAddress()) {
/* 148 */           i_f = a.getHostAddress();
/*     */         }
/*     */       } 
/*     */     } 
/* 152 */     if (DEBUG)
/* 153 */       System.out.println("IP: " + i_f); 
/* 154 */     return i_f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void closeOnExit(Closeable closeable) {
/* 163 */     Runtime.getRuntime().addShutdownHook(new Thread(new CloseOnExit(closeable)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class CloseOnExit
/*     */     implements Runnable
/*     */   {
/*     */     final Closeable closeable;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     CloseOnExit(Closeable closeable) {
/* 178 */       this.closeable = closeable;
/*     */     }
/*     */     
/*     */     public void run() {
/*     */       try {
/* 183 */         this.closeable.close();
/* 184 */       } catch (IOException iOException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ProcessorThread
/*     */     extends Thread
/*     */   {
/*     */     private AtomicBoolean isRunning;
/*     */ 
/*     */ 
/*     */     
/*     */     private Processor publisher;
/*     */ 
/*     */ 
/*     */     
/*     */     public ProcessorThread(Processor publisher) {
/* 203 */       this.isRunning = new AtomicBoolean(false);
/* 204 */       this.publisher = publisher;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 209 */       this.isRunning.set(true);
/* 210 */       while (this.isRunning.get()) {
/*     */         try {
/* 212 */           this.publisher.process();
/* 213 */         } catch (ProcessingException e) {
/* 214 */           if (!this.isRunning.get() && 
/* 215 */             ServiceUtility.DEBUG)
/* 216 */             System.out.println(String.valueOf(this.publisher.getClass().getSimpleName()) + " has stopped"); 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public void close() {
/* 222 */       this.isRunning.set(false);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\sd.jar!\edu\carleton\services\ServiceUtility.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */