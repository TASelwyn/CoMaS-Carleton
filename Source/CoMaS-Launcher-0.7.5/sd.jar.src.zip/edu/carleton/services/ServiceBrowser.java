/*     */ package edu.carleton.services;
/*     */ 
/*     */ import edu.carleton.encryption.AES;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.NetworkInterface;
/*     */ import java.net.SocketException;
/*     */ import java.net.StandardProtocolFamily;
/*     */ import java.net.StandardSocketOptions;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.DatagramChannel;
/*     */ import java.nio.channels.MembershipKey;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceBrowser
/*     */   implements Processor, Closeable
/*     */ {
/*     */   private ServiceUtility.ProcessorThread reader;
/*     */   private DatagramChannel datagramChannel;
/*     */   private MembershipKey membershipKey;
/*     */   private ServiceListener listener;
/*     */   
/*     */   public ServiceBrowser(ServiceListener listener) throws SocketException, IOException {
/*  38 */     this(ServiceUtility.MULTICAST_IP, ServiceUtility.findInterface(), ServiceUtility.findIP(), ServiceUtility.MULTICAST_BROWSER_PORT, listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ServiceBrowser(String ip, String iface, String i_ip, int port, ServiceListener listener) throws SocketException, IOException {
/*  52 */     open(ip, iface, i_ip, port);
/*  53 */     this.listener = listener;
/*  54 */     ServiceUtility.closeOnExit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void open(String ip, String iface, String i_ip, int port) throws IOException {
/*  68 */     this.datagramChannel = DatagramChannel.open(StandardProtocolFamily.INET);
/*  69 */     NetworkInterface networkInterface = NetworkInterface.getByName(iface);
/*  70 */     if (networkInterface == null)
/*  71 */       networkInterface = NetworkInterface.getByInetAddress(InetAddress.getByName(i_ip)); 
/*  72 */     this.datagramChannel.setOption(StandardSocketOptions.SO_REUSEADDR, Boolean.valueOf(true));
/*  73 */     this.datagramChannel.bind(new InetSocketAddress(port));
/*  74 */     this.datagramChannel.setOption(StandardSocketOptions.IP_MULTICAST_IF, networkInterface);
/*  75 */     this.datagramChannel.configureBlocking(true);
/*  76 */     InetAddress inetAddress = InetAddress.getByName(ip);
/*  77 */     this.membershipKey = this.datagramChannel.join(inetAddress, networkInterface);
/*  78 */     this.reader = new ServiceUtility.ProcessorThread(this);
/*  79 */     this.reader.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  86 */     this.reader.close();
/*  87 */     this.reader.interrupt();
/*  88 */     this.membershipKey.drop();
/*  89 */     if (this.datagramChannel.isOpen()) {
/*  90 */       this.datagramChannel.close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String read() throws IOException {
/* 100 */     ByteBuffer byteBuffer = ByteBuffer.allocate(1024);
/* 101 */     this.datagramChannel.receive(byteBuffer);
/* 102 */     byteBuffer.flip();
/* 103 */     byte[] bytes = new byte[byteBuffer.limit()];
/* 104 */     byteBuffer.get(bytes, 0, byteBuffer.limit());
/* 105 */     return new String(bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void process() throws ProcessingException {
/* 114 */     String msg = null;
/* 115 */     String encryptedMessage = null;
/*     */     try {
/* 117 */       encryptedMessage = read();
/*     */       
/* 119 */       encryptedMessage = encryptedMessage.trim();
/* 120 */       msg = AES.decrypt(encryptedMessage);
/*     */       
/* 122 */       if (ServiceUtility.DEBUG)
/* 123 */         System.out.println("ServiceBrowser: [" + msg + "]"); 
/* 124 */     } catch (IOException e) {
/* 125 */       throw new ProcessingException(e.getMessage());
/*     */     } 
/*     */     
/* 128 */     String[] fields = msg.split(ServiceUtility.DELIMETER);
/* 129 */     if (fields == null)
/* 130 */       throw new ProcessingException("Unknown message format: " + msg); 
/* 131 */     if (fields.length != 3) {
/* 132 */       throw new ProcessingException("Illegal number of fields: " + fields.length);
/*     */     }
/*     */     
/* 135 */     if (fields[0].equals("added")) {
/* 136 */       this.listener.onAdd(fields[1], fields[2]);
/* 137 */     } else if (fields[0].equals("removed")) {
/* 138 */       this.listener.onRemove(fields[1], fields[2]);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\sd.jar!\edu\carleton\services\ServiceBrowser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */