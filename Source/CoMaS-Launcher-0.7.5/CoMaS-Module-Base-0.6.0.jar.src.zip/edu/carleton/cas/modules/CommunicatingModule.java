package edu.carleton.cas.modules;

public interface CommunicatingModule extends Module {
  void receive(String paramString1, String paramString2);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\CoMaS-Module-Base-0.6.0.jar!\edu\carleton\cas\modules\CommunicatingModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */