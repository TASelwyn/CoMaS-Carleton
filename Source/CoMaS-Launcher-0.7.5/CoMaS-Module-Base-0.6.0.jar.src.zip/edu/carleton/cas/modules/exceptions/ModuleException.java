/*    */ package edu.carleton.cas.modules.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModuleException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public ModuleException() {}
/*    */   
/*    */   public ModuleException(String message, Throwable throwable) {
/* 14 */     super(message, throwable);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\CoMaS-Module-Base-0.6.0.jar!\edu\carleton\cas\modules\exceptions\ModuleException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */