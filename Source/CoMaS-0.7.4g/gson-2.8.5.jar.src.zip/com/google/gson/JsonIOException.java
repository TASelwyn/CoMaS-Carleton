package com.google.gson;

public final class JsonIOException extends JsonParseException {
  private static final long serialVersionUID = 1L;
  
  public JsonIOException(String msg) {
    super(msg);
  }
  
  public JsonIOException(String msg, Throwable cause) {
    super(msg, cause);
  }
  
  public JsonIOException(Throwable cause) {
    super(cause);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\gson-2.8.5.jar!\com\google\gson\JsonIOException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */