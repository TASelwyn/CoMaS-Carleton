package com.google.gson.internal;

public final class JavaVersion {
  private static final int majorJavaVersion = determineMajorJavaVersion();
  
  private static int determineMajorJavaVersion() {
    String javaVersion = System.getProperty("java.version");
    return getMajorJavaVersion(javaVersion);
  }
  
  static int getMajorJavaVersion(String javaVersion) {
    int version = parseDotted(javaVersion);
    if (version == -1)
      version = extractBeginningInt(javaVersion); 
    if (version == -1)
      return 6; 
    return version;
  }
  
  private static int parseDotted(String javaVersion) {
    try {
      String[] parts = javaVersion.split("[._]");
      int firstVer = Integer.parseInt(parts[0]);
      if (firstVer == 1 && parts.length > 1)
        return Integer.parseInt(parts[1]); 
      return firstVer;
    } catch (NumberFormatException e) {
      return -1;
    } 
  }
  
  private static int extractBeginningInt(String javaVersion) {
    try {
      StringBuilder num = new StringBuilder();
      for (int i = 0; i < javaVersion.length(); ) {
        char c = javaVersion.charAt(i);
        if (Character.isDigit(c)) {
          num.append(c);
          i++;
        } 
      } 
      return Integer.parseInt(num.toString());
    } catch (NumberFormatException e) {
      return -1;
    } 
  }
  
  public static int getMajorJavaVersion() {
    return majorJavaVersion;
  }
  
  public static boolean isJava9OrLater() {
    return (majorJavaVersion >= 9);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\gson-2.8.5.jar!\com\google\gson\internal\JavaVersion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */