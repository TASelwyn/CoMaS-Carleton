package com.google.gson.internal;

public final class GsonBuildConfig {
  public static final String VERSION = "2.8.5";
}
