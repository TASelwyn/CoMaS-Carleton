package com.sun.media;

import java.awt.Frame;
import javax.media.Buffer;
import javax.media.Codec;
import javax.media.Format;
import javax.media.ResourceUnavailableException;
import javax.media.control.FrameProcessingControl;

public class BasicFilterModule extends BasicModule {
  protected Codec codec;
  
  protected InputConnector ic;
  
  protected OutputConnector oc;
  
  protected FrameProcessingControl frameControl = null;
  
  protected float curFramesBehind = 0.0F;
  
  protected float prevFramesBehind = 0.0F;
  
  protected Frame controlFrame;
  
  protected final boolean VERBOSE_CONTROL = false;
  
  protected Buffer storedInputBuffer;
  
  protected Buffer storedOutputBuffer;
  
  protected boolean readPendingFlag;
  
  protected boolean writePendingFlag;
  
  private boolean failed;
  
  private boolean markerSet;
  
  private Object lastHdr;
  
  public boolean doRealize() {
    if (this.codec != null)
      try {
        this.codec.open();
      } catch (ResourceUnavailableException rue) {
        return false;
      }  
    return true;
  }
  
  public boolean doPrefetch() {
    return super.doPrefetch();
  }
  
  public void doClose() {
    if (this.codec != null)
      this.codec.close(); 
    if (this.controlFrame != null) {
      this.controlFrame.dispose();
      this.controlFrame = null;
    } 
  }
  
  public void setFormat(Connector c, Format f) {
    if (c == this.ic) {
      if (this.codec != null)
        this.codec.setInputFormat(f); 
    } else if (c == this.oc && 
      this.codec != null) {
      this.codec.setOutputFormat(f);
    } 
  }
  
  public boolean setCodec(String codec) {
    return true;
  }
  
  public boolean setCodec(Codec codec) {
    this.codec = codec;
    return true;
  }
  
  public Codec getCodec() {
    return this.codec;
  }
  
  public boolean isThreaded() {
    if (getProtocol() == 1)
      return true; 
    return false;
  }
  
  public Object[] getControls() {
    return this.codec.getControls();
  }
  
  public Object getControl(String s) {
    return this.codec.getControl(s);
  }
  
  protected void setFramesBehind(float framesBehind) {
    this.curFramesBehind = framesBehind;
  }
  
  protected boolean reinitCodec(Format input) {
    if (this.codec != null) {
      if (this.codec.setInputFormat(input) != null)
        return true; 
      this.codec.close();
      this.codec = null;
    } 
    Codec c;
    if ((c = SimpleGraphBuilder.findCodec(input, null, null, null)) == null)
      return false; 
    setCodec(c);
    return true;
  }
  
  public BasicFilterModule(Codec c) {
    this.readPendingFlag = false;
    this.writePendingFlag = false;
    this.failed = false;
    this.markerSet = false;
    this.lastHdr = null;
    this.ic = new BasicInputConnector();
    registerInputConnector("input", this.ic);
    this.oc = new BasicOutputConnector();
    registerOutputConnector("output", this.oc);
    setCodec(c);
    this.protocol = 0;
    Object control = c.getControl("javax.media.control.FrameProcessingControl");
    if (control instanceof FrameProcessingControl)
      this.frameControl = (FrameProcessingControl)control; 
  }
  
  public void process() {
    do {
      Buffer buffer1, buffer2;
      if (this.readPendingFlag) {
        buffer1 = this.storedInputBuffer;
      } else {
        buffer1 = this.ic.getValidBuffer();
        Format incomingFormat = buffer1.getFormat();
        if (incomingFormat == null) {
          incomingFormat = this.ic.getFormat();
          buffer1.setFormat(incomingFormat);
        } 
        if (incomingFormat != this.ic.getFormat() && incomingFormat != null && !incomingFormat.equals(this.ic.getFormat()) && !buffer1.isDiscard()) {
          if (this.writePendingFlag) {
            this.storedOutputBuffer.setDiscard(true);
            this.oc.writeReport();
            this.writePendingFlag = false;
          } 
          if (!reinitCodec(buffer1.getFormat())) {
            buffer1.setDiscard(true);
            this.ic.readReport();
            this.failed = true;
            if (this.moduleListener != null)
              this.moduleListener.formatChangedFailure(this, this.ic.getFormat(), buffer1.getFormat()); 
            return;
          } 
          Format oldFormat = this.ic.getFormat();
          this.ic.setFormat(buffer1.getFormat());
          if (this.moduleListener != null)
            this.moduleListener.formatChanged(this, oldFormat, buffer1.getFormat()); 
        } 
        if ((buffer1.getFlags() & 0x400) != 0)
          this.markerSet = true; 
        if (PlaybackEngine.DEBUG && buffer1 != null)
          this.jmd.moduleIn(this, 0, buffer1, true); 
      } 
      if (this.writePendingFlag) {
        buffer2 = this.storedOutputBuffer;
      } else {
        buffer2 = this.oc.getEmptyBuffer();
        if (buffer2 != null) {
          if (PlaybackEngine.DEBUG)
            this.jmd.moduleOut(this, 0, buffer2, true); 
          buffer2.setLength(0);
          buffer2.setOffset(0);
          this.lastHdr = buffer2.getHeader();
        } 
      } 
      buffer2.setTimeStamp(buffer1.getTimeStamp());
      buffer2.setDuration(buffer1.getDuration());
      buffer2.setSequenceNumber(buffer1.getSequenceNumber());
      buffer2.setFlags(buffer1.getFlags());
      buffer2.setHeader(buffer1.getHeader());
      if (this.resetted) {
        if ((buffer1.getFlags() & 0x200) != 0) {
          this.codec.reset();
          this.resetted = false;
        } 
        this.readPendingFlag = this.writePendingFlag = false;
        this.ic.readReport();
        this.oc.writeReport();
        return;
      } 
      if (this.failed || buffer1.isDiscard()) {
        if (this.markerSet) {
          buffer2.setFlags(buffer2.getFlags() & 0xFFFFFBFF);
          this.markerSet = false;
        } 
        this.curFramesBehind = 0.0F;
        this.ic.readReport();
        if (!this.writePendingFlag)
          this.oc.writeReport(); 
        return;
      } 
      if (this.frameControl != null && this.curFramesBehind != this.prevFramesBehind && (buffer1.getFlags() & 0x20) == 0) {
        this.frameControl.setFramesBehind(this.curFramesBehind);
        this.prevFramesBehind = this.curFramesBehind;
      } 
      int rc = 0;
      try {
        rc = this.codec.process(buffer1, buffer2);
      } catch (Throwable e) {
        Log.dumpStack(e);
        if (this.moduleListener != null)
          this.moduleListener.internalErrorOccurred(this); 
      } 
      if (PlaybackEngine.TRACE_ON && !verifyBuffer(buffer2)) {
        System.err.println("verify buffer failed: " + this.codec);
        Thread.dumpStack();
        if (this.moduleListener != null)
          this.moduleListener.internalErrorOccurred(this); 
      } 
      if ((rc & 0x8) != 0) {
        this.failed = true;
        if (this.moduleListener != null)
          this.moduleListener.pluginTerminated(this); 
        this.readPendingFlag = this.writePendingFlag = false;
        this.ic.readReport();
        this.oc.writeReport();
        return;
      } 
      if (this.curFramesBehind > 0.0F && buffer2.isDiscard()) {
        this.curFramesBehind--;
        if (this.curFramesBehind < 0.0F)
          this.curFramesBehind = 0.0F; 
        this;
        rc &= 0x4 ^ 0xFFFFFFFF;
      } 
      this;
      if ((rc & 0x1) != 0) {
        buffer2.setDiscard(true);
        if (this.markerSet) {
          buffer2.setFlags(buffer2.getFlags() & 0xFFFFFBFF);
          this.markerSet = false;
        } 
        if (PlaybackEngine.DEBUG)
          this.jmd.moduleIn(this, 0, buffer1, false); 
        this.ic.readReport();
        if (PlaybackEngine.DEBUG)
          this.jmd.moduleOut(this, 0, buffer2, false); 
        this.oc.writeReport();
        this.readPendingFlag = this.writePendingFlag = false;
        return;
      } 
      this;
      this;
      if (buffer2.isEOM() && ((rc & 0x2) != 0 || (rc & 0x4) != 0))
        buffer2.setEOM(false); 
      this;
      if ((rc & 0x4) != 0) {
        this.writePendingFlag = true;
        this.storedOutputBuffer = buffer2;
      } else {
        if (PlaybackEngine.DEBUG)
          this.jmd.moduleOut(this, 0, buffer2, false); 
        if (this.markerSet) {
          buffer2.setFlags(buffer2.getFlags() | 0x400);
          this.markerSet = false;
        } 
        this.oc.writeReport();
        this.writePendingFlag = false;
      } 
      this;
      if ((rc & 0x2) != 0 || (buffer1.isEOM() && !buffer2.isEOM())) {
        this.readPendingFlag = true;
        this.storedInputBuffer = buffer1;
      } else {
        if (PlaybackEngine.DEBUG)
          this.jmd.moduleIn(this, 0, buffer1, false); 
        buffer1.setHeader(this.lastHdr);
        this.ic.readReport();
        this.readPendingFlag = false;
      } 
    } while (this.readPendingFlag);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\BasicFilterModule.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */