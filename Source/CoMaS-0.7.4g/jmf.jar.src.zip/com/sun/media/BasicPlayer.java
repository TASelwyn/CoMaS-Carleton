/*      */ package com.sun.media;
/*      */ import com.ms.security.PermissionID;
/*      */ import com.ms.security.PolicyEngine;
/*      */ import com.sun.media.controls.SliderRegionControl;
/*      */ import com.sun.media.controls.SliderRegionControlAdapter;
/*      */ import com.sun.media.ui.DefaultControlPanel;
/*      */ import com.sun.media.util.jdk12;
/*      */ import java.awt.Component;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.util.Vector;
/*      */ import javax.media.CachingControl;
/*      */ import javax.media.CachingControlEvent;
/*      */ import javax.media.ClockStartedError;
/*      */ import javax.media.Control;
/*      */ import javax.media.Controller;
/*      */ import javax.media.ControllerClosedEvent;
/*      */ import javax.media.ControllerErrorEvent;
/*      */ import javax.media.ControllerEvent;
/*      */ import javax.media.Duration;
/*      */ import javax.media.EndOfMediaEvent;
/*      */ import javax.media.ExtendedCachingControl;
/*      */ import javax.media.GainControl;
/*      */ import javax.media.IncompatibleTimeBaseException;
/*      */ import javax.media.NotRealizedError;
/*      */ import javax.media.RestartingEvent;
/*      */ import javax.media.SizeChangeEvent;
/*      */ import javax.media.StopByRequestEvent;
/*      */ import javax.media.StopEvent;
/*      */ import javax.media.StopTimeChangeEvent;
/*      */ import javax.media.Time;
/*      */ import javax.media.TimeBase;
/*      */ import javax.media.protocol.DataSource;
/*      */ import javax.media.protocol.RateConfiguration;
/*      */ import javax.media.protocol.RateConfigureable;
/*      */ import javax.media.protocol.RateRange;
/*      */ 
/*      */ public abstract class BasicPlayer extends BasicController implements Player, ControllerListener, DownloadProgressListener {
/*   38 */   public static String VERSION = JMFI18N.getResource("mediaplayer.version");
/*      */ 
/*      */   
/*   41 */   protected DataSource source = null;
/*   42 */   protected Vector controllerList = new Vector();
/*   43 */   private Vector optionalControllerList = new Vector();
/*   44 */   private Vector removedControllerList = new Vector();
/*   45 */   private Vector currentControllerList = new Vector();
/*   46 */   private Vector potentialEventsList = null;
/*   47 */   private Vector receivedEventList = new Vector();
/*      */   private boolean receivedAllEvents = false;
/*   49 */   private Vector configureEventList = new Vector();
/*   50 */   private Vector realizeEventList = new Vector();
/*   51 */   private Vector prefetchEventList = new Vector();
/*   52 */   private Vector stopEventList = new Vector();
/*   53 */   private ControllerEvent CachingControlEvent = null;
/*   54 */   private Controller restartFrom = null;
/*   55 */   private Vector eomEventsReceivedFrom = new Vector();
/*   56 */   private Vector stopAtTimeReceivedFrom = new Vector();
/*   57 */   private PlayThread playThread = null;
/*   58 */   private StatsThread statsThread = null;
/*   59 */   private Time duration = Duration.DURATION_UNKNOWN;
/*      */   
/*      */   private Time startTime;
/*      */   private Time mediaTimeAtStart;
/*      */   private boolean aboutToRestart = false;
/*      */   private boolean closing = false;
/*      */   private boolean prefetchFailed = false;
/*      */   protected boolean framePositioning = true;
/*   67 */   protected Control[] controls = null;
/*   68 */   protected Component controlComp = null;
/*      */ 
/*      */   
/*   71 */   public SliderRegionControl regionControl = null;
/*      */   
/*   73 */   protected CachingControl cachingControl = null;
/*   74 */   protected ExtendedCachingControl extendedCachingControl = null;
/*   75 */   protected BufferControl bufferControl = null;
/*      */   
/*   77 */   private Object startSync = new Object();
/*   78 */   private Object mediaTimeSync = new Object();
/*      */   
/*   80 */   private static JMFSecurity jmfSecurity = null;
/*      */   private static boolean securityPrivelege = false;
/*   82 */   private Method[] m = new Method[1];
/*   83 */   private Class[] cl = new Class[1];
/*   84 */   private Object[][] args = new Object[1][0]; long lastTime; static final int LOCAL_STOP = 0; static final int STOP_BY_REQUEST = 1; static final int RESTARTING = 2;
/*      */   
/*      */   static {
/*      */     try {
/*   88 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*   89 */       securityPrivelege = true;
/*   90 */     } catch (SecurityException e) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFramePositionable() {
/*  116 */     return this.framePositioning;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isConfigurable() {
/*  123 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
/*  139 */     this.source = source;
/*      */     
/*      */     try {
/*  142 */       this.cachingControl = (CachingControl)source.getControl("javax.media.CachingControl");
/*  143 */       if (this.cachingControl != null && this.cachingControl instanceof ExtendedCachingControl) {
/*      */         
/*  145 */         this.extendedCachingControl = (ExtendedCachingControl)this.cachingControl;
/*  146 */         if (this.extendedCachingControl != null) {
/*      */           
/*  148 */           this.regionControl = (SliderRegionControl)new SliderRegionControlAdapter();
/*  149 */           this.extendedCachingControl.addDownloadProgressListener(this, 100);
/*      */         } 
/*      */       } 
/*  152 */     } catch (ClassCastException e) {}
/*      */   }
/*      */   
/*      */   public void downloadUpdate() {
/*      */     int i;
/*  157 */     if (this.extendedCachingControl == null) {
/*      */       return;
/*      */     }
/*      */     
/*  161 */     sendEvent((ControllerEvent)new CachingControlEvent(this, this.cachingControl, this.cachingControl.getContentProgress()));
/*      */ 
/*      */     
/*  164 */     if (this.regionControl == null) {
/*      */       return;
/*      */     }
/*  167 */     long contentLength = this.cachingControl.getContentLength();
/*      */     
/*  169 */     if (contentLength == -1L || contentLength <= 0L) {
/*      */       
/*  171 */       i = 0;
/*      */     } else {
/*  173 */       long endOffset = this.extendedCachingControl.getEndOffset();
/*  174 */       i = (int)(100.0D * endOffset / contentLength);
/*  175 */       if (i < 0) {
/*  176 */         i = 0;
/*  177 */       } else if (i > 100) {
/*  178 */         i = 100;
/*      */       } 
/*  180 */     }  this.regionControl.setMinValue(0L);
/*  181 */     this.regionControl.setMaxValue(i);
/*      */   }
/*      */   
/*      */   public MediaLocator getMediaLocator() {
/*  185 */     if (this.source != null)
/*  186 */       return this.source.getLocator(); 
/*  187 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getContentType() {
/*  192 */     if (this.source != null)
/*  193 */       return this.source.getContentType(); 
/*  194 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DataSource getSource() {
/*  203 */     return this.source;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doClose() {
/*  214 */     synchronized (this) {
/*  215 */       this.closing = true;
/*  216 */       notifyAll();
/*      */     } 
/*      */     
/*  219 */     if (getState() == 600)
/*      */     {
/*  221 */       stop(0);
/*      */     }
/*      */ 
/*      */     
/*  225 */     if (this.controllerList != null)
/*      */     {
/*  227 */       while (!this.controllerList.isEmpty()) {
/*  228 */         Controller c = this.controllerList.firstElement();
/*  229 */         c.close();
/*  230 */         this.controllerList.removeElement(c);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  235 */     if (this.controlComp != null)
/*  236 */       ((DefaultControlPanel)this.controlComp).dispose(); 
/*  237 */     this.controlComp = null;
/*      */     
/*  239 */     if (this.statsThread != null) {
/*  240 */       this.statsThread.kill();
/*      */     }
/*  242 */     sendEvent((ControllerEvent)new ControllerClosedEvent(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimeBase(TimeBase tb) throws IncompatibleTimeBaseException {
/*  259 */     TimeBase oldTimeBase = getMasterTimeBase();
/*      */     
/*  261 */     if (tb == null) {
/*  262 */       tb = oldTimeBase;
/*      */     }
/*  264 */     Controller c = null;
/*      */ 
/*      */     
/*  267 */     if (this.controllerList != null) {
/*      */       try {
/*  269 */         int i = this.controllerList.size();
/*  270 */         while (--i >= 0) {
/*  271 */           c = this.controllerList.elementAt(i);
/*  272 */           c.setTimeBase(tb);
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*  279 */       catch (IncompatibleTimeBaseException e) {
/*  280 */         int i = this.controllerList.size();
/*  281 */         while (--i >= 0) {
/*  282 */           Controller cx = this.controllerList.elementAt(i);
/*  283 */           if (cx == c)
/*      */             break; 
/*  285 */           cx.setTimeBase(oldTimeBase);
/*      */         } 
/*  287 */         Log.dumpStack((Throwable)e);
/*  288 */         throw e;
/*      */       } 
/*      */     }
/*      */     
/*  292 */     super.setTimeBase(tb);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setMediaLength(long t) {
/*  300 */     this.duration = new Time(t);
/*  301 */     super.setMediaLength(t);
/*      */   }
/*      */   
/*      */   public BasicPlayer() {
/*  305 */     this.lastTime = 0L; this.configureEventList.addElement("javax.media.ConfigureCompleteEvent"); this.configureEventList.addElement("javax.media.ResourceUnavailableEvent"); this.realizeEventList.addElement("javax.media.RealizeCompleteEvent");
/*      */     this.realizeEventList.addElement("javax.media.ResourceUnavailableEvent");
/*      */     this.prefetchEventList.addElement("javax.media.PrefetchCompleteEvent");
/*      */     this.prefetchEventList.addElement("javax.media.ResourceUnavailableEvent");
/*      */     this.stopEventList.addElement("javax.media.StopEvent");
/*      */     this.stopEventList.addElement("javax.media.StopByRequestEvent");
/*      */     this.stopEventList.addElement("javax.media.StopAtTimeEvent");
/*      */     this.stopThreadEnabled = false; } public Time getDuration() { long t;
/*  313 */     if ((t = getMediaNanoseconds()) > this.lastTime) {
/*  314 */       this.lastTime = t;
/*  315 */       updateDuration();
/*      */     } 
/*  317 */     return this.duration; }
/*      */ 
/*      */   
/*      */   protected synchronized void updateDuration() {
/*  321 */     Time oldDuration = this.duration;
/*  322 */     this.duration = Duration.DURATION_UNKNOWN;
/*  323 */     for (int i = 0; i < this.controllerList.size(); i++) {
/*  324 */       Controller c = this.controllerList.elementAt(i);
/*  325 */       Time dur = c.getDuration();
/*  326 */       if (dur.equals(Duration.DURATION_UNKNOWN)) {
/*  327 */         if (!(c instanceof BasicController)) {
/*  328 */           this.duration = Duration.DURATION_UNKNOWN; break;
/*      */         } 
/*      */       } else {
/*  331 */         if (dur.equals(Duration.DURATION_UNBOUNDED)) {
/*  332 */           this.duration = Duration.DURATION_UNBOUNDED;
/*      */           break;
/*      */         } 
/*  335 */         if (this.duration.equals(Duration.DURATION_UNKNOWN)) {
/*  336 */           this.duration = dur;
/*  337 */         } else if (this.duration.getNanoseconds() < dur.getNanoseconds()) {
/*  338 */           this.duration = dur;
/*      */         } 
/*      */       } 
/*  341 */     }  if (this.duration.getNanoseconds() != oldDuration.getNanoseconds()) {
/*  342 */       setMediaLength(this.duration.getNanoseconds());
/*  343 */       sendEvent((ControllerEvent)new DurationUpdateEvent(this, this.duration));
/*      */     } 
/*      */   }
/*      */   
/*      */   public Time getStartLatency() {
/*  348 */     super.getStartLatency();
/*      */ 
/*      */     
/*  351 */     long t = 0L;
/*      */ 
/*      */     
/*  354 */     for (int i = 0; i < this.controllerList.size(); i++) {
/*  355 */       Controller c = this.controllerList.elementAt(i);
/*  356 */       Time latency = c.getStartLatency();
/*      */       
/*  358 */       if (latency != Controller.LATENCY_UNKNOWN)
/*      */       {
/*      */         
/*  361 */         if (latency.getNanoseconds() > t)
/*  362 */           t = latency.getNanoseconds(); 
/*      */       }
/*      */     } 
/*  365 */     if (t == 0L) {
/*  366 */       return Controller.LATENCY_UNKNOWN;
/*      */     }
/*  368 */     return new Time(t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void stopAtTime() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void controllerStopAtTime() {
/*  385 */     super.stopAtTime();
/*      */   }
/*      */   
/*      */   public void setStopTime(Time t) {
/*  389 */     if (this.state < 300) {
/*  390 */       throwError((Error)new NotRealizedError("Cannot set stop time on an unrealized controller."));
/*      */     }
/*      */     
/*  393 */     if (getClock().getStopTime() == null || getClock().getStopTime().getNanoseconds() != t.getNanoseconds())
/*      */     {
/*  395 */       sendEvent((ControllerEvent)new StopTimeChangeEvent(this, t));
/*      */     }
/*      */     
/*  398 */     doSetStopTime(t);
/*      */   }
/*      */   
/*      */   private void doSetStopTime(Time t) {
/*  402 */     getClock().setStopTime(t);
/*  403 */     Vector list = this.controllerList;
/*  404 */     int i = list.size();
/*  405 */     while (--i >= 0) {
/*  406 */       Controller c = this.controllerList.elementAt(i);
/*  407 */       c.setStopTime(t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void controllerSetStopTime(Time t) {
/*  415 */     super.setStopTime(t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setMediaTime(Time now) {
/*  426 */     if (this.state < 300) {
/*  427 */       throwError((Error)new NotRealizedError(BasicController.MediaTimeError));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  432 */     synchronized (this.mediaTimeSync) {
/*      */       
/*  434 */       if (syncStartInProgress()) {
/*      */         return;
/*      */       }
/*  437 */       if (getState() == 600) {
/*  438 */         this.aboutToRestart = true;
/*  439 */         stop(2);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  444 */       if (this.source instanceof Positionable) {
/*  445 */         now = ((Positionable)this.source).setPosition(now, 2);
/*      */       }
/*  447 */       super.setMediaTime(now);
/*      */       
/*  449 */       int i = this.controllerList.size();
/*  450 */       while (--i >= 0) {
/*  451 */         ((Controller)this.controllerList.elementAt(i)).setMediaTime(now);
/*      */       }
/*      */ 
/*      */       
/*  455 */       doSetMediaTime(now);
/*      */       
/*  457 */       if (this.aboutToRestart) {
/*  458 */         syncStart(getTimeBase().getTime());
/*  459 */         this.aboutToRestart = false;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAboutToRestart() {
/*  468 */     return this.aboutToRestart;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doSetMediaTime(Time now) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Component getVisualComponent() {
/*  489 */     int state = getState();
/*  490 */     if (state < 300) {
/*  491 */       throwError((Error)new NotRealizedError("Cannot get visual component on an unrealized player"));
/*      */     }
/*  493 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Component getControlPanelComponent() {
/*  507 */     int state = getState();
/*  508 */     if (state < 300) {
/*  509 */       throwError((Error)new NotRealizedError("Cannot get control panel component on an unrealized player"));
/*      */     }
/*  511 */     if (this.controlComp == null) {
/*  512 */       this.controlComp = (Component)new DefaultControlPanel(this);
/*      */     }
/*  514 */     return this.controlComp;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GainControl getGainControl() {
/*  524 */     int state = getState();
/*  525 */     if (state < 300) {
/*  526 */       throwError((Error)new NotRealizedError("Cannot get gain control on an unrealized player"));
/*      */     } else {
/*  528 */       return (GainControl)getControl("javax.media.GainControl");
/*      */     } 
/*  530 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Control[] getControls() {
/*  539 */     if (this.controls != null) {
/*  540 */       return this.controls;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  546 */     Vector cv = new Vector();
/*      */     
/*  548 */     if (this.cachingControl != null) {
/*  549 */       cv.addElement(this.cachingControl);
/*      */     }
/*  551 */     if (this.bufferControl != null) {
/*  552 */       cv.addElement(this.bufferControl);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  557 */     int size = this.controllerList.size(); int i;
/*  558 */     for (i = 0; i < size; i++) {
/*  559 */       Controller ctrller = this.controllerList.elementAt(i);
/*  560 */       Control[] arrayOfControl = ctrller.getControls();
/*  561 */       if (arrayOfControl != null) {
/*  562 */         for (int j = 0; j < arrayOfControl.length; j++) {
/*  563 */           cv.addElement(arrayOfControl[j]);
/*      */         }
/*      */       }
/*      */     } 
/*      */     
/*  568 */     size = cv.size();
/*  569 */     Control[] ctrls = new Control[size];
/*      */     
/*  571 */     for (i = 0; i < size; i++) {
/*  572 */       ctrls[i] = (Control)cv.elementAt(i);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  578 */     if (getState() >= 300) {
/*  579 */       this.controls = ctrls;
/*      */     }
/*  581 */     return ctrls;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void controllerUpdate(ControllerEvent evt) {
/*  589 */     processEvent(evt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Vector getControllerList() {
/*  597 */     return this.controllerList;
/*      */   }
/*      */   
/*      */   private Vector getPotentialEventsList() {
/*  601 */     return this.potentialEventsList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void resetReceivedEventList() {
/*  608 */     if (this.receivedEventList != null) {
/*  609 */       this.receivedEventList.removeAllElements();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Vector getReceivedEventsList() {
/*  616 */     return this.receivedEventList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateReceivedEventsList(ControllerEvent event) {
/*  623 */     if (this.receivedEventList != null) {
/*  624 */       Controller source = event.getSourceController();
/*      */       
/*  626 */       if (this.receivedEventList.contains(source)) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/*  631 */       this.receivedEventList.addElement(source);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void start() {
/*  650 */     synchronized (this.startSync) {
/*      */       
/*  652 */       if (this.restartFrom != null) {
/*      */         return;
/*      */       }
/*      */       
/*  656 */       if (getState() == 600) {
/*  657 */         sendEvent((ControllerEvent)new StartEvent(this, 600, 600, 600, this.mediaTimeAtStart, this.startTime));
/*      */         
/*      */         return;
/*      */       } 
/*  661 */       if (this.playThread == null || !this.playThread.isAlive()) {
/*  662 */         setTargetState(600);
/*  663 */         if (jmfSecurity != null) {
/*  664 */           String permission = null;
/*      */           try {
/*  666 */             if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  667 */               permission = "thread";
/*  668 */               jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/*  669 */               this.m[0].invoke(this.cl[0], this.args[0]);
/*      */               
/*  671 */               permission = "thread group";
/*  672 */               jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/*  673 */               this.m[0].invoke(this.cl[0], this.args[0]);
/*  674 */             } else if (jmfSecurity.getName().startsWith("internet")) {
/*  675 */               PolicyEngine.checkPermission(PermissionID.THREAD);
/*  676 */               PolicyEngine.assertPermission(PermissionID.THREAD);
/*      */             }
/*      */           
/*  679 */           } catch (Throwable e) {
/*      */ 
/*      */ 
/*      */             
/*  683 */             securityPrivelege = false;
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  689 */         if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*      */           try {
/*  691 */             Constructor cons = CreateWorkThreadAction.cons;
/*  692 */             this.playThread = (PlayThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { PlayThread.class, BasicPlayer.class, this }) });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  702 */             this.playThread.start();
/*  703 */           } catch (Exception e) {}
/*      */         } else {
/*      */           
/*  706 */           this.playThread = new PlayThread(this);
/*  707 */           this.playThread.start();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void syncStart(Time tbt) {
/*  731 */     synchronized (this.mediaTimeSync) {
/*      */       
/*  733 */       if (syncStartInProgress()) {
/*      */         return;
/*      */       }
/*  736 */       int state = getState();
/*      */       
/*  738 */       if (state == 600) {
/*  739 */         throwError((Error)new ClockStartedError("syncStart() cannot be used on an already started player"));
/*      */       }
/*      */       
/*  742 */       if (state != 500) {
/*  743 */         throwError((Error)new NotPrefetchedError("Cannot start player before it has been prefetched"));
/*      */       }
/*      */ 
/*      */       
/*  747 */       this.eomEventsReceivedFrom.removeAllElements();
/*  748 */       this.stopAtTimeReceivedFrom.removeAllElements();
/*      */       
/*  750 */       setTargetState(600);
/*      */       
/*  752 */       int i = this.controllerList.size();
/*      */ 
/*      */       
/*  755 */       while (--i >= 0) {
/*  756 */         if (getTargetState() == 600) {
/*  757 */           ((Controller)this.controllerList.elementAt(i)).syncStart(tbt);
/*      */         }
/*      */       } 
/*      */       
/*  761 */       if (getTargetState() == 600) {
/*      */ 
/*      */         
/*  764 */         this.startTime = tbt;
/*  765 */         this.mediaTimeAtStart = getMediaTime();
/*  766 */         super.syncStart(tbt);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doStart() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final synchronized void play() {
/*  787 */     if (getTargetState() != 600) {
/*      */       return;
/*      */     }
/*      */     
/*  791 */     this.prefetchFailed = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  797 */     int state = getState();
/*  798 */     if (state == 100 || state == 180 || state == 300) {
/*  799 */       prefetch();
/*      */     }
/*  801 */     while (!this.closing && !this.prefetchFailed && (getState() == 140 || getState() == 200 || getState() == 300 || getState() == 400)) {
/*      */ 
/*      */       
/*      */       try {
/*  805 */         wait();
/*  806 */       } catch (InterruptedException e) {}
/*      */     } 
/*      */ 
/*      */     
/*  810 */     if (getState() != 600 && getTargetState() == 600 && getState() == 500)
/*      */     {
/*  812 */       syncStart(getTimeBase().getTime());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doStop() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void stop() {
/*  830 */     stop(1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void stop(int stopType) {
/*      */     int state;
/*  841 */     switch (state = getState()) {
/*      */       case 100:
/*      */       case 300:
/*      */       case 500:
/*  845 */         setTargetState(state);
/*      */         break;
/*      */       case 200:
/*  848 */         setTargetState(300);
/*      */         break;
/*      */       case 400:
/*      */       case 600:
/*  852 */         setTargetState(500);
/*      */         break;
/*      */     } 
/*      */     
/*  856 */     if (getState() != 600) {
/*  857 */       switch (stopType) {
/*      */         case 1:
/*  859 */           sendEvent((ControllerEvent)new StopByRequestEvent(this, getState(), getState(), getTargetState(), getMediaTime()));
/*      */           return;
/*      */ 
/*      */ 
/*      */         
/*      */         case 2:
/*  865 */           sendEvent((ControllerEvent)new RestartingEvent(this, getState(), getState(), 600, getMediaTime()));
/*      */           return;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  871 */       sendEvent((ControllerEvent)new StopEvent(this, getState(), getState(), getTargetState(), getMediaTime()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  878 */     else if (getState() == 600) {
/*      */       
/*  880 */       synchronized (this) {
/*      */         
/*  882 */         this.potentialEventsList = this.stopEventList;
/*      */         
/*  884 */         resetReceivedEventList();
/*  885 */         this.receivedAllEvents = false;
/*  886 */         this.currentControllerList.removeAllElements();
/*      */         
/*  888 */         int i = this.controllerList.size();
/*  889 */         while (--i >= 0) {
/*  890 */           Controller c = this.controllerList.elementAt(i);
/*  891 */           this.currentControllerList.addElement(c);
/*  892 */           c.stop();
/*      */         } 
/*  894 */         if (this.currentControllerList == null)
/*      */           return; 
/*  896 */         if (!this.currentControllerList.isEmpty()) {
/*      */           try {
/*  898 */             while (!this.closing && !this.receivedAllEvents)
/*  899 */               wait(); 
/*  900 */           } catch (InterruptedException e) {}
/*      */           
/*  902 */           this.currentControllerList.removeAllElements();
/*      */         } 
/*  904 */         super.stop();
/*      */ 
/*      */         
/*  907 */         switch (stopType) {
/*      */           case 1:
/*  909 */             sendEvent((ControllerEvent)new StopByRequestEvent(this, 600, getState(), getTargetState(), getMediaTime()));
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 2:
/*  915 */             sendEvent((ControllerEvent)new RestartingEvent(this, 600, getState(), 600, getMediaTime()));
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/*  921 */             sendEvent((ControllerEvent)new StopEvent(this, 600, getState(), getTargetState(), getMediaTime()));
/*      */             break;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void processEndOfMedia() {
/*  932 */     super.stop();
/*  933 */     sendEvent((ControllerEvent)new EndOfMediaEvent(this, 600, 500, getTargetState(), getMediaTime()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void manageController(Controller controller) {
/*  943 */     manageController(controller, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void manageController(Controller controller, boolean optional) {
/*  951 */     if (controller != null && 
/*  952 */       !this.controllerList.contains(controller)) {
/*  953 */       this.controllerList.addElement(controller);
/*  954 */       if (optional)
/*  955 */         this.optionalControllerList.addElement(controller); 
/*  956 */       controller.addControllerListener(this);
/*      */     } 
/*      */     
/*  959 */     updateDuration();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void unmanageController(Controller controller) {
/*  968 */     if (controller != null && 
/*  969 */       this.controllerList.contains(controller)) {
/*  970 */       this.controllerList.removeElement(controller);
/*  971 */       controller.removeControllerListener(this);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void addController(Controller newController) throws IncompatibleTimeBaseException {
/* 1010 */     int playerState = getState();
/*      */     
/* 1012 */     if (playerState == 600) {
/* 1013 */       throwError((Error)new ClockStartedError("Cannot add controller to a started player"));
/*      */     }
/*      */     
/* 1016 */     if (playerState == 100 || playerState == 200) {
/* 1017 */       throwError((Error)new NotRealizedError("A Controller cannot be added to an Unrealized Player"));
/*      */     }
/*      */     
/* 1020 */     if (newController == null || newController == this) {
/*      */       return;
/*      */     }
/* 1023 */     int controllerState = newController.getState();
/* 1024 */     if (controllerState == 100 || controllerState == 200) {
/* 1025 */       throwError((Error)new NotRealizedError("An Unrealized Controller cannot be added to a Player"));
/*      */     }
/*      */     
/* 1028 */     if (this.controllerList.contains(newController)) {
/*      */       return;
/*      */     }
/*      */     
/* 1032 */     if (playerState == 500 && (
/* 1033 */       controllerState == 300 || controllerState == 400))
/*      */     {
/*      */       
/* 1036 */       deallocate();
/*      */     }
/*      */ 
/*      */     
/* 1040 */     manageController(newController);
/*      */ 
/*      */     
/* 1043 */     newController.setTimeBase(getTimeBase());
/* 1044 */     newController.setMediaTime(getMediaTime());
/* 1045 */     newController.setStopTime(getStopTime());
/*      */     
/* 1047 */     if (newController.setRate(getRate()) != getRate())
/*      */     {
/*      */       
/* 1050 */       setRate(1.0F);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final synchronized void removeController(Controller oldController) {
/* 1060 */     int state = getState();
/*      */     
/* 1062 */     if (state < 300) {
/* 1063 */       throwError((Error)new NotRealizedError("Cannot remove controller from a unrealized player"));
/*      */     }
/*      */     
/* 1066 */     if (state == 600) {
/* 1067 */       throwError((Error)new ClockStartedError("Cannot remove controller from a started player"));
/*      */     }
/*      */     
/* 1070 */     if (oldController == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1074 */     if (this.controllerList.contains(oldController)) {
/* 1075 */       this.controllerList.removeElement(oldController);
/* 1076 */       oldController.removeControllerListener(this);
/* 1077 */       updateDuration();
/*      */       
/*      */       try {
/* 1080 */         oldController.setTimeBase(null);
/* 1081 */       } catch (IncompatibleTimeBaseException e) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized boolean doConfigure() {
/* 1122 */     this.potentialEventsList = this.configureEventList;
/*      */     
/* 1124 */     resetReceivedEventList();
/* 1125 */     this.receivedAllEvents = false;
/* 1126 */     this.currentControllerList.removeAllElements();
/*      */     
/* 1128 */     int i = this.controllerList.size();
/* 1129 */     while (--i >= 0) {
/* 1130 */       Controller c = this.controllerList.elementAt(i);
/* 1131 */       if (c.getState() == 100 && (c instanceof Processor || c instanceof BasicController))
/*      */       {
/* 1133 */         this.currentControllerList.addElement(c);
/*      */       }
/*      */     } 
/*      */     
/* 1137 */     i = this.currentControllerList.size();
/* 1138 */     while (--i >= 0) {
/* 1139 */       Controller c = this.currentControllerList.elementAt(i);
/* 1140 */       if (c instanceof Processor) {
/* 1141 */         ((Processor)c).configure(); continue;
/* 1142 */       }  if (c instanceof BasicController) {
/* 1143 */         ((BasicController)c).configure();
/*      */       }
/*      */     } 
/* 1146 */     if (!this.currentControllerList.isEmpty()) {
/*      */       try {
/* 1148 */         while (!this.closing && !this.receivedAllEvents)
/* 1149 */           wait(); 
/* 1150 */       } catch (InterruptedException e) {}
/*      */       
/* 1152 */       this.currentControllerList.removeAllElements();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1160 */     i = this.controllerList.size();
/* 1161 */     while (--i >= 0) {
/* 1162 */       Controller c = this.controllerList.elementAt(i);
/* 1163 */       if ((c instanceof Processor || c instanceof BasicController) && c.getState() < 180) {
/*      */         
/* 1165 */         Log.error("Error: Unable to configure " + c);
/* 1166 */         this.source.disconnect();
/* 1167 */         return false;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1172 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void completeConfigure() {
/* 1179 */     super.completeConfigure();
/* 1180 */     synchronized (this) {
/* 1181 */       notify();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doFailedConfigure() {
/* 1189 */     super.doFailedConfigure();
/* 1190 */     synchronized (this) {
/* 1191 */       notify();
/*      */     } 
/* 1193 */     close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized boolean doRealize() {
/* 1209 */     this.potentialEventsList = this.realizeEventList;
/*      */     
/* 1211 */     resetReceivedEventList();
/* 1212 */     this.receivedAllEvents = false;
/* 1213 */     this.currentControllerList.removeAllElements();
/*      */     
/* 1215 */     int i = this.controllerList.size();
/* 1216 */     while (--i >= 0) {
/* 1217 */       Controller c = this.controllerList.elementAt(i);
/* 1218 */       if (c.getState() == 100 || c.getState() == 180) {
/* 1219 */         this.currentControllerList.addElement(c);
/*      */       }
/*      */     } 
/*      */     
/* 1223 */     i = this.currentControllerList.size();
/* 1224 */     while (--i >= 0) {
/* 1225 */       Controller c = this.currentControllerList.elementAt(i);
/* 1226 */       c.realize();
/*      */     } 
/*      */     
/* 1229 */     if (!this.currentControllerList.isEmpty()) {
/*      */       try {
/* 1231 */         while (!this.closing && !this.receivedAllEvents)
/* 1232 */           wait(); 
/* 1233 */       } catch (InterruptedException e) {}
/*      */       
/* 1235 */       this.currentControllerList.removeAllElements();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1243 */     i = this.controllerList.size();
/* 1244 */     while (--i >= 0) {
/* 1245 */       Controller c = this.controllerList.elementAt(i);
/* 1246 */       if (c.getState() < 300) {
/* 1247 */         Log.error("Error: Unable to realize " + c);
/* 1248 */         this.source.disconnect();
/* 1249 */         return false;
/*      */       } 
/*      */     } 
/*      */     
/* 1253 */     updateDuration();
/*      */     
/* 1255 */     if (jmfSecurity != null) {
/* 1256 */       String permission = null;
/*      */       try {
/* 1258 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 1259 */           permission = "thread";
/* 1260 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/* 1261 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*      */           
/* 1263 */           permission = "thread group";
/* 1264 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/* 1265 */           this.m[0].invoke(this.cl[0], this.args[0]);
/* 1266 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/* 1267 */           PolicyEngine.checkPermission(PermissionID.THREAD);
/* 1268 */           PolicyEngine.assertPermission(PermissionID.THREAD);
/*      */         }
/*      */       
/* 1271 */       } catch (Exception e) {
/*      */ 
/*      */ 
/*      */         
/* 1275 */         securityPrivelege = false;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1281 */     if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*      */       try {
/* 1283 */         Constructor cons = CreateWorkThreadAction.cons;
/* 1284 */         this.statsThread = (StatsThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { StatsThread.class, BasicPlayer.class, this }) });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1294 */         this.statsThread.start();
/*      */       }
/* 1296 */       catch (Exception e) {}
/*      */     } else {
/*      */       
/* 1299 */       this.statsThread = new StatsThread(this);
/* 1300 */       this.statsThread.start();
/*      */     } 
/*      */ 
/*      */     
/* 1304 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void completeRealize() {
/* 1311 */     this.state = 300;
/*      */     try {
/* 1313 */       slaveToMasterTimeBase(getMasterTimeBase());
/*      */     } catch (IncompatibleTimeBaseException e) {
/* 1315 */       Log.error(e);
/*      */     } 
/* 1317 */     super.completeRealize();
/* 1318 */     synchronized (this) {
/* 1319 */       notify();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doFailedRealize() {
/* 1327 */     super.doFailedRealize();
/* 1328 */     synchronized (this) {
/* 1329 */       notify();
/*      */     } 
/* 1331 */     close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void completePrefetch() {
/* 1338 */     super.completePrefetch();
/* 1339 */     synchronized (this) {
/* 1340 */       notify();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doFailedPrefetch() {
/* 1348 */     super.doFailedPrefetch();
/* 1349 */     synchronized (this) {
/* 1350 */       notify();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void abortRealize() {
/* 1360 */     if (this.controllerList != null) {
/* 1361 */       int i = this.controllerList.size();
/* 1362 */       while (--i >= 0) {
/* 1363 */         Controller c = this.controllerList.elementAt(i);
/* 1364 */         c.deallocate();
/*      */       } 
/*      */     } 
/* 1367 */     synchronized (this) {
/* 1368 */       notify();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean doPrefetch() {
/* 1381 */     this.potentialEventsList = this.prefetchEventList;
/*      */     
/* 1383 */     resetReceivedEventList();
/* 1384 */     this.receivedAllEvents = false;
/* 1385 */     this.currentControllerList.removeAllElements();
/*      */     
/* 1387 */     Vector list = this.controllerList;
/*      */     
/* 1389 */     if (list == null) {
/* 1390 */       return false;
/*      */     }
/*      */     
/* 1393 */     int i = list.size();
/* 1394 */     while (--i >= 0) {
/* 1395 */       Controller c = list.elementAt(i);
/* 1396 */       if (c.getState() == 300) {
/* 1397 */         this.currentControllerList.addElement(c);
/* 1398 */         c.prefetch();
/*      */       } 
/*      */     } 
/* 1401 */     if (!this.currentControllerList.isEmpty()) {
/* 1402 */       synchronized (this) {
/*      */         try {
/* 1404 */           while (!this.closing && !this.receivedAllEvents)
/* 1405 */             wait(); 
/* 1406 */         } catch (InterruptedException e) {}
/*      */         
/* 1408 */         this.currentControllerList.removeAllElements();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1417 */     i = list.size();
/* 1418 */     while (--i >= 0) {
/* 1419 */       Controller c = list.elementAt(i);
/* 1420 */       if (c.getState() < 500) {
/* 1421 */         Log.error("Error: Unable to prefetch " + c + "\n");
/* 1422 */         if (this.optionalControllerList.contains(c)) {
/*      */           
/* 1424 */           this.removedControllerList.addElement(c);
/*      */           continue;
/*      */         } 
/* 1427 */         synchronized (this) {
/* 1428 */           this.prefetchFailed = true;
/* 1429 */           notifyAll();
/*      */         } 
/* 1431 */         return false;
/*      */       } 
/*      */     } 
/*      */     
/* 1435 */     if (this.removedControllerList != null) {
/* 1436 */       i = this.removedControllerList.size();
/* 1437 */       while (--i >= 0) {
/* 1438 */         Object o = this.removedControllerList.elementAt(i);
/* 1439 */         this.controllerList.removeElement(o);
/* 1440 */         ((BasicController)o).close();
/* 1441 */         if (!deviceBusy((BasicController)o)) {
/*      */           
/* 1443 */           synchronized (this) {
/* 1444 */             this.prefetchFailed = true;
/* 1445 */             notifyAll();
/*      */           } 
/* 1447 */           return false;
/*      */         } 
/*      */       } 
/* 1450 */       this.removedControllerList.removeAllElements();
/*      */     } 
/*      */ 
/*      */     
/* 1454 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void abortPrefetch() {
/* 1463 */     if (this.controllerList != null) {
/* 1464 */       int i = this.controllerList.size();
/* 1465 */       while (--i >= 0) {
/* 1466 */         Controller c = this.controllerList.elementAt(i);
/* 1467 */         c.deallocate();
/*      */       } 
/*      */     } 
/* 1470 */     synchronized (this) {
/* 1471 */       notify();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean deviceBusy(BasicController mc) {
/* 1485 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void slaveToMasterTimeBase(TimeBase tb) throws IncompatibleTimeBaseException {
/* 1502 */     setTimeBase(tb);
/*      */   }
/*      */ 
/*      */   
/*      */   private void notifyIfAllEventsArrived(Vector controllerList, Vector receivedEventList) {
/* 1507 */     if (receivedEventList != null && receivedEventList.size() == this.currentControllerList.size()) {
/*      */       
/* 1509 */       this.receivedAllEvents = true;
/* 1510 */       resetReceivedEventList();
/* 1511 */       synchronized (this) {
/* 1512 */         notifyAll();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void processEvent(ControllerEvent evt) {
/* 1520 */     Controller source = evt.getSourceController();
/*      */     
/* 1522 */     if (evt instanceof AudioDeviceUnavailableEvent) {
/* 1523 */       sendEvent((ControllerEvent)new AudioDeviceUnavailableEvent(this));
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/* 1531 */     if (evt instanceof ControllerClosedEvent && !this.closing && this.controllerList.contains(source) && !(evt instanceof javax.media.ResourceUnavailableEvent)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1538 */       this.controllerList.removeElement(source);
/*      */       
/* 1540 */       if (evt instanceof ControllerErrorEvent) {
/* 1541 */         sendEvent((ControllerEvent)new ControllerErrorEvent(this, ((ControllerErrorEvent)evt).getMessage()));
/*      */       }
/* 1543 */       close();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1549 */     if (evt instanceof SizeChangeEvent && this.controllerList.contains(source)) {
/*      */ 
/*      */       
/* 1552 */       sendEvent((ControllerEvent)new SizeChangeEvent(this, ((SizeChangeEvent)evt).getWidth(), ((SizeChangeEvent)evt).getHeight(), ((SizeChangeEvent)evt).getScale()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1576 */     if (evt instanceof DurationUpdateEvent && this.controllerList.contains(source)) {
/* 1577 */       updateDuration();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1590 */     if (evt instanceof RestartingEvent && this.controllerList.contains(source)) {
/* 1591 */       this.restartFrom = source;
/* 1592 */       int i = this.controllerList.size();
/* 1593 */       super.stop();
/* 1594 */       setTargetState(500);
/*      */       
/* 1596 */       for (int ii = 0; ii < i; ii++) {
/* 1597 */         Controller c = this.controllerList.elementAt(ii);
/* 1598 */         if (c != source) {
/* 1599 */           c.stop();
/*      */         }
/*      */       } 
/* 1602 */       super.stop();
/*      */       
/* 1604 */       sendEvent((ControllerEvent)new RestartingEvent(this, 600, 400, 600, getMediaTime()));
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1609 */     if (evt instanceof StartEvent && source == this.restartFrom) {
/* 1610 */       this.restartFrom = null;
/*      */       
/* 1612 */       start();
/*      */     } 
/*      */     
/* 1615 */     if (evt instanceof SeekFailedEvent && this.controllerList.contains(source)) {
/*      */       
/* 1617 */       int i = this.controllerList.size();
/* 1618 */       super.stop();
/* 1619 */       setTargetState(500);
/*      */       
/* 1621 */       for (int ii = 0; ii < i; ii++) {
/* 1622 */         Controller c = this.controllerList.elementAt(ii);
/* 1623 */         if (c != source) {
/* 1624 */           c.stop();
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1632 */       sendEvent((ControllerEvent)new SeekFailedEvent(this, 600, 500, 500, getMediaTime()));
/*      */     } 
/*      */ 
/*      */     
/* 1636 */     if (evt instanceof EndOfMediaEvent && this.controllerList.contains(source)) {
/*      */       
/* 1638 */       if (this.eomEventsReceivedFrom.contains(source)) {
/*      */         return;
/*      */       }
/*      */       
/* 1642 */       this.eomEventsReceivedFrom.addElement(source);
/* 1643 */       if (this.eomEventsReceivedFrom.size() == this.controllerList.size()) {
/* 1644 */         super.stop();
/* 1645 */         sendEvent((ControllerEvent)new EndOfMediaEvent(this, 600, 500, getTargetState(), getMediaTime()));
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1651 */     if (evt instanceof StopAtTimeEvent && this.controllerList.contains(source) && getState() == 600)
/*      */     {
/*      */       
/* 1654 */       synchronized (this.stopAtTimeReceivedFrom) {
/*      */         
/* 1656 */         if (this.stopAtTimeReceivedFrom.contains(source)) {
/*      */           return;
/*      */         }
/* 1659 */         this.stopAtTimeReceivedFrom.addElement(source);
/*      */         
/* 1661 */         boolean allStopped = (this.stopAtTimeReceivedFrom.size() == this.controllerList.size());
/*      */         
/* 1663 */         if (!allStopped) {
/*      */           
/* 1665 */           allStopped = true;
/* 1666 */           for (int i = 0; i < this.controllerList.size(); i++) {
/* 1667 */             Controller c = this.controllerList.elementAt(i);
/* 1668 */             if (!this.stopAtTimeReceivedFrom.contains(c) && !this.eomEventsReceivedFrom.contains(c)) {
/*      */               
/* 1670 */               allStopped = false;
/*      */               
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         } 
/* 1676 */         if (allStopped) {
/* 1677 */           super.stop();
/* 1678 */           doSetStopTime(Clock.RESET);
/* 1679 */           sendEvent((ControllerEvent)new StopAtTimeEvent(this, 600, 500, getTargetState(), getMediaTime()));
/*      */         } 
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1688 */     if (evt instanceof CachingControlEvent && this.controllerList.contains(source)) {
/* 1689 */       CachingControl mcc = ((CachingControlEvent)evt).getCachingControl();
/*      */       
/* 1691 */       sendEvent((ControllerEvent)new CachingControlEvent(this, mcc, mcc.getContentProgress()));
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1697 */     Vector eventList = this.potentialEventsList;
/*      */     
/* 1699 */     if (this.controllerList != null && this.controllerList.contains(source) && eventList != null && eventList.contains(evt.getClass().getName())) {
/*      */       
/* 1701 */       updateReceivedEventsList(evt);
/* 1702 */       notifyIfAllEventsArrived(this.controllerList, getReceivedEventsList());
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean trySetRate(float rate) {
/* 1707 */     int i = this.controllerList.size();
/*      */     
/* 1709 */     while (--i >= 0) {
/* 1710 */       Controller c = this.controllerList.elementAt(i);
/* 1711 */       if (c.setRate(rate) != rate) {
/* 1712 */         return false;
/*      */       }
/*      */     } 
/* 1715 */     return true;
/*      */   }
/*      */   
/*      */   protected float doSetRate(float factor) {
/* 1719 */     return factor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float setRate(float rate) {
/*      */     float f1;
/* 1728 */     if (this.state < 300) {
/* 1729 */       throwError((Error)new NotRealizedError("Cannot set rate on an unrealized Player."));
/*      */     }
/*      */ 
/*      */     
/* 1733 */     if (this.source instanceof RateConfigureable) {
/* 1734 */       rate = checkRateConfig((RateConfigureable)this.source, rate);
/*      */     }
/* 1736 */     float oldRate = getRate();
/*      */     
/* 1738 */     if (oldRate == rate) {
/* 1739 */       return rate;
/*      */     }
/* 1741 */     if (getState() == 600) {
/* 1742 */       this.aboutToRestart = true;
/* 1743 */       stop(2);
/*      */     } 
/*      */ 
/*      */     
/* 1747 */     if (!trySetRate(rate)) {
/* 1748 */       if (!trySetRate(oldRate)) {
/* 1749 */         trySetRate(1.0F);
/* 1750 */         f1 = 1.0F;
/*      */       } else {
/* 1752 */         f1 = oldRate;
/*      */       } 
/*      */     } else {
/* 1755 */       f1 = rate;
/*      */     } 
/* 1757 */     super.setRate(f1);
/*      */     
/* 1759 */     if (this.aboutToRestart) {
/* 1760 */       syncStart(getTimeBase().getTime());
/* 1761 */       this.aboutToRestart = false;
/*      */     } 
/* 1763 */     return f1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   float checkRateConfig(RateConfigureable rc, float rate) {
/* 1771 */     RateConfiguration[] config = rc.getRateConfigurations();
/* 1772 */     if (config == null) {
/* 1773 */       return 1.0F;
/*      */     }
/*      */ 
/*      */     
/* 1777 */     float corrected = 1.0F;
/* 1778 */     for (int i = 0; i < config.length; i++) {
/* 1779 */       RateRange rr = config[i].getRate();
/* 1780 */       if (rr != null && rr.inRange(rate)) {
/* 1781 */         rr.setCurrentRate(rate);
/* 1782 */         corrected = rate;
/* 1783 */         RateConfiguration c = rc.setRateConfiguration(config[i]);
/* 1784 */         if (c != null && (rr = c.getRate()) != null)
/* 1785 */           corrected = rr.getCurrentRate(); 
/*      */         break;
/*      */       } 
/*      */     } 
/* 1789 */     return corrected;
/*      */   }
/*      */   
/*      */   protected abstract boolean audioEnabled();
/*      */   
/*      */   protected abstract boolean videoEnabled();
/*      */   
/*      */   protected abstract TimeBase getMasterTimeBase();
/*      */   
/*      */   public abstract void updateStats();
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\BasicPlayer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */