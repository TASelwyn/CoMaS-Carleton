package com.sun.media.protocol;

import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.SourceStream;

public class BasicSourceStream implements SourceStream {
  protected ContentDescriptor contentDescriptor = null;
  
  protected long contentLength = -1L;
  
  protected Object[] controls = new Object[0];
  
  public static final int LENGTH_DISCARD = -2;
  
  public BasicSourceStream() {}
  
  public BasicSourceStream(ContentDescriptor cd, long contentLength) {
    this.contentDescriptor = cd;
    this.contentLength = contentLength;
  }
  
  public ContentDescriptor getContentDescriptor() {
    return this.contentDescriptor;
  }
  
  public long getContentLength() {
    return this.contentLength;
  }
  
  public boolean endOfStream() {
    return false;
  }
  
  public Object[] getControls() {
    return this.controls;
  }
  
  public Object getControl(String controlType) {
    try {
      Class cls = Class.forName(controlType);
      Object[] cs = getControls();
      for (int i = 0; i < cs.length; i++) {
        if (cls.isInstance(cs[i]))
          return cs[i]; 
      } 
      return null;
    } catch (Exception e) {
      return null;
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\protocol\BasicSourceStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */