/*     */ package com.sun.media.protocol;
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.ui.CacheControlComponent;
/*     */ import com.sun.media.util.ContentType;
/*     */ import com.sun.media.util.JMFI18N;
/*     */ import com.sun.media.util.Registry;
/*     */ import com.sun.media.util.jdk12;
/*     */ import com.sun.media.util.jdk12ConnectionAction;
/*     */ import java.awt.Component;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.Random;
/*     */ import javax.media.DownloadProgressListener;
/*     */ import javax.media.ExtendedCachingControl;
/*     */ import javax.media.Manager;
/*     */ import javax.media.MediaLocator;
/*     */ import javax.media.Time;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.PullDataSource;
/*     */ import javax.media.protocol.PullSourceStream;
/*     */ 
/*     */ public class DataSource extends PullDataSource {
/*  32 */   private String contentType = null; protected boolean connected = false;
/*  33 */   private PullSourceStream[] pssArray = new PullSourceStream[1];
/*  34 */   private CachedPullSourceStream cachedStream = null;
/*  35 */   private long contentLength = -1L;
/*     */   private InputStream inputStream;
/*  37 */   private String fileSeparator = System.getProperty("file.separator");
/*     */   private boolean downLoadThreadStarted = false;
/*     */   private boolean isEnabledCaching = false;
/*  40 */   private ExtendedCachingControl[] cachingControls = new ExtendedCachingControl[0];
/*     */   
/*  42 */   private static JMFSecurity jmfSecurity = null;
/*     */   private static boolean securityPrivelege = false;
/*  44 */   private Method[] m = new Method[1];
/*  45 */   private Class[] cl = new Class[1];
/*  46 */   private Object[][] args = new Object[1][0];
/*     */   
/*     */   static {
/*     */     try {
/*  50 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  51 */       securityPrivelege = true;
/*  52 */     } catch (SecurityException e) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentType() {
/*  57 */     if (!this.connected)
/*  58 */       return null; 
/*  59 */     return this.contentType;
/*     */   } public void connect() throws IOException {
/*     */     URL url;
/*     */     URLConnection urlC;
/*  63 */     if (this.connected) {
/*     */       return;
/*     */     }
/*  66 */     MediaLocator locator = getLocator();
/*  67 */     if (locator == null) {
/*  68 */       throw new IOException(this + ": connect() failed");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  74 */       url = locator.getURL();
/*  75 */       urlC = url.openConnection();
/*  76 */       urlC.setAllowUserInteraction(true);
/*     */     }
/*     */     catch (MalformedURLException e) {
/*     */       
/*  80 */       throw new IOException(this + ": connect() failed");
/*     */     } 
/*  82 */     String protocol = url.getProtocol();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     boolean needConnectPermission = true;
/*     */     try {
/*  91 */       this.inputStream = urlC.getInputStream();
/*  92 */       needConnectPermission = false;
/*     */     
/*     */     }
/*  95 */     catch (Throwable e) {}
/*     */ 
/*     */ 
/*     */     
/*  99 */     if (this.inputStream == null) {
/* 100 */       if (jmfSecurity != null) {
/*     */         try {
/* 102 */           if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 103 */             jmfSecurity.requestPermission(this.m, this.cl, this.args, 128);
/* 104 */             this.m[0].invoke(this.cl[0], this.args[0]);
/* 105 */           } else if (jmfSecurity.getName().startsWith("internet")) {
/* 106 */             PolicyEngine.checkPermission(PermissionID.NETIO);
/* 107 */             PolicyEngine.assertPermission(PermissionID.NETIO);
/*     */           }
/*     */         
/* 110 */         } catch (Exception e) {
/*     */ 
/*     */ 
/*     */           
/* 114 */           jmfSecurity.permissionFailureNotification(128);
/* 115 */           throw new IOException("Unable to get connect permission" + e.getMessage());
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 122 */         if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/* 123 */           Constructor cons = jdk12ConnectionAction.cons;
/* 124 */           this.inputStream = (InputStream)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { urlC }) });
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */ 
/*     */           
/* 133 */           this.inputStream = urlC.getInputStream();
/*     */         } 
/*     */       } catch (Throwable e) {
/*     */         
/* 137 */         throw new IOException(JMFI18N.getResource("error.connectionerror") + e.getMessage());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 142 */     if (this.inputStream == null) {
/* 143 */       throw new IOException(JMFI18N.getResource("error.connectionerror") + "Unable to open a URL connection");
/*     */     }
/*     */ 
/*     */     
/* 147 */     if (protocol.equals("ftp")) {
/* 148 */       this.contentType = "content/unknown";
/*     */     }
/*     */     else {
/*     */       
/* 152 */       this.contentType = urlC.getContentType();
/* 153 */       this.contentLength = urlC.getContentLength();
/*     */     } 
/*     */ 
/*     */     
/* 157 */     this.contentType = ContentType.getCorrectedContentType(this.contentType, locator.getRemainder());
/*     */     
/* 159 */     this.contentType = ContentDescriptor.mimeTypeToPackageName(this.contentType);
/*     */ 
/*     */ 
/*     */     
/* 163 */     boolean cachingRequested = ((Boolean)Manager.getHint(2)).booleanValue();
/*     */ 
/*     */     
/* 166 */     if (this.contentType.endsWith(".mvr") || this.contentType.endsWith("x_shockwave_flash") || this.contentType.endsWith("futuresplash"))
/*     */     {
/*     */ 
/*     */       
/* 170 */       cachingRequested = false;
/*     */     }
/*     */     
/* 173 */     String filePrefix = null;
/* 174 */     if (cachingRequested) {
/*     */       
/* 176 */       filePrefix = Manager.getCacheDirectory();
/* 177 */       if (filePrefix != null) {
/* 178 */         Object allowCachingObj = Registry.get("secure.allowCaching");
/* 179 */         if (allowCachingObj != null) {
/* 180 */           this.isEnabledCaching = ((Boolean)allowCachingObj).booleanValue();
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 185 */     if (this.isEnabledCaching) {
/*     */       
/* 187 */       String fileName = filePrefix + this.fileSeparator + generateFileName(getLocator().getRemainder());
/*     */       
/*     */       try {
/* 190 */         this.cachedStream = new CachedPullSourceStream(this.inputStream, fileName, this.contentLength, protocol);
/*     */         
/* 192 */         this.pssArray[0] = this.cachedStream;
/* 193 */         this.cachingControls = new ExtendedCachingControl[1];
/* 194 */         this.cachingControls[0] = new CachingControl(this, this.cachedStream);
/* 195 */         Log.comment("Caching in " + filePrefix);
/*     */       } catch (IOException e) {
/* 197 */         this.isEnabledCaching = false;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 202 */     if (!this.isEnabledCaching) {
/*     */       try {
/* 204 */         this.pssArray[0] = new BasicPullSourceStream(url, this.inputStream, this.contentLength, needConnectPermission);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 209 */         this.cachedStream = null;
/*     */       } catch (Exception ie) {
/* 211 */         this.pssArray[0] = null;
/* 212 */         throw new IOException(JMFI18N.getResource("error.connectionerror") + ie.getMessage());
/*     */       } 
/*     */     }
/*     */     
/* 216 */     this.connected = true;
/*     */   }
/*     */   
/*     */   public void disconnect() {
/* 220 */     if (!this.connected)
/*     */       return; 
/* 222 */     if (this.cachedStream != null) {
/* 223 */       this.cachedStream.close();
/* 224 */       this.cachedStream = null;
/*     */     } 
/* 226 */     this.pssArray[0] = null;
/* 227 */     this.connected = false;
/*     */   }
/*     */   
/*     */   public void start() throws IOException {
/* 231 */     if (!this.connected) {
/*     */       return;
/*     */     }
/* 234 */     if (this.cachedStream != null) {
/* 235 */       if (!this.downLoadThreadStarted) {
/* 236 */         this.cachedStream.startDownload();
/* 237 */         this.downLoadThreadStarted = true;
/*     */       } else {
/* 239 */         this.cachedStream.resumeDownload();
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void stop() throws IOException {
/* 245 */     if (!this.connected) {
/*     */       return;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PullSourceStream[] getStreams() {
/* 253 */     return this.pssArray;
/*     */   }
/*     */   
/*     */   public Time getDuration() {
/* 257 */     return null;
/*     */   }
/*     */   
/*     */   public Object[] getControls() {
/* 261 */     return (Object[])this.cachingControls;
/*     */   }
/*     */   
/*     */   public Object getControl(String controlType) {
/* 265 */     if (this.cachingControls.length > 0 && controlType.equals("javax.media.CachingControl"))
/*     */     {
/* 267 */       return this.cachingControls[0];
/*     */     }
/* 269 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String generateFileName(String infile) {
/* 280 */     String str1, ext = null;
/* 281 */     int sepindex = 0;
/* 282 */     Random generator = new Random();
/* 283 */     int dotindex = infile.lastIndexOf('.');
/* 284 */     int suffix = generator.nextInt();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 290 */     if (dotindex != -1) {
/* 291 */       ext = new String(infile.substring(dotindex));
/*     */     } else {
/* 293 */       dotindex = infile.length();
/*     */     } 
/*     */     
/* 296 */     sepindex = infile.lastIndexOf(File.separatorChar);
/*     */     
/* 298 */     sepindex = Math.max(infile.lastIndexOf('/'), sepindex);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 303 */     if (sepindex >= dotindex) {
/* 304 */       dotindex = infile.length();
/* 305 */       ext = null;
/*     */     } 
/*     */     
/* 308 */     String filename = infile.substring(sepindex + 1, dotindex);
/*     */     
/* 310 */     if (ext != null) {
/* 311 */       str1 = new String(filename + suffix + ext);
/*     */     } else {
/* 313 */       str1 = new String(filename + suffix);
/* 314 */     }  return convertNonAlphaNumericToUnderscore(str1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String convertNonAlphaNumericToUnderscore(String in) {
/* 320 */     if (in == null) {
/* 321 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 325 */     int len = in.length();
/* 326 */     char[] nm = new char[len];
/* 327 */     in.getChars(0, len, nm, 0);
/* 328 */     for (int i = 0; i < len; i++) {
/* 329 */       char c = nm[i];
/* 330 */       if (c != '.' && ('A' > c || c > 'Z') && ('a' > c || c > 'z') && ('0' > c || c > '9'))
/*     */       {
/*     */ 
/*     */         
/* 334 */         nm[i] = '_';
/*     */       }
/*     */     } 
/* 337 */     return new String(nm);
/*     */   }
/*     */   
/*     */   class CachingControl implements ExtendedCachingControl { private CacheControlComponent controlComponent;
/*     */     private Component progressBar;
/*     */     private CachedPullSourceStream cpss;
/*     */     private final DataSource this$0;
/*     */     
/*     */     CachingControl(DataSource this$0, CachedPullSourceStream cpss) {
/* 346 */       this.this$0 = this$0;
/*     */       
/* 348 */       this.cpss = cpss;
/* 349 */       this.controlComponent = new CacheControlComponent((javax.media.CachingControl)this, null);
/* 350 */       this.progressBar = this.controlComponent.getProgressBar();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isDownloading() {
/* 357 */       return this.cpss.isDownloading();
/*     */     }
/*     */ 
/*     */     
/*     */     public long getContentLength() {
/* 362 */       return this.this$0.contentLength;
/*     */     }
/*     */     
/*     */     public long getContentProgress() {
/* 366 */       return this.cpss.getContentProgress();
/*     */     }
/*     */     
/*     */     public Component getProgressBarComponent() {
/* 370 */       return this.progressBar;
/*     */     }
/*     */     
/*     */     public Component getControlComponent() {
/* 374 */       return (Component)this.controlComponent;
/*     */     }
/*     */     
/*     */     public void pauseDownload() {
/* 378 */       this.cpss.pauseDownload();
/*     */     }
/*     */     
/*     */     public void resumeDownload() {
/* 382 */       this.cpss.resumeDownload();
/*     */     }
/*     */     
/*     */     public long getStartOffset() {
/* 386 */       return this.cpss.getStartOffset();
/*     */     }
/*     */ 
/*     */     
/*     */     public long getEndOffset() {
/* 391 */       return this.cpss.getEndOffset();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setBufferSize(Time t) {}
/*     */ 
/*     */     
/*     */     public Time getBufferSize() {
/* 400 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void addDownloadProgressListener(DownloadProgressListener l, int numKiloBytes) {
/* 406 */       this.cpss.addDownloadProgressListener(l, numKiloBytes);
/*     */     }
/*     */     
/*     */     public void removeDownloadProgressListener(DownloadProgressListener l) {
/* 410 */       this.cpss.removeDownloadProgressListener(l);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\protocol\DataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */