package com.sun.media.protocol;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import com.sun.media.JMFSecurity;
import com.sun.media.JMFSecurityManager;
import com.sun.media.Log;
import com.sun.media.ui.CacheControlComponent;
import com.sun.media.util.ContentType;
import com.sun.media.util.JMFI18N;
import com.sun.media.util.Registry;
import com.sun.media.util.jdk12;
import com.sun.media.util.jdk12ConnectionAction;
import java.awt.Component;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Random;
import javax.media.DownloadProgressListener;
import javax.media.ExtendedCachingControl;
import javax.media.Manager;
import javax.media.MediaLocator;
import javax.media.Time;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.PullDataSource;
import javax.media.protocol.PullSourceStream;

public class DataSource extends PullDataSource {
  protected boolean connected = false;
  
  private String contentType = null;
  
  private PullSourceStream[] pssArray = new PullSourceStream[1];
  
  private CachedPullSourceStream cachedStream = null;
  
  private long contentLength = -1L;
  
  private InputStream inputStream;
  
  private String fileSeparator = System.getProperty("file.separator");
  
  private boolean downLoadThreadStarted = false;
  
  private boolean isEnabledCaching = false;
  
  private ExtendedCachingControl[] cachingControls = new ExtendedCachingControl[0];
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] m = new Method[1];
  
  private Class[] cl = new Class[1];
  
  private Object[][] args = new Object[1][0];
  
  static {
    try {
      jmfSecurity = JMFSecurityManager.getJMFSecurity();
      securityPrivelege = true;
    } catch (SecurityException e) {}
  }
  
  public String getContentType() {
    if (!this.connected)
      return null; 
    return this.contentType;
  }
  
  public void connect() throws IOException {
    URL url;
    URLConnection urlC;
    if (this.connected)
      return; 
    MediaLocator locator = getLocator();
    if (locator == null)
      throw new IOException(this + ": connect() failed"); 
    try {
      url = locator.getURL();
      urlC = url.openConnection();
      urlC.setAllowUserInteraction(true);
    } catch (MalformedURLException e) {
      throw new IOException(this + ": connect() failed");
    } 
    String protocol = url.getProtocol();
    boolean needConnectPermission = true;
    try {
      this.inputStream = urlC.getInputStream();
      needConnectPermission = false;
    } catch (Throwable e) {}
    if (this.inputStream == null) {
      if (jmfSecurity != null)
        try {
          if (jmfSecurity.getName().startsWith("jmf-security")) {
            jmfSecurity.requestPermission(this.m, this.cl, this.args, 128);
            this.m[0].invoke(this.cl[0], this.args[0]);
          } else if (jmfSecurity.getName().startsWith("internet")) {
            PolicyEngine.checkPermission(PermissionID.NETIO);
            PolicyEngine.assertPermission(PermissionID.NETIO);
          } 
        } catch (Exception e) {
          jmfSecurity.permissionFailureNotification(128);
          throw new IOException("Unable to get connect permission" + e.getMessage());
        }  
      try {
        if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
          Constructor cons = jdk12ConnectionAction.cons;
          this.inputStream = (InputStream)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { urlC }) });
        } else {
          this.inputStream = urlC.getInputStream();
        } 
      } catch (Throwable e) {
        throw new IOException(JMFI18N.getResource("error.connectionerror") + e.getMessage());
      } 
    } 
    if (this.inputStream == null)
      throw new IOException(JMFI18N.getResource("error.connectionerror") + "Unable to open a URL connection"); 
    if (protocol.equals("ftp")) {
      this.contentType = "content/unknown";
    } else {
      this.contentType = urlC.getContentType();
      this.contentLength = urlC.getContentLength();
    } 
    this.contentType = ContentType.getCorrectedContentType(this.contentType, locator.getRemainder());
    this.contentType = ContentDescriptor.mimeTypeToPackageName(this.contentType);
    boolean cachingRequested = ((Boolean)Manager.getHint(2)).booleanValue();
    if (this.contentType.endsWith(".mvr") || this.contentType.endsWith("x_shockwave_flash") || this.contentType.endsWith("futuresplash"))
      cachingRequested = false; 
    String filePrefix = null;
    if (cachingRequested) {
      filePrefix = Manager.getCacheDirectory();
      if (filePrefix != null) {
        Object allowCachingObj = Registry.get("secure.allowCaching");
        if (allowCachingObj != null)
          this.isEnabledCaching = ((Boolean)allowCachingObj).booleanValue(); 
      } 
    } 
    if (this.isEnabledCaching) {
      String fileName = filePrefix + this.fileSeparator + generateFileName(getLocator().getRemainder());
      try {
        this.cachedStream = new CachedPullSourceStream(this.inputStream, fileName, this.contentLength, protocol);
        this.pssArray[0] = this.cachedStream;
        this.cachingControls = new ExtendedCachingControl[1];
        this.cachingControls[0] = new CachingControl(this, this.cachedStream);
        Log.comment("Caching in " + filePrefix);
      } catch (IOException e) {
        this.isEnabledCaching = false;
      } 
    } 
    if (!this.isEnabledCaching)
      try {
        this.pssArray[0] = new BasicPullSourceStream(url, this.inputStream, this.contentLength, needConnectPermission);
        this.cachedStream = null;
      } catch (Exception ie) {
        this.pssArray[0] = null;
        throw new IOException(JMFI18N.getResource("error.connectionerror") + ie.getMessage());
      }  
    this.connected = true;
  }
  
  public void disconnect() {
    if (!this.connected)
      return; 
    if (this.cachedStream != null) {
      this.cachedStream.close();
      this.cachedStream = null;
    } 
    this.pssArray[0] = null;
    this.connected = false;
  }
  
  public void start() throws IOException {
    if (!this.connected)
      return; 
    if (this.cachedStream != null)
      if (!this.downLoadThreadStarted) {
        this.cachedStream.startDownload();
        this.downLoadThreadStarted = true;
      } else {
        this.cachedStream.resumeDownload();
      }  
  }
  
  public void stop() throws IOException {
    if (!this.connected)
      return; 
  }
  
  public PullSourceStream[] getStreams() {
    return this.pssArray;
  }
  
  public Time getDuration() {
    return null;
  }
  
  public Object[] getControls() {
    return (Object[])this.cachingControls;
  }
  
  public Object getControl(String controlType) {
    if (this.cachingControls.length > 0 && controlType.equals("javax.media.CachingControl"))
      return this.cachingControls[0]; 
    return null;
  }
  
  public static String generateFileName(String infile) {
    String str1, ext = null;
    int sepindex = 0;
    Random generator = new Random();
    int dotindex = infile.lastIndexOf('.');
    int suffix = generator.nextInt();
    if (dotindex != -1) {
      ext = new String(infile.substring(dotindex));
    } else {
      dotindex = infile.length();
    } 
    sepindex = infile.lastIndexOf(File.separatorChar);
    sepindex = Math.max(infile.lastIndexOf('/'), sepindex);
    if (sepindex >= dotindex) {
      dotindex = infile.length();
      ext = null;
    } 
    String filename = infile.substring(sepindex + 1, dotindex);
    if (ext != null) {
      str1 = new String(filename + suffix + ext);
    } else {
      str1 = new String(filename + suffix);
    } 
    return convertNonAlphaNumericToUnderscore(str1);
  }
  
  private static String convertNonAlphaNumericToUnderscore(String in) {
    if (in == null)
      return null; 
    int len = in.length();
    char[] nm = new char[len];
    in.getChars(0, len, nm, 0);
    for (int i = 0; i < len; i++) {
      char c = nm[i];
      if (c != '.' && ('A' > c || c > 'Z') && ('a' > c || c > 'z') && ('0' > c || c > '9'))
        nm[i] = '_'; 
    } 
    return new String(nm);
  }
  
  class CachingControl implements ExtendedCachingControl {
    private CacheControlComponent controlComponent;
    
    private Component progressBar;
    
    private CachedPullSourceStream cpss;
    
    private final DataSource this$0;
    
    CachingControl(DataSource this$0, CachedPullSourceStream cpss) {
      this.this$0 = this$0;
      this.cpss = cpss;
      this.controlComponent = new CacheControlComponent((javax.media.CachingControl)this, null);
      this.progressBar = this.controlComponent.getProgressBar();
    }
    
    public boolean isDownloading() {
      return this.cpss.isDownloading();
    }
    
    public long getContentLength() {
      return this.this$0.contentLength;
    }
    
    public long getContentProgress() {
      return this.cpss.getContentProgress();
    }
    
    public Component getProgressBarComponent() {
      return this.progressBar;
    }
    
    public Component getControlComponent() {
      return (Component)this.controlComponent;
    }
    
    public void pauseDownload() {
      this.cpss.pauseDownload();
    }
    
    public void resumeDownload() {
      this.cpss.resumeDownload();
    }
    
    public long getStartOffset() {
      return this.cpss.getStartOffset();
    }
    
    public long getEndOffset() {
      return this.cpss.getEndOffset();
    }
    
    public void setBufferSize(Time t) {}
    
    public Time getBufferSize() {
      return null;
    }
    
    public void addDownloadProgressListener(DownloadProgressListener l, int numKiloBytes) {
      this.cpss.addDownloadProgressListener(l, numKiloBytes);
    }
    
    public void removeDownloadProgressListener(DownloadProgressListener l) {
      this.cpss.removeDownloadProgressListener(l);
    }
  }
}
