package com.sun.media.protocol.https;

import com.sun.media.JMFSecurityManager;
import com.sun.media.protocol.DataSource;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLStreamHandlerFactory;
import javax.media.protocol.SourceCloneable;

public class DataSource extends DataSource implements SourceCloneable {
  private static SecurityManager securityManager = System.getSecurityManager();
  
  static {
    boolean netscape = false;
    boolean ie = false;
    boolean msjvm = false;
    String javaVendor = System.getProperty("java.vendor", "Sun").toLowerCase();
    if (javaVendor.indexOf("icrosoft") > 0)
      msjvm = true; 
    if (securityManager != null) {
      netscape = (securityManager.toString().indexOf("netscape") != -1);
      ie = (securityManager.toString().indexOf("com.ms.security") != -1);
    } 
    if (ie || msjvm) {
      try {
        Class clsFactory = Class.forName("com.ms.net.wininet.WininetStreamHandlerFactory");
        if (clsFactory != null)
          URL.setURLStreamHandlerFactory((URLStreamHandlerFactory)clsFactory.newInstance()); 
      } catch (Throwable t) {}
    } else if (!netscape) {
      if (!JMFSecurityManager.isJDK12())
        throw new UnsatisfiedLinkError("Fatal Error: DataSource for https protocol needs JDK1.2 or higher VM"); 
      try {
        Class sslproviderC = Class.forName("com.sun.net.ssl.internal.ssl.Provider");
        Object provider = sslproviderC.newInstance();
        Class securityC = Class.forName("java.security.Security");
        Class providerC = Class.forName("java.security.Provider");
        Class systemC = Class.forName("java.lang.System");
        Method addProviderM = securityC.getMethod("addProvider", new Class[] { providerC });
        Method setPropertyM = systemC.getMethod("setProperty", new Class[] { String.class, String.class });
        if (addProviderM != null && setPropertyM != null) {
          addProviderM.invoke(securityC, new Object[] { provider });
          setPropertyM.invoke(systemC, new Object[] { "java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol" });
        } 
      } catch (Exception e) {
        throw new UnsatisfiedLinkError("Fatal Error:Java Secure Socket Extension classes are not present");
      } catch (Error e) {
        throw new UnsatisfiedLinkError("Fatal Error:Java Secure Socket Extension classes are not present");
      } 
    } 
  }
  
  public javax.media.protocol.DataSource createClone() {
    DataSource ds = new DataSource();
    ds.setLocator(getLocator());
    if (this.connected)
      try {
        ds.connect();
      } catch (IOException e) {
        return null;
      }  
    return (javax.media.protocol.DataSource)ds;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\protocol\https\DataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */