/*     */ package com.sun.media.protocol.avi;
/*     */ 
/*     */ import com.sun.media.parser.video.AviParser;
/*     */ import com.sun.media.protocol.BasicSourceStream;
/*     */ import java.io.IOException;
/*     */ import javax.media.BadHeaderException;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Duration;
/*     */ import javax.media.Format;
/*     */ import javax.media.IncompatibleSourceException;
/*     */ import javax.media.MediaLocator;
/*     */ import javax.media.Time;
/*     */ import javax.media.Track;
/*     */ import javax.media.protocol.BufferTransferHandler;
/*     */ import javax.media.protocol.PushBufferDataSource;
/*     */ import javax.media.protocol.PushBufferStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSource
/*     */   extends PushBufferDataSource
/*     */ {
/*     */   private String fileName;
/*     */   private javax.media.protocol.DataSource inputDataSource;
/*     */   private AviParser aviParser;
/*     */   private Track[] tracks;
/*     */   private Format[] formats;
/*     */   private int numTracks;
/*  30 */   private String contentType = "raw";
/*     */   
/*     */   private boolean connected = false;
/*  33 */   private PushBufferStream[] streams = new PushBufferStream[0];
/*     */ 
/*     */ 
/*     */   
/*     */   public void doConnect(String fileName) throws IOException {
/*     */     try {
/*  39 */       this.fileName = fileName;
/*  40 */       this.inputDataSource = (javax.media.protocol.DataSource)new FileDataSource(fileName);
/*     */       
/*  42 */       this.inputDataSource.connect();
/*  43 */       this.aviParser = new AviParser();
/*  44 */       this.aviParser.setSource(this.inputDataSource);
/*     */       try {
/*  46 */         this.tracks = this.aviParser.getTracks();
/*     */       } catch (BadHeaderException e) {
/*  48 */         throw new IOException("");
/*     */       } 
/*     */       
/*  51 */       if (this.tracks == null || this.tracks.length <= 0) {
/*  52 */         throw new IOException("Unable to get the tracks");
/*     */       }
/*  54 */       for (int i = 0; i < this.tracks.length; i++) {
/*  55 */         System.out.println(this.tracks[i].getFormat().getEncoding());
/*     */       }
/*     */       
/*  58 */       this.numTracks = this.tracks.length;
/*  59 */       this.formats = new Format[this.numTracks];
/*  60 */       for (int j = 0; j < this.numTracks; j++) {
/*  61 */         System.out.println(this.tracks[j]);
/*  62 */         this.formats[j] = this.tracks[j].getFormat();
/*  63 */         this.tracks[j].setEnabled(true);
/*     */       } 
/*     */     } catch (IncompatibleSourceException e) {
/*     */       
/*  67 */       throw new IOException(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void connect() throws IOException {
/*  73 */     if (this.connected) {
/*     */       return;
/*     */     }
/*  76 */     MediaLocator locator = getLocator();
/*  77 */     if (locator == null) {
/*  78 */       System.err.println("medialocator is null");
/*  79 */       throw new IOException(this + ": connect() failed");
/*     */     } 
/*     */     
/*  82 */     String fileName = locator.getRemainder();
/*  83 */     doConnect(fileName);
/*     */     
/*  85 */     this.streams = new PushBufferStream[this.numTracks];
/*     */     
/*  87 */     for (int i = 0; i < this.numTracks; i++) {
/*  88 */       this.streams[i] = new AviSourceStream(this, this.tracks[i]);
/*     */     }
/*     */     
/*  91 */     System.out.println("connected");
/*  92 */     this.connected = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void disconnect() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() throws IOException {
/* 102 */     for (int i = 0; i < this.numTracks; i++) {
/* 103 */       if (this.streams[i] != null) {
/* 104 */         ((AviSourceStream)this.streams[i]).start();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() throws IOException {}
/*     */ 
/*     */   
/*     */   public String getContentType() {
/* 114 */     if (!this.connected)
/* 115 */       return null; 
/* 116 */     System.out.println("avids: getContentType returns " + this.contentType);
/* 117 */     return this.contentType;
/*     */   }
/*     */   
/*     */   public PushBufferStream[] getStreams() {
/* 121 */     if (!this.connected)
/* 122 */       return null; 
/* 123 */     return this.streams;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getControls() {
/* 128 */     return new Object[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getControl(String controlType) {
/* 133 */     return null;
/*     */   }
/*     */   
/*     */   public Time getDuration() {
/* 137 */     return Duration.DURATION_UNKNOWN;
/*     */   }
/*     */   
/*     */   class AviSourceStream
/*     */     extends BasicSourceStream implements PushBufferStream, Runnable {
/*     */     private BufferTransferHandler transferHandler;
/*     */     private boolean started;
/*     */     private Buffer buffer;
/*     */     private Format format;
/*     */     private Track track;
/*     */     private final DataSource this$0;
/*     */     
/*     */     AviSourceStream(DataSource this$0, Track track) {
/* 150 */       this.this$0 = this$0; this.transferHandler = null; this.started = false; this.buffer = new Buffer();
/* 151 */       this.track = track;
/* 152 */       this.buffer.setData(null);
/* 153 */       this.format = track.getFormat();
/*     */     }
/*     */     
/*     */     public Format getFormat() {
/* 157 */       return this.format;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setTransferHandler(BufferTransferHandler th) {
/* 162 */       System.out.println("setTransferHandler: " + th);
/* 163 */       this.transferHandler = th;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void connect() throws IOException {}
/*     */ 
/*     */ 
/*     */     
/*     */     void disconnect() {}
/*     */ 
/*     */     
/*     */     void start() throws IOException {
/* 176 */       if (this.started) {
/*     */         return;
/*     */       }
/* 179 */       if (this.transferHandler != null) {
/*     */         
/* 181 */         (new Thread(this)).start();
/* 182 */         this.started = true;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void stop() throws IOException {
/* 188 */       this.started = false;
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void read(Buffer b) {
/* 193 */       if (this.buffer.getLength() > 0) {
/* 194 */         b.setOffset(this.buffer.getOffset());
/* 195 */         b.setData(this.buffer.getData());
/*     */         
/* 197 */         b.setLength(this.buffer.getLength());
/*     */         
/* 199 */         b.setTimeStamp(this.buffer.getTimeStamp());
/* 200 */         b.setFormat(this.format);
/*     */       } else {
/*     */         
/* 203 */         b.setLength(this.buffer.getLength());
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/*     */       while (true) {
/* 212 */         this.track.readFrame(this.buffer);
/*     */         
/* 214 */         synchronized (this) {
/* 215 */           if (this.transferHandler != null)
/*     */           {
/* 217 */             this.transferHandler.transferData(this);
/*     */           }
/*     */         } 
/*     */         
/* 221 */         Thread.currentThread(); Thread.yield();
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\protocol\avi\DataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */