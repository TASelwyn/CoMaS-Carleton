package com.sun.media.protocol;

public interface Streamable {
  boolean isPrefetchable();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\protocol\Streamable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */