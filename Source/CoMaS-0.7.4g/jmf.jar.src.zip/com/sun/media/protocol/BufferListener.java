package com.sun.media.protocol;

import javax.media.protocol.DataSource;

public interface BufferListener {
  void minThresholdReached(DataSource paramDataSource);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\protocol\BufferListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */