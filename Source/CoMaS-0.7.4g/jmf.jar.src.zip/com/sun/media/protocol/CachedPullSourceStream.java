package com.sun.media.protocol;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import com.sun.media.JMFSecurity;
import com.sun.media.JMFSecurityManager;
import com.sun.media.Log;
import com.sun.media.util.MediaThread;
import com.sun.media.util.Registry;
import com.sun.media.util.jdk12;
import com.sun.media.util.jdk12CreateThreadRunnableAction;
import com.sun.media.util.jdk12DeleteFileAction;
import com.sun.media.util.jdk12MakeDirectoryAction;
import com.sun.media.util.jdk12PriorityAction;
import com.sun.media.util.jdk12RandomAccessFileAction;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import javax.media.DownloadProgressListener;
import javax.media.protocol.CachedStream;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.PullSourceStream;
import javax.media.protocol.Seekable;

public class CachedPullSourceStream implements Runnable, PullSourceStream, Seekable, CachedStream {
  private InputStream stream;
  
  private RandomAccessFile readRAF = null;
  
  private RandomAccessFile writeRAF = null;
  
  private String fileName;
  
  private int bufferSize = 2048;
  
  private byte[] buffer = new byte[this.bufferSize];
  
  private boolean eosReached = false;
  
  private boolean ioException = false;
  
  private long length;
  
  private File file;
  
  private String protocol;
  
  private boolean readAborted = false;
  
  private boolean paused = false;
  
  private boolean abort = false;
  
  private MediaThread downloadThread;
  
  private long contentLength;
  
  private int highMarkFactor = 10;
  
  private boolean blockRead = true;
  
  private static int MAX_HIGH_MARK = 2000000;
  
  private static int DEFAULT_HIGH_MARK = 1000000;
  
  private static int MIN_HIGH_MARK = 8192;
  
  private int highMark = DEFAULT_HIGH_MARK;
  
  private int lowMark = 0;
  
  private boolean enabled = true;
  
  private boolean jitterEnabled = true;
  
  private DownloadProgressListener listener = null;
  
  private int numKiloBytesUpdateIncrement = -1;
  
  private boolean closed = true;
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] m = new Method[1];
  
  private Class[] cl = new Class[1];
  
  private Object[][] args = new Object[1][0];
  
  private int maxCacheSize = Integer.MAX_VALUE;
  
  static {
    try {
      jmfSecurity = JMFSecurityManager.getJMFSecurity();
      securityPrivelege = true;
    } catch (SecurityException e) {}
  }
  
  public CachedPullSourceStream(InputStream stream, String fileName, long contentLength, String protocol) throws IOException {
    this.stream = stream;
    this.contentLength = contentLength;
    this.fileName = fileName;
    this.protocol = protocol;
    if (jmfSecurity != null) {
      String permission = null;
      int permissionid = 0;
      try {
        if (jmfSecurity.getName().startsWith("jmf-security")) {
          try {
            permission = "thread";
            jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
            this.m[0].invoke(this.cl[0], this.args[0]);
            permission = "thread group";
            jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
            this.m[0].invoke(this.cl[0], this.args[0]);
          } catch (Throwable t) {}
          permission = "read file";
          permissionid = 2;
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 2);
          this.m[0].invoke(this.cl[0], this.args[0]);
          permission = "write file";
          permissionid = 4;
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 4);
          this.m[0].invoke(this.cl[0], this.args[0]);
          permission = "delete file";
          permissionid = 8;
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 8);
          this.m[0].invoke(this.cl[0], this.args[0]);
        } else if (jmfSecurity.getName().startsWith("internet")) {
          PolicyEngine.checkPermission(PermissionID.FILEIO);
          PolicyEngine.assertPermission(PermissionID.FILEIO);
          try {
            PolicyEngine.checkPermission(PermissionID.THREAD);
            PolicyEngine.assertPermission(PermissionID.THREAD);
          } catch (Throwable t) {}
        } 
      } catch (Exception e) {
        if (permissionid > 0)
          jmfSecurity.permissionFailureNotification(permissionid); 
        securityPrivelege = false;
      } 
    } 
    if (!securityPrivelege)
      throw new IOException("No security privilege for caching"); 
    createFilesAndThread(fileName);
    Object cdir = Registry.get("secure.maxCacheSizeMB");
    if (cdir != null && cdir instanceof Integer) {
      int size = ((Integer)cdir).intValue();
      if (size < 1)
        size = 1; 
      this.maxCacheSize = size * 1000000;
    } 
    this.highMark = getHighMark(contentLength);
    this.closed = false;
  }
  
  private int getHighMark(long contentLength) {
    if (contentLength <= 0L)
      return DEFAULT_HIGH_MARK; 
    long tryHighMark = contentLength / this.highMarkFactor;
    if (tryHighMark < MIN_HIGH_MARK) {
      tryHighMark = MIN_HIGH_MARK;
    } else if (tryHighMark > MAX_HIGH_MARK) {
      tryHighMark = MAX_HIGH_MARK;
    } 
    return (int)tryHighMark;
  }
  
  public void setEnabledBuffering(boolean b) {
    this.jitterEnabled = b;
  }
  
  public boolean getEnabledBuffering() {
    return this.jitterEnabled;
  }
  
  private void createFilesAndThread(String fileName) throws IOException {
    try {
      this.file = new File(fileName);
      String parent = this.file.getParent();
      File parentFile = null;
      if (parent != null)
        parentFile = new File(parent); 
      if (securityPrivelege && jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
        if (parentFile != null) {
          Constructor cons = jdk12MakeDirectoryAction.cons;
          Boolean success = (Boolean)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { parentFile }) });
          if (success == null || !success.booleanValue())
            throw new IOException("Unable to create directory " + parentFile); 
        } 
        Constructor constructor = jdk12RandomAccessFileAction.cons;
        this.writeRAF = (RandomAccessFile)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { constructor.newInstance(new Object[] { this.file.getPath(), "rw" }) });
        if (this.writeRAF == null)
          throw new IOException("Cannot create cache file"); 
        this.readRAF = (RandomAccessFile)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { constructor.newInstance(new Object[] { this.file.getPath(), "r" }) });
        if (this.readRAF == null)
          throw new IOException("Cannot create cache file"); 
        constructor = jdk12CreateThreadRunnableAction.cons;
        this.downloadThread = (MediaThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { constructor.newInstance(new Object[] { MediaThread.class, this }) });
        this.downloadThread.setName("download");
        constructor = jdk12PriorityAction.cons;
        (new Object[2])[0] = this.downloadThread;
        this;
        jdk12.doPrivM.invoke(jdk12.ac, new Object[] { constructor.newInstance(new Object[] { null, new Integer(MediaThread.getVideoPriority()) }) });
      } else {
        if (parentFile != null && 
          !parentFile.exists() && !parentFile.mkdirs())
          throw new IOException("Unable to create directory " + parentFile); 
        this.writeRAF = new RandomAccessFile(this.file, "rw");
        this.readRAF = new RandomAccessFile(this.file, "r");
        this.downloadThread = new MediaThread(this, "download");
        this.downloadThread.useVideoPriority();
      } 
    } catch (Throwable e) {
      throw new IOException(e.getMessage());
    } 
  }
  
  private synchronized void setLength(long length) {
    this.length = length;
  }
  
  private synchronized long getLength() {
    return this.length;
  }
  
  public void run() {
    int totalBytesRead = 0;
    int nextUpdate = this.numKiloBytesUpdateIncrement;
    int debugIndex = 1;
    if (this.ioException)
      return; 
    while (!this.eosReached) {
      if (this.abort)
        return; 
      try {
        if (this.contentLength > 0L && !this.protocol.equals("https"))
          while (this.stream.available() == 0) {
            synchronized (this) {
              try {
                wait(25L);
              } catch (InterruptedException e) {}
            } 
            if (this.abort)
              return; 
          }  
        while (this.paused) {
          synchronized (this) {
            try {
              wait(1000L);
            } catch (InterruptedException e) {}
            if (this.abort)
              return; 
          } 
        } 
        int bytesRead = this.stream.read(this.buffer, 0, this.buffer.length);
        if (bytesRead != -1) {
          if (getLength() + bytesRead > this.maxCacheSize) {
            Log.warning("MAX CACHESIZE of " + this.maxCacheSize + " reached ");
            this.contentLength = totalBytesRead;
            this.eosReached = true;
          } 
          this.writeRAF.write(this.buffer, 0, bytesRead);
          totalBytesRead += bytesRead;
          long length = totalBytesRead;
          setLength(length);
          if (length == this.contentLength)
            this.eosReached = true; 
          if (this.listener != null && 
            totalBytesRead >= nextUpdate) {
            this.listener.downloadUpdate();
            nextUpdate += this.numKiloBytesUpdateIncrement;
          } 
        } else {
          setLength(totalBytesRead);
          this.contentLength = totalBytesRead;
          this.eosReached = true;
        } 
        loadUpdate();
      } catch (IOException e) {
        Log.warning(e + " : Check if you have enough space in the cache directory");
        this.ioException = true;
        this.eosReached = true;
        this.blockRead = false;
        break;
      } 
    } 
    if (this.listener != null)
      this.listener.downloadUpdate(); 
    if (this.writeRAF != null) {
      try {
        this.writeRAF.close();
        this.writeRAF = null;
      } catch (IOException e) {}
      this.writeRAF = null;
    } 
  }
  
  void startDownload() {
    if (this.enabled && 
      this.downloadThread != null)
      this.downloadThread.start(); 
  }
  
  void pauseDownload() {
    if (this.downloadThread != null && !this.downloadThread.isAlive())
      return; 
    if (this.enabled)
      synchronized (this) {
        if (!this.paused) {
          this.paused = true;
          notify();
        } 
      }  
  }
  
  void resumeDownload() {
    if (this.downloadThread != null && !this.downloadThread.isAlive())
      return; 
    if (this.enabled)
      synchronized (this) {
        if (this.paused) {
          this.paused = false;
          notify();
        } 
      }  
  }
  
  public void abortDownload() {
    this.abort = true;
  }
  
  public void abortRead() {
    synchronized (this) {
      this.readAborted = true;
    } 
  }
  
  public long seek(long where) {
    int debugTime = 0;
    synchronized (this) {
      this.readAborted = false;
    } 
    try {
      if ((!this.jitterEnabled || !drainCondition(where)) && 
        where <= getLength())
        return doSeek(where); 
      while (true) {
        if (this.eosReached) {
          if (where <= getLength())
            return doSeek(where); 
          return -1L;
        } 
        if (this.jitterEnabled)
          synchronized (this) {
            while (this.blockRead) {
              try {
                wait(100L);
              } catch (InterruptedException e) {}
              if (this.readAborted) {
                this.readAborted = false;
                return -2L;
              } 
            } 
          }  
        if (this.readAborted) {
          this.readAborted = false;
          return -2L;
        } 
        if (where <= getLength())
          return doSeek(where); 
        try {
          Thread.currentThread();
          Thread.sleep(250L);
        } catch (InterruptedException e) {}
      } 
    } finally {
      if (this.jitterEnabled)
        drainCondition(where); 
    } 
  }
  
  private long getWriteReadPtrOffset() {
    return getLength() - tell();
  }
  
  private synchronized void loadUpdate() {
    if (this.blockRead && (
      this.eosReached || getWriteReadPtrOffset() >= this.highMark)) {
      this.blockRead = false;
      synchronized (this) {
        notify();
      } 
    } 
  }
  
  private synchronized boolean drainCondition() {
    return drainCondition(tell());
  }
  
  private synchronized boolean drainCondition(long offset) {
    offset = getLength() - offset;
    if (this.eosReached) {
      if (this.blockRead) {
        this.blockRead = false;
        notify();
      } 
      return false;
    } 
    if (this.blockRead) {
      if (offset < this.highMark)
        return true; 
      this.blockRead = false;
      notify();
      return false;
    } 
    if (offset < this.lowMark) {
      this.blockRead = true;
      return true;
    } 
    return false;
  }
  
  public boolean willReadBytesBlock(long offset, int numBytes) {
    if (this.jitterEnabled && drainCondition(offset))
      return true; 
    return (offset + numBytes > getLength());
  }
  
  public boolean willReadBytesBlock(int numBytes) {
    return willReadBytesBlock(tell(), numBytes);
  }
  
  private int waitUntilSeekWillSucceed(long where) throws IOException {
    boolean debugPrint = true;
    if (!this.jitterEnabled || !drainCondition(where))
      if (where <= getLength())
        return 0;  
    while (true) {
      if (this.eosReached) {
        if (where <= getLength())
          return 0; 
        return -1;
      } 
      if (this.jitterEnabled)
        synchronized (this) {
          while (this.blockRead) {
            try {
              wait(100L);
            } catch (InterruptedException e) {}
            if (this.readAborted)
              return -2; 
          } 
        }  
      if (this.readAborted)
        return -2; 
      if (where <= getLength())
        return 0; 
      try {
        Thread.currentThread();
        Thread.sleep(250L);
      } catch (InterruptedException e) {}
    } 
  }
  
  public long tell() {
    synchronized (this) {
      if (this.closed)
        return -1L; 
      try {
        return this.readRAF.getFilePointer();
      } catch (IOException e) {
        return -1L;
      } 
    } 
  }
  
  private synchronized long doSeek(long where) {
    if (this.closed)
      return -1L; 
    try {
      this.readRAF.seek(where);
      return this.readRAF.getFilePointer();
    } catch (IOException e) {
      return -1L;
    } 
  }
  
  public synchronized int doRead(byte[] buffer, int offset, int length) throws IOException {
    if (this.closed)
      return -1; 
    try {
      int actual = this.readRAF.read(buffer, offset, length);
      return actual;
    } catch (ArrayIndexOutOfBoundsException e) {
      e.printStackTrace();
      return -2;
    } 
  }
  
  private synchronized void doClose() {
    try {
      this.closed = true;
      if (this.readRAF != null)
        this.readRAF.close(); 
      if (this.writeRAF != null)
        this.writeRAF.close(); 
      if (this.file == null)
        return; 
      deleteFile(this.file);
      this.file = null;
    } catch (IOException e) {}
  }
  
  public boolean isRandomAccess() {
    if (this.enabled)
      return true; 
    try {
      Seekable s = (Seekable)this.stream;
      return s.isRandomAccess();
    } catch (ClassCastException e) {
      return false;
    } 
  }
  
  public boolean willReadBlock() {
    return false;
  }
  
  public int read(byte[] buffer, int offset, int length) throws IOException {
    try {
      int result = waitUntilSeekWillSucceed(tell() + length);
      if (result == -1)
        return -1; 
      if (result != -2)
        return doRead(buffer, offset, length); 
      return result;
    } finally {
      if (this.jitterEnabled)
        drainCondition(); 
    } 
  }
  
  public ContentDescriptor getContentDescriptor() {
    return null;
  }
  
  public boolean endOfStream() {
    return false;
  }
  
  public Object[] getControls() {
    return new Object[0];
  }
  
  public Object getControl(String controlType) {
    return null;
  }
  
  void close() {
    if (!this.abort)
      abortDownload(); 
    if (this.downloadThread != null)
      for (int i = 0; i < 20 && 
        this.downloadThread.isAlive(); i++) {
        try {
          Thread.currentThread();
          Thread.sleep(100L);
        } catch (InterruptedException e) {}
      }  
    doClose();
  }
  
  public long getContentLength() {
    return this.contentLength;
  }
  
  long getContentProgress() {
    return this.length;
  }
  
  void addDownloadProgressListener(DownloadProgressListener l, int numKiloBytes) {
    this.listener = l;
    if (numKiloBytes <= 0)
      numKiloBytes = 1024; 
    this.numKiloBytesUpdateIncrement = numKiloBytes * 1024;
  }
  
  void removeDownloadProgressListener(DownloadProgressListener l) {
    this.listener = null;
  }
  
  long getStartOffset() {
    return 0L;
  }
  
  long getEndOffset() {
    return this.length;
  }
  
  private boolean deleteFile(File file) {
    boolean fileDeleted = false;
    try {
      if (jmfSecurity != null)
        try {
          if (jmfSecurity.getName().startsWith("jmf-security")) {
            jmfSecurity.requestPermission(this.m, this.cl, this.args, 8);
            this.m[0].invoke(this.cl[0], this.args[0]);
          } else if (jmfSecurity.getName().startsWith("internet")) {
            PolicyEngine.checkPermission(PermissionID.FILEIO);
            PolicyEngine.assertPermission(PermissionID.FILEIO);
          } 
        } catch (Exception e) {
          securityPrivelege = false;
        }  
      if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
        Constructor cons = jdk12DeleteFileAction.cons;
        Boolean success = (Boolean)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { file }) });
        fileDeleted = success.booleanValue();
      } else {
        fileDeleted = file.delete();
      } 
    } catch (Throwable e) {}
    return fileDeleted;
  }
  
  boolean isDownloading() {
    if (this.eosReached)
      return false; 
    return (this.length != -1L);
  }
}
