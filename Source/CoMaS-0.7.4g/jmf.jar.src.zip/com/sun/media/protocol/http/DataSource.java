package com.sun.media.protocol.http;

import com.sun.media.protocol.DataSource;
import java.io.IOException;
import javax.media.protocol.SourceCloneable;

public class DataSource extends DataSource implements SourceCloneable {
  public javax.media.protocol.DataSource createClone() {
    DataSource ds = new DataSource();
    ds.setLocator(getLocator());
    if (this.connected)
      try {
        ds.connect();
      } catch (IOException e) {
        return null;
      }  
    return (javax.media.protocol.DataSource)ds;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\protocol\http\DataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */