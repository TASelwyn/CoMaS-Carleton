package com.sun.media.protocol.rtsp;

import com.sun.media.protocol.BasicPushBufferDataSource;
import java.io.IOException;
import javax.media.MediaLocator;
import javax.media.Player;
import javax.media.protocol.PushBufferStream;

public class DataSource extends BasicPushBufferDataSource {
  private PushBufferStream[] srcStreams = null;
  
  private boolean stopped = true;
  
  Player streamplayer = null;
  
  public DataSource() {
    this.srcStreams = new PushBufferStream[1];
  }
  
  public PushBufferStream[] getStreams() {
    if (!this.connected)
      return null; 
    return this.srcStreams;
  }
  
  public void setPlayer(Player player) {
    this.streamplayer = player;
  }
  
  public Player getPlayer() {
    return this.streamplayer;
  }
  
  public void setSourceStream(PushBufferStream stream) {
    if (this.srcStreams != null)
      this.srcStreams[0] = stream; 
  }
  
  public void setLocator(MediaLocator mrl) {
    super.setLocator(mrl);
  }
  
  public void start() throws IOException {
    super.start();
  }
  
  public void stop() throws IOException {
    super.stop();
  }
  
  public String getContentType() {
    return "rtsp";
  }
  
  public boolean isStarted() {
    return this.started;
  }
  
  public void connect() throws IOException {
    this.connected = true;
  }
  
  public void disconnect() {
    this.connected = false;
  }
  
  public Object[] getControls() {
    return null;
  }
  
  public void setControl(Object control) {}
  
  public Object getControl(String controlName) {
    return null;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\protocol\rtsp\DataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */