/*     */ package com.sun.media.protocol.rtp;
/*     */ 
/*     */ import com.sun.media.protocol.BasicPushBufferDataSource;
/*     */ import com.sun.media.protocol.BufferListener;
/*     */ import com.sun.media.protocol.RTPSource;
/*     */ import com.sun.media.protocol.Streamable;
/*     */ import com.sun.media.rtp.RTPControlImpl;
/*     */ import com.sun.media.rtp.RTPSessionMgr;
/*     */ import com.sun.media.rtp.RTPSourceStream;
/*     */ import com.sun.media.rtp.SSRCInfo;
/*     */ import java.io.IOException;
/*     */ import javax.media.MediaLocator;
/*     */ import javax.media.Player;
/*     */ import javax.media.protocol.PushBufferStream;
/*     */ import javax.media.rtp.RTPControl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSource
/*     */   extends BasicPushBufferDataSource
/*     */   implements Streamable, RTPSource
/*     */ {
/*  25 */   static int SSRC_UNDEFINED = 0;
/*     */   
/*  27 */   private RTPSourceStream[] srcStreams = null;
/*     */   private boolean stopped = true;
/*  29 */   Player streamplayer = null;
/*  30 */   RTPSessionMgr mgr = null;
/*  31 */   RTPControl rtpcontrol = null;
/*  32 */   DataSource childsrc = null;
/*  33 */   int ssrc = SSRC_UNDEFINED;
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMgr(RTPSessionMgr mgr) {
/*  38 */     this.mgr = mgr;
/*     */   }
/*     */   
/*     */   public RTPSessionMgr getMgr() {
/*  42 */     return this.mgr;
/*     */   }
/*     */   
/*     */   public void setChild(DataSource source) {
/*  46 */     this.childsrc = source;
/*     */   }
/*     */ 
/*     */   
/*     */   public DataSource() {
/*  51 */     this.srcStreams = new RTPSourceStream[1];
/*  52 */     this.rtpcontrol = (RTPControl)new MyRTPControl(this);
/*     */     
/*  54 */     setContentType("rtp");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PushBufferStream[] getStreams() {
/*  67 */     if (!this.connected)
/*  68 */       return null; 
/*  69 */     return (PushBufferStream[])this.srcStreams;
/*     */   }
/*     */   
/*     */   public void setPlayer(Player player) {
/*  73 */     this.streamplayer = player;
/*     */   }
/*     */   
/*     */   public Player getPlayer() {
/*  77 */     return this.streamplayer;
/*     */   }
/*     */   
/*     */   public void setSourceStream(RTPSourceStream stream) {
/*  81 */     if (this.srcStreams != null)
/*  82 */       this.srcStreams[0] = stream; 
/*     */   }
/*     */   
/*     */   public void setBufferListener(BufferListener listener) {
/*  86 */     this.srcStreams[0].setBufferListener(listener);
/*     */   }
/*     */   
/*     */   public void setLocator(MediaLocator mrl) {
/*  90 */     super.setLocator(mrl);
/*     */   }
/*     */   
/*     */   public void setBufferWhenStopped(boolean flag) {
/*  94 */     this.srcStreams[0].setBufferWhenStopped(flag);
/*     */   }
/*     */   
/*     */   public void prebuffer() {
/*  98 */     this.started = true;
/*  99 */     this.srcStreams[0].prebuffer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {
/* 106 */     this.srcStreams[0].reset();
/*     */   }
/*     */   
/*     */   public void setSSRC(int ssrc) {
/* 110 */     this.ssrc = ssrc;
/*     */   }
/*     */   
/*     */   public int getSSRC() {
/* 114 */     return this.ssrc;
/*     */   }
/*     */   
/*     */   public String getCNAME() {
/* 118 */     if (this.mgr == null)
/* 119 */       return null; 
/* 120 */     SSRCInfo info = this.mgr.getSSRCInfo(this.ssrc);
/* 121 */     if (info != null)
/* 122 */       return info.getCNAME(); 
/* 123 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() throws IOException {
/* 133 */     super.start();
/* 134 */     if (this.childsrc != null)
/* 135 */       this.childsrc.start(); 
/* 136 */     if (this.srcStreams != null) {
/* 137 */       for (int i = 0; i < this.srcStreams.length; i++) {
/* 138 */         this.srcStreams[i].start();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() throws IOException {
/* 148 */     super.stop();
/*     */     
/* 150 */     if (this.childsrc != null)
/* 151 */       this.childsrc.stop(); 
/* 152 */     if (this.srcStreams != null)
/* 153 */       for (int i = 0; i < this.srcStreams.length; i++) {
/* 154 */         this.srcStreams[i].stop();
/*     */       } 
/*     */   }
/*     */   
/*     */   public void setContentType(String contentType) {
/* 159 */     this.contentType = contentType;
/*     */   }
/*     */   
/*     */   public boolean isStarted() {
/* 163 */     return this.started;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect() throws IOException {
/* 181 */     if (this.srcStreams != null)
/* 182 */       for (int i = 0; i < this.srcStreams.length; i++) {
/* 183 */         if (this.srcStreams[i] != null) {
/* 184 */           this.srcStreams[i].connect();
/*     */         }
/*     */       }  
/* 187 */     this.connected = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disconnect() {
/* 205 */     if (this.srcStreams != null) {
/* 206 */       for (int i = 0; i < this.srcStreams.length; i++) {
/* 207 */         this.srcStreams[i].close();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getControls() {
/* 232 */     RTPControl[] controls = new RTPControl[1];
/* 233 */     controls[0] = this.rtpcontrol;
/* 234 */     return (Object[])controls;
/*     */   }
/*     */   
/*     */   public void setControl(Object control) {
/* 238 */     this.rtpcontrol = (RTPControl)control;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getControl(String type) {
/*     */     Class cls;
/*     */     try {
/* 249 */       cls = Class.forName(type);
/*     */     } catch (ClassNotFoundException e) {
/* 251 */       return null;
/*     */     } 
/* 253 */     Object[] cs = getControls();
/* 254 */     for (int i = 0; i < cs.length; i++) {
/* 255 */       if (cls.isInstance(cs[i]))
/* 256 */         return cs[i]; 
/*     */     } 
/* 258 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isPrefetchable() {
/* 262 */     return false;
/*     */   }
/*     */   
/*     */   class MyRTPControl extends RTPControlImpl { MyRTPControl(DataSource this$0) {
/* 266 */       this.this$0 = this$0;
/*     */     } private final DataSource this$0;
/*     */     public int getSSRC() {
/* 269 */       return this.this$0.ssrc;
/*     */     }
/*     */     
/*     */     public String getCNAME() {
/* 273 */       if (this.this$0.mgr == null)
/* 274 */         return null; 
/* 275 */       SSRCInfo info = this.this$0.mgr.getSSRCInfo(this.this$0.ssrc);
/* 276 */       if (info != null)
/* 277 */         return info.getCNAME(); 
/* 278 */       return null;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\protocol\rtp\DataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */