package com.sun.media.protocol;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import com.sun.media.JMFSecurity;
import com.sun.media.JMFSecurityManager;
import com.sun.media.util.JMFI18N;
import com.sun.media.util.jdk12;
import com.sun.media.util.jdk12ConnectionAction;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLConnection;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.PullSourceStream;
import javax.media.protocol.Seekable;

public class BasicPullSourceStream implements PullSourceStream, Seekable {
  protected InputStream stream;
  
  protected long location;
  
  protected boolean eofReached;
  
  protected long contentLength;
  
  protected URL url;
  
  protected URLConnection urlC;
  
  private boolean needConnectPermission;
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] m = new Method[1];
  
  private Class[] cl = new Class[1];
  
  private Object[][] args = new Object[1][0];
  
  static {
    try {
      jmfSecurity = JMFSecurityManager.getJMFSecurity();
      securityPrivelege = true;
    } catch (SecurityException e) {}
  }
  
  public BasicPullSourceStream(URL url, InputStream stream, long contentLength, boolean needConnectPermission) throws IOException {
    this.needConnectPermission = needConnectPermission;
    if (stream != null) {
      this.stream = stream;
      this.contentLength = contentLength;
    } else {
      try {
        this.urlC = url.openConnection();
        this.contentLength = this.urlC.getContentLength();
        this.stream = this.urlC.getInputStream();
        if (this.stream == null)
          throw new IOException("Got null input stream from url connection"); 
      } catch (IOException ie) {
        throw new IOException("error in connection");
      } 
    } 
    this.location = 0L;
    this.eofReached = false;
    this.url = url;
  }
  
  public ContentDescriptor getContentDescriptor() {
    return null;
  }
  
  public boolean endOfStream() {
    return this.eofReached;
  }
  
  public boolean willReadBlock() {
    try {
      return (this.stream.available() == 0);
    } catch (IOException e) {
      System.err.println("Exception PullSourceStream::willReadBlock " + e.toString());
      return true;
    } 
  }
  
  public int read(byte[] buffer, int offset, int length) throws IOException {
    int len = length;
    int off = offset;
    do {
      int bytesRead = this.stream.read(buffer, off, len);
      if (bytesRead == -1) {
        this.eofReached = true;
        int totalBytesRead = length - len;
        return (totalBytesRead > 0) ? totalBytesRead : -1;
      } 
      this.location += bytesRead;
      len -= bytesRead;
      off += bytesRead;
    } while (len != 0);
    return length;
  }
  
  public Object[] getControls() {
    Object[] objects = new Object[0];
    return objects;
  }
  
  public Object getControl(String controlType) {
    return null;
  }
  
  public long seek(long where) {
    long oldLocation = this.location;
    this.location = where;
    try {
      if (where < oldLocation) {
        reopenStream();
        this.eofReached = false;
        return skip(this.stream, where);
      } 
      return skip(this.stream, where - oldLocation);
    } catch (IOException e) {
      return 0L;
    } 
  }
  
  void reopenStream() {
    try {
      if (this.stream != null)
        this.stream.close(); 
      if (this.needConnectPermission && 
        jmfSecurity != null)
        try {
          if (jmfSecurity.getName().startsWith("jmf-security")) {
            jmfSecurity.requestPermission(this.m, this.cl, this.args, 128);
            this.m[0].invoke(this.cl[0], this.args[0]);
          } else if (jmfSecurity.getName().startsWith("internet")) {
            PolicyEngine.checkPermission(PermissionID.NETIO);
            PolicyEngine.assertPermission(PermissionID.NETIO);
          } 
        } catch (Throwable e) {
          securityPrivelege = false;
          throw new IOException(JMFI18N.getResource("error.connectionerror") + e.getMessage());
        }  
      this.urlC = this.url.openConnection();
      try {
        if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
          Constructor cons = jdk12ConnectionAction.cons;
          this.stream = (InputStream)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { this.urlC }) });
        } else {
          this.stream = this.urlC.getInputStream();
        } 
      } catch (Exception e) {
        System.err.println("Unable to re-open a URL connection " + e);
        throw new IOException(JMFI18N.getResource("error.connectionerror") + e.getMessage());
      } 
    } catch (IOException ex) {}
  }
  
  public long tell() {
    return this.location;
  }
  
  public boolean isRandomAccess() {
    return true;
  }
  
  public void close() {
    try {
      this.stream.close();
      this.stream = null;
    } catch (Exception e) {
      System.out.println("BasicPullSourceStream close - IOException");
    } 
  }
  
  public long getContentLength() {
    return this.contentLength;
  }
  
  private long skip(InputStream istream, long amount) throws IOException {
    long remaining = amount;
    while (remaining > 0L) {
      long actual = istream.skip(remaining);
      remaining -= actual;
    } 
    return amount;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\protocol\BasicPullSourceStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */