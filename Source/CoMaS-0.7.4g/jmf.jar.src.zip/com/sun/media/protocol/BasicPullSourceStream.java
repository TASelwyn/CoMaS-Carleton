/*     */ package com.sun.media.protocol;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import com.sun.media.util.JMFI18N;
/*     */ import com.sun.media.util.jdk12;
/*     */ import com.sun.media.util.jdk12ConnectionAction;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.PullSourceStream;
/*     */ import javax.media.protocol.Seekable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicPullSourceStream
/*     */   implements PullSourceStream, Seekable
/*     */ {
/*     */   protected InputStream stream;
/*     */   protected long location;
/*     */   protected boolean eofReached;
/*     */   protected long contentLength;
/*     */   protected URL url;
/*     */   protected URLConnection urlC;
/*     */   private boolean needConnectPermission;
/*  46 */   private static JMFSecurity jmfSecurity = null;
/*     */   private static boolean securityPrivelege = false;
/*  48 */   private Method[] m = new Method[1];
/*  49 */   private Class[] cl = new Class[1];
/*  50 */   private Object[][] args = new Object[1][0];
/*     */   
/*     */   static {
/*     */     try {
/*  54 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  55 */       securityPrivelege = true;
/*  56 */     } catch (SecurityException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicPullSourceStream(URL url, InputStream stream, long contentLength, boolean needConnectPermission) throws IOException {
/*  66 */     this.needConnectPermission = needConnectPermission;
/*     */     
/*  68 */     if (stream != null) {
/*  69 */       this.stream = stream;
/*  70 */       this.contentLength = contentLength;
/*     */     } else {
/*     */ 
/*     */       
/*     */       try {
/*  75 */         this.urlC = url.openConnection();
/*  76 */         this.contentLength = this.urlC.getContentLength();
/*  77 */         this.stream = this.urlC.getInputStream();
/*  78 */         if (this.stream == null)
/*  79 */           throw new IOException("Got null input stream from url connection"); 
/*     */       } catch (IOException ie) {
/*  81 */         throw new IOException("error in connection");
/*     */       } 
/*     */     } 
/*     */     
/*  85 */     this.location = 0L;
/*  86 */     this.eofReached = false;
/*  87 */     this.url = url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContentDescriptor getContentDescriptor() {
/*  97 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean endOfStream() {
/* 106 */     return this.eofReached;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean willReadBlock() {
/*     */     try {
/* 116 */       return (this.stream.available() == 0);
/*     */     } catch (IOException e) {
/* 118 */       System.err.println("Exception PullSourceStream::willReadBlock " + e.toString());
/*     */       
/* 120 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] buffer, int offset, int length) throws IOException {
/* 136 */     int len = length;
/* 137 */     int off = offset;
/*     */     do {
/* 139 */       int bytesRead = this.stream.read(buffer, off, len);
/* 140 */       if (bytesRead == -1) {
/* 141 */         this.eofReached = true;
/* 142 */         int totalBytesRead = length - len;
/* 143 */         return (totalBytesRead > 0) ? totalBytesRead : -1;
/*     */       } 
/* 145 */       this.location += bytesRead;
/* 146 */       len -= bytesRead;
/* 147 */       off += bytesRead;
/*     */     }
/* 149 */     while (len != 0);
/*     */     
/* 151 */     return length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getControls() {
/* 164 */     Object[] objects = new Object[0];
/*     */     
/* 166 */     return objects;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getControl(String controlType) {
/* 178 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long seek(long where) {
/* 189 */     long oldLocation = this.location;
/* 190 */     this.location = where;
/*     */     try {
/* 192 */       if (where < oldLocation) {
/* 193 */         reopenStream();
/* 194 */         this.eofReached = false;
/* 195 */         return skip(this.stream, where);
/*     */       } 
/* 197 */       return skip(this.stream, where - oldLocation);
/*     */     
/*     */     }
/*     */     catch (IOException e) {
/*     */ 
/*     */       
/* 203 */       return 0L;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void reopenStream() {
/*     */     try {
/* 211 */       if (this.stream != null) {
/* 212 */         this.stream.close();
/*     */       }
/*     */ 
/*     */       
/* 216 */       if (this.needConnectPermission && 
/* 217 */         jmfSecurity != null) {
/*     */         try {
/* 219 */           if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 220 */             jmfSecurity.requestPermission(this.m, this.cl, this.args, 128);
/* 221 */             this.m[0].invoke(this.cl[0], this.args[0]);
/* 222 */           } else if (jmfSecurity.getName().startsWith("internet")) {
/* 223 */             PolicyEngine.checkPermission(PermissionID.NETIO);
/* 224 */             PolicyEngine.assertPermission(PermissionID.NETIO);
/*     */           }
/*     */         
/* 227 */         } catch (Throwable e) {
/*     */ 
/*     */ 
/*     */           
/* 231 */           securityPrivelege = false;
/* 232 */           throw new IOException(JMFI18N.getResource("error.connectionerror") + e.getMessage());
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 238 */       this.urlC = this.url.openConnection();
/*     */       
/*     */       try {
/* 241 */         if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/* 242 */           Constructor cons = jdk12ConnectionAction.cons;
/* 243 */           this.stream = (InputStream)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { this.urlC }) });
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */ 
/*     */           
/* 252 */           this.stream = this.urlC.getInputStream();
/*     */         } 
/*     */       } catch (Exception e) {
/* 255 */         System.err.println("Unable to re-open a URL connection " + e);
/* 256 */         throw new IOException(JMFI18N.getResource("error.connectionerror") + e.getMessage());
/*     */       }
/*     */     
/* 259 */     } catch (IOException ex) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long tell() {
/* 270 */     return this.location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRandomAccess() {
/* 281 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*     */     try {
/* 291 */       this.stream.close();
/* 292 */       this.stream = null;
/*     */     } catch (Exception e) {
/* 294 */       System.out.println("BasicPullSourceStream close - IOException");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public long getContentLength() {
/* 300 */     return this.contentLength;
/*     */   }
/*     */ 
/*     */   
/*     */   private long skip(InputStream istream, long amount) throws IOException {
/* 305 */     long remaining = amount;
/* 306 */     while (remaining > 0L) {
/* 307 */       long actual = istream.skip(remaining);
/* 308 */       remaining -= actual;
/*     */     } 
/* 310 */     return amount;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\protocol\BasicPullSourceStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */