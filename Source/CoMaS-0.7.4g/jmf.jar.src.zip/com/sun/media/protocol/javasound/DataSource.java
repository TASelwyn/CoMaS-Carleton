/*     */ package com.sun.media.protocol.javasound;
/*     */ 
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import com.sun.media.protocol.BasicPushBufferDataSource;
/*     */ import java.io.IOException;
/*     */ import javax.media.CaptureDeviceInfo;
/*     */ import javax.media.Duration;
/*     */ import javax.media.Time;
/*     */ import javax.media.control.FormatControl;
/*     */ import javax.media.protocol.CaptureDevice;
/*     */ import javax.media.protocol.PushBufferStream;
/*     */ import javax.media.protocol.RateConfiguration;
/*     */ import javax.media.protocol.RateConfigureable;
/*     */ import javax.media.protocol.RateRange;
/*     */ import javax.media.protocol.SourceStream;
/*     */ 
/*     */ public class DataSource
/*     */   extends BasicPushBufferDataSource
/*     */   implements CaptureDevice, RateConfigureable {
/*  20 */   PushBufferStream[] streams = new PushBufferStream[0];
/*  21 */   JavaSoundSourceStream sourceStream = null;
/*     */   
/*     */   String contentType;
/*     */   
/*     */   Time duration;
/*     */   boolean started = false;
/*  27 */   static String ContentType = "raw";
/*     */   
/*     */   public DataSource() {
/*  30 */     JMFSecurityManager.checkCapture();
/*  31 */     this.contentType = ContentType;
/*  32 */     this.duration = Duration.DURATION_UNBOUNDED;
/*  33 */     this.sourceStream = new JavaSoundSourceStream(this);
/*  34 */     this.streams = new PushBufferStream[1];
/*  35 */     this.streams[0] = this.sourceStream;
/*     */   }
/*     */   
/*     */   public static CaptureDeviceInfo[] listCaptureDeviceInfo() {
/*  39 */     return JavaSoundSourceStream.listCaptureDeviceInfo();
/*     */   }
/*     */   
/*     */   public CaptureDeviceInfo getCaptureDeviceInfo() {
/*  43 */     return JavaSoundSourceStream.listCaptureDeviceInfo()[0];
/*     */   }
/*     */   
/*     */   public FormatControl[] getFormatControls() {
/*  47 */     FormatControl[] fc = new FormatControl[1];
/*  48 */     fc[0] = (FormatControl)this.sourceStream.getControl("javax.media.control.FormatControl");
/*  49 */     return fc;
/*     */   }
/*     */ 
/*     */   
/*     */   public PushBufferStream[] getStreams() {
/*  54 */     if (this.streams == null) {
/*  55 */       System.err.println("DataSource needs to be connected before calling getStreams");
/*     */     }
/*  57 */     return this.streams;
/*     */   }
/*     */ 
/*     */   
/*     */   public void connect() throws IOException {
/*  62 */     if (this.sourceStream.isConnected()) {
/*     */       return;
/*     */     }
/*  65 */     if (getLocator() != null)
/*  66 */       this.sourceStream.setFormat(JavaSoundSourceStream.parseLocator(getLocator())); 
/*  67 */     this.sourceStream.connect();
/*     */   }
/*     */ 
/*     */   
/*     */   public void disconnect() {
/*  72 */     this.sourceStream.disconnect();
/*     */   }
/*     */ 
/*     */   
/*     */   public void start() throws IOException {
/*  77 */     this.sourceStream.start();
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() throws IOException {
/*  82 */     this.sourceStream.stop();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentType() {
/*  87 */     return this.contentType;
/*     */   }
/*     */ 
/*     */   
/*     */   public Time getDuration() {
/*  92 */     return this.duration;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean getStarted() {
/*  97 */     return this.started;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getControls() {
/* 102 */     Object[] o = this.sourceStream.getControls();
/* 103 */     return o;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getControl(String name) {
/* 108 */     return this.sourceStream.getControl(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RateConfiguration[] getRateConfigurations() {
/* 115 */     RateConfiguration[] config = { new OneRateConfig(this) };
/* 116 */     return config;
/*     */   }
/*     */   
/*     */   public RateConfiguration setRateConfiguration(RateConfiguration config) {
/* 120 */     return config;
/*     */   }
/*     */   
/*     */   class OneRateConfig implements RateConfiguration {
/*     */     private final DataSource this$0;
/*     */     
/*     */     OneRateConfig(DataSource this$0) {
/* 127 */       this.this$0 = this$0;
/*     */     } public RateRange getRate() {
/* 129 */       return new RateRange(1.0F, 1.0F, 1.0F, true);
/*     */     }
/*     */     
/*     */     public SourceStream[] getStreams() {
/* 133 */       SourceStream[] ss = { (SourceStream)this.this$0.sourceStream };
/* 134 */       return ss;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\protocol\javasound\DataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */