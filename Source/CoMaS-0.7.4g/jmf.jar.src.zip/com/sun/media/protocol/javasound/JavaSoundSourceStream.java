/*     */ package com.sun.media.protocol.javasound;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.CircularBuffer;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.protocol.BasicSourceStream;
/*     */ import com.sun.media.renderer.audio.device.JavaSoundOutput;
/*     */ import com.sun.media.ui.AudioFormatChooser;
/*     */ import com.sun.media.util.Arch;
/*     */ import com.sun.media.util.jdk12;
/*     */ import java.awt.Component;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.CaptureDeviceInfo;
/*     */ import javax.media.Format;
/*     */ import javax.media.MediaLocator;
/*     */ import javax.media.Owned;
/*     */ import javax.media.control.BufferControl;
/*     */ import javax.media.control.FormatControl;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.protocol.BufferTransferHandler;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.PushBufferStream;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioSystem;
/*     */ import javax.sound.sampled.DataLine;
/*     */ import javax.sound.sampled.TargetDataLine;
/*     */ 
/*     */ public class JavaSoundSourceStream
/*     */   extends BasicSourceStream
/*     */   implements PushBufferStream {
/*     */   DataSource dsource;
/*  38 */   TargetDataLine dataLine = null;
/*     */   
/*     */   AudioFormat format;
/*     */   AudioFormat devFormat;
/*     */   boolean reconnect = false;
/*     */   int bufSize;
/*     */   BufferTransferHandler transferHandler;
/*     */   boolean started = false;
/*     */   AudioFormatChooser afc;
/*     */   BufferControl bc;
/*  48 */   CircularBuffer cb = new CircularBuffer(1);
/*  49 */   PushThread pushThread = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   static int DefRate = 44100;
/*  56 */   static int DefBits = 16;
/*  57 */   static int DefChannels = 2;
/*  58 */   static int DefSigned = 1;
/*  59 */   static int DefEndian = Arch.isBigEndian() ? 1 : 0;
/*     */ 
/*     */   
/*  62 */   static int OtherEndian = Arch.isBigEndian() ? 1 : 0;
/*     */   
/*     */   static Format[] supported;
/*     */   
/*     */   protected static CaptureDeviceInfo[] deviceList;
/*     */   
/*  68 */   private static JMFSecurity jmfSecurity = null;
/*     */   private static boolean securityPrivelege = false;
/*  70 */   private Method[] mSecurity = new Method[1];
/*  71 */   private Class[] clSecurity = new Class[1];
/*  72 */   private Object[][] argsSecurity = new Object[1][0]; static int DefaultMinBufferSize;
/*     */   static int DefaultMaxBufferSize;
/*     */   long bufLenReq;
/*     */   
/*     */   static { try {
/*  77 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  78 */       securityPrivelege = true;
/*  79 */     } catch (SecurityException e) {}
/*     */ 
/*     */     
/*  82 */     supported = new Format[] { (Format)new AudioFormat("LINEAR", 44100.0D, 16, 2, DefEndian, DefSigned), (Format)new AudioFormat("LINEAR", 44100.0D, 16, 1, DefEndian, DefSigned), (Format)new AudioFormat("LINEAR", 22050.0D, 16, 2, DefEndian, DefSigned), (Format)new AudioFormat("LINEAR", 22050.0D, 16, 1, DefEndian, DefSigned), (Format)new AudioFormat("LINEAR", 11025.0D, 16, 2, DefEndian, DefSigned), (Format)new AudioFormat("LINEAR", 11025.0D, 16, 1, DefEndian, DefSigned), (Format)new AudioFormat("LINEAR", 8000.0D, 16, 2, DefEndian, DefSigned), (Format)new AudioFormat("LINEAR", 8000.0D, 16, 1, DefEndian, DefSigned) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 143 */     deviceList = new CaptureDeviceInfo[] { new CaptureDeviceInfo("JavaSound audio capture", new MediaLocator("javasound://44100"), supported) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 680 */     DefaultMinBufferSize = 16;
/* 681 */     DefaultMaxBufferSize = 4000; } public JavaSoundSourceStream(DataSource ds) { super(new ContentDescriptor("raw"), -1L);
/* 682 */     this.bufLenReq = 125L; this.dsource = ds; this.bc = new BC(this, this); this.controls = (Object[])new javax.media.Control[2]; this.controls[0] = new FC(this, this); this.controls[1] = this.bc; }
/*     */   public static Format parseLocator(MediaLocator ml) { String rateStr = null, bitsStr = null, channelsStr = null; String endianStr = null, signedStr = null; String remainder = ml.getRemainder(); if (remainder != null && remainder.length() > 0) { while (remainder.length() > 1 && remainder.charAt(0) == '/') remainder = remainder.substring(1);  int off = remainder.indexOf('/'); if (off == -1) { if (!remainder.equals("")) rateStr = remainder;  } else { rateStr = remainder.substring(0, off); remainder = remainder.substring(off + 1); off = remainder.indexOf('/'); if (off == -1) { if (!remainder.equals("")) bitsStr = remainder;  } else { bitsStr = remainder.substring(0, off); remainder = remainder.substring(off + 1); off = remainder.indexOf('/'); if (off == -1) { if (!remainder.equals("")) channelsStr = remainder;  } else { channelsStr = remainder.substring(0, off); remainder = remainder.substring(off + 1); off = remainder.indexOf('/'); if (off == -1) { if (!remainder.equals("")) endianStr = remainder;  } else { endianStr = remainder.substring(0, off); if (!remainder.equals("")) signedStr = remainder.substring(off + 1);  }  }  }  }  }  int rate = DefRate; if (rateStr != null) { try { Integer integer = Integer.valueOf(rateStr); if (integer != null) rate = integer.intValue();  } catch (Throwable t) {} if (rate <= 0 || rate > 96000) { Log.warning("JavaSound capture: unsupported sample rate: " + rate); rate = DefRate; Log.warning("        defaults to: " + rate); }  }  int bits = DefBits; if (bitsStr != null) { try { Integer integer = Integer.valueOf(bitsStr); if (integer != null) bits = integer.intValue();  } catch (Throwable t) {} if (bits != 8 && bits != 16) { Log.warning("JavaSound capture: unsupported sample size: " + bits); bits = DefBits; Log.warning("        defaults to: " + bits); }  }  int channels = DefChannels; if (channelsStr != null) { try { Integer integer = Integer.valueOf(channelsStr); if (integer != null) channels = integer.intValue();  } catch (Throwable t) {} if (channels != 1 && channels != 2) { Log.warning("JavaSound capture: unsupported # of channels: " + channels); channels = DefChannels; Log.warning("        defaults to: " + channels); }  }  int endian = DefEndian; if (endianStr != null) if (endianStr.equalsIgnoreCase("big")) { endian = 1; } else if (endianStr.equalsIgnoreCase("little")) { endian = 0; } else { Log.warning("JavaSound capture: unsupported endianess: " + endianStr); Log.warning("        defaults to: big endian"); }   int signed = DefSigned; if (signedStr != null) if (signedStr.equalsIgnoreCase("signed")) { signed = 1; } else if (signedStr.equalsIgnoreCase("unsigned")) { signed = 0; } else { Log.warning("JavaSound capture: unsupported signedness: " + signedStr); Log.warning("        defaults to: signed"); }   AudioFormat fmt = new AudioFormat("LINEAR", rate, bits, channels, endian, signed); return (Format)fmt; }
/*     */   public Format setFormat(Format fmt) { if (this.started) { Log.warning("Cannot change audio capture format after started."); return (Format)this.format; }  if (fmt == null) return (Format)this.format;  Format f = null; for (int i = 0; i < supported.length && (!fmt.matches(supported[i]) || (f = fmt.intersects(supported[i])) == null); i++); if (f == null) return (Format)this.format;  try { if (this.devFormat != null) { if (!this.devFormat.matches(f) && !JavaSoundOutput.isOpen()) { this.format = (AudioFormat)f; disconnect(); connect(); }  } else { this.format = (AudioFormat)f; connect(); }  } catch (IOException e) { return null; }  if (this.afc != null) this.afc.setCurrentFormat(this.format);  return (Format)this.format; }
/*     */   public boolean isConnected() { return (this.devFormat != null); }
/*     */   public void connect() throws IOException { if (isConnected()) return;  if (JavaSoundOutput.isOpen()) { Log.warning("JavaSound is already opened for rendering.  Will capture at the default format."); this.format = null; }  openDev(); if (this.pushThread == null) { if (jmfSecurity != null) { String permission = null; try { if (jmfSecurity.getName().startsWith("jmf-security")) { permission = "thread"; jmfSecurity.requestPermission(this.mSecurity, this.clSecurity, this.argsSecurity, 16); this.mSecurity[0].invoke(this.clSecurity[0], this.argsSecurity[0]); permission = "thread group"; jmfSecurity.requestPermission(this.mSecurity, this.clSecurity, this.argsSecurity, 32); this.mSecurity[0].invoke(this.clSecurity[0], this.argsSecurity[0]); } else if (jmfSecurity.getName().startsWith("internet")) { PolicyEngine.checkPermission(PermissionID.THREAD); PolicyEngine.assertPermission(PermissionID.THREAD); }  } catch (Throwable e) { securityPrivelege = false; }  }  if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) { try { Constructor cons = jdk12CreateThreadAction.cons; this.pushThread = (PushThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { PushThread.class }) }); } catch (Exception e) {} } else { this.pushThread = new PushThread(); }  this.pushThread.setSourceStream(this); }  if (this.reconnect) Log.comment("Capture buffer size: " + this.bufSize);  this.devFormat = this.format; this.reconnect = false; }
/*     */   void openDev() throws IOException { DataLine.Info info; AudioFormat afmt = null; if (this.format != null) { afmt = JavaSoundOutput.convertFormat(this.format); int chnls = (this.format.getChannels() == -1) ? 1 : this.format.getChannels(); int size = (this.format.getSampleSizeInBits() == -1) ? 16 : this.format.getSampleSizeInBits(); int frameSize = size * chnls / 8; if (frameSize == 0) frameSize = 1;  this.bufSize = (int)(this.format.getSampleRate() * frameSize * this.bc.getBufferLength() / 1000.0D); info = new DataLine.Info(TargetDataLine.class, afmt, this.bufSize); } else { info = new DataLine.Info(TargetDataLine.class, null, -1); }  if (!AudioSystem.isLineSupported(info)) { Log.error("Audio not supported: " + info + "\n"); throw new IOException("Cannot open audio device for input."); }  try { this.dataLine = (TargetDataLine)AudioSystem.getLine(info); if (this.format != null) { this.dataLine.open(afmt, this.bufSize); } else { this.dataLine.open(); this.format = JavaSoundOutput.convertFormat(this.dataLine.getFormat()); }  this.bufSize = this.dataLine.getBufferSize(); } catch (Exception e) { Log.error("Cannot open audio device for input: " + e); throw new IOException(e.getMessage()); }  }
/*     */   public void disconnect() { if (this.dataLine == null) return;  this.dataLine.stop(); this.dataLine.close(); this.dataLine = null; this.devFormat = null; if (this.pushThread != null) { this.pushThread.kill(); this.pushThread = null; }  } public void start() throws IOException { if (this.dataLine == null) throw new IOException("A JavaSound input channel cannot be opened.");  if (this.started) return;  if (this.afc != null) { Format f; if ((f = this.afc.getFormat()) == null || f.matches((Format)this.format) || setFormat(f) == null); this.afc.setEnabled(false); }  if (this.reconnect) disconnect();  if (!isConnected()) connect();  synchronized (this.cb) { while (this.cb.canRead()) { this.cb.read(); this.cb.readReport(); }  this.cb.notifyAll(); }  this.pushThread.start(); this.dataLine.flush(); this.dataLine.start(); this.started = true; } public void stop() throws IOException { if (!this.started) return;  this.pushThread.pause(); if (this.dataLine != null) this.dataLine.stop();  this.started = false; if (this.afc != null && !JavaSoundOutput.isOpen()) this.afc.setEnabled(true);  } public Format getFormat() { return (Format)this.format; } public Object[] getControls() { return this.controls; } public static Format[] getSupportedFormats() { return supported; } public static CaptureDeviceInfo[] listCaptureDeviceInfo() { return deviceList; } public void setTransferHandler(BufferTransferHandler th) { this.transferHandler = th; } public boolean willReadBlock() { return !this.started; } public void read(Buffer in) { Buffer buffer; synchronized (this.cb) { while (!this.cb.canRead()) { try { this.cb.wait(); } catch (Exception e) {} }  buffer = this.cb.read(); }  Object data = in.getData(); in.copy(buffer); buffer.setData(data); synchronized (this.cb) { this.cb.readReport(); this.cb.notify(); }  } class FC implements FormatControl, Owned {
/*     */     JavaSoundSourceStream jsss; private final JavaSoundSourceStream this$0; public FC(JavaSoundSourceStream this$0, JavaSoundSourceStream jsss) { this.this$0 = this$0; this.jsss = jsss; } public Object getOwner() { return this.this$0.dsource; } public Format getFormat() { return (Format)this.this$0.format; } public Format setFormat(Format fmt) { return this.jsss.setFormat(fmt); } public Format[] getSupportedFormats() { return JavaSoundSourceStream.supported; } public boolean isEnabled() { return true; } public void setEnabled(boolean enabled) {} public Component getControlComponent() { if (this.this$0.afc == null) { this.this$0.afc = new AudioFormatChooser(JavaSoundSourceStream.supported, this.this$0.format); this.this$0.afc.setName("JavaSound"); if (this.this$0.started || this.this$0.dataLine == null || JavaSoundOutput.isOpen()) this.this$0.afc.setEnabled(false);  }  return (Component)this.this$0.afc; }
/*     */   } class BC implements BufferControl, Owned {
/* 691 */     JavaSoundSourceStream jsss; BC(JavaSoundSourceStream this$0, JavaSoundSourceStream js) { this.this$0 = this$0;
/* 692 */       this.jsss = js; }
/*     */     
/*     */     private final JavaSoundSourceStream this$0;
/*     */     public long getBufferLength() {
/* 696 */       return this.this$0.bufLenReq;
/*     */     }
/*     */     
/*     */     public long setBufferLength(long time) {
/* 700 */       if (time < JavaSoundSourceStream.DefaultMinBufferSize) {
/* 701 */         this.this$0.bufLenReq = JavaSoundSourceStream.DefaultMinBufferSize;
/* 702 */       } else if (time > JavaSoundSourceStream.DefaultMaxBufferSize) {
/* 703 */         this.this$0.bufLenReq = JavaSoundSourceStream.DefaultMaxBufferSize;
/*     */       } else {
/* 705 */         this.this$0.bufLenReq = time;
/* 706 */       }  Log.comment("Capture buffer length set: " + this.this$0.bufLenReq);
/* 707 */       this.this$0.reconnect = true;
/* 708 */       return this.this$0.bufLenReq;
/*     */     }
/*     */     
/*     */     public long getMinimumThreshold() {
/* 712 */       return 0L;
/*     */     }
/*     */     
/*     */     public long setMinimumThreshold(long time) {
/* 716 */       return 0L;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setEnabledThreshold(boolean b) {}
/*     */     
/*     */     public boolean getEnabledThreshold() {
/* 723 */       return false;
/*     */     }
/*     */     
/*     */     public Component getControlComponent() {
/* 727 */       return null;
/*     */     }
/*     */     
/*     */     public Object getOwner() {
/* 731 */       return this.this$0.dsource;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\protocol\javasound\JavaSoundSourceStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */