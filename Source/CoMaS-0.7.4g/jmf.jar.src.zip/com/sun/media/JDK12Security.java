/*     */ package com.sun.media;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.Permission;
/*     */ import java.security.PrivilegedAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDK12Security
/*     */   implements JMFSecurity
/*     */ {
/*     */   public static final JMFSecurity security;
/*  19 */   private static Class cls = null;
/*  20 */   private static Method dummyMethodRef = null;
/*     */   
/*  22 */   private static Permission threadPermission = null;
/*  23 */   private static Permission threadGroupPermission = null;
/*  24 */   private static Permission connectPermission = null;
/*  25 */   private static Permission multicastPermission = null;
/*  26 */   private static Permission readAllFilesPermission = null;
/*     */   
/*     */   private static Constructor filepermcons;
/*     */ 
/*     */   
/*     */   static {
/*  32 */     security = new JDK12Security();
/*     */     try {
/*  34 */       cls = security.getClass();
/*  35 */       dummyMethodRef = cls.getMethod("dummyMethod", new Class[0]);
/*     */ 
/*     */       
/*  38 */       Class rtperm = Class.forName("java.lang.RuntimePermission");
/*  39 */       Class socketperm = Class.forName("java.net.SocketPermission");
/*  40 */       Class fileperm = Class.forName("java.io.FilePermission");
/*  41 */       filepermcons = fileperm.getConstructor(new Class[] { String.class, String.class });
/*     */ 
/*     */       
/*  44 */       Constructor cons = rtperm.getConstructor(new Class[] { String.class });
/*  45 */       threadPermission = (Permission)cons.newInstance(new Object[] { "modifyThread" });
/*     */ 
/*     */       
/*  48 */       threadGroupPermission = (Permission)cons.newInstance(new Object[] { "modifyThreadGroup" });
/*     */ 
/*     */ 
/*     */       
/*  52 */       cons = socketperm.getConstructor(new Class[] { String.class, String.class });
/*     */ 
/*     */ 
/*     */       
/*  56 */       connectPermission = (Permission)cons.newInstance(new Object[] { "*", "connect" });
/*     */ 
/*     */ 
/*     */       
/*  60 */       multicastPermission = (Permission)cons.newInstance(new Object[] { "*", "accept,connect" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  73 */     catch (Exception e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Permission getReadFilePermission(String name) {
/*     */     try {
/*  80 */       return filepermcons.newInstance(new Object[] { name, "read" });
/*     */     } catch (Exception e) {
/*     */       
/*  83 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Permission getWriteFilePermission(String name) {
/*     */     try {
/*  89 */       return filepermcons.newInstance(new Object[] { name, "read, write" });
/*     */     } catch (Exception e) {
/*     */       
/*  92 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dummyMethod() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 106 */     return "jdk12";
/*     */   }
/*     */   
/*     */   public static Permission getThreadPermission() {
/* 110 */     return threadPermission;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Permission getThreadGroupPermission() {
/* 115 */     return threadGroupPermission;
/*     */   }
/*     */   
/*     */   public static Permission getConnectPermission() {
/* 119 */     return connectPermission;
/*     */   }
/*     */   
/*     */   public static Permission getMulticastPermission() {
/* 123 */     return multicastPermission;
/*     */   }
/*     */   
/*     */   public static Permission getReadAllFilesPermission() {
/* 127 */     return readAllFilesPermission;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void requestPermission(Method[] m, Class[] c, Object[][] args, int request) throws SecurityException {
/* 134 */     m[0] = dummyMethodRef;
/* 135 */     c[0] = cls;
/* 136 */     args[0] = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void requestPermission(Method[] m, Class[] c, Object[][] args, int request, String parameter) throws SecurityException {
/* 144 */     requestPermission(m, c, args, request);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLinkPermissionEnabled() {
/* 149 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void permissionFailureNotification(int permission) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadLibrary(String name) throws UnsatisfiedLinkError {
/* 160 */     AccessController.doPrivileged(new PrivilegedAction(this, name)
/*     */         {
/*     */           public Object run() {
/* 163 */             System.loadLibrary(this.val$name);
/* 164 */             return null;
/*     */           }
/*     */           
/*     */           private final String val$name;
/*     */           private final JDK12Security this$0;
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\JDK12Security.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */