/*     */ package com.sun.media.codec.video.colorspace;
/*     */ 
/*     */ import com.sun.media.BasicCodec;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.control.FrameProcessingControl;
/*     */ import javax.media.format.RGBFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RGBConverter
/*     */   extends BasicCodec
/*     */ {
/*     */   private static final String PLUGIN_NAME = "RGB To RGB Converter";
/*  22 */   private FrameProcessingControl frameControl = null;
/*     */   private boolean dropFrame;
/*     */   
/*     */   public RGBConverter() {
/*  26 */     this.inputFormats = new Format[] { (Format)new RGBFormat() };
/*  27 */     this.outputFormats = new Format[] { (Format)new RGBFormat() };
/*  28 */     if (this.frameControl == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  53 */       this.frameControl = new RGBConverter$1$FPC(this);
/*  54 */       ((BasicPlugIn)this).controls = (Object[])new javax.media.Control[1];
/*  55 */       ((BasicPlugIn)this).controls[0] = this.frameControl;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getName() {
/*  60 */     return "RGB To RGB Converter";
/*     */   }
/*     */ 
/*     */   
/*     */   public Format[] getSupportedOutputFormats(Format input) {
/*  65 */     if (input == null)
/*  66 */       return this.outputFormats; 
/*  67 */     if (input instanceof RGBFormat) {
/*  68 */       RGBFormat rgb = (RGBFormat)input;
/*  69 */       Dimension size = rgb.getSize();
/*  70 */       float frameRate = rgb.getFrameRate();
/*  71 */       int bpp = rgb.getBitsPerPixel();
/*  72 */       RGBFormat bits_16_p = new RGBFormat(size, size.width * size.height, Format.shortArray, frameRate, 16, -1, -1, -1, 1, size.width, -1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  82 */       RGBFormat bits_16_up = new RGBFormat(size, size.width * size.height * 2, Format.byteArray, frameRate, 16, -1, -1, -1, 2, size.width * 2, -1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  92 */       RGBFormat masks_565 = new RGBFormat(null, -1, null, -1.0F, -1, 63488, 2016, 31, -1, -1, -1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  99 */       RGBFormat masks_555 = new RGBFormat(null, -1, null, -1.0F, -1, 31744, 992, 31, -1, -1, -1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 106 */       RGBFormat bits_24_up = new RGBFormat(size, size.width * size.height * 3, Format.byteArray, frameRate, 24, -1, -1, -1, 3, size.width * 3, -1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 116 */       RGBFormat masks_RGB = new RGBFormat(null, -1, null, -1.0F, -1, 1, 2, 3, -1, -1, -1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 122 */       RGBFormat masks_BGR = new RGBFormat(null, -1, null, -1.0F, -1, 3, 2, 1, -1, -1, -1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 128 */       RGBFormat bits_32_p = new RGBFormat(size, size.width * size.height, Format.intArray, frameRate, 32, -1, -1, -1, 1, size.width, -1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 137 */       RGBFormat bits_32_up = new RGBFormat(size, size.width * size.height * 4, Format.byteArray, frameRate, 32, -1, -1, -1, 4, size.width * 4, -1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 147 */       RGBFormat masks_234 = new RGBFormat(null, -1, null, -1.0F, -1, 2, 3, 4, -1, -1, -1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 153 */       RGBFormat masks_432 = new RGBFormat(null, -1, null, -1.0F, -1, 4, 3, 2, -1, -1, -1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 159 */       RGBFormat masks_123 = new RGBFormat(null, -1, null, -1.0F, -1, 1, 2, 3, -1, -1, -1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 165 */       RGBFormat flipped = new RGBFormat(null, -1, null, -1.0F, -1, -1, -1, -1, -1, -1, 1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 173 */       RGBFormat straight = new RGBFormat(null, -1, null, -1.0F, -1, -1, -1, -1, -1, -1, 0, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 181 */       RGBFormat big = new RGBFormat(null, -1, null, -1.0F, -1, -1, -1, -1, -1, -1, -1, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 190 */       RGBFormat little = new RGBFormat(null, -1, null, -1.0F, -1, -1, -1, -1, -1, -1, -1, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 199 */       RGBFormat masks_321 = new RGBFormat(null, -1, null, -1.0F, -1, 3, 2, 1, -1, -1, -1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 205 */       RGBFormat masks_XRGB = new RGBFormat(null, -1, null, -1.0F, -1, 16711680, 65280, 255, -1, -1, -1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 211 */       RGBFormat masks_XBGR = new RGBFormat(null, -1, null, -1.0F, -1, 255, 65280, 16711680, -1, -1, -1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 219 */       Format[] out = { bits_16_p.intersects((Format)masks_565).intersects((Format)flipped), bits_16_p.intersects((Format)masks_565).intersects((Format)straight), bits_16_up.intersects((Format)masks_565).intersects((Format)flipped).intersects((Format)little), bits_16_up.intersects((Format)masks_565).intersects((Format)flipped).intersects((Format)big), bits_16_up.intersects((Format)masks_565).intersects((Format)straight).intersects((Format)little), bits_16_up.intersects((Format)masks_565).intersects((Format)straight).intersects((Format)big), bits_16_p.intersects((Format)masks_555).intersects((Format)flipped), bits_16_p.intersects((Format)masks_555).intersects((Format)straight), bits_16_up.intersects((Format)masks_555).intersects((Format)flipped).intersects((Format)little), bits_16_up.intersects((Format)masks_555).intersects((Format)flipped).intersects((Format)big), bits_16_up.intersects((Format)masks_555).intersects((Format)straight).intersects((Format)little), bits_16_up.intersects((Format)masks_555).intersects((Format)straight).intersects((Format)big), bits_24_up.intersects((Format)masks_RGB).intersects((Format)flipped), bits_24_up.intersects((Format)masks_RGB).intersects((Format)straight), bits_24_up.intersects((Format)masks_BGR).intersects((Format)flipped), bits_24_up.intersects((Format)masks_BGR).intersects((Format)straight), bits_32_p.intersects((Format)masks_XRGB).intersects((Format)flipped), bits_32_p.intersects((Format)masks_XRGB).intersects((Format)straight), bits_32_p.intersects((Format)masks_XBGR).intersects((Format)flipped), bits_32_p.intersects((Format)masks_XBGR).intersects((Format)straight), bits_32_up.intersects((Format)masks_123).intersects((Format)flipped), bits_32_up.intersects((Format)masks_123).intersects((Format)straight), bits_32_up.intersects((Format)masks_321).intersects((Format)flipped), bits_32_up.intersects((Format)masks_321).intersects((Format)straight), bits_32_up.intersects((Format)masks_234).intersects((Format)flipped), bits_32_up.intersects((Format)masks_234).intersects((Format)straight), bits_32_up.intersects((Format)masks_432).intersects((Format)flipped), bits_32_up.intersects((Format)masks_432).intersects((Format)straight) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 256 */       return out;
/*     */     } 
/* 258 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format setInputFormat(Format in) {
/* 302 */     Format returnFormat = super.setInputFormat(in);
/* 303 */     if (returnFormat == null)
/* 304 */       return null; 
/* 305 */     if (((RGBFormat)returnFormat).getBitsPerPixel() < 15)
/* 306 */       return null; 
/* 307 */     Dimension size = ((VideoFormat)in).getSize();
/*     */     
/* 309 */     if (this.opened)
/*     */     {
/* 311 */       this.outputFormat = (Format)updateRGBFormat((VideoFormat)in, (RGBFormat)this.outputFormat);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 331 */     return returnFormat;
/*     */   }
/*     */   
/*     */   public int process(Buffer inBuffer, Buffer outBuffer) {
/* 335 */     if (isEOM(inBuffer)) {
/* 336 */       propagateEOM(outBuffer);
/* 337 */       return 0;
/*     */     } 
/*     */     
/* 340 */     if (this.dropFrame) {
/* 341 */       outBuffer.setFlags(outBuffer.getFlags() | 0x2);
/* 342 */       return 0;
/*     */     } 
/*     */     
/* 345 */     RGBFormat inputRGB = (RGBFormat)this.inputFormat;
/* 346 */     RGBFormat outputRGB = (RGBFormat)this.outputFormat;
/*     */     
/* 348 */     Object inObject = inBuffer.getData();
/* 349 */     Object outObject = outBuffer.getData();
/*     */ 
/*     */     
/* 352 */     if (inObject.getClass() != this.inputFormat.getDataType()) {
/* 353 */       return 1;
/*     */     }
/* 355 */     int outMaxDataLen = outputRGB.getMaxDataLength();
/* 356 */     int outLength = 0;
/* 357 */     if (outObject != null) {
/* 358 */       if (outObject.getClass() == Format.byteArray) {
/* 359 */         outLength = ((byte[])outObject).length;
/* 360 */       } else if (outObject.getClass() == Format.shortArray) {
/* 361 */         outLength = ((short[])outObject).length;
/* 362 */       } else if (outObject.getClass() == Format.intArray) {
/* 363 */         outLength = ((int[])outObject).length;
/*     */       } 
/*     */     }
/*     */     
/* 367 */     if (outObject == null || outLength < outMaxDataLen || this.outputFormat != outBuffer.getFormat() || !this.outputFormat.equals(outBuffer.getFormat())) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 372 */       Class outputDataType = this.outputFormat.getDataType();
/* 373 */       if (outputDataType == Format.byteArray) {
/* 374 */         outObject = new byte[outputRGB.getMaxDataLength()];
/* 375 */       } else if (outputDataType == Format.shortArray) {
/* 376 */         outObject = new short[outputRGB.getMaxDataLength()];
/* 377 */       } else if (outputDataType == Format.intArray) {
/* 378 */         outObject = new int[outputRGB.getMaxDataLength()];
/*     */       } else {
/* 380 */         return 1;
/* 381 */       }  outBuffer.setData(outObject);
/*     */     } 
/*     */ 
/*     */     
/* 385 */     if (outObject.getClass() != this.outputFormat.getDataType()) {
/* 386 */       return 1;
/*     */     }
/* 388 */     int inBPP = inputRGB.getBitsPerPixel();
/* 389 */     int outBPP = outputRGB.getBitsPerPixel();
/* 390 */     boolean inPacked = (inputRGB.getDataType() != Format.byteArray);
/* 391 */     boolean outPacked = (outputRGB.getDataType() != Format.byteArray);
/* 392 */     int inPS = inputRGB.getPixelStride();
/* 393 */     int outPS = outputRGB.getPixelStride();
/* 394 */     int inEndian = inputRGB.getEndian();
/* 395 */     int outEndian = outputRGB.getEndian();
/* 396 */     int inRed = inputRGB.getRedMask();
/* 397 */     int inGreen = inputRGB.getGreenMask();
/* 398 */     int inBlue = inputRGB.getBlueMask();
/* 399 */     int outRed = outputRGB.getRedMask();
/* 400 */     int outGreen = outputRGB.getGreenMask();
/* 401 */     int outBlue = outputRGB.getBlueMask();
/* 402 */     int inLS = inputRGB.getLineStride();
/* 403 */     int outLS = outputRGB.getLineStride();
/*     */     
/* 405 */     boolean flip = (inputRGB.getFlipped() != outputRGB.getFlipped());
/* 406 */     Dimension size = inputRGB.getSize();
/* 407 */     int width = size.width;
/* 408 */     int height = size.height;
/*     */     
/* 410 */     if (inBPP == 16 && outBPP == 16) {
/* 411 */       sixteenToSixteen(inObject, inPS, inLS, inBPP, inRed, inGreen, inBlue, inPacked, inEndian, outObject, outPS, outLS, outBPP, outRed, outGreen, outBlue, outPacked, outEndian, width, height, flip);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 416 */     else if (inBPP == 16 && outBPP >= 24) {
/* 417 */       sixteenToComponent(inObject, inPS, inLS, inBPP, inRed, inGreen, inBlue, inPacked, inEndian, outObject, outPS, outLS, outBPP, outRed, outGreen, outBlue, outPacked, outEndian, width, height, flip);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 422 */     else if (inBPP >= 24 && outBPP == 16) {
/* 423 */       componentToSixteen(inObject, inPS, inLS, inBPP, inRed, inGreen, inBlue, inPacked, inEndian, outObject, outPS, outLS, outBPP, outRed, outGreen, outBlue, outPacked, outEndian, width, height, flip);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 428 */     else if (inBPP >= 24 && outBPP >= 24) {
/*     */ 
/*     */       
/* 431 */       componentToComponent(inObject, inPS, inLS, inBPP, inRed, inGreen, inBlue, inPacked, inEndian, outObject, outPS, outLS, outBPP, outRed, outGreen, outBlue, outPacked, outEndian, width, height, flip);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 438 */     outBuffer.setFormat(this.outputFormat);
/* 439 */     outBuffer.setLength(outputRGB.getMaxDataLength());
/*     */     
/* 441 */     return 0;
/*     */   }
/*     */   
/*     */   public void open() throws ResourceUnavailableException {
/* 445 */     super.open();
/*     */   }
/*     */   
/*     */   public void close() {
/* 449 */     super.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {}
/*     */   
/*     */   protected int getShift(int mask) {
/* 456 */     int shift = 0;
/* 457 */     while ((mask & 0x1) == 0) {
/* 458 */       mask >>= 1;
/* 459 */       shift++;
/*     */     } 
/* 461 */     return shift;
/*     */   }
/*     */   
/*     */   protected abstract void sixteenToSixteen(Object paramObject1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean1, int paramInt7, Object paramObject2, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, boolean paramBoolean2, int paramInt14, int paramInt15, int paramInt16, boolean paramBoolean3);
/*     */   
/*     */   protected abstract void sixteenToComponent(Object paramObject1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean1, int paramInt7, Object paramObject2, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, boolean paramBoolean2, int paramInt14, int paramInt15, int paramInt16, boolean paramBoolean3);
/*     */   
/*     */   protected abstract void componentToSixteen(Object paramObject1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean1, int paramInt7, Object paramObject2, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, boolean paramBoolean2, int paramInt14, int paramInt15, int paramInt16, boolean paramBoolean3);
/*     */   
/*     */   protected abstract void componentToComponent(Object paramObject1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean1, int paramInt7, Object paramObject2, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, boolean paramBoolean2, int paramInt14, int paramInt15, int paramInt16, boolean paramBoolean3);
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\codec\video\colorspace\RGBConverter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */