/*     */ package com.sun.media.codec.video.jpeg;
/*     */ 
/*     */ import javax.media.Buffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RTPDePacketizer
/*     */ {
/*  35 */   private JPEGFrame currentFrame = null;
/*  36 */   protected byte[] frameBuffer = null;
/*  37 */   protected int sequenceNumber = 0;
/*  38 */   protected int quality = 0;
/*  39 */   protected int type = -1;
/*     */   
/*  41 */   byte[] lastJFIFHeader = null;
/*  42 */   int lastQuality = -2;
/*  43 */   int lastType = -1;
/*  44 */   int lastWidth = -1;
/*  45 */   int lastHeight = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getQuality() {
/*  51 */     return this.quality;
/*     */   }
/*     */   
/*     */   public int getType() {
/*  55 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int process(Buffer inBuffer, Buffer outBuffer) {
/*  72 */     if (this.currentFrame != null && inBuffer.getTimeStamp() != this.currentFrame.rtptimestamp)
/*     */     {
/*  74 */       this.currentFrame = null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  79 */     if (getFragOffset((byte[])inBuffer.getData(), inBuffer.getOffset()) == 0) {
/*  80 */       this.currentFrame = new JPEGFrame(this, inBuffer, (byte[])outBuffer.getData());
/*  81 */     } else if (this.currentFrame != null) {
/*     */       
/*  83 */       this.currentFrame.add(inBuffer, 0);
/*     */     }
/*     */     else {
/*     */       
/*  87 */       return 4;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  92 */     if ((inBuffer.getFlags() & 0x800) != 0) {
/*  93 */       if (this.currentFrame.gotAllPackets(inBuffer.getSequenceNumber())) {
/*  94 */         this.currentFrame.completeTransfer(inBuffer, outBuffer);
/*  95 */         this.currentFrame = null;
/*  96 */         return 0;
/*     */       } 
/*  98 */       this.currentFrame = null;
/*  99 */       return 4;
/*     */     } 
/*     */ 
/*     */     
/* 103 */     return 4;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFragOffset(byte[] data, int doff) {
/* 109 */     int foff = 0;
/* 110 */     foff |= (data[doff + 1] & 0xFF) << 16;
/* 111 */     foff |= (data[doff + 2] & 0xFF) << 8;
/* 112 */     foff |= data[doff + 3] & 0xFF;
/*     */     
/* 114 */     return foff;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\codec\video\jpeg\RTPDePacketizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */