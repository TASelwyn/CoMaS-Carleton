package com.sun.media.codec.video.mpeg;

import java.awt.Dimension;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Vector;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.format.VideoFormat;

public class RTPDePacketizer {
  public static float[] RATE_TABLE = new float[] { 0.0F, 23.976F, 24.0F, 25.0F, 29.97F, 30.0F, 50.0F, 59.94F, 60.0F };
  
  private static char[] hexChar = new char[] { 
      '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
      'a', 'b', 'c', 'd', 'e', 'f' };
  
  private long discardtimestamp = -1L;
  
  private MPEGFrame currentframe = null;
  
  private boolean newframe = true;
  
  private boolean gotSequenceHeader = false;
  
  private boolean sequenceSent = false;
  
  private byte[] sequenceHeader = null;
  
  private boolean gopset = false;
  
  private int closedGop = 0;
  
  private int ref_pic_temp = -1;
  
  private int dep_pic_temp = -1;
  
  private int sequenceNumber = 0;
  
  private int width = 352;
  
  private int height = 240;
  
  private float frameRate = -1.0F;
  
  private VideoFormat outFormat = null;
  
  private boolean allowHeadless = false;
  
  private boolean fullFrameOnly = true;
  
  private boolean droppedPFrame = false;
  
  private boolean droppedIFrame = false;
  
  private boolean capture = false;
  
  private OutputStream captureFile = null;
  
  private static final boolean debug = false;
  
  RTPDePacketizer() {
    if (this.capture)
      try {
        this.captureFile = new BufferedOutputStream(new FileOutputStream("/tmp/rtpstream.mpg"));
      } catch (IOException ioe) {
        System.err.println("RTPDePacketizer: unable to open file " + ioe);
        this.capture = false;
      }  
  }
  
  public void finalize() {
    if (this.capture)
      try {
        this.captureFile.flush();
        this.captureFile.close();
        System.err.println("RTPDePacketizer: closed file");
      } catch (IOException ioe) {
        System.err.println("RTPDePacketizer: unable to close file " + ioe);
        this.capture = false;
      }  
  }
  
  public int process(Buffer inBuffer, Buffer outBuffer) {
    if (inBuffer.getTimeStamp() == this.discardtimestamp && this.discardtimestamp != -1L)
      return 4; 
    if (!this.newframe && this.currentframe != null && inBuffer.getTimeStamp() != this.currentframe.rtptimestamp) {
      if (this.allowHeadless || firstPacket(inBuffer)) {
        boolean haveframe = false;
        if (this.fullFrameOnly) {
          dropFrame();
        } else {
          haveframe = constructFrame(outBuffer);
        } 
        this.currentframe = createNewFrame(inBuffer);
        if (haveframe)
          return 0; 
        if ((this.currentframe.getFirst().getFlags() & 0x800) != 0)
          if (constructFrame(outBuffer))
            return 0;  
        return 4;
      } 
      this.discardtimestamp = inBuffer.getTimeStamp();
      if (this.fullFrameOnly) {
        dropFrame();
        dropBufferFrame(inBuffer);
      } else if (compareSequenceNumbers(this.currentframe.seqno, inBuffer.getSequenceNumber()) > 0) {
        if (constructFrame(outBuffer))
          return 0; 
      } 
      return 4;
    } 
    if (this.newframe) {
      if (firstPacket(inBuffer)) {
        this.newframe = false;
        this.currentframe = createNewFrame(inBuffer);
        if ((this.currentframe.getFirst().getFlags() & 0x800) != 0)
          if (constructFrame(outBuffer))
            return 0;  
        return 4;
      } 
      if (this.fullFrameOnly)
        dropBufferFrame(inBuffer); 
      this.discardtimestamp = inBuffer.getTimeStamp();
      this.newframe = true;
      return 4;
    } 
    int ret = addToFrame(inBuffer, outBuffer);
    return ret;
  }
  
  protected String toHex(byte[] inData, int inOffset) {
    String hex = new String();
    for (int i = 0; i < 4; i++) {
      hex = hex + hexChar[inData[inOffset + i] >> 4 & 0xF];
      hex = hex + hexChar[inData[inOffset + i] & 0xF];
    } 
    return hex;
  }
  
  private int addToFrame(Buffer inBuffer, Buffer outBuffer) {
    Buffer b = copyInto(inBuffer);
    this.currentframe.add(b);
    if ((b.getFlags() & 0x800) != 0)
      if (constructFrame(outBuffer))
        return 0;  
    return 4;
  }
  
  private void constructGop(Buffer outBuffer) {
    byte[] dest = (byte[])outBuffer.getData();
    int outoffset = outBuffer.getLength();
    if (this.sequenceHeader != null) {
      System.arraycopy(this.sequenceHeader, 0, dest, outoffset, this.sequenceHeader.length);
      outBuffer.setLength(outBuffer.getLength() + this.sequenceHeader.length);
      outoffset += this.sequenceHeader.length;
      this.sequenceSent = true;
    } 
    dest[outoffset] = 0;
    dest[outoffset + 1] = 0;
    dest[outoffset + 2] = 1;
    dest[outoffset + 3] = -72;
    dest[outoffset + 4] = Byte.MIN_VALUE;
    dest[outoffset + 5] = 8;
    dest[outoffset + 6] = 0;
    dest[outoffset + 7] = (byte)(this.closedGop | 0x20);
    outBuffer.setLength(outBuffer.getLength() + 8);
    this.ref_pic_temp = 0;
    this.dep_pic_temp = -1;
  }
  
  private void constructPicture(Buffer inBuffer, Buffer outBuffer) {
    byte[] payload = (byte[])inBuffer.getData();
    int offset = inBuffer.getOffset();
    byte[] dest = (byte[])outBuffer.getData();
    int outoffset = outBuffer.getLength();
    int next = 0;
    dest[outoffset] = 0;
    dest[outoffset + 1] = 0;
    dest[outoffset + 2] = 1;
    dest[outoffset + 3] = 0;
    dest[outoffset + 4] = (byte)((payload[offset] & 0x3) << 6 | (payload[offset + 1] & 0xFC) >> 2);
    int ptype = payload[offset + 2] & 0x7;
    int back = (payload[offset + 3] & 0xF0) >> 4;
    int fwd = payload[offset + 3] & 0xF;
    dest[outoffset + 5] = (byte)((payload[offset + 1] & 0x2) << 6 | ptype << 3);
    dest[outoffset + 6] = 0;
    if (ptype == 1) {
      dest[outoffset + 7] = 0;
      outBuffer.setLength(outBuffer.getLength() + 8);
    } else {
      next = fwd >> 1;
      dest[outoffset + 7] = (byte)next;
      next = (fwd & 0x1) << 7;
      if (ptype > 2)
        next |= back << 3; 
      dest[outoffset + 8] = (byte)next;
      outBuffer.setLength(outBuffer.getLength() + 9);
    } 
  }
  
  private void constructHeaders(Buffer outBuffer) {
    boolean havePicture = false;
    int outoffset = 0;
    byte[] dest = (byte[])outBuffer.getData();
    Buffer src = this.currentframe.data.elementAt(0);
    byte[] payload = (byte[])src.getData();
    int offset = src.getOffset();
    int tr = (payload[offset] & 0x3) << 8 | payload[offset + 1] & 0xFF;
    int type = payload[offset + 2] & 0x7;
    if (src.getLength() >= 8 && (payload[offset + 2] & 0x10) == 16 && payload[offset + 4] == 0 && payload[offset + 5] == 0 && payload[offset + 6] == 1) {
      int startCode = payload[offset + 7] & 0xFF;
      if (startCode == 179) {
        this.sequenceSent = true;
        this.ref_pic_temp = tr;
        this.dep_pic_temp = -1;
        return;
      } 
      if (startCode == 184) {
        if (this.sequenceHeader != null) {
          System.arraycopy(this.sequenceHeader, 0, dest, outBuffer.getLength(), this.sequenceHeader.length);
          outBuffer.setLength(outBuffer.getLength() + this.sequenceHeader.length);
          this.sequenceSent = true;
        } 
        this.ref_pic_temp = tr;
        this.dep_pic_temp = -1;
        return;
      } 
      if (startCode == 0)
        havePicture = true; 
    } 
    this.ref_pic_temp++;
    this.dep_pic_temp++;
    if (type < 3) {
      if (tr < this.ref_pic_temp)
        constructGop(outBuffer); 
      this.ref_pic_temp = tr;
    } else {
      if (tr < this.dep_pic_temp)
        constructGop(outBuffer); 
      this.dep_pic_temp = tr;
    } 
    if (!havePicture)
      constructPicture(src, outBuffer); 
  }
  
  private void dropFrame() {
    Buffer src = this.currentframe.data.firstElement();
    dropBufferFrame(src);
  }
  
  private void dropBufferFrame(Buffer src) {
    int type = ((byte[])src.getData())[src.getOffset() + 2] & 0x7;
    if (type == 1) {
      this.droppedIFrame = true;
    } else if (type == 2) {
      this.droppedPFrame = true;
    } 
    this.newframe = true;
    this.currentframe = null;
  }
  
  private boolean constructFrame(Buffer outBuffer) {
    Buffer src = this.currentframe.data.lastElement();
    int type = ((byte[])src.getData())[src.getOffset() + 2] & 0x7;
    if (this.fullFrameOnly) {
      if (type >= 2 && (this.droppedIFrame || this.droppedPFrame)) {
        dropFrame();
        return false;
      } 
      if (type == 1) {
        this.droppedIFrame = false;
        this.droppedPFrame = false;
      } 
      if ((src.getFlags() & 0x800) == 0) {
        dropFrame();
        return false;
      } 
      for (int j = this.currentframe.data.size() - 2; j >= 0; j--) {
        Buffer prev = this.currentframe.data.elementAt(j);
        if (compareSequenceNumbers(prev.getSequenceNumber(), src.getSequenceNumber()) != 1) {
          dropFrame();
          return false;
        } 
        src = prev;
      } 
    } 
    boolean noslices = true;
    byte[] dest = (byte[])outBuffer.getData();
    if (dest == null || dest.length < this.currentframe.datalength + this.sequenceHeader.length + 16)
      dest = new byte[this.currentframe.datalength + this.sequenceHeader.length + 16]; 
    outBuffer.setData(dest);
    outBuffer.setOffset(0);
    outBuffer.setLength(0);
    constructHeaders(outBuffer);
    if (!this.sequenceSent) {
      dropFrame();
      return false;
    } 
    int outoffset = outBuffer.getLength();
    for (int i = 0; i < this.currentframe.data.size(); i++) {
      src = this.currentframe.data.elementAt(i);
      byte[] payload = (byte[])src.getData();
      int offset = src.getOffset();
      if ((payload[offset + 2] & 0x10) == 16)
        if ((payload[offset + 2] & 0x8) == 8) {
          System.arraycopy(payload, offset + 4, dest, outoffset, src.getLength() - 4);
          outoffset += src.getLength() - 4;
          noslices = false;
        } else {
          long seq = src.getSequenceNumber();
          int j;
          for (j = i + 1; j < this.currentframe.data.size(); j++) {
            Buffer next = this.currentframe.data.elementAt(j);
            if (compareSequenceNumbers(seq, next.getSequenceNumber()) != 1) {
              if (i == 0) {
                offset += 4;
                int len = src.getLength() - 4;
                int off = offset;
                while (len > 4 && (
                  payload[off + 0] != 0 || payload[off + 1] != 0 || payload[off + 2] != 1 || (payload[off + 3] & 0xFF) <= 0 || (payload[off + 3] & 0xFF) > 175)) {
                  off++;
                  len--;
                } 
                if (off == offset)
                  // Byte code: goto -> 702 
                System.arraycopy(payload, offset, dest, outoffset, off - offset);
                outoffset += off - offset;
                // Byte code: goto -> 702
              } 
              // Byte code: goto -> 702
            } 
            seq = next.getSequenceNumber();
            if ((((byte[])next.getData())[next.getOffset() + 2] & 0x8) == 8)
              break; 
          } 
          if (j == this.currentframe.data.size())
            break; 
          for (int k = i; k <= j; k++) {
            src = this.currentframe.data.elementAt(k);
            System.arraycopy(src.getData(), src.getOffset() + 4, dest, outoffset, src.getLength() - 4);
            outoffset += src.getLength() - 4;
          } 
          noslices = false;
          i = j;
        }  
    } 
    if (this.outFormat == null || (this.outFormat.getSize()).width != this.width || (this.outFormat.getSize()).height != this.height || this.outFormat.getFrameRate() != this.frameRate) {
      Dimension d = new Dimension(this.width, this.height);
      this.outFormat = new VideoFormat("mpeg", d, -1, Format.byteArray, this.frameRate);
    } 
    outBuffer.setLength(outoffset);
    outBuffer.setFormat((Format)this.outFormat);
    if (noslices)
      outBuffer.setFlags(2); 
    outBuffer.setTimeStamp(this.currentframe.rtptimestamp);
    outBuffer.setSequenceNumber(this.sequenceNumber++);
    this.newframe = true;
    this.currentframe = null;
    if (noslices)
      return false; 
    if (this.capture)
      try {
        this.captureFile.write((byte[])outBuffer.getData(), outBuffer.getOffset(), outBuffer.getLength());
      } catch (IOException ioe) {
        System.err.println("RTPDePacketizer: write error for sequence number " + outBuffer.getSequenceNumber() + " : " + ioe);
        this.capture = false;
      }  
    return true;
  }
  
  private boolean firstPacket(Buffer inBuffer) {
    if (inBuffer == null)
      return false; 
    byte[] payload = (byte[])inBuffer.getData();
    if (payload == null)
      return false; 
    int offset = inBuffer.getOffset();
    int len = inBuffer.getLength();
    if (len < 12)
      return false; 
    if (!this.gotSequenceHeader) {
      if ((payload[offset + 2] & 0x20) == 32 && payload[offset + 4] == 0 && payload[offset + 5] == 0 && payload[offset + 6] == 1 && (payload[offset + 7] & 0xFF) == 179) {
        this.width = (payload[offset + 8] & 0xFF) << 4 | (payload[offset + 9] & 0xF0) >> 4;
        this.height = (payload[offset + 9] & 0xF) << 8 | payload[offset + 10] & 0xFF;
        this.gotSequenceHeader = true;
        offset += 4;
        len -= 4;
        int off = offset;
        while (len > 8) {
          if (payload[off + 0] == 0 && payload[off + 1] == 0 && payload[off + 2] == 1)
            if ((payload[off + 3] & 0xFF) == 184) {
              this.gopset = true;
              this.closedGop = payload[off + 7] & 0x40;
              payload[off + 7] = (byte)(payload[off + 7] & 0x20);
              this.sequenceHeader = new byte[off - offset];
              System.arraycopy(payload, offset, this.sequenceHeader, 0, this.sequenceHeader.length);
              return true;
            }  
          off++;
          len--;
        } 
        return true;
      } 
      return false;
    } 
    if ((payload[offset + 2] & 0x10) != 16)
      return false; 
    offset += 4;
    len -= 4;
    while (len > 8) {
      if (payload[offset + 0] == 0 && payload[offset + 1] == 0 && payload[offset + 2] == 1) {
        if (payload[offset + 3] == 0)
          return true; 
        if ((payload[offset + 3] & 0xFF) == 184) {
          this.gopset = true;
          this.closedGop = payload[offset + 7] & 0x40;
          payload[offset + 7] = (byte)(payload[offset + 7] | 0x20);
          return true;
        } 
        if ((payload[offset + 3] & 0xFF) <= 175)
          return false; 
      } 
      offset++;
      len--;
    } 
    return false;
  }
  
  private static int MAX_SEQ = 65535;
  
  private int compareSequenceNumbers(long p, long c) {
    if (c > p)
      return (int)(c - p); 
    if (c == p)
      return 0; 
    if (p > (MAX_SEQ - 100) && c < 100L)
      return (int)(MAX_SEQ - p + c + 1L); 
    return -1;
  }
  
  private MPEGFrame createNewFrame(Buffer inBuffer) {
    Buffer b = copyInto(inBuffer);
    MPEGFrame newframe = new MPEGFrame(this, b);
    newframe.add(b);
    return newframe;
  }
  
  private Buffer copyInto(Buffer src) {
    Buffer dest = new Buffer();
    dest.copy(src);
    src.setData(null);
    src.setHeader(null);
    src.setLength(0);
    src.setOffset(0);
    return dest;
  }
  
  class MPEGFrame {
    public long rtptimestamp;
    
    public long seqno;
    
    private int datalength;
    
    private Vector data;
    
    private final RTPDePacketizer this$0;
    
    public MPEGFrame(RTPDePacketizer this$0, Buffer buffer) {
      this.this$0 = this$0;
      this.rtptimestamp = -1L;
      this.seqno = -1L;
      this.datalength = 0;
      this.data = new Vector();
      this.rtptimestamp = buffer.getTimeStamp();
    }
    
    public void add(Buffer buffer) {
      if (buffer == null || buffer.getData() == null || buffer.getLength() < 4)
        return; 
      if (this.this$0.compareSequenceNumbers(this.seqno, buffer.getSequenceNumber()) > 0) {
        this.data.addElement(buffer);
        this.seqno = buffer.getSequenceNumber();
      } else {
        long sq = buffer.getSequenceNumber();
        for (int i = 0; i < this.data.size(); i++) {
          long bsq = ((Buffer)this.data.elementAt(i)).getSequenceNumber();
          if (this.this$0.compareSequenceNumbers(bsq, sq) < 0) {
            this.data.insertElementAt(buffer, i);
            break;
          } 
          if (sq == bsq)
            return; 
        } 
      } 
      this.datalength += buffer.getLength() - 4;
    }
    
    public Vector getData() {
      return this.data;
    }
    
    public Buffer getFirst() {
      if (this.data.size() > 0)
        return this.data.firstElement(); 
      return null;
    }
    
    public int getLength() {
      return this.datalength;
    }
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\codec\video\mpeg\RTPDePacketizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */