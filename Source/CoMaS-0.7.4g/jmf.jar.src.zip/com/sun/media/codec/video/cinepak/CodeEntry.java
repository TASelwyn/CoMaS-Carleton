package com.sun.media.codec.video.cinepak;

public class CodeEntry {
  int aRGB0;
  
  int aRGB1;
  
  int aRGB2;
  
  int aRGB3;
  
  public CodeEntry(CodeEntry fromCode) {
    this.aRGB0 = fromCode.aRGB0;
    this.aRGB1 = fromCode.aRGB1;
    this.aRGB2 = fromCode.aRGB2;
    this.aRGB3 = fromCode.aRGB3;
  }
  
  public CodeEntry() {
    this.aRGB0 = 10724259;
    this.aRGB1 = 10724259;
    this.aRGB2 = 10724259;
    this.aRGB3 = 10724259;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\codec\video\cinepak\CodeEntry.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */