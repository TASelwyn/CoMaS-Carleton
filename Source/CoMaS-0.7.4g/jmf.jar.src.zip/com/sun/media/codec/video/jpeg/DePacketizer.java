package com.sun.media.codec.video.jpeg;

import com.sun.media.BasicCodec;
import com.sun.media.BasicPlugIn;
import java.awt.Dimension;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.ResourceUnavailableException;
import javax.media.format.JPEGFormat;
import javax.media.format.VideoFormat;

public class DePacketizer extends BasicCodec {
  private VideoFormat inputFormat = null;
  
  private JPEGFormat outputFormat = null;
  
  private int decimation = -1;
  
  private int quality = -1;
  
  private RTPDePacketizer rtpdp = null;
  
  int DEFAULT_WIDTH = 320;
  
  int DEFAULT_HEIGHT = 240;
  
  public DePacketizer() {
    this.inputFormats = new Format[] { (Format)new VideoFormat("jpeg/rtp") };
    this.outputFormats = new Format[] { (Format)new VideoFormat("jpeg") };
  }
  
  protected Format getInputFormat() {
    return (Format)this.inputFormat;
  }
  
  protected Format getOutputFormat() {
    return (Format)this.outputFormat;
  }
  
  public Format[] getSupportedOutputFormats(Format in) {
    if (in == null)
      return this.outputFormats; 
    if (BasicPlugIn.matches(in, this.inputFormats) == null)
      return new Format[0]; 
    Format[] out = new Format[1];
    out[0] = (Format)makeJPEGFormat(in);
    return out;
  }
  
  public Format setInputFormat(Format input) {
    this.inputFormat = (VideoFormat)input;
    if (this.opened)
      this.outputFormat = makeJPEGFormat((Format)this.inputFormat); 
    return input;
  }
  
  public Format setOutputFormat(Format output) {
    if (!(output instanceof VideoFormat))
      return null; 
    this.outputFormat = makeJPEGFormat(output);
    return (Format)this.outputFormat;
  }
  
  private final JPEGFormat makeJPEGFormat(Format in) {
    VideoFormat vf = (VideoFormat)in;
    return new JPEGFormat((vf.getSize() != null) ? vf.getSize() : new Dimension(this.DEFAULT_WIDTH, this.DEFAULT_HEIGHT), -1, Format.byteArray, vf.getFrameRate(), this.quality, this.decimation);
  }
  
  public void open() throws ResourceUnavailableException {
    if (this.inputFormat == null || this.outputFormat == null)
      throw new ResourceUnavailableException("Incorrect formats set on JPEG converter"); 
    this.rtpdp = new RTPDePacketizer();
    super.open();
  }
  
  public synchronized void close() {
    this.rtpdp = null;
    super.close();
  }
  
  public void reset() {}
  
  public synchronized int process(Buffer inBuffer, Buffer outBuffer) {
    if (isEOM(inBuffer)) {
      propagateEOM(outBuffer);
      return 0;
    } 
    if (inBuffer.isDiscard()) {
      updateOutput(outBuffer, (Format)this.outputFormat, 0, 0);
      outBuffer.setDiscard(true);
      return 4;
    } 
    int retVal = this.rtpdp.process(inBuffer, outBuffer);
    if (retVal != 0)
      return retVal; 
    int type = this.rtpdp.getType();
    int q = this.rtpdp.getQuality();
    if (type != this.decimation || q != this.quality) {
      this.decimation = type;
      this.quality = q;
      this.outputFormat = makeJPEGFormat(inBuffer.getFormat());
    } 
    outBuffer.setFormat((Format)this.outputFormat);
    outBuffer.setOffset(0);
    outBuffer.setTimeStamp(inBuffer.getTimeStamp());
    inBuffer.setLength(0);
    outBuffer.setFlags(outBuffer.getFlags() | 0x10);
    return 0;
  }
  
  public void finalize() {
    close();
  }
  
  public String getName() {
    return "JPEG DePacketizer";
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\codec\video\jpeg\DePacketizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */