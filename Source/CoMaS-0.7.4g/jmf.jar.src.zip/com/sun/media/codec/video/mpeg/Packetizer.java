/*     */ package com.sun.media.codec.video.mpeg;
/*     */ 
/*     */ import com.sun.media.BasicCodec;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import java.util.Vector;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Packetizer
/*     */   extends BasicCodec
/*     */ {
/*  28 */   public static float[] RATE_TABLE = new float[] { 0.0F, 23.976F, 24.0F, 25.0F, 29.97F, 30.0F, 50.0F, 59.94F, 60.0F };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  33 */   private static char[] hexChar = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  39 */   protected static int SEGMENT_DONE = 1;
/*  40 */   protected static int SEGMENT_REPEAT = 2;
/*  41 */   protected static int SEGMENT_DONE_BUFFER_FULL = 3;
/*     */ 
/*     */   
/*  44 */   protected static int PACKET_MAX = 1456;
/*     */   
/*     */   private static boolean debug = false;
/*     */   
/*  48 */   private VideoFormat inputFormat = null;
/*  49 */   private VideoFormat outputFormat = null;
/*     */   
/*     */   private boolean inputEOM = false;
/*     */   
/*     */   private boolean expectingNewInput = true;
/*     */   
/*     */   private boolean expectingNewOutput = true;
/*     */   
/*     */   private boolean resetTime = true;
/*     */   private boolean resetInProgress = true;
/*  59 */   private Vector outputQueue = new Vector();
/*     */ 
/*     */ 
/*     */   
/*  63 */   private Vector inputQueue = new Vector();
/*     */ 
/*     */ 
/*     */   
/*  67 */   private Vector segmentQueue = new Vector();
/*     */ 
/*     */   
/*  70 */   private byte[] sequenceHeader = null;
/*     */   
/*  72 */   private int frameWidth = 0;
/*  73 */   private int frameHeight = 0;
/*  74 */   private double frameRate = 0.0D;
/*     */ 
/*     */   
/*  77 */   private long picNanos = 0L;
/*     */ 
/*     */   
/*  80 */   private long gopTime = 0L;
/*     */ 
/*     */   
/*  83 */   private long startTime = 1L;
/*     */ 
/*     */ 
/*     */   
/*  87 */   private long frameTime = 0L;
/*  88 */   private long frameCount = 0L;
/*     */ 
/*     */   
/*  91 */   private int sequenceNumber = 0;
/*     */ 
/*     */   
/*  94 */   private byte[] mpegHeader = new byte[] { 0, 0, 0, 0 };
/*     */ 
/*     */ 
/*     */   
/*     */   public Packetizer() {
/*  99 */     this.inputFormats = new Format[] { (Format)new VideoFormat("mpeg") };
/* 100 */     this.outputFormats = new Format[] { (Format)new VideoFormat("mpeg/rtp") };
/*     */   }
/*     */   
/*     */   protected Format getInputFormat() {
/* 104 */     return (Format)this.inputFormat;
/*     */   }
/*     */   
/*     */   protected Format getOutputFormat() {
/* 108 */     return (Format)this.outputFormat;
/*     */   }
/*     */ 
/*     */   
/*     */   public Format[] getSupportedOutputFormats(Format in) {
/* 113 */     if (in == null) {
/* 114 */       return this.outputFormats;
/*     */     }
/*     */     
/* 117 */     if (BasicPlugIn.matches(in, this.inputFormats) == null) {
/* 118 */       return new Format[0];
/*     */     }
/* 120 */     Format[] out = new Format[1];
/* 121 */     out[0] = (Format)makeMPEGFormat(in);
/* 122 */     return out;
/*     */   }
/*     */   
/*     */   public Format setInputFormat(Format input) {
/* 126 */     this.inputFormat = (VideoFormat)input;
/* 127 */     return input;
/*     */   }
/*     */   
/*     */   public Format setOutputFormat(Format output) {
/* 131 */     if (!(output instanceof VideoFormat)) return null; 
/* 132 */     this.outputFormat = makeMPEGFormat(output);
/* 133 */     return output;
/*     */   }
/*     */   
/*     */   private final VideoFormat makeMPEGFormat(Format in) {
/* 137 */     VideoFormat vf = (VideoFormat)in;
/* 138 */     return new VideoFormat("mpeg/rtp", vf.getSize(), -1, Format.byteArray, vf.getFrameRate());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() throws ResourceUnavailableException {
/* 146 */     if (this.inputFormat == null || this.outputFormat == null) {
/* 147 */       throw new ResourceUnavailableException("Incorrect formats set on MPEG converter");
/*     */     }
/* 149 */     this.startTime = 1L;
/* 150 */     this.frameRate = 0.0D;
/* 151 */     this.picNanos = 0L;
/* 152 */     this.sequenceNumber = 0;
/* 153 */     this.resetTime = true;
/*     */   }
/*     */   
/*     */   public synchronized void close() {
/* 157 */     reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 162 */     super.reset();
/* 163 */     this.outputQueue.removeAllElements();
/* 164 */     this.inputQueue.removeAllElements();
/* 165 */     this.segmentQueue.removeAllElements();
/* 166 */     this.inputEOM = false;
/* 167 */     this.expectingNewInput = true;
/* 168 */     this.expectingNewOutput = true;
/* 169 */     this.resetInProgress = true;
/* 170 */     this.resetTime = true;
/* 171 */     this.sequenceHeader = null;
/* 172 */     this.frameWidth = 0;
/* 173 */     this.frameHeight = 0;
/* 174 */     this.mpegHeader[0] = 0;
/* 175 */     this.mpegHeader[1] = 0;
/* 176 */     this.mpegHeader[2] = 0;
/* 177 */     this.mpegHeader[3] = 0;
/* 178 */     this.gopTime = 1L;
/* 179 */     this.frameTime = 0L;
/* 180 */     this.frameCount = 0L;
/* 181 */     if (debug) {
/* 182 */       System.err.println("Packetizer(V): reset completed");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized int process(Buffer inBuffer, Buffer outBuffer) {
/* 188 */     if (this.outputQueue.size() > 0) {
/* 189 */       Buffer qbuf = this.outputQueue.firstElement();
/* 190 */       this.outputQueue.removeElementAt(0);
/*     */       
/* 192 */       outBuffer.setData(qbuf.getData());
/* 193 */       outBuffer.setOffset(qbuf.getOffset());
/* 194 */       outBuffer.setLength(qbuf.getLength());
/* 195 */       outBuffer.setFlags(qbuf.getFlags());
/* 196 */       outBuffer.setTimeStamp(qbuf.getTimeStamp());
/* 197 */       outBuffer.setSequenceNumber(this.sequenceNumber++);
/* 198 */       outBuffer.setFormat((Format)this.outputFormat);
/* 199 */       this.expectingNewOutput = true;
/* 200 */       return 2;
/*     */     } 
/* 202 */     if (isEOM(inBuffer)) {
/* 203 */       this.inputEOM = true;
/* 204 */       if (this.segmentQueue.isEmpty()) {
/* 205 */         propagateEOM(outBuffer);
/* 206 */         outBuffer.setSequenceNumber(this.sequenceNumber++);
/* 207 */         return 0;
/*     */       } 
/*     */     } 
/* 210 */     if (inBuffer.isDiscard()) {
/* 211 */       updateOutput(outBuffer, (Format)this.outputFormat, 0, 0);
/* 212 */       outBuffer.setDiscard(true);
/* 213 */       return 4;
/*     */     } 
/*     */     
/* 216 */     int retVal = 1;
/*     */     try {
/* 218 */       retVal = doProcess(inBuffer, outBuffer);
/*     */     } catch (Exception ex) {
/* 220 */       ex.printStackTrace();
/* 221 */       return 1;
/*     */     } 
/*     */ 
/*     */     
/* 225 */     if (this.outputFormat == null) {
/* 226 */       this.outputFormat = makeMPEGFormat(inBuffer.getFormat());
/*     */     }
/*     */     
/* 229 */     if (retVal != 4) {
/* 230 */       outBuffer.setSequenceNumber(this.sequenceNumber++);
/*     */     }
/* 232 */     return retVal;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 237 */     return "MPEG Video Packetizer";
/*     */   }
/*     */   
/*     */   public void finalize() {
/* 241 */     close();
/*     */   }
/*     */   
/*     */   private int doProcess(Buffer inBuffer, Buffer outBuffer) {
/* 245 */     if (this.expectingNewInput) {
/* 246 */       if (!this.inputEOM) {
/* 247 */         if (inBuffer.getData() == null) {
/* 248 */           return 4;
/*     */         }
/* 250 */         if (this.resetTime) {
/*     */           
/* 252 */           this.startTime = inBuffer.getTimeStamp();
/* 253 */           if (debug) {
/* 254 */             System.err.println("Packetizer(V): new synctime set: " + this.startTime);
/*     */           }
/*     */           
/* 257 */           if (this.startTime == 0L)
/* 258 */             this.startTime = 1L; 
/* 259 */           this.resetTime = false;
/*     */         } 
/* 261 */         this.inputQueue.addElement(copyInto(inBuffer));
/*     */       } 
/* 263 */       this.expectingNewInput = false;
/*     */     } 
/*     */     
/* 266 */     if (this.expectingNewOutput) {
/* 267 */       byte[] outData = (byte[])outBuffer.getData();
/* 268 */       if (outData == null || outData.length < PACKET_MAX) {
/* 269 */         outData = new byte[PACKET_MAX];
/* 270 */         outBuffer.setData(outData);
/*     */       } 
/* 272 */       System.arraycopy(this.mpegHeader, 0, outData, 0, 4);
/* 273 */       outBuffer.setOffset(0);
/* 274 */       outBuffer.setLength(4);
/* 275 */       outBuffer.setFlags(0);
/* 276 */       outBuffer.setHeader(null);
/* 277 */       outBuffer.setFormat((Format)this.outputFormat);
/* 278 */       this.expectingNewOutput = false;
/*     */     } 
/*     */     
/* 281 */     if (this.segmentQueue.isEmpty()) {
/* 282 */       findFirstStartCode();
/* 283 */       if (this.segmentQueue.isEmpty()) {
/* 284 */         this.expectingNewInput = true;
/* 285 */         return 4;
/*     */       } 
/*     */     } 
/* 288 */     MPEGSegment mseg = this.segmentQueue.firstElement();
/* 289 */     while (mseg != null) {
/* 290 */       if (mseg.getLength() < 0) {
/*     */         
/* 292 */         this.expectingNewInput = true;
/* 293 */         return 4;
/*     */       } 
/* 295 */       int startCode = mseg.startCode;
/* 296 */       int res = 0;
/* 297 */       if (startCode == 179) {
/* 298 */         res = doSequenceHeader(mseg, outBuffer);
/* 299 */       } else if (startCode == 183) {
/* 300 */         res = doSequenceEnd(mseg, outBuffer);
/* 301 */       } else if (startCode == 184) {
/* 302 */         res = doGOP(mseg, outBuffer);
/* 303 */       } else if (startCode == 0) {
/* 304 */         res = doPicture(mseg, outBuffer);
/* 305 */       } else if (startCode >= 1 && startCode <= 175) {
/* 306 */         res = doSlice(mseg, outBuffer);
/*     */       } else {
/*     */         
/* 309 */         res = SEGMENT_DONE;
/*     */       } 
/* 311 */       if (res == SEGMENT_DONE) {
/* 312 */         this.segmentQueue.removeElementAt(0);
/* 313 */         if (this.segmentQueue.isEmpty()) {
/* 314 */           this.expectingNewInput = true;
/* 315 */           if (outBuffer.getLength() > 4) {
/* 316 */             return 0;
/*     */           }
/* 318 */           return 4;
/*     */         } 
/*     */         
/* 321 */         mseg = this.segmentQueue.firstElement();
/*     */         continue;
/*     */       } 
/* 324 */       if (res == SEGMENT_DONE_BUFFER_FULL) {
/* 325 */         this.segmentQueue.removeElementAt(0);
/*     */         
/* 327 */         outBuffer.setFlags(outBuffer.getFlags() | 0x20);
/* 328 */         if (this.expectingNewInput) {
/* 329 */           return 0;
/*     */         }
/* 331 */         return 2;
/*     */       } 
/* 333 */       if (res == SEGMENT_REPEAT) {
/*     */         
/* 335 */         outBuffer.setFlags(outBuffer.getFlags() | 0x20);
/* 336 */         if (this.expectingNewInput) {
/* 337 */           return 0;
/*     */         }
/* 339 */         return 2;
/*     */       } 
/*     */     } 
/* 342 */     return 1;
/*     */   }
/*     */   
/*     */   private Buffer copyInto(Buffer src) {
/* 346 */     Buffer dest = new Buffer();
/* 347 */     dest.copy(src);
/* 348 */     dest.setFlags(dest.getFlags() | 0x20);
/* 349 */     src.setData(null);
/* 350 */     src.setHeader(null);
/* 351 */     src.setLength(0);
/* 352 */     src.setOffset(0);
/* 353 */     return dest;
/*     */   }
/*     */   
/*     */   protected String toHex(byte[] inData, int inOffset) {
/* 357 */     String hex = new String();
/* 358 */     for (int i = 0; i < 4; i++) {
/* 359 */       hex = hex + hexChar[inData[inOffset + i] >> 4 & 0xF];
/* 360 */       hex = hex + hexChar[inData[inOffset + i] & 0xF];
/*     */     } 
/* 362 */     return hex;
/*     */   }
/*     */   
/*     */   private int doSequenceHeader(MPEGSegment sh, Buffer outBuffer) {
/* 366 */     this.sequenceHeader = new byte[sh.getLength()];
/* 367 */     sh.copyData(this.sequenceHeader, 0);
/* 368 */     this.frameWidth = (this.sequenceHeader[4] & 0xFF) << 4 | (this.sequenceHeader[5] & 0xF0) >> 4;
/*     */     
/* 370 */     this.frameHeight = (this.sequenceHeader[5] & 0xF) << 8 | this.sequenceHeader[6] & 0xFF;
/*     */     
/* 372 */     int frix = this.sequenceHeader[7] & 0xF;
/* 373 */     if (frix > 0 && frix <= 8)
/* 374 */       this.frameRate = RATE_TABLE[frix]; 
/* 375 */     this.picNanos = (long)(1.0E9D / this.frameRate);
/*     */ 
/*     */ 
/*     */     
/* 379 */     return SEGMENT_DONE;
/*     */   }
/*     */   
/*     */   private int copySequenceHeader(Buffer outBuffer) {
/* 383 */     if (this.sequenceHeader == null)
/* 384 */       return 0; 
/* 385 */     System.arraycopy(this.sequenceHeader, 0, outBuffer.getData(), outBuffer.getLength(), this.sequenceHeader.length);
/*     */ 
/*     */ 
/*     */     
/* 389 */     outBuffer.setLength(outBuffer.getLength() + this.sequenceHeader.length);
/* 390 */     return this.sequenceHeader.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int doSequenceEnd(MPEGSegment se, Buffer outBuffer) {
/* 396 */     return SEGMENT_DONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int doGOP(MPEGSegment gop, Buffer outBuffer) {
/* 414 */     if (this.frameCount == 0L) {
/* 415 */       this.gopTime = 1L + this.startTime;
/*     */     } else {
/* 417 */       this.gopTime = this.frameCount * this.picNanos + this.startTime;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 422 */     copySequenceHeader(outBuffer);
/* 423 */     gop.copyData((byte[])outBuffer.getData(), outBuffer.getLength());
/* 424 */     outBuffer.setLength(outBuffer.getLength() + gop.getLength());
/* 425 */     return SEGMENT_DONE;
/*     */   }
/*     */   
/*     */   private int doPicture(MPEGSegment ph, Buffer outBuffer) {
/* 429 */     byte[] pic = new byte[ph.getLength()];
/* 430 */     ph.copyData(pic, 0);
/* 431 */     int cnt = (pic[4] & 0xFF) << 2 | (pic[5] & 0xC0) >> 6;
/* 432 */     int type = (pic[5] & 0x38) >> 3;
/* 433 */     this.mpegHeader[0] = (byte)(cnt >> 8 & 0x2);
/* 434 */     this.mpegHeader[1] = (byte)cnt;
/* 435 */     this.mpegHeader[2] = (byte)type;
/* 436 */     if (type == 1) {
/* 437 */       this.mpegHeader[3] = 0;
/*     */     } else {
/* 439 */       int next = (pic[7] & 0x7) << 1 | (pic[8] & 0x80) >> 7;
/* 440 */       if (type > 2)
/* 441 */         next |= (pic[8] & 0x78) << 1; 
/* 442 */       this.mpegHeader[3] = (byte)next;
/*     */     } 
/* 444 */     this.resetInProgress = false;
/* 445 */     byte[] outData = (byte[])outBuffer.getData();
/* 446 */     System.arraycopy(this.mpegHeader, 0, outData, 0, 4);
/*     */ 
/*     */ 
/*     */     
/* 450 */     if (outBuffer.getLength() > 8 && outData[4] == 0 && outData[5] == 0 && outData[6] == 1 && (outData[7] & 0xFF) == 179)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 455 */       outData[2] = (byte)(outData[2] | 0x20);
/*     */     }
/*     */     
/* 458 */     ph.copyData((byte[])outBuffer.getData(), outBuffer.getLength());
/* 459 */     outBuffer.setLength(outBuffer.getLength() + ph.getLength());
/* 460 */     outBuffer.setFlags(outBuffer.getFlags() | 0x10);
/* 461 */     this.frameCount++;
/* 462 */     this.frameTime = this.gopTime + cnt * this.picNanos;
/* 463 */     outBuffer.setTimeStamp(this.frameTime);
/* 464 */     outBuffer.setFormat((Format)this.outputFormat);
/* 465 */     return SEGMENT_DONE;
/*     */   }
/*     */   
/*     */   private int doSlice(MPEGSegment slice, Buffer outBuffer) {
/* 469 */     byte[] outData = (byte[])outBuffer.getData();
/* 470 */     if (slice.getLength() < PACKET_MAX - outBuffer.getLength()) {
/* 471 */       slice.copyData(outData, outBuffer.getLength());
/* 472 */       outBuffer.setLength(outBuffer.getLength() + slice.getLength());
/* 473 */       outBuffer.setTimeStamp(this.frameTime);
/* 474 */       outBuffer.setFormat((Format)this.outputFormat);
/* 475 */       outData[2] = (byte)(outData[2] | 0x18);
/* 476 */       if (this.segmentQueue.size() > 1) {
/* 477 */         MPEGSegment mse = this.segmentQueue.elementAt(1);
/* 478 */         if (mse.startCode < 1 || mse.startCode > 175) {
/* 479 */           outBuffer.setFlags(outBuffer.getFlags() | 0x800);
/*     */           
/* 481 */           this.expectingNewOutput = true;
/* 482 */           return SEGMENT_DONE_BUFFER_FULL;
/*     */         } 
/* 484 */       } else if (this.inputEOM) {
/* 485 */         outBuffer.setFlags(outBuffer.getFlags() | 0x800);
/*     */         
/* 487 */         this.expectingNewOutput = true;
/* 488 */         return SEGMENT_DONE_BUFFER_FULL;
/*     */       } 
/* 490 */       return SEGMENT_DONE;
/*     */     } 
/* 492 */     if ((outData[2] & 0x18) != 0) {
/*     */ 
/*     */       
/* 495 */       this.expectingNewOutput = true;
/* 496 */       return SEGMENT_REPEAT;
/*     */     } 
/* 498 */     int len = PACKET_MAX - outBuffer.getLength();
/* 499 */     slice.copyData(0, len, outData, outBuffer.getLength());
/* 500 */     outBuffer.setLength(outBuffer.getLength() + len);
/* 501 */     outBuffer.setTimeStamp(this.frameTime);
/* 502 */     outBuffer.setFormat((Format)this.outputFormat);
/* 503 */     outData[2] = (byte)(outData[2] | 0x10);
/* 504 */     int off = len;
/* 505 */     len = slice.getLength() - len;
/*     */     
/* 507 */     Buffer b = null;
/*     */     
/* 509 */     while (len > 0) {
/* 510 */       b = new Buffer();
/* 511 */       outData = new byte[PACKET_MAX];
/* 512 */       b.setData(outData);
/* 513 */       b.setTimeStamp(this.frameTime);
/* 514 */       b.setHeader(null);
/* 515 */       b.setFormat((Format)this.outputFormat);
/* 516 */       b.setFlags(outBuffer.getFlags());
/* 517 */       b.setOffset(0);
/* 518 */       System.arraycopy(this.mpegHeader, 0, outData, 0, 4);
/* 519 */       int l = len;
/* 520 */       if (len > PACKET_MAX - 4)
/* 521 */         l = PACKET_MAX - 4; 
/* 522 */       slice.copyData(off, l, (byte[])b.getData(), 4);
/* 523 */       b.setLength(l + 4);
/* 524 */       off += l;
/* 525 */       len -= l;
/* 526 */       if (len <= 0)
/* 527 */         outData[2] = (byte)(outData[2] | 0x8); 
/* 528 */       this.outputQueue.addElement(b);
/*     */     } 
/* 530 */     if (this.segmentQueue.size() > 1) {
/* 531 */       MPEGSegment mse = this.segmentQueue.elementAt(1);
/* 532 */       if (mse.startCode < 1 || mse.startCode > 175) {
/* 533 */         b.setFlags(b.getFlags() | 0x800);
/* 534 */         this.expectingNewOutput = true;
/* 535 */         return SEGMENT_DONE_BUFFER_FULL;
/*     */       } 
/* 537 */     } else if (this.inputEOM) {
/* 538 */       b.setFlags(b.getFlags() | 0x800);
/* 539 */       this.expectingNewOutput = true;
/* 540 */       return SEGMENT_DONE_BUFFER_FULL;
/*     */     } 
/* 542 */     this.expectingNewOutput = true;
/* 543 */     return SEGMENT_DONE_BUFFER_FULL;
/*     */   }
/*     */ 
/*     */   
/*     */   private void findFirstStartCode() {
/* 548 */     if (this.inputQueue.isEmpty())
/*     */       return; 
/* 550 */     Buffer inBuffer = this.inputQueue.firstElement();
/*     */     
/* 552 */     this.inputQueue.removeElementAt(0);
/* 553 */     byte[] inData = (byte[])inBuffer.getData();
/* 554 */     int off = inBuffer.getOffset();
/* 555 */     int len = inBuffer.getLength();
/* 556 */     while (len > 4) {
/* 557 */       if (inData[off] == 0 && inData[off + 1] == 0 && inData[off + 2] == 1)
/*     */       {
/* 559 */         if ((inData[off + 3] & 0xFF) != 181 && (inData[off + 3] & 0xFF) != 178)
/*     */         {
/* 561 */           if (this.resetInProgress) {
/*     */             
/* 563 */             if ((inData[off + 3] & 0xFF) == 179 || (inData[off + 3] & 0xFF) == 184) {
/*     */               
/* 565 */               MPEGSegment ns = new MPEGSegment(this, inData[off + 3] & 0xFF, off, inBuffer);
/*     */ 
/*     */               
/* 568 */               this.segmentQueue.addElement(ns);
/*     */               return;
/*     */             } 
/*     */           } else {
/* 572 */             MPEGSegment ns = new MPEGSegment(this, inData[off + 3] & 0xFF, off, inBuffer);
/*     */             
/* 574 */             this.segmentQueue.addElement(ns);
/*     */             return;
/*     */           } 
/*     */         }
/*     */       }
/* 579 */       off++;
/* 580 */       len--;
/*     */     } 
/*     */     
/* 583 */     this.expectingNewInput = true;
/*     */   }
/*     */ 
/*     */   
/*     */   class MPEGSegment
/*     */   {
/*     */     int startCode;
/*     */     
/*     */     int offset;
/*     */     
/*     */     int length;
/*     */     
/*     */     Buffer startBuffer;
/*     */     Buffer endBuffer;
/*     */     private final Packetizer this$0;
/*     */     
/*     */     MPEGSegment(Packetizer this$0, int code, int off, Buffer buf) {
/* 600 */       this.this$0 = this$0; this.startCode = -1; this.offset = -1; this.length = -1; this.startBuffer = null; this.endBuffer = null;
/* 601 */       this.startCode = code;
/* 602 */       this.offset = off;
/* 603 */       this.startBuffer = buf;
/*     */     }
/*     */ 
/*     */     
/*     */     void copyData(byte[] dest, int outoffset) {
/* 608 */       copyData(0, this.length, dest, outoffset);
/*     */     }
/*     */ 
/*     */     
/*     */     void copyData(int off, byte[] dest, int outoffset) {
/* 613 */       copyData(off, this.length - off, dest, outoffset);
/*     */     }
/*     */ 
/*     */     
/*     */     void copyData(int off, int len, byte[] dest, int outoffset) {
/* 618 */       if (off + len > this.length) {
/* 619 */         len = this.length - off;
/*     */       }
/* 621 */       if (this.endBuffer == null) {
/*     */         
/* 623 */         System.arraycopy(this.startBuffer.getData(), this.offset + off, dest, outoffset, len);
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 629 */       int len1 = this.startBuffer.getLength() - this.offset - this.startBuffer.getOffset();
/*     */       
/* 631 */       int len2 = this.length - len1;
/* 632 */       if (off + len <= len1) {
/*     */         
/* 634 */         System.arraycopy(this.startBuffer.getData(), this.offset + off, dest, outoffset, len);
/*     */         
/*     */         return;
/*     */       } 
/* 638 */       if (off >= len1) {
/*     */         
/* 640 */         off -= len1;
/* 641 */         System.arraycopy(this.endBuffer.getData(), this.endBuffer.getOffset() + off, dest, outoffset, len);
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 647 */       int l = len1 - off;
/* 648 */       System.arraycopy(this.startBuffer.getData(), this.offset + off, dest, outoffset, l);
/*     */       
/* 650 */       len -= l;
/* 651 */       System.arraycopy(this.endBuffer.getData(), this.endBuffer.getOffset(), dest, outoffset + l, len);
/*     */     }
/*     */ 
/*     */     
/*     */     int getLength() {
/* 656 */       if (this.length < 0)
/* 657 */         calculateLength(); 
/* 658 */       return this.length;
/*     */     }
/*     */     
/*     */     private void calculateLength() {
/* 662 */       if (this.length > 0)
/*     */         return; 
/* 664 */       int off = findNextStart();
/* 665 */       if (off > this.offset) {
/* 666 */         this.length = off - this.offset;
/*     */         return;
/*     */       } 
/* 669 */       if (this.this$0.inputEOM) {
/*     */         
/* 671 */         this.length = this.startBuffer.getLength() - this.offset - this.startBuffer.getOffset();
/*     */         
/*     */         return;
/*     */       } 
/* 675 */       if (this.endBuffer == null) {
/* 676 */         if (this.this$0.inputQueue.isEmpty())
/*     */           return; 
/* 678 */         this.endBuffer = this.this$0.inputQueue.firstElement();
/* 679 */         this.this$0.inputQueue.removeElementAt(0);
/*     */       } 
/*     */       
/* 682 */       off = findNextStartBetweenBuffers();
/* 683 */       if (off > this.offset) {
/* 684 */         this.length = off - this.offset;
/*     */         return;
/*     */       } 
/* 687 */       off = findNextStartInEndBuffer();
/* 688 */       this.length = this.startBuffer.getLength() - this.offset - this.startBuffer.getOffset();
/*     */       
/* 690 */       this.length += off - this.endBuffer.getOffset();
/*     */     }
/*     */     
/*     */     private int findNextStart() {
/* 694 */       byte[] inData = (byte[])this.startBuffer.getData();
/* 695 */       int off = this.offset + 4;
/* 696 */       int len = this.startBuffer.getLength() - this.offset + 4 - this.startBuffer.getOffset();
/*     */       
/* 698 */       while (len > 3) {
/* 699 */         if (inData[off] == 0 && inData[off + 1] == 0 && inData[off + 2] == 1)
/*     */         {
/*     */ 
/*     */           
/* 703 */           if ((inData[off + 3] & 0xFF) != 181 && (inData[off + 3] & 0xFF) != 178) {
/*     */             
/* 705 */             MPEGSegment ns = new MPEGSegment(this.this$0, inData[off + 3] & 0xFF, off, this.startBuffer);
/*     */             
/* 707 */             this.this$0.segmentQueue.addElement(ns);
/* 708 */             return off;
/*     */           } 
/*     */         }
/* 711 */         off++;
/* 712 */         len--;
/*     */       } 
/* 714 */       return -1;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private int findNextStartBetweenBuffers() {
/* 720 */       byte[] inData = (byte[])this.startBuffer.getData();
/* 721 */       byte[] inData2 = (byte[])this.endBuffer.getData();
/* 722 */       int off = this.startBuffer.getOffset() + this.startBuffer.getLength() - 3;
/* 723 */       if (off <= this.offset)
/* 724 */         return -1; 
/* 725 */       int off2 = this.endBuffer.getOffset();
/* 726 */       if (inData[off] == 0 && inData[off + 1] == 0 && inData[off + 2] == 1)
/*     */       {
/* 728 */         if ((inData2[off2] & 0xFF) != 181 && (inData[off2] & 0xFF) != 178) {
/*     */           
/* 730 */           MPEGSegment ns = new MPEGSegment(this.this$0, inData2[off2] & 0xFF, off, this.startBuffer);
/*     */           
/* 732 */           ns.endBuffer = this.endBuffer;
/* 733 */           this.this$0.segmentQueue.addElement(ns);
/* 734 */           this.endBuffer = null;
/* 735 */           return off;
/*     */         } 
/*     */       }
/* 738 */       if (inData[off + 1] == 0 && inData[off + 2] == 0 && inData2[off2] == 1)
/*     */       {
/*     */         
/* 741 */         if ((inData2[off2 + 1] & 0xFF) != 181 && (inData[off2 + 1] & 0xFF) != 178) {
/*     */           
/* 743 */           MPEGSegment ns = new MPEGSegment(this.this$0, inData2[off2 + 1] & 0xFF, off + 1, this.startBuffer);
/*     */           
/* 745 */           ns.endBuffer = this.endBuffer;
/* 746 */           this.this$0.segmentQueue.addElement(ns);
/* 747 */           this.endBuffer = null;
/* 748 */           return off + 1;
/*     */         } 
/*     */       }
/* 751 */       if (inData[off + 2] == 0 && inData2[off2] == 0 && inData2[off2 + 1] == 1)
/*     */       {
/*     */         
/* 754 */         if ((inData2[off2 + 2] & 0xFF) != 181 && (inData[off2 + 2] & 0xFF) != 178) {
/*     */           
/* 756 */           MPEGSegment ns = new MPEGSegment(this.this$0, inData2[off2 + 2] & 0xFF, off + 2, this.startBuffer);
/*     */           
/* 758 */           ns.endBuffer = this.endBuffer;
/* 759 */           this.this$0.segmentQueue.addElement(ns);
/* 760 */           this.endBuffer = null;
/* 761 */           return off + 2;
/*     */         } 
/*     */       }
/* 764 */       return -1;
/*     */     }
/*     */     
/*     */     private int findNextStartInEndBuffer() {
/* 768 */       byte[] inData = (byte[])this.endBuffer.getData();
/* 769 */       int off = this.endBuffer.getOffset();
/* 770 */       int len = this.endBuffer.getLength();
/* 771 */       while (len > 3) {
/* 772 */         if (inData[off] == 0 && inData[off + 1] == 0 && inData[off + 2] == 1)
/*     */         {
/*     */ 
/*     */           
/* 776 */           if ((inData[off + 3] & 0xFF) != 181 && (inData[off + 3] & 0xFF) != 178) {
/*     */             
/* 778 */             MPEGSegment ns = new MPEGSegment(this.this$0, inData[off + 3] & 0xFF, off, this.endBuffer);
/*     */             
/* 780 */             this.this$0.segmentQueue.addElement(ns);
/* 781 */             return off;
/*     */           } 
/*     */         }
/* 784 */         off++;
/* 785 */         len--;
/*     */       } 
/* 787 */       return -1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\codec\video\mpeg\Packetizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */