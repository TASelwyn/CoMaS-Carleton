/*     */ package com.sun.media.codec.video.colorspace;
/*     */ 
/*     */ import com.sun.media.BasicCodec;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.control.FrameProcessingControl;
/*     */ import javax.media.format.RGBFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ import javax.media.format.YUVFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaRGBToYUV
/*     */   extends BasicCodec
/*     */ {
/*     */   private static final String PLUGIN_NAME = "RGB To YUV";
/*  25 */   private FrameProcessingControl frameControl = null;
/*     */   private boolean dropFrame = false;
/*     */   
/*     */   public JavaRGBToYUV() {
/*  29 */     int NS = -1;
/*     */     
/*  31 */     this.inputFormats = new Format[] { (Format)new RGBFormat(null, NS, Format.byteArray, NS, 24, NS, NS, NS, NS, NS, NS, NS), (Format)new RGBFormat(null, NS, Format.intArray, NS, 32, 16711680, 65280, 255, 1, NS, NS, NS), (Format)new RGBFormat(null, NS, Format.intArray, NS, 32, 255, 65280, 16711680, 1, NS, NS, NS) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  43 */     this.outputFormats = new Format[] { (Format)new YUVFormat(2) };
/*     */ 
/*     */ 
/*     */     
/*  47 */     if (this.frameControl == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  72 */       this.frameControl = new JavaRGBToYUV$1$FPC(this);
/*  73 */       ((BasicPlugIn)this).controls = (Object[])new javax.media.Control[1];
/*  74 */       ((BasicPlugIn)this).controls[0] = this.frameControl;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  80 */     return "RGB To YUV";
/*     */   }
/*     */ 
/*     */   
/*     */   public Format[] getSupportedOutputFormats(Format input) {
/*  85 */     if (input == null)
/*  86 */       return this.outputFormats; 
/*  87 */     if (input instanceof RGBFormat && BasicPlugIn.matches(input, this.inputFormats) != null) {
/*     */       
/*  89 */       RGBFormat rgb = (RGBFormat)input;
/*  90 */       Dimension size = rgb.getSize();
/*  91 */       float frameRate = rgb.getFrameRate();
/*  92 */       int bpp = rgb.getBitsPerPixel();
/*  93 */       int scan = size.width + 1 & 0xFFFFFFFE;
/*     */       
/*  95 */       YUVFormat output = new YUVFormat(size, scan * size.height * 3 / 2, Format.byteArray, frameRate, 2, scan, scan / 2, 0, scan * size.height, scan * size.height * 5 / 4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 104 */       Format[] outputs = { (Format)output };
/* 105 */       return outputs;
/*     */     } 
/* 107 */     return new Format[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public Format setInputFormat(Format input) {
/* 112 */     Format ret = super.setInputFormat(input);
/* 113 */     if (this.opened) {
/* 114 */       this.outputFormat = getSupportedOutputFormats(ret)[0];
/*     */     }
/* 116 */     return ret;
/*     */   }
/*     */   
/*     */   public int process(Buffer inBuffer, Buffer outBuffer) {
/* 120 */     if (isEOM(inBuffer)) {
/* 121 */       propagateEOM(outBuffer);
/* 122 */       return 0;
/*     */     } 
/*     */     
/* 125 */     if (this.dropFrame) {
/* 126 */       outBuffer.setFlags(outBuffer.getFlags() | 0x2);
/* 127 */       return 0;
/*     */     } 
/*     */     
/* 130 */     Format inF = inBuffer.getFormat();
/*     */     
/* 132 */     if (!(inF instanceof RGBFormat) || inBuffer.getData() == null)
/*     */     {
/* 134 */       return 1;
/*     */     }
/* 136 */     Object inData = inBuffer.getData();
/* 137 */     validateByteArraySize(outBuffer, ((VideoFormat)this.outputFormat).getMaxDataLength());
/*     */ 
/*     */     
/* 140 */     outBuffer.setFormat(this.outputFormat);
/* 141 */     outBuffer.setLength(((VideoFormat)this.outputFormat).getMaxDataLength());
/* 142 */     if (((RGBFormat)inF).getBitsPerPixel() == 24) {
/* 143 */       return convert24(inBuffer, outBuffer);
/*     */     }
/* 145 */     return convertInt(inBuffer, outBuffer);
/*     */   }
/*     */   
/*     */   protected int convert24(Buffer inBuffer, Buffer outBuffer) {
/* 149 */     RGBFormat rgb = (RGBFormat)inBuffer.getFormat();
/* 150 */     YUVFormat yuv = (YUVFormat)outBuffer.getFormat();
/* 151 */     Dimension size = rgb.getSize();
/* 152 */     byte[] outData = (byte[])outBuffer.getData();
/* 153 */     byte[] inData = (byte[])inBuffer.getData();
/* 154 */     boolean flipped = (rgb.getFlipped() == 1);
/* 155 */     int increment = flipped ? -1 : 1;
/* 156 */     int ystride = yuv.getStrideY();
/* 157 */     int uvstride = yuv.getStrideUV();
/* 158 */     int pointerY = yuv.getOffsetY() + ystride * (flipped ? (size.height - 1) : 0);
/*     */     
/* 160 */     int pointerU = yuv.getOffsetU() + uvstride * (flipped ? (size.height / 2 - 1) : 0);
/*     */     
/* 162 */     int pointerV = yuv.getOffsetV() + uvstride * (flipped ? (size.height / 2 - 1) : 0);
/*     */     
/* 164 */     int pRGB = 0;
/* 165 */     int rgbscan = rgb.getLineStride();
/* 166 */     int pixstride = rgb.getPixelStride();
/* 167 */     int rOffset = rgb.getRedMask() - 1;
/* 168 */     int gOffset = rgb.getGreenMask() - 1;
/* 169 */     int bOffset = rgb.getBlueMask() - 1;
/*     */ 
/*     */ 
/*     */     
/* 173 */     for (int y = 0; y < size.height; y += 2) {
/* 174 */       for (int x = 0; x < size.width; x += 2) {
/*     */         
/* 176 */         int rval = inData[pRGB + rOffset] & 0xFF;
/* 177 */         int gval = inData[pRGB + gOffset] & 0xFF;
/* 178 */         int bval = inData[pRGB + bOffset] & 0xFF;
/* 179 */         int yval = (rval * 257 + gval * 504 + bval * 98) / 1000 + 16;
/* 180 */         int uval = (-rval * 148 - gval * 291 + bval * 439) / 1000 + 128;
/* 181 */         int vval = (rval * 439 - gval * 368 - bval * 71) / 1000 + 128;
/*     */         
/* 183 */         outData[pointerY] = (byte)(yval & 0xFF);
/*     */ 
/*     */         
/* 186 */         rval = inData[pRGB + rOffset + pixstride] & 0xFF;
/* 187 */         gval = inData[pRGB + gOffset + pixstride] & 0xFF;
/* 188 */         bval = inData[pRGB + bOffset + pixstride] & 0xFF;
/* 189 */         yval = (rval * 257 + gval * 504 + bval * 98) / 1000 + 16;
/* 190 */         uval += (-rval * 148 - gval * 291 + bval * 439) / 1000 + 128;
/* 191 */         vval += (rval * 439 - gval * 368 - bval * 71) / 1000 + 128;
/*     */         
/* 193 */         outData[pointerY + 1] = (byte)(yval & 0xFF);
/*     */ 
/*     */         
/* 196 */         rval = inData[pRGB + rOffset + rgbscan] & 0xFF;
/* 197 */         gval = inData[pRGB + gOffset + rgbscan] & 0xFF;
/* 198 */         bval = inData[pRGB + bOffset + rgbscan] & 0xFF;
/* 199 */         yval = (rval * 257 + gval * 504 + bval * 98) / 1000 + 16;
/* 200 */         uval += (-rval * 148 - gval * 291 + bval * 439) / 1000 + 128;
/* 201 */         vval += (rval * 439 - gval * 368 - bval * 71) / 1000 + 128;
/*     */         
/* 203 */         outData[pointerY + increment * ystride] = (byte)(yval & 0xFF);
/*     */ 
/*     */         
/* 206 */         rval = inData[pRGB + rOffset + rgbscan + pixstride] & 0xFF;
/* 207 */         gval = inData[pRGB + gOffset + rgbscan + pixstride] & 0xFF;
/* 208 */         bval = inData[pRGB + bOffset + rgbscan + pixstride] & 0xFF;
/* 209 */         yval = (rval * 257 + gval * 504 + bval * 98) / 1000 + 16;
/* 210 */         uval += (-rval * 148 - gval * 291 + bval * 439) / 1000 + 128;
/* 211 */         vval += (rval * 439 - gval * 368 - bval * 71) / 1000 + 128;
/*     */         
/* 213 */         outData[pointerY + increment * ystride + 1] = (byte)(yval & 0xFF);
/* 214 */         outData[pointerU] = (byte)(uval >> 2 & 0xFF);
/* 215 */         outData[pointerV] = (byte)(vval >> 2 & 0xFF);
/* 216 */         pointerY += 2;
/* 217 */         pointerU++;
/* 218 */         pointerV++;
/* 219 */         pRGB += pixstride * 2;
/*     */       } 
/* 221 */       pRGB += rgbscan * 2 - size.width * pixstride;
/* 222 */       pointerY += increment * ystride * 2 - size.width;
/* 223 */       pointerU += increment * uvstride - size.width / 2;
/* 224 */       pointerV += increment * uvstride - size.width / 2;
/*     */     } 
/* 226 */     return 0;
/*     */   }
/*     */   
/*     */   protected int convertInt(Buffer inBuffer, Buffer outBuffer) {
/* 230 */     RGBFormat rgb = (RGBFormat)inBuffer.getFormat();
/* 231 */     YUVFormat yuv = (YUVFormat)outBuffer.getFormat();
/* 232 */     Dimension size = rgb.getSize();
/* 233 */     byte[] outData = (byte[])outBuffer.getData();
/* 234 */     int[] inData = (int[])inBuffer.getData();
/* 235 */     boolean flipped = (rgb.getFlipped() == 1);
/* 236 */     int increment = flipped ? -1 : 1;
/* 237 */     int ystride = yuv.getStrideY();
/* 238 */     int uvstride = yuv.getStrideUV();
/* 239 */     int pointerY = yuv.getOffsetY() + ystride * (flipped ? (size.height - 1) : 0);
/*     */     
/* 241 */     int pointerU = yuv.getOffsetU() + uvstride * (flipped ? (size.height / 2 - 1) : 0);
/*     */     
/* 243 */     int pointerV = yuv.getOffsetV() + uvstride * (flipped ? (size.height / 2 - 1) : 0);
/*     */     
/* 245 */     int pRGB = 0;
/* 246 */     int rgbscan = rgb.getLineStride();
/* 247 */     int rOffset = 16;
/* 248 */     int gOffset = 8;
/* 249 */     int bOffset = 0;
/*     */ 
/*     */ 
/*     */     
/* 253 */     if (rgb.getRedMask() == 255) {
/* 254 */       rOffset = 0;
/* 255 */       bOffset = 16;
/*     */     } 
/*     */     
/* 258 */     for (int y = 0; y < size.height; y += 2) {
/* 259 */       for (int x = 0; x < size.width; x += 2) {
/*     */         
/* 261 */         int rval = inData[pRGB] >> rOffset & 0xFF;
/* 262 */         int gval = inData[pRGB] >> gOffset & 0xFF;
/* 263 */         int bval = inData[pRGB] >> bOffset & 0xFF;
/* 264 */         int yval = (rval * 257 + gval * 504 + bval * 98) / 1000 + 16;
/* 265 */         int uval = (-rval * 148 - gval * 291 + bval * 439) / 1000 + 128;
/* 266 */         int vval = (rval * 439 - gval * 368 - bval * 71) / 1000 + 128;
/*     */         
/* 268 */         outData[pointerY] = (byte)(yval & 0xFF);
/*     */ 
/*     */         
/* 271 */         rval = inData[pRGB + 1] >> rOffset & 0xFF;
/* 272 */         gval = inData[pRGB + 1] >> gOffset & 0xFF;
/* 273 */         bval = inData[pRGB + 1] >> bOffset & 0xFF;
/* 274 */         yval = (rval * 257 + gval * 504 + bval * 98) / 1000 + 16;
/* 275 */         uval += (-rval * 148 - gval * 291 + bval * 439) / 1000 + 128;
/* 276 */         vval += (rval * 439 - gval * 368 - bval * 71) / 1000 + 128;
/*     */         
/* 278 */         outData[pointerY + 1] = (byte)(yval & 0xFF);
/*     */ 
/*     */         
/* 281 */         rval = inData[pRGB + rgbscan] >> rOffset & 0xFF;
/* 282 */         gval = inData[pRGB + rgbscan] >> gOffset & 0xFF;
/* 283 */         bval = inData[pRGB + rgbscan] >> bOffset & 0xFF;
/* 284 */         yval = (rval * 257 + gval * 504 + bval * 98) / 1000 + 16;
/* 285 */         uval += (-rval * 148 - gval * 291 + bval * 439) / 1000 + 128;
/* 286 */         vval += (rval * 439 - gval * 368 - bval * 71) / 1000 + 128;
/*     */         
/* 288 */         outData[pointerY + increment * ystride] = (byte)(yval & 0xFF);
/*     */ 
/*     */         
/* 291 */         rval = inData[pRGB + rgbscan + 1] >> rOffset & 0xFF;
/* 292 */         gval = inData[pRGB + rgbscan + 1] >> gOffset & 0xFF;
/* 293 */         bval = inData[pRGB + rgbscan + 1] >> bOffset & 0xFF;
/* 294 */         yval = (rval * 257 + gval * 504 + bval * 98) / 1000 + 16;
/* 295 */         uval += (-rval * 148 - gval * 291 + bval * 439) / 1000 + 128;
/* 296 */         vval += (rval * 439 - gval * 368 - bval * 71) / 1000 + 128;
/*     */         
/* 298 */         outData[pointerY + increment * ystride + 1] = (byte)(yval & 0xFF);
/* 299 */         outData[pointerU] = (byte)(uval >> 2 & 0xFF);
/* 300 */         outData[pointerV] = (byte)(vval >> 2 & 0xFF);
/* 301 */         pointerY += 2;
/* 302 */         pointerU++;
/* 303 */         pointerV++;
/* 304 */         pRGB += 2;
/*     */       } 
/* 306 */       pRGB += rgbscan * 2 - size.width;
/* 307 */       pointerY += increment * ystride * 2 - size.width;
/* 308 */       pointerU += increment * uvstride - size.width / 2;
/* 309 */       pointerV += increment * uvstride - size.width / 2;
/*     */     } 
/* 311 */     return 0;
/*     */   }
/*     */   
/*     */   public void reset() {}
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\codec\video\colorspace\JavaRGBToYUV.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */