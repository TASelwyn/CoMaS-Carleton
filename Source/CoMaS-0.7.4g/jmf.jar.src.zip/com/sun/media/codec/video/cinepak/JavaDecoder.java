package com.sun.media.codec.video.cinepak;

import com.ibm.media.codec.video.VideoCodec;
import java.awt.Dimension;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.ResourceUnavailableException;
import javax.media.format.RGBFormat;
import javax.media.format.VideoFormat;

public class JavaDecoder extends VideoCodec {
  private static final int rMask = 255;
  
  private static final int gMask = 65280;
  
  private static final int bMask = 16711680;
  
  private int[] refData = null;
  
  private CineStore fOurStore;
  
  public JavaDecoder() {
    this.supportedInputFormats = new VideoFormat[] { new VideoFormat("cvid") };
    this.defaultOutputFormats = new VideoFormat[] { (VideoFormat)new RGBFormat(null, -1, Format.intArray, -1.0F, 32, 255, 65280, 16711680, 1, -1, 0, -1) };
    this.PLUGIN_NAME = "Cinepak Decoder";
  }
  
  protected Format[] getMatchingOutputFormats(Format in) {
    VideoFormat ivf = (VideoFormat)in;
    Dimension inSize = ivf.getSize();
    int lineStride = inSize.width + 3 & 0xFFFFFFFC;
    int rowStride = inSize.height + 3 & 0xFFFFFFFC;
    this.supportedOutputFormats = new VideoFormat[] { (VideoFormat)new RGBFormat(new Dimension(inSize), lineStride * rowStride, Format.intArray, ivf.getFrameRate(), 32, 255, 65280, 16711680) };
    return (Format[])this.supportedOutputFormats;
  }
  
  public void open() throws ResourceUnavailableException {
    initDecoder();
  }
  
  public void close() {
    this.fOurStore = null;
  }
  
  public void reset() {}
  
  protected void videoResized() {
    initDecoder();
  }
  
  protected void initDecoder() {
    this.fOurStore = new CineStore();
  }
  
  public int process(Buffer inputBuffer, Buffer outputBuffer) {
    if (!checkInputBuffer(inputBuffer))
      return 1; 
    if (isEOM(inputBuffer)) {
      propagateEOM(outputBuffer);
      return 0;
    } 
    VideoFormat ivf = (VideoFormat)inputBuffer.getFormat();
    int inLength = inputBuffer.getLength();
    int inMaxLength = ivf.getMaxDataLength();
    int outMaxLength = this.outputFormat.getMaxDataLength();
    byte[] inData = (byte[])inputBuffer.getData();
    int[] outData = validateIntArraySize(outputBuffer, outMaxLength);
    if (this.refData == null) {
      this.refData = outData;
      outputBuffer.setData(null);
      outData = validateIntArraySize(outputBuffer, outMaxLength);
    } 
    outputBuffer.setData(this.refData);
    outputBuffer.setFormat((Format)this.outputFormat);
    this.fOurStore.DoFrame(inputBuffer, outputBuffer, this.fOurStore);
    System.arraycopy(this.refData, 0, outData, 0, outMaxLength);
    outputBuffer.setData(outData);
    updateOutput(outputBuffer, (Format)this.outputFormat, outMaxLength, 0);
    return 0;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\codec\video\cinepak\JavaDecoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */