/*     */ package com.sun.media.codec.video.cinepak;
/*     */ 
/*     */ import com.ibm.media.codec.video.VideoCodec;
/*     */ import java.awt.Dimension;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.RGBFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaDecoder
/*     */   extends VideoCodec
/*     */ {
/*     */   private static final int rMask = 255;
/*     */   private static final int gMask = 65280;
/*     */   private static final int bMask = 16711680;
/*  31 */   private int[] refData = null;
/*     */ 
/*     */   
/*     */   private CineStore fOurStore;
/*     */ 
/*     */   
/*     */   public JavaDecoder() {
/*  38 */     this.supportedInputFormats = new VideoFormat[] { new VideoFormat("cvid") };
/*  39 */     this.defaultOutputFormats = new VideoFormat[] { (VideoFormat)new RGBFormat(null, -1, Format.intArray, -1.0F, 32, 255, 65280, 16711680, 1, -1, 0, -1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  49 */     this.PLUGIN_NAME = "Cinepak Decoder";
/*     */   }
/*     */ 
/*     */   
/*     */   protected Format[] getMatchingOutputFormats(Format in) {
/*  54 */     VideoFormat ivf = (VideoFormat)in;
/*  55 */     Dimension inSize = ivf.getSize();
/*  56 */     int lineStride = inSize.width + 3 & 0xFFFFFFFC;
/*  57 */     int rowStride = inSize.height + 3 & 0xFFFFFFFC;
/*     */     
/*  59 */     this.supportedOutputFormats = new VideoFormat[] { (VideoFormat)new RGBFormat(new Dimension(inSize), lineStride * rowStride, Format.intArray, ivf.getFrameRate(), 32, 255, 65280, 16711680) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  68 */     return (Format[])this.supportedOutputFormats;
/*     */   }
/*     */ 
/*     */   
/*     */   public void open() throws ResourceUnavailableException {
/*  73 */     initDecoder();
/*     */   }
/*     */   
/*     */   public void close() {
/*  77 */     this.fOurStore = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {}
/*     */ 
/*     */   
/*     */   protected void videoResized() {
/*  86 */     initDecoder();
/*     */   }
/*     */   
/*     */   protected void initDecoder() {
/*  90 */     this.fOurStore = new CineStore();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int process(Buffer inputBuffer, Buffer outputBuffer) {
/*  96 */     if (!checkInputBuffer(inputBuffer)) {
/*  97 */       return 1;
/*     */     }
/*     */     
/* 100 */     if (isEOM(inputBuffer)) {
/* 101 */       propagateEOM(outputBuffer);
/* 102 */       return 0;
/*     */     } 
/*     */     
/* 105 */     VideoFormat ivf = (VideoFormat)inputBuffer.getFormat();
/* 106 */     int inLength = inputBuffer.getLength();
/* 107 */     int inMaxLength = ivf.getMaxDataLength();
/* 108 */     int outMaxLength = this.outputFormat.getMaxDataLength();
/*     */     
/* 110 */     byte[] inData = (byte[])inputBuffer.getData();
/* 111 */     int[] outData = validateIntArraySize(outputBuffer, outMaxLength);
/*     */     
/* 113 */     if (this.refData == null) {
/* 114 */       this.refData = outData;
/* 115 */       outputBuffer.setData(null);
/* 116 */       outData = validateIntArraySize(outputBuffer, outMaxLength);
/*     */     } 
/*     */     
/* 119 */     outputBuffer.setData(this.refData);
/*     */ 
/*     */     
/* 122 */     outputBuffer.setFormat((Format)this.outputFormat);
/*     */     
/* 124 */     this.fOurStore.DoFrame(inputBuffer, outputBuffer, this.fOurStore);
/*     */     
/* 126 */     System.arraycopy(this.refData, 0, outData, 0, outMaxLength);
/*     */ 
/*     */ 
/*     */     
/* 130 */     outputBuffer.setData(outData);
/*     */     
/* 132 */     updateOutput(outputBuffer, (Format)this.outputFormat, outMaxLength, 0);
/*     */     
/* 134 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\codec\video\cinepak\JavaDecoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */