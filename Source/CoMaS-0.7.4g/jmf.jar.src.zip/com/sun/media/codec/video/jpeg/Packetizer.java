/*     */ package com.sun.media.codec.video.jpeg;
/*     */ 
/*     */ import com.sun.media.BasicCodec;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.Log;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.control.FrameProcessingControl;
/*     */ import javax.media.format.JPEGFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Packetizer
/*     */   extends BasicCodec
/*     */ {
/*  33 */   static final JPEGFormat fJPEG = new JPEGFormat();
/*     */ 
/*     */   
/*  36 */   private VideoFormat inputFormat = null;
/*  37 */   private VideoFormat outputFormat = null;
/*     */ 
/*     */ 
/*     */   
/*  41 */   private int PACKET_SIZE = 960;
/*     */ 
/*     */   
/*  44 */   private int currentSeq = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   private int copyLength = this.PACKET_SIZE;
/*     */   
/*     */   private boolean newFrame = true;
/*     */   
/*     */   private boolean dropFrame = false;
/*     */   private boolean minimal = false;
/*  55 */   private int offset = 0;
/*  56 */   private int frameLength = 0;
/*     */   
/*     */   private static final int J_SOF = 192;
/*     */   private static final int J_SOF1 = 193;
/*  60 */   private int decimation = -1;
/*     */ 
/*     */   
/*     */   private static final int DEFAULT_FRAMERATE = 15;
/*     */   
/*  65 */   private float frame_duration = -1.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Packetizer() {
/*  72 */     this.inputFormats = (Format[])new VideoFormat[] { new VideoFormat("jpeg") };
/*  73 */     this.outputFormats = (Format[])new VideoFormat[] { new VideoFormat("jpeg/rtp") };
/*     */     
/*  75 */     FrameProcessingControl fpc = new FrameProcessingControl(this) {
/*     */         public boolean setMinimalProcessing(boolean newMinimal) {
/*  77 */           this.this$0.minimal = newMinimal;
/*  78 */           return this.this$0.minimal;
/*     */         }
/*     */         private final Packetizer this$0;
/*     */         public void setFramesBehind(float frames) {
/*  82 */           if (frames >= 1.0F) {
/*  83 */             this.this$0.dropFrame = true;
/*     */           } else {
/*  85 */             this.this$0.dropFrame = false;
/*     */           } 
/*     */         }
/*     */         public Component getControlComponent() {
/*  89 */           return null;
/*     */         }
/*     */         
/*     */         public int getFramesDropped() {
/*  93 */           return 0;
/*     */         }
/*     */       };
/*     */ 
/*     */     
/*  98 */     ((BasicPlugIn)this).controls = (Object[])new javax.media.Control[1];
/*  99 */     ((BasicPlugIn)this).controls[0] = fpc;
/*     */   }
/*     */   
/*     */   protected Format getInputFormat() {
/* 103 */     return (Format)this.inputFormat;
/*     */   }
/*     */   
/*     */   protected Format getOutputFormat() {
/* 107 */     return (Format)this.outputFormat;
/*     */   }
/*     */ 
/*     */   
/*     */   public Format[] getSupportedOutputFormats(Format in) {
/* 112 */     if (in == null) {
/* 113 */       return this.outputFormats;
/*     */     }
/*     */     
/* 116 */     if (!verifyInputFormat(in)) {
/* 117 */       return new Format[0];
/*     */     }
/* 119 */     Format[] out = new Format[1];
/*     */ 
/*     */ 
/*     */     
/* 123 */     if (((VideoFormat)in).getFrameRate() == -1.0F) {
/* 124 */       out[0] = (Format)new VideoFormat("jpeg/rtp", ((VideoFormat)in).getSize(), ((VideoFormat)in).getMaxDataLength(), Format.byteArray, 15.0F);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 130 */       out[0] = (Format)new VideoFormat("jpeg/rtp", ((VideoFormat)in).getSize(), ((VideoFormat)in).getMaxDataLength(), Format.byteArray, ((VideoFormat)in).getFrameRate());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     return out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean verifyInputFormat(Format input) {
/* 146 */     return fJPEG.matches(input);
/*     */   }
/*     */   
/*     */   public Format setInputFormat(Format input) {
/* 150 */     if (!verifyInputFormat(input))
/* 151 */       return null; 
/* 152 */     this.inputFormat = (VideoFormat)input;
/* 153 */     float rate = this.inputFormat.getFrameRate();
/* 154 */     if (rate != -1.0F)
/*     */     {
/* 156 */       this.frame_duration = 1000.0F / rate; } 
/* 157 */     if (this.opened) {
/* 158 */       this.outputFormat = (VideoFormat)getSupportedOutputFormats(input)[0];
/*     */     }
/* 160 */     return input;
/*     */   }
/*     */   
/*     */   public Format setOutputFormat(Format output) {
/* 164 */     if (BasicPlugIn.matches(output, this.outputFormats) == null)
/* 165 */       return null; 
/* 166 */     this.outputFormat = (VideoFormat)output;
/* 167 */     return output;
/*     */   }
/*     */   public void open() throws ResourceUnavailableException {
/* 170 */     if (this.inputFormat == null || this.outputFormat == null) {
/* 171 */       throw new ResourceUnavailableException("Incorrect formats set on JPEG Packetizer");
/*     */     }
/*     */     
/* 174 */     Dimension size = this.inputFormat.getSize();
/* 175 */     if (size != null)
/*     */     {
/*     */ 
/*     */       
/* 179 */       if (size.width % 8 != 0 || size.height % 8 != 0) {
/* 180 */         Log.error("Class: " + this);
/* 181 */         Log.error("  can only packetize in sizes of multiple of 8 pixels.");
/* 182 */         throw new ResourceUnavailableException("Incorrect formats set on JPEG Packetizer");
/*     */       } 
/*     */     }
/* 185 */     super.open();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {}
/*     */ 
/*     */   
/*     */   public synchronized int process(Buffer inBuffer, Buffer outBuffer) {
/* 194 */     if (isEOM(inBuffer)) {
/* 195 */       propagateEOM(outBuffer);
/* 196 */       return 0;
/*     */     } 
/*     */     
/* 199 */     if (inBuffer.isDiscard()) {
/* 200 */       updateOutput(outBuffer, (Format)this.outputFormat, 0, 0);
/* 201 */       outBuffer.setDiscard(true);
/* 202 */       return 4;
/*     */     } 
/*     */     
/* 205 */     if (inBuffer.getLength() <= 0) {
/* 206 */       outBuffer.setDiscard(true);
/* 207 */       return 4;
/*     */     } 
/*     */     
/* 210 */     byte[] inData = (byte[])inBuffer.getData();
/*     */     
/* 212 */     outBuffer.setFormat((Format)this.outputFormat);
/*     */     
/* 214 */     Dimension size = this.inputFormat.getSize();
/* 215 */     int keyFrame = 0;
/*     */     
/* 217 */     if (this.newFrame) {
/* 218 */       if (this.dropFrame || this.minimal) {
/* 219 */         outBuffer.setDiscard(true);
/* 220 */         return 0;
/*     */       } 
/* 222 */       int tempdec = peekJPEGDecimation(inData, inBuffer.getLength());
/* 223 */       if (tempdec >= 0)
/* 224 */         this.decimation = tempdec; 
/* 225 */       if (this.inputFormat instanceof JPEGFormat) {
/* 226 */         stripTables(inBuffer);
/*     */       }
/* 228 */       this.frameLength = inBuffer.getLength();
/* 229 */       this.offset = 0;
/* 230 */       this.newFrame = false;
/* 231 */       keyFrame = 16;
/*     */     } 
/*     */ 
/*     */     
/* 235 */     if (this.frameLength - this.offset < this.PACKET_SIZE) {
/* 236 */       this.copyLength = this.frameLength - this.offset;
/*     */     } else {
/* 238 */       this.copyLength = this.PACKET_SIZE;
/*     */     } 
/* 240 */     byte[] outData = (byte[])outBuffer.getData();
/* 241 */     if (outData == null || outData.length < this.copyLength + 8) {
/* 242 */       outData = new byte[this.copyLength + 8];
/* 243 */       outBuffer.setData(outData);
/*     */     } 
/*     */     
/* 246 */     System.arraycopy(inData, this.offset + inBuffer.getOffset(), outData, 8, this.copyLength);
/*     */ 
/*     */     
/* 249 */     int qfactor = (this.inputFormat instanceof JPEGFormat) ? ((JPEGFormat)this.inputFormat).getQFactor() : 80;
/*     */     
/* 251 */     this.decimation = (this.inputFormat instanceof JPEGFormat) ? ((JPEGFormat)this.inputFormat).getDecimation() : this.decimation;
/*     */     
/* 253 */     if (this.decimation == -1) {
/* 254 */       this.decimation = 1;
/*     */     }
/* 256 */     outBuffer.setLength(this.copyLength + 8);
/* 257 */     outBuffer.setOffset(0);
/*     */     
/* 259 */     outBuffer.setSequenceNumber(this.currentSeq++);
/* 260 */     outBuffer.setFormat((Format)this.outputFormat);
/* 261 */     outData[0] = 0;
/* 262 */     outData[1] = (byte)(this.offset >> 16);
/* 263 */     outData[2] = (byte)(this.offset >> 8);
/* 264 */     outData[3] = (byte)this.offset;
/* 265 */     outData[4] = (byte)this.decimation;
/* 266 */     outData[5] = (byte)qfactor;
/* 267 */     outData[6] = (byte)(size.width / 8);
/* 268 */     outData[7] = (byte)(size.height / 8);
/*     */     
/* 270 */     this.offset += this.copyLength;
/*     */     
/* 272 */     outBuffer.setFlags(outBuffer.getFlags() | keyFrame);
/*     */     
/* 274 */     if (this.offset == this.frameLength) {
/* 275 */       outBuffer.setFlags(outBuffer.getFlags() | 0x800);
/* 276 */       this.newFrame = true;
/* 277 */       return 0;
/*     */     } 
/*     */     
/* 280 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public void finalize() {
/* 285 */     close();
/*     */   }
/*     */   
/*     */   public String getName() {
/* 289 */     return "JPEG Packetizer";
/*     */   }
/*     */   
/*     */   int peekJPEGDecimation(byte[] data, int dataLen) {
/* 293 */     int i = 0;
/*     */     
/* 295 */     if ((data[0] & 0xFF) != 255 || data[1] == 0)
/* 296 */       return -1; 
/* 297 */     while (i < dataLen - 2) {
/* 298 */       if ((data[i] & 0xFF) == 255) {
/* 299 */         i++;
/* 300 */         int code = data[i] & 0xFF;
/* 301 */         i++;
/* 302 */         switch (code) {
/*     */           case 192:
/*     */           case 193:
/* 305 */             return getDecimationFromSOF(data, i, dataLen);
/*     */         }  continue;
/*     */       } 
/* 308 */       i++;
/*     */     } 
/* 310 */     return -1;
/*     */   }
/*     */   
/*     */   private void stripTables(Buffer inb) {
/* 314 */     byte[] data = (byte[])inb.getData();
/* 315 */     int offset = inb.getOffset();
/* 316 */     int length = inb.getLength();
/* 317 */     int i = offset;
/* 318 */     while (i < length + offset - 8) {
/* 319 */       if (data[i] == -1 && 
/* 320 */         data[i + 1] == -38) {
/*     */ 
/*     */         
/* 323 */         int blockSize = (data[i + 2] & 0xFF) << 8 | data[i + 3] & 0xFF;
/*     */         
/* 325 */         i += 2 + blockSize;
/* 326 */         System.arraycopy(data, i, data, 0, length + offset - i);
/*     */ 
/*     */         
/* 329 */         inb.setOffset(0);
/* 330 */         inb.setLength(length + offset - i);
/*     */         
/*     */         break;
/*     */       } 
/* 334 */       i++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getDecimationFromSOF(byte[] data, int i, int length) {
/* 346 */     int sectionLen = (data[i++] & 0xFF) << 8;
/* 347 */     sectionLen |= data[i++] & 0xFF;
/*     */     
/* 349 */     i += 5;
/* 350 */     int ncomp = data[i++] & 0xFF;
/*     */     
/* 352 */     if (sectionLen != ncomp * 3 + 8) {
/* 353 */       System.err.println("Bogus SOF length");
/*     */     }
/* 355 */     int id = data[i++] & 0xFF;
/* 356 */     int deccode = data[i++] & 0xFF;
/* 357 */     int hsf = deccode >> 4 & 0xF;
/* 358 */     int vsf = deccode & 0xF;
/* 359 */     if (vsf == 2 && hsf == 2)
/* 360 */       return 1; 
/* 361 */     if (vsf == 1 && hsf == 1) {
/* 362 */       return 2;
/*     */     }
/* 364 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\codec\video\jpeg\Packetizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */