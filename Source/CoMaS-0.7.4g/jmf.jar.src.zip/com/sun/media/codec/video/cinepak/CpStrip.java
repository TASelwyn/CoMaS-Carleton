package com.sun.media.codec.video.cinepak;

public class CpStrip {
  private int fSizeOfStrip = 0;
  
  private int fx0 = 0;
  
  private int fy0 = 0;
  
  private int fx1 = 0;
  
  private int fy1 = 0;
  
  private int fCID = 0;
  
  public CodeEntry[] Detail = new CodeEntry[256];
  
  public CodeEntry[] Smooth = new CodeEntry[256];
  
  public CpStrip() {
    for (int i = 0; i < 256; i++) {
      this.Detail[i] = new CodeEntry();
      this.Smooth[i] = new CodeEntry();
    } 
  }
}
