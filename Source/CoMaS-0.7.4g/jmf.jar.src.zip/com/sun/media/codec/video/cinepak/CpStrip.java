package com.sun.media.codec.video.cinepak;

public class CpStrip {
  private int fSizeOfStrip = 0;
  
  private int fx0 = 0;
  
  private int fy0 = 0;
  
  private int fx1 = 0;
  
  private int fy1 = 0;
  
  private int fCID = 0;
  
  public CodeEntry[] Detail = new CodeEntry[256];
  
  public CodeEntry[] Smooth = new CodeEntry[256];
  
  public CpStrip() {
    for (int i = 0; i < 256; i++) {
      this.Detail[i] = new CodeEntry();
      this.Smooth[i] = new CodeEntry();
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\codec\video\cinepak\CpStrip.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */