/*    */ package com.sun.media.codec.video.cinepak;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CpStrip
/*    */ {
/* 25 */   private int fSizeOfStrip = 0;
/*    */   
/* 27 */   private int fx0 = 0;
/*    */   
/* 29 */   private int fy0 = 0;
/*    */   
/* 31 */   private int fx1 = 0;
/*    */   
/* 33 */   private int fy1 = 0;
/*    */   
/* 35 */   private int fCID = 0;
/*    */ 
/*    */ 
/*    */   
/* 39 */   public CodeEntry[] Detail = new CodeEntry[256];
/*    */   
/* 41 */   public CodeEntry[] Smooth = new CodeEntry[256];
/*    */   public CpStrip() {
/* 43 */     for (int i = 0; i < 256; i++) {
/*    */       
/* 45 */       this.Detail[i] = new CodeEntry();
/*    */       
/* 47 */       this.Smooth[i] = new CodeEntry();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\codec\video\cinepak\CpStrip.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */