/*     */ package com.sun.media.codec.audio.msadpcm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MsAdpcm
/*     */ {
/*  11 */   private static int[] gainTable = new int[] { 230, 230, 230, 230, 307, 409, 512, 614, 768, 614, 512, 409, 307, 230, 230, 230 };
/*     */ 
/*     */ 
/*     */   
/*  15 */   private static int[] pred1Table = new int[] { 256, 512, 0, 192, 240, 460, 392 };
/*  16 */   private static int[] pred2Table = new int[] { 0, -256, 0, 64, 0, -208, -232 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void decodeBlock(byte[] indata, int inOffset, byte[] outdata, int outOffset, int samplesInBlock, MsAdpcmState[] state, int channels) {
/*  29 */     for (int i = 0; i < channels; i++) {
/*  30 */       (state[i]).bpred = indata[inOffset++] & 0xFF;
/*     */       
/*  32 */       if ((state[i]).bpred >= 7) {
/*  33 */         (state[i]).bpred = 0;
/*  34 */         System.err.println("[MSADPCM] Illegal predictor value");
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  39 */     for (int j = 0; j < channels; j++) {
/*  40 */       (state[j]).index = indata[inOffset++] & 0xFF;
/*  41 */       (state[j]).index |= indata[inOffset++] << 8;
/*     */     } 
/*  43 */     for (int k = 0; k < channels; k++) {
/*  44 */       (state[k]).sample1 = indata[inOffset++] & 0xFF;
/*  45 */       (state[k]).sample1 |= indata[inOffset++] << 8;
/*     */     } 
/*     */     
/*  48 */     for (int m = 0; m < channels; m++) {
/*  49 */       (state[m]).sample2 = indata[inOffset++] & 0xFF;
/*  50 */       (state[m]).sample2 |= indata[inOffset++] << 8;
/*     */     } 
/*     */ 
/*     */     
/*  54 */     for (int n = 0; n < channels; n++) {
/*  55 */       outdata[outOffset++] = (byte)(state[n]).sample2;
/*  56 */       outdata[outOffset++] = (byte)((state[n]).sample2 >> 8);
/*     */     } 
/*  58 */     for (int i1 = 0; i1 < channels; i1++) {
/*  59 */       outdata[outOffset++] = (byte)(state[i1]).sample1;
/*  60 */       outdata[outOffset++] = (byte)((state[i1]).sample1 >> 8);
/*     */     } 
/*     */     
/*  63 */     for (int loop = samplesInBlock; loop > 0; loop--) {
/*  64 */       int b = indata[inOffset++];
/*     */ 
/*     */       
/*  67 */       int delta = b >> 4 & 0xF;
/*  68 */       MsAdpcmState localState = state[0];
/*     */       
/*  70 */       int localIndex = localState.index;
/*     */       
/*  72 */       int samplePredictor = localState.sample1 * pred1Table[localState.bpred] + localState.sample2 * pred2Table[localState.bpred] >> 8;
/*     */ 
/*     */       
/*  75 */       int signedDelta = delta << 28 >> 28;
/*     */       
/*  77 */       int sample = signedDelta * localIndex + samplePredictor;
/*     */ 
/*     */       
/*  80 */       if (sample > 32767) {
/*  81 */         sample = 32767;
/*  82 */       } else if (sample < -32768) {
/*  83 */         sample = -32768;
/*     */       } 
/*     */       
/*  86 */       localIndex = gainTable[delta] * localIndex >> 8;
/*     */       
/*  88 */       if (localIndex < 16) {
/*  89 */         localIndex = 16;
/*     */       }
/*  91 */       localState.sample2 = localState.sample1;
/*  92 */       localState.sample1 = sample;
/*     */       
/*  94 */       localState.index = localIndex;
/*     */       
/*  96 */       outdata[outOffset++] = (byte)sample;
/*  97 */       outdata[outOffset++] = (byte)(sample >> 8);
/*     */ 
/*     */ 
/*     */       
/* 101 */       delta = b & 0xF;
/*     */       
/* 103 */       localState = state[(channels == 1) ? 0 : 1];
/*     */       
/* 105 */       localIndex = localState.index;
/*     */       
/* 107 */       samplePredictor = localState.sample1 * pred1Table[localState.bpred] + localState.sample2 * pred2Table[localState.bpred] >> 8;
/*     */ 
/*     */       
/* 110 */       signedDelta = delta << 28 >> 28;
/*     */       
/* 112 */       sample = signedDelta * localIndex + samplePredictor;
/*     */ 
/*     */       
/* 115 */       if (sample > 32767) {
/* 116 */         sample = 32767;
/* 117 */       } else if (sample < -32768) {
/* 118 */         sample = -32768;
/*     */       } 
/*     */       
/* 121 */       localIndex = gainTable[delta] * localIndex >> 8;
/*     */       
/* 123 */       if (localIndex < 16) {
/* 124 */         localIndex = 16;
/*     */       }
/* 126 */       localState.sample2 = localState.sample1;
/* 127 */       localState.sample1 = sample;
/*     */       
/* 129 */       localState.index = localIndex;
/*     */       
/* 131 */       outdata[outOffset++] = (byte)sample;
/* 132 */       outdata[outOffset++] = (byte)(sample >> 8);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\codec\audio\msadpcm\MsAdpcm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */