package com.sun.media.codec.audio.mpa;

import com.sun.media.controls.PacketSizeAdapter;
import javax.media.Codec;

class PacketSizeAdapter extends PacketSizeAdapter {
  public PacketSizeAdapter(Codec newOwner, int newPacketSize, boolean newIsSetable) {
    super(newOwner, newPacketSize, newIsSetable);
  }
  
  public int setPacketSize(int numBytes) {
    if (numBytes < 110)
      numBytes = 110; 
    if (numBytes > 1456)
      numBytes = 1456; 
    this.packetSize = numBytes;
    ((Packetizer)this.owner).setPacketSize(this.packetSize);
    return this.packetSize;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\codec\audio\mpa\PacketSizeAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */