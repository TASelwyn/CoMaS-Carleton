package com.sun.media.codec.audio.mpa;

public class MPAParse {
  private static int MPA_MAX_BYTES_IN_FRAME = 2024;
  
  private static int MPA_MIN_BYTES_IN_FRAME = 21;
  
  private static int MPA_NSAMP = 1152;
  
  private static int MPA_LAYER1 = 3;
  
  private static int MPA_LAYER2 = 2;
  
  private static int MPA_LAYER3 = 1;
  
  private static int MPA_MPEG1 = 1;
  
  private static int MPA_MPEG2 = 0;
  
  private static int MPA_MONO = 3;
  
  public static int[][] SAMPLE_TABLE = new int[][] { { 22050, 24000, 16000, 0 }, { 44100, 48000, 32000, 0 } };
  
  public static int[][] BITRATE_TABLE1 = new int[][] { { 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1, -1 }, { 
        0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 
        160, 192, 224, 256, 320, -1 }, { 
        0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 
        192, 224, 256, 320, 384, -1 }, { 
        0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 
        320, 352, 384, 416, 448, -1 } };
  
  public static int[][] BITRATE_TABLE2 = new int[][] { { 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1, -1 }, { 
        0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 
        96, 112, 128, 144, 160, -1 }, { 
        0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 
        96, 112, 128, 144, 160, -1 }, { 
        0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 
        160, 176, 192, 224, 256, -1 } };
  
  private static int[] MAX_FREE_BITS = new int[] { 0, 11520, 13824, 5376 };
  
  public static int[] SLOT_BITS_MASK = new int[] { 0, 7, 7, 31 };
  
  public static int[][] SAMPLES_PER_FRAME = new int[][] { { 0, 576, 1152, 384 }, { 0, 1152, 1152, 384 } };
  
  public static int MPA_OK = 0;
  
  public static int MPA_HDR_DOUBTED = 1;
  
  public static int MPA_ERR_LOWBUFFER = -1;
  
  public static int MPA_ERR_NULLPTR = -2;
  
  public static int MPA_ERR_NOHDR = -3;
  
  private boolean firstFound = false;
  
  private int firstId = 0;
  
  private int firstLayer = 0;
  
  private int firstSamplingRate = 0;
  
  public String getName() {
    return "MPEG Audio Parser";
  }
  
  public void reset() {
    this.firstFound = false;
    this.firstId = 0;
    this.firstLayer = 0;
    this.firstSamplingRate = 0;
  }
  
  public int getHeader(MPAHeader header, byte[] inData, int inOffset, int inLength) {
    int status = MPA_ERR_NOHDR;
    boolean found = false;
    int offset = inOffset;
    int off2 = 0;
    if (inLength < 4)
      return status; 
    int bufend = offset + inLength;
    label113: while (true) {
      if ((inData[offset] & 0xFF) == 255 && (inData[offset + 1] & 0xF6) > 240 && (inData[offset + 2] & 0xF0) != 240 && (inData[offset + 2] & 0xC) != 12 && (inData[offset + 3] & 0x3) != 2) {
        int id = inData[offset + 1] >> 3 & 0x1;
        int layer = inData[offset + 1] >> 1 & 0x3;
        int crc = inData[offset + 1] & 0x1;
        int bitrateIndex = inData[offset + 2] >> 4 & 0xF;
        int samplingIndex = inData[offset + 2] >> 2 & 0x3;
        int paddingBit = inData[offset + 2] >> 1 & 0x1;
        int channelMode = inData[offset + 3] >> 6 & 0x3;
        int nSamples = SAMPLES_PER_FRAME[id][layer];
        int samplingRate = SAMPLE_TABLE[id][samplingIndex];
        if (bitrateIndex != 0) {
          int bitsInFrame = ((id == MPA_MPEG1) ? BITRATE_TABLE1[layer][bitrateIndex] : BITRATE_TABLE2[layer][bitrateIndex]) * 1000 * nSamples / samplingRate & (SLOT_BITS_MASK[layer] ^ 0xFFFFFFFF);
          if (paddingBit != 0)
            bitsInFrame += SLOT_BITS_MASK[layer] + 1; 
          off2 = offset + (bitsInFrame >> 3);
          if (off2 + 1 < bufend) {
            if ((inData[off2] & 0xFF) == 255 && (inData[off2 + 1] & 0xFE) == (inData[offset + 1] & 0xFE)) {
              if (this.firstFound) {
                if (id == this.firstId && layer == this.firstLayer && samplingRate == this.firstSamplingRate) {
                  header.headerOffset = offset;
                  found = true;
                  status = MPA_OK;
                  break;
                } 
                offset++;
                continue;
              } 
              header.headerOffset = offset;
              found = true;
              status = MPA_OK;
              break;
            } 
            if (offset == inOffset && this.firstFound && id == this.firstId && layer == this.firstLayer && samplingRate == this.firstSamplingRate) {
              if (!found)
                header.headerOffset = offset; 
              found = true;
              status = MPA_HDR_DOUBTED;
              break;
            } 
            offset++;
            continue;
          } 
          if (!found)
            header.headerOffset = offset; 
          found = true;
          status = MPA_HDR_DOUBTED;
          offset++;
          continue;
        } 
        int maxLen = MAX_FREE_BITS[layer] >> 3;
        off2 = 48;
        if (offset + off2 + 3 >= bufend) {
          if (!found)
            header.headerOffset = offset; 
          found = true;
          status = MPA_HDR_DOUBTED;
          offset++;
          continue;
        } 
        try {
          while ((inData[offset + off2] & 0xFF) != 255 || (inData[offset + off2 + 1] & 0xFE) != (inData[offset + 1] & 0xFE) || (inData[offset + off2 + 2] & 0xFC) != (inData[offset + 2] & 0xFC) || (inData[offset + off2 + 3] & 0x3) != 2) {
            off2++;
            if (off2 > maxLen) {
              offset++;
              continue label113;
            } 
            if (offset + off2 + 3 >= bufend) {
              if (!found)
                header.headerOffset = offset; 
              found = true;
              status = MPA_HDR_DOUBTED;
              offset++;
              continue label113;
            } 
          } 
        } catch (Exception ex) {
          System.err.println("Exception: off " + offset + " off2 " + off2 + " bufend " + bufend);
          ex.printStackTrace();
          return MPA_ERR_NOHDR;
        } 
        header.headerOffset = offset;
        found = true;
        status = MPA_OK;
        break;
      } 
      offset++;
      if (offset + 3 >= bufend) {
        if (found)
          break; 
        return status;
      } 
    } 
    offset = header.headerOffset;
    int i = inData[offset + 1] >> 3 & 0x1;
    int j = inData[offset + 1] >> 1 & 0x3;
    int k = inData[offset + 1] & 0x1;
    int m = inData[offset + 2] >> 4 & 0xF;
    int n = inData[offset + 2] >> 2 & 0x3;
    int i1 = inData[offset + 2] >> 1 & 0x1;
    int i2 = inData[offset + 3] >> 6 & 0x3;
    header.layer = 4 - j;
    header.nSamples = SAMPLES_PER_FRAME[i][j];
    header.samplingRate = SAMPLE_TABLE[i][n];
    header.bitRate = (i == MPA_MPEG1) ? BITRATE_TABLE1[j][m] : BITRATE_TABLE2[j][m];
    header.nChannels = (i2 == MPA_MONO) ? 1 : 2;
    if (header.bitRate > 0) {
      header.bitsInFrame = header.bitRate * 1000 * header.nSamples / header.samplingRate & (SLOT_BITS_MASK[j] ^ 0xFFFFFFFF);
      if (i1 != 0)
        header.bitsInFrame += SLOT_BITS_MASK[j] + 1; 
    } else if (status == MPA_OK) {
      header.bitsInFrame = off2 << 3;
    } else {
      header.bitsInFrame = bufend - offset << 3;
    } 
    if (j == MPA_LAYER3) {
      int hoff = (k == 1) ? 4 : 6;
      if (i == MPA_MPEG1) {
        header.negOffset = (inData[offset + hoff] & 0xFF) << 1 | inData[offset + hoff + 1] >> 7 & 0x1;
      } else {
        header.negOffset = inData[offset + hoff] & 0xFF;
      } 
    } else {
      header.negOffset = 0;
    } 
    if (!this.firstFound && status == MPA_OK) {
      this.firstFound = true;
      this.firstId = i;
      this.firstLayer = j;
      this.firstSamplingRate = header.samplingRate;
    } 
    return status;
  }
}
