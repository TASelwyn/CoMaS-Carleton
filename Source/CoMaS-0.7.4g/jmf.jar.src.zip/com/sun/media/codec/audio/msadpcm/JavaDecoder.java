package com.sun.media.codec.audio.msadpcm;

import com.sun.media.BasicCodec;
import com.sun.media.BasicPlugIn;
import com.sun.media.codec.audio.AudioCodec;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.format.AudioFormat;

public class JavaDecoder extends AudioCodec {
  private static final boolean DEBUG = true;
  
  private MsAdpcmState[] state;
  
  public JavaDecoder() {
    ((BasicCodec)this).inputFormats = new Format[] { (Format)new AudioFormat("msadpcm") };
  }
  
  public String getName() {
    return "msadpcm decoder";
  }
  
  public Format[] getSupportedOutputFormats(Format in) {
    if (in == null)
      return new Format[] { (Format)new AudioFormat("LINEAR") }; 
    if (BasicPlugIn.matches(in, ((BasicCodec)this).inputFormats) == null)
      return new Format[0]; 
    if (!(in instanceof AudioFormat))
      return new Format[] { (Format)new AudioFormat("LINEAR") }; 
    AudioFormat af = (AudioFormat)in;
    int frameSize = af.getFrameSizeInBits();
    if (frameSize != 2048 && frameSize != 4096 && frameSize != 8192)
      return new Format[0]; 
    return new Format[] { (Format)new AudioFormat("LINEAR", af.getSampleRate(), 16, af.getChannels(), 0, 1) };
  }
  
  public void open() {
    this.state = new MsAdpcmState[2];
    this.state[0] = new MsAdpcmState();
    this.state[1] = new MsAdpcmState();
  }
  
  public void close() {
    this.state[0] = null;
    this.state[1] = null;
    this.state = null;
  }
  
  public int process(Buffer inputBuffer, Buffer outputBuffer) {
    if (!checkInputBuffer(inputBuffer))
      return 1; 
    if (isEOM(inputBuffer)) {
      propagateEOM(outputBuffer);
      return 0;
    } 
    byte[] inData = (byte[])inputBuffer.getData();
    byte[] outData = validateByteArraySize(outputBuffer, inData.length * 4);
    AudioFormat iaf = (AudioFormat)inputBuffer.getFormat();
    int blockAlign = iaf.getFrameSizeInBits() >> 3;
    int channels = iaf.getChannels();
    int outLength = decode(inData, outData, inputBuffer.getLength(), blockAlign, channels);
    updateOutput(outputBuffer, ((BasicCodec)this).outputFormat, outLength, 0);
    return 0;
  }
  
  private int decode(byte[] inpData, byte[] outData, int inLength, int blockAlign, int channels) {
    int dataBytesInBlock = blockAlign - 7 * channels;
    int outBytes = 4 * channels + (blockAlign - 7 * channels) * 4;
    int readPtr = 0;
    int writePtr = 0;
    int numberOfBlocks = inLength / blockAlign;
    int n = 1;
    for (; n <= numberOfBlocks; 
      n++, writePtr += outBytes, readPtr += blockAlign)
      MsAdpcm.decodeBlock(inpData, readPtr, outData, writePtr, dataBytesInBlock, this.state, channels); 
    return writePtr;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\codec\audio\msadpcm\JavaDecoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */