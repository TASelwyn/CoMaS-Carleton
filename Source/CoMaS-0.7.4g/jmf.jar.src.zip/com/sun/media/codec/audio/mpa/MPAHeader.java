package com.sun.media.codec.audio.mpa;

public class MPAHeader {
  public int layer;
  
  public int headerOffset;
  
  public int bitsInFrame;
  
  public int bitRate;
  
  public int samplingRate;
  
  public int nChannels;
  
  public int nSamples;
  
  public int negOffset;
  
  public String toString() {
    String s = "\n   Layer = " + this.layer + "\n" + "   HeaderOffset = " + this.headerOffset + "\n" + "   BitsInFrame = " + this.bitsInFrame + "\n" + "   BitRate = " + this.bitRate + "\n" + "   SamplingRate = " + this.samplingRate + "\n" + "   Channels = " + this.nChannels + "\n" + "   Samples = " + this.nSamples + "\n";
    return s;
  }
}
