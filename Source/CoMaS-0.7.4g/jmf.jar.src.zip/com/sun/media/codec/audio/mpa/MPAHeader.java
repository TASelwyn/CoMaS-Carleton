/*    */ package com.sun.media.codec.audio.mpa;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MPAHeader
/*    */ {
/*    */   public int layer;
/*    */   public int headerOffset;
/*    */   public int bitsInFrame;
/*    */   public int bitRate;
/*    */   public int samplingRate;
/*    */   public int nChannels;
/*    */   public int nSamples;
/*    */   public int negOffset;
/*    */   
/*    */   public String toString() {
/* 26 */     String s = "\n   Layer = " + this.layer + "\n" + "   HeaderOffset = " + this.headerOffset + "\n" + "   BitsInFrame = " + this.bitsInFrame + "\n" + "   BitRate = " + this.bitRate + "\n" + "   SamplingRate = " + this.samplingRate + "\n" + "   Channels = " + this.nChannels + "\n" + "   Samples = " + this.nSamples + "\n";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 34 */     return s;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\codec\audio\mpa\MPAHeader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */