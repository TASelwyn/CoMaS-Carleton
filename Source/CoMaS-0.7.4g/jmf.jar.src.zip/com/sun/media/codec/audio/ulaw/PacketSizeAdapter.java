/*     */ package com.sun.media.codec.audio.ulaw;
/*     */ 
/*     */ import com.sun.media.controls.PacketSizeAdapter;
/*     */ import javax.media.Codec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PacketSizeAdapter
/*     */   extends PacketSizeAdapter
/*     */ {
/*     */   public PacketSizeAdapter(Codec newOwner, int newPacketSize, boolean newIsSetable) {
/* 114 */     super(newOwner, newPacketSize, newIsSetable);
/*     */   }
/*     */ 
/*     */   
/*     */   public int setPacketSize(int numBytes) {
/* 119 */     int numOfPackets = numBytes;
/*     */     
/* 121 */     if (numOfPackets < 10) {
/* 122 */       numOfPackets = 10;
/*     */     }
/*     */     
/* 125 */     if (numOfPackets > 8000) {
/* 126 */       numOfPackets = 8000;
/*     */     }
/* 128 */     this.packetSize = numOfPackets;
/*     */ 
/*     */     
/* 131 */     ((Packetizer)this.owner).setPacketSize(this.packetSize);
/*     */     
/* 133 */     return this.packetSize;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\codec\audi\\ulaw\PacketSizeAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */