/*    */ package com.sun.media;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultSecurity
/*    */   implements JMFSecurity
/*    */ {
/*    */   public static JMFSecurity security;
/* 16 */   private static ClassLoader clsLoader = null;
/* 17 */   private static Class cls = null;
/* 18 */   private static Method dummyMethodRef = null;
/*    */ 
/*    */   
/*    */   static {
/* 22 */     security = new DefaultSecurity();
/*    */     try {
/* 24 */       cls = security.getClass();
/* 25 */       clsLoader = cls.getClassLoader();
/* 26 */       dummyMethodRef = cls.getMethod("dummyMethod", new Class[0]);
/*    */     } catch (Exception e) {
/* 28 */       System.out.println(e);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void dummyMethod() {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 42 */     return "default";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void requestPermission(Method[] m, Class[] c, Object[][] args, int request) throws SecurityException {
/* 49 */     m[0] = dummyMethodRef;
/* 50 */     c[0] = cls;
/* 51 */     args[0] = null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void requestPermission(Method[] m, Class[] c, Object[][] args, int request, String parameter) throws SecurityException {
/* 64 */     requestPermission(m, c, args, request);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isLinkPermissionEnabled() {
/* 69 */     if (clsLoader == null) {
/* 70 */       return true;
/*    */     }
/*    */     
/* 73 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void permissionFailureNotification(int permission) {}
/*    */ 
/*    */   
/*    */   public void loadLibrary(String name) throws UnsatisfiedLinkError {
/* 82 */     if (clsLoader == null) {
/* 83 */       System.loadLibrary(name);
/*    */     } else {
/*    */       
/* 86 */       throw new UnsatisfiedLinkError("Unable to get link privilege to " + name);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\DefaultSecurity.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */