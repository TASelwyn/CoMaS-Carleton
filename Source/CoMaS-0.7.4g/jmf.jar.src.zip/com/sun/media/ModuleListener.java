package com.sun.media;

import javax.media.Buffer;
import javax.media.Format;

public interface ModuleListener {
  void bufferPrefetched(Module paramModule);
  
  void stopAtTime(Module paramModule);
  
  void mediaEnded(Module paramModule);
  
  void resetted(Module paramModule);
  
  void dataBlocked(Module paramModule, boolean paramBoolean);
  
  void framesBehind(Module paramModule, float paramFloat, InputConnector paramInputConnector);
  
  void markedDataArrived(Module paramModule, Buffer paramBuffer);
  
  void formatChanged(Module paramModule, Format paramFormat1, Format paramFormat2);
  
  void formatChangedFailure(Module paramModule, Format paramFormat1, Format paramFormat2);
  
  void pluginTerminated(Module paramModule);
  
  void internalErrorOccurred(Module paramModule);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\ModuleListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */