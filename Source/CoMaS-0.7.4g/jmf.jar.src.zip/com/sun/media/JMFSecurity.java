package com.sun.media;

import java.lang.reflect.Method;

public interface JMFSecurity {
  public static final int READ_PROPERTY = 1;
  
  public static final int READ_FILE = 2;
  
  public static final int WRITE_FILE = 4;
  
  public static final int DELETE_FILE = 8;
  
  public static final int THREAD = 16;
  
  public static final int THREAD_GROUP = 32;
  
  public static final int LINK = 64;
  
  public static final int CONNECT = 128;
  
  public static final int TOP_LEVEL_WINDOW = 256;
  
  public static final int MULTICAST = 512;
  
  String getName();
  
  void requestPermission(Method[] paramArrayOfMethod, Class[] paramArrayOfClass, Object[][] paramArrayOfObject, int paramInt) throws SecurityException;
  
  void requestPermission(Method[] paramArrayOfMethod, Class[] paramArrayOfClass, Object[][] paramArrayOfObject, int paramInt, String paramString) throws SecurityException;
  
  boolean isLinkPermissionEnabled();
  
  void permissionFailureNotification(int paramInt);
  
  void loadLibrary(String paramString) throws UnsatisfiedLinkError;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\JMFSecurity.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */