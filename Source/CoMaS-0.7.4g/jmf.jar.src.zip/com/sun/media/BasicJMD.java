package com.sun.media;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.Enumeration;
import java.util.Vector;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.PlugIn;

public final class BasicJMD extends Panel implements JMD, WindowListener {
  Vector modList = new Vector();
  
  Vector conList = new Vector();
  
  boolean graphic = true;
  
  Panel center;
  
  Label status;
  
  Frame frame = null;
  
  boolean activated = false;
  
  Button button = null;
  
  Dimension preferredSize = new Dimension(512, 140);
  
  int ro;
  
  int col;
  
  int colMax;
  
  int roMax;
  
  int wrapWidth;
  
  int wrapHeight;
  
  int offX;
  
  int offY;
  
  int fill;
  
  int cSize;
  
  public Component getControlComponent() {
    if (this.button == null) {
      this.button = new Button(this, "PlugIn Viewer") {
          private final BasicJMD this$0;
          
          public void removeNotify() {
            super.removeNotify();
            this.this$0.dispose();
          }
        };
      this.button.setName("PlugIns");
      this.button.addActionListener(new ActionListener(this) {
            private final BasicJMD this$0;
            
            public void actionPerformed(ActionEvent ae) {
              this.this$0.setVisible(true);
            }
          });
    } 
    return this.button;
  }
  
  public synchronized void dispose() {
    if (this.frame != null) {
      this.frame.dispose();
      this.frame = null;
    } 
  }
  
  public synchronized void setVisible(boolean visible) {
    if (getParent() == null) {
      if (visible && 
        this.frame == null) {
        this.frame = new Frame("PlugIn Viewer");
        this.frame.setLayout(new BorderLayout());
        this.frame.add("Center", this);
        this.frame.addWindowListener(this);
        this.frame.pack();
        this.frame.setVisible(true);
      } 
    } else if (getParent() == this.frame) {
      this.frame.setVisible(visible);
    } else {
      super.setVisible(visible);
    } 
  }
  
  public BasicJMD(String title) {
    this.colMax = 1;
    this.roMax = 1;
    this.wrapWidth = 200;
    this.wrapHeight = 50;
    this.offX = 0;
    this.offY = 0;
    this.fill = 10;
    this.cSize = 10;
    setLayout(new BorderLayout());
    setBackground(Color.lightGray);
    this.center = new Panel(this) {
        private final BasicJMD this$0;
        
        public Dimension getPreferredSize() {
          return this.this$0.preferredSize;
        }
      };
    this.center.setLayout(null);
    add("North", this.center);
    this.status = new Label();
    add("South", this.status);
    setSize(512, 200);
  }
  
  public void initGraph(BasicModule source) {
    this.center.removeAll();
    this.modList = new Vector();
    this.conList = new Vector();
    drawGraph(source);
    this.ro = 0;
    this.col = 0;
    this.preferredSize = new Dimension((this.colMax + 1) * this.wrapWidth + this.offX * 2, this.roMax * this.wrapHeight + this.offY * 2);
  }
  
  public void drawGraph(BasicModule source) {
    String[] names = source.getOutputConnectorNames();
    int height = names.length;
    if (height == 0)
      height = 1; 
    createModuleWrap(source, this.ro, this.col, height);
    if (this.roMax < names.length)
      this.roMax = names.length; 
    for (int i = 0; i < names.length; i++) {
      OutputConnector oc = source.getOutputConnector(names[i]);
      InputConnector ic;
      if ((ic = oc.getInputConnector()) == null) {
        if (this.col == 0)
          this.ro++; 
      } else {
        Module m;
        if ((m = ic.getModule()) == null) {
          if (this.col == 0)
            this.ro++; 
        } else {
          this.col++;
          if (this.col > this.colMax)
            this.colMax = this.col; 
          drawGraph((BasicModule)m);
          this.col--;
          if (this.col == 0)
            this.ro++; 
        } 
      } 
    } 
  }
  
  public void createModuleWrap(BasicModule m, int row, int column, int h) {
    Object plugin = m;
    if (m instanceof BasicSourceModule) {
      plugin = ((BasicSourceModule)m).getDemultiplexer();
    } else if (m instanceof BasicFilterModule) {
      plugin = ((BasicFilterModule)m).getCodec();
    } else if (m instanceof BasicRendererModule) {
      plugin = ((BasicRendererModule)m).getRenderer();
    } else if (m instanceof BasicMuxModule) {
      plugin = ((BasicMuxModule)m).getMultiplexer();
    } 
    String name = ((PlugIn)plugin).getName();
    Button b = new ModButton(this, name, m, (PlugIn)plugin);
    b.setName("M" + m.hashCode());
    this.modList.addElement(b);
    b.setBackground(new Color(192, 192, 128));
    b.setForeground(Color.black);
    this.center.add(b);
    b.setBounds(this.offX + column * this.wrapWidth + this.fill, this.offY + row * this.wrapHeight + this.fill, this.wrapWidth - this.fill * 2, h * this.wrapHeight - this.fill * 2);
    b.setVisible(true);
    this.center.invalidate();
  }
  
  public void moduleIn(BasicModule bm, int index, Buffer d, boolean here) {
    updateConnector(bm, index, d, here, 0);
  }
  
  public void updateConnector(BasicModule bm, int index, Buffer d, boolean here, int inOut) {
    if (!this.activated)
      return; 
    Con c = findConnector(bm, index, inOut);
    if (c == null)
      return; 
    c.setData(d);
    if (here) {
      if (d.isEOM()) {
        c.flash(Color.red);
      } else if (d.isDiscard()) {
        c.flash(Color.yellow);
      } else {
        c.flash(Color.green);
      } 
    } else {
      c.flash(Color.gray);
    } 
  }
  
  public void moduleOut(BasicModule bm, int index, Buffer d, boolean here) {
    updateConnector(bm, index, d, here, 1);
  }
  
  public Con findConnector(BasicModule bm, int index, int inOut) {
    String name = "C" + bm.hashCode() + index + inOut;
    Enumeration e = this.conList.elements();
    while (e.hasMoreElements()) {
      Con con = e.nextElement();
      if (con.getName().equals(name))
        return con; 
    } 
    Component m = findModule(bm);
    if (m == null)
      return null; 
    Point p = m.getLocation();
    Con c = new Con(this);
    this.center.add(c);
    c.setBounds(p.x - this.fill + (this.wrapWidth - this.fill) * inOut, p.y + (this.wrapHeight - 2 * this.fill - this.cSize) / 2 + this.wrapHeight * index, this.cSize, this.cSize);
    c.setName(name);
    this.conList.addElement(c);
    return c;
  }
  
  public Component findModule(BasicModule bm) {
    String name = "M" + bm.hashCode();
    Enumeration e = this.modList.elements();
    while (e.hasMoreElements()) {
      Component c = e.nextElement();
      if (c.getName().equals(name))
        return c; 
    } 
    return null;
  }
  
  public void windowActivated(WindowEvent we) {
    this.activated = true;
  }
  
  public void windowOpened(WindowEvent we) {}
  
  public void windowIconified(WindowEvent we) {}
  
  public void windowDeiconified(WindowEvent we) {}
  
  public void windowClosing(WindowEvent we) {
    setVisible(false);
  }
  
  public void windowClosed(WindowEvent we) {}
  
  public void windowDeactivated(WindowEvent we) {
    this.activated = false;
  }
  
  class ModButton extends Button {
    BasicModule module;
    
    boolean mouseHere;
    
    PlugIn plugin;
    
    private final BasicJMD this$0;
    
    public String cropName(String name) {
      boolean bool;
      int box_width = 120;
      FontMetrics fm = getFontMetrics(new Font("Dialog", 0, 11));
      String cropped = name;
      int width = fm.stringWidth(cropped);
      if (width > box_width) {
        bool = true;
      } else {
        bool = false;
      } 
      while (width > box_width) {
        int length = cropped.length();
        cropped = name.substring(0, length - 1);
        width = fm.stringWidth(cropped);
      } 
      if (bool)
        cropped = cropped + "..."; 
      return cropped;
    }
    
    public ModButton(BasicJMD this$0, String name, BasicModule m, PlugIn p) {
      this.this$0 = this$0;
      this.mouseHere = false;
      name = cropName(name);
      setLabel(name);
      this.module = m;
      this.plugin = p;
      addMouseListener((MouseListener)new Object(this));
    }
    
    public void updateStatus() {
      this.this$0.status.setText(this.plugin.getClass().getName() + " , " + this.plugin.getName());
    }
  }
  
  class Con extends Button {
    Graphics g;
    
    Buffer data;
    
    boolean mouseHere;
    
    private final BasicJMD this$0;
    
    public Con(BasicJMD this$0) {
      this.this$0 = this$0;
      this.g = null;
      this.data = null;
      this.mouseHere = false;
      addMouseListener((MouseListener)new Object(this));
    }
    
    public void flash(Color c) {
      Graphics g = getGraphics();
      if (g == null)
        return; 
      g.setColor(c);
      g.fillRect(1, 1, this.this$0.cSize - 2, this.this$0.cSize - 2);
    }
    
    public Graphics getGraphics() {
      this.g = super.getGraphics();
      return this.g;
    }
    
    public void paint(Graphics g) {
      g.setColor(Color.black);
      g.drawRect(0, 0, this.this$0.cSize - 1, this.this$0.cSize - 1);
      g.setColor(Color.gray);
      g.fillRect(1, 1, this.this$0.cSize - 2, this.this$0.cSize - 2);
    }
    
    public void setData(Buffer d) {
      if (this.mouseHere)
        updateStatus(); 
      this.data = d;
    }
    
    void updateStatus() {
      String str;
      Format f = this.data.getFormat();
      if (f == null) {
        str = "null";
      } else {
        str = f.toString();
      } 
      this.this$0.status.setText(str + ", Length = " + this.data.getLength());
    }
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\BasicJMD.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */