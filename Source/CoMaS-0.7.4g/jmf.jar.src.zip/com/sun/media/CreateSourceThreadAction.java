/*    */ package com.sun.media;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CreateSourceThreadAction
/*    */   implements PrivilegedAction
/*    */ {
/*    */   private Class sourceThreadClass;
/*    */   private BasicSourceModule bsm;
/*    */   private Object myoc;
/*    */   private int i;
/*    */   static Constructor cons;
/*    */   
/*    */   static {
/*    */     try {
/* 30 */       cons = CreateSourceThreadAction.class.getConstructor(new Class[] { Class.class, BasicSourceModule.class, Object.class, int.class });
/*    */     }
/* 32 */     catch (Throwable e) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CreateSourceThreadAction(Class sourceThreadClass, BasicSourceModule bsm, Object myoc, int i) {
/*    */     try {
/* 40 */       this.sourceThreadClass = sourceThreadClass;
/* 41 */       this.bsm = bsm;
/* 42 */       this.myoc = myoc;
/* 43 */       this.i = i;
/* 44 */     } catch (Throwable e) {}
/*    */   }
/*    */ 
/*    */   
/*    */   public Object run() {
/*    */     try {
/* 50 */       Constructor cons = this.sourceThreadClass.getConstructor(new Class[] { BasicSourceModule.class, this.myoc.getClass(), int.class });
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 55 */       Object object = cons.newInstance(new Object[] { this.bsm, this.myoc, new Integer(this.i) });
/*    */       
/* 57 */       return object;
/*    */     } catch (Throwable e) {
/* 59 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\CreateSourceThreadAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */