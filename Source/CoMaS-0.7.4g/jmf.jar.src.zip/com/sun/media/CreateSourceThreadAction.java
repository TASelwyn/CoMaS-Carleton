package com.sun.media;

import java.lang.reflect.Constructor;
import java.security.PrivilegedAction;

public class CreateSourceThreadAction implements PrivilegedAction {
  private Class sourceThreadClass;
  
  private BasicSourceModule bsm;
  
  private Object myoc;
  
  private int i;
  
  static Constructor cons;
  
  static {
    try {
      cons = CreateSourceThreadAction.class.getConstructor(new Class[] { Class.class, BasicSourceModule.class, Object.class, int.class });
    } catch (Throwable e) {}
  }
  
  public CreateSourceThreadAction(Class sourceThreadClass, BasicSourceModule bsm, Object myoc, int i) {
    try {
      this.sourceThreadClass = sourceThreadClass;
      this.bsm = bsm;
      this.myoc = myoc;
      this.i = i;
    } catch (Throwable e) {}
  }
  
  public Object run() {
    try {
      Constructor cons = this.sourceThreadClass.getConstructor(new Class[] { BasicSourceModule.class, this.myoc.getClass(), int.class });
      Object object = cons.newInstance(new Object[] { this.bsm, this.myoc, new Integer(this.i) });
      return object;
    } catch (Throwable e) {
      return null;
    } 
  }
}
