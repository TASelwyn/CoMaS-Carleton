package com.sun.media;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import com.sun.media.util.Registry;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Method;

public class Log {
  public static boolean isEnabled = true;
  
  private static DataOutputStream log = null;
  
  private static String fileName = "jmf.log";
  
  private static int indent = 0;
  
  private static JMFSecurity jmfSecurity = null;
  
  private static Method[] m = new Method[1];
  
  private static Class[] cl = new Class[1];
  
  private static Object[][] args = new Object[1][0];
  
  private static boolean ieSec = false;
  
  private static String permission = null;
  
  private static int permissionid = 0;
  
  static {
    synchronized (fileName) {
      if (isEnabled && log == null) {
        Object llog = Registry.get("allowLogging");
        if (llog != null && llog instanceof Boolean && 
          !((Boolean)llog).booleanValue())
          isEnabled = false; 
        if (isEnabled)
          try {
            jmfSecurity = JMFSecurityManager.getJMFSecurity();
            if (jmfSecurity != null)
              if (jmfSecurity.getName().startsWith("jmf-security")) {
                permission = "write file";
                permissionid = 4;
                jmfSecurity.requestPermission(m, cl, args, 4);
                m[0].invoke(cl[0], args[0]);
                permission = "delete file";
                permissionid = 8;
                jmfSecurity.requestPermission(m, cl, args, 8);
                m[0].invoke(cl[0], args[0]);
                permission = "read system property";
                permissionid = 1;
                jmfSecurity.requestPermission(m, cl, args, 1);
                m[0].invoke(cl[0], args[0]);
              } else if (jmfSecurity.getName().startsWith("internet")) {
                PolicyEngine.checkPermission(PermissionID.FILEIO);
                PolicyEngine.assertPermission(PermissionID.FILEIO);
                ieSec = true;
              }  
          } catch (Exception e) {
            isEnabled = false;
          }  
        if (isEnabled) {
          isEnabled = false;
          try {
            String str1;
            Object ldir = Registry.get("secure.logDir");
            if (ldir != null && ldir instanceof String && !"".equals(ldir)) {
              str1 = (String)ldir;
            } else {
              str1 = System.getProperty("user.dir");
            } 
            String file = str1 + File.separator + fileName;
            log = new DataOutputStream(new FileOutputStream(file));
            if (log != null) {
              System.err.println("Open log file: " + file);
              isEnabled = true;
              writeHeader();
            } 
          } catch (Exception e) {
            System.err.println("Failed to open log file.");
          } 
        } 
      } 
    } 
  }
  
  private static synchronized boolean requestPerm() {
    try {
      if (!ieSec) {
        permission = "write file";
        permissionid = 4;
        jmfSecurity.requestPermission(m, cl, args, 4);
        m[0].invoke(cl[0], args[0]);
      } else {
        PolicyEngine.checkPermission(PermissionID.FILEIO);
        PolicyEngine.assertPermission(PermissionID.FILEIO);
      } 
    } catch (Exception e) {
      return false;
    } 
    return true;
  }
  
  private static synchronized void writeHeader() {
    if (jmfSecurity != null && !requestPerm())
      return; 
    write("#\n# JMF " + BasicPlayer.VERSION + "\n#\n");
    String os = null, osver = null, osarch = null;
    String java = null, jver = null;
    try {
      os = System.getProperty("os.name");
      osarch = System.getProperty("os.arch");
      osver = System.getProperty("os.version");
      java = System.getProperty("java.vendor");
      jver = System.getProperty("java.version");
    } catch (Throwable e) {
      return;
    } 
    if (os != null)
      comment("Platform: " + os + ", " + osarch + ", " + osver); 
    if (java != null)
      comment("Java VM: " + java + ", " + jver); 
    write("");
  }
  
  public static synchronized void comment(Object str) {
    if (isEnabled) {
      if (jmfSecurity != null && !requestPerm())
        return; 
      try {
        log.writeBytes("## " + str + "\n");
      } catch (IOException e) {}
    } 
  }
  
  public static synchronized void warning(Object str) {
    if (isEnabled) {
      if (jmfSecurity != null && !requestPerm())
        return; 
      try {
        log.writeBytes("!! " + str + "\n");
      } catch (IOException e) {}
    } 
  }
  
  public static synchronized void profile(Object str) {
    if (isEnabled) {
      if (jmfSecurity != null && !requestPerm())
        return; 
      try {
        log.writeBytes("$$ " + str + "\n");
      } catch (IOException e) {}
    } 
  }
  
  static boolean errorWarned = false;
  
  public static synchronized void error(Object str) {
    if (isEnabled) {
      if (jmfSecurity != null && !requestPerm())
        return; 
      if (!errorWarned) {
        System.err.println("An error has occurred.  Check jmf.log for details.");
        errorWarned = true;
      } 
      try {
        log.writeBytes("XX " + str + "\n");
      } catch (IOException e) {}
    } else {
      System.err.println(str);
    } 
  }
  
  public static synchronized void dumpStack(Throwable e) {
    if (isEnabled) {
      if (jmfSecurity != null && !requestPerm())
        return; 
      e.printStackTrace(new PrintWriter(log, true));
      write("");
    } else {
      e.printStackTrace();
    } 
  }
  
  public static synchronized void write(Object str) {
    if (isEnabled) {
      if (jmfSecurity != null && !requestPerm())
        return; 
      try {
        for (int i = indent; i > 0; i--)
          log.writeBytes("    "); 
        log.writeBytes(str + "\n");
      } catch (IOException e) {}
    } 
  }
  
  public static synchronized void setIndent(int i) {
    indent = i;
  }
  
  public static synchronized void incrIndent() {
    indent++;
  }
  
  public static synchronized void decrIndent() {
    indent--;
  }
  
  public static int getIndent() {
    return indent;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\Log.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */