/*     */ package com.sun.media;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.util.Registry;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Log
/*     */ {
/*     */   public static boolean isEnabled = true;
/*  27 */   private static DataOutputStream log = null;
/*  28 */   private static String fileName = "jmf.log";
/*  29 */   private static int indent = 0;
/*     */ 
/*     */   
/*  32 */   private static JMFSecurity jmfSecurity = null;
/*  33 */   private static Method[] m = new Method[1];
/*  34 */   private static Class[] cl = new Class[1];
/*  35 */   private static Object[][] args = new Object[1][0];
/*     */   private static boolean ieSec = false;
/*  37 */   private static String permission = null;
/*  38 */   private static int permissionid = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  45 */     synchronized (fileName) {
/*     */ 
/*     */       
/*  48 */       if (isEnabled && log == null) {
/*     */         
/*  50 */         Object llog = Registry.get("allowLogging");
/*     */ 
/*     */         
/*  53 */         if (llog != null && llog instanceof Boolean && 
/*  54 */           !((Boolean)llog).booleanValue()) {
/*  55 */           isEnabled = false;
/*     */         }
/*     */ 
/*     */         
/*  59 */         if (isEnabled) {
/*     */           try {
/*  61 */             jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  62 */             if (jmfSecurity != null)
/*     */             {
/*  64 */               if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  65 */                 permission = "write file";
/*  66 */                 permissionid = 4;
/*  67 */                 jmfSecurity.requestPermission(m, cl, args, 4);
/*  68 */                 m[0].invoke(cl[0], args[0]);
/*     */                 
/*  70 */                 permission = "delete file";
/*  71 */                 permissionid = 8;
/*  72 */                 jmfSecurity.requestPermission(m, cl, args, 8);
/*  73 */                 m[0].invoke(cl[0], args[0]);
/*  74 */                 permission = "read system property";
/*  75 */                 permissionid = 1;
/*  76 */                 jmfSecurity.requestPermission(m, cl, args, 1);
/*  77 */                 m[0].invoke(cl[0], args[0]);
/*  78 */               } else if (jmfSecurity.getName().startsWith("internet")) {
/*  79 */                 PolicyEngine.checkPermission(PermissionID.FILEIO);
/*  80 */                 PolicyEngine.assertPermission(PermissionID.FILEIO);
/*  81 */                 ieSec = true;
/*     */               }  } 
/*     */           } catch (Exception e) {
/*  84 */             isEnabled = false;
/*     */           } 
/*     */         }
/*     */         
/*  88 */         if (isEnabled) {
/*  89 */           isEnabled = false;
/*     */           try {
/*     */             String str1;
/*  92 */             Object ldir = Registry.get("secure.logDir");
/*  93 */             if (ldir != null && ldir instanceof String && !"".equals(ldir)) {
/*  94 */               str1 = (String)ldir;
/*     */             } else {
/*  96 */               str1 = System.getProperty("user.dir");
/*     */             } 
/*  98 */             String file = str1 + File.separator + fileName;
/*  99 */             log = new DataOutputStream(new FileOutputStream(file));
/* 100 */             if (log != null) {
/* 101 */               System.err.println("Open log file: " + file);
/* 102 */               isEnabled = true;
/* 103 */               writeHeader();
/*     */             } 
/*     */           } catch (Exception e) {
/* 106 */             System.err.println("Failed to open log file.");
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static synchronized boolean requestPerm() {
/*     */     try {
/* 118 */       if (!ieSec) {
/* 119 */         permission = "write file";
/* 120 */         permissionid = 4;
/* 121 */         jmfSecurity.requestPermission(m, cl, args, 4);
/* 122 */         m[0].invoke(cl[0], args[0]);
/*     */       } else {
/* 124 */         PolicyEngine.checkPermission(PermissionID.FILEIO);
/* 125 */         PolicyEngine.assertPermission(PermissionID.FILEIO);
/*     */       } 
/*     */     } catch (Exception e) {
/* 128 */       return false;
/*     */     } 
/* 130 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static synchronized void writeHeader() {
/* 136 */     if (jmfSecurity != null && !requestPerm()) {
/*     */       return;
/*     */     }
/* 139 */     write("#\n# JMF " + BasicPlayer.VERSION + "\n#\n");
/*     */     
/* 141 */     String os = null, osver = null, osarch = null;
/* 142 */     String java = null, jver = null;
/*     */     try {
/* 144 */       os = System.getProperty("os.name");
/* 145 */       osarch = System.getProperty("os.arch");
/* 146 */       osver = System.getProperty("os.version");
/* 147 */       java = System.getProperty("java.vendor");
/* 148 */       jver = System.getProperty("java.version");
/*     */     
/*     */     }
/* 151 */     catch (Throwable e) {
/*     */       return;
/*     */     } 
/* 154 */     if (os != null)
/* 155 */       comment("Platform: " + os + ", " + osarch + ", " + osver); 
/* 156 */     if (java != null)
/* 157 */       comment("Java VM: " + java + ", " + jver); 
/* 158 */     write("");
/*     */   }
/*     */ 
/*     */   
/*     */   public static synchronized void comment(Object str) {
/* 163 */     if (isEnabled) {
/*     */       
/* 165 */       if (jmfSecurity != null && !requestPerm()) {
/*     */         return;
/*     */       }
/*     */       try {
/* 169 */         log.writeBytes("## " + str + "\n");
/* 170 */       } catch (IOException e) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static synchronized void warning(Object str) {
/* 176 */     if (isEnabled) {
/*     */       
/* 178 */       if (jmfSecurity != null && !requestPerm()) {
/*     */         return;
/*     */       }
/*     */       try {
/* 182 */         log.writeBytes("!! " + str + "\n");
/* 183 */       } catch (IOException e) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static synchronized void profile(Object str) {
/* 189 */     if (isEnabled) {
/*     */       
/* 191 */       if (jmfSecurity != null && !requestPerm()) {
/*     */         return;
/*     */       }
/*     */       try {
/* 195 */         log.writeBytes("$$ " + str + "\n");
/* 196 */       } catch (IOException e) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean errorWarned = false;
/*     */   
/*     */   public static synchronized void error(Object str) {
/* 204 */     if (isEnabled) {
/*     */       
/* 206 */       if (jmfSecurity != null && !requestPerm()) {
/*     */         return;
/*     */       }
/* 209 */       if (!errorWarned) {
/* 210 */         System.err.println("An error has occurred.  Check jmf.log for details.");
/* 211 */         errorWarned = true;
/*     */       } 
/*     */       
/*     */       try {
/* 215 */         log.writeBytes("XX " + str + "\n");
/* 216 */       } catch (IOException e) {}
/*     */     } else {
/* 218 */       System.err.println(str);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static synchronized void dumpStack(Throwable e) {
/* 224 */     if (isEnabled) {
/*     */       
/* 226 */       if (jmfSecurity != null && !requestPerm()) {
/*     */         return;
/*     */       }
/* 229 */       e.printStackTrace(new PrintWriter(log, true));
/* 230 */       write("");
/*     */     } else {
/* 232 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static synchronized void write(Object str) {
/* 237 */     if (isEnabled) {
/*     */       
/* 239 */       if (jmfSecurity != null && !requestPerm()) {
/*     */         return;
/*     */       }
/*     */       try {
/* 243 */         for (int i = indent; i > 0; i--)
/* 244 */           log.writeBytes("    "); 
/* 245 */         log.writeBytes(str + "\n");
/* 246 */       } catch (IOException e) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static synchronized void setIndent(int i) {
/* 252 */     indent = i;
/*     */   }
/*     */ 
/*     */   
/*     */   public static synchronized void incrIndent() {
/* 257 */     indent++;
/*     */   }
/*     */ 
/*     */   
/*     */   public static synchronized void decrIndent() {
/* 262 */     indent--;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getIndent() {
/* 267 */     return indent;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\Log.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */