package com.sun.media;

import javax.media.Buffer;

public class BasicInputConnector extends BasicConnector implements InputConnector {
  protected OutputConnector outputConnector = null;
  
  private boolean reset = false;
  
  public OutputConnector getOutputConnector() {
    return this.outputConnector;
  }
  
  public void reset() {
    synchronized (this.circularBuffer) {
      this.reset = true;
      super.reset();
      this.circularBuffer.notifyAll();
    } 
  }
  
  public boolean isValidBufferAvailable() {
    return this.circularBuffer.canRead();
  }
  
  public Buffer getValidBuffer() {
    switch (this.protocol) {
      case 0:
        synchronized (this.circularBuffer) {
          if (!isValidBufferAvailable() && this.reset)
            return null; 
          this.reset = false;
          return this.circularBuffer.read();
        } 
      case 1:
        synchronized (this.circularBuffer) {
          this.reset = false;
          while (!this.reset && !isValidBufferAvailable()) {
            try {
              this.circularBuffer.wait();
            } catch (Exception e) {}
          } 
          if (this.reset)
            return null; 
          Buffer buffer = this.circularBuffer.read();
          this.circularBuffer.notifyAll();
          return buffer;
        } 
    } 
    throw new RuntimeException();
  }
  
  public void setOutputConnector(OutputConnector outputConnector) {
    this.outputConnector = outputConnector;
  }
  
  public void readReport() {
    switch (this.protocol) {
      case 0:
      case 1:
        synchronized (this.circularBuffer) {
          if (this.reset)
            return; 
          this.circularBuffer.readReport();
          this.circularBuffer.notifyAll();
          return;
        } 
    } 
    throw new RuntimeException();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\BasicInputConnector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */