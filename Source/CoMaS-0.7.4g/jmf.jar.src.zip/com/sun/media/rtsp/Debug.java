package com.sun.media.rtsp;

abstract class Debug {
  static boolean debug_enabled = false;
  
  public static void println(Object object) {
    if (debug_enabled)
      System.out.println(object); 
  }
  
  public static void dump(byte[] data) {
    if (debug_enabled)
      for (int i = 0; i < data.length; i++) {
        int value = data[i] & 0xFF;
        System.out.println(i + ": " + Integer.toHexString(value));
      }  
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\Debug.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */