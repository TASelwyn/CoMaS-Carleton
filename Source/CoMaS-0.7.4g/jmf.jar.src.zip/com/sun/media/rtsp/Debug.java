/*    */ package com.sun.media.rtsp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class Debug
/*    */ {
/*    */   static boolean debug_enabled = false;
/*    */   
/*    */   public static void println(Object object) {
/* 15 */     if (debug_enabled) {
/* 16 */       System.out.println(object);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void dump(byte[] data) {
/* 21 */     if (debug_enabled)
/* 22 */       for (int i = 0; i < data.length; i++) {
/* 23 */         int value = data[i] & 0xFF;
/*    */         
/* 25 */         System.out.println(i + ": " + Integer.toHexString(value));
/*    */       }  
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtsp\Debug.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */