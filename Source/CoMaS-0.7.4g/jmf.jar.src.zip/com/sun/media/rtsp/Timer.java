package com.sun.media.rtsp;

import java.util.Vector;

public class Timer extends Thread implements Runnable {
  private Vector listeners;
  
  private long duration;
  
  private boolean stopped;
  
  public Timer(TimerListener listener, long duration) {
    this.listeners = new Vector();
    this.duration = duration / 1000000L;
    addListener(listener);
    this.stopped = false;
  }
  
  public void reset() {}
  
  public void stopTimer() {
    this.stopped = true;
    synchronized (this) {
      notify();
    } 
  }
  
  public void run() {
    synchronized (this) {
      try {
        wait(this.duration);
      } catch (Exception e) {
        e.printStackTrace();
      } 
    } 
    if (!this.stopped)
      for (int i = 0; i < this.listeners.size(); i++) {
        TimerListener listener = this.listeners.elementAt(i);
        listener.timerExpired();
      }  
  }
  
  public void addListener(TimerListener listener) {
    this.listeners.addElement(listener);
  }
  
  public void removeListener(TimerListener listener) {
    this.listeners.removeElement(listener);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\Timer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */