package com.sun.media.rtsp;

import com.sun.media.rtsp.protocol.Message;

public interface RtspListener {
  void rtspMessageIndication(int paramInt, Message paramMessage);
  
  void rtspConnectionTerminated(int paramInt);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtsp\RtspListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */