package com.sun.media.rtsp.protocol;

public class TransportHeader {
  private String transportProtocol;
  
  private String profile;
  
  private String lowerTransport;
  
  private int server_data_port;
  
  private int server_control_port;
  
  public TransportHeader(String str) {
    int end = str.indexOf('/');
    this.transportProtocol = str.substring(0, end);
    int start = str.indexOf("client_port");
    if (start > 0);
    start = str.indexOf("server_port");
    if (start > 0) {
      String str1;
      start = str.indexOf("=", start) + 1;
      end = str.indexOf("-", start);
      String data_str = str.substring(start, end);
      this.server_data_port = (new Integer(data_str)).intValue();
      start = end + 1;
      end = str.indexOf(";", start);
      if (end > 0) {
        str1 = str.substring(start, end);
      } else {
        str1 = str.substring(start);
      } 
      this.server_control_port = (new Integer(str1)).intValue();
    } 
  }
  
  public String getTransportProtocol() {
    return this.transportProtocol;
  }
  
  public int getServerDataPort() {
    return this.server_data_port;
  }
  
  public int getServerControlPort() {
    return this.server_control_port;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\protocol\TransportHeader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */