package com.sun.media.rtsp.protocol;

import java.io.ByteArrayInputStream;
import java.util.Vector;

public class Request extends Parser {
  public RequestLine requestLine;
  
  public Vector headers;
  
  public Request(ByteArrayInputStream bin) {
    String line = getLine(bin);
    this.requestLine = new RequestLine(line);
    this.headers = new Vector();
    line = getLine(bin);
    while (line.length() > 0) {
      if (line.length() > 0) {
        Header header = new Header(line);
        this.headers.addElement(header);
        line = getLine(bin);
      } 
    } 
  }
  
  public RequestLine getRequestLine() {
    return this.requestLine;
  }
  
  public Header getHeader(int type) {
    Header header = null;
    for (int i = 0; i < this.headers.size(); i++) {
      Header tmpHeader = this.headers.elementAt(i);
      if (tmpHeader.type == type) {
        header = tmpHeader;
        break;
      } 
    } 
    return header;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\protocol\Request.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */