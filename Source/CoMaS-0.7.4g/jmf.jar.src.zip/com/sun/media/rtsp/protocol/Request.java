/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Request
/*    */   extends Parser
/*    */ {
/*    */   public RequestLine requestLine;
/*    */   public Vector headers;
/*    */   
/*    */   public Request(ByteArrayInputStream bin) {
/* 18 */     String line = getLine(bin);
/*    */     
/* 20 */     this.requestLine = new RequestLine(line);
/*    */     
/* 22 */     this.headers = new Vector();
/*    */     
/* 24 */     line = getLine(bin);
/*    */     
/* 26 */     while (line.length() > 0) {
/* 27 */       if (line.length() > 0) {
/* 28 */         Header header = new Header(line);
/*    */         
/* 30 */         this.headers.addElement(header);
/*    */         
/* 32 */         line = getLine(bin);
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public RequestLine getRequestLine() {
/* 38 */     return this.requestLine;
/*    */   }
/*    */   
/*    */   public Header getHeader(int type) {
/* 42 */     Header header = null;
/*    */     
/* 44 */     for (int i = 0; i < this.headers.size(); i++) {
/* 45 */       Header tmpHeader = this.headers.elementAt(i);
/*    */       
/* 47 */       if (tmpHeader.type == type) {
/* 48 */         header = tmpHeader;
/*    */         
/*    */         break;
/*    */       } 
/*    */     } 
/*    */     
/* 54 */     return header;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtsp\protocol\Request.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */