/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayMessage
/*    */   extends RequestMessage
/*    */ {
/*    */   public PlayMessage(byte[] data) {
/* 14 */     super(data);
/*    */   }
/*    */ 
/*    */   
/*    */   public PlayMessage(String url, int sequenceNumber, int sessionId, int range_lo, int range_hi) {
/* 19 */     String msg = "PLAY " + url + "RTSP/1.0" + "\r\n" + "CSeq: " + sequenceNumber + "\r\n" + "Session: " + sessionId + "\r\n" + "Range: npt=" + range_lo + "-" + range_hi;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtsp\protocol\PlayMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */