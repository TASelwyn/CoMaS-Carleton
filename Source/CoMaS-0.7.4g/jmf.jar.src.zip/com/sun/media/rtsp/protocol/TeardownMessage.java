/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TeardownMessage
/*    */   extends RequestMessage
/*    */ {
/*    */   public TeardownMessage(byte[] data) {
/* 14 */     super(data);
/*    */   }
/*    */   
/*    */   public TeardownMessage(String url, int sequenceNumber, int sessionId) {
/* 18 */     String msg = "TEARDOWN " + url + "RTSP/1.0" + "\r\n" + "CSeq: " + sequenceNumber + "\r\n" + "Session: " + sessionId + "\r\n";
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtsp\protocol\TeardownMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */