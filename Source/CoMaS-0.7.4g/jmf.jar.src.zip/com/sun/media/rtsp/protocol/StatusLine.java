package com.sun.media.rtsp.protocol;

import java.io.ByteArrayInputStream;

public class StatusLine extends Parser {
  private String protocol;
  
  private int code;
  
  private String reason;
  
  public StatusLine(String input) {
    ByteArrayInputStream bin = new ByteArrayInputStream(input.getBytes());
    String protocol = getToken(bin);
    Debug.println("protocol : " + protocol);
    this.code = (new Integer(getToken(bin))).intValue();
    Debug.println("code     : " + this.code);
    this.reason = getStringToken(bin);
    Debug.println("reason   : " + this.reason);
  }
  
  public String getReason() {
    return this.reason;
  }
  
  public int getCode() {
    return this.code;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\protocol\StatusLine.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */