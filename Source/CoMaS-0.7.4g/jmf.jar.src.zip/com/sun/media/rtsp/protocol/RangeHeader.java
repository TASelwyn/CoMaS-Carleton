package com.sun.media.rtsp.protocol;

public class RangeHeader {
  private long startPos;
  
  public RangeHeader(String str) {
    int start = str.indexOf('=') + 1;
    int end = str.indexOf('-');
    String startPosStr = str.substring(start, end);
    this.startPos = (new Long(startPosStr)).longValue();
  }
  
  public long getStartPos() {
    return this.startPos;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\protocol\RangeHeader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */