/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RangeHeader
/*    */ {
/*    */   private long startPos;
/*    */   
/*    */   public RangeHeader(String str) {
/* 16 */     int start = str.indexOf('=') + 1;
/* 17 */     int end = str.indexOf('-');
/*    */     
/* 19 */     String startPosStr = str.substring(start, end);
/*    */     
/* 21 */     this.startPos = (new Long(startPosStr)).longValue();
/*    */   }
/*    */   
/*    */   public long getStartPos() {
/* 25 */     return this.startPos;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtsp\protocol\RangeHeader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */