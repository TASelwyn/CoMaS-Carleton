package com.sun.media.rtsp.protocol;

public class PauseMessage extends RequestMessage {
  public PauseMessage(byte[] data) {
    super(data);
  }
  
  public PauseMessage(String url, int sequenceNumber, int sessionId) {
    String msg = "PAUSE " + url + "RTSP/1.0" + "\r\n" + "CSeq: " + sequenceNumber + "\r\n" + "Session: " + sessionId + "\r\n";
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\protocol\PauseMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */