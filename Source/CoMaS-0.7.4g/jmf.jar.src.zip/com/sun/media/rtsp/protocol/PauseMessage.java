package com.sun.media.rtsp.protocol;

public class PauseMessage extends RequestMessage {
  public PauseMessage(byte[] data) {
    super(data);
  }
  
  public PauseMessage(String url, int sequenceNumber, int sessionId) {
    String msg = "PAUSE " + url + "RTSP/1.0" + "\r\n" + "CSeq: " + sequenceNumber + "\r\n" + "Session: " + sessionId + "\r\n";
  }
}
