package com.sun.media.rtsp.protocol;

public class SessionHeader {
  private String sessionId;
  
  private long timeout;
  
  public SessionHeader(String str) {
    int index = str.indexOf(';');
    if (index > 0) {
      this.sessionId = str.substring(0, index);
      str = str.substring(index);
      index = str.indexOf('=');
      String seconds = str.substring(index + 1);
      try {
        this.timeout = (new Long(seconds)).longValue();
      } catch (NumberFormatException e) {
        this.timeout = 60L;
      } 
    } else {
      this.sessionId = str;
    } 
  }
  
  public String getSessionId() {
    return this.sessionId;
  }
  
  public long getTimeoutValue() {
    return this.timeout;
  }
}
