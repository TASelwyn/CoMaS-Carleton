/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SetupMessage
/*    */   extends RequestMessage
/*    */ {
/*    */   public SetupMessage(byte[] data) {
/* 14 */     super(data);
/*    */   }
/*    */   
/*    */   public SetupMessage(String url, int sequenceNumber, int port_lo, int port_hi) {
/* 18 */     String msg = "SETUP " + url + "RTSP/1.0" + "\r\n" + "CSeq: " + sequenceNumber + "\r\n" + "Transport: RTP/AVP;unicast;client_port=" + port_lo + "-" + port_hi;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtsp\protocol\SetupMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */