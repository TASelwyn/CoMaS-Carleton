/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DescribeMessage
/*    */   extends RequestMessage
/*    */ {
/*    */   public DescribeMessage(byte[] data) {
/* 14 */     super(data);
/*    */   }
/*    */   
/*    */   public DescribeMessage(String url, int sequenceNumber) {
/* 18 */     String msg = "DESCRIBE " + url + "RTSP/1.0" + "\r\n" + "CSeq: " + sequenceNumber + "\r\n\r\n";
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtsp\protocol\DescribeMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */