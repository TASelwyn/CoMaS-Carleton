package com.sun.media.rtsp.protocol;

import java.util.StringTokenizer;

public class Message {
  private byte[] data;
  
  private int type;
  
  private Object parameter;
  
  public Message(int type, Object parameter) {}
  
  public Message(byte[] data) {
    this.data = data;
    parseData();
  }
  
  private void parseData() {
    StringTokenizer st = new StringTokenizer(new String(this.data));
    this.type = (new MessageType(st.nextToken())).getType();
    switch (this.type) {
      case 1:
        this.parameter = new DescribeMessage(this.data);
        return;
      case 9:
        this.parameter = new SetupMessage(this.data);
        return;
      case 6:
        this.parameter = new PlayMessage(this.data);
        return;
      case 5:
        this.parameter = new PauseMessage(this.data);
        return;
      case 11:
        this.parameter = new TeardownMessage(this.data);
        return;
      case 4:
        this.parameter = new OptionsMessage(this.data);
        return;
      case 12:
        this.parameter = new ResponseMessage(this.data);
        return;
      case 10:
        this.parameter = new SetParameterMessage(this.data);
        return;
    } 
    Debug.println("Unknown msg type: " + this.type);
    Debug.println("Unknown msg type: " + new String(this.data));
  }
  
  public int getType() {
    return this.type;
  }
  
  public Object getParameter() {
    return this.parameter;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\protocol\Message.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */