/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ import java.util.StringTokenizer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Message
/*    */ {
/*    */   private byte[] data;
/*    */   private int type;
/*    */   private Object parameter;
/*    */   
/*    */   public Message(int type, Object parameter) {}
/*    */   
/*    */   public Message(byte[] data) {
/* 20 */     this.data = data;
/*    */     
/* 22 */     parseData();
/*    */   }
/*    */   
/*    */   private void parseData() {
/* 26 */     StringTokenizer st = new StringTokenizer(new String(this.data));
/*    */     
/* 28 */     this.type = (new MessageType(st.nextToken())).getType();
/*    */     
/* 30 */     switch (this.type) {
/*    */       case 1:
/* 32 */         this.parameter = new DescribeMessage(this.data);
/*    */         return;
/*    */       case 9:
/* 35 */         this.parameter = new SetupMessage(this.data);
/*    */         return;
/*    */       case 6:
/* 38 */         this.parameter = new PlayMessage(this.data);
/*    */         return;
/*    */       case 5:
/* 41 */         this.parameter = new PauseMessage(this.data);
/*    */         return;
/*    */       case 11:
/* 44 */         this.parameter = new TeardownMessage(this.data);
/*    */         return;
/*    */       case 4:
/* 47 */         this.parameter = new OptionsMessage(this.data);
/*    */         return;
/*    */       case 12:
/* 50 */         this.parameter = new ResponseMessage(this.data);
/*    */         return;
/*    */       case 10:
/* 53 */         this.parameter = new SetParameterMessage(this.data);
/*    */         return;
/*    */     } 
/* 56 */     Debug.println("Unknown msg type: " + this.type);
/* 57 */     Debug.println("Unknown msg type: " + new String(this.data));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getType() {
/* 63 */     return this.type;
/*    */   }
/*    */   
/*    */   public Object getParameter() {
/* 67 */     return this.parameter;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtsp\protocol\Message.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */