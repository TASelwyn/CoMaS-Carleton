package com.sun.media.rtsp.protocol;

public class DurationHeader {
  private long duration;
  
  public DurationHeader(String str) {
    this.duration = (new Long(str)).longValue();
  }
  
  public long getDuration() {
    return this.duration;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\protocol\DurationHeader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */