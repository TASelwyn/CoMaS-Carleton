package com.sun.media.rtsp.protocol;

public class DurationHeader {
  private long duration;
  
  public DurationHeader(String str) {
    this.duration = (new Long(str)).longValue();
  }
  
  public long getDuration() {
    return this.duration;
  }
}
