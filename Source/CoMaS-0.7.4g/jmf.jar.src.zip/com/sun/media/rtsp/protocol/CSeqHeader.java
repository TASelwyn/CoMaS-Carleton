package com.sun.media.rtsp.protocol;

public class CSeqHeader {
  private String sequence_number;
  
  public CSeqHeader(String number) {
    this.sequence_number = number;
  }
  
  public String getSequenceNumber() {
    return this.sequence_number;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\protocol\CSeqHeader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */