package com.sun.media.rtsp;

public interface TimerListener {
  void timerExpired();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\TimerListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */