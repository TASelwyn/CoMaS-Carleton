package com.sun.media.rtsp;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class Server extends Thread {
  private RtspManager rtspManager;
  
  private ServerSocket serverSocket;
  
  public Server(RtspManager rtspManager) {
    this.rtspManager = rtspManager;
    try {
      this.serverSocket = new ServerSocket(RtspPort.getPort());
      System.err.println("Server Socket: " + this.serverSocket.toString());
      this.serverSocket.getInetAddress();
      System.err.println("Socket is connected to: " + InetAddress.getLocalHost());
      System.err.println("Local port: " + this.serverSocket.getLocalPort());
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
  
  public void run() {
    Debug.println("Server running...");
    if (this.serverSocket == null)
      return; 
    while (true) {
      try {
        Debug.println("accepting...");
        Socket socket = this.serverSocket.accept();
        this.rtspManager.addConnection(socket);
      } catch (IOException e) {
        e.printStackTrace();
      } 
    } 
  }
  
  public void shutdown() {
    try {
      Debug.println("...closing server socket");
      this.serverSocket.close();
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\Server.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */