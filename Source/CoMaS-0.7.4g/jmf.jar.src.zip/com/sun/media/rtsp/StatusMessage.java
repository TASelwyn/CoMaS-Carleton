package com.sun.media.rtsp;

public abstract class StatusMessage {
  public static final int INVALID_ADDRESS = 1;
  
  public static final int SERVER_DOWN = 2;
  
  public static final int TIMEOUT = 3;
  
  public static final int NOT_FOUND = 4;
  
  public static final int PLAYING = 5;
  
  public static final int PAUSING = 6;
  
  public static final int END_REACHED = 7;
  
  public static final int READY = 8;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\StatusMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */