package com.sun.media.rtsp;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class Connection extends Thread implements Runnable {
  public int connectionId;
  
  private Socket socket;
  
  private RtspManager rtspManager;
  
  private MessageProcessor mp;
  
  private boolean connectionIsAlive;
  
  public Connection(RtspManager rtspManager, int connectionId, byte[] dstAddress, int port) throws UnknownHostException, ConnectException {
    this.rtspManager = rtspManager;
    this.connectionId = connectionId;
    String domain = new String(dstAddress);
    InetAddress dst = InetAddress.getByName(domain);
    try {
      this.socket = new Socket(dst, port);
      start();
    } catch (IOException e) {
      throw new ConnectException();
    } 
  }
  
  public Connection(RtspManager rtspManager, int connectionId, Socket socket) {
    this.rtspManager = rtspManager;
    this.connectionId = connectionId;
    this.socket = socket;
    start();
  }
  
  public boolean sendData(byte[] message) {
    boolean success = false;
    try {
      OutputStream out = this.socket.getOutputStream();
      out.write(message);
      out.flush();
      success = true;
    } catch (IOException e) {}
    return success;
  }
  
  public void run() {
    this.connectionIsAlive = true;
    while (this.connectionIsAlive) {
      try {
        InputStream in = this.socket.getInputStream();
        DataInputStream din = new DataInputStream(in);
        byte ch = din.readByte();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        baos.write(ch);
        while (!eomReached(baos.toByteArray()))
          baos.write(din.readByte()); 
        int length = getContentLength(new String(baos.toByteArray()));
        for (int i = 0; i < length; i++)
          baos.write(din.readByte()); 
        if (this.mp == null)
          this.mp = new MessageProcessor(this.connectionId, this.rtspManager); 
        this.mp.processMessage(baos.toByteArray());
      } catch (Exception e) {
        this.connectionIsAlive = false;
      } 
    } 
  }
  
  private boolean eomReached(byte[] buffer) {
    boolean endReached = false;
    int size = buffer.length;
    if (size >= 4 && 
      buffer[size - 4] == 13 && buffer[size - 3] == 10 && buffer[size - 2] == 13 && buffer[size - 1] == 10)
      endReached = true; 
    return endReached;
  }
  
  private int getContentLength(String msg_header) {
    int i, start = msg_header.indexOf("Content-length");
    if (start == -1)
      start = msg_header.indexOf("Content-Length"); 
    if (start == -1) {
      i = 0;
    } else {
      start = msg_header.indexOf(':', start) + 2;
      int end = msg_header.indexOf('\r', start);
      String length_str = msg_header.substring(start, end);
      i = (new Integer(length_str)).intValue();
    } 
    return i;
  }
  
  public void cleanup() {
    Debug.println("RTSP::Connection:cleanup, id=" + this.connectionId);
    close();
    this.rtspManager.removeConnection(this.connectionId);
  }
  
  public void close() {
    this.connectionIsAlive = false;
    try {
      if (this.socket != null) {
        this.socket.close();
        this.socket = null;
      } 
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
  
  public String getIpAddress() {
    return this.socket.getInetAddress().getHostAddress();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\Connection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */