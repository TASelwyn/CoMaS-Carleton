package com.sun.media.rtsp;

import com.sun.media.Log;
import com.sun.media.rtsp.protocol.Message;

public class MessageProcessor {
  private int connectionId;
  
  private RtspManager rtspManager;
  
  private byte[] buffer;
  
  public MessageProcessor(int connectionId, RtspManager rtspManager) {
    this.connectionId = connectionId;
    this.rtspManager = rtspManager;
    this.buffer = new byte[0];
  }
  
  public void processMessage(byte[] data) {
    Log.comment("incoming msg:");
    Log.comment(new String(data));
    Message message = new Message(data);
    this.rtspManager.dataIndication(this.connectionId, message);
  }
}
