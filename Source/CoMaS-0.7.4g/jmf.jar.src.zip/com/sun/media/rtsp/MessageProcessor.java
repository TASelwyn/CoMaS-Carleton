package com.sun.media.rtsp;

import com.sun.media.Log;
import com.sun.media.rtsp.protocol.Message;

public class MessageProcessor {
  private int connectionId;
  
  private RtspManager rtspManager;
  
  private byte[] buffer;
  
  public MessageProcessor(int connectionId, RtspManager rtspManager) {
    this.connectionId = connectionId;
    this.rtspManager = rtspManager;
    this.buffer = new byte[0];
  }
  
  public void processMessage(byte[] data) {
    Log.comment("incoming msg:");
    Log.comment(new String(data));
    Message message = new Message(data);
    this.rtspManager.dataIndication(this.connectionId, message);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\MessageProcessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */