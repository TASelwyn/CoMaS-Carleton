package com.sun.media.rtsp;

import com.sun.media.Log;
import com.sun.media.rtsp.protocol.Message;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Vector;

public class RtspManager {
  private Vector listeners;
  
  private int connectionCounter;
  
  private Vector connections;
  
  private String address;
  
  private int port;
  
  public RtspManager() {
    this.listeners = new Vector();
    this.connections = new Vector();
    Server server = new Server(this);
    server.start();
  }
  
  public RtspManager(boolean server_socket) {
    this.listeners = new Vector();
    this.connections = new Vector();
    if (server_socket) {
      Server server = new Server(this);
      server.start();
    } 
  }
  
  public boolean sendMessage(int connectionId, String message) {
    boolean bool;
    Log.comment("outgoing msg:");
    Log.comment(message);
    Connection connection = getConnection(connectionId);
    if (connection == null) {
      bool = false;
    } else {
      bool = connection.sendData(message.getBytes());
    } 
    return bool;
  }
  
  public void dataIndication(int connectionId, Message message) {
    for (int i = 0; i < this.listeners.size(); i++) {
      RtspListener listener = this.listeners.elementAt(i);
      listener.rtspMessageIndication(connectionId, message);
    } 
  }
  
  public void addListener(RtspListener listener) {
    this.listeners.addElement(listener);
  }
  
  public void removeListener(RtspListener listener) {
    this.listeners.removeElement(listener);
  }
  
  public int createConnection(String address, int port) {
    this.address = address;
    this.port = port;
    int connectionId = -1;
    try {
      Connection connection = new Connection(this, this.connectionCounter + 1, address.getBytes(), port);
      this.connections.addElement(connection);
      connectionId = connection.connectionId;
      this.connectionCounter++;
    } catch (UnknownHostException e) {
      Log.error("[EXCEPTION]: Unknown host.");
      connectionId = -2;
    } catch (ConnectException e) {
      Log.error("[EXCEPTION]: Can't connect to server.");
      connectionId = -3;
    } 
    return connectionId;
  }
  
  public void addConnection(Socket socket) {
    this.connectionCounter++;
    Connection connection = new Connection(this, this.connectionCounter, socket);
    this.connections.addElement(connection);
  }
  
  public void removeConnection(int connectionId) {
    Connection connection = getConnection(connectionId);
    this.connections.removeElement(connection);
    for (int i = 0; i < this.listeners.size(); i++) {
      RtspListener listener = this.listeners.elementAt(i);
      listener.rtspConnectionTerminated(connectionId);
    } 
  }
  
  public void closeConnection(int connectionId) {
    Connection connection = getConnection(connectionId);
    if (connection != null) {
      connection.close();
      this.connections.removeElement(connection);
    } else {
      System.out.println("connection not found!");
    } 
  }
  
  public Connection getConnection(int connectionId) {
    Connection connection = null;
    for (int i = 0; i < this.connections.size(); i++) {
      Connection tmpConnection = this.connections.elementAt(i);
      if (tmpConnection.connectionId == connectionId) {
        connection = tmpConnection;
        break;
      } 
    } 
    return connection;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtsp\RtspManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */