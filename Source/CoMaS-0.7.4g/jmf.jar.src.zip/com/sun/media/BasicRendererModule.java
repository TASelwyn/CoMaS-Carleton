/*      */ package com.sun.media;
/*      */ 
/*      */ import com.ms.security.PermissionID;
/*      */ import com.ms.security.PolicyEngine;
/*      */ import com.sun.media.renderer.audio.AudioRenderer;
/*      */ import com.sun.media.rtp.util.RTPTimeBase;
/*      */ import com.sun.media.rtp.util.RTPTimeReporter;
/*      */ import com.sun.media.util.ElapseTime;
/*      */ import com.sun.media.util.jdk12;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Method;
/*      */ import javax.media.Buffer;
/*      */ import javax.media.Clock;
/*      */ import javax.media.Drainable;
/*      */ import javax.media.Format;
/*      */ import javax.media.Prefetchable;
/*      */ import javax.media.Renderer;
/*      */ import javax.media.ResourceUnavailableException;
/*      */ import javax.media.format.AudioFormat;
/*      */ import javax.media.format.VideoFormat;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BasicRendererModule
/*      */   extends BasicSinkModule
/*      */   implements RTPTimeReporter
/*      */ {
/*      */   protected PlaybackEngine engine;
/*      */   protected Renderer renderer;
/*      */   protected InputConnector ic;
/*   43 */   protected int framesPlayed = 0;
/*   44 */   protected float frameRate = 30.0F;
/*      */   
/*      */   protected boolean framesWereBehind = false;
/*      */   protected boolean prefetching = false;
/*      */   protected boolean started = false;
/*      */   private boolean opened = false;
/*   50 */   private int chunkSize = Integer.MAX_VALUE;
/*   51 */   private long prefetchedAudioDuration = 0L;
/*   52 */   private long lastDuration = 0L;
/*      */   
/*   54 */   private RTPTimeBase rtpTimeBase = null;
/*      */   
/*   56 */   private String rtpCNAME = null;
/*      */   
/*      */   RenderThread renderThread;
/*      */   
/*   60 */   private static JMFSecurity jmfSecurity = null;
/*      */   private static boolean securityPrivelege = false;
/*   62 */   private Method[] m = new Method[1];
/*   63 */   private Class[] cl = new Class[1];
/*   64 */   private Object[][] args = new Object[1][0];
/*   65 */   private Object prefetchSync = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   74 */   private ElapseTime elapseTime = new ElapseTime(); private long LEEWAY; private long lastRendered; private boolean failed; private boolean notToDropNext; private Buffer storedBuffer;
/*      */   
/*      */   static {
/*      */     try {
/*   78 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*   79 */       securityPrivelege = true;
/*   80 */     } catch (SecurityException e) {}
/*      */   }
/*      */   private boolean checkRTP; private boolean noSync; final float MAX_RATE = 1.05F;
/*      */   final float RATE_INCR = 0.01F;
/*      */   final int FLOW_LIMIT = 20;
/*      */   boolean overMsg;
/*      */   int overflown;
/*      */   float rate;
/*      */   long systemErr;
/*      */   static final long RTP_TIME_MARGIN = 2000000000L;
/*      */   boolean rtpErrMsg;
/*      */   long lastTimeStamp;
/*      */   static final int MAX_CHUNK_SIZE = 16;
/*      */   AudioFormat ulawFormat;
/*      */   AudioFormat linearFormat;
/*      */   
/*      */   public boolean isThreaded() {
/*   97 */     return true;
/*      */   }
/*      */   
/*      */   public boolean doRealize() {
/*  101 */     this.chunkSize = computeChunkSize(this.ic.getFormat());
/*      */     
/*  103 */     if (jmfSecurity != null) {
/*  104 */       String permission = null;
/*      */       try {
/*  106 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  107 */           permission = "thread";
/*  108 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/*  109 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*      */           
/*  111 */           permission = "thread group";
/*  112 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/*  113 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*  114 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/*  115 */           PolicyEngine.checkPermission(PermissionID.THREAD);
/*  116 */           PolicyEngine.assertPermission(PermissionID.THREAD);
/*      */         }
/*      */       
/*  119 */       } catch (Throwable e) {
/*      */ 
/*      */ 
/*      */         
/*  123 */         securityPrivelege = false;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  129 */     if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*      */       
/*      */       try {
/*  132 */         Constructor cons = CreateWorkThreadAction.cons;
/*  133 */         this.renderThread = (RenderThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { RenderThread.class, BasicRendererModule.class, this }) });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  142 */       catch (Exception e) {}
/*      */     } else {
/*      */       
/*  145 */       this.renderThread = new RenderThread(this);
/*      */     } 
/*      */     
/*  148 */     this.engine = (PlaybackEngine)getController();
/*      */     
/*  150 */     return true;
/*      */   }
/*      */   
/*      */   public boolean doPrefetch() {
/*  154 */     super.doPrefetch();
/*  155 */     if (!this.opened) {
/*      */       try {
/*  157 */         this.renderer.open();
/*      */       } catch (ResourceUnavailableException e) {
/*  159 */         this.prefetchFailed = true;
/*  160 */         return false;
/*      */       } 
/*  162 */       this.prefetchFailed = false;
/*  163 */       this.opened = true;
/*      */     } 
/*      */ 
/*      */     
/*  167 */     if (!((PlaybackEngine)this.controller).prefetchEnabled) {
/*  168 */       return true;
/*      */     }
/*  170 */     this.prefetching = true;
/*      */ 
/*      */ 
/*      */     
/*  174 */     this.renderThread.start();
/*      */     
/*  176 */     return true;
/*      */   }
/*      */   
/*      */   public void doFailedPrefetch() {
/*  180 */     this.renderThread.pause();
/*  181 */     this.renderer.close();
/*  182 */     this.opened = false;
/*  183 */     this.prefetching = false;
/*      */   }
/*      */   
/*      */   public void abortPrefetch() {
/*  187 */     this.renderThread.pause();
/*  188 */     this.renderer.close();
/*  189 */     this.prefetching = false;
/*  190 */     this.opened = false;
/*      */   }
/*      */   
/*      */   public void doStart() {
/*  194 */     super.doStart();
/*      */     
/*  196 */     if (!(this.renderer instanceof Clock))
/*  197 */       this.renderer.start(); 
/*  198 */     this.prerolling = false;
/*  199 */     this.started = true;
/*      */     
/*  201 */     synchronized (this.prefetchSync) {
/*  202 */       this.prefetching = false;
/*  203 */       this.renderThread.start();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void doStop() {
/*  208 */     this.started = false;
/*  209 */     this.prefetching = true;
/*  210 */     super.doStop();
/*      */     
/*  212 */     if (this.renderer != null && !(this.renderer instanceof Clock))
/*  213 */       this.renderer.stop(); 
/*      */   }
/*      */   
/*      */   public void doDealloc() {
/*  217 */     this.renderer.close();
/*      */   }
/*      */   
/*      */   public void doClose() {
/*  221 */     this.renderThread.kill();
/*  222 */     if (this.renderer != null)
/*  223 */       this.renderer.close(); 
/*  224 */     if (this.rtpTimeBase != null) {
/*  225 */       RTPTimeBase.remove(this, this.rtpCNAME);
/*  226 */       this.rtpTimeBase = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void reset() {
/*  231 */     super.reset();
/*  232 */     this.prefetching = false;
/*      */   }
/*      */   
/*      */   public void triggerReset() {
/*  236 */     if (this.renderer != null) {
/*  237 */       this.renderer.reset();
/*      */     }
/*  239 */     synchronized (this.prefetchSync) {
/*  240 */       this.prefetching = false;
/*      */ 
/*      */ 
/*      */       
/*  244 */       if (this.resetted)
/*  245 */         this.renderThread.start(); 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void doneReset() {
/*  250 */     this.renderThread.pause();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean reinitRenderer(Format input) {
/*  257 */     if (this.renderer != null && 
/*  258 */       this.renderer.setInputFormat(input) != null)
/*      */     {
/*  260 */       return true;
/*      */     }
/*      */ 
/*      */     
/*  264 */     if (this.started) {
/*  265 */       this.renderer.stop();
/*  266 */       this.renderer.reset();
/*      */     } 
/*      */     
/*  269 */     this.renderer.close();
/*  270 */     this.renderer = null;
/*      */     
/*      */     Renderer r;
/*  273 */     if ((r = SimpleGraphBuilder.findRenderer(input)) == null) {
/*  274 */       return false;
/*      */     }
/*  276 */     setRenderer(r);
/*  277 */     if (this.started) {
/*  278 */       this.renderer.start();
/*      */     }
/*  280 */     this.chunkSize = computeChunkSize(input);
/*      */     
/*  282 */     return true;
/*      */   }
/*      */   
/*      */   protected void setRenderer(Renderer r) {
/*  286 */     this.renderer = r;
/*  287 */     if (this.renderer instanceof Clock)
/*  288 */       setClock((Clock)this.renderer); 
/*      */   }
/*      */   
/*      */   public Renderer getRenderer() {
/*  292 */     return this.renderer;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void process() {}
/*      */ 
/*      */   
/*      */   protected BasicRendererModule(Renderer r)
/*      */   {
/*  301 */     this.LEEWAY = 10L;
/*  302 */     this.lastRendered = 0L;
/*  303 */     this.failed = false;
/*  304 */     this.notToDropNext = false;
/*  305 */     this.storedBuffer = null;
/*      */     
/*  307 */     this.checkRTP = false;
/*  308 */     this.noSync = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  630 */     this.MAX_RATE = 1.05F;
/*  631 */     this.RATE_INCR = 0.01F;
/*  632 */     this.FLOW_LIMIT = 20;
/*  633 */     this.overMsg = false;
/*  634 */     this.overflown = 10;
/*  635 */     this.rate = 1.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  914 */     this.systemErr = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  999 */     this.rtpErrMsg = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1076 */     this.ulawFormat = new AudioFormat("ULAW");
/* 1077 */     this.linearFormat = new AudioFormat("LINEAR"); setRenderer(r); this.ic = new BasicInputConnector(); if (r instanceof javax.media.renderer.VideoRenderer) {
/*      */       this.ic.setSize(4);
/*      */     } else {
/*      */       this.ic.setSize(1);
/* 1081 */     }  this.ic.setModule(this); registerInputConnector("input", this.ic); setProtocol(1); } private int computeChunkSize(Format format) { if (format instanceof AudioFormat && (this.ulawFormat.matches(format) || this.linearFormat.matches(format))) {
/*      */ 
/*      */       
/* 1084 */       AudioFormat af = (AudioFormat)format;
/* 1085 */       int units = af.getSampleSizeInBits() * af.getChannels() / 8;
/* 1086 */       if (units == 0)
/* 1087 */         units = 1; 
/* 1088 */       int chunks = (int)af.getSampleRate() * units / 16;
/*      */ 
/*      */       
/* 1091 */       return chunks / units * units;
/*      */     } 
/*      */     
/* 1094 */     return Integer.MAX_VALUE; }
/*      */ 
/*      */   
/*      */   protected boolean doProcess() {
/*      */     Buffer buffer;
/*      */     if ((this.started || this.prefetching) && this.stopTime > -1L && this.elapseTime.value >= this.stopTime) {
/*      */       if (this.renderer instanceof Drainable)
/*      */         ((Drainable)this.renderer).drain(); 
/*      */       doStop();
/*      */       if (this.moduleListener != null)
/*      */         this.moduleListener.stopAtTime(this); 
/*      */     } 
/*      */     if (this.storedBuffer != null) {
/*      */       buffer = this.storedBuffer;
/*      */     } else {
/*      */       buffer = this.ic.getValidBuffer();
/*      */     } 
/*      */     if (!this.checkRTP)
/*      */       if ((buffer.getFlags() & 0x1000) != 0) {
/*      */         String key = this.engine.getCNAME();
/*      */         if (key != null) {
/*      */           this.rtpTimeBase = RTPTimeBase.find(this, key);
/*      */           this.rtpCNAME = key;
/*      */           if (this.ic.getFormat() instanceof AudioFormat) {
/*      */             Log.comment("RTP master time set: " + this.renderer + "\n");
/*      */             this.rtpTimeBase.setMaster(this);
/*      */           } 
/*      */           this.checkRTP = true;
/*      */           this.noSync = false;
/*      */         } else {
/*      */           this.noSync = true;
/*      */         } 
/*      */       } else {
/*      */         this.checkRTP = true;
/*      */       }  
/*      */     this.lastTimeStamp = buffer.getTimeStamp();
/*      */     if (this.failed || this.resetted) {
/*      */       if ((buffer.getFlags() & 0x200) != 0) {
/*      */         this.resetted = false;
/*      */         this.renderThread.pause();
/*      */         if (this.moduleListener != null)
/*      */           this.moduleListener.resetted(this); 
/*      */       } 
/*      */       this.storedBuffer = null;
/*      */       this.ic.readReport();
/*      */       return true;
/*      */     } 
/*      */     if (PlaybackEngine.DEBUG)
/*      */       this.jmd.moduleIn(this, 0, buffer, true); 
/*      */     boolean rtn = scheduleBuffer(buffer);
/*      */     if (this.storedBuffer == null && buffer.isEOM()) {
/*      */       if (this.prefetching)
/*      */         donePrefetch(); 
/*      */       if ((buffer.getFlags() & 0x40) == 0 && buffer.getTimeStamp() > 0L && buffer.getDuration() > 0L && buffer.getFormat() != null && !(buffer.getFormat() instanceof AudioFormat) && !this.noSync)
/*      */         waitForPT(buffer.getTimeStamp() + this.lastDuration); 
/*      */       this.storedBuffer = null;
/*      */       this.ic.readReport();
/*      */       if (PlaybackEngine.DEBUG)
/*      */         this.jmd.moduleIn(this, 0, buffer, false); 
/*      */       doStop();
/*      */       if (this.moduleListener != null)
/*      */         this.moduleListener.mediaEnded(this); 
/*      */       return true;
/*      */     } 
/*      */     if (this.storedBuffer == null)
/*      */       this.ic.readReport(); 
/*      */     if (PlaybackEngine.DEBUG)
/*      */       this.jmd.moduleIn(this, 0, buffer, false); 
/*      */     return rtn;
/*      */   }
/*      */   
/*      */   protected boolean scheduleBuffer(Buffer buf) {
/*      */     int rc = 0;
/*      */     Format format = buf.getFormat();
/*      */     if (format == null) {
/*      */       format = this.ic.getFormat();
/*      */       buf.setFormat(format);
/*      */     } 
/*      */     if (format != this.ic.getFormat() && !format.equals(this.ic.getFormat()) && !buf.isDiscard())
/*      */       if (!handleFormatChange(format))
/*      */         return false;  
/*      */     if ((buf.getFlags() & 0x400) != 0 && this.moduleListener != null) {
/*      */       this.moduleListener.markedDataArrived(this, buf);
/*      */       buf.setFlags(buf.getFlags() & 0xFFFFFBFF);
/*      */     } 
/*      */     if (this.prefetching || format instanceof AudioFormat || buf.getTimeStamp() <= 0L || (buf.getFlags() & 0x60) == 96 || this.noSync) {
/*      */       if (!buf.isDiscard())
/*      */         rc = processBuffer(buf); 
/*      */     } else {
/*      */       long mt = getSyncTime(buf.getTimeStamp());
/*      */       long lateBy = mt / 1000000L - buf.getTimeStamp() / 1000000L - getLatency() / 1000000L;
/*      */       if (this.storedBuffer == null && lateBy > 0L) {
/*      */         if (buf.isDiscard()) {
/*      */           this.notToDropNext = true;
/*      */         } else {
/*      */           if (buf.isEOM()) {
/*      */             this.notToDropNext = true;
/*      */           } else if (this.moduleListener != null && format instanceof VideoFormat) {
/*      */             float fb = (float)lateBy * this.frameRate / 1000.0F;
/*      */             if (fb < 1.0F)
/*      */               fb = 1.0F; 
/*      */             this.moduleListener.framesBehind(this, fb, this.ic);
/*      */             this.framesWereBehind = true;
/*      */           } 
/*      */           if ((buf.getFlags() & 0x20) != 0) {
/*      */             rc = processBuffer(buf);
/*      */           } else if (lateBy < this.LEEWAY || this.notToDropNext || buf.getTimeStamp() - this.lastRendered > 1000000000L) {
/*      */             rc = processBuffer(buf);
/*      */             this.lastRendered = buf.getTimeStamp();
/*      */             this.notToDropNext = false;
/*      */           } 
/*      */         } 
/*      */       } else {
/*      */         if (this.moduleListener != null && this.framesWereBehind && format instanceof VideoFormat) {
/*      */           this.moduleListener.framesBehind(this, 0.0F, this.ic);
/*      */           this.framesWereBehind = false;
/*      */         } 
/*      */         if (!buf.isDiscard()) {
/*      */           if ((buf.getFlags() & 0x40) == 0)
/*      */             waitForPT(buf.getTimeStamp()); 
/*      */           if (!this.resetted) {
/*      */             rc = processBuffer(buf);
/*      */             this.lastRendered = buf.getTimeStamp();
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     if ((rc & 0x1) != 0) {
/*      */       this.storedBuffer = null;
/*      */     } else if ((rc & 0x2) != 0) {
/*      */       this.storedBuffer = buf;
/*      */     } else {
/*      */       this.storedBuffer = null;
/*      */       if (buf.getDuration() >= 0L)
/*      */         this.lastDuration = buf.getDuration(); 
/*      */     } 
/*      */     return true;
/*      */   }
/*      */   
/*      */   public int processBuffer(Buffer buffer) {
/*      */     int remain = buffer.getLength();
/*      */     int offset = buffer.getOffset();
/*      */     int rc = 0;
/*      */     boolean isEOM = false;
/*      */     if (this.renderer instanceof Clock) {
/*      */       if ((buffer.getFlags() & 0x2000) != 0) {
/*      */         this.overflown++;
/*      */       } else {
/*      */         this.overflown--;
/*      */       } 
/*      */       if (this.overflown > 20) {
/*      */         if (this.rate < 1.05F) {
/*      */           this.rate += 0.01F;
/*      */           this.renderer.stop();
/*      */           ((Clock)this.renderer).setRate(this.rate);
/*      */           this.renderer.start();
/*      */           if (!this.overMsg) {
/*      */             Log.comment("Data buffers overflown.  Adjust rendering speed up to 5 % to compensate");
/*      */             this.overMsg = true;
/*      */           } 
/*      */         } 
/*      */         this.overflown = 10;
/*      */       } else if (this.overflown <= 0) {
/*      */         if (this.rate > 1.0F) {
/*      */           this.rate -= 0.01F;
/*      */           this.renderer.stop();
/*      */           ((Clock)this.renderer).setRate(this.rate);
/*      */           this.renderer.start();
/*      */         } 
/*      */         this.overflown = 10;
/*      */       } 
/*      */     } 
/*      */     do {
/*      */       int i;
/*      */       if (this.stopTime > -1L && this.elapseTime.value >= this.stopTime) {
/*      */         if (this.prefetching)
/*      */           donePrefetch(); 
/*      */         return 2;
/*      */       } 
/*      */       if (remain <= this.chunkSize || this.prerolling) {
/*      */         if (isEOM) {
/*      */           isEOM = false;
/*      */           buffer.setEOM(true);
/*      */         } 
/*      */         i = remain;
/*      */       } else {
/*      */         if (buffer.isEOM()) {
/*      */           isEOM = true;
/*      */           buffer.setEOM(false);
/*      */         } 
/*      */         i = this.chunkSize;
/*      */       } 
/*      */       buffer.setLength(i);
/*      */       buffer.setOffset(offset);
/*      */       if (this.prerolling && !handlePreroll(buffer)) {
/*      */         offset += i;
/*      */         remain -= i;
/*      */       } else {
/*      */         try {
/*      */           rc = this.renderer.process(buffer);
/*      */         } catch (Throwable e) {
/*      */           Log.dumpStack(e);
/*      */           if (this.moduleListener != null)
/*      */             this.moduleListener.internalErrorOccurred(this); 
/*      */         } 
/*      */         if ((rc & 0x8) != 0) {
/*      */           this.failed = true;
/*      */           if (this.moduleListener != null)
/*      */             this.moduleListener.pluginTerminated(this); 
/*      */           return rc;
/*      */         } 
/*      */         if ((rc & 0x1) != 0) {
/*      */           buffer.setDiscard(true);
/*      */           if (this.prefetching)
/*      */             donePrefetch(); 
/*      */           return rc;
/*      */         } 
/*      */         if ((rc & 0x2) != 0)
/*      */           i -= buffer.getLength(); 
/*      */         offset += i;
/*      */         remain -= i;
/*      */         if (this.prefetching && (!(this.renderer instanceof Prefetchable) || ((Prefetchable)this.renderer).isPrefetched())) {
/*      */           isEOM = false;
/*      */           buffer.setEOM(false);
/*      */           donePrefetch();
/*      */           break;
/*      */         } 
/*      */         this.elapseTime.update(i, buffer.getTimeStamp(), buffer.getFormat());
/*      */       } 
/*      */     } while (remain > 0 && !this.resetted);
/*      */     if (isEOM)
/*      */       buffer.setEOM(true); 
/*      */     buffer.setLength(remain);
/*      */     buffer.setOffset(offset);
/*      */     if (rc == 0)
/*      */       this.framesPlayed++; 
/*      */     return rc;
/*      */   }
/*      */   
/*      */   private boolean handleFormatChange(Format format) {
/*      */     if (!reinitRenderer(format)) {
/*      */       this.storedBuffer = null;
/*      */       this.failed = true;
/*      */       if (this.moduleListener != null)
/*      */         this.moduleListener.formatChangedFailure(this, this.ic.getFormat(), format); 
/*      */       return false;
/*      */     } 
/*      */     Format oldFormat = this.ic.getFormat();
/*      */     this.ic.setFormat(format);
/*      */     if (this.moduleListener != null)
/*      */       this.moduleListener.formatChanged(this, oldFormat, format); 
/*      */     if (format instanceof VideoFormat) {
/*      */       float fr = ((VideoFormat)format).getFrameRate();
/*      */       if (fr != -1.0F)
/*      */         this.frameRate = fr; 
/*      */     } 
/*      */     return true;
/*      */   }
/*      */   
/*      */   private void donePrefetch() {
/*      */     synchronized (this.prefetchSync) {
/*      */       if (!this.started && this.prefetching)
/*      */         this.renderThread.pause(); 
/*      */       this.prefetching = false;
/*      */     } 
/*      */     if (this.moduleListener != null)
/*      */       this.moduleListener.bufferPrefetched(this); 
/*      */   }
/*      */   
/*      */   public void setPreroll(long wanted, long actual) {
/*      */     super.setPreroll(wanted, actual);
/*      */     this.elapseTime.setValue(actual);
/*      */   }
/*      */   
/*      */   protected boolean handlePreroll(Buffer buf) {
/*      */     if (buf.getFormat() instanceof AudioFormat) {
/*      */       if (!hasReachAudioPrerollTarget(buf))
/*      */         return false; 
/*      */     } else if ((buf.getFlags() & 0x60) == 0 && buf.getTimeStamp() >= 0L) {
/*      */       if (buf.getTimeStamp() < getSyncTime(buf.getTimeStamp()))
/*      */         return false; 
/*      */     } 
/*      */     this.prerolling = false;
/*      */     return true;
/*      */   }
/*      */   
/*      */   private boolean hasReachAudioPrerollTarget(Buffer buf) {
/*      */     long target = getSyncTime(buf.getTimeStamp());
/*      */     this.elapseTime.update(buf.getLength(), buf.getTimeStamp(), buf.getFormat());
/*      */     if (this.elapseTime.value >= target) {
/*      */       long remain = ElapseTime.audioTimeToLen(this.elapseTime.value - target, (AudioFormat)buf.getFormat());
/*      */       int offset = buf.getOffset() + buf.getLength() - (int)remain;
/*      */       if (offset >= 0) {
/*      */         buf.setOffset(offset);
/*      */         buf.setLength((int)remain);
/*      */       } 
/*      */       this.elapseTime.setValue(target);
/*      */       return true;
/*      */     } 
/*      */     return false;
/*      */   }
/*      */   
/*      */   private boolean waitForPT(long pt) {
/*      */     long mt = getSyncTime(pt);
/*      */     long lastAheadBy = -1L;
/*      */     int beenHere = 0;
/*      */     long aheadBy = (pt - mt) / 1000000L;
/*      */     if (this.rate != 1.0F)
/*      */       aheadBy = (long)((float)aheadBy / this.rate); 
/*      */     while (aheadBy > this.systemErr && !this.resetted) {
/*      */       if (aheadBy == lastAheadBy) {
/*      */         l1 = aheadBy + (5 * beenHere);
/*      */         if (l1 > 33L) {
/*      */           l1 = 33L;
/*      */         } else {
/*      */           beenHere++;
/*      */         } 
/*      */       } else {
/*      */         l1 = aheadBy;
/*      */         beenHere = 0;
/*      */       } 
/*      */       long l1 = (l1 > 125L) ? 125L : l1;
/*      */       long before = System.currentTimeMillis();
/*      */       l1 -= this.systemErr;
/*      */       try {
/*      */         if (l1 > 0L) {
/*      */           Thread.currentThread();
/*      */           Thread.sleep(l1);
/*      */         } 
/*      */       } catch (InterruptedException e) {}
/*      */       long slept = System.currentTimeMillis() - before;
/*      */       this.systemErr = (slept - l1 + this.systemErr) / 2L;
/*      */       if (this.systemErr < 0L) {
/*      */         this.systemErr = 0L;
/*      */       } else if (this.systemErr > l1) {
/*      */         this.systemErr = l1;
/*      */       } 
/*      */       mt = getSyncTime(pt);
/*      */       lastAheadBy = aheadBy;
/*      */       aheadBy = (pt - mt) / 1000000L;
/*      */       if (this.rate != 1.0F)
/*      */         aheadBy = (long)((float)aheadBy / this.rate); 
/*      */       if (getState() != 600)
/*      */         break; 
/*      */     } 
/*      */     return true;
/*      */   }
/*      */   
/*      */   private long getSyncTime(long pts) {
/*      */     if (this.rtpTimeBase != null) {
/*      */       if (this.rtpTimeBase.getMaster() == getController())
/*      */         return pts; 
/*      */       long ts = this.rtpTimeBase.getNanoseconds();
/*      */       if (ts > pts + 2000000000L || ts < pts - 2000000000L) {
/*      */         if (!this.rtpErrMsg) {
/*      */           Log.comment("Cannot perform RTP sync beyond a difference of: " + ((ts - pts) / 1000000L) + " msecs.\n");
/*      */           this.rtpErrMsg = true;
/*      */         } 
/*      */         return pts;
/*      */       } 
/*      */       return ts;
/*      */     } 
/*      */     return getMediaNanoseconds();
/*      */   }
/*      */   
/*      */   public long getRTPTime() {
/*      */     if (this.ic.getFormat() instanceof AudioFormat) {
/*      */       if (this.renderer instanceof AudioRenderer)
/*      */         return this.lastTimeStamp - ((AudioRenderer)this.renderer).getLatency(); 
/*      */       return this.lastTimeStamp;
/*      */     } 
/*      */     return this.lastTimeStamp;
/*      */   }
/*      */   
/*      */   public Object[] getControls() {
/*      */     return this.renderer.getControls();
/*      */   }
/*      */   
/*      */   public Object getControl(String s) {
/*      */     return this.renderer.getControl(s);
/*      */   }
/*      */   
/*      */   public void setFormat(Connector connector, Format format) {
/*      */     this.renderer.setInputFormat(format);
/*      */     if (format instanceof VideoFormat) {
/*      */       float fr = ((VideoFormat)format).getFrameRate();
/*      */       if (fr != -1.0F)
/*      */         this.frameRate = fr; 
/*      */     } 
/*      */   }
/*      */   
/*      */   public int getFramesPlayed() {
/*      */     return this.framesPlayed;
/*      */   }
/*      */   
/*      */   public void resetFramesPlayed() {
/*      */     this.framesPlayed = 0;
/*      */   }
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\BasicRendererModule.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */