package com.sun.media;

import javax.media.Buffer;

public interface InputConnector extends Connector {
  OutputConnector getOutputConnector();
  
  void setOutputConnector(OutputConnector paramOutputConnector);
  
  boolean isValidBufferAvailable();
  
  Buffer getValidBuffer();
  
  void readReport();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\InputConnector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */