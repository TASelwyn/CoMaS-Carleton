/*     */ package com.sun.media.renderer.audio.device;
/*     */ 
/*     */ import com.sun.media.Log;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioSystem;
/*     */ import javax.sound.sampled.BooleanControl;
/*     */ import javax.sound.sampled.DataLine;
/*     */ import javax.sound.sampled.FloatControl;
/*     */ import javax.sound.sampled.Line;
/*     */ import javax.sound.sampled.Mixer;
/*     */ import javax.sound.sampled.SourceDataLine;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaSoundOutput
/*     */   implements AudioOutput
/*     */ {
/*  20 */   static Mixer mixer = null;
/*  21 */   static Object initSync = new Object();
/*     */   
/*     */   protected SourceDataLine dataLine;
/*     */   
/*     */   protected FloatControl gc;
/*     */   
/*     */   protected FloatControl rc;
/*     */   
/*     */   protected BooleanControl mc;
/*     */   
/*     */   protected boolean paused = true;
/*     */   
/*     */   protected int bufSize;
/*     */   protected AudioFormat format;
/*     */   long lastPos;
/*     */   long originPos;
/*     */   long totalCount;
/*     */   
/*     */   public boolean initialize(AudioFormat format, int bufSize) {
/*  40 */     synchronized (initSync) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  45 */       AudioFormat afmt = convertFormat(format);
/*     */ 
/*     */ 
/*     */       
/*  49 */       DataLine.Info info = new DataLine.Info(SourceDataLine.class, afmt, bufSize);
/*     */ 
/*     */       
/*     */       try {
/*  53 */         if (!AudioSystem.isLineSupported(info)) {
/*  54 */           Log.warning("DataLine not supported: " + format);
/*  55 */           return false;
/*     */         } 
/*     */         
/*  58 */         this.dataLine = (SourceDataLine)AudioSystem.getLine(info);
/*  59 */         this.dataLine.open(afmt, bufSize);
/*     */       } catch (Exception e) {
/*     */         
/*  62 */         Log.warning("Cannot open audio device: " + e);
/*  63 */         return false;
/*     */       } 
/*     */       
/*  66 */       this.format = format;
/*  67 */       this.bufSize = bufSize;
/*     */       
/*  69 */       if (this.dataLine == null) {
/*  70 */         Log.warning("JavaSound unsupported format: " + format);
/*  71 */         return false;
/*     */       } 
/*     */       
/*     */       try {
/*  75 */         this.gc = (FloatControl)this.dataLine.getControl(FloatControl.Type.MASTER_GAIN);
/*  76 */         this.mc = (BooleanControl)this.dataLine.getControl(BooleanControl.Type.MUTE);
/*     */       } catch (Exception e) {
/*  78 */         Log.warning("JavaSound: No gain control");
/*     */       } 
/*     */       
/*     */       try {
/*  82 */         this.rc = (FloatControl)this.dataLine.getControl(FloatControl.Type.SAMPLE_RATE);
/*     */       } catch (Exception e) {
/*  84 */         Log.warning("JavaSound: No rate control");
/*     */       } 
/*     */       
/*  87 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  94 */     this.dataLine.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public void finalize() throws Throwable {
/*  99 */     super.finalize();
/* 100 */     dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   public void pause() {
/* 105 */     if (this.dataLine != null)
/* 106 */       this.dataLine.stop(); 
/* 107 */     this.paused = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resume() {
/* 112 */     if (this.dataLine != null)
/* 113 */       this.dataLine.start(); 
/* 114 */     this.paused = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void drain() {
/* 120 */     this.dataLine.drain();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {
/* 126 */     this.dataLine.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public AudioFormat getFormat() {
/* 131 */     return this.format;
/*     */   }
/*     */   public JavaSoundOutput() {
/* 134 */     this.lastPos = 0L;
/* 135 */     this.originPos = 0L;
/* 136 */     this.totalCount = 0L;
/*     */   }
/*     */   public long getMediaNanoseconds() {
/* 139 */     if (this.dataLine == null || this.format == null) {
/* 140 */       return 0L;
/*     */     }
/* 142 */     long pos = this.dataLine.getFramePosition();
/*     */     
/* 144 */     if (pos < this.lastPos) {
/*     */       
/* 146 */       this.totalCount += this.lastPos - this.originPos;
/* 147 */       this.originPos = pos;
/*     */     } 
/*     */     
/* 150 */     this.lastPos = pos;
/*     */     
/* 152 */     return (long)(((this.totalCount + pos - this.originPos) * 1000L) / this.format.getSampleRate() * 1000000.0D);
/*     */   }
/*     */   
/*     */   public void setGain(double g) {
/* 156 */     if (this.gc != null) {
/* 157 */       this.gc.setValue((float)g);
/*     */     }
/*     */   }
/*     */   
/*     */   public double getGain() {
/* 162 */     return (this.gc != null) ? this.gc.getValue() : 0.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMute(boolean m) {
/* 167 */     if (this.mc != null) {
/* 168 */       this.mc.setValue(m);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean getMute() {
/* 173 */     return (this.mc != null) ? this.mc.getValue() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public float setRate(float r) {
/* 178 */     if (this.rc == null) {
/* 179 */       return 1.0F;
/*     */     }
/* 181 */     float rate = (float)(r * this.format.getSampleRate());
/*     */     
/* 183 */     if (rate > this.rc.getMaximum() || rate < this.rc.getMinimum()) {
/* 184 */       return getRate();
/*     */     }
/* 186 */     this.rc.setValue(rate);
/*     */     
/* 188 */     return r;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getRate() {
/* 193 */     if (this.rc == null)
/* 194 */       return 1.0F; 
/* 195 */     return (float)(this.rc.getValue() / this.format.getSampleRate());
/*     */   }
/*     */ 
/*     */   
/*     */   public int bufferAvailable() {
/* 200 */     return this.dataLine.available();
/*     */   }
/*     */ 
/*     */   
/*     */   public int write(byte[] data, int off, int len) {
/* 205 */     return this.dataLine.write(data, off, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isOpen() {
/* 210 */     Mixer mixer = AudioSystem.getMixer(null);
/* 211 */     Line[] lines = mixer.getSourceLines();
/*     */     
/* 213 */     return (lines != null && lines.length > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AudioFormat convertFormat(AudioFormat fmt) {
/*     */     String str;
/* 222 */     AudioFormat.Encoding type = fmt.getEncoding();
/*     */ 
/*     */     
/* 225 */     if (type == AudioFormat.Encoding.PCM_SIGNED || type == AudioFormat.Encoding.PCM_UNSIGNED) {
/*     */       
/* 227 */       str = "LINEAR";
/* 228 */     } else if (type == AudioFormat.Encoding.ALAW) {
/* 229 */       str = "alaw";
/* 230 */     } else if (type == AudioFormat.Encoding.ULAW) {
/* 231 */       str = "ULAW";
/*     */     } else {
/* 233 */       str = null;
/*     */     } 
/* 235 */     return new AudioFormat(str, fmt.getSampleRate(), fmt.getSampleSizeInBits(), fmt.getChannels(), fmt.isBigEndian() ? 1 : 0, (type == AudioFormat.Encoding.PCM_SIGNED) ? 1 : 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AudioFormat convertFormat(AudioFormat fmt) {
/* 255 */     return new AudioFormat((fmt.getSampleRate() == -1.0D) ? 8000.0F : (float)fmt.getSampleRate(), (fmt.getSampleSizeInBits() == -1) ? 16 : fmt.getSampleSizeInBits(), (fmt.getChannels() == -1) ? 1 : fmt.getChannels(), (fmt.getSigned() == 1), (fmt.getEndian() == 1));
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\renderer\audio\device\JavaSoundOutput.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */