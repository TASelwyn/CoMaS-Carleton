/*     */ package com.sun.media.renderer.audio;
/*     */ 
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.MediaTimeBase;
/*     */ import com.sun.media.renderer.audio.device.AudioOutput;
/*     */ import java.awt.Component;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Clock;
/*     */ import javax.media.ClockStoppedException;
/*     */ import javax.media.Control;
/*     */ import javax.media.Drainable;
/*     */ import javax.media.Format;
/*     */ import javax.media.GainControl;
/*     */ import javax.media.IncompatibleTimeBaseException;
/*     */ import javax.media.Owned;
/*     */ import javax.media.Prefetchable;
/*     */ import javax.media.Renderer;
/*     */ import javax.media.Time;
/*     */ import javax.media.TimeBase;
/*     */ import javax.media.control.BufferControl;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AudioRenderer
/*     */   extends BasicPlugIn
/*     */   implements Renderer, Prefetchable, Drainable, Clock
/*     */ {
/*     */   Format[] supportedFormats;
/*     */   protected AudioFormat inputFormat;
/*     */   protected AudioFormat devFormat;
/*  33 */   protected AudioOutput device = null;
/*  34 */   protected TimeBase timeBase = null;
/*     */   
/*     */   protected boolean started = false;
/*     */   
/*     */   protected boolean prefetched = false;
/*     */   protected boolean resetted = false;
/*     */   protected boolean devicePaused = true;
/*     */   protected GainControl gainControl;
/*     */   protected BufferControl bufferControl;
/*  43 */   protected Control peakVolumeMeter = null;
/*     */   
/*  45 */   protected long bytesWritten = 0L;
/*     */   
/*     */   protected int bytesPerSec;
/*  48 */   private Object writeLock = new Object();
/*     */   long mediaTimeAnchor;
/*     */   long startTime;
/*     */   long stopTime;
/*     */   long ticksSinceLastReset;
/*     */   float rate;
/*     */   TimeBase master;
/*     */   
/*     */   public Format[] getSupportedInputFormats() {
/*  57 */     return this.supportedFormats;
/*     */   }
/*     */   
/*     */   public Format setInputFormat(Format format) {
/*  61 */     for (int i = 0; i < this.supportedFormats.length; i++) {
/*  62 */       if (this.supportedFormats[i].matches(format)) {
/*  63 */         this.inputFormat = (AudioFormat)format;
/*  64 */         return format;
/*     */       } 
/*     */     } 
/*  67 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/*  72 */     stop();
/*  73 */     if (this.device != null) {
/*  74 */       pauseDevice();
/*  75 */       this.device.flush();
/*  76 */       this.mediaTimeAnchor = getMediaNanoseconds();
/*  77 */       this.ticksSinceLastReset = 0L;
/*  78 */       this.device.dispose();
/*     */     } 
/*  80 */     this.device = null;
/*     */   }
/*     */   
/*     */   public void reset() {
/*  84 */     this.resetted = true;
/*     */ 
/*     */     
/*  87 */     this.mediaTimeAnchor = getMediaNanoseconds();
/*     */     
/*  89 */     if (this.device != null) {
/*  90 */       this.device.flush();
/*  91 */       this.ticksSinceLastReset = this.device.getMediaNanoseconds();
/*     */     } else {
/*  93 */       this.ticksSinceLastReset = 0L;
/*     */     } 
/*  95 */     this.prefetched = false;
/*     */   }
/*     */ 
/*     */   
/*     */   synchronized void pauseDevice() {
/* 100 */     if (!this.devicePaused && this.device != null) {
/* 101 */       this.device.pause();
/* 102 */       this.devicePaused = true;
/*     */     } 
/* 104 */     if (this.timeBase instanceof AudioTimeBase) {
/* 105 */       ((AudioTimeBase)this.timeBase).mediaStopped();
/*     */     }
/*     */   }
/*     */   
/*     */   synchronized void resumeDevice() {
/* 110 */     if (this.timeBase instanceof AudioTimeBase)
/* 111 */       ((AudioTimeBase)this.timeBase).mediaStarted(); 
/* 112 */     if (this.devicePaused && this.device != null) {
/* 113 */       this.device.resume();
/* 114 */       this.devicePaused = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void start() {
/* 120 */     syncStart(getTimeBase().getTime());
/*     */   }
/*     */   
/*     */   public synchronized void drain() {
/* 124 */     if (this.started && this.device != null)
/* 125 */       this.device.drain(); 
/* 126 */     this.prefetched = false;
/*     */   }
/*     */   
/*     */   public int process(Buffer buffer) {
/* 130 */     int rtn = processData(buffer);
/* 131 */     if (buffer.isEOM() && rtn != 2) {
/*     */       
/* 133 */       drain();
/* 134 */       pauseDevice();
/*     */     } 
/* 136 */     return rtn;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean checkInput(Buffer buffer) {
/* 141 */     Format format = buffer.getFormat();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     if (this.device == null || this.devFormat == null || !this.devFormat.equals(format)) {
/* 148 */       if (!initDevice((AudioFormat)format)) {
/*     */         
/* 150 */         buffer.setDiscard(true);
/* 151 */         return false;
/*     */       } 
/* 153 */       this.devFormat = (AudioFormat)format;
/*     */     } 
/*     */     
/* 156 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int processData(Buffer buffer) {
/* 161 */     if (!checkInput(buffer)) {
/* 162 */       return 1;
/*     */     }
/* 164 */     return doProcessData(buffer);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int doProcessData(Buffer buffer) {
/* 169 */     byte[] data = (byte[])buffer.getData();
/* 170 */     int remain = buffer.getLength();
/* 171 */     int off = buffer.getOffset();
/* 172 */     int len = 0;
/*     */     
/* 174 */     synchronized (this) {
/* 175 */       if (!this.started) {
/*     */ 
/*     */         
/* 178 */         if (!this.devicePaused) {
/* 179 */           pauseDevice();
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 186 */         this.resetted = false;
/*     */         
/* 188 */         int available = this.device.bufferAvailable();
/*     */         
/* 190 */         if (available > remain) {
/* 191 */           available = remain;
/*     */         }
/* 193 */         if (available > 0) {
/* 194 */           len = this.device.write(data, off, available);
/* 195 */           this.bytesWritten += len;
/*     */         } 
/*     */         
/* 198 */         buffer.setLength(remain - len);
/* 199 */         if (buffer.getLength() > 0 || buffer.isEOM()) {
/* 200 */           buffer.setOffset(off + len);
/* 201 */           this.prefetched = true;
/* 202 */           return 2;
/*     */         } 
/* 204 */         return 0;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 211 */     synchronized (this.writeLock) {
/*     */       
/* 213 */       if (this.devicePaused) {
/* 214 */         return 2;
/*     */       }
/*     */       try {
/* 217 */         while (remain > 0 && !this.resetted) {
/*     */ 
/*     */ 
/*     */           
/* 221 */           len = this.device.write(data, off, remain);
/* 222 */           this.bytesWritten += len;
/* 223 */           off += len; remain -= len;
/*     */         } 
/*     */       } catch (NullPointerException e) {
/* 226 */         return 0;
/*     */       } 
/*     */     } 
/*     */     
/* 230 */     buffer.setLength(0);
/* 231 */     buffer.setOffset(0);
/*     */     
/* 233 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean initDevice(AudioFormat format) {
/* 238 */     if (format == null) {
/* 239 */       System.err.println("AudioRenderer: ERROR: Unknown AudioFormat");
/* 240 */       return false;
/*     */     } 
/*     */     
/* 243 */     if (format.getSampleRate() == -1.0D || format.getSampleSizeInBits() == -1) {
/*     */       
/* 245 */       Log.error("Cannot initialize audio renderer with format: " + format);
/* 246 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 250 */     if (this.device != null) {
/*     */       
/* 252 */       this.device.drain();
/* 253 */       pauseDevice();
/*     */ 
/*     */ 
/*     */       
/* 257 */       this.mediaTimeAnchor = getMediaNanoseconds();
/* 258 */       this.ticksSinceLastReset = 0L;
/*     */       
/* 260 */       this.device.dispose();
/* 261 */       this.device = null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 275 */     AudioFormat audioFormat = new AudioFormat(format.getEncoding(), format.getSampleRate(), format.getSampleSizeInBits(), format.getChannels(), format.getEndian(), format.getSigned());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 285 */     this.device = createDevice(audioFormat);
/*     */     
/* 287 */     if (this.device == null || !this.device.initialize(audioFormat, computeBufferSize(audioFormat))) {
/*     */       
/* 289 */       this.device = null;
/* 290 */       return false;
/*     */     } 
/*     */     
/* 293 */     this.device.setMute(this.gainControl.getMute());
/* 294 */     this.device.setGain(this.gainControl.getDB());
/*     */     
/* 296 */     if (this.rate != 1.0F && 
/* 297 */       this.rate != this.device.setRate(this.rate)) {
/* 298 */       System.err.println("The AudioRenderer does not support the given rate: " + this.rate);
/* 299 */       this.device.setRate(1.0F);
/*     */     } 
/*     */ 
/*     */     
/* 303 */     if (this.started) {
/* 304 */       resumeDevice();
/*     */     }
/* 306 */     this.bytesPerSec = (int)(format.getSampleRate() * format.getChannels() * format.getSampleSizeInBits() / 8.0D);
/*     */ 
/*     */     
/* 309 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processByWaiting(Buffer buffer) {
/* 316 */     synchronized (this) {
/*     */ 
/*     */       
/* 319 */       if (!this.started) {
/* 320 */         this.prefetched = true;
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 325 */     AudioFormat format = (AudioFormat)buffer.getFormat();
/*     */ 
/*     */     
/* 328 */     int sampleRate = (int)format.getSampleRate();
/* 329 */     int sampleSize = format.getSampleSizeInBits();
/* 330 */     int channels = format.getChannels();
/*     */ 
/*     */ 
/*     */     
/* 334 */     long duration = (buffer.getLength() * 1000 / sampleSize / 8 * sampleRate * channels);
/*     */     
/* 336 */     int timeToWait = (int)((float)duration / getRate());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 346 */       Thread.currentThread(); Thread.sleep(timeToWait);
/* 347 */     } catch (Exception e) {}
/*     */     
/* 349 */     buffer.setLength(0);
/* 350 */     buffer.setOffset(0);
/*     */     
/* 352 */     this.mediaTimeAnchor += duration * 1000000L;
/*     */   }
/*     */   
/*     */   public Object[] getControls() {
/* 356 */     Control[] c = { (Control)this.gainControl, (Control)this.bufferControl };
/*     */ 
/*     */ 
/*     */     
/* 360 */     return (Object[])c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPrefetched() {
/* 370 */     return this.prefetched;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AudioRenderer() {
/* 380 */     this.mediaTimeAnchor = 0L;
/* 381 */     this.startTime = Long.MAX_VALUE;
/* 382 */     this.stopTime = Long.MAX_VALUE;
/* 383 */     this.ticksSinceLastReset = 0L;
/* 384 */     this.rate = 1.0F;
/*     */ 
/*     */     
/* 387 */     this.master = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 531 */     this.bufLenReq = 200L; this.timeBase = (TimeBase)new AudioTimeBase(this, this); this.bufferControl = new BC(this, this);
/*     */   }
/*     */   public void setTimeBase(TimeBase master) throws IncompatibleTimeBaseException { if (!(master instanceof AudioTimeBase)) Log.warning("AudioRenderer cannot be controlled by time bases other than its own: " + master);  this.master = master; }
/*     */   public synchronized void syncStart(Time at) { this.started = true; this.prefetched = true; this.resetted = false; resumeDevice(); this.startTime = at.getNanoseconds(); }
/*     */   public synchronized void stop() { this.started = false; this.prefetched = false; synchronized (this.writeLock) { pauseDevice(); }  }
/*     */   public void setStopTime(Time t) { this.stopTime = t.getNanoseconds(); }
/*     */   public Time getStopTime() { return new Time(this.stopTime); } public void setMediaTime(Time now) { this.mediaTimeAnchor = now.getNanoseconds(); } public Time getMediaTime() { return new Time(getMediaNanoseconds()); } public long getMediaNanoseconds() { return this.mediaTimeAnchor + ((this.device != null) ? this.device.getMediaNanoseconds() : 0L) - this.ticksSinceLastReset; } public long getLatency() { long ts = this.bytesWritten * 1000L / this.bytesPerSec * 1000000L; return ts - getMediaNanoseconds(); } public Time getSyncTime() { return new Time(0L); } public TimeBase getTimeBase() { if (this.master != null) return this.master;  return this.timeBase; } public Time mapToTimeBase(Time t) throws ClockStoppedException { return new Time((long)((float)(t.getNanoseconds() - this.mediaTimeAnchor) / this.rate) + this.startTime); } public float getRate() { return this.rate; } public float setRate(float factor) { if (this.device != null) { this.rate = this.device.setRate(factor); } else { this.rate = 1.0F; }  return this.rate; } public int computeBufferSize(AudioFormat f) { long l1, bytesPerSecond = (long)(f.getSampleRate() * f.getChannels() * f.getSampleSizeInBits() / 8.0D); if (this.bufLenReq < DefaultMinBufferSize) { l1 = DefaultMinBufferSize; } else if (this.bufLenReq > DefaultMaxBufferSize) { l1 = DefaultMaxBufferSize; } else { l1 = this.bufLenReq; }  float r = (float)l1 / 1000.0F; long bufSize = (long)((float)bytesPerSecond * r); return (int)bufSize; } class AudioTimeBase extends MediaTimeBase {
/*     */     AudioRenderer renderer; private final AudioRenderer this$0; AudioTimeBase(AudioRenderer this$0, AudioRenderer r) { this.this$0 = this$0; this.renderer = r; } public long getMediaTime() { if (this.this$0.rate == 1.0F || this.this$0.rate == 0.0F) return (this.this$0.device != null) ? this.this$0.device.getMediaNanoseconds() : 0L;  return (long)(((this.this$0.device != null) ? (float)this.this$0.device.getMediaNanoseconds() : 0.0F) / this.this$0.rate); }
/*     */   } static int DefaultMinBufferSize = 62; static int DefaultMaxBufferSize = 4000; long bufLenReq; protected abstract AudioOutput createDevice(AudioFormat paramAudioFormat); class BC implements BufferControl, Owned {
/* 540 */     AudioRenderer renderer; BC(AudioRenderer this$0, AudioRenderer ar) { this.this$0 = this$0;
/* 541 */       this.renderer = ar; }
/*     */     
/*     */     private final AudioRenderer this$0;
/*     */     public long getBufferLength() {
/* 545 */       return this.this$0.bufLenReq;
/*     */     }
/*     */     
/*     */     public long setBufferLength(long time) {
/* 549 */       if (time < AudioRenderer.DefaultMinBufferSize) {
/* 550 */         this.this$0.bufLenReq = AudioRenderer.DefaultMinBufferSize;
/* 551 */       } else if (time > AudioRenderer.DefaultMaxBufferSize) {
/* 552 */         this.this$0.bufLenReq = AudioRenderer.DefaultMaxBufferSize;
/*     */       } else {
/* 554 */         this.this$0.bufLenReq = time;
/*     */       } 
/* 556 */       return this.this$0.bufLenReq;
/*     */     }
/*     */     
/*     */     public long getMinimumThreshold() {
/* 560 */       return 0L;
/*     */     }
/*     */     
/*     */     public long setMinimumThreshold(long time) {
/* 564 */       return 0L;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setEnabledThreshold(boolean b) {}
/*     */     
/*     */     public boolean getEnabledThreshold() {
/* 571 */       return false;
/*     */     }
/*     */     
/*     */     public Component getControlComponent() {
/* 575 */       return null;
/*     */     }
/*     */     
/*     */     public Object getOwner() {
/* 579 */       return this.renderer;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\renderer\audio\AudioRenderer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */