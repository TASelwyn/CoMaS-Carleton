/*     */ package com.sun.media.renderer.audio;
/*     */ 
/*     */ import com.sun.media.ExclusiveUse;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import com.sun.media.SimpleGraphBuilder;
/*     */ import com.sun.media.controls.GainControlAdapter;
/*     */ import com.sun.media.renderer.audio.device.AudioOutput;
/*     */ import com.sun.media.renderer.audio.device.JavaSoundOutput;
/*     */ import java.awt.Canvas;
/*     */ import java.awt.Checkbox;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Panel;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Codec;
/*     */ import javax.media.Control;
/*     */ import javax.media.Format;
/*     */ import javax.media.GainControl;
/*     */ import javax.media.Owned;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ public class JavaSoundRenderer
/*     */   extends AudioRenderer
/*     */   implements ExclusiveUse
/*     */ {
/*  29 */   static String NAME = "JavaSound Renderer";
/*     */   Codec ulawDecoder;
/*     */   Format ulawOutputFormat;
/*     */   Format ulawFormat;
/*     */   Format linearFormat;
/*  34 */   static int METERHEIGHT = 4;
/*     */   static boolean available = false;
/*     */   
/*     */   static {
/*  38 */     String javaVersion = null;
/*  39 */     String subver = null;
/*     */     
/*     */     try {
/*     */       byte b;
/*  43 */       javaVersion = System.getProperty("java.version");
/*  44 */       if (javaVersion.length() < 3) {
/*  45 */         b = javaVersion.length();
/*     */       } else {
/*  47 */         b = 3;
/*  48 */       }  subver = javaVersion.substring(0, b);
/*     */     } catch (Throwable t) {
/*  50 */       javaVersion = null;
/*  51 */       subver = null;
/*     */     } 
/*     */     
/*  54 */     if (subver == null || subver.compareTo("1.3") < 0) {
/*     */       try {
/*  56 */         JMFSecurityManager.loadLibrary("jmutil");
/*  57 */         JMFSecurityManager.loadLibrary("jsound");
/*  58 */         available = true;
/*  59 */       } catch (Throwable t) {}
/*     */     } else {
/*     */       
/*  62 */       available = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaSoundRenderer() {
/*  69 */     if (!available) {
/*  70 */       throw new UnsatisfiedLinkError("No JavaSound library");
/*     */     }
/*  72 */     this.ulawFormat = (Format)new AudioFormat("ULAW");
/*     */     
/*  74 */     this.linearFormat = (Format)new AudioFormat("LINEAR");
/*     */     
/*  76 */     this.supportedFormats = new Format[2];
/*  77 */     this.supportedFormats[0] = this.linearFormat;
/*  78 */     this.supportedFormats[1] = this.ulawFormat;
/*     */     
/*  80 */     this.gainControl = (GainControl)new GCA(this, this);
/*  81 */     this.peakVolumeMeter = new PeakVolumeMeter(this, this);
/*     */   }
/*     */   
/*     */   public String getName() {
/*  85 */     return NAME;
/*     */   }
/*     */ 
/*     */   
/*     */   public void open() throws ResourceUnavailableException {
/*  90 */     if (this.device == null && this.inputFormat != null) {
/*  91 */       if (!initDevice(this.inputFormat))
/*  92 */         throw new ResourceUnavailableException("Cannot intialize audio device for playback"); 
/*  93 */       this.device.pause();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isExclusive() {
/*  99 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean initDevice(AudioFormat in) {
/*     */     Format format;
/* 104 */     AudioFormat audioFormat = in;
/*     */ 
/*     */     
/* 107 */     if (this.ulawDecoder != null) {
/* 108 */       this.ulawDecoder.close();
/* 109 */       this.ulawDecoder = null;
/*     */     } 
/*     */ 
/*     */     
/* 113 */     Format[] outs = new Format[1];
/* 114 */     if (this.ulawFormat.matches((Format)in)) {
/*     */       
/* 116 */       this.ulawDecoder = SimpleGraphBuilder.findCodec((Format)in, this.linearFormat, null, outs);
/* 117 */       if (this.ulawDecoder != null) {
/* 118 */         this.ulawOutputFormat = format = outs[0];
/*     */       } else {
/* 120 */         return false;
/*     */       } 
/*     */     } 
/* 123 */     this.devFormat = in;
/*     */     
/* 125 */     return super.initDevice((AudioFormat)format);
/*     */   }
/*     */   
/*     */   protected AudioOutput createDevice(AudioFormat format) {
/* 129 */     return (AudioOutput)new JavaSoundOutput();
/*     */   }
/*     */   
/* 132 */   Buffer decodeBuffer = null;
/*     */ 
/*     */   
/*     */   public int processData(Buffer buffer) {
/* 136 */     if (!checkInput(buffer)) {
/* 137 */       return 1;
/*     */     }
/*     */     
/* 140 */     if (this.ulawDecoder == null) {
/*     */       try {
/* 142 */         ((PeakVolumeMeter)this.peakVolumeMeter).processData(buffer);
/*     */       } catch (Throwable t) {
/* 144 */         t.printStackTrace();
/*     */       } 
/* 146 */       return doProcessData(buffer);
/*     */     } 
/*     */ 
/*     */     
/* 150 */     if (this.decodeBuffer == null) {
/* 151 */       this.decodeBuffer = new Buffer();
/* 152 */       this.decodeBuffer.setFormat(this.ulawOutputFormat);
/*     */     } 
/*     */     
/* 155 */     this.decodeBuffer.setLength(0);
/* 156 */     this.decodeBuffer.setOffset(0);
/* 157 */     this.decodeBuffer.setFlags(buffer.getFlags());
/* 158 */     this.decodeBuffer.setTimeStamp(buffer.getTimeStamp());
/* 159 */     this.decodeBuffer.setSequenceNumber(buffer.getSequenceNumber());
/*     */     
/* 161 */     int rc = this.ulawDecoder.process(buffer, this.decodeBuffer);
/*     */     
/* 163 */     if (rc == 0) {
/*     */       try {
/* 165 */         ((PeakVolumeMeter)this.peakVolumeMeter).processData(this.decodeBuffer);
/*     */       } catch (Throwable t) {
/* 167 */         System.err.println(t);
/*     */       } 
/* 169 */       return doProcessData(this.decodeBuffer);
/*     */     } 
/*     */     
/* 172 */     return 1;
/*     */   }
/*     */   
/*     */   public Object[] getControls() {
/* 176 */     Control[] c = { (Control)this.gainControl, (Control)this.bufferControl, this.peakVolumeMeter };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 181 */     return (Object[])c;
/*     */   }
/*     */   
/*     */   class GCA extends GainControlAdapter {
/*     */     AudioRenderer renderer;
/*     */     private final JavaSoundRenderer this$0;
/*     */     
/*     */     protected GCA(JavaSoundRenderer this$0, AudioRenderer r) {
/* 189 */       super(false); this.this$0 = this$0;
/* 190 */       this.renderer = r;
/*     */     }
/*     */     
/*     */     public void setMute(boolean mute) {
/* 194 */       if (this.renderer != null && this.renderer.device != null)
/* 195 */         this.renderer.device.setMute(mute); 
/* 196 */       super.setMute(mute);
/*     */     }
/*     */     
/*     */     public float setLevel(float g) {
/* 200 */       float level = super.setLevel(g);
/* 201 */       if (this.renderer != null && this.renderer.device != null)
/* 202 */         this.renderer.device.setGain(getDB()); 
/* 203 */       return level;
/*     */     }
/*     */   }
/*     */   
/*     */   class PeakVolumeMeter implements Control, Owned {
/*     */     int averagePeak;
/*     */     int lastPeak;
/*     */     Panel component;
/*     */     Checkbox cbEnabled;
/*     */     Canvas canvas;
/*     */     AudioRenderer renderer;
/*     */     long lastResetTime;
/*     */     Graphics cGraphics;
/*     */     private final JavaSoundRenderer this$0;
/*     */     
/*     */     public PeakVolumeMeter(JavaSoundRenderer this$0, AudioRenderer r) {
/* 219 */       this.this$0 = this$0; this.averagePeak = 0; this.lastPeak = 0; this.component = null; this.cbEnabled = null; this.canvas = null; this.cGraphics = null;
/* 220 */       this.renderer = r;
/* 221 */       this.lastResetTime = System.currentTimeMillis();
/*     */     }
/*     */     
/*     */     public Object getOwner() {
/* 225 */       return this.renderer;
/*     */     }
/*     */     
/*     */     public Component getControlComponent() {
/* 229 */       if (this.component == null) {
/* 230 */         this.canvas = (Canvas)new Object(this);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 235 */         this.cbEnabled = new Checkbox("Peak Volume Meter", false);
/* 236 */         this.component = new Panel();
/* 237 */         this.component.add(this.cbEnabled);
/* 238 */         this.component.add(this.canvas);
/* 239 */         this.canvas.setBackground(Color.black);
/*     */       } 
/* 241 */       return this.component;
/*     */     }
/*     */     
/*     */     public void processData(Buffer buf) {
/* 245 */       AudioFormat af = (AudioFormat)buf.getFormat();
/* 246 */       int index = 0;
/* 247 */       int peak = 0;
/* 248 */       int inc = 2;
/* 249 */       if (this.component == null)
/*     */         return; 
/* 251 */       if (!this.cbEnabled.getState())
/*     */         return; 
/* 253 */       byte[] data = (byte[])buf.getData();
/*     */       
/* 255 */       if (buf.isDiscard())
/*     */         return; 
/* 257 */       if (buf.getLength() <= 0)
/*     */         return; 
/* 259 */       if (af.getEndian() == 0) {
/* 260 */         index = 1;
/*     */       }
/* 262 */       boolean signed = (af.getSigned() == 1);
/* 263 */       if (af.getSampleSizeInBits() == 8)
/* 264 */         inc = 1; 
/* 265 */       if (signed) {
/* 266 */         for (int i = index; i < buf.getLength(); i += inc * 5) {
/* 267 */           int d = data[i];
/* 268 */           if (d < 0)
/* 269 */             d = -d; 
/* 270 */           if (d > peak)
/* 271 */             peak = d; 
/*     */         } 
/* 273 */         peak = peak * 100 / 127;
/*     */       } else {
/* 275 */         for (int i = index; i < buf.getLength(); i += inc * 5) {
/* 276 */           if ((data[i] & 0xFF) > peak)
/* 277 */             peak = data[i] & 0xFF; 
/*     */         } 
/* 279 */         peak = peak * 100 / 255;
/*     */       } 
/* 281 */       this.averagePeak = (peak + this.averagePeak) / 2;
/* 282 */       long currentTime = System.currentTimeMillis();
/* 283 */       if (currentTime > this.lastResetTime + 100L) {
/* 284 */         this.lastResetTime = currentTime;
/* 285 */         updatePeak(this.averagePeak);
/* 286 */         this.averagePeak = peak;
/*     */       } 
/*     */     }
/*     */     
/*     */     private void updatePeak(int newPeak) {
/* 291 */       if (this.canvas == null)
/*     */         return; 
/* 293 */       if (this.cGraphics == null) {
/* 294 */         this.cGraphics = this.canvas.getGraphics();
/*     */       }
/* 296 */       if (this.cGraphics == null)
/*     */         return; 
/* 298 */       if (newPeak > 99)
/* 299 */         newPeak = 99; 
/* 300 */       this.cGraphics.setColor(Color.green);
/* 301 */       if (newPeak < 80) {
/* 302 */         this.cGraphics.drawLine(1, 1, newPeak + 1, 1);
/* 303 */         this.cGraphics.drawLine(1, 2, newPeak + 1, 2);
/*     */       } else {
/* 305 */         this.cGraphics.drawLine(1, 1, 81, 1);
/* 306 */         this.cGraphics.drawLine(1, 2, 81, 2);
/* 307 */         this.cGraphics.setColor(Color.yellow);
/* 308 */         if (newPeak < 90) {
/* 309 */           this.cGraphics.drawLine(81, 1, newPeak + 1, 1);
/* 310 */           this.cGraphics.drawLine(81, 2, newPeak + 1, 2);
/*     */         } else {
/* 312 */           this.cGraphics.drawLine(81, 1, 91, 1);
/* 313 */           this.cGraphics.drawLine(81, 2, 91, 2);
/* 314 */           this.cGraphics.setColor(Color.red);
/* 315 */           this.cGraphics.drawLine(91, 1, newPeak + 1, 1);
/* 316 */           this.cGraphics.drawLine(91, 2, newPeak + 1, 2);
/*     */         } 
/*     */       } 
/* 319 */       this.cGraphics.setColor(Color.black);
/* 320 */       this.cGraphics.drawLine(newPeak + 2, 1, 102, 1);
/* 321 */       this.cGraphics.drawLine(newPeak + 2, 2, 102, 2);
/* 322 */       this.lastPeak = newPeak;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\renderer\audio\JavaSoundRenderer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */