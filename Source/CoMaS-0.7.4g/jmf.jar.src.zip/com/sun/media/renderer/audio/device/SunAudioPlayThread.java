package com.sun.media.renderer.audio.device;

import com.sun.media.util.LoopThread;

class SunAudioPlayThread extends LoopThread {
  long initialTime;
  
  long currentTime;
  
  int samplesUpdated;
  
  int sunAudioInternalDelay = -1;
  
  SunAudioOutput sunAudioOutput;
  
  SunAudioPlayThread() {
    setName(getName() + ": " + this);
  }
  
  void setStream(SunAudioOutput s) {
    this.sunAudioOutput = s;
  }
  
  public void resetSampleCountTime() {
    this.initialTime = System.currentTimeMillis();
  }
  
  public synchronized void start() {
    this.currentTime = System.currentTimeMillis();
    super.start();
  }
  
  public void setInternalDelay(int delay) {
    if (delay >= 0)
      this.sunAudioInternalDelay = delay; 
    this.sunAudioOutput.setPaddingLength(this.sunAudioInternalDelay * 2);
  }
  
  protected boolean process() {
    try {
      this;
      Thread.sleep(50L);
    } catch (InterruptedException e) {}
    if (this.sunAudioInternalDelay >= 0) {
      this.currentTime = System.currentTimeMillis();
      this.samplesUpdated = (int)((this.currentTime - this.initialTime) * 8L);
      if (this.samplesUpdated >= 0 && !this.sunAudioOutput.paused) {
        int tmpSamplesPlayed = this.sunAudioOutput.sunAudioInitialCount + this.samplesUpdated;
        if (tmpSamplesPlayed > this.sunAudioOutput.samplesPlayed && tmpSamplesPlayed <= this.sunAudioOutput.sunAudioFinalCount)
          if (tmpSamplesPlayed - this.sunAudioInternalDelay > this.sunAudioOutput.samplesPlayed)
            this.sunAudioOutput.samplesPlayed = tmpSamplesPlayed - this.sunAudioInternalDelay;  
      } 
    } 
    return true;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\renderer\audio\device\SunAudioPlayThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */