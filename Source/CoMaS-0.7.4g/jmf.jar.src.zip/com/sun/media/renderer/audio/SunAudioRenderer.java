/*     */ package com.sun.media.renderer.audio;
/*     */ 
/*     */ import com.sun.media.BasicClock;
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.controls.GainControlAdapter;
/*     */ import com.sun.media.renderer.audio.device.AudioOutput;
/*     */ import com.sun.media.renderer.audio.device.SunAudioOutput;
/*     */ import javax.media.ClockStoppedException;
/*     */ import javax.media.Format;
/*     */ import javax.media.GainControl;
/*     */ import javax.media.IncompatibleTimeBaseException;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.SystemTimeBase;
/*     */ import javax.media.Time;
/*     */ import javax.media.TimeBase;
/*     */ import javax.media.format.AudioFormat;
/*     */ import sun.audio.AudioPlayer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SunAudioRenderer
/*     */   extends AudioRenderer
/*     */ {
/*  28 */   static String NAME = "SunAudio Renderer";
/*     */   
/*  30 */   public static String vendor = null;
/*  31 */   public static String version = null;
/*     */   public static boolean runningOnMac = false;
/*     */   public static boolean useSystemTime = false;
/*     */   
/*     */   static {
/*     */     try {
/*  37 */       vendor = System.getProperty("java.vendor");
/*  38 */       version = System.getProperty("java.version");
/*  39 */       if (vendor != null) {
/*  40 */         vendor = vendor.toUpperCase();
/*  41 */         if (vendor.startsWith("APPLE") && version.startsWith("1.1")) {
/*  42 */           runningOnMac = true;
/*  43 */           useSystemTime = true;
/*     */         } 
/*     */       } 
/*  46 */     } catch (Throwable e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  51 */   private BasicClock clock = null;
/*  52 */   private long startMediaTime = 0L;
/*     */ 
/*     */ 
/*     */   
/*     */   public SunAudioRenderer() {
/*  57 */     if (useSystemTime) {
/*  58 */       this.timeBase = (TimeBase)new SystemTimeBase();
/*  59 */       this.clock = new BasicClock();
/*     */     } 
/*     */     
/*  62 */     this.supportedFormats = new Format[1];
/*  63 */     this.supportedFormats[0] = (Format)new AudioFormat("ULAW", 8000.0D, 8, 1, -1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     this.gainControl = (GainControl)new MCA(this, this);
/*     */   }
/*     */   
/*     */   public String getName() {
/*  76 */     return NAME;
/*     */   }
/*     */ 
/*     */   
/*     */   public void open() throws ResourceUnavailableException {
/*  81 */     if (!grabDevice()) {
/*  82 */       throw new ResourceUnavailableException("AudioRenderer: Failed to initialize audio device.");
/*     */     }
/*     */   }
/*     */   
/*     */   public void close() {
/*  87 */     super.close();
/*     */   }
/*     */ 
/*     */   
/*     */   protected AudioOutput createDevice(AudioFormat format) {
/*  92 */     return (AudioOutput)new SunAudioOutput();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static synchronized boolean grabDevice() {
/* 103 */     if (runningOnMac && 
/* 104 */       !AudioPlayer.player.isAlive()) {
/* 105 */       System.out.println("Audio device is busy");
/* 106 */       return false;
/*     */     } 
/*     */     
/* 109 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeBase(TimeBase master) throws IncompatibleTimeBaseException {
/* 118 */     if (useSystemTime) {
/* 119 */       if (!(master instanceof SystemTimeBase)) {
/* 120 */         Log.warning("AudioRenderer cannot be controlled by time bases other than its own: " + master);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 128 */       this.clock.setTimeBase(master);
/*     */     } else {
/* 130 */       super.setTimeBase(master);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void syncStart(Time at) {
/* 136 */     super.syncStart(at);
/* 137 */     if (useSystemTime) {
/* 138 */       this.clock.syncStart(at);
/*     */     }
/*     */   }
/*     */   
/*     */   public void stop() {
/* 143 */     super.stop();
/* 144 */     if (useSystemTime) {
/* 145 */       this.clock.stop();
/*     */     }
/*     */   }
/*     */   
/*     */   public void setStopTime(Time t) {
/* 150 */     if (useSystemTime) {
/* 151 */       this.clock.setStopTime(t);
/*     */     } else {
/* 153 */       super.setStopTime(t);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Time getStopTime() {
/* 158 */     if (useSystemTime) {
/* 159 */       return this.clock.getStopTime();
/*     */     }
/* 161 */     return super.getStopTime();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMediaTime(Time now) {
/* 166 */     if (useSystemTime) {
/* 167 */       this.clock.setMediaTime(now);
/* 168 */       this.startMediaTime = now.getNanoseconds();
/*     */     } else {
/* 170 */       super.setMediaTime(now);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Time getMediaTime() {
/* 175 */     return useSystemTime ? this.clock.getMediaTime() : super.getMediaTime();
/*     */   }
/*     */ 
/*     */   
/* 179 */   public static long DEVICE_LATENCY = runningOnMac ? 7000000000L : 0L;
/*     */   
/*     */   public long getMediaNanoseconds() {
/* 182 */     if (useSystemTime) {
/* 183 */       long t = this.clock.getMediaNanoseconds();
/* 184 */       if (t - this.startMediaTime < DEVICE_LATENCY) {
/* 185 */         return this.startMediaTime;
/*     */       }
/* 187 */       return t - DEVICE_LATENCY;
/*     */     } 
/* 189 */     return super.getMediaNanoseconds();
/*     */   }
/*     */ 
/*     */   
/*     */   public Time getSyncTime() {
/* 194 */     return useSystemTime ? this.clock.getSyncTime() : super.getSyncTime();
/*     */   }
/*     */ 
/*     */   
/*     */   public TimeBase getTimeBase() {
/* 199 */     return useSystemTime ? this.clock.getTimeBase() : super.getTimeBase();
/*     */   }
/*     */ 
/*     */   
/*     */   public Time mapToTimeBase(Time t) throws ClockStoppedException {
/* 204 */     return useSystemTime ? this.clock.mapToTimeBase(t) : super.mapToTimeBase(t);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getRate() {
/* 209 */     return useSystemTime ? this.clock.getRate() : super.getRate();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float setRate(float factor) {
/* 215 */     return super.setRate(1.0F);
/*     */   }
/*     */   
/*     */   class MCA
/*     */     extends GainControlAdapter
/*     */   {
/*     */     AudioRenderer renderer;
/*     */     private final SunAudioRenderer this$0;
/*     */     
/*     */     protected MCA(SunAudioRenderer this$0, AudioRenderer r) {
/* 225 */       super(false); this.this$0 = this$0;
/* 226 */       this.renderer = r;
/*     */     }
/*     */     
/*     */     public void setMute(boolean mute) {
/* 230 */       if (this.renderer != null && this.renderer.device != null)
/* 231 */         this.renderer.device.setMute(mute); 
/* 232 */       super.setMute(mute);
/*     */     }
/*     */     
/*     */     public float getLevel() {
/* 236 */       return -1.0F;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\renderer\audio\SunAudioRenderer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */