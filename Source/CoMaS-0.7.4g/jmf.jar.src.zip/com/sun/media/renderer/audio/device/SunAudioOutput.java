/*     */ package com.sun.media.renderer.audio.device;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import com.sun.media.renderer.audio.SunAudioRenderer;
/*     */ import com.sun.media.util.jdk12;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.media.format.AudioFormat;
/*     */ import sun.audio.AudioPlayer;
/*     */ import sun.audio.AudioStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SunAudioOutput
/*     */   extends InputStream
/*     */   implements AudioOutput
/*     */ {
/*     */   protected AudioStream audioStream;
/*     */   protected int bufLength;
/*     */   protected byte[] buffer;
/*  27 */   protected static int EOM = -1;
/*     */   protected boolean paused = false;
/*     */   protected boolean started = false;
/*     */   protected boolean flushing = false;
/*     */   private boolean startAfterWrite = false;
/*     */   protected AudioFormat format;
/*  33 */   private int SUN_MAGIC = 779316836;
/*  34 */   private int HDR_SIZE = 24;
/*  35 */   private int FILE_LENGTH = 0;
/*  36 */   private int SAMPLE_RATE = 8000;
/*  37 */   private int ENCODING = 1;
/*  38 */   private int CHANNELS = 1;
/*     */ 
/*     */ 
/*     */   
/*  42 */   int in = 0;
/*  43 */   int out = 0;
/*     */   
/*     */   boolean eom = false;
/*  46 */   int samplesPlayed = 0;
/*     */   private boolean isMuted = false;
/*  48 */   private double gain = 0.0D;
/*     */ 
/*     */   
/*     */   private byte[] silence;
/*     */ 
/*     */   
/*     */   private static final int END_OF_MEDIA_PADDING_LENGTH = 800;
/*     */   
/*     */   private int endOfMediaPaddingLength;
/*     */   
/*     */   private byte[] conversionBuffer;
/*     */   
/*     */   static final int SLEEP_TIME = 50;
/*     */   
/*     */   protected boolean internalDelayUpdate = false;
/*     */   
/*  64 */   private SunAudioPlayThread timeUpdatingThread = null;
/*  65 */   protected int sunAudioInitialCount = 0;
/*  66 */   protected int sunAudioFinalCount = 0;
/*  67 */   protected int silenceCount = 0;
/*     */   
/*  69 */   private static JMFSecurity jmfSecurity = null;
/*     */   private static boolean securityPrivelege = false;
/*  71 */   private Method[] m = new Method[1];
/*  72 */   private Class[] cl = new Class[1];
/*  73 */   private Object[][] args = new Object[1][0];
/*     */   
/*     */   static {
/*     */     try {
/*  77 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  78 */       securityPrivelege = true;
/*  79 */     } catch (SecurityException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean initialize(AudioFormat format, int length) {
/*  88 */     this.format = format;
/*     */ 
/*     */     
/*  91 */     this.bufLength = 12000;
/*  92 */     this.buffer = new byte[this.bufLength];
/*     */     
/*  94 */     this.silence = new byte[this.bufLength];
/*  95 */     for (int i = 0; i < this.bufLength; i++) {
/*  96 */       this.silence[i] = Byte.MAX_VALUE;
/*     */     }
/*  98 */     if (jmfSecurity != null) {
/*  99 */       String permission = null;
/*     */       
/*     */       try {
/* 102 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 103 */           permission = "thread";
/* 104 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/* 105 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*     */           
/* 107 */           permission = "thread group";
/* 108 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/* 109 */           this.m[0].invoke(this.cl[0], this.args[0]);
/* 110 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/* 111 */           PolicyEngine.checkPermission(PermissionID.THREAD);
/* 112 */           PolicyEngine.assertPermission(PermissionID.THREAD);
/*     */         }
/*     */       
/* 115 */       } catch (Throwable e) {
/*     */ 
/*     */ 
/*     */         
/* 119 */         securityPrivelege = false;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 124 */     if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*     */       try {
/* 126 */         Constructor cons = jdk12CreateThreadAction.cons;
/*     */         
/* 128 */         this.timeUpdatingThread = (SunAudioPlayThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { SunAudioPlayThread.class }) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 135 */       catch (Exception e) {}
/*     */     } else {
/*     */       
/* 138 */       this.timeUpdatingThread = new SunAudioPlayThread();
/*     */     } 
/*     */     
/* 141 */     this.timeUpdatingThread.setStream(this);
/* 142 */     setPaddingLength(800);
/*     */ 
/*     */     
/* 145 */     ByteArrayOutputStream tempOut = new ByteArrayOutputStream();
/* 146 */     DataOutputStream tempData = new DataOutputStream(tempOut);
/*     */     try {
/* 148 */       tempData.writeInt(this.SUN_MAGIC);
/* 149 */       tempData.writeInt(this.HDR_SIZE);
/* 150 */       tempData.writeInt(this.FILE_LENGTH);
/* 151 */       tempData.writeInt(this.ENCODING);
/* 152 */       tempData.writeInt(this.SAMPLE_RATE);
/* 153 */       tempData.writeInt(this.CHANNELS);
/* 154 */     } catch (Exception e) {}
/*     */     
/* 156 */     byte[] buf = tempOut.toByteArray();
/*     */     
/* 158 */     write(buf, 0, buf.length);
/*     */     
/* 160 */     String encoding = format.getEncoding();
/* 161 */     int sampleRate = (int)format.getSampleRate();
/*     */     
/* 163 */     if (format.getChannels() != 1 || sampleRate != 8000 || !encoding.equals("ULAW")) {
/*     */ 
/*     */ 
/*     */       
/* 167 */       System.out.println("AudioPlay:Unsupported Audio Format");
/* 168 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 174 */       this.audioStream = new AudioStream(this);
/*     */     } catch (Exception e) {
/* 176 */       System.err.println("Exception: " + e);
/* 177 */       this.audioStream = null;
/* 178 */       return false;
/*     */     } 
/* 180 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void finalize() throws Throwable {
/* 185 */     super.finalize();
/* 186 */     dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void pause() {
/* 192 */     if (this.audioStream != null) {
/* 193 */       this.timeUpdatingThread.pause();
/* 194 */       AudioPlayer.player.stop(this.audioStream);
/*     */     } 
/* 196 */     this.paused = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void resume() {
/* 202 */     if (this.audioStream != null && (!this.started || this.paused)) {
/* 203 */       this.started = true;
/*     */       
/* 205 */       AudioPlayer.player.start(this.audioStream);
/* 206 */       this.timeUpdatingThread.start();
/*     */     } 
/*     */     
/* 209 */     this.paused = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void dispose() {
/* 218 */     if (this.audioStream != null) {
/* 219 */       this.timeUpdatingThread.kill();
/* 220 */       AudioPlayer.player.stop(this.audioStream);
/*     */     } 
/* 222 */     this.buffer = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drain() {
/* 231 */     synchronized (this) {
/*     */       
/* 233 */       int remain = this.endOfMediaPaddingLength;
/*     */ 
/*     */ 
/*     */       
/* 237 */       while (remain > 0) {
/* 238 */         int len = write(this.silence, 0, remain);
/* 239 */         remain -= len;
/*     */       } 
/*     */ 
/*     */       
/* 243 */       while (this.in != this.out && !this.paused) {
/*     */         try {
/* 245 */           wait();
/* 246 */         } catch (InterruptedException e) {}
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 251 */       if (SunAudioRenderer.runningOnMac) {
/*     */         try {
/* 253 */           Thread.sleep(SunAudioRenderer.DEVICE_LATENCY / 1000000L);
/* 254 */         } catch (InterruptedException e) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void flush() {
/* 263 */     this.in = 0;
/* 264 */     this.out = 0;
/* 265 */     this.sunAudioInitialCount = this.sunAudioFinalCount = this.samplesPlayed;
/* 266 */     this.flushing = true;
/* 267 */     notifyAll();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMediaNanoseconds() {
/* 280 */     return (this.audioStream == null) ? 0L : (this.samplesPlayed * 125000L);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMute(boolean m) {
/* 285 */     this.isMuted = m;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getMute() {
/* 290 */     return this.isMuted;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setGain(double g) {}
/*     */   
/*     */   public double getGain() {
/* 297 */     return 0.0D;
/*     */   }
/*     */   
/*     */   public float setRate(float r) {
/* 301 */     return 1.0F;
/*     */   }
/*     */   
/*     */   public float getRate() {
/* 305 */     return 1.0F;
/*     */   }
/*     */   
/*     */   public int dataAvailable() {
/* 309 */     if (this.in == this.out) {
/* 310 */       return 0;
/*     */     }
/* 312 */     if (this.in > this.out) {
/* 313 */       return this.in - this.out;
/*     */     }
/* 315 */     return this.bufLength - this.out - this.in;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int bufferAvailable() {
/* 321 */     if (SunAudioRenderer.runningOnMac)
/* 322 */       return 0; 
/* 323 */     return this.bufLength - dataAvailable() - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int read() {
/* 330 */     while (this.in == this.out) {
/* 331 */       if (this.eom) {
/* 332 */         this.eom = false;
/* 333 */         return EOM;
/*     */       } 
/*     */       try {
/* 336 */         wait();
/* 337 */       } catch (InterruptedException e) {}
/*     */     } 
/*     */     
/* 340 */     int ret = this.buffer[this.out++] & 0xFF;
/* 341 */     if (this.out >= this.buffer.length) {
/* 342 */       this.out = 0;
/*     */     }
/* 344 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int read(byte[] b, int off, int len) {
/* 356 */     int inputLength = len;
/*     */     
/* 358 */     if (len <= 0) {
/* 359 */       return -1;
/*     */     }
/*     */ 
/*     */     
/* 363 */     if (len > 4 && !this.internalDelayUpdate) {
/*     */       
/* 365 */       this.internalDelayUpdate = true;
/* 366 */       this.timeUpdatingThread.setInternalDelay(len);
/*     */     } 
/*     */     
/* 369 */     if (dataAvailable() == 0) {
/*     */       
/* 371 */       System.arraycopy(this.silence, 0, b, off, inputLength);
/*     */ 
/*     */       
/* 374 */       this.silenceCount += inputLength;
/* 375 */       return inputLength;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 380 */     int c = read();
/* 381 */     if (c < 0) {
/* 382 */       return -1;
/*     */     }
/* 384 */     b[off] = (byte)c;
/*     */     
/* 386 */     int rlen = 1;
/*     */     
/* 388 */     if (this.in != this.out) {
/*     */ 
/*     */       
/* 391 */       len--;
/* 392 */       if (this.out < this.in) {
/* 393 */         int avail = this.in - this.out;
/* 394 */         if (avail > len)
/* 395 */           avail = len; 
/* 396 */         System.arraycopy(this.buffer, this.out, b, off + 1, avail);
/* 397 */         this.out += avail;
/* 398 */         rlen += avail;
/* 399 */       } else if (this.out > this.in) {
/* 400 */         int i = this.bufLength - this.out;
/* 401 */         if (i >= len) {
/* 402 */           i = len;
/* 403 */           System.arraycopy(this.buffer, this.out, b, off + 1, i);
/*     */           
/* 405 */           this.out += i;
/* 406 */           if (this.out >= this.bufLength)
/* 407 */             this.out = 0; 
/* 408 */           rlen += i;
/*     */         } else {
/* 410 */           int j; System.arraycopy(this.buffer, this.out, b, off + 1, i);
/* 411 */           this.out += i;
/* 412 */           if (this.out >= this.bufLength)
/* 413 */             this.out = 0; 
/* 414 */           int copied = i;
/* 415 */           rlen += i;
/* 416 */           int need = len - i;
/* 417 */           i = this.in - this.out;
/* 418 */           if (need <= i) {
/* 419 */             j = need;
/*     */           } else {
/* 421 */             j = i;
/* 422 */           }  System.arraycopy(this.buffer, 0, b, off + 1 + copied, j);
/* 423 */           this.out += j;
/* 424 */           rlen += j;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 430 */     if (this.isMuted) {
/*     */ 
/*     */       
/* 433 */       System.arraycopy(this.silence, 0, b, off, inputLength);
/*     */ 
/*     */     
/*     */     }
/* 437 */     else if (rlen < inputLength) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 443 */       System.arraycopy(this.silence, 0, b, off + rlen, inputLength - rlen);
/* 444 */       this.silenceCount += inputLength - rlen;
/*     */     }
/* 446 */     else if (this.silenceCount > 0) {
/*     */ 
/*     */ 
/*     */       
/* 450 */       if (this.silenceCount > rlen) {
/* 451 */         this.silenceCount -= rlen;
/* 452 */         rlen = 0;
/*     */       } else {
/* 454 */         rlen -= this.silenceCount;
/* 455 */         this.silenceCount = 0;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 460 */     this.timeUpdatingThread.resetSampleCountTime();
/* 461 */     this.sunAudioInitialCount = this.sunAudioFinalCount;
/* 462 */     this.sunAudioFinalCount += rlen;
/* 463 */     notifyAll();
/*     */     
/* 465 */     return inputLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int write(byte[] data, int off, int len) {
/* 478 */     this.flushing = false;
/* 479 */     if (len <= 0) {
/* 480 */       return 0;
/*     */     }
/*     */ 
/*     */     
/* 484 */     while ((this.in + 1) % this.buffer.length == this.out) {
/*     */       try {
/* 486 */         wait();
/* 487 */       } catch (InterruptedException e) {}
/*     */     } 
/*     */ 
/*     */     
/* 491 */     if (this.flushing) {
/* 492 */       return 0;
/*     */     }
/*     */     
/* 495 */     int wlen = 0;
/*     */ 
/*     */ 
/*     */     
/* 499 */     if (this.in < this.out) {
/* 500 */       int canWrite = this.out - this.in - 1;
/* 501 */       int actualWrite = (canWrite < len) ? canWrite : len;
/* 502 */       System.arraycopy(data, off, this.buffer, this.in, actualWrite);
/* 503 */       this.in += actualWrite;
/* 504 */       wlen += actualWrite;
/*     */     } else {
/* 506 */       int i; if (this.out == 0) {
/* 507 */         i = this.bufLength - this.in - 1;
/*     */       } else {
/* 509 */         i = this.bufLength - this.in;
/*     */       } 
/* 511 */       if (i >= len) {
/* 512 */         int j = len;
/* 513 */         System.arraycopy(data, off, this.buffer, this.in, j);
/* 514 */         this.in += j;
/* 515 */         if (this.in >= this.bufLength)
/* 516 */           this.in = 0; 
/* 517 */         wlen += j;
/*     */       } else {
/* 519 */         int j = i;
/* 520 */         System.arraycopy(data, off, this.buffer, this.in, j);
/* 521 */         this.in += j;
/* 522 */         if (this.in >= this.bufLength)
/* 523 */           this.in = 0; 
/* 524 */         wlen += j;
/* 525 */         len -= j;
/* 526 */         int actualWrite1 = j;
/*     */         
/* 528 */         if (this.out > 0) {
/* 529 */           int k = this.out - this.in - 1;
/* 530 */           j = (k < len) ? k : len;
/* 531 */           System.arraycopy(data, off + actualWrite1, this.buffer, 0, j);
/*     */           
/* 533 */           wlen += j;
/* 534 */           this.in = j;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 541 */     notifyAll();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 547 */     return wlen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setPaddingLength(int paddingLength) {
/* 570 */     this.endOfMediaPaddingLength = paddingLength;
/* 571 */     if (this.endOfMediaPaddingLength > this.silence.length)
/* 572 */       this.endOfMediaPaddingLength = this.silence.length; 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\renderer\audio\device\SunAudioOutput.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */