package com.sun.media.renderer.audio.device;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import com.sun.media.JMFSecurity;
import com.sun.media.JMFSecurityManager;
import com.sun.media.renderer.audio.SunAudioRenderer;
import com.sun.media.util.jdk12;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import javax.media.format.AudioFormat;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;

public class SunAudioOutput extends InputStream implements AudioOutput {
  protected AudioStream audioStream;
  
  protected int bufLength;
  
  protected byte[] buffer;
  
  protected static int EOM = -1;
  
  protected boolean paused = false;
  
  protected boolean started = false;
  
  protected boolean flushing = false;
  
  private boolean startAfterWrite = false;
  
  protected AudioFormat format;
  
  private int SUN_MAGIC = 779316836;
  
  private int HDR_SIZE = 24;
  
  private int FILE_LENGTH = 0;
  
  private int SAMPLE_RATE = 8000;
  
  private int ENCODING = 1;
  
  private int CHANNELS = 1;
  
  int in = 0;
  
  int out = 0;
  
  boolean eom = false;
  
  int samplesPlayed = 0;
  
  private boolean isMuted = false;
  
  private double gain = 0.0D;
  
  private byte[] silence;
  
  private static final int END_OF_MEDIA_PADDING_LENGTH = 800;
  
  private int endOfMediaPaddingLength;
  
  private byte[] conversionBuffer;
  
  static final int SLEEP_TIME = 50;
  
  protected boolean internalDelayUpdate = false;
  
  private SunAudioPlayThread timeUpdatingThread = null;
  
  protected int sunAudioInitialCount = 0;
  
  protected int sunAudioFinalCount = 0;
  
  protected int silenceCount = 0;
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] m = new Method[1];
  
  private Class[] cl = new Class[1];
  
  private Object[][] args = new Object[1][0];
  
  static {
    try {
      jmfSecurity = JMFSecurityManager.getJMFSecurity();
      securityPrivelege = true;
    } catch (SecurityException e) {}
  }
  
  public boolean initialize(AudioFormat format, int length) {
    this.format = format;
    this.bufLength = 12000;
    this.buffer = new byte[this.bufLength];
    this.silence = new byte[this.bufLength];
    for (int i = 0; i < this.bufLength; i++)
      this.silence[i] = Byte.MAX_VALUE; 
    if (jmfSecurity != null) {
      String permission = null;
      try {
        if (jmfSecurity.getName().startsWith("jmf-security")) {
          permission = "thread";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
          this.m[0].invoke(this.cl[0], this.args[0]);
          permission = "thread group";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
          this.m[0].invoke(this.cl[0], this.args[0]);
        } else if (jmfSecurity.getName().startsWith("internet")) {
          PolicyEngine.checkPermission(PermissionID.THREAD);
          PolicyEngine.assertPermission(PermissionID.THREAD);
        } 
      } catch (Throwable e) {
        securityPrivelege = false;
      } 
    } 
    if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
      try {
        Constructor cons = jdk12CreateThreadAction.cons;
        this.timeUpdatingThread = (SunAudioPlayThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { SunAudioPlayThread.class }) });
      } catch (Exception e) {}
    } else {
      this.timeUpdatingThread = new SunAudioPlayThread();
    } 
    this.timeUpdatingThread.setStream(this);
    setPaddingLength(800);
    ByteArrayOutputStream tempOut = new ByteArrayOutputStream();
    DataOutputStream tempData = new DataOutputStream(tempOut);
    try {
      tempData.writeInt(this.SUN_MAGIC);
      tempData.writeInt(this.HDR_SIZE);
      tempData.writeInt(this.FILE_LENGTH);
      tempData.writeInt(this.ENCODING);
      tempData.writeInt(this.SAMPLE_RATE);
      tempData.writeInt(this.CHANNELS);
    } catch (Exception e) {}
    byte[] buf = tempOut.toByteArray();
    write(buf, 0, buf.length);
    String encoding = format.getEncoding();
    int sampleRate = (int)format.getSampleRate();
    if (format.getChannels() != 1 || sampleRate != 8000 || !encoding.equals("ULAW")) {
      System.out.println("AudioPlay:Unsupported Audio Format");
      return false;
    } 
    try {
      this.audioStream = new AudioStream(this);
    } catch (Exception e) {
      System.err.println("Exception: " + e);
      this.audioStream = null;
      return false;
    } 
    return true;
  }
  
  public void finalize() throws Throwable {
    super.finalize();
    dispose();
  }
  
  public void pause() {
    if (this.audioStream != null) {
      this.timeUpdatingThread.pause();
      AudioPlayer.player.stop(this.audioStream);
    } 
    this.paused = true;
  }
  
  public synchronized void resume() {
    if (this.audioStream != null && (!this.started || this.paused)) {
      this.started = true;
      AudioPlayer.player.start(this.audioStream);
      this.timeUpdatingThread.start();
    } 
    this.paused = false;
  }
  
  public synchronized void dispose() {
    if (this.audioStream != null) {
      this.timeUpdatingThread.kill();
      AudioPlayer.player.stop(this.audioStream);
    } 
    this.buffer = null;
  }
  
  public void drain() {
    synchronized (this) {
      int remain = this.endOfMediaPaddingLength;
      while (remain > 0) {
        int len = write(this.silence, 0, remain);
        remain -= len;
      } 
      while (this.in != this.out && !this.paused) {
        try {
          wait();
        } catch (InterruptedException e) {}
      } 
      if (SunAudioRenderer.runningOnMac)
        try {
          Thread.sleep(SunAudioRenderer.DEVICE_LATENCY / 1000000L);
        } catch (InterruptedException e) {} 
    } 
  }
  
  public synchronized void flush() {
    this.in = 0;
    this.out = 0;
    this.sunAudioInitialCount = this.sunAudioFinalCount = this.samplesPlayed;
    this.flushing = true;
    notifyAll();
  }
  
  public long getMediaNanoseconds() {
    return (this.audioStream == null) ? 0L : (this.samplesPlayed * 125000L);
  }
  
  public void setMute(boolean m) {
    this.isMuted = m;
  }
  
  public boolean getMute() {
    return this.isMuted;
  }
  
  public void setGain(double g) {}
  
  public double getGain() {
    return 0.0D;
  }
  
  public float setRate(float r) {
    return 1.0F;
  }
  
  public float getRate() {
    return 1.0F;
  }
  
  public int dataAvailable() {
    if (this.in == this.out)
      return 0; 
    if (this.in > this.out)
      return this.in - this.out; 
    return this.bufLength - this.out - this.in;
  }
  
  public int bufferAvailable() {
    if (SunAudioRenderer.runningOnMac)
      return 0; 
    return this.bufLength - dataAvailable() - 1;
  }
  
  public synchronized int read() {
    while (this.in == this.out) {
      if (this.eom) {
        this.eom = false;
        return EOM;
      } 
      try {
        wait();
      } catch (InterruptedException e) {}
    } 
    int ret = this.buffer[this.out++] & 0xFF;
    if (this.out >= this.buffer.length)
      this.out = 0; 
    return ret;
  }
  
  public synchronized int read(byte[] b, int off, int len) {
    int inputLength = len;
    if (len <= 0)
      return -1; 
    if (len > 4 && !this.internalDelayUpdate) {
      this.internalDelayUpdate = true;
      this.timeUpdatingThread.setInternalDelay(len);
    } 
    if (dataAvailable() == 0) {
      System.arraycopy(this.silence, 0, b, off, inputLength);
      this.silenceCount += inputLength;
      return inputLength;
    } 
    int c = read();
    if (c < 0)
      return -1; 
    b[off] = (byte)c;
    int rlen = 1;
    if (this.in != this.out) {
      len--;
      if (this.out < this.in) {
        int avail = this.in - this.out;
        if (avail > len)
          avail = len; 
        System.arraycopy(this.buffer, this.out, b, off + 1, avail);
        this.out += avail;
        rlen += avail;
      } else if (this.out > this.in) {
        int i = this.bufLength - this.out;
        if (i >= len) {
          i = len;
          System.arraycopy(this.buffer, this.out, b, off + 1, i);
          this.out += i;
          if (this.out >= this.bufLength)
            this.out = 0; 
          rlen += i;
        } else {
          int j;
          System.arraycopy(this.buffer, this.out, b, off + 1, i);
          this.out += i;
          if (this.out >= this.bufLength)
            this.out = 0; 
          int copied = i;
          rlen += i;
          int need = len - i;
          i = this.in - this.out;
          if (need <= i) {
            j = need;
          } else {
            j = i;
          } 
          System.arraycopy(this.buffer, 0, b, off + 1 + copied, j);
          this.out += j;
          rlen += j;
        } 
      } 
    } 
    if (this.isMuted) {
      System.arraycopy(this.silence, 0, b, off, inputLength);
    } else if (rlen < inputLength) {
      System.arraycopy(this.silence, 0, b, off + rlen, inputLength - rlen);
      this.silenceCount += inputLength - rlen;
    } else if (this.silenceCount > 0) {
      if (this.silenceCount > rlen) {
        this.silenceCount -= rlen;
        rlen = 0;
      } else {
        rlen -= this.silenceCount;
        this.silenceCount = 0;
      } 
    } 
    this.timeUpdatingThread.resetSampleCountTime();
    this.sunAudioInitialCount = this.sunAudioFinalCount;
    this.sunAudioFinalCount += rlen;
    notifyAll();
    return inputLength;
  }
  
  public synchronized int write(byte[] data, int off, int len) {
    this.flushing = false;
    if (len <= 0)
      return 0; 
    while ((this.in + 1) % this.buffer.length == this.out) {
      try {
        wait();
      } catch (InterruptedException e) {}
    } 
    if (this.flushing)
      return 0; 
    int wlen = 0;
    if (this.in < this.out) {
      int canWrite = this.out - this.in - 1;
      int actualWrite = (canWrite < len) ? canWrite : len;
      System.arraycopy(data, off, this.buffer, this.in, actualWrite);
      this.in += actualWrite;
      wlen += actualWrite;
    } else {
      int i;
      if (this.out == 0) {
        i = this.bufLength - this.in - 1;
      } else {
        i = this.bufLength - this.in;
      } 
      if (i >= len) {
        int j = len;
        System.arraycopy(data, off, this.buffer, this.in, j);
        this.in += j;
        if (this.in >= this.bufLength)
          this.in = 0; 
        wlen += j;
      } else {
        int j = i;
        System.arraycopy(data, off, this.buffer, this.in, j);
        this.in += j;
        if (this.in >= this.bufLength)
          this.in = 0; 
        wlen += j;
        len -= j;
        int actualWrite1 = j;
        if (this.out > 0) {
          int k = this.out - this.in - 1;
          j = (k < len) ? k : len;
          System.arraycopy(data, off + actualWrite1, this.buffer, 0, j);
          wlen += j;
          this.in = j;
        } 
      } 
    } 
    notifyAll();
    return wlen;
  }
  
  protected void setPaddingLength(int paddingLength) {
    this.endOfMediaPaddingLength = paddingLength;
    if (this.endOfMediaPaddingLength > this.silence.length)
      this.endOfMediaPaddingLength = this.silence.length; 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\renderer\audio\device\SunAudioOutput.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */