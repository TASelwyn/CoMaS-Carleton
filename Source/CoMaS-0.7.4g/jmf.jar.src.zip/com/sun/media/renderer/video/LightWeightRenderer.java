/*    */ package com.sun.media.renderer.video;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LightWeightRenderer
/*    */   extends AWTRenderer
/*    */ {
/*    */   private static final String MyName = "LightWeight Renderer";
/*    */   
/*    */   public LightWeightRenderer() {
/* 22 */     super("LightWeight Renderer");
/*    */   }
/*    */   
/*    */   public boolean isLightWeight() {
/* 26 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\renderer\video\LightWeightRenderer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */