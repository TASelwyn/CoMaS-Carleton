/*     */ package com.sun.media.renderer.video;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.Point;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.image.AffineTransformOp;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.DataBufferInt;
/*     */ import java.awt.image.DirectColorModel;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.SinglePixelPackedSampleModel;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.util.Vector;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.format.RGBFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Java2DRenderer
/*     */   implements Blitter
/*     */ {
/*  40 */   private transient AffineTransformOp savedATO = null;
/*  41 */   private transient DirectColorModel dcm = null;
/*  42 */   private transient Image destImage = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Java2DRenderer() {
/*     */     try {
/*  50 */       Class.forName("java.awt.Graphics2D");
/*  51 */     } catch (ClassNotFoundException classNotFoundException) {
/*  52 */       throw new RuntimeException("No Java2D");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Image process(Buffer paramBuffer, Object paramObject1, Object paramObject2, Dimension paramDimension) {
/*  61 */     return (Image)paramObject1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void draw(Graphics paramGraphics, Component paramComponent, Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8) {
/*  67 */     if (paramImage == null || paramInt3 < 1 || paramInt4 < 1)
/*     */       return; 
/*  69 */     if (this.savedATO == null) {
/*  70 */       AffineTransform affineTransform = new AffineTransform(paramInt3 / paramInt7, 0.0F, 
/*  71 */           0.0F, paramInt4 / paramInt8, 
/*  72 */           0.0F, 0.0F);
/*  73 */       AffineTransformOp affineTransformOp = new AffineTransformOp(affineTransform, null);
/*     */       
/*  75 */       this.savedATO = affineTransformOp;
/*  76 */       this.destImage = affineTransformOp.createCompatibleDestImage((BufferedImage)paramImage, 
/*  77 */           this.dcm);
/*     */     } 
/*  79 */     this.savedATO.filter((BufferedImage)paramImage, (BufferedImage)this.destImage);
/*  80 */     if (paramGraphics != null && paramImage != null && paramGraphics instanceof Graphics2D) {
/*  81 */       ((Graphics2D)paramGraphics).drawImage(this.destImage, 0, 0, paramComponent);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int newData(Buffer paramBuffer, Vector paramVector1, Vector paramVector2, Vector paramVector3) {
/*  87 */     Object object = paramBuffer.getData();
/*  88 */     if (!(object instanceof int[]))
/*  89 */       return -1; 
/*  90 */     RGBFormat rGBFormat = (RGBFormat)paramBuffer.getFormat();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     int i = rGBFormat.getRedMask();
/*  99 */     int j = rGBFormat.getGreenMask();
/* 100 */     int k = rGBFormat.getBlueMask();
/* 101 */     int[] arrayOfInt = new int[3];
/* 102 */     arrayOfInt[0] = i;
/* 103 */     arrayOfInt[1] = j;
/* 104 */     arrayOfInt[2] = k;
/*     */     
/* 106 */     DataBufferInt dataBufferInt = new DataBufferInt((int[])object, 
/* 107 */         rGBFormat.getLineStride() * 
/* 108 */         (rGBFormat.getSize()).height);
/*     */     
/* 110 */     SinglePixelPackedSampleModel singlePixelPackedSampleModel = new SinglePixelPackedSampleModel(3, 
/* 111 */         rGBFormat.getLineStride(), 
/* 112 */         (rGBFormat.getSize()).height, 
/* 113 */         arrayOfInt);
/* 114 */     WritableRaster writableRaster = Raster.createWritableRaster(singlePixelPackedSampleModel, dataBufferInt, new Point(0, 0));
/*     */     
/* 116 */     this.dcm = new DirectColorModel(24, i, j, k);
/* 117 */     BufferedImage bufferedImage = new BufferedImage(this.dcm, writableRaster, true, null);
/*     */     
/* 119 */     paramVector3.addElement(object);
/* 120 */     paramVector1.addElement(bufferedImage);
/* 121 */     paramVector2.addElement(bufferedImage);
/* 122 */     synchronized (this) {
/* 123 */       this.savedATO = null;
/*     */     } 
/* 125 */     return paramVector1.size() - 1;
/*     */   }
/*     */   
/*     */   public void resized(Component paramComponent) {
/* 129 */     this.savedATO = null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\renderer\video\Java2DRenderer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */