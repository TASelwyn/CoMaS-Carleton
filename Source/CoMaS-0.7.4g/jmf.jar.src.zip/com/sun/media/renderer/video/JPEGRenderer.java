package com.sun.media.renderer.video;

import com.sun.media.BasicPlugIn;
import com.sun.media.JMFSecurityManager;
import com.sun.media.SlowPlugIn;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.ResourceUnavailableException;
import javax.media.format.VideoFormat;

public class JPEGRenderer extends BasicVideoRenderer implements SlowPlugIn {
  private static final String MyName = "JPEG Renderer";
  
  private VideoFormat supportedJPEG = null;
  
  private VideoFormat supportedMJPG = null;
  
  private boolean forceToFail = false;
  
  public void forceToUse() {
    this.forceToFail = false;
  }
  
  public JPEGRenderer() {
    super("JPEG Renderer");
    if (BasicPlugIn.plugInExists("com.sun.media.codec.video.jpeg.NativeDecoder", 2))
      try {
        JMFSecurityManager.loadLibrary("jmutil");
        JMFSecurityManager.loadLibrary("jmjpeg");
        this.forceToFail = true;
      } catch (Throwable t) {} 
    this.supportedJPEG = new VideoFormat("jpeg", null, -1, Format.byteArray, -1.0F);
    this.supportedMJPG = new VideoFormat("mjpg", null, -1, Format.byteArray, -1.0F);
    this.supportedFormats = new VideoFormat[1];
    this.supportedFormats[0] = this.supportedJPEG;
  }
  
  public void open() throws ResourceUnavailableException {}
  
  public void reset() {}
  
  public Format setInputFormat(Format format) {
    if (this.forceToFail)
      return null; 
    if (super.setInputFormat(format) != null) {
      reset();
      return format;
    } 
    return null;
  }
  
  public synchronized int doProcess(Buffer buffer) {
    if (this.component == null)
      return 0; 
    if (!buffer.getFormat().equals(this.inputFormat)) {
      Format in = buffer.getFormat();
      if (!in.matches((Format)this.supportedJPEG))
        return 1; 
      this.inputFormat = (VideoFormat)in;
    } 
    Dimension size = this.inputFormat.getSize();
    Object data = buffer.getData();
    if (!(data instanceof byte[]))
      return 1; 
    Image im = Toolkit.getDefaultToolkit().createImage((byte[])data);
    MediaTracker tracker = new MediaTracker(this.component);
    Dimension d = this.component.getSize();
    this.outWidth = d.width;
    this.outHeight = d.height;
    tracker.addImage(im, 0);
    try {
      tracker.waitForAll();
    } catch (Exception e) {}
    Graphics g = this.component.getGraphics();
    if (g != null)
      g.drawImage(im, 0, 0, this.outWidth, this.outHeight, 0, 0, size.width, size.height, this.component); 
    return 0;
  }
  
  protected void repaint() {}
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\renderer\video\JPEGRenderer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */