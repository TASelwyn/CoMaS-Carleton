package com.sun.media.renderer.video;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;

public class HeavyComponent extends Canvas {
  BasicVideoRenderer bvr = null;
  
  public void setRenderer(BasicVideoRenderer bvr) {
    this.bvr = bvr;
  }
  
  public synchronized void paint(Graphics g) {
    if (this.bvr != null)
      this.bvr.repaint(); 
  }
  
  public synchronized void update(Graphics g) {}
  
  public Dimension getMinimumSize() {
    return new Dimension(1, 1);
  }
  
  public Dimension getPreferredSize() {
    if (this.bvr != null)
      return this.bvr.myPreferredSize(); 
    return super.getPreferredSize();
  }
  
  public synchronized void addNotify() {
    super.addNotify();
    if (this.bvr != null)
      this.bvr.setAvailable(true); 
  }
  
  public synchronized void removeNotify() {
    if (this.bvr != null)
      this.bvr.setAvailable(false); 
    super.removeNotify();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\renderer\video\HeavyComponent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */