/*    */ package com.sun.media.renderer.video;
/*    */ 
/*    */ import java.awt.Canvas;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HeavyComponent
/*    */   extends Canvas
/*    */ {
/* 13 */   BasicVideoRenderer bvr = null;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRenderer(BasicVideoRenderer bvr) {
/* 19 */     this.bvr = bvr;
/*    */   }
/*    */   
/*    */   public synchronized void paint(Graphics g) {
/* 23 */     if (this.bvr != null) {
/* 24 */       this.bvr.repaint();
/*    */     }
/*    */   }
/*    */   
/*    */   public synchronized void update(Graphics g) {}
/*    */   
/*    */   public Dimension getMinimumSize() {
/* 31 */     return new Dimension(1, 1);
/*    */   }
/*    */   
/*    */   public Dimension getPreferredSize() {
/* 35 */     if (this.bvr != null) {
/* 36 */       return this.bvr.myPreferredSize();
/*    */     }
/* 38 */     return super.getPreferredSize();
/*    */   }
/*    */   
/*    */   public synchronized void addNotify() {
/* 42 */     super.addNotify();
/* 43 */     if (this.bvr != null)
/* 44 */       this.bvr.setAvailable(true); 
/*    */   }
/*    */   
/*    */   public synchronized void removeNotify() {
/* 48 */     if (this.bvr != null)
/* 49 */       this.bvr.setAvailable(false); 
/* 50 */     super.removeNotify();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\renderer\video\HeavyComponent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */