/*     */ package com.sun.media.renderer.video;
/*     */ 
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.ExtBuffer;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ComponentAdapter;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.ComponentListener;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Control;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.control.FrameGrabbingControl;
/*     */ import javax.media.format.VideoFormat;
/*     */ import javax.media.renderer.VideoRenderer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BasicVideoRenderer
/*     */   extends BasicPlugIn
/*     */   implements VideoRenderer, FrameGrabbingControl
/*     */ {
/*     */   protected String name;
/*  35 */   protected transient VideoFormat[] supportedFormats = null;
/*     */   
/*  37 */   protected VideoFormat inputFormat = null;
/*     */   
/*  39 */   protected int outWidth = -1;
/*  40 */   protected int outHeight = -1;
/*  41 */   protected int inWidth = -1;
/*  42 */   protected int inHeight = -1;
/*  43 */   protected Component component = null;
/*  44 */   protected ComponentListener compListener = null;
/*     */   
/*     */   protected boolean componentAvailable = false;
/*  47 */   protected Rectangle bounds = null;
/*     */   
/*     */   protected boolean started = false;
/*  50 */   protected Control[] controls = null;
/*  51 */   protected FrameGrabbingControl frameGrabber = null;
/*  52 */   protected ExtBuffer lastBuffer = new ExtBuffer();
/*  53 */   protected Object lastData = null, lastHdr = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicVideoRenderer(String name) {
/*  60 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  72 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format[] getSupportedInputFormats() {
/*  79 */     return (Format[])this.supportedFormats;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() throws ResourceUnavailableException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int process(Buffer inbuffer) {
/*     */     int result;
/* 112 */     if (inbuffer.getLength() == 0) {
/* 113 */       return 0;
/*     */     }
/*     */ 
/*     */     
/* 117 */     synchronized (this.lastBuffer) {
/* 118 */       result = doProcess(inbuffer);
/*     */       
/* 120 */       if (result == 0) {
/* 121 */         this.lastBuffer.copy(inbuffer, true);
/*     */       }
/*     */     } 
/* 124 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract int doProcess(Buffer paramBuffer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format setInputFormat(Format format) {
/* 138 */     if (BasicPlugIn.matches(format, (Format[])this.supportedFormats) != null) {
/* 139 */       this.inputFormat = (VideoFormat)format;
/* 140 */       Dimension size = this.inputFormat.getSize();
/* 141 */       if (size != null) {
/* 142 */         this.inWidth = size.width;
/* 143 */         this.inHeight = size.height;
/*     */       } 
/* 145 */       return format;
/*     */     } 
/* 147 */     return null;
/*     */   }
/*     */   
/*     */   public void start() {
/* 151 */     this.started = true;
/*     */   }
/*     */   
/*     */   public void stop() {
/* 155 */     this.started = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getComponent() {
/* 167 */     if (this.component == null) {
/*     */       
/*     */       try {
/* 170 */         Class mshc = Class.forName("com.sun.media.renderer.video.MSHeavyComponent");
/* 171 */         if (mshc != null)
/* 172 */           this.component = (Component)mshc.newInstance(); 
/*     */       } catch (Throwable t) {
/* 174 */         this.component = new HeavyComponent();
/*     */       } 
/* 176 */       ((HeavyComponent)this.component).setRenderer(this);
/* 177 */       this.component.setBackground(getPreferredBackground());
/* 178 */       if (this.compListener == null)
/* 179 */         this.compListener = new CompListener(this); 
/* 180 */       this.component.addComponentListener(this.compListener);
/*     */     } 
/* 182 */     return this.component;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean setComponent(Component comp) {
/* 191 */     reset();
/* 192 */     this.component = comp;
/* 193 */     if (this.compListener == null)
/* 194 */       this.compListener = new CompListener(this); 
/* 195 */     this.component.addComponentListener(this.compListener);
/* 196 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBounds(Rectangle rect) {
/* 205 */     this.bounds = rect;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle getBounds() {
/* 213 */     return this.bounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Color getPreferredBackground() {
/* 221 */     return Color.black;
/*     */   }
/*     */   
/*     */   void resized(Component c) {
/* 225 */     if (c != null && c == this.component) {
/* 226 */       Dimension d = this.component.getSize();
/* 227 */       this.outWidth = d.width;
/* 228 */       this.outHeight = d.height;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected synchronized void setAvailable(boolean on) {
/* 234 */     this.componentAvailable = on;
/* 235 */     if (!this.componentAvailable) {
/* 236 */       removingComponent();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void removingComponent() {}
/*     */   
/*     */   protected Dimension myPreferredSize() {
/* 243 */     return new Dimension(this.inWidth, this.inHeight);
/*     */   }
/*     */   
/*     */   protected boolean isStarted() {
/* 247 */     return this.started;
/*     */   }
/*     */   
/*     */   protected void repaint() {
/* 251 */     System.err.println("repaint call not implemented on this renderer");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getControls() {
/* 259 */     if (this.controls != null) {
/* 260 */       return (Object[])this.controls;
/*     */     }
/* 262 */     this.frameGrabber = this;
/* 263 */     this.controls = new Control[1];
/* 264 */     this.controls[0] = (Control)this.frameGrabber;
/* 265 */     return (Object[])this.controls;
/*     */   }
/*     */   
/*     */   public Component getControlComponent() {
/* 269 */     return null;
/*     */   }
/*     */   
/*     */   public Buffer grabFrame() {
/* 273 */     synchronized (this.lastBuffer) {
/* 274 */       Object object1; Buffer newBuffer = new Buffer();
/* 275 */       newBuffer.setFormat(this.lastBuffer.getFormat());
/* 276 */       newBuffer.setFlags(this.lastBuffer.getFlags());
/* 277 */       newBuffer.setLength(this.lastBuffer.getLength());
/* 278 */       newBuffer.setOffset(0);
/* 279 */       newBuffer.setHeader(this.lastBuffer.getHeader());
/* 280 */       newBuffer.setData(this.lastBuffer.getData());
/*     */       
/* 282 */       Object data = this.lastBuffer.getData();
/* 283 */       int length = this.lastBuffer.getLength();
/*     */       
/* 285 */       if (data instanceof byte[]) {
/* 286 */         object1 = new byte[length];
/* 287 */       } else if (data instanceof short[]) {
/* 288 */         object1 = new short[length];
/* 289 */       } else if (data instanceof int[]) {
/* 290 */         object1 = new int[length];
/*     */       } else {
/* 292 */         return newBuffer;
/* 293 */       }  System.arraycopy(data, this.lastBuffer.getOffset(), object1, 0, length);
/*     */ 
/*     */       
/* 296 */       newBuffer.setData(object1);
/* 297 */       return newBuffer;
/*     */     } 
/*     */   }
/*     */   
/*     */   public class CompListener extends ComponentAdapter {
/*     */     private final BasicVideoRenderer this$0;
/*     */     
/*     */     public CompListener(BasicVideoRenderer this$0) {
/* 305 */       this.this$0 = this$0;
/*     */     } public void componentResized(ComponentEvent ce) {
/* 307 */       this.this$0.resized(ce.getComponent());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\renderer\video\BasicVideoRenderer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */