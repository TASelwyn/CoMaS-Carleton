package com.sun.media.renderer.video;

import com.sun.media.BasicPlugIn;
import com.sun.media.ExtBuffer;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import javax.media.Buffer;
import javax.media.Control;
import javax.media.Format;
import javax.media.ResourceUnavailableException;
import javax.media.control.FrameGrabbingControl;
import javax.media.format.VideoFormat;
import javax.media.renderer.VideoRenderer;

public abstract class BasicVideoRenderer extends BasicPlugIn implements VideoRenderer, FrameGrabbingControl {
  protected String name;
  
  protected transient VideoFormat[] supportedFormats = null;
  
  protected VideoFormat inputFormat = null;
  
  protected int outWidth = -1;
  
  protected int outHeight = -1;
  
  protected int inWidth = -1;
  
  protected int inHeight = -1;
  
  protected Component component = null;
  
  protected ComponentListener compListener = null;
  
  protected boolean componentAvailable = false;
  
  protected Rectangle bounds = null;
  
  protected boolean started = false;
  
  protected Control[] controls = null;
  
  protected FrameGrabbingControl frameGrabber = null;
  
  protected ExtBuffer lastBuffer = new ExtBuffer();
  
  protected Object lastData = null, lastHdr = null;
  
  public BasicVideoRenderer(String name) {
    this.name = name;
  }
  
  public String getName() {
    return this.name;
  }
  
  public Format[] getSupportedInputFormats() {
    return (Format[])this.supportedFormats;
  }
  
  public void open() throws ResourceUnavailableException {}
  
  public void close() {}
  
  public void reset() {}
  
  public int process(Buffer inbuffer) {
    int result;
    if (inbuffer.getLength() == 0)
      return 0; 
    synchronized (this.lastBuffer) {
      result = doProcess(inbuffer);
      if (result == 0)
        this.lastBuffer.copy(inbuffer, true); 
    } 
    return result;
  }
  
  protected abstract int doProcess(Buffer paramBuffer);
  
  public Format setInputFormat(Format format) {
    if (BasicPlugIn.matches(format, (Format[])this.supportedFormats) != null) {
      this.inputFormat = (VideoFormat)format;
      Dimension size = this.inputFormat.getSize();
      if (size != null) {
        this.inWidth = size.width;
        this.inHeight = size.height;
      } 
      return format;
    } 
    return null;
  }
  
  public void start() {
    this.started = true;
  }
  
  public void stop() {
    this.started = false;
  }
  
  public Component getComponent() {
    if (this.component == null) {
      try {
        Class mshc = Class.forName("com.sun.media.renderer.video.MSHeavyComponent");
        if (mshc != null)
          this.component = (Component)mshc.newInstance(); 
      } catch (Throwable t) {
        this.component = new HeavyComponent();
      } 
      ((HeavyComponent)this.component).setRenderer(this);
      this.component.setBackground(getPreferredBackground());
      if (this.compListener == null)
        this.compListener = new CompListener(this); 
      this.component.addComponentListener(this.compListener);
    } 
    return this.component;
  }
  
  public synchronized boolean setComponent(Component comp) {
    reset();
    this.component = comp;
    if (this.compListener == null)
      this.compListener = new CompListener(this); 
    this.component.addComponentListener(this.compListener);
    return true;
  }
  
  public void setBounds(Rectangle rect) {
    this.bounds = rect;
  }
  
  public Rectangle getBounds() {
    return this.bounds;
  }
  
  protected Color getPreferredBackground() {
    return Color.black;
  }
  
  void resized(Component c) {
    if (c != null && c == this.component) {
      Dimension d = this.component.getSize();
      this.outWidth = d.width;
      this.outHeight = d.height;
    } 
  }
  
  protected synchronized void setAvailable(boolean on) {
    this.componentAvailable = on;
    if (!this.componentAvailable)
      removingComponent(); 
  }
  
  protected void removingComponent() {}
  
  protected Dimension myPreferredSize() {
    return new Dimension(this.inWidth, this.inHeight);
  }
  
  protected boolean isStarted() {
    return this.started;
  }
  
  protected void repaint() {
    System.err.println("repaint call not implemented on this renderer");
  }
  
  public Object[] getControls() {
    if (this.controls != null)
      return (Object[])this.controls; 
    this.frameGrabber = this;
    this.controls = new Control[1];
    this.controls[0] = (Control)this.frameGrabber;
    return (Object[])this.controls;
  }
  
  public Component getControlComponent() {
    return null;
  }
  
  public Buffer grabFrame() {
    synchronized (this.lastBuffer) {
      Object object1;
      Buffer newBuffer = new Buffer();
      newBuffer.setFormat(this.lastBuffer.getFormat());
      newBuffer.setFlags(this.lastBuffer.getFlags());
      newBuffer.setLength(this.lastBuffer.getLength());
      newBuffer.setOffset(0);
      newBuffer.setHeader(this.lastBuffer.getHeader());
      newBuffer.setData(this.lastBuffer.getData());
      Object data = this.lastBuffer.getData();
      int length = this.lastBuffer.getLength();
      if (data instanceof byte[]) {
        object1 = new byte[length];
      } else if (data instanceof short[]) {
        object1 = new short[length];
      } else if (data instanceof int[]) {
        object1 = new int[length];
      } else {
        return newBuffer;
      } 
      System.arraycopy(data, this.lastBuffer.getOffset(), object1, 0, length);
      newBuffer.setData(object1);
      return newBuffer;
    } 
  }
  
  public class CompListener extends ComponentAdapter {
    private final BasicVideoRenderer this$0;
    
    public CompListener(BasicVideoRenderer this$0) {
      this.this$0 = this$0;
    }
    
    public void componentResized(ComponentEvent ce) {
      this.this$0.resized(ce.getComponent());
    }
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\renderer\video\BasicVideoRenderer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */