package com.sun.media.renderer.video;

import com.sun.media.BasicPlugIn;
import com.sun.media.util.Arch;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.DirectColorModel;
import java.awt.image.MemoryImageSource;
import java.util.Vector;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.ResourceUnavailableException;
import javax.media.format.RGBFormat;
import javax.media.format.VideoFormat;

public class AWTRenderer extends BasicVideoRenderer implements Blitter {
  private static final String MyName = "AWT Renderer";
  
  private transient Vector cacheInputData;
  
  private transient Vector cacheInputImage;
  
  private transient Vector cacheOutputImage;
  
  private transient Image lastImage;
  
  private RGBFormat supportedRGB;
  
  private RGBFormat supportedOther;
  
  private transient int lastWidth;
  
  private transient int lastHeight;
  
  private Blitter blitter;
  
  public static String vendor = null;
  
  public static boolean runningOnMac = false;
  
  static {
    try {
      vendor = System.getProperty("java.vendor");
      if (vendor != null) {
        vendor = vendor.toUpperCase();
        if (vendor.startsWith("APPLE"))
          runningOnMac = true; 
      } 
    } catch (Throwable e) {}
  }
  
  public AWTRenderer() {
    this("AWT Renderer");
  }
  
  public AWTRenderer(String name) {
    super(name);
    int i;
    char c;
    char c1;
    this.cacheInputData = null;
    this.cacheInputImage = null;
    this.cacheOutputImage = null;
    this.lastImage = null;
    this.supportedRGB = null;
    this.supportedOther = null;
    this.lastWidth = 1;
    this.lastHeight = 1;
    this.blitter = null;
    if ((Arch.getArch() & 0x8) != 0 && !runningOnMac) {
      i = 255;
      c = '＀';
      c1 = '\000';
    } else {
      c1 = 'ÿ';
      c = '＀';
      i = 16711680;
    } 
    this.supportedRGB = new RGBFormat(null, -1, Format.intArray, -1.0F, 32, i, c, c1, 1, -1, 0, -1);
    this.supportedOther = new RGBFormat(null, -1, Format.intArray, -1.0F, 32, c1, c, i, 1, -1, 0, -1);
    this.supportedFormats = new VideoFormat[2];
    this.supportedFormats[0] = (VideoFormat)this.supportedRGB;
    this.supportedFormats[1] = (VideoFormat)this.supportedOther;
    if (runningOnMac)
      this.supportedFormats[1] = (VideoFormat)this.supportedRGB; 
    try {
      Class cls = Class.forName("com.sun.media.renderer.video.Java2DRenderer");
      this.blitter = (Blitter)cls.newInstance();
    } catch (Throwable t) {
      if (t instanceof ThreadDeath)
        throw (ThreadDeath)t; 
      this.blitter = this;
    } 
  }
  
  public boolean isLightWeight() {
    return false;
  }
  
  public void open() throws ResourceUnavailableException {
    this.cacheInputData = new Vector();
    this.cacheInputImage = new Vector();
    this.cacheOutputImage = new Vector();
  }
  
  public synchronized void reset() {
    this.cacheInputData = new Vector();
    this.cacheInputImage = new Vector();
    this.cacheOutputImage = new Vector();
  }
  
  public Format setInputFormat(Format format) {
    if (super.setInputFormat(format) != null) {
      reset();
      return format;
    } 
    return null;
  }
  
  protected synchronized int doProcess(Buffer buffer) {
    if (this.component == null)
      return 0; 
    if (!buffer.getFormat().equals(this.inputFormat)) {
      Format in = buffer.getFormat();
      if (BasicPlugIn.matches(in, (Format[])this.supportedFormats) == null)
        return 1; 
      this.inputFormat = (VideoFormat)in;
    } 
    Object data = buffer.getData();
    if (!(data instanceof int[]))
      return 1; 
    int cacheSize = this.cacheInputData.size();
    boolean found = false;
    int i;
    for (i = 0; i < cacheSize; i++) {
      Object bufKnown = this.cacheInputData.elementAt(i);
      if (bufKnown == data) {
        found = true;
        break;
      } 
    } 
    if (!found)
      i = this.blitter.newData(buffer, this.cacheInputImage, this.cacheOutputImage, this.cacheInputData); 
    if (i < 0)
      return 1; 
    RGBFormat format = (RGBFormat)buffer.getFormat();
    Dimension size = format.getSize();
    this.inWidth = size.width;
    this.inHeight = size.height;
    if (this.outWidth == -1)
      this.outWidth = size.width; 
    if (this.outHeight == -1)
      this.outHeight = size.height; 
    this.lastImage = this.blitter.process(buffer, this.cacheInputImage.elementAt(i), this.cacheOutputImage.elementAt(i), size);
    this.lastWidth = size.width;
    this.lastHeight = size.height;
    if (!isLightWeight()) {
      Graphics g = this.component.getGraphics();
      if (g != null)
        this.blitter.draw(g, this.component, this.lastImage, 0, 0, this.outWidth, this.outHeight, 0, 0, size.width, size.height); 
    } else {
      this.component.repaint();
    } 
    return 0;
  }
  
  protected void repaint() {
    if (!isStarted() && this.lastImage != null) {
      Graphics g = this.component.getGraphics();
      this.blitter.draw(g, this.component, this.lastImage, 0, 0, this.outWidth, this.outHeight, 0, 0, this.lastWidth, this.lastHeight);
    } 
  }
  
  public Component getComponent() {
    if (this.component == null)
      if (isLightWeight()) {
        this.component = new LightComponent(this);
        this.component.setBackground(getPreferredBackground());
        if (this.compListener == null)
          this.compListener = new BasicVideoRenderer.CompListener(this); 
        this.component.addComponentListener(this.compListener);
      } else {
        this.component = super.getComponent();
      }  
    return this.component;
  }
  
  public synchronized void resized(Component c) {
    super.resized(c);
    if (this.blitter != this)
      this.blitter.resized(c); 
  }
  
  public Image process(Buffer buffer, Object cacheInputImage, Object cacheOutputImage, Dimension size) {
    MemoryImageSource sourceImage = (MemoryImageSource)cacheInputImage;
    Image lastImage = (Image)cacheOutputImage;
    sourceImage.newPixels(0, 0, size.width, size.height);
    return lastImage;
  }
  
  public void draw(Graphics g, Component component, Image lastImage, int dx, int dy, int dw, int dh, int sx, int sy, int sw, int sh) {
    if (g != null)
      g.drawImage(lastImage, dx, dy, dw, dh, sx, sy, sw, sh, component); 
  }
  
  public void paint(Graphics g) {
    if (g != null && this.lastImage != null)
      this.blitter.draw(g, this.component, this.lastImage, 0, 0, this.outWidth, this.outHeight, 0, 0, this.lastWidth, this.lastHeight); 
  }
  
  public int newData(Buffer buffer, Vector cacheInputImage, Vector cacheOutputImage, Vector cacheInputData) {
    Object data = buffer.getData();
    if (!(data instanceof int[]))
      return -1; 
    RGBFormat format = (RGBFormat)buffer.getFormat();
    DirectColorModel dcm = new DirectColorModel(format.getBitsPerPixel(), format.getRedMask(), format.getGreenMask(), format.getBlueMask());
    MemoryImageSource sourceImage = new MemoryImageSource(format.getLineStride(), (format.getSize()).height, dcm, (int[])data, 0, format.getLineStride());
    sourceImage.setAnimated(true);
    sourceImage.setFullBufferUpdates(true);
    Image destImage = null;
    if (this.component != null) {
      destImage = this.component.createImage(sourceImage);
      this.component.prepareImage(destImage, this.component);
    } 
    cacheOutputImage.addElement(destImage);
    cacheInputData.addElement(data);
    cacheInputImage.addElement(sourceImage);
    return cacheInputImage.size() - 1;
  }
  
  public class LightComponent extends Component {
    private final AWTRenderer this$0;
    
    public LightComponent(AWTRenderer this$0) {
      this.this$0 = this$0;
    }
    
    public synchronized void paint(Graphics g) {
      this.this$0.paint(g);
    }
    
    public synchronized void update(Graphics g) {}
    
    public Dimension getMinimumSize() {
      return new Dimension(1, 1);
    }
    
    public Dimension getPreferredSize() {
      return this.this$0.myPreferredSize();
    }
    
    public synchronized void addNotify() {
      super.addNotify();
      this.this$0.setAvailable(true);
    }
    
    public synchronized void removeNotify() {
      this.this$0.setAvailable(false);
      super.removeNotify();
    }
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\renderer\video\AWTRenderer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */