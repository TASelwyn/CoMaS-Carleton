/*     */ package com.sun.media.renderer.video;
/*     */ 
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.util.Arch;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.image.DirectColorModel;
/*     */ import java.awt.image.MemoryImageSource;
/*     */ import java.util.Vector;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.RGBFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AWTRenderer
/*     */   extends BasicVideoRenderer
/*     */   implements Blitter
/*     */ {
/*     */   private static final String MyName = "AWT Renderer";
/*     */   private transient Vector cacheInputData;
/*     */   private transient Vector cacheInputImage;
/*     */   private transient Vector cacheOutputImage;
/*     */   private transient Image lastImage;
/*     */   private RGBFormat supportedRGB;
/*     */   private RGBFormat supportedOther;
/*     */   private transient int lastWidth;
/*     */   private transient int lastHeight;
/*     */   private Blitter blitter;
/*  46 */   public static String vendor = null;
/*     */   public static boolean runningOnMac = false;
/*     */   
/*     */   static {
/*     */     try {
/*  51 */       vendor = System.getProperty("java.vendor");
/*  52 */       if (vendor != null) {
/*  53 */         vendor = vendor.toUpperCase();
/*  54 */         if (vendor.startsWith("APPLE")) {
/*  55 */           runningOnMac = true;
/*     */         }
/*     */       } 
/*  58 */     } catch (Throwable e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AWTRenderer() {
/*  68 */     this("AWT Renderer");
/*     */   }
/*     */   
/*     */   public AWTRenderer(String name) {
/*  72 */     super(name); int i; char c; char c1; this.cacheInputData = null; this.cacheInputImage = null; this.cacheOutputImage = null; this.lastImage = null; this.supportedRGB = null; this.supportedOther = null;
/*     */     this.lastWidth = 1;
/*     */     this.lastHeight = 1;
/*     */     this.blitter = null;
/*  76 */     if ((Arch.getArch() & 0x8) != 0 && !runningOnMac) {
/*  77 */       i = 255;
/*  78 */       c = '＀';
/*  79 */       c1 = '\000';
/*     */     } else {
/*  81 */       c1 = 'ÿ';
/*  82 */       c = '＀';
/*  83 */       i = 16711680;
/*     */     } 
/*     */     
/*  86 */     this.supportedRGB = new RGBFormat(null, -1, Format.intArray, -1.0F, 32, i, c, c1, 1, -1, 0, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     this.supportedOther = new RGBFormat(null, -1, Format.intArray, -1.0F, 32, c1, c, i, 1, -1, 0, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     this.supportedFormats = new VideoFormat[2];
/* 106 */     this.supportedFormats[0] = (VideoFormat)this.supportedRGB;
/* 107 */     this.supportedFormats[1] = (VideoFormat)this.supportedOther;
/*     */ 
/*     */ 
/*     */     
/* 111 */     if (runningOnMac) {
/* 112 */       this.supportedFormats[1] = (VideoFormat)this.supportedRGB;
/*     */     }
/*     */     try {
/* 115 */       Class cls = Class.forName("com.sun.media.renderer.video.Java2DRenderer");
/* 116 */       this.blitter = (Blitter)cls.newInstance();
/*     */     } catch (Throwable t) {
/*     */       
/* 119 */       if (t instanceof ThreadDeath)
/* 120 */         throw (ThreadDeath)t; 
/* 121 */       this.blitter = this;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isLightWeight() {
/* 126 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() throws ResourceUnavailableException {
/* 140 */     this.cacheInputData = new Vector();
/* 141 */     this.cacheInputImage = new Vector();
/* 142 */     this.cacheOutputImage = new Vector();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void reset() {
/* 150 */     this.cacheInputData = new Vector();
/* 151 */     this.cacheInputImage = new Vector();
/* 152 */     this.cacheOutputImage = new Vector();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format setInputFormat(Format format) {
/* 164 */     if (super.setInputFormat(format) != null) {
/* 165 */       reset();
/* 166 */       return format;
/*     */     } 
/* 168 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized int doProcess(Buffer buffer) {
/* 176 */     if (this.component == null)
/* 177 */       return 0; 
/* 178 */     if (!buffer.getFormat().equals(this.inputFormat)) {
/* 179 */       Format in = buffer.getFormat();
/* 180 */       if (BasicPlugIn.matches(in, (Format[])this.supportedFormats) == null) {
/* 181 */         return 1;
/*     */       }
/* 183 */       this.inputFormat = (VideoFormat)in;
/*     */     } 
/*     */     
/* 186 */     Object data = buffer.getData();
/* 187 */     if (!(data instanceof int[])) {
/* 188 */       return 1;
/*     */     }
/* 190 */     int cacheSize = this.cacheInputData.size();
/*     */     
/* 192 */     boolean found = false; int i;
/* 193 */     for (i = 0; i < cacheSize; i++) {
/* 194 */       Object bufKnown = this.cacheInputData.elementAt(i);
/* 195 */       if (bufKnown == data) {
/* 196 */         found = true;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 202 */     if (!found) {
/* 203 */       i = this.blitter.newData(buffer, this.cacheInputImage, this.cacheOutputImage, this.cacheInputData);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 209 */     if (i < 0)
/* 210 */       return 1; 
/* 211 */     RGBFormat format = (RGBFormat)buffer.getFormat();
/* 212 */     Dimension size = format.getSize();
/* 213 */     this.inWidth = size.width;
/* 214 */     this.inHeight = size.height;
/* 215 */     if (this.outWidth == -1)
/* 216 */       this.outWidth = size.width; 
/* 217 */     if (this.outHeight == -1) {
/* 218 */       this.outHeight = size.height;
/*     */     }
/* 220 */     this.lastImage = this.blitter.process(buffer, this.cacheInputImage.elementAt(i), this.cacheOutputImage.elementAt(i), size);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 226 */     this.lastWidth = size.width;
/* 227 */     this.lastHeight = size.height;
/*     */     
/* 229 */     if (!isLightWeight()) {
/* 230 */       Graphics g = this.component.getGraphics();
/* 231 */       if (g != null) {
/* 232 */         this.blitter.draw(g, this.component, this.lastImage, 0, 0, this.outWidth, this.outHeight, 0, 0, size.width, size.height);
/*     */       }
/*     */     } else {
/*     */       
/* 236 */       this.component.repaint();
/*     */     } 
/* 238 */     return 0;
/*     */   }
/*     */   
/*     */   protected void repaint() {
/* 242 */     if (!isStarted() && this.lastImage != null) {
/* 243 */       Graphics g = this.component.getGraphics();
/* 244 */       this.blitter.draw(g, this.component, this.lastImage, 0, 0, this.outWidth, this.outHeight, 0, 0, this.lastWidth, this.lastHeight);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getComponent() {
/* 254 */     if (this.component == null)
/* 255 */       if (isLightWeight()) {
/* 256 */         this.component = new LightComponent(this);
/* 257 */         this.component.setBackground(getPreferredBackground());
/* 258 */         if (this.compListener == null)
/* 259 */           this.compListener = new BasicVideoRenderer.CompListener(this); 
/* 260 */         this.component.addComponentListener(this.compListener);
/*     */       } else {
/* 262 */         this.component = super.getComponent();
/*     */       }  
/* 264 */     return this.component;
/*     */   }
/*     */   
/*     */   public synchronized void resized(Component c) {
/* 268 */     super.resized(c);
/* 269 */     if (this.blitter != this) {
/* 270 */       this.blitter.resized(c);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Image process(Buffer buffer, Object cacheInputImage, Object cacheOutputImage, Dimension size) {
/* 280 */     MemoryImageSource sourceImage = (MemoryImageSource)cacheInputImage;
/* 281 */     Image lastImage = (Image)cacheOutputImage;
/* 282 */     sourceImage.newPixels(0, 0, size.width, size.height);
/* 283 */     return lastImage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(Graphics g, Component component, Image lastImage, int dx, int dy, int dw, int dh, int sx, int sy, int sw, int sh) {
/* 289 */     if (g != null) {
/* 290 */       g.drawImage(lastImage, dx, dy, dw, dh, sx, sy, sw, sh, component);
/*     */     }
/*     */   }
/*     */   
/*     */   public void paint(Graphics g) {
/* 295 */     if (g != null && this.lastImage != null) {
/* 296 */       this.blitter.draw(g, this.component, this.lastImage, 0, 0, this.outWidth, this.outHeight, 0, 0, this.lastWidth, this.lastHeight);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int newData(Buffer buffer, Vector cacheInputImage, Vector cacheOutputImage, Vector cacheInputData) {
/* 302 */     Object data = buffer.getData();
/*     */     
/* 304 */     if (!(data instanceof int[]))
/* 305 */       return -1; 
/* 306 */     RGBFormat format = (RGBFormat)buffer.getFormat();
/*     */     
/* 308 */     DirectColorModel dcm = new DirectColorModel(format.getBitsPerPixel(), format.getRedMask(), format.getGreenMask(), format.getBlueMask());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 313 */     MemoryImageSource sourceImage = new MemoryImageSource(format.getLineStride(), (format.getSize()).height, dcm, (int[])data, 0, format.getLineStride());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 318 */     sourceImage.setAnimated(true);
/* 319 */     sourceImage.setFullBufferUpdates(true);
/* 320 */     Image destImage = null;
/* 321 */     if (this.component != null) {
/* 322 */       destImage = this.component.createImage(sourceImage);
/* 323 */       this.component.prepareImage(destImage, this.component);
/*     */     } 
/* 325 */     cacheOutputImage.addElement(destImage);
/* 326 */     cacheInputData.addElement(data);
/* 327 */     cacheInputImage.addElement(sourceImage);
/* 328 */     return cacheInputImage.size() - 1;
/*     */   } public class LightComponent extends Component { private final AWTRenderer this$0;
/*     */     public LightComponent(AWTRenderer this$0) {
/* 331 */       this.this$0 = this$0;
/*     */     } public synchronized void paint(Graphics g) {
/* 333 */       this.this$0.paint(g);
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void update(Graphics g) {}
/*     */     
/*     */     public Dimension getMinimumSize() {
/* 340 */       return new Dimension(1, 1);
/*     */     }
/*     */     
/*     */     public Dimension getPreferredSize() {
/* 344 */       return this.this$0.myPreferredSize();
/*     */     }
/*     */     
/*     */     public synchronized void addNotify() {
/* 348 */       super.addNotify();
/* 349 */       this.this$0.setAvailable(true);
/*     */     }
/*     */     
/*     */     public synchronized void removeNotify() {
/* 353 */       this.this$0.setAvailable(false);
/* 354 */       super.removeNotify();
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\renderer\video\AWTRenderer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */