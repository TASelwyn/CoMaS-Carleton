/*     */ package com.sun.media;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Codec;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.RGBFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BasicCodec
/*     */   extends BasicPlugIn
/*     */   implements Codec
/*     */ {
/*     */   private static final boolean DEBUG = true;
/*     */   protected Format inputFormat;
/*     */   protected Format outputFormat;
/*     */   protected boolean opened = false;
/*  23 */   protected Format[] inputFormats = new Format[0];
/*     */   
/*  25 */   protected Format[] outputFormats = new Format[0];
/*     */   
/*     */   protected boolean pendingEOM = false;
/*     */   
/*     */   public Format setInputFormat(Format input) {
/*  30 */     this.inputFormat = input;
/*  31 */     return input;
/*     */   }
/*     */   
/*     */   public Format setOutputFormat(Format output) {
/*  35 */     this.outputFormat = output;
/*  36 */     return output;
/*     */   }
/*     */   
/*     */   protected Format getInputFormat() {
/*  40 */     return this.inputFormat;
/*     */   }
/*     */   
/*     */   protected Format getOutputFormat() {
/*  44 */     return this.outputFormat;
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {}
/*     */   
/*     */   public void open() throws ResourceUnavailableException {
/*  51 */     this.opened = true;
/*     */   }
/*     */   
/*     */   public void close() {
/*  55 */     this.opened = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Format[] getSupportedInputFormats() {
/*  60 */     return this.inputFormats;
/*     */   }
/*     */   
/*     */   protected RGBFormat updateRGBFormat(VideoFormat newFormat, RGBFormat outputFormat) {
/*  64 */     Dimension size = newFormat.getSize();
/*  65 */     RGBFormat oldFormat = outputFormat;
/*  66 */     int lineStride = size.width * oldFormat.getPixelStride();
/*  67 */     RGBFormat newRGB = new RGBFormat(size, lineStride * size.height, oldFormat.getDataType(), newFormat.getFrameRate(), oldFormat.getBitsPerPixel(), oldFormat.getRedMask(), oldFormat.getGreenMask(), oldFormat.getBlueMask(), oldFormat.getPixelStride(), lineStride, oldFormat.getFlipped(), oldFormat.getEndian());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     return newRGB;
/*     */   }
/*     */   
/*     */   protected boolean isEOM(Buffer inputBuffer) {
/*  84 */     return inputBuffer.isEOM();
/*     */   }
/*     */   
/*     */   protected void propagateEOM(Buffer outputBuffer) {
/*  88 */     updateOutput(outputBuffer, getOutputFormat(), 0, 0);
/*  89 */     outputBuffer.setEOM(true);
/*     */   }
/*     */   
/*     */   protected void updateOutput(Buffer outputBuffer, Format format, int length, int offset) {
/*  93 */     outputBuffer.setFormat(format);
/*  94 */     outputBuffer.setLength(length);
/*  95 */     outputBuffer.setOffset(offset);
/*     */   }
/*     */   
/*     */   protected boolean checkInputBuffer(Buffer inputBuffer) {
/*  99 */     boolean fError = (!isEOM(inputBuffer) && (inputBuffer == null || inputBuffer.getFormat() == null || !checkFormat(inputBuffer.getFormat())));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     if (fError) {
/* 105 */       System.out.println(getClass().getName() + " : [error] checkInputBuffer");
/*     */     }
/* 107 */     return !fError;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean checkFormat(Format format) {
/* 112 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int checkEOM(Buffer inputBuffer, Buffer outputBuffer) {
/* 117 */     processAtEOM(inputBuffer, outputBuffer);
/*     */ 
/*     */ 
/*     */     
/* 121 */     if (outputBuffer.getLength() > 0) {
/* 122 */       this.pendingEOM = true;
/* 123 */       return 2;
/*     */     } 
/*     */     
/* 126 */     propagateEOM(outputBuffer);
/* 127 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int processAtEOM(Buffer inputBuffer, Buffer outputBuffer) {
/* 132 */     return 0;
/*     */   }
/*     */   
/*     */   protected int getArrayElementSize(Class type) {
/* 136 */     if (type == Format.intArray)
/* 137 */       return 4; 
/* 138 */     if (type == Format.shortArray)
/* 139 */       return 2; 
/* 140 */     if (type == Format.byteArray) {
/* 141 */       return 1;
/*     */     }
/* 143 */     return 0;
/*     */   }
/*     */   
/*     */   public abstract int process(Buffer paramBuffer1, Buffer paramBuffer2);
/*     */   
/*     */   public abstract Format[] getSupportedOutputFormats(Format paramFormat);
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\BasicCodec.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */