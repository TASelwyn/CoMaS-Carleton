package com.sun.media;

import java.util.Enumeration;
import java.util.Hashtable;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.Time;

public abstract class BasicModule implements Module, StateTransistor {
  protected Registry inputConnectors = new Registry(this);
  
  protected Registry outputConnectors = new Registry(this);
  
  protected InputConnector[] inputConnectorsArray;
  
  protected OutputConnector[] outputConnectorsArray;
  
  protected int protocol = 0;
  
  protected String name = null;
  
  protected ModuleListener moduleListener;
  
  protected BasicController controller;
  
  protected boolean resetted = false;
  
  protected boolean prefetchFailed = false;
  
  protected JMD jmd = null;
  
  public boolean doRealize() {
    return true;
  }
  
  public void doFailedRealize() {}
  
  public void abortRealize() {}
  
  public void connectorPushed(InputConnector inputConnector) {
    process();
  }
  
  public boolean doPrefetch() {
    this.resetted = false;
    return true;
  }
  
  public void doFailedPrefetch() {}
  
  public void abortPrefetch() {}
  
  public void doStart() {
    this.resetted = false;
  }
  
  public void doStop() {}
  
  public void doDealloc() {}
  
  public void doClose() {}
  
  public void doSetMediaTime(Time t) {}
  
  public float doSetRate(float r) {
    return r;
  }
  
  public Object[] getControls() {
    return null;
  }
  
  public Object getControl(String s) {
    return null;
  }
  
  public void setModuleListener(ModuleListener listener) {
    this.moduleListener = listener;
  }
  
  public void setFormat(Connector connector, Format format) {}
  
  public String[] getInputConnectorNames() {
    return this.inputConnectors.getNames();
  }
  
  public String[] getOutputConnectorNames() {
    return this.outputConnectors.getNames();
  }
  
  public InputConnector getInputConnector(String connectorName) {
    return (InputConnector)this.inputConnectors.get(connectorName);
  }
  
  public OutputConnector getOutputConnector(String connectorName) {
    return (OutputConnector)this.outputConnectors.get(connectorName);
  }
  
  public void registerInputConnector(String name, InputConnector inputConnector) {
    this.inputConnectors.put(name, inputConnector);
    inputConnector.setModule(this);
  }
  
  public void registerOutputConnector(String name, OutputConnector outputConnector) {
    this.outputConnectors.put(name, outputConnector);
    outputConnector.setModule(this);
  }
  
  public void reset() {
    this.resetted = true;
  }
  
  protected boolean verifyBuffer(Buffer buffer) {
    if (buffer.isDiscard())
      return true; 
    Object data = buffer.getData();
    if (buffer.getLength() < 0)
      System.err.println("warning: data length shouldn't be negative: " + buffer.getLength()); 
    if (data == null) {
      System.err.println("warning: data buffer is null");
      if (buffer.getLength() != 0) {
        System.err.println("buffer advertized length = " + buffer.getLength() + " but data buffer is null!");
        return false;
      } 
    } else if (data instanceof byte[]) {
      if (buffer.getLength() > ((byte[])data).length) {
        System.err.println("buffer advertized length = " + buffer.getLength() + " but actual length = " + ((byte[])data).length);
        return false;
      } 
    } else if (data instanceof int[] && 
      buffer.getLength() > ((int[])data).length) {
      System.err.println("buffer advertized length = " + buffer.getLength() + " but actual length = " + ((int[])data).length);
      return false;
    } 
    return true;
  }
  
  public final boolean isInterrupted() {
    return (this.controller == null) ? false : this.controller.isInterrupted();
  }
  
  public boolean isThreaded() {
    return true;
  }
  
  public boolean canRun() {
    for (int i = 0; i < this.inputConnectorsArray.length; i++) {
      if (!this.inputConnectorsArray[i].isValidBufferAvailable())
        return false; 
    } 
    for (int j = 0; j < this.outputConnectorsArray.length; j++) {
      if (!this.outputConnectorsArray[j].isEmptyBufferAvailable())
        return false; 
    } 
    return true;
  }
  
  protected abstract void process();
  
  protected void error() {
    throw new RuntimeException(getClass().getName() + " error");
  }
  
  public final BasicController getController() {
    return this.controller;
  }
  
  public final void setController(BasicController c) {
    this.controller = c;
  }
  
  public final int getState() {
    return this.controller.getState();
  }
  
  public final String getName() {
    return this.name;
  }
  
  public void setName(String name) {
    this.name = name;
  }
  
  public void setJMD(JMD jmd) {
    this.jmd = jmd;
  }
  
  public Time getMediaTime() {
    return this.controller.getMediaTime();
  }
  
  public long getMediaNanoseconds() {
    return this.controller.getMediaNanoseconds();
  }
  
  public long getLatency() {
    return ((PlaybackEngine)this.controller).getLatency();
  }
  
  public void setProtocol(int protocol) {
    this.protocol = protocol;
    Connector[] connectors = this.inputConnectors.getConnectors();
    for (int i = 0; i < connectors.length; i++)
      connectors[i].setProtocol(protocol); 
    connectors = this.outputConnectors.getConnectors();
    for (int j = 0; j < connectors.length; j++)
      connectors[j].setProtocol(protocol); 
  }
  
  public int getProtocol() {
    return this.protocol;
  }
  
  public boolean prefetchFailed() {
    return this.prefetchFailed;
  }
  
  class Registry extends Hashtable {
    Connector def;
    
    private final BasicModule this$0;
    
    Registry(BasicModule this$0) {
      this.this$0 = this$0;
      this.def = null;
    }
    
    String[] getNames() {
      Enumeration namesEnum = keys();
      String[] namesArray = new String[size()];
      for (int i = 0; i < size(); i++)
        namesArray[i] = (String)namesEnum.nextElement(); 
      return namesArray;
    }
    
    void put(String name, Connector connector) {
      if (containsKey(name))
        throw new RuntimeException("Connector '" + name + "' already exists in Module '" + this.this$0.getClass().getName() + "::" + name + "'"); 
      if (this.def == null)
        this.def = connector; 
      put((K)name, (V)connector);
    }
    
    Object get(String name) {
      if (name == null)
        return this.def; 
      return get(name);
    }
    
    Connector[] getConnectors() {
      Enumeration connectorsEnum = elements();
      Connector[] connectorsArray = new Connector[size()];
      for (int i = 0; i < size(); i++)
        connectorsArray[i] = (Connector)connectorsEnum.nextElement(); 
      return connectorsArray;
    }
  }
}
