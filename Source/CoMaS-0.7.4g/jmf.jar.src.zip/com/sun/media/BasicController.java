/*      */ package com.sun.media;
/*      */ 
/*      */ import com.ms.security.PermissionID;
/*      */ import com.ms.security.PolicyEngine;
/*      */ import com.sun.media.util.jdk12;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Vector;
/*      */ import javax.media.Clock;
/*      */ import javax.media.ClockStartedError;
/*      */ import javax.media.ClockStoppedException;
/*      */ import javax.media.ConfigureCompleteEvent;
/*      */ import javax.media.Control;
/*      */ import javax.media.Controller;
/*      */ import javax.media.ControllerEvent;
/*      */ import javax.media.ControllerListener;
/*      */ import javax.media.DeallocateEvent;
/*      */ import javax.media.Duration;
/*      */ import javax.media.IncompatibleTimeBaseException;
/*      */ import javax.media.MediaTimeSetEvent;
/*      */ import javax.media.NotPrefetchedError;
/*      */ import javax.media.NotRealizedError;
/*      */ import javax.media.PrefetchCompleteEvent;
/*      */ import javax.media.RateChangeEvent;
/*      */ import javax.media.RealizeCompleteEvent;
/*      */ import javax.media.ResourceUnavailableEvent;
/*      */ import javax.media.StartEvent;
/*      */ import javax.media.StopAtTimeEvent;
/*      */ import javax.media.StopTimeChangeEvent;
/*      */ import javax.media.Time;
/*      */ import javax.media.TimeBase;
/*      */ import javax.media.TransitionEvent;
/*      */ 
/*      */ public abstract class BasicController implements Controller, Duration {
/*   36 */   private int targetState = 100;
/*   37 */   protected int state = 100;
/*   38 */   private Vector listenerList = null;
/*      */   private SendEventQueue sendEvtQueue;
/*   40 */   private ConfigureWorkThread configureThread = null;
/*   41 */   private RealizeWorkThread realizeThread = null;
/*   42 */   private PrefetchWorkThread prefetchThread = null;
/*   43 */   protected String processError = null;
/*      */   
/*      */   private Clock clock;
/*   46 */   private TimedStartThread startThread = null;
/*   47 */   private StopTimeThread stopTimeThread = null;
/*      */   private boolean interrupted = false;
/*   49 */   private Object interruptSync = new Object();
/*      */   
/*      */   static final int Configuring = 140;
/*      */   
/*      */   static final int Configured = 180;
/*   54 */   private static JMFSecurity jmfSecurity = null;
/*      */   private static boolean securityPrivelege = false;
/*   56 */   private Method[] m = new Method[1];
/*   57 */   private Class[] cl = new Class[1];
/*   58 */   private Object[][] args = new Object[1][0];
/*      */   
/*      */   protected boolean stopThreadEnabled = true;
/*      */   
/*      */   static {
/*      */     try {
/*   64 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*   65 */       securityPrivelege = true;
/*   66 */     } catch (SecurityException e) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BasicController() {
/*   74 */     if (jmfSecurity != null) {
/*   75 */       String permission = null;
/*      */       
/*      */       try {
/*   78 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/*   79 */           permission = "thread";
/*   80 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/*   81 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*      */           
/*   83 */           permission = "thread group";
/*   84 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/*   85 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*   86 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/*   87 */           PolicyEngine.checkPermission(PermissionID.THREAD);
/*   88 */           PolicyEngine.assertPermission(PermissionID.THREAD);
/*      */         }
/*      */       
/*   91 */       } catch (Throwable e) {
/*      */ 
/*      */ 
/*      */         
/*   95 */         securityPrivelege = false;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  102 */     if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*      */       try {
/*  104 */         Constructor cons = CreateWorkThreadAction.cons;
/*  105 */         this.sendEvtQueue = (SendEventQueue)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { SendEventQueue.class, BasicController.class, this }) });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  115 */         this.sendEvtQueue.setName(this.sendEvtQueue.getName() + ": SendEventQueue: " + getClass().getName());
/*      */         
/*  117 */         this.sendEvtQueue.start();
/*  118 */         this.clock = new BasicClock();
/*  119 */       } catch (Exception e) {}
/*      */     } else {
/*      */       
/*  122 */       this.sendEvtQueue = new SendEventQueue(this);
/*  123 */       this.sendEvtQueue.setName(this.sendEvtQueue.getName() + ": SendEventQueue: " + getClass().getName());
/*      */       
/*  125 */       this.sendEvtQueue.start();
/*  126 */       this.clock = new BasicClock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setClock(Clock c) {
/*  142 */     this.clock = c;
/*      */   }
/*      */   
/*      */   protected Clock getClock() {
/*  146 */     return this.clock;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void interrupt() {
/*  153 */     synchronized (this.interruptSync) {
/*  154 */       this.interrupted = true;
/*  155 */       this.interruptSync.notify();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void resetInterrupt() {
/*  163 */     synchronized (this.interruptSync) {
/*  164 */       this.interrupted = false;
/*  165 */       this.interruptSync.notify();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isInterrupted() {
/*  173 */     return this.interrupted;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean doConfigure() {
/*  180 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void abortConfigure() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doStop() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void close() {
/*  261 */     doClose();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  266 */     interrupt();
/*      */     
/*  268 */     if (this.startThread != null) {
/*  269 */       this.startThread.abort();
/*      */     }
/*  271 */     if (this.stopTimeThread != null) {
/*  272 */       this.stopTimeThread.abort();
/*      */     }
/*  274 */     if (this.sendEvtQueue != null) {
/*  275 */       this.sendEvtQueue.kill();
/*  276 */       this.sendEvtQueue = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doClose() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  298 */   static String TimeBaseError = "Cannot set time base on an unrealized controller.";
/*      */   public void setTimeBase(TimeBase tb) throws IncompatibleTimeBaseException {
/*  300 */     if (this.state < 300) {
/*  301 */       throwError((Error)new NotRealizedError(TimeBaseError));
/*      */     }
/*  303 */     this.clock.setTimeBase(tb);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Control[] getControls() {
/*  317 */     return new Control[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Control getControl(String type) {
/*      */     Class cls;
/*      */     try {
/*  333 */       cls = Class.forName(type);
/*      */     } catch (ClassNotFoundException e) {
/*  335 */       return null;
/*      */     } 
/*  337 */     Control[] cs = getControls();
/*  338 */     for (int i = 0; i < cs.length; i++) {
/*  339 */       if (cls.isInstance(cs[i]))
/*  340 */         return cs[i]; 
/*      */     } 
/*  342 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  354 */   static String SyncStartError = "Cannot start the controller before it has been prefetched.";
/*      */   public void syncStart(Time tbt) {
/*  356 */     if (this.state < 500) {
/*  357 */       throwError((Error)new NotPrefetchedError(SyncStartError));
/*      */     }
/*  359 */     this.clock.syncStart(tbt);
/*  360 */     this.state = 600;
/*  361 */     setTargetState(600);
/*  362 */     sendEvent((ControllerEvent)new StartEvent(this, 500, 600, 600, getMediaTime(), tbt));
/*      */     
/*      */     long timeToStop;
/*  365 */     if ((timeToStop = checkStopTime()) < 0L || (this.stopThreadEnabled && activateStopThread(timeToStop))) {
/*      */ 
/*      */ 
/*      */       
/*  369 */       stopAtTime();
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/*  377 */     if (jmfSecurity != null) {
/*  378 */       String permission = null;
/*      */       try {
/*  380 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  381 */           permission = "thread";
/*  382 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/*  383 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*      */           
/*  385 */           permission = "thread group";
/*  386 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/*  387 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*  388 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/*  389 */           PolicyEngine.checkPermission(PermissionID.THREAD);
/*  390 */           PolicyEngine.assertPermission(PermissionID.THREAD);
/*      */         }
/*      */       
/*  393 */       } catch (Throwable e) {
/*      */ 
/*      */ 
/*      */         
/*  397 */         securityPrivelege = false;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  403 */     if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*      */       try {
/*  405 */         Constructor cons = CreateTimedThreadAction.cons;
/*  406 */         this.startThread = (TimedStartThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { TimedStartThread.class, BasicController.class, this, new Long(tbt.getNanoseconds()) }) });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  418 */         this.startThread.setName(this.startThread.getName() + " ( startThread: " + this + " )");
/*  419 */         this.startThread.start();
/*  420 */       } catch (Exception e) {}
/*      */     }
/*      */     else {
/*      */       
/*  424 */       this.startThread = new TimedStartThread(this, tbt.getNanoseconds());
/*  425 */       this.startThread.setName(this.startThread.getName() + " ( startThread: " + this + " )");
/*  426 */       this.startThread.start();
/*      */     } 
/*      */   }
/*      */   
/*      */   protected boolean syncStartInProgress() {
/*  431 */     return (this.startThread != null && this.startThread.isAlive());
/*      */   }
/*      */ 
/*      */   
/*      */   private long checkStopTime() {
/*  436 */     long stopTime = getStopTime().getNanoseconds();
/*      */     
/*  438 */     if (stopTime == Long.MAX_VALUE) {
/*  439 */       return 1L;
/*      */     }
/*  441 */     return (long)((float)(stopTime - getMediaTime().getNanoseconds()) / getRate());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean activateStopThread(long timeToStop) {
/*  447 */     if (getStopTime().getNanoseconds() == Long.MAX_VALUE) {
/*  448 */       return false;
/*      */     }
/*  450 */     if (this.stopTimeThread != null && this.stopTimeThread.isAlive()) {
/*  451 */       this.stopTimeThread.abort();
/*  452 */       this.stopTimeThread = null;
/*      */     } 
/*      */     
/*  455 */     if (timeToStop > 100000000L) {
/*  456 */       if (jmfSecurity != null) {
/*  457 */         String permission = null;
/*      */         
/*      */         try {
/*  460 */           if (jmfSecurity.getName().startsWith("jmf-security")) {
/*      */             
/*  462 */             permission = "thread";
/*  463 */             jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/*  464 */             this.m[0].invoke(this.cl[0], this.args[0]);
/*      */             
/*  466 */             permission = "thread group";
/*  467 */             jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/*  468 */             this.m[0].invoke(this.cl[0], this.args[0]);
/*  469 */           } else if (jmfSecurity.getName().startsWith("internet")) {
/*  470 */             PolicyEngine.checkPermission(PermissionID.THREAD);
/*  471 */             PolicyEngine.assertPermission(PermissionID.THREAD);
/*      */           }
/*      */         
/*  474 */         } catch (Throwable e) {
/*      */ 
/*      */ 
/*      */           
/*  478 */           securityPrivelege = false;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  484 */       if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*      */         try {
/*  486 */           Constructor cons = CreateTimedThreadAction.cons;
/*  487 */           this.stopTimeThread = (StopTimeThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { StopTimeThread.class, BasicController.class, this, new Long(timeToStop) }) });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  499 */           this.stopTimeThread.start();
/*  500 */         } catch (Exception e) {}
/*      */       } else {
/*      */         
/*  503 */         (this.stopTimeThread = new StopTimeThread(this, timeToStop)).start();
/*      */       } 
/*      */       
/*  506 */       return false;
/*      */     } 
/*      */     
/*  509 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void stop() {
/*  522 */     if (this.state == 600 || this.state == 400) {
/*  523 */       stopControllerOnly();
/*  524 */       doStop();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void stopControllerOnly() {
/*  536 */     if (this.state == 600 || this.state == 400) {
/*  537 */       this.clock.stop();
/*  538 */       this.state = 500;
/*  539 */       setTargetState(500);
/*      */       
/*  541 */       if (this.stopTimeThread != null && this.stopTimeThread.isAlive() && Thread.currentThread() != this.stopTimeThread)
/*      */       {
/*  543 */         this.stopTimeThread.abort();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  549 */       if (this.startThread != null && this.startThread.isAlive()) {
/*  550 */         this.startThread.abort();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void stopAtTime() {
/*  559 */     stop();
/*  560 */     setStopTime(Clock.RESET);
/*  561 */     sendEvent((ControllerEvent)new StopAtTimeEvent(this, 600, 500, getTargetState(), getMediaTime()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  575 */   static String StopTimeError = "Cannot set stop time on an unrealized controller.";
/*      */   
/*      */   public void setStopTime(Time t) {
/*  578 */     if (this.state < 300) {
/*  579 */       throwError((Error)new NotRealizedError(StopTimeError));
/*      */     }
/*  581 */     Time oldStopTime = getStopTime();
/*  582 */     this.clock.setStopTime(t);
/*  583 */     boolean stopTimeHasPassed = false;
/*  584 */     if (this.state == 600) {
/*      */       long timeToStop;
/*  586 */       if ((timeToStop = checkStopTime()) < 0L || (this.stopThreadEnabled && activateStopThread(timeToStop)))
/*      */       {
/*  588 */         stopTimeHasPassed = true; } 
/*      */     } 
/*  590 */     if (oldStopTime.getNanoseconds() != t.getNanoseconds()) {
/*  591 */       sendEvent((ControllerEvent)new StopTimeChangeEvent(this, t));
/*      */     }
/*  593 */     if (stopTimeHasPassed) {
/*  594 */       stopAtTime();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getStopTime() {
/*  603 */     return this.clock.getStopTime();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  614 */   static String MediaTimeError = "Cannot set media time on a unrealized controller";
/*      */   public void setMediaTime(Time when) {
/*  616 */     if (this.state < 300) {
/*  617 */       throwError((Error)new NotRealizedError(MediaTimeError));
/*      */     }
/*  619 */     this.clock.setMediaTime(when);
/*  620 */     doSetMediaTime(when);
/*  621 */     sendEvent((ControllerEvent)new MediaTimeSetEvent(this, when));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doSetMediaTime(Time when) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getMediaTime() {
/*  634 */     return this.clock.getMediaTime();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getMediaNanoseconds() {
/*  642 */     return this.clock.getMediaNanoseconds();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getSyncTime() {
/*  650 */     return new Time(0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  657 */   static String GetTimeBaseError = "Cannot get Time Base from an unrealized controller";
/*      */   public TimeBase getTimeBase() {
/*  659 */     if (this.state < 300) {
/*  660 */       throwError((Error)new NotRealizedError(GetTimeBaseError));
/*      */     }
/*      */     
/*  663 */     return this.clock.getTimeBase();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time mapToTimeBase(Time t) throws ClockStoppedException {
/*  674 */     return this.clock.mapToTimeBase(t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  691 */   static String SetRateError = "Cannot set rate on an unrealized controller.";
/*      */   public float setRate(float factor) {
/*  693 */     if (this.state < 300) {
/*  694 */       throwError((Error)new NotRealizedError(SetRateError));
/*      */     }
/*      */     
/*  697 */     float oldRate = getRate();
/*  698 */     float rateSet = doSetRate(factor);
/*  699 */     float newRate = this.clock.setRate(rateSet);
/*      */     
/*  701 */     if (newRate != oldRate) {
/*  702 */       sendEvent((ControllerEvent)new RateChangeEvent(this, newRate));
/*      */     }
/*  704 */     return newRate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected float doSetRate(float factor) {
/*  713 */     return factor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getRate() {
/*  721 */     return this.clock.getRate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getState() {
/*  729 */     return this.state;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void setTargetState(int state) {
/*  736 */     this.targetState = state;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getTargetState() {
/*  744 */     return this.targetState;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  752 */   static String LatencyError = "Cannot get start latency from an unrealized controller";
/*      */   public Time getStartLatency() {
/*  754 */     if (this.state < 300) {
/*  755 */       throwError((Error)new NotRealizedError(LatencyError));
/*      */     }
/*  757 */     return Controller.LATENCY_UNKNOWN;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getDuration() {
/*  766 */     return Duration.DURATION_UNKNOWN;
/*      */   }
/*      */   
/*      */   protected void setMediaLength(long t) {
/*  770 */     if (this.clock instanceof BasicClock)
/*  771 */       ((BasicClock)this.clock).setMediaLength(t); 
/*      */   }
/*      */   
/*      */   public synchronized void configure() {
/*  775 */     if (getTargetState() < 180) {
/*  776 */       setTargetState(180);
/*      */     }
/*  778 */     switch (this.state) {
/*      */       case 180:
/*      */       case 200:
/*      */       case 300:
/*      */       case 400:
/*      */       case 500:
/*      */       case 600:
/*  785 */         sendEvent((ControllerEvent)new ConfigureCompleteEvent(this, this.state, this.state, getTargetState()));
/*      */         break;
/*      */ 
/*      */       
/*      */       case 100:
/*  790 */         this.state = 140;
/*  791 */         sendEvent((ControllerEvent)new TransitionEvent(this, 100, 140, getTargetState()));
/*      */         
/*  793 */         if (jmfSecurity != null) {
/*  794 */           String permission = null;
/*      */           try {
/*  796 */             if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  797 */               permission = "thread";
/*  798 */               jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/*  799 */               this.m[0].invoke(this.cl[0], this.args[0]);
/*      */               
/*  801 */               permission = "thread group";
/*  802 */               jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/*  803 */               this.m[0].invoke(this.cl[0], this.args[0]);
/*  804 */             } else if (jmfSecurity.getName().startsWith("internet")) {
/*  805 */               PolicyEngine.checkPermission(PermissionID.THREAD);
/*  806 */               PolicyEngine.assertPermission(PermissionID.THREAD);
/*      */             }
/*      */           
/*  809 */           } catch (Throwable e) {
/*      */ 
/*      */ 
/*      */             
/*  813 */             securityPrivelege = false;
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  819 */         if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*      */           try {
/*  821 */             Constructor cons = CreateWorkThreadAction.cons;
/*  822 */             this.configureThread = (ConfigureWorkThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { ConfigureWorkThread.class, BasicController.class, this }) });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  832 */             this.configureThread.setName(this.configureThread.getName() + "[ " + this + " ]" + " ( configureThread)");
/*      */ 
/*      */ 
/*      */             
/*  836 */             this.configureThread.start();
/*  837 */           } catch (Exception e) {}
/*      */           
/*      */           break;
/*      */         } 
/*  841 */         this.configureThread = new ConfigureWorkThread(this);
/*  842 */         this.configureThread.setName(this.configureThread.getName() + "[ " + this + " ]" + " ( configureThread)");
/*      */ 
/*      */ 
/*      */         
/*  846 */         this.configureThread.start();
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void completeConfigure() {
/*  859 */     this.state = 180;
/*  860 */     sendEvent((ControllerEvent)new ConfigureCompleteEvent(this, 140, 180, getTargetState()));
/*      */     
/*  862 */     if (getTargetState() >= 300) {
/*  863 */       realize();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doFailedConfigure() {
/*  871 */     this.state = 100;
/*  872 */     setTargetState(100);
/*  873 */     String msg = "Failed to configure";
/*  874 */     if (this.processError != null)
/*  875 */       msg = msg + ": " + this.processError; 
/*  876 */     sendEvent((ControllerEvent)new ResourceUnavailableEvent(this, msg));
/*  877 */     this.processError = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final synchronized void realize() {
/*      */     int oldState;
/*  892 */     if (getTargetState() < 300) {
/*  893 */       setTargetState(300);
/*      */     }
/*  895 */     switch (this.state) {
/*      */       case 300:
/*      */       case 400:
/*      */       case 500:
/*      */       case 600:
/*  900 */         sendEvent((ControllerEvent)new RealizeCompleteEvent(this, this.state, this.state, getTargetState()));
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 100:
/*  907 */         if (isConfigurable()) {
/*  908 */           configure();
/*      */           break;
/*      */         } 
/*      */       
/*      */       case 180:
/*  913 */         oldState = this.state;
/*  914 */         this.state = 200;
/*  915 */         sendEvent((ControllerEvent)new TransitionEvent(this, oldState, 200, getTargetState()));
/*      */ 
/*      */ 
/*      */         
/*  919 */         if (jmfSecurity != null) {
/*  920 */           String permission = null;
/*      */           try {
/*  922 */             if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  923 */               permission = "thread";
/*  924 */               jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/*  925 */               this.m[0].invoke(this.cl[0], this.args[0]);
/*      */               
/*  927 */               permission = "thread group";
/*  928 */               jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/*  929 */               this.m[0].invoke(this.cl[0], this.args[0]);
/*  930 */             } else if (jmfSecurity.getName().startsWith("internet")) {
/*  931 */               PolicyEngine.checkPermission(PermissionID.THREAD);
/*  932 */               PolicyEngine.assertPermission(PermissionID.THREAD);
/*      */             }
/*      */           
/*  935 */           } catch (Throwable e) {
/*      */ 
/*      */ 
/*      */             
/*  939 */             securityPrivelege = false;
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/*  944 */         if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*      */           try {
/*  946 */             Constructor cons = CreateWorkThreadAction.cons;
/*  947 */             this.realizeThread = (RealizeWorkThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { RealizeWorkThread.class, BasicController.class, this }) });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  957 */             this.realizeThread.setName(this.realizeThread.getName() + "[ " + this + " ]" + " ( realizeThread)");
/*      */ 
/*      */ 
/*      */             
/*  961 */             this.realizeThread.start();
/*      */           }
/*  963 */           catch (Exception e) {}
/*      */           break;
/*      */         } 
/*  966 */         this.realizeThread = new RealizeWorkThread(this);
/*  967 */         this.realizeThread.setName(this.realizeThread.getName() + "[ " + this + " ]" + " ( realizeThread)");
/*      */ 
/*      */ 
/*      */         
/*  971 */         this.realizeThread.start();
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void completeRealize() {
/*  987 */     this.state = 300;
/*  988 */     sendEvent((ControllerEvent)new RealizeCompleteEvent(this, 200, 300, getTargetState()));
/*      */     
/*  990 */     if (getTargetState() >= 500) {
/*  991 */       prefetch();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doFailedRealize() {
/*  999 */     this.state = 100;
/* 1000 */     setTargetState(100);
/* 1001 */     String msg = "Failed to realize";
/* 1002 */     if (this.processError != null)
/* 1003 */       msg = msg + ": " + this.processError; 
/* 1004 */     sendEvent((ControllerEvent)new ResourceUnavailableEvent(this, msg));
/* 1005 */     this.processError = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void prefetch() {
/* 1019 */     if (getTargetState() <= 300)
/* 1020 */       setTargetState(500); 
/* 1021 */     switch (this.state) {
/*      */       case 500:
/*      */       case 600:
/* 1024 */         sendEvent((ControllerEvent)new PrefetchCompleteEvent(this, this.state, this.state, getTargetState()));
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 100:
/*      */       case 180:
/* 1034 */         realize();
/*      */         break;
/*      */ 
/*      */       
/*      */       case 300:
/* 1039 */         this.state = 400;
/* 1040 */         sendEvent((ControllerEvent)new TransitionEvent(this, 300, 400, getTargetState()));
/*      */ 
/*      */         
/* 1043 */         if (jmfSecurity != null) {
/* 1044 */           String permission = null;
/*      */           try {
/* 1046 */             if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 1047 */               permission = "thread";
/* 1048 */               jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/* 1049 */               this.m[0].invoke(this.cl[0], this.args[0]);
/*      */               
/* 1051 */               permission = "thread group";
/* 1052 */               jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/* 1053 */               this.m[0].invoke(this.cl[0], this.args[0]);
/* 1054 */             } else if (jmfSecurity.getName().startsWith("internet")) {
/* 1055 */               PolicyEngine.checkPermission(PermissionID.THREAD);
/* 1056 */               PolicyEngine.assertPermission(PermissionID.THREAD);
/*      */             }
/*      */           
/* 1059 */           } catch (Throwable e) {
/*      */ 
/*      */ 
/*      */             
/* 1063 */             securityPrivelege = false;
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 1068 */         if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*      */           try {
/* 1070 */             Constructor cons = CreateWorkThreadAction.cons;
/* 1071 */             this.prefetchThread = (PrefetchWorkThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { PrefetchWorkThread.class, BasicController.class, this }) });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1081 */             this.prefetchThread.setName(this.prefetchThread.getName() + "[ " + this + " ]" + " ( prefetchThread)");
/*      */ 
/*      */ 
/*      */             
/* 1085 */             this.prefetchThread.start();
/*      */           }
/* 1087 */           catch (Exception e) {}
/*      */           break;
/*      */         } 
/* 1090 */         this.prefetchThread = new PrefetchWorkThread(this);
/* 1091 */         this.prefetchThread.setName(this.prefetchThread.getName() + " ( prefetchThread)");
/* 1092 */         this.prefetchThread.start();
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void completePrefetch() {
/* 1109 */     this.clock.stop();
/* 1110 */     this.state = 500;
/* 1111 */     sendEvent((ControllerEvent)new PrefetchCompleteEvent(this, 400, 500, getTargetState()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doFailedPrefetch() {
/* 1118 */     this.state = 300;
/* 1119 */     setTargetState(300);
/* 1120 */     String msg = "Failed to prefetch";
/* 1121 */     if (this.processError != null)
/* 1122 */       msg = msg + ": " + this.processError; 
/* 1123 */     sendEvent((ControllerEvent)new ResourceUnavailableEvent(this, msg));
/* 1124 */     this.processError = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1137 */   static String DeallocateError = "deallocate cannot be used on a started controller.";
/*      */   
/*      */   public final void deallocate() {
/* 1140 */     int previousState = getState();
/*      */     
/* 1142 */     if (this.state == 600) {
/* 1143 */       throwError((Error)new ClockStartedError(DeallocateError));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1150 */     switch (this.state) {
/*      */       case 140:
/*      */       case 200:
/* 1153 */         interrupt();
/* 1154 */         this.state = 100;
/*      */         break;
/*      */       case 400:
/* 1157 */         interrupt();
/* 1158 */         this.state = 300;
/*      */         break;
/*      */       case 500:
/* 1161 */         abortPrefetch();
/* 1162 */         this.state = 300;
/* 1163 */         resetInterrupt();
/*      */         break;
/*      */     } 
/*      */     
/* 1167 */     setTargetState(this.state);
/*      */ 
/*      */     
/* 1170 */     doDeallocate();
/*      */ 
/*      */     
/* 1173 */     synchronized (this.interruptSync) {
/* 1174 */       while (isInterrupted()) {
/*      */         try {
/* 1176 */           this.interruptSync.wait();
/* 1177 */         } catch (InterruptedException e) {}
/*      */       } 
/*      */     } 
/*      */     
/* 1181 */     sendEvent((ControllerEvent)new DeallocateEvent(this, previousState, this.state, this.state, getMediaTime()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doDeallocate() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addControllerListener(ControllerListener listener) {
/* 1200 */     if (this.listenerList == null) {
/* 1201 */       this.listenerList = new Vector();
/*      */     }
/*      */     
/* 1204 */     synchronized (this.listenerList) {
/* 1205 */       if (!this.listenerList.contains(listener)) {
/* 1206 */         this.listenerList.addElement(listener);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void removeControllerListener(ControllerListener listener) {
/* 1218 */     if (this.listenerList == null)
/*      */       return; 
/* 1220 */     synchronized (this.listenerList) {
/* 1221 */       if (this.listenerList != null) {
/* 1222 */         this.listenerList.removeElement(listener);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void sendEvent(ControllerEvent evt) {
/* 1233 */     if (this.sendEvtQueue != null) {
/* 1234 */       this.sendEvtQueue.postEvent(evt);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void dispatchEvent(ControllerEvent evt) {
/* 1247 */     if (this.listenerList == null) {
/*      */       return;
/*      */     }
/* 1250 */     synchronized (this.listenerList) {
/* 1251 */       Enumeration list = this.listenerList.elements();
/* 1252 */       while (list.hasMoreElements()) {
/* 1253 */         ControllerListener listener = list.nextElement();
/* 1254 */         listener.controllerUpdate(evt);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void throwError(Error e) {
/* 1261 */     Log.dumpStack(e);
/* 1262 */     throw e;
/*      */   }
/*      */   
/*      */   protected abstract boolean isConfigurable();
/*      */   
/*      */   protected abstract boolean doRealize();
/*      */   
/*      */   protected abstract void abortRealize();
/*      */   
/*      */   protected abstract boolean doPrefetch();
/*      */   
/*      */   protected abstract void abortPrefetch();
/*      */   
/*      */   protected abstract void doStart();
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\BasicController.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */