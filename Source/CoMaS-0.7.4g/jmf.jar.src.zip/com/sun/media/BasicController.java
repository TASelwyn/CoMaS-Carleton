package com.sun.media;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import com.sun.media.util.jdk12;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Vector;
import javax.media.Clock;
import javax.media.ClockStartedError;
import javax.media.ClockStoppedException;
import javax.media.ConfigureCompleteEvent;
import javax.media.Control;
import javax.media.Controller;
import javax.media.ControllerEvent;
import javax.media.ControllerListener;
import javax.media.DeallocateEvent;
import javax.media.Duration;
import javax.media.IncompatibleTimeBaseException;
import javax.media.MediaTimeSetEvent;
import javax.media.NotPrefetchedError;
import javax.media.NotRealizedError;
import javax.media.PrefetchCompleteEvent;
import javax.media.RateChangeEvent;
import javax.media.RealizeCompleteEvent;
import javax.media.ResourceUnavailableEvent;
import javax.media.StartEvent;
import javax.media.StopAtTimeEvent;
import javax.media.StopTimeChangeEvent;
import javax.media.Time;
import javax.media.TimeBase;
import javax.media.TransitionEvent;

public abstract class BasicController implements Controller, Duration {
  private int targetState = 100;
  
  protected int state = 100;
  
  private Vector listenerList = null;
  
  private SendEventQueue sendEvtQueue;
  
  private ConfigureWorkThread configureThread = null;
  
  private RealizeWorkThread realizeThread = null;
  
  private PrefetchWorkThread prefetchThread = null;
  
  protected String processError = null;
  
  private Clock clock;
  
  private TimedStartThread startThread = null;
  
  private StopTimeThread stopTimeThread = null;
  
  private boolean interrupted = false;
  
  private Object interruptSync = new Object();
  
  static final int Configuring = 140;
  
  static final int Configured = 180;
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] m = new Method[1];
  
  private Class[] cl = new Class[1];
  
  private Object[][] args = new Object[1][0];
  
  protected boolean stopThreadEnabled = true;
  
  static {
    try {
      jmfSecurity = JMFSecurityManager.getJMFSecurity();
      securityPrivelege = true;
    } catch (SecurityException e) {}
  }
  
  public BasicController() {
    if (jmfSecurity != null) {
      String permission = null;
      try {
        if (jmfSecurity.getName().startsWith("jmf-security")) {
          permission = "thread";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
          this.m[0].invoke(this.cl[0], this.args[0]);
          permission = "thread group";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
          this.m[0].invoke(this.cl[0], this.args[0]);
        } else if (jmfSecurity.getName().startsWith("internet")) {
          PolicyEngine.checkPermission(PermissionID.THREAD);
          PolicyEngine.assertPermission(PermissionID.THREAD);
        } 
      } catch (Throwable e) {
        securityPrivelege = false;
      } 
    } 
    if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
      try {
        Constructor cons = CreateWorkThreadAction.cons;
        this.sendEvtQueue = (SendEventQueue)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { SendEventQueue.class, BasicController.class, this }) });
        this.sendEvtQueue.setName(this.sendEvtQueue.getName() + ": SendEventQueue: " + getClass().getName());
        this.sendEvtQueue.start();
        this.clock = new BasicClock();
      } catch (Exception e) {}
    } else {
      this.sendEvtQueue = new SendEventQueue(this);
      this.sendEvtQueue.setName(this.sendEvtQueue.getName() + ": SendEventQueue: " + getClass().getName());
      this.sendEvtQueue.start();
      this.clock = new BasicClock();
    } 
  }
  
  protected void setClock(Clock c) {
    this.clock = c;
  }
  
  protected Clock getClock() {
    return this.clock;
  }
  
  protected void interrupt() {
    synchronized (this.interruptSync) {
      this.interrupted = true;
      this.interruptSync.notify();
    } 
  }
  
  protected void resetInterrupt() {
    synchronized (this.interruptSync) {
      this.interrupted = false;
      this.interruptSync.notify();
    } 
  }
  
  protected boolean isInterrupted() {
    return this.interrupted;
  }
  
  protected boolean doConfigure() {
    return true;
  }
  
  protected void abortConfigure() {}
  
  protected void doStop() {}
  
  public final void close() {
    doClose();
    interrupt();
    if (this.startThread != null)
      this.startThread.abort(); 
    if (this.stopTimeThread != null)
      this.stopTimeThread.abort(); 
    if (this.sendEvtQueue != null) {
      this.sendEvtQueue.kill();
      this.sendEvtQueue = null;
    } 
  }
  
  protected void doClose() {}
  
  static String TimeBaseError = "Cannot set time base on an unrealized controller.";
  
  public void setTimeBase(TimeBase tb) throws IncompatibleTimeBaseException {
    if (this.state < 300)
      throwError((Error)new NotRealizedError(TimeBaseError)); 
    this.clock.setTimeBase(tb);
  }
  
  public Control[] getControls() {
    return new Control[0];
  }
  
  public Control getControl(String type) {
    Class cls;
    try {
      cls = Class.forName(type);
    } catch (ClassNotFoundException e) {
      return null;
    } 
    Control[] cs = getControls();
    for (int i = 0; i < cs.length; i++) {
      if (cls.isInstance(cs[i]))
        return cs[i]; 
    } 
    return null;
  }
  
  static String SyncStartError = "Cannot start the controller before it has been prefetched.";
  
  public void syncStart(Time tbt) {
    if (this.state < 500)
      throwError((Error)new NotPrefetchedError(SyncStartError)); 
    this.clock.syncStart(tbt);
    this.state = 600;
    setTargetState(600);
    sendEvent((ControllerEvent)new StartEvent(this, 500, 600, 600, getMediaTime(), tbt));
    long timeToStop;
    if ((timeToStop = checkStopTime()) < 0L || (this.stopThreadEnabled && activateStopThread(timeToStop))) {
      stopAtTime();
      return;
    } 
    if (jmfSecurity != null) {
      String permission = null;
      try {
        if (jmfSecurity.getName().startsWith("jmf-security")) {
          permission = "thread";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
          this.m[0].invoke(this.cl[0], this.args[0]);
          permission = "thread group";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
          this.m[0].invoke(this.cl[0], this.args[0]);
        } else if (jmfSecurity.getName().startsWith("internet")) {
          PolicyEngine.checkPermission(PermissionID.THREAD);
          PolicyEngine.assertPermission(PermissionID.THREAD);
        } 
      } catch (Throwable e) {
        securityPrivelege = false;
      } 
    } 
    if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
      try {
        Constructor cons = CreateTimedThreadAction.cons;
        this.startThread = (TimedStartThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { TimedStartThread.class, BasicController.class, this, new Long(tbt.getNanoseconds()) }) });
        this.startThread.setName(this.startThread.getName() + " ( startThread: " + this + " )");
        this.startThread.start();
      } catch (Exception e) {}
    } else {
      this.startThread = new TimedStartThread(this, tbt.getNanoseconds());
      this.startThread.setName(this.startThread.getName() + " ( startThread: " + this + " )");
      this.startThread.start();
    } 
  }
  
  protected boolean syncStartInProgress() {
    return (this.startThread != null && this.startThread.isAlive());
  }
  
  private long checkStopTime() {
    long stopTime = getStopTime().getNanoseconds();
    if (stopTime == Long.MAX_VALUE)
      return 1L; 
    return (long)((float)(stopTime - getMediaTime().getNanoseconds()) / getRate());
  }
  
  private boolean activateStopThread(long timeToStop) {
    if (getStopTime().getNanoseconds() == Long.MAX_VALUE)
      return false; 
    if (this.stopTimeThread != null && this.stopTimeThread.isAlive()) {
      this.stopTimeThread.abort();
      this.stopTimeThread = null;
    } 
    if (timeToStop > 100000000L) {
      if (jmfSecurity != null) {
        String permission = null;
        try {
          if (jmfSecurity.getName().startsWith("jmf-security")) {
            permission = "thread";
            jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
            this.m[0].invoke(this.cl[0], this.args[0]);
            permission = "thread group";
            jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
            this.m[0].invoke(this.cl[0], this.args[0]);
          } else if (jmfSecurity.getName().startsWith("internet")) {
            PolicyEngine.checkPermission(PermissionID.THREAD);
            PolicyEngine.assertPermission(PermissionID.THREAD);
          } 
        } catch (Throwable e) {
          securityPrivelege = false;
        } 
      } 
      if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
        try {
          Constructor cons = CreateTimedThreadAction.cons;
          this.stopTimeThread = (StopTimeThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { StopTimeThread.class, BasicController.class, this, new Long(timeToStop) }) });
          this.stopTimeThread.start();
        } catch (Exception e) {}
      } else {
        (this.stopTimeThread = new StopTimeThread(this, timeToStop)).start();
      } 
      return false;
    } 
    return true;
  }
  
  public void stop() {
    if (this.state == 600 || this.state == 400) {
      stopControllerOnly();
      doStop();
    } 
  }
  
  protected void stopControllerOnly() {
    if (this.state == 600 || this.state == 400) {
      this.clock.stop();
      this.state = 500;
      setTargetState(500);
      if (this.stopTimeThread != null && this.stopTimeThread.isAlive() && Thread.currentThread() != this.stopTimeThread)
        this.stopTimeThread.abort(); 
      if (this.startThread != null && this.startThread.isAlive())
        this.startThread.abort(); 
    } 
  }
  
  protected void stopAtTime() {
    stop();
    setStopTime(Clock.RESET);
    sendEvent((ControllerEvent)new StopAtTimeEvent(this, 600, 500, getTargetState(), getMediaTime()));
  }
  
  static String StopTimeError = "Cannot set stop time on an unrealized controller.";
  
  public void setStopTime(Time t) {
    if (this.state < 300)
      throwError((Error)new NotRealizedError(StopTimeError)); 
    Time oldStopTime = getStopTime();
    this.clock.setStopTime(t);
    boolean stopTimeHasPassed = false;
    if (this.state == 600) {
      long timeToStop;
      if ((timeToStop = checkStopTime()) < 0L || (this.stopThreadEnabled && activateStopThread(timeToStop)))
        stopTimeHasPassed = true; 
    } 
    if (oldStopTime.getNanoseconds() != t.getNanoseconds())
      sendEvent((ControllerEvent)new StopTimeChangeEvent(this, t)); 
    if (stopTimeHasPassed)
      stopAtTime(); 
  }
  
  public Time getStopTime() {
    return this.clock.getStopTime();
  }
  
  static String MediaTimeError = "Cannot set media time on a unrealized controller";
  
  public void setMediaTime(Time when) {
    if (this.state < 300)
      throwError((Error)new NotRealizedError(MediaTimeError)); 
    this.clock.setMediaTime(when);
    doSetMediaTime(when);
    sendEvent((ControllerEvent)new MediaTimeSetEvent(this, when));
  }
  
  protected void doSetMediaTime(Time when) {}
  
  public Time getMediaTime() {
    return this.clock.getMediaTime();
  }
  
  public long getMediaNanoseconds() {
    return this.clock.getMediaNanoseconds();
  }
  
  public Time getSyncTime() {
    return new Time(0L);
  }
  
  static String GetTimeBaseError = "Cannot get Time Base from an unrealized controller";
  
  public TimeBase getTimeBase() {
    if (this.state < 300)
      throwError((Error)new NotRealizedError(GetTimeBaseError)); 
    return this.clock.getTimeBase();
  }
  
  public Time mapToTimeBase(Time t) throws ClockStoppedException {
    return this.clock.mapToTimeBase(t);
  }
  
  static String SetRateError = "Cannot set rate on an unrealized controller.";
  
  public float setRate(float factor) {
    if (this.state < 300)
      throwError((Error)new NotRealizedError(SetRateError)); 
    float oldRate = getRate();
    float rateSet = doSetRate(factor);
    float newRate = this.clock.setRate(rateSet);
    if (newRate != oldRate)
      sendEvent((ControllerEvent)new RateChangeEvent(this, newRate)); 
    return newRate;
  }
  
  protected float doSetRate(float factor) {
    return factor;
  }
  
  public float getRate() {
    return this.clock.getRate();
  }
  
  public final int getState() {
    return this.state;
  }
  
  protected final void setTargetState(int state) {
    this.targetState = state;
  }
  
  public final int getTargetState() {
    return this.targetState;
  }
  
  static String LatencyError = "Cannot get start latency from an unrealized controller";
  
  public Time getStartLatency() {
    if (this.state < 300)
      throwError((Error)new NotRealizedError(LatencyError)); 
    return Controller.LATENCY_UNKNOWN;
  }
  
  public Time getDuration() {
    return Duration.DURATION_UNKNOWN;
  }
  
  protected void setMediaLength(long t) {
    if (this.clock instanceof BasicClock)
      ((BasicClock)this.clock).setMediaLength(t); 
  }
  
  public synchronized void configure() {
    if (getTargetState() < 180)
      setTargetState(180); 
    switch (this.state) {
      case 180:
      case 200:
      case 300:
      case 400:
      case 500:
      case 600:
        sendEvent((ControllerEvent)new ConfigureCompleteEvent(this, this.state, this.state, getTargetState()));
        break;
      case 100:
        this.state = 140;
        sendEvent((ControllerEvent)new TransitionEvent(this, 100, 140, getTargetState()));
        if (jmfSecurity != null) {
          String permission = null;
          try {
            if (jmfSecurity.getName().startsWith("jmf-security")) {
              permission = "thread";
              jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
              this.m[0].invoke(this.cl[0], this.args[0]);
              permission = "thread group";
              jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
              this.m[0].invoke(this.cl[0], this.args[0]);
            } else if (jmfSecurity.getName().startsWith("internet")) {
              PolicyEngine.checkPermission(PermissionID.THREAD);
              PolicyEngine.assertPermission(PermissionID.THREAD);
            } 
          } catch (Throwable e) {
            securityPrivelege = false;
          } 
        } 
        if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
          try {
            Constructor cons = CreateWorkThreadAction.cons;
            this.configureThread = (ConfigureWorkThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { ConfigureWorkThread.class, BasicController.class, this }) });
            this.configureThread.setName(this.configureThread.getName() + "[ " + this + " ]" + " ( configureThread)");
            this.configureThread.start();
          } catch (Exception e) {}
          break;
        } 
        this.configureThread = new ConfigureWorkThread(this);
        this.configureThread.setName(this.configureThread.getName() + "[ " + this + " ]" + " ( configureThread)");
        this.configureThread.start();
        break;
    } 
  }
  
  protected synchronized void completeConfigure() {
    this.state = 180;
    sendEvent((ControllerEvent)new ConfigureCompleteEvent(this, 140, 180, getTargetState()));
    if (getTargetState() >= 300)
      realize(); 
  }
  
  protected void doFailedConfigure() {
    this.state = 100;
    setTargetState(100);
    String msg = "Failed to configure";
    if (this.processError != null)
      msg = msg + ": " + this.processError; 
    sendEvent((ControllerEvent)new ResourceUnavailableEvent(this, msg));
    this.processError = null;
  }
  
  public final synchronized void realize() {
    int oldState;
    if (getTargetState() < 300)
      setTargetState(300); 
    switch (this.state) {
      case 300:
      case 400:
      case 500:
      case 600:
        sendEvent((ControllerEvent)new RealizeCompleteEvent(this, this.state, this.state, getTargetState()));
        break;
      case 100:
        if (isConfigurable()) {
          configure();
          break;
        } 
      case 180:
        oldState = this.state;
        this.state = 200;
        sendEvent((ControllerEvent)new TransitionEvent(this, oldState, 200, getTargetState()));
        if (jmfSecurity != null) {
          String permission = null;
          try {
            if (jmfSecurity.getName().startsWith("jmf-security")) {
              permission = "thread";
              jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
              this.m[0].invoke(this.cl[0], this.args[0]);
              permission = "thread group";
              jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
              this.m[0].invoke(this.cl[0], this.args[0]);
            } else if (jmfSecurity.getName().startsWith("internet")) {
              PolicyEngine.checkPermission(PermissionID.THREAD);
              PolicyEngine.assertPermission(PermissionID.THREAD);
            } 
          } catch (Throwable e) {
            securityPrivelege = false;
          } 
        } 
        if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
          try {
            Constructor cons = CreateWorkThreadAction.cons;
            this.realizeThread = (RealizeWorkThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { RealizeWorkThread.class, BasicController.class, this }) });
            this.realizeThread.setName(this.realizeThread.getName() + "[ " + this + " ]" + " ( realizeThread)");
            this.realizeThread.start();
          } catch (Exception e) {}
          break;
        } 
        this.realizeThread = new RealizeWorkThread(this);
        this.realizeThread.setName(this.realizeThread.getName() + "[ " + this + " ]" + " ( realizeThread)");
        this.realizeThread.start();
        break;
    } 
  }
  
  protected synchronized void completeRealize() {
    this.state = 300;
    sendEvent((ControllerEvent)new RealizeCompleteEvent(this, 200, 300, getTargetState()));
    if (getTargetState() >= 500)
      prefetch(); 
  }
  
  protected void doFailedRealize() {
    this.state = 100;
    setTargetState(100);
    String msg = "Failed to realize";
    if (this.processError != null)
      msg = msg + ": " + this.processError; 
    sendEvent((ControllerEvent)new ResourceUnavailableEvent(this, msg));
    this.processError = null;
  }
  
  public final void prefetch() {
    if (getTargetState() <= 300)
      setTargetState(500); 
    switch (this.state) {
      case 500:
      case 600:
        sendEvent((ControllerEvent)new PrefetchCompleteEvent(this, this.state, this.state, getTargetState()));
        break;
      case 100:
      case 180:
        realize();
        break;
      case 300:
        this.state = 400;
        sendEvent((ControllerEvent)new TransitionEvent(this, 300, 400, getTargetState()));
        if (jmfSecurity != null) {
          String permission = null;
          try {
            if (jmfSecurity.getName().startsWith("jmf-security")) {
              permission = "thread";
              jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
              this.m[0].invoke(this.cl[0], this.args[0]);
              permission = "thread group";
              jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
              this.m[0].invoke(this.cl[0], this.args[0]);
            } else if (jmfSecurity.getName().startsWith("internet")) {
              PolicyEngine.checkPermission(PermissionID.THREAD);
              PolicyEngine.assertPermission(PermissionID.THREAD);
            } 
          } catch (Throwable e) {
            securityPrivelege = false;
          } 
        } 
        if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
          try {
            Constructor cons = CreateWorkThreadAction.cons;
            this.prefetchThread = (PrefetchWorkThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { PrefetchWorkThread.class, BasicController.class, this }) });
            this.prefetchThread.setName(this.prefetchThread.getName() + "[ " + this + " ]" + " ( prefetchThread)");
            this.prefetchThread.start();
          } catch (Exception e) {}
          break;
        } 
        this.prefetchThread = new PrefetchWorkThread(this);
        this.prefetchThread.setName(this.prefetchThread.getName() + " ( prefetchThread)");
        this.prefetchThread.start();
        break;
    } 
  }
  
  protected void completePrefetch() {
    this.clock.stop();
    this.state = 500;
    sendEvent((ControllerEvent)new PrefetchCompleteEvent(this, 400, 500, getTargetState()));
  }
  
  protected void doFailedPrefetch() {
    this.state = 300;
    setTargetState(300);
    String msg = "Failed to prefetch";
    if (this.processError != null)
      msg = msg + ": " + this.processError; 
    sendEvent((ControllerEvent)new ResourceUnavailableEvent(this, msg));
    this.processError = null;
  }
  
  static String DeallocateError = "deallocate cannot be used on a started controller.";
  
  public final void deallocate() {
    int previousState = getState();
    if (this.state == 600)
      throwError((Error)new ClockStartedError(DeallocateError)); 
    switch (this.state) {
      case 140:
      case 200:
        interrupt();
        this.state = 100;
        break;
      case 400:
        interrupt();
        this.state = 300;
        break;
      case 500:
        abortPrefetch();
        this.state = 300;
        resetInterrupt();
        break;
    } 
    setTargetState(this.state);
    doDeallocate();
    synchronized (this.interruptSync) {
      while (isInterrupted()) {
        try {
          this.interruptSync.wait();
        } catch (InterruptedException e) {}
      } 
    } 
    sendEvent((ControllerEvent)new DeallocateEvent(this, previousState, this.state, this.state, getMediaTime()));
  }
  
  protected void doDeallocate() {}
  
  public final void addControllerListener(ControllerListener listener) {
    if (this.listenerList == null)
      this.listenerList = new Vector(); 
    synchronized (this.listenerList) {
      if (!this.listenerList.contains(listener))
        this.listenerList.addElement(listener); 
    } 
  }
  
  public final void removeControllerListener(ControllerListener listener) {
    if (this.listenerList == null)
      return; 
    synchronized (this.listenerList) {
      if (this.listenerList != null)
        this.listenerList.removeElement(listener); 
    } 
  }
  
  protected final void sendEvent(ControllerEvent evt) {
    if (this.sendEvtQueue != null)
      this.sendEvtQueue.postEvent(evt); 
  }
  
  protected final void dispatchEvent(ControllerEvent evt) {
    if (this.listenerList == null)
      return; 
    synchronized (this.listenerList) {
      Enumeration list = this.listenerList.elements();
      while (list.hasMoreElements()) {
        ControllerListener listener = list.nextElement();
        listener.controllerUpdate(evt);
      } 
    } 
  }
  
  protected void throwError(Error e) {
    Log.dumpStack(e);
    throw e;
  }
  
  protected abstract boolean isConfigurable();
  
  protected abstract boolean doRealize();
  
  protected abstract void abortRealize();
  
  protected abstract boolean doPrefetch();
  
  protected abstract void abortPrefetch();
  
  protected abstract void doStart();
}
