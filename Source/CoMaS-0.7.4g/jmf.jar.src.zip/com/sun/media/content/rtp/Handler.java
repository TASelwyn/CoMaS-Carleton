/*     */ package com.sun.media.content.rtp;
/*     */ 
/*     */ import com.sun.media.BasicController;
/*     */ import com.sun.media.BasicPlayer;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.protocol.BufferListener;
/*     */ import com.sun.media.protocol.rtp.DataSource;
/*     */ import com.sun.media.rtp.RTPMediaLocator;
/*     */ import com.sun.media.rtp.RTPSessionMgr;
/*     */ import java.awt.Component;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetAddress;
/*     */ import java.util.Vector;
/*     */ import javax.media.CachingControl;
/*     */ import javax.media.ClockStartedError;
/*     */ import javax.media.Control;
/*     */ import javax.media.Controller;
/*     */ import javax.media.ControllerEvent;
/*     */ import javax.media.ControllerListener;
/*     */ import javax.media.Format;
/*     */ import javax.media.IncompatibleSourceException;
/*     */ import javax.media.IncompatibleTimeBaseException;
/*     */ import javax.media.Manager;
/*     */ import javax.media.MediaLocator;
/*     */ import javax.media.NotRealizedError;
/*     */ import javax.media.Owned;
/*     */ import javax.media.Player;
/*     */ import javax.media.SystemTimeBase;
/*     */ import javax.media.Time;
/*     */ import javax.media.TimeBase;
/*     */ import javax.media.control.BufferControl;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.format.FormatChangeEvent;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.rtp.RTPControl;
/*     */ import javax.media.rtp.RTPManager;
/*     */ import javax.media.rtp.RTPPushDataSource;
/*     */ import javax.media.rtp.RTPSocket;
/*     */ import javax.media.rtp.ReceiveStream;
/*     */ import javax.media.rtp.ReceiveStreamListener;
/*     */ import javax.media.rtp.SessionAddress;
/*     */ import javax.media.rtp.event.NewReceiveStreamEvent;
/*     */ import javax.media.rtp.event.ReceiveStreamEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Handler
/*     */   extends BasicPlayer
/*     */   implements ReceiveStreamListener, BufferListener
/*     */ {
/*  54 */   RTPSessionMgr[] mgrs = null;
/*  55 */   DataSource[] sources = null;
/*  56 */   Player[] players = null;
/*  57 */   Format[] formats = null;
/*  58 */   Format[] formatChanged = null;
/*  59 */   boolean[] realized = null;
/*  60 */   boolean[] dataReady = null;
/*  61 */   Vector locators = null;
/*  62 */   ControllerListener listener = new PlayerListener(this, this);
/*     */   
/*     */   boolean playersRealized = false;
/*  65 */   Object realizedSync = new Object();
/*  66 */   Object closeSync = new Object();
/*  67 */   Object dataSync = new Object();
/*  68 */   Object stateLock = new Object();
/*     */   
/*     */   private boolean closed = false;
/*     */   private boolean audioEnabled = false;
/*     */   private boolean videoEnabled = false;
/*     */   private boolean prebuffer = false;
/*     */   private boolean dataAllReady = false;
/*  75 */   private static JMFSecurity jmfSecurity = null;
/*     */   private static boolean securityPrivelege = false;
/*  77 */   private Method[] m = new Method[1];
/*  78 */   private Class[] cl = new Class[1];
/*  79 */   private Object[][] args = new Object[1][0];
/*     */ 
/*     */   
/*     */   String sessionError;
/*     */ 
/*     */   
/*     */   public Handler()
/*     */   {
/*  87 */     this.sessionError = "cannot create and initialize the RTP session.";
/*     */     this.framePositioning = false;
/*     */     this.bufferControl = new BC(this);
/*     */     ((BasicController)this).stopThreadEnabled = true; } protected boolean doRealize() {
/*  91 */     super.doRealize();
/*     */ 
/*     */     
/*     */     try {
/*  95 */       if (this.source instanceof RTPSocket) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 100 */         this.mgrs = new RTPSessionMgr[1];
/*     */         
/* 102 */         this.mgrs[1] = new RTPSessionMgr((RTPPushDataSource)this.source);
/* 103 */         this.mgrs[1].addReceiveStreamListener(this);
/*     */         
/* 105 */         this.sources = new DataSource[1];
/* 106 */         this.players = new Player[1];
/* 107 */         this.formats = new Format[1];
/* 108 */         this.realized = new boolean[1];
/* 109 */         this.dataReady = new boolean[1];
/* 110 */         this.formatChanged = new Format[1];
/*     */         
/* 112 */         this.sources[0] = this.source;
/* 113 */         this.dataReady[0] = false;
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 118 */         SessionAddress localAddr = new SessionAddress();
/*     */ 
/*     */         
/* 121 */         this.mgrs = new RTPSessionMgr[this.locators.size()];
/* 122 */         this.sources = new DataSource[this.locators.size()];
/* 123 */         this.players = new Player[this.locators.size()];
/* 124 */         this.formats = new Format[this.locators.size()];
/* 125 */         this.realized = new boolean[this.locators.size()];
/* 126 */         this.dataReady = new boolean[this.locators.size()];
/* 127 */         this.formatChanged = new Format[this.locators.size()];
/*     */         
/* 129 */         for (int i = 0; i < this.locators.size(); i++) {
/* 130 */           SessionAddress sessionAddress; RTPMediaLocator rml = this.locators.elementAt(i);
/* 131 */           this.realized[i] = false;
/*     */           
/* 133 */           this.mgrs[i] = (RTPSessionMgr)RTPManager.newInstance();
/* 134 */           this.mgrs[i].addReceiveStreamListener(this);
/*     */           
/* 136 */           InetAddress ipAddr = InetAddress.getByName(rml.getSessionAddress());
/*     */           
/* 138 */           if (ipAddr.isMulticastAddress()) {
/*     */             
/* 140 */             localAddr = new SessionAddress(ipAddr, rml.getSessionPort(), rml.getTTL());
/*     */ 
/*     */ 
/*     */             
/* 144 */             sessionAddress = new SessionAddress(ipAddr, rml.getSessionPort(), rml.getTTL());
/*     */           
/*     */           }
/*     */           else {
/*     */             
/* 149 */             localAddr = new SessionAddress(InetAddress.getLocalHost(), rml.getSessionPort());
/*     */ 
/*     */             
/* 152 */             sessionAddress = new SessionAddress(ipAddr, rml.getSessionPort());
/*     */           } 
/*     */ 
/*     */           
/* 156 */           this.mgrs[i].initialize(localAddr);
/*     */           
/* 158 */           if (this.prebuffer) {
/* 159 */             BufferControl bc = (BufferControl)this.mgrs[i].getControl("javax.media.control.BufferControl");
/* 160 */             bc.setBufferLength(this.bufferControl.getBufferLength());
/* 161 */             bc.setMinimumThreshold(this.bufferControl.getMinimumThreshold());
/*     */           } 
/*     */           
/* 164 */           this.mgrs[i].addTarget(sessionAddress);
/*     */         } 
/*     */       } 
/*     */     } catch (Exception e) {
/*     */       
/* 169 */       Log.error("Cannot create the RTP Session: " + e.getMessage());
/* 170 */       ((BasicController)this).processError = this.sessionError;
/* 171 */       return false;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 176 */       synchronized (this.realizedSync) {
/* 177 */         while (!this.playersRealized && !isInterrupted() && !this.closed)
/* 178 */           this.realizedSync.wait(); 
/*     */       } 
/* 180 */     } catch (Exception e) {}
/*     */ 
/*     */     
/* 183 */     if (this.closed || isInterrupted()) {
/* 184 */       resetInterrupt();
/* 185 */       ((BasicController)this).processError = "no RTP data was received.";
/* 186 */       return false;
/*     */     } 
/*     */     
/* 189 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void completeRealize() {
/* 194 */     ((BasicController)this).state = 300;
/* 195 */     super.completeRealize();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doStart() {
/* 200 */     super.doStart();
/*     */     
/* 202 */     synchronized (this.dataSync) {
/* 203 */       if (this.prebuffer) {
/* 204 */         this.dataAllReady = false;
/* 205 */         for (int j = 0; j < this.dataReady.length; j++) {
/* 206 */           this.dataReady[j] = false;
/* 207 */           ((DataSource)this.sources[j]).flush();
/* 208 */           ((DataSource)this.sources[j]).prebuffer();
/*     */         } 
/*     */         
/* 211 */         if (!this.dataAllReady && !this.closed) {
/*     */           try {
/* 213 */             this.dataSync.wait(3000L);
/* 214 */           } catch (Exception e) {}
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 221 */     for (int i = 0; i < this.players.length; i++) {
/*     */       try {
/* 223 */         if (this.players[i] != null) {
/* 224 */           waitForStart(this.players[i]);
/*     */         }
/* 226 */       } catch (Exception e) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doStop() {
/* 232 */     super.doStop();
/*     */     
/* 234 */     synchronized (this.dataSync) {
/* 235 */       if (this.prebuffer) {
/* 236 */         this.dataSync.notify();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 241 */     for (int i = 0; i < this.players.length; i++) {
/*     */       try {
/* 243 */         if (this.players[i] != null) {
/* 244 */           waitForStop(this.players[i]);
/*     */         }
/* 246 */       } catch (Exception e) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doDeallocate() {
/* 252 */     for (int i = 0; i < this.players.length; i++) {
/*     */       try {
/* 254 */         if (this.players[i] != null)
/* 255 */           this.players[i].deallocate(); 
/* 256 */       } catch (Exception e) {}
/*     */     } 
/* 258 */     synchronized (this.realizedSync) {
/* 259 */       this.realizedSync.notify();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doFailedRealize() {
/* 266 */     synchronized (this.closeSync) {
/*     */       
/* 268 */       for (int i = 0; i < this.mgrs.length; i++) {
/* 269 */         if (this.mgrs[i] != null) {
/* 270 */           this.mgrs[i].removeTargets("Closing session from the RTP Handler");
/* 271 */           this.mgrs[i].dispose();
/* 272 */           this.mgrs[i] = null;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 277 */     super.doFailedRealize();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doClose() {
/* 283 */     this.closed = true;
/*     */     
/* 285 */     synchronized (this.realizedSync) {
/* 286 */       this.realizedSync.notify();
/*     */     } 
/*     */     
/* 289 */     synchronized (this.dataSync) {
/* 290 */       this.dataSync.notifyAll();
/*     */     } 
/*     */     
/* 293 */     stop();
/* 294 */     for (int i = 0; i < this.players.length; i++) {
/*     */       try {
/* 296 */         if (this.players[i] != null)
/* 297 */           this.players[i].close(); 
/* 298 */       } catch (Exception e) {}
/*     */     } 
/*     */ 
/*     */     
/* 302 */     synchronized (this.closeSync) {
/* 303 */       for (int j = 0; j < this.mgrs.length; j++) {
/* 304 */         if (this.mgrs[j] != null) {
/* 305 */           this.mgrs[j].removeTargets("Closing session from the RTP Handler");
/* 306 */           this.mgrs[j].dispose();
/* 307 */           this.mgrs[j] = null;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 312 */     super.doClose();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTimeBase(TimeBase tb) throws IncompatibleTimeBaseException {}
/*     */   
/*     */   protected TimeBase getMasterTimeBase() {
/* 319 */     return (TimeBase)new SystemTimeBase();
/*     */   }
/*     */   
/*     */   public float setRate(float rate) {
/* 323 */     if (getState() < 300) {
/* 324 */       throwError((Error)new NotRealizedError("Cannot set rate on an unrealized Player."));
/*     */     }
/*     */ 
/*     */     
/* 328 */     return 1.0F;
/*     */   }
/*     */   
/*     */   public void setStopTime(Time t) {
/* 332 */     controllerSetStopTime(t);
/*     */   }
/*     */   
/*     */   protected void stopAtTime() {
/* 336 */     controllerStopAtTime();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void addController(Controller newController) throws IncompatibleTimeBaseException {
/* 341 */     int playerState = getState();
/*     */     
/* 343 */     if (playerState == 600) {
/* 344 */       throwError((Error)new ClockStartedError("Cannot add controller to a started player"));
/*     */     }
/*     */     
/* 347 */     if (playerState == 100 || playerState == 200) {
/* 348 */       throwError((Error)new NotRealizedError("A Controller cannot be added to an Unrealized Player"));
/*     */     }
/*     */     
/* 351 */     throw new IncompatibleTimeBaseException();
/*     */   }
/*     */   
/*     */   protected boolean audioEnabled() {
/* 355 */     return this.audioEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean videoEnabled() {
/* 360 */     return this.videoEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   private void sendMyEvent(ControllerEvent e) {
/* 365 */     sendEvent(e);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void update(ReceiveStreamEvent event) {
/* 371 */     RTPSessionMgr mgr = (RTPSessionMgr)event.getSource();
/*     */     
/*     */     int idx;
/* 374 */     for (idx = 0; idx < this.mgrs.length && 
/* 375 */       this.mgrs[idx] != mgr; idx++);
/*     */ 
/*     */ 
/*     */     
/* 379 */     if (idx >= this.mgrs.length) {
/*     */       
/* 381 */       System.err.println("Unknown manager: " + mgr);
/*     */       
/*     */       return;
/*     */     } 
/* 385 */     if (event instanceof javax.media.rtp.event.RemotePayloadChangeEvent) {
/*     */       
/* 387 */       Log.comment("Received an RTP PayloadChangeEvent");
/* 388 */       RTPControl ctl = (RTPControl)this.sources[idx].getControl("javax.media.rtp.RTPControl");
/*     */       
/* 390 */       if (ctl != null) {
/* 391 */         this.formatChanged[idx] = ctl.getFormat();
/*     */       }
/*     */ 
/*     */       
/* 395 */       if (this.players[idx] != null) {
/*     */ 
/*     */         
/* 398 */         stop();
/*     */ 
/*     */ 
/*     */         
/* 402 */         waitForClose(this.players[idx]);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 409 */         this.sources[idx].connect();
/* 410 */         this.players[idx] = Manager.createPlayer(this.sources[idx]);
/*     */         
/* 412 */         if (this.players[idx] == null) {
/* 413 */           Log.error("Could not create player for the new RTP payload.");
/*     */           return;
/*     */         } 
/* 416 */         this.players[idx].addControllerListener(this.listener);
/* 417 */         this.players[idx].realize();
/*     */       } catch (Exception e) {
/*     */         
/* 420 */         Log.error("Could not create player for the new payload.");
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 425 */     if (event instanceof NewReceiveStreamEvent) {
/*     */       
/* 427 */       if (this.players[idx] != null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 434 */       ReceiveStream stream = null;
/*     */       try {
/* 436 */         stream = ((NewReceiveStreamEvent)event).getReceiveStream();
/* 437 */         this.sources[idx] = stream.getDataSource();
/*     */         
/* 439 */         RTPControl ctl = (RTPControl)this.sources[idx].getControl("javax.media.rtp.RTPControl");
/* 440 */         if (ctl != null) {
/* 441 */           this.formats[idx] = ctl.getFormat();
/* 442 */           if (this.formats[idx] instanceof AudioFormat) {
/* 443 */             this.audioEnabled = true;
/* 444 */           } else if (this.formats[idx] instanceof javax.media.format.VideoFormat) {
/* 445 */             this.videoEnabled = true;
/*     */           } 
/*     */         } 
/* 448 */         if (this.source instanceof RTPSocket) {
/* 449 */           ((RTPSocket)this.source).setChild(this.sources[idx]);
/*     */         } else {
/* 451 */           ((DataSource)this.source).setChild((DataSource)this.sources[idx]);
/*     */         } 
/*     */         
/* 454 */         this.players[idx] = Manager.createPlayer(this.sources[idx]);
/* 455 */         if (this.players[idx] == null) {
/*     */           return;
/*     */         }
/* 458 */         this.players[idx].addControllerListener(this.listener);
/* 459 */         this.players[idx].realize();
/*     */         
/* 461 */         if (this.prebuffer) {
/* 462 */           ((DataSource)this.sources[idx]).setBufferListener(this);
/*     */         }
/*     */       } catch (Exception e) {
/* 465 */         Log.error("NewReceiveStreamEvent exception " + e.getMessage());
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void waitForStart(Player p) {
/* 474 */     (new StateWaiter(this)).waitForStart(p, true);
/*     */   }
/*     */ 
/*     */   
/*     */   private void waitForStop(Player p) {
/* 479 */     (new StateWaiter(this)).waitForStart(p, false);
/*     */   }
/*     */ 
/*     */   
/*     */   private void waitForClose(Player p) {
/* 484 */     (new StateWaiter(this)).waitForClose(p);
/*     */   }
/*     */   class StateWaiter implements ControllerListener { boolean closeDown;
/*     */     StateWaiter(Handler this$0) {
/* 488 */       this.this$0 = this$0;
/*     */       
/* 490 */       this.closeDown = false;
/* 491 */       this.stateLock = new Object();
/*     */     } Object stateLock; private final Handler this$0;
/*     */     public void waitForStart(Player p, boolean startOn) {
/* 494 */       p.addControllerListener(this);
/* 495 */       if (startOn) {
/* 496 */         p.start();
/*     */       } else {
/* 498 */         p.stop();
/* 499 */       }  synchronized (this.stateLock) {
/*     */         
/* 501 */         while (((startOn && p.getState() != 600) || (!startOn && p.getState() == 600)) && !this.closeDown) {
/*     */           
/*     */           try {
/* 504 */             this.stateLock.wait(1000L);
/*     */           }
/* 506 */           catch (InterruptedException ie) {
/*     */             break;
/*     */           } 
/*     */         } 
/* 510 */       }  p.removeControllerListener(this);
/*     */     }
/*     */     
/*     */     public void waitForClose(Player p) {
/* 514 */       p.addControllerListener(this);
/* 515 */       p.close();
/* 516 */       synchronized (this.stateLock) {
/* 517 */         while (!this.closeDown) {
/*     */           try {
/* 519 */             this.stateLock.wait(1000L);
/*     */           }
/* 521 */           catch (InterruptedException ie) {
/*     */             break;
/*     */           } 
/*     */         } 
/* 525 */       }  p.removeControllerListener(this);
/*     */     }
/*     */     
/*     */     public void controllerUpdate(ControllerEvent ce) {
/* 529 */       if (ce instanceof javax.media.ControllerClosedEvent || ce instanceof javax.media.ControllerErrorEvent)
/*     */       {
/* 531 */         this.closeDown = true;
/*     */       }
/* 533 */       synchronized (this.stateLock) {
/* 534 */         this.stateLock.notify();
/*     */       } 
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
/* 543 */     super.setSource(source);
/* 544 */     if (source instanceof DataSource) {
/* 545 */       MediaLocator ml = source.getLocator();
/* 546 */       String mlStr = ml.getRemainder();
/*     */ 
/*     */ 
/*     */       
/* 550 */       int start = 0;
/* 551 */       while (mlStr.charAt(start) == '/')
/* 552 */         start++; 
/* 553 */       this.locators = new Vector();
/*     */       try {
/*     */         String str;
/*     */         int idx;
/* 557 */         while (start < mlStr.length() && (idx = mlStr.indexOf("&", start)) != -1) {
/* 558 */           str = mlStr.substring(start, idx);
/* 559 */           RTPMediaLocator rml = new RTPMediaLocator("rtp://" + str);
/* 560 */           this.locators.addElement(rml);
/* 561 */           start = idx + 1;
/*     */         } 
/* 563 */         if (start != 0) {
/* 564 */           str = mlStr.substring(start);
/*     */         } else {
/* 566 */           str = mlStr;
/* 567 */         }  RTPMediaLocator rTPMediaLocator = new RTPMediaLocator("rtp://" + str);
/* 568 */         this.locators.addElement(rTPMediaLocator);
/*     */       } catch (Exception e) {
/*     */         
/* 571 */         throw new IncompatibleSourceException();
/*     */       } 
/*     */       
/* 574 */       if (this.locators.size() > 1) {
/* 575 */         this.prebuffer = true;
/*     */       }
/* 577 */     } else if (!(source instanceof RTPSocket)) {
/* 578 */       throw new IncompatibleSourceException();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 583 */     RTPControl ctl = (RTPControl)source.getControl("javax.media.rtp.RTPControl");
/*     */     
/* 585 */     if (ctl != null) {
/* 586 */       ctl.addFormat((Format)new AudioFormat("dvi/rtp", 44100.0D, 4, 1), 18);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void invalidateComp() {
/* 595 */     this.controlComp = null;
/* 596 */     this.controls = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getVisualComponent() {
/* 608 */     super.getVisualComponent();
/* 609 */     for (int i = 0; i < this.players.length; i++) {
/* 610 */       if (this.players[i] != null && this.players[i].getVisualComponent() != null)
/* 611 */         return this.players[i].getVisualComponent(); 
/*     */     } 
/* 613 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Control[] getControls() {
/* 623 */     if (this.controls != null) {
/* 624 */       return this.controls;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 630 */     Vector cv = new Vector();
/*     */     
/* 632 */     if (this.cachingControl != null) {
/* 633 */       cv.addElement(this.cachingControl);
/*     */     }
/* 635 */     if (this.bufferControl != null) {
/* 636 */       cv.addElement(this.bufferControl);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 641 */     int size = this.players.length; int i;
/* 642 */     for (i = 0; i < size; i++) {
/* 643 */       Player player = this.players[i];
/* 644 */       Control[] arrayOfControl = player.getControls();
/* 645 */       if (arrayOfControl != null) {
/* 646 */         for (int j = 0; j < arrayOfControl.length; j++) {
/* 647 */           cv.addElement(arrayOfControl[j]);
/*     */         }
/*     */       }
/*     */     } 
/*     */     
/* 652 */     size = cv.size();
/* 653 */     Control[] ctrls = new Control[size];
/*     */     
/* 655 */     for (i = 0; i < size; i++) {
/* 656 */       ctrls[i] = (Control)cv.elementAt(i);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 662 */     if (getState() >= 300) {
/* 663 */       this.controls = ctrls;
/*     */     }
/* 665 */     return ctrls;
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateStats() {
/* 670 */     for (int i = 0; i < this.players.length; i++) {
/* 671 */       if (this.players[i] != null) {
/* 672 */         ((BasicPlayer)this.players[i]).updateStats();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void minThresholdReached(DataSource ds) {
/* 678 */     boolean ready = true;
/* 679 */     synchronized (this.dataSync) {
/* 680 */       for (int i = 0; i < this.sources.length; i++) {
/* 681 */         if (this.sources[i] == ds) {
/* 682 */           this.dataReady[i] = true;
/* 683 */         } else if (!this.dataReady[i]) {
/* 684 */           ready = false;
/*     */         } 
/* 686 */       }  if (!ready) {
/*     */         return;
/*     */       }
/* 689 */       this.dataAllReady = true;
/* 690 */       this.dataSync.notify();
/*     */     } 
/*     */   }
/*     */   
/*     */   class PlayerListener implements ControllerListener {
/*     */     Handler handler;
/*     */     private final Handler this$0;
/*     */     
/*     */     public PlayerListener(Handler this$0, Handler handler) {
/* 699 */       this.this$0 = this$0;
/* 700 */       this.handler = handler;
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void controllerUpdate(ControllerEvent ce) {
/* 705 */       Player p = (Player)ce.getSourceController();
/*     */ 
/*     */       
/* 708 */       if (p == null)
/*     */         return; 
/*     */       int idx;
/* 711 */       for (idx = 0; idx < this.this$0.players.length && 
/* 712 */         this.this$0.players[idx] != p; idx++);
/*     */ 
/*     */ 
/*     */       
/* 716 */       if (idx >= this.this$0.players.length) {
/*     */         
/* 718 */         System.err.println("Unknown player: " + p);
/*     */         
/*     */         return;
/*     */       } 
/* 722 */       if (ce instanceof javax.media.RealizeCompleteEvent) {
/*     */ 
/*     */ 
/*     */         
/* 726 */         if (this.this$0.formatChanged[idx] != null) {
/*     */           
/*     */           try {
/*     */ 
/*     */             
/* 731 */             this.this$0.invalidateComp();
/*     */             
/* 733 */             FormatChangeEvent f = new FormatChangeEvent((Controller)this.handler, this.this$0.formats[idx], this.this$0.formatChanged[idx]);
/*     */ 
/*     */ 
/*     */             
/* 737 */             this.handler.sendMyEvent((ControllerEvent)f);
/* 738 */             this.this$0.formats[idx] = this.this$0.formatChanged[idx];
/* 739 */             this.this$0.formatChanged[idx] = null;
/*     */           
/*     */           }
/*     */           catch (Exception e) {
/*     */ 
/*     */             
/* 745 */             e.getMessage();
/*     */           } 
/*     */         }
/*     */         
/* 749 */         this.this$0.realized[idx] = true;
/*     */ 
/*     */         
/* 752 */         for (int i = 0; i < this.this$0.realized.length; i++) {
/* 753 */           if (!this.this$0.realized[i]) {
/*     */             return;
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/* 759 */         synchronized (this.this$0.realizedSync) {
/* 760 */           this.this$0.playersRealized = true;
/* 761 */           this.this$0.realizedSync.notifyAll();
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 766 */       if (ce instanceof javax.media.ControllerErrorEvent) {
/* 767 */         this.this$0.players[idx].removeControllerListener(this);
/* 768 */         Log.error("RTP Handler internal error: " + ce);
/* 769 */         this.this$0.players[idx] = null;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   class BC implements BufferControl, Owned {
/*     */     long len;
/*     */     long min;
/*     */     private final Handler this$0;
/*     */     
/*     */     BC(Handler this$0) {
/* 780 */       this.this$0 = this$0;
/*     */       
/* 782 */       this.len = -1L;
/* 783 */       this.min = -1L;
/*     */     }
/*     */     public long getBufferLength() {
/* 786 */       if (this.len < 0L)
/* 787 */         return this.this$0.prebuffer ? 750L : 125L; 
/* 788 */       return this.len;
/*     */     }
/*     */     
/*     */     public long setBufferLength(long time) {
/* 792 */       this.len = time;
/* 793 */       Log.comment("RTP Handler buffer length set: " + this.len);
/* 794 */       return this.len;
/*     */     }
/*     */     
/*     */     public long getMinimumThreshold() {
/* 798 */       if (this.min < 0L)
/* 799 */         return this.this$0.prebuffer ? 125L : 0L; 
/* 800 */       return this.min;
/*     */     }
/*     */     
/*     */     public long setMinimumThreshold(long time) {
/* 804 */       this.min = time;
/* 805 */       Log.comment("RTP Handler buffer minimum threshold: " + this.min);
/* 806 */       return this.min;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setEnabledThreshold(boolean b) {}
/*     */     
/*     */     public boolean getEnabledThreshold() {
/* 813 */       return (getMinimumThreshold() > 0L);
/*     */     }
/*     */     
/*     */     public Component getControlComponent() {
/* 817 */       return null;
/*     */     }
/*     */     
/*     */     public Object getOwner() {
/* 821 */       return this.this$0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\content\rtp\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */