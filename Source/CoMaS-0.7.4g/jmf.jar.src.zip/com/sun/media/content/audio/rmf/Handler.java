package com.sun.media.content.audio.rmf;

import com.sun.media.content.audio.midi.Handler;

public class Handler extends Handler {}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\content\audio\rmf\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */