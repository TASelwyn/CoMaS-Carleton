package com.sun.media.content.rtsp;

import com.sun.media.BasicController;
import com.sun.media.BasicPlayer;
import com.sun.media.Log;
import com.sun.media.controls.RtspAdapter;
import com.sun.media.protocol.BufferListener;
import com.sun.media.protocol.rtp.DataSource;
import com.sun.media.rtsp.Timer;
import com.sun.media.rtsp.TimerListener;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Panel;
import java.io.IOException;
import java.net.InetAddress;
import java.util.Vector;
import javax.media.ClockStartedError;
import javax.media.Control;
import javax.media.Controller;
import javax.media.ControllerEvent;
import javax.media.ControllerListener;
import javax.media.Duration;
import javax.media.DurationUpdateEvent;
import javax.media.GainControl;
import javax.media.IncompatibleSourceException;
import javax.media.IncompatibleTimeBaseException;
import javax.media.Manager;
import javax.media.MediaLocator;
import javax.media.NotRealizedError;
import javax.media.Player;
import javax.media.SystemTimeBase;
import javax.media.Time;
import javax.media.TimeBase;
import javax.media.control.BufferControl;
import javax.media.protocol.DataSource;
import javax.media.renderer.VisualContainer;
import javax.media.rtp.Participant;
import javax.media.rtp.RTPManager;
import javax.media.rtp.ReceiveStream;
import javax.media.rtp.ReceiveStreamListener;
import javax.media.rtp.SessionAddress;
import javax.media.rtp.event.NewReceiveStreamEvent;
import javax.media.rtp.event.ReceiveStreamEvent;

public class Handler extends BasicPlayer implements ReceiveStreamListener, TimerListener, BufferListener {
  private final int INITIALIZED = 0;
  
  private final int REALIZED = 1;
  
  private final int PLAYING = 2;
  
  private final int PAUSING = 3;
  
  private RtspUtil rtspUtil;
  
  private Player[] players;
  
  private Vector playerList;
  
  private boolean dataReceived;
  
  private DataSource[] data_sources;
  
  private boolean[] track_ready;
  
  private String url;
  
  private Object readySync = new Object();
  
  private Object stateSync = new Object();
  
  private boolean waitFailed;
  
  private int state;
  
  private boolean first_pass = true;
  
  private Timer timer;
  
  private Container container;
  
  protected synchronized boolean doRealize() {
    boolean realized = super.doRealize();
    if (realized) {
      realized = initRtspSession();
      if (!realized) {
        ((BasicController)this).processError = this.rtspUtil.getProcessError();
      } else {
        long duration = this.rtspUtil.getDuration();
        if (duration > 0L)
          sendEvent((ControllerEvent)new DurationUpdateEvent((Controller)this, new Time(duration))); 
      } 
    } 
    return realized;
  }
  
  private boolean initRtspSession() {
    boolean realized = false;
    this.rtspUtil.setUrl(this.url);
    String ipAddress = this.rtspUtil.getServerIpAddress();
    if (ipAddress == null) {
      Log.error("Invalid server address");
      this.rtspUtil.setProcessError("Invalid server address");
      realized = false;
    } else {
      realized = this.rtspUtil.createConnection();
      if (realized) {
        realized = this.rtspUtil.rtspSetup();
        try {
          InetAddress destaddr = InetAddress.getByName(ipAddress);
          int numberOfTracks = this.rtspUtil.getNumberOfTracks();
          int[] server_ports = this.rtspUtil.getServerPorts();
          for (int i = 0; i < numberOfTracks; i++) {
            SessionAddress remoteAddress = new SessionAddress(destaddr, server_ports[i]);
            RTPManager mgr = this.rtspUtil.getRTPManager(i);
            mgr.addTarget(remoteAddress);
            BufferControl bc = (BufferControl)mgr.getControl("javax.media.control.BufferControl");
            String mediaType = this.rtspUtil.getMediaType(i);
            if (mediaType.equals("audio")) {
              bc.setBufferLength(250L);
              bc.setMinimumThreshold(125L);
            } else if (mediaType.equals("video")) {
              bc.setBufferLength(1500L);
              bc.setMinimumThreshold(250L);
            } 
          } 
        } catch (Exception e) {
          Log.error(e.getMessage());
          return realized;
        } 
      } 
    } 
    if (realized) {
      this.state = 1;
      int size = this.rtspUtil.getNumberOfTracks();
      this.players = new Player[size];
      this.data_sources = new DataSource[size];
      this.track_ready = new boolean[size];
      this.dataReceived = false;
      if (!this.rtspUtil.rtspStart()) {
        if (this.first_pass && this.rtspUtil.getStatusCode() == 454) {
          this.first_pass = false;
          this.playerList = new Vector();
          return initRtspSession();
        } 
        return false;
      } 
      waitForData();
      if (this.playerList.size() > 0) {
        rtspStop();
        this.rtspUtil.setStartPos(0.0D);
        for (int i = 0; i < this.rtspUtil.getNumberOfTracks(); i++)
          this.data_sources[i].flush(); 
      } else {
        this.rtspUtil.setProcessError("Media tracks not supported");
        realized = false;
      } 
    } 
    return realized;
  }
  
  public boolean doPrefetch() {
    boolean prefetched = super.doPrefetch();
    return prefetched;
  }
  
  public void doStart() {
    if (this.state >= 1 && this.state != 2) {
      for (int i = 0; i < this.rtspUtil.getNumberOfTracks(); i++) {
        this.track_ready[i] = (this.rtspUtil.getRTPManager(i) == null);
        this.data_sources[i].prebuffer();
      } 
      boolean success = this.rtspUtil.rtspStart();
      synchronized (this.readySync) {
        boolean ready = true;
        for (int j = 0; j < this.rtspUtil.getNumberOfTracks(); j++) {
          if (!this.track_ready[j]) {
            ready = false;
            break;
          } 
        } 
        if (!ready)
          try {
            this.readySync.wait(3000L);
          } catch (Exception e) {} 
      } 
      if (success) {
        super.doStart();
        startPlayers();
        this.state = 2;
        long duration = this.rtspUtil.getDuration();
        if (duration > 0L) {
          this.timer = new Timer(this, duration + 500000000L - getMediaTime().getNanoseconds());
          this.timer.start();
        } 
      } 
    } 
  }
  
  public void doSetMediaTime(Time now) {
    super.doSetMediaTime(now);
    this.rtspUtil.setStartPos(now.getNanoseconds());
    for (int i = 0; i < this.rtspUtil.getNumberOfTracks(); i++)
      this.data_sources[i].flush(); 
  }
  
  public Time getMediaTime() {
    Time time = super.getMediaTime();
    return time;
  }
  
  public void timerExpired() {
    this.timer = null;
    processEndOfMedia();
  }
  
  public void doStop() {
    if (this.state == 2) {
      super.doStop();
      if (this.timer != null) {
        this.timer.stopTimer();
        this.timer.removeListener(this);
        this.timer = null;
      } 
      stopPlayers();
      rtspStop();
      this.state = 3;
    } 
  }
  
  public void rtspStop() {
    this.rtspUtil.setStartPos(getMediaTime().getNanoseconds());
    this.rtspUtil.rtspStop();
  }
  
  public void doClose() {
    stopPlayers();
    closePlayers();
    if (this.timer != null) {
      this.timer.stopTimer();
      this.timer.removeListener(this);
      this.timer = null;
    } 
    if (this.state == 2)
      this.rtspUtil.rtspTeardown(); 
    this.state = 0;
    this.rtspUtil.closeConnection();
    for (int i = 0; i < this.rtspUtil.getNumberOfTracks(); i++) {
      RTPManager mgr = this.rtspUtil.getRTPManager(i);
      mgr.removeTargets("server down.");
      mgr.dispose();
    } 
    super.doClose();
  }
  
  public float setRate(float rate) {
    if (getState() < 300)
      throwError((Error)new NotRealizedError("Cannot set rate on an unrealized Player.")); 
    return 1.0F;
  }
  
  public void setStopTime(Time t) {
    controllerSetStopTime(t);
  }
  
  protected void stopAtTime() {
    controllerStopAtTime();
  }
  
  public synchronized void addController(Controller newController) throws IncompatibleTimeBaseException {
    int playerState = getState();
    if (playerState == 600)
      throwError((Error)new ClockStartedError("Cannot add controller to a started player")); 
    if (playerState == 100 || playerState == 200)
      throwError((Error)new NotRealizedError("A Controller cannot be added to an Unrealized Player")); 
    throw new IncompatibleTimeBaseException();
  }
  
  public boolean audioEnabled() {
    boolean enabled = true;
    return enabled;
  }
  
  public boolean videoEnabled() {
    boolean enabled = true;
    return enabled;
  }
  
  public void updateStats() {}
  
  protected TimeBase getMasterTimeBase() {
    return (TimeBase)new SystemTimeBase();
  }
  
  public synchronized void update(ReceiveStreamEvent event) {
    RTPManager source = (RTPManager)event.getSource();
    if (event instanceof NewReceiveStreamEvent) {
      ReceiveStream stream = ((NewReceiveStreamEvent)event).getReceiveStream();
      Participant part = stream.getParticipant();
      int numberOfTracks = this.rtspUtil.getNumberOfTracks();
      for (int i = 0; i < numberOfTracks; i++) {
        if (source == this.rtspUtil.getRTPManager(i)) {
          DataSource ds = (DataSource)stream.getDataSource();
          try {
            this.players[i] = Manager.createPlayer((DataSource)ds);
          } catch (Exception e) {
            System.err.println("Failed to create a player from the given Data Source: " + e);
          } 
          try {
            this.waitFailed = false;
            this.players[i].addControllerListener(new StateListener(this));
            this.players[i].realize();
            waitForState(this.players[i], 300);
          } catch (Exception e) {}
          if (this.players[i].getState() == 300) {
            this.playerList.addElement(this.players[i]);
            ds.setBufferListener(this);
            this.data_sources[i] = ds;
            break;
          } 
          this.players[i].close();
          this.players[i] = null;
          this.rtspUtil.removeTrack(i);
          break;
        } 
      } 
      if (this.playerList.size() == this.rtspUtil.getNumberOfTracks()) {
        this.dataReceived = true;
        synchronized (this) {
          notifyAll();
        } 
      } 
    } else if (event instanceof javax.media.rtp.event.ByeEvent) {
    
    } 
  }
  
  public void minThresholdReached(DataSource ds) {
    synchronized (this.readySync) {
      for (int i = 0; i < this.rtspUtil.getNumberOfTracks(); i++) {
        if (ds == this.data_sources[i]) {
          this.track_ready[i] = true;
          break;
        } 
      } 
      boolean all_ready = true;
      for (int j = 0; j < this.rtspUtil.getNumberOfTracks(); j++) {
        if (!this.track_ready[j]) {
          all_ready = false;
          break;
        } 
      } 
      if (all_ready)
        this.readySync.notifyAll(); 
    } 
  }
  
  public long getMediaNanoseconds() {
    long value = super.getMediaNanoseconds();
    return value;
  }
  
  public Time getDuration() {
    long t = this.rtspUtil.getDuration();
    if (t <= 0L)
      return Duration.DURATION_UNKNOWN; 
    return new Time(t);
  }
  
  private synchronized void waitForState(Player p, int state) {
    while (p.getState() < state && !this.waitFailed) {
      synchronized (this.stateSync) {
        try {
          this.stateSync.wait();
        } catch (InterruptedException ie) {}
      } 
    } 
  }
  
  class StateListener implements ControllerListener {
    private final Handler this$0;
    
    StateListener(Handler this$0) {
      this.this$0 = this$0;
    }
    
    public void controllerUpdate(ControllerEvent ce) {
      if (ce instanceof javax.media.ControllerClosedEvent);
      if (ce instanceof javax.media.ResourceUnavailableEvent) {
        this.this$0.waitFailed = true;
        synchronized (this.this$0.stateSync) {
          this.this$0.stateSync.notify();
        } 
      } 
      if (ce instanceof javax.media.RealizeCompleteEvent)
        synchronized (this.this$0.stateSync) {
          this.this$0.stateSync.notify();
        }  
      if (ce instanceof ControllerEvent)
        synchronized (this.this$0.stateSync) {
          this.this$0.stateSync.notify();
        }  
      if (ce instanceof javax.media.EndOfMediaEvent);
    }
  }
  
  private synchronized boolean waitForData() {
    try {
      synchronized (this) {
        while (!this.dataReceived)
          wait(); 
      } 
    } catch (InterruptedException e) {
      e.printStackTrace();
    } 
    return this.dataReceived;
  }
  
  public Handler() {
    this.container = null;
    this.rtspUtil = new RtspUtil(this);
    this.framePositioning = false;
    this.playerList = new Vector();
    this.state = 0;
    ((BasicController)this).stopThreadEnabled = true;
  }
  
  public Component getVisualComponent() {
    Vector visuals = new Vector(1);
    for (int i = 0; i < this.rtspUtil.getNumberOfTracks(); i++) {
      if (this.players[i] != null) {
        Component comp = this.players[i].getVisualComponent();
        if (comp != null)
          visuals.addElement(comp); 
      } 
    } 
    if (visuals.size() == 0)
      return null; 
    if (visuals.size() == 1)
      return visuals.elementAt(0); 
    return createVisualContainer(visuals);
  }
  
  protected Component createVisualContainer(Vector visuals) {
    Boolean hint = (Boolean)Manager.getHint(3);
    if (this.container == null) {
      if (hint == null || !hint.booleanValue()) {
        this.container = new HeavyPanel(this, visuals);
      } else {
        this.container = new LightPanel(this, visuals);
      } 
      this.container.setLayout(new FlowLayout());
      this.container.setBackground(Color.black);
      for (int i = 0; i < visuals.size(); i++) {
        Component c = visuals.elementAt(i);
        this.container.add(c);
        c.setSize(c.getPreferredSize());
      } 
    } 
    return this.container;
  }
  
  class HeavyPanel extends Panel implements VisualContainer {
    private final Handler this$0;
    
    public HeavyPanel(Handler this$0, Vector visuals) {
      this.this$0 = this$0;
    }
  }
  
  class LightPanel extends Container implements VisualContainer {
    private final Handler this$0;
    
    public LightPanel(Handler this$0, Vector visuals) {
      this.this$0 = this$0;
    }
  }
  
  public GainControl getGainControl() {
    GainControl gainControl = null;
    for (int i = 0; i < this.playerList.size(); i++) {
      Player player = this.playerList.elementAt(i);
      gainControl = player.getGainControl();
      if (gainControl != null)
        break; 
    } 
    return gainControl;
  }
  
  public Control[] getControls() {
    int size = 0;
    for (int i = 0; i < this.playerList.size(); i++) {
      Control[] controls = ((Player)this.playerList.elementAt(i)).getControls();
      size += controls.length;
    } 
    size++;
    Control[] rtspControls = new Control[size];
    RtspAdapter rtspAdapter = new RtspAdapter();
    rtspAdapter.setRTPManagers(this.rtspUtil.getRTPManagers());
    rtspAdapter.setMediaTypes(this.rtspUtil.getMediaTypes());
    int counter = 0;
    rtspControls[counter++] = (Control)rtspAdapter;
    for (int j = 0; j < this.playerList.size(); j++) {
      Control[] controls = ((Player)this.playerList.elementAt(j)).getControls();
      for (int k = 0; k < controls.length; k++)
        rtspControls[counter++] = controls[k]; 
    } 
    return rtspControls;
  }
  
  private void startPlayers() {
    for (int i = 0; i < this.playerList.size(); i++) {
      Player player = this.playerList.elementAt(i);
      player.start();
    } 
  }
  
  private void stopPlayers() {
    for (int i = 0; i < this.playerList.size(); i++) {
      Player player = this.playerList.elementAt(i);
      player.stop();
    } 
  }
  
  private void closePlayers() {
    for (int i = 0; i < this.playerList.size(); i++) {
      Player player = this.playerList.elementAt(i);
      player.close();
    } 
  }
  
  public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
    if (source instanceof com.sun.media.protocol.rtsp.DataSource) {
      MediaLocator ml = source.getLocator();
      try {
        this.url = ml.toString();
      } catch (Exception e) {
        throw new IncompatibleSourceException();
      } 
    } else {
      throw new IncompatibleSourceException();
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\content\rtsp\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */