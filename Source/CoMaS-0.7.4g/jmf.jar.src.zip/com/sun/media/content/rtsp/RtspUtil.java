/*     */ package com.sun.media.content.rtsp;
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.rtsp.RtspAppListener;
/*     */ import com.sun.media.rtsp.RtspUrl;
/*     */ import com.sun.media.rtsp.protocol.CSeqHeader;
/*     */ import com.sun.media.rtsp.protocol.ContentBaseHeader;
/*     */ import com.sun.media.rtsp.protocol.Header;
/*     */ import com.sun.media.rtsp.protocol.Message;
/*     */ import com.sun.media.rtsp.protocol.OptionsMessage;
/*     */ import com.sun.media.rtsp.protocol.ResponseMessage;
/*     */ import com.sun.media.rtsp.protocol.SessionHeader;
/*     */ import com.sun.media.rtsp.protocol.TransportHeader;
/*     */ import com.sun.media.sdp.MediaAttribute;
/*     */ import com.sun.media.sdp.MediaDescription;
/*     */ import com.sun.media.sdp.SdpParser;
/*     */ import java.net.InetAddress;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.Vector;
/*     */ import javax.media.rtp.RTPManager;
/*     */ import javax.media.rtp.ReceiveStreamListener;
/*     */ import javax.media.rtp.SessionAddress;
/*     */ 
/*     */ public class RtspUtil implements RtspListener {
/*  24 */   private final int TIMER_1 = 60000;
/*  25 */   private final int TIMER_2 = 30000;
/*     */   
/*     */   private RtspManager rtspManager;
/*     */   
/*     */   private RTPManager[] mgrs;
/*     */   
/*     */   private String[] mediaTypes;
/*     */   
/*     */   private long sequenceNumber;
/*     */   
/*     */   private int numberOfTracks;
/*     */   
/*     */   private String userAgent;
/*     */   
/*     */   private RtspUrl rtspUrl;
/*     */   
/*     */   private String[] mediaControls;
/*     */   
/*     */   private int[] server_ports;
/*     */   
/*     */   private int[] client_ports;
/*     */   
/*     */   private String[] session_ids;
/*     */   
/*     */   private Message message;
/*     */   
/*     */   private int connectionId;
/*     */   
/*     */   private String url;
/*     */   private double startPos;
/*     */   private String processError;
/*     */   private long duration;
/*     */   private Vector listeners;
/*     */   private ReceiveStreamListener parent;
/*     */   boolean responseReceived;
/*     */   boolean dataReceived;
/*     */   Object responseSync;
/*     */   
/*     */   public void setUrl(String url) {
/*  64 */     this.url = url;
/*     */   }
/*     */   
/*     */   public void setStartPos(double startPos) {
/*  68 */     this.startPos = startPos;
/*     */   }
/*     */   
/*     */   public RTPManager getRTPManager(int i) {
/*  72 */     return this.mgrs[i];
/*     */   }
/*     */   
/*     */   public RTPManager[] getRTPManagers() {
/*  76 */     return this.mgrs;
/*     */   }
/*     */   
/*     */   public String getMediaType(int i) {
/*  80 */     return this.mediaTypes[i];
/*     */   }
/*     */   
/*     */   public String[] getMediaTypes() {
/*  84 */     return this.mediaTypes;
/*     */   }
/*     */   
/*     */   public long getDuration() {
/*  88 */     return this.duration;
/*     */   }
/*     */   
/*     */   public void removeTrack(int trackId) {
/*  92 */     Log.comment("track removed: " + this.mediaTypes[trackId]);
/*     */     
/*  94 */     this.mgrs[trackId].removeTargets("media track not supported");
/*  95 */     this.mgrs[trackId].dispose();
/*     */     
/*  97 */     this.numberOfTracks--;
/*     */     
/*  99 */     if (trackId + 1 > this.mgrs.length) {
/* 100 */       int length = this.mgrs.length - trackId - 1;
/*     */       
/* 102 */       System.arraycopy(this.mgrs, trackId + 1, this.mgrs, trackId, length);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean createConnection() {
/* 107 */     boolean realized = true;
/*     */     
/*     */     try {
/* 110 */       this.rtspUrl = new RtspUrl(this.url);
/*     */     } catch (MalformedURLException e) {
/* 112 */       this.processError = "Invalid RTSP URL: " + this.url;
/* 113 */       return false;
/*     */     } 
/*     */     
/* 116 */     String ipAddress = getServerIpAddress();
/*     */     
/* 118 */     if (ipAddress == null) {
/* 119 */       Log.error("Invalid server address:" + this.url);
/* 120 */       this.processError = "Invalid Server adress: " + this.url;
/* 121 */       return false;
/*     */     } 
/*     */     
/* 124 */     this.connectionId = this.rtspManager.createConnection(ipAddress, this.rtspUrl.getPort());
/*     */     
/* 126 */     if (this.connectionId < 0) {
/* 127 */       switch (this.connectionId) {
/*     */         case -2:
/* 129 */           this.processError = "Unknown RTSP Host!";
/*     */           break;
/*     */         case -3:
/* 132 */           this.processError = "Can't connect to RTSP Server!";
/*     */           break;
/*     */         default:
/* 135 */           this.processError = "Unknown reason";
/*     */           break;
/*     */       } 
/*     */       
/* 139 */       realized = false;
/*     */     } 
/*     */     
/* 142 */     return realized;
/*     */   }
/*     */   
/*     */   public void closeConnection() {
/* 146 */     this.rtspManager.closeConnection(this.connectionId);
/*     */   }
/*     */   
/*     */   public boolean rtspSetup() {
/* 150 */     String msg = "DESCRIBE rtsp://" + this.rtspUrl.getHost() + "/" + this.rtspUrl.getFile() + " RTSP/1.0\r\n" + "CSeq: " + this.sequenceNumber + "\r\n" + "Accept: application/sdp\r\n" + this.userAgent + "\r\n\r\n";
/*     */ 
/*     */ 
/*     */     
/* 154 */     sendMessage(msg);
/*     */     
/* 156 */     boolean timeout = waitForResponse(60000);
/*     */     
/* 158 */     if (timeout) {
/* 159 */       sendStatusMessage(3, "Timeout received.");
/*     */       
/* 161 */       return false;
/*     */     } 
/*     */     
/* 164 */     if (!responseOk()) {
/* 165 */       return false;
/*     */     }
/*     */     
/* 168 */     setDuration();
/*     */ 
/*     */     
/* 171 */     this.numberOfTracks = getNumTracks();
/*     */     
/* 173 */     this.client_ports = new int[this.numberOfTracks];
/*     */     
/* 175 */     this.mgrs = new RTPManager[this.numberOfTracks];
/*     */ 
/*     */     
/* 178 */     this.mediaControls = new String[this.numberOfTracks];
/* 179 */     this.mediaTypes = new String[this.numberOfTracks];
/* 180 */     String[] dynamicPayloads = new String[this.numberOfTracks];
/*     */     
/* 182 */     for (int i = 0; i < this.numberOfTracks; i++) {
/* 183 */       this.mgrs[i] = createSessionManager(i);
/*     */       
/* 185 */       this.mediaTypes[i] = getCurMediaType(i);
/* 186 */       this.mediaControls[i] = getMediaAttributeValue(i, "control");
/* 187 */       dynamicPayloads[i] = getMediaAttributeValue(i, "rtpmap");
/*     */ 
/*     */       
/* 190 */       if (this.mediaTypes[i] != null && dynamicPayloads[i] != null) {
/* 191 */         addDynamicPayload(this.mgrs[i], this.mediaTypes[i], dynamicPayloads[i]);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 196 */     String contentBase = getContentBase();
/*     */     
/* 198 */     this.session_ids = new String[this.numberOfTracks];
/*     */     
/* 200 */     this.server_ports = new int[this.numberOfTracks];
/*     */ 
/*     */     
/* 203 */     for (int j = 0; j < this.numberOfTracks; j++) {
/* 204 */       if (j == 0) {
/* 205 */         msg = "SETUP " + contentBase + this.mediaControls[j] + " RTSP/1.0\r\n" + "CSeq: " + this.sequenceNumber + "\r\n" + "Transport: RTP/AVP;unicast;client_port=" + this.client_ports[j] + "-" + (this.client_ports[j] + 1) + "\r\n" + this.userAgent + "\r\n\r\n";
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 210 */         msg = "SETUP " + contentBase + this.mediaControls[j] + " RTSP/1.0\r\n" + "CSeq: " + this.sequenceNumber + "\r\n" + "Transport: RTP/AVP;unicast;client_port=" + this.client_ports[j] + "-" + (this.client_ports[j] + 1) + "\r\n" + "Session: " + this.session_ids[0] + "\r\n" + this.userAgent + "\r\n\r\n";
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 217 */       sendMessage(msg);
/*     */       
/* 219 */       timeout = waitForResponse(30000);
/*     */       
/* 221 */       if (timeout) {
/* 222 */         Log.error("ERROR: Timeout received (1).");
/* 223 */         this.processError = "Server is not responding";
/* 224 */         return false;
/*     */       } 
/*     */       
/* 227 */       if (!responseOk()) {
/* 228 */         return false;
/*     */       }
/*     */       
/* 231 */       String sessionId = getSessionId();
/*     */       
/* 233 */       if (sessionId == null) {
/* 234 */         this.processError = "Invalid session ID";
/* 235 */         return false;
/*     */       } 
/*     */       
/* 238 */       this.session_ids[j] = sessionId;
/*     */       
/* 240 */       int pos = this.session_ids[j].indexOf(';');
/*     */       
/* 242 */       if (pos > 0) {
/* 243 */         this.session_ids[j] = this.session_ids[j].substring(0, pos);
/*     */       }
/*     */       
/* 246 */       int serverPort = getServerDataPort();
/*     */       
/* 248 */       if (serverPort == -1) {
/* 249 */         this.processError = "Invalid server data port";
/* 250 */         return false;
/*     */       } 
/*     */       
/* 253 */       this.server_ports[j] = serverPort;
/*     */     } 
/*     */     
/* 256 */     return true;
/*     */   }
/*     */   
/*     */   private boolean responseOk() {
/* 260 */     boolean result = false;
/*     */     
/* 262 */     int statusCode = getStatusCode();
/*     */     
/* 264 */     if (statusCode == 200) {
/* 265 */       result = true;
/*     */     } else {
/* 267 */       this.processError = "Message from RTSP Server - " + getStatusText(statusCode);
/*     */     } 
/*     */     
/* 270 */     return result;
/*     */   }
/*     */   
/*     */   private String getSessionId() {
/* 274 */     String id = null;
/*     */     
/*     */     try {
/* 277 */       ResponseMessage responseMsg = (ResponseMessage)this.message.getParameter();
/*     */       
/* 279 */       SessionHeader hdr = (SessionHeader)(responseMsg.getResponse().getHeader(3)).parameter;
/*     */ 
/*     */       
/* 282 */       id = hdr.getSessionId();
/* 283 */     } catch (Exception e) {}
/*     */ 
/*     */     
/* 286 */     return id;
/*     */   }
/*     */   
/*     */   private int getServerDataPort() {
/* 290 */     int port = -1;
/*     */     
/*     */     try {
/* 293 */       ResponseMessage responseMsg = (ResponseMessage)this.message.getParameter();
/*     */       
/* 295 */       TransportHeader transport_hdr = (TransportHeader)(responseMsg.getResponse().getHeader(1)).parameter;
/*     */ 
/*     */ 
/*     */       
/* 299 */       port = transport_hdr.getServerDataPort();
/* 300 */     } catch (Exception e) {}
/*     */ 
/*     */     
/* 303 */     return port;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean rtspStart() {
/* 310 */     String msg = "PLAY rtsp://" + this.rtspUrl.getHost() + "/" + this.rtspUrl.getFile() + " RTSP/1.0\r\n" + "CSeq: " + this.sequenceNumber + "\r\n" + "Range: npt=" + (this.startPos / 1.0E9D) + "-\r\n" + "Session: " + this.session_ids[0] + "\r\n" + this.userAgent + "\r\n\r\n";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 316 */     sendMessage(msg);
/*     */     
/* 318 */     boolean timeout = waitForResponse(30000);
/*     */     
/* 320 */     if (timeout) {
/* 321 */       this.processError = "Server is not responding";
/* 322 */       return false;
/*     */     } 
/*     */     
/* 325 */     int code = getStatusCode();
/*     */     
/* 327 */     if (code == -1) {
/* 328 */       this.processError = "Received invalid status code";
/* 329 */       return false;
/*     */     } 
/*     */     
/* 332 */     if (getStatusCode() == 454) {
/* 333 */       int i = 0; if (i < this.numberOfTracks) {
/* 334 */         this.mgrs[i].removeTargets("session not found");
/* 335 */         this.mgrs[i].dispose();
/*     */         
/* 337 */         return false;
/*     */       } 
/*     */     } 
/*     */     
/* 341 */     return true;
/*     */   }
/*     */   
/*     */   public void rtspStop() {
/* 345 */     String msg = "PAUSE rtsp://" + this.rtspUrl.getHost() + "/" + this.rtspUrl.getFile() + " RTSP/1.0\r\n" + "CSeq: " + this.sequenceNumber + "\r\n" + "Session: " + this.session_ids[0] + "\r\n" + this.userAgent + "\r\n\r\n";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 351 */     sendMessage(msg);
/*     */     
/* 353 */     boolean timeout = waitForResponse(30000);
/*     */     
/* 355 */     if (timeout) {
/* 356 */       sendStatusMessage(3, "Timeout received.");
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void rtspTeardown() {
/* 363 */     String msg = "TEARDOWN rtsp://" + this.rtspUrl.getHost() + "/" + this.rtspUrl.getFile() + " RTSP/1.0\r\n" + "CSeq: " + this.sequenceNumber + "\r\n" + "Session: " + this.session_ids[0] + "\r\n" + this.userAgent + "\r\n\r\n";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 368 */     sendMessage(msg);
/*     */     
/* 370 */     boolean timeout = waitForResponse(30000);
/*     */     
/* 372 */     if (timeout) {
/* 373 */       sendStatusMessage(3, "Timeout received.");
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RTPManager createSessionManager(int index) {
/* 381 */     RTPManager rtpManager = RTPManager.newInstance();
/*     */     
/* 383 */     if (rtpManager == null) {
/* 384 */       return null;
/*     */     }
/*     */     
/* 387 */     rtpManager.addReceiveStreamListener(this.parent);
/*     */ 
/*     */     
/*     */     try {
/* 391 */       InetAddress localHost = InetAddress.getLocalHost();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 396 */       SessionAddress localAddress = new SessionAddress();
/*     */ 
/*     */       
/* 399 */       rtpManager.initialize(localAddress);
/*     */       
/* 401 */       this.client_ports[index] = localAddress.getDataPort();
/*     */     } catch (Exception e) {
/* 403 */       e.printStackTrace();
/* 404 */       return null;
/*     */     } 
/*     */     
/* 407 */     return rtpManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addDynamicPayload(RTPManager mgr, String typeStr, String dpStr) {
/* 424 */     int c = 0;
/* 425 */     for (; dpStr.length() > 0 && dpStr.charAt(c) == ' '; c++);
/* 426 */     if (c > 0) {
/* 427 */       dpStr = dpStr.substring(c);
/*     */     }
/*     */     
/* 430 */     c = 0;
/* 431 */     for (; dpStr.length() > 0 && dpStr.charAt(c) != ' '; c++);
/* 432 */     if (c < 0) {
/*     */       return;
/*     */     }
/* 435 */     String tmpStr = dpStr.substring(0, c);
/* 436 */     dpStr = dpStr.substring(c);
/*     */     
/* 438 */     Integer integer = Integer.valueOf(tmpStr);
/* 439 */     if (integer == null) {
/*     */       return;
/*     */     }
/*     */     
/* 443 */     int payload = integer.intValue();
/* 444 */     if (payload < 96 || payload > 127) {
/*     */       return;
/*     */     }
/*     */     
/* 448 */     c = 0;
/* 449 */     for (; dpStr.length() > 0 && dpStr.charAt(c) == ' '; c++);
/* 450 */     if (c > 0) {
/* 451 */       dpStr = dpStr.substring(c);
/*     */     }
/* 453 */     if (dpStr.length() == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 457 */     c = 0;
/* 458 */     for (; dpStr.length() > 0 && dpStr.charAt(c) != '/'; c++);
/* 459 */     if (c > 0) {
/* 460 */       tmpStr = dpStr.substring(0, c);
/*     */     } else {
/* 462 */       tmpStr = dpStr;
/*     */     } 
/* 464 */     if (tmpStr.length() == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 468 */     tmpStr = tmpStr.toLowerCase() + "/rtp";
/*     */ 
/*     */ 
/*     */     
/* 472 */     if ("video".equalsIgnoreCase(typeStr)) {
/* 473 */       mgr.addFormat((Format)new VideoFormat(tmpStr), payload);
/* 474 */       Log.comment("Add RTP dynamic payload for video: " + payload + " : " + tmpStr);
/* 475 */     }  if ("audio".equalsIgnoreCase(typeStr)) {
/* 476 */       mgr.addFormat((Format)new AudioFormat(tmpStr), payload);
/* 477 */       Log.comment("Add RTP dynamic payload for audio: " + payload + " : " + tmpStr);
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getStatusCode() {
/* 482 */     int code = -1;
/*     */     
/*     */     try {
/* 485 */       ResponseMessage responseMsg = (ResponseMessage)this.message.getParameter();
/* 486 */       code = responseMsg.getResponse().getStatusLine().getCode();
/* 487 */     } catch (Exception e) {}
/*     */ 
/*     */     
/* 490 */     return code;
/*     */   }
/*     */   
/*     */   private String getStatusText(int code) {
/* 494 */     return StatusCode.getStatusText(code);
/*     */   }
/*     */   
/*     */   private void setDuration() {
/* 498 */     this.duration = 0L;
/*     */     
/* 500 */     ResponseMessage msg = (ResponseMessage)this.message.getParameter();
/*     */     
/* 502 */     double start_time = 0.0D;
/* 503 */     double end_time = 0.0D;
/*     */     
/* 505 */     SdpParser sdp = (msg.getResponse()).sdp;
/*     */     
/* 507 */     if (sdp != null) {
/* 508 */       MediaAttribute attribute = sdp.getSessionAttribute("range");
/*     */       
/* 510 */       if (attribute != null) {
/* 511 */         String value = attribute.getValue();
/*     */         
/* 513 */         if (value.startsWith("npt")) {
/* 514 */           int start = value.indexOf('=') + 1;
/* 515 */           int end = value.indexOf('-');
/*     */           
/* 517 */           String startTime = value.substring(start, end).trim();
/*     */           
/* 519 */           String endTime = value.substring(end + 1).trim();
/*     */           
/* 521 */           end_time = (new Double(endTime)).doubleValue();
/*     */           
/* 523 */           this.duration = (long)(end_time * 1.0E9D);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private int getNumTracks() {
/* 530 */     int numTracks = 0;
/*     */     
/* 532 */     ResponseMessage msg = (ResponseMessage)this.message.getParameter();
/*     */     
/* 534 */     SdpParser sdp = (msg.getResponse()).sdp;
/*     */     
/* 536 */     if (sdp != null) {
/* 537 */       numTracks = sdp.getMediaDescriptions().size();
/*     */     }
/*     */     
/* 540 */     return numTracks;
/*     */   }
/*     */   
/*     */   private MediaDescription getMediaDescription(String mediaName) {
/* 544 */     MediaDescription description = null;
/*     */     
/*     */     try {
/* 547 */       ResponseMessage msg = (ResponseMessage)this.message.getParameter();
/*     */       
/* 549 */       SdpParser sdp = (msg.getResponse()).sdp;
/*     */       
/* 551 */       description = sdp.getMediaDescription(mediaName);
/* 552 */     } catch (Exception e) {}
/*     */ 
/*     */     
/* 555 */     return description;
/*     */   }
/*     */   
/*     */   private String getCurMediaType(int i) {
/* 559 */     String type = null;
/*     */     
/*     */     try {
/* 562 */       ResponseMessage msg = (ResponseMessage)this.message.getParameter();
/*     */       
/* 564 */       SdpParser sdp = (msg.getResponse()).sdp;
/*     */       
/* 566 */       MediaDescription md = sdp.getMediaDescriptions().elementAt(i);
/*     */       
/* 568 */       type = md.name;
/* 569 */     } catch (Exception e) {}
/*     */ 
/*     */     
/* 572 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getMediaAttribute(MediaDescription md, String attribute) {
/* 578 */     String mediaAttribute = "";
/*     */     
/* 580 */     if (md != null) {
/* 581 */       MediaAttribute ma = md.getMediaAttribute("control");
/*     */       
/* 583 */       if (ma != null) {
/* 584 */         mediaAttribute = ma.getValue();
/*     */       }
/*     */     } 
/*     */     
/* 588 */     return mediaAttribute;
/*     */   }
/*     */   
/*     */   private String getMediaAttributeValue(int i, String attribute) {
/* 592 */     String value = null;
/*     */     
/*     */     try {
/* 595 */       ResponseMessage msg = (ResponseMessage)this.message.getParameter();
/*     */       
/* 597 */       SdpParser sdp = (msg.getResponse()).sdp;
/*     */       
/* 599 */       MediaDescription md = sdp.getMediaDescriptions().elementAt(i);
/*     */       
/* 601 */       MediaAttribute ma = md.getMediaAttribute(attribute);
/*     */       
/* 603 */       value = ma.getValue();
/* 604 */     } catch (Exception e) {}
/*     */ 
/*     */     
/* 607 */     return value;
/*     */   }
/*     */   
/*     */   private String getTrackID(String mediaName) {
/* 611 */     String trackId = null;
/*     */     
/*     */     try {
/* 614 */       ResponseMessage msg = (ResponseMessage)this.message.getParameter();
/*     */       
/* 616 */       SdpParser sdp = (msg.getResponse()).sdp;
/*     */       
/* 618 */       MediaDescription description = sdp.getMediaDescription(mediaName);
/*     */       
/* 620 */       MediaAttribute attribute = description.getMediaAttribute("control");
/*     */       
/* 622 */       trackId = attribute.getValue();
/* 623 */     } catch (Exception e) {}
/*     */ 
/*     */     
/* 626 */     return trackId;
/*     */   }
/*     */   
/*     */   private String getContentBase() {
/* 630 */     String contentBase = "";
/*     */     
/*     */     try {
/* 633 */       ResponseMessage responseMsg = (ResponseMessage)this.message.getParameter();
/*     */       
/* 635 */       Header header = responseMsg.getResponse().getHeader(9);
/*     */       
/* 637 */       ContentBaseHeader cbh = (ContentBaseHeader)header.parameter;
/*     */       
/* 639 */       contentBase = cbh.getContentBase();
/* 640 */     } catch (Exception e) {}
/*     */ 
/*     */     
/* 643 */     return contentBase;
/*     */   }
/*     */   
/*     */   private void sendMessage(String message) {
/* 647 */     this.responseReceived = false;
/*     */     
/* 649 */     boolean success = this.rtspManager.sendMessage(this.connectionId, message);
/*     */     
/* 651 */     if (!success) {
/* 652 */       String ipAddress = getServerIpAddress();
/*     */       
/* 654 */       this.connectionId = this.rtspManager.createConnection(ipAddress, this.rtspUrl.getPort());
/*     */       
/* 656 */       this.rtspManager.sendMessage(this.connectionId, message);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RtspUtil(ReceiveStreamListener parent) {
/* 663 */     this.responseSync = new Object(); this.parent = parent; this.listeners = new Vector(); this.rtspManager = new RtspManager(false);
/*     */     this.sequenceNumber = (long)(Math.random() * 1000.0D);
/*     */     this.userAgent = "User-Agent: JMF RTSP Player " + BasicPlayer.VERSION;
/* 666 */     this.rtspManager.addListener(this); } private synchronized boolean waitForResponse(int time) { boolean timeout = false;
/*     */     
/*     */     try {
/* 669 */       synchronized (this.responseSync) {
/*     */         
/* 671 */         if (!this.responseReceived) {
/* 672 */           this.responseSync.wait(time);
/*     */         }
/*     */         
/* 675 */         if (this.responseReceived) {
/* 676 */           this.sequenceNumber++;
/*     */         } else {
/* 678 */           timeout = true;
/*     */         } 
/*     */       } 
/*     */     } catch (InterruptedException e) {
/* 682 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 685 */     return timeout; }
/*     */ 
/*     */   
/*     */   private void processRtspRequest(int connectionId, Message message) {
/* 689 */     if (message.getType() == 4) {
/* 690 */       OptionsMessage msg = (OptionsMessage)message.getParameter();
/*     */       
/* 692 */       sendResponse(connectionId, msg.getRequest());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void processRtspResponse(int connectionId, Message message) {
/* 697 */     this.message = message;
/*     */     
/* 699 */     this.responseReceived = true;
/*     */     
/* 701 */     synchronized (this.responseSync) {
/* 702 */       this.responseSync.notify();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void sendResponse(int connectionId, Request msg) {
/* 707 */     String type = null;
/*     */     
/* 709 */     Header header = msg.getHeader(2);
/*     */     
/* 711 */     if (header != null) {
/* 712 */       CSeqHeader cSeqHeader = (CSeqHeader)header.parameter;
/*     */       
/* 714 */       String message = "RTSP/1.0 200 OK\r\nCSeq: " + cSeqHeader.getSequenceNumber() + "\r\n\r\n";
/*     */ 
/*     */       
/* 717 */       sendMessage(message);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void sendStatusMessage(int code, String message) {
/* 722 */     for (int i = 0; i < this.listeners.size(); i++) {
/* 723 */       ((RtspAppListener)this.listeners.elementAt(i)).postStatusMessage(code, message);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(RtspAppListener listener) {
/* 729 */     this.listeners.addElement(listener);
/*     */   }
/*     */   
/*     */   public void removeListener(RtspAppListener listener) {
/* 733 */     this.listeners.removeElement(listener);
/*     */   }
/*     */   
/*     */   public int getNumberOfTracks() {
/* 737 */     return this.numberOfTracks;
/*     */   }
/*     */   
/*     */   public int[] getServerPorts() {
/* 741 */     return this.server_ports;
/*     */   }
/*     */   
/*     */   public void rtspMessageIndication(int connectionId, Message message) {
/* 745 */     if (message.getType() == 12) {
/* 746 */       processRtspResponse(connectionId, message);
/*     */     } else {
/* 748 */       processRtspRequest(connectionId, message);
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getServerIpAddress() {
/* 753 */     String ipAddress = null;
/*     */     
/*     */     try {
/* 756 */       if (this.rtspUrl == null) {
/* 757 */         this.rtspUrl = new RtspUrl(this.url);
/*     */       }
/*     */       
/* 760 */       String host = this.rtspUrl.getHost();
/*     */       
/* 762 */       if (host != null) {
/* 763 */         ipAddress = InetAddress.getByName(host).getHostAddress();
/*     */       }
/* 765 */     } catch (MalformedURLException e) {
/*     */     
/* 767 */     } catch (UnknownHostException e) {}
/*     */ 
/*     */ 
/*     */     
/* 771 */     return ipAddress;
/*     */   }
/*     */ 
/*     */   
/*     */   public void rtspConnectionTerminated(int connectionId) {}
/*     */ 
/*     */   
/*     */   public String getProcessError() {
/* 779 */     return this.processError;
/*     */   }
/*     */   
/*     */   public void setProcessError(String error) {
/* 783 */     this.processError = error;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\content\rtsp\RtspUtil.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */