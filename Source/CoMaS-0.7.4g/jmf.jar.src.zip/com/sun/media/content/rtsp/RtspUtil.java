package com.sun.media.content.rtsp;

import com.sun.media.BasicPlayer;
import com.sun.media.Log;
import com.sun.media.rtsp.RtspAppListener;
import com.sun.media.rtsp.RtspListener;
import com.sun.media.rtsp.RtspManager;
import com.sun.media.rtsp.RtspUrl;
import com.sun.media.rtsp.protocol.CSeqHeader;
import com.sun.media.rtsp.protocol.ContentBaseHeader;
import com.sun.media.rtsp.protocol.Header;
import com.sun.media.rtsp.protocol.Message;
import com.sun.media.rtsp.protocol.OptionsMessage;
import com.sun.media.rtsp.protocol.Request;
import com.sun.media.rtsp.protocol.ResponseMessage;
import com.sun.media.rtsp.protocol.SessionHeader;
import com.sun.media.rtsp.protocol.StatusCode;
import com.sun.media.rtsp.protocol.TransportHeader;
import com.sun.media.sdp.MediaAttribute;
import com.sun.media.sdp.MediaDescription;
import com.sun.media.sdp.SdpParser;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.util.Vector;
import javax.media.Format;
import javax.media.format.AudioFormat;
import javax.media.format.VideoFormat;
import javax.media.rtp.RTPManager;
import javax.media.rtp.ReceiveStreamListener;
import javax.media.rtp.SessionAddress;

public class RtspUtil implements RtspListener {
  private final int TIMER_1 = 60000;
  
  private final int TIMER_2 = 30000;
  
  private RtspManager rtspManager;
  
  private RTPManager[] mgrs;
  
  private String[] mediaTypes;
  
  private long sequenceNumber;
  
  private int numberOfTracks;
  
  private String userAgent;
  
  private RtspUrl rtspUrl;
  
  private String[] mediaControls;
  
  private int[] server_ports;
  
  private int[] client_ports;
  
  private String[] session_ids;
  
  private Message message;
  
  private int connectionId;
  
  private String url;
  
  private double startPos;
  
  private String processError;
  
  private long duration;
  
  private Vector listeners;
  
  private ReceiveStreamListener parent;
  
  boolean responseReceived;
  
  boolean dataReceived;
  
  Object responseSync;
  
  public void setUrl(String url) {
    this.url = url;
  }
  
  public void setStartPos(double startPos) {
    this.startPos = startPos;
  }
  
  public RTPManager getRTPManager(int i) {
    return this.mgrs[i];
  }
  
  public RTPManager[] getRTPManagers() {
    return this.mgrs;
  }
  
  public String getMediaType(int i) {
    return this.mediaTypes[i];
  }
  
  public String[] getMediaTypes() {
    return this.mediaTypes;
  }
  
  public long getDuration() {
    return this.duration;
  }
  
  public void removeTrack(int trackId) {
    Log.comment("track removed: " + this.mediaTypes[trackId]);
    this.mgrs[trackId].removeTargets("media track not supported");
    this.mgrs[trackId].dispose();
    this.numberOfTracks--;
    if (trackId + 1 > this.mgrs.length) {
      int length = this.mgrs.length - trackId - 1;
      System.arraycopy(this.mgrs, trackId + 1, this.mgrs, trackId, length);
    } 
  }
  
  public boolean createConnection() {
    boolean realized = true;
    try {
      this.rtspUrl = new RtspUrl(this.url);
    } catch (MalformedURLException e) {
      this.processError = "Invalid RTSP URL: " + this.url;
      return false;
    } 
    String ipAddress = getServerIpAddress();
    if (ipAddress == null) {
      Log.error("Invalid server address:" + this.url);
      this.processError = "Invalid Server adress: " + this.url;
      return false;
    } 
    this.connectionId = this.rtspManager.createConnection(ipAddress, this.rtspUrl.getPort());
    if (this.connectionId < 0) {
      switch (this.connectionId) {
        case -2:
          this.processError = "Unknown RTSP Host!";
          break;
        case -3:
          this.processError = "Can't connect to RTSP Server!";
          break;
        default:
          this.processError = "Unknown reason";
          break;
      } 
      realized = false;
    } 
    return realized;
  }
  
  public void closeConnection() {
    this.rtspManager.closeConnection(this.connectionId);
  }
  
  public boolean rtspSetup() {
    String msg = "DESCRIBE rtsp://" + this.rtspUrl.getHost() + "/" + this.rtspUrl.getFile() + " RTSP/1.0\r\n" + "CSeq: " + this.sequenceNumber + "\r\n" + "Accept: application/sdp\r\n" + this.userAgent + "\r\n\r\n";
    sendMessage(msg);
    boolean timeout = waitForResponse(60000);
    if (timeout) {
      sendStatusMessage(3, "Timeout received.");
      return false;
    } 
    if (!responseOk())
      return false; 
    setDuration();
    this.numberOfTracks = getNumTracks();
    this.client_ports = new int[this.numberOfTracks];
    this.mgrs = new RTPManager[this.numberOfTracks];
    this.mediaControls = new String[this.numberOfTracks];
    this.mediaTypes = new String[this.numberOfTracks];
    String[] dynamicPayloads = new String[this.numberOfTracks];
    for (int i = 0; i < this.numberOfTracks; i++) {
      this.mgrs[i] = createSessionManager(i);
      this.mediaTypes[i] = getCurMediaType(i);
      this.mediaControls[i] = getMediaAttributeValue(i, "control");
      dynamicPayloads[i] = getMediaAttributeValue(i, "rtpmap");
      if (this.mediaTypes[i] != null && dynamicPayloads[i] != null)
        addDynamicPayload(this.mgrs[i], this.mediaTypes[i], dynamicPayloads[i]); 
    } 
    String contentBase = getContentBase();
    this.session_ids = new String[this.numberOfTracks];
    this.server_ports = new int[this.numberOfTracks];
    for (int j = 0; j < this.numberOfTracks; j++) {
      if (j == 0) {
        msg = "SETUP " + contentBase + this.mediaControls[j] + " RTSP/1.0\r\n" + "CSeq: " + this.sequenceNumber + "\r\n" + "Transport: RTP/AVP;unicast;client_port=" + this.client_ports[j] + "-" + (this.client_ports[j] + 1) + "\r\n" + this.userAgent + "\r\n\r\n";
      } else {
        msg = "SETUP " + contentBase + this.mediaControls[j] + " RTSP/1.0\r\n" + "CSeq: " + this.sequenceNumber + "\r\n" + "Transport: RTP/AVP;unicast;client_port=" + this.client_ports[j] + "-" + (this.client_ports[j] + 1) + "\r\n" + "Session: " + this.session_ids[0] + "\r\n" + this.userAgent + "\r\n\r\n";
      } 
      sendMessage(msg);
      timeout = waitForResponse(30000);
      if (timeout) {
        Log.error("ERROR: Timeout received (1).");
        this.processError = "Server is not responding";
        return false;
      } 
      if (!responseOk())
        return false; 
      String sessionId = getSessionId();
      if (sessionId == null) {
        this.processError = "Invalid session ID";
        return false;
      } 
      this.session_ids[j] = sessionId;
      int pos = this.session_ids[j].indexOf(';');
      if (pos > 0)
        this.session_ids[j] = this.session_ids[j].substring(0, pos); 
      int serverPort = getServerDataPort();
      if (serverPort == -1) {
        this.processError = "Invalid server data port";
        return false;
      } 
      this.server_ports[j] = serverPort;
    } 
    return true;
  }
  
  private boolean responseOk() {
    boolean result = false;
    int statusCode = getStatusCode();
    if (statusCode == 200) {
      result = true;
    } else {
      this.processError = "Message from RTSP Server - " + getStatusText(statusCode);
    } 
    return result;
  }
  
  private String getSessionId() {
    String id = null;
    try {
      ResponseMessage responseMsg = (ResponseMessage)this.message.getParameter();
      SessionHeader hdr = (SessionHeader)(responseMsg.getResponse().getHeader(3)).parameter;
      id = hdr.getSessionId();
    } catch (Exception e) {}
    return id;
  }
  
  private int getServerDataPort() {
    int port = -1;
    try {
      ResponseMessage responseMsg = (ResponseMessage)this.message.getParameter();
      TransportHeader transport_hdr = (TransportHeader)(responseMsg.getResponse().getHeader(1)).parameter;
      port = transport_hdr.getServerDataPort();
    } catch (Exception e) {}
    return port;
  }
  
  public boolean rtspStart() {
    String msg = "PLAY rtsp://" + this.rtspUrl.getHost() + "/" + this.rtspUrl.getFile() + " RTSP/1.0\r\n" + "CSeq: " + this.sequenceNumber + "\r\n" + "Range: npt=" + (this.startPos / 1.0E9D) + "-\r\n" + "Session: " + this.session_ids[0] + "\r\n" + this.userAgent + "\r\n\r\n";
    sendMessage(msg);
    boolean timeout = waitForResponse(30000);
    if (timeout) {
      this.processError = "Server is not responding";
      return false;
    } 
    int code = getStatusCode();
    if (code == -1) {
      this.processError = "Received invalid status code";
      return false;
    } 
    if (getStatusCode() == 454) {
      int i = 0;
      if (i < this.numberOfTracks) {
        this.mgrs[i].removeTargets("session not found");
        this.mgrs[i].dispose();
        return false;
      } 
    } 
    return true;
  }
  
  public void rtspStop() {
    String msg = "PAUSE rtsp://" + this.rtspUrl.getHost() + "/" + this.rtspUrl.getFile() + " RTSP/1.0\r\n" + "CSeq: " + this.sequenceNumber + "\r\n" + "Session: " + this.session_ids[0] + "\r\n" + this.userAgent + "\r\n\r\n";
    sendMessage(msg);
    boolean timeout = waitForResponse(30000);
    if (timeout) {
      sendStatusMessage(3, "Timeout received.");
      return;
    } 
  }
  
  public void rtspTeardown() {
    String msg = "TEARDOWN rtsp://" + this.rtspUrl.getHost() + "/" + this.rtspUrl.getFile() + " RTSP/1.0\r\n" + "CSeq: " + this.sequenceNumber + "\r\n" + "Session: " + this.session_ids[0] + "\r\n" + this.userAgent + "\r\n\r\n";
    sendMessage(msg);
    boolean timeout = waitForResponse(30000);
    if (timeout) {
      sendStatusMessage(3, "Timeout received.");
      return;
    } 
  }
  
  public RTPManager createSessionManager(int index) {
    RTPManager rtpManager = RTPManager.newInstance();
    if (rtpManager == null)
      return null; 
    rtpManager.addReceiveStreamListener(this.parent);
    try {
      InetAddress localHost = InetAddress.getLocalHost();
      SessionAddress localAddress = new SessionAddress();
      rtpManager.initialize(localAddress);
      this.client_ports[index] = localAddress.getDataPort();
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    } 
    return rtpManager;
  }
  
  private void addDynamicPayload(RTPManager mgr, String typeStr, String dpStr) {
    int c = 0;
    for (; dpStr.length() > 0 && dpStr.charAt(c) == ' '; c++);
    if (c > 0)
      dpStr = dpStr.substring(c); 
    c = 0;
    for (; dpStr.length() > 0 && dpStr.charAt(c) != ' '; c++);
    if (c < 0)
      return; 
    String tmpStr = dpStr.substring(0, c);
    dpStr = dpStr.substring(c);
    Integer integer = Integer.valueOf(tmpStr);
    if (integer == null)
      return; 
    int payload = integer.intValue();
    if (payload < 96 || payload > 127)
      return; 
    c = 0;
    for (; dpStr.length() > 0 && dpStr.charAt(c) == ' '; c++);
    if (c > 0)
      dpStr = dpStr.substring(c); 
    if (dpStr.length() == 0)
      return; 
    c = 0;
    for (; dpStr.length() > 0 && dpStr.charAt(c) != '/'; c++);
    if (c > 0) {
      tmpStr = dpStr.substring(0, c);
    } else {
      tmpStr = dpStr;
    } 
    if (tmpStr.length() == 0)
      return; 
    tmpStr = tmpStr.toLowerCase() + "/rtp";
    if ("video".equalsIgnoreCase(typeStr)) {
      mgr.addFormat((Format)new VideoFormat(tmpStr), payload);
      Log.comment("Add RTP dynamic payload for video: " + payload + " : " + tmpStr);
    } 
    if ("audio".equalsIgnoreCase(typeStr)) {
      mgr.addFormat((Format)new AudioFormat(tmpStr), payload);
      Log.comment("Add RTP dynamic payload for audio: " + payload + " : " + tmpStr);
    } 
  }
  
  public int getStatusCode() {
    int code = -1;
    try {
      ResponseMessage responseMsg = (ResponseMessage)this.message.getParameter();
      code = responseMsg.getResponse().getStatusLine().getCode();
    } catch (Exception e) {}
    return code;
  }
  
  private String getStatusText(int code) {
    return StatusCode.getStatusText(code);
  }
  
  private void setDuration() {
    this.duration = 0L;
    ResponseMessage msg = (ResponseMessage)this.message.getParameter();
    double start_time = 0.0D;
    double end_time = 0.0D;
    SdpParser sdp = (msg.getResponse()).sdp;
    if (sdp != null) {
      MediaAttribute attribute = sdp.getSessionAttribute("range");
      if (attribute != null) {
        String value = attribute.getValue();
        if (value.startsWith("npt")) {
          int start = value.indexOf('=') + 1;
          int end = value.indexOf('-');
          String startTime = value.substring(start, end).trim();
          String endTime = value.substring(end + 1).trim();
          end_time = (new Double(endTime)).doubleValue();
          this.duration = (long)(end_time * 1.0E9D);
        } 
      } 
    } 
  }
  
  private int getNumTracks() {
    int numTracks = 0;
    ResponseMessage msg = (ResponseMessage)this.message.getParameter();
    SdpParser sdp = (msg.getResponse()).sdp;
    if (sdp != null)
      numTracks = sdp.getMediaDescriptions().size(); 
    return numTracks;
  }
  
  private MediaDescription getMediaDescription(String mediaName) {
    MediaDescription description = null;
    try {
      ResponseMessage msg = (ResponseMessage)this.message.getParameter();
      SdpParser sdp = (msg.getResponse()).sdp;
      description = sdp.getMediaDescription(mediaName);
    } catch (Exception e) {}
    return description;
  }
  
  private String getCurMediaType(int i) {
    String type = null;
    try {
      ResponseMessage msg = (ResponseMessage)this.message.getParameter();
      SdpParser sdp = (msg.getResponse()).sdp;
      MediaDescription md = sdp.getMediaDescriptions().elementAt(i);
      type = md.name;
    } catch (Exception e) {}
    return type;
  }
  
  public static String getMediaAttribute(MediaDescription md, String attribute) {
    String mediaAttribute = "";
    if (md != null) {
      MediaAttribute ma = md.getMediaAttribute("control");
      if (ma != null)
        mediaAttribute = ma.getValue(); 
    } 
    return mediaAttribute;
  }
  
  private String getMediaAttributeValue(int i, String attribute) {
    String value = null;
    try {
      ResponseMessage msg = (ResponseMessage)this.message.getParameter();
      SdpParser sdp = (msg.getResponse()).sdp;
      MediaDescription md = sdp.getMediaDescriptions().elementAt(i);
      MediaAttribute ma = md.getMediaAttribute(attribute);
      value = ma.getValue();
    } catch (Exception e) {}
    return value;
  }
  
  private String getTrackID(String mediaName) {
    String trackId = null;
    try {
      ResponseMessage msg = (ResponseMessage)this.message.getParameter();
      SdpParser sdp = (msg.getResponse()).sdp;
      MediaDescription description = sdp.getMediaDescription(mediaName);
      MediaAttribute attribute = description.getMediaAttribute("control");
      trackId = attribute.getValue();
    } catch (Exception e) {}
    return trackId;
  }
  
  private String getContentBase() {
    String contentBase = "";
    try {
      ResponseMessage responseMsg = (ResponseMessage)this.message.getParameter();
      Header header = responseMsg.getResponse().getHeader(9);
      ContentBaseHeader cbh = (ContentBaseHeader)header.parameter;
      contentBase = cbh.getContentBase();
    } catch (Exception e) {}
    return contentBase;
  }
  
  private void sendMessage(String message) {
    this.responseReceived = false;
    boolean success = this.rtspManager.sendMessage(this.connectionId, message);
    if (!success) {
      String ipAddress = getServerIpAddress();
      this.connectionId = this.rtspManager.createConnection(ipAddress, this.rtspUrl.getPort());
      this.rtspManager.sendMessage(this.connectionId, message);
    } 
  }
  
  public RtspUtil(ReceiveStreamListener parent) {
    this.responseSync = new Object();
    this.parent = parent;
    this.listeners = new Vector();
    this.rtspManager = new RtspManager(false);
    this.sequenceNumber = (long)(Math.random() * 1000.0D);
    this.userAgent = "User-Agent: JMF RTSP Player " + BasicPlayer.VERSION;
    this.rtspManager.addListener(this);
  }
  
  private synchronized boolean waitForResponse(int time) {
    boolean timeout = false;
    try {
      synchronized (this.responseSync) {
        if (!this.responseReceived)
          this.responseSync.wait(time); 
        if (this.responseReceived) {
          this.sequenceNumber++;
        } else {
          timeout = true;
        } 
      } 
    } catch (InterruptedException e) {
      e.printStackTrace();
    } 
    return timeout;
  }
  
  private void processRtspRequest(int connectionId, Message message) {
    if (message.getType() == 4) {
      OptionsMessage msg = (OptionsMessage)message.getParameter();
      sendResponse(connectionId, msg.getRequest());
    } 
  }
  
  private void processRtspResponse(int connectionId, Message message) {
    this.message = message;
    this.responseReceived = true;
    synchronized (this.responseSync) {
      this.responseSync.notify();
    } 
  }
  
  private void sendResponse(int connectionId, Request msg) {
    String type = null;
    Header header = msg.getHeader(2);
    if (header != null) {
      CSeqHeader cSeqHeader = (CSeqHeader)header.parameter;
      String message = "RTSP/1.0 200 OK\r\nCSeq: " + cSeqHeader.getSequenceNumber() + "\r\n\r\n";
      sendMessage(message);
    } 
  }
  
  private void sendStatusMessage(int code, String message) {
    for (int i = 0; i < this.listeners.size(); i++)
      ((RtspAppListener)this.listeners.elementAt(i)).postStatusMessage(code, message); 
  }
  
  public void addListener(RtspAppListener listener) {
    this.listeners.addElement(listener);
  }
  
  public void removeListener(RtspAppListener listener) {
    this.listeners.removeElement(listener);
  }
  
  public int getNumberOfTracks() {
    return this.numberOfTracks;
  }
  
  public int[] getServerPorts() {
    return this.server_ports;
  }
  
  public void rtspMessageIndication(int connectionId, Message message) {
    if (message.getType() == 12) {
      processRtspResponse(connectionId, message);
    } else {
      processRtspRequest(connectionId, message);
    } 
  }
  
  public String getServerIpAddress() {
    String ipAddress = null;
    try {
      if (this.rtspUrl == null)
        this.rtspUrl = new RtspUrl(this.url); 
      String host = this.rtspUrl.getHost();
      if (host != null)
        ipAddress = InetAddress.getByName(host).getHostAddress(); 
    } catch (MalformedURLException e) {
    
    } catch (UnknownHostException e) {}
    return ipAddress;
  }
  
  public void rtspConnectionTerminated(int connectionId) {}
  
  public String getProcessError() {
    return this.processError;
  }
  
  public void setProcessError(String error) {
    this.processError = error;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\content\rtsp\RtspUtil.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */