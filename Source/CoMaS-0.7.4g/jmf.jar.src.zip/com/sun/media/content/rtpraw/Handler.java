package com.sun.media.content.rtpraw;

import com.sun.media.content.rtp.Handler;

public class Handler extends Handler {}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\content\rtpraw\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */