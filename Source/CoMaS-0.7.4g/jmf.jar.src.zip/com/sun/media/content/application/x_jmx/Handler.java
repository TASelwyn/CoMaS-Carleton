/*     */ package com.sun.media.content.application.x_jmx;
/*     */ 
/*     */ import com.sun.media.BasicController;
/*     */ import com.sun.media.BasicPlayer;
/*     */ import com.sun.media.Log;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Panel;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ import javax.media.Controller;
/*     */ import javax.media.ControllerEvent;
/*     */ import javax.media.ControllerListener;
/*     */ import javax.media.IncompatibleSourceException;
/*     */ import javax.media.IncompatibleTimeBaseException;
/*     */ import javax.media.Manager;
/*     */ import javax.media.MediaLocator;
/*     */ import javax.media.Player;
/*     */ import javax.media.TimeBase;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PullDataSource;
/*     */ import javax.media.protocol.PullSourceStream;
/*     */ import javax.media.renderer.VisualContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Handler
/*     */   extends BasicPlayer
/*     */ {
/*  41 */   Player[] players = null;
/*  42 */   Player master = null;
/*  43 */   boolean[] realized = null;
/*  44 */   Vector locators = new Vector();
/*  45 */   ControllerListener listener = new PlayerListener(this, this);
/*     */   
/*     */   boolean playersRealized = false;
/*  48 */   Object realizedSync = new Object();
/*     */   
/*     */   private boolean closed = false;
/*     */   
/*     */   private boolean audioEnabled = false;
/*     */   private boolean videoEnabled = false;
/*     */   String sessionError;
/*     */   private Container container;
/*     */   
/*     */   public Handler() {
/*  58 */     this.sessionError = "Cannot create a Player for: ";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 272 */     this.container = null; this.framePositioning = true;
/*     */   } protected boolean doRealize() { super.doRealize(); MediaLocator ml = null; try { this.players = new Player[this.locators.size()]; this.realized = new boolean[this.locators.size()]; for (int i = 0; i < this.locators.size(); i++) { ml = this.locators.elementAt(i); this.players[i] = Manager.createPlayer(ml); this.players[i].addControllerListener(this.listener); this.realized[i] = false; this.players[i].realize(); }  } catch (Exception e) { Log.error(this.sessionError + ml); ((BasicController)this).processError = this.sessionError + ml; return false; }  try { synchronized (this.realizedSync) { while (!this.playersRealized && !isInterrupted() && !this.closed) this.realizedSync.wait();  }  } catch (Exception e) {} if (this.closed || isInterrupted()) { resetInterrupt(); ((BasicController)this).processError = "Realize interrupted"; return false; }  try { this.master = this.players[0]; for (int i = 1; i < this.players.length; i++) this.master.addController((Controller)this.players[i]);  } catch (IncompatibleTimeBaseException e) { ((BasicController)this).processError = "AddController failed"; return false; }  manageController((Controller)this.master); return true; } protected void completeRealize() { ((BasicController)this).state = 300; super.completeRealize(); } protected void doStart() { super.doStart(); } protected void doStop() { super.doStop(); } protected void doDeallocate() { synchronized (this.realizedSync) { this.realizedSync.notify(); }  }
/*     */   protected void doClose() { this.closed = true; synchronized (this.realizedSync) { this.realizedSync.notify(); }  stop(); super.doClose(); }
/* 275 */   public Component getVisualComponent() { Vector visuals = new Vector(1);
/*     */     
/* 277 */     for (int i = 0; i < this.players.length; i++) {
/* 278 */       Component comp = this.players[i].getVisualComponent();
/*     */       
/* 280 */       if (comp != null) {
/* 281 */         visuals.addElement(comp);
/*     */       }
/*     */     } 
/*     */     
/* 285 */     if (visuals.size() == 0)
/* 286 */       return null; 
/* 287 */     if (visuals.size() == 1) {
/* 288 */       return visuals.elementAt(0);
/*     */     }
/* 290 */     return createVisualContainer(visuals); }
/*     */   protected TimeBase getMasterTimeBase() { return this.master.getTimeBase(); }
/*     */   protected boolean audioEnabled() {
/*     */     return this.audioEnabled;
/*     */   } protected boolean videoEnabled() {
/*     */     return this.videoEnabled;
/* 296 */   } protected Component createVisualContainer(Vector visuals) { Boolean hint = (Boolean)Manager.getHint(3);
/*     */     
/* 298 */     if (this.container == null) {
/* 299 */       if (hint == null || !hint.booleanValue()) {
/* 300 */         this.container = new HeavyPanel(this, visuals);
/*     */       } else {
/* 302 */         this.container = new LightPanel(this, visuals);
/*     */       } 
/*     */       
/* 305 */       this.container.setLayout(new FlowLayout());
/* 306 */       this.container.setBackground(Color.black);
/*     */       
/* 308 */       for (int i = 0; i < visuals.size(); i++) {
/* 309 */         Component c = visuals.elementAt(i);
/* 310 */         this.container.add(c);
/* 311 */         c.setSize(c.getPreferredSize());
/*     */       } 
/*     */     } 
/*     */     
/* 315 */     return this.container; }
/*     */   private void sendMyEvent(ControllerEvent e) { sendEvent(e); } public void setSource(DataSource source) throws IOException, IncompatibleSourceException { String content; super.setSource(source); if (!(source instanceof PullDataSource)) throw new IncompatibleSourceException();  PullSourceStream[] pss = ((PullDataSource)source).getStreams(); if (pss.length != 1) throw new IncompatibleSourceException();  source.start(); int len = (int)pss[0].getContentLength(); if (len == -1L) throw new IncompatibleSourceException();  byte[] barray = new byte[len]; try { len = pss[0].read(barray, 0, len); content = new String(barray); } catch (Exception e) { throw new IncompatibleSourceException(); }  int start = 0; int size = content.length(); String relPath = null; char ch = content.charAt(start); while (start < size) { start++; while ((ch == ' ' || ch == '\n') && start < size) ch = content.charAt(start);  if (start >= size) break;  int idx = start; idx++; while (idx < size) { ch = content.charAt(idx); if (ch == '\n') break;  }  String str = content.substring(start, idx); if (str.indexOf(':') == -1) { if (relPath == null) { MediaLocator loc = source.getLocator(); if (loc == null) throw new IncompatibleSourceException();  relPath = loc.toString(); int i = relPath.lastIndexOf('/'); if (i < 0)
/*     */             i = relPath.lastIndexOf(File.separator);  relPath = relPath.substring(0, i + 1); }  str = relPath + str; }  this.locators.addElement(new MediaLocator(str)); start = idx; }  if (this.locators.size() < 1)
/*     */       throw new IncompatibleSourceException();  } private void invalidateComp() { this.controlComp = null; this.controls = null; } class HeavyPanel extends Panel implements VisualContainer
/*     */   {
/* 320 */     private final Handler this$0; public HeavyPanel(Handler this$0, Vector visuals) { this.this$0 = this$0; }
/*     */      }
/*     */   
/*     */   class LightPanel extends Container implements VisualContainer { private final Handler this$0;
/*     */     
/*     */     public LightPanel(Handler this$0, Vector visuals) {
/* 326 */       this.this$0 = this$0;
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateStats() {
/* 332 */     for (int i = 0; i < this.players.length; i++) {
/* 333 */       if (this.players[i] != null)
/* 334 */         ((BasicPlayer)this.players[i]).updateStats(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   class PlayerListener implements ControllerListener {
/*     */     Handler handler;
/*     */     private final Handler this$0;
/*     */     
/*     */     public PlayerListener(Handler this$0, Handler handler) {
/* 343 */       this.this$0 = this$0;
/* 344 */       this.handler = handler;
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void controllerUpdate(ControllerEvent ce) {
/* 349 */       Player p = (Player)ce.getSourceController();
/*     */ 
/*     */       
/* 352 */       if (p == null)
/*     */         return; 
/*     */       int idx;
/* 355 */       for (idx = 0; idx < this.this$0.players.length && 
/* 356 */         this.this$0.players[idx] != p; idx++);
/*     */ 
/*     */ 
/*     */       
/* 360 */       if (idx >= this.this$0.players.length) {
/*     */         
/* 362 */         System.err.println("Unknown player: " + p);
/*     */         
/*     */         return;
/*     */       } 
/* 366 */       if (ce instanceof javax.media.RealizeCompleteEvent) {
/*     */         
/* 368 */         this.this$0.realized[idx] = true;
/*     */ 
/*     */         
/* 371 */         for (int i = 0; i < this.this$0.realized.length; i++) {
/* 372 */           if (!this.this$0.realized[i]) {
/*     */             return;
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/* 378 */         synchronized (this.this$0.realizedSync) {
/* 379 */           this.this$0.playersRealized = true;
/* 380 */           this.this$0.realizedSync.notifyAll();
/*     */         } 
/*     */       } 
/*     */       
/* 384 */       if (ce instanceof javax.media.ControllerErrorEvent) {
/* 385 */         this.this$0.players[idx].removeControllerListener(this);
/* 386 */         Log.error("Meta Handler internal error: " + ce);
/* 387 */         this.this$0.players[idx] = null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\content\application\x_jmx\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */