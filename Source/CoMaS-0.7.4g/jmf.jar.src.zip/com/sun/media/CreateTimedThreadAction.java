package com.sun.media;

import java.lang.reflect.Constructor;
import java.security.PrivilegedAction;

public class CreateTimedThreadAction implements PrivilegedAction {
  private Class objclass;
  
  private Class baseClass;
  
  private Object arg1;
  
  private long nanoseconds;
  
  static Constructor cons;
  
  static {
    try {
      cons = CreateTimedThreadAction.class.getConstructor(new Class[] { Class.class, Class.class, Object.class, long.class });
    } catch (Throwable e) {}
  }
  
  public CreateTimedThreadAction(Class objclass, Class baseClass, Object arg1, long nanoseconds) {
    try {
      this.objclass = objclass;
      this.baseClass = baseClass;
      this.arg1 = arg1;
      this.nanoseconds = nanoseconds;
    } catch (Throwable e) {}
  }
  
  public Object run() {
    try {
      Constructor cons = this.objclass.getConstructor(new Class[] { this.baseClass, long.class });
      Object object = cons.newInstance(new Object[] { this.arg1, new Long(this.nanoseconds) });
      return object;
    } catch (Throwable e) {
      return null;
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\CreateTimedThreadAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */