/*     */ package com.sun.media.format;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AviVideoFormat
/*     */   extends VideoFormat
/*     */ {
/*  20 */   protected int planes = -1;
/*  21 */   protected int bitsPerPixel = -1;
/*  22 */   protected int imageSize = -1;
/*  23 */   protected int xPelsPerMeter = -1;
/*  24 */   protected int yPelsPerMeter = -1;
/*  25 */   protected int clrUsed = -1;
/*  26 */   protected int clrImportant = -1;
/*     */   
/*  28 */   protected byte[] codecSpecificHeader = null;
/*     */   
/*     */   public AviVideoFormat(String encoding) {
/*  31 */     super(encoding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AviVideoFormat(String encoding, Dimension size, int maxDataLength, Class dataType, float frameRate, int planes, int bitsPerPixel, int imageSize, int xPelsPerMeter, int yPelsPerMeter, int clrUsed, int clrImportant, byte[] codecHeader) {
/*  39 */     super(encoding, size, maxDataLength, dataType, frameRate);
/*     */     
/*  41 */     this.planes = planes;
/*  42 */     this.bitsPerPixel = bitsPerPixel;
/*  43 */     this.imageSize = imageSize;
/*  44 */     this.xPelsPerMeter = xPelsPerMeter;
/*  45 */     this.yPelsPerMeter = yPelsPerMeter;
/*  46 */     this.clrUsed = clrUsed;
/*  47 */     this.clrImportant = clrImportant;
/*  48 */     this.codecSpecificHeader = codecHeader;
/*     */   }
/*     */   
/*     */   public int getPlanes() {
/*  52 */     return this.planes;
/*     */   }
/*     */   
/*     */   public int getBitsPerPixel() {
/*  56 */     return this.bitsPerPixel;
/*     */   }
/*     */   
/*     */   public int getImageSize() {
/*  60 */     return this.imageSize;
/*     */   }
/*     */   
/*     */   public int getXPelsPerMeter() {
/*  64 */     return this.xPelsPerMeter;
/*     */   }
/*     */   
/*     */   public int getYPelsPerMeter() {
/*  68 */     return this.yPelsPerMeter;
/*     */   }
/*     */   
/*     */   public int getClrUsed() {
/*  72 */     return this.clrUsed;
/*     */   }
/*     */   
/*     */   public int getClrImportant() {
/*  76 */     return this.clrImportant;
/*     */   }
/*     */   
/*     */   public byte[] getCodecSpecificHeader() {
/*  80 */     return this.codecSpecificHeader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/*  87 */     AviVideoFormat f = new AviVideoFormat(((Format)this).encoding);
/*  88 */     f.copy((Format)this);
/*  89 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void copy(Format f) {
/*  96 */     super.copy(f);
/*  97 */     if (f instanceof AviVideoFormat) {
/*  98 */       AviVideoFormat other = (AviVideoFormat)f;
/*  99 */       this.planes = other.planes;
/* 100 */       this.bitsPerPixel = other.bitsPerPixel;
/* 101 */       this.imageSize = other.imageSize;
/* 102 */       this.xPelsPerMeter = other.xPelsPerMeter;
/* 103 */       this.yPelsPerMeter = other.yPelsPerMeter;
/* 104 */       this.clrUsed = other.clrUsed;
/* 105 */       this.clrImportant = other.clrImportant;
/* 106 */       this.codecSpecificHeader = other.codecSpecificHeader;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object format) {
/* 114 */     if (format instanceof AviVideoFormat) {
/* 115 */       AviVideoFormat other = (AviVideoFormat)format;
/*     */       
/* 117 */       boolean result = (super.equals(format) && this.planes == other.planes && this.bitsPerPixel == other.bitsPerPixel && this.imageSize == other.imageSize && this.xPelsPerMeter == other.xPelsPerMeter && this.yPelsPerMeter == other.yPelsPerMeter && this.clrUsed == other.clrUsed && this.clrImportant == other.clrImportant);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 125 */       if (!result) {
/* 126 */         return false;
/*     */       }
/* 128 */       if (this.codecSpecificHeader == other.codecSpecificHeader)
/* 129 */         return true; 
/* 130 */       if (this.codecSpecificHeader == null || other.codecSpecificHeader == null)
/*     */       {
/* 132 */         return false; } 
/* 133 */       if (this.codecSpecificHeader.length != other.codecSpecificHeader.length)
/* 134 */         return false; 
/* 135 */       for (int i = 0; i < this.codecSpecificHeader.length; i++) {
/* 136 */         if (this.codecSpecificHeader[i] != other.codecSpecificHeader[i])
/* 137 */           return false; 
/* 138 */       }  return true;
/*     */     } 
/*     */     
/* 141 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(Format format) {
/* 156 */     if (!super.matches(format))
/* 157 */       return false; 
/* 158 */     if (!(format instanceof AviVideoFormat)) {
/* 159 */       return true;
/*     */     }
/* 161 */     AviVideoFormat other = (AviVideoFormat)format;
/*     */     
/* 163 */     boolean returnVal = ((this.planes == -1 || other.planes == -1 || this.planes == other.planes) && (this.bitsPerPixel == -1 || other.bitsPerPixel == -1 || this.bitsPerPixel == other.bitsPerPixel) && (this.imageSize == -1 || other.imageSize == -1 || this.imageSize == other.imageSize) && (this.xPelsPerMeter == -1 || other.xPelsPerMeter == -1 || this.xPelsPerMeter == other.xPelsPerMeter) && (this.yPelsPerMeter == -1 || other.yPelsPerMeter == -1 || this.yPelsPerMeter == other.yPelsPerMeter) && (this.clrUsed == -1 || other.clrUsed == -1 || this.clrUsed == other.clrUsed) && (this.clrImportant == -1 || other.clrImportant == -1 || this.clrImportant == other.clrImportant) && (this.codecSpecificHeader == null || other.codecSpecificHeader == null || this.codecSpecificHeader == other.codecSpecificHeader || this.codecSpecificHeader.equals(this.codecSpecificHeader)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 183 */     return returnVal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format intersects(Format format) {
/*     */     Format fmt;
/* 197 */     if ((fmt = super.intersects(format)) == null)
/* 198 */       return null; 
/* 199 */     if (!(format instanceof AviVideoFormat))
/* 200 */       return fmt; 
/* 201 */     AviVideoFormat other = (AviVideoFormat)format;
/* 202 */     AviVideoFormat res = (AviVideoFormat)fmt;
/* 203 */     res.planes = (this.planes != -1) ? this.planes : other.planes;
/*     */     
/* 205 */     res.bitsPerPixel = (this.bitsPerPixel != -1) ? this.bitsPerPixel : other.bitsPerPixel;
/*     */     
/* 207 */     res.imageSize = (this.imageSize != -1) ? this.imageSize : other.imageSize;
/*     */     
/* 209 */     res.xPelsPerMeter = (this.xPelsPerMeter != -1) ? this.xPelsPerMeter : other.xPelsPerMeter;
/*     */     
/* 211 */     res.yPelsPerMeter = (this.yPelsPerMeter != -1) ? this.yPelsPerMeter : other.yPelsPerMeter;
/*     */     
/* 213 */     res.clrUsed = (this.clrUsed != -1) ? this.clrUsed : other.clrUsed;
/*     */     
/* 215 */     res.clrImportant = (this.clrImportant != -1) ? this.clrImportant : other.clrImportant;
/*     */     
/* 217 */     res.codecSpecificHeader = (this.codecSpecificHeader != null) ? this.codecSpecificHeader : other.codecSpecificHeader;
/*     */     
/* 219 */     return (Format)res;
/*     */   }
/*     */   
/*     */   public Format relax() {
/*     */     AviVideoFormat fmt;
/* 224 */     if ((fmt = (AviVideoFormat)super.relax()) == null) {
/* 225 */       return null;
/*     */     }
/* 227 */     fmt.imageSize = -1;
/* 228 */     return (Format)fmt;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 232 */     String s = super.toString() + " " + ((this.codecSpecificHeader != null) ? this.codecSpecificHeader.length : 0) + " extra bytes";
/* 233 */     return s;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\format\AviVideoFormat.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */