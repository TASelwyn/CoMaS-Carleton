/*     */ package com.sun.media.format;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WavAudioFormat
/*     */   extends AudioFormat
/*     */ {
/*     */   public static final int WAVE_FORMAT_PCM = 1;
/*     */   public static final int WAVE_FORMAT_ADPCM = 2;
/*     */   public static final int WAVE_FORMAT_ALAW = 6;
/*     */   public static final int WAVE_FORMAT_MULAW = 7;
/*     */   public static final int WAVE_FORMAT_OKI_ADPCM = 16;
/*     */   public static final int WAVE_FORMAT_DIGISTD = 21;
/*     */   public static final int WAVE_FORMAT_DIGIFIX = 22;
/*     */   public static final int WAVE_FORMAT_GSM610 = 49;
/*     */   public static final int WAVE_IBM_FORMAT_MULAW = 257;
/*     */   public static final int WAVE_IBM_FORMAT_ALAW = 258;
/*     */   public static final int WAVE_IBM_FORMAT_ADPCM = 259;
/*     */   public static final int WAVE_FORMAT_DVI_ADPCM = 17;
/*     */   public static final int WAVE_FORMAT_SX7383 = 7175;
/*     */   public static final int WAVE_FORMAT_DSPGROUP_TRUESPEECH = 34;
/*     */   public static final int WAVE_FORMAT_MSNAUDIO = 50;
/*     */   public static final int WAVE_FORMAT_MSG723 = 66;
/*     */   public static final int WAVE_FORMAT_MPEG_LAYER3 = 85;
/*     */   public static final int WAVE_FORMAT_VOXWARE_AC8 = 112;
/*     */   public static final int WAVE_FORMAT_VOXWARE_AC10 = 113;
/*     */   public static final int WAVE_FORMAT_VOXWARE_AC16 = 114;
/*     */   public static final int WAVE_FORMAT_VOXWARE_AC20 = 115;
/*     */   public static final int WAVE_FORMAT_VOXWARE_METAVOICE = 116;
/*     */   public static final int WAVE_FORMAT_VOXWARE_METASOUND = 117;
/*     */   public static final int WAVE_FORMAT_VOXWARE_RT29H = 118;
/*     */   public static final int WAVE_FORMAT_VOXWARE_VR12 = 119;
/*     */   public static final int WAVE_FORMAT_VOXWARE_VR18 = 120;
/*     */   public static final int WAVE_FORMAT_VOXWARE_TQ40 = 121;
/*     */   public static final int WAVE_FORMAT_VOXWARE_TQ60 = 129;
/*     */   public static final int WAVE_FORMAT_MSRT24 = 130;
/*  45 */   protected byte[] codecSpecificHeader = null;
/*  46 */   private int averageBytesPerSecond = -1;
/*     */ 
/*     */   
/*  49 */   public static final Hashtable formatMapper = new Hashtable();
/*  50 */   public static final Hashtable reverseFormatMapper = new Hashtable();
/*     */   static {
/*  52 */     formatMapper.put(new Integer(1), "LINEAR");
/*  53 */     formatMapper.put(new Integer(2), "msadpcm");
/*     */     
/*  55 */     formatMapper.put(new Integer(17), "ima4/ms");
/*  56 */     formatMapper.put(new Integer(6), "alaw");
/*  57 */     formatMapper.put(new Integer(7), "ULAW");
/*  58 */     formatMapper.put(new Integer(49), "gsm/ms");
/*     */     
/*  60 */     formatMapper.put(new Integer(34), "truespeech");
/*     */ 
/*     */     
/*  63 */     formatMapper.put(new Integer(50), "msnaudio");
/*     */ 
/*     */     
/*  66 */     formatMapper.put(new Integer(112), "voxwareac8");
/*     */ 
/*     */     
/*  69 */     formatMapper.put(new Integer(113), "voxwareac10");
/*     */ 
/*     */     
/*  72 */     formatMapper.put(new Integer(114), "voxwareac16");
/*     */ 
/*     */     
/*  75 */     formatMapper.put(new Integer(115), "voxwareac20");
/*     */ 
/*     */     
/*  78 */     formatMapper.put(new Integer(116), "voxwaremetavoice");
/*     */ 
/*     */     
/*  81 */     formatMapper.put(new Integer(117), "voxwaremetasound");
/*     */ 
/*     */ 
/*     */     
/*  85 */     formatMapper.put(new Integer(118), "voxwarert29h");
/*     */ 
/*     */     
/*  88 */     formatMapper.put(new Integer(119), "voxwarevr12");
/*     */ 
/*     */     
/*  91 */     formatMapper.put(new Integer(120), "voxwarevr18");
/*     */ 
/*     */     
/*  94 */     formatMapper.put(new Integer(121), "voxwaretq40");
/*     */ 
/*     */     
/*  97 */     formatMapper.put(new Integer(129), "voxwaretq60");
/*     */ 
/*     */ 
/*     */     
/* 101 */     formatMapper.put(new Integer(85), "mpeglayer3");
/*     */ 
/*     */     
/* 104 */     formatMapper.put(new Integer(130), "msrt24");
/*     */ 
/*     */ 
/*     */     
/* 108 */     reverseFormatMapper.put("LINEAR".toLowerCase(), new Integer(1));
/* 109 */     reverseFormatMapper.put("msadpcm".toLowerCase(), new Integer(2));
/* 110 */     reverseFormatMapper.put("ima4/ms".toLowerCase(), new Integer(17));
/* 111 */     reverseFormatMapper.put("alaw".toLowerCase(), new Integer(6));
/* 112 */     reverseFormatMapper.put("ULAW".toLowerCase(), new Integer(7));
/* 113 */     reverseFormatMapper.put("gsm/ms".toLowerCase(), new Integer(49));
/* 114 */     reverseFormatMapper.put("truespeech".toLowerCase(), new Integer(34));
/* 115 */     reverseFormatMapper.put("msnaudio".toLowerCase(), new Integer(50));
/* 116 */     reverseFormatMapper.put("voxwareac8".toLowerCase(), new Integer(112));
/* 117 */     reverseFormatMapper.put("voxwareac10".toLowerCase(), new Integer(113));
/* 118 */     reverseFormatMapper.put("voxwareac16".toLowerCase(), new Integer(114));
/* 119 */     reverseFormatMapper.put("voxwareac20".toLowerCase(), new Integer(115));
/* 120 */     reverseFormatMapper.put("voxwaremetavoice".toLowerCase(), new Integer(116));
/* 121 */     reverseFormatMapper.put("voxwaremetasound".toLowerCase(), new Integer(117));
/* 122 */     reverseFormatMapper.put("voxwarert29h".toLowerCase(), new Integer(118));
/* 123 */     reverseFormatMapper.put("voxwarevr12".toLowerCase(), new Integer(119));
/* 124 */     reverseFormatMapper.put("voxwarevr18".toLowerCase(), new Integer(120));
/* 125 */     reverseFormatMapper.put("voxwaretq40".toLowerCase(), new Integer(121));
/* 126 */     reverseFormatMapper.put("voxwaretq60".toLowerCase(), new Integer(129));
/* 127 */     reverseFormatMapper.put("mpeglayer3".toLowerCase(), new Integer(85));
/* 128 */     reverseFormatMapper.put("msrt24".toLowerCase(), new Integer(130));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WavAudioFormat(String encoding) {
/* 134 */     super(encoding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WavAudioFormat(String encoding, double sampleRate, int sampleSizeInBits, int channels, int frameSizeInBits, int averageBytesPerSecond, byte[] codecSpecificHeader) {
/* 141 */     super(encoding, sampleRate, sampleSizeInBits, channels);
/* 142 */     this.codecSpecificHeader = codecSpecificHeader;
/* 143 */     this.averageBytesPerSecond = averageBytesPerSecond;
/* 144 */     this.frameRate = averageBytesPerSecond;
/* 145 */     this.frameSizeInBits = frameSizeInBits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WavAudioFormat(String encoding, double sampleRate, int sampleSizeInBits, int channels, int frameSizeInBits, int averageBytesPerSecond, int endian, int signed, float frameRate, Class dataType, byte[] codecSpecificHeader) {
/* 158 */     super(encoding, sampleRate, sampleSizeInBits, channels, endian, signed, frameSizeInBits, frameRate, dataType);
/*     */     
/* 160 */     this.codecSpecificHeader = codecSpecificHeader;
/* 161 */     this.averageBytesPerSecond = averageBytesPerSecond;
/* 162 */     this.frameRate = averageBytesPerSecond;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAverageBytesPerSecond() {
/* 170 */     return this.averageBytesPerSecond;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getCodecSpecificHeader() {
/* 177 */     return this.codecSpecificHeader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object format) {
/* 184 */     if (format instanceof WavAudioFormat) {
/* 185 */       WavAudioFormat other = (WavAudioFormat)format;
/*     */       
/* 187 */       if (!super.equals(format)) {
/* 188 */         return false;
/*     */       }
/* 190 */       if (this.codecSpecificHeader == null && other.codecSpecificHeader == null) {
/* 191 */         return true;
/*     */       }
/* 193 */       if (this.codecSpecificHeader == null || other.codecSpecificHeader == null) {
/* 194 */         return false;
/*     */       }
/* 196 */       if (this.codecSpecificHeader.length != other.codecSpecificHeader.length) {
/* 197 */         return false;
/*     */       }
/* 199 */       for (int i = 0; i < this.codecSpecificHeader.length; i++) {
/* 200 */         if (this.codecSpecificHeader[i] != other.codecSpecificHeader[i])
/* 201 */           return false; 
/*     */       } 
/* 203 */       return true;
/*     */     } 
/* 205 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(Format format) {
/* 220 */     if (!super.matches(format))
/* 221 */       return false; 
/* 222 */     if (!(format instanceof WavAudioFormat)) {
/* 223 */       return true;
/*     */     }
/* 225 */     WavAudioFormat other = (WavAudioFormat)format;
/*     */     
/* 227 */     if (this.codecSpecificHeader == null || other.codecSpecificHeader == null)
/*     */     {
/* 229 */       return true;
/*     */     }
/* 231 */     if (this.codecSpecificHeader.length != other.codecSpecificHeader.length) {
/* 232 */       return false;
/*     */     }
/* 234 */     for (int i = 0; i < this.codecSpecificHeader.length; i++) {
/* 235 */       if (this.codecSpecificHeader[i] != other.codecSpecificHeader[i])
/* 236 */         return false; 
/*     */     } 
/* 238 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format intersects(Format format) {
/*     */     Format fmt;
/* 252 */     if ((fmt = super.intersects(format)) == null)
/* 253 */       return null; 
/* 254 */     if (!(format instanceof WavAudioFormat))
/* 255 */       return fmt; 
/* 256 */     WavAudioFormat other = (WavAudioFormat)format;
/* 257 */     WavAudioFormat res = (WavAudioFormat)fmt;
/* 258 */     res.codecSpecificHeader = (this.codecSpecificHeader != null) ? this.codecSpecificHeader : other.codecSpecificHeader;
/*     */     
/* 260 */     return (Format)res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 267 */     WavAudioFormat f = new WavAudioFormat(((Format)this).encoding);
/* 268 */     f.copy((Format)this);
/* 269 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void copy(Format f) {
/* 276 */     super.copy(f);
/* 277 */     WavAudioFormat other = (WavAudioFormat)f;
/*     */     
/* 279 */     this.averageBytesPerSecond = other.averageBytesPerSecond;
/* 280 */     this.codecSpecificHeader = other.codecSpecificHeader;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\format\WavAudioFormat.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */