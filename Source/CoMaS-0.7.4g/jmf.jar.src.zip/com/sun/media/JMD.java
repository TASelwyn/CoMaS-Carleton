package com.sun.media;

import javax.media.Buffer;
import javax.media.Control;

public interface JMD extends Control {
  void setVisible(boolean paramBoolean);
  
  void initGraph(BasicModule paramBasicModule);
  
  void moduleIn(BasicModule paramBasicModule, int paramInt, Buffer paramBuffer, boolean paramBoolean);
  
  void moduleOut(BasicModule paramBasicModule, int paramInt, Buffer paramBuffer, boolean paramBoolean);
}
