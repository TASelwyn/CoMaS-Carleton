package com.sun.media;

import javax.media.Buffer;
import javax.media.Control;

public interface JMD extends Control {
  void setVisible(boolean paramBoolean);
  
  void initGraph(BasicModule paramBasicModule);
  
  void moduleIn(BasicModule paramBasicModule, int paramInt, Buffer paramBuffer, boolean paramBoolean);
  
  void moduleOut(BasicModule paramBasicModule, int paramInt, Buffer paramBuffer, boolean paramBoolean);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\JMD.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */