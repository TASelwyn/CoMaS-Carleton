package com.sun.media.processor.rtsp;

import com.sun.media.BasicController;
import com.sun.media.BasicPlayer;
import com.sun.media.BasicProcessor;
import com.sun.media.JMFSecurity;
import com.sun.media.Log;
import com.sun.media.content.rtsp.RtspUtil;
import java.awt.Component;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.util.Vector;
import javax.media.Control;
import javax.media.Controller;
import javax.media.ControllerErrorEvent;
import javax.media.ControllerEvent;
import javax.media.ControllerListener;
import javax.media.Format;
import javax.media.IncompatibleSourceException;
import javax.media.IncompatibleTimeBaseException;
import javax.media.Manager;
import javax.media.MediaLocator;
import javax.media.NotConfiguredError;
import javax.media.NotRealizedError;
import javax.media.Player;
import javax.media.Processor;
import javax.media.SystemTimeBase;
import javax.media.TimeBase;
import javax.media.control.BufferControl;
import javax.media.control.TrackControl;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.DataSource;
import javax.media.rtp.RTPControl;
import javax.media.rtp.RTPManager;
import javax.media.rtp.ReceiveStream;
import javax.media.rtp.ReceiveStreamListener;
import javax.media.rtp.SessionAddress;
import javax.media.rtp.event.NewReceiveStreamEvent;
import javax.media.rtp.event.ReceiveStreamEvent;

public class Handler extends BasicProcessor implements ReceiveStreamListener {
  private final int INITIALIZED = 0;
  
  private final int REALIZED = 1;
  
  private final int PLAYING = 2;
  
  private final int PAUSING = 3;
  
  private DataSource[] data_sources;
  
  Processor processor = null;
  
  Format[] formats = null;
  
  Vector locators = null;
  
  Object dataLock = new Object();
  
  boolean dataReady = false;
  
  private boolean closed = false;
  
  private boolean audioEnabled = false;
  
  private boolean videoEnabled = false;
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] m = new Method[1];
  
  private Class[] cl = new Class[1];
  
  private Object[][] args = new Object[1][0];
  
  private boolean first_pass = true;
  
  RtspUtil rtspUtil;
  
  String sessionError;
  
  public Handler() {
    this.sessionError = "cannot create and initialize the RTP Session.";
    ((BasicPlayer)this).framePositioning = false;
    this.rtspUtil = new RtspUtil(this);
    this.locators = new Vector();
  }
  
  protected synchronized boolean doConfigure() {
    boolean configured = super.doConfigure();
    if (configured)
      configured = initRtspSession(); 
    return configured;
  }
  
  private boolean initRtspSession() {
    boolean realized = false;
    MediaLocator ml = this.locators.elementAt(0);
    this.rtspUtil.setUrl(ml.toString());
    String ipAddress = this.rtspUtil.getServerIpAddress();
    if (ipAddress == null) {
      System.out.println("Invalid server address.");
      realized = false;
    } else {
      this.rtspUtil.setUrl(ml.toString());
      realized = this.rtspUtil.createConnection();
      if (realized) {
        realized = this.rtspUtil.rtspSetup();
        try {
          InetAddress destaddr = InetAddress.getByName(ipAddress);
          int[] server_ports = this.rtspUtil.getServerPorts();
          for (int i = 0; i < this.rtspUtil.getNumberOfTracks(); i++) {
            SessionAddress remoteAddress = new SessionAddress(destaddr, server_ports[i]);
            this.rtspUtil.getRTPManager(i).addTarget(remoteAddress);
            BufferControl bc = (BufferControl)this.rtspUtil.getRTPManager(i).getControl("javax.media.control.BufferControl");
            String mediaType = this.rtspUtil.getMediaType(i);
            if (mediaType.equals("audio")) {
              bc.setBufferLength(250L);
              bc.setMinimumThreshold(125L);
            } else if (mediaType.equals("video")) {
              bc.setBufferLength(1500L);
              bc.setMinimumThreshold(250L);
            } 
          } 
        } catch (Exception e) {
          Log.error(e.getMessage());
          return realized;
        } 
      } 
    } 
    if (realized) {
      ((BasicController)this).state = 1;
      int size = this.rtspUtil.getNumberOfTracks();
      this.data_sources = new DataSource[size];
      this.formats = new Format[size];
      if (!this.rtspUtil.rtspStart()) {
        if (this.first_pass && this.rtspUtil.getStatusCode() == 454) {
          this.first_pass = false;
          return initRtspSession();
        } 
        return false;
      } 
      waitForData();
    } 
    return realized;
  }
  
  private synchronized boolean waitForData() {
    try {
      synchronized (this.dataLock) {
        while (!this.dataReady)
          this.dataLock.wait(); 
      } 
    } catch (InterruptedException e) {
      e.printStackTrace();
    } 
    return this.dataReady;
  }
  
  protected void completeConfigure() {
    ((BasicController)this).state = 180;
    super.completeConfigure();
  }
  
  protected void doFailedConfigure() {
    closeSessions();
    super.doFailedConfigure();
  }
  
  private void closeSessions() {
    RTPManager[] mgrs = this.rtspUtil.getRTPManagers();
    for (int i = 0; i < mgrs.length; i++) {
      if (mgrs[i] != null) {
        mgrs[i].removeTargets("Closing session from the RTP Handler");
        mgrs[i].dispose();
      } 
      mgrs[i] = null;
    } 
  }
  
  protected boolean doRealize() {
    return waitForRealize(this.processor);
  }
  
  protected void completeRealize() {
    ((BasicController)this).state = 300;
    super.completeRealize();
  }
  
  protected void doFailedRealize() {
    closeSessions();
    super.doFailedRealize();
  }
  
  protected void doStart() {
    super.doStart();
    waitForStart((Player)this.processor);
  }
  
  protected void doStop() {
    super.doStop();
    waitForStop((Player)this.processor);
  }
  
  protected void doDeallocate() {
    this.processor.deallocate();
    synchronized (this.dataLock) {
      this.dataLock.notifyAll();
    } 
  }
  
  protected void doClose() {
    this.closed = true;
    synchronized (this.dataLock) {
      this.dataLock.notify();
    } 
    stop();
    this.processor.close();
    closeSessions();
    super.doClose();
  }
  
  public void setTimeBase(TimeBase tb) throws IncompatibleTimeBaseException {}
  
  protected TimeBase getMasterTimeBase() {
    return (TimeBase)new SystemTimeBase();
  }
  
  protected boolean audioEnabled() {
    return this.audioEnabled;
  }
  
  protected boolean videoEnabled() {
    return this.videoEnabled;
  }
  
  private void sendMyEvent(ControllerEvent e) {
    sendEvent(e);
  }
  
  public void update(ReceiveStreamEvent event) {
    RTPManager mgr = (RTPManager)event.getSource();
    if (this.data_sources == null)
      return; 
    RTPManager[] mgrs = this.rtspUtil.getRTPManagers();
    int idx;
    for (idx = 0; idx < mgrs.length && 
      mgrs[idx] != mgr; idx++);
    if (idx >= mgrs.length) {
      System.err.println("Unknown manager: " + mgr);
      return;
    } 
    if (event instanceof javax.media.rtp.event.RemotePayloadChangeEvent) {
      Log.comment("Received an RTP PayloadChangeEvent");
      Log.error("The RTP processor cannot handle mid-stream payload change.\n");
      sendEvent((ControllerEvent)new ControllerErrorEvent((Controller)this, "Cannot handle mid-stream payload change."));
      close();
    } 
    if (event instanceof NewReceiveStreamEvent) {
      if (this.data_sources[idx] != null)
        return; 
      ReceiveStream stream = null;
      try {
        DataSource mixDS;
        stream = ((NewReceiveStreamEvent)event).getReceiveStream();
        this.data_sources[idx] = stream.getDataSource();
        RTPControl ctl = (RTPControl)this.data_sources[idx].getControl("javax.media.rtp.RTPControl");
        if (ctl != null) {
          this.formats[idx] = ctl.getFormat();
          if (this.formats[idx] instanceof javax.media.format.AudioFormat)
            this.audioEnabled = true; 
          if (this.formats[idx] instanceof javax.media.format.VideoFormat)
            this.videoEnabled = true; 
        } 
        for (int i = 0; i < this.data_sources.length; i++) {
          if (this.data_sources[i] == null)
            return; 
        } 
        try {
          mixDS = Manager.createMergingDataSource(this.data_sources);
        } catch (Exception e) {
          System.err.println("Cannot merge data sources.");
          return;
        } 
        try {
          this.processor = Manager.createProcessor(mixDS);
        } catch (Exception e) {
          System.err.println("Cannot create the mix processor.");
          return;
        } 
        if (!waitForConfigure(this.processor))
          return; 
        synchronized (this.dataLock) {
          this.dataReady = true;
          this.dataLock.notifyAll();
        } 
      } catch (Exception e) {
        System.err.println("NewReceiveStreamEvent exception " + e.getMessage());
        return;
      } 
    } 
  }
  
  public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
    super.setSource(source);
    if (source instanceof com.sun.media.protocol.rtsp.DataSource) {
      MediaLocator ml = source.getLocator();
      this.locators.addElement(ml);
    } else {
      throw new IncompatibleSourceException();
    } 
  }
  
  private void invalidateComp() {
    ((BasicPlayer)this).controlComp = null;
    ((BasicPlayer)this).controls = null;
  }
  
  public Component getVisualComponent() {
    super.getVisualComponent();
    return this.processor.getVisualComponent();
  }
  
  public Control[] getControls() {
    return this.processor.getControls();
  }
  
  public void updateStats() {
    if (this.processor != null)
      ((BasicProcessor)this.processor).updateStats(); 
  }
  
  public TrackControl[] getTrackControls() throws NotConfiguredError {
    super.getTrackControls();
    return this.processor.getTrackControls();
  }
  
  public ContentDescriptor[] getSupportedContentDescriptors() throws NotConfiguredError {
    super.getSupportedContentDescriptors();
    return this.processor.getSupportedContentDescriptors();
  }
  
  public ContentDescriptor setContentDescriptor(ContentDescriptor ocd) throws NotConfiguredError {
    super.setContentDescriptor(ocd);
    return this.processor.setContentDescriptor(ocd);
  }
  
  public ContentDescriptor getContentDescriptor() throws NotConfiguredError {
    super.getContentDescriptor();
    return this.processor.getContentDescriptor();
  }
  
  public DataSource getDataOutput() throws NotRealizedError {
    super.getDataOutput();
    return this.processor.getDataOutput();
  }
  
  private boolean waitForConfigure(Processor p) {
    return (new StateWaiter(this)).waitForConfigure(p);
  }
  
  private boolean waitForRealize(Processor p) {
    return (new StateWaiter(this)).waitForRealize(p);
  }
  
  private void waitForStart(Player p) {
    (new StateWaiter(this)).waitForStart(p, true);
  }
  
  private void waitForStop(Player p) {
    (new StateWaiter(this)).waitForStart(p, false);
  }
  
  private void waitForClose(Player p) {
    (new StateWaiter(this)).waitForClose(p);
  }
  
  class StateWaiter implements ControllerListener {
    boolean closeDown;
    
    Object stateLock;
    
    private final Handler this$0;
    
    StateWaiter(Handler this$0) {
      this.this$0 = this$0;
      this.closeDown = false;
      this.stateLock = new Object();
    }
    
    public boolean waitForConfigure(Processor p) {
      p.addControllerListener(this);
      p.configure();
      synchronized (this.stateLock) {
        while (p.getState() != 180 && !this.closeDown) {
          try {
            this.stateLock.wait(1000L);
          } catch (InterruptedException ie) {
            break;
          } 
        } 
      } 
      p.removeControllerListener(this);
      return !this.closeDown;
    }
    
    public boolean waitForRealize(Processor p) {
      p.addControllerListener(this);
      p.realize();
      synchronized (this.stateLock) {
        while (p.getState() != 300 && !this.closeDown) {
          try {
            this.stateLock.wait(1000L);
          } catch (InterruptedException ie) {
            break;
          } 
        } 
      } 
      p.removeControllerListener(this);
      return !this.closeDown;
    }
    
    public void waitForStart(Player p, boolean startOn) {
      p.addControllerListener(this);
      if (startOn) {
        p.start();
      } else {
        p.stop();
      } 
      synchronized (this.stateLock) {
        while (((startOn && p.getState() != 600) || (!startOn && p.getState() == 600)) && !this.closeDown) {
          try {
            this.stateLock.wait(1000L);
          } catch (InterruptedException ie) {
            break;
          } 
        } 
      } 
      p.removeControllerListener(this);
    }
    
    public void waitForClose(Player p) {
      p.addControllerListener(this);
      p.close();
      synchronized (this.stateLock) {
        while (!this.closeDown) {
          try {
            this.stateLock.wait(1000L);
          } catch (InterruptedException ie) {
            break;
          } 
        } 
      } 
      p.removeControllerListener(this);
    }
    
    public void controllerUpdate(ControllerEvent ce) {
      if (ce instanceof javax.media.ControllerClosedEvent || ce instanceof ControllerErrorEvent)
        this.closeDown = true; 
      synchronized (this.stateLock) {
        this.stateLock.notify();
      } 
    }
  }
}
