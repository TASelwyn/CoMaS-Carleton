package com.sun.media.processor.unknown;

import com.sun.media.MediaProcessor;

public class Handler extends MediaProcessor {}
