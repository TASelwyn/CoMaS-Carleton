package com.sun.media;

import javax.media.Controls;
import javax.media.Format;

public interface Module extends Controls {
  String[] getInputConnectorNames();
  
  String[] getOutputConnectorNames();
  
  InputConnector getInputConnector(String paramString);
  
  OutputConnector getOutputConnector(String paramString);
  
  void registerInputConnector(String paramString, InputConnector paramInputConnector);
  
  void registerOutputConnector(String paramString, OutputConnector paramOutputConnector);
  
  void reset();
  
  void connectorPushed(InputConnector paramInputConnector);
  
  String getName();
  
  void setName(String paramString);
  
  void setFormat(Connector paramConnector, Format paramFormat);
  
  void setModuleListener(ModuleListener paramModuleListener);
  
  boolean isInterrupted();
  
  void setJMD(JMD paramJMD);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\Module.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */