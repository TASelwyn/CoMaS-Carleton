/*    */ package com.sun.media;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DisabledSecurity
/*    */   implements JMFSecurity
/*    */ {
/* 16 */   public static JMFSecurity security = new DisabledSecurity();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 29 */     return "jmf-security-disabled";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void requestPermission(Method[] m, Class[] c, Object[][] args, int request) throws SecurityException {
/* 35 */     throw new SecurityException("DisabledSecurity : Cannot request permission");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void requestPermission(Method[] m, Class[] c, Object[][] args, int request, String parameter) throws SecurityException {
/* 42 */     requestPermission(m, c, args, request);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isLinkPermissionEnabled() {
/* 47 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void permissionFailureNotification(int permission) {}
/*    */   
/*    */   public void loadLibrary(String name) throws UnsatisfiedLinkError {
/* 54 */     throw new UnsatisfiedLinkError("Unable to get link privilege to " + name);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\DisabledSecurity.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */