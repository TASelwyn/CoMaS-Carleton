/*     */ package com.sun.media.parser;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Demultiplexer;
/*     */ import javax.media.Format;
/*     */ import javax.media.IncompatibleSourceException;
/*     */ import javax.media.Time;
/*     */ import javax.media.Track;
/*     */ import javax.media.TrackListener;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PullBufferDataSource;
/*     */ import javax.media.protocol.PullBufferStream;
/*     */ import javax.media.protocol.SourceStream;
/*     */ 
/*     */ public class RawPullBufferParser
/*     */   extends RawPullStreamParser
/*     */ {
/*     */   static final String NAME = "Raw pull stream parser";
/*     */   
/*     */   public String getName() {
/*  22 */     return "Raw pull stream parser";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
/*  28 */     if (!(source instanceof PullBufferDataSource)) {
/*  29 */       throw new IncompatibleSourceException("DataSource not supported: " + source);
/*     */     }
/*  31 */     this.streams = (SourceStream[])((PullBufferDataSource)source).getStreams();
/*     */ 
/*     */ 
/*     */     
/*  35 */     if (this.streams == null) {
/*  36 */       throw new IOException("Got a null stream from the DataSource");
/*     */     }
/*     */     
/*  39 */     if (this.streams.length == 0) {
/*  40 */       throw new IOException("Got a empty stream array from the DataSource");
/*     */     }
/*     */     
/*  43 */     if (!supports(this.streams)) {
/*  44 */       throw new IncompatibleSourceException("DataSource not supported: " + source);
/*     */     }
/*  46 */     this.source = source;
/*  47 */     this.streams = this.streams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean supports(SourceStream[] streams) {
/*  57 */     return (streams[0] != null && streams[0] instanceof PullBufferStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() {
/*  68 */     if (this.tracks != null)
/*     */       return; 
/*  70 */     this.tracks = new Track[this.streams.length];
/*  71 */     for (int i = 0; i < this.streams.length; i++) {
/*  72 */       this.tracks[i] = new FrameTrack(this, this, (PullBufferStream)this.streams[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   class FrameTrack
/*     */     implements Track
/*     */   {
/*     */     Demultiplexer parser;
/*     */     
/*     */     PullBufferStream pbs;
/*     */     boolean enabled;
/*     */     Format format;
/*     */     TrackListener listener;
/*     */     Integer stateReq;
/*     */     private final RawPullBufferParser this$0;
/*     */     
/*     */     public FrameTrack(RawPullBufferParser this$0, Demultiplexer parser, PullBufferStream pbs) {
/*  90 */       this.this$0 = this$0; this.enabled = true; this.format = null; this.stateReq = new Integer(0);
/*  91 */       this.pbs = pbs;
/*  92 */       this.format = pbs.getFormat();
/*     */     }
/*     */     
/*     */     public Format getFormat() {
/*  96 */       return this.format;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean t) {
/* 100 */       this.enabled = t;
/*     */     }
/*     */     
/*     */     public boolean isEnabled() {
/* 104 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public Time getDuration() {
/* 108 */       return this.parser.getDuration();
/*     */     }
/*     */     
/*     */     public Time getStartTime() {
/* 112 */       return new Time(0L);
/*     */     }
/*     */     
/*     */     public void setTrackListener(TrackListener l) {
/* 116 */       this.listener = l;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void readFrame(Buffer buffer) {
/* 122 */       if (buffer.getData() == null) {
/* 123 */         buffer.setData(new byte[500]);
/*     */       }
/*     */       try {
/* 126 */         this.pbs.read(buffer);
/*     */       } catch (IOException e) {
/* 128 */         buffer.setDiscard(true);
/*     */       } 
/*     */     }
/*     */     
/*     */     public int mapTimeToFrame(Time t) {
/* 133 */       return -1;
/*     */     }
/*     */     
/*     */     public Time mapFrameToTime(int frameNumber) {
/* 137 */       return new Time(0L);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\parser\RawPullBufferParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */