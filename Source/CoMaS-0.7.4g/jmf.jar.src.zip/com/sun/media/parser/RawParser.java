/*    */ package com.sun.media.parser;
/*    */ 
/*    */ import com.sun.media.BasicPlugIn;
/*    */ import java.io.IOException;
/*    */ import javax.media.Demultiplexer;
/*    */ import javax.media.Duration;
/*    */ import javax.media.IncompatibleSourceException;
/*    */ import javax.media.Time;
/*    */ import javax.media.Track;
/*    */ import javax.media.protocol.ContentDescriptor;
/*    */ import javax.media.protocol.DataSource;
/*    */ import javax.media.protocol.Positionable;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RawParser
/*    */   extends BasicPlugIn
/*    */   implements Demultiplexer
/*    */ {
/*    */   static final String NAME = "Raw parser";
/*    */   protected DataSource source;
/*    */   ContentDescriptor[] supported;
/*    */   
/*    */   public String getName() {
/* 25 */     return "Raw parser";
/*    */   }
/*    */   
/*    */   public RawParser() {
/* 29 */     this.supported = new ContentDescriptor[1];
/* 30 */     this.supported[0] = new ContentDescriptor("raw");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ContentDescriptor[] getSupportedInputContentDescriptors() {
/* 37 */     return this.supported;
/*    */   }
/*    */   
/*    */   public boolean isPositionable() {
/* 41 */     return this.source instanceof Positionable;
/*    */   }
/*    */   
/*    */   public boolean isRandomAccess() {
/* 45 */     return (this.source instanceof Positionable && ((Positionable)this.source).isRandomAccess());
/*    */   }
/*    */ 
/*    */   
/*    */   public Track[] getTracks() {
/* 50 */     return null;
/*    */   }
/*    */   
/*    */   public Time getMediaTime() {
/* 54 */     return Time.TIME_UNKNOWN;
/*    */   }
/*    */   
/*    */   public Time getDuration() {
/* 58 */     return (this.source == null) ? Duration.DURATION_UNKNOWN : this.source.getDuration();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void reset() {}
/*    */ 
/*    */ 
/*    */   
/*    */   public Time setPosition(Time when, int round) {
/* 69 */     if (this.source instanceof Positionable)
/* 70 */       return ((Positionable)this.source).setPosition(when, round); 
/* 71 */     return when;
/*    */   }
/*    */   
/*    */   public Object[] getControls() {
/* 75 */     return this.source.getControls();
/*    */   }
/*    */   
/*    */   public abstract void stop();
/*    */   
/*    */   public abstract void start() throws IOException;
/*    */   
/*    */   public abstract void setSource(DataSource paramDataSource) throws IOException, IncompatibleSourceException;
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\parser\RawParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */