/*     */ package com.sun.media.parser;
/*     */ 
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import java.io.IOException;
/*     */ import javax.media.BadHeaderException;
/*     */ import javax.media.Demultiplexer;
/*     */ import javax.media.Format;
/*     */ import javax.media.IncompatibleSourceException;
/*     */ import javax.media.Time;
/*     */ import javax.media.Track;
/*     */ import javax.media.protocol.CachedStream;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PullDataSource;
/*     */ import javax.media.protocol.PullSourceStream;
/*     */ import javax.media.protocol.Seekable;
/*     */ import javax.media.protocol.SourceStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BasicPullParser
/*     */   extends BasicPlugIn
/*     */   implements Demultiplexer
/*     */ {
/*     */   protected DataSource source;
/*     */   protected SourceStream[] streams;
/*     */   private Format[] outputFormats;
/*  29 */   private byte[] b = new byte[1];
/*  30 */   private byte[] intArray = new byte[4];
/*  31 */   private byte[] shortArray = new byte[2];
/*  32 */   private final int TEMP_BUFFER_LENGTH = 2048;
/*  33 */   private byte[] tempBuffer = new byte[2048];
/*  34 */   private long currentLocation = 0L;
/*     */   protected boolean seekable = false;
/*     */   protected boolean positionable = false;
/*     */   protected CachedStream cacheStream;
/*  38 */   private Object sync = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
/*  44 */     if (!(source instanceof PullDataSource)) {
/*  45 */       throw new IncompatibleSourceException("DataSource not supported: " + source);
/*     */     }
/*  47 */     this.streams = (SourceStream[])((PullDataSource)source).getStreams();
/*     */ 
/*     */ 
/*     */     
/*  51 */     if (this.streams == null) {
/*  52 */       throw new IOException("Got a null stream from the DataSource");
/*     */     }
/*     */     
/*  55 */     if (this.streams.length == 0) {
/*  56 */       throw new IOException("Got a empty stream array from the DataSource");
/*     */     }
/*     */     
/*  59 */     this.source = source;
/*  60 */     this.streams = this.streams;
/*     */     
/*  62 */     this.positionable = this.streams[0] instanceof Seekable;
/*  63 */     this.seekable = (this.positionable && ((Seekable)this.streams[0]).isRandomAccess());
/*     */     
/*  65 */     if (!supports(this.streams)) {
/*  66 */       throw new IncompatibleSourceException("DataSource not supported: " + source);
/*     */     }
/*     */     try {
/*  69 */       this.cacheStream = (CachedStream)this.streams[0];
/*     */     } catch (ClassCastException e) {
/*     */       
/*  72 */       this.cacheStream = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean supports(SourceStream[] streams) {
/*  88 */     return (streams[0] != null && streams[0] instanceof PullSourceStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPositionable() {
/*  95 */     return this.positionable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRandomAccess() {
/* 104 */     return this.seekable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readBytes(PullSourceStream pss, byte[] array, int numBytes) throws IOException {
/* 114 */     return readBytes(pss, array, 0, numBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readBytes(PullSourceStream pss, byte[] array, int offset, int numBytes) throws IOException {
/* 127 */     if (array == null)
/* 128 */       throw new NullPointerException(); 
/* 129 */     if (offset < 0 || offset > array.length || numBytes < 0 || offset + numBytes > array.length || offset + numBytes < 0)
/*     */     {
/* 131 */       throw new IndexOutOfBoundsException(); } 
/* 132 */     if (numBytes == 0) {
/* 133 */       return 0;
/*     */     }
/*     */     
/* 136 */     int remainingLength = numBytes;
/* 137 */     int actualRead = 0;
/*     */     
/* 139 */     remainingLength = numBytes;
/* 140 */     while (remainingLength > 0) {
/*     */       
/* 142 */       actualRead = pss.read(array, offset, remainingLength);
/* 143 */       if (actualRead == -1) {
/* 144 */         if (offset == 0)
/*     */         {
/* 146 */           throw new IOException("BasicPullParser: readBytes(): Reached end of stream while trying to read " + numBytes + " bytes");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 151 */         return offset;
/*     */       } 
/* 153 */       if (actualRead == -2)
/* 154 */         return -2; 
/* 155 */       if (actualRead < 0) {
/* 156 */         throw new IOException("BasicPullParser: readBytes() read returned " + actualRead);
/*     */       }
/* 158 */       remainingLength -= actualRead;
/*     */       
/* 160 */       offset += actualRead;
/* 161 */       synchronized (this.sync) {
/* 162 */         this.currentLocation += actualRead;
/*     */       } 
/*     */     } 
/* 165 */     return numBytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readInt(PullSourceStream pss) throws IOException {
/* 172 */     return readInt(pss, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public int readShort(PullSourceStream pss) throws IOException {
/* 177 */     return readShort(pss, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int readByte(PullSourceStream pss) throws IOException {
/* 183 */     readBytes(pss, this.b, 1);
/* 184 */     return this.b[0];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int readInt(PullSourceStream pss, boolean isBigEndian) throws IOException {
/*     */     int i;
/* 191 */     readBytes(pss, this.intArray, 4);
/* 192 */     if (isBigEndian) {
/* 193 */       i = (this.intArray[0] & 0xFF) << 24 | (this.intArray[1] & 0xFF) << 16 | (this.intArray[2] & 0xFF) << 8 | this.intArray[3] & 0xFF;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 198 */       i = (this.intArray[3] & 0xFF) << 24 | (this.intArray[2] & 0xFF) << 16 | (this.intArray[1] & 0xFF) << 8 | this.intArray[0] & 0xFF;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 203 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int parseIntFromArray(byte[] array, int offset, boolean isBigEndian) throws IOException {
/*     */     int i;
/* 211 */     if (isBigEndian) {
/* 212 */       i = (array[offset + 0] & 0xFF) << 24 | (array[offset + 1] & 0xFF) << 16 | (array[offset + 2] & 0xFF) << 8 | array[offset + 3] & 0xFF;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 217 */       i = (array[offset + 3] & 0xFF) << 24 | (array[offset + 2] & 0xFF) << 16 | (array[offset + 1] & 0xFF) << 8 | array[offset + 0] & 0xFF;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 222 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected short readShort(PullSourceStream pss, boolean isBigEndian) throws IOException {
/*     */     int i;
/* 232 */     readBytes(pss, this.shortArray, 2);
/* 233 */     if (isBigEndian) {
/* 234 */       i = (this.shortArray[0] & 0xFF) << 8 | this.shortArray[1] & 0xFF;
/*     */     } else {
/*     */       
/* 237 */       i = (this.shortArray[1] & 0xFF) << 8 | this.shortArray[0] & 0xFF;
/*     */     } 
/*     */     
/* 240 */     return (short)i;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final short parseShortFromArray(byte[] array, boolean isBigEndian) throws IOException {
/*     */     int i;
/* 246 */     if (array.length < 2) {
/* 247 */       throw new IOException("Unexpected EOF");
/*     */     }
/*     */ 
/*     */     
/* 251 */     if (isBigEndian) {
/* 252 */       i = (array[0] & 0xFF) << 8 | array[1] & 0xFF;
/*     */     } else {
/*     */       
/* 255 */       i = (array[1] & 0xFF) << 8 | array[0] & 0xFF;
/*     */     } 
/*     */     
/* 258 */     return (short)i;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String readString(PullSourceStream pss) throws IOException {
/* 263 */     readBytes(pss, this.intArray, 4);
/* 264 */     return new String(this.intArray);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void skip(PullSourceStream pss, int numBytes) throws IOException {
/* 277 */     if (pss instanceof Seekable && ((Seekable)pss).isRandomAccess()) {
/* 278 */       long current = ((Seekable)pss).tell();
/* 279 */       long newPos = current + numBytes;
/*     */       
/* 281 */       ((Seekable)pss).seek(newPos);
/* 282 */       if (newPos != ((Seekable)pss).tell())
/*     */       {
/*     */         
/* 285 */         throw new IOException("Seek to " + newPos + " failed");
/*     */       }
/* 287 */       synchronized (this.sync) {
/* 288 */         this.currentLocation += numBytes;
/*     */       } 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 296 */     int remaining = numBytes;
/*     */     
/* 298 */     while (remaining > 2048) {
/*     */       
/* 300 */       int bytesRead = readBytes(pss, this.tempBuffer, 2048);
/* 301 */       if (bytesRead != 2048) {
/* 302 */         throw new IOException("BasicPullParser: End of Media reached while trying to skip " + numBytes);
/*     */       }
/* 304 */       remaining -= 2048;
/*     */     } 
/* 306 */     if (remaining > 0) {
/*     */       
/* 308 */       int i = readBytes(pss, this.tempBuffer, remaining);
/* 309 */       if (i != remaining) {
/* 310 */         throw new IOException("BasicPullParser: End of Media reached while trying to skip " + numBytes);
/*     */       }
/*     */     } 
/* 313 */     synchronized (this.sync) {
/* 314 */       this.currentLocation += numBytes;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final long getLocation(PullSourceStream pss) {
/* 320 */     synchronized (this.sync) {
/* 321 */       if (pss instanceof Seekable) {
/* 322 */         return ((Seekable)pss).tell();
/*     */       }
/* 324 */       return this.currentLocation;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract ContentDescriptor[] getSupportedInputContentDescriptors();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 352 */     if (this.source != null) {
/*     */       try {
/* 354 */         this.source.stop();
/* 355 */         this.source.disconnect();
/* 356 */       } catch (IOException e) {}
/*     */ 
/*     */       
/* 359 */       this.source = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() throws IOException {
/* 367 */     if (this.source != null) {
/* 368 */       this.source.start();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 375 */     if (this.source != null)
/*     */       try {
/* 377 */         this.source.stop();
/* 378 */       } catch (IOException e) {} 
/*     */   }
/*     */   
/*     */   public void reset() {}
/*     */   
/*     */   public abstract Time getDuration();
/*     */   
/*     */   public abstract Time getMediaTime();
/*     */   
/*     */   public abstract Time setPosition(Time paramTime, int paramInt);
/*     */   
/*     */   public abstract Track[] getTracks() throws IOException, BadHeaderException;
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\parser\BasicPullParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */