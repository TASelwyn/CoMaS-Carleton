package com.sun.media.parser;

import com.sun.media.Log;
import java.io.IOException;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.Time;
import javax.media.Track;
import javax.media.TrackListener;
import javax.media.protocol.PullSourceStream;
import javax.media.protocol.Seekable;

public class BasicTrack implements Track {
  private Format format;
  
  private boolean enabled = true;
  
  protected Time duration;
  
  private Time startTime;
  
  private int numBuffers;
  
  private int dataSize;
  
  private PullSourceStream stream;
  
  private long minLocation;
  
  private long maxLocation;
  
  private long maxStartLocation;
  
  private BasicPullParser parser;
  
  private long sequenceNumber = 0L;
  
  private TrackListener listener;
  
  private long seekLocation = -1L;
  
  private long mediaSizeAtEOM = -1L;
  
  private boolean warnedUserOfReadPastEOM = false;
  
  public BasicTrack(BasicPullParser parser, Format format, boolean enabled, Time duration, Time startTime, int numBuffers, int dataSize, PullSourceStream stream) {
    this(parser, format, enabled, duration, startTime, numBuffers, dataSize, stream, 0L, Long.MAX_VALUE);
  }
  
  public BasicTrack(BasicPullParser parser, Format format, boolean enabled, Time duration, Time startTime, int numBuffers, int dataSize, PullSourceStream stream, long minLocation, long maxLocation) {
    this.parser = parser;
    this.format = format;
    this.enabled = enabled;
    this.duration = duration;
    this.startTime = startTime;
    this.numBuffers = numBuffers;
    this.dataSize = dataSize;
    this.stream = stream;
    this.minLocation = minLocation;
    this.maxLocation = maxLocation;
    this.maxStartLocation = maxLocation - dataSize;
  }
  
  public Format getFormat() {
    return this.format;
  }
  
  public void setEnabled(boolean t) {
    this.enabled = t;
  }
  
  public boolean isEnabled() {
    return this.enabled;
  }
  
  public Time getDuration() {
    return this.duration;
  }
  
  public Time getStartTime() {
    return this.startTime;
  }
  
  public void setTrackListener(TrackListener l) {
    this.listener = l;
  }
  
  public synchronized void setSeekLocation(long location) {
    this.seekLocation = location;
  }
  
  public synchronized long getSeekLocation() {
    return this.seekLocation;
  }
  
  public void readFrame(Buffer buffer) {
    byte[] arrayOfByte;
    long l;
    boolean bool;
    int i;
    if (buffer == null)
      return; 
    if (!this.enabled) {
      buffer.setDiscard(true);
      return;
    } 
    buffer.setFormat(this.format);
    Object obj = buffer.getData();
    synchronized (this) {
      if (this.seekLocation != -1L) {
        l = this.seekLocation;
        if (this.seekLocation < this.maxLocation)
          this.seekLocation = -1L; 
        bool = true;
      } else {
        l = this.parser.getLocation(this.stream);
        bool = false;
      } 
    } 
    if (l < this.minLocation) {
      buffer.setDiscard(true);
      return;
    } 
    if (l >= this.maxLocation) {
      buffer.setLength(0);
      buffer.setEOM(true);
      return;
    } 
    if (l > this.maxStartLocation) {
      i = this.dataSize - (int)(l - this.maxStartLocation);
    } else {
      i = this.dataSize;
    } 
    if (obj == null || !(obj instanceof byte[]) || ((byte[])obj).length < i) {
      arrayOfByte = new byte[i];
      buffer.setData(arrayOfByte);
    } else {
      arrayOfByte = (byte[])obj;
    } 
    try {
      if (this.parser.cacheStream != null && this.listener != null && 
        this.parser.cacheStream.willReadBytesBlock(l, i))
        this.listener.readHasBlocked(this); 
      if (bool) {
        long pos = ((Seekable)this.stream).seek(l);
        if (pos == -2L) {
          buffer.setDiscard(true);
          return;
        } 
      } 
      if (this.parser.getMediaTime() != null) {
        buffer.setTimeStamp(this.parser.getMediaTime().getNanoseconds());
      } else {
        buffer.setTimeStamp(-1L);
      } 
      buffer.setDuration(-1L);
      int actualBytesRead = this.parser.readBytes(this.stream, arrayOfByte, i);
      buffer.setOffset(0);
      buffer.setLength(actualBytesRead);
      buffer.setSequenceNumber(++this.sequenceNumber);
    } catch (IOException e) {
      if (this.maxLocation != Long.MAX_VALUE) {
        if (!this.warnedUserOfReadPastEOM) {
          Log.warning("Warning: Attempt to read past End of Media");
          Log.warning("This typically happens if the duration is not known or");
          Log.warning("if the media file has incorrect header info");
          this.warnedUserOfReadPastEOM = true;
        } 
        buffer.setLength(0);
        buffer.setEOM(true);
      } else {
        long length = this.parser.streams[0].getContentLength();
        if (length != -1L) {
          this.maxLocation = length;
          this.maxStartLocation = this.maxLocation - this.dataSize;
          this.mediaSizeAtEOM = this.maxLocation - this.minLocation;
          buffer.setLength(0);
          buffer.setDiscard(true);
        } else {
          this.maxLocation = this.parser.getLocation(this.stream);
          this.maxStartLocation = this.maxLocation - this.dataSize;
          this.mediaSizeAtEOM = this.maxLocation - this.minLocation;
          buffer.setLength(0);
          buffer.setEOM(true);
        } 
      } 
    } 
  }
  
  public int mapTimeToFrame(Time t) {
    return Integer.MAX_VALUE;
  }
  
  public Time mapFrameToTime(int frameNumber) {
    return Track.TIME_UNKNOWN;
  }
  
  public long getMediaSizeAtEOM() {
    return this.mediaSizeAtEOM;
  }
}
