/*     */ package com.sun.media.parser;
/*     */ 
/*     */ import com.sun.media.Log;
/*     */ import java.io.IOException;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.Time;
/*     */ import javax.media.Track;
/*     */ import javax.media.TrackListener;
/*     */ import javax.media.protocol.PullSourceStream;
/*     */ import javax.media.protocol.Seekable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicTrack
/*     */   implements Track
/*     */ {
/*     */   private Format format;
/*     */   private boolean enabled = true;
/*     */   protected Time duration;
/*     */   private Time startTime;
/*     */   private int numBuffers;
/*     */   private int dataSize;
/*     */   private PullSourceStream stream;
/*     */   private long minLocation;
/*     */   private long maxLocation;
/*     */   private long maxStartLocation;
/*     */   private BasicPullParser parser;
/*  31 */   private long sequenceNumber = 0L;
/*     */   private TrackListener listener;
/*  33 */   private long seekLocation = -1L;
/*  34 */   private long mediaSizeAtEOM = -1L;
/*     */   
/*     */   private boolean warnedUserOfReadPastEOM = false;
/*     */ 
/*     */   
/*     */   public BasicTrack(BasicPullParser parser, Format format, boolean enabled, Time duration, Time startTime, int numBuffers, int dataSize, PullSourceStream stream) {
/*  40 */     this(parser, format, enabled, duration, startTime, numBuffers, dataSize, stream, 0L, Long.MAX_VALUE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicTrack(BasicPullParser parser, Format format, boolean enabled, Time duration, Time startTime, int numBuffers, int dataSize, PullSourceStream stream, long minLocation, long maxLocation) {
/*  55 */     this.parser = parser;
/*     */     
/*  57 */     this.format = format;
/*  58 */     this.enabled = enabled;
/*  59 */     this.duration = duration;
/*  60 */     this.startTime = startTime;
/*  61 */     this.numBuffers = numBuffers;
/*  62 */     this.dataSize = dataSize;
/*  63 */     this.stream = stream;
/*  64 */     this.minLocation = minLocation;
/*  65 */     this.maxLocation = maxLocation;
/*  66 */     this.maxStartLocation = maxLocation - dataSize;
/*     */   }
/*     */   
/*     */   public Format getFormat() {
/*  70 */     return this.format;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEnabled(boolean t) {
/*  75 */     this.enabled = t;
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/*  79 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public Time getDuration() {
/*  83 */     return this.duration;
/*     */   }
/*     */ 
/*     */   
/*     */   public Time getStartTime() {
/*  88 */     return this.startTime;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTrackListener(TrackListener l) {
/*  93 */     this.listener = l;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setSeekLocation(long location) {
/*  98 */     this.seekLocation = location;
/*     */   }
/*     */   
/*     */   public synchronized long getSeekLocation() {
/* 102 */     return this.seekLocation; } public void readFrame(Buffer buffer) {
/*     */     byte[] arrayOfByte;
/*     */     long l;
/*     */     boolean bool;
/*     */     int i;
/* 107 */     if (buffer == null) {
/*     */       return;
/*     */     }
/* 110 */     if (!this.enabled) {
/* 111 */       buffer.setDiscard(true);
/*     */       
/*     */       return;
/*     */     } 
/* 115 */     buffer.setFormat(this.format);
/* 116 */     Object obj = buffer.getData();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     synchronized (this) {
/* 122 */       if (this.seekLocation != -1L) {
/* 123 */         l = this.seekLocation;
/* 124 */         if (this.seekLocation < this.maxLocation)
/* 125 */           this.seekLocation = -1L; 
/* 126 */         bool = true;
/*     */       } else {
/* 128 */         l = this.parser.getLocation(this.stream);
/* 129 */         bool = false;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     if (l < this.minLocation) {
/*     */       
/* 138 */       buffer.setDiscard(true); return;
/*     */     } 
/* 140 */     if (l >= this.maxLocation) {
/* 141 */       buffer.setLength(0);
/* 142 */       buffer.setEOM(true); return;
/*     */     } 
/* 144 */     if (l > this.maxStartLocation) {
/* 145 */       i = this.dataSize - (int)(l - this.maxStartLocation);
/*     */     } else {
/* 147 */       i = this.dataSize;
/*     */     } 
/*     */ 
/*     */     
/* 151 */     if (obj == null || !(obj instanceof byte[]) || ((byte[])obj).length < i) {
/*     */ 
/*     */ 
/*     */       
/* 155 */       arrayOfByte = new byte[i];
/* 156 */       buffer.setData(arrayOfByte);
/*     */     } else {
/* 158 */       arrayOfByte = (byte[])obj;
/*     */     } 
/*     */     try {
/* 161 */       if (this.parser.cacheStream != null && this.listener != null && 
/* 162 */         this.parser.cacheStream.willReadBytesBlock(l, i))
/*     */       {
/*     */         
/* 165 */         this.listener.readHasBlocked(this);
/*     */       }
/*     */       
/* 168 */       if (bool) {
/*     */ 
/*     */         
/* 171 */         long pos = ((Seekable)this.stream).seek(l);
/* 172 */         if (pos == -2L) {
/* 173 */           buffer.setDiscard(true);
/*     */           return;
/*     */         } 
/*     */       } 
/* 177 */       if (this.parser.getMediaTime() != null) {
/* 178 */         buffer.setTimeStamp(this.parser.getMediaTime().getNanoseconds());
/*     */       } else {
/* 180 */         buffer.setTimeStamp(-1L);
/* 181 */       }  buffer.setDuration(-1L);
/*     */       
/* 183 */       int actualBytesRead = this.parser.readBytes(this.stream, arrayOfByte, i);
/* 184 */       buffer.setOffset(0);
/* 185 */       buffer.setLength(actualBytesRead);
/*     */       
/* 187 */       buffer.setSequenceNumber(++this.sequenceNumber);
/*     */     } catch (IOException e) {
/*     */       
/* 190 */       if (this.maxLocation != Long.MAX_VALUE) {
/*     */ 
/*     */         
/* 193 */         if (!this.warnedUserOfReadPastEOM) {
/* 194 */           Log.warning("Warning: Attempt to read past End of Media");
/* 195 */           Log.warning("This typically happens if the duration is not known or");
/* 196 */           Log.warning("if the media file has incorrect header info");
/* 197 */           this.warnedUserOfReadPastEOM = true;
/*     */         } 
/* 199 */         buffer.setLength(0);
/* 200 */         buffer.setEOM(true);
/*     */       }
/*     */       else {
/*     */         
/* 204 */         long length = this.parser.streams[0].getContentLength();
/* 205 */         if (length != -1L) {
/*     */ 
/*     */ 
/*     */           
/* 209 */           this.maxLocation = length;
/* 210 */           this.maxStartLocation = this.maxLocation - this.dataSize;
/* 211 */           this.mediaSizeAtEOM = this.maxLocation - this.minLocation;
/* 212 */           buffer.setLength(0);
/* 213 */           buffer.setDiscard(true);
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 220 */           this.maxLocation = this.parser.getLocation(this.stream);
/* 221 */           this.maxStartLocation = this.maxLocation - this.dataSize;
/* 222 */           this.mediaSizeAtEOM = this.maxLocation - this.minLocation;
/* 223 */           buffer.setLength(0);
/* 224 */           buffer.setEOM(true);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int mapTimeToFrame(Time t) {
/* 237 */     return Integer.MAX_VALUE;
/*     */   }
/*     */   
/*     */   public Time mapFrameToTime(int frameNumber) {
/* 241 */     return Track.TIME_UNKNOWN;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getMediaSizeAtEOM() {
/* 246 */     return this.mediaSizeAtEOM;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\parser\BasicTrack.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */