/*     */ package com.sun.media.parser;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Demultiplexer;
/*     */ import javax.media.Format;
/*     */ import javax.media.IncompatibleSourceException;
/*     */ import javax.media.Time;
/*     */ import javax.media.Track;
/*     */ import javax.media.TrackListener;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PullDataSource;
/*     */ import javax.media.protocol.PullSourceStream;
/*     */ import javax.media.protocol.SourceStream;
/*     */ 
/*     */ public class RawPullStreamParser
/*     */   extends RawParser
/*     */ {
/*     */   protected SourceStream[] streams;
/*  20 */   protected Track[] tracks = null;
/*     */   
/*     */   static final String NAME = "Raw pull stream parser";
/*     */   
/*     */   public String getName() {
/*  25 */     return "Raw pull stream parser";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
/*  34 */     if (!(source instanceof PullDataSource)) {
/*  35 */       throw new IncompatibleSourceException("DataSource not supported: " + source);
/*     */     }
/*  37 */     this.streams = (SourceStream[])((PullDataSource)source).getStreams();
/*     */ 
/*     */ 
/*     */     
/*  41 */     if (this.streams == null) {
/*  42 */       throw new IOException("Got a null stream from the DataSource");
/*     */     }
/*     */     
/*  45 */     if (this.streams.length == 0) {
/*  46 */       throw new IOException("Got a empty stream array from the DataSource");
/*     */     }
/*     */     
/*  49 */     if (!supports(this.streams)) {
/*  50 */       throw new IncompatibleSourceException("DataSource not supported: " + source);
/*     */     }
/*  52 */     this.source = source;
/*  53 */     this.streams = this.streams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean supports(SourceStream[] streams) {
/*  63 */     return (streams[0] != null && streams[0] instanceof PullSourceStream);
/*     */   }
/*     */ 
/*     */   
/*     */   public Track[] getTracks() {
/*  68 */     return this.tracks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() {
/*  78 */     if (this.tracks != null)
/*     */       return; 
/*  80 */     this.tracks = new Track[this.streams.length];
/*  81 */     for (int i = 0; i < this.streams.length; i++) {
/*  82 */       this.tracks[i] = new FrameTrack(this, this, (PullSourceStream)this.streams[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*  93 */     if (this.source != null) {
/*     */       try {
/*  95 */         this.source.stop();
/*  96 */         this.source.disconnect();
/*  97 */       } catch (IOException e) {}
/*     */ 
/*     */       
/* 100 */       this.source = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() throws IOException {
/* 108 */     this.source.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/*     */     try {
/* 116 */       this.source.stop();
/* 117 */     } catch (IOException e) {}
/*     */   }
/*     */ 
/*     */   
/*     */   class FrameTrack
/*     */     implements Track
/*     */   {
/*     */     Demultiplexer parser;
/*     */     
/*     */     PullSourceStream pss;
/*     */     
/*     */     boolean enabled;
/*     */     
/*     */     Format format;
/*     */     TrackListener listener;
/*     */     Integer stateReq;
/*     */     private final RawPullStreamParser this$0;
/*     */     
/*     */     public FrameTrack(RawPullStreamParser this$0, Demultiplexer parser, PullSourceStream pss) {
/* 136 */       this.this$0 = this$0; this.enabled = true; this.format = null; this.stateReq = new Integer(0);
/* 137 */       this.pss = pss;
/*     */     }
/*     */     
/*     */     public Format getFormat() {
/* 141 */       return this.format;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean t) {
/* 145 */       this.enabled = t;
/*     */     }
/*     */     
/*     */     public boolean isEnabled() {
/* 149 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public Time getDuration() {
/* 153 */       return this.parser.getDuration();
/*     */     }
/*     */     
/*     */     public Time getStartTime() {
/* 157 */       return new Time(0L);
/*     */     }
/*     */     
/*     */     public void setTrackListener(TrackListener l) {
/* 161 */       this.listener = l;
/*     */     }
/*     */     
/*     */     public void readFrame(Buffer buffer) {
/* 165 */       byte[] data = (byte[])buffer.getData();
/*     */ 
/*     */       
/* 168 */       if (data == null) {
/* 169 */         data = new byte[500];
/* 170 */         buffer.setData(data);
/*     */       } 
/*     */       
/*     */       try {
/* 174 */         int len = this.pss.read(data, 0, data.length);
/* 175 */         buffer.setLength(len);
/*     */       } catch (IOException e) {
/* 177 */         buffer.setDiscard(true);
/*     */       } 
/*     */     }
/*     */     
/*     */     public int mapTimeToFrame(Time t) {
/* 182 */       return -1;
/*     */     }
/*     */     
/*     */     public Time mapFrameToTime(int frameNumber) {
/* 186 */       return new Time(0L);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\parser\RawPullStreamParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */