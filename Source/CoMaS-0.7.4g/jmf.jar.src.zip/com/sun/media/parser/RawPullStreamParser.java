package com.sun.media.parser;

import java.io.IOException;
import javax.media.Buffer;
import javax.media.Demultiplexer;
import javax.media.Format;
import javax.media.IncompatibleSourceException;
import javax.media.Time;
import javax.media.Track;
import javax.media.TrackListener;
import javax.media.protocol.DataSource;
import javax.media.protocol.PullDataSource;
import javax.media.protocol.PullSourceStream;
import javax.media.protocol.SourceStream;

public class RawPullStreamParser extends RawParser {
  protected SourceStream[] streams;
  
  protected Track[] tracks = null;
  
  static final String NAME = "Raw pull stream parser";
  
  public String getName() {
    return "Raw pull stream parser";
  }
  
  public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
    if (!(source instanceof PullDataSource))
      throw new IncompatibleSourceException("DataSource not supported: " + source); 
    this.streams = (SourceStream[])((PullDataSource)source).getStreams();
    if (this.streams == null)
      throw new IOException("Got a null stream from the DataSource"); 
    if (this.streams.length == 0)
      throw new IOException("Got a empty stream array from the DataSource"); 
    if (!supports(this.streams))
      throw new IncompatibleSourceException("DataSource not supported: " + source); 
    this.source = source;
    this.streams = this.streams;
  }
  
  protected boolean supports(SourceStream[] streams) {
    return (streams[0] != null && streams[0] instanceof PullSourceStream);
  }
  
  public Track[] getTracks() {
    return this.tracks;
  }
  
  public void open() {
    if (this.tracks != null)
      return; 
    this.tracks = new Track[this.streams.length];
    for (int i = 0; i < this.streams.length; i++)
      this.tracks[i] = new FrameTrack(this, this, (PullSourceStream)this.streams[i]); 
  }
  
  public void close() {
    if (this.source != null) {
      try {
        this.source.stop();
        this.source.disconnect();
      } catch (IOException e) {}
      this.source = null;
    } 
  }
  
  public void start() throws IOException {
    this.source.start();
  }
  
  public void stop() {
    try {
      this.source.stop();
    } catch (IOException e) {}
  }
  
  class FrameTrack implements Track {
    Demultiplexer parser;
    
    PullSourceStream pss;
    
    boolean enabled;
    
    Format format;
    
    TrackListener listener;
    
    Integer stateReq;
    
    private final RawPullStreamParser this$0;
    
    public FrameTrack(RawPullStreamParser this$0, Demultiplexer parser, PullSourceStream pss) {
      this.this$0 = this$0;
      this.enabled = true;
      this.format = null;
      this.stateReq = new Integer(0);
      this.pss = pss;
    }
    
    public Format getFormat() {
      return this.format;
    }
    
    public void setEnabled(boolean t) {
      this.enabled = t;
    }
    
    public boolean isEnabled() {
      return this.enabled;
    }
    
    public Time getDuration() {
      return this.parser.getDuration();
    }
    
    public Time getStartTime() {
      return new Time(0L);
    }
    
    public void setTrackListener(TrackListener l) {
      this.listener = l;
    }
    
    public void readFrame(Buffer buffer) {
      byte[] data = (byte[])buffer.getData();
      if (data == null) {
        data = new byte[500];
        buffer.setData(data);
      } 
      try {
        int len = this.pss.read(data, 0, data.length);
        buffer.setLength(len);
      } catch (IOException e) {
        buffer.setDiscard(true);
      } 
    }
    
    public int mapTimeToFrame(Time t) {
      return -1;
    }
    
    public Time mapFrameToTime(int frameNumber) {
      return new Time(0L);
    }
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\parser\RawPullStreamParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */