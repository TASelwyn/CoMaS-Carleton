package com.sun.media.parser.audio;

import com.sun.media.format.WavAudioFormat;
import com.sun.media.parser.BasicPullParser;
import com.sun.media.parser.BasicTrack;
import com.sun.media.util.SettableTime;
import java.io.IOException;
import javax.media.BadHeaderException;
import javax.media.Duration;
import javax.media.Format;
import javax.media.Time;
import javax.media.Track;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.PullSourceStream;

public class WavParser extends BasicPullParser {
  private Time duration = Duration.DURATION_UNKNOWN;
  
  private WavAudioFormat format = null;
  
  private Track[] tracks = new Track[1];
  
  private int numBuffers = 4;
  
  private int bufferSize;
  
  private int dataSize;
  
  private SettableTime mediaTime = new SettableTime(0L);
  
  private int encoding;
  
  private String encodingString;
  
  private int sampleRate;
  
  private int channels;
  
  private int sampleSizeInBits;
  
  private int blockAlign;
  
  private int samplesPerBlock;
  
  private long minLocation;
  
  private long maxLocation;
  
  private double locationToMediaTime = -1.0D;
  
  private double timePerBlockNano = -1.0D;
  
  private PullSourceStream stream = null;
  
  private static ContentDescriptor[] supportedFormat = new ContentDescriptor[] { new ContentDescriptor("audio.x_wav") };
  
  public ContentDescriptor[] getSupportedInputContentDescriptors() {
    return supportedFormat;
  }
  
  public Track[] getTracks() throws IOException, BadHeaderException {
    if (this.tracks[0] != null)
      return this.tracks; 
    this.stream = (PullSourceStream)this.streams[0];
    if (this.cacheStream != null)
      this.cacheStream.setEnabledBuffering(false); 
    readHeader();
    if (this.cacheStream != null)
      this.cacheStream.setEnabledBuffering(true); 
    this.minLocation = getLocation(this.stream);
    this.maxLocation = this.minLocation + this.dataSize;
    this.tracks[0] = (Track)new WavTrack(this.format, true, new Time(0L), this.numBuffers, this.bufferSize, this.minLocation, this.maxLocation);
    return this.tracks;
  }
  
  private void readHeader() throws IOException, BadHeaderException {
    boolean bool;
    String magicRIFF = readString(this.stream);
    if (!magicRIFF.equals("RIFF"))
      throw new BadHeaderException("WAVE Parser: expected magic string RIFF, got " + magicRIFF); 
    int length = readInt(this.stream, false);
    String magicWAVE = readString(this.stream);
    if (!magicWAVE.equals("WAVE"))
      throw new BadHeaderException("WAVE Parser: expected magic string WAVE, got " + magicWAVE); 
    length += 8;
    while (!readString(this.stream).equals("fmt ")) {
      int size = readInt(this.stream, false);
      skip(this.stream, size);
    } 
    int formatSize = readInt(this.stream, false);
    int remainingFormatSize = formatSize;
    if (formatSize < 16);
    this.encoding = readShort(this.stream, false);
    this.encodingString = (String)WavAudioFormat.formatMapper.get(new Integer(this.encoding));
    if (this.encodingString == null)
      this.encodingString = "unknown"; 
    this.channels = readShort(this.stream, false);
    this.sampleRate = readInt(this.stream, false);
    int bytesPerSecond = readInt(this.stream, false);
    this.blockAlign = readShort(this.stream, false);
    this.sampleSizeInBits = readShort(this.stream, false);
    if (this.encoding == 85)
      this.sampleSizeInBits = 16; 
    this.samplesPerBlock = -1;
    remainingFormatSize -= 16;
    if ((remainingFormatSize > 0 && this.encoding == 1) || remainingFormatSize <= 2) {
      skip(this.stream, remainingFormatSize);
      remainingFormatSize = 0;
    } 
    byte[] codecSpecificHeader = null;
    int extraFieldsSize = 0;
    if (remainingFormatSize >= 2) {
      extraFieldsSize = readShort(this.stream, false);
      remainingFormatSize -= 2;
      if (extraFieldsSize > 0) {
        codecSpecificHeader = new byte[extraFieldsSize];
        readBytes(this.stream, codecSpecificHeader, codecSpecificHeader.length);
        remainingFormatSize -= extraFieldsSize;
      } 
    } 
    switch (this.encoding) {
      case 2:
      case 17:
      case 49:
        if (extraFieldsSize < 2)
          throw new BadHeaderException("msadpcm: samplesPerBlock field not available"); 
        this.samplesPerBlock = BasicPullParser.parseShortFromArray(codecSpecificHeader, false);
        this.locationToMediaTime = this.samplesPerBlock / (this.sampleRate * this.blockAlign);
        break;
      default:
        this.locationToMediaTime = 1.0D / (this.sampleRate * this.blockAlign);
        break;
    } 
    if (remainingFormatSize < 0)
      throw new BadHeaderException("WAVE Parser: incorrect chunkSize in the fmt chunk"); 
    if (remainingFormatSize > 0)
      skip(this.stream, remainingFormatSize); 
    while (!readString(this.stream).equals("data")) {
      int size = readInt(this.stream, false);
      skip(this.stream, size);
    } 
    this.dataSize = readInt(this.stream, false);
    if (this.blockAlign != 0) {
      if (bytesPerSecond < this.dataSize) {
        this.bufferSize = bytesPerSecond - bytesPerSecond % this.blockAlign;
      } else {
        this.bufferSize = this.dataSize - this.dataSize % this.blockAlign;
      } 
    } else if (bytesPerSecond < this.dataSize) {
      this.bufferSize = bytesPerSecond;
    } else {
      this.bufferSize = this.dataSize;
    } 
    double durationSeconds = -1.0D;
    if (this.channels * this.sampleSizeInBits / 8 == this.blockAlign) {
      durationSeconds = (this.dataSize / bytesPerSecond);
    } else if (this.samplesPerBlock > 0) {
      durationSeconds = (this.dataSize / this.blockAlign * this.samplesPerBlock / this.sampleRate);
      this.timePerBlockNano = this.samplesPerBlock * 1.0E9D / this.sampleRate;
    } else {
      this.timePerBlockNano = this.blockAlign * 1.0E9D / bytesPerSecond;
      durationSeconds = (this.dataSize / bytesPerSecond);
    } 
    this.duration = new Time(durationSeconds);
    if (this.sampleSizeInBits > 8) {
      bool = true;
    } else {
      bool = false;
    } 
    this.format = new WavAudioFormat(this.encodingString, this.sampleRate, this.sampleSizeInBits, this.channels, this.blockAlign * 8, bytesPerSecond, 0, bool ? 1 : 0, -1.0F, Format.byteArray, codecSpecificHeader);
  }
  
  public Time setPosition(Time where, int rounding) {
    long l1;
    if (!this.seekable)
      return getMediaTime(); 
    long time = where.getNanoseconds();
    if (time < 0L)
      time = 0L; 
    if (this.timePerBlockNano <= 0.0D) {
      int bytesPerSecond = this.sampleRate * this.blockAlign;
      double newPosd = (time * this.sampleRate * this.blockAlign) / 1.0E9D;
      double remainder = newPosd % this.blockAlign;
      l1 = (long)(newPosd - remainder);
      if (remainder > 0.0D)
        switch (rounding) {
          case 1:
            l1 += this.blockAlign;
            break;
          case 3:
            if (remainder > this.blockAlign / 2.0D)
              l1 += this.blockAlign; 
            break;
        }  
    } else {
      double blockNum = time / this.timePerBlockNano;
      int blockNumInt = (int)blockNum;
      double remainder = blockNum - blockNumInt;
      if (remainder > 0.0D)
        switch (rounding) {
          case 1:
            blockNumInt++;
            break;
          case 3:
            if (remainder > 0.5D)
              blockNumInt++; 
            break;
        }  
      l1 = (blockNumInt * this.blockAlign);
    } 
    l1 += this.minLocation;
    ((BasicTrack)this.tracks[0]).setSeekLocation(l1);
    if (this.cacheStream != null)
      synchronized (this) {
        this.cacheStream.abortRead();
      }  
    return where;
  }
  
  public Time getMediaTime() {
    long l1, seekLocation = ((BasicTrack)this.tracks[0]).getSeekLocation();
    if (seekLocation != -1L) {
      l1 = seekLocation - this.minLocation;
    } else {
      l1 = getLocation(this.stream) - this.minLocation;
    } 
    synchronized (this.mediaTime) {
      this.mediaTime.set(l1 * this.locationToMediaTime);
    } 
    return (Time)this.mediaTime;
  }
  
  public Time getDuration() {
    return this.duration;
  }
  
  public String getName() {
    return "Parser for WAV file format";
  }
  
  class WavTrack extends BasicTrack {
    private double sampleRate;
    
    private float timePerFrame;
    
    private SettableTime frameToTime;
    
    private final WavParser this$0;
    
    WavTrack(WavParser this$0, WavAudioFormat format, boolean enabled, Time startTime, int numBuffers, int bufferSize, long minLocation, long maxLocation) {
      super(WavParser.this, (Format)format, enabled, WavParser.this.duration, startTime, numBuffers, bufferSize, WavParser.this.stream, minLocation, maxLocation);
      WavParser.this = WavParser.this;
      this.frameToTime = new SettableTime();
      double sampleRate = format.getSampleRate();
      int channels = format.getChannels();
      int sampleSizeInBits = format.getSampleSizeInBits();
      int blockSize = format.getFrameSizeInBits() / 8;
      if (WavParser.this.encoding == 1 || WavParser.this.encoding == 7 || WavParser.this.encoding == 6 || WavParser.this.encoding == 257 || WavParser.this.encoding == 258) {
        float bytesPerSecond = (float)sampleRate * blockSize;
        float bytesPerFrame = bufferSize;
        this.timePerFrame = bufferSize / bytesPerSecond;
      } else if (WavParser.this.encoding == 2 || WavParser.this.encoding == 17 || WavParser.this.encoding == 49) {
        float f1 = bufferSize;
        float blocksPerFrame = bufferSize / blockSize;
        float samplesPerFrame = blocksPerFrame * WavParser.this.samplesPerBlock;
        this.timePerFrame = (float)(samplesPerFrame / sampleRate);
      } else {
        float f1 = (float)sampleRate * blockSize;
        float f2 = bufferSize;
        this.timePerFrame = bufferSize / f1;
      } 
    }
    
    WavTrack(WavAudioFormat format, boolean enabled, Time startTime, int numBuffers, int bufferSize) {
      this(format, enabled, startTime, numBuffers, bufferSize, 0L, Long.MAX_VALUE);
    }
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\parser\audio\WavParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */