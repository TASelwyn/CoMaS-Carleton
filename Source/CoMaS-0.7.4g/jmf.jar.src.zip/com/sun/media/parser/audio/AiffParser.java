package com.sun.media.parser.audio;

import com.sun.media.parser.BasicPullParser;
import com.sun.media.parser.BasicTrack;
import com.sun.media.util.SettableTime;
import java.io.IOException;
import javax.media.BadHeaderException;
import javax.media.Duration;
import javax.media.Format;
import javax.media.Time;
import javax.media.Track;
import javax.media.format.AudioFormat;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.PullSourceStream;

public class AiffParser extends BasicPullParser {
  private Time duration = Duration.DURATION_UNKNOWN;
  
  private Format format = null;
  
  private Track[] tracks = new Track[1];
  
  private int numBuffers = 4;
  
  private int bufferSize = -1;
  
  private int dataSize;
  
  private SettableTime mediaTime = new SettableTime(0L);
  
  private PullSourceStream stream = null;
  
  private int maxFrame;
  
  private int blockSize = 0;
  
  private double sampleRate = -1.0D;
  
  private long minLocation;
  
  private long maxLocation;
  
  private String encodingString = null;
  
  private int samplesPerBlock = 1;
  
  private double timePerBlockNano = -1.0D;
  
  private double locationToMediaTime = -1.0D;
  
  public static final String FormID = "FORM";
  
  public static final String FormatVersionID = "FVER";
  
  public static final String CommonID = "COMM";
  
  public static final String SoundDataID = "SSND";
  
  private static ContentDescriptor[] supportedFormat = new ContentDescriptor[] { new ContentDescriptor("audio.x_aiff") };
  
  public static final int CommonIDSize = 18;
  
  private boolean isAIFC = false;
  
  private boolean commonChunkSeen = false;
  
  private boolean soundDataChunkSeen = false;
  
  private boolean formatVersionChunkSeen = false;
  
  public ContentDescriptor[] getSupportedInputContentDescriptors() {
    return supportedFormat;
  }
  
  public Track[] getTracks() throws IOException, BadHeaderException {
    if (this.tracks[0] != null)
      return this.tracks; 
    this.stream = (PullSourceStream)this.streams[0];
    if (this.cacheStream != null)
      this.cacheStream.setEnabledBuffering(false); 
    readHeader();
    if (this.cacheStream != null)
      this.cacheStream.setEnabledBuffering(true); 
    this.tracks[0] = (Track)new AiffTrack((AudioFormat)this.format, true, new Time(0L), this.numBuffers, this.bufferSize, this.minLocation, this.maxLocation);
    return this.tracks;
  }
  
  private void readHeader() throws IOException, BadHeaderException {
    boolean signed = true;
    String magic = readString(this.stream);
    if (!magic.equals("FORM"))
      throw new BadHeaderException("AIFF Parser: expected string FORM, got " + magic); 
    int fileLength = readInt(this.stream) + 8;
    String formType = readString(this.stream);
    if (formType.equals("AIFC")) {
      this.isAIFC = true;
    } else {
      this.encodingString = "LINEAR";
    } 
    int remainingLength = fileLength - 12;
    String compressionType = null;
    int offset = 0;
    int channels = -1;
    int sampleSizeInBits = -1;
    while (remainingLength >= 8) {
      String type = readString(this.stream);
      int size = readInt(this.stream);
      remainingLength -= 8;
      if (type.equals("FVER")) {
        if (!this.isAIFC);
        int timestamp = readInt(this.stream);
        if (size != 4)
          throw new BadHeaderException("Illegal FormatVersionID: chunk size is not 4 but " + size); 
        this.formatVersionChunkSeen = true;
      } else if (type.equals("COMM")) {
        if (size < 18)
          throw new BadHeaderException("Size of COMM chunk should be atleast 18"); 
        channels = readShort(this.stream);
        if (channels < 1)
          throw new BadHeaderException("Number of channels is " + channels); 
        this.maxFrame = readInt(this.stream);
        sampleSizeInBits = readShort(this.stream);
        if (sampleSizeInBits <= 0)
          throw new BadHeaderException("Illegal sampleSize " + sampleSizeInBits); 
        this.sampleRate = readIeeeExtended(this.stream);
        if (this.sampleRate < 0.0D)
          throw new BadHeaderException("Negative Sample Rate " + this.sampleRate); 
        int remainingCommSize = size - 18;
        if (this.isAIFC) {
          if (remainingCommSize < 4)
            throw new BadHeaderException("COMM chunk in AIFC doesn't have compressionType info"); 
          compressionType = readString(this.stream);
          if (compressionType == null)
            throw new BadHeaderException("Compression type for AIFC is null"); 
          skip(this.stream, remainingCommSize - 4);
        } 
        this.commonChunkSeen = true;
      } else if (type.equals("SSND")) {
        if (this.soundDataChunkSeen)
          throw new BadHeaderException("Cannot have more than 1 Sound Data Chunk"); 
        offset = readInt(this.stream);
        this.blockSize = readInt(this.stream);
        this.minLocation = getLocation(this.stream);
        this.dataSize = size - 8;
        this.maxLocation = this.minLocation + this.dataSize;
        this.soundDataChunkSeen = true;
        if (this.commonChunkSeen) {
          remainingLength -= 8;
          break;
        } 
        skip(this.stream, size - 8);
      } else {
        skip(this.stream, size);
      } 
      remainingLength -= size;
    } 
    if (!this.commonChunkSeen)
      throw new BadHeaderException("Mandatory chunk COMM missing"); 
    if (!this.soundDataChunkSeen)
      throw new BadHeaderException("Mandatory chunk SSND missing"); 
    double durationSeconds = -1.0D;
    if (this.isAIFC) {
      String c = compressionType;
      if (c.equalsIgnoreCase("NONE")) {
        this.encodingString = "LINEAR";
      } else if (c.equalsIgnoreCase("twos")) {
        this.encodingString = "LINEAR";
      } else if (c.equalsIgnoreCase("raw")) {
        this.encodingString = "LINEAR";
        signed = false;
      } else if (c.equalsIgnoreCase("ULAW")) {
        this.encodingString = "ULAW";
        sampleSizeInBits = 8;
        signed = false;
      } else if (c.equalsIgnoreCase("ALAW")) {
        this.encodingString = "alaw";
        sampleSizeInBits = 8;
        signed = false;
      } else if (c.equalsIgnoreCase("G723")) {
        this.encodingString = "g723";
      } else if (c.equalsIgnoreCase("MAC3")) {
        this.encodingString = "MAC3";
        this.blockSize = 2;
        this.samplesPerBlock = 6;
        this.timePerBlockNano = this.samplesPerBlock * 1.0E9D / this.sampleRate;
      } else if (c.equalsIgnoreCase("MAC6")) {
        this.encodingString = "MAC6";
        this.blockSize = 1;
        this.samplesPerBlock = 6;
        this.timePerBlockNano = this.samplesPerBlock * 1.0E9D / this.sampleRate;
      } else if (c.equalsIgnoreCase("IMA4")) {
        this.encodingString = "ima4";
        this.blockSize = 34 * channels;
        this.samplesPerBlock = 64;
        this.timePerBlockNano = this.samplesPerBlock * 1.0E9D / this.sampleRate;
      } else {
        throw new BadHeaderException("Unsupported encoding" + c);
      } 
    } 
    if (this.blockSize == 0)
      this.blockSize = channels * sampleSizeInBits / 8; 
    this.bufferSize = this.blockSize * (int)(this.sampleRate / this.samplesPerBlock);
    durationSeconds = (this.maxFrame * this.samplesPerBlock) / this.sampleRate;
    if (durationSeconds > 0.0D)
      this.duration = new Time(durationSeconds); 
    this.locationToMediaTime = this.samplesPerBlock / this.sampleRate * this.blockSize;
    this.format = (Format)new AudioFormat(this.encodingString, this.sampleRate, sampleSizeInBits, channels, 1, signed ? 1 : 0, this.blockSize * 8, -1.0D, Format.byteArray);
  }
  
  public Time setPosition(Time where, int rounding) {
    long l1;
    if (!this.seekable)
      return getMediaTime(); 
    long time = where.getNanoseconds();
    if (time < 0L)
      time = 0L; 
    if (this.timePerBlockNano == -1.0D) {
      int bytesPerSecond = (int)this.sampleRate * this.blockSize;
      double newPosd = time * this.sampleRate * this.blockSize / 1.0E9D;
      double remainder = newPosd % this.blockSize;
      l1 = (long)(newPosd - remainder);
      if (remainder > 0.0D)
        switch (rounding) {
          case 1:
            l1 += this.blockSize;
            break;
          case 3:
            if (remainder > this.blockSize / 2.0D)
              l1 += this.blockSize; 
            break;
        }  
    } else {
      double blockNum = time / this.timePerBlockNano;
      int blockNumInt = (int)blockNum;
      double remainder = blockNum - blockNumInt;
      if (remainder > 0.0D)
        switch (rounding) {
          case 1:
            blockNumInt++;
            break;
          case 3:
            if (remainder > 0.5D)
              blockNumInt++; 
            break;
        }  
      l1 = (blockNumInt * this.blockSize);
    } 
    l1 += this.minLocation;
    ((BasicTrack)this.tracks[0]).setSeekLocation(l1);
    if (this.cacheStream != null)
      synchronized (this) {
        this.cacheStream.abortRead();
      }  
    return where;
  }
  
  public Time getMediaTime() {
    long l1, seekLocation = ((BasicTrack)this.tracks[0]).getSeekLocation();
    if (seekLocation != -1L) {
      l1 = seekLocation - this.minLocation;
    } else {
      l1 = getLocation(this.stream) - this.minLocation;
    } 
    synchronized (this.mediaTime) {
      this.mediaTime.set(l1 * this.locationToMediaTime);
    } 
    return (Time)this.mediaTime;
  }
  
  public Time getDuration() {
    if (this.maxFrame <= 0 && 
      this.tracks[0] != null) {
      long mediaSizeAtEOM = ((BasicTrack)this.tracks[0]).getMediaSizeAtEOM();
      if (mediaSizeAtEOM > 0L) {
        this.maxFrame = (int)(mediaSizeAtEOM / this.blockSize);
        double durationSeconds = (this.maxFrame * this.samplesPerBlock) / this.sampleRate;
        if (durationSeconds > 0.0D)
          this.duration = new Time(durationSeconds); 
      } 
    } 
    return this.duration;
  }
  
  public String getName() {
    return "Parser for AIFF file format";
  }
  
  class AiffTrack extends BasicTrack {
    private double sampleRate;
    
    private float timePerFrame;
    
    private SettableTime frameToTime;
    
    private final AiffParser this$0;
    
    AiffTrack(AiffParser this$0, AudioFormat format, boolean enabled, Time startTime, int numBuffers, int bufferSize, long minLocation, long maxLocation) {
      super(AiffParser.this, (Format)format, enabled, AiffParser.this.duration, startTime, numBuffers, bufferSize, AiffParser.this.stream, minLocation, maxLocation);
      AiffParser.this = AiffParser.this;
      this.frameToTime = new SettableTime();
      double sampleRate = format.getSampleRate();
      int channels = format.getChannels();
      int sampleSizeInBits = format.getSampleSizeInBits();
      if (AiffParser.this.timePerBlockNano == -1.0D) {
        float bytesPerSecond = (float)(sampleRate * AiffParser.this.blockSize);
        this.timePerFrame = bufferSize / bytesPerSecond;
      } else {
        float blocksPerFrame = bufferSize / AiffParser.this.blockSize;
        float samplesPerFrame = blocksPerFrame * AiffParser.this.samplesPerBlock;
        this.timePerFrame = (float)(samplesPerFrame / sampleRate);
      } 
    }
    
    AiffTrack(AudioFormat format, boolean enabled, Time startTime, int numBuffers, int bufferSize) {
      this(format, enabled, startTime, numBuffers, bufferSize, 0L, Long.MAX_VALUE);
    }
  }
  
  private double readIeeeExtended(PullSourceStream stream) throws IOException {
    double f = 0.0D;
    int expon = 0;
    long hiMant = 0L, loMant = 0L;
    double huge = 3.4028234663852886E38D;
    expon = readShort(stream);
    hiMant = readInt(stream);
    if (hiMant < 0L)
      hiMant += 4294967296L; 
    loMant = readInt(stream);
    if (loMant < 0L)
      loMant += 4294967296L; 
    if (expon == 0 && hiMant == 0L && loMant == 0L) {
      f = 0.0D;
    } else if (expon == 32767) {
      f = huge;
    } else {
      expon -= 16383;
      expon -= 31;
      f = hiMant * Math.pow(2.0D, expon);
      expon -= 32;
      f += loMant * Math.pow(2.0D, expon);
    } 
    return f;
  }
}
