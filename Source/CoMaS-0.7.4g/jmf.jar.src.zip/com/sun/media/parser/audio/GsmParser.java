/*     */ package com.sun.media.parser.audio;
/*     */ 
/*     */ import com.sun.media.parser.BasicPullParser;
/*     */ import com.sun.media.parser.BasicTrack;
/*     */ import com.sun.media.util.SettableTime;
/*     */ import java.io.IOException;
/*     */ import javax.media.BadHeaderException;
/*     */ import javax.media.Duration;
/*     */ import javax.media.Format;
/*     */ import javax.media.Time;
/*     */ import javax.media.Track;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.PullSourceStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GsmParser
/*     */   extends BasicPullParser
/*     */ {
/*  26 */   private Time duration = Duration.DURATION_UNKNOWN;
/*  27 */   private Format format = null;
/*  28 */   private Track[] tracks = new Track[1];
/*  29 */   private int numBuffers = 4;
/*     */   private int bufferSize;
/*     */   private int dataSize;
/*  32 */   private SettableTime mediaTime = new SettableTime(0L);
/*     */   private int encoding;
/*     */   private String encodingString;
/*     */   private int sampleRate;
/*     */   private int samplesPerBlock;
/*  37 */   private int bytesPerSecond = 1650;
/*  38 */   private int blockSize = 33;
/*     */   private long minLocation;
/*     */   private long maxLocation;
/*  41 */   private PullSourceStream stream = null;
/*     */ 
/*     */   
/*  44 */   private static ContentDescriptor[] supportedFormat = new ContentDescriptor[] { new ContentDescriptor("audio.x_gsm") };
/*     */   
/*     */   public ContentDescriptor[] getSupportedInputContentDescriptors() {
/*  47 */     return supportedFormat;
/*     */   }
/*     */ 
/*     */   
/*     */   public Track[] getTracks() throws IOException, BadHeaderException {
/*  52 */     if (this.tracks[0] != null) {
/*  53 */       return this.tracks;
/*     */     }
/*  55 */     this.stream = (PullSourceStream)this.streams[0];
/*     */ 
/*     */     
/*  58 */     readHeader();
/*  59 */     this.bufferSize = this.bytesPerSecond;
/*  60 */     this.tracks[0] = (Track)new GsmTrack((AudioFormat)this.format, true, new Time(0L), this.numBuffers, this.bufferSize, this.minLocation, this.maxLocation);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  68 */     return this.tracks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readHeader() throws IOException, BadHeaderException {
/*  81 */     this.minLocation = getLocation(this.stream);
/*     */     
/*  83 */     long contentLength = this.stream.getContentLength();
/*  84 */     if (contentLength != -1L) {
/*  85 */       double durationSeconds = (contentLength / this.bytesPerSecond);
/*  86 */       this.duration = new Time(durationSeconds);
/*  87 */       this.maxLocation = contentLength;
/*     */     } else {
/*  89 */       this.maxLocation = Long.MAX_VALUE;
/*     */     } 
/*     */     
/*  92 */     boolean signed = true;
/*  93 */     boolean bigEndian = false;
/*  94 */     this.format = (Format)new AudioFormat("gsm", 8000.0D, 16, 1, bigEndian ? 1 : 0, signed ? 1 : 0, this.blockSize * 8, -1.0D, Format.byteArray);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Time setPosition(Time where, int rounding) {
/* 112 */     if (!this.seekable) {
/* 113 */       return getMediaTime();
/*     */     }
/*     */     
/* 116 */     long time = where.getNanoseconds();
/*     */ 
/*     */     
/* 119 */     if (time < 0L) {
/* 120 */       time = 0L;
/*     */     }
/* 122 */     double newPosd = (time * this.bytesPerSecond) / 1.0E9D;
/* 123 */     double remainder = newPosd % this.blockSize;
/*     */     
/* 125 */     long newPos = (long)(newPosd - remainder);
/*     */     
/* 127 */     if (remainder > 0.0D) {
/* 128 */       switch (rounding) {
/*     */         case 1:
/* 130 */           newPos += this.blockSize;
/*     */           break;
/*     */         case 3:
/* 133 */           if (remainder > this.blockSize / 2.0D) {
/* 134 */             newPos += this.blockSize;
/*     */           }
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 142 */     newPos += this.minLocation;
/* 143 */     ((BasicTrack)this.tracks[0]).setSeekLocation(newPos);
/* 144 */     if (this.cacheStream != null) {
/* 145 */       synchronized (this) {
/*     */         
/* 147 */         this.cacheStream.abortRead();
/*     */       } 
/*     */     }
/* 150 */     return where;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Time getMediaTime() {
/* 156 */     long l1, seekLocation = ((BasicTrack)this.tracks[0]).getSeekLocation();
/* 157 */     if (seekLocation != -1L) {
/* 158 */       l1 = seekLocation - this.minLocation;
/*     */     } else {
/* 160 */       l1 = getLocation(this.stream) - this.minLocation;
/* 161 */     }  synchronized (this.mediaTime) {
/* 162 */       this.mediaTime.set(l1 / this.bytesPerSecond);
/*     */     } 
/* 164 */     return (Time)this.mediaTime;
/*     */   }
/*     */   
/*     */   public Time getDuration() {
/* 168 */     if (this.duration.equals(Duration.DURATION_UNKNOWN) && this.tracks[0] != null) {
/*     */       
/* 170 */       long mediaSizeAtEOM = ((BasicTrack)this.tracks[0]).getMediaSizeAtEOM();
/* 171 */       if (mediaSizeAtEOM > 0L) {
/* 172 */         double durationSeconds = (mediaSizeAtEOM / this.bytesPerSecond);
/* 173 */         this.duration = new Time(durationSeconds);
/*     */       } 
/*     */     } 
/* 176 */     return this.duration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 184 */     return "Parser for raw GSM";
/*     */   }
/*     */   
/*     */   class GsmTrack
/*     */     extends BasicTrack {
/*     */     private double sampleRate;
/*     */     private float timePerFrame;
/*     */     private SettableTime frameToTime;
/*     */     private final GsmParser this$0;
/*     */     
/*     */     GsmTrack(GsmParser this$0, AudioFormat format, boolean enabled, Time startTime, int numBuffers, int bufferSize, long minLocation, long maxLocation) {
/* 195 */       super(GsmParser.this, (Format)format, enabled, GsmParser.this.duration, startTime, numBuffers, bufferSize, GsmParser.this.stream, minLocation, maxLocation);
/*     */       
/*     */       GsmParser.this = GsmParser.this;
/*     */       this.timePerFrame = 0.02F;
/*     */       this.frameToTime = new SettableTime();
/* 200 */       double sampleRate = format.getSampleRate();
/* 201 */       int channels = format.getChannels();
/* 202 */       int sampleSizeInBits = format.getSampleSizeInBits();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 208 */       long durationNano = this.duration.getNanoseconds();
/*     */     }
/*     */ 
/*     */     
/*     */     GsmTrack(AudioFormat format, boolean enabled, Time startTime, int numBuffers, int bufferSize) {
/* 213 */       this(format, enabled, startTime, numBuffers, bufferSize, 0L, Long.MAX_VALUE);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\parser\audio\GsmParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */