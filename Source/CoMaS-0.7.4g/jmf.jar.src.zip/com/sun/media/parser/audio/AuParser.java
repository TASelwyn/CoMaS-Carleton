/*     */ package com.sun.media.parser.audio;
/*     */ 
/*     */ import com.sun.media.parser.BasicPullParser;
/*     */ import com.sun.media.parser.BasicTrack;
/*     */ import com.sun.media.util.SettableTime;
/*     */ import java.io.IOException;
/*     */ import javax.media.BadHeaderException;
/*     */ import javax.media.Duration;
/*     */ import javax.media.Format;
/*     */ import javax.media.Time;
/*     */ import javax.media.Track;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.PullSourceStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuParser
/*     */   extends BasicPullParser
/*     */ {
/*  25 */   private Time duration = Duration.DURATION_UNKNOWN;
/*  26 */   private Format format = null;
/*  27 */   private Track[] tracks = new Track[1];
/*  28 */   private int numBuffers = 4;
/*     */   private int bufferSize;
/*     */   private int dataSize;
/*  31 */   private SettableTime mediaTime = new SettableTime(0L);
/*     */   private int encoding;
/*     */   private String encodingString;
/*     */   private int sampleRate;
/*     */   private int samplesPerBlock;
/*     */   private int bytesPerSecond;
/*     */   private int blockSize;
/*     */   private long minLocation;
/*     */   private long maxLocation;
/*  40 */   private PullSourceStream stream = null;
/*     */   
/*     */   public static final int AU_SUN_MAGIC = 779316836;
/*     */   
/*     */   public static final int AU_SUN_INV_MAGIC = 1684960046;
/*     */   
/*     */   public static final int AU_DEC_MAGIC = 779314176;
/*     */   public static final int AU_DEC_INV_MAGIC = 6583086;
/*     */   public static final int AU_ULAW_8 = 1;
/*     */   public static final int AU_LINEAR_8 = 2;
/*     */   public static final int AU_LINEAR_16 = 3;
/*     */   public static final int AU_LINEAR_24 = 4;
/*     */   public static final int AU_LINEAR_32 = 5;
/*     */   public static final int AU_FLOAT = 6;
/*     */   public static final int AU_DOUBLE = 7;
/*     */   public static final int AU_ADPCM_G721 = 23;
/*     */   public static final int AU_ADPCM_G722 = 24;
/*     */   public static final int AU_ADPCM_G723_3 = 25;
/*     */   public static final int AU_ADPCM_G723_5 = 26;
/*     */   public static final int AU_ALAW_8 = 27;
/*  60 */   private static ContentDescriptor[] supportedFormat = new ContentDescriptor[] { new ContentDescriptor("audio.basic") };
/*     */   
/*     */   public ContentDescriptor[] getSupportedInputContentDescriptors() {
/*  63 */     return supportedFormat;
/*     */   }
/*     */ 
/*     */   
/*     */   public Track[] getTracks() throws IOException, BadHeaderException {
/*  68 */     if (this.tracks[0] != null) {
/*  69 */       return this.tracks;
/*     */     }
/*  71 */     this.stream = (PullSourceStream)this.streams[0];
/*  72 */     if (this.cacheStream != null)
/*     */     {
/*  74 */       this.cacheStream.setEnabledBuffering(false);
/*     */     }
/*  76 */     readHeader();
/*  77 */     if (this.cacheStream != null) {
/*  78 */       this.cacheStream.setEnabledBuffering(true);
/*     */     }
/*     */     
/*  81 */     this.minLocation = getLocation(this.stream);
/*  82 */     if (this.dataSize == -1) {
/*  83 */       this.maxLocation = Long.MAX_VALUE;
/*     */     } else {
/*  85 */       this.maxLocation = this.minLocation + this.dataSize;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     this.tracks[0] = (Track)new AuTrack((AudioFormat)this.format, true, new Time(0L), this.numBuffers, this.bufferSize, this.minLocation, this.maxLocation);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     return this.tracks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readHeader() throws IOException, BadHeaderException {
/*     */     boolean bool;
/* 109 */     int sampleSizeInBits, magic = readInt(this.stream, true);
/*     */     
/* 111 */     if (magic == 779316836 || magic == 779314176) {
/* 112 */       bool = true;
/* 113 */     } else if (magic == 1684960046 || magic == 6583086) {
/* 114 */       bool = false;
/*     */     } else {
/* 116 */       throw new BadHeaderException("Invalid magic number " + Integer.toHexString(magic));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 121 */     int headerSize = readInt(this.stream);
/*     */     
/* 123 */     if (headerSize < 24) {
/* 124 */       throw new BadHeaderException("AU Parser: header size should be atleast 24 but is " + headerSize);
/*     */     }
/*     */ 
/*     */     
/* 128 */     this.dataSize = readInt(this.stream);
/*     */     
/* 130 */     if (this.dataSize == -1) {
/*     */ 
/*     */       
/* 133 */       long contentLength = this.stream.getContentLength();
/* 134 */       if (contentLength != -1L) {
/* 135 */         this.dataSize = (int)(contentLength - headerSize);
/* 136 */         if (this.dataSize < 0) {
/* 137 */           this.dataSize = -1;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 142 */     int encoding = readInt(this.stream);
/*     */ 
/*     */     
/* 145 */     this.blockSize = -1;
/* 146 */     switch (encoding) {
/*     */       case 1:
/* 148 */         this.encodingString = "ULAW";
/* 149 */         sampleSizeInBits = 8;
/* 150 */         this.blockSize = 1;
/*     */         break;
/*     */       case 27:
/* 153 */         this.encodingString = "alaw";
/* 154 */         sampleSizeInBits = 8;
/* 155 */         this.blockSize = 1;
/*     */         break;
/*     */       case 2:
/* 158 */         this.encodingString = "LINEAR";
/* 159 */         sampleSizeInBits = 8;
/* 160 */         this.blockSize = 1;
/*     */         break;
/*     */       case 3:
/* 163 */         this.encodingString = "LINEAR";
/* 164 */         sampleSizeInBits = 16;
/* 165 */         this.blockSize = 2;
/*     */         break;
/*     */       case 4:
/* 168 */         this.encodingString = "LINEAR";
/* 169 */         sampleSizeInBits = 24;
/* 170 */         this.blockSize = 3;
/*     */         break;
/*     */       case 5:
/* 173 */         this.encodingString = "LINEAR";
/* 174 */         sampleSizeInBits = 32;
/* 175 */         this.blockSize = 4;
/*     */         break;
/*     */       case 6:
/* 178 */         this.encodingString = "float";
/* 179 */         sampleSizeInBits = 32;
/* 180 */         this.blockSize = 4;
/*     */         break;
/*     */       case 7:
/* 183 */         this.encodingString = "double";
/* 184 */         sampleSizeInBits = 64;
/* 185 */         this.blockSize = 8;
/*     */         break;
/*     */       case 23:
/* 188 */         this.encodingString = "??? what adpcm";
/* 189 */         sampleSizeInBits = 4;
/*     */         break;
/*     */       case 25:
/* 192 */         this.encodingString = "G723_3";
/* 193 */         sampleSizeInBits = 3;
/*     */         break;
/*     */       case 26:
/* 196 */         this.encodingString = "G723_5";
/* 197 */         sampleSizeInBits = 5;
/*     */         break;
/*     */       default:
/* 200 */         throw new BadHeaderException("Unsupported encoding: " + Integer.toHexString(encoding));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 205 */     int sampleRate = readInt(this.stream);
/*     */     
/* 207 */     if (sampleRate < 0) {
/* 208 */       throw new BadHeaderException("Negative Sample Rate " + sampleRate);
/*     */     }
/* 210 */     int channels = readInt(this.stream);
/*     */     
/* 212 */     if (channels < 1) {
/* 213 */       throw new BadHeaderException("Number of channels is " + channels);
/*     */     }
/* 215 */     if (this.blockSize != -1) {
/* 216 */       this.blockSize *= channels;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     skip(this.stream, headerSize - 24);
/*     */ 
/*     */     
/* 226 */     this.bytesPerSecond = channels * sampleSizeInBits * sampleRate / 8;
/*     */     
/* 228 */     int frameSizeInBytes = channels * sampleSizeInBits / 8;
/* 229 */     this.bufferSize = this.bytesPerSecond;
/*     */ 
/*     */ 
/*     */     
/* 233 */     if (this.dataSize != -1) {
/* 234 */       double durationSeconds = this.dataSize / this.bytesPerSecond;
/* 235 */       this.duration = new Time(durationSeconds);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 240 */     boolean signed = true;
/* 241 */     this.format = (Format)new AudioFormat(this.encodingString, sampleRate, sampleSizeInBits, channels, bool ? 1 : 0, signed ? 1 : 0, frameSizeInBytes * 8, -1.0D, Format.byteArray);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Time setPosition(Time where, int rounding) {
/* 257 */     if (!this.seekable) {
/* 258 */       return getMediaTime();
/*     */     }
/* 260 */     if (this.blockSize < 0)
/*     */     {
/*     */       
/* 263 */       return getMediaTime();
/*     */     }
/* 265 */     long time = where.getNanoseconds();
/*     */ 
/*     */     
/* 268 */     if (time < 0L) {
/* 269 */       time = 0L;
/*     */     }
/* 271 */     double newPosd = (time * this.bytesPerSecond) / 1.0E9D;
/* 272 */     double remainder = newPosd % this.blockSize;
/*     */     
/* 274 */     long newPos = (long)(newPosd - remainder);
/*     */     
/* 276 */     if (remainder > 0.0D) {
/* 277 */       switch (rounding) {
/*     */         case 1:
/* 279 */           newPos += this.blockSize;
/*     */           break;
/*     */         case 3:
/* 282 */           if (remainder > this.blockSize / 2.0D) {
/* 283 */             newPos += this.blockSize;
/*     */           }
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 291 */     newPos += this.minLocation;
/* 292 */     ((BasicTrack)this.tracks[0]).setSeekLocation(newPos);
/* 293 */     if (this.cacheStream != null) {
/* 294 */       synchronized (this) {
/*     */         
/* 296 */         this.cacheStream.abortRead();
/*     */       } 
/*     */     }
/* 299 */     return where;
/*     */   }
/*     */ 
/*     */   
/*     */   public Time getMediaTime() {
/* 304 */     long l1, seekLocation = ((BasicTrack)this.tracks[0]).getSeekLocation();
/* 305 */     if (seekLocation != -1L) {
/* 306 */       l1 = seekLocation - this.minLocation;
/*     */     } else {
/* 308 */       l1 = getLocation(this.stream) - this.minLocation;
/* 309 */     }  synchronized (this.mediaTime) {
/* 310 */       this.mediaTime.set(l1 / this.bytesPerSecond);
/*     */     } 
/* 312 */     return (Time)this.mediaTime;
/*     */   }
/*     */   
/*     */   public Time getDuration() {
/* 316 */     return this.duration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 324 */     return "Parser for AU file format";
/*     */   }
/*     */   
/*     */   class AuTrack
/*     */     extends BasicTrack {
/*     */     private double sampleRate;
/*     */     private float timePerFrame;
/*     */     private SettableTime frameToTime;
/*     */     private final AuParser this$0;
/*     */     
/*     */     AuTrack(AuParser this$0, AudioFormat format, boolean enabled, Time startTime, int numBuffers, int bufferSize, long minLocation, long maxLocation) {
/* 335 */       super(AuParser.this, (Format)format, enabled, AuParser.this.duration, startTime, numBuffers, bufferSize, AuParser.this.stream, minLocation, maxLocation);
/*     */       
/*     */       AuParser.this = AuParser.this;
/*     */       
/*     */       this.frameToTime = new SettableTime();
/* 340 */       double sampleRate = format.getSampleRate();
/* 341 */       int channels = format.getChannels();
/* 342 */       int sampleSizeInBits = format.getSampleSizeInBits();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 348 */       long durationNano = this.duration.getNanoseconds();
/*     */     }
/*     */ 
/*     */     
/*     */     AuTrack(AudioFormat format, boolean enabled, Time startTime, int numBuffers, int bufferSize) {
/* 353 */       this(format, enabled, startTime, numBuffers, bufferSize, 0L, Long.MAX_VALUE);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\parser\audio\AuParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */