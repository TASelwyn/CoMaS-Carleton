package com.sun.media.parser;

import com.sun.media.CircularBuffer;
import java.io.IOException;
import javax.media.Buffer;
import javax.media.Demultiplexer;
import javax.media.Format;
import javax.media.IncompatibleSourceException;
import javax.media.Time;
import javax.media.Track;
import javax.media.TrackListener;
import javax.media.protocol.DataSource;
import javax.media.protocol.PushDataSource;
import javax.media.protocol.PushSourceStream;
import javax.media.protocol.SourceStream;
import javax.media.protocol.SourceTransferHandler;

public class RawStreamParser extends RawParser {
  protected SourceStream[] streams;
  
  protected Track[] tracks = null;
  
  static final String NAME = "Raw stream parser";
  
  public String getName() {
    return "Raw stream parser";
  }
  
  public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
    if (!(source instanceof PushDataSource))
      throw new IncompatibleSourceException("DataSource not supported: " + source); 
    this.streams = (SourceStream[])((PushDataSource)source).getStreams();
    if (this.streams == null)
      throw new IOException("Got a null stream from the DataSource"); 
    if (this.streams.length == 0)
      throw new IOException("Got a empty stream array from the DataSource"); 
    if (!supports(this.streams))
      throw new IncompatibleSourceException("DataSource not supported: " + source); 
    this.source = source;
    this.streams = this.streams;
  }
  
  protected boolean supports(SourceStream[] streams) {
    return (streams[0] != null && streams[0] instanceof PushSourceStream);
  }
  
  public Track[] getTracks() {
    return this.tracks;
  }
  
  public void open() {
    if (this.tracks != null)
      return; 
    this.tracks = new Track[this.streams.length];
    for (int i = 0; i < this.streams.length; i++)
      this.tracks[i] = new FrameTrack(this, this, (PushSourceStream)this.streams[i], 5); 
  }
  
  public void close() {
    if (this.source != null) {
      try {
        this.source.stop();
        for (int i = 0; i < this.tracks.length; i++)
          ((FrameTrack)this.tracks[i]).stop(); 
        this.source.disconnect();
      } catch (IOException e) {}
      this.source = null;
    } 
  }
  
  public void start() throws IOException {
    this.source.start();
    for (int i = 0; i < this.tracks.length; i++)
      ((FrameTrack)this.tracks[i]).start(); 
  }
  
  public void stop() {
    try {
      this.source.stop();
      for (int i = 0; i < this.tracks.length; i++)
        ((FrameTrack)this.tracks[i]).stop(); 
    } catch (IOException e) {}
  }
  
  class FrameTrack implements Track, SourceTransferHandler {
    Demultiplexer parser;
    
    PushSourceStream pss;
    
    boolean enabled;
    
    CircularBuffer bufferQ;
    
    Format format;
    
    TrackListener listener;
    
    Integer stateReq;
    
    boolean stopped;
    
    private final RawStreamParser this$0;
    
    public FrameTrack(RawStreamParser this$0, Demultiplexer parser, PushSourceStream pss, int numOfBufs) {
      this.this$0 = this$0;
      this.enabled = true;
      this.format = null;
      this.stateReq = new Integer(0);
      this.stopped = true;
      this.pss = pss;
      pss.setTransferHandler(this);
      this.bufferQ = new CircularBuffer(numOfBufs);
    }
    
    public Format getFormat() {
      return this.format;
    }
    
    public void setEnabled(boolean t) {
      if (t) {
        this.pss.setTransferHandler(this);
      } else {
        this.pss.setTransferHandler(null);
      } 
      this.enabled = t;
    }
    
    public boolean isEnabled() {
      return this.enabled;
    }
    
    public Time getDuration() {
      return this.parser.getDuration();
    }
    
    public Time getStartTime() {
      return new Time(0L);
    }
    
    public void setTrackListener(TrackListener l) {
      this.listener = l;
    }
    
    public void readFrame(Buffer buffer) {
      Buffer filled;
      synchronized (this.stateReq) {
        if (this.stopped) {
          buffer.setDiscard(true);
          buffer.setFormat(this.format);
          return;
        } 
      } 
      synchronized (this.bufferQ) {
        while (!this.bufferQ.canRead()) {
          try {
            this.bufferQ.wait();
            synchronized (this.stateReq) {
              if (this.stopped) {
                buffer.setDiscard(true);
                buffer.setFormat(this.format);
                return;
              } 
            } 
          } catch (Exception e) {}
        } 
        filled = this.bufferQ.read();
        this.bufferQ.notifyAll();
      } 
      byte[] data = (byte[])filled.getData();
      filled.setData(buffer.getData());
      buffer.setData(data);
      buffer.setLength(filled.getLength());
      buffer.setFormat(this.format);
      buffer.setTimeStamp(-1L);
      synchronized (this.bufferQ) {
        this.bufferQ.readReport();
        this.bufferQ.notifyAll();
      } 
    }
    
    public void stop() {
      synchronized (this.stateReq) {
        this.stopped = true;
      } 
      synchronized (this.bufferQ) {
        this.bufferQ.notifyAll();
      } 
    }
    
    public void start() {
      synchronized (this.stateReq) {
        this.stopped = false;
      } 
      synchronized (this.bufferQ) {
        this.bufferQ.notifyAll();
      } 
    }
    
    public int mapTimeToFrame(Time t) {
      return -1;
    }
    
    public Time mapFrameToTime(int frameNumber) {
      return new Time(0L);
    }
    
    public void transferData(PushSourceStream pss) {
      Buffer buffer;
      synchronized (this.bufferQ) {
        while (!this.bufferQ.canWrite()) {
          try {
            this.bufferQ.wait();
          } catch (Exception e) {}
        } 
        buffer = this.bufferQ.getEmptyBuffer();
        this.bufferQ.notifyAll();
      } 
      int size = pss.getMinimumTransferSize();
      byte[] data;
      if ((data = (byte[])buffer.getData()) == null || data.length < size) {
        data = new byte[size];
        buffer.setData(data);
      } 
      try {
        int len = pss.read(data, 0, size);
        buffer.setLength(len);
      } catch (IOException e) {
        buffer.setDiscard(true);
      } 
      synchronized (this.bufferQ) {
        this.bufferQ.writeReport();
        this.bufferQ.notifyAll();
      } 
    }
  }
}
