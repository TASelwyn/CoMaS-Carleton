/*      */ package com.sun.media.parser.video;
/*      */ 
/*      */ import com.sun.media.format.WavAudioFormat;
/*      */ import com.sun.media.parser.BasicPullParser;
/*      */ import com.sun.media.vfw.BitMapInfo;
/*      */ import java.io.IOException;
/*      */ import javax.media.BadHeaderException;
/*      */ import javax.media.Buffer;
/*      */ import javax.media.Duration;
/*      */ import javax.media.Format;
/*      */ import javax.media.IncompatibleSourceException;
/*      */ import javax.media.Time;
/*      */ import javax.media.Track;
/*      */ import javax.media.TrackListener;
/*      */ import javax.media.format.AudioFormat;
/*      */ import javax.media.format.VideoFormat;
/*      */ import javax.media.protocol.CachedStream;
/*      */ import javax.media.protocol.ContentDescriptor;
/*      */ import javax.media.protocol.DataSource;
/*      */ import javax.media.protocol.PullSourceStream;
/*      */ import javax.media.protocol.Seekable;
/*      */ import javax.media.protocol.SourceStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class AviParser
/*      */   extends BasicPullParser
/*      */ {
/*   33 */   private static ContentDescriptor[] supportedFormat = new ContentDescriptor[] { new ContentDescriptor("video.x_msvideo") };
/*      */   
/*   35 */   private PullSourceStream stream = null;
/*      */   private CachedStream cacheStream;
/*      */   private Track[] tracks;
/*      */   private Seekable seekableStream;
/*   39 */   private int numSupportedTracks = 0;
/*      */   private int length;
/*   41 */   private int audioTrack = -1;
/*   42 */   private int videoTrack = -1;
/*   43 */   private int keyFrameTrack = -1;
/*      */   
/*      */   private static final int SIZE_OF_AVI_INDEX = 16;
/*      */   
/*      */   private static final int AVIH_HEADER_LENGTH = 56;
/*      */   
/*      */   private static final int STRH_HEADER_LENGTH = 56;
/*      */   
/*      */   private static final int STRF_VIDEO_HEADER_LENGTH = 40;
/*      */   private static final int STRF_AUDIO_HEADER_LENGTH = 16;
/*      */   static final int AVIF_HASINDEX = 16;
/*      */   static final int AVIF_MUSTUSEINDEX = 32;
/*      */   static final int AVIF_ISINTERLEAVED = 256;
/*      */   static final int AVIF_WASCAPTUREFILE = 65536;
/*      */   static final int AVIF_COPYRIGHTED = 131072;
/*      */   static final int AVIF_KEYFRAME = 16;
/*      */   static final String AUDIO = "auds";
/*      */   static final String VIDEO = "vids";
/*      */   static final String LISTRECORDCHUNK = "rec ";
/*      */   static final String VIDEO_MAGIC = "dc";
/*      */   static final String VIDEO_MAGIC_JPEG = "db";
/*      */   static final String VIDEO_MAGIC_IV32a = "iv";
/*      */   static final String VIDEO_MAGIC_IV32b = "32";
/*      */   static final String VIDEO_MAGIC_IV31 = "31";
/*      */   static final String VIDEO_MAGIC_CVID = "id";
/*      */   static final String AUDIO_MAGIC = "wb";
/*   69 */   private int usecPerFrame = 0;
/*   70 */   private long nanoSecPerFrame = 0L;
/*      */   private int maxBytesPerSecond;
/*      */   private int paddingGranularity;
/*      */   private int flags;
/*   74 */   private int totalFrames = 0;
/*      */   private int initialFrames;
/*   76 */   private int numTracks = 0;
/*      */   private int suggestedBufferSize;
/*      */   private int width;
/*      */   private int height;
/*      */   private TrakList[] trakList;
/*      */   private int idx1MinimumChunkOffset;
/*   82 */   private int moviOffset = 0;
/*   83 */   private Time duration = Duration.DURATION_UNKNOWN;
/*      */   
/*      */   private boolean moviChunkSeen = false;
/*      */   private boolean idx1ChunkSeen = false;
/*   87 */   private int maxAudioChunkIndex = 0;
/*   88 */   private int maxVideoChunkIndex = 0;
/*      */   
/*   90 */   private int extraHeaderLength = 0;
/*   91 */   private byte[] codecSpecificHeader = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   97 */   private Object seekSync = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean supports(SourceStream[] streams) {
/*  104 */     return this.seekable;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
/*  110 */     super.setSource(source);
/*  111 */     this.stream = (PullSourceStream)this.streams[0];
/*  112 */     this.seekableStream = (Seekable)this.streams[0];
/*      */   }
/*      */   
/*      */   public ContentDescriptor[] getSupportedInputContentDescriptors() {
/*  116 */     return supportedFormat;
/*      */   }
/*      */ 
/*      */   
/*      */   public Track[] getTracks() throws IOException, BadHeaderException {
/*  121 */     if (this.tracks != null) {
/*  122 */       return this.tracks;
/*      */     }
/*  124 */     if (this.seekableStream == null) {
/*  125 */       return new Track[0];
/*      */     }
/*      */     
/*  128 */     readHeader();
/*  129 */     if (!this.moviChunkSeen) {
/*  130 */       throw new BadHeaderException("No movi chunk");
/*      */     }
/*      */     
/*  133 */     if (!this.idx1ChunkSeen)
/*      */     {
/*  135 */       throw new BadHeaderException("Currently files with no idx1 chunk are not supported");
/*      */     }
/*      */     
/*  138 */     if (this.numTracks <= 0) {
/*  139 */       throw new BadHeaderException("Error parsing header");
/*      */     }
/*      */     
/*  142 */     this.tracks = new Track[this.numTracks];
/*      */ 
/*      */ 
/*      */     
/*  146 */     for (int i = 0; i < this.tracks.length; i++) {
/*      */       
/*  148 */       TrakList trakInfo = this.trakList[i];
/*  149 */       if (trakInfo.trackType.equals("auds")) {
/*  150 */         this.tracks[i] = new AudioTrack(this, trakInfo);
/*  151 */       } else if (trakInfo.trackType.equals("vids")) {
/*      */ 
/*      */         
/*  154 */         this.tracks[i] = new VideoTrack(this, trakInfo);
/*      */       } 
/*      */     } 
/*  157 */     return this.tracks;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readHeader() throws IOException, BadHeaderException {
/*  164 */     String magicRIFF = readString(this.stream);
/*  165 */     if (!magicRIFF.equals("RIFF")) {
/*  166 */       throw new BadHeaderException("AVI Parser: expected string RIFF, got " + magicRIFF);
/*      */     }
/*      */ 
/*      */     
/*  170 */     this.length = readInt(this.stream, false);
/*  171 */     this.length += 8;
/*      */     
/*  173 */     String magicAVI = readString(this.stream);
/*  174 */     if (!magicAVI.equals("AVI ")) {
/*  175 */       throw new BadHeaderException("AVI Parser: expected string AVI, got " + magicAVI);
/*      */     }
/*      */ 
/*      */     
/*  179 */     int currentTrack = 0;
/*  180 */     while (getLocation(this.stream) <= (this.length - 12)) {
/*  181 */       String next = readString(this.stream);
/*  182 */       int subchunkLength = readInt(this.stream, false);
/*  183 */       if (next.equals("LIST")) {
/*  184 */         String subchunk = readString(this.stream);
/*  185 */         if (subchunk.equals("hdrl")) {
/*  186 */           parseHDRL(); continue;
/*  187 */         }  if (subchunk.equals("strl")) {
/*  188 */           parseSTRL(subchunkLength, currentTrack);
/*  189 */           currentTrack++; continue;
/*  190 */         }  if (subchunk.equals("movi")) {
/*  191 */           parseMOVI(subchunkLength - 4);
/*      */           
/*      */           continue;
/*      */         } 
/*  195 */         skip(this.stream, subchunkLength - 4); continue;
/*      */       } 
/*  197 */       if (next.equals("idx1")) {
/*  198 */         parseIDX1(subchunkLength); continue;
/*      */       } 
/*  200 */       skip(this.stream, subchunkLength);
/*  201 */       if ((subchunkLength & 0x1) > 0) {
/*  202 */         skip(this.stream, 1);
/*      */       }
/*      */     } 
/*  205 */     if (this.totalFrames != 0 && this.usecPerFrame != 0) {
/*  206 */       this.duration = new Time(this.usecPerFrame * this.totalFrames * 1000L);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private long getLocation() {
/*  213 */     return getLocation(this.stream);
/*      */   }
/*      */ 
/*      */   
/*      */   private void parseHDRL() throws BadHeaderException {
/*      */     try {
/*  219 */       String next = readString(this.stream);
/*  220 */       if (!next.equals("avih")) {
/*  221 */         throw new BadHeaderException("AVI Parser: expected string AVIH, got " + next);
/*      */       }
/*      */       
/*  224 */       int headerLength = readInt(this.stream, false);
/*  225 */       parseAVIH(headerLength);
/*  226 */       this.trakList = new TrakList[this.numTracks];
/*      */     } catch (IOException e) {
/*  228 */       throw new BadHeaderException("IOException when parsing hdrl");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseSTRL(int length, int currentTrack) throws BadHeaderException {
/*      */     try {
/*  236 */       if (currentTrack >= this.trakList.length) {
/*  237 */         throw new BadHeaderException("inconsistent number of strl atoms");
/*      */       }
/*      */       
/*  240 */       length -= 12;
/*  241 */       while (length >= 12) {
/*  242 */         String subchunkid = readString(this.stream);
/*  243 */         int subchunkLength = readInt(this.stream, false);
/*  244 */         if (subchunkid.equals("strh")) {
/*  245 */           parseSTRH(subchunkLength, currentTrack);
/*  246 */         } else if (subchunkid.equals("strf")) {
/*  247 */           if (this.trakList[currentTrack] == null) {
/*  248 */             throw new BadHeaderException("strf doesn't have a strh atom preceding it");
/*      */           }
/*  250 */           parseSTRF(subchunkLength, currentTrack);
/*      */         }
/*      */         else {
/*      */           
/*  254 */           if ((subchunkLength & 0x1) > 0)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  260 */             subchunkLength++;
/*      */           }
/*  262 */           skip(this.stream, subchunkLength);
/*      */         } 
/*  264 */         length -= subchunkLength + 4;
/*      */       } 
/*      */     } catch (IOException e) {
/*  267 */       throw new BadHeaderException("IOException when parsing hdrl");
/*      */     } 
/*      */   }
/*      */   
/*      */   private void parseSTRH(int length, int currentTrack) throws BadHeaderException {
/*      */     try {
/*  273 */       if (length < 56) {
/*  274 */         throw new BadHeaderException("strh: header length should be atleast 56 but is " + length);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  279 */       this.trakList[currentTrack] = new TrakList();
/*  280 */       (this.trakList[currentTrack]).trackType = readString(this.stream);
/*  281 */       (this.trakList[currentTrack]).streamHandler = readString(this.stream);
/*  282 */       (this.trakList[currentTrack]).flags = readInt(this.stream, false);
/*  283 */       (this.trakList[currentTrack]).priority = readInt(this.stream, false);
/*  284 */       (this.trakList[currentTrack]).initialFrames = readInt(this.stream, false);
/*  285 */       (this.trakList[currentTrack]).scale = readInt(this.stream, false);
/*  286 */       (this.trakList[currentTrack]).rate = readInt(this.stream, false);
/*  287 */       (this.trakList[currentTrack]).start = readInt(this.stream, false);
/*  288 */       (this.trakList[currentTrack]).length = readInt(this.stream, false);
/*  289 */       (this.trakList[currentTrack]).suggestedBufferSize = readInt(this.stream, false);
/*  290 */       (this.trakList[currentTrack]).quality = readInt(this.stream, false);
/*  291 */       (this.trakList[currentTrack]).sampleSize = readInt(this.stream, false);
/*      */       
/*  293 */       skip(this.stream, 8);
/*  294 */       if (length - 56 > 0) {
/*  295 */         skip(this.stream, length - 56);
/*      */       }
/*      */     } catch (IOException e) {
/*  298 */       throw new BadHeaderException("IOException when parsing hdrl");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void parseSTRF(int length, int currentTrack) throws BadHeaderException {
/*      */     try {
/*  305 */       String trackType = (this.trakList[currentTrack]).trackType;
/*  306 */       if (trackType.equals("vids")) {
/*  307 */         Video video = new Video();
/*  308 */         video.size = readInt(this.stream, false);
/*  309 */         video.width = readInt(this.stream, false);
/*  310 */         video.height = readInt(this.stream, false);
/*  311 */         video.planes = readShort(this.stream, false);
/*  312 */         video.depth = readShort(this.stream, false);
/*      */ 
/*      */         
/*  315 */         byte[] intArray = new byte[4];
/*  316 */         readBytes(this.stream, intArray, 4);
/*  317 */         if (intArray[0] > 32) {
/*  318 */           video.compressor = new String(intArray);
/*      */         } else {
/*  320 */           switch (intArray[0]) {
/*      */             case 0:
/*  322 */               video.compressor = "rgb";
/*      */               break;
/*      */             case 1:
/*  325 */               video.compressor = "rle8";
/*      */               break;
/*      */             case 2:
/*  328 */               video.compressor = "rle4";
/*      */               break;
/*      */             case 3:
/*  331 */               video.compressor = "rgb";
/*      */               break;
/*      */           } 
/*      */ 
/*      */         
/*      */         } 
/*  337 */         BitMapInfo bmi = new BitMapInfo();
/*  338 */         bmi.biWidth = video.width;
/*  339 */         bmi.biHeight = video.height;
/*  340 */         bmi.biPlanes = video.planes;
/*  341 */         bmi.biBitCount = video.depth;
/*  342 */         bmi.fourcc = new String(video.compressor);
/*  343 */         video.bitMapInfo = bmi;
/*  344 */         bmi.biSizeImage = readInt(this.stream, false);
/*  345 */         bmi.biXPelsPerMeter = readInt(this.stream, false);
/*  346 */         bmi.biYPelsPerMeter = readInt(this.stream, false);
/*  347 */         bmi.biClrUsed = readInt(this.stream, false);
/*  348 */         bmi.biClrImportant = readInt(this.stream, false);
/*      */ 
/*      */         
/*  351 */         if (length - 40 > 0) {
/*  352 */           bmi.extraSize = length - 40;
/*  353 */           bmi.extraBytes = new byte[bmi.extraSize];
/*  354 */           readBytes(this.stream, bmi.extraBytes, bmi.extraSize);
/*      */         } 
/*      */         
/*  357 */         (this.trakList[currentTrack]).media = video;
/*  358 */         (this.trakList[currentTrack]).media.maxSampleSize = (this.trakList[currentTrack]).suggestedBufferSize;
/*      */         
/*  360 */         this.videoTrack = currentTrack;
/*  361 */       } else if (trackType.equals("auds")) {
/*  362 */         Audio audio = new Audio();
/*      */         
/*  364 */         audio.formatTag = readShort(this.stream, false);
/*  365 */         audio.channels = readShort(this.stream, false);
/*  366 */         audio.sampleRate = readInt(this.stream, false);
/*  367 */         audio.avgBytesPerSec = readInt(this.stream, false);
/*  368 */         audio.blockAlign = readShort(this.stream, false);
/*  369 */         audio.bitsPerSample = readShort(this.stream, false);
/*      */         
/*  371 */         int remainingFormatSize = length - 16;
/*      */         
/*  373 */         this.codecSpecificHeader = null;
/*  374 */         int extraFieldsSize = 0;
/*  375 */         if (remainingFormatSize >= 2) {
/*  376 */           extraFieldsSize = readShort(this.stream, false);
/*  377 */           remainingFormatSize -= 2;
/*      */           
/*  379 */           if (extraFieldsSize > 0) {
/*  380 */             this.codecSpecificHeader = new byte[extraFieldsSize];
/*  381 */             readBytes(this.stream, this.codecSpecificHeader, this.codecSpecificHeader.length);
/*  382 */             remainingFormatSize -= extraFieldsSize;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  388 */           if (audio.formatTag == 2 || audio.formatTag == 17 || audio.formatTag == 49) {
/*      */ 
/*      */ 
/*      */             
/*  392 */             if (extraFieldsSize < 2) {
/*  393 */               throw new BadHeaderException("samplesPerBlock field not available for encoding" + audio.formatTag);
/*      */             }
/*      */ 
/*      */             
/*  397 */             audio.samplesPerBlock = BasicPullParser.parseShortFromArray(this.codecSpecificHeader, false);
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/*  402 */         if (remainingFormatSize < 0) {
/*  403 */           throw new BadHeaderException("Avi Parser: incorrect headersize in the STRF");
/*      */         }
/*      */         
/*  406 */         if (remainingFormatSize > 0) {
/*  407 */           skip(this.stream, length - 16);
/*      */         }
/*  409 */         (this.trakList[currentTrack]).media = audio;
/*  410 */         this.audioTrack = currentTrack;
/*      */       } else {
/*  412 */         throw new BadHeaderException("strf: unsupported stream type " + trackType);
/*      */       } 
/*      */     } catch (IOException e) {
/*      */       
/*  416 */       throw new BadHeaderException("IOException when parsing hdrl");
/*      */     } 
/*      */   }
/*      */   
/*      */   private void parseAVIH(int length) throws BadHeaderException {
/*      */     try {
/*  422 */       if (length < 56) {
/*  423 */         throw new BadHeaderException("avih: header size is not 56");
/*      */       }
/*      */       
/*  426 */       this.usecPerFrame = readInt(this.stream, false);
/*  427 */       this.nanoSecPerFrame = (this.usecPerFrame * 1000);
/*  428 */       this.maxBytesPerSecond = readInt(this.stream, false);
/*  429 */       this.paddingGranularity = readInt(this.stream, false);
/*  430 */       this.flags = readInt(this.stream, false);
/*  431 */       this.totalFrames = readInt(this.stream, false);
/*  432 */       this.initialFrames = readInt(this.stream, false);
/*  433 */       this.numTracks = readInt(this.stream, false);
/*  434 */       this.suggestedBufferSize = readInt(this.stream, false);
/*  435 */       this.width = readInt(this.stream, false);
/*  436 */       this.height = readInt(this.stream, false);
/*  437 */       skip(this.stream, 16);
/*  438 */       if (length - 56 > 0)
/*  439 */         skip(this.stream, length - 56); 
/*      */     } catch (IOException e) {
/*  441 */       throw new BadHeaderException("IOException when parsing hdrl");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void parseIDX1(int length) throws BadHeaderException {
/*      */     try {
/*  448 */       if (!this.moviChunkSeen) {
/*  449 */         throw new BadHeaderException("idx1 chunk appears before movi chunk");
/*      */       }
/*      */       
/*  452 */       int numIndices = length / 16;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  458 */       for (int i = 0; i < this.numTracks; i++) {
/*  459 */         if (this.trakList[i] == null) {
/*  460 */           throw new BadHeaderException("Bad file format");
/*      */         }
/*  462 */         (this.trakList[i]).chunkInfo = new AVIIndexEntry[numIndices];
/*  463 */         if ((this.trakList[i]).trackType.equals("vids")) {
/*  464 */           (this.trakList[i]).keyFrames = new int[numIndices];
/*      */         }
/*      */       } 
/*      */       
/*  468 */       this.idx1MinimumChunkOffset = Integer.MAX_VALUE;
/*      */       
/*  470 */       for (int j = 0; j < numIndices; j++) {
/*  471 */         String id = readString(this.stream);
/*  472 */         if (id.equals("rec ")) {
/*      */           
/*  474 */           readInt(this.stream, false);
/*  475 */           readInt(this.stream, false);
/*  476 */           readInt(this.stream, false);
/*      */         } else {
/*      */           int streamNumber;
/*      */           
/*      */           try {
/*  481 */             streamNumber = Integer.parseInt(id.substring(0, 2));
/*      */           } catch (NumberFormatException e) {
/*      */             
/*  484 */             readInt(this.stream, false);
/*  485 */             readInt(this.stream, false);
/*  486 */             readInt(this.stream, false);
/*      */           } 
/*      */ 
/*      */           
/*  490 */           if (streamNumber < 0 || streamNumber >= this.numTracks) {
/*  491 */             throw new BadHeaderException("index chunk has illegal stream # " + streamNumber);
/*      */           }
/*      */           
/*  494 */           int flag = readInt(this.stream, false);
/*  495 */           int chunkOffset = readInt(this.stream, false);
/*  496 */           int chunkLength = readInt(this.stream, false);
/*      */           
/*  498 */           AVIIndexEntry[] chunkInfo = (this.trakList[streamNumber]).chunkInfo;
/*  499 */           int index = (this.trakList[streamNumber]).maxChunkIndex;
/*      */           
/*  501 */           chunkInfo[index] = new AVIIndexEntry();
/*  502 */           (chunkInfo[index]).id = id;
/*  503 */           (chunkInfo[index]).flag = flag;
/*  504 */           (chunkInfo[index]).chunkOffset = chunkOffset;
/*  505 */           (chunkInfo[index]).chunkLength = chunkLength;
/*      */           
/*  507 */           if ((this.trakList[streamNumber]).trackType.equals("auds")) {
/*  508 */             int c = (this.trakList[streamNumber]).tmpCumulativeChunkLength += chunkLength;
/*  509 */             (chunkInfo[index]).cumulativeChunkLength = c;
/*      */           } 
/*      */           
/*  512 */           if ((this.trakList[streamNumber]).trackType.equals("vids") && (
/*  513 */             flag & 0x10) > 0) {
/*  514 */             int keyFrameIndex = (this.trakList[streamNumber]).numKeyFrames;
/*  515 */             (this.trakList[streamNumber]).keyFrames[keyFrameIndex] = index;
/*  516 */             (this.trakList[streamNumber]).numKeyFrames++;
/*      */           } 
/*      */           
/*  519 */           (this.trakList[streamNumber]).maxChunkIndex++;
/*      */           
/*  521 */           if (chunkOffset < this.idx1MinimumChunkOffset) {
/*  522 */             this.idx1MinimumChunkOffset = chunkOffset;
/*      */           }
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  529 */       for (int k = 0; k < this.numTracks; k++) {
/*  530 */         if ((this.trakList[k]).trackType.equals("vids")) {
/*  531 */           int numKeyFrames = (this.trakList[k]).numKeyFrames;
/*  532 */           if (numKeyFrames > 0)
/*  533 */             this.keyFrameTrack = k; 
/*  534 */           int maxChunkIndex = (this.trakList[k]).maxChunkIndex;
/*  535 */           if (numKeyFrames > 0 && numKeyFrames < maxChunkIndex) {
/*  536 */             (this.trakList[k]).indexToKeyframeIndex = buildIndexToKeyFrameIndexTable((this.trakList[k]).keyFrames, numKeyFrames, maxChunkIndex);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*  541 */           (this.trakList[k]).keyFrames = null;
/*      */         } 
/*      */       } 
/*      */       
/*  545 */       if (this.idx1MinimumChunkOffset >= this.moviOffset)
/*      */       {
/*  547 */         this.moviOffset = 0;
/*      */       }
/*  549 */       this.moviOffset += 8;
/*      */     } catch (IOException e) {
/*  551 */       throw new BadHeaderException("IOException when parsing IDX1");
/*      */     } 
/*  553 */     this.idx1ChunkSeen = true;
/*      */   }
/*      */   
/*      */   private void parseMOVI(int length) throws BadHeaderException {
/*      */     try {
/*  558 */       this.moviChunkSeen = true;
/*  559 */       if ((this.flags & 0x10) > 0)
/*      */       {
/*  561 */         this.moviOffset = (int)getLocation(this.stream) - 4;
/*  562 */         skip(this.stream, length);
/*      */       }
/*      */     
/*      */     } catch (IOException e) {
/*      */       
/*  567 */       throw new BadHeaderException("IOException when parsing movi");
/*      */     } 
/*      */   }
/*      */   
/*      */   public Time setPosition(Time where, int rounding) {
/*  572 */     int keyframeNum = -1;
/*  573 */     if (this.keyFrameTrack != -1 && this.tracks[this.keyFrameTrack].isEnabled()) {
/*      */ 
/*      */       
/*  576 */       TrakList trakInfo = this.trakList[this.keyFrameTrack];
/*  577 */       Track track = this.tracks[this.keyFrameTrack];
/*  578 */       int frameNum = track.mapTimeToFrame(where);
/*  579 */       keyframeNum = frameNum;
/*      */ 
/*      */       
/*  582 */       if (trakInfo.indexToKeyframeIndex.length > frameNum) {
/*  583 */         keyframeNum = trakInfo.indexToKeyframeIndex[frameNum];
/*      */       }
/*      */       
/*  586 */       if (keyframeNum != frameNum) {
/*  587 */         where = track.mapFrameToTime(keyframeNum);
/*      */       }
/*      */     } 
/*  590 */     for (int i = 0; i < this.numTracks; i++) {
/*  591 */       if (!this.tracks[i].isEnabled()) {
/*      */         continue;
/*      */       }
/*  594 */       int chunkNumber = 0;
/*  595 */       int offsetWithinChunk = 0;
/*      */       try {
/*  597 */         if (i == this.keyFrameTrack) {
/*  598 */           chunkNumber = keyframeNum;
/*      */           
/*      */           continue;
/*      */         } 
/*  602 */         TrakList trakInfo = this.trakList[i];
/*  603 */         if (trakInfo.trackType.equals("vids")) {
/*  604 */           if (this.usecPerFrame != 0) {
/*  605 */             chunkNumber = (int)(where.getNanoseconds() / this.nanoSecPerFrame);
/*  606 */             if (chunkNumber < 0) {
/*  607 */               chunkNumber = 0;
/*  608 */             } else if (chunkNumber >= trakInfo.maxChunkIndex) {
/*      */             
/*      */             } 
/*      */           }  continue;
/*  612 */         }  if (trakInfo.trackType.equals("auds"))
/*  613 */         { int bytePos = (int)(where.getSeconds() * ((Audio)trakInfo.media).avgBytesPerSec);
/*      */           
/*  615 */           if (bytePos < 0) {
/*  616 */             bytePos = 0;
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*  621 */           if (trakInfo.maxChunkIndex == 1)
/*  622 */           { if (bytePos >= (trakInfo.chunkInfo[0]).chunkLength)
/*  623 */             { chunkNumber = trakInfo.maxChunkIndex; }
/*      */             else
/*      */             
/*  626 */             { chunkNumber = 0;
/*  627 */               offsetWithinChunk = bytePos;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  639 */               if ((offsetWithinChunk & 0x1) > 0)
/*  640 */                 offsetWithinChunk--;  }  continue; }  chunkNumber = trakInfo.getChunkNumber(bytePos); if (chunkNumber >= trakInfo.maxChunkIndex) continue;  int approx = (trakInfo.chunkInfo[chunkNumber]).cumulativeChunkLength - (trakInfo.chunkInfo[chunkNumber]).chunkLength; offsetWithinChunk = bytePos - approx; } else { continue; }  if ((offsetWithinChunk & 0x1) > 0) offsetWithinChunk--;
/*      */       
/*      */       } finally {}
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  652 */     return where;
/*      */   }
/*      */   
/*      */   public Time getMediaTime() {
/*  656 */     return null;
/*      */   }
/*      */   
/*      */   public Time getDuration() {
/*  660 */     return this.duration;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  668 */     return "Parser for avi file format";
/*      */   }
/*      */   
/*      */   private boolean isSupported(String trackType) {
/*  672 */     return (trackType.equals("vids") || trackType.equals("auds"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int[] buildIndexToKeyFrameIndexTable(int[] syncSamples, int numKeyFrames, int numberOfSamples) {
/*  680 */     int i, syncSampleMapping[] = new int[numberOfSamples];
/*  681 */     int index = 0;
/*      */     
/*  683 */     if (syncSamples[0] != 0) {
/*      */ 
/*      */       
/*  686 */       i = syncSampleMapping[0] = 0;
/*      */     } else {
/*  688 */       i = syncSampleMapping[0] = 0;
/*  689 */       index++;
/*      */     } 
/*      */     
/*  692 */     for (; index < numKeyFrames; index++) {
/*  693 */       int next = syncSamples[index];
/*  694 */       for (int j = i + 1; j < next; j++) {
/*  695 */         syncSampleMapping[j] = i;
/*      */       }
/*      */       
/*  698 */       syncSampleMapping[next] = next;
/*      */       
/*  700 */       i = next;
/*      */     } 
/*  702 */     int lastSyncFrame = syncSamples[numKeyFrames - 1];
/*  703 */     for (index = lastSyncFrame + 1; index < numberOfSamples; index++) {
/*  704 */       syncSampleMapping[index] = lastSyncFrame;
/*      */     }
/*  706 */     return syncSampleMapping;
/*      */   } private abstract class Media { int maxSampleSize; private final AviParser this$0;
/*      */     private Media(AviParser this$0) {
/*  709 */       AviParser.this = AviParser.this;
/*      */     }
/*      */     abstract Format createFormat(); }
/*      */   private class Audio extends Media { int formatTag; int channels; int sampleRate; int avgBytesPerSec; int blockAlign; int bitsPerSample; int samplesPerBlock; AudioFormat format; private final AviParser this$0;
/*      */     private Audio(AviParser this$0) {
/*  714 */       AviParser.this = AviParser.this;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  722 */       this.format = null;
/*      */     } Format createFormat() {
/*      */       boolean bool;
/*  725 */       if (this.format != null)
/*  726 */         return (Format)this.format; 
/*  727 */       String encodingString = (String)WavAudioFormat.formatMapper.get(new Integer(this.formatTag));
/*      */       
/*  729 */       if (encodingString == null) {
/*  730 */         encodingString = "unknown";
/*      */       }
/*      */ 
/*      */       
/*  734 */       if (this.bitsPerSample > 8) {
/*  735 */         bool = true;
/*      */       } else {
/*  737 */         bool = false;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  753 */       this.format = (AudioFormat)new WavAudioFormat(encodingString, this.sampleRate, this.bitsPerSample, this.channels, this.blockAlign * 8, this.avgBytesPerSec, 0, bool ? 1 : 0, -1.0F, Format.byteArray, AviParser.this.codecSpecificHeader);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  766 */       return (Format)this.format;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  771 */       System.out.println("Audio Media: " + this.format);
/*  772 */       System.out.println("Number of channels " + this.channels);
/*  773 */       System.out.println("average bytes per second " + this.avgBytesPerSec);
/*  774 */       System.out.println("sampleRate " + this.sampleRate);
/*  775 */       System.out.println("blockAlign " + this.blockAlign);
/*  776 */       System.out.println("bitsPerSample " + this.bitsPerSample);
/*  777 */       System.out.println("formatTag " + this.formatTag);
/*  778 */       return super.toString();
/*      */     } }
/*      */   private class Video extends Media { int size; int width; int height; int planes; int depth; String compressor; VideoFormat format; BitMapInfo bitMapInfo; private final AviParser this$0;
/*      */     private Video(AviParser this$0) {
/*  782 */       AviParser.this = AviParser.this;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  789 */       this.format = null;
/*  790 */       this.bitMapInfo = null;
/*      */     }
/*      */     
/*      */     Format createFormat() {
/*  794 */       if (this.format != null) {
/*  795 */         return (Format)this.format;
/*      */       }
/*  797 */       if (AviParser.this.usecPerFrame != 0) {
/*  798 */         this.format = this.bitMapInfo.createVideoFormat(Format.byteArray, (float)(1.0D / AviParser.this.usecPerFrame * 1000000.0D));
/*      */       } else {
/*      */         
/*  801 */         this.format = this.bitMapInfo.createVideoFormat(Format.byteArray);
/*      */       } 
/*      */ 
/*      */       
/*  805 */       return (Format)this.format;
/*      */     }
/*      */     
/*      */     public String toString() {
/*  809 */       System.out.println("size is " + this.size);
/*  810 */       System.out.println("width is " + this.width);
/*  811 */       System.out.println("height is " + this.height);
/*  812 */       System.out.println("planes is " + this.planes);
/*  813 */       System.out.println("depth is " + this.depth);
/*  814 */       System.out.println("compressor is " + this.compressor);
/*      */       
/*  816 */       return super.toString();
/*      */     } }
/*      */   private class TrakList { Time duration; String trackType; String streamHandler; int flags; int priority; int initialFrames; int scale; int rate; int start; int length;
/*      */     int suggestedBufferSize;
/*      */     
/*      */     private TrakList(AviParser this$0) {
/*  822 */       AviParser.this = AviParser.this;
/*  823 */       this.duration = Duration.DURATION_UNKNOWN;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  842 */       this.supported = true;
/*      */       
/*  844 */       this.chunkInfo = new AviParser.AVIIndexEntry[0];
/*  845 */       this.maxChunkIndex = 0;
/*      */       
/*  847 */       this.indexToKeyframeIndex = new int[0];
/*  848 */       this.keyFrames = new int[0];
/*      */ 
/*      */       
/*  851 */       this.numKeyFrames = 0;
/*  852 */       this.tmpCumulativeChunkLength = 0;
/*      */     }
/*      */     int quality; int sampleSize; AviParser.Media media; boolean supported; AviParser.AVIIndexEntry[] chunkInfo; int maxChunkIndex; int[] indexToKeyframeIndex; int[] keyFrames; int numKeyFrames; int tmpCumulativeChunkLength; private final AviParser this$0;
/*      */     
/*      */     int getChunkNumber(int offset) {
/*  857 */       for (int i = 0; i < this.maxChunkIndex; i++) {
/*  858 */         if (offset < (this.chunkInfo[i]).cumulativeChunkLength) {
/*  859 */           return i;
/*      */         }
/*      */       } 
/*  862 */       return this.maxChunkIndex;
/*      */     } }
/*      */ 
/*      */   
/*      */   private abstract class MediaTrack implements Track { protected AviParser.TrakList trakInfo;
/*      */     private boolean enabled;
/*      */     private int numBuffers;
/*      */     private Format format;
/*      */     private long sequenceNumber;
/*      */     private int chunkNumber;
/*      */     protected int useChunkNumber;
/*      */     protected int offsetWithinChunk;
/*      */     protected int useOffsetWithinChunk;
/*      */     private AviParser parser;
/*      */     private AviParser.AVIIndexEntry indexEntry;
/*      */     private Object header;
/*      */     private TrackListener listener;
/*      */     private final AviParser this$0;
/*      */     
/*      */     MediaTrack(AviParser this$0, AviParser.TrakList trakInfo) {
/*  882 */       this.this$0 = this$0; this.enabled = true; this.numBuffers = 4; this.sequenceNumber = 0L; this.chunkNumber = 0; this.useChunkNumber = 0; this.offsetWithinChunk = -1; this.useOffsetWithinChunk = 0; this.parser = this.this$0; this.header = null;
/*  883 */       this.trakInfo = trakInfo;
/*  884 */       this.format = trakInfo.media.createFormat();
/*      */     }
/*      */ 
/*      */     
/*      */     public void setTrackListener(TrackListener l) {
/*  889 */       this.listener = l;
/*      */     }
/*      */ 
/*      */     
/*      */     public Format getFormat() {
/*  894 */       return this.format;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setEnabled(boolean t) {
/*  899 */       this.enabled = t;
/*      */     }
/*      */     
/*      */     public boolean isEnabled() {
/*  903 */       return this.enabled;
/*      */     }
/*      */     
/*      */     public Time getDuration() {
/*  907 */       return this.trakInfo.duration;
/*      */     }
/*      */ 
/*      */     
/*      */     public Time getStartTime() {
/*  912 */       return new Time(0L);
/*      */     }
/*      */     
/*      */     synchronized void setChunkNumberAndOffset(int number, int offset) {
/*  916 */       this.chunkNumber = number;
/*  917 */       this.offsetWithinChunk = offset;
/*      */     }
/*      */     
/*      */     public void readFrame(Buffer buffer) {
/*      */       byte[] arrayOfByte;
/*  922 */       if (buffer == null) {
/*      */         return;
/*      */       }
/*  925 */       if (!this.enabled) {
/*  926 */         buffer.setDiscard(true);
/*      */         
/*      */         return;
/*      */       } 
/*  930 */       synchronized (this) {
/*  931 */         if (this.offsetWithinChunk == -1) {
/*  932 */           this.useOffsetWithinChunk = 0;
/*      */         } else {
/*  934 */           this.useOffsetWithinChunk = this.offsetWithinChunk;
/*  935 */           this.offsetWithinChunk = -1;
/*      */         } 
/*  937 */         this.useChunkNumber = this.chunkNumber;
/*      */       } 
/*      */ 
/*      */       
/*  941 */       if (this.useChunkNumber >= this.trakInfo.maxChunkIndex || this.useChunkNumber < 0) {
/*      */         
/*  943 */         buffer.setLength(0);
/*  944 */         buffer.setEOM(true);
/*      */         return;
/*      */       } 
/*  947 */       buffer.setFormat(this.format);
/*      */       
/*  949 */       this.indexEntry = this.trakInfo.chunkInfo[this.useChunkNumber];
/*      */ 
/*      */       
/*  952 */       int chunkLength = this.indexEntry.chunkLength;
/*      */       
/*  954 */       Object obj = buffer.getData();
/*      */ 
/*      */       
/*  957 */       buffer.setHeader(new Integer(this.indexEntry.flag));
/*      */       
/*  959 */       if (obj == null || !(obj instanceof byte[]) || ((byte[])obj).length < chunkLength) {
/*      */ 
/*      */         
/*  962 */         arrayOfByte = new byte[chunkLength];
/*  963 */         buffer.setData(arrayOfByte);
/*      */       } else {
/*  965 */         arrayOfByte = (byte[])obj;
/*      */       } 
/*      */       
/*      */       try {
/*      */         int actualBytesRead;
/*  970 */         synchronized (this.this$0.seekSync) {
/*  971 */           this.this$0.seekableStream.seek((this.indexEntry.chunkOffset + this.this$0.moviOffset + this.useOffsetWithinChunk));
/*      */ 
/*      */           
/*  974 */           actualBytesRead = this.parser.readBytes(this.this$0.stream, arrayOfByte, chunkLength - this.useOffsetWithinChunk);
/*      */           
/*  976 */           this.offsetWithinChunk = 0;
/*  977 */           buffer.setTimeStamp(getTimeStamp());
/*      */         } 
/*  979 */         buffer.setLength(actualBytesRead);
/*  980 */         long frameDuration = -1L;
/*  981 */         if (this.trakInfo.trackType.equals("vids")) {
/*  982 */           if (this.this$0.nanoSecPerFrame > 0L)
/*  983 */             frameDuration = this.this$0.nanoSecPerFrame; 
/*  984 */           if (this.trakInfo.indexToKeyframeIndex.length == 0 || this.useChunkNumber == this.trakInfo.indexToKeyframeIndex[this.useChunkNumber])
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  990 */             buffer.setFlags(buffer.getFlags() | 0x10);
/*      */           }
/*      */         } 
/*      */         
/*  994 */         buffer.setDuration(frameDuration);
/*      */         
/*  996 */         buffer.setSequenceNumber(++this.sequenceNumber);
/*      */       } catch (IOException e) {
/*      */         
/*  999 */         buffer.setLength(0);
/* 1000 */         buffer.setEOM(true);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1006 */       synchronized (this) {
/* 1007 */         if (this.chunkNumber == this.useChunkNumber) {
/* 1008 */           this.chunkNumber++;
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*      */     abstract void doReadFrame(Buffer param1Buffer);
/*      */     
/*      */     public int mapTimeToFrame(Time t) {
/* 1016 */       return Integer.MAX_VALUE;
/*      */     }
/*      */     
/*      */     public Time mapFrameToTime(int frameNumber) {
/* 1020 */       return Track.TIME_UNKNOWN;
/*      */     }
/*      */     
/*      */     abstract long getTimeStamp(); }
/*      */   
/*      */   private class AudioTrack extends MediaTrack {
/*      */     int channels;
/*      */     int avgBytesPerSec;
/*      */     AviParser.AVIIndexEntry[] chunkInfo;
/*      */     private final AviParser this$0;
/*      */     
/*      */     AudioTrack(AviParser this$0, AviParser.TrakList trakInfo) {
/* 1032 */       super(this$0, trakInfo); this.this$0 = this$0;
/* 1033 */       this.channels = ((AviParser.Audio)trakInfo.media).channels;
/* 1034 */       this.avgBytesPerSec = ((AviParser.Audio)trakInfo.media).avgBytesPerSec;
/* 1035 */       this.chunkInfo = trakInfo.chunkInfo;
/*      */     }
/*      */ 
/*      */     
/*      */     void doReadFrame(Buffer buffer) {}
/*      */     
/*      */     long getTimeStamp() {
/* 1042 */       if (this.avgBytesPerSec > 0) {
/* 1043 */         long bytes = this.useOffsetWithinChunk;
/* 1044 */         if (this.useChunkNumber > 0) {
/* 1045 */           bytes += (this.chunkInfo[this.useChunkNumber - 1]).cumulativeChunkLength;
/*      */         }
/*      */ 
/*      */         
/* 1049 */         return (long)(((float)bytes / this.avgBytesPerSec) * 1.0E9D);
/*      */       } 
/* 1051 */       return 0L;
/*      */     }
/*      */   }
/*      */   
/*      */   private class VideoTrack extends MediaTrack {
/*      */     int needBufferSize;
/*      */     boolean variableSampleSize;
/*      */     private final AviParser this$0;
/*      */     
/*      */     VideoTrack(AviParser this$0, AviParser.TrakList trakInfo) {
/* 1061 */       super(this$0, trakInfo);
/*      */       this.this$0 = this$0;
/*      */       this.variableSampleSize = true;
/*      */     }
/*      */ 
/*      */     
/*      */     void doReadFrame(Buffer buffer) {}
/*      */     
/*      */     long getTimeStamp() {
/* 1070 */       return this.useChunkNumber * this.this$0.usecPerFrame * 1000L;
/*      */     }
/*      */     
/*      */     public int mapTimeToFrame(Time t) {
/* 1074 */       if (this.this$0.nanoSecPerFrame <= 0L) {
/* 1075 */         return Integer.MAX_VALUE;
/*      */       }
/* 1077 */       if (t.getNanoseconds() < 0L) {
/* 1078 */         return Integer.MAX_VALUE;
/*      */       }
/*      */       
/* 1081 */       int chunkNumber = (int)(t.getNanoseconds() / this.this$0.nanoSecPerFrame);
/*      */       
/* 1083 */       if (chunkNumber >= this.trakInfo.maxChunkIndex) {
/* 1084 */         return this.trakInfo.maxChunkIndex - 1;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1092 */       return chunkNumber;
/*      */     }
/*      */     
/*      */     public Time mapFrameToTime(int frameNumber) {
/* 1096 */       if (frameNumber < 0 || frameNumber >= this.trakInfo.maxChunkIndex) {
/* 1097 */         return Track.TIME_UNKNOWN;
/*      */       }
/* 1099 */       long time = frameNumber * this.this$0.nanoSecPerFrame;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1104 */       return new Time(time);
/*      */     } }
/*      */   private class AVIIndexEntry { public String id; public int flag;
/*      */     public int chunkOffset;
/*      */     public int chunkLength;
/*      */     public int cumulativeChunkLength;
/*      */     private final AviParser this$0;
/*      */     
/*      */     private AVIIndexEntry(AviParser this$0) {
/* 1113 */       AviParser.this = AviParser.this;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1119 */       this.cumulativeChunkLength = 0;
/*      */     } }
/*      */ 
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\parser\video\AviParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */