package com.sun.media.parser.video;

import com.sun.media.parser.BasicPullParser;
import com.sun.media.util.SettableTime;
import java.awt.Dimension;
import java.io.IOException;
import javax.media.BadHeaderException;
import javax.media.Buffer;
import javax.media.Duration;
import javax.media.Format;
import javax.media.IncompatibleSourceException;
import javax.media.Time;
import javax.media.Track;
import javax.media.TrackListener;
import javax.media.format.AudioFormat;
import javax.media.format.RGBFormat;
import javax.media.format.VideoFormat;
import javax.media.format.YUVFormat;
import javax.media.protocol.CachedStream;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.DataSource;
import javax.media.protocol.PullSourceStream;
import javax.media.protocol.Seekable;
import javax.media.protocol.SourceStream;

public class QuicktimeParser extends BasicPullParser {
  private final boolean enableHintTrackSupport = true;
  
  private static ContentDescriptor[] supportedFormat = new ContentDescriptor[] { new ContentDescriptor("video.quicktime") };
  
  private PullSourceStream stream = null;
  
  private Track[] tracks;
  
  private Seekable seekableStream;
  
  private boolean mdatAtomPresent = false;
  
  private boolean moovAtomPresent = false;
  
  public static final int MVHD_ATOM_SIZE = 100;
  
  public static final int TKHD_ATOM_SIZE = 84;
  
  public static final int MDHD_ATOM_SIZE = 24;
  
  public static final int MIN_HDLR_ATOM_SIZE = 24;
  
  public static final int MIN_STSD_ATOM_SIZE = 8;
  
  public static final int MIN_STTS_ATOM_SIZE = 8;
  
  public static final int MIN_STSC_ATOM_SIZE = 8;
  
  public static final int MIN_STSZ_ATOM_SIZE = 8;
  
  public static final int MIN_STCO_ATOM_SIZE = 8;
  
  public static final int MIN_STSS_ATOM_SIZE = 8;
  
  public static final int MIN_VIDEO_SAMPLE_DATA_SIZE = 70;
  
  public static final int MIN_AUDIO_SAMPLE_DATA_SIZE = 20;
  
  public static final int TRACK_ENABLED = 1;
  
  public static final int TRACK_IN_MOVIE = 2;
  
  public static final int TRACK_IN_PREVIEW = 4;
  
  public static final int TRACK_IN_POSTER = 8;
  
  public static final String VIDEO = "vide";
  
  public static final String AUDIO = "soun";
  
  public static final String HINT = "hint";
  
  private static final int DATA_SELF_REFERENCE_FLAG = 1;
  
  private static final int HINT_NOP_IGNORE = 0;
  
  private static final int HINT_IMMEDIATE_DATA = 1;
  
  private static final int HINT_SAMPLE_DATA = 2;
  
  private static final int HINT_SAMPLE_DESCRIPTION = 3;
  
  private MovieHeader movieHeader = new MovieHeader();
  
  private int numTracks = 0;
  
  private int numSupportedTracks = 0;
  
  private int numberOfHintTracks = 0;
  
  private static int MAX_TRACKS_SUPPORTED = 100;
  
  private TrakList[] trakList = new TrakList[MAX_TRACKS_SUPPORTED];
  
  private TrakList currentTrack;
  
  private int keyFrameTrack = -1;
  
  private SettableTime mediaTime = new SettableTime(0L);
  
  private int hintAudioTrackNum = -1;
  
  private boolean debug = false;
  
  private boolean debug1 = false;
  
  private boolean debug2 = false;
  
  private Object seekSync = new Object();
  
  private int tmpIntBufferSize = 16384;
  
  private byte[] tmpBuffer = new byte[this.tmpIntBufferSize * 4];
  
  protected boolean supports(SourceStream[] s) {
    return this.seekable;
  }
  
  public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
    super.setSource(source);
    this.stream = (PullSourceStream)this.streams[0];
    this.seekableStream = (Seekable)this.streams[0];
  }
  
  private CachedStream getCacheStream() {
    return this.cacheStream;
  }
  
  public ContentDescriptor[] getSupportedInputContentDescriptors() {
    return supportedFormat;
  }
  
  public Track[] getTracks() throws IOException, BadHeaderException {
    if (this.tracks != null)
      return this.tracks; 
    if (this.seekableStream == null)
      return new Track[0]; 
    if (this.cacheStream != null)
      this.cacheStream.setEnabledBuffering(false); 
    readHeader();
    if (this.cacheStream != null)
      this.cacheStream.setEnabledBuffering(true); 
    this.tracks = new Track[this.numSupportedTracks];
    int index = 0;
    for (int i = 0; i < this.numSupportedTracks; i++) {
      TrakList trakInfo = this.trakList[i];
      if (trakInfo.trackType.equals("soun")) {
        this.tracks[i] = new AudioTrack(this, trakInfo);
      } else if (trakInfo.trackType.equals("vide")) {
        this.tracks[i] = new VideoTrack(this, trakInfo);
      } 
    } 
    for (int j = 0; j < this.numSupportedTracks; j++) {
      TrakList trakInfo = this.trakList[j];
      if (trakInfo.trackType.equals("hint")) {
        int trackBeingHinted = trakInfo.trackIdOfTrackBeingHinted;
        for (int k = 0; k < this.numTracks; k++) {
          if (trackBeingHinted == (this.trakList[k]).id) {
            trakInfo.indexOfTrackBeingHinted = k;
            String hintedTrackType = (this.trakList[k]).trackType;
            String encodingOfHintedTrack = (this.trakList[trakInfo.indexOfTrackBeingHinted]).media.encoding;
            if (encodingOfHintedTrack.equals("agsm"))
              encodingOfHintedTrack = "gsm"; 
            String rtpEncoding = encodingOfHintedTrack + "/rtp";
            if (hintedTrackType.equals("soun")) {
              Audio audio = (Audio)(this.trakList[k]).media;
              this.hintAudioTrackNum = j;
              int channels = audio.channels;
              int frameSizeInBytes = audio.frameSizeInBits / 8;
              int samplesPerBlock = audio.samplesPerBlock;
              int sampleRate = audio.sampleRate;
              ((Hint)trakInfo.media).format = (Format)new AudioFormat(rtpEncoding, sampleRate, 8, channels);
              this.tracks[j] = new HintAudioTrack(this, trakInfo, channels, rtpEncoding, frameSizeInBytes, samplesPerBlock, sampleRate);
              break;
            } 
            if (hintedTrackType.equals("vide")) {
              int indexOfTrackBeingHinted = trakInfo.indexOfTrackBeingHinted;
              TrakList sampleTrakInfo = null;
              if (indexOfTrackBeingHinted >= 0)
                sampleTrakInfo = this.trakList[indexOfTrackBeingHinted]; 
              int width = 0;
              int height = 0;
              if (sampleTrakInfo != null) {
                Video sampleTrakVideo = (Video)sampleTrakInfo.media;
                width = sampleTrakVideo.width;
                height = sampleTrakVideo.height;
              } 
              if (width > 0 && height > 0)
                ((Hint)trakInfo.media).format = (Format)new VideoFormat(rtpEncoding, new Dimension(width, height), -1, null, -1.0F); 
              HintVideoTrack hintVideoTrack = new HintVideoTrack(this, trakInfo);
              this.tracks[j] = hintVideoTrack;
            } 
            break;
          } 
        } 
      } 
    } 
    return this.tracks;
  }
  
  private void readHeader() throws IOException, BadHeaderException {
    do {
    
    } while (parseAtom());
    if (!this.moovAtomPresent)
      throw new BadHeaderException("moov atom not present"); 
    if (!this.mdatAtomPresent)
      throw new BadHeaderException("mdat atom not present"); 
    for (int i = 0; i < this.numSupportedTracks; i++) {
      TrakList trak = this.trakList[i];
      if (trak.buildSyncTable())
        this.keyFrameTrack = i; 
      trak.buildSamplePerChunkTable();
      if (!trak.trackType.equals("soun")) {
        trak.buildSampleOffsetTable();
        trak.buildStartTimeAndDurationTable();
        float frameRate = (float)(trak.numberOfSamples / trak.duration.getSeconds());
        trak.media.frameRate = frameRate;
      } 
      trak.buildCumulativeSamplePerChunkTable();
      trak.media.createFormat();
    } 
  }
  
  public Time setPosition(Time where, int rounding) {
    double time = where.getSeconds();
    if (time < 0.0D)
      time = 0.0D; 
    int keyT;
    if (((keyT = this.keyFrameTrack) != -1 && this.tracks[this.keyFrameTrack].isEnabled()) || ((keyT = this.hintAudioTrackNum) != -1 && this.tracks[this.hintAudioTrackNum].isEnabled())) {
      TrakList trakInfo = this.trakList[keyT];
      int index = trakInfo.time2Index(time);
      if (index < 0) {
        ((MediaTrack)this.tracks[keyT]).setSampleIndex(trakInfo.numberOfSamples + 1);
      } else {
        int j;
        if (keyT == this.keyFrameTrack) {
          if (index >= trakInfo.syncSampleMapping.length)
            index = trakInfo.syncSampleMapping.length - 1; 
          if (trakInfo.syncSampleMapping != null) {
            j = trakInfo.syncSampleMapping[index];
            double newtime = (trakInfo.index2TimeAndDuration(j)).startTime;
            time = newtime;
          } else {
            j = index;
          } 
        } else {
          j = index;
          double newtime = (trakInfo.index2TimeAndDuration(j)).startTime;
          time = newtime;
        } 
        ((MediaTrack)this.tracks[keyT]).setSampleIndex(j);
      } 
    } 
    for (int i = 0; i < this.numSupportedTracks; i++) {
      if (i != keyT)
        if (this.tracks[i].isEnabled()) {
          TrakList trakInfo = this.trakList[i];
          int index = trakInfo.time2Index(time);
          if (trakInfo.trackType.equals("vide") || (trakInfo.trackType.equals("hint") && this.tracks[i] instanceof HintVideoTrack)) {
            if (index < 0) {
              ((MediaTrack)this.tracks[i]).setSampleIndex(trakInfo.numberOfSamples + 1);
            } else {
              int j;
              if (trakInfo.syncSampleMapping != null) {
                j = trakInfo.syncSampleMapping[index];
              } else {
                j = index;
              } 
              ((MediaTrack)this.tracks[i]).setSampleIndex(j);
            } 
          } else if (index < 0) {
            ((MediaTrack)this.tracks[i]).setChunkNumber(trakInfo.numberOfChunks + 1);
          } else {
            int j;
            ((MediaTrack)this.tracks[i]).setSampleIndex(index);
            int chunkNumber = trakInfo.index2Chunk(index);
            if (chunkNumber != 0) {
              if (trakInfo.constantSamplesPerChunk == -1) {
                j = index - trakInfo.samplesPerChunk[chunkNumber - 1];
              } else {
                j = index - chunkNumber * trakInfo.constantSamplesPerChunk;
              } 
            } else {
              j = index;
            } 
            ((AudioTrack)this.tracks[i]).setChunkNumberAndSampleOffset(chunkNumber, j);
          } 
        }  
    } 
    if (this.cacheStream != null)
      synchronized (this) {
        this.cacheStream.abortRead();
      }  
    synchronized (this.mediaTime) {
      this.mediaTime.set(time);
    } 
    return (Time)this.mediaTime;
  }
  
  public Time getMediaTime() {
    return null;
  }
  
  public Time getDuration() {
    return this.movieHeader.duration;
  }
  
  public String getName() {
    return "Parser for quicktime file format";
  }
  
  private boolean parseAtom() throws BadHeaderException {
    boolean readSizeField = false;
    try {
      int atomSize = readInt(this.stream);
      readSizeField = true;
      String atom = readString(this.stream);
      if (atomSize < 8)
        throw new BadHeaderException(atom + ": Bad Atom size " + atomSize); 
      if (atom.equals("moov"))
        return parseMOOV(atomSize - 8); 
      if (atom.equals("mdat"))
        return parseMDAT(atomSize - 8); 
      skipAtom(atom + " [not implemented]", atomSize - 8);
      return true;
    } catch (IOException e) {
      if (!readSizeField)
        return false; 
      throw new BadHeaderException("Unexpected End of Media");
    } 
  }
  
  private void skipAtom(String atom, int size) throws IOException {
    if (this.debug2)
      System.out.println("skip unsupported atom " + atom); 
    skip(this.stream, size);
  }
  
  private boolean parseMOOV(int moovSize) throws BadHeaderException {
    boolean trakAtomPresent = false;
    try {
      this.moovAtomPresent = true;
      long moovMax = getLocation(this.stream) + moovSize;
      int remainingSize = moovSize;
      int atomSize = readInt(this.stream);
      String atom = readString(this.stream);
      if (atomSize < 8)
        throw new BadHeaderException(atom + ": Bad Atom size " + atomSize); 
      if (!atom.equals("mvhd")) {
        if (atom.equals("cmov"))
          throw new BadHeaderException("Compressed movie headers are not supported"); 
        throw new BadHeaderException("Expected mvhd atom but got " + atom);
      } 
      parseMVHD(atomSize - 8);
      remainingSize -= atomSize;
      while (remainingSize > 0) {
        atomSize = readInt(this.stream);
        atom = readString(this.stream);
        if (atom.equals("trak")) {
          if (this.trakList[this.numSupportedTracks] == null)
            this.trakList[this.numSupportedTracks] = this.currentTrack = new TrakList(); 
          if (parseTRAK(atomSize - 8))
            this.numSupportedTracks++; 
          trakAtomPresent = true;
          this.numTracks++;
        } else if (atom.equals("ctab")) {
          parseCTAB(atomSize - 8);
        } else {
          skipAtom(atom + " [atom in moov: not implemented]", atomSize - 8);
        } 
        remainingSize -= atomSize;
      } 
      if (!trakAtomPresent)
        throw new BadHeaderException("trak atom not present in trak atom container"); 
      return !this.mdatAtomPresent;
    } catch (IOException e) {
      throw new BadHeaderException("IOException when parsing the header");
    } 
  }
  
  private boolean parseMDAT(int size) throws BadHeaderException {
    try {
      this.mdatAtomPresent = true;
      this.movieHeader.mdatStart = getLocation(this.stream);
      this.movieHeader.mdatSize = size;
      if (!this.moovAtomPresent) {
        skip(this.stream, size);
        return true;
      } 
      return false;
    } catch (IOException e) {
      throw new BadHeaderException("Got IOException when seeking past MDAT atom");
    } 
  }
  
  private void parseMVHD(int size) throws BadHeaderException {
    try {
      if (size != 100)
        throw new BadHeaderException("mvhd atom: header size is incorrect"); 
      skip(this.stream, 12);
      this.movieHeader.timeScale = readInt(this.stream);
      int duration = readInt(this.stream);
      this.movieHeader.duration = new Time(duration / this.movieHeader.timeScale);
      int preferredRate = readInt(this.stream);
      int preferredVolume = readShort(this.stream);
      skip(this.stream, 10);
      skip(this.stream, 36);
      int previewTime = readInt(this.stream);
      int previewDuration = readInt(this.stream);
      int posterTime = readInt(this.stream);
      int selectionTime = readInt(this.stream);
      int selectionDuration = readInt(this.stream);
      int currentTime = readInt(this.stream);
      int nextTrackID = readInt(this.stream);
    } catch (IOException e) {
      throw new BadHeaderException("Got IOException when seeking past MVHD atom");
    } 
  }
  
  private boolean parseTRAK(int trakSize) throws BadHeaderException {
    boolean mdiaAtomPresent = false;
    boolean supported = false;
    try {
      int remainingSize = trakSize;
      int atomSize = readInt(this.stream);
      String atom = readString(this.stream);
      if (atomSize < 8)
        throw new BadHeaderException(atom + ": Bad Atom size " + atomSize); 
      if (!atom.equals("tkhd"))
        throw new BadHeaderException("Expected tkhd atom but got " + atom); 
      parseTKHD(atomSize - 8);
      remainingSize -= atomSize;
      while (remainingSize > 0) {
        atomSize = readInt(this.stream);
        atom = readString(this.stream);
        if (atom.equals("mdia")) {
          supported = parseMDIA(atomSize - 8);
          mdiaAtomPresent = true;
        } else if (atom.equals("tref")) {
          parseTREF(atomSize - 8);
        } else {
          skipAtom(atom + " [atom in trak: not implemented]", atomSize - 8);
        } 
        remainingSize -= atomSize;
      } 
    } catch (IOException e) {
      throw new BadHeaderException("Got IOException when seeking past TRAK atom");
    } 
    if (!mdiaAtomPresent)
      throw new BadHeaderException("mdia atom not present in trak atom container"); 
    if (supported && this.currentTrack.media == null)
      supported = false; 
    return supported;
  }
  
  private void parseCTAB(int ctabSize) throws BadHeaderException {
    try {
      skip(this.stream, ctabSize);
    } catch (IOException e) {
      throw new BadHeaderException("....");
    } 
  }
  
  private void parseTKHD(int tkhdSize) throws BadHeaderException {
    try {
      if (tkhdSize != 84)
        throw new BadHeaderException("mvhd atom: header size is incorrect"); 
      int iVersionPlusFlag = readInt(this.stream);
      this.currentTrack.flag = iVersionPlusFlag & 0xFFFFFF;
      skip(this.stream, 8);
      this.currentTrack.id = readInt(this.stream);
      skip(this.stream, 4);
      int duration = readInt(this.stream);
      this.currentTrack.duration = new Time(duration / this.movieHeader.timeScale);
      skip(this.stream, tkhdSize - 4 - 8 - 4 - 4 - 4);
    } catch (IOException e) {
      throw new BadHeaderException("Got IOException when seeking past TKHD atom");
    } 
  }
  
  private boolean parseMDIA(int mdiaSize) throws BadHeaderException {
    boolean hdlrAtomPresent = false;
    boolean minfAtomPresent = false;
    try {
      this.currentTrack.trackType = null;
      int remainingSize = mdiaSize;
      int atomSize = readInt(this.stream);
      String atom = readString(this.stream);
      if (atomSize < 8)
        throw new BadHeaderException(atom + ": Bad Atom size " + atomSize); 
      if (!atom.equals("mdhd"))
        throw new BadHeaderException("Expected mdhd atom but got " + atom); 
      parseMDHD(atomSize - 8);
      remainingSize -= atomSize;
      while (remainingSize > 0) {
        atomSize = readInt(this.stream);
        atom = readString(this.stream);
        if (atom.equals("hdlr")) {
          parseHDLR(atomSize - 8);
          hdlrAtomPresent = true;
        } else if (atom.equals("minf")) {
          if (this.currentTrack.trackType == null)
            throw new BadHeaderException("In MDIA atom container minf atom appears before hdlr"); 
          if (this.currentTrack.supported) {
            parseMINF(atomSize - 8);
          } else {
            skipAtom(atom + " [atom in mdia] as trackType " + this.currentTrack.trackType + " is not supported", atomSize - 8);
          } 
          minfAtomPresent = true;
        } else {
          skipAtom(atom + " [atom in mdia: not implemented]", atomSize - 8);
        } 
        remainingSize -= atomSize;
      } 
      if (!hdlrAtomPresent)
        throw new BadHeaderException("hdlr atom not present in mdia atom container"); 
      if (!minfAtomPresent)
        throw new BadHeaderException("minf atom not present in mdia atom container"); 
      return this.currentTrack.supported;
    } catch (IOException e) {
      throw new BadHeaderException("Got IOException when seeking past MDIA atom");
    } 
  }
  
  private void parseMDHD(int mdhdSize) throws BadHeaderException {
    try {
      if (mdhdSize != 24)
        throw new BadHeaderException("mdhd atom: header size is incorrect"); 
      skip(this.stream, 12);
      int timeScale = readInt(this.stream);
      int duration = readInt(this.stream);
      this.currentTrack.mediaDuration = new Time(duration / timeScale);
      this.currentTrack.mediaTimeScale = timeScale;
      skip(this.stream, 4);
    } catch (IOException e) {
      throw new BadHeaderException("Got IOException when seeking past MDHD atom");
    } 
  }
  
  private void parseHDLR(int hdlrSize) throws BadHeaderException {
    try {
      if (hdlrSize < 24)
        throw new BadHeaderException("hdlr atom: header size is incorrect"); 
      skip(this.stream, 8);
      this.currentTrack.trackType = readString(this.stream);
      this.currentTrack.supported = isSupported(this.currentTrack.trackType);
      skip(this.stream, hdlrSize - 8 - 4);
    } catch (IOException e) {
      throw new BadHeaderException("Got IOException when seeking past HDLR atom");
    } 
  }
  
  private void parseTREF(int size) throws BadHeaderException {
    try {
      int childAtomSize = readInt(this.stream);
      size -= 4;
      String atom = readString(this.stream);
      size -= 4;
      if (atom.equalsIgnoreCase("hint")) {
        this.currentTrack.trackIdOfTrackBeingHinted = readInt(this.stream);
        size -= 4;
      } 
      skip(this.stream, size);
    } catch (IOException e) {
      throw new BadHeaderException("Got IOException when seeking past HDLR atom");
    } 
  }
  
  private void parseMINF(int minfSize) throws BadHeaderException {
    boolean hdlrAtomPresent = false;
    try {
      int remainingSize = minfSize;
      int atomSize = readInt(this.stream);
      String atom = readString(this.stream);
      if (atomSize < 8)
        throw new BadHeaderException(atom + ": Bad Atom size " + atomSize); 
      if (!atom.endsWith("hd"))
        throw new BadHeaderException("Expected media information header atom but got " + atom); 
      skipAtom(atom + " [atom in minf: not implemented]", atomSize - 8);
      remainingSize -= atomSize;
      while (remainingSize > 0) {
        atomSize = readInt(this.stream);
        atom = readString(this.stream);
        if (atom.equals("hdlr")) {
          skipAtom(atom + " [atom in minf: not implemented]", atomSize - 8);
          hdlrAtomPresent = true;
        } else if (atom.equals("dinf")) {
          parseDINF(atomSize - 8);
        } else if (atom.equals("stbl")) {
          parseSTBL(atomSize - 8);
        } else {
          skipAtom(atom + " [atom in minf: not implemented]", atomSize - 8);
        } 
        remainingSize -= atomSize;
      } 
      if (!hdlrAtomPresent)
        throw new BadHeaderException("hdlr atom not present in minf atom container"); 
    } catch (IOException e) {
      throw new BadHeaderException("Got IOException when seeking past MINF atom");
    } 
  }
  
  private void parseDINF(int dinfSize) throws BadHeaderException {
    try {
      int remainingSize = dinfSize;
      while (remainingSize > 0) {
        int atomSize = readInt(this.stream);
        String atom = readString(this.stream);
        if (atom.equals("dref")) {
          parseDREF(atomSize - 8);
        } else {
          skipAtom(atom + " [Unknown atom in dinf]", atomSize - 8);
        } 
        remainingSize -= atomSize;
      } 
    } catch (IOException e) {
      throw new BadHeaderException("Got IOException when seeking past DIMF atom");
    } 
  }
  
  private void parseDREF(int drefSize) throws BadHeaderException {
    try {
      skip(this.stream, 4);
      int numEntries = readInt(this.stream);
      for (int i = 0; i < numEntries; i++) {
        int drefEntrySize = readInt(this.stream);
        int type = readInt(this.stream);
        int versionPlusFlag = readInt(this.stream);
        skip(this.stream, drefEntrySize - 12);
        if ((versionPlusFlag & 0x1) <= 0)
          throw new BadHeaderException("Only self contained Quicktime movies are supported"); 
      } 
    } catch (IOException e) {
      throw new BadHeaderException("Got IOException when seeking past DREF atom");
    } 
  }
  
  private void parseSTBL(int stblSize) throws BadHeaderException {
    try {
      int remainingSize = stblSize;
      while (remainingSize > 0) {
        int atomSize = readInt(this.stream);
        String atom = readString(this.stream);
        if (atom.equals("stsd")) {
          parseSTSD(atomSize - 8);
        } else if (atom.equals("stts")) {
          parseSTTS(atomSize - 8);
        } else if (atom.equals("stss")) {
          parseSTSS(atomSize - 8);
        } else if (atom.equals("stsc")) {
          parseSTSC(atomSize - 8);
        } else if (atom.equals("stsz")) {
          parseSTSZ(atomSize - 8);
        } else if (atom.equals("stco")) {
          parseSTCO(atomSize - 8);
        } else if (atom.equals("stsh")) {
          skipAtom(atom + " [not implemented]", atomSize - 8);
        } else {
          skipAtom(atom + " [UNKNOWN atom in stbl: ignored]", atomSize - 8);
        } 
        remainingSize -= atomSize;
      } 
    } catch (IOException e) {
      throw new BadHeaderException("Got IOException when seeking past STBL atom");
    } 
  }
  
  private void parseSTSD(int stsdSize) throws BadHeaderException {
    try {
      if (stsdSize < 8)
        throw new BadHeaderException("stsd atom: header size is incorrect"); 
      skip(this.stream, 4);
      int numEntries = readInt(this.stream);
      if (numEntries > 1);
      for (int i = 0; i < numEntries; i++) {
        int sampleDescriptionSize = readInt(this.stream);
        String encoding = readString(this.stream);
        if (i != 0) {
          skip(this.stream, sampleDescriptionSize - 8);
        } else {
          skip(this.stream, 6);
          if (this.currentTrack.trackType.equals("vide")) {
            this.currentTrack.media = parseVideoSampleData(encoding, sampleDescriptionSize - 4 - 4 - 6);
          } else if (this.currentTrack.trackType.equals("soun")) {
            this.currentTrack.media = parseAudioSampleData(encoding, sampleDescriptionSize - 4 - 4 - 6);
          } else if (this.currentTrack.trackType.equals("hint")) {
            this.numberOfHintTracks++;
            this.currentTrack.media = parseHintSampleData(encoding, sampleDescriptionSize - 4 - 4 - 6);
          } else {
            skip(this.stream, sampleDescriptionSize - 4 - 4 - 6);
          } 
        } 
      } 
    } catch (IOException e) {
      throw new BadHeaderException("Got IOException when seeking past STSD atom");
    } 
  }
  
  private Video parseVideoSampleData(String encoding, int dataSize) throws IOException, BadHeaderException {
    skip(this.stream, 2);
    skip(this.stream, 16);
    Video video = new Video();
    video.encoding = encoding;
    video.width = readShort(this.stream);
    video.height = readShort(this.stream);
    skip(this.stream, 14);
    skip(this.stream, 32);
    video.pixelDepth = readShort(this.stream);
    video.colorTableID = readShort(this.stream);
    int colorTableSize = 0;
    if (video.colorTableID == 0) {
      colorTableSize = readInt(this.stream);
      skip(this.stream, colorTableSize - 4);
    } 
    skip(this.stream, dataSize - 2 - 70 - -colorTableSize);
    return video;
  }
  
  private Audio parseAudioSampleData(String encoding, int dataSize) throws IOException, BadHeaderException {
    skip(this.stream, 2);
    skip(this.stream, 8);
    Audio audio = new Audio();
    audio.encoding = encoding;
    audio.channels = readShort(this.stream);
    audio.bitsPerSample = readShort(this.stream);
    skip(this.stream, 4);
    int sampleRate = readInt(this.stream);
    audio.sampleRate = this.currentTrack.mediaTimeScale;
    skip(this.stream, dataSize - 2 - 20);
    return audio;
  }
  
  private Hint parseHintSampleData(String encoding, int dataSize) throws IOException, BadHeaderException {
    if (!encoding.equals("rtp "))
      System.err.println("Hint track Data Format is not rtp"); 
    Hint hint = new Hint();
    int dataReferenceIndex = readShort(this.stream);
    int hintTrackVersion = readShort(this.stream);
    if (hintTrackVersion == 0) {
      System.err.println("Hint Track version #0 is not supported");
      System.err.println("Use QuickTimePro to convert it to version #1");
      this.currentTrack.supported = false;
      if (dataSize - 2 - 2 > 0)
        skip(this.stream, dataSize - 2 - 2); 
      return hint;
    } 
    int lastCompatibleHintTrackVersion = readShort(this.stream);
    int maxPacketSize = readInt(this.stream);
    this.currentTrack.maxPacketSize = maxPacketSize;
    int remaining = dataSize - 2 - 2 - 2 - 4;
    if (this.debug1) {
      System.out.println("dataReferenceIndex is " + dataReferenceIndex);
      System.out.println("hintTrackVersion is " + hintTrackVersion);
      System.out.println("lastCompatibleHintTrackVersion is " + lastCompatibleHintTrackVersion);
      System.out.println("maxPacketSize is " + maxPacketSize);
      System.out.println("remaining is " + remaining);
    } 
    while (remaining > 8) {
      int entryLength = readInt(this.stream);
      remaining -= 4;
      if (entryLength > 8) {
        if (this.debug2)
          System.out.println("entryLength is " + entryLength); 
        String dataTag = readString(this.stream);
        if (this.debug2)
          System.out.println("dataTag is " + dataTag); 
        remaining -= 4;
        if (dataTag.equals("tims")) {
          int rtpTimeScale = readInt(this.stream);
          remaining -= 4;
          continue;
        } 
        if (dataTag.equals("tsro")) {
          System.out.println("QuicktimeParser: rtp: tsro dataTag not supported");
          int rtpTimeStampOffset = readInt(this.stream);
          remaining -= 4;
          continue;
        } 
        if (dataTag.equals("snro")) {
          System.out.println("QuicktimeParser: rtp: snro dataTag not supported");
          int rtpSequenceNumberOffset = readInt(this.stream);
          remaining -= 4;
          continue;
        } 
        if (dataTag.equals("rely")) {
          System.out.println("QuicktimeParser: rtp: rely dataTag not supported");
          int rtpReliableTransportFlag = readByte(this.stream);
          remaining--;
          continue;
        } 
        skip(this.stream, remaining);
        remaining = 0;
        continue;
      } 
      skip(this.stream, remaining);
      remaining = 0;
      break;
    } 
    if (remaining > 0)
      skip(this.stream, remaining); 
    return hint;
  }
  
  private void parseSTTS(int sttsSize) throws BadHeaderException {
    if (this.debug2)
      System.out.println("parseSTTS: " + sttsSize); 
    try {
      if (sttsSize < 8)
        throw new BadHeaderException("stts atom: header size is incorrect"); 
      skip(this.stream, 4);
      int numEntries = readInt(this.stream);
      if (this.debug2)
        System.out.println("numEntries is " + numEntries); 
      int requiredSize = sttsSize - 8 - numEntries * 8;
      if (requiredSize < 0)
        throw new BadHeaderException("stts atom: inconsistent number_of_entries field"); 
      int totalNumSamples = 0;
      double timeScaleFactor = 1.0D / this.currentTrack.mediaTimeScale;
      if (numEntries == 1) {
        totalNumSamples = readInt(this.stream);
        this.currentTrack.durationOfSamples = readInt(this.stream) * timeScaleFactor;
      } else {
        int[] timeToSampleIndices = new int[numEntries];
        double[] durations = new double[numEntries];
        timeToSampleIndices[0] = readInt(this.stream);
        totalNumSamples += timeToSampleIndices[0];
        durations[0] = readInt(this.stream) * timeScaleFactor * timeToSampleIndices[0];
        int remaining = numEntries - 1;
        int numIntsWrittenPerLoop = 2;
        int maxEntriesPerLoop = this.tmpIntBufferSize / numIntsWrittenPerLoop;
        int i = 1;
        while (remaining > 0) {
          int numEntriesPerLoop = (remaining > maxEntriesPerLoop) ? maxEntriesPerLoop : remaining;
          readBytes(this.stream, this.tmpBuffer, numEntriesPerLoop * numIntsWrittenPerLoop * 4);
          int offset = 0;
          for (int ii = 1; ii <= numEntriesPerLoop; ii++, i++) {
            timeToSampleIndices[i] = parseIntFromArray(this.tmpBuffer, offset, true);
            offset += 4;
            int value = parseIntFromArray(this.tmpBuffer, offset, true);
            offset += 4;
            durations[i] = durations[i] + value * timeScaleFactor * timeToSampleIndices[i] + durations[i - 1];
            totalNumSamples += timeToSampleIndices[i];
            timeToSampleIndices[i] = totalNumSamples;
          } 
          remaining -= numEntriesPerLoop;
        } 
        this.currentTrack.timeToSampleIndices = timeToSampleIndices;
        this.currentTrack.cumulativeDurationOfSamples = durations;
      } 
      if (this.currentTrack.numberOfSamples == 0)
        this.currentTrack.numberOfSamples = totalNumSamples; 
      skip(this.stream, requiredSize);
    } catch (IOException e) {
      throw new BadHeaderException("Got IOException when seeking past STTS atom");
    } 
  }
  
  private void parseSTSC(int stscSize) throws BadHeaderException {
    try {
      if (stscSize < 8)
        throw new BadHeaderException("stsc atom: header size is incorrect"); 
      skip(this.stream, 4);
      int numEntries = readInt(this.stream);
      int requiredSize = stscSize - 8 - numEntries * 12;
      if (requiredSize < 0)
        throw new BadHeaderException("stsc atom: inconsistent number_of_entries field"); 
      int[] compactSamplesChunkNum = new int[numEntries];
      int[] compactSamplesPerChunk = new int[numEntries];
      byte[] tmpBuf = new byte[numEntries * 4 * 3];
      readBytes(this.stream, tmpBuf, numEntries * 4 * 3);
      int offset = 0;
      for (int i = 0; i < numEntries; i++) {
        compactSamplesChunkNum[i] = parseIntFromArray(tmpBuf, offset, true);
        offset += 4;
        compactSamplesPerChunk[i] = parseIntFromArray(tmpBuf, offset, true);
        offset += 4;
        offset += 4;
      } 
      tmpBuf = null;
      this.currentTrack.compactSamplesChunkNum = compactSamplesChunkNum;
      this.currentTrack.compactSamplesPerChunk = compactSamplesPerChunk;
      skip(this.stream, requiredSize);
    } catch (IOException e) {
      throw new BadHeaderException("Got IOException when seeking past STSC atom");
    } 
  }
  
  private void parseSTSZ(int stszSize) throws BadHeaderException {
    if (this.debug2)
      System.out.println("parseSTSZ: " + stszSize); 
    try {
      if (stszSize < 8)
        throw new BadHeaderException("stsz atom: header size is incorrect"); 
      skip(this.stream, 4);
      this.currentTrack.sampleSize = readInt(this.stream);
      if (this.currentTrack.sampleSize != 0) {
        skip(this.stream, stszSize - 8);
        this.currentTrack.media.maxSampleSize = this.currentTrack.sampleSize;
        return;
      } 
      if (stszSize - 8 < 4)
        throw new BadHeaderException("stsz atom: incorrect atom size"); 
      int numEntries = readInt(this.stream);
      if (this.currentTrack.numberOfSamples == 0)
        this.currentTrack.numberOfSamples = numEntries; 
      int requiredSize = stszSize - 8 - 4 - numEntries * 4;
      if (requiredSize < 0)
        throw new BadHeaderException("stsz atom: inconsistent number_of_entries field"); 
      int[] sampleSizeArray = new int[numEntries];
      int maxSampleSize = Integer.MIN_VALUE;
      int remaining = numEntries;
      int numIntsWrittenPerLoop = 1;
      int maxEntriesPerLoop = this.tmpIntBufferSize / numIntsWrittenPerLoop;
      int i = 0;
      while (remaining > 0) {
        int numEntriesPerLoop = (remaining > maxEntriesPerLoop) ? maxEntriesPerLoop : remaining;
        readBytes(this.stream, this.tmpBuffer, numEntriesPerLoop * numIntsWrittenPerLoop * 4);
        int offset = 0;
        for (int ii = 1; ii <= numEntriesPerLoop; ii++, i++) {
          int value = parseIntFromArray(this.tmpBuffer, offset, true);
          offset += 4;
          if (value > maxSampleSize)
            maxSampleSize = value; 
          sampleSizeArray[i] = value;
        } 
        remaining -= numEntriesPerLoop;
      } 
      this.currentTrack.sampleSizeArray = sampleSizeArray;
      this.currentTrack.media.maxSampleSize = maxSampleSize;
      skip(this.stream, requiredSize);
    } catch (IOException e) {
      throw new BadHeaderException("Got IOException when seeking past STSZ atom");
    } 
  }
  
  private void parseSTCO(int stcoSize) throws BadHeaderException {
    if (this.debug2)
      System.out.println("rtp:parseSTCO: " + stcoSize); 
    try {
      if (stcoSize < 8)
        throw new BadHeaderException("stco atom: header size is incorrect"); 
      skip(this.stream, 4);
      int numEntries = readInt(this.stream);
      this.currentTrack.numberOfChunks = numEntries;
      int[] chunkOffsets = new int[numEntries];
      int requiredSize = stcoSize - 8 - numEntries * 4;
      if (requiredSize < 0)
        throw new BadHeaderException("stco atom: inconsistent number_of_entries field"); 
      int remaining = numEntries;
      int numIntsWrittenPerLoop = 1;
      int maxEntriesPerLoop = this.tmpIntBufferSize / numIntsWrittenPerLoop;
      int i = 0;
      while (remaining > 0) {
        int numEntriesPerLoop = (remaining > maxEntriesPerLoop) ? maxEntriesPerLoop : remaining;
        readBytes(this.stream, this.tmpBuffer, numEntriesPerLoop * numIntsWrittenPerLoop * 4);
        int offset = 0;
        for (int ii = 1; ii <= numEntriesPerLoop; ii++, i++) {
          chunkOffsets[i] = parseIntFromArray(this.tmpBuffer, offset, true);
          offset += 4;
        } 
        remaining -= numEntriesPerLoop;
      } 
      this.currentTrack.chunkOffsets = chunkOffsets;
      skip(this.stream, requiredSize);
    } catch (IOException e) {
      throw new BadHeaderException("Got IOException when seeking past STCO atom");
    } 
  }
  
  private void parseSTSS(int stssSize) throws BadHeaderException {
    try {
      if (stssSize < 8)
        throw new BadHeaderException("stss atom: header size is incorrect"); 
      skip(this.stream, 4);
      int numEntries = readInt(this.stream);
      int requiredSize = stssSize - 8 - numEntries * 4;
      if (requiredSize < 0)
        throw new BadHeaderException("stss atom: inconsistent number_of_entries field"); 
      if (numEntries < 1) {
        skip(this.stream, requiredSize);
        return;
      } 
      int[] syncSamples = new int[numEntries];
      int remaining = numEntries;
      int numIntsWrittenPerLoop = 1;
      int maxEntriesPerLoop = this.tmpIntBufferSize / numIntsWrittenPerLoop;
      int i = 0;
      while (remaining > 0) {
        int numEntriesPerLoop = (remaining > maxEntriesPerLoop) ? maxEntriesPerLoop : remaining;
        readBytes(this.stream, this.tmpBuffer, numEntriesPerLoop * numIntsWrittenPerLoop * 4);
        int offset = 0;
        for (int ii = 1; ii <= numEntriesPerLoop; ii++, i++) {
          syncSamples[i] = parseIntFromArray(this.tmpBuffer, offset, true);
          offset += 4;
        } 
        remaining -= numEntriesPerLoop;
      } 
      this.currentTrack.syncSamples = syncSamples;
      skip(this.stream, requiredSize);
    } catch (IOException e) {
      throw new BadHeaderException("Got IOException when seeking past STSS atom");
    } 
  }
  
  private boolean isSupported(String trackType) {
    return (trackType.equals("vide") || trackType.equals("soun") || trackType.equals("hint"));
  }
  
  private class MovieHeader {
    int timeScale;
    
    Time duration;
    
    long mdatStart;
    
    long mdatSize;
    
    private final QuicktimeParser this$0;
    
    private MovieHeader(QuicktimeParser this$0) {
      QuicktimeParser.this = QuicktimeParser.this;
      this.duration = Duration.DURATION_UNKNOWN;
    }
  }
  
  private abstract class Media {
    String encoding;
    
    int maxSampleSize;
    
    float frameRate;
    
    private final QuicktimeParser this$0;
    
    private Media(QuicktimeParser this$0) {
      QuicktimeParser.this = QuicktimeParser.this;
    }
    
    abstract Format createFormat();
  }
  
  private class Audio extends Media {
    int channels;
    
    int bitsPerSample;
    
    int sampleRate;
    
    AudioFormat format;
    
    int frameSizeInBits;
    
    int samplesPerBlock;
    
    private final QuicktimeParser this$0;
    
    private Audio(QuicktimeParser this$0) {
      QuicktimeParser.this = QuicktimeParser.this;
      this.format = null;
      this.samplesPerBlock = 1;
    }
    
    public String toString() {
      String info = "Audio: " + this.format + "\n";
      info = info + "encoding is " + this.encoding + "\n";
      info = info + "Number of channels " + this.channels + "\n";
      info = info + "Bits per sample " + this.bitsPerSample + "\n";
      info = info + "sampleRate " + this.sampleRate + "\n";
      return info;
    }
    
    Format createFormat() {
      if (this.format != null)
        return (Format)this.format; 
      String encodingString = null;
      boolean signed = true;
      boolean bigEndian = true;
      if (this.encoding.equals("ulaw") || this.encoding.equals("alaw"))
        this.bitsPerSample = 8; 
      this.frameSizeInBits = this.channels * this.bitsPerSample;
      if (this.encoding.equals("ulaw")) {
        encodingString = "ULAW";
        signed = false;
      } else if (this.encoding.equals("alaw")) {
        encodingString = "alaw";
        signed = false;
      } else if (this.encoding.equals("twos")) {
        encodingString = "LINEAR";
      } else if (this.encoding.equals("ima4")) {
        encodingString = "ima4";
        this.samplesPerBlock = 64;
        this.frameSizeInBits = 34 * this.channels * 8;
      } else if (this.encoding.equals("raw ")) {
        encodingString = "LINEAR";
        signed = false;
      } else if (this.encoding.equals("agsm")) {
        encodingString = "gsm";
        this.samplesPerBlock = 33;
        this.frameSizeInBits = 264;
      } else if (this.encoding.equals("mac3")) {
        encodingString = "MAC3";
      } else if (this.encoding.equals("mac6")) {
        encodingString = "MAC6";
      } else {
        encodingString = this.encoding;
      } 
      this.format = new AudioFormat(encodingString, this.sampleRate, this.bitsPerSample, this.channels, bigEndian ? 1 : 0, signed ? 1 : 0, this.frameSizeInBits, -1.0D, Format.byteArray);
      return (Format)this.format;
    }
  }
  
  private class Video extends Media {
    int width;
    
    int height;
    
    int pixelDepth;
    
    int colorTableID;
    
    VideoFormat format;
    
    private final QuicktimeParser this$0;
    
    private Video(QuicktimeParser this$0) {
      QuicktimeParser.this = QuicktimeParser.this;
    }
    
    Format createFormat() {
      if (this.format != null)
        return (Format)this.format; 
      if (this.encoding.toLowerCase().startsWith("raw")) {
        this.encoding = "rgb";
        if (this.pixelDepth == 24) {
          this.format = (VideoFormat)new RGBFormat(new Dimension(this.width, this.height), -1, Format.byteArray, this.frameRate, this.pixelDepth, 1, 2, 3, 3, this.width * 3, 0, 0);
        } else if (this.pixelDepth == 16) {
          this.format = (VideoFormat)new RGBFormat(new Dimension(this.width, this.height), -1, Format.byteArray, this.frameRate, this.pixelDepth, 31744, 992, 31, 2, this.width * 2, 0, 0);
        } else if (this.pixelDepth == 32) {
          this.encoding = "rgb";
          this.format = (VideoFormat)new RGBFormat(new Dimension(this.width, this.height), -1, Format.byteArray, this.frameRate, this.pixelDepth, 2, 3, 4, 4, this.width * 4, 0, 0);
        } 
      } else if (this.encoding.toLowerCase().equals("8bps")) {
        this.format = new VideoFormat(this.encoding, new Dimension(this.width, this.height), this.maxSampleSize, Format.byteArray, this.frameRate);
      } else if (this.encoding.toLowerCase().equals("yuv2")) {
        this.format = (VideoFormat)new YUVFormat(new Dimension(this.width, this.height), -1, Format.byteArray, this.frameRate, 96, this.width * 2, this.width * 2, 0, 1, 3);
      } else {
        this.format = new VideoFormat(this.encoding, new Dimension(this.width, this.height), this.maxSampleSize, Format.byteArray, this.frameRate);
      } 
      return (Format)this.format;
    }
    
    public String toString() {
      String info = "Video: " + this.format + "\n";
      info = info + "encoding is " + this.encoding + "\n";
      info = info + "pixelDepth is " + this.pixelDepth + "\n";
      return info;
    }
  }
  
  private class Hint extends Media {
    Format format;
    
    private final QuicktimeParser this$0;
    
    private Hint(QuicktimeParser this$0) {
      QuicktimeParser.this = QuicktimeParser.this;
      this.format = null;
    }
    
    Format createFormat() {
      return this.format;
    }
  }
  
  private class TrakList {
    int flag;
    
    int id;
    
    Time duration;
    
    int mediaTimeScale;
    
    Time mediaDuration;
    
    String trackType;
    
    int numberOfSamples;
    
    int sampleSize;
    
    int[] sampleSizeArray;
    
    boolean supported;
    
    QuicktimeParser.Media media;
    
    int numberOfChunks;
    
    int[] chunkOffsets;
    
    int[] compactSamplesChunkNum;
    
    int[] compactSamplesPerChunk;
    
    int constantSamplesPerChunk;
    
    int[] samplesPerChunk;
    
    double durationOfSamples;
    
    int[] timeToSampleIndices;
    
    double[] cumulativeDurationOfSamples;
    
    double[] startTimeOfSampleArray;
    
    double[] durationOfSampleArray;
    
    long[] sampleOffsetTable;
    
    int[] syncSamples;
    
    int[] syncSampleMapping;
    
    QuicktimeParser.TimeAndDuration timeAndDuration;
    
    int trackIdOfTrackBeingHinted;
    
    int indexOfTrackBeingHinted;
    
    int maxPacketSize;
    
    private final QuicktimeParser this$0;
    
    private TrakList(QuicktimeParser this$0) {
      QuicktimeParser.this = QuicktimeParser.this;
      this.duration = Duration.DURATION_UNKNOWN;
      this.mediaDuration = Duration.DURATION_UNKNOWN;
      this.sampleSize = 0;
      this.chunkOffsets = new int[0];
      this.compactSamplesChunkNum = new int[0];
      this.compactSamplesPerChunk = new int[0];
      this.constantSamplesPerChunk = -1;
      this.durationOfSamples = -1.0D;
      this.timeToSampleIndices = new int[0];
      this.cumulativeDurationOfSamples = new double[0];
      this.startTimeOfSampleArray = new double[0];
      this.durationOfSampleArray = new double[0];
      this.timeAndDuration = new QuicktimeParser.TimeAndDuration();
      this.trackIdOfTrackBeingHinted = -1;
      this.indexOfTrackBeingHinted = -1;
      this.maxPacketSize = -1;
    }
    
    void buildSamplePerChunkTable() {
      if (this.numberOfChunks <= 0)
        return; 
      if (this.compactSamplesPerChunk.length == 1) {
        this.constantSamplesPerChunk = this.compactSamplesPerChunk[0];
        return;
      } 
      this.samplesPerChunk = new int[this.numberOfChunks];
      int i = 1;
      int j;
      for (j = 0; j < this.compactSamplesChunkNum.length - 1; j++) {
        int numSamples = this.compactSamplesPerChunk[j];
        while (i != this.compactSamplesChunkNum[j + 1]) {
          this.samplesPerChunk[i - 1] = numSamples;
          i++;
        } 
      } 
      for (; i <= this.numberOfChunks; i++)
        this.samplesPerChunk[i - 1] = this.compactSamplesPerChunk[j]; 
    }
    
    void buildCumulativeSamplePerChunkTable() {
      if (this.constantSamplesPerChunk == -1)
        for (int i = 1; i < this.numberOfChunks; i++)
          this.samplesPerChunk[i] = this.samplesPerChunk[i] + this.samplesPerChunk[i - 1];  
    }
    
    void buildSampleOffsetTable() {
      this.sampleOffsetTable = new long[this.numberOfSamples];
      int index = 0;
      if (this.sampleSize != 0) {
        if (this.constantSamplesPerChunk != -1) {
          for (int i = 0; i < this.numberOfChunks; i++) {
            long offset = this.chunkOffsets[i];
            for (int j = 0; j < this.constantSamplesPerChunk; j++)
              this.sampleOffsetTable[index++] = offset + (j * this.sampleSize); 
          } 
        } else {
          for (byte b = 0; b < this.numberOfChunks; b++) {
            long l = this.chunkOffsets[b];
            for (byte b1 = 0; b1 < this.samplesPerChunk[b]; b1++)
              this.sampleOffsetTable[index++] = l + (b1 * this.sampleSize); 
          } 
        } 
      } else {
        int numSamplesInChunk = 0;
        if (this.constantSamplesPerChunk != -1)
          numSamplesInChunk = this.constantSamplesPerChunk; 
        for (byte b = 0; b < this.numberOfChunks; b++) {
          long l = this.chunkOffsets[b];
          this.sampleOffsetTable[index] = l;
          index++;
          if (this.constantSamplesPerChunk == -1)
            numSamplesInChunk = this.samplesPerChunk[b]; 
          for (byte b1 = 1; b1 < numSamplesInChunk; b1++) {
            this.sampleOffsetTable[index] = this.sampleOffsetTable[index - 1] + this.sampleSizeArray[index - 1];
            index++;
          } 
        } 
      } 
    }
    
    boolean buildSyncTable() {
      int i;
      if (this.syncSamples == null)
        return false; 
      if (!this.trackType.equals("vide"))
        return false; 
      int numEntries = this.syncSamples.length;
      if (numEntries == this.numberOfSamples) {
        this.syncSamples = null;
        return false;
      } 
      this.syncSampleMapping = new int[this.numberOfSamples];
      int index = 0;
      if (this.syncSamples[0] != 1) {
        i = this.syncSampleMapping[0] = 0;
      } else {
        i = this.syncSampleMapping[0] = 0;
        index++;
      } 
      for (; index < this.syncSamples.length; index++) {
        int next = this.syncSamples[index] - 1;
        this.syncSampleMapping[next] = next;
        int range = next - i - 1;
        for (int j = i + 1; j < next; j++)
          this.syncSampleMapping[j] = i; 
        i = next;
      } 
      int lastSyncFrame = this.syncSamples[this.syncSamples.length - 1] - 1;
      for (index = lastSyncFrame + 1; index < this.numberOfSamples; index++)
        this.syncSampleMapping[index] = lastSyncFrame; 
      return true;
    }
    
    int time2Index(double time) {
      int j, k;
      double d1;
      if (time < 0.0D)
        time = 0.0D; 
      int length = this.timeToSampleIndices.length;
      if (length == 0) {
        i = (int)(time / this.mediaDuration.getSeconds() * this.numberOfSamples + 0.5D);
        if (i >= this.numberOfSamples)
          return -1; 
        return i;
      } 
      int approxLocation = (int)(time / this.mediaDuration.getSeconds() * length);
      if (approxLocation == length)
        approxLocation--; 
      if (approxLocation >= this.cumulativeDurationOfSamples.length)
        return -1; 
      if (this.cumulativeDurationOfSamples[approxLocation] < time) {
        int m;
        for (m = approxLocation + 1; m < length && 
          this.cumulativeDurationOfSamples[m] < time; m++);
        j = m;
      } else if (this.cumulativeDurationOfSamples[approxLocation] > time) {
        int m;
        for (m = approxLocation - 1; m >= 0 && 
          this.cumulativeDurationOfSamples[m] >= time; m--);
        j = m + 1;
      } else {
        j = approxLocation;
      } 
      if (j == length)
        j--; 
      double delta = this.cumulativeDurationOfSamples[j] - time;
      if (j == 0) {
        i = this.timeToSampleIndices[j];
        k = i;
        d1 = this.cumulativeDurationOfSamples[j];
      } else {
        i = this.timeToSampleIndices[j];
        k = i - this.timeToSampleIndices[j - 1];
        d1 = this.cumulativeDurationOfSamples[j] - this.cumulativeDurationOfSamples[j - 1];
      } 
      double fraction = delta / d1;
      int i = (int)(i - k * fraction);
      return i;
    }
    
    QuicktimeParser.TimeAndDuration index2TimeAndDuration(int index) {
      double startTime = 0.0D;
      double duration = 0.0D;
      try {
        if (index < 0) {
          index = 0;
        } else if (index >= this.numberOfSamples) {
          index = this.numberOfSamples - 1;
        } 
        int length = this.timeToSampleIndices.length;
        if (length == 0) {
          duration = this.durationOfSamples;
          startTime = duration * index;
        } else if (this.startTimeOfSampleArray.length >= index) {
          duration = this.durationOfSampleArray[index];
          startTime = this.startTimeOfSampleArray[index];
        } else {
          float factor = length / this.numberOfSamples;
          int location = (int)(index * factor);
          duration = 0.0D;
          startTime = 0.0D;
        } 
      } finally {
        synchronized (this.timeAndDuration) {
          this.timeAndDuration.startTime = startTime;
          this.timeAndDuration.duration = duration;
          return this.timeAndDuration;
        } 
      } 
    }
    
    int index2Chunk(int index) {
      int i;
      if (this.constantSamplesPerChunk != -1) {
        i = index / this.constantSamplesPerChunk;
        return i;
      } 
      int length = this.samplesPerChunk.length;
      int approxChunk = (int)((index / this.numberOfSamples) * length);
      if (approxChunk == length)
        approxChunk--; 
      if (this.samplesPerChunk[approxChunk] < index) {
        int j;
        for (j = approxChunk + 1; j < length && 
          this.samplesPerChunk[j] < index; j++);
        i = j;
      } else if (this.samplesPerChunk[approxChunk] > index) {
        int j;
        for (j = approxChunk - 1; j >= 0 && 
          this.samplesPerChunk[j] >= index; j--);
        i = j + 1;
      } else {
        i = approxChunk;
      } 
      return i;
    }
    
    long index2Offset(int index) {
      int i, j, chunk = index2Chunk(index + 1);
      if (QuicktimeParser.this.debug)
        System.out.println(" index2Chunk chunk is " + chunk); 
      if (chunk >= this.chunkOffsets.length)
        return -2L; 
      long offset = this.chunkOffsets[chunk];
      if (QuicktimeParser.this.debug1)
        System.out.println("index2Offset: index, chunk, chunkOffset " + index + " : " + chunk + " : " + offset); 
      if (this.constantSamplesPerChunk != -1) {
        i = index % this.constantSamplesPerChunk;
        j = chunk * this.constantSamplesPerChunk;
      } else {
        if (chunk == 0) {
          j = 0;
        } else {
          j = this.samplesPerChunk[chunk - 1];
        } 
        i = index - j;
        if (QuicktimeParser.this.debug1) {
          System.out.println("index, start, sampleNumInChunk " + index + " : " + j + " : " + i);
          System.out.println("sampleSize is " + this.sampleSize);
        } 
      } 
      if (QuicktimeParser.this.debug1)
        System.out.println("sampleSize is " + this.sampleSize); 
      if (this.sampleSize != 0) {
        offset += (this.sampleSize * i);
      } else {
        for (int k = 0; k < i; k++)
          offset += this.sampleSizeArray[j++]; 
      } 
      return offset;
    }
    
    void buildStartTimeAndDurationTable() {
      if (QuicktimeParser.this.debug2)
        System.out.println("buildStartTimeAndDurationTable"); 
      int length = this.timeToSampleIndices.length;
      if (length == 0)
        return; 
      this.startTimeOfSampleArray = new double[this.numberOfSamples];
      this.durationOfSampleArray = new double[this.numberOfSamples];
      int previousSamples = 0;
      double previousDuration = 0.0D;
      double time = 0.0D;
      int index = 0;
      for (int i = 0; i < length; i++) {
        int numSamples = this.timeToSampleIndices[i];
        double duration = (this.cumulativeDurationOfSamples[i] - previousDuration) / (numSamples - previousSamples);
        for (int j = 0; j < numSamples - previousSamples; j++) {
          this.startTimeOfSampleArray[index] = time;
          this.durationOfSampleArray[index] = duration;
          index++;
          time += duration;
        } 
        previousSamples = numSamples;
        previousDuration = this.cumulativeDurationOfSamples[i];
      } 
    }
    
    public String toString() {
      String info = "";
      info = info + "track id is " + this.id + "\n";
      info = info + "duration itrack is " + this.duration.getSeconds() + "\n";
      info = info + "duration of media is " + this.mediaDuration.getSeconds() + "\n";
      info = info + "trackType is " + this.trackType + "\n";
      info = info + this.media;
      return info;
    }
  }
  
  private abstract class MediaTrack implements Track {
    QuicktimeParser.TrakList trakInfo;
    
    boolean enabled;
    
    int numBuffers;
    
    Format format;
    
    long sequenceNumber;
    
    int chunkNumber;
    
    int sampleIndex;
    
    int useChunkNumber;
    
    int useSampleIndex;
    
    QuicktimeParser parser;
    
    CachedStream cacheStream;
    
    int constantSamplesPerChunk;
    
    int[] samplesPerChunk;
    
    protected TrackListener listener;
    
    private final QuicktimeParser this$0;
    
    MediaTrack(QuicktimeParser this$0, QuicktimeParser.TrakList trakInfo) {
      this.this$0 = this$0;
      this.enabled = true;
      this.numBuffers = 4;
      this.sequenceNumber = 0L;
      this.chunkNumber = 0;
      this.sampleIndex = 0;
      this.useChunkNumber = 0;
      this.useSampleIndex = 0;
      this.parser = this.this$0;
      this.cacheStream = this.parser.getCacheStream();
      this.trakInfo = trakInfo;
      if (trakInfo != null) {
        this.enabled = ((trakInfo.flag & 0x1) != 0);
        this.format = trakInfo.media.createFormat();
        this.samplesPerChunk = trakInfo.samplesPerChunk;
        this.constantSamplesPerChunk = trakInfo.constantSamplesPerChunk;
      } 
    }
    
    public void setTrackListener(TrackListener l) {
      this.listener = l;
    }
    
    public Format getFormat() {
      return this.format;
    }
    
    public void setEnabled(boolean t) {
      this.enabled = t;
    }
    
    public boolean isEnabled() {
      return this.enabled;
    }
    
    public Time getDuration() {
      return this.trakInfo.duration;
    }
    
    public Time getStartTime() {
      return new Time(0L);
    }
    
    synchronized void setSampleIndex(int index) {
      this.sampleIndex = index;
    }
    
    synchronized void setChunkNumber(int number) {
      this.chunkNumber = number;
    }
    
    public void readFrame(Buffer buffer) {
      if (buffer == null)
        return; 
      if (!this.enabled) {
        buffer.setDiscard(true);
        return;
      } 
      synchronized (this) {
        this.useChunkNumber = this.chunkNumber;
        this.useSampleIndex = this.sampleIndex;
      } 
      if (this.useChunkNumber >= this.trakInfo.numberOfChunks || this.useChunkNumber < 0) {
        buffer.setEOM(true);
        return;
      } 
      buffer.setFormat(this.format);
      doReadFrame(buffer);
    }
    
    abstract void doReadFrame(Buffer param1Buffer);
    
    public int mapTimeToFrame(Time t) {
      return Integer.MAX_VALUE;
    }
    
    public Time mapFrameToTime(int frameNumber) {
      return Track.TIME_UNKNOWN;
    }
  }
  
  private class AudioTrack extends MediaTrack {
    String encoding;
    
    int channels;
    
    int sampleOffsetInChunk;
    
    int useSampleOffsetInChunk;
    
    int frameSizeInBytes;
    
    int samplesPerBlock;
    
    int sampleRate;
    
    private final QuicktimeParser this$0;
    
    AudioTrack(QuicktimeParser this$0, QuicktimeParser.TrakList trakInfo, int channels, String encoding, int frameSizeInBytes, int samplesPerBlock, int sampleRate) {
      super(this$0, trakInfo);
      this.this$0 = this$0;
      this.sampleOffsetInChunk = -1;
      this.useSampleOffsetInChunk = 0;
      this.channels = channels;
      this.encoding = encoding;
      this.frameSizeInBytes = frameSizeInBytes;
      this.samplesPerBlock = samplesPerBlock;
      this.sampleRate = sampleRate;
    }
    
    AudioTrack(QuicktimeParser this$0, QuicktimeParser.TrakList trakInfo) {
      super(this$0, trakInfo);
      this.this$0 = this$0;
      this.sampleOffsetInChunk = -1;
      this.useSampleOffsetInChunk = 0;
      if (trakInfo != null) {
        this.channels = ((QuicktimeParser.Audio)trakInfo.media).channels;
        this.encoding = trakInfo.media.encoding;
        this.frameSizeInBytes = ((QuicktimeParser.Audio)trakInfo.media).frameSizeInBits / 8;
        this.samplesPerBlock = ((QuicktimeParser.Audio)trakInfo.media).samplesPerBlock;
        this.sampleRate = ((QuicktimeParser.Audio)trakInfo.media).sampleRate;
      } 
    }
    
    synchronized void setChunkNumberAndSampleOffset(int number, int offset) {
      this.chunkNumber = number;
      this.sampleOffsetInChunk = offset;
    }
    
    void doReadFrame(Buffer buffer) {
      int i;
      long l;
      int j, k;
      byte[] arrayOfByte;
      synchronized (this) {
        if (this.sampleOffsetInChunk == -1) {
          this.useSampleOffsetInChunk = 0;
        } else {
          this.useSampleOffsetInChunk = this.sampleOffsetInChunk;
          this.sampleOffsetInChunk = -1;
        } 
      } 
      if (this.constantSamplesPerChunk != -1) {
        i = this.constantSamplesPerChunk;
        l = (this.constantSamplesPerChunk * this.useChunkNumber);
      } else if (this.useChunkNumber > 0) {
        i = this.samplesPerChunk[this.useChunkNumber] - this.samplesPerChunk[this.useChunkNumber - 1];
        l = this.samplesPerChunk[this.useChunkNumber];
      } else {
        i = this.samplesPerChunk[this.useChunkNumber];
        l = 0L;
      } 
      if (this.samplesPerBlock > 1) {
        k = this.useSampleOffsetInChunk / this.samplesPerBlock;
        this.useSampleOffsetInChunk = k * this.samplesPerBlock;
        j = this.frameSizeInBytes * k;
      } else {
        j = this.useSampleOffsetInChunk * this.frameSizeInBytes;
      } 
      i -= this.useSampleOffsetInChunk;
      l += this.useSampleOffsetInChunk;
      if (this.encoding.equals("ima4")) {
        k = i / this.samplesPerBlock * 34 * this.channels;
      } else if (this.encoding.equals("agsm")) {
        k = i / 160 * this.samplesPerBlock;
      } else {
        k = i * ((AudioFormat)this.format).getSampleSizeInBits() / 8 * this.channels;
      } 
      Object obj = buffer.getData();
      if (obj == null || !(obj instanceof byte[]) || ((byte[])obj).length < k) {
        arrayOfByte = new byte[k];
        buffer.setData(arrayOfByte);
      } else {
        arrayOfByte = (byte[])obj;
      } 
      try {
        int actualBytesRead;
        synchronized (this.this$0.seekSync) {
          int offset = this.trakInfo.chunkOffsets[this.useChunkNumber];
          if (this.sampleIndex != this.useSampleIndex) {
            buffer.setDiscard(true);
            return;
          } 
          if (this.cacheStream != null && this.listener != null)
            if (this.cacheStream.willReadBytesBlock((offset + j), k))
              this.listener.readHasBlocked(this);  
          long pos = this.this$0.seekableStream.seek((offset + j));
          if (pos == -2L) {
            buffer.setDiscard(true);
            return;
          } 
          actualBytesRead = this.parser.readBytes(this.this$0.stream, arrayOfByte, k);
          if (actualBytesRead == -2) {
            buffer.setDiscard(true);
            return;
          } 
        } 
        buffer.setLength(actualBytesRead);
        buffer.setSequenceNumber(++this.sequenceNumber);
        if (this.sampleRate > 0) {
          long timeStamp = l * 1000000000L / this.sampleRate;
          buffer.setTimeStamp(timeStamp);
          buffer.setDuration(-1L);
        } 
      } catch (IOException e) {
        buffer.setLength(0);
        buffer.setEOM(true);
      } 
      synchronized (this) {
        if (this.chunkNumber == this.useChunkNumber)
          this.chunkNumber++; 
      } 
    }
  }
  
  private class VideoTrack extends MediaTrack {
    int needBufferSize;
    
    boolean variableSampleSize;
    
    private final QuicktimeParser this$0;
    
    VideoTrack(QuicktimeParser this$0, QuicktimeParser.TrakList trakInfo) {
      super(this$0, trakInfo);
      this.this$0 = this$0;
      this.variableSampleSize = true;
      if (trakInfo != null && 
        trakInfo.sampleSize != 0) {
        this.variableSampleSize = false;
        this.needBufferSize = trakInfo.sampleSize;
      } 
    }
    
    void doReadFrame(Buffer buffer) {
      byte[] arrayOfByte;
      if (this.useSampleIndex >= this.trakInfo.numberOfSamples) {
        buffer.setLength(0);
        buffer.setEOM(true);
        return;
      } 
      if (this.variableSampleSize) {
        if (this.useSampleIndex >= this.trakInfo.sampleSizeArray.length) {
          buffer.setLength(0);
          buffer.setEOM(true);
          return;
        } 
        this.needBufferSize = this.trakInfo.sampleSizeArray[this.useSampleIndex];
      } 
      long offset = this.trakInfo.sampleOffsetTable[this.useSampleIndex];
      Object obj = buffer.getData();
      if (obj == null || !(obj instanceof byte[]) || ((byte[])obj).length < this.needBufferSize) {
        arrayOfByte = new byte[this.needBufferSize];
        buffer.setData(arrayOfByte);
      } else {
        arrayOfByte = (byte[])obj;
      } 
      try {
        int actualBytesRead;
        synchronized (this.this$0.seekSync) {
          if (this.sampleIndex != this.useSampleIndex) {
            buffer.setDiscard(true);
            return;
          } 
          if (this.cacheStream != null && this.listener != null && 
            this.cacheStream.willReadBytesBlock(offset, this.needBufferSize))
            this.listener.readHasBlocked(this); 
          long pos = this.this$0.seekableStream.seek(offset);
          if (pos == -2L) {
            buffer.setDiscard(true);
            return;
          } 
          actualBytesRead = this.parser.readBytes(this.this$0.stream, arrayOfByte, this.needBufferSize);
          if (actualBytesRead == -2) {
            buffer.setDiscard(true);
            return;
          } 
        } 
        buffer.setLength(actualBytesRead);
        int[] syncSampleMapping = this.trakInfo.syncSampleMapping;
        boolean keyFrame = true;
        if (syncSampleMapping != null)
          keyFrame = (syncSampleMapping[this.useSampleIndex] == this.useSampleIndex); 
        if (keyFrame)
          buffer.setFlags(buffer.getFlags() | 0x10); 
        buffer.setSequenceNumber(++this.sequenceNumber);
        QuicktimeParser.TimeAndDuration td = this.trakInfo.index2TimeAndDuration(this.useSampleIndex);
        buffer.setTimeStamp((long)(td.startTime * 1.0E9D));
        buffer.setDuration((long)(td.duration * 1.0E9D));
      } catch (IOException e) {
        buffer.setLength(0);
        buffer.setEOM(true);
      } 
      synchronized (this) {
        if (this.sampleIndex == this.useSampleIndex)
          this.sampleIndex++; 
      } 
    }
    
    public int mapTimeToFrame(Time t) {
      double time = t.getSeconds();
      if (time < 0.0D)
        return Integer.MAX_VALUE; 
      int index = this.trakInfo.time2Index(time);
      if (index < 0)
        return this.trakInfo.numberOfSamples - 1; 
      return index;
    }
    
    public Time mapFrameToTime(int frameNumber) {
      if (frameNumber < 0 || frameNumber >= this.trakInfo.numberOfSamples)
        return Track.TIME_UNKNOWN; 
      double time = (frameNumber / this.trakInfo.media.frameRate);
      return new Time(time);
    }
  }
  
  private class HintAudioTrack extends AudioTrack {
    int hintSampleSize;
    
    int indexOfTrackBeingHinted;
    
    int maxPacketSize;
    
    int currentPacketNumber;
    
    int numPacketsInSample;
    
    long offsetToStartOfPacketInfo;
    
    QuicktimeParser.TrakList sampleTrakInfo;
    
    boolean variableSampleSize;
    
    private final QuicktimeParser this$0;
    
    HintAudioTrack(QuicktimeParser this$0, QuicktimeParser.TrakList trakInfo, int channels, String encoding, int frameSizeInBytes, int samplesPerBlock, int sampleRate) {
      super(this$0, trakInfo, channels, encoding, frameSizeInBytes, samplesPerBlock, sampleRate);
      this.this$0 = this$0;
      this.indexOfTrackBeingHinted = this.trakInfo.indexOfTrackBeingHinted;
      this.currentPacketNumber = 0;
      this.numPacketsInSample = -1;
      this.offsetToStartOfPacketInfo = -1L;
      this.variableSampleSize = true;
      this.format = ((QuicktimeParser.Hint)trakInfo.media).format;
      this.maxPacketSize = trakInfo.maxPacketSize;
      if (this.indexOfTrackBeingHinted >= 0) {
        this.sampleTrakInfo = this$0.trakList[this.indexOfTrackBeingHinted];
      } else if (this$0.debug) {
        System.out.println("sampleTrakInfo is not set " + this.indexOfTrackBeingHinted);
      } 
      if (trakInfo.sampleSize != 0) {
        this.variableSampleSize = false;
        this.hintSampleSize = trakInfo.sampleSize;
      } 
    }
    
    public void readFrame(Buffer buffer) {
      if (buffer == null)
        return; 
      if (!this.enabled) {
        buffer.setDiscard(true);
        return;
      } 
      synchronized (this) {
        this.useChunkNumber = this.chunkNumber;
        this.useSampleIndex = this.sampleIndex;
      } 
      buffer.setFormat(this.format);
      doReadFrame(buffer);
    }
    
    synchronized void setSampleIndex(int index) {
      this.chunkNumber = index;
      this.sampleIndex = index;
    }
    
    void doReadFrame(Buffer buffer) {
      byte[] arrayOfByte;
      if (this.this$0.debug1)
        System.out.println("audio: hint doReadFrame: " + this.useChunkNumber + " : " + this.sampleOffsetInChunk); 
      boolean rtpMarkerSet = false;
      if (this.indexOfTrackBeingHinted < 0) {
        buffer.setDiscard(true);
        return;
      } 
      int rtpOffset = 0;
      if (this.variableSampleSize)
        if (this.useSampleIndex >= this.trakInfo.sampleSizeArray.length) {
          this.hintSampleSize = this.trakInfo.sampleSizeArray[this.trakInfo.sampleSizeArray.length - 1];
        } else {
          this.hintSampleSize = this.trakInfo.sampleSizeArray[this.useSampleIndex];
        }  
      int remainingHintSampleSize = this.hintSampleSize;
      if (this.this$0.debug1)
        System.out.println("hintSampleSize is " + this.hintSampleSize); 
      Object obj = buffer.getData();
      if (obj == null || !(obj instanceof byte[]) || ((byte[])obj).length < this.maxPacketSize) {
        arrayOfByte = new byte[this.maxPacketSize];
        buffer.setData(arrayOfByte);
      } else {
        arrayOfByte = (byte[])obj;
      } 
      try {
        int rtpSequenceNumber, actualBytesRead;
        synchronized (this.this$0.seekSync) {
          if (this.sampleIndex != this.useSampleIndex) {
            buffer.setDiscard(true);
            this.currentPacketNumber = 0;
            this.numPacketsInSample = -1;
            this.offsetToStartOfPacketInfo = -1L;
            rtpOffset = 0;
            return;
          } 
          long offset = this.trakInfo.index2Offset(this.useChunkNumber);
          if (this.this$0.debug) {
            System.out.println("audio: Calling index2Offset on hint track with arg " + this.useChunkNumber);
            System.out.println("offset is " + offset);
          } 
          if (offset == -2L) {
            buffer.setLength(0);
            buffer.setEOM(true);
            return;
          } 
          if (this.cacheStream != null && this.listener != null)
            if (this.cacheStream.willReadBytesBlock(offset, this.hintSampleSize))
              this.listener.readHasBlocked(this);  
          if (this.this$0.debug1)
            System.out.println("currentPacketNumber is " + this.currentPacketNumber); 
          if (this.offsetToStartOfPacketInfo < 0L) {
            if (this.this$0.debug1)
              System.out.println("NEW SEEK"); 
            long pos = this.this$0.seekableStream.seek(offset);
            if (pos == -2L) {
              buffer.setDiscard(true);
              return;
            } 
            this.numPacketsInSample = this.parser.readShort(this.this$0.stream);
            if (this.this$0.debug)
              System.out.println("num packets in sample " + this.numPacketsInSample); 
            if (this.numPacketsInSample < 1) {
              buffer.setDiscard(true);
              return;
            } 
            remainingHintSampleSize -= 2;
            this.parser.readShort(this.this$0.stream);
            remainingHintSampleSize -= 2;
          } else {
            long l = this.this$0.seekableStream.seek(this.offsetToStartOfPacketInfo);
            if (l == -2L) {
              buffer.setDiscard(true);
              return;
            } 
          } 
          int relativeTransmissionTime = this.parser.readInt(this.this$0.stream);
          remainingHintSampleSize -= 4;
          int rtpHeaderInfo = this.parser.readShort(this.this$0.stream);
          if (this.this$0.debug)
            System.out.println("rtpHeaderInfo is " + Integer.toHexString(rtpHeaderInfo)); 
          rtpMarkerSet = ((rtpHeaderInfo & 0x80) > 0);
          remainingHintSampleSize -= 2;
          rtpSequenceNumber = this.parser.readShort(this.this$0.stream);
          remainingHintSampleSize -= 2;
          boolean paddingPresent = ((rtpHeaderInfo & 0x2000) > 0);
          boolean extensionHeaderPresent = ((rtpHeaderInfo & 0x1000) > 0);
          if (paddingPresent);
          if (extensionHeaderPresent);
          int flags = this.parser.readShort(this.this$0.stream);
          if (this.this$0.debug) {
            System.out.println("rtp marker present? " + rtpMarkerSet);
            System.out.println("rtp payload type " + (rtpHeaderInfo & 0x7F));
            System.out.println("padding? " + paddingPresent);
            System.out.println("extension header? " + extensionHeaderPresent);
            System.out.println("audio hint: flags is " + Integer.toHexString(flags));
          } 
          remainingHintSampleSize -= 2;
          int entriesInDataTable = this.parser.readShort(this.this$0.stream);
          remainingHintSampleSize -= 2;
          boolean extraInfoTLVPresent = ((flags & 0x4) > 0);
          if (extraInfoTLVPresent) {
            int tlvTableSize = this.parser.readInt(this.this$0.stream);
            this.this$0.skip(this.this$0.stream, tlvTableSize - 4);
            if (this.this$0.debug) {
              System.err.println("audio: extraInfoTLVPresent: Skipped");
              System.out.println("tlvTableSize is " + tlvTableSize);
            } 
          } 
          if (this.this$0.debug) {
            System.out.println("Packet # " + this.currentPacketNumber);
            System.out.println("  relativeTransmissionTime is " + relativeTransmissionTime);
            System.out.println("  rtpSequenceNumber is " + rtpSequenceNumber);
            System.out.println("  entriesInDataTable is " + entriesInDataTable);
          } 
          for (int j = 0; j < entriesInDataTable; j++) {
            int dataBlockSource = this.parser.readByte(this.this$0.stream);
            remainingHintSampleSize--;
            if (this.this$0.debug1)
              System.out.println("    dataBlockSource is " + dataBlockSource); 
            if (dataBlockSource == 1) {
              int length = this.parser.readByte(this.this$0.stream);
              remainingHintSampleSize--;
              this.parser.readBytes(this.this$0.stream, arrayOfByte, rtpOffset, length);
              rtpOffset += length;
              this.parser.skip(this.this$0.stream, 14 - length);
              remainingHintSampleSize -= 14;
            } else if (dataBlockSource == 2) {
              QuicktimeParser.TrakList trakList;
              long l2;
              int trackRefIndex = this.parser.readByte(this.this$0.stream);
              if (this.this$0.debug1)
                System.out.println("     audio:trackRefIndex is " + trackRefIndex); 
              if (trackRefIndex > 0) {
                System.err.println("     Currently we don't support hint tracks that refer to multiple media tracks: " + trackRefIndex);
                buffer.setDiscard(true);
                return;
              } 
              int numBytesToCopy = this.parser.readShort(this.this$0.stream);
              int sampleNumber = this.parser.readInt(this.this$0.stream);
              int byteOffset = this.parser.readInt(this.this$0.stream);
              int bytesPerCompresionBlock = this.parser.readShort(this.this$0.stream);
              int samplesPerCompresionBlock = this.parser.readShort(this.this$0.stream);
              if (this.this$0.debug1) {
                System.out.println("     sample Number is " + sampleNumber);
                System.out.println("     numBytesToCopy is " + numBytesToCopy);
                System.out.println("     byteOffset is " + byteOffset);
                System.out.println("     bytesPerCompresionBlock is " + bytesPerCompresionBlock);
                System.out.println("     samplesPerCompresionBlock is " + samplesPerCompresionBlock);
              } 
              remainingHintSampleSize -= 15;
              long saveCurrentPos = this.parser.getLocation(this.this$0.stream);
              if (trackRefIndex == 0) {
                trakList = this.sampleTrakInfo;
                if (this.this$0.debug2)
                  System.out.println("set useTrakInfo as sampleTrakInfo"); 
              } else {
                trakList = this.trakInfo;
              } 
              if (this.this$0.debug1) {
                System.out.println("useTrakInfo is " + trakList);
                System.out.println("useTrakInfo.sampleOffsetTable is " + trakList.sampleOffsetTable);
              } 
              if (trakList.sampleOffsetTable == null) {
                l2 = trakList.index2Offset(sampleNumber - 1);
                if (this.this$0.debug1) {
                  System.out.println("chunkOffsets size is " + trakList.chunkOffsets.length);
                  System.out.println("sampleOffset from index2Offset " + l2);
                } 
              } else {
                l2 = trakList.sampleOffsetTable[sampleNumber - 1];
              } 
              l2 += byteOffset;
              long l1 = this.this$0.seekableStream.seek(l2);
              if (l1 == -2L) {
                buffer.setDiscard(true);
                this.offsetToStartOfPacketInfo = -1L;
                return;
              } 
              if (this.this$0.debug1)
                System.out.println("Audio: Seek to " + l2 + " and read " + numBytesToCopy + " bytes into buffer with offset " + rtpOffset); 
              this.parser.readBytes(this.this$0.stream, arrayOfByte, rtpOffset, numBytesToCopy);
              rtpOffset += numBytesToCopy;
              l1 = this.this$0.seekableStream.seek(saveCurrentPos);
              if (l1 == -2L) {
                buffer.setDiscard(true);
                this.offsetToStartOfPacketInfo = -1L;
                return;
              } 
            } else if (dataBlockSource == 0) {
              int length = this.parser.readByte(this.this$0.stream);
              this.parser.skip(this.this$0.stream, length);
              remainingHintSampleSize -= length;
            } else {
              System.err.println("DISCARD: dataBlockSource " + dataBlockSource + " not supported");
              buffer.setDiscard(true);
              this.offsetToStartOfPacketInfo = -1L;
              return;
            } 
          } 
          actualBytesRead = rtpOffset;
          if (this.this$0.debug1)
            System.out.println("Actual size of packet sent " + rtpOffset); 
          rtpOffset = 0;
          this.offsetToStartOfPacketInfo = this.parser.getLocation(this.this$0.stream);
          if (actualBytesRead == -2) {
            buffer.setDiscard(true);
            return;
          } 
        } 
        buffer.setLength(actualBytesRead);
        if (rtpMarkerSet) {
          if (this.this$0.debug)
            System.out.println("rtpMarkerSet: true"); 
          buffer.setFlags(buffer.getFlags() | 0x800);
        } else {
          if (this.this$0.debug)
            System.out.println("rtpMarkerSet: false"); 
          buffer.setFlags(buffer.getFlags() & 0xFFFFF7FF);
        } 
        buffer.setSequenceNumber(rtpSequenceNumber);
        double startTime = (this.trakInfo.index2TimeAndDuration(this.useChunkNumber)).startTime;
        long timeStamp = (long)(startTime * 1.0E9D);
        buffer.setTimeStamp(timeStamp);
        buffer.setDuration(-1L);
      } catch (IOException e) {
        buffer.setLength(0);
        buffer.setEOM(true);
      } 
      synchronized (this) {
        if (this.chunkNumber != this.useChunkNumber) {
          this.currentPacketNumber = 0;
          this.numPacketsInSample = -1;
          this.offsetToStartOfPacketInfo = -1L;
          rtpOffset = 0;
        } else {
          this.currentPacketNumber++;
          if (this.currentPacketNumber >= this.numPacketsInSample) {
            this.chunkNumber++;
            this.currentPacketNumber = 0;
            this.numPacketsInSample = -1;
            this.offsetToStartOfPacketInfo = -1L;
            rtpOffset = 0;
          } 
        } 
      } 
    }
  }
  
  private class HintVideoTrack extends VideoTrack {
    int hintSampleSize;
    
    int indexOfTrackBeingHinted;
    
    int maxPacketSize;
    
    int currentPacketNumber;
    
    int numPacketsInSample;
    
    long offsetToStartOfPacketInfo;
    
    QuicktimeParser.TrakList sampleTrakInfo;
    
    private final QuicktimeParser this$0;
    
    HintVideoTrack(QuicktimeParser this$0, QuicktimeParser.TrakList trakInfo) {
      super(this$0, trakInfo);
      this.this$0 = this$0;
      this.indexOfTrackBeingHinted = this.trakInfo.indexOfTrackBeingHinted;
      this.currentPacketNumber = 0;
      this.numPacketsInSample = -1;
      this.offsetToStartOfPacketInfo = -1L;
      this.sampleTrakInfo = null;
      this.format = ((QuicktimeParser.Hint)trakInfo.media).format;
      this.hintSampleSize = this.needBufferSize;
      this.maxPacketSize = trakInfo.maxPacketSize;
      if (this$0.debug1) {
        System.out.println("HintVideoTrack: Index of hinted track: " + trakInfo.indexOfTrackBeingHinted);
        System.out.println("HintVideoTrack: packet size is " + this.maxPacketSize);
      } 
      if (this.indexOfTrackBeingHinted >= 0) {
        this.sampleTrakInfo = this$0.trakList[this.indexOfTrackBeingHinted];
      } else if (this$0.debug) {
        System.out.println("sampleTrakInfo is not set " + this.indexOfTrackBeingHinted);
      } 
    }
    
    void doReadFrame(Buffer buffer) {
      byte[] arrayOfByte;
      boolean rtpMarkerSet = false;
      if (this.indexOfTrackBeingHinted < 0) {
        buffer.setDiscard(true);
        return;
      } 
      if (this.useSampleIndex >= this.trakInfo.numberOfSamples) {
        buffer.setLength(0);
        buffer.setEOM(true);
        return;
      } 
      int rtpOffset = 0;
      if (this.variableSampleSize)
        this.hintSampleSize = this.trakInfo.sampleSizeArray[this.useSampleIndex]; 
      int remainingHintSampleSize = this.hintSampleSize;
      long offset = this.trakInfo.sampleOffsetTable[this.useSampleIndex];
      if (this.this$0.debug1) {
        System.out.println("hintSampleSize is " + this.hintSampleSize);
        System.out.println("useSampleIndex, offset " + this.useSampleIndex + " : " + offset);
      } 
      Object obj = buffer.getData();
      if (obj == null || !(obj instanceof byte[]) || ((byte[])obj).length < this.maxPacketSize) {
        arrayOfByte = new byte[this.maxPacketSize];
        buffer.setData(arrayOfByte);
      } else {
        arrayOfByte = (byte[])obj;
      } 
      try {
        int rtpSequenceNumber, actualBytesRead;
        synchronized (this.this$0.seekSync) {
          if (this.sampleIndex != this.useSampleIndex) {
            buffer.setDiscard(true);
            this.currentPacketNumber = 0;
            this.numPacketsInSample = -1;
            this.offsetToStartOfPacketInfo = -1L;
            rtpOffset = 0;
            return;
          } 
          if (this.cacheStream != null && this.listener != null && 
            this.cacheStream.willReadBytesBlock(offset, this.hintSampleSize))
            this.listener.readHasBlocked(this); 
          if (this.offsetToStartOfPacketInfo < 0L) {
            long pos = this.this$0.seekableStream.seek(offset);
            if (pos == -2L) {
              buffer.setDiscard(true);
              return;
            } 
            this.numPacketsInSample = this.parser.readShort(this.this$0.stream);
            if (this.this$0.debug)
              System.out.println("video: num packets in sample " + this.numPacketsInSample); 
            if (this.numPacketsInSample < 1) {
              buffer.setDiscard(true);
              return;
            } 
            remainingHintSampleSize -= 2;
            this.parser.readShort(this.this$0.stream);
            remainingHintSampleSize -= 2;
          } else {
            long l = this.this$0.seekableStream.seek(this.offsetToStartOfPacketInfo);
            if (l == -2L) {
              buffer.setDiscard(true);
              return;
            } 
          } 
          int relativeTransmissionTime = this.parser.readInt(this.this$0.stream);
          remainingHintSampleSize -= 4;
          int rtpHeaderInfo = (short)this.parser.readShort(this.this$0.stream);
          rtpMarkerSet = ((rtpHeaderInfo & 0x80) > 0);
          remainingHintSampleSize -= 2;
          rtpSequenceNumber = this.parser.readShort(this.this$0.stream);
          remainingHintSampleSize -= 2;
          boolean paddingPresent = ((rtpHeaderInfo & 0x2000) > 0);
          boolean extensionHeaderPresent = ((rtpHeaderInfo & 0x1000) > 0);
          if (paddingPresent);
          if (extensionHeaderPresent);
          int flags = this.parser.readShort(this.this$0.stream);
          if (this.this$0.debug) {
            System.out.println("rtp marker present? " + rtpMarkerSet);
            System.out.println("rtp payload type " + (rtpHeaderInfo & 0x7F));
            System.out.println("padding? " + paddingPresent);
            System.out.println("extension header? " + extensionHeaderPresent);
            System.out.println("video hint: flags is " + Integer.toHexString(flags));
          } 
          remainingHintSampleSize -= 2;
          int entriesInDataTable = this.parser.readShort(this.this$0.stream);
          remainingHintSampleSize -= 2;
          boolean extraInfoTLVPresent = ((flags & 0x4) > 0);
          if (extraInfoTLVPresent) {
            int tlvTableSize = this.parser.readInt(this.this$0.stream);
            this.this$0.skip(this.this$0.stream, tlvTableSize - 4);
            if (this.this$0.debug) {
              System.err.println("video: extraInfoTLVPresent: Skipped");
              System.out.println("tlvTableSize is " + tlvTableSize);
            } 
          } 
          if (this.this$0.debug) {
            System.out.println("Packet # " + this.currentPacketNumber);
            System.out.println("  relativeTransmissionTime is " + relativeTransmissionTime);
            System.out.println("$$$ relativeTransmissionTime is in timescale " + this.trakInfo.mediaTimeScale);
            System.out.println("  rtpSequenceNumber is " + rtpSequenceNumber);
            System.out.println("  entriesInDataTable is " + entriesInDataTable);
          } 
          for (int j = 0; j < entriesInDataTable; j++) {
            int dataBlockSource = this.parser.readByte(this.this$0.stream);
            remainingHintSampleSize--;
            if (this.this$0.debug1)
              System.out.println("    dataBlockSource is " + dataBlockSource); 
            if (dataBlockSource == 1) {
              int length = this.parser.readByte(this.this$0.stream);
              remainingHintSampleSize--;
              this.parser.readBytes(this.this$0.stream, arrayOfByte, rtpOffset, length);
              rtpOffset += length;
              this.parser.skip(this.this$0.stream, 14 - length);
              remainingHintSampleSize -= 14;
            } else if (dataBlockSource == 2) {
              QuicktimeParser.TrakList trakList;
              int trackRefIndex = this.parser.readByte(this.this$0.stream);
              if (this.this$0.debug1)
                System.out.println("     video: trackRefIndex is " + trackRefIndex); 
              if (trackRefIndex > 0) {
                System.err.println("     Currently we don't support hint tracks that refer to multiple media tracks");
                buffer.setDiscard(true);
                return;
              } 
              int numBytesToCopy = this.parser.readShort(this.this$0.stream);
              int sampleNumber = this.parser.readInt(this.this$0.stream);
              int byteOffset = this.parser.readInt(this.this$0.stream);
              int bytesPerCompresionBlock = this.parser.readShort(this.this$0.stream);
              int samplesPerCompresionBlock = this.parser.readShort(this.this$0.stream);
              if (this.this$0.debug1) {
                System.out.println("     sample Number is " + sampleNumber);
                System.out.println("     numBytesToCopy is " + numBytesToCopy);
                System.out.println("     byteOffset is " + byteOffset);
                System.out.println("     bytesPerCompresionBlock is " + bytesPerCompresionBlock);
                System.out.println("     samplesPerCompresionBlock is " + samplesPerCompresionBlock);
              } 
              remainingHintSampleSize -= 15;
              long saveCurrentPos = this.parser.getLocation(this.this$0.stream);
              if (trackRefIndex == 0) {
                trakList = this.sampleTrakInfo;
              } else {
                trakList = this.trakInfo;
              } 
              long sampleOffset = trakList.sampleOffsetTable[sampleNumber - 1];
              sampleOffset += byteOffset;
              long l1 = this.this$0.seekableStream.seek(sampleOffset);
              if (l1 == -2L) {
                buffer.setDiscard(true);
                this.offsetToStartOfPacketInfo = -1L;
                return;
              } 
              if (this.this$0.debug1)
                System.out.println("     read " + numBytesToCopy + " bytes from offset " + rtpOffset); 
              this.parser.readBytes(this.this$0.stream, arrayOfByte, rtpOffset, numBytesToCopy);
              rtpOffset += numBytesToCopy;
              l1 = this.this$0.seekableStream.seek(saveCurrentPos);
              if (l1 == -2L) {
                buffer.setDiscard(true);
                this.offsetToStartOfPacketInfo = -1L;
                return;
              } 
            } else {
              buffer.setDiscard(true);
              this.offsetToStartOfPacketInfo = -1L;
              return;
            } 
          } 
          actualBytesRead = rtpOffset;
          if (this.this$0.debug1)
            System.out.println("Actual size of packet sent " + rtpOffset); 
          rtpOffset = 0;
          this.offsetToStartOfPacketInfo = this.parser.getLocation(this.this$0.stream);
          if (actualBytesRead == -2) {
            buffer.setDiscard(true);
            return;
          } 
        } 
        buffer.setLength(actualBytesRead);
        if (rtpMarkerSet) {
          if (this.this$0.debug)
            System.out.println("rtpMarkerSet: true"); 
          buffer.setFlags(buffer.getFlags() | 0x800);
        } else {
          if (this.this$0.debug)
            System.out.println("rtpMarkerSet: false"); 
          buffer.setFlags(buffer.getFlags() & 0xFFFFF7FF);
        } 
        buffer.setSequenceNumber(rtpSequenceNumber);
        QuicktimeParser.TimeAndDuration td = this.trakInfo.index2TimeAndDuration(this.useSampleIndex);
        double startTime = td.startTime;
        long timeStamp = (long)(startTime * 1.0E9D);
        buffer.setTimeStamp(timeStamp);
        buffer.setDuration((long)(td.duration * 1.0E9D));
      } catch (IOException e) {
        buffer.setLength(0);
        buffer.setEOM(true);
      } 
      synchronized (this) {
        if (this.sampleIndex != this.useSampleIndex) {
          this.currentPacketNumber = 0;
          this.numPacketsInSample = -1;
          this.offsetToStartOfPacketInfo = -1L;
          rtpOffset = 0;
        } else {
          this.currentPacketNumber++;
          if (this.currentPacketNumber >= this.numPacketsInSample) {
            this.sampleIndex++;
            this.currentPacketNumber = 0;
            this.numPacketsInSample = -1;
            this.offsetToStartOfPacketInfo = -1L;
            rtpOffset = 0;
          } 
        } 
      } 
    }
  }
  
  private class TimeAndDuration {
    double startTime;
    
    double duration;
    
    private final QuicktimeParser this$0;
    
    private TimeAndDuration(QuicktimeParser this$0) {
      QuicktimeParser.this = QuicktimeParser.this;
    }
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\parser\video\QuicktimeParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */