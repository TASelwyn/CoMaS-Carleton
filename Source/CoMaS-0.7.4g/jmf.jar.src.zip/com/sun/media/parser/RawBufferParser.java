/*     */ package com.sun.media.parser;
/*     */ 
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.CircularBuffer;
/*     */ import com.sun.media.rtp.Depacketizer;
/*     */ import java.awt.Dimension;
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Demultiplexer;
/*     */ import javax.media.Format;
/*     */ import javax.media.IncompatibleSourceException;
/*     */ import javax.media.PlugInManager;
/*     */ import javax.media.Time;
/*     */ import javax.media.Track;
/*     */ import javax.media.TrackListener;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ import javax.media.protocol.BufferTransferHandler;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PushBufferDataSource;
/*     */ import javax.media.protocol.PushBufferStream;
/*     */ import javax.media.protocol.SourceStream;
/*     */ 
/*     */ public class RawBufferParser
/*     */   extends RawStreamParser {
/*     */   static final String NAMEBUFFER = "Raw video/audio buffer stream parser";
/*     */   private boolean started = false;
/*  29 */   static AudioFormat mpegAudio = new AudioFormat("mpegaudio/rtp");
/*  30 */   static VideoFormat mpegVideo = new VideoFormat("mpeg/rtp");
/*  31 */   static VideoFormat jpegVideo = new VideoFormat("jpeg/rtp");
/*  32 */   static VideoFormat h261Video = new VideoFormat("h261/rtp");
/*  33 */   static VideoFormat h263Video = new VideoFormat("h263/rtp");
/*  34 */   static VideoFormat h263_1998Video = new VideoFormat("h263-1998/rtp");
/*     */   
/*     */   public String getName() {
/*  37 */     return "Raw video/audio buffer stream parser";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
/*  43 */     if (!(source instanceof PushBufferDataSource)) {
/*  44 */       throw new IncompatibleSourceException("DataSource not supported: " + source);
/*     */     }
/*  46 */     this.streams = (SourceStream[])((PushBufferDataSource)source).getStreams();
/*     */ 
/*     */     
/*  49 */     if (this.streams == null) {
/*  50 */       throw new IOException("Got a null stream from the DataSource");
/*     */     }
/*     */     
/*  53 */     if (this.streams.length == 0) {
/*  54 */       throw new IOException("Got a empty stream array from the DataSource");
/*     */     }
/*     */     
/*  57 */     if (!supports(this.streams)) {
/*  58 */       throw new IncompatibleSourceException("DataSource not supported: " + source);
/*     */     }
/*  60 */     this.source = source;
/*  61 */     this.streams = this.streams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean supports(SourceStream[] streams) {
/*  69 */     return (streams[0] != null && streams[0] instanceof PushBufferStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() {
/*  80 */     if (this.tracks != null)
/*     */       return; 
/*  82 */     this.tracks = new Track[this.streams.length];
/*  83 */     for (int i = 0; i < this.streams.length; i++) {
/*  84 */       this.tracks[i] = new FrameTrack(this, this, (PushBufferStream)this.streams[i], 1);
/*     */     }
/*     */   }
/*     */   
/*     */   public void close() {
/*  89 */     if (this.source != null) {
/*     */       try {
/*  91 */         this.source.stop();
/*     */ 
/*     */         
/*  94 */         for (int i = 0; i < this.tracks.length; i++) {
/*  95 */           ((FrameTrack)this.tracks[i]).stop();
/*  96 */           ((FrameTrack)this.tracks[i]).close();
/*     */         } 
/*     */         
/*  99 */         this.source.disconnect();
/* 100 */       } catch (Exception e) {}
/*     */ 
/*     */       
/* 103 */       this.source = null;
/*     */     } 
/* 105 */     this.started = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Track[] getTracks() {
/* 111 */     for (int i = 0; i < this.tracks.length; i++)
/* 112 */       ((FrameTrack)this.tracks[i]).parse(); 
/* 113 */     return this.tracks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() throws IOException {
/* 120 */     for (int i = 0; i < this.tracks.length; i++)
/* 121 */       ((FrameTrack)this.tracks[i]).start(); 
/* 122 */     this.source.start();
/* 123 */     this.started = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/*     */     try {
/* 131 */       this.source.stop();
/*     */       
/* 133 */       for (int i = 0; i < this.tracks.length; i++) {
/* 134 */         ((FrameTrack)this.tracks[i]).stop();
/*     */       }
/* 136 */     } catch (Exception e) {}
/*     */ 
/*     */     
/* 139 */     this.started = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 147 */     for (int i = 0; i < this.tracks.length; i++)
/* 148 */       ((FrameTrack)this.tracks[i]).reset(); 
/*     */   }
/*     */   
/*     */   boolean isRTPFormat(Format fmt) {
/* 152 */     return (fmt != null && fmt.getEncoding() != null && (fmt.getEncoding().endsWith("rtp") || fmt.getEncoding().endsWith("RTP")));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 163 */   final int[] h261Widths = new int[] { 176, 352 };
/* 164 */   final int[] h261Heights = new int[] { 144, 288 };
/*     */   
/* 166 */   final int[] h263Widths = new int[] { 0, 128, 176, 352, 704, 1408, 0, 0 };
/* 167 */   final int[] h263Heights = new int[] { 0, 96, 144, 288, 576, 1152, 0, 0 };
/*     */   
/* 169 */   final float[] MPEGRateTbl = new float[] { 0.0F, 23.976F, 24.0F, 25.0F, 29.97F, 30.0F, 50.0F, 59.94F, 60.0F };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 174 */   public static int[][] MPASampleTbl = new int[][] { { 22050, 24000, 16000, 0 }, { 44100, 48000, 32000, 0 } };
/*     */ 
/*     */   
/*     */   class FrameTrack
/*     */     implements Track, BufferTransferHandler
/*     */   {
/*     */     Demultiplexer parser;
/*     */     PushBufferStream pbs;
/*     */     boolean enabled;
/*     */     CircularBuffer bufferQ;
/*     */     Format format;
/*     */     TrackListener listener;
/*     */     boolean stopped;
/*     */     boolean closed;
/*     */     boolean keyFrameFound;
/*     */     boolean checkDepacketizer;
/*     */     Depacketizer depacketizer;
/*     */     Object keyFrameLock;
/*     */     private final RawBufferParser this$0;
/*     */     
/*     */     public FrameTrack(RawBufferParser this$0, Demultiplexer parser, PushBufferStream pbs, int numOfBufs) {
/* 195 */       this.this$0 = this$0; this.enabled = true; this.format = null; this.stopped = true; this.closed = false; this.keyFrameFound = false; this.checkDepacketizer = false; this.depacketizer = null; this.keyFrameLock = new Object();
/* 196 */       this.pbs = pbs;
/* 197 */       this.format = pbs.getFormat();
/*     */       
/* 199 */       if (this$0.source instanceof com.sun.media.protocol.DelegateDataSource || !this$0.isRTPFormat(this.format))
/*     */       {
/* 201 */         this.keyFrameFound = true;
/*     */       }
/*     */       
/* 204 */       this.bufferQ = new CircularBuffer(numOfBufs);
/* 205 */       pbs.setTransferHandler(this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Format getFormat() {
/* 211 */       return this.format;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean t) {
/* 215 */       if (t) {
/* 216 */         this.pbs.setTransferHandler(this);
/*     */       } else {
/* 218 */         this.pbs.setTransferHandler(null);
/* 219 */       }  this.enabled = t;
/*     */     }
/*     */     
/*     */     public boolean isEnabled() {
/* 223 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public Time getDuration() {
/* 227 */       return this.parser.getDuration();
/*     */     }
/*     */     
/*     */     public Time getStartTime() {
/* 231 */       return new Time(0L);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setTrackListener(TrackListener l) {
/* 236 */       this.listener = l;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void parse() {
/*     */       try {
/* 245 */         synchronized (this.keyFrameLock) {
/* 246 */           while (!this.keyFrameFound)
/* 247 */             this.keyFrameLock.wait(); 
/*     */         } 
/* 249 */       } catch (Exception e) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Depacketizer findDepacketizer(String name, Format input) {
/*     */       
/* 260 */       try { Class cls = BasicPlugIn.getClassForName(name);
/* 261 */         Object obj = cls.newInstance();
/*     */         
/* 263 */         if (!(obj instanceof Depacketizer)) {
/* 264 */           return null;
/*     */         }
/* 266 */         Depacketizer dpktizer = (Depacketizer)obj;
/*     */         
/* 268 */         if (dpktizer.setInputFormat(input) == null) {
/* 269 */           return null;
/*     */         }
/* 271 */         dpktizer.open();
/*     */         
/* 273 */         return dpktizer; }
/*     */       
/* 275 */       catch (Exception e) {  }
/* 276 */       catch (Error e) {}
/*     */       
/* 278 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean findKeyFrame(Buffer buf) {
/* 284 */       if (!this.checkDepacketizer) {
/*     */ 
/*     */ 
/*     */         
/* 288 */         Vector pnames = PlugInManager.getPlugInList(buf.getFormat(), null, 6);
/*     */         
/* 290 */         if (pnames.size() != 0) {
/* 291 */           this.depacketizer = findDepacketizer(pnames.elementAt(0), buf.getFormat());
/*     */         }
/*     */         
/* 294 */         this.checkDepacketizer = true;
/*     */       } 
/*     */       
/* 297 */       Format fmt = buf.getFormat();
/*     */       
/* 299 */       if (fmt == null) {
/* 300 */         return false;
/*     */       }
/* 302 */       if (fmt.getEncoding() == null) {
/* 303 */         synchronized (this.keyFrameLock) {
/* 304 */           this.keyFrameFound = true;
/* 305 */           this.keyFrameLock.notifyAll();
/*     */         } 
/* 307 */         return true;
/*     */       } 
/*     */       
/* 310 */       boolean rtn = true;
/*     */       
/* 312 */       if (RawBufferParser.jpegVideo.matches(fmt)) {
/* 313 */         rtn = findJPEGKey(buf);
/* 314 */       } else if (RawBufferParser.h261Video.matches(fmt)) {
/* 315 */         rtn = findH261Key(buf);
/* 316 */       } else if (RawBufferParser.h263Video.matches(fmt)) {
/* 317 */         rtn = findH263Key(buf);
/* 318 */       } else if (RawBufferParser.h263_1998Video.matches(fmt)) {
/* 319 */         rtn = findH263_1998Key(buf);
/* 320 */       } else if (RawBufferParser.mpegVideo.matches(fmt)) {
/* 321 */         rtn = findMPEGKey(buf);
/* 322 */       } else if (RawBufferParser.mpegAudio.matches(fmt)) {
/* 323 */         rtn = findMPAKey(buf);
/* 324 */       } else if (this.depacketizer != null) {
/* 325 */         fmt = this.depacketizer.parse(buf);
/* 326 */         if (fmt != null) {
/*     */ 
/*     */           
/* 329 */           this.format = fmt;
/* 330 */           buf.setFormat(this.format);
/* 331 */           this.depacketizer.close();
/* 332 */           this.depacketizer = null;
/*     */         } else {
/* 334 */           rtn = false;
/*     */         } 
/*     */       } 
/* 337 */       if (rtn) {
/* 338 */         synchronized (this.keyFrameLock) {
/* 339 */           this.keyFrameFound = true;
/* 340 */           this.keyFrameLock.notifyAll();
/*     */         } 
/*     */       }
/*     */       
/* 344 */       return this.keyFrameFound;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean findJPEGKey(Buffer b) {
/* 354 */       if ((b.getFlags() & 0x800) == 0) {
/* 355 */         return false;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 360 */       byte[] data = (byte[])b.getData();
/* 361 */       int width = (data[b.getOffset() + 6] & 0xFF) * 8;
/* 362 */       int height = (data[b.getOffset() + 7] & 0xFF) * 8;
/*     */       
/* 364 */       this.format = (Format)new VideoFormat("jpeg/rtp", new Dimension(width, height), ((VideoFormat)this.format).getMaxDataLength(), ((VideoFormat)this.format).getDataType(), ((VideoFormat)this.format).getFrameRate());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 370 */       b.setFormat(this.format);
/* 371 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean findH261Key(Buffer b) {
/*     */       byte[] data;
/* 383 */       if ((data = (byte[])b.getData()) == null) {
/* 384 */         return false;
/*     */       }
/* 386 */       int offset = b.getOffset();
/*     */ 
/*     */       
/* 389 */       int skipBytes = 4;
/*     */       
/* 391 */       if (data[offset + skipBytes] != 0 || data[offset + skipBytes + 1] != 1 || (data[offset + skipBytes + 2] & 0xFC) != 0)
/*     */       {
/*     */         
/* 394 */         return false;
/*     */       }
/*     */       
/* 397 */       int s = data[offset + skipBytes + 3] >> 3 & 0x1;
/* 398 */       int width = this.this$0.h261Widths[s];
/* 399 */       int height = this.this$0.h261Heights[s];
/* 400 */       this.format = (Format)new VideoFormat("h261/rtp", new Dimension(width, height), ((VideoFormat)this.format).getMaxDataLength(), ((VideoFormat)this.format).getDataType(), ((VideoFormat)this.format).getFrameRate());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 406 */       b.setFormat(this.format);
/* 407 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean findH263Key(Buffer b) {
/*     */       byte[] data;
/* 419 */       if ((data = (byte[])b.getData()) == null) {
/* 420 */         return false;
/*     */       }
/* 422 */       int payloadLen = getH263PayloadHeaderLength(data, b.getOffset());
/* 423 */       int offset = b.getOffset();
/* 424 */       if (data[offset + payloadLen] != 0 || data[offset + payloadLen + 1] != 0 || (data[offset + payloadLen + 2] & 0xFC) != 128)
/*     */       {
/*     */         
/* 427 */         return false;
/*     */       }
/* 429 */       int s = data[offset + payloadLen + 4] >> 2 & 0x7;
/* 430 */       int width = this.this$0.h263Widths[s];
/* 431 */       int height = this.this$0.h263Heights[s];
/*     */       
/* 433 */       this.format = (Format)new VideoFormat("h263/rtp", new Dimension(width, height), ((VideoFormat)this.format).getMaxDataLength(), ((VideoFormat)this.format).getDataType(), ((VideoFormat)this.format).getFrameRate());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 439 */       b.setFormat(this.format);
/* 440 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     int getH263PayloadHeaderLength(byte[] input, int offset) {
/* 446 */       int l = 0;
/* 447 */       byte b = input[offset];
/*     */       
/* 449 */       if ((b & 0x80) != 0)
/* 450 */       { if ((b & 0x40) != 0) {
/* 451 */           l = 12;
/*     */         } else {
/* 453 */           l = 8;
/*     */         }  }
/* 455 */       else { l = 4; }
/*     */ 
/*     */       
/* 458 */       return l;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean findH263_1998Key(Buffer b) {
/* 469 */       int s = -1;
/* 470 */       int picOffset = -1;
/*     */       byte[] data;
/* 472 */       if ((data = (byte[])b.getData()) == null) {
/* 473 */         return false;
/*     */       }
/* 475 */       int offset = b.getOffset();
/*     */ 
/*     */       
/* 478 */       int payloadLen = 2 + ((data[offset] & 0x1) << 5 | (data[offset + 1] & 0xF8) >> 3);
/*     */       
/* 480 */       if ((data[offset] & 0x2) != 0) {
/* 481 */         payloadLen++;
/*     */       }
/*     */       
/* 484 */       picOffset = -1;
/*     */       
/* 486 */       if (payloadLen > 5) {
/*     */         
/* 488 */         if ((data[offset] & 0x2) == 2 && (data[offset + 3] & 0xFC) == 128) {
/*     */           
/* 490 */           picOffset = offset + 3;
/* 491 */         } else if ((data[offset + 2] & 0xFC) == 128) {
/* 492 */           picOffset = offset + 2;
/*     */         } 
/* 494 */       } else if ((data[offset] & 0x4) == 4 && (data[offset + payloadLen] & 0xFC) == 128) {
/*     */         
/* 496 */         picOffset = offset + payloadLen;
/*     */       } 
/*     */       
/* 499 */       if (picOffset < 0) {
/* 500 */         return false;
/*     */       }
/* 502 */       s = data[picOffset + 2] >> 2 & 0x7;
/* 503 */       if (s == 7)
/*     */       {
/*     */         
/* 506 */         if ((data[picOffset + 3] >> 1 & 0x7) == 1) {
/* 507 */           s = data[picOffset + 3] << 2 & 0x4 | data[picOffset + 4] >> 6 & 0x3;
/*     */         } else {
/*     */           
/* 510 */           return false;
/*     */         } 
/*     */       }
/* 513 */       if (s < 0) {
/* 514 */         return false;
/*     */       }
/* 516 */       int width = this.this$0.h263Widths[s];
/* 517 */       int height = this.this$0.h263Heights[s];
/*     */       
/* 519 */       this.format = (Format)new VideoFormat("h263-1998/rtp", new Dimension(width, height), ((VideoFormat)this.format).getMaxDataLength(), ((VideoFormat)this.format).getDataType(), ((VideoFormat)this.format).getFrameRate());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 524 */       b.setFormat(this.format);
/* 525 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean findMPEGKey(Buffer b) {
/*     */       byte[] data;
/* 538 */       if ((data = (byte[])b.getData()) == null) {
/* 539 */         return false;
/*     */       }
/*     */       
/* 542 */       int off = b.getOffset();
/* 543 */       if (b.getLength() < 12) {
/* 544 */         return false;
/*     */       }
/*     */       
/* 547 */       if ((data[off + 2] & 0x20) != 32) {
/* 548 */         return false;
/*     */       }
/*     */       
/* 551 */       if (data[off + 4] != 0 || data[off + 5] != 0 || data[off + 6] != 1 || (data[off + 7] & 0xFF) != 179)
/*     */       {
/*     */ 
/*     */         
/* 555 */         return false;
/*     */       }
/*     */       
/* 558 */       int frix = data[off + 11] & 0xF;
/* 559 */       if (frix == 0 || frix > 8) {
/* 560 */         return false;
/*     */       }
/*     */       
/* 563 */       int width = (data[off + 8] & 0xFF) << 4 | (data[off + 9] & 0xF0) >> 4;
/*     */       
/* 565 */       int height = (data[off + 9] & 0xF) << 8 | data[off + 10] & 0xFF;
/* 566 */       float frameRate = this.this$0.MPEGRateTbl[frix];
/*     */       
/* 568 */       this.format = (Format)new VideoFormat("mpeg/rtp", new Dimension(width, height), ((VideoFormat)this.format).getMaxDataLength(), ((VideoFormat)this.format).getDataType(), frameRate);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 574 */       b.setFormat(this.format);
/* 575 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean findMPAKey(Buffer b) {
/*     */       byte[] data;
/* 588 */       if ((data = (byte[])b.getData()) == null) {
/* 589 */         return false;
/*     */       }
/* 591 */       int off = b.getOffset();
/* 592 */       if (b.getLength() < 8) {
/* 593 */         return false;
/*     */       }
/* 595 */       if (data[off + 2] != 0 || data[off + 3] != 0) {
/* 596 */         return false;
/*     */       }
/* 598 */       off += 4;
/* 599 */       if ((data[off] & 0xFF) != 255 || (data[off + 1] & 0xF6) <= 240 || (data[off + 2] & 0xF0) == 240 || (data[off + 2] & 0xC) == 12 || (data[off + 3] & 0x3) == 2)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 604 */         return false;
/*     */       }
/* 606 */       int id = data[off + 1] >> 3 & 0x1;
/* 607 */       int six = data[off + 2] >> 2 & 0x3;
/* 608 */       int channels = ((data[off + 3] >> 6 & 0x3) == 3) ? 1 : 2;
/* 609 */       double sampleRate = RawBufferParser.MPASampleTbl[id][six];
/*     */       
/* 611 */       this.format = (Format)new AudioFormat("mpegaudio/rtp", sampleRate, 16, channels, 0, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 616 */       b.setFormat(this.format);
/* 617 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void stop() {
/* 625 */       synchronized (this.bufferQ) {
/* 626 */         this.stopped = true;
/* 627 */         this.bufferQ.notifyAll();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void start() {
/* 634 */       synchronized (this.bufferQ) {
/* 635 */         this.stopped = false;
/* 636 */         if (this.this$0.source instanceof javax.media.protocol.CaptureDevice)
/*     */         {
/* 638 */           while (this.bufferQ.canRead()) {
/* 639 */             this.bufferQ.read();
/* 640 */             this.bufferQ.readReport();
/*     */           } 
/*     */         }
/* 643 */         this.bufferQ.notifyAll();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() {
/* 649 */       setEnabled(false);
/* 650 */       synchronized (this.bufferQ) {
/* 651 */         this.closed = true;
/* 652 */         this.bufferQ.notifyAll();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void reset() {}
/*     */ 
/*     */     
/*     */     public void readFrame(Buffer buffer) {
/*     */       Buffer filled;
/* 662 */       if (this.stopped) {
/* 663 */         buffer.setDiscard(true);
/* 664 */         buffer.setFormat(this.format);
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 669 */       synchronized (this.bufferQ) {
/* 670 */         while (!this.bufferQ.canRead()) {
/*     */           try {
/* 672 */             this.bufferQ.wait();
/* 673 */             if (this.stopped) {
/* 674 */               buffer.setDiscard(true);
/* 675 */               buffer.setFormat(this.format);
/*     */               return;
/*     */             } 
/* 678 */           } catch (Exception e) {}
/*     */         } 
/* 680 */         filled = this.bufferQ.read();
/*     */       } 
/*     */ 
/*     */       
/* 684 */       Object hdr = buffer.getHeader();
/* 685 */       buffer.copy(filled, true);
/* 686 */       filled.setHeader(hdr);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 692 */       this.format = filled.getFormat();
/*     */       
/* 694 */       synchronized (this.bufferQ) {
/* 695 */         this.bufferQ.readReport();
/* 696 */         this.bufferQ.notifyAll();
/*     */       } 
/*     */     }
/*     */     
/*     */     public int mapTimeToFrame(Time t) {
/* 701 */       return -1;
/*     */     }
/*     */     
/*     */     public Time mapFrameToTime(int frameNumber) {
/* 705 */       return new Time(0L);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void transferData(PushBufferStream pbs) {
/*     */       Buffer buffer;
/* 712 */       synchronized (this.bufferQ) {
/* 713 */         while (!this.bufferQ.canWrite() && !this.closed) {
/*     */           try {
/* 715 */             this.bufferQ.wait();
/* 716 */           } catch (Exception e) {}
/*     */         } 
/*     */         
/* 719 */         if (this.closed)
/*     */           return; 
/* 721 */         buffer = this.bufferQ.getEmptyBuffer();
/*     */       } 
/*     */       
/*     */       try {
/* 725 */         pbs.read(buffer);
/*     */       } catch (IOException e) {
/* 727 */         buffer.setDiscard(true);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 732 */       if (!this.keyFrameFound && !findKeyFrame(buffer)) {
/* 733 */         synchronized (this.bufferQ) {
/*     */           
/* 735 */           this.bufferQ.writeReport();
/* 736 */           this.bufferQ.read();
/* 737 */           this.bufferQ.readReport();
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 743 */       synchronized (this.bufferQ) {
/* 744 */         this.bufferQ.writeReport();
/* 745 */         this.bufferQ.notifyAll();
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\parser\RawBufferParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */