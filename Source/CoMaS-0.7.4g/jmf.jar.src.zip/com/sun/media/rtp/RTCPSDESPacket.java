package com.sun.media.rtp;

import java.io.DataOutputStream;
import java.io.IOException;

public class RTCPSDESPacket extends RTCPPacket {
  public RTCPSDES[] sdes;
  
  public RTCPSDESPacket(RTCPPacket parent) {
    super(parent);
    this.type = 202;
  }
  
  public RTCPSDESPacket(RTCPSDES[] sdes) {
    this.sdes = sdes;
    if (sdes.length > 31)
      throw new IllegalArgumentException("Too many SDESs"); 
  }
  
  public String toString() {
    return "\tRTCP SDES Packet:\n" + RTCPSDES.toString(this.sdes);
  }
  
  public int calcLength() {
    int len = 4;
    for (int i = 0; i < this.sdes.length; i++) {
      int sublen = 5;
      for (int j = 0; j < (this.sdes[i]).items.length; j++)
        sublen += 2 + ((this.sdes[i]).items[j]).data.length; 
      sublen = sublen + 3 & 0xFFFFFFFC;
      len += sublen;
    } 
    return len;
  }
  
  void assemble(DataOutputStream out) throws IOException {
    out.writeByte(128 + this.sdes.length);
    out.writeByte(202);
    out.writeShort(calcLength() - 4 >> 2);
    for (int i = 0; i < this.sdes.length; i++) {
      out.writeInt((this.sdes[i]).ssrc);
      int sublen = 0;
      for (int j = 0; j < (this.sdes[i]).items.length; j++) {
        out.writeByte(((this.sdes[i]).items[j]).type);
        out.writeByte(((this.sdes[i]).items[j]).data.length);
        out.write(((this.sdes[i]).items[j]).data);
        sublen += 2 + ((this.sdes[i]).items[j]).data.length;
      } 
      for (int k = (sublen + 4 & 0xFFFFFFFC) - sublen; k > 0; k--)
        out.writeByte(0); 
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTCPSDESPacket.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */