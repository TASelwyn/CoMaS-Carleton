package com.sun.media.rtp;

import com.sun.media.rtp.util.Packet;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class RTCPCompoundPacket extends RTCPPacket {
  RTCPPacket[] packets;
  
  public RTCPCompoundPacket(Packet base) {
    super(base);
    this.type = -1;
  }
  
  public RTCPCompoundPacket(RTCPPacket[] packets) {
    this.packets = packets;
    this.type = -1;
    this.received = false;
  }
  
  public String toString() {
    return "RTCP Packet with the following subpackets:\n" + toString(this.packets);
  }
  
  public String toString(RTCPPacket[] packets) {
    String s = "";
    for (int i = 0; i < packets.length; i++)
      s = s + packets[i]; 
    return s;
  }
  
  public int calcLength() {
    int len = 0;
    if (this.packets == null || this.packets.length < 1)
      throw new IllegalArgumentException("Bad RTCP Compound Packet"); 
    for (int i = 0; i < this.packets.length; i++)
      len += this.packets[i].calcLength(); 
    return len;
  }
  
  void assemble(DataOutputStream out) throws IOException {
    throw new IllegalArgumentException("Recursive Compound Packet");
  }
  
  public void assemble(int len, boolean encrypted) {
    int laststart;
    this.length = len;
    this.offset = 0;
    ByteArrayOutputStream baos = new ByteArrayOutputStream(len);
    DataOutputStream out = new DataOutputStream(baos);
    try {
      if (encrypted)
        this.offset += 4; 
      laststart = this.offset;
      for (int i = 0; i < this.packets.length; i++) {
        laststart = baos.size();
        this.packets[i].assemble(out);
      } 
    } catch (IOException e) {
      throw new NullPointerException("Impossible IO Exception");
    } 
    int prelen = baos.size();
    this.data = baos.toByteArray();
    if (prelen > len)
      throw new NullPointerException("RTCP Packet overflow"); 
    if (prelen < len) {
      if (this.data.length < len)
        System.arraycopy(this.data, 0, this.data = new byte[len], 0, prelen); 
      this.data[laststart] = (byte)(this.data[laststart] | 0x20);
      this.data[len - 1] = (byte)(len - prelen);
      int temp = (this.data[laststart + 3] & 0xFF) + (len - prelen >> 2);
      if (temp >= 256)
        this.data[laststart + 2] = (byte)(this.data[laststart + 2] + (len - prelen >> 10)); 
      this.data[laststart + 3] = (byte)temp;
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTCPCompoundPacket.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */