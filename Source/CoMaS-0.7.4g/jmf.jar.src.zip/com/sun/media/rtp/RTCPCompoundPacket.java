/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import com.sun.media.rtp.util.Packet;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RTCPCompoundPacket
/*    */   extends RTCPPacket
/*    */ {
/*    */   RTCPPacket[] packets;
/*    */   
/*    */   public RTCPCompoundPacket(Packet base) {
/* 16 */     super(base);
/* 17 */     this.type = -1;
/*    */   }
/*    */ 
/*    */   
/*    */   public RTCPCompoundPacket(RTCPPacket[] packets) {
/* 22 */     this.packets = packets;
/* 23 */     this.type = -1;
/* 24 */     this.received = false;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 28 */     return "RTCP Packet with the following subpackets:\n" + toString(this.packets);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString(RTCPPacket[] packets) {
/* 33 */     String s = "";
/* 34 */     for (int i = 0; i < packets.length; i++)
/* 35 */       s = s + packets[i]; 
/* 36 */     return s;
/*    */   }
/*    */   
/*    */   public int calcLength() {
/* 40 */     int len = 0;
/* 41 */     if (this.packets == null || this.packets.length < 1)
/* 42 */       throw new IllegalArgumentException("Bad RTCP Compound Packet"); 
/* 43 */     for (int i = 0; i < this.packets.length; i++)
/* 44 */       len += this.packets[i].calcLength(); 
/* 45 */     return len;
/*    */   }
/*    */   
/*    */   void assemble(DataOutputStream out) throws IOException {
/* 49 */     throw new IllegalArgumentException("Recursive Compound Packet");
/*    */   }
/*    */   public void assemble(int len, boolean encrypted) {
/*    */     int laststart;
/* 53 */     this.length = len;
/* 54 */     this.offset = 0;
/* 55 */     ByteArrayOutputStream baos = new ByteArrayOutputStream(len);
/* 56 */     DataOutputStream out = new DataOutputStream(baos);
/*    */ 
/*    */     
/*    */     try {
/* 60 */       if (encrypted)
/*    */       {
/*    */         
/* 63 */         this.offset += 4;
/*    */       }
/* 65 */       laststart = this.offset;
/* 66 */       for (int i = 0; i < this.packets.length; i++) {
/*    */         
/* 68 */         laststart = baos.size();
/* 69 */         this.packets[i].assemble(out);
/*    */       } 
/*    */     } catch (IOException e) {
/*    */       
/* 73 */       throw new NullPointerException("Impossible IO Exception");
/* 74 */     }  int prelen = baos.size();
/* 75 */     this.data = baos.toByteArray();
/* 76 */     if (prelen > len)
/* 77 */       throw new NullPointerException("RTCP Packet overflow"); 
/* 78 */     if (prelen < len) {
/*    */       
/* 80 */       if (this.data.length < len)
/* 81 */         System.arraycopy(this.data, 0, this.data = new byte[len], 0, prelen); 
/* 82 */       this.data[laststart] = (byte)(this.data[laststart] | 0x20);
/* 83 */       this.data[len - 1] = (byte)(len - prelen);
/* 84 */       int temp = (this.data[laststart + 3] & 0xFF) + (len - prelen >> 2);
/* 85 */       if (temp >= 256)
/* 86 */         this.data[laststart + 2] = (byte)(this.data[laststart + 2] + (len - prelen >> 10)); 
/* 87 */       this.data[laststart + 3] = (byte)temp;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtp\RTCPCompoundPacket.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */