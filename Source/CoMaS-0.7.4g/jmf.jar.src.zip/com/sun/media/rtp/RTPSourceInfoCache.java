package com.sun.media.rtp;

import java.util.Hashtable;

public class RTPSourceInfoCache {
  public SSRCCache ssrccache;
  
  Hashtable cache = new Hashtable(20);
  
  RTPSourceInfoCache main;
  
  public void setMainCache(RTPSourceInfoCache main) {
    this.main = main;
  }
  
  public RTPSourceInfoCache getMainCache() {
    if (this.main == null)
      this.main = new RTPSourceInfoCache(); 
    return this.main;
  }
  
  public void setSSRCCache(SSRCCache ssrccache) {
    this.main.ssrccache = ssrccache;
  }
  
  public RTPSourceInfo get(String cname, boolean local) {
    RTPSourceInfo info = null;
    synchronized (this) {
      info = (RTPSourceInfo)this.cache.get(cname);
      if (info == null && !local) {
        info = new RTPRemoteSourceInfo(cname, this.main);
        this.cache.put(cname, info);
      } 
      if (info == null && local) {
        info = new RTPLocalSourceInfo(cname, this.main);
        this.cache.put(cname, info);
      } 
    } 
    return info;
  }
  
  public void remove(String cname) {
    this.cache.remove(cname);
  }
  
  public Hashtable getCacheTable() {
    return this.cache;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTPSourceInfoCache.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */