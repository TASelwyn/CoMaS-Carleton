/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RTCPSDESItem
/*    */ {
/*    */   public int type;
/*    */   public byte[] data;
/*    */   public static final int CNAME = 1;
/*    */   public static final int NAME = 2;
/*    */   public static final int EMAIL = 3;
/*    */   public static final int PHONE = 4;
/*    */   public static final int LOC = 5;
/*    */   public static final int TOOL = 6;
/*    */   public static final int NOTE = 7;
/*    */   public static final int PRIV = 8;
/*    */   public static final int HIGHEST = 8;
/* 26 */   public static final String[] names = new String[] { "CNAME", "NAME", "EMAIL", "PHONE", "LOC", "TOOL", "NOTE", "PRIV" };
/*    */ 
/*    */   
/*    */   public RTCPSDESItem() {}
/*    */   
/*    */   public RTCPSDESItem(int type, String s) {
/* 32 */     this.type = type;
/* 33 */     this.data = new byte[s.length()];
/* 34 */     this.data = s.getBytes();
/*    */   }
/*    */   public String toString() {
/* 37 */     return "\t\t\t" + names[this.type - 1] + ": " + new String(this.data) + "\n";
/*    */   }
/*    */   public static String toString(RTCPSDESItem[] items) {
/* 40 */     String s = "";
/* 41 */     for (int i = 0; i < items.length; i++)
/* 42 */       s = s + items[i]; 
/* 43 */     return s;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtp\RTCPSDESItem.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */