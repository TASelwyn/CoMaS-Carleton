/*     */ package com.sun.media.rtp;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.rtp.util.RTPMediaThread;
/*     */ import com.sun.media.util.MediaThread;
/*     */ import com.sun.media.util.jdk12;
/*     */ import com.sun.media.util.jdk12CreateThreadRunnableAction;
/*     */ import com.sun.media.util.jdk12PriorityAction;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetAddress;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RTCPReporter
/*     */   implements Runnable
/*     */ {
/*     */   RTCPTransmitter transmit;
/*     */   SSRCCache cache;
/*     */   RTPMediaThread reportthread;
/*     */   Random myrand;
/*     */   boolean restart = false;
/*     */   boolean closed = false;
/*     */   InetAddress host;
/*     */   String cname;
/*  38 */   private static JMFSecurity jmfSecurity = null;
/*     */   private static boolean securityPrivelege = false;
/*  40 */   private Method[] m = new Method[1];
/*  41 */   private Class[] cl = new Class[1];
/*  42 */   private Object[][] args = new Object[1][0];
/*     */   
/*     */   static {
/*     */     try {
/*  46 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  47 */       securityPrivelege = true;
/*  48 */     } catch (SecurityException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RTCPReporter(SSRCCache cache, RTCPTransmitter t) {
/*  55 */     this.cache = cache;
/*  56 */     setTransmitter(t);
/*     */     
/*  58 */     if (jmfSecurity != null) {
/*  59 */       String permission = null;
/*     */       try {
/*  61 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  62 */           permission = "thread";
/*  63 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/*  64 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*     */           
/*  66 */           permission = "thread group";
/*  67 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/*  68 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*     */         }
/*  70 */         else if (jmfSecurity.getName().startsWith("internet")) {
/*  71 */           PolicyEngine.checkPermission(PermissionID.THREAD);
/*  72 */           PolicyEngine.assertPermission(PermissionID.THREAD);
/*     */         }
/*     */       
/*  75 */       } catch (Throwable e) {
/*     */ 
/*     */ 
/*     */         
/*  79 */         if (permission.endsWith("group")) {
/*  80 */           jmfSecurity.permissionFailureNotification(32);
/*     */         } else {
/*  82 */           jmfSecurity.permissionFailureNotification(16);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  87 */     if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*     */       try {
/*  89 */         Constructor cons = jdk12CreateThreadRunnableAction.cons;
/*     */         
/*  91 */         this.reportthread = (RTPMediaThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { RTPMediaThread.class, this }) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 100 */         this.reportthread.setName("RTCP Reporter");
/*     */         
/* 102 */         cons = jdk12PriorityAction.cons;
/* 103 */         jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { this.reportthread, new Integer(MediaThread.getControlPriority()) }) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 111 */       catch (Exception e) {}
/*     */     } else {
/*     */       
/* 114 */       this.reportthread = new RTPMediaThread(this, "RTCP Reporter");
/* 115 */       this.reportthread.useControlPriority();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 120 */     this.reportthread.setDaemon(true);
/*     */     
/* 122 */     this.reportthread.start();
/*     */   }
/*     */   public void setTransmitter(RTCPTransmitter t) {
/* 125 */     this.transmit = t;
/*     */   }
/*     */   public void close(String reason) {
/* 128 */     synchronized (this.reportthread) {
/* 129 */       this.closed = true;
/* 130 */       this.reportthread.notify();
/*     */     } 
/* 132 */     releasessrc(reason);
/* 133 */     this.transmit.close();
/*     */   }
/*     */   
/*     */   public void releasessrc(String reason) {
/* 137 */     this.transmit.bye(reason);
/*     */     
/* 139 */     this.transmit.ssrcInfo.setOurs(false);
/*     */     
/* 141 */     this.transmit.ssrcInfo = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 147 */     if (jmfSecurity != null) {
/*     */       try {
/* 149 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 150 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 128);
/* 151 */           this.m[0].invoke(this.cl[0], this.args[0]);
/* 152 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/* 153 */           PolicyEngine.checkPermission(PermissionID.NETIO);
/* 154 */           PolicyEngine.assertPermission(PermissionID.NETIO);
/*     */         }
/*     */       
/* 157 */       } catch (Throwable e) {
/*     */ 
/*     */ 
/*     */         
/* 161 */         jmfSecurity.permissionFailureNotification(128);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 172 */     if (this.restart) {
/* 173 */       this.restart = false;
/*     */     }
/*     */ 
/*     */     
/*     */     while (true) {
/* 178 */       double delay = this.cache.calcReportInterval(this.cache.ourssrc.sender, false);
/*     */       
/* 180 */       synchronized (this.reportthread) {
/*     */         
/*     */         try {
/* 183 */           this.reportthread.wait((long)delay);
/*     */         } catch (InterruptedException e) {
/* 185 */           Log.dumpStack(e);
/*     */         } 
/*     */       } 
/*     */       
/* 189 */       if (this.closed) {
/*     */         return;
/*     */       }
/* 192 */       if (!this.restart) {
/* 193 */         this.transmit.report(); continue;
/*     */       } 
/* 195 */       this.restart = false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtp\RTCPReporter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */