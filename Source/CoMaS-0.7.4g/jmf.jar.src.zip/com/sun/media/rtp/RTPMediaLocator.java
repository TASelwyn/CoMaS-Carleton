/*     */ package com.sun.media.rtp;
/*     */ 
/*     */ import java.net.InetAddress;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.UnknownHostException;
/*     */ import javax.media.MediaLocator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RTPMediaLocator
/*     */   extends MediaLocator
/*     */ {
/*  28 */   String address = "";
/*  29 */   String contentType = "";
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean valid = true;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int PORT_UNDEFINED = -1;
/*     */ 
/*     */   
/*     */   public static final int SSRC_UNDEFINED = 0;
/*     */ 
/*     */   
/*     */   public static final int TTL_UNDEFINED = 1;
/*     */ 
/*     */   
/*  46 */   int port = -1;
/*  47 */   long ssrc = 0L;
/*  48 */   int ttl = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RTPMediaLocator(String locatorString) throws MalformedURLException {
/*  59 */     super(locatorString);
/*     */ 
/*     */     
/*  62 */     parseLocator(locatorString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseLocator(String locatorString) throws MalformedURLException {
/*  70 */     String remainder = getRemainder();
/*  71 */     int colonIndex = remainder.indexOf(":");
/*  72 */     int slashIndex = remainder.indexOf("/", 2);
/*  73 */     int nextcolonIndex = -1;
/*  74 */     int nextslashIndex = -1;
/*  75 */     if (colonIndex != -1)
/*  76 */       nextcolonIndex = remainder.indexOf(":", colonIndex + 1); 
/*  77 */     if (slashIndex != -1) {
/*  78 */       nextslashIndex = remainder.indexOf("/", slashIndex + 1);
/*     */     }
/*  80 */     if (colonIndex != -1) {
/*  81 */       this.address = remainder.substring(2, colonIndex);
/*     */     }
/*     */     try {
/*  84 */       InetAddress Iaddr = InetAddress.getByName(this.address);
/*     */     } catch (UnknownHostException e) {
/*     */       
/*  87 */       throw new MalformedURLException("Valid RTP Session Address must be given");
/*     */     } 
/*  89 */     if (colonIndex == -1 || slashIndex == -1)
/*  90 */       throw new MalformedURLException("RTP MediaLocator is Invalid. Must be of form rtp://addr:port/content/ttl"); 
/*  91 */     String portstr = "";
/*  92 */     if (nextcolonIndex == -1) {
/*  93 */       portstr = remainder.substring(colonIndex + 1, slashIndex);
/*     */     } else {
/*     */       
/*  96 */       portstr = remainder.substring(colonIndex + 1, nextcolonIndex);
/*     */     } 
/*     */     try {
/*  99 */       Integer Iport = Integer.valueOf(portstr);
/* 100 */       this.port = Iport.intValue();
/*     */     } catch (NumberFormatException e) {
/* 102 */       throw new MalformedURLException("RTP MediaLocator Port must be a valid integer");
/*     */     } 
/* 104 */     if (nextcolonIndex != -1) {
/* 105 */       String ssrcstr = remainder.substring(nextcolonIndex + 1, slashIndex);
/*     */       
/*     */       try {
/* 108 */         Long Lssrcstr = Long.valueOf(ssrcstr);
/* 109 */         this.ssrc = Lssrcstr.longValue();
/* 110 */       } catch (NumberFormatException e) {}
/*     */     } 
/*     */     
/* 113 */     if (slashIndex != -1) {
/* 114 */       if (nextslashIndex == -1) {
/* 115 */         this.contentType = remainder.substring(slashIndex + 1, remainder.length());
/*     */       } else {
/* 117 */         this.contentType = remainder.substring(slashIndex + 1, nextslashIndex);
/*     */       } 
/* 119 */       if (!this.contentType.equals("audio") && !this.contentType.equals("video"))
/*     */       {
/* 121 */         throw new MalformedURLException("Content Type in URL must be audio or video ");
/*     */       }
/*     */ 
/*     */       
/* 125 */       this.contentType = "rtp/" + this.contentType;
/*     */     } 
/*     */     
/* 128 */     if (nextslashIndex != -1) {
/* 129 */       String ttlstr = remainder.substring(nextslashIndex + 1, remainder.length());
/*     */       
/*     */       try {
/* 132 */         Integer Ittl = Integer.valueOf(ttlstr);
/* 133 */         this.ttl = Ittl.intValue();
/* 134 */       } catch (NumberFormatException e) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSessionAddress() {
/* 142 */     return this.address;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSessionPort() {
/* 150 */     return this.port;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getSSRC() {
/* 157 */     return this.ssrc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/* 168 */     return this.contentType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTTL() {
/* 176 */     return this.ttl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValid() {
/* 187 */     return this.valid;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtp\RTPMediaLocator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */