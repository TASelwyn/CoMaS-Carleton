package com.sun.media.rtp;

import com.sun.media.Log;
import com.sun.media.protocol.rtp.DataSource;
import com.sun.media.rtp.util.Packet;
import com.sun.media.rtp.util.PacketFilter;
import com.sun.media.rtp.util.PacketSource;
import com.sun.media.rtp.util.RTPPacket;
import com.sun.media.rtp.util.SSRCTable;
import com.sun.media.rtp.util.UDPPacket;
import java.io.IOException;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import javax.media.Format;
import javax.media.protocol.PushBufferStream;
import javax.media.rtp.ReceiveStream;
import javax.media.rtp.SessionAddress;
import javax.media.rtp.event.ActiveReceiveStreamEvent;
import javax.media.rtp.event.NewReceiveStreamEvent;
import javax.media.rtp.event.RTPEvent;
import javax.media.rtp.event.RemotePayloadChangeEvent;

public class RTPReceiver extends PacketFilter {
  SSRCCache cache;
  
  RTPDemultiplexer rtpdemultiplexer;
  
  int lastseqnum = -1;
  
  private boolean rtcpstarted = false;
  
  private boolean setpriority = false;
  
  private boolean mismatchprinted = false;
  
  private String content = "";
  
  SSRCTable probationList = new SSRCTable();
  
  static final int MAX_DROPOUT = 3000;
  
  static final int MAX_MISORDER = 100;
  
  static final int SEQ_MOD = 65536;
  
  static final int MIN_SEQUENTIAL = 2;
  
  private boolean initBC = false;
  
  public String filtername() {
    return "RTP Packet Receiver";
  }
  
  public String controlstr = "javax.media.rtp.RTPControl";
  
  private int errorPayload = -1;
  
  public RTPReceiver(SSRCCache cache, RTPDemultiplexer rtpdemux) {
    this.cache = cache;
    this.rtpdemultiplexer = rtpdemux;
    setConsumer(null);
  }
  
  public RTPReceiver(SSRCCache cache, RTPDemultiplexer rtpdemux, PacketSource source) {
    this(cache, rtpdemux);
    setSource(source);
  }
  
  public RTPReceiver(SSRCCache cache, RTPDemultiplexer rtpdemux, DatagramSocket sock) {
    this(cache, rtpdemux, (PacketSource)new RTPRawReceiver(sock, cache.sm.defaultstats));
  }
  
  public RTPReceiver(SSRCCache cache, RTPDemultiplexer rtpdemux, int port, String address) throws UnknownHostException, IOException {
    this(cache, rtpdemux, (PacketSource)new RTPRawReceiver(port & 0xFFFFFFFE, address, cache.sm.defaultstats));
  }
  
  public Packet handlePacket(Packet p) {
    return handlePacket((RTPPacket)p);
  }
  
  public Packet handlePacket(Packet p, int index) {
    return null;
  }
  
  public Packet handlePacket(Packet p, SessionAddress a) {
    return null;
  }
  
  public Packet handlePacket(Packet p, SessionAddress a, boolean b) {
    return null;
  }
  
  public Packet handlePacket(RTPPacket p) {
    SSRCInfo info = null;
    if (p.base instanceof UDPPacket) {
      InetAddress remoteAddress = ((UDPPacket)p.base).remoteAddress;
      if (this.cache.sm.bindtome && !this.cache.sm.isBroadcast(this.cache.sm.dataaddress) && !remoteAddress.equals(this.cache.sm.dataaddress))
        return null; 
    } else if (p.base instanceof Packet) {
      p.base.toString();
    } 
    if (info == null)
      if (p.base instanceof UDPPacket) {
        info = this.cache.get(p.ssrc, ((UDPPacket)p.base).remoteAddress, ((UDPPacket)p.base).remotePort, 1);
      } else {
        info = this.cache.get(p.ssrc, null, 0, 1);
      }  
    if (info == null)
      return null; 
    for (int i = 0; i < p.csrc.length; i++) {
      SSRCInfo cinfo = null;
      if (p.base instanceof UDPPacket) {
        cinfo = this.cache.get(p.csrc[i], ((UDPPacket)p.base).remoteAddress, ((UDPPacket)p.base).remotePort, 1);
      } else {
        cinfo = this.cache.get(p.csrc[i], null, 0, 1);
      } 
      if (cinfo != null)
        cinfo.lastHeardFrom = ((Packet)p).receiptTime; 
    } 
    if (info.lastPayloadType != -1 && info.lastPayloadType == p.payloadType && this.mismatchprinted)
      return null; 
    if (!info.sender) {
      info.initsource(p.seqnum);
      info.payloadType = p.payloadType;
    } 
    int deltaseq = p.seqnum - info.maxseq;
    if (info.maxseq + 1 != p.seqnum)
      if (deltaseq > 0)
        info.stats.update(0, deltaseq - 1);  
    if (info.wrapped)
      info.wrapped = false; 
    boolean justOutOfProbation = false;
    if (info.probation > 0) {
      if (p.seqnum == info.maxseq + 1) {
        info.probation--;
        info.maxseq = p.seqnum;
        if (info.probation == 0)
          justOutOfProbation = true; 
      } else {
        info.probation = 1;
        info.maxseq = p.seqnum;
        info.stats.update(2);
      } 
    } else if (deltaseq < 3000) {
      if (p.seqnum < info.baseseq) {
        info.cycles += 65536;
        info.wrapped = true;
      } 
      info.maxseq = p.seqnum;
    } else if (deltaseq <= 65436) {
      info.stats.update(3);
      if (p.seqnum == info.lastbadseq) {
        info.initsource(p.seqnum);
      } else {
        info.lastbadseq = p.seqnum + 1 & 0xFFFF;
      } 
    } else {
      info.stats.update(4);
    } 
    boolean unicast = this.cache.sm.isUnicast();
    if (unicast)
      if (!this.rtcpstarted) {
        this.cache.sm.startRTCPReports(((UDPPacket)p.base).remoteAddress);
        this.rtcpstarted = true;
        byte[] lsb = this.cache.sm.controladdress.getAddress();
        int address = lsb[3] & 0xFF;
        if ((address & 0xFF) == 255) {
          this.cache.sm.addUnicastAddr(this.cache.sm.controladdress);
        } else {
          InetAddress localaddr = null;
          boolean localfound = true;
          try {
            localaddr = InetAddress.getLocalHost();
          } catch (UnknownHostException e) {
            localfound = false;
          } 
          if (localfound)
            this.cache.sm.addUnicastAddr(localaddr); 
        } 
      } else if (!this.cache.sm.isSenderDefaultAddr(((UDPPacket)p.base).remoteAddress)) {
        this.cache.sm.addUnicastAddr(((UDPPacket)p.base).remoteAddress);
      }  
    info.received++;
    info.stats.update(1);
    if (info.probation > 0) {
      this.probationList.put(info.ssrc, p.clone());
      return null;
    } 
    info.maxseq = p.seqnum;
    if (info.lastPayloadType != -1 && info.lastPayloadType != p.payloadType) {
      info.currentformat = null;
      if (info.dsource != null) {
        RTPControlImpl control = (RTPControlImpl)info.dsource.getControl(this.controlstr);
        if (control != null) {
          control.currentformat = null;
          control.payload = -1;
        } 
      } 
      info.lastPayloadType = p.payloadType;
      if (info.dsource != null)
        try {
          info.dsource.stop();
        } catch (IOException e) {
          System.err.println("Stopping DataSource after PCE " + e.getMessage());
        }  
      RemotePayloadChangeEvent event = new RemotePayloadChangeEvent(this.cache.sm, (ReceiveStream)info, info.lastPayloadType, p.payloadType);
      this.cache.eventhandler.postEvent((RTPEvent)event);
    } 
    if (info.currentformat == null) {
      info.currentformat = this.cache.sm.formatinfo.get(p.payloadType);
      if (info.currentformat == null) {
        if (this.errorPayload != p.payloadType) {
          Log.error("No format has been registered for RTP Payload type " + p.payloadType);
          this.errorPayload = p.payloadType;
        } 
        return (Packet)p;
      } 
      if (info.dstream != null)
        info.dstream.setFormat(info.currentformat); 
    } 
    if (info.currentformat == null) {
      System.err.println("No Format for PT= " + p.payloadType);
      return (Packet)p;
    } 
    if (info.dsource != null) {
      RTPControlImpl control = (RTPControlImpl)info.dsource.getControl(this.controlstr);
      if (control != null) {
        Format fmt = this.cache.sm.formatinfo.get(p.payloadType);
        control.currentformat = fmt;
      } 
    } 
    if (!this.initBC) {
      ((BufferControlImpl)this.cache.sm.buffercontrol).initBufferControl(info.currentformat);
      this.initBC = true;
    } 
    if (!info.streamconnect) {
      DataSource source = (DataSource)this.cache.sm.dslist.get(info.ssrc);
      if (source == null) {
        DataSource defaultsource = this.cache.sm.getDataSource(null);
        if (defaultsource == null) {
          source = this.cache.sm.createNewDS((RTPMediaLocator)null);
          this.cache.sm.setDefaultDSassigned(info.ssrc);
        } else if (!this.cache.sm.isDefaultDSassigned()) {
          source = defaultsource;
          this.cache.sm.setDefaultDSassigned(info.ssrc);
        } else {
          source = this.cache.sm.createNewDS(info.ssrc);
        } 
      } 
      PushBufferStream[] streams = source.getStreams();
      info.dsource = source;
      info.dstream = (RTPSourceStream)streams[0];
      info.dstream.setContentDescriptor(this.content);
      info.dstream.setFormat(info.currentformat);
      RTPControlImpl control = (RTPControlImpl)info.dsource.getControl(this.controlstr);
      if (control != null) {
        Format fmt = this.cache.sm.formatinfo.get(p.payloadType);
        control.currentformat = fmt;
        control.stream = info;
      } 
      info.streamconnect = true;
    } 
    if (info.dsource != null)
      info.active = true; 
    if (!info.newrecvstream) {
      NewReceiveStreamEvent evt = new NewReceiveStreamEvent(this.cache.sm, (ReceiveStream)info);
      info.newrecvstream = true;
      this.cache.eventhandler.postEvent((RTPEvent)evt);
    } 
    if (info.lastRTPReceiptTime != 0L && info.lastPayloadType == p.payloadType) {
      long abstimediff = ((Packet)p).receiptTime - info.lastRTPReceiptTime;
      abstimediff = abstimediff * this.cache.clockrate[info.payloadType] / 1000L;
      long rtptimediff = p.timestamp - info.lasttimestamp;
      double timediff = (abstimediff - rtptimediff);
      if (timediff < 0.0D)
        timediff = -timediff; 
      info.jitter += 0.0625D * (timediff - info.jitter);
    } 
    info.lastRTPReceiptTime = ((Packet)p).receiptTime;
    info.lasttimestamp = p.timestamp;
    info.payloadType = p.payloadType;
    info.lastPayloadType = p.payloadType;
    info.bytesreceived += p.payloadlength;
    info.lastHeardFrom = ((Packet)p).receiptTime;
    if (info.quiet) {
      info.quiet = false;
      ActiveReceiveStreamEvent event = null;
      if (info instanceof ReceiveStream) {
        event = new ActiveReceiveStreamEvent(this.cache.sm, info.sourceInfo, (ReceiveStream)info);
      } else {
        event = new ActiveReceiveStreamEvent(this.cache.sm, info.sourceInfo, null);
      } 
      this.cache.eventhandler.postEvent((RTPEvent)event);
    } 
    SourceRTPPacket sp = new SourceRTPPacket(p, info);
    if (info.dsource != null) {
      if (this.mismatchprinted)
        this.mismatchprinted = false; 
      if (justOutOfProbation) {
        RTPPacket pp = (RTPPacket)this.probationList.remove(info.ssrc);
        if (pp != null)
          this.rtpdemultiplexer.demuxpayload(new SourceRTPPacket(pp, info)); 
      } 
      this.rtpdemultiplexer.demuxpayload(sp);
    } 
    return (Packet)p;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTPReceiver.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */