/*     */ package com.sun.media.rtp;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import com.sun.media.rtp.util.SSRCTable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetAddress;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.rtp.ReceiveStream;
/*     */ import javax.media.rtp.event.LocalCollisionEvent;
/*     */ import javax.media.rtp.event.RTPEvent;
/*     */ import javax.media.rtp.event.RemoteCollisionEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSRCCache
/*     */ {
/*  40 */   SSRCTable cache = new SSRCTable();
/*     */ 
/*     */   
/*     */   RTPSourceInfoCache sourceInfoCache;
/*     */ 
/*     */   
/*  46 */   OverallStats stats = null;
/*  47 */   OverallTransStats transstats = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   RTPEventHandler eventhandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   int[] clockrate = new int[128];
/*     */   
/*     */   static final int DATA = 1;
/*     */   
/*     */   static final int CONTROL = 2;
/*     */   
/*     */   static final int SRCDATA = 3;
/*     */   
/*     */   static final int RTCP_MIN_TIME = 5000;
/*     */   
/*     */   static final int BYE_THRESHOLD = 50;
/*     */   
/*  74 */   int sendercount = 0;
/*  75 */   double rtcp_bw_fraction = 0.0D;
/*  76 */   double rtcp_sender_bw_fraction = 0.0D;
/*  77 */   int rtcp_min_time = 5000;
/*     */   
/*     */   private static final int NOTIFYPERIOD = 500;
/*     */   
/*  81 */   int sessionbandwidth = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   boolean initial = true;
/*     */ 
/*     */ 
/*     */   
/*     */   boolean byestate = false;
/*     */ 
/*     */ 
/*     */   
/*     */   boolean rtcpsent = false;
/*     */ 
/*     */ 
/*     */   
/*  97 */   int avgrtcpsize = 128;
/*     */ 
/*     */ 
/*     */   
/* 101 */   Hashtable conflicttable = new Hashtable(5);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   SSRCInfo ourssrc = null;
/*     */   
/*     */   public RTPSessionMgr sm;
/*     */   
/* 112 */   private static JMFSecurity jmfSecurity = null;
/*     */   private static boolean securityPrivelege = false;
/* 114 */   private Method[] m = new Method[1];
/* 115 */   private Class[] cl = new Class[1];
/* 116 */   private Object[][] args = new Object[1][0];
/*     */   
/*     */   static {
/*     */     try {
/* 120 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/* 121 */       securityPrivelege = true;
/* 122 */     } catch (SecurityException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SSRCCache(RTPSessionMgr sm) {
/* 157 */     if (jmfSecurity != null) {
/* 158 */       String permission = null;
/*     */       try {
/* 160 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 161 */           permission = "thread";
/* 162 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/* 163 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*     */           
/* 165 */           permission = "thread group";
/* 166 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/* 167 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*     */         }
/* 169 */         else if (jmfSecurity.getName().startsWith("internet")) {
/* 170 */           PolicyEngine.checkPermission(PermissionID.THREAD);
/* 171 */           PolicyEngine.assertPermission(PermissionID.THREAD);
/*     */         }
/*     */       
/* 174 */       } catch (Throwable e) {
/*     */ 
/*     */ 
/*     */         
/* 178 */         if (permission.endsWith("group")) {
/* 179 */           jmfSecurity.permissionFailureNotification(32);
/*     */         } else {
/* 181 */           jmfSecurity.permissionFailureNotification(16);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 186 */     this.stats = sm.defaultstats;
/* 187 */     this.transstats = sm.transstats;
/* 188 */     this.sourceInfoCache = new RTPSourceInfoCache();
/* 189 */     this.sourceInfoCache.setMainCache(this.sourceInfoCache);
/*     */     
/* 191 */     this.sourceInfoCache.setSSRCCache(this);
/* 192 */     this.sm = sm;
/* 193 */     this.eventhandler = new RTPEventHandler(sm);
/* 194 */     setclockrates();
/*     */   }
/*     */   
/*     */   SSRCCache(RTPSessionMgr sm, RTPSourceInfoCache sic) {
/* 198 */     this.stats = sm.defaultstats;
/* 199 */     this.transstats = sm.transstats;
/* 200 */     this.sourceInfoCache = sic;
/* 201 */     sic.setSSRCCache(this);
/* 202 */     this.sm = sm;
/* 203 */     this.eventhandler = new RTPEventHandler(sm);
/*     */   }
/*     */   
/*     */   int aliveCount() {
/* 207 */     int tot = 0;
/* 208 */     Enumeration e = this.cache.elements();
/*     */     
/* 210 */     while (e.hasMoreElements()) {
/* 211 */       SSRCInfo s = e.nextElement();
/* 212 */       if (s.alive)
/* 213 */         tot++; 
/*     */     } 
/* 215 */     return tot;
/*     */   }
/*     */   
/*     */   void setclockrates() {
/* 219 */     for (int i = 0; i < 16; i++)
/* 220 */       this.clockrate[i] = 8000; 
/* 221 */     this.clockrate[6] = 16000;
/* 222 */     this.clockrate[10] = 44100;
/* 223 */     this.clockrate[11] = 44100;
/* 224 */     this.clockrate[14] = 90000;
/* 225 */     this.clockrate[16] = 11025;
/* 226 */     this.clockrate[17] = 22050;
/* 227 */     this.clockrate[18] = 44100;
/* 228 */     for (int j = 24; j < 34; j++) {
/* 229 */       this.clockrate[j] = 90000;
/*     */     }
/* 231 */     for (int k = 96; k < 128; k++) {
/* 232 */       Format fmt = this.sm.formatinfo.get(k);
/*     */       
/* 234 */       if (fmt != null && fmt instanceof AudioFormat) {
/* 235 */         this.clockrate[k] = (int)((AudioFormat)fmt).getSampleRate();
/*     */       } else {
/* 237 */         this.clockrate[k] = 90000;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   synchronized void destroy() {
/* 243 */     this.cache.removeAll();
/* 244 */     if (this.eventhandler != null) {
/* 245 */       this.eventhandler.close();
/*     */     }
/*     */   }
/*     */   
/*     */   SSRCInfo lookup(int ssrc) {
/* 250 */     return (SSRCInfo)this.cache.get(ssrc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SSRCInfo get(int ssrc, InetAddress address, int port, int mode) {
/* 261 */     SSRCInfo info = null;
/* 262 */     boolean localcollision = false;
/*     */     
/* 264 */     synchronized (this) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 272 */       if (this.ourssrc != null && this.ourssrc.ssrc == ssrc && this.ourssrc.address != null && !this.ourssrc.address.equals(address)) {
/*     */ 
/*     */         
/* 275 */         localcollision = true;
/* 276 */         LocalCollision(ssrc);
/*     */       } 
/*     */ 
/*     */       
/* 280 */       info = lookup(ssrc);
/*     */ 
/*     */ 
/*     */       
/* 284 */       if (info != null) {
/* 285 */         synchronized (info) {
/* 286 */           if (info.address == null || !info.alive) {
/* 287 */             info.address = address;
/* 288 */             info.port = port;
/*     */           }
/* 290 */           else if (!info.address.equals(address)) {
/* 291 */             if (info.probation > 0) {
/* 292 */               info.probation = 2;
/* 293 */               info.address = address;
/* 294 */               info.port = port;
/*     */             } else {
/*     */               
/* 297 */               this.stats.update(4, 1);
/*     */               
/* 299 */               this.transstats.remote_coll++;
/*     */ 
/*     */               
/* 302 */               RemoteCollisionEvent evt = new RemoteCollisionEvent(this.sm, info.ssrc);
/*     */ 
/*     */               
/* 305 */               this.eventhandler.postEvent((RTPEvent)evt);
/* 306 */               return null;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 314 */       if (info != null && mode == 1 && !(info instanceof RecvSSRCInfo)) {
/*     */         
/* 316 */         if (info.ours) {
/* 317 */           return null;
/*     */         }
/*     */         
/* 320 */         SSRCInfo newinfo = new RecvSSRCInfo(info);
/*     */         
/* 322 */         info = newinfo;
/* 323 */         this.cache.put(ssrc, info);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 330 */       if (info != null && mode == 2 && !(info instanceof PassiveSSRCInfo)) {
/*     */         
/* 332 */         if (info.ours)
/* 333 */           return null; 
/* 334 */         System.out.println("changing to Passive");
/* 335 */         System.out.println("existing one " + info);
/* 336 */         SSRCInfo newinfo = new PassiveSSRCInfo(info);
/* 337 */         System.out.println("new one is " + newinfo);
/* 338 */         info = newinfo;
/*     */         
/* 340 */         this.cache.put(ssrc, info);
/*     */       } 
/* 342 */       if (info == null) {
/* 343 */         if (mode == 3) {
/*     */           
/* 345 */           if (this.ourssrc != null && this.ourssrc.ssrc == ssrc) {
/* 346 */             return this.ourssrc;
/*     */           }
/* 348 */           info = new SendSSRCInfo(this, ssrc);
/* 349 */           info.initsource((int)TrueRandom.rand());
/*     */         } 
/*     */ 
/*     */         
/* 353 */         if (mode == 1) {
/* 354 */           info = new RecvSSRCInfo(this, ssrc);
/*     */         }
/* 356 */         if (mode == 2) {
/* 357 */           info = new PassiveSSRCInfo(this, ssrc);
/*     */         }
/* 359 */         if (info == null) {
/* 360 */           return null;
/*     */         }
/* 362 */         info.address = address;
/* 363 */         info.port = port;
/* 364 */         this.cache.put(ssrc, info);
/*     */       } 
/*     */       
/* 367 */       if (info.address == null && info.port == 0) {
/* 368 */         info.address = address;
/* 369 */         info.port = port;
/*     */       } 
/*     */ 
/*     */       
/* 373 */       if (localcollision) {
/* 374 */         LocalCollisionEvent levt = null;
/* 375 */         if (info instanceof RecvSSRCInfo) {
/* 376 */           levt = new LocalCollisionEvent(this.sm, (ReceiveStream)info, this.ourssrc.ssrc);
/*     */         }
/*     */         else {
/*     */           
/* 380 */           levt = new LocalCollisionEvent(this.sm, null, this.ourssrc.ssrc);
/*     */         } 
/*     */ 
/*     */         
/* 384 */         this.eventhandler.postEvent((RTPEvent)levt);
/*     */       } 
/*     */     } 
/*     */     
/* 388 */     return info;
/*     */   }
/*     */   
/*     */   private void changessrc(SSRCInfo info) {
/* 392 */     info.setOurs(true);
/* 393 */     if (this.ourssrc != null) {
/* 394 */       info.sourceInfo = this.sourceInfoCache.get(this.ourssrc.sourceInfo.getCNAME(), info.ours);
/*     */       
/* 396 */       info.sourceInfo.addSSRC(info);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 403 */     info.reporter.releasessrc("Local Collision Detected");
/*     */     
/* 405 */     this.ourssrc = info;
/*     */ 
/*     */     
/* 408 */     info.reporter.restart = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void LocalCollision(int ssrc) {
/* 414 */     int newssrc = 0;
/*     */     
/*     */     while (true) {
/* 417 */       newssrc = (int)TrueRandom.rand();
/* 418 */       if (lookup(newssrc) != null) {
/*     */         continue;
/*     */       }
/*     */       
/*     */       break;
/*     */     } 
/*     */     
/* 425 */     SSRCInfo newinfo = new PassiveSSRCInfo(this.ourssrc);
/* 426 */     newinfo.ssrc = newssrc;
/* 427 */     this.cache.put(newssrc, newinfo);
/* 428 */     changessrc(newinfo);
/*     */     
/* 430 */     this.ourssrc = newinfo;
/*     */ 
/*     */ 
/*     */     
/* 434 */     this.stats.update(3, 1);
/* 435 */     this.transstats.local_coll++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SSRCInfo get(int ssrc, InetAddress address, int port) {
/* 444 */     synchronized (this) {
/* 445 */       SSRCInfo info = lookup(ssrc);
/* 446 */       return info;
/*     */     } 
/*     */   }
/*     */   
/*     */   void remove(int ssrc) {
/* 451 */     SSRCInfo info = (SSRCInfo)this.cache.remove(ssrc);
/* 452 */     if (info != null)
/*     */     {
/*     */       
/* 455 */       info.delete();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   int getSessionBandwidth() {
/* 461 */     if (this.sessionbandwidth == 0)
/* 462 */       throw new IllegalArgumentException("Session Bandwidth not set"); 
/* 463 */     return this.sessionbandwidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   double calcReportInterval(boolean sender, boolean recvfromothers) {
/* 473 */     this.rtcp_min_time = 5000;
/*     */     
/* 475 */     double rtcp_bw = this.rtcp_bw_fraction;
/*     */     
/* 477 */     if (this.initial) {
/* 478 */       this.rtcp_min_time /= 2;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 489 */     int n = aliveCount();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 497 */     if (this.sendercount > 0 && this.sendercount < n * this.rtcp_sender_bw_fraction)
/*     */     {
/* 499 */       if (sender) {
/* 500 */         rtcp_bw *= this.rtcp_sender_bw_fraction;
/* 501 */         n = this.sendercount;
/*     */       } else {
/* 503 */         rtcp_bw *= 1.0D - this.rtcp_sender_bw_fraction;
/* 504 */         n -= this.sendercount;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 512 */     if (recvfromothers && rtcp_bw == 0.0D) {
/* 513 */       rtcp_bw = 0.05D;
/*     */ 
/*     */       
/* 516 */       if (this.sendercount > 0 && this.sendercount < n * 0.25D)
/*     */       {
/* 518 */         if (sender) {
/* 519 */           rtcp_bw *= 0.25D;
/* 520 */           n = this.sendercount;
/*     */         } else {
/* 522 */           rtcp_bw *= 0.75D;
/* 523 */           n -= this.sendercount;
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 538 */     double time = 0.0D;
/* 539 */     if (rtcp_bw != 0.0D) {
/* 540 */       time = (this.avgrtcpsize * n) / rtcp_bw;
/* 541 */       if (time < this.rtcp_min_time) {
/* 542 */         time = this.rtcp_min_time;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 551 */     if (recvfromothers) {
/* 552 */       return time;
/*     */     }
/* 554 */     return time * (Math.random() + 0.5D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void updateavgrtcpsize(int size) {
/* 561 */     this.avgrtcpsize = (int)(0.0625D * size + 0.9375D * this.avgrtcpsize);
/*     */   }
/*     */ 
/*     */   
/*     */   RTPSourceInfoCache getRTPSICache() {
/* 566 */     return this.sourceInfoCache;
/*     */   }
/*     */   
/*     */   SSRCTable getMainCache() {
/* 570 */     return this.cache;
/*     */   }
/*     */   
/*     */   public void reset(int size) {
/* 574 */     this.initial = true;
/* 575 */     this.sendercount = 0;
/*     */     
/* 577 */     this.avgrtcpsize = size;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtp\SSRCCache.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */