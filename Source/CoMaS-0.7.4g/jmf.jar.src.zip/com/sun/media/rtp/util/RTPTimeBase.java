package com.sun.media.rtp.util;

import com.sun.media.Log;
import java.util.Vector;
import javax.media.Time;
import javax.media.TimeBase;

public class RTPTimeBase implements TimeBase {
  static Vector timeBases = new Vector();
  
  static int SSRC_UNDEFINED = 0;
  
  String cname;
  
  public static RTPTimeBase find(RTPTimeReporter r, String cname) {
    synchronized (timeBases) {
      RTPTimeBase result = null;
      for (int i = 0; i < timeBases.size(); i++) {
        RTPTimeBase tb = timeBases.elementAt(i);
        if (tb.cname.equals(cname)) {
          result = tb;
          break;
        } 
      } 
      if (result == null) {
        Log.comment("Created RTP time base for session: " + cname + "\n");
        result = new RTPTimeBase(cname);
        timeBases.addElement(result);
      } 
      if (r != null) {
        if (result.getMaster() == null)
          result.setMaster(r); 
        result.reporters.addElement(r);
      } 
      return result;
    } 
  }
  
  public static void remove(RTPTimeReporter r, String cname) {
    synchronized (timeBases) {
      for (int i = 0; i < timeBases.size(); i++) {
        RTPTimeBase tb = timeBases.elementAt(i);
        if (tb.cname.equals(cname)) {
          tb.reporters.removeElement(r);
          if (tb.reporters.size() == 0) {
            tb.master = null;
            timeBases.removeElement(tb);
            break;
          } 
          synchronized (tb) {
            if (tb.master == r)
              tb.setMaster(tb.reporters.elementAt(0)); 
          } 
          break;
        } 
      } 
    } 
  }
  
  public static RTPTimeBase getMapper(String cname) {
    synchronized (timeBases) {
      return find(null, cname);
    } 
  }
  
  public static RTPTimeBase getMapperUpdatable(String cname) {
    synchronized (timeBases) {
      RTPTimeBase tb = find(null, cname);
      if (tb.offsetUpdatable) {
        tb.offsetUpdatable = false;
        return tb;
      } 
      return null;
    } 
  }
  
  public static void returnMapperUpdatable(RTPTimeBase tb) {
    synchronized (timeBases) {
      tb.offsetUpdatable = true;
    } 
  }
  
  RTPTimeReporter master = null;
  
  Vector reporters = new Vector();
  
  long origin = 0L;
  
  long offset = 0L;
  
  boolean offsetUpdatable = true;
  
  RTPTimeBase(String cname) {
    this.cname = cname;
  }
  
  public Time getTime() {
    return new Time(getNanoseconds());
  }
  
  public synchronized long getNanoseconds() {
    return (this.master != null) ? this.master.getRTPTime() : 0L;
  }
  
  public synchronized void setMaster(RTPTimeReporter r) {
    this.master = r;
  }
  
  public synchronized RTPTimeReporter getMaster() {
    return this.master;
  }
  
  public synchronized void setOrigin(long orig) {
    this.origin = orig;
  }
  
  public long getOrigin() {
    return this.origin;
  }
  
  public synchronized void setOffset(long off) {
    this.offset = off;
  }
  
  public long getOffset() {
    return this.offset;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rt\\util\RTPTimeBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */