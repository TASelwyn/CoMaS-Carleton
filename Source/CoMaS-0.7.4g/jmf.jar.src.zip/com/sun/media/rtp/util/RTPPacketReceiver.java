/*     */ package com.sun.media.rtp.util;
/*     */ 
/*     */ import com.sun.media.CircularBuffer;
/*     */ import java.io.IOException;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.protocol.PushSourceStream;
/*     */ import javax.media.protocol.SourceTransferHandler;
/*     */ import javax.media.rtp.RTPPushDataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RTPPacketReceiver
/*     */   implements PacketSource, SourceTransferHandler
/*     */ {
/*  20 */   RTPPushDataSource rtpsource = null;
/*  21 */   CircularBuffer bufQue = new CircularBuffer(2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean closed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean dataRead;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void transferData(PushSourceStream sourcestream) {
/*     */     Buffer buf;
/*  38 */     synchronized (this.bufQue) {
/*  39 */       while (!this.bufQue.canWrite() && !this.closed) {
/*     */         try {
/*  41 */           this.bufQue.wait(1000L);
/*  42 */         } catch (InterruptedException e) {}
/*     */       } 
/*     */       
/*  45 */       if (this.closed) {
/*     */         return;
/*     */       }
/*  48 */       buf = this.bufQue.getEmptyBuffer();
/*     */     } 
/*     */     
/*  51 */     int size = sourcestream.getMinimumTransferSize();
/*     */     
/*  53 */     byte[] data = (byte[])buf.getData();
/*  54 */     int len = 0;
/*     */     
/*  56 */     if (data == null || data.length < size) {
/*  57 */       data = new byte[size];
/*  58 */       buf.setData(data);
/*     */     } 
/*     */     
/*     */     try {
/*  62 */       len = sourcestream.read(data, 0, size);
/*     */     }
/*  64 */     catch (IOException e) {}
/*     */     
/*  66 */     buf.setLength(len);
/*  67 */     buf.setOffset(0);
/*     */     
/*  69 */     synchronized (this.bufQue) {
/*  70 */       this.bufQue.writeReport();
/*  71 */       this.bufQue.notify();
/*     */     } 
/*     */   }
/*     */   
/*     */   public RTPPacketReceiver(RTPPushDataSource rtpsource) {
/*  76 */     this.dataRead = false; this.rtpsource = rtpsource; PushSourceStream output = rtpsource.getOutputStream(); output.setTransferHandler(this); } public RTPPacketReceiver(PushSourceStream pss) { this.dataRead = false;
/*     */     pss.setTransferHandler(this); }
/*     */   
/*     */   public Packet receiveFrom() throws IOException {
/*     */     Buffer buffer;
/*     */     byte[] arrayOfByte;
/*  82 */     synchronized (this.bufQue) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  90 */       if (this.dataRead) {
/*  91 */         this.bufQue.readReport();
/*  92 */         this.bufQue.notify();
/*     */       } 
/*     */       
/*  95 */       while (!this.bufQue.canRead() && !this.closed) {
/*     */         try {
/*  97 */           this.bufQue.wait(1000L);
/*  98 */         } catch (InterruptedException e) {}
/*     */       } 
/*     */       
/* 101 */       if (this.closed) {
/* 102 */         buffer = null;
/* 103 */         this.dataRead = false;
/*     */       } else {
/* 105 */         buffer = this.bufQue.read();
/* 106 */         this.dataRead = true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 112 */     if (buffer != null) {
/* 113 */       arrayOfByte = (byte[])buffer.getData();
/*     */     } else {
/* 115 */       arrayOfByte = new byte[1];
/*     */     } 
/* 117 */     UDPPacket p = new UDPPacket();
/* 118 */     p.receiptTime = System.currentTimeMillis();
/* 119 */     p.data = arrayOfByte;
/* 120 */     p.offset = 0;
/* 121 */     p.length = (buffer == null) ? 0 : buffer.getLength();
/*     */     
/* 123 */     return p;
/*     */   }
/*     */   
/*     */   public void closeSource() {
/* 127 */     synchronized (this.bufQue) {
/* 128 */       this.closed = true;
/* 129 */       this.bufQue.notifyAll();
/*     */     } 
/*     */   }
/*     */   
/*     */   public String sourceString() {
/* 134 */     String s = "RTPPacketReceiver for " + this.rtpsource;
/* 135 */     return s;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rt\\util\RTPPacketReceiver.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */