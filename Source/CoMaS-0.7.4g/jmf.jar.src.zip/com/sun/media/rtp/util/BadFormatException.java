package com.sun.media.rtp.util;

public class BadFormatException extends Exception {
  public BadFormatException() {}
  
  public BadFormatException(String m) {
    super(m);
  }
}
