/*    */ package com.sun.media.rtp.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BadFormatException
/*    */   extends Exception
/*    */ {
/*    */   public BadFormatException() {}
/*    */   
/*    */   public BadFormatException(String m) {
/* 13 */     super(m);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rt\\util\BadFormatException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */