package com.sun.media.rtp.util;

public final class Signed {
  public static long UnsignedInt(int signed) {
    return 4294967296L + signed;
  }
}
