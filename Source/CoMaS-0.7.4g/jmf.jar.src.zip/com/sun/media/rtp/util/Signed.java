/*    */ package com.sun.media.rtp.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Signed
/*    */ {
/*    */   public static long UnsignedInt(int signed) {
/* 15 */     return 4294967296L + signed;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rt\\util\Signed.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */