package com.sun.media.rtp.util;

public interface RTPTimeReporter {
  long getRTPTime();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rt\\util\RTPTimeReporter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */