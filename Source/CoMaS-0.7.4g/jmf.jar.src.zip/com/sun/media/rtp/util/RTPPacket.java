package com.sun.media.rtp.util;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class RTPPacket extends Packet {
  public Packet base;
  
  public boolean extensionPresent;
  
  public int marker;
  
  public int payloadType;
  
  public int seqnum;
  
  public long timestamp;
  
  public int ssrc;
  
  public int[] csrc;
  
  public int extensionType;
  
  public byte[] extension;
  
  public int payloadoffset;
  
  public int payloadlength;
  
  public RTPPacket() {}
  
  public RTPPacket(Packet p) {
    super(p);
    this.base = p;
  }
  
  public String toString() {
    String s = "RTP Packet:\n\tPayload Type: " + this.payloadType + "    Marker: " + this.marker + "\n\tSequence Number: " + this.seqnum + "\n\tTimestamp: " + this.timestamp + "\n\tSSRC (Sync Source): " + this.ssrc + "\n\tPayload Length: " + this.payloadlength + "    Payload Offset: " + this.payloadoffset + "\n";
    if (this.csrc.length > 0) {
      s = s + "Contributing sources:  " + this.csrc[0];
      for (int i = 1; i < this.csrc.length; i++)
        s = s + ", " + this.csrc[i]; 
      s = s + "\n";
    } 
    if (this.extensionPresent)
      s = s + "\tExtension:  type " + this.extensionType + ", length " + this.extension.length + "\n"; 
    return s;
  }
  
  public int calcLength() {
    return this.payloadlength + 12;
  }
  
  public void assemble(int len, boolean encrypted) {
    this.length = len;
    this.offset = 0;
    ByteArrayOutputStream baos = new ByteArrayOutputStream(len);
    DataOutputStream out = new DataOutputStream(baos);
    try {
      out.writeByte(128);
      int mp = this.payloadType;
      if (this.marker == 1)
        mp = this.payloadType | 0x80; 
      out.writeByte((byte)mp);
      out.writeShort(this.seqnum);
      out.writeInt((int)this.timestamp);
      out.writeInt(this.ssrc);
      out.write(this.base.data, this.payloadoffset, this.payloadlength);
      this.data = baos.toByteArray();
    } catch (IOException e) {
      System.out.println("caught IOException in DOS");
    } 
  }
  
  public Object clone() {
    RTPPacket p = new RTPPacket((Packet)this.base.clone());
    p.extensionPresent = this.extensionPresent;
    p.marker = this.marker;
    p.payloadType = this.payloadType;
    p.seqnum = this.seqnum;
    p.timestamp = this.timestamp;
    p.ssrc = this.ssrc;
    p.csrc = (int[])this.csrc.clone();
    p.extensionType = this.extensionType;
    p.extension = this.extension;
    p.payloadoffset = this.payloadoffset;
    p.payloadlength = this.payloadlength;
    return p;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rt\\util\RTPPacket.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */