/*     */ package com.sun.media.rtp.util;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RTPPacket
/*     */   extends Packet
/*     */ {
/*     */   public Packet base;
/*     */   public boolean extensionPresent;
/*     */   public int marker;
/*     */   public int payloadType;
/*     */   public int seqnum;
/*     */   public long timestamp;
/*     */   public int ssrc;
/*     */   public int[] csrc;
/*     */   public int extensionType;
/*     */   public byte[] extension;
/*     */   public int payloadoffset;
/*     */   public int payloadlength;
/*     */   
/*     */   public RTPPacket() {}
/*     */   
/*     */   public RTPPacket(Packet p) {
/* 111 */     super(p);
/* 112 */     this.base = p;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 116 */     String s = "RTP Packet:\n\tPayload Type: " + this.payloadType + "    Marker: " + this.marker + "\n\tSequence Number: " + this.seqnum + "\n\tTimestamp: " + this.timestamp + "\n\tSSRC (Sync Source): " + this.ssrc + "\n\tPayload Length: " + this.payloadlength + "    Payload Offset: " + this.payloadoffset + "\n";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 123 */     if (this.csrc.length > 0) {
/* 124 */       s = s + "Contributing sources:  " + this.csrc[0];
/* 125 */       for (int i = 1; i < this.csrc.length; i++)
/* 126 */         s = s + ", " + this.csrc[i]; 
/* 127 */       s = s + "\n";
/*     */     } 
/* 129 */     if (this.extensionPresent) {
/* 130 */       s = s + "\tExtension:  type " + this.extensionType + ", length " + this.extension.length + "\n";
/*     */     }
/*     */     
/* 133 */     return s;
/*     */   }
/*     */   
/*     */   public int calcLength() {
/* 137 */     return this.payloadlength + 12;
/*     */   }
/*     */ 
/*     */   
/*     */   public void assemble(int len, boolean encrypted) {
/* 142 */     this.length = len;
/* 143 */     this.offset = 0;
/* 144 */     ByteArrayOutputStream baos = new ByteArrayOutputStream(len);
/* 145 */     DataOutputStream out = new DataOutputStream(baos);
/*     */     
/*     */     try {
/* 148 */       out.writeByte(128);
/* 149 */       int mp = this.payloadType;
/* 150 */       if (this.marker == 1)
/* 151 */         mp = this.payloadType | 0x80; 
/* 152 */       out.writeByte((byte)mp);
/* 153 */       out.writeShort(this.seqnum);
/* 154 */       out.writeInt((int)this.timestamp);
/* 155 */       out.writeInt(this.ssrc);
/* 156 */       out.write(this.base.data, this.payloadoffset, this.payloadlength);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 162 */       this.data = baos.toByteArray();
/*     */     
/*     */     }
/*     */     catch (IOException e) {
/*     */       
/* 167 */       System.out.println("caught IOException in DOS");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 173 */     RTPPacket p = new RTPPacket((Packet)this.base.clone());
/* 174 */     p.extensionPresent = this.extensionPresent;
/* 175 */     p.marker = this.marker;
/* 176 */     p.payloadType = this.payloadType;
/* 177 */     p.seqnum = this.seqnum;
/* 178 */     p.timestamp = this.timestamp;
/* 179 */     p.ssrc = this.ssrc;
/* 180 */     p.csrc = (int[])this.csrc.clone();
/* 181 */     p.extensionType = this.extensionType;
/* 182 */     p.extension = this.extension;
/* 183 */     p.payloadoffset = this.payloadoffset;
/* 184 */     p.payloadlength = this.payloadlength;
/* 185 */     return p;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rt\\util\RTPPacket.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */