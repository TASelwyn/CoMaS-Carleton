package com.sun.media.rtp.util;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import com.sun.media.JMFSecurity;
import com.sun.media.JMFSecurityManager;
import com.sun.media.util.MediaThread;
import com.sun.media.util.jdk12;
import com.sun.media.util.jdk12CreateThreadRunnableAction;
import com.sun.media.util.jdk12PriorityAction;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class PacketForwarder implements Runnable {
  PacketSource source = null;
  
  PacketConsumer consumer = null;
  
  RTPMediaThread thread;
  
  boolean closed = false;
  
  private boolean paused;
  
  public IOException exception = null;
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] m = new Method[1];
  
  private Class[] cl = new Class[1];
  
  private Object[][] args = new Object[1][0];
  
  static {
    try {
      jmfSecurity = JMFSecurityManager.getJMFSecurity();
      securityPrivelege = true;
    } catch (SecurityException e) {}
  }
  
  public PacketForwarder(PacketSource s, PacketConsumer c) {
    this.source = s;
    this.consumer = c;
    this.closed = false;
    this.exception = null;
  }
  
  public void startPF() {
    startPF(null);
  }
  
  public void startPF(String threadname) {
    if (this.thread != null)
      throw new IllegalArgumentException("Called start more than once"); 
    if (jmfSecurity != null) {
      String permission = null;
      try {
        if (jmfSecurity.getName().startsWith("jmf-security")) {
          permission = "thread";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
          this.m[0].invoke(this.cl[0], this.args[0]);
          permission = "thread group";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
          this.m[0].invoke(this.cl[0], this.args[0]);
        } else if (jmfSecurity.getName().startsWith("internet")) {
          PolicyEngine.checkPermission(PermissionID.THREAD);
          PolicyEngine.assertPermission(PermissionID.THREAD);
        } 
      } catch (Throwable e) {
        if (permission.endsWith("group")) {
          jmfSecurity.permissionFailureNotification(32);
        } else {
          jmfSecurity.permissionFailureNotification(16);
        } 
      } 
    } 
    if (threadname == null)
      threadname = "RTPMediaThread"; 
    if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
      try {
        Constructor cons = jdk12CreateThreadRunnableAction.cons;
        this.thread = (RTPMediaThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { RTPMediaThread.class, this }) });
        this.thread.setName(threadname);
        cons = jdk12PriorityAction.cons;
        jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { this.thread, new Integer(MediaThread.getNetworkPriority()) }) });
      } catch (Exception e) {}
    } else {
      this.thread = new RTPMediaThread(this, threadname);
      this.thread.useNetworkPriority();
    } 
    this.thread.setDaemon(true);
    this.thread.start();
  }
  
  public void setVideoPriority() {
    this.thread.useVideoNetworkPriority();
  }
  
  public PacketSource getSource() {
    return this.source;
  }
  
  public PacketConsumer getConsumer() {
    return this.consumer;
  }
  
  public String getId() {
    if (this.thread == null) {
      System.err.println("the packetforwarders thread is null");
      return null;
    } 
    return this.thread.getName();
  }
  
  public void run() {
    if (this.closed || this.exception != null) {
      if (this.source != null)
        this.source.closeSource(); 
      return;
    } 
    if (jmfSecurity != null)
      try {
        if (jmfSecurity.getName().startsWith("jmf-security")) {
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 128);
          this.m[0].invoke(this.cl[0], this.args[0]);
        } else if (jmfSecurity.getName().startsWith("internet")) {
          PolicyEngine.checkPermission(PermissionID.NETIO);
          PolicyEngine.assertPermission(PermissionID.NETIO);
        } 
      } catch (Throwable e) {
        jmfSecurity.permissionFailureNotification(128);
      }  
    try {
      while (true) {
        try {
          Packet p = this.source.receiveFrom();
          if (checkForClose())
            return; 
          if (p != null)
            this.consumer.sendTo(p); 
          if (checkForClose())
            return; 
        } catch (InterruptedIOException e) {
          if (checkForClose())
            return; 
        } 
      } 
    } catch (IOException e) {
      if (checkForClose())
        return; 
      this.exception = e;
    } finally {
      this.consumer.closeConsumer();
    } 
  }
  
  private boolean checkForClose() {
    if (this.closed && this.thread != null) {
      if (this.source != null)
        this.source.closeSource(); 
      return true;
    } 
    return false;
  }
  
  public void close() {
    this.closed = true;
    if (this.consumer != null)
      this.consumer.closeConsumer(); 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rt\\util\PacketForwarder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */