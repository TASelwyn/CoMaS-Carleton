/*    */ package com.sun.media.rtp.util;
/*    */ 
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Packet
/*    */ {
/*    */   public byte[] data;
/*    */   public int offset;
/*    */   public int length;
/*    */   public boolean received = true;
/*    */   public long receiptTime;
/*    */   
/*    */   public Packet() {}
/*    */   
/*    */   public Packet(Packet p) {
/* 56 */     this.data = p.data;
/* 57 */     this.offset = p.offset;
/* 58 */     this.length = p.length;
/* 59 */     this.received = p.received;
/* 60 */     this.receiptTime = p.receiptTime;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 65 */     String s = "Packet of size " + this.length;
/* 66 */     if (this.received)
/* 67 */       s = s + " received at " + new Date(this.receiptTime); 
/* 68 */     return s;
/*    */   }
/*    */   
/*    */   public Object clone() {
/* 72 */     Packet p = new Packet(this);
/* 73 */     p.data = (byte[])this.data.clone();
/* 74 */     return p;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rt\\util\Packet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */