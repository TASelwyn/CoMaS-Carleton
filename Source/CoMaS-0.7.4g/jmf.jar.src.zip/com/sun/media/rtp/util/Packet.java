package com.sun.media.rtp.util;

import java.util.Date;

public class Packet {
  public byte[] data;
  
  public int offset;
  
  public int length;
  
  public boolean received = true;
  
  public long receiptTime;
  
  public Packet() {}
  
  public Packet(Packet p) {
    this.data = p.data;
    this.offset = p.offset;
    this.length = p.length;
    this.received = p.received;
    this.receiptTime = p.receiptTime;
  }
  
  public String toString() {
    String s = "Packet of size " + this.length;
    if (this.received)
      s = s + " received at " + new Date(this.receiptTime); 
    return s;
  }
  
  public Object clone() {
    Packet p = new Packet(this);
    p.data = (byte[])this.data.clone();
    return p;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rt\\util\Packet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */