package com.sun.media.rtp.util;

import java.io.IOException;

public interface PacketSource {
  Packet receiveFrom() throws IOException;
  
  void closeSource();
  
  String sourceString();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rt\\util\PacketSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */