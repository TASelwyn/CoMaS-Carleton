/*     */ package com.sun.media.rtp.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ import javax.media.rtp.SessionAddress;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PacketFilter
/*     */   implements PacketSource, PacketConsumer
/*     */ {
/*     */   PacketSource source;
/*     */   PacketConsumer consumer;
/*  18 */   public Vector destAddressList = null;
/*  19 */   public Vector peerlist = null;
/*     */   
/*     */   public boolean control = false;
/*     */   
/*     */   public abstract Packet handlePacket(Packet paramPacket);
/*     */   
/*     */   public Packet receiveFrom() throws IOException {
/*  26 */     Packet p = null;
/*     */     
/*  28 */     Packet rawp = this.source.receiveFrom();
/*  29 */     if (rawp != null)
/*  30 */       p = handlePacket(rawp); 
/*  31 */     return p;
/*     */   }
/*     */   
/*     */   public abstract Packet handlePacket(Packet paramPacket, int paramInt);
/*     */   
/*     */   public void sendTo(Packet p) throws IOException {
/*  37 */     Packet origpacket = p;
/*     */     
/*  39 */     if (this.peerlist != null) {
/*  40 */       p = handlePacket(origpacket);
/*  41 */       for (int i = 0; i < this.peerlist.size(); i++) {
/*  42 */         SessionAddress a = this.peerlist.elementAt(i);
/*  43 */         if (!this.control) {
/*  44 */           ((UDPPacket)p).remoteAddress = a.getDataAddress();
/*  45 */           ((UDPPacket)p).remotePort = a.getDataPort();
/*     */         } else {
/*  47 */           ((UDPPacket)p).remoteAddress = a.getControlAddress();
/*  48 */           ((UDPPacket)p).remotePort = a.getControlPort();
/*     */         } 
/*     */         
/*  51 */         if (p != null && this.consumer != null) {
/*  52 */           this.consumer.sendTo(p);
/*     */         }
/*     */       } 
/*  55 */     } else if (this.destAddressList != null) {
/*  56 */       for (int i = 0; i < this.destAddressList.size(); i++) {
/*  57 */         SessionAddress sa = this.destAddressList.elementAt(i);
/*     */         
/*  59 */         p = handlePacket(origpacket, sa);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  66 */         if (p != null && this.consumer != null)
/*  67 */           this.consumer.sendTo(p); 
/*     */       } 
/*  69 */     } else if (this.destAddressList == null) {
/*  70 */       p = handlePacket(p);
/*  71 */       if (p != null && this.consumer != null)
/*  72 */         this.consumer.sendTo(p); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public abstract Packet handlePacket(Packet paramPacket, SessionAddress paramSessionAddress);
/*     */   
/*     */   public void close() {}
/*     */   
/*     */   public void closeSource() {
/*  81 */     close();
/*  82 */     if (this.source != null)
/*  83 */       this.source.closeSource(); 
/*     */   }
/*     */   
/*     */   public void closeConsumer() {
/*  87 */     close();
/*     */     
/*  89 */     if (this.consumer != null)
/*  90 */       this.consumer.closeConsumer(); 
/*     */   }
/*     */   
/*     */   public PacketConsumer getConsumer() {
/*  94 */     return this.consumer;
/*     */   }
/*     */   
/*     */   public PacketSource getSource() {
/*  98 */     return this.source;
/*     */   }
/*     */   
/*     */   public Vector getDestList() {
/* 102 */     return null;
/*     */   }
/*     */   
/*     */   public void setConsumer(PacketConsumer c) {
/* 106 */     this.consumer = c;
/*     */   }
/*     */   
/*     */   public void setSource(PacketSource s) {
/* 110 */     this.source = s;
/*     */   }
/*     */   
/*     */   public String filtername() {
/* 114 */     return getClass().getName();
/*     */   }
/*     */   
/*     */   public String consumerString() {
/* 118 */     if (this.consumer == null) {
/* 119 */       return filtername();
/*     */     }
/* 121 */     return filtername() + " connected to " + this.consumer.consumerString();
/*     */   }
/*     */   
/*     */   public String sourceString() {
/* 125 */     if (this.source == null) {
/* 126 */       return filtername();
/*     */     }
/* 128 */     return filtername() + " attached to " + this.source.sourceString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rt\\util\PacketFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */