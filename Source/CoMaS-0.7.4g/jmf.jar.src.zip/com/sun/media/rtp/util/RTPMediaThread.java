/*    */ package com.sun.media.rtp.util;
/*    */ 
/*    */ import com.sun.media.util.MediaThread;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RTPMediaThread
/*    */   extends MediaThread
/*    */ {
/*    */   public RTPMediaThread() {
/* 19 */     this("RTP thread");
/*    */   }
/*    */   
/*    */   public RTPMediaThread(String name) {
/* 23 */     super(name);
/*    */   }
/*    */   
/*    */   public RTPMediaThread(Runnable r) {
/* 27 */     this(r, "RTP thread");
/*    */   }
/*    */   
/*    */   public RTPMediaThread(Runnable r, String name) {
/* 31 */     super(r, name);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rt\\util\RTPMediaThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */