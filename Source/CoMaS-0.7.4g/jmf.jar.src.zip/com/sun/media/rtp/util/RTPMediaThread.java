package com.sun.media.rtp.util;

import com.sun.media.util.MediaThread;

public class RTPMediaThread extends MediaThread {
  public RTPMediaThread() {
    this("RTP thread");
  }
  
  public RTPMediaThread(String name) {
    super(name);
  }
  
  public RTPMediaThread(Runnable r) {
    this(r, "RTP thread");
  }
  
  public RTPMediaThread(Runnable r, String name) {
    super(r, name);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rt\\util\RTPMediaThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */