package com.sun.media.rtp;

import java.io.DataOutputStream;
import java.io.IOException;

public class RTCPRRPacket extends RTCPPacket {
  int ssrc;
  
  RTCPReportBlock[] reports;
  
  RTCPRRPacket(RTCPPacket parent) {
    super(parent);
    this.type = 201;
  }
  
  RTCPRRPacket(int ssrc, RTCPReportBlock[] reports) {
    this.ssrc = ssrc;
    this.reports = reports;
    if (reports.length > 31)
      throw new IllegalArgumentException("Too many reports"); 
  }
  
  public String toString() {
    return "\tRTCP RR (receiver report) packet for sync source " + this.ssrc + ":\n" + RTCPReportBlock.toString(this.reports);
  }
  
  public int calcLength() {
    return 8 + this.reports.length * 24;
  }
  
  void assemble(DataOutputStream out) throws IOException {
    out.writeByte(128 + this.reports.length);
    out.writeByte(201);
    out.writeShort(1 + this.reports.length * 6);
    out.writeInt(this.ssrc);
    for (int i = 0; i < this.reports.length; i++) {
      out.writeInt((this.reports[i]).ssrc);
      out.writeInt(((this.reports[i]).packetslost & 0xFFFFFF) + ((this.reports[i]).fractionlost << 24));
      out.writeInt((int)(this.reports[i]).lastseq);
      out.writeInt((this.reports[i]).jitter);
      out.writeInt((int)(this.reports[i]).lsr);
      out.writeInt((int)(this.reports[i]).dlsr);
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTCPRRPacket.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */