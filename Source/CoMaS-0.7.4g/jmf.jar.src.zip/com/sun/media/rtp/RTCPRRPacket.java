/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RTCPRRPacket
/*    */   extends RTCPPacket
/*    */ {
/*    */   int ssrc;
/*    */   RTCPReportBlock[] reports;
/*    */   
/*    */   RTCPRRPacket(RTCPPacket parent) {
/* 23 */     super(parent);
/* 24 */     this.type = 201;
/*    */   }
/*    */   
/*    */   RTCPRRPacket(int ssrc, RTCPReportBlock[] reports) {
/* 28 */     this.ssrc = ssrc;
/* 29 */     this.reports = reports;
/* 30 */     if (reports.length > 31)
/* 31 */       throw new IllegalArgumentException("Too many reports"); 
/*    */   }
/*    */   
/*    */   public String toString() {
/* 35 */     return "\tRTCP RR (receiver report) packet for sync source " + this.ssrc + ":\n" + RTCPReportBlock.toString(this.reports);
/*    */   }
/*    */ 
/*    */   
/*    */   public int calcLength() {
/* 40 */     return 8 + this.reports.length * 24;
/*    */   }
/*    */   
/*    */   void assemble(DataOutputStream out) throws IOException {
/* 44 */     out.writeByte(128 + this.reports.length);
/* 45 */     out.writeByte(201);
/* 46 */     out.writeShort(1 + this.reports.length * 6);
/* 47 */     out.writeInt(this.ssrc);
/* 48 */     for (int i = 0; i < this.reports.length; i++) {
/* 49 */       out.writeInt((this.reports[i]).ssrc);
/* 50 */       out.writeInt(((this.reports[i]).packetslost & 0xFFFFFF) + ((this.reports[i]).fractionlost << 24));
/*    */       
/* 52 */       out.writeInt((int)(this.reports[i]).lastseq);
/* 53 */       out.writeInt((this.reports[i]).jitter);
/* 54 */       out.writeInt((int)(this.reports[i]).lsr);
/* 55 */       out.writeInt((int)(this.reports[i]).dlsr);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtp\RTCPRRPacket.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */