package com.sun.media.rtp;

import com.sun.media.util.RTPInfo;
import java.awt.Component;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.media.Format;
import javax.media.rtp.GlobalReceptionStats;
import javax.media.rtp.RTPControl;
import javax.media.rtp.ReceptionStats;

public abstract class RTPControlImpl implements RTPControl, RTPInfo {
  String cname = null;
  
  Hashtable codeclist = null;
  
  int rtptime = 0;
  
  int seqno = 0;
  
  int payload = -1;
  
  String codec = "";
  
  Format currentformat = null;
  
  SSRCInfo stream = null;
  
  public RTPControlImpl() {
    this.codeclist = new Hashtable(5);
  }
  
  public abstract int getSSRC();
  
  public abstract String getCNAME();
  
  public void addFormat(Format info, int payload) {
    this.codeclist.put(new Integer(payload), info);
  }
  
  public Format getFormat() {
    return this.currentformat;
  }
  
  public Format getFormat(int payload) {
    return (Format)this.codeclist.get(new Integer(payload));
  }
  
  public Format[] getFormatList() {
    Format[] infolist = new Format[this.codeclist.size()];
    int i = 0;
    Enumeration e = this.codeclist.elements();
    while (e.hasMoreElements()) {
      Format f = e.nextElement();
      infolist[i++] = (Format)f.clone();
    } 
    return infolist;
  }
  
  public void setRTPInfo(int rtptime, int seqno) {
    this.rtptime = rtptime;
    this.seqno = seqno;
  }
  
  public String toString() {
    String s = "\n\tRTPTime is " + this.rtptime + "\n\tSeqno is " + this.seqno;
    if (this.codeclist != null) {
      s = s + "\n\tCodecInfo is " + this.codeclist.toString();
    } else {
      s = s + "\n\tcodeclist is null";
    } 
    return s;
  }
  
  public ReceptionStats getReceptionStats() {
    if (this.stream == null)
      return null; 
    RecvSSRCInfo recvstream = (RecvSSRCInfo)this.stream;
    return recvstream.getSourceReceptionStats();
  }
  
  public GlobalReceptionStats getGlobalStats() {
    return null;
  }
  
  public Component getControlComponent() {
    return null;
  }
}
