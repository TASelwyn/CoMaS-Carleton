/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import com.sun.media.util.RTPInfo;
/*    */ import java.awt.Component;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Hashtable;
/*    */ import javax.media.Format;
/*    */ import javax.media.rtp.GlobalReceptionStats;
/*    */ import javax.media.rtp.RTPControl;
/*    */ import javax.media.rtp.ReceptionStats;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RTPControlImpl
/*    */   implements RTPControl, RTPInfo
/*    */ {
/* 18 */   String cname = null;
/* 19 */   Hashtable codeclist = null;
/* 20 */   int rtptime = 0;
/* 21 */   int seqno = 0;
/*    */ 
/*    */   
/* 24 */   int payload = -1;
/* 25 */   String codec = "";
/* 26 */   Format currentformat = null;
/* 27 */   SSRCInfo stream = null;
/*    */ 
/*    */   
/*    */   public RTPControlImpl() {
/* 31 */     this.codeclist = new Hashtable(5);
/*    */   }
/*    */   
/*    */   public abstract int getSSRC();
/*    */   
/*    */   public abstract String getCNAME();
/*    */   
/*    */   public void addFormat(Format info, int payload) {
/* 39 */     this.codeclist.put(new Integer(payload), info);
/*    */   }
/*    */ 
/*    */   
/*    */   public Format getFormat() {
/* 44 */     return this.currentformat;
/*    */   }
/*    */   
/*    */   public Format getFormat(int payload) {
/* 48 */     return (Format)this.codeclist.get(new Integer(payload));
/*    */   }
/*    */   
/*    */   public Format[] getFormatList() {
/* 52 */     Format[] infolist = new Format[this.codeclist.size()];
/* 53 */     int i = 0;
/*    */     
/* 55 */     Enumeration e = this.codeclist.elements();
/* 56 */     while (e.hasMoreElements()) {
/* 57 */       Format f = e.nextElement();
/* 58 */       infolist[i++] = (Format)f.clone();
/*    */     } 
/* 60 */     return infolist;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRTPInfo(int rtptime, int seqno) {
/* 65 */     this.rtptime = rtptime;
/* 66 */     this.seqno = seqno;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 70 */     String s = "\n\tRTPTime is " + this.rtptime + "\n\tSeqno is " + this.seqno;
/*    */     
/* 72 */     if (this.codeclist != null) {
/* 73 */       s = s + "\n\tCodecInfo is " + this.codeclist.toString();
/*    */     } else {
/* 75 */       s = s + "\n\tcodeclist is null";
/* 76 */     }  return s;
/*    */   }
/*    */   
/*    */   public ReceptionStats getReceptionStats() {
/* 80 */     if (this.stream == null)
/* 81 */       return null; 
/* 82 */     RecvSSRCInfo recvstream = (RecvSSRCInfo)this.stream;
/* 83 */     return recvstream.getSourceReceptionStats();
/*    */   }
/*    */   
/*    */   public GlobalReceptionStats getGlobalStats() {
/* 87 */     return null;
/*    */   }
/*    */   
/*    */   public Component getControlComponent() {
/* 91 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtp\RTPControlImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */