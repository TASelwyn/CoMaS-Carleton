package com.sun.media.rtp;

import com.sun.media.rtp.util.Packet;
import java.io.DataOutputStream;
import java.io.IOException;

public abstract class RTCPPacket extends Packet {
  public Packet base;
  
  public int type;
  
  public static final int SR = 200;
  
  public static final int RR = 201;
  
  public static final int SDES = 202;
  
  public static final int BYE = 203;
  
  public static final int APP = 204;
  
  public static final int COMPOUND = -1;
  
  public RTCPPacket() {}
  
  public RTCPPacket(Packet p) {
    super(p);
    this.base = p;
  }
  
  public RTCPPacket(RTCPPacket parent) {
    super(parent);
    this.base = parent.base;
  }
  
  public abstract int calcLength();
  
  abstract void assemble(DataOutputStream paramDataOutputStream) throws IOException;
}
