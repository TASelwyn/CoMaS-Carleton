package com.sun.media.rtp;

import com.sun.media.rtp.util.RTPPacket;

public class SourceRTPPacket {
  RTPPacket p;
  
  SSRCInfo ssrcinfo;
  
  public SourceRTPPacket(RTPPacket p, SSRCInfo ssrcinfo) {
    this.p = p;
    this.ssrcinfo = ssrcinfo;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\SourceRTPPacket.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */