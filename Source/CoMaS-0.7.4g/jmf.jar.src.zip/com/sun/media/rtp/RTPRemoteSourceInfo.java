/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import javax.media.rtp.RemoteParticipant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RTPRemoteSourceInfo
/*    */   extends RTPSourceInfo
/*    */   implements RemoteParticipant
/*    */ {
/*    */   public RTPRemoteSourceInfo(String cname, RTPSourceInfoCache sic) {
/* 15 */     super(cname, sic);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtp\RTPRemoteSourceInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */