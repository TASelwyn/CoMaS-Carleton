/*     */ package com.sun.media.rtp;
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.rtp.util.BadFormatException;
/*     */ import com.sun.media.rtp.util.Packet;
/*     */ import com.sun.media.rtp.util.PacketSource;
/*     */ import com.sun.media.rtp.util.RTPPacket;
/*     */ import com.sun.media.rtp.util.RTPPacketReceiver;
/*     */ import com.sun.media.rtp.util.UDPPacketReceiver;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.DatagramSocket;
/*     */ import java.net.SocketException;
/*     */ import java.net.UnknownHostException;
/*     */ import javax.media.rtp.RTPConnector;
/*     */ import javax.media.rtp.RTPPushDataSource;
/*     */ import javax.media.rtp.SessionAddress;
/*     */ 
/*     */ public class RTPRawReceiver extends PacketFilter {
/*  21 */   private OverallStats stats = null;
/*     */   private boolean recvBufSizeSet = false;
/*     */   public DatagramSocket socket;
/*  24 */   private RTPConnector rtpConnector = null;
/*     */   
/*     */   public String filtername() {
/*  27 */     return "RTP Raw Packet Receiver";
/*     */   }
/*     */ 
/*     */   
/*     */   public RTPRawReceiver() {}
/*     */   
/*     */   public RTPRawReceiver(DatagramSocket sock, OverallStats stats) {
/*  34 */     setSource((PacketSource)new UDPPacketReceiver(sock, 2000));
/*  35 */     this.stats = stats;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RTPRawReceiver(SessionAddress localAddress, SessionAddress remoteAddress, OverallStats stats, DatagramSocket dataSocket) throws UnknownHostException, IOException, SocketException {
/*  44 */     this.stats = stats;
/*     */     
/*  46 */     UDPPacketReceiver recv = new UDPPacketReceiver(localAddress.getDataPort(), localAddress.getDataHostAddress(), remoteAddress.getDataPort(), remoteAddress.getDataHostAddress(), 2000, dataSocket);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  54 */     setSource((PacketSource)recv);
/*     */     
/*  56 */     this.socket = recv.getSocket();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RTPRawReceiver(int localPort, String localAddress, OverallStats stats) throws UnknownHostException, IOException, SocketException {
/*     */     UDPPacketReceiver recv;
/*  66 */     setSource((PacketSource)(recv = new UDPPacketReceiver(localPort & 0xFFFFFFFE, localAddress, -1, null, 2000, null)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     this.socket = recv.getSocket();
/*     */     
/*  75 */     this.stats = stats;
/*     */   }
/*     */   
/*     */   public RTPRawReceiver(RTPPushDataSource networkdatasource, OverallStats stats) {
/*  79 */     setSource((PacketSource)new RTPPacketReceiver(networkdatasource));
/*  80 */     this.stats = stats;
/*     */   }
/*     */   
/*     */   public RTPRawReceiver(RTPConnector rtpConnector, OverallStats stats) {
/*     */     try {
/*  85 */       setSource((PacketSource)new RTPPacketReceiver(rtpConnector.getDataInputStream()));
/*     */     } catch (IOException e) {
/*  87 */       e.printStackTrace();
/*     */     } 
/*     */     
/*  90 */     this.rtpConnector = rtpConnector;
/*  91 */     this.stats = stats;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRecvBufSize(int size) {
/*     */     try {
/* 100 */       if (this.socket != null) {
/* 101 */         Class cls = this.socket.getClass();
/* 102 */         Method m = cls.getMethod("setReceiveBufferSize", new Class[] { int.class });
/*     */         
/* 104 */         m.invoke(this.socket, new Object[] { new Integer(size) });
/*     */       
/*     */       }
/* 107 */       else if (this.rtpConnector != null) {
/* 108 */         this.rtpConnector.setReceiveBufferSize(size);
/*     */       } 
/*     */     } catch (Exception e) {
/*     */       
/* 112 */       Log.comment("Cannot set receive buffer size: " + e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRecvBufSize() {
/*     */     try {
/* 123 */       if (this.socket != null) {
/* 124 */         Class cls = this.socket.getClass();
/* 125 */         Method m = cls.getMethod("getReceiveBufferSize", null);
/* 126 */         Integer res = (Integer)m.invoke(this.socket, null);
/*     */ 
/*     */         
/* 129 */         return res.intValue();
/* 130 */       }  if (this.rtpConnector != null) {
/* 131 */         return this.rtpConnector.getReceiveBufferSize();
/*     */       }
/* 133 */     } catch (Exception e) {}
/*     */ 
/*     */     
/* 136 */     return -1;
/*     */   }
/*     */   
/*     */   public void close() {
/* 140 */     if (this.socket != null)
/* 141 */       this.socket.close(); 
/* 142 */     if (getSource() instanceof RTPPacketReceiver)
/* 143 */       getSource().closeSource(); 
/*     */   }
/*     */   
/*     */   public Packet handlePacket(Packet p, int index) {
/* 147 */     return null;
/*     */   }
/*     */   
/*     */   public Packet handlePacket(Packet p, SessionAddress a, boolean b) {
/* 151 */     return null;
/*     */   }
/*     */   
/*     */   public Packet handlePacket(Packet p, SessionAddress a) {
/* 155 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Packet handlePacket(Packet p) {
/*     */     RTPPacket result;
/* 161 */     this.stats.update(0, 1);
/*     */ 
/*     */     
/* 164 */     this.stats.update(1, p.length);
/*     */ 
/*     */     
/*     */     try {
/* 168 */       result = parse(p);
/*     */     } catch (BadFormatException e) {
/*     */       
/* 171 */       this.stats.update(2, 1);
/* 172 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 176 */     if (!this.recvBufSizeSet)
/* 177 */     { this.recvBufSizeSet = true;
/* 178 */       switch (result.payloadType)
/*     */       { case 14:
/*     */         case 26:
/*     */         case 34:
/*     */         case 42:
/* 183 */           setRecvBufSize(64000);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 199 */           return (Packet)result;case 31: setRecvBufSize(128000); return (Packet)result;case 32: setRecvBufSize(128000); return (Packet)result; }  if (result.payloadType >= 96 && result.payloadType <= 127) setRecvBufSize(64000);  }  return (Packet)result;
/*     */   }
/*     */ 
/*     */   
/*     */   public RTPPacket parse(Packet packet) throws BadFormatException {
/* 204 */     RTPPacket p = new RTPPacket(packet);
/*     */     
/* 206 */     DataInputStream in = new DataInputStream(new ByteArrayInputStream(((Packet)p).data, ((Packet)p).offset, ((Packet)p).length));
/*     */ 
/*     */     
/*     */     try {
/* 210 */       int firstbyte = in.readUnsignedByte();
/*     */ 
/*     */       
/* 213 */       if ((firstbyte & 0xC0) != 128) {
/* 214 */         throw new BadFormatException();
/*     */       }
/* 216 */       if ((firstbyte & 0x10) != 0) {
/* 217 */         p.extensionPresent = true;
/*     */       }
/* 219 */       int padlen = 0;
/* 220 */       if ((firstbyte & 0x20) != 0) {
/* 221 */         padlen = ((Packet)p).data[((Packet)p).offset + ((Packet)p).length - 1] & 0xFF;
/*     */       }
/*     */       
/* 224 */       firstbyte &= 0xF;
/* 225 */       p.payloadType = in.readUnsignedByte();
/* 226 */       p.marker = p.payloadType >> 7;
/* 227 */       p.payloadType &= 0x7F;
/* 228 */       p.seqnum = in.readUnsignedShort();
/* 229 */       p.timestamp = in.readInt() & 0xFFFFFFFFL;
/* 230 */       p.ssrc = in.readInt();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 235 */       int offset = 0;
/* 236 */       if (p.extensionPresent) {
/* 237 */         p.extensionType = in.readUnsignedShort();
/* 238 */         int extlen = in.readUnsignedShort();
/* 239 */         extlen <<= 2;
/* 240 */         p.extension = new byte[extlen];
/* 241 */         in.readFully(p.extension);
/* 242 */         offset += extlen + 4;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 247 */       p.csrc = new int[firstbyte];
/* 248 */       for (int i = 0; i < p.csrc.length; i++) {
/* 249 */         p.csrc[i] = in.readInt();
/*     */       }
/* 251 */       offset += 12 + (p.csrc.length << 2);
/* 252 */       p.payloadlength = ((Packet)p).length - offset + padlen;
/*     */       
/* 254 */       if (p.payloadlength < 1) {
/* 255 */         throw new BadFormatException();
/*     */       }
/* 257 */       p.payloadoffset = offset + ((Packet)p).offset;
/*     */     }
/*     */     catch (EOFException e) {
/*     */       
/* 261 */       throw new BadFormatException("Unexpected end of RTP packet");
/*     */     } catch (IOException e) {
/* 263 */       throw new IllegalArgumentException("Impossible Exception");
/*     */     } 
/*     */     
/* 266 */     return p;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtp\RTPRawReceiver.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */