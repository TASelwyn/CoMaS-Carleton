package com.sun.media.rtp;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Choice;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.util.Vector;
import javax.media.Format;
import javax.media.control.BufferControl;

public class BufferControlImpl implements BufferControl {
  private long currBuffer = 2147483647L;
  
  private long currThreshold = 2147483647L;
  
  private long defBuffer = 2147483647L;
  
  private long defThreshold = 2147483647L;
  
  private long maxBuffer = 2147483647L;
  
  private long maxThreshold = 2147483647L;
  
  BufferControlPanel controlComp = null;
  
  boolean threshold_enabled = true;
  
  private static final int AUDIO_DEFAULT_BUFFER = 250;
  
  private static final int AUDIO_DEFAULT_THRESHOLD = 125;
  
  private static final int AUDIO_MAX_BUFFER = 4000;
  
  private static final int AUDIO_MAX_THRESHOLD = 2000;
  
  private static final int VIDEO_DEFAULT_BUFFER = 135;
  
  private static final int VIDEO_DEFAULT_THRESHOLD = 0;
  
  private static final int VIDEO_MAX_BUFFER = 4000;
  
  private static final int VIDEO_MAX_THRESHOLD = 0;
  
  private static final int NOT_SPECIFIED = 2147483647;
  
  private int bufValue = Integer.MAX_VALUE;
  
  private int threshValue = Integer.MAX_VALUE;
  
  private boolean inited = false;
  
  private Vector sourcestreamlist = new Vector(1);
  
  protected void addSourceStream(RTPSourceStream s) {
    this.sourcestreamlist.addElement(s);
    s.setBufferControl(this);
  }
  
  protected void removeSourceStream(RTPSourceStream s) {
    this.sourcestreamlist.removeElement(s);
  }
  
  protected void initBufferControl(Format f) {
    if (f instanceof javax.media.format.AudioFormat) {
      this.defBuffer = (this.defBuffer == 2147483647L) ? 250L : this.currBuffer;
      this.defThreshold = (this.defThreshold == 2147483647L) ? 125L : this.currThreshold;
      this.maxBuffer = (this.maxBuffer == 2147483647L) ? 4000L : this.maxBuffer;
      this.maxThreshold = (this.maxThreshold == 2147483647L) ? 2000L : this.maxThreshold;
      this.currBuffer = (this.currBuffer == 2147483647L) ? this.defBuffer : this.currBuffer;
      this.currThreshold = (this.currThreshold == 2147483647L) ? this.defThreshold : this.currThreshold;
    } 
    if (f instanceof javax.media.format.VideoFormat) {
      this.defBuffer = (this.defBuffer == 2147483647L) ? 135L : this.currBuffer;
      this.defThreshold = (this.defThreshold == 2147483647L) ? 0L : this.currThreshold;
      this.maxBuffer = (this.maxBuffer == 2147483647L) ? 4000L : this.maxBuffer;
      this.maxThreshold = (this.maxThreshold == 2147483647L) ? 0L : this.maxThreshold;
      this.currBuffer = (this.currBuffer == 2147483647L) ? this.defBuffer : this.currBuffer;
      this.currThreshold = (this.currThreshold == 2147483647L) ? this.defThreshold : this.currThreshold;
    } 
    if (this.currBuffer == -2L)
      this.currBuffer = this.maxBuffer; 
    if (this.currBuffer == -1L)
      this.currBuffer = this.defBuffer; 
    if (this.currThreshold == -2L)
      this.currThreshold = this.maxThreshold; 
    if (this.currThreshold == -1L)
      this.currThreshold = this.defThreshold; 
    if (this.controlComp != null) {
      this.controlComp.updateBuffer(this.currBuffer);
      this.controlComp.updateThreshold(this.currThreshold);
    } 
    this.inited = true;
  }
  
  public long getBufferLength() {
    return this.currBuffer;
  }
  
  public long setBufferLength(long time) {
    if (!this.inited) {
      this.currBuffer = time;
      return time;
    } 
    if (time == -1L)
      time = this.defBuffer; 
    if (time == -2L)
      time = this.maxBuffer; 
    if (time < this.currThreshold)
      return this.currBuffer; 
    if (time >= this.maxBuffer) {
      this.currBuffer = this.maxBuffer;
    } else if (time <= 0L || time == this.defBuffer) {
      this.currBuffer = this.defBuffer;
    } else {
      this.currBuffer = time;
    } 
    for (int i = 0; i < this.sourcestreamlist.size(); i++)
      ((RTPSourceStream)this.sourcestreamlist.elementAt(i)).updateBuffer(this.currBuffer); 
    if (this.controlComp != null)
      this.controlComp.updateBuffer(this.currBuffer); 
    return this.currBuffer;
  }
  
  public long getMinimumThreshold() {
    return this.currThreshold;
  }
  
  public long setMinimumThreshold(long t) {
    if (!this.inited) {
      this.currThreshold = t;
      return t;
    } 
    if (t == -1L)
      t = this.defThreshold; 
    if (t == -2L)
      t = this.maxThreshold; 
    if (t > this.currBuffer)
      return this.currThreshold; 
    if (t >= this.maxThreshold) {
      this.currThreshold = this.maxThreshold;
    } else if (t == this.defThreshold) {
      this.currThreshold = this.defThreshold;
    } else {
      this.currThreshold = t;
    } 
    if (t < 0L)
      this.currThreshold = 0L; 
    for (int i = 0; i < this.sourcestreamlist.size(); i++)
      ((RTPSourceStream)this.sourcestreamlist.elementAt(i)).updateThreshold(this.currThreshold); 
    if (this.controlComp != null)
      this.controlComp.updateThreshold(this.currThreshold); 
    return this.currThreshold;
  }
  
  public void setEnabledThreshold(boolean b) {
    this.threshold_enabled = b;
  }
  
  public boolean getEnabledThreshold() {
    return this.threshold_enabled;
  }
  
  public Component getControlComponent() {
    if (this.controlComp == null)
      this.controlComp = new BufferControlPanel(this); 
    return this.controlComp;
  }
  
  class BufferControlPanel extends Panel {
    Panel buffersize;
    
    Panel threshold;
    
    TextField bsize;
    
    TextField btext;
    
    Choice bchoice;
    
    Choice tchoice;
    
    TextField tsize;
    
    TextField ttext;
    
    Button bb;
    
    Button tb;
    
    private final BufferControlImpl this$0;
    
    public BufferControlPanel(BufferControlImpl this$0) {
      super(new BorderLayout());
      this.this$0 = this$0;
      this.buffersize = null;
      this.threshold = null;
      this.btext = null;
      this.bchoice = null;
      this.tchoice = null;
      this.ttext = null;
      this.tb = null;
      this.buffersize = new Panel(new FlowLayout());
      this.buffersize.add(new Label("BufferSize"));
      this.bsize = new TextField(15);
      updateBuffer(this$0.getBufferLength());
      this.bsize.setEnabled(false);
      this.buffersize.add(this.bsize);
      this.buffersize.add(new Label("Update"));
      this.buffersize.add(this.bchoice = new Choice());
      this.bchoice.add("DEFAULT");
      this.bchoice.add("MAX");
      this.bchoice.add("User Defined");
      this.bchoice.addItemListener((ItemListener)new Object(this));
      this.buffersize.add(new Label("If User Defined, Enter here:"));
      this.buffersize.add(this.btext = new TextField(10));
      this.btext.setEnabled(false);
      this.buffersize.add(this.bb = new Button("Commit"));
      this.bb.addActionListener((ActionListener)new Object(this));
      this.threshold = new Panel(new FlowLayout());
      this.threshold.add(new Label("Threshold"));
      this.tsize = new TextField(15);
      updateThreshold(this$0.getMinimumThreshold());
      this.tsize.setEnabled(false);
      this.threshold.add(this.tsize);
      this.threshold.add(new Label("Update"));
      this.threshold.add(this.tchoice = new Choice());
      this.tchoice.add("DEFAULT");
      this.tchoice.add("MAX");
      this.tchoice.add("User Defined");
      this.tchoice.addItemListener((ItemListener)new Object(this));
      this.threshold.add(new Label("If User Defined, Enter here:"));
      this.threshold.add(this.ttext = new TextField(10));
      this.ttext.setEnabled(false);
      this.threshold.add(this.tb = new Button("Commit"));
      this.tb.addActionListener((ActionListener)new Object(this));
      add(this.buffersize, "North");
      add(new Label("Actual buffer & threshold sizes (in millisec) not displayed until media type is determined"), "Center");
      add(this.threshold, "South");
      setVisible(true);
    }
    
    private void buffersizeUpdate() {
      String s = this.bchoice.getSelectedItem();
      long b = -1L;
      if (s.equals("MAX")) {
        b = -2L;
      } else if (s.equals("DEFAULT")) {
        b = -1L;
      } else {
        s = this.btext.getText();
        b = (new Long(s)).longValue();
      } 
      b = this.this$0.setBufferLength(b);
      updateBuffer(b);
    }
    
    private void thresholdUpdate() {
      String s = this.tchoice.getSelectedItem();
      long t = -1L;
      if (s.equals("DEFAULT")) {
        t = -1L;
      } else if (s.equals("MAX")) {
        t = -2L;
      } else {
        s = this.ttext.getText();
        t = (new Long(s)).longValue();
      } 
      t = this.this$0.setMinimumThreshold(t);
      updateThreshold(t);
    }
    
    public void updateBuffer(long b) {
      if (b != 2147483647L && b != -2L && b != -1L)
        this.bsize.setText((new Long(b)).toString()); 
    }
    
    public void updateThreshold(long d) {
      if (d != 2147483647L && d != -2L && d != -1L)
        this.tsize.setText((new Long(d)).toString()); 
    }
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\BufferControlImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */