package com.sun.media.rtp;

public final class TrueRandom {
  public void TrueRandom() {}
  
  public static long rand() {
    return System.currentTimeMillis();
  }
}
