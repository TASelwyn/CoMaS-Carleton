package com.sun.media.rtp;

import com.sun.media.rtp.util.Packet;
import com.sun.media.rtp.util.PacketConsumer;
import com.sun.media.rtp.util.PacketForwarder;
import com.sun.media.rtp.util.PacketSource;
import com.sun.media.rtp.util.UDPPacket;
import java.io.IOException;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import javax.media.rtp.ReceiveStream;
import javax.media.rtp.event.ActiveReceiveStreamEvent;
import javax.media.rtp.event.ApplicationEvent;
import javax.media.rtp.event.ByeEvent;
import javax.media.rtp.event.NewParticipantEvent;
import javax.media.rtp.event.RTPEvent;
import javax.media.rtp.event.ReceiverReportEvent;
import javax.media.rtp.event.SenderReportEvent;
import javax.media.rtp.event.StreamMappedEvent;
import javax.media.rtp.rtcp.ReceiverReport;
import javax.media.rtp.rtcp.SenderReport;

public class RTCPReceiver implements PacketConsumer {
  private static final int SR = 1;
  
  private static final int RR = 2;
  
  private boolean rtcpstarted = false;
  
  private boolean sentrecvstrmap = false;
  
  SSRCCache cache;
  
  private int type = 0;
  
  public RTCPReceiver(SSRCCache cache) {
    this.cache = cache;
    SSRCInfo info = cache.lookup(cache.ourssrc.ssrc);
  }
  
  public RTCPReceiver(SSRCCache cache, PacketSource source) {
    this(cache);
    PacketForwarder f = new PacketForwarder(source, this);
    f.startPF();
  }
  
  public RTCPReceiver(SSRCCache cache, DatagramSocket sock, StreamSynch streamSynch) {
    this(cache, (PacketSource)new RTCPRawReceiver(sock, cache.sm.defaultstats, streamSynch));
  }
  
  public RTCPReceiver(SSRCCache cache, int port, String address, StreamSynch streamSynch) throws UnknownHostException, IOException {
    this(cache, (PacketSource)new RTCPRawReceiver(port | 0x1, address, cache.sm.defaultstats, streamSynch));
  }
  
  public String consumerString() {
    return "RTCP Packet Receiver/Collector";
  }
  
  public void closeConsumer() {}
  
  public void sendTo(Packet p) {
    sendTo((RTCPPacket)p);
  }
  
  public void sendTo(RTCPPacket p) {
    RTCPCompoundPacket cp;
    int i;
    RTCPSRPacket srp;
    int j;
    RTCPRRPacket rrp;
    int k;
    ReceiverReportEvent evt;
    RTCPSDESPacket sdesp;
    int m;
    RTCPBYEPacket byep;
    int n;
    RTCPAPPPacket appp;
    ApplicationEvent evnt;
    SSRCInfo info = null;
    boolean unicast = this.cache.sm.isUnicast();
    if (unicast)
      if (!this.rtcpstarted) {
        this.cache.sm.startRTCPReports(((UDPPacket)p.base).remoteAddress);
        this.rtcpstarted = true;
        byte[] lsb = this.cache.sm.controladdress.getAddress();
        int address = lsb[3] & 0xFF;
        if ((address & 0xFF) == 255) {
          this.cache.sm.addUnicastAddr(this.cache.sm.controladdress);
        } else {
          InetAddress localaddr = null;
          boolean localfound = true;
          try {
            localaddr = InetAddress.getLocalHost();
          } catch (UnknownHostException e) {
            localfound = false;
          } 
          if (localfound)
            this.cache.sm.addUnicastAddr(localaddr); 
        } 
      } else if (!this.cache.sm.isSenderDefaultAddr(((UDPPacket)p.base).remoteAddress)) {
        this.cache.sm.addUnicastAddr(((UDPPacket)p.base).remoteAddress);
      }  
    switch (p.type) {
      case -1:
        cp = (RTCPCompoundPacket)p;
        this.cache.updateavgrtcpsize(cp.length);
        for (i = 0; i < cp.packets.length; i++)
          sendTo(cp.packets[i]); 
        if (this.cache.sm.cleaner != null)
          this.cache.sm.cleaner.setClean(); 
        break;
      case 200:
        srp = (RTCPSRPacket)p;
        this.type = 1;
        if (p.base instanceof UDPPacket) {
          info = this.cache.get(srp.ssrc, ((UDPPacket)p.base).remoteAddress, ((UDPPacket)p.base).remotePort, 1);
        } else {
          info = this.cache.get(srp.ssrc, null, 0, 1);
        } 
        if (info == null)
          break; 
        info.setAlive(true);
        info.lastSRntptimestamp = (srp.ntptimestampmsw << 32L) + srp.ntptimestamplsw;
        info.lastSRrtptimestamp = srp.rtptimestamp;
        info.lastSRreceiptTime = srp.receiptTime;
        info.lastRTCPreceiptTime = srp.receiptTime;
        info.lastHeardFrom = srp.receiptTime;
        if (info.quiet) {
          info.quiet = false;
          ActiveReceiveStreamEvent event = null;
          if (info instanceof ReceiveStream) {
            event = new ActiveReceiveStreamEvent(this.cache.sm, info.sourceInfo, (ReceiveStream)info);
          } else {
            event = new ActiveReceiveStreamEvent(this.cache.sm, info.sourceInfo, null);
          } 
          this.cache.eventhandler.postEvent((RTPEvent)event);
        } 
        info.lastSRpacketcount = srp.packetcount;
        info.lastSRoctetcount = srp.octetcount;
        for (j = 0; j < srp.reports.length; j++) {
          (srp.reports[j]).receiptTime = srp.receiptTime;
          int rbssrc = (srp.reports[j]).ssrc;
          RTCPReportBlock[] reporta = (RTCPReportBlock[])info.reports.get(rbssrc);
          if (reporta == null) {
            reporta = new RTCPReportBlock[2];
            reporta[0] = srp.reports[j];
            info.reports.put(rbssrc, reporta);
          } else {
            reporta[1] = reporta[0];
            reporta[0] = srp.reports[j];
          } 
        } 
        if (info.probation <= 0) {
          if (!info.newpartsent && info.sourceInfo != null) {
            NewParticipantEvent evtsdes = new NewParticipantEvent(this.cache.sm, info.sourceInfo);
            this.cache.eventhandler.postEvent((RTPEvent)evtsdes);
            info.newpartsent = true;
          } 
          if (!info.recvstrmap && info.sourceInfo != null) {
            info.recvstrmap = true;
            StreamMappedEvent streamMappedEvent = new StreamMappedEvent(this.cache.sm, (ReceiveStream)info, info.sourceInfo);
            this.cache.eventhandler.postEvent((RTPEvent)streamMappedEvent);
          } 
          SenderReportEvent evtsr = new SenderReportEvent(this.cache.sm, (SenderReport)info);
          this.cache.eventhandler.postEvent((RTPEvent)evtsr);
        } 
        break;
      case 201:
        rrp = (RTCPRRPacket)p;
        this.type = 2;
        if (p.base instanceof UDPPacket) {
          info = this.cache.get(rrp.ssrc, ((UDPPacket)p.base).remoteAddress, ((UDPPacket)p.base).remotePort, 2);
        } else {
          info = this.cache.get(rrp.ssrc, null, 0, 2);
        } 
        if (info == null)
          break; 
        info.setAlive(true);
        info.lastRTCPreceiptTime = rrp.receiptTime;
        info.lastHeardFrom = rrp.receiptTime;
        if (info.quiet) {
          info.quiet = false;
          ActiveReceiveStreamEvent event = null;
          if (info instanceof ReceiveStream) {
            event = new ActiveReceiveStreamEvent(this.cache.sm, info.sourceInfo, (ReceiveStream)info);
          } else {
            event = new ActiveReceiveStreamEvent(this.cache.sm, info.sourceInfo, null);
          } 
          this.cache.eventhandler.postEvent((RTPEvent)event);
        } 
        for (k = 0; k < rrp.reports.length; k++) {
          (rrp.reports[k]).receiptTime = rrp.receiptTime;
          int rbssrc = (rrp.reports[k]).ssrc;
          RTCPReportBlock[] reporta = (RTCPReportBlock[])info.reports.get(rbssrc);
          if (reporta == null) {
            reporta = new RTCPReportBlock[2];
            reporta[0] = rrp.reports[k];
            info.reports.put(rbssrc, reporta);
          } else {
            reporta[1] = reporta[0];
            reporta[0] = rrp.reports[k];
          } 
        } 
        if (!info.newpartsent && info.sourceInfo != null) {
          NewParticipantEvent evtsdes = new NewParticipantEvent(this.cache.sm, info.sourceInfo);
          this.cache.eventhandler.postEvent((RTPEvent)evtsdes);
          info.newpartsent = true;
        } 
        evt = new ReceiverReportEvent(this.cache.sm, (ReceiverReport)info);
        this.cache.eventhandler.postEvent((RTPEvent)evt);
        break;
      case 202:
        sdesp = (RTCPSDESPacket)p;
        for (m = 0; m < sdesp.sdes.length; m++) {
          RTCPSDES chunk = sdesp.sdes[m];
          if (this.type == 1)
            if (p.base instanceof UDPPacket) {
              info = this.cache.get(chunk.ssrc, ((UDPPacket)p.base).remoteAddress, ((UDPPacket)p.base).remotePort, 1);
            } else {
              info = this.cache.get(chunk.ssrc, null, 0, 1);
            }  
          if (this.type == 2)
            if (p.base instanceof UDPPacket) {
              info = this.cache.get(chunk.ssrc, ((UDPPacket)p.base).remoteAddress, ((UDPPacket)p.base).remotePort, 2);
            } else {
              info = this.cache.get(chunk.ssrc, null, 0, 2);
            }  
          if (info == null)
            break; 
          info.setAlive(true);
          info.lastHeardFrom = sdesp.receiptTime;
          info.addSDESInfo(chunk);
        } 
        if (info != null && !info.newpartsent && info.sourceInfo != null) {
          NewParticipantEvent evtsdes = new NewParticipantEvent(this.cache.sm, info.sourceInfo);
          this.cache.eventhandler.postEvent((RTPEvent)evtsdes);
          info.newpartsent = true;
        } 
        if (info != null && !info.recvstrmap && info.sourceInfo != null && info instanceof RecvSSRCInfo) {
          info.recvstrmap = true;
          StreamMappedEvent evtr = new StreamMappedEvent(this.cache.sm, (ReceiveStream)info, info.sourceInfo);
          this.cache.eventhandler.postEvent((RTPEvent)evtr);
        } 
        this.type = 0;
        break;
      case 203:
        byep = (RTCPBYEPacket)p;
        if (p.base instanceof UDPPacket) {
          info = this.cache.get(byep.ssrc[0], ((UDPPacket)p.base).remoteAddress, ((UDPPacket)p.base).remotePort);
        } else {
          info = this.cache.get(byep.ssrc[0], null, 0);
        } 
        for (n = 0; n < byep.ssrc.length; n++) {
          if (p.base instanceof UDPPacket) {
            info = this.cache.get(byep.ssrc[n], ((UDPPacket)p.base).remoteAddress, ((UDPPacket)p.base).remotePort);
          } else {
            info = this.cache.get(byep.ssrc[n], null, 0);
          } 
          if (info == null)
            break; 
          if (!this.cache.byestate) {
            info.setAlive(false);
            info.byeReceived = true;
            info.byeTime = p.receiptTime;
            info.lastHeardFrom = byep.receiptTime;
          } 
        } 
        if (info == null)
          break; 
        if (info.quiet) {
          info.quiet = false;
          ActiveReceiveStreamEvent event = null;
          if (info instanceof ReceiveStream) {
            event = new ActiveReceiveStreamEvent(this.cache.sm, info.sourceInfo, (ReceiveStream)info);
          } else {
            event = new ActiveReceiveStreamEvent(this.cache.sm, info.sourceInfo, null);
          } 
          this.cache.eventhandler.postEvent((RTPEvent)event);
        } 
        info.byereason = new String(byep.reason);
        if (!info.byeReceived) {
          boolean byepart = false;
          RTPSourceInfo sourceInfo = info.sourceInfo;
          if (sourceInfo != null && sourceInfo.getStreamCount() == 0)
            byepart = true; 
          ByeEvent evtbye = null;
          if (info instanceof RecvSSRCInfo)
            evtbye = new ByeEvent(this.cache.sm, info.sourceInfo, (ReceiveStream)info, new String(byep.reason), byepart); 
          if (info instanceof PassiveSSRCInfo)
            evtbye = new ByeEvent(this.cache.sm, info.sourceInfo, null, new String(byep.reason), byepart); 
          this.cache.eventhandler.postEvent((RTPEvent)evtbye);
        } 
        break;
      case 204:
        appp = (RTCPAPPPacket)p;
        if (p.base instanceof UDPPacket) {
          info = this.cache.get(appp.ssrc, ((UDPPacket)p.base).remoteAddress, ((UDPPacket)p.base).remotePort);
        } else {
          info = this.cache.get(appp.ssrc, null, 0);
        } 
        if (info == null)
          break; 
        info.lastHeardFrom = appp.receiptTime;
        if (info.quiet) {
          info.quiet = false;
          ActiveReceiveStreamEvent event = null;
          if (info instanceof ReceiveStream) {
            event = new ActiveReceiveStreamEvent(this.cache.sm, info.sourceInfo, (ReceiveStream)info);
          } else {
            event = new ActiveReceiveStreamEvent(this.cache.sm, info.sourceInfo, null);
          } 
          this.cache.eventhandler.postEvent((RTPEvent)event);
        } 
        evnt = null;
        if (info instanceof RecvSSRCInfo)
          evnt = new ApplicationEvent(this.cache.sm, info.sourceInfo, (ReceiveStream)info, appp.subtype, null, appp.data); 
        if (info instanceof PassiveSSRCInfo)
          evnt = new ApplicationEvent(this.cache.sm, info.sourceInfo, null, appp.subtype, null, appp.data); 
        this.cache.eventhandler.postEvent((RTPEvent)evnt);
        break;
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTCPReceiver.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */