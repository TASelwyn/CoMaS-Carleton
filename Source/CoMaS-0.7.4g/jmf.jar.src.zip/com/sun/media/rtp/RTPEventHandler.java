package com.sun.media.rtp;

import com.sun.media.rtp.util.RTPMediaThread;
import java.util.Vector;
import javax.media.rtp.ReceiveStreamListener;
import javax.media.rtp.RemoteListener;
import javax.media.rtp.SendStreamListener;
import javax.media.rtp.SessionListener;
import javax.media.rtp.event.RTPEvent;
import javax.media.rtp.event.ReceiveStreamEvent;
import javax.media.rtp.event.RemoteEvent;
import javax.media.rtp.event.SendStreamEvent;
import javax.media.rtp.event.SessionEvent;

public class RTPEventHandler extends RTPMediaThread {
  private RTPSessionMgr sm;
  
  private Vector eventQueue = new Vector();
  
  private boolean killed = false;
  
  public RTPEventHandler(RTPSessionMgr sm) {
    super("RTPEventHandler");
    this.sm = sm;
    useControlPriority();
    setDaemon(true);
    start();
  }
  
  protected void processEvent(RTPEvent evt) {
    if (evt instanceof SessionEvent) {
      for (int i = 0; i < this.sm.sessionlistener.size(); i++) {
        SessionListener sl = this.sm.sessionlistener.elementAt(i);
        if (sl != null)
          sl.update((SessionEvent)evt); 
      } 
      return;
    } 
    if (evt instanceof RemoteEvent) {
      for (int i = 0; i < this.sm.remotelistener.size(); i++) {
        RemoteListener sl = this.sm.remotelistener.elementAt(i);
        if (sl != null)
          sl.update((RemoteEvent)evt); 
      } 
      return;
    } 
    if (evt instanceof ReceiveStreamEvent) {
      for (int i = 0; i < this.sm.streamlistener.size(); i++) {
        ReceiveStreamListener sl = this.sm.streamlistener.elementAt(i);
        if (sl != null)
          sl.update((ReceiveStreamEvent)evt); 
      } 
      return;
    } 
    if (evt instanceof SendStreamEvent)
      for (int i = 0; i < this.sm.sendstreamlistener.size(); i++) {
        SendStreamListener sl = this.sm.sendstreamlistener.elementAt(i);
        if (sl != null)
          sl.update((SendStreamEvent)evt); 
      }  
  }
  
  protected void dispatchEvents() {
    RTPEvent evt;
    synchronized (this) {
      try {
        while (this.eventQueue.size() == 0 && !this.killed)
          wait(); 
      } catch (InterruptedException e) {}
      if (this.killed)
        return; 
      evt = this.eventQueue.elementAt(0);
      this.eventQueue.removeElementAt(0);
    } 
    processEvent(evt);
  }
  
  public synchronized void postEvent(RTPEvent evt) {
    this.eventQueue.addElement(evt);
    notifyAll();
  }
  
  public synchronized void close() {
    this.killed = true;
    notifyAll();
  }
  
  public void run() {
    while (!this.killed)
      dispatchEvents(); 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTPEventHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */