/*     */ package com.sun.media.rtp;
/*     */ 
/*     */ import com.sun.media.rtp.util.RTPMediaThread;
/*     */ import java.util.Vector;
/*     */ import javax.media.rtp.ReceiveStreamListener;
/*     */ import javax.media.rtp.RemoteListener;
/*     */ import javax.media.rtp.SendStreamListener;
/*     */ import javax.media.rtp.SessionListener;
/*     */ import javax.media.rtp.event.RTPEvent;
/*     */ import javax.media.rtp.event.ReceiveStreamEvent;
/*     */ import javax.media.rtp.event.RemoteEvent;
/*     */ import javax.media.rtp.event.SendStreamEvent;
/*     */ import javax.media.rtp.event.SessionEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RTPEventHandler
/*     */   extends RTPMediaThread
/*     */ {
/*     */   private RTPSessionMgr sm;
/*  21 */   private Vector eventQueue = new Vector();
/*     */   
/*     */   private boolean killed = false;
/*     */   
/*     */   public RTPEventHandler(RTPSessionMgr sm) {
/*  26 */     super("RTPEventHandler");
/*  27 */     this.sm = sm;
/*  28 */     useControlPriority();
/*  29 */     setDaemon(true);
/*  30 */     start();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processEvent(RTPEvent evt) {
/*  36 */     if (evt instanceof SessionEvent) {
/*     */ 
/*     */       
/*  39 */       for (int i = 0; i < this.sm.sessionlistener.size(); i++) {
/*  40 */         SessionListener sl = this.sm.sessionlistener.elementAt(i);
/*  41 */         if (sl != null)
/*  42 */           sl.update((SessionEvent)evt); 
/*     */       } 
/*     */       return;
/*     */     } 
/*  46 */     if (evt instanceof RemoteEvent) {
/*     */ 
/*     */       
/*  49 */       for (int i = 0; i < this.sm.remotelistener.size(); i++) {
/*  50 */         RemoteListener sl = this.sm.remotelistener.elementAt(i);
/*  51 */         if (sl != null)
/*  52 */           sl.update((RemoteEvent)evt); 
/*     */       } 
/*     */       return;
/*     */     } 
/*  56 */     if (evt instanceof ReceiveStreamEvent) {
/*     */ 
/*     */       
/*  59 */       for (int i = 0; i < this.sm.streamlistener.size(); i++) {
/*  60 */         ReceiveStreamListener sl = this.sm.streamlistener.elementAt(i);
/*  61 */         if (sl != null)
/*  62 */           sl.update((ReceiveStreamEvent)evt); 
/*     */       } 
/*     */       return;
/*     */     } 
/*  66 */     if (evt instanceof SendStreamEvent)
/*     */     {
/*     */       
/*  69 */       for (int i = 0; i < this.sm.sendstreamlistener.size(); i++) {
/*  70 */         SendStreamListener sl = this.sm.sendstreamlistener.elementAt(i);
/*  71 */         if (sl != null) {
/*  72 */           sl.update((SendStreamEvent)evt);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   protected void dispatchEvents() {
/*     */     RTPEvent evt;
/*  80 */     synchronized (this) {
/*     */       
/*     */       try {
/*  83 */         while (this.eventQueue.size() == 0 && !this.killed) {
/*  84 */           wait();
/*     */         }
/*  86 */       } catch (InterruptedException e) {}
/*     */       
/*  88 */       if (this.killed) {
/*     */         return;
/*     */       }
/*     */       
/*  92 */       evt = this.eventQueue.elementAt(0);
/*  93 */       this.eventQueue.removeElementAt(0);
/*     */     } 
/*     */     
/*  96 */     processEvent(evt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void postEvent(RTPEvent evt) {
/* 102 */     this.eventQueue.addElement(evt);
/* 103 */     notifyAll();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void close() {
/* 108 */     this.killed = true;
/* 109 */     notifyAll();
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/* 114 */     while (!this.killed)
/* 115 */       dispatchEvents(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtp\RTPEventHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */