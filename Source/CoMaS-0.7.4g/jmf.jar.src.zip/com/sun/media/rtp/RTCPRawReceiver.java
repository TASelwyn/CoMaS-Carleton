package com.sun.media.rtp;

import com.sun.media.rtp.util.BadFormatException;
import com.sun.media.rtp.util.Packet;
import com.sun.media.rtp.util.PacketFilter;
import com.sun.media.rtp.util.PacketSource;
import com.sun.media.rtp.util.RTPPacketReceiver;
import com.sun.media.rtp.util.UDPPacketReceiver;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Vector;
import javax.media.rtp.RTPConnector;
import javax.media.rtp.RTPPushDataSource;
import javax.media.rtp.SessionAddress;

public class RTCPRawReceiver extends PacketFilter {
  public DatagramSocket socket;
  
  private StreamSynch streamSynch;
  
  private OverallStats stats = null;
  
  public String filtername() {
    return "RTCP Raw Receiver";
  }
  
  public RTCPRawReceiver() {}
  
  public RTCPRawReceiver(DatagramSocket sock, OverallStats stats, StreamSynch streamSynch) {
    setSource((PacketSource)new UDPPacketReceiver(sock, 1000));
    this.stats = stats;
    this.streamSynch = streamSynch;
  }
  
  public RTCPRawReceiver(SessionAddress localAddress, SessionAddress remoteAddress, OverallStats stats, StreamSynch streamSynch, DatagramSocket controlSocket) throws UnknownHostException, IOException, SocketException {
    this.streamSynch = streamSynch;
    this.stats = stats;
    UDPPacketReceiver recv = new UDPPacketReceiver(localAddress.getControlPort(), localAddress.getControlHostAddress(), remoteAddress.getControlPort(), remoteAddress.getControlHostAddress(), 1000, controlSocket);
    setSource((PacketSource)recv);
    this.socket = recv.getSocket();
  }
  
  public RTCPRawReceiver(int localPort, String localAddress, OverallStats stats, StreamSynch streamSynch) throws UnknownHostException, IOException, SocketException {
    this.streamSynch = streamSynch;
    this.stats = stats;
    UDPPacketReceiver recv = new UDPPacketReceiver(localPort, localAddress, -1, null, 1000, null);
    setSource((PacketSource)recv);
    this.socket = recv.getSocket();
  }
  
  public RTCPRawReceiver(RTPPushDataSource networkdatasource, OverallStats stats, StreamSynch streamSynch) {
    this.streamSynch = streamSynch;
    setSource((PacketSource)new RTPPacketReceiver(networkdatasource));
    this.stats = stats;
  }
  
  public RTCPRawReceiver(RTPConnector rtpConnector, OverallStats stats, StreamSynch streamSynch) {
    this.streamSynch = streamSynch;
    try {
      setSource((PacketSource)new RTPPacketReceiver(rtpConnector.getControlInputStream()));
    } catch (IOException e) {
      e.printStackTrace();
    } 
    this.stats = stats;
  }
  
  public void close() {
    if (this.socket != null)
      this.socket.close(); 
    if (getSource() instanceof RTPPacketReceiver)
      getSource().closeSource(); 
  }
  
  public Packet handlePacket(Packet p, int i) {
    return null;
  }
  
  public Packet handlePacket(Packet p, SessionAddress a, boolean control) {
    return null;
  }
  
  public Packet handlePacket(Packet p, SessionAddress a) {
    return null;
  }
  
  public Packet handlePacket(Packet p) {
    RTCPPacket result;
    this.stats.update(0, 1);
    this.stats.update(11, 1);
    this.stats.update(1, p.length);
    try {
      result = parse(p);
    } catch (BadFormatException e) {
      this.stats.update(13, 1);
      return null;
    } 
    return result;
  }
  
  public RTCPPacket parse(Packet packet) throws BadFormatException {
    RTCPCompoundPacket base = new RTCPCompoundPacket(packet);
    Vector subpackets = new Vector(2);
    DataInputStream in = new DataInputStream(new ByteArrayInputStream(base.data, base.offset, base.length));
    try {
      for (int offset = 0; offset < base.length; offset += length) {
        RTCPPacket p;
        RTCPSRPacket srp;
        int i;
        RTCPRRPacket rrp;
        int j;
        RTCPSDESPacket sdesp;
        int sdesoff, k;
        RTCPBYEPacket byep;
        int m, n;
        RTCPAPPPacket appp;
        int firstbyte = in.readUnsignedByte();
        if ((firstbyte & 0xC0) != 128)
          throw new BadFormatException(); 
        int type = in.readUnsignedByte();
        int length = in.readUnsignedShort();
        length = length + 1 << 2;
        int padlen = 0;
        if (offset + length > base.length)
          throw new BadFormatException(); 
        if (offset + length == base.length) {
          if ((firstbyte & 0x20) != 0) {
            padlen = base.data[base.offset + base.length - 1] & 0xFF;
            if (padlen == 0)
              throw new BadFormatException(); 
          } 
        } else if ((firstbyte & 0x20) != 0) {
          throw new BadFormatException();
        } 
        int inlength = length - padlen;
        firstbyte &= 0x1F;
        switch (type) {
          case 200:
            this.stats.update(12, 1);
            if (inlength != 28 + 24 * firstbyte) {
              this.stats.update(18, 1);
              System.out.println("bad format.");
              throw new BadFormatException();
            } 
            srp = new RTCPSRPacket(base);
            p = srp;
            srp.ssrc = in.readInt();
            srp.ntptimestampmsw = in.readInt() & 0xFFFFFFFFL;
            srp.ntptimestamplsw = in.readInt() & 0xFFFFFFFFL;
            srp.rtptimestamp = in.readInt() & 0xFFFFFFFFL;
            srp.packetcount = in.readInt() & 0xFFFFFFFFL;
            srp.octetcount = in.readInt() & 0xFFFFFFFFL;
            srp.reports = new RTCPReportBlock[firstbyte];
            this.streamSynch.update(srp.ssrc, srp.rtptimestamp, srp.ntptimestampmsw, srp.ntptimestamplsw);
            for (i = 0; i < srp.reports.length; i++) {
              RTCPReportBlock report = new RTCPReportBlock();
              srp.reports[i] = report;
              report.ssrc = in.readInt();
              long val = in.readInt();
              val &= 0xFFFFFFFFL;
              report.fractionlost = (int)(val >> 24L);
              report.packetslost = (int)(val & 0xFFFFFFL);
              report.lastseq = in.readInt() & 0xFFFFFFFFL;
              report.jitter = in.readInt();
              report.lsr = in.readInt() & 0xFFFFFFFFL;
              report.dlsr = in.readInt() & 0xFFFFFFFFL;
            } 
            break;
          case 201:
            if (inlength != 8 + 24 * firstbyte) {
              this.stats.update(15, 1);
              throw new BadFormatException();
            } 
            rrp = new RTCPRRPacket(base);
            p = rrp;
            rrp.ssrc = in.readInt();
            rrp.reports = new RTCPReportBlock[firstbyte];
            for (j = 0; j < rrp.reports.length; j++) {
              RTCPReportBlock report = new RTCPReportBlock();
              rrp.reports[j] = report;
              report.ssrc = in.readInt();
              long val = in.readInt();
              val &= 0xFFFFFFFFL;
              report.fractionlost = (int)(val >> 24L);
              report.packetslost = (int)(val & 0xFFFFFFL);
              report.lastseq = in.readInt() & 0xFFFFFFFFL;
              report.jitter = in.readInt();
              report.lsr = in.readInt() & 0xFFFFFFFFL;
              report.dlsr = in.readInt() & 0xFFFFFFFFL;
            } 
            break;
          case 202:
            sdesp = new RTCPSDESPacket(base);
            p = sdesp;
            sdesp.sdes = new RTCPSDES[firstbyte];
            sdesoff = 4;
            for (k = 0; k < sdesp.sdes.length; k++) {
              RTCPSDES chunk = new RTCPSDES();
              sdesp.sdes[k] = chunk;
              chunk.ssrc = in.readInt();
              sdesoff += 5;
              Vector items = new Vector();
              boolean gotcname = false;
              while ((n = in.readUnsignedByte()) != 0) {
                if (n < 1 || n > 8) {
                  this.stats.update(16, 1);
                  throw new BadFormatException();
                } 
                if (n == 1)
                  gotcname = true; 
                RTCPSDESItem item = new RTCPSDESItem();
                items.addElement(item);
                item.type = n;
                int sdeslen = in.readUnsignedByte();
                item.data = new byte[sdeslen];
                in.readFully(item.data);
                sdesoff += 2 + sdeslen;
              } 
              if (!gotcname) {
                this.stats.update(16, 1);
                throw new BadFormatException();
              } 
              chunk.items = new RTCPSDESItem[items.size()];
              items.copyInto((Object[])chunk.items);
              if ((sdesoff & 0x3) != 0) {
                in.skip((4 - (sdesoff & 0x3)));
                sdesoff = sdesoff + 3 & 0xFFFFFFFC;
              } 
            } 
            if (inlength != sdesoff) {
              this.stats.update(16, 1);
              throw new BadFormatException();
            } 
            break;
          case 203:
            byep = new RTCPBYEPacket(base);
            p = byep;
            byep.ssrc = new int[firstbyte];
            for (m = 0; m < byep.ssrc.length; m++)
              byep.ssrc[m] = in.readInt(); 
            if (inlength > 4 + 4 * firstbyte) {
              n = in.readUnsignedByte();
              byep.reason = new byte[n];
              n++;
            } else {
              n = 0;
              byep.reason = new byte[0];
            } 
            n = n + 3 & 0xFFFFFFFC;
            if (inlength != 4 + 4 * firstbyte + n) {
              this.stats.update(17, 1);
              throw new BadFormatException();
            } 
            in.readFully(byep.reason);
            in.skip((n - byep.reason.length));
            break;
          case 204:
            if (inlength < 12)
              throw new BadFormatException(); 
            appp = new RTCPAPPPacket(base);
            p = appp;
            appp.ssrc = in.readInt();
            appp.name = in.readInt();
            appp.subtype = firstbyte;
            appp.data = new byte[inlength - 12];
            in.readFully(appp.data);
            in.skip((inlength - 12 - appp.data.length));
            break;
          default:
            this.stats.update(14, 1);
            throw new BadFormatException();
        } 
        p.offset = offset;
        p.length = length;
        subpackets.addElement(p);
        in.skipBytes(padlen);
      } 
    } catch (EOFException e) {
      throw new BadFormatException("Unexpected end of RTCP packet");
    } catch (IOException e) {
      throw new IllegalArgumentException("Impossible Exception");
    } 
    base.packets = new RTCPPacket[subpackets.size()];
    subpackets.copyInto((Object[])base.packets);
    return base;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTCPRawReceiver.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */