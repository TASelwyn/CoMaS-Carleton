package com.sun.media.rtp;

import com.sun.media.rtp.util.Packet;
import com.sun.media.rtp.util.PacketConsumer;
import com.sun.media.rtp.util.PacketFilter;
import com.sun.media.rtp.util.RTPPacketSender;
import com.sun.media.rtp.util.UDPPacket;
import com.sun.media.rtp.util.UDPPacketSender;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Vector;
import javax.media.rtp.SessionAddress;

public class RTCPRawSender extends PacketFilter {
  private InetAddress destaddr;
  
  private int destport;
  
  public String filtername() {
    return "RTCP Raw Packet Sender";
  }
  
  public RTCPRawSender(int port, String address) throws UnknownHostException, IOException {
    this.destaddr = InetAddress.getByName(address);
    this.destport = port | 0x1;
    this.destAddressList = null;
  }
  
  public RTCPRawSender(int port, String address, UDPPacketSender sender) throws UnknownHostException, IOException {
    this(port, address);
    setConsumer((PacketConsumer)sender);
    this.destAddressList = null;
  }
  
  public RTCPRawSender(RTPPacketSender sender) {
    setConsumer((PacketConsumer)sender);
  }
  
  public void addDestAddr(InetAddress newaddr) {
    int i = 0;
    if (this.destAddressList == null) {
      this.destAddressList = new Vector();
      this.destAddressList.addElement(this.destaddr);
    } 
    for (i = 0; i < this.destAddressList.size(); i++) {
      InetAddress curraddr = this.destAddressList.elementAt(i);
      if (curraddr.equals(newaddr))
        break; 
    } 
    if (i == this.destAddressList.size())
      this.destAddressList.addElement(newaddr); 
  }
  
  public InetAddress getRemoteAddr() {
    return this.destaddr;
  }
  
  public Packet handlePacket(Packet p, SessionAddress sessionAddress) {
    assemble((RTCPCompoundPacket)p);
    PacketConsumer consumer = getConsumer();
    if (consumer instanceof RTPPacketSender)
      return p; 
    UDPPacket udpp = new UDPPacket();
    ((Packet)udpp).received = false;
    ((Packet)udpp).data = p.data;
    ((Packet)udpp).offset = p.offset;
    ((Packet)udpp).length = p.length;
    udpp.remoteAddress = sessionAddress.getControlAddress();
    udpp.remotePort = sessionAddress.getControlPort();
    return (Packet)udpp;
  }
  
  public Packet handlePacket(Packet p, int index) {
    assemble((RTCPCompoundPacket)p);
    UDPPacket udpp = new UDPPacket();
    ((Packet)udpp).received = false;
    ((Packet)udpp).data = p.data;
    ((Packet)udpp).offset = p.offset;
    ((Packet)udpp).length = p.length;
    udpp.remoteAddress = this.destAddressList.elementAt(index);
    udpp.remotePort = this.destport;
    return (Packet)udpp;
  }
  
  public Packet handlePacket(Packet p) {
    assemble((RTCPCompoundPacket)p);
    PacketConsumer consumer = getConsumer();
    if (consumer instanceof RTPPacketSender)
      return p; 
    UDPPacket udpp = new UDPPacket();
    ((Packet)udpp).received = false;
    ((Packet)udpp).data = p.data;
    ((Packet)udpp).offset = p.offset;
    ((Packet)udpp).length = p.length;
    udpp.remoteAddress = this.destaddr;
    udpp.remotePort = this.destport;
    return (Packet)udpp;
  }
  
  public void assemble(RTCPCompoundPacket p) {
    int len = p.calcLength();
    p.assemble(len, false);
  }
  
  public void setDestAddresses(Vector destAddresses) {
    this.destAddressList = destAddresses;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTCPRawSender.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */