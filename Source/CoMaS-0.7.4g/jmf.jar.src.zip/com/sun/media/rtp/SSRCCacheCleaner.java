/*     */ package com.sun.media.rtp;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import com.sun.media.rtp.util.RTPMediaThread;
/*     */ import com.sun.media.util.MediaThread;
/*     */ import com.sun.media.util.jdk12;
/*     */ import com.sun.media.util.jdk12CreateThreadRunnableAction;
/*     */ import com.sun.media.util.jdk12PriorityAction;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Enumeration;
/*     */ import javax.media.rtp.ReceiveStream;
/*     */ import javax.media.rtp.event.ByeEvent;
/*     */ import javax.media.rtp.event.InactiveReceiveStreamEvent;
/*     */ import javax.media.rtp.event.RTPEvent;
/*     */ import javax.media.rtp.event.TimeoutEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSRCCacheCleaner
/*     */   implements Runnable
/*     */ {
/*     */   private SSRCCache cache;
/*     */   private RTPMediaThread thread;
/*     */   private static final int DEATHTIME = 1800000;
/*     */   private static final int TIMEOUT_MULTIPLIER = 5;
/*     */   boolean timeToClean = false;
/*  31 */   private static JMFSecurity jmfSecurity = null;
/*     */   private static boolean securityPrivelege = false;
/*  33 */   private Method[] m = new Method[1];
/*  34 */   private Class[] cl = new Class[1];
/*  35 */   private Object[][] args = new Object[1][0];
/*     */   
/*     */   private boolean killed = false;
/*     */   
/*     */   private StreamSynch streamSynch;
/*     */   
/*     */   static {
/*     */     try {
/*  43 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  44 */       securityPrivelege = true;
/*  45 */     } catch (SecurityException e) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public SSRCCacheCleaner(SSRCCache cache, StreamSynch streamSynch) {
/*  50 */     this.cache = cache;
/*  51 */     this.streamSynch = streamSynch;
/*     */     
/*  53 */     if (jmfSecurity != null) {
/*  54 */       String permission = null;
/*     */       try {
/*  56 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  57 */           permission = "thread";
/*  58 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/*  59 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*     */           
/*  61 */           permission = "thread group";
/*  62 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/*  63 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*     */         }
/*  65 */         else if (jmfSecurity.getName().startsWith("internet")) {
/*  66 */           PolicyEngine.checkPermission(PermissionID.THREAD);
/*  67 */           PolicyEngine.assertPermission(PermissionID.THREAD);
/*     */         }
/*     */       
/*  70 */       } catch (Throwable e) {
/*     */ 
/*     */ 
/*     */         
/*  74 */         if (permission.endsWith("group")) {
/*  75 */           jmfSecurity.permissionFailureNotification(32);
/*     */         } else {
/*  77 */           jmfSecurity.permissionFailureNotification(16);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  82 */     if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*     */       try {
/*  84 */         Constructor conswithname = jdk12CreateThreadRunnableAction.conswithname;
/*     */         
/*  86 */         this.thread = (RTPMediaThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { conswithname.newInstance(new Object[] { RTPMediaThread.class, this, "SSRC Cache Cleaner" }) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  96 */         Constructor pcons = jdk12PriorityAction.cons;
/*  97 */         jdk12.doPrivM.invoke(jdk12.ac, new Object[] { pcons.newInstance(new Object[] { this.thread, new Integer(MediaThread.getControlPriority()) }) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 107 */       catch (Exception e) {}
/*     */     } else {
/*     */       
/* 110 */       this.thread = new RTPMediaThread(this, "SSRC Cache Cleaner");
/* 111 */       this.thread.useControlPriority();
/*     */     } 
/*     */     
/* 114 */     this.thread.setDaemon(true);
/* 115 */     this.thread.start();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void stop() {
/* 120 */     this.killed = true;
/* 121 */     notifyAll();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void run() {
/*     */     try {
/*     */       while (true) {
/* 135 */         if (this.timeToClean || this.killed) {
/*     */ 
/*     */ 
/*     */           
/* 139 */           if (this.killed) {
/*     */             return;
/*     */           }
/* 142 */           cleannow();
/* 143 */           this.timeToClean = false; continue;
/*     */         }  wait();
/*     */       } 
/*     */     } catch (Exception e) {
/* 147 */       e.printStackTrace();
/*     */       return;
/*     */     } 
/*     */   }
/*     */   public synchronized void setClean() {
/* 152 */     this.timeToClean = true;
/* 153 */     notifyAll();
/*     */   }
/*     */   
/*     */   public synchronized void cleannow() {
/* 157 */     long time = System.currentTimeMillis();
/*     */     
/* 159 */     if (this.cache.ourssrc == null) {
/*     */       return;
/*     */     }
/* 162 */     double reportInterval = this.cache.calcReportInterval(this.cache.ourssrc.sender, true);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 167 */     Enumeration enum = this.cache.cache.elements();
/* 168 */     while (enum.hasMoreElements()) {
/* 169 */       SSRCInfo info = enum.nextElement();
/* 170 */       if (info.ours) {
/*     */         continue;
/*     */       }
/* 173 */       if (info.byeReceived) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 180 */         if (time - info.byeTime < 1000L) {
/*     */           try {
/* 182 */             Thread.sleep(1000L - time + info.byeTime);
/* 183 */           } catch (InterruptedException e) {}
/* 184 */           time = System.currentTimeMillis();
/*     */         } 
/*     */         
/* 187 */         info.byeTime = 0L;
/* 188 */         info.byeReceived = false;
/* 189 */         this.cache.remove(info.ssrc);
/*     */         
/* 191 */         this.streamSynch.remove(info.ssrc);
/*     */         
/* 193 */         boolean byepart = false;
/* 194 */         RTPSourceInfo sourceInfo = info.sourceInfo;
/* 195 */         if (sourceInfo != null && sourceInfo.getStreamCount() == 0) {
/* 196 */           byepart = true;
/*     */         }
/* 198 */         ByeEvent evtbye = null;
/* 199 */         if (info instanceof RecvSSRCInfo) {
/* 200 */           evtbye = new ByeEvent(this.cache.sm, info.sourceInfo, (ReceiveStream)info, info.byereason, byepart);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 206 */         if (info instanceof PassiveSSRCInfo) {
/* 207 */           evtbye = new ByeEvent(this.cache.sm, info.sourceInfo, null, info.byereason, byepart);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 213 */         this.cache.eventhandler.postEvent((RTPEvent)evtbye);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 223 */       if (info.lastHeardFrom + reportInterval <= time) {
/*     */ 
/*     */         
/* 226 */         InactiveReceiveStreamEvent event = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 232 */         if (!info.inactivesent) {
/* 233 */           boolean laststream = false;
/* 234 */           RTPSourceInfo si = info.sourceInfo;
/* 235 */           if (si != null && si.getStreamCount() == 1) {
/* 236 */             laststream = true;
/*     */           }
/* 238 */           if (info instanceof ReceiveStream) {
/* 239 */             event = new InactiveReceiveStreamEvent(this.cache.sm, info.sourceInfo, (ReceiveStream)info, laststream);
/*     */ 
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */ 
/*     */             
/* 247 */             reportInterval *= 5.0D;
/* 248 */             if (info.lastHeardFrom + reportInterval <= time)
/*     */             {
/* 250 */               event = new InactiveReceiveStreamEvent(this.cache.sm, info.sourceInfo, null, laststream);
/*     */             }
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 258 */           if (event != null) {
/* 259 */             this.cache.eventhandler.postEvent((RTPEvent)event);
/* 260 */             info.quiet = true;
/* 261 */             info.inactivesent = true;
/* 262 */             info.setAlive(false);
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 274 */         if (info.lastHeardFrom + 1800000L <= time) {
/*     */           
/* 276 */           TimeoutEvent evt = null;
/*     */           
/* 278 */           this.cache.remove(info.ssrc);
/* 279 */           boolean byepart = false;
/* 280 */           RTPSourceInfo sourceInfo = info.sourceInfo;
/*     */           
/* 282 */           if (sourceInfo != null && sourceInfo.getStreamCount() == 0)
/*     */           {
/* 284 */             byepart = true;
/*     */           }
/* 286 */           if (info instanceof ReceiveStream) {
/* 287 */             evt = new TimeoutEvent(this.cache.sm, info.sourceInfo, (ReceiveStream)info, byepart);
/*     */           
/*     */           }
/*     */           else {
/*     */             
/* 292 */             evt = new TimeoutEvent(this.cache.sm, info.sourceInfo, null, byepart);
/*     */           } 
/*     */ 
/*     */           
/* 296 */           this.cache.eventhandler.postEvent((RTPEvent)evt);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtp\SSRCCacheCleaner.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */