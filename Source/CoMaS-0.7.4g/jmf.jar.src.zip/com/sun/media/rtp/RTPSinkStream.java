package com.sun.media.rtp;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import com.sun.media.JMFSecurity;
import com.sun.media.JMFSecurityManager;
import com.sun.media.rtp.util.RTPMediaThread;
import java.lang.reflect.Method;
import javax.media.Buffer;
import javax.media.format.AudioFormat;
import javax.media.format.VideoFormat;
import javax.media.protocol.BufferTransferHandler;
import javax.media.protocol.PushBufferStream;
import javax.media.rtp.event.LocalPayloadChangeEvent;
import javax.media.rtp.event.RTPEvent;

public class RTPSinkStream implements BufferTransferHandler {
  private RTPMediaThread thread = null;
  
  Buffer current = new Buffer();
  
  boolean started = false;
  
  Object startReq = new Integer(0);
  
  RTPTransmitter transmitter = null;
  
  RTPRawSender sender = null;
  
  SendSSRCInfo info = null;
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] m = new Method[1];
  
  private Class[] cl = new Class[1];
  
  private Object[][] args = new Object[1][0];
  
  static AudioFormat mpegAudio = new AudioFormat("mpegaudio/rtp");
  
  static VideoFormat mpegVideo = new VideoFormat("mpeg/rtp");
  
  static {
    try {
      jmfSecurity = JMFSecurityManager.getJMFSecurity();
      securityPrivelege = true;
    } catch (SecurityException e) {}
  }
  
  public void startStream() {
    if (jmfSecurity != null) {
      String permission = null;
      try {
        if (jmfSecurity.getName().startsWith("jmf-security")) {
          permission = "thread";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
          this.m[0].invoke(this.cl[0], this.args[0]);
          permission = "thread group";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
          this.m[0].invoke(this.cl[0], this.args[0]);
        } else if (jmfSecurity.getName().startsWith("internet")) {
          PolicyEngine.checkPermission(PermissionID.THREAD);
          PolicyEngine.assertPermission(PermissionID.THREAD);
        } 
      } catch (Throwable e) {
        if (permission.endsWith("group")) {
          jmfSecurity.permissionFailureNotification(32);
        } else {
          jmfSecurity.permissionFailureNotification(16);
        } 
      } 
    } 
  }
  
  protected void setSSRCInfo(SendSSRCInfo info) {
    this.info = info;
  }
  
  protected void setTransmitter(RTPTransmitter t) {
    this.transmitter = t;
    if (this.transmitter != null)
      this.sender = this.transmitter.getSender(); 
  }
  
  public void transferData(PushBufferStream stream) {
    try {
      synchronized (this.startReq) {
        while (!this.started) {
          this.startPT = -1L;
          this.startReq.wait();
        } 
      } 
      stream.read(this.current);
      if (!this.current.getFormat().matches(this.info.myformat)) {
        int payload = this.transmitter.cache.sm.formatinfo.getPayload(this.current.getFormat());
        if (payload == -1)
          return; 
        LocalPayloadChangeEvent evt = new LocalPayloadChangeEvent(this.transmitter.cache.sm, this.info, this.info.payloadType, payload);
        this.transmitter.cache.eventhandler.postEvent((RTPEvent)evt);
        this.info.payloadType = payload;
        this.info.myformat = this.current.getFormat();
      } 
      if (this.info.myformat instanceof VideoFormat) {
        transmitVideo();
      } else if (this.info.myformat instanceof AudioFormat) {
        transmitAudio();
      } 
    } catch (Exception e) {}
  }
  
  public void start() {
    if (this.started)
      return; 
    this.started = true;
    synchronized (this.startReq) {
      this.startReq.notifyAll();
    } 
  }
  
  public void stop() {
    this.started = false;
    this.startPT = -1L;
    synchronized (this.startReq) {
      this.startReq.notifyAll();
    } 
  }
  
  protected void close() {
    stop();
  }
  
  long startTime = 0L;
  
  long startPT = -1L;
  
  int rate;
  
  boolean mpegBFrame = false;
  
  boolean mpegPFrame = false;
  
  boolean bufSizeSet = false;
  
  private void transmitVideo() {
    if (this.current.isEOM() || this.current.isDiscard()) {
      this.startPT = -1L;
      this.mpegBFrame = false;
      this.mpegPFrame = false;
      return;
    } 
    if (this.startPT == -1L) {
      this.startTime = System.currentTimeMillis();
      this.startPT = this.current.getTimeStamp() / 1000000L;
    } 
    if (this.current.getTimeStamp() > 0L && (this.current.getFlags() & 0x60) == 0 && (this.current.getFlags() & 0x800) != 0)
      if (mpegVideo.matches(this.info.myformat)) {
        byte[] payload = (byte[])this.current.getData();
        int offset = this.current.getOffset();
        int ptype = payload[offset + 2] & 0x7;
        if (ptype > 2) {
          this.mpegBFrame = true;
        } else if (ptype == 2) {
          this.mpegPFrame = true;
        } 
        if (ptype > 2 || (ptype == 2 && !this.mpegBFrame) || (ptype == 1 && (this.mpegBFrame | this.mpegPFrame) == 0))
          waitForPT(this.startTime, this.startPT, this.current.getTimeStamp() / 1000000L); 
      } else {
        waitForPT(this.startTime, this.startPT, this.current.getTimeStamp() / 1000000L);
      }  
    this.transmitter.TransmitPacket(this.current, this.info);
  }
  
  long audioPT = 0L;
  
  private void transmitAudio() {
    if (this.current.isEOM() || this.current.isDiscard()) {
      this.startPT = -1L;
      return;
    } 
    if (this.startPT == -1L) {
      this.startTime = System.currentTimeMillis();
      this.startPT = (this.current.getTimeStamp() > 0L) ? (this.current.getTimeStamp() / 1000000L) : 0L;
      this.audioPT = this.startPT;
    } 
    if ((this.current.getFlags() & 0x60) == 0) {
      if (mpegAudio.matches(this.current.getFormat())) {
        this.audioPT = this.current.getTimeStamp() / 1000000L;
      } else {
        this.audioPT += ((AudioFormat)this.info.myformat).computeDuration(this.current.getLength()) / 1000000L;
      } 
      waitForPT(this.startTime, this.startPT, this.audioPT);
    } 
    this.transmitter.TransmitPacket(this.current, this.info);
  }
  
  static int THRESHOLD = 80;
  
  static int LEEWAY = 5;
  
  private void waitForPT(long start, long startPT, long pt) {
    long delay = pt - startPT - System.currentTimeMillis() - start;
    while (delay > LEEWAY) {
      if (delay > THRESHOLD)
        delay = THRESHOLD; 
      try {
        Thread.currentThread();
        Thread.sleep(delay);
      } catch (Exception e) {
        break;
      } 
      delay = pt - startPT - System.currentTimeMillis() - start;
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTPSinkStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */