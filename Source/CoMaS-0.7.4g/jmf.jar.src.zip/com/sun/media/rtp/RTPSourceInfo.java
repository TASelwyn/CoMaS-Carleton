package com.sun.media.rtp;

import java.util.Vector;
import javax.media.rtp.Participant;
import javax.media.rtp.RTPStream;
import javax.media.rtp.rtcp.SourceDescription;

public abstract class RTPSourceInfo implements Participant {
  RTPSourceInfoCache sic;
  
  private SSRCInfo[] ssrc;
  
  private SourceDescription cname;
  
  RTPSourceInfo(String cname, RTPSourceInfoCache sic) {
    this.cname = new SourceDescription(1, cname, 0, false);
    this.sic = sic;
    this.ssrc = new SSRCInfo[0];
  }
  
  SourceDescription getCNAMESDES() {
    return this.cname;
  }
  
  public String getCNAME() {
    return this.cname.getDescription();
  }
  
  public Vector getStreams() {
    Vector recvstreams = new Vector();
    for (int i = 0; i < this.ssrc.length; i++) {
      if (this.ssrc[i].isActive())
        recvstreams.addElement(this.ssrc[i]); 
    } 
    recvstreams.trimToSize();
    return recvstreams;
  }
  
  RTPStream getSSRCStream(long filterssrc) {
    for (int i = 0; i < this.ssrc.length; i++) {
      if (this.ssrc[i] instanceof RTPStream && (this.ssrc[i]).ssrc == (int)filterssrc)
        return (RTPStream)this.ssrc[i]; 
    } 
    return null;
  }
  
  public Vector getReports() {
    Vector reportlist = new Vector();
    for (int i = 0; i < this.ssrc.length; i++)
      reportlist.addElement(this.ssrc[i]); 
    reportlist.trimToSize();
    return reportlist;
  }
  
  public Vector getSourceDescription() {
    Vector sdeslist = null;
    if (this.ssrc.length == 0) {
      sdeslist = new Vector(0);
      return sdeslist;
    } 
    sdeslist = this.ssrc[0].getSourceDescription();
    return sdeslist;
  }
  
  synchronized void addSSRC(SSRCInfo ssrcinfo) {
    for (int i = 0; i < this.ssrc.length; i++) {
      if (this.ssrc[i] == ssrcinfo)
        return; 
    } 
    System.arraycopy(this.ssrc, 0, this.ssrc = new SSRCInfo[this.ssrc.length + 1], 0, this.ssrc.length - 1);
    this.ssrc[this.ssrc.length - 1] = ssrcinfo;
  }
  
  synchronized void removeSSRC(SSRCInfo ssrcinfo) {
    if (ssrcinfo.dsource != null)
      this.sic.ssrccache.sm.removeDataSource(ssrcinfo.dsource); 
    for (int i = 0; i < this.ssrc.length; i++) {
      if (this.ssrc[i] == ssrcinfo) {
        this.ssrc[i] = this.ssrc[this.ssrc.length - 1];
        System.arraycopy(this.ssrc, 0, this.ssrc = new SSRCInfo[this.ssrc.length - 1], 0, this.ssrc.length);
        break;
      } 
    } 
    if (this.ssrc.length == 0)
      this.sic.remove(this.cname.getDescription()); 
  }
  
  int getStreamCount() {
    return this.ssrc.length;
  }
}
