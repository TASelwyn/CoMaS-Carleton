/*     */ package com.sun.media.rtp;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import javax.media.rtp.Participant;
/*     */ import javax.media.rtp.RTPStream;
/*     */ import javax.media.rtp.rtcp.SourceDescription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RTPSourceInfo
/*     */   implements Participant
/*     */ {
/*     */   RTPSourceInfoCache sic;
/*     */   private SSRCInfo[] ssrc;
/*     */   private SourceDescription cname;
/*     */   
/*     */   RTPSourceInfo(String cname, RTPSourceInfoCache sic) {
/*  33 */     this.cname = new SourceDescription(1, cname, 0, false);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  38 */     this.sic = sic;
/*  39 */     this.ssrc = new SSRCInfo[0];
/*     */   }
/*     */   
/*     */   SourceDescription getCNAMESDES() {
/*  43 */     return this.cname;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCNAME() {
/*  49 */     return this.cname.getDescription();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getStreams() {
/*  55 */     Vector recvstreams = new Vector();
/*  56 */     for (int i = 0; i < this.ssrc.length; i++) {
/*  57 */       if (this.ssrc[i].isActive()) {
/*  58 */         recvstreams.addElement(this.ssrc[i]);
/*     */       }
/*     */     } 
/*  61 */     recvstreams.trimToSize();
/*  62 */     return recvstreams;
/*     */   }
/*     */   
/*     */   RTPStream getSSRCStream(long filterssrc) {
/*  66 */     for (int i = 0; i < this.ssrc.length; i++) {
/*  67 */       if (this.ssrc[i] instanceof RTPStream && (this.ssrc[i]).ssrc == (int)filterssrc)
/*     */       {
/*     */         
/*  70 */         return (RTPStream)this.ssrc[i]; } 
/*     */     } 
/*  72 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getReports() {
/*  82 */     Vector reportlist = new Vector();
/*  83 */     for (int i = 0; i < this.ssrc.length; i++)
/*  84 */       reportlist.addElement(this.ssrc[i]); 
/*  85 */     reportlist.trimToSize();
/*  86 */     return reportlist;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getSourceDescription() {
/*  96 */     Vector sdeslist = null;
/*  97 */     if (this.ssrc.length == 0) {
/*  98 */       sdeslist = new Vector(0);
/*  99 */       return sdeslist;
/*     */     } 
/* 101 */     sdeslist = this.ssrc[0].getSourceDescription();
/* 102 */     return sdeslist;
/*     */   }
/*     */   
/*     */   synchronized void addSSRC(SSRCInfo ssrcinfo) {
/* 106 */     for (int i = 0; i < this.ssrc.length; i++) {
/* 107 */       if (this.ssrc[i] == ssrcinfo)
/*     */         return; 
/*     */     } 
/* 110 */     System.arraycopy(this.ssrc, 0, this.ssrc = new SSRCInfo[this.ssrc.length + 1], 0, this.ssrc.length - 1);
/*     */     
/* 112 */     this.ssrc[this.ssrc.length - 1] = ssrcinfo;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void removeSSRC(SSRCInfo ssrcinfo) {
/* 118 */     if (ssrcinfo.dsource != null)
/* 119 */       this.sic.ssrccache.sm.removeDataSource(ssrcinfo.dsource); 
/* 120 */     for (int i = 0; i < this.ssrc.length; i++) {
/* 121 */       if (this.ssrc[i] == ssrcinfo) {
/* 122 */         this.ssrc[i] = this.ssrc[this.ssrc.length - 1];
/* 123 */         System.arraycopy(this.ssrc, 0, this.ssrc = new SSRCInfo[this.ssrc.length - 1], 0, this.ssrc.length);
/*     */ 
/*     */ 
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 133 */     if (this.ssrc.length == 0) {
/* 134 */       this.sic.remove(this.cname.getDescription());
/*     */     }
/*     */   }
/*     */   
/*     */   int getStreamCount() {
/* 139 */     return this.ssrc.length;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\rtp\RTPSourceInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */