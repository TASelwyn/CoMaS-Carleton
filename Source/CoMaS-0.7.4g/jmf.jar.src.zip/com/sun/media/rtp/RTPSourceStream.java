package com.sun.media.rtp;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import com.sun.media.JMFSecurity;
import com.sun.media.JMFSecurityManager;
import com.sun.media.Log;
import com.sun.media.protocol.BasicSourceStream;
import com.sun.media.protocol.BufferListener;
import com.sun.media.protocol.rtp.DataSource;
import com.sun.media.rtp.util.RTPMediaThread;
import com.sun.media.util.MediaThread;
import com.sun.media.util.jdk12;
import com.sun.media.util.jdk12CreateThreadRunnableAction;
import com.sun.media.util.jdk12PriorityAction;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.control.BufferControl;
import javax.media.format.AudioFormat;
import javax.media.format.VideoFormat;
import javax.media.protocol.BufferTransferHandler;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.DataSource;
import javax.media.protocol.PushBufferStream;

public class RTPSourceStream extends BasicSourceStream implements PushBufferStream, Runnable {
  private DataSource dsource;
  
  private Format format = null;
  
  BufferTransferHandler handler = null;
  
  boolean started = false;
  
  boolean killed = false;
  
  boolean replenish = true;
  
  PktQue pktQ;
  
  Object startReq = new Object();
  
  private RTPMediaThread thread = null;
  
  private boolean hasRead = false;
  
  private int DEFAULT_AUDIO_RATE = 8000;
  
  private int DEFAULT_VIDEO_RATE = 15;
  
  private BufferControlImpl bc = null;
  
  private long lastSeqRecv = -1L;
  
  private long lastSeqSent = -1L;
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] m = new Method[1];
  
  private Class[] cl = new Class[1];
  
  private Object[][] args = new Object[1][0];
  
  private static final int NOT_SPECIFIED = -1;
  
  private BufferListener listener = null;
  
  private int threshold = 0;
  
  private boolean prebuffering = false;
  
  private boolean prebufferNotice = false;
  
  private boolean bufferWhenStopped = true;
  
  static AudioFormat mpegAudio = new AudioFormat("mpegaudio/rtp");
  
  static VideoFormat mpegVideo = new VideoFormat("mpeg/rtp");
  
  static {
    try {
      jmfSecurity = JMFSecurityManager.getJMFSecurity();
      securityPrivelege = true;
    } catch (SecurityException e) {}
  }
  
  public RTPSourceStream(DataSource dsource) {
    this.dsource = dsource;
    dsource.setSourceStream(this);
    this.pktQ = new PktQue(this, 4);
    createThread();
  }
  
  public void setBufferControl(BufferControl b) {
    this.bc = (BufferControlImpl)b;
    updateBuffer(this.bc.getBufferLength());
    updateThreshold(this.bc.getMinimumThreshold());
  }
  
  public long updateBuffer(long len) {
    return len;
  }
  
  public long updateThreshold(long threshold) {
    return threshold;
  }
  
  public void setBufferListener(BufferListener listener) {
    this.listener = listener;
  }
  
  public void add(Buffer filled, boolean wrapped, RTPRawReceiver rtpr) {
    if (!this.started && !this.bufferWhenStopped)
      return; 
    if (this.lastSeqRecv - filled.getSequenceNumber() > 256L)
      this.pktQ.reset(); 
    this.lastSeqRecv = filled.getSequenceNumber();
    boolean overflown = false;
    synchronized (this.pktQ) {
      this.pktQ.monitorQueueSize(filled, rtpr);
      if (this.pktQ.noMoreFree()) {
        long head = this.pktQ.getFirstSeq();
        if (head != -1L && filled.getSequenceNumber() < head)
          return; 
        this.pktQ.dropPkt();
      } 
    } 
    if (this.pktQ.totalFree() <= 1)
      overflown = true; 
    Buffer buf = this.pktQ.getFree();
    byte[] inData = (byte[])filled.getData();
    byte[] outData = (byte[])buf.getData();
    if (outData == null || outData.length < inData.length)
      outData = new byte[inData.length]; 
    System.arraycopy(inData, filled.getOffset(), outData, filled.getOffset(), filled.getLength());
    buf.copy(filled);
    buf.setData(outData);
    if (overflown) {
      buf.setFlags(buf.getFlags() | 0x2000 | 0x20);
    } else {
      buf.setFlags(buf.getFlags() | 0x20);
    } 
    this.pktQ.addPkt(buf);
    synchronized (this.pktQ) {
      if (this.started && this.prebufferNotice && this.listener != null && this.pktQ.totalPkts() >= this.threshold) {
        this.listener.minThresholdReached((DataSource)this.dsource);
        this.prebufferNotice = false;
        this.prebuffering = false;
        synchronized (this.startReq) {
          this.startReq.notifyAll();
        } 
      } 
      if (this.replenish && this.format instanceof AudioFormat) {
        if (this.pktQ.totalPkts() >= this.pktQ.size / 2) {
          this.replenish = false;
          this.pktQ.notifyAll();
        } 
      } else {
        this.pktQ.notifyAll();
      } 
    } 
  }
  
  public void read(Buffer buf) {
    if (this.pktQ.totalPkts() == 0) {
      buf.setDiscard(true);
      return;
    } 
    Buffer pkt = this.pktQ.getPkt();
    this.lastSeqSent = pkt.getSequenceNumber();
    Object data = buf.getData();
    Object hdr = buf.getHeader();
    buf.copy(pkt);
    pkt.setData(data);
    pkt.setHeader(hdr);
    this.pktQ.returnFree(pkt);
    synchronized (this.pktQ) {
      this.hasRead = true;
      if (this.format instanceof AudioFormat) {
        if (this.pktQ.totalPkts() > 0) {
          this.pktQ.notifyAll();
        } else {
          this.replenish = true;
        } 
      } else {
        this.pktQ.notifyAll();
      } 
    } 
  }
  
  public void reset() {
    this.pktQ.reset();
    this.lastSeqSent = -1L;
  }
  
  public Format getFormat() {
    return this.format;
  }
  
  protected void setFormat(Format format) {
    this.format = format;
  }
  
  public void setTransferHandler(BufferTransferHandler transferHandler) {
    this.handler = transferHandler;
  }
  
  void setContentDescriptor(String contentType) {
    this.contentDescriptor = new ContentDescriptor(contentType);
  }
  
  public void setBufferWhenStopped(boolean flag) {
    this.bufferWhenStopped = flag;
  }
  
  public void prebuffer() {
    synchronized (this.pktQ) {
      this.prebuffering = true;
      this.prebufferNotice = true;
    } 
  }
  
  public void start() {
    synchronized (this.startReq) {
      this.started = true;
      this.startReq.notifyAll();
    } 
  }
  
  public void stop() {
    synchronized (this.startReq) {
      this.started = false;
      this.prebuffering = false;
      if (!this.bufferWhenStopped)
        reset(); 
    } 
  }
  
  public void connect() {
    this.killed = false;
    createThread();
  }
  
  public void close() {
    if (this.killed)
      return; 
    stop();
    this.killed = true;
    synchronized (this.startReq) {
      this.startReq.notifyAll();
    } 
    synchronized (this.pktQ) {
      this.pktQ.notifyAll();
    } 
    this.thread = null;
    if (this.bc != null)
      this.bc.removeSourceStream(this); 
  }
  
  public void run() {
    while (true) {
      try {
        synchronized (this.startReq) {
          while ((!this.started || this.prebuffering) && !this.killed)
            this.startReq.wait(); 
        } 
        synchronized (this.pktQ) {
          do {
            if (!this.hasRead && !this.killed)
              this.pktQ.wait(); 
            this.hasRead = false;
          } while (this.pktQ.totalPkts() <= 0 && !this.killed);
        } 
        if (this.killed)
          break; 
        if (this.handler != null)
          this.handler.transferData(this); 
      } catch (InterruptedException e) {
        Log.error("Thread " + e.getMessage());
      } 
    } 
  }
  
  private void createThread() {
    if (this.thread != null)
      return; 
    if (jmfSecurity != null) {
      String permission = null;
      try {
        if (jmfSecurity.getName().startsWith("jmf-security")) {
          permission = "thread";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
          this.m[0].invoke(this.cl[0], this.args[0]);
          permission = "thread group";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
          this.m[0].invoke(this.cl[0], this.args[0]);
        } else if (jmfSecurity.getName().startsWith("internet")) {
          PolicyEngine.checkPermission(PermissionID.THREAD);
          PolicyEngine.assertPermission(PermissionID.THREAD);
        } 
      } catch (Throwable e) {
        if (permission.endsWith("group")) {
          jmfSecurity.permissionFailureNotification(32);
        } else {
          jmfSecurity.permissionFailureNotification(16);
        } 
      } 
    } 
    if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
      try {
        Constructor cons = jdk12CreateThreadRunnableAction.cons;
        this.thread = (RTPMediaThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { RTPMediaThread.class, this }) });
        this.thread.setName("RTPStream");
        cons = jdk12PriorityAction.cons;
        jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { this.thread, new Integer(MediaThread.getControlPriority()) }) });
      } catch (Exception e) {}
    } else {
      this.thread = new RTPMediaThread(this, "RTPStream");
      this.thread.useControlPriority();
    } 
    this.thread.start();
  }
  
  class PktQue {
    int FUDGE;
    
    int DEFAULT_AUD_PKT_SIZE;
    
    int DEFAULT_MILLISECS_PER_PKT;
    
    int DEFAULT_PKTS_TO_BUFFER;
    
    int MIN_BUF_CHECK;
    
    int BUF_CHECK_INTERVAL;
    
    int pktsEst;
    
    int framesEst;
    
    int fps;
    
    int pktsPerFrame;
    
    int sizePerPkt;
    
    int maxPktsToBuffer;
    
    int sockBufSize;
    
    int tooMuchBufferingCount;
    
    long lastPktSeq;
    
    long lastCheckTime;
    
    Buffer[] fill;
    
    Buffer[] free;
    
    int headFill;
    
    int tailFill;
    
    int headFree;
    
    int tailFree;
    
    protected int size;
    
    private final RTPSourceStream this$0;
    
    public PktQue(RTPSourceStream this$0, int n) {
      this.this$0 = this$0;
      this.FUDGE = 5;
      this.DEFAULT_AUD_PKT_SIZE = 256;
      this.DEFAULT_MILLISECS_PER_PKT = 30;
      this.DEFAULT_PKTS_TO_BUFFER = 30;
      this.MIN_BUF_CHECK = 10;
      this.BUF_CHECK_INTERVAL = 7;
      this.framesEst = 0;
      this.fps = 15;
      this.pktsPerFrame = this.this$0.DEFAULT_VIDEO_RATE;
      this.sizePerPkt = this.DEFAULT_AUD_PKT_SIZE;
      this.maxPktsToBuffer = 0;
      this.sockBufSize = 0;
      this.tooMuchBufferingCount = 0;
      this.lastPktSeq = 0L;
      this.lastCheckTime = 0L;
      allocBuffers(n);
    }
    
    public synchronized void reset() {
      while (moreFilled())
        returnFree(get()); 
      this.tooMuchBufferingCount = 0;
      notifyAll();
    }
    
    public int totalPkts() {
      return (this.tailFill >= this.headFill) ? (this.tailFill - this.headFill) : (this.size - this.headFill - this.tailFill);
    }
    
    public int totalFree() {
      return (this.tailFree >= this.headFree) ? (this.tailFree - this.headFree) : (this.size - this.headFree - this.tailFree);
    }
    
    public synchronized void addPkt(Buffer buf) {
      long head = -1L, tail = -1L;
      long seq = buf.getSequenceNumber();
      if (moreFilled()) {
        head = this.fill[this.headFill].getSequenceNumber();
        int i = this.tailFill - 1;
        if (i < 0)
          i = this.size - 1; 
        tail = this.fill[i].getSequenceNumber();
      } 
      if (head == -1L && tail == -1L) {
        append(buf);
      } else if (seq < head) {
        prepend(buf);
      } else if (head < seq && seq < tail) {
        insert(buf);
      } else if (seq > tail) {
        append(buf);
      } else {
        returnFree(buf);
      } 
    }
    
    public void monitorQueueSize(Buffer buf, RTPRawReceiver rtpr) {
      this.sizePerPkt = (this.sizePerPkt + buf.getLength()) / 2;
      if (this.this$0.format instanceof VideoFormat) {
        int i;
        if (this.lastPktSeq + 1L == buf.getSequenceNumber()) {
          this.pktsEst++;
        } else {
          this.pktsEst = 1;
        } 
        this.lastPktSeq = buf.getSequenceNumber();
        if (RTPSourceStream.mpegVideo.matches(this.this$0.format)) {
          byte[] payload = (byte[])buf.getData();
          int offset = buf.getOffset();
          int ptype = payload[offset + 2] & 0x7;
          if (ptype < 3)
            if ((buf.getFlags() & 0x800) != 0) {
              this.pktsPerFrame = (this.pktsPerFrame + this.pktsEst) / 2;
              this.pktsEst = 0;
            }  
          this.fps = 30;
        } else if ((buf.getFlags() & 0x800) != 0) {
          this.pktsPerFrame = (this.pktsPerFrame + this.pktsEst) / 2;
          this.pktsEst = 0;
          this.framesEst++;
          long now = System.currentTimeMillis();
          if (now - this.lastCheckTime >= 1000L) {
            this.lastCheckTime = now;
            this.fps = (this.fps + this.framesEst) / 2;
            this.framesEst = 0;
            if (this.fps > 30)
              this.fps = 30; 
          } 
        } 
        if (this.this$0.bc != null) {
          i = (int)(this.this$0.bc.getBufferLength() * this.fps / 1000L);
          if (i <= 0)
            i = 1; 
          i = this.pktsPerFrame * i;
          this.this$0.threshold = (int)(this.this$0.bc.getMinimumThreshold() * this.fps / 1000L * this.pktsPerFrame);
          if (this.this$0.threshold > i / 2);
          this.this$0.threshold = i / 2;
        } else {
          i = this.DEFAULT_PKTS_TO_BUFFER;
        } 
        if (this.maxPktsToBuffer > 0) {
          this.maxPktsToBuffer = (this.maxPktsToBuffer + i) / 2;
        } else {
          this.maxPktsToBuffer = i;
        } 
        int tot = totalPkts();
        if (this.size > this.MIN_BUF_CHECK && tot < this.size / 4) {
          if (!this.this$0.prebuffering && this.tooMuchBufferingCount++ > this.pktsPerFrame * this.fps * this.BUF_CHECK_INTERVAL) {
            cutByHalf();
            this.tooMuchBufferingCount = 0;
          } 
        } else if (tot >= this.size / 2 && this.size < this.maxPktsToBuffer) {
          i = this.size + this.size / 2;
          if (i > this.maxPktsToBuffer)
            i = this.maxPktsToBuffer; 
          grow(i + this.FUDGE);
          Log.comment("RTP video buffer size: " + this.size + " pkts, " + (i * this.sizePerPkt) + " bytes.\n");
          this.tooMuchBufferingCount = 0;
        } else {
          this.tooMuchBufferingCount = 0;
        } 
        int sizeToBuffer = i * this.sizePerPkt / 2;
        if (rtpr != null && sizeToBuffer > this.sockBufSize) {
          rtpr.setRecvBufSize(sizeToBuffer);
          if (rtpr.getRecvBufSize() < sizeToBuffer) {
            this.sockBufSize = Integer.MAX_VALUE;
          } else {
            this.sockBufSize = sizeToBuffer;
          } 
          Log.comment("RTP video socket buffer size: " + rtpr.getRecvBufSize() + " bytes.\n");
        } 
      } else if (this.this$0.format instanceof AudioFormat) {
        if (this.sizePerPkt <= 0)
          this.sizePerPkt = this.DEFAULT_AUD_PKT_SIZE; 
        if (this.this$0.bc != null) {
          int i;
          if (RTPSourceStream.mpegAudio.matches(this.this$0.format)) {
            i = this.sizePerPkt / 4;
          } else {
            i = this.DEFAULT_MILLISECS_PER_PKT;
          } 
          int pktsToBuffer = (int)(this.this$0.bc.getBufferLength() / i);
          this.this$0.threshold = (int)(this.this$0.bc.getMinimumThreshold() / i);
          if (this.this$0.threshold > pktsToBuffer / 2);
          this.this$0.threshold = pktsToBuffer / 2;
          if (pktsToBuffer > this.size) {
            grow(pktsToBuffer);
            Log.comment("RTP audio buffer size: " + this.size + " pkts, " + (pktsToBuffer * this.sizePerPkt) + " bytes.\n");
          } 
          int sizeToBuffer = pktsToBuffer * this.sizePerPkt / 2;
          if (rtpr != null && sizeToBuffer > this.sockBufSize) {
            rtpr.setRecvBufSize(sizeToBuffer);
            if (rtpr.getRecvBufSize() < sizeToBuffer) {
              this.sockBufSize = Integer.MAX_VALUE;
            } else {
              this.sockBufSize = sizeToBuffer;
            } 
            Log.comment("RTP audio socket buffer size: " + rtpr.getRecvBufSize() + " bytes.\n");
          } 
        } 
      } 
    }
    
    public synchronized Buffer getPkt() {
      while (!moreFilled()) {
        try {
          wait();
        } catch (Exception e) {}
      } 
      Buffer b = get();
      return b;
    }
    
    public void dropPkt() {
      while (!moreFilled()) {
        try {
          wait();
        } catch (Exception e) {}
      } 
      if (this.this$0.format instanceof AudioFormat) {
        dropFirstPkt();
      } else if (RTPSourceStream.mpegVideo.matches(this.this$0.format)) {
        dropMpegPkt();
      } else {
        dropFirstPkt();
      } 
    }
    
    public synchronized void dropFirstPkt() {
      Buffer buf = get();
      this.this$0.lastSeqSent = buf.getSequenceNumber();
      returnFree(buf);
    }
    
    public synchronized void dropMpegPkt() {
      int i = this.headFill;
      int firstP = -1, firstB = -1;
      while (i != this.tailFill) {
        Buffer buf = this.fill[i];
        byte[] payload = (byte[])buf.getData();
        int offset = buf.getOffset();
        int ptype = payload[offset + 2] & 0x7;
        if (ptype > 2) {
          firstB = i;
          break;
        } 
        if (ptype == 2 && firstP == -1)
          firstP = i; 
        i++;
        if (i >= this.size)
          i = 0; 
      } 
      if (firstB == -1)
        i = (firstP == -1) ? this.headFill : firstP; 
      Buffer buffer = this.fill[i];
      if (i == 0)
        this.this$0.lastSeqSent = buffer.getSequenceNumber(); 
      removeAt(i);
    }
    
    public synchronized long getFirstSeq() {
      if (!moreFilled())
        return -1L; 
      return this.fill[this.headFill].getSequenceNumber();
    }
    
    private void allocBuffers(int n) {
      this.fill = new Buffer[n];
      this.free = new Buffer[n];
      for (int i = 0; i < n - 1; i++)
        this.free[i] = new Buffer(); 
      this.size = n;
      this.headFill = this.tailFill = 0;
      this.headFree = 0;
      this.tailFree = this.size - 1;
    }
    
    private synchronized void grow(int newSize) {
      Buffer[] newFill = new Buffer[newSize];
      Buffer[] newFree = new Buffer[newSize];
      int totPkts = totalPkts();
      int totFree = totalFree();
      int i = this.headFill;
      int j = 0;
      while (i != this.tailFill) {
        newFill[j] = this.fill[i];
        i++;
        if (i >= this.size)
          i = 0; 
        j++;
      } 
      this.headFill = 0;
      this.tailFill = totPkts;
      this.fill = newFill;
      i = this.headFree;
      j = 0;
      while (i != this.tailFree) {
        newFree[j] = this.free[i];
        i++;
        if (i >= this.size)
          i = 0; 
        j++;
      } 
      this.headFree = 0;
      this.tailFree = totFree;
      i = newSize - this.size;
      while (i > 0) {
        newFree[this.tailFree] = new Buffer();
        this.tailFree++;
        i--;
      } 
      this.free = newFree;
      this.size = newSize;
    }
    
    private synchronized void cutByHalf() {
      int newSize = this.size / 2;
      if (newSize <= 0)
        return; 
      Buffer[] newFill = new Buffer[this.size / 2];
      Buffer[] newFree = new Buffer[this.size / 2];
      int tot = totalPkts();
      int i;
      for (i = 0; i < newSize && i < tot; i++)
        newFill[i] = get(); 
      tot = newSize - i - this.size - tot - totalFree();
      this.headFill = 0;
      this.tailFill = i;
      for (i = 0; i <= tot; i++)
        newFree[i] = new Buffer(); 
      this.headFree = 0;
      this.tailFree = tot;
      this.fill = newFill;
      this.free = newFree;
      this.size = newSize;
    }
    
    private synchronized Buffer get() {
      Buffer b = this.fill[this.headFill];
      this.fill[this.headFill] = null;
      this.headFill++;
      if (this.headFill >= this.size)
        this.headFill = 0; 
      return b;
    }
    
    private synchronized void append(Buffer b) {
      this.fill[this.tailFill] = b;
      this.tailFill++;
      if (this.tailFill >= this.size)
        this.tailFill = 0; 
    }
    
    private synchronized void prepend(Buffer b) {
      this.headFill--;
      if (this.headFill < 0)
        this.headFill = 0; 
      this.fill[this.headFill] = b;
    }
    
    private synchronized void insert(Buffer b) {
      int i = this.headFill;
      while (i != this.tailFill && 
        this.fill[i].getSequenceNumber() <= b.getSequenceNumber()) {
        i++;
        if (i >= this.size)
          i = 0; 
      } 
      if (i != this.tailFill) {
        this.tailFill++;
        if (this.tailFill >= this.size)
          this.tailFill = 0; 
        int prev = this.tailFill, j = prev;
        while (true) {
          prev--;
          if (prev < 0)
            prev = this.size - 1; 
          this.fill[j] = this.fill[prev];
          j = prev;
          if (j == i) {
            this.fill[i] = b;
            break;
          } 
        } 
      } 
    }
    
    private void removeAt(int n) {
      Buffer buf = this.fill[n];
      if (n == this.headFill) {
        this.headFill++;
        if (this.headFill >= this.size)
          this.headFill = 0; 
      } else if (n == this.tailFill) {
        this.tailFill--;
        if (this.tailFill < 0)
          this.tailFill = this.size - 1; 
      } else {
        int prev = n;
        while (true) {
          prev--;
          if (prev < 0)
            prev = this.size - 1; 
          this.fill[n] = this.fill[prev];
          n = prev;
          if (n == this.headFill) {
            this.headFill++;
            if (this.headFill >= this.size)
              this.headFill = 0; 
          } else {
            continue;
          } 
          returnFree(buf);
          return;
        } 
      } 
      returnFree(buf);
    }
    
    private boolean moreFilled() {
      return (this.headFill != this.tailFill);
    }
    
    public synchronized Buffer getFree() {
      Buffer b = this.free[this.headFree];
      this.free[this.headFree] = null;
      this.headFree++;
      if (this.headFree >= this.size)
        this.headFree = 0; 
      return b;
    }
    
    private synchronized void returnFree(Buffer b) {
      this.free[this.tailFree] = b;
      this.tailFree++;
      if (this.tailFree >= this.size)
        this.tailFree = 0; 
    }
    
    private boolean noMoreFree() {
      return (this.headFree == this.tailFree);
    }
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\rtp\RTPSourceStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */