/*     */ package com.sun.media;
/*     */ 
/*     */ import javax.media.Codec;
/*     */ import javax.media.Format;
/*     */ import javax.media.Multiplexer;
/*     */ import javax.media.PlugIn;
/*     */ import javax.media.Renderer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GraphNode
/*     */ {
/*     */   Class clz;
/*     */   String cname;
/*     */   PlugIn plugin;
/*  26 */   int type = -1; Format input;
/*  27 */   Format output = null;
/*     */   Format[] supportedIns;
/*     */   Format[] supportedOuts;
/*     */   GraphNode prev;
/*     */   int level;
/*     */   boolean failed = false;
/*     */   boolean custom = false;
/*  34 */   static int ARRAY_INC = 30; int attemptedIdx; Format[] attempted;
/*     */   
/*     */   GraphNode(PlugIn plugin, Format input, GraphNode prev, int level) {
/*  37 */     this((plugin == null) ? null : plugin.getClass().getName(), plugin, input, prev, level);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Format[] getSupportedInputs() {
/*  63 */     if (this.supportedIns != null)
/*  64 */       return this.supportedIns; 
/*  65 */     if (this.plugin == null)
/*  66 */       return null; 
/*  67 */     if ((this.type == -1 || this.type == 2) && this.plugin instanceof Codec) {
/*     */       
/*  69 */       this.supportedIns = ((Codec)this.plugin).getSupportedInputFormats();
/*  70 */     } else if ((this.type == -1 || this.type == 4) && this.plugin instanceof Renderer) {
/*     */       
/*  72 */       this.supportedIns = ((Renderer)this.plugin).getSupportedInputFormats();
/*  73 */     } else if (this.plugin instanceof Multiplexer) {
/*  74 */       this.supportedIns = ((Multiplexer)this.plugin).getSupportedInputFormats();
/*  75 */     }  return this.supportedIns;
/*     */   }
/*     */   
/*     */   Format[] getSupportedOutputs(Format in) {
/*  79 */     if (in == this.input && this.supportedOuts != null)
/*  80 */       return this.supportedOuts; 
/*  81 */     if (this.plugin == null)
/*  82 */       return null; 
/*  83 */     if ((this.type == -1 || this.type == 4) && this.plugin instanceof Renderer)
/*     */     {
/*  85 */       return null; } 
/*  86 */     if ((this.type == -1 || this.type == 2) && this.plugin instanceof Codec) {
/*     */ 
/*     */       
/*  89 */       Format[] outs = ((Codec)this.plugin).getSupportedOutputFormats(in);
/*  90 */       if (this.input == in)
/*  91 */         this.supportedOuts = outs; 
/*  92 */       return outs;
/*     */     } 
/*  94 */     return null;
/*     */   }
/*     */   
/*     */   public void resetAttempted() {
/*  98 */     this.attemptedIdx = 0;
/*  99 */     this.attempted = null;
/*     */   }
/*     */   
/* 102 */   GraphNode(String cname, PlugIn plugin, Format input, GraphNode prev, int level) { this.attemptedIdx = 0;
/* 103 */     this.attempted = null; this.cname = cname; this.plugin = plugin; this.input = input; this.prev = prev; this.level = level; } GraphNode(GraphNode gn, Format input, GraphNode prev, int level) { this.attemptedIdx = 0; this.attempted = null; this.cname = gn.cname; this.plugin = gn.plugin; this.type = gn.type; this.custom = gn.custom; this.input = input; this.prev = prev;
/*     */     this.level = level;
/*     */     this.supportedIns = gn.supportedIns;
/*     */     if (gn.input == input)
/* 107 */       this.supportedOuts = gn.supportedOuts;  } boolean checkAttempted(Format input) { if (this.attempted == null) {
/* 108 */       this.attempted = new Format[ARRAY_INC];
/* 109 */       this.attempted[this.attemptedIdx++] = input;
/* 110 */       return false;
/*     */     } 
/*     */     
/* 113 */     for (int j = 0; j < this.attemptedIdx; j++) {
/* 114 */       if (input.equals(this.attempted[j])) {
/* 115 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 119 */     if (this.attemptedIdx >= this.attempted.length) {
/*     */       
/* 121 */       Format[] newarray = new Format[this.attempted.length + ARRAY_INC];
/* 122 */       System.arraycopy(this.attempted, 0, newarray, 0, this.attempted.length);
/* 123 */       this.attempted = newarray;
/*     */     } 
/* 125 */     this.attempted[this.attemptedIdx++] = input;
/* 126 */     return false; }
/*     */ 
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\GraphNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */