/*     */ package com.sun.media.util;
/*     */ 
/*     */ import com.sun.media.ExtBuffer;
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.SimpleGraphBuilder;
/*     */ import java.awt.Component;
/*     */ import java.util.Vector;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Codec;
/*     */ import javax.media.Format;
/*     */ import javax.media.Renderer;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CodecChain
/*     */ {
/*     */   static final int STAGES = 5;
/*  23 */   protected Codec[] codecs = null;
/*  24 */   protected Buffer[] buffers = null;
/*  25 */   protected Format[] formats = null;
/*  26 */   protected Renderer renderer = null;
/*     */   
/*     */   private boolean deallocated = true;
/*     */   protected boolean firstBuffer = true;
/*     */   private boolean rtpFormat = false;
/*     */   
/*     */   boolean isRawFormat(Format format) {
/*  33 */     return false;
/*     */   }
/*     */   
/*     */   public void reset() {
/*  37 */     this.firstBuffer = true;
/*  38 */     for (int i = 0; i < this.codecs.length; i++) {
/*  39 */       if (this.codecs[i] != null) {
/*  40 */         this.codecs[i].reset();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int process(Buffer buffer, boolean render) {
/*  49 */     int codecNo = 0;
/*  50 */     return doProcess(codecNo, buffer, render);
/*     */   }
/*     */ 
/*     */   
/*     */   private int doProcess(int codecNo, Buffer input, boolean render) {
/*     */     int returnVal;
/*  56 */     Format format = input.getFormat();
/*  57 */     if (codecNo == this.codecs.length) {
/*     */       
/*  59 */       if (render) {
/*     */ 
/*     */         
/*  62 */         if (this.renderer != null && this.formats[codecNo] != null && this.formats[codecNo] != format && !this.formats[codecNo].equals(format) && !input.isDiscard()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  68 */           if (this.renderer.setInputFormat(format) == null) {
/*     */             
/*  70 */             Log.error("Monitor failed to handle mid-stream format change:");
/*  71 */             Log.error("  old: " + this.formats[codecNo]);
/*  72 */             Log.error("  new: " + format);
/*  73 */             return 1;
/*     */           } 
/*     */ 
/*     */           
/*  77 */           this.formats[codecNo] = format;
/*     */         } 
/*     */         
/*     */         try {
/*  81 */           return this.renderer.process(input);
/*     */         } catch (Exception e) {
/*  83 */           Log.dumpStack(e);
/*  84 */           return 1;
/*     */         } catch (Error err) {
/*  86 */           Log.dumpStack(err);
/*  87 */           return 1;
/*     */         } 
/*     */       } 
/*     */       
/*  91 */       return 0;
/*     */     } 
/*     */     
/*  94 */     if (isRawFormat(format)) {
/*  95 */       if (!render) {
/*  96 */         return 0;
/*     */       
/*     */       }
/*     */     }
/* 100 */     else if (!this.rtpFormat && this.firstBuffer) {
/* 101 */       if ((input.getFlags() & 0x10) == 0) {
/* 102 */         return 0;
/*     */       }
/* 104 */       this.firstBuffer = false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     Codec codec = this.codecs[codecNo];
/*     */ 
/*     */ 
/*     */     
/* 114 */     if (codec != null && this.formats[codecNo] != null && this.formats[codecNo] != format && !this.formats[codecNo].equals(format) && !input.isDiscard()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 120 */       if (codec.setInputFormat(format) == null) {
/*     */         
/* 122 */         Log.error("Monitor failed to handle mid-stream format change:");
/* 123 */         Log.error("  old: " + this.formats[codecNo]);
/* 124 */         Log.error("  new: " + format);
/* 125 */         return 1;
/*     */       } 
/*     */ 
/*     */       
/* 129 */       this.formats[codecNo] = format;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/*     */       try {
/* 136 */         returnVal = codec.process(input, this.buffers[codecNo]);
/*     */       } catch (Exception e) {
/* 138 */         Log.dumpStack(e);
/* 139 */         return 1;
/*     */       } catch (Error err) {
/* 141 */         Log.dumpStack(err);
/* 142 */         return 1;
/*     */       } 
/*     */ 
/*     */       
/* 146 */       if (returnVal == 1)
/* 147 */         return 1; 
/* 148 */       if ((returnVal & 0x4) != 0)
/*     */         continue; 
/* 150 */       if (!this.buffers[codecNo].isDiscard() && !this.buffers[codecNo].isEOM())
/* 151 */         doProcess(codecNo + 1, this.buffers[codecNo], render); 
/* 152 */       this.buffers[codecNo].setOffset(0);
/* 153 */       this.buffers[codecNo].setLength(0);
/* 154 */       this.buffers[codecNo].setFlags(0);
/*     */     }
/* 156 */     while ((returnVal & 0x2) != 0);
/*     */     
/* 158 */     return returnVal;
/*     */   }
/*     */ 
/*     */   
/*     */   public Component getControlComponent() {
/* 163 */     return null;
/*     */   }
/*     */   
/*     */   public boolean prefetch() {
/* 167 */     if (!this.deallocated)
/* 168 */       return true; 
/*     */     try {
/* 170 */       this.renderer.open();
/*     */     } catch (ResourceUnavailableException e) {
/* 172 */       return false;
/*     */     } 
/* 174 */     this.renderer.start();
/* 175 */     this.deallocated = false;
/* 176 */     return true;
/*     */   }
/*     */   
/*     */   public void deallocate() {
/* 180 */     if (this.deallocated)
/*     */       return; 
/* 182 */     if (this.renderer != null)
/* 183 */       this.renderer.close(); 
/* 184 */     this.deallocated = true;
/*     */   }
/*     */   
/*     */   public void close() {
/* 188 */     for (int i = 0; i < this.codecs.length; i++) {
/* 189 */       this.codecs[i].close();
/*     */     }
/* 191 */     if (this.renderer != null) {
/* 192 */       this.renderer.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean buildChain(Format input) {
/* 198 */     Vector formatList = new Vector(10);
/*     */     Vector pluginList;
/* 200 */     if ((pluginList = SimpleGraphBuilder.findRenderingChain(input, formatList)) == null) {
/* 201 */       return false;
/*     */     }
/* 203 */     int len = pluginList.size();
/* 204 */     this.codecs = new Codec[len - 1];
/* 205 */     this.buffers = (Buffer[])new ExtBuffer[len - 1];
/* 206 */     this.formats = new Format[len];
/*     */     
/* 208 */     this.formats[0] = input;
/*     */     
/* 210 */     Log.comment("Monitor codec chain:");
/*     */     
/* 212 */     for (int j = 0; j < this.codecs.length; j++) {
/* 213 */       this.codecs[j] = pluginList.elementAt(len - j - 1);
/*     */       
/* 215 */       this.formats[j + 1] = formatList.elementAt(len - j - 2);
/* 216 */       this.buffers[j] = (Buffer)new ExtBuffer();
/* 217 */       this.buffers[j].setFormat(this.formats[j + 1]);
/* 218 */       Log.write("    codec: " + this.codecs[j]);
/* 219 */       Log.write("      format: " + this.formats[j]);
/*     */     } 
/*     */     
/* 222 */     this.renderer = (Renderer)pluginList.elementAt(0);
/*     */     
/* 224 */     Log.write("    renderer: " + this.renderer);
/* 225 */     Log.write("      format: " + this.formats[this.codecs.length] + "\n");
/*     */     
/* 227 */     if (input.getEncoding() != null) {
/* 228 */       String enc = input.getEncoding().toUpperCase();
/* 229 */       if (enc.endsWith("RTP")) {
/* 230 */         this.rtpFormat = true;
/*     */       }
/*     */     } 
/* 233 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\util\CodecChain.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */