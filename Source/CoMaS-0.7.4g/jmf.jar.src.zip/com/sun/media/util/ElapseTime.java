/*    */ package com.sun.media.util;
/*    */ 
/*    */ import javax.media.Format;
/*    */ import javax.media.format.AudioFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ElapseTime
/*    */ {
/* 19 */   public long value = 0L;
/*    */   
/*    */   public void setValue(long t) {
/* 22 */     this.value = t;
/*    */   }
/*    */   
/*    */   public long getValue() {
/* 26 */     return this.value;
/*    */   }
/*    */   
/*    */   public boolean update(int len, long ts, Format f) {
/* 30 */     if (f instanceof AudioFormat) {
/*    */       long t;
/* 32 */       if ((t = ((AudioFormat)f).computeDuration(len)) > 0L)
/* 33 */       { this.value += t; }
/* 34 */       else if (ts > 0L)
/* 35 */       { this.value = ts; }
/*    */       else
/* 37 */       { return false; } 
/* 38 */     } else if (ts > 0L) {
/* 39 */       this.value = ts;
/*    */     } else {
/* 41 */       return false;
/*    */     } 
/* 43 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static long audioLenToTime(long len, AudioFormat af) {
/* 51 */     return af.computeDuration(len);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static long audioTimeToLen(long duration, AudioFormat af) {
/*    */     long l1;
/*    */     long l2;
/* 62 */     if (af.getSampleSizeInBits() > 0) {
/* 63 */       l1 = (af.getSampleSizeInBits() * af.getChannels());
/* 64 */       l2 = (long)(l1 * af.getSampleRate() / 8.0D);
/* 65 */     } else if (af.getFrameSizeInBits() != -1 && af.getFrameRate() != -1.0D) {
/*    */       
/* 67 */       l1 = af.getFrameSizeInBits();
/* 68 */       l2 = (long)(l1 * af.getFrameRate() / 8.0D);
/*    */     } else {
/* 70 */       l1 = l2 = 0L;
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 75 */     return (l2 == 0L) ? 0L : (duration * l2 / 1000000000L / l1 * l1);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\util\ElapseTime.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */