package com.sun.media.util;

import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class JMFI18N {
  public static ResourceBundle bundle = null;
  
  public static ResourceBundle bundleApps = null;
  
  public static String getResource(String key) {
    Locale currentLocale = Locale.getDefault();
    if (bundle == null) {
      try {
        bundle = ResourceBundle.getBundle("com.sun.media.util.locale.JMFProps", currentLocale);
      } catch (MissingResourceException e) {
        System.out.println("Could not load Resources");
        System.exit(0);
      } 
      try {
        bundleApps = ResourceBundle.getBundle("com.sun.media.util.locale.JMFAppProps", currentLocale);
      } catch (MissingResourceException me) {}
    } 
    String value = "";
    try {
      value = (String)bundle.getObject(key);
    } catch (MissingResourceException e) {
      if (bundleApps != null) {
        try {
          value = (String)bundleApps.getObject(key);
        } catch (MissingResourceException mre) {
          System.out.println("Could not find " + key);
        } 
      } else {
        System.out.println("Could not find " + key);
      } 
    } 
    return value;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\util\JMFI18N.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */