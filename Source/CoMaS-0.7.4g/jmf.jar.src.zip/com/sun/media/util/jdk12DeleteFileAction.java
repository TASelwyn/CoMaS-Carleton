package com.sun.media.util;

import java.io.File;
import java.lang.reflect.Constructor;
import java.security.PrivilegedAction;

public class jdk12DeleteFileAction implements PrivilegedAction {
  public static Constructor cons;
  
  private File file;
  
  private static Boolean TRUE = new Boolean(true);
  
  private static Boolean FALSE = new Boolean(false);
  
  static {
    try {
      cons = jdk12DeleteFileAction.class.getConstructor(new Class[] { File.class });
    } catch (Throwable e) {}
  }
  
  public jdk12DeleteFileAction(File file) {
    try {
      this.file = file;
    } catch (Throwable e) {}
  }
  
  public Object run() {
    try {
      if (this.file != null) {
        if (this.file.delete())
          return TRUE; 
        return FALSE;
      } 
      return FALSE;
    } catch (Throwable e) {
      return null;
    } 
  }
}
