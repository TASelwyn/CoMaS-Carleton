package com.sun.media.util;

public class JMFPropertiesGen {
  public static void main(String[] args) {
    String[] nativeList = RegistryGen.nativePlugins;
    String[] defaultList = RegistryGen.defaultPlugins;
    boolean allJava = false;
    if (args.length > 0 && args[0].equalsIgnoreCase("java"))
      allJava = true; 
    String[] mergedList = RegistryGen.findAllPlugInList(allJava, defaultList, nativeList);
    RegistryGen.registerPlugIns(mergedList);
    if (!allJava) {
      String fileSeparator = System.getProperty("file.separator");
      if (fileSeparator.equals("/")) {
        Registry.set("secure.cacheDir", "/tmp");
      } else {
        Registry.set("secure.cacheDir", "C:" + fileSeparator + "temp");
      } 
      try {
        Registry.commit();
      } catch (Exception e) {}
    } 
    System.exit(0);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\util\JMFPropertiesGen.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */