package com.sun.media.util;

import javax.media.Format;

public interface DynamicPlugIn {
  Format[] getBaseInputFormats();
  
  Format[] getBaseOutputFormats();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\util\DynamicPlugIn.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */