package com.sun.media.util;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.media.CaptureDeviceInfo;
import javax.media.CaptureDeviceManager;
import javax.media.Codec;
import javax.media.Demultiplexer;
import javax.media.Effect;
import javax.media.Format;
import javax.media.Multiplexer;
import javax.media.PlugInManager;
import javax.media.Renderer;
import javax.media.protocol.ContentDescriptor;

public class RegistryGen {
  static String arname;
  
  static String pkgname;
  
  static String destdir;
  
  static String[] names;
  
  static DataOutputStream ds;
  
  static byte[] properties = null;
  
  private static String filename = null;
  
  private static Format[] emptyFormat = new Format[0];
  
  static {
    String fileSeparator = System.getProperty("file.separator");
    Registry.set("secure.allowCaching", new Boolean(true));
    Registry.set("secure.maxCacheSizeMB", new Integer(250));
    Registry.set("secure.allowSaveFileFromApplets", new Boolean(false));
    Registry.set("secure.allowCaptureFromApplets", new Boolean(false));
    Registry.set("allowLogging", new Boolean(false));
    try {
      Registry.commit();
    } catch (Exception e) {}
  }
  
  static String[] nativePlugins = new String[] { 
      "com.ibm.media.codec.video.mpeg.MpegVideo", "com.sun.media.codec.video.cinepak.NativeDecoder", "com.sun.media.codec.video.cinepakpro.NativeEncoder", "com.sun.media.codec.video.h261.NativeDecoder", "com.sun.media.codec.video.vh263.NativeDecoder", "com.sun.media.codec.video.jpeg.NativeDecoder", "com.sun.media.codec.video.vcm.NativeDecoder", "com.sun.media.codec.video.vcm.NativeEncoder", "com.ibm.media.codec.audio.g723.NativeDecoder", "com.ibm.media.codec.audio.gsm.NativeDecoder", 
      "com.ibm.media.codec.audio.gsm.NativeDecoder_ms", "com.ibm.media.codec.audio.ACMCodec", "com.sun.media.codec.video.jpeg.NativeEncoder", "com.ibm.media.codec.video.h263.NativeEncoder", "com.ibm.media.codec.audio.g723.NativeEncoder", "com.ibm.media.codec.audio.gsm.NativeEncoder", "com.sun.media.codec.audio.mpa.NativeDecoder", "com.sun.media.codec.audio.mpa.NativeEncoder", "com.sun.media.codec.video.colorspace.YUVToRGB", "com.sun.media.renderer.video.DDRenderer", 
      "com.sun.media.renderer.video.GDIRenderer", "com.sun.media.renderer.video.SunRayRenderer", "com.sun.media.renderer.video.XILRenderer", "com.sun.media.renderer.video.XLibRenderer" };
  
  static String[] defaultPlugins = new String[] { 
      "com.ibm.media.parser.video.MpegParser", "com.sun.media.parser.audio.WavParser", "com.sun.media.parser.audio.AuParser", "com.sun.media.parser.audio.AiffParser", "com.sun.media.parser.audio.GsmParser", "com.sun.media.parser.RawStreamParser", "com.sun.media.parser.RawBufferParser", "com.sun.media.parser.RawPullStreamParser", "com.sun.media.parser.RawPullBufferParser", "com.sun.media.parser.video.QuicktimeParser", 
      "com.sun.media.parser.video.AviParser", "com.sun.media.codec.audio.mpa.JavaDecoder", "com.sun.media.codec.video.cinepak.JavaDecoder", "com.ibm.media.codec.video.h263.JavaDecoder", "com.sun.media.codec.video.colorspace.JavaRGBConverter", "com.sun.media.codec.video.colorspace.JavaRGBToYUV", "com.ibm.media.codec.audio.PCMToPCM", "com.ibm.media.codec.audio.rc.RCModule", "com.sun.media.codec.audio.rc.RateCvrt", "com.sun.media.codec.audio.msadpcm.JavaDecoder", 
      "com.ibm.media.codec.audio.ulaw.JavaDecoder", "com.ibm.media.codec.audio.alaw.JavaDecoder", "com.ibm.media.codec.audio.dvi.JavaDecoder", "com.ibm.media.codec.audio.g723.JavaDecoder", "com.ibm.media.codec.audio.gsm.JavaDecoder", "com.ibm.media.codec.audio.gsm.JavaDecoder_ms", "com.ibm.media.codec.audio.ima4.JavaDecoder", "com.ibm.media.codec.audio.ima4.JavaDecoder_ms", "com.ibm.media.codec.audio.ulaw.JavaEncoder", "com.ibm.media.codec.audio.dvi.JavaEncoder", 
      "com.ibm.media.codec.audio.gsm.JavaEncoder", "com.ibm.media.codec.audio.gsm.JavaEncoder_ms", "com.ibm.media.codec.audio.ima4.JavaEncoder", "com.ibm.media.codec.audio.ima4.JavaEncoder_ms", "com.sun.media.codec.audio.ulaw.Packetizer", "com.sun.media.codec.audio.ulaw.DePacketizer", "com.sun.media.codec.audio.mpa.Packetizer", "com.sun.media.codec.audio.mpa.DePacketizer", "com.ibm.media.codec.audio.gsm.Packetizer", "com.ibm.media.codec.audio.g723.Packetizer", 
      "com.sun.media.codec.video.jpeg.Packetizer", "com.sun.media.codec.video.jpeg.DePacketizer", "com.sun.media.codec.video.mpeg.Packetizer", "com.sun.media.codec.video.mpeg.DePacketizer", "com.sun.media.renderer.audio.JavaSoundRenderer", "com.sun.media.renderer.audio.SunAudioRenderer", "com.sun.media.renderer.video.AWTRenderer", "com.sun.media.renderer.video.LightWeightRenderer", "com.sun.media.renderer.video.JPEGRenderer", "com.sun.media.multiplexer.RawBufferMux", 
      "com.sun.media.multiplexer.RawSyncBufferMux", "com.sun.media.multiplexer.RTPSyncBufferMux", "com.sun.media.multiplexer.audio.GSMMux", "com.sun.media.multiplexer.audio.MPEGMux", "com.sun.media.multiplexer.audio.WAVMux", "com.sun.media.multiplexer.audio.AIFFMux", "com.sun.media.multiplexer.audio.AUMux", "com.sun.media.multiplexer.video.AVIMux", "com.sun.media.multiplexer.video.QuicktimeMux" };
  
  static void printUsage() {
    System.err.println("java RegistryGen [-d <destdir>] [-j java] <registrylib> ");
    System.err.println("-j java: all-java");
  }
  
  static void writeClass() {
    int accBytes = 0;
    try {
      ds.writeBytes("/* Generated by RegistryGen.\n   DO NOT EDIT.*/\n\n");
      if (pkgname != null) {
        ds.writeBytes("package ");
        ds.writeBytes(pkgname);
        ds.writeBytes(";\n\n");
      } 
      ds.writeBytes("public abstract class ");
      ds.writeBytes(arname);
      ds.writeBytes(" {\n\n");
      if (properties.length > 0) {
        ds.writeBytes("   public static byte[] getData(){\n");
        ds.writeBytes("       int i;\n");
        ds.writeBytes("       byte[] b= new byte[" + properties.length + "];\n");
        ds.writeBytes("       for (i=0;i<b.length;i++)\n");
        ds.writeBytes("          b[i] = (byte)(s.charAt(i)-1);\n");
        ds.writeBytes("       return b;\n");
        ds.writeBytes("    }\n");
      } else {
        ds.writeBytes("   public static byte[] getData(){\n");
        ds.writeBytes("       return null;\n");
        ds.writeBytes("    }\n");
      } 
      ds.writeBytes("    private static String s = \n        ");
      ds.writeBytes("\"");
      int len = properties.length;
      for (int j = 0; j < len; j++) {
        ds.writeBytes("\\" + byte2oct((byte)(1 + properties[j])));
        if (j % 16 == 15)
          ds.writeBytes("\"+\n        \""); 
      } 
      ds.writeBytes("\";\n\n");
      ds.writeBytes("}\n");
    } catch (IOException e) {}
  }
  
  private static String byte2oct(byte b) {
    int i = b & 0xFF;
    int dig3 = i % 8;
    int dig2 = i / 8 % 8;
    int dig1 = i / 64;
    return "" + dig1 + "" + dig2 + "" + dig3;
  }
  
  private static void registerPlugIn(String className) {
    try {
      boolean bool;
      Class pic = Class.forName(className);
      Object instance = pic.newInstance();
      Format[] inputs = null;
      Format[] outputs = null;
      if (instance instanceof Demultiplexer) {
        bool = true;
        ContentDescriptor[] arrayOfContentDescriptor = ((Demultiplexer)instance).getSupportedInputContentDescriptors();
        outputs = emptyFormat;
      } else if (instance instanceof Codec) {
        bool = true;
        inputs = ((Codec)instance).getSupportedInputFormats();
        outputs = ((Codec)instance).getSupportedOutputFormats(null);
      } else if (instance instanceof Renderer) {
        bool = true;
        inputs = ((Renderer)instance).getSupportedInputFormats();
        outputs = emptyFormat;
      } else if (instance instanceof Multiplexer) {
        bool = true;
        inputs = emptyFormat;
        ContentDescriptor[] arrayOfContentDescriptor = ((Multiplexer)instance).getSupportedOutputContentDescriptors(null);
      } else if (instance instanceof Effect) {
        bool = true;
        inputs = ((Effect)instance).getSupportedInputFormats();
        outputs = ((Effect)instance).getSupportedOutputFormats(null);
      } else {
        bool = false;
      } 
      if (instance instanceof DynamicPlugIn) {
        inputs = ((DynamicPlugIn)instance).getBaseInputFormats();
        outputs = ((DynamicPlugIn)instance).getBaseOutputFormats();
      } 
      if (bool)
        boolean result = PlugInManager.addPlugIn(className, inputs, outputs, bool); 
    } catch (ClassNotFoundException cnfe) {
    
    } catch (Exception e) {
    
    } catch (UnsatisfiedLinkError erro) {}
  }
  
  private static void deletePlugins(int type) {
    Vector v = PlugInManager.getPlugInList(null, null, type);
    Enumeration eClassNames = v.elements();
    while (eClassNames.hasMoreElements()) {
      String className = eClassNames.nextElement();
      PlugInManager.removePlugIn(className, type);
    } 
  }
  
  static void registerPlugIns(String[] plugins) {
    if (plugins == null)
      return; 
    deletePlugins(1);
    deletePlugins(2);
    deletePlugins(4);
    deletePlugins(5);
    deletePlugins(3);
    for (int i = 0; i < plugins.length; i++)
      registerPlugIn(plugins[i]); 
    try {
      PlugInManager.commit();
    } catch (Exception e) {
      System.err.println("can't commit PlugInManager");
    } 
  }
  
  static void registerCaptureDevices(CaptureDeviceInfo[] cdis) {
    for (int i = 0; i < cdis.length; i++)
      CaptureDeviceManager.addDevice(cdis[i]); 
    try {
      CaptureDeviceManager.commit();
    } catch (IOException ioe) {
      System.err.println("can't commit CaptureDeviceManager");
    } 
  }
  
  private static boolean readProperties() {
    String classpath = null;
    try {
      classpath = System.getProperty("java.class.path");
    } catch (Exception e) {
      filename = null;
      return false;
    } 
    StringTokenizer tokens = new StringTokenizer(classpath, File.pathSeparator);
    String strJMF = "jmf.properties";
    File file = null;
    while (tokens.hasMoreTokens()) {
      String dir = tokens.nextToken();
      String caps = dir.toUpperCase();
      try {
        if (caps.indexOf(".ZIP") > 0 || caps.indexOf(".JAR") > 0) {
          int sep = dir.lastIndexOf(File.separator);
          if (sep == -1 && !File.separator.equals("/"))
            sep = dir.lastIndexOf("/"); 
          if (sep == -1) {
            sep = dir.lastIndexOf(":");
            if (sep == -1) {
              dir = strJMF;
            } else {
              dir = dir.substring(0, sep) + ":" + strJMF;
            } 
          } else {
            dir = dir.substring(0, sep) + File.separator + strJMF;
          } 
        } else {
          dir = dir + File.separator + strJMF;
        } 
      } catch (Exception e) {
        dir = dir + File.separator + strJMF;
      } 
      try {
        file = new File(dir);
        if (file.exists()) {
          filename = dir;
          break;
        } 
      } catch (Throwable t) {
        filename = null;
        return false;
      } 
    } 
    try {
      if (filename == null || file == null)
        return false; 
      if (file.length() == 0L)
        return false; 
    } catch (Throwable t) {
      return false;
    } 
    try {
      FileInputStream fis = new FileInputStream(filename);
      DataInputStream dis = new DataInputStream(fis);
      int len = dis.available();
      properties = new byte[len];
      dis.read(properties, 0, len);
      dis.close();
      fis.close();
    } catch (IOException ioe) {
      System.err.println("IOException in readProperties: " + ioe);
      return false;
    } 
    return true;
  }
  
  public static String[] findAllPlugInList(boolean allJava, String[] defaultList, String[] nativeList) {
    String[] arrayOfString;
    if (allJava) {
      arrayOfString = defaultList;
    } else {
      int addDirectAudio = 0;
      if (System.getProperty("os.name").startsWith("Solaris") || System.getProperty("os.name").startsWith("SunOS"))
        addDirectAudio = 1; 
      arrayOfString = new String[nativeList.length + addDirectAudio + defaultList.length];
      int i;
      for (i = 0; i < nativeList.length; i++)
        arrayOfString[i] = nativeList[i]; 
      if (addDirectAudio == 0) {
        for (i = 0; i < defaultList.length; i++)
          arrayOfString[i + nativeList.length] = defaultList[i]; 
      } else {
        int idxJS = -1;
        for (int j = 0; j < defaultList.length; j++) {
          if (defaultList[j].indexOf("JavaSoundRenderer") >= 0) {
            idxJS = j;
            break;
          } 
        } 
        if (idxJS >= 0) {
          for (int k = 0; k <= idxJS; k++)
            arrayOfString[nativeList.length + k] = defaultList[k]; 
          arrayOfString[nativeList.length + idxJS + 1] = "com.sun.media.renderer.audio.DirectAudioRenderer";
          for (int m = idxJS + 1; m < defaultList.length; m++)
            arrayOfString[nativeList.length + 1 + m] = defaultList[m]; 
        } else {
          for (int k = 0; k < defaultList.length; k++)
            arrayOfString[nativeList.length + k] = defaultList[k]; 
          arrayOfString[nativeList.length + defaultList.length] = "com.sun.media.renderer.audio.DirectAudioRenderer";
        } 
      } 
    } 
    return arrayOfString;
  }
  
  public static void main(String[] args) {
    boolean allJava = false;
    names = new String[args.length + 1];
    int i, j;
    for (i = 0, j = 0; i < args.length; i++) {
      if (args[i].equals("-d")) {
        if (i++ >= args.length) {
          printUsage();
          return;
        } 
        destdir = args[i];
      } else if (args[i].equals("-j")) {
        int k = i + 1;
        if (k < args.length && args[k].equalsIgnoreCase("java")) {
          allJava = true;
          i++;
        } else {
          allJava = false;
        } 
      } else {
        names[j++] = args[i];
      } 
    } 
    names[j] = null;
    if (j == 0) {
      printUsage();
      return;
    } 
    i = names[0].lastIndexOf(".");
    if (i == -1) {
      pkgname = null;
      arname = names[0];
    } else {
      pkgname = names[0].substring(0, i);
      arname = names[0].substring(i + 1);
    } 
    String filename = null;
    try {
      if (destdir == null) {
        filename = arname + ".java";
      } else {
        filename = destdir + File.separator + arname + ".java";
      } 
      ds = new DataOutputStream(new FileOutputStream(filename));
    } catch (IOException e) {
      System.err.println("Cannot open file: " + filename + e);
    } 
    String[] mergedList = null;
    mergedList = findAllPlugInList(allJava, defaultPlugins, nativePlugins);
    registerPlugIns(mergedList);
    if (!readProperties()) {
      System.err.println("Cannot read jmf.properties");
      System.exit(0);
    } 
    writeClass();
    System.exit(0);
  }
}
