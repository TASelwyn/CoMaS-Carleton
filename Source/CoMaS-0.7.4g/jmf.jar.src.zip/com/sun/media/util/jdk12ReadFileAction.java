/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.io.FileInputStream;
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class jdk12ReadFileAction
/*    */   implements PrivilegedAction
/*    */ {
/*    */   public static Constructor cons;
/*    */   private String name;
/*    */   
/*    */   static {
/*    */     try {
/* 21 */       cons = jdk12ReadFileAction.class.getConstructor(new Class[] { String.class });
/*    */     }
/* 23 */     catch (Throwable e) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public jdk12ReadFileAction(String name) {
/*    */     try {
/* 31 */       this.name = name;
/* 32 */     } catch (Throwable e) {}
/*    */   }
/*    */ 
/*    */   
/*    */   public Object run() {
/*    */     try {
/* 38 */       return new FileInputStream(this.name);
/*    */     } catch (Throwable t) {
/* 40 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\util\jdk12ReadFileAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */