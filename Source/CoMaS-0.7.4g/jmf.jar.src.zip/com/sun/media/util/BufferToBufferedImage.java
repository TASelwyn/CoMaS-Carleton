/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.awt.Image;
/*    */ import java.awt.Point;
/*    */ import java.awt.geom.AffineTransform;
/*    */ import java.awt.image.AffineTransformOp;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.awt.image.DataBufferInt;
/*    */ import java.awt.image.DirectColorModel;
/*    */ import java.awt.image.Raster;
/*    */ import java.awt.image.SinglePixelPackedSampleModel;
/*    */ import java.awt.image.WritableRaster;
/*    */ import javax.media.Buffer;
/*    */ import javax.media.format.RGBFormat;
/*    */ import javax.media.format.VideoFormat;
/*    */ import javax.media.util.BufferToImage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BufferToBufferedImage
/*    */   extends BufferToImage
/*    */ {
/*    */   public BufferToBufferedImage() throws ClassNotFoundException {
/* 28 */     super(null);
/* 29 */     Class.forName("java.awt.Graphics2D");
/*    */   }
/*    */   
/*    */   public BufferToBufferedImage(VideoFormat paramVideoFormat) throws ClassNotFoundException {
/* 33 */     super(paramVideoFormat);
/* 34 */     Class.forName("java.awt.Graphics2D");
/*    */   }
/*    */   
/*    */   public Image createImage(Buffer paramBuffer) {
/* 38 */     RGBFormat rGBFormat = (RGBFormat)paramBuffer.getFormat();
/*    */     
/* 40 */     Object object = paramBuffer.getData();
/*    */ 
/*    */     
/* 43 */     int i = rGBFormat.getRedMask();
/* 44 */     int j = rGBFormat.getGreenMask();
/* 45 */     int k = rGBFormat.getBlueMask();
/* 46 */     int[] arrayOfInt = new int[3];
/* 47 */     arrayOfInt[0] = i;
/* 48 */     arrayOfInt[1] = j;
/* 49 */     arrayOfInt[2] = k;
/*    */     
/* 51 */     DataBufferInt dataBufferInt = new DataBufferInt((int[])object, 
/* 52 */         rGBFormat.getLineStride() * 
/* 53 */         (rGBFormat.getSize()).height);
/*    */     
/* 55 */     SinglePixelPackedSampleModel singlePixelPackedSampleModel = new SinglePixelPackedSampleModel(3, 
/* 56 */         rGBFormat.getLineStride(), 
/* 57 */         (rGBFormat.getSize()).height, 
/* 58 */         arrayOfInt);
/* 59 */     WritableRaster writableRaster = Raster.createWritableRaster(singlePixelPackedSampleModel, dataBufferInt, new Point(0, 0));
/*    */     
/* 61 */     DirectColorModel directColorModel = new DirectColorModel(24, i, j, k);
/* 62 */     BufferedImage bufferedImage1 = new BufferedImage(directColorModel, writableRaster, true, null);
/*    */     
/* 64 */     AffineTransform affineTransform = new AffineTransform(1.0F, 0.0F, 
/* 65 */         0.0F, 1.0F, 
/* 66 */         0.0F, 0.0F);
/* 67 */     AffineTransformOp affineTransformOp = new AffineTransformOp(affineTransform, null);
/*    */     
/* 69 */     BufferedImage bufferedImage2 = affineTransformOp.createCompatibleDestImage(bufferedImage1, 
/* 70 */         directColorModel);
/*    */ 
/*    */     
/* 73 */     affineTransformOp.filter(bufferedImage1, bufferedImage2);
/*    */     
/* 75 */     return bufferedImage2;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\util\BufferToBufferedImage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */