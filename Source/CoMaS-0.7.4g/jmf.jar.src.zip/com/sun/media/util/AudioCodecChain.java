/*    */ package com.sun.media.util;
/*    */ 
/*    */ import com.sun.media.ui.GainControlComponent;
/*    */ import java.awt.Component;
/*    */ import javax.media.Control;
/*    */ import javax.media.Format;
/*    */ import javax.media.GainControl;
/*    */ import javax.media.format.AudioFormat;
/*    */ import javax.media.format.UnsupportedFormatException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AudioCodecChain
/*    */   extends CodecChain
/*    */ {
/*    */   public AudioCodecChain(AudioFormat input) throws UnsupportedFormatException {
/* 20 */     AudioFormat af = input;
/*    */     
/* 22 */     if (!buildChain((Format)input)) {
/* 23 */       throw new UnsupportedFormatException(input);
/*    */     }
/*    */ 
/*    */     
/* 27 */     this.renderer.close();
/*    */     
/* 29 */     this.firstBuffer = false;
/*    */   }
/*    */   
/* 32 */   Component gainComp = null;
/*    */   
/*    */   public Component getControlComponent() {
/* 35 */     if (this.gainComp != null) {
/* 36 */       return this.gainComp;
/*    */     }
/* 38 */     Control c = (Control)this.renderer.getControl("javax.media.GainControl");
/* 39 */     if (c != null)
/* 40 */       this.gainComp = (Component)new GainControlComponent((GainControl)c); 
/* 41 */     return this.gainComp;
/*    */   }
/*    */   
/*    */   public void reset() {}
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\util\AudioCodecChain.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */