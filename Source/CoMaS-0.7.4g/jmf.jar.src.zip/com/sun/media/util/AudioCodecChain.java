package com.sun.media.util;

import com.sun.media.ui.GainControlComponent;
import java.awt.Component;
import javax.media.Control;
import javax.media.Format;
import javax.media.GainControl;
import javax.media.format.AudioFormat;
import javax.media.format.UnsupportedFormatException;

public class AudioCodecChain extends CodecChain {
  public AudioCodecChain(AudioFormat input) throws UnsupportedFormatException {
    AudioFormat af = input;
    if (!buildChain((Format)input))
      throw new UnsupportedFormatException(input); 
    this.renderer.close();
    this.firstBuffer = false;
  }
  
  Component gainComp = null;
  
  public Component getControlComponent() {
    if (this.gainComp != null)
      return this.gainComp; 
    Control c = (Control)this.renderer.getControl("javax.media.GainControl");
    if (c != null)
      this.gainComp = (Component)new GainControlComponent((GainControl)c); 
    return this.gainComp;
  }
  
  public void reset() {}
}
