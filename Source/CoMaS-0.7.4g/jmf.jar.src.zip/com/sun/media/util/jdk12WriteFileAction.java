package com.sun.media.util;

import java.io.FileOutputStream;
import java.lang.reflect.Constructor;
import java.security.PrivilegedAction;

public class jdk12WriteFileAction implements PrivilegedAction {
  public static Constructor cons;
  
  private String name;
  
  static {
    try {
      cons = jdk12WriteFileAction.class.getConstructor(new Class[] { String.class });
    } catch (Throwable e) {}
  }
  
  public jdk12WriteFileAction(String name) {
    try {
      this.name = name;
    } catch (Throwable e) {}
  }
  
  public Object run() {
    try {
      return new FileOutputStream(this.name);
    } catch (Throwable t) {
      return null;
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\util\jdk12WriteFileAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */