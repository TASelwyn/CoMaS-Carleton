package com.sun.media.util;

import javax.media.Time;

public class SettableTime extends Time {
  public SettableTime() {
    super(0L);
  }
  
  public SettableTime(long nanoseconds) {
    super(nanoseconds);
  }
  
  public SettableTime(double seconds) {
    super(seconds);
  }
  
  public final Time set(long nanoseconds) {
    this.nanoseconds = nanoseconds;
    return this;
  }
  
  public final Time set(double seconds) {
    this.nanoseconds = secondsToNanoseconds(seconds);
    return this;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\util\SettableTime.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */