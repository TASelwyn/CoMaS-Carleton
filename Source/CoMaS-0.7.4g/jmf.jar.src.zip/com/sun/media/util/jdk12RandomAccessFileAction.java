package com.sun.media.util;

import java.io.RandomAccessFile;
import java.lang.reflect.Constructor;
import java.security.PrivilegedAction;

public class jdk12RandomAccessFileAction implements PrivilegedAction {
  public static Constructor cons;
  
  private String name;
  
  private String mode;
  
  static {
    try {
      cons = jdk12RandomAccessFileAction.class.getConstructor(new Class[] { String.class, String.class });
    } catch (Throwable e) {}
  }
  
  public jdk12RandomAccessFileAction(String name, String mode) {
    boolean rw = mode.equals("rw");
    if (!rw)
      mode = "r"; 
    this.mode = mode;
    this.name = name;
  }
  
  public Object run() {
    try {
      return new RandomAccessFile(this.name, this.mode);
    } catch (Throwable e) {
      return null;
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\util\jdk12RandomAccessFileAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */