package com.sun.media.util;

import java.util.Vector;
import javax.media.ControllerEvent;

public abstract class ThreadedEventQueue extends MediaThread {
  private Vector eventQueue = new Vector();
  
  private boolean killed = false;
  
  public ThreadedEventQueue() {
    useControlPriority();
  }
  
  protected abstract void processEvent(ControllerEvent paramControllerEvent);
  
  protected boolean dispatchEvents() {
    ControllerEvent evt = null;
    synchronized (this) {
      try {
        while (!this.killed && this.eventQueue.size() == 0)
          wait(); 
      } catch (InterruptedException e) {
        System.err.println("MediaNode event thread " + e);
        return true;
      } 
      if (this.eventQueue.size() > 0) {
        evt = this.eventQueue.firstElement();
        this.eventQueue.removeElementAt(0);
      } 
    } 
    if (evt != null)
      processEvent(evt); 
    return (!this.killed || this.eventQueue.size() != 0);
  }
  
  public synchronized void postEvent(ControllerEvent evt) {
    this.eventQueue.addElement(evt);
    notifyAll();
  }
  
  public synchronized void kill() {
    this.killed = true;
    notifyAll();
  }
  
  public void run() {
    do {
    
    } while (dispatchEvents());
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\util\ThreadedEventQueue.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */