/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.net.URLConnection;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class jdk12ConnectionAction
/*    */   implements PrivilegedAction
/*    */ {
/*    */   public static Constructor cons;
/*    */   private URLConnection urlC;
/*    */   
/*    */   static {
/*    */     try {
/* 21 */       cons = jdk12ConnectionAction.class.getConstructor(new Class[] { URLConnection.class });
/*    */     }
/* 23 */     catch (Throwable e) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public jdk12ConnectionAction(URLConnection urlC) {
/*    */     try {
/* 31 */       this.urlC = urlC;
/* 32 */     } catch (Throwable e) {}
/*    */   }
/*    */ 
/*    */   
/*    */   public Object run() {
/*    */     try {
/* 38 */       return this.urlC.getInputStream();
/*    */     } catch (Throwable t) {
/* 40 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\util\jdk12ConnectionAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */