/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class jdk12MakeDirectoryAction
/*    */   implements PrivilegedAction
/*    */ {
/*    */   public static Constructor cons;
/*    */   private File file;
/* 18 */   private static Boolean TRUE = new Boolean(true);
/* 19 */   private static Boolean FALSE = new Boolean(false);
/*    */   static {
/*    */     try {
/* 22 */       cons = jdk12MakeDirectoryAction.class.getConstructor(new Class[] { File.class });
/*    */     }
/* 24 */     catch (Throwable e) {}
/*    */   }
/*    */ 
/*    */   
/*    */   public jdk12MakeDirectoryAction(File file) {
/* 29 */     this.file = file;
/*    */   }
/*    */   
/*    */   public Object run() {
/*    */     try {
/* 34 */       if (this.file != null) {
/* 35 */         if (this.file.exists() || this.file.mkdirs()) {
/* 36 */           return TRUE;
/*    */         }
/* 38 */         return FALSE;
/*    */       } 
/* 40 */       return FALSE;
/*    */     } catch (Throwable e) {
/*    */       
/* 43 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\util\jdk12MakeDirectoryAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */