/*    */ package com.sun.media.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Arch
/*    */ {
/*    */   public static final int SPARC = 1;
/*    */   public static final int UNIX = 2;
/*    */   public static final int WIN32 = 4;
/*    */   public static final int SOLARIS = 8;
/*    */   public static final int LINUX = 16;
/*    */   public static final int X86 = 32;
/*    */   
/*    */   public static boolean isBigEndian() {
/* 25 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isLittleEndian() {
/* 32 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int getAlignment() {
/* 41 */     return 1;
/*    */   }
/*    */   
/*    */   public static int getArch() {
/* 45 */     return 36;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\util\Arch.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */