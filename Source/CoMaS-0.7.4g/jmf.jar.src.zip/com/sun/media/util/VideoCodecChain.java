/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Dimension;
/*    */ import javax.media.Format;
/*    */ import javax.media.format.UnsupportedFormatException;
/*    */ import javax.media.format.VideoFormat;
/*    */ import javax.media.renderer.VideoRenderer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VideoCodecChain
/*    */   extends CodecChain
/*    */ {
/*    */   public VideoCodecChain(VideoFormat vf) throws UnsupportedFormatException {
/* 20 */     Dimension size = vf.getSize();
/* 21 */     VideoFormat inputFormat = vf;
/*    */     
/* 23 */     if (size == null || vf == null) {
/* 24 */       throw new UnsupportedFormatException(vf);
/*    */     }
/* 26 */     if (!buildChain((Format)vf)) {
/* 27 */       throw new UnsupportedFormatException(vf);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   boolean isRawFormat(Format format) {
/* 39 */     return (format instanceof javax.media.format.RGBFormat || format instanceof javax.media.format.YUVFormat || (format.getEncoding() != null && (format.getEncoding().equalsIgnoreCase("jpeg") || format.getEncoding().equalsIgnoreCase("mpeg"))));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Component getControlComponent() {
/* 47 */     if (this.renderer instanceof VideoRenderer) {
/* 48 */       return ((VideoRenderer)this.renderer).getComponent();
/*    */     }
/* 50 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\util\VideoCodecChain.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */