package com.sun.media.util;

import java.lang.reflect.Method;

public class jdk12 {
  public static Class ac;
  
  public static Class accontextC;
  
  public static Class permissionC;
  
  public static Class privActionC;
  
  public static Method checkPermissionM;
  
  public static Method doPrivM;
  
  public static Method doPrivContextM;
  
  public static Method getContextM;
  
  static {
    try {
      ac = Class.forName("java.security.AccessController");
      accontextC = Class.forName("java.security.AccessControlContext");
      permissionC = Class.forName("java.security.Permission");
      privActionC = Class.forName("java.security.PrivilegedAction");
      checkPermissionM = ac.getMethod("checkPermission", new Class[] { permissionC });
      doPrivM = ac.getMethod("doPrivileged", new Class[] { privActionC });
      getContextM = ac.getMethod("getContext", null);
      doPrivContextM = ac.getMethod("doPrivileged", new Class[] { privActionC, accontextC });
    } catch (Throwable t) {}
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\util\jdk12.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */