/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.net.InetAddress;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class jdk12InetAddressAction
/*    */   implements PrivilegedAction
/*    */ {
/*    */   public static Constructor cons;
/*    */   private InetAddress addr;
/*    */   private String method;
/*    */   private String arg;
/*    */   
/*    */   static {
/*    */     try {
/* 23 */       cons = jdk12InetAddressAction.class.getConstructor(new Class[] { InetAddress.class, String.class, String.class });
/*    */     }
/* 25 */     catch (Throwable e) {}
/*    */   }
/*    */ 
/*    */   
/*    */   public jdk12InetAddressAction(InetAddress addr, String method, String arg) {
/* 30 */     this.addr = addr;
/* 31 */     this.method = method;
/* 32 */     this.arg = arg;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object run() {
/*    */     try {
/* 38 */       if (this.method.equals("getLocalHost"))
/* 39 */         return InetAddress.getLocalHost(); 
/* 40 */       if (this.method.equals("getAllByName"))
/* 41 */         return InetAddress.getAllByName(this.arg); 
/* 42 */       if (this.method.equals("getByName"))
/* 43 */         return InetAddress.getByName(this.arg); 
/* 44 */       if (this.method.equals("getHostName")) {
/* 45 */         return this.addr.getHostName();
/*    */       }
/* 47 */       return null;
/*    */     } catch (Throwable t) {
/* 49 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\util\jdk12InetAddressAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */