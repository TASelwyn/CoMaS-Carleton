package com.sun.media.util;

public abstract class LoopThread extends MediaThread {
  protected boolean paused = false, started = false;
  
  protected boolean killed = false;
  
  private boolean waitingAtPaused = false;
  
  public LoopThread() {
    setName("Loop thread");
  }
  
  public synchronized void pause() {
    this.paused = true;
  }
  
  public synchronized void blockingPause() {
    if (this.waitingAtPaused || this.killed)
      return; 
    this.paused = true;
    waitForCompleteStop();
  }
  
  public boolean isPaused() {
    return this.paused;
  }
  
  public synchronized void waitForCompleteStop() {
    try {
      while (!this.killed && !this.waitingAtPaused && this.paused)
        wait(); 
    } catch (InterruptedException e) {}
  }
  
  public synchronized void waitForCompleteStop(int millis) {
    try {
      if (!this.killed && !this.waitingAtPaused && this.paused)
        wait(millis); 
    } catch (InterruptedException e) {}
  }
  
  public synchronized void start() {
    if (!this.started) {
      super.start();
      this.started = true;
    } 
    this.paused = false;
    notifyAll();
  }
  
  public synchronized void kill() {
    this.killed = true;
    notifyAll();
  }
  
  public synchronized boolean waitHereIfPaused() {
    if (this.killed)
      return false; 
    this.waitingAtPaused = true;
    if (this.paused)
      notifyAll(); 
    try {
      while (!this.killed && this.paused)
        wait(); 
    } catch (InterruptedException e) {
      System.err.println("Timer: timeLoop() wait interrupted " + e);
    } 
    this.waitingAtPaused = false;
    if (this.killed)
      return false; 
    return true;
  }
  
  protected abstract boolean process();
  
  public void run() {
    while (waitHereIfPaused()) {
      if (!process())
        break; 
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\util\LoopThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */