package com.sun.media.util;

import javax.media.Format;

class FormatTable {
  public Format[] keys;
  
  public Format[][] table;
  
  public int[] hits;
  
  public int last;
  
  public FormatTable(int size) {
    this.keys = new Format[size];
    this.table = new Format[size][];
    this.hits = new int[size];
    this.last = 0;
  }
  
  Format[] get(Format input) {
    Format[] res = null;
    for (int i = 0; i < this.last; i++) {
      if (res == null && this.keys[i].matches(input)) {
        res = this.table[i];
        this.hits[i] = this.keys.length;
      } else {
        this.hits[i] = this.hits[i] - 1;
      } 
    } 
    return res;
  }
  
  public void save(Format input, Format[] supported) {
    int i;
    if (this.last >= this.keys.length) {
      i = findLeastHit();
    } else {
      i = this.last;
      this.last++;
    } 
    this.keys[i] = input;
    this.table[i] = supported;
    this.hits[i] = this.keys.length;
  }
  
  public int findLeastHit() {
    int min = this.hits[0];
    int idx = 0;
    for (int i = 1; i < this.last; i++) {
      if (this.hits[i] < min) {
        min = this.hits[i];
        idx = i;
      } 
    } 
    return idx;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\util\FormatTable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */