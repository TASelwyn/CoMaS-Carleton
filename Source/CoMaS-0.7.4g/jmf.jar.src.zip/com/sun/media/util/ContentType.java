package com.sun.media.util;

import com.sun.media.Log;
import com.sun.media.MimeManager;

public class ContentType {
  public static String getCorrectedContentType(String contentType, String fileName) {
    if (contentType != null) {
      if (contentType.startsWith("text")) {
        int j = fileName.lastIndexOf(".");
        if (j != -1) {
          String ext = fileName.substring(j + 1).toLowerCase();
          String str1 = MimeManager.getMimeType(ext);
          if (str1 != null)
            return str1; 
        } 
        Log.error("Warning: The URL may not exist. Please check URL");
        return contentType;
      } 
      if (contentType.equals("audio/wav"))
        return "audio/x-wav"; 
      if (contentType.equals("audio/aiff"))
        return "audio/x-aiff"; 
      if (contentType.equals("application/x-troff-msvideo"))
        return "video/x-msvideo"; 
      if (contentType.equals("video/msvideo"))
        return "video/x-msvideo"; 
      if (contentType.equals("video/avi"))
        return "video/x-msvideo"; 
      if (contentType.equals("audio/x-mpegaudio"))
        return "audio/mpeg"; 
    } 
    String type = null;
    int i = fileName.lastIndexOf(".");
    if (i != -1) {
      String ext = fileName.substring(i + 1).toLowerCase();
      type = MimeManager.getMimeType(ext);
    } 
    if (type != null)
      return type; 
    if (contentType != null)
      return contentType; 
    return "content/unknown";
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\util\ContentType.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */