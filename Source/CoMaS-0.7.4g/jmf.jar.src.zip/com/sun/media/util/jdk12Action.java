package com.sun.media.util;

import java.lang.reflect.Constructor;
import java.security.Permission;

public class jdk12Action {
  public static Constructor getCheckPermissionAction() throws NoSuchMethodException {
    return CheckPermissionAction.class.getConstructor(new Class[] { Permission.class });
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\util\jdk12Action.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */