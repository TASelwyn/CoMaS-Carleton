/*     */ package com.sun.media.util;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OptionalDataException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.media.Format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Resource
/*     */ {
/*  40 */   private static Hashtable hash = null;
/*     */ 
/*     */   
/*  43 */   private static String filename = null;
/*     */ 
/*     */   
/*     */   private static final int versionNumber = 200;
/*     */   
/*     */   private static boolean securityPrivelege = false;
/*     */   
/*  50 */   private static JMFSecurity jmfSecurity = null;
/*  51 */   private static Method[] m = new Method[1];
/*  52 */   private static Class[] cl = new Class[1];
/*  53 */   private static Object[][] args = new Object[1][0];
/*     */   private static final String USERHOME = "user.home";
/*  55 */   private static String userhome = null;
/*     */   static FormatTable audioFmtTbl;
/*     */   static FormatTable videoFmtTbl;
/*     */   static FormatTable miscFmtTbl; static Object fmtTblSync; static int AUDIO_TBL_SIZE; static int VIDEO_TBL_SIZE; static int MISC_TBL_SIZE; static String AUDIO_SIZE_KEY; static String AUDIO_INPUT_KEY; static String AUDIO_FORMAT_KEY; static String AUDIO_HIT_KEY; static String VIDEO_SIZE_KEY; static String VIDEO_INPUT_KEY; static String VIDEO_FORMAT_KEY; static String VIDEO_HIT_KEY; static String MISC_SIZE_KEY; static String MISC_INPUT_KEY; static String MISC_FORMAT_KEY; static String MISC_HIT_KEY; static boolean needSaving; public static final synchronized void reset() { hash = new Hashtable(); } public static final synchronized boolean set(String key, Object value) { if (key != null && value != null) {
/*     */       if (jmfSecurity != null && key.indexOf("secure.") == 0)
/*     */         return false;  hash.put(key, value); return true;
/*     */     }  return false; } public static final synchronized Object get(String key) { if (key != null)
/*  62 */       return hash.get(key);  return null; } static { hash = new Hashtable();
/*     */     
/*     */     try {
/*  65 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  66 */       securityPrivelege = true;
/*  67 */     } catch (SecurityException e) {}
/*     */ 
/*     */     
/*  70 */     if (jmfSecurity != null) {
/*  71 */       String permission = null;
/*     */       try {
/*  73 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  74 */           permission = "read property";
/*  75 */           jmfSecurity.requestPermission(m, cl, args, 1);
/*  76 */           m[0].invoke(cl[0], args[0]);
/*     */ 
/*     */           
/*  79 */           permission = "read file";
/*  80 */           jmfSecurity.requestPermission(m, cl, args, 2);
/*  81 */           m[0].invoke(cl[0], args[0]);
/*  82 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/*  83 */           PolicyEngine.checkPermission(PermissionID.PROPERTY);
/*  84 */           PolicyEngine.checkPermission(PermissionID.FILEIO);
/*  85 */           PolicyEngine.assertPermission(PermissionID.PROPERTY);
/*  86 */           PolicyEngine.assertPermission(PermissionID.FILEIO);
/*     */         }
/*     */       
/*  89 */       } catch (Throwable e) {
/*     */ 
/*     */ 
/*     */         
/*  93 */         securityPrivelege = false;
/*     */       } 
/*     */     } 
/*     */     
/*  97 */     if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*     */       try {
/*  99 */         Constructor cons = jdk12PropertyAction.cons;
/* 100 */         userhome = (String)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { "user.home" }) });
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */       catch (Throwable e) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 110 */         securityPrivelege = false;
/*     */       } 
/*     */     } else {
/*     */       try {
/* 114 */         if (securityPrivelege)
/* 115 */           userhome = System.getProperty("user.home"); 
/*     */       } catch (Exception e) {
/* 117 */         userhome = null;
/* 118 */         securityPrivelege = false;
/*     */       } 
/*     */     } 
/*     */     
/* 122 */     if (userhome == null) {
/* 123 */       securityPrivelege = false;
/*     */     }
/* 125 */     InputStream is = null;
/*     */     
/* 127 */     if (securityPrivelege) {
/* 128 */       is = findResourceFile();
/* 129 */       if (is == null) {
/* 130 */         securityPrivelege = false;
/*     */       }
/*     */     } 
/*     */     
/* 134 */     if (!readResource(is)) {
/* 135 */       hash = new Hashtable();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 376 */     fmtTblSync = new Object();
/*     */     
/* 378 */     AUDIO_TBL_SIZE = 40;
/* 379 */     VIDEO_TBL_SIZE = 20;
/* 380 */     MISC_TBL_SIZE = 10;
/*     */     
/* 382 */     AUDIO_SIZE_KEY = "ATS";
/* 383 */     AUDIO_INPUT_KEY = "AI.";
/* 384 */     AUDIO_FORMAT_KEY = "AF.";
/* 385 */     AUDIO_HIT_KEY = "AH.";
/* 386 */     VIDEO_SIZE_KEY = "VTS";
/* 387 */     VIDEO_INPUT_KEY = "VI.";
/* 388 */     VIDEO_FORMAT_KEY = "VF.";
/* 389 */     VIDEO_HIT_KEY = "VH.";
/* 390 */     MISC_SIZE_KEY = "MTS";
/* 391 */     MISC_INPUT_KEY = "MI.";
/* 392 */     MISC_FORMAT_KEY = "MF.";
/* 393 */     MISC_HIT_KEY = "MH.";
/*     */     
/* 395 */     needSaving = false; }
/*     */   public static final synchronized boolean remove(String key) { if (key != null && hash.containsKey(key)) { hash.remove(key); return true; }  return false; }
/*     */   public static final synchronized void removeGroup(String keyStart) { Vector keys = new Vector(); if (keyStart != null) { Enumeration e = hash.keys(); while (e.hasMoreElements()) { String key = e.nextElement(); if (key.startsWith(keyStart))
/*     */           keys.addElement(key);  }
/*     */        }
/*     */      for (int i = 0; i < keys.size(); i++)
/* 401 */       hash.remove(keys.elementAt(i));  } static final void initDB() { synchronized (fmtTblSync) {
/* 402 */       audioFmtTbl = new FormatTable(AUDIO_TBL_SIZE);
/* 403 */       videoFmtTbl = new FormatTable(VIDEO_TBL_SIZE);
/* 404 */       miscFmtTbl = new FormatTable(MISC_TBL_SIZE);
/* 405 */       loadDB();
/*     */     }  } public static final synchronized boolean commit() throws IOException { if (filename == null)
/*     */       throw new IOException("Can't find resource file");  FileOutputStream fos = new FileOutputStream(filename); ObjectOutputStream oos = new ObjectOutputStream(fos); int tableSize = hash.size(); oos.writeInt(tableSize); oos.writeInt(200); for (Enumeration e = hash.keys(); e.hasMoreElements(); ) { String key = e.nextElement(); Object value = hash.get(key); oos.writeUTF(key); oos.writeObject(value); oos.flush(); }
/*     */      oos.close(); return true; }
/*     */   public static final synchronized void destroy() { if (filename == null)
/*     */       return;  try { File file = new File(filename); file.delete(); }
/*     */     catch (Throwable t)
/*     */     { filename = null; }
/*     */      }
/* 414 */   public static final void purgeDB() { synchronized (fmtTblSync) {
/* 415 */       if (audioFmtTbl == null)
/*     */         return; 
/* 417 */       audioFmtTbl = new FormatTable(AUDIO_TBL_SIZE);
/* 418 */       videoFmtTbl = new FormatTable(VIDEO_TBL_SIZE);
/* 419 */       miscFmtTbl = new FormatTable(MISC_TBL_SIZE);
/*     */     }  } private static final synchronized InputStream findResourceFile() { String strJMF = ".jmf-resource"; File file = null; InputStream ris = null; if (userhome == null)
/*     */       return null;  try {
/*     */       filename = userhome + File.separator + strJMF;
/*     */       file = new File(filename);
/*     */       ris = getResourceStream(file);
/*     */     } catch (Throwable t) {
/*     */       filename = null;
/*     */       return null;
/*     */     } 
/*     */     return ris; }
/* 430 */   public static final Format[] getDB(Format input) { synchronized (fmtTblSync) {
/*     */       
/* 432 */       if (audioFmtTbl == null) {
/* 433 */         initDB();
/*     */       }
/* 435 */       if (input instanceof javax.media.format.AudioFormat)
/* 436 */         return audioFmtTbl.get(input); 
/* 437 */       if (input instanceof javax.media.format.VideoFormat) {
/* 438 */         return videoFmtTbl.get(input);
/*     */       }
/* 440 */       return miscFmtTbl.get(input);
/*     */     }  } private static final FileInputStream getResourceStream(File file) throws IOException { try {
/*     */       if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*     */         Constructor cons = jdk12ReadFileAction.cons; return (FileInputStream)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { file.getPath() }) });
/*     */       }  if (!file.exists())
/*     */         return null; 
/*     */       return new FileInputStream(file.getPath());
/*     */     } catch (Throwable t) {
/*     */       return null;
/*     */     }  }
/* 450 */   public static final Format[] putDB(Format input, Format[] supported) { synchronized (fmtTblSync)
/*     */     
/* 452 */     { Format in = input.relax();
/* 453 */       Format[] list = new Format[supported.length];
/* 454 */       for (int i = 0; i < supported.length; i++) {
/* 455 */         list[i] = supported[i].relax();
/*     */       }
/* 457 */       if (in instanceof javax.media.format.AudioFormat) {
/* 458 */         audioFmtTbl.save(in, list);
/* 459 */       } else if (in instanceof javax.media.format.VideoFormat) {
/* 460 */         videoFmtTbl.save(in, list);
/*     */       } else {
/* 462 */         miscFmtTbl.save(in, list);
/*     */       } 
/* 464 */       needSaving = true;
/*     */       
/* 466 */       return list; }  } private static final synchronized boolean readResource(InputStream ris) { if (ris == null)
/*     */       return false;  try { ObjectInputStream ois = new ObjectInputStream(ris); int tableSize = ois.readInt(); int version = ois.readInt(); if (version > 200)
/*     */         System.err.println("Version number mismatch.\nThere could be errors in reading the resource");  hash = new Hashtable(); for (int i = 0; i < tableSize; i++) { String key = ois.readUTF(); boolean failed = false; try { Object value = ois.readObject(); hash.put(key, value); }
/*     */         catch (ClassNotFoundException cnfe) { failed = true; }
/*     */         catch (OptionalDataException ode) { failed = true; }
/*     */          }
/*     */        ois.close(); ris.close(); }
/*     */     catch (IOException ioe) { System.err.println("IOException in readResource: " + ioe); return false; }
/*     */     catch (Throwable t) { return false; }
/*     */      return true; }
/* 476 */   private static final void loadDB() { synchronized (fmtTblSync) {
/*     */       int j;
/*     */ 
/*     */ 
/*     */       
/* 481 */       Object key = get(AUDIO_SIZE_KEY);
/* 482 */       if (key instanceof Integer) {
/* 483 */         j = ((Integer)key).intValue();
/*     */       } else {
/* 485 */         j = 0;
/* 486 */       }  if (j > AUDIO_TBL_SIZE) {
/*     */         
/* 488 */         System.err.println("Resource file is corrupted");
/* 489 */         j = AUDIO_TBL_SIZE;
/*     */       } 
/*     */       
/* 492 */       audioFmtTbl.last = j; int i;
/* 493 */       for (i = 0; i < j; i++) {
/* 494 */         key = get(AUDIO_INPUT_KEY + i);
/* 495 */         Object value = get(AUDIO_FORMAT_KEY + i);
/* 496 */         Object hit = get(AUDIO_HIT_KEY + i);
/* 497 */         if (key instanceof Format && value instanceof Format[] && hit instanceof Integer) {
/*     */           
/* 499 */           audioFmtTbl.keys[i] = (Format)key;
/* 500 */           audioFmtTbl.table[i] = (Format[])value;
/* 501 */           audioFmtTbl.hits[i] = ((Integer)hit).intValue();
/*     */         } else {
/* 503 */           System.err.println("Resource file is corrupted");
/* 504 */           audioFmtTbl.last = 0;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 509 */       key = get(VIDEO_SIZE_KEY);
/* 510 */       if (key instanceof Integer) {
/* 511 */         j = ((Integer)key).intValue();
/*     */       } else {
/* 513 */         j = 0;
/* 514 */       }  if (j > VIDEO_TBL_SIZE) {
/*     */         
/* 516 */         System.err.println("Resource file is corrupted");
/* 517 */         j = VIDEO_TBL_SIZE;
/*     */       } 
/*     */       
/* 520 */       videoFmtTbl.last = j;
/* 521 */       for (i = 0; i < j; i++) {
/* 522 */         key = get(VIDEO_INPUT_KEY + i);
/* 523 */         Object object1 = get(VIDEO_FORMAT_KEY + i);
/* 524 */         Object object2 = get(VIDEO_HIT_KEY + i);
/* 525 */         if (key instanceof Format && object1 instanceof Format[] && object2 instanceof Integer) {
/*     */           
/* 527 */           videoFmtTbl.keys[i] = (Format)key;
/* 528 */           videoFmtTbl.table[i] = (Format[])object1;
/* 529 */           videoFmtTbl.hits[i] = ((Integer)object2).intValue();
/*     */         } else {
/* 531 */           System.err.println("Resource file is corrupted");
/* 532 */           videoFmtTbl.last = 0;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 537 */       key = get(MISC_SIZE_KEY);
/* 538 */       if (key instanceof Integer) {
/* 539 */         j = ((Integer)key).intValue();
/*     */       } else {
/* 541 */         j = 0;
/* 542 */       }  if (j > MISC_TBL_SIZE) {
/*     */         
/* 544 */         System.err.println("Resource file is corrupted");
/* 545 */         j = MISC_TBL_SIZE;
/*     */       } 
/*     */       
/* 548 */       miscFmtTbl.last = j;
/* 549 */       for (i = 0; i < j; i++) {
/* 550 */         key = get(MISC_INPUT_KEY + i);
/* 551 */         Object object1 = get(MISC_FORMAT_KEY + i);
/* 552 */         Object object2 = get(MISC_HIT_KEY + i);
/* 553 */         if (key instanceof Format && object1 instanceof Format[] && object2 instanceof Integer) {
/*     */           
/* 555 */           miscFmtTbl.keys[i] = (Format)key;
/* 556 */           miscFmtTbl.table[i] = (Format[])object1;
/* 557 */           miscFmtTbl.hits[i] = ((Integer)object2).intValue();
/*     */         } else {
/* 559 */           System.err.println("Resource file is corrupted");
/* 560 */           miscFmtTbl.last = 0;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }  }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void saveDB() {
/* 574 */     synchronized (fmtTblSync) {
/*     */       
/* 576 */       if (!needSaving) {
/*     */         return;
/*     */       }
/* 579 */       reset();
/*     */ 
/*     */       
/* 582 */       set(AUDIO_SIZE_KEY, new Integer(audioFmtTbl.last)); int i;
/* 583 */       for (i = 0; i < audioFmtTbl.last; i++) {
/* 584 */         set(AUDIO_INPUT_KEY + i, audioFmtTbl.keys[i]);
/* 585 */         set(AUDIO_FORMAT_KEY + i, audioFmtTbl.table[i]);
/* 586 */         set(AUDIO_HIT_KEY + i, new Integer(audioFmtTbl.hits[i]));
/*     */       } 
/* 588 */       set(VIDEO_SIZE_KEY, new Integer(videoFmtTbl.last));
/* 589 */       for (i = 0; i < videoFmtTbl.last; i++) {
/* 590 */         set(VIDEO_INPUT_KEY + i, videoFmtTbl.keys[i]);
/* 591 */         set(VIDEO_FORMAT_KEY + i, videoFmtTbl.table[i]);
/* 592 */         set(VIDEO_HIT_KEY + i, new Integer(videoFmtTbl.hits[i]));
/*     */       } 
/* 594 */       set(MISC_SIZE_KEY, new Integer(miscFmtTbl.last));
/* 595 */       for (i = 0; i < miscFmtTbl.last; i++) {
/* 596 */         set(MISC_INPUT_KEY + i, miscFmtTbl.keys[i]);
/* 597 */         set(MISC_FORMAT_KEY + i, miscFmtTbl.table[i]);
/* 598 */         set(MISC_HIT_KEY + i, new Integer(miscFmtTbl.hits[i]));
/*     */       } 
/*     */       
/*     */       try {
/* 602 */         commit();
/* 603 */       } catch (Throwable e) {}
/*     */ 
/*     */ 
/*     */       
/* 607 */       needSaving = false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\util\Resource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */