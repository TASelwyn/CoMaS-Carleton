/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.security.AccessController;
/*    */ import java.security.Permission;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CheckPermissionAction
/*    */   implements PrivilegedAction
/*    */ {
/*    */   private Permission permission;
/*    */   
/*    */   public CheckPermissionAction(Permission p) {
/* 26 */     this.permission = p;
/*    */   }
/*    */   
/*    */   public Object run() {
/* 30 */     AccessController.checkPermission(this.permission);
/* 31 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\util\CheckPermissionAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */