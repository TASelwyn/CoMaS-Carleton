package com.sun.media.util;

import java.security.AccessController;
import java.security.Permission;
import java.security.PrivilegedAction;

class CheckPermissionAction implements PrivilegedAction {
  private Permission permission;
  
  public CheckPermissionAction(Permission p) {
    this.permission = p;
  }
  
  public Object run() {
    AccessController.checkPermission(this.permission);
    return null;
  }
}
