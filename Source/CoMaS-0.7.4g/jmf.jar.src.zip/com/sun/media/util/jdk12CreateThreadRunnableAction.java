/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class jdk12CreateThreadRunnableAction
/*    */   implements PrivilegedAction
/*    */ {
/*    */   private Class threadclass;
/*    */   private Runnable runnable;
/* 19 */   private String name = null;
/*    */   
/*    */   public static Constructor cons;
/*    */   public static Constructor conswithname;
/*    */   
/*    */   static {
/*    */     try {
/* 26 */       cons = jdk12CreateThreadRunnableAction.class.getConstructor(new Class[] { Class.class, Runnable.class });
/*    */       
/* 28 */       conswithname = jdk12CreateThreadRunnableAction.class.getConstructor(new Class[] { Class.class, Runnable.class, String.class });
/*    */     }
/* 30 */     catch (Throwable e) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public jdk12CreateThreadRunnableAction(Class threadclass, Runnable run, String name) {
/*    */     try {
/* 38 */       this.threadclass = threadclass;
/* 39 */       this.runnable = run;
/* 40 */       this.name = name;
/* 41 */     } catch (Throwable e) {}
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public jdk12CreateThreadRunnableAction(Class threadclass, Runnable run) {
/* 47 */     this(threadclass, run, null);
/*    */   }
/*    */   
/*    */   public Object run() {
/*    */     try {
/* 52 */       Constructor cons = this.threadclass.getConstructor(new Class[] { Runnable.class });
/*    */       
/* 54 */       Object object = cons.newInstance(new Object[] { this.runnable });
/* 55 */       if (this.name != null) {
/* 56 */         ((Thread)object).setName(this.name);
/*    */       }
/* 58 */       return object;
/*    */     } catch (Throwable e) {
/* 60 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\util\jdk12CreateThreadRunnableAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */