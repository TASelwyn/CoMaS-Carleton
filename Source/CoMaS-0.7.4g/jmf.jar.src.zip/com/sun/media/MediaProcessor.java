/*     */ package com.sun.media;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.io.IOException;
/*     */ import javax.media.GainControl;
/*     */ import javax.media.IncompatibleSourceException;
/*     */ import javax.media.NotConfiguredError;
/*     */ import javax.media.NotRealizedError;
/*     */ import javax.media.Time;
/*     */ import javax.media.TimeBase;
/*     */ import javax.media.control.TrackControl;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.DataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MediaProcessor
/*     */   extends BasicProcessor
/*     */ {
/*  26 */   protected ProcessEngine engine = new ProcessEngine(this);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
/*  32 */     this.engine.setSource(source);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  37 */     manageController(this.engine);
/*     */     
/*  39 */     super.setSource(source);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getVisualComponent() {
/*  50 */     super.getVisualComponent();
/*  51 */     return this.engine.getVisualComponent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GainControl getGainControl() {
/*  58 */     super.getGainControl();
/*  59 */     return this.engine.getGainControl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Time getMediaTime() {
/*  70 */     if (this.controllerList.size() > 1) {
/*  71 */       return super.getMediaTime();
/*     */     }
/*  73 */     return this.engine.getMediaTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMediaNanoseconds() {
/*  81 */     if (this.controllerList.size() > 1) {
/*  82 */       return super.getMediaNanoseconds();
/*     */     }
/*  84 */     return this.engine.getMediaNanoseconds();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TimeBase getMasterTimeBase() {
/*  91 */     return this.engine.getTimeBase();
/*     */   }
/*     */   
/*     */   protected boolean audioEnabled() {
/*  95 */     return this.engine.audioEnabled();
/*     */   }
/*     */   
/*     */   protected boolean videoEnabled() {
/*  99 */     return this.engine.videoEnabled();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TrackControl[] getTrackControls() throws NotConfiguredError {
/* 107 */     return this.engine.getTrackControls();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContentDescriptor[] getSupportedContentDescriptors() throws NotConfiguredError {
/* 115 */     return this.engine.getSupportedContentDescriptors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContentDescriptor setContentDescriptor(ContentDescriptor ocd) throws NotConfiguredError {
/* 123 */     return this.engine.setContentDescriptor(ocd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContentDescriptor getContentDescriptor() throws NotConfiguredError {
/* 131 */     return this.engine.getContentDescriptor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataSource getDataOutput() throws NotRealizedError {
/* 138 */     return this.engine.getDataOutput();
/*     */   }
/*     */   
/*     */   public void updateStats() {
/* 142 */     this.engine.updateRates();
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\MediaProcessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */