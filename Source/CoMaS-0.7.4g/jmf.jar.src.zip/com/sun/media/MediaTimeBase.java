package com.sun.media;

import javax.media.SystemTimeBase;
import javax.media.Time;
import javax.media.TimeBase;

public abstract class MediaTimeBase implements TimeBase {
  long origin = 0L;
  
  long offset = 0L;
  
  long time = 0L;
  
  TimeBase systemTimeBase = null;
  
  public MediaTimeBase() {
    mediaStopped();
  }
  
  public Time getTime() {
    return new Time(getNanoseconds());
  }
  
  public synchronized long getNanoseconds() {
    if (this.systemTimeBase != null) {
      this.time = this.origin + this.systemTimeBase.getNanoseconds() - this.offset;
    } else {
      this.time = this.origin + getMediaTime() - this.offset;
    } 
    return this.time;
  }
  
  public abstract long getMediaTime();
  
  public synchronized void mediaStarted() {
    this.systemTimeBase = null;
    this.offset = getMediaTime();
    this.origin = this.time;
  }
  
  public synchronized void mediaStopped() {
    this.systemTimeBase = (TimeBase)new SystemTimeBase();
    this.offset = this.systemTimeBase.getNanoseconds();
    this.origin = this.time;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\MediaTimeBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */