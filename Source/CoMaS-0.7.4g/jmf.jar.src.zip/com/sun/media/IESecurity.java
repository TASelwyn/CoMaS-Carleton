/*     */ package com.sun.media;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IESecurity
/*     */   implements JMFSecurity
/*     */ {
/*     */   public static JMFSecurity security;
/*     */   public static boolean jview = false;
/*  42 */   private static Class cls = null;
/*  43 */   private static Method dummyMethodRef = null;
/*     */   
/*     */   public static final boolean DEBUG = false;
/*     */   
/*     */   static {
/*  48 */     security = new IESecurity();
/*  49 */     cls = security.getClass();
/*     */     try {
/*  51 */       dummyMethodRef = cls.getMethod("dummyMethod", new Class[0]);
/*  52 */     } catch (Exception e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  61 */     return "internetexplorer";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dummyMethod() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void requestPermission(Method[] m, Class[] c, Object[][] args, int request) throws SecurityException {
/*  76 */     m[0] = dummyMethodRef;
/*  77 */     c[0] = cls;
/*  78 */     args[0] = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void requestPermission(Method[] m, Class[] c, Object[][] args, int request, String parameter) throws SecurityException {
/*  86 */     requestPermission(m, c, args, request);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLinkPermissionEnabled() {
/*  91 */     return jview;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void permissionFailureNotification(int permission) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadLibrary(String name) throws UnsatisfiedLinkError {
/*     */     try {
/*     */       try {
/* 106 */         if (!jview) {
/* 107 */           PolicyEngine.assertPermission(PermissionID.SYSTEM);
/*     */         }
/* 109 */       } catch (Throwable t) {}
/*     */ 
/*     */       
/* 112 */       System.loadLibrary(name);
/*     */     }
/* 114 */     catch (Exception e) {
/*     */       
/* 116 */       throw new UnsatisfiedLinkError("Unable to get link privilege to " + name);
/*     */     }
/* 118 */     catch (Error e) {
/*     */       
/* 120 */       throw new UnsatisfiedLinkError("Unable to get link privilege to " + name);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\IESecurity.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */