/*    */ package com.sun.media.controls;
/*    */ 
/*    */ import com.sun.media.ui.SliderComp;
/*    */ import java.awt.Component;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.media.control.QualityControl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QualityAdapter
/*    */   implements QualityControl, ActionListener
/*    */ {
/*    */   protected float preferredValue;
/*    */   protected float minValue;
/*    */   protected float maxValue;
/*    */   protected float value;
/*    */   protected boolean settable;
/*    */   protected boolean isTSsupported;
/* 23 */   protected SliderComp sliderComp = null;
/* 24 */   private float scale = 100.0F;
/*    */ 
/*    */   
/*    */   public QualityAdapter(float preferred, float min, float max, boolean settable) {
/* 28 */     this(preferred, min, max, false, settable);
/*    */   }
/*    */ 
/*    */   
/*    */   public QualityAdapter(float preferred, float min, float max, boolean isTSsupported, boolean settable) {
/* 33 */     this.preferredValue = preferred;
/* 34 */     this.minValue = min;
/* 35 */     this.maxValue = max;
/* 36 */     this.value = preferred;
/* 37 */     this.settable = settable;
/* 38 */     this.isTSsupported = isTSsupported;
/*    */   }
/*    */   
/*    */   public float getQuality() {
/* 42 */     return this.value;
/*    */   }
/*    */   
/*    */   public float setQuality(float newValue) {
/* 46 */     if (newValue < this.minValue) {
/* 47 */       newValue = this.minValue;
/* 48 */     } else if (newValue > this.maxValue) {
/* 49 */       newValue = this.maxValue;
/*    */     } 
/*    */     
/* 52 */     this.value = newValue;
/* 53 */     if (this.sliderComp != null) {
/* 54 */       this.sliderComp.setValue(this.value * this.scale);
/*    */     }
/*    */ 
/*    */     
/* 58 */     if (this.settable) {
/* 59 */       return this.value;
/*    */     }
/* 61 */     return -1.0F;
/*    */   }
/*    */   
/*    */   public float getPreferredQuality() {
/* 65 */     return this.preferredValue;
/*    */   }
/*    */   
/*    */   public boolean isTemporalSpatialTradeoffSupported() {
/* 69 */     return this.isTSsupported;
/*    */   }
/*    */   
/*    */   protected String getName() {
/* 73 */     return "Quality";
/*    */   }
/*    */   
/*    */   public Component getControlComponent() {
/* 77 */     if (this.sliderComp == null) {
/*    */       
/* 79 */       this.sliderComp = new SliderComp(getName(), this.minValue * this.scale, this.maxValue * this.scale, this.value * this.scale);
/*    */ 
/*    */ 
/*    */       
/* 83 */       this.sliderComp.setActionListener(this);
/*    */     } 
/* 85 */     return (Component)this.sliderComp;
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent ae) {
/* 89 */     float newValue = this.sliderComp.getFloatValue() / this.scale;
/* 90 */     setQuality(newValue);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\controls\QualityAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */