/*    */ package com.sun.media.controls;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import javax.media.Control;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringControlAdapter
/*    */   extends AtomicControlAdapter
/*    */   implements StringControl
/*    */ {
/*    */   String value;
/*    */   String title;
/*    */   
/*    */   public StringControlAdapter() {
/* 20 */     super(null, true, null);
/*    */   }
/*    */   
/*    */   public StringControlAdapter(Component c, boolean def, Control parent) {
/* 24 */     super(c, def, parent);
/*    */   }
/*    */   
/*    */   public String setValue(String value) {
/* 28 */     this.value = value;
/* 29 */     informListeners();
/* 30 */     return value;
/*    */   }
/*    */   
/*    */   public String getValue() {
/* 34 */     return this.value;
/*    */   }
/*    */   
/*    */   public String getTitle() {
/* 38 */     return this.title;
/*    */   }
/*    */   
/*    */   public String setTitle(String title) {
/* 42 */     this.title = title;
/* 43 */     informListeners();
/* 44 */     return title;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\controls\StringControlAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */