package com.sun.media.controls;

import java.awt.Component;
import javax.media.Control;

public class StringControlAdapter extends AtomicControlAdapter implements StringControl {
  String value;
  
  String title;
  
  public StringControlAdapter() {
    super(null, true, null);
  }
  
  public StringControlAdapter(Component c, boolean def, Control parent) {
    super(c, def, parent);
  }
  
  public String setValue(String value) {
    this.value = value;
    informListeners();
    return value;
  }
  
  public String getValue() {
    return this.value;
  }
  
  public String getTitle() {
    return this.title;
  }
  
  public String setTitle(String title) {
    this.title = title;
    informListeners();
    return title;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\controls\StringControlAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */