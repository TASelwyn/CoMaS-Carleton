package com.sun.media.controls;

public interface NumericControl extends AtomicControl {
  float getLowerLimit();
  
  float getUpperLimit();
  
  float getValue();
  
  float setValue(float paramFloat);
  
  float getDefaultValue();
  
  float setDefaultValue(float paramFloat);
  
  float getGranularity();
  
  boolean isLogarithmic();
  
  float getLogarithmicBase();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\controls\NumericControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */