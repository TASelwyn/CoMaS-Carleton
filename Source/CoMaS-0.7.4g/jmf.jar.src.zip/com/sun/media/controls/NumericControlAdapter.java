/*     */ package com.sun.media.controls;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import javax.media.Control;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NumericControlAdapter
/*     */   extends AtomicControlAdapter
/*     */   implements NumericControl
/*     */ {
/*     */   protected float lowerLimit;
/*     */   protected float upperLimit;
/*     */   protected float defaultValue;
/*     */   protected float granularity;
/*     */   protected boolean logarithmic;
/*     */   
/*     */   public NumericControlAdapter() {
/*  33 */     super(null, true, null);
/*  34 */     this.lowerLimit = 0.0F;
/*  35 */     this.upperLimit = 1.0F;
/*  36 */     this.defaultValue = 0.5F;
/*  37 */     this.granularity = 0.001F;
/*  38 */     this.logarithmic = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericControlAdapter(float ll, float ul, float dv, float gran, boolean log, Component comp, boolean def, Control parent) {
/*  47 */     super(comp, def, parent);
/*  48 */     this.lowerLimit = ll;
/*  49 */     this.upperLimit = ul;
/*  50 */     this.defaultValue = dv;
/*  51 */     this.granularity = gran;
/*  52 */     this.logarithmic = log;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getLowerLimit() {
/*  59 */     return this.lowerLimit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getUpperLimit() {
/*  66 */     return this.upperLimit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getValue() {
/*  73 */     return 0.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float setValue(float value) {
/*  81 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getDefaultValue() {
/*  88 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float setDefaultValue(float value) {
/*  95 */     return this.defaultValue = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getGranularity() {
/* 102 */     return this.granularity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLogarithmic() {
/* 109 */     return this.logarithmic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getLogarithmicBase() {
/* 116 */     return 0.0F;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\controls\NumericControlAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */