package com.sun.media.controls;

import javax.media.Control;

public interface AtomicControl extends Control {
  boolean isDefault();
  
  void setVisible(boolean paramBoolean);
  
  boolean getVisible();
  
  void setEnabled(boolean paramBoolean);
  
  boolean getEnabled();
  
  Control getParent();
  
  void addControlChangeListener(ControlChangeListener paramControlChangeListener);
  
  void removeControlChangeListener(ControlChangeListener paramControlChangeListener);
  
  boolean isReadOnly();
  
  String getTip();
  
  void setTip(String paramString);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\controls\AtomicControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */