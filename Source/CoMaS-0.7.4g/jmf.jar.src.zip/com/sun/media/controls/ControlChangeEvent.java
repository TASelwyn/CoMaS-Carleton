package com.sun.media.controls;

import javax.media.Control;

public class ControlChangeEvent {
  private Control c;
  
  public ControlChangeEvent(Control c) {
    this.c = c;
  }
  
  public Control getControl() {
    return this.c;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\controls\ControlChangeEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */