/*    */ package com.sun.media.controls;
/*    */ 
/*    */ import javax.media.Control;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ControlChangeEvent
/*    */ {
/*    */   private Control c;
/*    */   
/*    */   public ControlChangeEvent(Control c) {
/* 24 */     this.c = c;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Control getControl() {
/* 31 */     return this.c;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\controls\ControlChangeEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */