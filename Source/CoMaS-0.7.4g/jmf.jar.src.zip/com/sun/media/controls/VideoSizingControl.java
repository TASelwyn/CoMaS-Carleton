package com.sun.media.controls;

import java.awt.Dimension;
import java.awt.Rectangle;
import javax.media.Control;

public interface VideoSizingControl extends Control {
  boolean supportsAnyScale();
  
  Dimension setVideoSize(Dimension paramDimension);
  
  Dimension getVideoSize();
  
  Dimension getInputVideoSize();
  
  boolean supportsZoom();
  
  float[] getValidZoomFactors();
  
  NumericControl getZoomControl();
  
  boolean supportsClipping();
  
  Rectangle setClipRegion(Rectangle paramRectangle);
  
  Rectangle getClipRegion();
  
  BooleanControl getVideoMute();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\controls\VideoSizingControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */