package com.sun.media.controls;

import javax.media.Control;

public class ProgressControlAdapter extends AtomicControlAdapter implements ProgressControl {
  Control[] controls = null;
  
  StringControl frc = null;
  
  StringControl brc = null;
  
  StringControl vpc = null;
  
  StringControl apc = null;
  
  StringControl ac = null;
  
  StringControl vc = null;
  
  public ProgressControlAdapter(StringControl frameRate, StringControl bitRate, StringControl videoProps, StringControl audioProps, StringControl videoCodec, StringControl audioCodec) {
    super(null, true, null);
    this.frc = frameRate;
    this.brc = bitRate;
    this.vpc = videoProps;
    this.apc = audioProps;
    this.vc = videoCodec;
    this.ac = audioCodec;
  }
  
  public StringControl getFrameRate() {
    return this.frc;
  }
  
  public StringControl getBitRate() {
    return this.brc;
  }
  
  public StringControl getAudioProperties() {
    return this.apc;
  }
  
  public StringControl getVideoProperties() {
    return this.vpc;
  }
  
  public StringControl getVideoCodec() {
    return this.vc;
  }
  
  public StringControl getAudioCodec() {
    return this.ac;
  }
  
  public Control[] getControls() {
    if (this.controls == null) {
      this.controls = new Control[6];
      this.controls[0] = this.frc;
      this.controls[1] = this.brc;
      this.controls[2] = this.vpc;
      this.controls[3] = this.apc;
      this.controls[4] = this.ac;
      this.controls[5] = this.vc;
    } 
    return this.controls;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\controls\ProgressControlAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */