package com.sun.media.controls;

import com.sun.media.util.LoopThread;

class MonitorThread extends LoopThread {
  MonitorAdapter ad;
  
  public MonitorThread(MonitorAdapter ad) {
    setName(getName() + " : MonitorAdapter");
    useVideoPriority();
    this.ad = ad;
  }
  
  protected boolean process() {
    return this.ad.doProcess();
  }
}
