package com.sun.media.controls;

public interface StringControl extends AtomicControl {
  String setValue(String paramString);
  
  String getValue();
  
  String setTitle(String paramString);
  
  String getTitle();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\controls\StringControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */