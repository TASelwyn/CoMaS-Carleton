package com.sun.media.controls;

public interface ProgressControl extends GroupControl {
  StringControl getFrameRate();
  
  StringControl getBitRate();
  
  StringControl getVideoProperties();
  
  StringControl getVideoCodec();
  
  StringControl getAudioCodec();
  
  StringControl getAudioProperties();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\controls\ProgressControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */