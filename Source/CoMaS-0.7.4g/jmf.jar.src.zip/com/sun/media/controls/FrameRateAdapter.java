/*     */ package com.sun.media.controls;
/*     */ 
/*     */ import com.sun.media.Reparentable;
/*     */ import com.sun.media.ui.TextComp;
/*     */ import java.awt.Component;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.media.control.FrameRateControl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FrameRateAdapter
/*     */   implements FrameRateControl, ActionListener, Reparentable
/*     */ {
/*  19 */   protected float value = 0.0F;
/*  20 */   protected float min = 0.0F;
/*  21 */   protected float max = 0.0F;
/*  22 */   protected TextComp textComp = null;
/*     */   protected boolean settable;
/*  24 */   protected Object owner = null;
/*     */ 
/*     */   
/*     */   public FrameRateAdapter(float initialFrameRate, float minFrameRate, float maxFrameRate, boolean settable) {
/*  28 */     this.value = initialFrameRate;
/*  29 */     this.min = minFrameRate;
/*  30 */     this.max = maxFrameRate;
/*  31 */     this.settable = settable;
/*     */   }
/*     */ 
/*     */   
/*     */   public FrameRateAdapter(Object owner, float initialFrameRate, float minFrameRate, float maxFrameRate, boolean settable) {
/*  36 */     this(initialFrameRate, minFrameRate, maxFrameRate, settable);
/*  37 */     this.owner = owner;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFrameRate() {
/*  45 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float setFrameRate(float newFrameRate) {
/*  55 */     if (this.settable) {
/*  56 */       if (newFrameRate < this.min) {
/*  57 */         newFrameRate = this.min;
/*  58 */       } else if (newFrameRate > this.max) {
/*  59 */         newFrameRate = this.max;
/*     */       } 
/*  61 */       this.value = newFrameRate;
/*  62 */       if (this.textComp != null) {
/*  63 */         this.textComp.setValue(Float.toString(this.value));
/*     */       }
/*     */       
/*  66 */       return this.value;
/*     */     } 
/*  68 */     return -1.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMaxSupportedFrameRate() {
/*  76 */     return this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getPreferredFrameRate() {
/*  84 */     return this.min;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getName() {
/*  89 */     return "Frame Rate";
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enable) {
/*  93 */     if (this.textComp != null)
/*  94 */       this.textComp.setEnabled(enable); 
/*     */   }
/*     */   
/*     */   public Component getControlComponent() {
/*  98 */     if (this.textComp == null) {
/*  99 */       this.textComp = new TextComp(getName(), this.value + "", 2, this.settable);
/* 100 */       this.textComp.setActionListener(this);
/*     */     } 
/* 102 */     return (Component)this.textComp;
/*     */   }
/*     */   
/*     */   public void actionPerformed(ActionEvent ae) {
/* 106 */     System.out.println("fra:");
/* 107 */     float newFrameRate = this.textComp.getFloatValue();
/* 108 */     setFrameRate(newFrameRate);
/*     */   }
/*     */   
/*     */   public Object getOwner() {
/* 112 */     if (this.owner == null) {
/* 113 */       return this;
/*     */     }
/* 115 */     return this.owner;
/*     */   }
/*     */   
/*     */   public void setOwner(Object newOwner) {
/* 119 */     this.owner = newOwner;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\controls\FrameRateAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */