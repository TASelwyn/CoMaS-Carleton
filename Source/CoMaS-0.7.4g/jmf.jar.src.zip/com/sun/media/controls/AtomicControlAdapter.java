/*     */ package com.sun.media.controls;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.util.Vector;
/*     */ import javax.media.Control;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AtomicControlAdapter
/*     */   implements AtomicControl
/*     */ {
/*  26 */   protected Component component = null;
/*  27 */   private Vector listeners = null;
/*     */   protected boolean isdefault = false;
/*  29 */   protected Control parent = null;
/*     */ 
/*     */   
/*     */   protected boolean enabled = true;
/*     */ 
/*     */ 
/*     */   
/*     */   public AtomicControlAdapter(Component c, boolean def, Control parent) {
/*  37 */     this.component = c;
/*  38 */     this.isdefault = def;
/*  39 */     this.parent = parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefault() {
/*  51 */     return this.isdefault;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVisible(boolean visible) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getVisible() {
/*  66 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/*  74 */     this.enabled = enabled;
/*  75 */     if (this.component != null)
/*  76 */       this.component.setEnabled(enabled); 
/*  77 */     informListeners();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getEnabled() {
/*  84 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setParent(Control p) {
/*  88 */     this.parent = p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Control getParent() {
/*  96 */     return this.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addControlChangeListener(ControlChangeListener ccl) {
/* 104 */     if (this.listeners == null) {
/* 105 */       this.listeners = new Vector();
/*     */     }
/* 107 */     if (ccl != null) {
/* 108 */       this.listeners.addElement(ccl);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeControlChangeListener(ControlChangeListener ccl) {
/* 117 */     if (this.listeners != null && ccl != null)
/* 118 */       this.listeners.removeElement(ccl); 
/*     */   }
/*     */   
/*     */   public void informListeners() {
/* 122 */     if (this.listeners != null) {
/* 123 */       for (int i = 0; i < this.listeners.size(); i++) {
/* 124 */         ControlChangeListener ccl = this.listeners.elementAt(i);
/*     */         
/* 126 */         ccl.controlChanged(new ControlChangeEvent(this));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTip() {
/* 135 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTip(String tip) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getControlComponent() {
/* 149 */     return this.component;
/*     */   }
/*     */   
/*     */   public boolean isReadOnly() {
/* 153 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\controls\AtomicControlAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */