package com.sun.media.controls;

public interface ActionControl extends AtomicControl {
  boolean performAction();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\controls\ActionControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */