/*    */ package com.sun.media.controls;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import javax.media.Control;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BooleanControlAdapter
/*    */   extends AtomicControlAdapter
/*    */   implements BooleanControl
/*    */ {
/*    */   public BooleanControlAdapter() {
/* 20 */     super(null, false, null);
/*    */   }
/*    */   
/*    */   public BooleanControlAdapter(Component c, boolean def, Control parent) {
/* 24 */     super(c, def, parent);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean setValue(boolean val) {
/* 29 */     return val;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean getValue() {
/* 34 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\controls\BooleanControlAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */