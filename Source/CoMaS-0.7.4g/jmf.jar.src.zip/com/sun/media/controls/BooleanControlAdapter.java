package com.sun.media.controls;

import java.awt.Component;
import javax.media.Control;

public class BooleanControlAdapter extends AtomicControlAdapter implements BooleanControl {
  public BooleanControlAdapter() {
    super(null, false, null);
  }
  
  public BooleanControlAdapter(Component c, boolean def, Control parent) {
    super(c, def, parent);
  }
  
  public boolean setValue(boolean val) {
    return val;
  }
  
  public boolean getValue() {
    return false;
  }
}
