package com.sun.media.controls;

import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.Component;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.lang.reflect.Method;
import javax.media.Codec;
import javax.media.control.H263Control;

public class H263Adapter implements H263Control {
  boolean isSetable;
  
  Codec owner = null;
  
  boolean advancedPrediction = false;
  
  boolean arithmeticCoding = false;
  
  boolean errorCompensation = false;
  
  boolean pbFrames = false;
  
  boolean unrestrictedVector = false;
  
  int hrd_B = -1;
  
  int bppMaxKb = -1;
  
  Component component = null;
  
  String CONTROL_ADVANCEDPREDICTION_STRING = "Advanced Prediction";
  
  String CONTROL_ARITHMETICCODING_STRING = "Arithmetic Coding";
  
  String CONTROL_ERRORCOMPENSATION_STRING = "Error Compensation";
  
  String CONTROL_PBFRAMES_STRING = "PB Frames";
  
  String CONTROL_UNRESTRICTEDVECTOR_STRING = "Unrestricted Vector";
  
  String CONTROL_HRD_B_STRING = "Hrd B";
  
  String CONTROL_BPPMAXKB_STRING = "Bpp Max Kb";
  
  public H263Adapter(Codec newOwner, boolean newAdvancedPrediction, boolean newArithmeticCoding, boolean newErrorCompensation, boolean newPBFrames, boolean newUnrestrictedVector, int newHrd_B, int newBppMaxKb, boolean newIsSetable) {
    this.advancedPrediction = newAdvancedPrediction;
    this.arithmeticCoding = newArithmeticCoding;
    this.errorCompensation = newErrorCompensation;
    this.pbFrames = newPBFrames;
    this.unrestrictedVector = newUnrestrictedVector;
    this.hrd_B = newHrd_B;
    this.bppMaxKb = newBppMaxKb;
    this.owner = newOwner;
    this.isSetable = newIsSetable;
  }
  
  public boolean isUnrestrictedVectorSupported() {
    return this.unrestrictedVector;
  }
  
  public boolean setUnrestrictedVector(boolean newUnrestrictedVectorMode) {
    return this.unrestrictedVector;
  }
  
  public boolean getUnrestrictedVector() {
    return this.unrestrictedVector;
  }
  
  public boolean isArithmeticCodingSupported() {
    return this.arithmeticCoding;
  }
  
  public boolean setArithmeticCoding(boolean newArithmeticCodingMode) {
    return this.arithmeticCoding;
  }
  
  public boolean getArithmeticCoding() {
    return this.arithmeticCoding;
  }
  
  public boolean isAdvancedPredictionSupported() {
    return this.advancedPrediction;
  }
  
  public boolean setAdvancedPrediction(boolean newAdvancedPredictionMode) {
    return this.advancedPrediction;
  }
  
  public boolean getAdvancedPrediction() {
    return this.advancedPrediction;
  }
  
  public boolean isPBFramesSupported() {
    return this.pbFrames;
  }
  
  public boolean setPBFrames(boolean newPBFramesMode) {
    return this.pbFrames;
  }
  
  public boolean getPBFrames() {
    return this.pbFrames;
  }
  
  public boolean isErrorCompensationSupported() {
    return this.errorCompensation;
  }
  
  public boolean setErrorCompensation(boolean newtErrorCompensationMode) {
    return this.errorCompensation;
  }
  
  public boolean getErrorCompensation() {
    return this.errorCompensation;
  }
  
  public int getHRD_B() {
    return this.hrd_B;
  }
  
  public int getBppMaxKb() {
    return this.bppMaxKb;
  }
  
  public Component getControlComponent() {
    if (this.component == null)
      try {
        Class[] booleanArray = { boolean.class };
        Panel componentPanel = new Panel();
        componentPanel.setLayout(new VFlowLayout(1));
        Panel tempPanel = new Panel();
        tempPanel.setLayout(new BorderLayout());
        tempPanel.add("Center", new Label(this.CONTROL_ADVANCEDPREDICTION_STRING, 1));
        Checkbox cb = new Checkbox(null, null, this.advancedPrediction);
        cb.setEnabled(this.isSetable);
        cb.addItemListener(new H263AdapterListener(this, cb, this, getClass().getMethod("setAdvancedPrediction", booleanArray)));
        tempPanel.add("East", cb);
        tempPanel.invalidate();
        componentPanel.add(tempPanel);
        tempPanel = new Panel();
        tempPanel.setLayout(new BorderLayout());
        tempPanel.add("Center", new Label(this.CONTROL_ARITHMETICCODING_STRING, 1));
        cb = new Checkbox(null, null, this.arithmeticCoding);
        cb.setEnabled(this.isSetable);
        cb.addItemListener(new H263AdapterListener(this, cb, this, getClass().getMethod("setArithmeticCoding", booleanArray)));
        tempPanel.add("East", cb);
        tempPanel.invalidate();
        componentPanel.add(tempPanel);
        tempPanel = new Panel();
        tempPanel.setLayout(new BorderLayout());
        tempPanel.add("Center", new Label(this.CONTROL_ERRORCOMPENSATION_STRING, 1));
        cb = new Checkbox(null, null, this.errorCompensation);
        cb.setEnabled(this.isSetable);
        cb.addItemListener(new H263AdapterListener(this, cb, this, getClass().getMethod("setErrorCompensation", booleanArray)));
        tempPanel.add("East", cb);
        tempPanel.invalidate();
        componentPanel.add(tempPanel);
        tempPanel = new Panel();
        tempPanel.setLayout(new BorderLayout());
        tempPanel.add("Center", new Label(this.CONTROL_PBFRAMES_STRING, 1));
        cb = new Checkbox(null, null, this.pbFrames);
        cb.setEnabled(this.isSetable);
        cb.addItemListener(new H263AdapterListener(this, cb, this, getClass().getMethod("setPBFrames", booleanArray)));
        tempPanel.add("East", cb);
        tempPanel.invalidate();
        componentPanel.add(tempPanel);
        tempPanel = new Panel();
        tempPanel.setLayout(new BorderLayout());
        tempPanel.add("Center", new Label(this.CONTROL_UNRESTRICTEDVECTOR_STRING, 1));
        cb = new Checkbox(null, null, this.unrestrictedVector);
        cb.setEnabled(this.isSetable);
        cb.addItemListener(new H263AdapterListener(this, cb, this, getClass().getMethod("setUnrestrictedVector", booleanArray)));
        tempPanel.add("East", cb);
        tempPanel.invalidate();
        componentPanel.add(tempPanel);
        tempPanel = new Panel();
        tempPanel.setLayout(new BorderLayout());
        tempPanel.add("Center", new Label(this.CONTROL_HRD_B_STRING, 1));
        tempPanel.add("East", new Label(this.hrd_B + "", 1));
        tempPanel.invalidate();
        componentPanel.add(tempPanel);
        tempPanel = new Panel();
        tempPanel.setLayout(new BorderLayout());
        tempPanel.add("Center", new Label(this.CONTROL_BPPMAXKB_STRING, 1));
        tempPanel.add("East", new Label(this.bppMaxKb + "", 1));
        tempPanel.invalidate();
        componentPanel.add(tempPanel);
        this.component = componentPanel;
      } catch (Exception exception) {} 
    return this.component;
  }
  
  class H263AdapterListener implements ItemListener {
    Checkbox cb;
    
    Method m;
    
    H263Adapter owner;
    
    private final H263Adapter this$0;
    
    public H263AdapterListener(H263Adapter this$0, Checkbox source, H263Adapter h263adaptor, Method action) {
      this.this$0 = this$0;
      this.cb = source;
      this.m = action;
      this.owner = h263adaptor;
    }
    
    public void itemStateChanged(ItemEvent e) {
      Object result = null;
      try {
        boolean newState = this.cb.getState();
        Boolean[] operands = { newState ? Boolean.TRUE : Boolean.FALSE };
        result = this.m.invoke(this.owner, (Object[])operands);
      } catch (Exception exception) {}
      this.cb.setState(result.equals(Boolean.TRUE));
    }
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\controls\H263Adapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */