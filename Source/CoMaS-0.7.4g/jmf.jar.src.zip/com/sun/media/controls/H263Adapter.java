/*     */ package com.sun.media.controls;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Checkbox;
/*     */ import java.awt.Component;
/*     */ import java.awt.Label;
/*     */ import java.awt.Panel;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.media.Codec;
/*     */ import javax.media.control.H263Control;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class H263Adapter
/*     */   implements H263Control
/*     */ {
/*     */   boolean isSetable;
/*  21 */   Codec owner = null;
/*     */   boolean advancedPrediction = false;
/*     */   boolean arithmeticCoding = false;
/*     */   boolean errorCompensation = false;
/*     */   boolean pbFrames = false;
/*     */   boolean unrestrictedVector = false;
/*  27 */   int hrd_B = -1;
/*  28 */   int bppMaxKb = -1;
/*     */   
/*  30 */   Component component = null;
/*  31 */   String CONTROL_ADVANCEDPREDICTION_STRING = "Advanced Prediction";
/*  32 */   String CONTROL_ARITHMETICCODING_STRING = "Arithmetic Coding";
/*  33 */   String CONTROL_ERRORCOMPENSATION_STRING = "Error Compensation";
/*  34 */   String CONTROL_PBFRAMES_STRING = "PB Frames";
/*  35 */   String CONTROL_UNRESTRICTEDVECTOR_STRING = "Unrestricted Vector";
/*  36 */   String CONTROL_HRD_B_STRING = "Hrd B";
/*  37 */   String CONTROL_BPPMAXKB_STRING = "Bpp Max Kb";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public H263Adapter(Codec newOwner, boolean newAdvancedPrediction, boolean newArithmeticCoding, boolean newErrorCompensation, boolean newPBFrames, boolean newUnrestrictedVector, int newHrd_B, int newBppMaxKb, boolean newIsSetable) {
/*  52 */     this.advancedPrediction = newAdvancedPrediction;
/*  53 */     this.arithmeticCoding = newArithmeticCoding;
/*  54 */     this.errorCompensation = newErrorCompensation;
/*  55 */     this.pbFrames = newPBFrames;
/*  56 */     this.unrestrictedVector = newUnrestrictedVector;
/*  57 */     this.hrd_B = newHrd_B;
/*  58 */     this.bppMaxKb = newBppMaxKb;
/*     */     
/*  60 */     this.owner = newOwner;
/*  61 */     this.isSetable = newIsSetable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUnrestrictedVectorSupported() {
/*  70 */     return this.unrestrictedVector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setUnrestrictedVector(boolean newUnrestrictedVectorMode) {
/*  80 */     return this.unrestrictedVector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getUnrestrictedVector() {
/*  88 */     return this.unrestrictedVector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isArithmeticCodingSupported() {
/*  97 */     return this.arithmeticCoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setArithmeticCoding(boolean newArithmeticCodingMode) {
/* 108 */     return this.arithmeticCoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getArithmeticCoding() {
/* 116 */     return this.arithmeticCoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAdvancedPredictionSupported() {
/* 125 */     return this.advancedPrediction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setAdvancedPrediction(boolean newAdvancedPredictionMode) {
/* 135 */     return this.advancedPrediction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getAdvancedPrediction() {
/* 143 */     return this.advancedPrediction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPBFramesSupported() {
/* 152 */     return this.pbFrames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setPBFrames(boolean newPBFramesMode) {
/* 162 */     return this.pbFrames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getPBFrames() {
/* 170 */     return this.pbFrames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isErrorCompensationSupported() {
/* 179 */     return this.errorCompensation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setErrorCompensation(boolean newtErrorCompensationMode) {
/* 189 */     return this.errorCompensation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getErrorCompensation() {
/* 197 */     return this.errorCompensation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHRD_B() {
/* 205 */     return this.hrd_B;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBppMaxKb() {
/* 213 */     return this.bppMaxKb;
/*     */   }
/*     */   
/*     */   public Component getControlComponent() {
/* 217 */     if (this.component == null) {
/*     */       try {
/* 219 */         Class[] booleanArray = { boolean.class };
/*     */         
/* 221 */         Panel componentPanel = new Panel();
/* 222 */         componentPanel.setLayout(new VFlowLayout(1));
/*     */         
/* 224 */         Panel tempPanel = new Panel();
/* 225 */         tempPanel.setLayout(new BorderLayout());
/* 226 */         tempPanel.add("Center", new Label(this.CONTROL_ADVANCEDPREDICTION_STRING, 1));
/* 227 */         Checkbox cb = new Checkbox(null, null, this.advancedPrediction);
/* 228 */         cb.setEnabled(this.isSetable);
/* 229 */         cb.addItemListener(new H263AdapterListener(this, cb, this, getClass().getMethod("setAdvancedPrediction", booleanArray)));
/*     */ 
/*     */         
/* 232 */         tempPanel.add("East", cb);
/* 233 */         tempPanel.invalidate();
/* 234 */         componentPanel.add(tempPanel);
/*     */         
/* 236 */         tempPanel = new Panel();
/* 237 */         tempPanel.setLayout(new BorderLayout());
/* 238 */         tempPanel.add("Center", new Label(this.CONTROL_ARITHMETICCODING_STRING, 1));
/* 239 */         cb = new Checkbox(null, null, this.arithmeticCoding);
/* 240 */         cb.setEnabled(this.isSetable);
/* 241 */         cb.addItemListener(new H263AdapterListener(this, cb, this, getClass().getMethod("setArithmeticCoding", booleanArray)));
/*     */ 
/*     */         
/* 244 */         tempPanel.add("East", cb);
/* 245 */         tempPanel.invalidate();
/* 246 */         componentPanel.add(tempPanel);
/*     */         
/* 248 */         tempPanel = new Panel();
/* 249 */         tempPanel.setLayout(new BorderLayout());
/* 250 */         tempPanel.add("Center", new Label(this.CONTROL_ERRORCOMPENSATION_STRING, 1));
/* 251 */         cb = new Checkbox(null, null, this.errorCompensation);
/* 252 */         cb.setEnabled(this.isSetable);
/* 253 */         cb.addItemListener(new H263AdapterListener(this, cb, this, getClass().getMethod("setErrorCompensation", booleanArray)));
/*     */ 
/*     */         
/* 256 */         tempPanel.add("East", cb);
/* 257 */         tempPanel.invalidate();
/* 258 */         componentPanel.add(tempPanel);
/*     */         
/* 260 */         tempPanel = new Panel();
/* 261 */         tempPanel.setLayout(new BorderLayout());
/* 262 */         tempPanel.add("Center", new Label(this.CONTROL_PBFRAMES_STRING, 1));
/* 263 */         cb = new Checkbox(null, null, this.pbFrames);
/* 264 */         cb.setEnabled(this.isSetable);
/* 265 */         cb.addItemListener(new H263AdapterListener(this, cb, this, getClass().getMethod("setPBFrames", booleanArray)));
/*     */ 
/*     */         
/* 268 */         tempPanel.add("East", cb);
/* 269 */         tempPanel.invalidate();
/* 270 */         componentPanel.add(tempPanel);
/*     */         
/* 272 */         tempPanel = new Panel();
/* 273 */         tempPanel.setLayout(new BorderLayout());
/* 274 */         tempPanel.add("Center", new Label(this.CONTROL_UNRESTRICTEDVECTOR_STRING, 1));
/* 275 */         cb = new Checkbox(null, null, this.unrestrictedVector);
/* 276 */         cb.setEnabled(this.isSetable);
/* 277 */         cb.addItemListener(new H263AdapterListener(this, cb, this, getClass().getMethod("setUnrestrictedVector", booleanArray)));
/*     */ 
/*     */         
/* 280 */         tempPanel.add("East", cb);
/* 281 */         tempPanel.invalidate();
/* 282 */         componentPanel.add(tempPanel);
/*     */         
/* 284 */         tempPanel = new Panel();
/* 285 */         tempPanel.setLayout(new BorderLayout());
/* 286 */         tempPanel.add("Center", new Label(this.CONTROL_HRD_B_STRING, 1));
/* 287 */         tempPanel.add("East", new Label(this.hrd_B + "", 1));
/* 288 */         tempPanel.invalidate();
/* 289 */         componentPanel.add(tempPanel);
/*     */         
/* 291 */         tempPanel = new Panel();
/* 292 */         tempPanel.setLayout(new BorderLayout());
/* 293 */         tempPanel.add("Center", new Label(this.CONTROL_BPPMAXKB_STRING, 1));
/* 294 */         tempPanel.add("East", new Label(this.bppMaxKb + "", 1));
/* 295 */         tempPanel.invalidate();
/* 296 */         componentPanel.add(tempPanel);
/*     */         
/* 298 */         this.component = componentPanel;
/* 299 */       } catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */     
/* 303 */     return this.component;
/*     */   }
/*     */   
/*     */   class H263AdapterListener implements ItemListener {
/*     */     Checkbox cb;
/*     */     Method m;
/*     */     
/*     */     public H263AdapterListener(H263Adapter this$0, Checkbox source, H263Adapter h263adaptor, Method action) {
/* 311 */       this.this$0 = this$0;
/* 312 */       this.cb = source;
/* 313 */       this.m = action;
/* 314 */       this.owner = h263adaptor;
/*     */     }
/*     */     H263Adapter owner; private final H263Adapter this$0;
/*     */     public void itemStateChanged(ItemEvent e) {
/* 318 */       Object result = null;
/*     */       
/*     */       try {
/* 321 */         boolean newState = this.cb.getState();
/* 322 */         Boolean[] operands = { newState ? Boolean.TRUE : Boolean.FALSE };
/*     */ 
/*     */         
/* 325 */         result = this.m.invoke(this.owner, (Object[])operands);
/*     */       }
/* 327 */       catch (Exception exception) {}
/*     */ 
/*     */       
/* 330 */       this.cb.setState(result.equals(Boolean.TRUE));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\controls\H263Adapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */