package com.sun.media.controls;

import java.awt.Component;
import javax.media.control.RtspControl;
import javax.media.rtp.RTPManager;

public class RtspAdapter implements RtspControl {
  private RTPManager[] managers;
  
  private String[] mediaTypes;
  
  public void setRTPManagers(RTPManager[] managers) {
    this.managers = managers;
  }
  
  public RTPManager[] getRTPManagers() {
    return this.managers;
  }
  
  public void setMediaTypes(String[] mediaTypes) {
    this.mediaTypes = mediaTypes;
  }
  
  public String[] getMediaTypes() {
    return this.mediaTypes;
  }
  
  public Component getControlComponent() {
    return null;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\controls\RtspAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */