package com.sun.media.controls;

import java.awt.Component;
import javax.media.control.RtspControl;
import javax.media.rtp.RTPManager;

public class RtspAdapter implements RtspControl {
  private RTPManager[] managers;
  
  private String[] mediaTypes;
  
  public void setRTPManagers(RTPManager[] managers) {
    this.managers = managers;
  }
  
  public RTPManager[] getRTPManagers() {
    return this.managers;
  }
  
  public void setMediaTypes(String[] mediaTypes) {
    this.mediaTypes = mediaTypes;
  }
  
  public String[] getMediaTypes() {
    return this.mediaTypes;
  }
  
  public Component getControlComponent() {
    return null;
  }
}
