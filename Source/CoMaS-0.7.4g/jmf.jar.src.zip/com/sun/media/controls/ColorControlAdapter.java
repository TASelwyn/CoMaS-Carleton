package com.sun.media.controls;

import java.awt.Component;
import javax.media.Control;

public class ColorControlAdapter extends AtomicControlAdapter implements ColorControl {
  NumericControl brightness;
  
  NumericControl contrast;
  
  NumericControl saturation;
  
  NumericControl hue;
  
  BooleanControl grayscale;
  
  Control[] controls;
  
  public ColorControlAdapter(NumericControl b, NumericControl c, NumericControl s, NumericControl h, BooleanControl g, Component comp, boolean def, Control parent) {
    super(comp, def, parent);
    this.brightness = b;
    this.contrast = c;
    this.saturation = s;
    this.hue = h;
    this.grayscale = g;
    int n = 0;
    n += (b == null) ? 0 : 1;
    n += (c == null) ? 0 : 1;
    n += (s == null) ? 0 : 1;
    n += (h == null) ? 0 : 1;
    n += (g == null) ? 0 : 1;
    this.controls = new Control[n];
    n = 0;
    if (b != null)
      this.controls[n++] = b; 
    if (c != null)
      this.controls[n++] = c; 
    if (s != null)
      this.controls[n++] = s; 
    if (h != null)
      this.controls[n++] = h; 
    if (g != null)
      this.controls[n++] = g; 
  }
  
  public Control[] getControls() {
    return this.controls;
  }
  
  public NumericControl getBrightness() {
    return this.brightness;
  }
  
  public NumericControl getContrast() {
    return this.contrast;
  }
  
  public NumericControl getSaturation() {
    return this.saturation;
  }
  
  public NumericControl getHue() {
    return this.hue;
  }
  
  public BooleanControl getGrayscale() {
    return this.grayscale;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\controls\ColorControlAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */