/*     */ package com.sun.media.controls;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.util.Vector;
/*     */ import javax.media.GainChangeEvent;
/*     */ import javax.media.GainChangeListener;
/*     */ import javax.media.GainControl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GainControlAdapter
/*     */   implements GainControl
/*     */ {
/*  17 */   private Vector listeners = null;
/*     */ 
/*     */   
/*     */   private boolean muteState;
/*     */   
/*     */   private Component component;
/*     */   
/*  24 */   private float DefLevel = 0.4F;
/*  25 */   private float dB = 0.0F;
/*  26 */   private float level = this.DefLevel;
/*     */ 
/*     */   
/*     */   public GainControlAdapter() {}
/*     */   
/*     */   public GainControlAdapter(float defLevel) {
/*  32 */     this.DefLevel = defLevel;
/*  33 */     this.level = defLevel;
/*     */   }
/*     */   
/*     */   public GainControlAdapter(boolean mute) {
/*  37 */     this.muteState = mute;
/*  38 */     setLevel(this.DefLevel);
/*     */   }
/*     */   
/*     */   public void setMute(boolean mute) {
/*  42 */     if (this.muteState != mute) {
/*  43 */       this.muteState = mute;
/*  44 */       informListeners();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean getMute() {
/*  49 */     return this.muteState;
/*     */   }
/*     */   
/*     */   public float setDB(float gain) {
/*  53 */     if (this.dB != gain) {
/*  54 */       this.dB = gain;
/*  55 */       float mult = (float)Math.pow(10.0D, this.dB / 20.0D);
/*  56 */       this.level = mult * this.DefLevel;
/*  57 */       if (this.level < 0.0D) {
/*  58 */         setLevel(0.0F);
/*  59 */       } else if (this.level > 1.0D) {
/*  60 */         setLevel(1.0F);
/*     */       } else {
/*  62 */         setLevel(this.level);
/*  63 */         informListeners();
/*     */       } 
/*     */     } 
/*  66 */     return this.dB;
/*     */   }
/*     */   
/*     */   public float getDB() {
/*  70 */     return this.dB;
/*     */   }
/*     */   
/*     */   public float setLevel(float level) {
/*  74 */     if (level < 0.0D)
/*  75 */       level = 0.0F; 
/*  76 */     if (level > 1.0D)
/*  77 */       level = 1.0F; 
/*  78 */     if (this.level != level) {
/*  79 */       this.level = level;
/*  80 */       float mult = level / this.DefLevel;
/*  81 */       this.dB = (float)(Math.log((mult == 0.0D) ? 1.0E-4D : mult) / Math.log(10.0D) * 20.0D);
/*  82 */       informListeners();
/*     */     } 
/*  84 */     return this.level;
/*     */   }
/*     */   
/*     */   public float getLevel() {
/*  88 */     return this.level;
/*     */   }
/*     */   
/*     */   public synchronized void addGainChangeListener(GainChangeListener listener) {
/*  92 */     if (listener != null) {
/*  93 */       if (this.listeners == null)
/*  94 */         this.listeners = new Vector(); 
/*  95 */       this.listeners.addElement(listener);
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized void removeGainChangeListener(GainChangeListener listener) {
/* 100 */     if (listener != null && this.listeners != null)
/* 101 */       this.listeners.removeElement(listener); 
/*     */   }
/*     */   
/*     */   public Component getControlComponent() {
/* 105 */     return null;
/*     */   }
/*     */   
/*     */   protected synchronized void informListeners() {
/* 109 */     if (this.listeners != null) {
/* 110 */       GainChangeEvent gce = new GainChangeEvent(this, this.muteState, this.dB, this.level);
/* 111 */       for (int i = 0; i < this.listeners.size(); i++) {
/* 112 */         GainChangeListener gcl = this.listeners.elementAt(i);
/* 113 */         gcl.gainChange(gce);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\controls\GainControlAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */