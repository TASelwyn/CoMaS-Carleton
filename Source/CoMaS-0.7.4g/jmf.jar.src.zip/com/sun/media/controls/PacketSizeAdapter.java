/*    */ package com.sun.media.controls;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Component;
/*    */ import java.awt.Label;
/*    */ import java.awt.Panel;
/*    */ import java.awt.TextField;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.media.Codec;
/*    */ import javax.media.control.PacketSizeControl;
/*    */ 
/*    */ 
/*    */ public class PacketSizeAdapter
/*    */   implements PacketSizeControl
/*    */ {
/* 17 */   protected Codec owner = null;
/*    */   protected boolean isSetable;
/*    */   protected int packetSize;
/* 20 */   Component component = null;
/* 21 */   String CONTROL_STRING = "Packet Size";
/*    */ 
/*    */   
/*    */   public PacketSizeAdapter(Codec newOwner, int newPacketSize, boolean newIsSetable) {
/* 25 */     this.packetSize = newPacketSize;
/* 26 */     this.owner = newOwner;
/* 27 */     this.isSetable = newIsSetable;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int setPacketSize(int numBytes) {
/* 40 */     return this.packetSize;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getPacketSize() {
/* 48 */     return this.packetSize;
/*    */   }
/*    */   
/*    */   public Component getControlComponent() {
/* 52 */     if (this.component == null) {
/* 53 */       Panel componentPanel = new Panel();
/* 54 */       componentPanel.setLayout(new BorderLayout());
/* 55 */       componentPanel.add("Center", new Label(this.CONTROL_STRING, 1));
/* 56 */       TextField tf = new TextField(this.packetSize + "", 5);
/* 57 */       tf.setEditable(this.isSetable);
/*    */       
/* 59 */       tf.addActionListener(new PacketSizeListner(this, tf));
/*    */       
/* 61 */       componentPanel.add("East", tf);
/* 62 */       componentPanel.invalidate();
/* 63 */       this.component = componentPanel;
/*    */     } 
/*    */     
/* 66 */     return this.component;
/*    */   }
/*    */   class PacketSizeListner implements ActionListener { TextField tf;
/*    */     
/*    */     public PacketSizeListner(PacketSizeAdapter this$0, TextField source) {
/* 71 */       this.this$0 = this$0;
/* 72 */       this.tf = source;
/*    */     }
/*    */     private final PacketSizeAdapter this$0;
/*    */     public void actionPerformed(ActionEvent e) {
/*    */       try {
/* 77 */         int newPacketSize = Integer.parseInt(this.tf.getText());
/* 78 */         System.out.println("newPacketSize " + newPacketSize);
/*    */         
/* 80 */         this.this$0.setPacketSize(newPacketSize);
/* 81 */       } catch (Exception exception) {}
/*    */ 
/*    */       
/* 84 */       this.tf.setText(this.this$0.packetSize + "");
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\controls\PacketSizeAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */