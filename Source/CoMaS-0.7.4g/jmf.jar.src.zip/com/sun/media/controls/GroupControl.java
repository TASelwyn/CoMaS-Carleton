package com.sun.media.controls;

import javax.media.Control;

public interface GroupControl extends AtomicControl {
  Control[] getControls();
}
