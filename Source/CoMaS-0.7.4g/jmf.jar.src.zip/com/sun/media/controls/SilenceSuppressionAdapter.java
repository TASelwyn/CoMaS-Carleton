/*    */ package com.sun.media.controls;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Checkbox;
/*    */ import java.awt.Component;
/*    */ import java.awt.Label;
/*    */ import java.awt.Panel;
/*    */ import java.awt.event.ItemEvent;
/*    */ import java.awt.event.ItemListener;
/*    */ import javax.media.Codec;
/*    */ import javax.media.control.SilenceSuppressionControl;
/*    */ 
/*    */ 
/*    */ public class SilenceSuppressionAdapter
/*    */   implements SilenceSuppressionControl
/*    */ {
/* 17 */   protected Codec owner = null;
/*    */   protected boolean silenceSuppression = false;
/*    */   protected boolean isSetable;
/* 20 */   Component component = null;
/* 21 */   String CONTROL_STRING = "Silence Suppression";
/*    */ 
/*    */   
/*    */   public SilenceSuppressionAdapter(Codec newOwner, boolean newSilenceSuppression, boolean newIsSetable) {
/* 25 */     this.silenceSuppression = newSilenceSuppression;
/* 26 */     this.owner = newOwner;
/* 27 */     this.isSetable = newIsSetable;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean getSilenceSuppression() {
/* 36 */     return this.silenceSuppression;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean setSilenceSuppression(boolean newSilenceSuppression) {
/* 47 */     return this.silenceSuppression;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isSilenceSuppressionSupported() {
/* 55 */     return this.silenceSuppression;
/*    */   }
/*    */   
/*    */   public Component getControlComponent() {
/* 59 */     if (this.component == null) {
/* 60 */       Panel componentPanel = new Panel();
/* 61 */       componentPanel.setLayout(new BorderLayout());
/* 62 */       componentPanel.add("Center", new Label(this.CONTROL_STRING, 1));
/* 63 */       Checkbox cb = new Checkbox(null, null, this.silenceSuppression);
/* 64 */       cb.setEnabled(this.isSetable);
/* 65 */       cb.addItemListener(new SilenceSuppresionAdapterListener(this, cb));
/*    */       
/* 67 */       componentPanel.add("East", cb);
/* 68 */       componentPanel.invalidate();
/* 69 */       this.component = componentPanel;
/*    */     } 
/*    */     
/* 72 */     return this.component;
/*    */   }
/*    */   class SilenceSuppresionAdapterListener implements ItemListener { Checkbox cb;
/*    */     
/*    */     public SilenceSuppresionAdapterListener(SilenceSuppressionAdapter this$0, Checkbox source) {
/* 77 */       this.this$0 = this$0;
/* 78 */       this.cb = source;
/*    */     }
/*    */     private final SilenceSuppressionAdapter this$0;
/*    */     public void itemStateChanged(ItemEvent e) {
/*    */       try {
/* 83 */         boolean newSilenceSuppression = this.cb.getState();
/*    */ 
/*    */         
/* 86 */         this.this$0.setSilenceSuppression(this.this$0.silenceSuppression);
/* 87 */       } catch (Exception exception) {}
/*    */ 
/*    */       
/* 90 */       this.cb.setState(this.this$0.silenceSuppression);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\controls\SilenceSuppressionAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */