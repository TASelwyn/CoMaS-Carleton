package com.sun.media.controls;

import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.Component;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.media.Codec;
import javax.media.control.SilenceSuppressionControl;

public class SilenceSuppressionAdapter implements SilenceSuppressionControl {
  protected Codec owner = null;
  
  protected boolean silenceSuppression = false;
  
  protected boolean isSetable;
  
  Component component = null;
  
  String CONTROL_STRING = "Silence Suppression";
  
  public SilenceSuppressionAdapter(Codec newOwner, boolean newSilenceSuppression, boolean newIsSetable) {
    this.silenceSuppression = newSilenceSuppression;
    this.owner = newOwner;
    this.isSetable = newIsSetable;
  }
  
  public boolean getSilenceSuppression() {
    return this.silenceSuppression;
  }
  
  public boolean setSilenceSuppression(boolean newSilenceSuppression) {
    return this.silenceSuppression;
  }
  
  public boolean isSilenceSuppressionSupported() {
    return this.silenceSuppression;
  }
  
  public Component getControlComponent() {
    if (this.component == null) {
      Panel componentPanel = new Panel();
      componentPanel.setLayout(new BorderLayout());
      componentPanel.add("Center", new Label(this.CONTROL_STRING, 1));
      Checkbox cb = new Checkbox(null, null, this.silenceSuppression);
      cb.setEnabled(this.isSetable);
      cb.addItemListener(new SilenceSuppresionAdapterListener(this, cb));
      componentPanel.add("East", cb);
      componentPanel.invalidate();
      this.component = componentPanel;
    } 
    return this.component;
  }
  
  class SilenceSuppresionAdapterListener implements ItemListener {
    Checkbox cb;
    
    private final SilenceSuppressionAdapter this$0;
    
    public SilenceSuppresionAdapterListener(SilenceSuppressionAdapter this$0, Checkbox source) {
      this.this$0 = this$0;
      this.cb = source;
    }
    
    public void itemStateChanged(ItemEvent e) {
      try {
        boolean newSilenceSuppression = this.cb.getState();
        this.this$0.setSilenceSuppression(this.this$0.silenceSuppression);
      } catch (Exception exception) {}
      this.cb.setState(this.this$0.silenceSuppression);
    }
  }
}
