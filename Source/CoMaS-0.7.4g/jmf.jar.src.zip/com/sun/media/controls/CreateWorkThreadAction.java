/*    */ package com.sun.media.controls;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CreateWorkThreadAction
/*    */   implements PrivilegedAction
/*    */ {
/*    */   private Class objclass;
/*    */   Class baseClass;
/*    */   Object arg;
/*    */   static Constructor cons;
/*    */   
/*    */   static {
/*    */     try {
/* 30 */       cons = CreateWorkThreadAction.class.getConstructor(new Class[] { Class.class, Class.class, Object.class });
/*    */     }
/* 32 */     catch (Throwable e) {}
/*    */   }
/*    */ 
/*    */   
/*    */   public CreateWorkThreadAction(Class objclass, Class baseClass, Object arg) {
/*    */     try {
/* 38 */       this.objclass = objclass;
/* 39 */       this.baseClass = baseClass;
/* 40 */       this.arg = arg;
/* 41 */     } catch (Throwable e) {}
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object run() {
/*    */     try {
/* 48 */       Constructor cons = this.objclass.getConstructor(new Class[] { this.baseClass });
/* 49 */       Object object = cons.newInstance(new Object[] { this.arg });
/* 50 */       return object;
/*    */     } catch (Throwable e) {
/* 52 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\controls\CreateWorkThreadAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */