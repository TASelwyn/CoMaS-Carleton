package com.sun.media.controls;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import com.sun.media.CircularBuffer;
import com.sun.media.JMFSecurity;
import com.sun.media.JMFSecurityManager;
import com.sun.media.Log;
import com.sun.media.util.AudioCodecChain;
import com.sun.media.util.CodecChain;
import com.sun.media.util.LoopThread;
import com.sun.media.util.VideoCodecChain;
import com.sun.media.util.jdk12;
import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.MenuItem;
import java.awt.Panel;
import java.awt.PopupMenu;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.Owned;
import javax.media.control.MonitorControl;
import javax.media.format.AudioFormat;
import javax.media.format.UnsupportedFormatException;
import javax.media.format.VideoFormat;

public class MonitorAdapter implements MonitorControl, Owned {
  protected CodecChain cc = null;
  
  protected boolean enabled = false;
  
  protected boolean closed = false;
  
  protected Component visualComponent = null;
  
  protected Component controlComponent = null;
  
  protected Checkbox cbEnabled = null;
  
  protected Format format = null;
  
  protected float inFrameRate = 0.0F;
  
  protected float previewFrameRate = 30.0F;
  
  protected long lastPreviewTime = 0L;
  
  protected long previewInterval = 33333333L;
  
  protected MouseListener ml = null;
  
  protected PopupMenu rateMenu = null;
  
  protected LoopThread loopThread;
  
  protected int[] frameRates = new int[] { 
      0, 1, 2, 5, 7, 10, 15, 20, 30, 60, 
      90 };
  
  CircularBuffer bufferQ;
  
  Object owner;
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] mSecurity = new Method[1];
  
  private Class[] clSecurity = new Class[1];
  
  private Object[][] argsSecurity = new Object[1][0];
  
  static VideoFormat mpegVideo = new VideoFormat("mpeg/rtp");
  
  static {
    try {
      jmfSecurity = JMFSecurityManager.getJMFSecurity();
      securityPrivelege = true;
    } catch (SecurityException e) {}
  }
  
  public MonitorAdapter(Format f, Object owner) {
    this.format = f;
    this.owner = owner;
  }
  
  protected boolean open() {
    try {
      if (this.format instanceof VideoFormat) {
        VideoFormat vf = (VideoFormat)this.format;
        this.cc = (CodecChain)new VideoCodecChain(vf);
        this.inFrameRate = vf.getFrameRate();
        if (this.inFrameRate < 0.0F)
          this.inFrameRate = 30.0F; 
        this.inFrameRate = (int)((this.inFrameRate * 10.0F) + 0.5D) / 10.0F;
      } else if (this.format instanceof AudioFormat) {
        this.cc = (CodecChain)new AudioCodecChain((AudioFormat)this.format);
      } 
    } catch (UnsupportedFormatException e) {
      Log.warning("Failed to initialize the monitor control: " + e);
      return false;
    } 
    if (this.cc == null)
      return false; 
    this.bufferQ = new CircularBuffer(2);
    if (jmfSecurity != null) {
      String permission = null;
      try {
        if (jmfSecurity.getName().startsWith("jmf-security")) {
          permission = "thread";
          jmfSecurity.requestPermission(this.mSecurity, this.clSecurity, this.argsSecurity, 16);
          this.mSecurity[0].invoke(this.clSecurity[0], this.argsSecurity[0]);
          permission = "thread group";
          jmfSecurity.requestPermission(this.mSecurity, this.clSecurity, this.argsSecurity, 32);
          this.mSecurity[0].invoke(this.clSecurity[0], this.argsSecurity[0]);
        } else if (jmfSecurity.getName().startsWith("internet")) {
          PolicyEngine.checkPermission(PermissionID.THREAD);
          PolicyEngine.assertPermission(PermissionID.THREAD);
        } 
      } catch (Throwable e) {
        securityPrivelege = false;
      } 
    } 
    if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
      try {
        Constructor cons = CreateWorkThreadAction.cons;
        this.loopThread = (MonitorThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { MonitorThread.class, MonitorAdapter.class, this }) });
      } catch (Exception e) {}
    } else {
      this.loopThread = new MonitorThread(this);
    } 
    return true;
  }
  
  public Object getOwner() {
    return this.owner;
  }
  
  public boolean setEnabled(boolean on) {
    if (on) {
      if (this.cc == null) {
        if (!open())
          return false; 
      } else {
        this.cc.reset();
      } 
      if (!this.cc.prefetch())
        return false; 
      synchronized (this.bufferQ) {
        while (this.bufferQ.canRead()) {
          this.bufferQ.read();
          this.bufferQ.readReport();
        } 
      } 
      this.enabled = true;
      this.loopThread.start();
    } else if (!on && this.cc != null) {
      this.loopThread.pause();
      synchronized (this.bufferQ) {
        this.enabled = false;
        this.bufferQ.notifyAll();
      } 
      this.cc.deallocate();
    } 
    return this.enabled;
  }
  
  public boolean isEnabled() {
    return this.enabled;
  }
  
  public void reset() {
    if (this.cc != null)
      this.cc.reset(); 
  }
  
  public void close() {
    if (this.cc == null)
      return; 
    this.loopThread.kill();
    synchronized (this.bufferQ) {
      this.closed = true;
      this.bufferQ.notifyAll();
    } 
    this.cc.close();
    this.cc = null;
  }
  
  public void process(Buffer input) {
    if (input == null || this.previewFrameRate <= 0.0F || this.format == null || input.isEOM() || input.isDiscard() || (input.getFlags() & 0x200) != 0)
      return; 
    if (!this.format.matches(input.getFormat()))
      return; 
    Buffer buffer = null;
    synchronized (this.bufferQ) {
      while (!this.bufferQ.canWrite() && this.enabled && !this.closed) {
        try {
          this.bufferQ.wait();
        } catch (Exception e) {}
      } 
      if (!this.enabled || this.closed)
        return; 
      buffer = this.bufferQ.getEmptyBuffer();
    } 
    buffer.setData(copyData(input.getData()));
    buffer.setFlags(input.getFlags());
    buffer.setFormat(input.getFormat());
    buffer.setSequenceNumber(input.getSequenceNumber());
    buffer.setHeader(input.getHeader());
    buffer.setLength(input.getLength());
    buffer.setOffset(input.getOffset());
    buffer.setTimeStamp(input.getTimeStamp());
    synchronized (this.bufferQ) {
      this.bufferQ.writeReport();
      this.bufferQ.notifyAll();
    } 
  }
  
  public boolean doProcess() {
    Buffer buffer;
    synchronized (this.bufferQ) {
      while (!this.bufferQ.canRead() && this.enabled && !this.closed) {
        try {
          this.bufferQ.wait();
        } catch (Exception e) {}
      } 
      if (this.closed)
        return false; 
      if (!this.enabled)
        return true; 
      buffer = this.bufferQ.read();
    } 
    boolean toDisplay = false;
    if (buffer.getFormat() instanceof AudioFormat) {
      toDisplay = true;
    } else {
      long time = buffer.getTimeStamp();
      if (time >= this.lastPreviewTime + this.previewInterval || time <= this.lastPreviewTime) {
        if (mpegVideo.matches(this.format)) {
          byte[] payload = (byte[])buffer.getData();
          int offset = buffer.getOffset();
          int ptype = payload[offset + 2] & 0x7;
          if (ptype == 1) {
            this.lastPreviewTime = time;
            toDisplay = true;
          } 
        } else {
          this.lastPreviewTime = time;
          toDisplay = true;
        } 
      } else {
        toDisplay = false;
      } 
    } 
    this.cc.process(buffer, toDisplay);
    synchronized (this.bufferQ) {
      this.bufferQ.readReport();
      this.bufferQ.notifyAll();
    } 
    return true;
  }
  
  private Object copyData(Object in) {
    if (in instanceof byte[]) {
      byte[] out = new byte[((byte[])in).length];
      System.arraycopy(in, 0, out, 0, out.length);
      return out;
    } 
    if (in instanceof short[]) {
      short[] out = new short[((short[])in).length];
      System.arraycopy(in, 0, out, 0, out.length);
      return out;
    } 
    if (in instanceof int[]) {
      int[] out = new int[((int[])in).length];
      System.arraycopy(in, 0, out, 0, out.length);
      return out;
    } 
    return in;
  }
  
  public float setPreviewFrameRate(float value) {
    if (value > this.inFrameRate)
      value = this.inFrameRate; 
    this.previewFrameRate = value;
    this.previewInterval = (long)(1.0E9D / value);
    return value;
  }
  
  public Component getControlComponent() {
    if (this.controlComponent != null)
      return this.controlComponent; 
    if (this.cc == null && !open())
      return null; 
    this.controlComponent = this.cc.getControlComponent();
    if (this.format instanceof AudioFormat && this.controlComponent != null) {
      Container controlPanel = new Panel();
      controlPanel.setLayout(new BorderLayout());
      this.cbEnabled = new Checkbox("Monitor Audio");
      controlPanel.add("West", this.cbEnabled);
      controlPanel.add("Center", this.controlComponent);
      this.controlComponent = controlPanel;
      controlPanel.setBackground(Color.lightGray);
    } 
    if (this.format instanceof VideoFormat && this.controlComponent != null) {
      Container controlPanel = new Panel();
      controlPanel.setLayout(new BorderLayout());
      this.cbEnabled = new Checkbox("Monitor Video");
      controlPanel.add("South", this.cbEnabled);
      controlPanel.add("Center", this.controlComponent);
      addPopupMenu(this.controlComponent);
      this.controlComponent = controlPanel;
      controlPanel.setBackground(Color.lightGray);
    } 
    if (this.cbEnabled != null) {
      this.cbEnabled.setState(isEnabled());
      this.cbEnabled.addItemListener(new ItemListener(this) {
            private final MonitorAdapter this$0;
            
            public void itemStateChanged(ItemEvent ie) {
              this.this$0.setEnabled(this.this$0.cbEnabled.getState());
            }
          });
    } 
    return this.controlComponent;
  }
  
  private void addPopupMenu(Component visual) {
    this.visualComponent = visual;
    this.rateMenu = new PopupMenu("Monitor Rate");
    ActionListener rateSelect = new ActionListener(this) {
        private final MonitorAdapter this$0;
        
        public void actionPerformed(ActionEvent ae) {
          String action = ae.getActionCommand();
          int space = action.indexOf(" ");
          String rateString = action.substring(0, space);
          try {
            int rate = Integer.parseInt(rateString);
            this.this$0.setPreviewFrameRate(rate);
          } catch (Throwable t) {
            if (t instanceof ThreadDeath)
              throw (ThreadDeath)t; 
          } 
        }
      };
    visual.add(this.rateMenu);
    int lastAdded = 0;
    for (int i = 0; i < this.frameRates.length; i++) {
      if (this.frameRates[i] < this.inFrameRate) {
        MenuItem mi = new MenuItem(this.frameRates[i] + " fps");
        this.rateMenu.add(mi);
        mi.addActionListener(rateSelect);
        lastAdded = this.frameRates[i];
      } 
    } 
    if (lastAdded < this.inFrameRate) {
      MenuItem menuItem = new MenuItem(this.inFrameRate + " fps");
      this.rateMenu.add(menuItem);
      menuItem.addActionListener(rateSelect);
    } 
    visual.addMouseListener(this.ml = new MouseAdapter(this) {
          private final MonitorAdapter this$0;
          
          public void mousePressed(MouseEvent me) {
            if (me.isPopupTrigger())
              this.this$0.rateMenu.show(this.this$0.visualComponent, me.getX(), me.getY()); 
          }
          
          public void mouseReleased(MouseEvent me) {
            if (me.isPopupTrigger())
              this.this$0.rateMenu.show(this.this$0.visualComponent, me.getX(), me.getY()); 
          }
          
          public void mouseClicked(MouseEvent me) {
            if (me.isPopupTrigger())
              this.this$0.rateMenu.show(this.this$0.visualComponent, me.getX(), me.getY()); 
          }
        });
  }
  
  public void finalize() {
    if (this.visualComponent != null) {
      this.visualComponent.remove(this.rateMenu);
      this.visualComponent.removeMouseListener(this.ml);
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\controls\MonitorAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */