/*     */ package com.sun.media.controls;
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.CircularBuffer;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.util.AudioCodecChain;
/*     */ import com.sun.media.util.CodecChain;
/*     */ import com.sun.media.util.LoopThread;
/*     */ import com.sun.media.util.VideoCodecChain;
/*     */ import com.sun.media.util.jdk12;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Checkbox;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.MenuItem;
/*     */ import java.awt.Panel;
/*     */ import java.awt.PopupMenu;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.Owned;
/*     */ import javax.media.control.MonitorControl;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.format.UnsupportedFormatException;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ public class MonitorAdapter implements MonitorControl, Owned {
/*  37 */   protected CodecChain cc = null;
/*     */   protected boolean enabled = false;
/*     */   protected boolean closed = false;
/*  40 */   protected Component visualComponent = null;
/*  41 */   protected Component controlComponent = null;
/*  42 */   protected Checkbox cbEnabled = null;
/*  43 */   protected Format format = null;
/*  44 */   protected float inFrameRate = 0.0F;
/*  45 */   protected float previewFrameRate = 30.0F;
/*  46 */   protected long lastPreviewTime = 0L;
/*  47 */   protected long previewInterval = 33333333L;
/*  48 */   protected MouseListener ml = null;
/*  49 */   protected PopupMenu rateMenu = null;
/*     */   
/*     */   protected LoopThread loopThread;
/*  52 */   protected int[] frameRates = new int[] { 0, 1, 2, 5, 7, 10, 15, 20, 30, 60, 90 };
/*     */   
/*     */   CircularBuffer bufferQ;
/*     */   
/*     */   Object owner;
/*     */   
/*  58 */   private static JMFSecurity jmfSecurity = null;
/*     */   private static boolean securityPrivelege = false;
/*  60 */   private Method[] mSecurity = new Method[1];
/*  61 */   private Class[] clSecurity = new Class[1];
/*  62 */   private Object[][] argsSecurity = new Object[1][0];
/*     */ 
/*     */   
/*  65 */   static VideoFormat mpegVideo = new VideoFormat("mpeg/rtp");
/*     */   
/*     */   static {
/*     */     try {
/*  69 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  70 */       securityPrivelege = true;
/*  71 */     } catch (SecurityException e) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public MonitorAdapter(Format f, Object owner) {
/*  76 */     this.format = f;
/*  77 */     this.owner = owner;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean open() {
/*     */     try {
/*  83 */       if (this.format instanceof VideoFormat) {
/*  84 */         VideoFormat vf = (VideoFormat)this.format;
/*  85 */         this.cc = (CodecChain)new VideoCodecChain(vf);
/*  86 */         this.inFrameRate = vf.getFrameRate();
/*  87 */         if (this.inFrameRate < 0.0F)
/*  88 */           this.inFrameRate = 30.0F; 
/*  89 */         this.inFrameRate = (int)((this.inFrameRate * 10.0F) + 0.5D) / 10.0F;
/*  90 */       } else if (this.format instanceof AudioFormat) {
/*  91 */         this.cc = (CodecChain)new AudioCodecChain((AudioFormat)this.format);
/*     */       } 
/*     */     } catch (UnsupportedFormatException e) {
/*     */       
/*  95 */       Log.warning("Failed to initialize the monitor control: " + e);
/*  96 */       return false;
/*     */     } 
/*     */     
/*  99 */     if (this.cc == null) {
/* 100 */       return false;
/*     */     }
/* 102 */     this.bufferQ = new CircularBuffer(2);
/* 103 */     if (jmfSecurity != null) {
/* 104 */       String permission = null;
/*     */       try {
/* 106 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 107 */           permission = "thread";
/* 108 */           jmfSecurity.requestPermission(this.mSecurity, this.clSecurity, this.argsSecurity, 16);
/*     */           
/* 110 */           this.mSecurity[0].invoke(this.clSecurity[0], this.argsSecurity[0]);
/*     */           
/* 112 */           permission = "thread group";
/* 113 */           jmfSecurity.requestPermission(this.mSecurity, this.clSecurity, this.argsSecurity, 32);
/*     */           
/* 115 */           this.mSecurity[0].invoke(this.clSecurity[0], this.argsSecurity[0]);
/* 116 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/* 117 */           PolicyEngine.checkPermission(PermissionID.THREAD);
/* 118 */           PolicyEngine.assertPermission(PermissionID.THREAD);
/*     */         }
/*     */       
/* 121 */       } catch (Throwable e) {
/*     */ 
/*     */ 
/*     */         
/* 125 */         securityPrivelege = false;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 130 */     if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
/*     */       try {
/* 132 */         Constructor cons = CreateWorkThreadAction.cons;
/* 133 */         this.loopThread = (MonitorThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { MonitorThread.class, MonitorAdapter.class, this }) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 142 */       catch (Exception e) {}
/*     */     } else {
/*     */       
/* 145 */       this.loopThread = new MonitorThread(this);
/*     */     } 
/*     */     
/* 148 */     return true;
/*     */   }
/*     */   
/*     */   public Object getOwner() {
/* 152 */     return this.owner;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setEnabled(boolean on) {
/* 157 */     if (on) {
/* 158 */       if (this.cc == null) {
/* 159 */         if (!open())
/* 160 */           return false; 
/*     */       } else {
/* 162 */         this.cc.reset();
/* 163 */       }  if (!this.cc.prefetch()) {
/* 164 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 168 */       synchronized (this.bufferQ) {
/* 169 */         while (this.bufferQ.canRead()) {
/* 170 */           this.bufferQ.read();
/* 171 */           this.bufferQ.readReport();
/*     */         } 
/*     */       } 
/*     */       
/* 175 */       this.enabled = true;
/* 176 */       this.loopThread.start();
/* 177 */     } else if (!on && this.cc != null) {
/* 178 */       this.loopThread.pause();
/*     */       
/* 180 */       synchronized (this.bufferQ) {
/* 181 */         this.enabled = false;
/* 182 */         this.bufferQ.notifyAll();
/*     */       } 
/* 184 */       this.cc.deallocate();
/*     */     } 
/*     */     
/* 187 */     return this.enabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/* 192 */     return this.enabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 197 */     if (this.cc != null) {
/* 198 */       this.cc.reset();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 204 */     if (this.cc == null) {
/*     */       return;
/*     */     }
/* 207 */     this.loopThread.kill();
/* 208 */     synchronized (this.bufferQ) {
/* 209 */       this.closed = true;
/* 210 */       this.bufferQ.notifyAll();
/*     */     } 
/*     */     
/* 213 */     this.cc.close();
/* 214 */     this.cc = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void process(Buffer input) {
/* 220 */     if (input == null || this.previewFrameRate <= 0.0F || this.format == null || input.isEOM() || input.isDiscard() || (input.getFlags() & 0x200) != 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 226 */     if (!this.format.matches(input.getFormat())) {
/*     */       return;
/*     */     }
/*     */     
/* 230 */     Buffer buffer = null;
/*     */ 
/*     */     
/* 233 */     synchronized (this.bufferQ) {
/* 234 */       while (!this.bufferQ.canWrite() && this.enabled && !this.closed) {
/*     */         try {
/* 236 */           this.bufferQ.wait();
/* 237 */         } catch (Exception e) {}
/*     */       } 
/*     */       
/* 240 */       if (!this.enabled || this.closed) {
/*     */         return;
/*     */       }
/* 243 */       buffer = this.bufferQ.getEmptyBuffer();
/*     */     } 
/*     */ 
/*     */     
/* 247 */     buffer.setData(copyData(input.getData()));
/* 248 */     buffer.setFlags(input.getFlags());
/* 249 */     buffer.setFormat(input.getFormat());
/* 250 */     buffer.setSequenceNumber(input.getSequenceNumber());
/* 251 */     buffer.setHeader(input.getHeader());
/* 252 */     buffer.setLength(input.getLength());
/* 253 */     buffer.setOffset(input.getOffset());
/* 254 */     buffer.setTimeStamp(input.getTimeStamp());
/*     */ 
/*     */     
/* 257 */     synchronized (this.bufferQ) {
/* 258 */       this.bufferQ.writeReport();
/* 259 */       this.bufferQ.notifyAll();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean doProcess() {
/*     */     Buffer buffer;
/* 268 */     synchronized (this.bufferQ) {
/* 269 */       while (!this.bufferQ.canRead() && this.enabled && !this.closed) {
/*     */         try {
/* 271 */           this.bufferQ.wait();
/* 272 */         } catch (Exception e) {}
/*     */       } 
/*     */       
/* 275 */       if (this.closed)
/* 276 */         return false; 
/* 277 */       if (!this.enabled) {
/* 278 */         return true;
/*     */       }
/* 280 */       buffer = this.bufferQ.read();
/*     */     } 
/*     */     
/* 283 */     boolean toDisplay = false;
/*     */     
/* 285 */     if (buffer.getFormat() instanceof AudioFormat) {
/* 286 */       toDisplay = true;
/*     */     } else {
/* 288 */       long time = buffer.getTimeStamp();
/* 289 */       if (time >= this.lastPreviewTime + this.previewInterval || time <= this.lastPreviewTime) {
/*     */         
/* 291 */         if (mpegVideo.matches(this.format)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 300 */           byte[] payload = (byte[])buffer.getData();
/* 301 */           int offset = buffer.getOffset();
/* 302 */           int ptype = payload[offset + 2] & 0x7;
/* 303 */           if (ptype == 1) {
/* 304 */             this.lastPreviewTime = time;
/* 305 */             toDisplay = true;
/*     */           } 
/*     */         } else {
/* 308 */           this.lastPreviewTime = time;
/* 309 */           toDisplay = true;
/*     */         } 
/*     */       } else {
/* 312 */         toDisplay = false;
/*     */       } 
/*     */     } 
/*     */     
/* 316 */     this.cc.process(buffer, toDisplay);
/*     */ 
/*     */     
/* 319 */     synchronized (this.bufferQ) {
/* 320 */       this.bufferQ.readReport();
/* 321 */       this.bufferQ.notifyAll();
/*     */     } 
/*     */     
/* 324 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object copyData(Object in) {
/* 329 */     if (in instanceof byte[]) {
/* 330 */       byte[] out = new byte[((byte[])in).length];
/* 331 */       System.arraycopy(in, 0, out, 0, out.length);
/* 332 */       return out;
/*     */     } 
/* 334 */     if (in instanceof short[]) {
/* 335 */       short[] out = new short[((short[])in).length];
/* 336 */       System.arraycopy(in, 0, out, 0, out.length);
/* 337 */       return out;
/*     */     } 
/* 339 */     if (in instanceof int[]) {
/* 340 */       int[] out = new int[((int[])in).length];
/* 341 */       System.arraycopy(in, 0, out, 0, out.length);
/* 342 */       return out;
/*     */     } 
/* 344 */     return in;
/*     */   }
/*     */   
/*     */   public float setPreviewFrameRate(float value) {
/* 348 */     if (value > this.inFrameRate)
/* 349 */       value = this.inFrameRate; 
/* 350 */     this.previewFrameRate = value;
/* 351 */     this.previewInterval = (long)(1.0E9D / value);
/* 352 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getControlComponent() {
/* 385 */     if (this.controlComponent != null) {
/* 386 */       return this.controlComponent;
/*     */     }
/* 388 */     if (this.cc == null && !open()) {
/* 389 */       return null;
/*     */     }
/* 391 */     this.controlComponent = this.cc.getControlComponent();
/*     */ 
/*     */     
/* 394 */     if (this.format instanceof AudioFormat && this.controlComponent != null) {
/* 395 */       Container controlPanel = new Panel();
/* 396 */       controlPanel.setLayout(new BorderLayout());
/* 397 */       this.cbEnabled = new Checkbox("Monitor Audio");
/* 398 */       controlPanel.add("West", this.cbEnabled);
/* 399 */       controlPanel.add("Center", this.controlComponent);
/* 400 */       this.controlComponent = controlPanel;
/* 401 */       controlPanel.setBackground(Color.lightGray);
/*     */     } 
/*     */     
/* 404 */     if (this.format instanceof VideoFormat && this.controlComponent != null) {
/* 405 */       Container controlPanel = new Panel();
/* 406 */       controlPanel.setLayout(new BorderLayout());
/* 407 */       this.cbEnabled = new Checkbox("Monitor Video");
/* 408 */       controlPanel.add("South", this.cbEnabled);
/* 409 */       controlPanel.add("Center", this.controlComponent);
/* 410 */       addPopupMenu(this.controlComponent);
/* 411 */       this.controlComponent = controlPanel;
/* 412 */       controlPanel.setBackground(Color.lightGray);
/*     */     } 
/*     */     
/* 415 */     if (this.cbEnabled != null) {
/* 416 */       this.cbEnabled.setState(isEnabled());
/* 417 */       this.cbEnabled.addItemListener(new ItemListener(this) { private final MonitorAdapter this$0;
/*     */             public void itemStateChanged(ItemEvent ie) {
/* 419 */               this.this$0.setEnabled(this.this$0.cbEnabled.getState());
/*     */             } }
/*     */         );
/*     */     } 
/*     */ 
/*     */     
/* 425 */     return this.controlComponent;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void addPopupMenu(Component visual) {
/* 431 */     this.visualComponent = visual;
/* 432 */     this.rateMenu = new PopupMenu("Monitor Rate");
/*     */     
/* 434 */     ActionListener rateSelect = new ActionListener(this) { private final MonitorAdapter this$0;
/*     */         public void actionPerformed(ActionEvent ae) {
/* 436 */           String action = ae.getActionCommand();
/* 437 */           int space = action.indexOf(" ");
/* 438 */           String rateString = action.substring(0, space);
/*     */           try {
/* 440 */             int rate = Integer.parseInt(rateString);
/* 441 */             this.this$0.setPreviewFrameRate(rate);
/*     */           } catch (Throwable t) {
/* 443 */             if (t instanceof ThreadDeath) {
/* 444 */               throw (ThreadDeath)t;
/*     */             }
/*     */           } 
/*     */         } }
/*     */       ;
/* 449 */     visual.add(this.rateMenu);
/* 450 */     int lastAdded = 0;
/*     */     
/* 452 */     for (int i = 0; i < this.frameRates.length; i++) {
/* 453 */       if (this.frameRates[i] < this.inFrameRate) {
/* 454 */         MenuItem mi = new MenuItem(this.frameRates[i] + " fps");
/* 455 */         this.rateMenu.add(mi);
/* 456 */         mi.addActionListener(rateSelect);
/* 457 */         lastAdded = this.frameRates[i];
/*     */       } 
/*     */     } 
/*     */     
/* 461 */     if (lastAdded < this.inFrameRate) {
/* 462 */       MenuItem menuItem = new MenuItem(this.inFrameRate + " fps");
/* 463 */       this.rateMenu.add(menuItem);
/* 464 */       menuItem.addActionListener(rateSelect);
/*     */     } 
/*     */     
/* 467 */     visual.addMouseListener(this.ml = new MouseAdapter(this) { private final MonitorAdapter this$0;
/*     */           public void mousePressed(MouseEvent me) {
/* 469 */             if (me.isPopupTrigger())
/* 470 */               this.this$0.rateMenu.show(this.this$0.visualComponent, me.getX(), me.getY()); 
/*     */           }
/*     */           
/*     */           public void mouseReleased(MouseEvent me) {
/* 474 */             if (me.isPopupTrigger())
/* 475 */               this.this$0.rateMenu.show(this.this$0.visualComponent, me.getX(), me.getY()); 
/*     */           }
/*     */           
/*     */           public void mouseClicked(MouseEvent me) {
/* 479 */             if (me.isPopupTrigger())
/* 480 */               this.this$0.rateMenu.show(this.this$0.visualComponent, me.getX(), me.getY()); 
/*     */           } }
/*     */       );
/*     */   }
/*     */   
/*     */   public void finalize() {
/* 486 */     if (this.visualComponent != null) {
/* 487 */       this.visualComponent.remove(this.rateMenu);
/* 488 */       this.visualComponent.removeMouseListener(this.ml);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\controls\MonitorAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */