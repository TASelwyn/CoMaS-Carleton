package com.sun.media.controls;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.media.Format;
import javax.media.control.FormatControl;

public class FormatAdapter implements FormatControl, ActionListener {
  protected Format currentFormat;
  
  protected Format[] supportedFormats;
  
  protected boolean enabled;
  
  protected boolean formattable;
  
  protected boolean enableable;
  
  public FormatAdapter(Format format, Format[] supported, boolean enabled, boolean formattable, boolean enableable) {
    this.currentFormat = format;
    this.supportedFormats = supported;
    this.enabled = enabled;
    this.formattable = formattable;
    this.enableable = enableable;
  }
  
  public Format getFormat() {
    return this.currentFormat;
  }
  
  public Format setFormat(Format newFormat) {
    if (this.formattable)
      this.currentFormat = newFormat; 
    return this.currentFormat;
  }
  
  public Format[] getSupportedFormats() {
    return this.supportedFormats;
  }
  
  public boolean isEnabled() {
    return this.enabled;
  }
  
  public void setEnabled(boolean newEnable) {
    if (this.enableable)
      this.enabled = newEnable; 
  }
  
  protected String getName() {
    return "Format";
  }
  
  public Component getControlComponent() {
    return null;
  }
  
  public void actionPerformed(ActionEvent ae) {}
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\controls\FormatAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */