package com.sun.media.controls;

public interface ControlChangeListener {
  void controlChanged(ControlChangeEvent paramControlChangeEvent);
}
