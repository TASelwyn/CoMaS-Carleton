package com.sun.media;

import javax.media.Track;

class MyOutputConnector extends BasicOutputConnector {
  protected Track track;
  
  public MyOutputConnector(Track track) {
    this.track = track;
    this.format = track.getFormat();
  }
  
  public String toString() {
    return super.toString() + ": " + getFormat();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\MyOutputConnector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */