/*     */ package com.sun.media.datasink.rtp;
/*     */ 
/*     */ import com.sun.media.datasink.BasicDataSink;
/*     */ import com.sun.media.rtp.RTPMediaLocator;
/*     */ import java.awt.Component;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.MalformedURLException;
/*     */ import javax.media.IncompatibleSourceException;
/*     */ import javax.media.MediaLocator;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PushBufferDataSource;
/*     */ import javax.media.protocol.PushBufferStream;
/*     */ import javax.media.rtp.RTPManager;
/*     */ import javax.media.rtp.SendStream;
/*     */ import javax.media.rtp.SessionAddress;
/*     */ 
/*     */ 
/*     */ public class Handler
/*     */   extends BasicDataSink
/*     */ {
/*  22 */   private RTPMediaLocator rtpmrl = null;
/*  23 */   RTPManager rtpmanager = null;
/*  24 */   PushBufferDataSource source = null;
/*  25 */   SendStream rtpsendstream = null;
/*     */   
/*     */   public Object getControl(String controlType) {
/*  28 */     return null;
/*     */   }
/*     */   
/*     */   public Object[] getControls() {
/*  32 */     return new Object[0];
/*     */   }
/*     */   
/*     */   public Component getControlComponent() {
/*  36 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
/*  42 */     if (!(source instanceof PushBufferDataSource)) {
/*  43 */       throw new IncompatibleSourceException("Only supports PushBufferDataSource");
/*     */     }
/*  45 */     this.source = (PushBufferDataSource)source;
/*  46 */     PushBufferStream[] streams = this.source.getStreams();
/*  47 */     int numStreams = streams.length;
/*  48 */     System.out.println("streams is " + streams + " : " + numStreams);
/*     */     
/*  50 */     if (streams == null || numStreams <= 0) {
/*  51 */       throw new IOException("source " + source + " doesn't have any streams");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOutputLocator(MediaLocator output) {
/*  62 */     if (this.rtpmrl == null) {
/*  63 */       System.out.println("sink: setOutputLocator " + output);
/*     */       
/*     */       try {
/*  66 */         this.rtpmrl = new RTPMediaLocator(output.toString());
/*     */       } catch (MalformedURLException e) {
/*  68 */         this.rtpmrl = null;
/*     */       } 
/*     */     } else {
/*  71 */       throw new Error("setOutputLocator cannot be called more than once");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaLocator getOutputLocator() {
/*  82 */     return (MediaLocator)this.rtpmrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() throws IOException {
/*  93 */     this.rtpsendstream.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() throws IOException {
/* 102 */     this.rtpsendstream.stop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() throws IOException, SecurityException {
/* 121 */     if (this.rtpmrl == null)
/* 122 */       throw new IOException("No Valid RTP MediaLocator"); 
/*     */     try {
/* 124 */       String address = this.rtpmrl.getSessionAddress();
/* 125 */       int port = this.rtpmrl.getSessionPort();
/* 126 */       int ttl = this.rtpmrl.getTTL();
/* 127 */       this.rtpmanager = RTPManager.newInstance();
/*     */ 
/*     */       
/* 130 */       SessionAddress localaddr = new SessionAddress();
/* 131 */       InetAddress destaddr = InetAddress.getByName(address);
/* 132 */       SessionAddress sessaddr = new SessionAddress(destaddr, port, ttl);
/*     */       
/* 134 */       this.rtpmanager.initialize(localaddr);
/* 135 */       this.rtpmanager.addTarget(sessaddr);
/* 136 */       this.rtpsendstream = this.rtpmanager.createSendStream((DataSource)this.source, 0);
/*     */     } catch (Exception e) {
/*     */       
/* 139 */       throw new IOException(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 154 */     if (this.rtpmanager != null) {
/* 155 */       this.rtpmanager.removeTargets("DataSink closed");
/* 156 */       this.rtpmanager.dispose();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/* 166 */     return "RTP";
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\datasink\rtp\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */