package com.sun.media.datasink;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Vector;
import javax.media.DataSink;
import javax.media.IncompatibleSourceException;
import javax.media.MediaLocator;
import javax.media.datasink.DataSinkErrorEvent;
import javax.media.datasink.DataSinkEvent;
import javax.media.datasink.DataSinkListener;
import javax.media.datasink.EndOfStreamEvent;
import javax.media.protocol.DataSource;

public abstract class BasicDataSink implements DataSink {
  protected Vector listeners = new Vector(1);
  
  public void addDataSinkListener(DataSinkListener dsl) {
    if (dsl != null && 
      !this.listeners.contains(dsl))
      this.listeners.addElement(dsl); 
  }
  
  public void removeDataSinkListener(DataSinkListener dsl) {
    if (dsl != null)
      this.listeners.removeElement(dsl); 
  }
  
  protected void sendEvent(DataSinkEvent event) {
    if (!this.listeners.isEmpty())
      synchronized (this.listeners) {
        Enumeration list = this.listeners.elements();
        while (list.hasMoreElements()) {
          DataSinkListener listener = list.nextElement();
          listener.dataSinkUpdate(event);
        } 
      }  
  }
  
  protected void removeAllListeners() {
    this.listeners.removeAllElements();
  }
  
  protected final void sendEndofStreamEvent() {
    sendEvent((DataSinkEvent)new EndOfStreamEvent(this));
  }
  
  protected final void sendDataSinkErrorEvent(String reason) {
    sendEvent((DataSinkEvent)new DataSinkErrorEvent(this, reason));
  }
  
  public abstract String getContentType();
  
  public abstract void close();
  
  public abstract void open() throws IOException, SecurityException;
  
  public abstract void stop() throws IOException;
  
  public abstract void start() throws IOException;
  
  public abstract MediaLocator getOutputLocator();
  
  public abstract void setOutputLocator(MediaLocator paramMediaLocator);
  
  public abstract void setSource(DataSource paramDataSource) throws IOException, IncompatibleSourceException;
  
  public abstract Object getControl(String paramString);
  
  public abstract Object[] getControls();
}
