package com.sun.media.sdp;

import java.io.ByteArrayInputStream;
import java.util.Vector;

public class SessionDescription extends Parser {
  public Vector timeDescriptions;
  
  public Vector sessionAttributes;
  
  public boolean connectionIncluded;
  
  public String version;
  
  public String origin;
  
  public String sessionName;
  
  public String sessionInfo;
  
  public String uri;
  
  public String email;
  
  public String phone;
  
  public String connectionInfo;
  
  public String bandwidthInfo;
  
  public String timezoneAdjustment;
  
  public String encryptionKey;
  
  public SessionDescription(ByteArrayInputStream bin) {
    this.connectionIncluded = false;
    this.version = getLine(bin);
    if (getToken(bin, "o=", true))
      this.origin = getLine(bin); 
    if (getToken(bin, "s=", true))
      this.sessionName = getLine(bin); 
    if (getToken(bin, "i=", false))
      this.sessionInfo = getLine(bin); 
    if (getToken(bin, "u=", false))
      this.uri = getLine(bin); 
    if (getToken(bin, "e=", false))
      this.email = getLine(bin); 
    if (getToken(bin, "e=", false))
      this.email = getLine(bin); 
    if (getToken(bin, "p=", false))
      this.phone = getLine(bin); 
    if (getToken(bin, "c=", false)) {
      this.connectionIncluded = true;
      this.connectionInfo = getLine(bin);
    } 
    if (getToken(bin, "b=", false)) {
      this.bandwidthInfo = getLine(bin);
      System.out.println("bandwidth info: " + this.bandwidthInfo);
    } 
    this.timeDescriptions = new Vector();
    boolean found = getToken(bin, "t=", true);
    while (found) {
      TimeDescription timeDescription = new TimeDescription(bin);
      this.timeDescriptions.addElement(timeDescription);
      found = getToken(bin, "t=", false);
    } 
    if (getToken(bin, "z=", false))
      this.timezoneAdjustment = getLine(bin); 
    if (getToken(bin, "k=", false))
      this.encryptionKey = getLine(bin); 
    this.sessionAttributes = new Vector();
    found = getToken(bin, "a=", false);
    while (found) {
      String sessionAttribute = getLine(bin);
      int index = sessionAttribute.indexOf(':');
      if (index > 0) {
        String name = sessionAttribute.substring(0, index);
        String value = sessionAttribute.substring(index + 1);
        MediaAttribute attribute = new MediaAttribute(name, value);
        this.sessionAttributes.addElement(attribute);
      } 
      found = getToken(bin, "a=", false);
    } 
  }
  
  public MediaAttribute getSessionAttribute(String name) {
    MediaAttribute attribute = null;
    if (this.sessionAttributes != null)
      for (int i = 0; i < this.sessionAttributes.size(); i++) {
        MediaAttribute entry = this.sessionAttributes.elementAt(i);
        if (entry.getName().equals(name)) {
          attribute = entry;
          break;
        } 
      }  
    return attribute;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\sdp\SessionDescription.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */