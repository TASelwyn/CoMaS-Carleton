package com.sun.media.sdp;

import java.io.ByteArrayInputStream;
import java.util.Vector;

public class MediaDescription extends Parser {
  public String name;
  
  public String port;
  
  public String protocol;
  
  public int payload_type;
  
  public String payload;
  
  public String mediaTitle;
  
  public String connectionInfo;
  
  public String bandwidthInfo;
  
  public String encryptionKey;
  
  public Vector mediaAttributes;
  
  public MediaDescription(ByteArrayInputStream bin, boolean connectionIncluded) {
    String line = getLine(bin);
    int end = line.indexOf(' ');
    this.name = line.substring(0, end);
    int start = end + 1;
    end = line.indexOf(' ', start);
    this.port = line.substring(start, end);
    start = end + 1;
    end = line.indexOf(' ', start);
    this.protocol = line.substring(start, end);
    start = end + 1;
    this.payload = line.substring(start);
    try {
      this.payload_type = (new Integer(this.payload)).intValue();
    } catch (Exception e) {
      this.payload_type = -1;
    } 
    if (getToken(bin, "i=", false)) {
      this.mediaTitle = getLine(bin);
      System.out.println("media title: " + this.mediaTitle);
    } 
    boolean mandatory = true;
    if (connectionIncluded)
      mandatory = false; 
    if (getToken(bin, "c=", mandatory)) {
      this.connectionInfo = getLine(bin);
      System.out.println("connection info: " + this.connectionInfo);
    } 
    if (getToken(bin, "b=", false)) {
      this.bandwidthInfo = getLine(bin);
      System.out.println("bandwidth info: " + this.bandwidthInfo);
    } 
    if (getToken(bin, "k=", false)) {
      this.encryptionKey = getLine(bin);
      System.out.println("encryption key: " + this.encryptionKey);
    } 
    this.mediaAttributes = new Vector();
    boolean found = getToken(bin, "a=", false);
    while (found) {
      String mediaAttribute = getLine(bin);
      int index = mediaAttribute.indexOf(':');
      if (index > 0) {
        String name = mediaAttribute.substring(0, index);
        String value = mediaAttribute.substring(index + 1);
        MediaAttribute attribute = new MediaAttribute(name, value);
        this.mediaAttributes.addElement(attribute);
      } 
      found = getToken(bin, "a=", false);
    } 
  }
  
  public MediaAttribute getMediaAttribute(String name) {
    MediaAttribute attribute = null;
    if (this.mediaAttributes != null)
      for (int i = 0; i < this.mediaAttributes.size(); i++) {
        MediaAttribute entry = this.mediaAttributes.elementAt(i);
        if (entry.getName().equals(name)) {
          attribute = entry;
          break;
        } 
      }  
    return attribute;
  }
}
