/*    */ package com.sun.media.sdp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MediaAttribute
/*    */ {
/*    */   private String name;
/*    */   private String value;
/*    */   
/*    */   public MediaAttribute(String name, String value) {
/* 14 */     this.name = name;
/* 15 */     this.value = value;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 19 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getValue() {
/* 23 */     return this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\sdp\MediaAttribute.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */