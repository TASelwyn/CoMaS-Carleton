package com.sun.media.sdp;

import java.io.ByteArrayInputStream;
import java.util.Vector;

public class TimeDescription extends Parser {
  public String timeActive;
  
  public Vector repeatTimes;
  
  public TimeDescription(ByteArrayInputStream bin) {
    this.timeActive = getLine(bin);
    this.repeatTimes = new Vector();
    boolean found = getToken(bin, "r=", false);
    while (found) {
      String repeatTime = getLine(bin);
      this.repeatTimes.addElement(repeatTime);
      found = getToken(bin, "r=", false);
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\sdp\TimeDescription.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */