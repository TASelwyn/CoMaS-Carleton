package com.sun.media.sdp;

import java.io.ByteArrayInputStream;
import java.util.Vector;

public class SdpParser extends Parser {
  public SessionDescription sessionDescription;
  
  public Vector mediaDescriptions;
  
  public SdpParser(byte[] data) {
    init();
    ByteArrayInputStream bin = new ByteArrayInputStream(data);
    parseData(bin);
  }
  
  public void parseData(ByteArrayInputStream bin) {
    if (getToken(bin, "v=", true)) {
      this.sessionDescription = new SessionDescription(bin);
      this.mediaDescriptions = new Vector();
      boolean found = getToken(bin, "m=", false);
      while (found) {
        MediaDescription mediaDescription = new MediaDescription(bin, this.sessionDescription.connectionIncluded);
        this.mediaDescriptions.addElement(mediaDescription);
        found = getToken(bin, "m=", false);
      } 
    } 
  }
  
  public MediaAttribute getSessionAttribute(String name) {
    MediaAttribute attribute = null;
    if (this.sessionDescription != null)
      attribute = this.sessionDescription.getSessionAttribute(name); 
    return attribute;
  }
  
  public MediaDescription getMediaDescription(String name) {
    MediaDescription description = null;
    if (this.mediaDescriptions != null)
      for (int i = 0; i < this.mediaDescriptions.size(); i++) {
        MediaDescription entry = this.mediaDescriptions.elementAt(i);
        if (entry.name.equals(name)) {
          description = entry;
          break;
        } 
      }  
    return description;
  }
  
  public Vector getMediaDescriptions() {
    return this.mediaDescriptions;
  }
  
  static String input = "v=0\r\no=mhandley 2890844526 2890842807 IN IP4 126.16.64.4\r\ns=SDP Seminar\r\ni=A Seminar on the session description protocol\r\nu=http://www.cs.ucl.ac.uk/staff/M.Handley/sdp.03.ps\r\ne=mjb@isi.edu (Mark Handley)\r\nc=IN IP4 224.2.17.12/127\r\nt=2873397496 2873404696\r\na=recvonly\r\nm=audio 49170 RTP/AVP 0\r\nm=video 51372 RTP/AVP 31\r\nm=application 32416 udp wbr\na=orient:portrait\r\n";
  
  public static void main(String[] args) {
    new SdpParser(input.getBytes());
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\sdp\SdpParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */