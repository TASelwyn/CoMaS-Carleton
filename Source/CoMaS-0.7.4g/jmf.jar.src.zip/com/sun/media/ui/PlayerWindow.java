package com.sun.media.ui;

import com.sun.media.util.JMFI18N;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Insets;
import java.awt.MenuItem;
import java.awt.Panel;
import java.awt.PopupMenu;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.media.CachingControl;
import javax.media.CachingControlEvent;
import javax.media.Control;
import javax.media.ControllerEvent;
import javax.media.ControllerListener;
import javax.media.Player;
import javax.media.SizeChangeEvent;
import javax.media.Time;
import javax.media.control.MonitorControl;

public class PlayerWindow extends Frame implements ControllerListener {
  private static final String MENU_ZOOM_1_2 = JMFI18N.getResource("mediaplayer.zoom.1:2");
  
  private static final String MENU_ZOOM_1_1 = JMFI18N.getResource("mediaplayer.zoom.1:1");
  
  private static final String MENU_ZOOM_2_1 = JMFI18N.getResource("mediaplayer.zoom.2:1");
  
  private static final String MENU_ZOOM_4_1 = JMFI18N.getResource("mediaplayer.zoom.4:1");
  
  private static final String MENU_ZOOM = JMFI18N.getResource("mediaplayer.menu.zoom");
  
  Player player;
  
  Panel framePanel;
  
  ComponentListener cl;
  
  ComponentListener fcl;
  
  WindowListener wl;
  
  MouseListener ml;
  
  Component controlComp = null;
  
  Component visualComp = null;
  
  Insets insets;
  
  PopupMenu zoomMenu = null;
  
  boolean windowCreated = false;
  
  boolean newVideo = true;
  
  boolean panelResized = false;
  
  boolean autoStart = true;
  
  boolean autoLoop = true;
  
  Component progressBar = null;
  
  private Integer playerLock = new Integer(1);
  
  public PlayerWindow(Player player) {
    this(player, JMFI18N.getResource("mediaplayer.windowtitle"), true, true);
  }
  
  public PlayerWindow(Player player, String title) {
    this(player, title, true, true);
  }
  
  public PlayerWindow(Player player, String title, boolean autoStart) {
    this(player, title, autoStart, true);
  }
  
  public PlayerWindow(Player player, String title, boolean autoStart, boolean autoLoop) {
    super(title);
    this.autoStart = autoStart;
    this.autoLoop = autoLoop;
    this.player = player;
    setLayout(new BorderLayout());
    this.framePanel = new Panel();
    this.framePanel.setLayout(null);
    add(this.framePanel, "Center");
    this.insets = getInsets();
    setSize(this.insets.left + this.insets.right + 320, this.insets.top + this.insets.bottom + 30);
    setVisible(true);
    addWindowListener(this.wl = new WindowAdapter(this) {
          private final PlayerWindow this$0;
          
          public void windowClosing(WindowEvent we) {
            this.this$0.killThePlayer();
          }
        });
    this.framePanel.addComponentListener(this.fcl = new ComponentAdapter(this) {
          private final PlayerWindow this$0;
          
          public void componentResized(ComponentEvent ce) {
            this.this$0.panelResized = true;
            this.this$0.doResize();
          }
        });
    addComponentListener(this.fcl = new ComponentAdapter(this) {
          private final PlayerWindow this$0;
          
          public void componentResized(ComponentEvent ce) {
            this.this$0.insets = this.this$0.getInsets();
            Dimension dim = this.this$0.getSize();
            this.this$0.framePanel.setSize(dim.width - this.this$0.insets.left - this.this$0.insets.right, dim.height - this.this$0.insets.top - this.this$0.insets.bottom);
          }
        });
    player.addControllerListener(this);
    player.realize();
  }
  
  void sleep(long time) {
    try {
      Thread.currentThread();
      Thread.sleep(time);
    } catch (Exception e) {}
  }
  
  public void addNotify() {
    super.addNotify();
    this.windowCreated = true;
    invalidate();
  }
  
  public void doResize() {
    Dimension d = this.framePanel.getSize();
    int videoHeight = d.height;
    if (this.controlComp != null) {
      videoHeight -= (this.controlComp.getPreferredSize()).height;
      if (videoHeight < 2)
        videoHeight = 2; 
      if (d.width < 80)
        d.width = 80; 
      this.controlComp.setBounds(0, videoHeight, d.width, (this.controlComp.getPreferredSize()).height);
      this.controlComp.invalidate();
    } 
    if (this.visualComp != null)
      this.visualComp.setBounds(0, 0, d.width, videoHeight); 
    this.framePanel.validate();
  }
  
  public void killThePlayer() {
    synchronized (this.playerLock) {
      if (this.visualComp != null) {
        this.framePanel.remove(this.visualComp);
        this.visualComp = null;
      } 
      if (this.controlComp != null) {
        this.framePanel.remove(this.controlComp);
        this.controlComp = null;
      } 
      if (this.player != null)
        this.player.close(); 
    } 
  }
  
  public void controllerUpdate(ControllerEvent ce) {
    synchronized (this.playerLock) {
      if (ce instanceof javax.media.RealizeCompleteEvent) {
        int width = 320;
        int height = 0;
        this.insets = getInsets();
        if (this.progressBar != null)
          this.framePanel.remove(this.progressBar); 
        if ((this.visualComp = this.player.getVisualComponent()) != null) {
          width = (this.visualComp.getPreferredSize()).width;
          height = (this.visualComp.getPreferredSize()).height;
          this.framePanel.add(this.visualComp);
          this.visualComp.setBounds(0, 0, width, height);
          addPopupMenu(this.visualComp);
        } else {
          MonitorControl mc = (MonitorControl)this.player.getControl("javax.media.control.MonitorControl");
          if (mc != null) {
            Control[] controls = this.player.getControls();
            Panel mainPanel = new Panel(new BorderLayout());
            Panel currentPanel = mainPanel;
            for (int i = 0; i < controls.length; i++) {
              if (controls[i] instanceof MonitorControl) {
                mc = (MonitorControl)controls[i];
                mc.setEnabled(true);
                if (mc.getControlComponent() != null) {
                  currentPanel.add("North", mc.getControlComponent());
                  Panel newPanel = new Panel(new BorderLayout());
                  currentPanel.add("South", newPanel);
                  currentPanel = newPanel;
                } 
              } 
            } 
            this.visualComp = mainPanel;
            width = (this.visualComp.getPreferredSize()).width;
            height = (this.visualComp.getPreferredSize()).height;
            this.framePanel.add(this.visualComp);
            this.visualComp.setBounds(0, 0, width, height);
          } 
        } 
        if ((this.controlComp = this.player.getControlPanelComponent()) != null) {
          int prefHeight = (this.controlComp.getPreferredSize()).height;
          this.framePanel.add(this.controlComp);
          this.controlComp.setBounds(0, height, width, prefHeight);
          height += prefHeight;
        } 
        setSize(width + this.insets.left + this.insets.right, height + this.insets.top + this.insets.bottom);
        if (this.autoStart)
          this.player.prefetch(); 
      } else if (ce instanceof javax.media.PrefetchCompleteEvent) {
        if (this.visualComp != null) {
          Dimension vSize = this.visualComp.getPreferredSize();
          if (this.controlComp != null)
            vSize.height += (this.controlComp.getPreferredSize()).height; 
          this.panelResized = false;
          setSize(vSize.width + this.insets.left + this.insets.right, vSize.height + this.insets.top + this.insets.bottom);
          int waited = 0;
          while (!this.panelResized && waited < 2000) {
            try {
              waited += 50;
              Thread.currentThread();
              Thread.sleep(50L);
              Thread.currentThread();
              Thread.yield();
            } catch (Exception e) {}
          } 
        } else {
          int height = 1;
          if (this.controlComp != null)
            height = (this.controlComp.getPreferredSize()).height; 
          setSize(320 + this.insets.left + this.insets.right, height + this.insets.top + this.insets.bottom);
        } 
        if (this.autoStart && 
          this.player != null && this.player.getTargetState() != 600)
          this.player.start(); 
      } else if (ce instanceof javax.media.EndOfMediaEvent) {
        if (this.autoLoop) {
          this.player.setMediaTime(new Time(0L));
          this.player.start();
        } 
      } else if (ce instanceof javax.media.ControllerErrorEvent) {
        System.err.println("Received controller error");
        killThePlayer();
        dispose();
      } else if (ce instanceof SizeChangeEvent) {
        if (this.framePanel != null) {
          SizeChangeEvent sce = (SizeChangeEvent)ce;
          int nooWidth = sce.getWidth();
          int nooHeight = sce.getHeight();
          if (this.controlComp != null)
            nooHeight += (this.controlComp.getPreferredSize()).height; 
          if ((this.framePanel.getSize()).width != nooWidth || (this.framePanel.getSize()).height != nooHeight) {
            setSize(nooWidth + this.insets.left + this.insets.right, nooHeight + this.insets.top + this.insets.bottom);
          } else {
            doResize();
          } 
          if (this.controlComp != null)
            this.controlComp.invalidate(); 
        } 
      } else if (ce instanceof javax.media.format.FormatChangeEvent) {
        Dimension vSize = new Dimension(320, 0);
        Component oldVisualComp = this.visualComp;
        if ((this.visualComp = this.player.getVisualComponent()) != null && 
          oldVisualComp != this.visualComp) {
          if (oldVisualComp != null && this.zoomMenu != null)
            oldVisualComp.remove(this.zoomMenu); 
          this.framePanel.remove(oldVisualComp);
          vSize = this.visualComp.getPreferredSize();
          this.framePanel.add(this.visualComp);
          this.visualComp.setBounds(0, 0, vSize.width, vSize.height);
          addPopupMenu(this.visualComp);
        } 
        Component oldComp = this.controlComp;
        if ((this.controlComp = this.player.getControlPanelComponent()) != null && 
          oldComp != this.controlComp) {
          this.framePanel.remove(oldComp);
          this.framePanel.add(this.controlComp);
          if (this.controlComp != null) {
            int prefHeight = (this.controlComp.getPreferredSize()).height;
            this.controlComp.setBounds(0, vSize.height, vSize.width, prefHeight);
          } 
        } 
      } else if (ce instanceof javax.media.ControllerClosedEvent) {
        if (this.visualComp != null) {
          if (this.zoomMenu != null)
            this.visualComp.remove(this.zoomMenu); 
          this.visualComp.removeMouseListener(this.ml);
        } 
        removeWindowListener(this.wl);
        removeComponentListener(this.cl);
        if (this.framePanel != null)
          this.framePanel.removeAll(); 
        this.player = null;
        this.visualComp = null;
        this.controlComp = null;
        sleep(200L);
        dispose();
      } else if (ce instanceof CachingControlEvent) {
        CachingControl cc = ((CachingControlEvent)ce).getCachingControl();
        if (cc != null && this.progressBar == null) {
          this.progressBar = cc.getControlComponent();
          if (this.progressBar == null)
            this.progressBar = cc.getProgressBarComponent(); 
          if (this.progressBar != null) {
            this.framePanel.add(this.progressBar);
            Dimension prefSize = this.progressBar.getPreferredSize();
            this.progressBar.setBounds(0, 0, prefSize.width, prefSize.height);
            this.insets = getInsets();
            this.framePanel.setSize(prefSize.width, prefSize.height);
            setSize(this.insets.left + this.insets.right + prefSize.width, this.insets.top + this.insets.bottom + prefSize.height);
          } 
        } 
      } 
    } 
  }
  
  public void zoomTo(float z) {
    if (this.visualComp != null) {
      this.insets = getInsets();
      Dimension d = this.visualComp.getPreferredSize();
      d.width = (int)(d.width * z);
      d.height = (int)(d.height * z);
      if (this.controlComp != null)
        d.height += (this.controlComp.getPreferredSize()).height; 
      setSize(d.width + this.insets.left + this.insets.right, d.height + this.insets.top + this.insets.bottom);
    } 
  }
  
  private void addPopupMenu(Component visual) {
    this.zoomMenu = new PopupMenu(MENU_ZOOM);
    ActionListener zoomSelect = new ActionListener(this) {
        private final PlayerWindow this$0;
        
        public void actionPerformed(ActionEvent ae) {
          String action = ae.getActionCommand();
          if (action.equals(PlayerWindow.MENU_ZOOM_1_2)) {
            this.this$0.zoomTo(0.5F);
          } else if (action.equals(PlayerWindow.MENU_ZOOM_1_1)) {
            this.this$0.zoomTo(1.0F);
          } else if (action.equals(PlayerWindow.MENU_ZOOM_2_1)) {
            this.this$0.zoomTo(2.0F);
          } else if (action.equals(PlayerWindow.MENU_ZOOM_4_1)) {
            this.this$0.zoomTo(4.0F);
          } 
        }
      };
    visual.add(this.zoomMenu);
    MenuItem mi = new MenuItem(MENU_ZOOM_1_2);
    this.zoomMenu.add(mi);
    mi.addActionListener(zoomSelect);
    mi = new MenuItem(MENU_ZOOM_1_1);
    this.zoomMenu.add(mi);
    mi.addActionListener(zoomSelect);
    mi = new MenuItem(MENU_ZOOM_2_1);
    this.zoomMenu.add(mi);
    mi.addActionListener(zoomSelect);
    mi = new MenuItem(MENU_ZOOM_4_1);
    this.zoomMenu.add(mi);
    mi.addActionListener(zoomSelect);
    visual.addMouseListener(this.ml = new MouseAdapter(this) {
          private final PlayerWindow this$0;
          
          public void mousePressed(MouseEvent me) {
            if (me.isPopupTrigger())
              this.this$0.zoomMenu.show(this.this$0.visualComp, me.getX(), me.getY()); 
          }
          
          public void mouseReleased(MouseEvent me) {
            if (me.isPopupTrigger())
              this.this$0.zoomMenu.show(this.this$0.visualComp, me.getX(), me.getY()); 
          }
          
          public void mouseClicked(MouseEvent me) {
            if (me.isPopupTrigger())
              this.this$0.zoomMenu.show(this.this$0.visualComp, me.getX(), me.getY()); 
          }
        });
  }
}
