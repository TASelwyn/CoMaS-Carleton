package com.sun.media.ui;

import com.sun.media.util.JMFI18N;
import java.awt.Choice;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Hashtable;

class VideoSizeControl extends Panel implements ItemListener, ComponentListener {
  private Choice comboSize;
  
  private Panel panelCustom;
  
  private TextField textWidth;
  
  private TextField textHeight;
  
  private Label labelX;
  
  private Hashtable htSizes = new Hashtable();
  
  private VideoSize sizeVideoDefault = null;
  
  private ActionListener listener;
  
  public static final String ACTION_SIZE_CHANGED = "Size Changed";
  
  static final String CUSTOM_STRING = JMFI18N.getResource("formatchooser.custom");
  
  public VideoSizeControl() {
    this(null);
  }
  
  public VideoSizeControl(VideoSize sizeVideoDefault) {
    this.sizeVideoDefault = sizeVideoDefault;
    init();
  }
  
  public void setEnabled(boolean boolEnable) {
    super.setEnabled(boolEnable);
    this.comboSize.setEnabled(boolEnable);
    this.textWidth.setEnabled(boolEnable);
    this.textHeight.setEnabled(boolEnable);
    this.labelX.setEnabled(boolEnable);
    if (boolEnable == true)
      updateFields(); 
  }
  
  public void addActionListener(ActionListener listener) {
    this.listener = listener;
  }
  
  public VideoSize getVideoSize() {
    VideoSize videoSize;
    String strItem = this.comboSize.getSelectedItem();
    Object objSize = this.htSizes.get(strItem);
    if (objSize == null || !(objSize instanceof VideoSize) || strItem.equals(CUSTOM_STRING)) {
      boolean bool1, bool2;
      try {
        bool1 = Integer.valueOf(this.textWidth.getText()).intValue();
      } catch (Exception exception) {
        bool1 = false;
      } 
      try {
        bool2 = Integer.valueOf(this.textHeight.getText()).intValue();
      } catch (Exception exception) {
        bool2 = false;
      } 
      videoSize = new VideoSize(bool1, bool2);
    } else {
      videoSize = (VideoSize)objSize;
    } 
    return videoSize;
  }
  
  public void addItem(VideoSize sizeVideo) {
    String str;
    if (sizeVideo == null) {
      sizeVideo = new VideoSize(-1, -1);
      str = CUSTOM_STRING;
    } else {
      str = sizeVideo.toString();
    } 
    if (this.htSizes.containsKey(str))
      return; 
    this.comboSize.addItem(str);
    this.htSizes.put(str, sizeVideo);
    if (this.comboSize.getItemCount() == 1)
      updateFields(); 
  }
  
  public void removeAll() {
    this.comboSize.removeAll();
    this.htSizes = new Hashtable();
    updateFields();
  }
  
  public void select(VideoSize sizeVideo) {
    if (sizeVideo == null) {
      this.comboSize.select(CUSTOM_STRING);
    } else {
      this.comboSize.select(sizeVideo.toString());
    } 
    updateFields();
  }
  
  public void select(int nIndex) {
    this.comboSize.select(nIndex);
    updateFields();
  }
  
  public int getItemCount() {
    return this.comboSize.getItemCount();
  }
  
  private void init() {
    setLayout(new GridLayout(0, 1, 4, 4));
    this.comboSize = new Choice();
    this.comboSize.addItem(CUSTOM_STRING);
    this.comboSize.addItemListener(this);
    add(this.comboSize);
    this.panelCustom = new Panel(null);
    this.panelCustom.addComponentListener(this);
    add(this.panelCustom);
    if (this.sizeVideoDefault == null) {
      this.textWidth = new TextField(3);
    } else {
      this.textWidth = new TextField("" + this.sizeVideoDefault.width, 3);
    } 
    this.panelCustom.add(this.textWidth, "Center");
    this.labelX = new Label("x", 1);
    this.panelCustom.add(this.labelX, "West");
    if (this.sizeVideoDefault == null) {
      this.textHeight = new TextField(3);
    } else {
      this.textHeight = new TextField("" + this.sizeVideoDefault.height, 3);
    } 
    this.panelCustom.add(this.textHeight, "Center");
    updateFields();
  }
  
  private void updateFields() {
    boolean bool;
    String strItem = this.comboSize.getSelectedItem();
    if (strItem == null || strItem.equals(CUSTOM_STRING)) {
      bool = true;
    } else {
      VideoSize sizeVideo = (VideoSize)this.htSizes.get(strItem);
      this.textWidth.setText("" + sizeVideo.width);
      this.textHeight.setText("" + sizeVideo.height);
      bool = false;
    } 
    this.textWidth.setEnabled(bool);
    this.textHeight.setEnabled(bool);
    this.labelX.setEnabled(bool);
  }
  
  private void resizeCustomFields() {
    Dimension dimPanel = this.panelCustom.getSize();
    Dimension dimLabelX = this.labelX.getPreferredSize();
    int nWidth = (dimPanel.width - dimLabelX.width) / 2;
    this.textWidth.setBounds(0, 0, nWidth, dimPanel.height);
    this.labelX.setBounds(nWidth, 0, dimLabelX.width, dimPanel.height);
    this.textHeight.setBounds(nWidth + dimLabelX.width, 0, nWidth, dimPanel.height);
  }
  
  public void itemStateChanged(ItemEvent event) {
    Object objectSource = event.getSource();
    if (objectSource != this.comboSize)
      return; 
    updateFields();
    if (this.listener != null) {
      ActionEvent eventAction = new ActionEvent(this, 1001, "Size Changed");
      this.listener.actionPerformed(eventAction);
    } 
  }
  
  public void componentResized(ComponentEvent event) {
    resizeCustomFields();
  }
  
  public void componentMoved(ComponentEvent event) {}
  
  public void componentShown(ComponentEvent event) {}
  
  public void componentHidden(ComponentEvent event) {}
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\VideoSizeControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */