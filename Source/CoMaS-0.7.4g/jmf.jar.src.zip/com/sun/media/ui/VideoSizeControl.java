/*      */ package com.sun.media.ui;
/*      */ 
/*      */ import com.sun.media.util.JMFI18N;
/*      */ import java.awt.Choice;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.GridLayout;
/*      */ import java.awt.Label;
/*      */ import java.awt.Panel;
/*      */ import java.awt.TextField;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.ComponentEvent;
/*      */ import java.awt.event.ComponentListener;
/*      */ import java.awt.event.ItemEvent;
/*      */ import java.awt.event.ItemListener;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class VideoSizeControl
/*      */   extends Panel
/*      */   implements ItemListener, ComponentListener
/*      */ {
/*      */   private Choice comboSize;
/*      */   private Panel panelCustom;
/*      */   private TextField textWidth;
/*      */   private TextField textHeight;
/*      */   private Label labelX;
/*  870 */   private Hashtable htSizes = new Hashtable();
/*  871 */   private VideoSize sizeVideoDefault = null;
/*      */ 
/*      */   
/*      */   private ActionListener listener;
/*      */   
/*      */   public static final String ACTION_SIZE_CHANGED = "Size Changed";
/*      */   
/*  878 */   static final String CUSTOM_STRING = JMFI18N.getResource("formatchooser.custom");
/*      */   
/*      */   public VideoSizeControl() {
/*  881 */     this(null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public VideoSizeControl(VideoSize sizeVideoDefault) {
/*  887 */     this.sizeVideoDefault = sizeVideoDefault;
/*  888 */     init();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEnabled(boolean boolEnable) {
/*  908 */     super.setEnabled(boolEnable);
/*      */     
/*  910 */     this.comboSize.setEnabled(boolEnable);
/*  911 */     this.textWidth.setEnabled(boolEnable);
/*  912 */     this.textHeight.setEnabled(boolEnable);
/*  913 */     this.labelX.setEnabled(boolEnable);
/*      */     
/*  915 */     if (boolEnable == true)
/*  916 */       updateFields(); 
/*      */   }
/*      */   
/*      */   public void addActionListener(ActionListener listener) {
/*  920 */     this.listener = listener;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public VideoSize getVideoSize() {
/*      */     VideoSize videoSize;
/*  930 */     String strItem = this.comboSize.getSelectedItem();
/*  931 */     Object objSize = this.htSizes.get(strItem);
/*  932 */     if (objSize == null || !(objSize instanceof VideoSize) || strItem.equals(CUSTOM_STRING)) {
/*      */       boolean bool1, bool2;
/*      */       try {
/*  935 */         bool1 = Integer.valueOf(this.textWidth.getText()).intValue();
/*      */       } catch (Exception exception) {
/*      */         
/*  938 */         bool1 = false;
/*      */       } 
/*      */       try {
/*  941 */         bool2 = Integer.valueOf(this.textHeight.getText()).intValue();
/*      */       } catch (Exception exception) {
/*      */         
/*  944 */         bool2 = false;
/*      */       } 
/*  946 */       videoSize = new VideoSize(bool1, bool2);
/*      */     } else {
/*      */       
/*  949 */       videoSize = (VideoSize)objSize;
/*      */     } 
/*  951 */     return videoSize;
/*      */   }
/*      */ 
/*      */   
/*      */   public void addItem(VideoSize sizeVideo) {
/*      */     String str;
/*  957 */     if (sizeVideo == null) {
/*  958 */       sizeVideo = new VideoSize(-1, -1);
/*  959 */       str = CUSTOM_STRING;
/*      */     } else {
/*      */       
/*  962 */       str = sizeVideo.toString();
/*      */     } 
/*      */     
/*  965 */     if (this.htSizes.containsKey(str)) {
/*      */       return;
/*      */     }
/*  968 */     this.comboSize.addItem(str);
/*  969 */     this.htSizes.put(str, sizeVideo);
/*      */     
/*  971 */     if (this.comboSize.getItemCount() == 1)
/*  972 */       updateFields(); 
/*      */   }
/*      */   
/*      */   public void removeAll() {
/*  976 */     this.comboSize.removeAll();
/*  977 */     this.htSizes = new Hashtable();
/*  978 */     updateFields();
/*      */   }
/*      */   
/*      */   public void select(VideoSize sizeVideo) {
/*  982 */     if (sizeVideo == null) {
/*  983 */       this.comboSize.select(CUSTOM_STRING);
/*      */     } else {
/*  985 */       this.comboSize.select(sizeVideo.toString());
/*  986 */     }  updateFields();
/*      */   }
/*      */   
/*      */   public void select(int nIndex) {
/*  990 */     this.comboSize.select(nIndex);
/*  991 */     updateFields();
/*      */   }
/*      */   
/*      */   public int getItemCount() {
/*  995 */     return this.comboSize.getItemCount();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void init() {
/* 1001 */     setLayout(new GridLayout(0, 1, 4, 4));
/*      */     
/* 1003 */     this.comboSize = new Choice();
/* 1004 */     this.comboSize.addItem(CUSTOM_STRING);
/* 1005 */     this.comboSize.addItemListener(this);
/* 1006 */     add(this.comboSize);
/*      */     
/* 1008 */     this.panelCustom = new Panel(null);
/* 1009 */     this.panelCustom.addComponentListener(this);
/* 1010 */     add(this.panelCustom);
/*      */     
/* 1012 */     if (this.sizeVideoDefault == null) {
/* 1013 */       this.textWidth = new TextField(3);
/*      */     } else {
/* 1015 */       this.textWidth = new TextField("" + this.sizeVideoDefault.width, 3);
/* 1016 */     }  this.panelCustom.add(this.textWidth, "Center");
/*      */     
/* 1018 */     this.labelX = new Label("x", 1);
/* 1019 */     this.panelCustom.add(this.labelX, "West");
/* 1020 */     if (this.sizeVideoDefault == null) {
/* 1021 */       this.textHeight = new TextField(3);
/*      */     } else {
/* 1023 */       this.textHeight = new TextField("" + this.sizeVideoDefault.height, 3);
/* 1024 */     }  this.panelCustom.add(this.textHeight, "Center");
/*      */     
/* 1026 */     updateFields();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateFields() {
/*      */     boolean bool;
/* 1035 */     String strItem = this.comboSize.getSelectedItem();
/* 1036 */     if (strItem == null || strItem.equals(CUSTOM_STRING)) {
/* 1037 */       bool = true;
/*      */     } else {
/*      */       
/* 1040 */       VideoSize sizeVideo = (VideoSize)this.htSizes.get(strItem);
/* 1041 */       this.textWidth.setText("" + sizeVideo.width);
/* 1042 */       this.textHeight.setText("" + sizeVideo.height);
/* 1043 */       bool = false;
/*      */     } 
/*      */     
/* 1046 */     this.textWidth.setEnabled(bool);
/* 1047 */     this.textHeight.setEnabled(bool);
/* 1048 */     this.labelX.setEnabled(bool);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void resizeCustomFields() {
/* 1056 */     Dimension dimPanel = this.panelCustom.getSize();
/* 1057 */     Dimension dimLabelX = this.labelX.getPreferredSize();
/* 1058 */     int nWidth = (dimPanel.width - dimLabelX.width) / 2;
/* 1059 */     this.textWidth.setBounds(0, 0, nWidth, dimPanel.height);
/* 1060 */     this.labelX.setBounds(nWidth, 0, dimLabelX.width, dimPanel.height);
/* 1061 */     this.textHeight.setBounds(nWidth + dimLabelX.width, 0, nWidth, dimPanel.height);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void itemStateChanged(ItemEvent event) {
/* 1068 */     Object objectSource = event.getSource();
/* 1069 */     if (objectSource != this.comboSize)
/*      */       return; 
/* 1071 */     updateFields();
/* 1072 */     if (this.listener != null) {
/* 1073 */       ActionEvent eventAction = new ActionEvent(this, 1001, "Size Changed");
/* 1074 */       this.listener.actionPerformed(eventAction);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void componentResized(ComponentEvent event) {
/* 1079 */     resizeCustomFields();
/*      */   }
/*      */   
/*      */   public void componentMoved(ComponentEvent event) {}
/*      */   
/*      */   public void componentShown(ComponentEvent event) {}
/*      */   
/*      */   public void componentHidden(ComponentEvent event) {}
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\ui\VideoSizeControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */