/*    */ package com.sun.media.ui;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Label;
/*    */ import java.awt.TextField;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SliderComp
/*    */   extends BasicComp
/*    */   implements ActionListener
/*    */ {
/*    */   float value;
/*    */   float minValue;
/*    */   float maxValue;
/*    */   float initialValue;
/*    */   Scroll scroll;
/*    */   TextField tfIndicator;
/*    */   private static final int MIN = 0;
/*    */   private static final int MAX = 1000;
/*    */   private static final int PAGESIZE = 100;
/*    */   
/*    */   public SliderComp(String label, float min, float max, float initial) {
/* 27 */     super(label);
/* 28 */     this.minValue = min;
/* 29 */     this.maxValue = max;
/* 30 */     this.initialValue = initial;
/* 31 */     this.value = initial;
/*    */     
/* 33 */     setLayout(new BorderLayout());
/* 34 */     Label lab = new Label(label, 0);
/* 35 */     add("West", lab);
/*    */     
/* 37 */     this.scroll = new Scroll();
/*    */     
/* 39 */     add("Center", this.scroll);
/* 40 */     this.scroll.setActionListener(this);
/* 41 */     this.scroll.setValue(toRatio(this.value));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setValue(int value) {
/* 49 */     this.value = value;
/* 50 */     this.scroll.setValue(toRatio(value));
/*    */   }
/*    */   
/*    */   public void setValue(float value) {
/* 54 */     this.value = value;
/* 55 */     this.scroll.setValue(toRatio(value));
/*    */   }
/*    */   
/*    */   public int getIntValue() {
/* 59 */     return (int)this.value;
/*    */   }
/*    */   
/*    */   public float getFloatValue() {
/* 63 */     return this.value;
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent ae) {
/* 67 */     float scrollValue = this.scroll.getValue();
/* 68 */     this.value = fromRatio(scrollValue);
/*    */     
/* 70 */     informListener();
/*    */   }
/*    */   
/*    */   private float toRatio(float value) {
/* 74 */     float diff = this.maxValue - this.minValue;
/* 75 */     return (value - this.minValue) / diff;
/*    */   }
/*    */   
/*    */   private float fromRatio(float value) {
/* 79 */     return value * (this.maxValue - this.minValue) + this.minValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\ui\SliderComp.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */