package com.sun.media.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.List;
import java.awt.Panel;
import java.awt.Point;
import java.awt.TextField;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class ComboBox extends Panel implements ItemListener {
  TextField edit;
  
  Button bPullDown;
  
  PullDownList listWindow = null;
  
  List list = null;
  
  boolean mouseIn = false;
  
  public ComboBox() {
    this(3);
  }
  
  public ComboBox(int cols) {
    setLayout(new BorderLayout());
    this.edit = new TextField(cols);
    this.bPullDown = new Button("...");
    add("Center", this.edit);
    add("East", this.bPullDown);
    this.list = new List(6);
    this.list.setBackground(Color.white);
    this.list.addItemListener(this);
    this.bPullDown.addActionListener(new ActionListener(this) {
          private final ComboBox this$0;
          
          public void actionPerformed(ActionEvent ae) {
            this.this$0.pullDown();
          }
        });
    this.bPullDown.addMouseListener(new MouseAdapter(this) {
          private final ComboBox this$0;
          
          public void mouseEntered(MouseEvent me) {
            if (this.this$0.listWindow == null)
              this.this$0.firstTime(); 
            this.this$0.mouseIn = true;
          }
          
          public void mouseExited(MouseEvent me) {
            this.this$0.mouseIn = false;
          }
        });
  }
  
  public void firstTime() {
    Component frame = this;
    while (!(frame instanceof Frame) && frame != null)
      frame = frame.getParent(); 
    if (frame == null) {
      System.out.println("No frame found in hierarchy");
      System.exit(0);
    } 
    this.listWindow = new PullDownList(this, (Frame)frame, this.list);
    this.listWindow.validate();
  }
  
  public void itemStateChanged(ItemEvent ie) {
    if (ie.getStateChange() == 1) {
      String s = this.list.getSelectedItem();
      this.edit.setText(s);
      this.edit.selectAll();
      pullDown();
    } 
  }
  
  public void pullDown() {
    if (!this.listWindow.isVisible()) {
      this.listWindow.show(this);
    } else {
      this.listWindow.setVisible(false);
    } 
  }
  
  public void addActionListener(ActionListener al) {
    this.edit.addActionListener(al);
  }
  
  public void removeActionListener(ActionListener al) {
    this.edit.removeActionListener(al);
  }
  
  public void addItemListener(ItemListener il) {
    this.list.addItemListener(il);
  }
  
  public void removeItemListener(ItemListener il) {
    this.list.removeItemListener(il);
  }
  
  public String getText() {
    return this.edit.getText();
  }
  
  public void setEditable(boolean f) {
    this.edit.setEditable(f);
  }
  
  public void add(String item) {
    this.list.add(item);
  }
  
  public void add(String item, int index) {
    this.list.add(item, index);
  }
  
  public void addItem(String item) {
    this.list.addItem(item);
  }
  
  public void addItem(String item, int index) {
    this.list.addItem(item, index);
  }
  
  public void delItem(int index) {
    this.list.delItem(index);
  }
  
  public String getSelectedItem() {
    return this.list.getSelectedItem();
  }
  
  public int getSelectedIndex() {
    return this.list.getSelectedIndex();
  }
  
  public void select(int index) {
    this.list.select(index);
    String s = this.list.getSelectedItem();
    this.edit.setText(s);
    this.edit.selectAll();
  }
  
  class PullDownList extends Window {
    List list;
    
    int height;
    
    int HEIGHT;
    
    private final ComboBox this$0;
    
    public PullDownList(ComboBox this$0, Frame f, List list) {
      super(f);
      this.this$0 = this$0;
      this.height = 100;
      this.HEIGHT = 100;
      setLayout(null);
      setBackground(Color.black);
      this.list = list;
      add(list);
      list.addMouseListener((MouseListener)new Object(this));
    }
    
    public void show(Component parent) {
      Point p = parent.getLocationOnScreen();
      Dimension psize = parent.getSize();
      this.height = (this.list.getPreferredSize()).height;
      if (this.height == 0)
        this.height = this.HEIGHT; 
      this.list.setBounds(1, 1, psize.width - 2, this.HEIGHT);
      setBounds(p.x, p.y + psize.height, psize.width, this.HEIGHT + 2);
      validate();
      setVisible(true);
    }
    
    public List getList() {
      return this.list;
    }
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\ComboBox.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */