package com.sun.media.ui;

import java.util.Vector;

class RowData {
  private Vector vectorValues = new Vector();
  
  public RowData(Object[] arrValues) {
    if (arrValues != null) {
      int nCount = arrValues.length;
      for (int i = 0; i < nCount; i++)
        this.vectorValues.addElement(arrValues[i]); 
    } 
  }
  
  void setValue(Object value, int nColumn) {
    this.vectorValues.setElementAt(value, nColumn);
  }
  
  Object getValue(int nColumn) {
    Object value = this.vectorValues.elementAt(nColumn);
    return value;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\RowData.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */