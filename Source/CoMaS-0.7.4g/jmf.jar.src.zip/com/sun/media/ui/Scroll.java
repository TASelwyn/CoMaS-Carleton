/*     */ package com.sun.media.ui;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ 
/*     */ public class Scroll
/*     */   extends Component implements MouseListener, MouseMotionListener {
/*     */   Image imageGrabber;
/*     */   Image imageGrabberX;
/*     */   Image imageGrabberDown;
/*  20 */   Graphics paintG = null;
/*     */   
/*     */   boolean grabbed;
/*     */   boolean entered;
/*     */   int grabberPosition;
/*  25 */   int leftBorder = 8; int sliderWidth; int width; int height;
/*  26 */   int rightBorder = 8;
/*     */   
/*     */   int displayPercent;
/*     */   
/*     */   float[] detents;
/*     */   Dimension dimension;
/*  32 */   float lower = 0.0F; float upper = 1.0F; float range = 1.0F; float value = 0.5F;
/*     */   boolean dragging = false;
/*     */   boolean grabberVisible = true;
/*  35 */   ActionListener actionListener = null;
/*     */   
/*     */   public Scroll() {
/*  38 */     this(null, null);
/*     */   }
/*     */   
/*     */   public Scroll(float[] detents) {
/*  42 */     this(detents, null);
/*     */   }
/*     */   
/*     */   public Scroll(float[] detents, Color background) {
/*  46 */     this.imageGrabber = BasicComp.fetchImage("grabber.gif");
/*  47 */     this.imageGrabberDown = BasicComp.fetchImage("grabber-pressed.gif");
/*  48 */     this.imageGrabberX = BasicComp.fetchImage("grabber-disabled.gif");
/*     */     
/*  50 */     this.detents = detents;
/*  51 */     if (background != null) {
/*  52 */       setBackground(background);
/*     */     }
/*  54 */     this.width = 115;
/*  55 */     this.height = 18;
/*  56 */     this.displayPercent = 100;
/*  57 */     this.dimension = new Dimension(this.width, this.height);
/*  58 */     this.sliderWidth = this.width - this.leftBorder - this.rightBorder;
/*  59 */     setSize(this.width, this.height);
/*  60 */     setVisible(true);
/*  61 */     this.grabbed = false;
/*  62 */     this.entered = false;
/*  63 */     addMouseListener(this);
/*  64 */     addMouseMotionListener(this);
/*     */   }
/*     */   
/*     */   public void setActionListener(ActionListener al) {
/*  68 */     this.actionListener = al;
/*     */   }
/*     */   
/*     */   public void setValue(float value) {
/*  72 */     this.lower = 0.0F;
/*  73 */     this.upper = 1.0F;
/*  74 */     this.range = this.upper - this.lower;
/*  75 */     setSliderPosition(value - this.lower, this.range);
/*  76 */     repaint();
/*     */   }
/*     */   
/*     */   public float getValue() {
/*  80 */     return this.value;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean state) {
/*  84 */     super.setEnabled(state);
/*  85 */     repaint();
/*     */   }
/*     */   
/*     */   public Point getPosition() {
/*  89 */     return new Point(this.grabberPosition + this.leftBorder, 10);
/*     */   }
/*     */   
/*     */   public void setDisplayPercent(int percent) {
/*  93 */     if (percent != this.displayPercent) {
/*  94 */       this.displayPercent = percent;
/*  95 */       if (this.displayPercent > 100) {
/*  96 */         this.displayPercent = 100;
/*  97 */       } else if (this.displayPercent < 0) {
/*  98 */         this.displayPercent = 0;
/*     */       } 
/* 100 */       repaint();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paint(Graphics g) {
/* 105 */     Dimension size = getSize();
/*     */     
/* 107 */     int y = size.height / 2 - 2;
/*     */     
/* 109 */     this.paintG = g;
/*     */     
/* 111 */     int grabberX = this.grabberPosition + this.leftBorder - 5;
/*     */ 
/*     */     
/* 114 */     g.setColor(getBackground());
/* 115 */     y = (getSize()).height / 2 - 2;
/* 116 */     g.draw3DRect(2, y, size.width - 4, 3, false);
/*     */ 
/*     */     
/* 119 */     if (this.displayPercent < 100) {
/* 120 */       g.setColor(Color.green);
/* 121 */       int x = this.sliderWidth * this.displayPercent / 100 + 3;
/* 122 */       y += 2;
/* 123 */       g.drawLine(x, y, size.width - 4, y);
/*     */     } 
/*     */ 
/*     */     
/* 127 */     if (this.detents != null && this.detents.length != 0) {
/* 128 */       this.paintG.setColor(Color.black);
/* 129 */       for (int i = 0; i < this.detents.length; i++) {
/* 130 */         int j = this.leftBorder + (int)(this.detents[i] * this.sliderWidth / this.range);
/* 131 */         this.paintG.drawLine(j, 12, j, 15);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 136 */     if (this.grabberVisible) {
/*     */       Image image;
/* 138 */       if (isEnabled())
/* 139 */       { if (this.grabbed || this.entered) {
/* 140 */           image = this.imageGrabberDown;
/*     */         } else {
/* 142 */           image = this.imageGrabber;
/*     */         }  }
/* 144 */       else { image = this.imageGrabberX; }
/*     */       
/* 146 */       this.paintG.drawImage(image, grabberX, 4, this);
/*     */     } 
/*     */   }
/*     */   
/*     */   private int limitGrabber(int mousex) {
/* 151 */     int x = mousex - this.leftBorder;
/* 152 */     if (x < 0) {
/* 153 */       x = 0;
/* 154 */     } else if (x > this.sliderWidth) {
/* 155 */       x = this.sliderWidth;
/* 156 */     }  return x;
/*     */   }
/*     */   
/*     */   private void setSliderPosition(float value, float range) {
/* 160 */     this.grabberPosition = (int)(value / range * this.sliderWidth);
/*     */   }
/*     */   
/*     */   private void seek() {
/* 164 */     this.value = this.grabberPosition / this.sliderWidth;
/* 165 */     if (this.detents != null && this.detents.length > 0 && this.dragging) {
/* 166 */       float tolerance = 0.05F;
/* 167 */       for (int i = 0; i < this.detents.length; i++) {
/* 168 */         if (Math.abs(this.detents[i] - this.value) <= tolerance) {
/* 169 */           this.value = this.detents[i];
/*     */         }
/*     */       } 
/*     */     } 
/* 173 */     repaint();
/* 174 */     if (this.actionListener != null) {
/* 175 */       this.actionListener.actionPerformed(new ActionEvent(this, 1001, "scroll"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mousePressed(MouseEvent me) {
/* 186 */     int modifier = me.getModifiers();
/* 187 */     if ((modifier & 0x8) == 0 && (modifier & 0x4) == 0)
/*     */     {
/* 189 */       if (isEnabled()) {
/* 190 */         this.dragging = false;
/* 191 */         this.grabbed = true;
/* 192 */         this.grabberPosition = limitGrabber(me.getX());
/* 193 */         seek();
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void mouseReleased(MouseEvent me) {
/* 199 */     int modifier = me.getModifiers();
/* 200 */     if ((modifier & 0x8) == 0 && (modifier & 0x4) == 0)
/*     */     {
/* 202 */       if (isEnabled()) {
/* 203 */         this.dragging = false;
/* 204 */         this.grabbed = false;
/* 205 */         repaint();
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void mouseDragged(MouseEvent me) {
/* 211 */     int modifier = me.getModifiers();
/* 212 */     if ((modifier & 0x8) == 0 && (modifier & 0x4) == 0)
/*     */     {
/* 214 */       if (isEnabled()) {
/* 215 */         this.dragging = true;
/* 216 */         this.grabberPosition = limitGrabber(me.getX());
/* 217 */         seek();
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void mouseEntered(MouseEvent me) {
/* 223 */     this.entered = true;
/* 224 */     repaint();
/*     */   }
/*     */   
/*     */   public void mouseExited(MouseEvent me) {
/* 228 */     this.entered = false;
/* 229 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseClicked(MouseEvent me) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseMoved(MouseEvent me) {}
/*     */ 
/*     */   
/*     */   public void setSize(int width, int height) {
/* 242 */     super.setSize(width, height);
/* 243 */     this.paintG = null;
/* 244 */     repaint();
/*     */   }
/*     */   
/*     */   public Dimension getPreferredSize() {
/* 248 */     return this.dimension;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\ui\Scroll.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */