package com.sun.media.ui;

import java.awt.Component;
import javax.media.CachingControl;

class ProgressBarThread extends Thread {
  private Component progressBar;
  
  private CachingControl cachingControl;
  
  private long lengthContent;
  
  public ProgressBarThread(Component progressBar, CachingControl cachingControl) {
    this.progressBar = progressBar;
    this.cachingControl = cachingControl;
    this.lengthContent = cachingControl.getContentLength();
  }
  
  public void run() {
    long lengthProgress = 0L;
    while (lengthProgress < this.lengthContent) {
      try {
        Thread.sleep(300L);
      } catch (Exception exception) {}
      lengthProgress = this.cachingControl.getContentProgress();
      this.progressBar.repaint();
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\ProgressBarThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */