/*    */ package com.sun.media.ui;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import javax.media.CachingControl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ProgressBarThread
/*    */   extends Thread
/*    */ {
/*    */   private Component progressBar;
/*    */   private CachingControl cachingControl;
/*    */   private long lengthContent;
/*    */   
/*    */   public ProgressBarThread(Component progressBar, CachingControl cachingControl) {
/* 60 */     this.progressBar = progressBar;
/* 61 */     this.cachingControl = cachingControl;
/*    */     
/* 63 */     this.lengthContent = cachingControl.getContentLength();
/*    */   }
/*    */   
/*    */   public void run() {
/* 67 */     long lengthProgress = 0L;
/*    */     
/* 69 */     while (lengthProgress < this.lengthContent) {
/*    */       try {
/* 71 */         Thread.sleep(300L);
/*    */       }
/* 73 */       catch (Exception exception) {}
/*    */ 
/*    */       
/* 76 */       lengthProgress = this.cachingControl.getContentProgress();
/* 77 */       this.progressBar.repaint();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\ui\ProgressBarThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */