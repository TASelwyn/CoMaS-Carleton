package com.sun.media.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MessageBox extends Frame {
  public MessageBox(String title, String message) {
    super(title);
    setLayout(new BorderLayout());
    Panel bottom = new Panel();
    bottom.setLayout(new FlowLayout());
    Button ok = new Button("Grrr!!!");
    ok.addActionListener(new ActionListener(this) {
          private final MessageBox this$0;
          
          public void actionPerformed(ActionEvent ae) {
            this.this$0.dispose();
          }
        });
    bottom.add(ok);
    add("Center", new Label(message, 1));
    add("South", bottom);
    setVisible(true);
  }
  
  public void addNotify() {
    super.addNotify();
    pack();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\MessageBox.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */