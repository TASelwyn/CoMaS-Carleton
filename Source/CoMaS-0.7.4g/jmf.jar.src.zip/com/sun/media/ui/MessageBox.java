/*    */ package com.sun.media.ui;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Button;
/*    */ import java.awt.FlowLayout;
/*    */ import java.awt.Frame;
/*    */ import java.awt.Label;
/*    */ import java.awt.Panel;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageBox
/*    */   extends Frame
/*    */ {
/*    */   public MessageBox(String title, String message) {
/* 19 */     super(title);
/* 20 */     setLayout(new BorderLayout());
/*    */ 
/*    */     
/* 23 */     Panel bottom = new Panel();
/* 24 */     bottom.setLayout(new FlowLayout());
/* 25 */     Button ok = new Button("Grrr!!!");
/* 26 */     ok.addActionListener(new ActionListener(this) {
/*    */           public void actionPerformed(ActionEvent ae) {
/* 28 */             this.this$0.dispose();
/*    */           } private final MessageBox this$0;
/*    */         });
/* 31 */     bottom.add(ok);
/*    */ 
/*    */     
/* 34 */     add("Center", new Label(message, 1));
/*    */     
/* 36 */     add("South", bottom);
/*    */     
/* 38 */     setVisible(true);
/*    */   }
/*    */   
/*    */   public void addNotify() {
/* 42 */     super.addNotify();
/* 43 */     pack();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\ui\MessageBox.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */