package com.sun.media.ui;

import java.awt.Rectangle;
import java.io.Serializable;
import java.util.Enumeration;
import java.util.Vector;

class Region implements Cloneable, Serializable {
  protected Vector rects;
  
  public Region() {
    this.rects = new Vector();
  }
  
  public Region(Rectangle r) {
    this.rects = new Vector();
    addRectangle(r);
  }
  
  public Region(Rectangle r1, Rectangle r2) {
    this.rects = new Vector();
    addRectangle(r1);
    addRectangle(r2);
  }
  
  public boolean isEmpty() {
    return this.rects.isEmpty();
  }
  
  public int getNumRectangles() {
    return this.rects.size();
  }
  
  public Enumeration rectangles() {
    return this.rects.elements();
  }
  
  public Object clone() {
    Region r = new Region();
    r.rects = (Vector)this.rects.clone();
    return r;
  }
  
  public Rectangle getBounds() {
    Rectangle r = new Rectangle();
    for (int i = 0; i < this.rects.size(); i++)
      r = r.union(this.rects.elementAt(i)); 
    return r;
  }
  
  public void addRectangle(Rectangle r) {
    int position = 0;
    while (position < this.rects.size()) {
      Rectangle current = this.rects.elementAt(position);
      if (r.x > current.x && r.y > current.y && right(r) <= right(current) && bottom(r) <= bottom(current))
        return; 
      if (r.intersects(current)) {
        r = r.union(current);
        this.rects.removeElementAt(position);
        continue;
      } 
      position++;
    } 
    this.rects.addElement(r);
  }
  
  public boolean intersects(Rectangle r) {
    int position = 0;
    while (position < this.rects.size()) {
      Rectangle rect = this.rects.elementAt(position);
      if (rect.intersects(r))
        return true; 
      position++;
    } 
    return false;
  }
  
  public void intersect(Rectangle r) {
    int position = 0;
    while (position < this.rects.size()) {
      Rectangle rect = this.rects.elementAt(position);
      rect = rect.intersection(r);
      if (rect.isEmpty()) {
        this.rects.removeElementAt(position);
        continue;
      } 
      this.rects.setElementAt(rect, position);
      position++;
    } 
  }
  
  public void addRegion(Region r) {
    for (Enumeration e = r.rectangles(); e.hasMoreElements();)
      addRectangle(e.nextElement()); 
  }
  
  public void translate(int dx, int dy) {
    for (int p = 0; p < this.rects.size(); p++) {
      Rectangle r = this.rects.elementAt(p);
      r.translate(dx, dy);
    } 
  }
  
  public String toString() {
    String s = getClass().getName() + " = [\n";
    for (Enumeration e = rectangles(); e.hasMoreElements();)
      s = s + "(" + (Rectangle)e.nextElement() + ")\n"; 
    return s + "]";
  }
  
  public static int right(Rectangle r) {
    return r.x + r.width - 1;
  }
  
  public static int bottom(Rectangle r) {
    return r.y + r.height - 1;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\Region.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */