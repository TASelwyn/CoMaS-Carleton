package com.sun.media.ui;

import java.awt.Dimension;

class VideoSize extends Dimension {
  public VideoSize() {}
  
  public VideoSize(int nWidth, int nHeight) {
    super(nWidth, nHeight);
  }
  
  public VideoSize(Dimension dim) {
    super(dim);
  }
  
  public boolean equals(Dimension dim) {
    boolean boolResult = true;
    if (dim == null)
      boolResult = false; 
    if (boolResult == true)
      boolResult = (this.width == dim.width); 
    if (boolResult == true)
      boolResult = (this.height == dim.height); 
    return boolResult;
  }
  
  public String toString() {
    return "" + this.width + " x " + this.height;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\VideoSize.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */