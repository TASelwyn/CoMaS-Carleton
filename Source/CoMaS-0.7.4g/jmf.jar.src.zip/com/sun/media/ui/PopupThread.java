package com.sun.media.ui;

import java.awt.Window;

class PopupThread extends Thread {
  private Window window;
  
  private int nTimeCounter = 3;
  
  private boolean boolRun = true;
  
  public PopupThread(Window window) {
    this.window = window;
  }
  
  public void resetCounter(int nTimeCounter) {
    this.nTimeCounter = nTimeCounter;
  }
  
  public void stopNormaly() {
    this.boolRun = false;
  }
  
  public void run() {
    while (this.boolRun) {
      if (this.nTimeCounter < 1)
        this.window.setVisible(false); 
      try {
        Thread.sleep(1000L);
      } catch (Exception exception) {}
      this.nTimeCounter--;
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\PopupThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */