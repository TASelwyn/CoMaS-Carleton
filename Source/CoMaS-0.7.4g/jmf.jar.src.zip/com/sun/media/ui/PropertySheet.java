package com.sun.media.ui;

import com.sun.media.BasicPlayer;
import com.sun.media.util.JMFI18N;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.Vector;
import javax.media.Control;
import javax.media.Duration;
import javax.media.Format;
import javax.media.MediaLocator;
import javax.media.Owned;
import javax.media.Player;
import javax.media.Time;
import javax.media.control.BitRateControl;
import javax.media.control.FormatControl;
import javax.media.control.FrameRateControl;
import javax.media.format.AudioFormat;
import javax.media.format.VideoFormat;
import javax.media.protocol.ContentDescriptor;

public class PropertySheet extends Dialog implements WindowListener, ActionListener {
  private Player player;
  
  private Vector vectorControlBitRate = new Vector(1);
  
  private Vector vectorLabelBitRate = new Vector(1);
  
  private FrameRateControl controlFrameRate = null;
  
  private Vector vectorTrackFormats = new Vector();
  
  private int nAudioTrackCount = 0;
  
  private int nVideoTrackCount = 0;
  
  private Vector vectorMiscControls = new Vector();
  
  private Button buttonClose;
  
  private Label labelDuration = null;
  
  private Label labelPosition = null;
  
  private Label labelBitRate = null;
  
  private Label labelFrameRate = null;
  
  private ColumnList columnListAudio;
  
  private ColumnList columnListVideo;
  
  private static final String STR_UNKNOWN = JMFI18N.getResource("propertysheet.unknown");
  
  private static final String STR_UNBOUNDED = JMFI18N.getResource("propertysheet.unbounded");
  
  public PropertySheet(Frame parent, Player player) {
    super(parent, JMFI18N.getResource("propertysheet.title"), false);
    this.player = player;
    try {
      init();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  private void init() throws Exception {
    setLayout(new BorderLayout(5, 5));
    setBackground(Color.lightGray);
    Panel panel = createPanelButtons();
    add(panel, "South");
    panel = createPanelProperties();
    add(panel, "Center");
    Canvas canvas = new Canvas();
    add(canvas, "North");
    canvas = new Canvas();
    add(canvas, "East");
    canvas = new Canvas();
    add(canvas, "West");
    pack();
    addWindowListener(this);
    setResizable(false);
    Dimension dim = getPreferredSize();
    if (dim.width > 480)
      dim.width = 480; 
    setBounds(100, 100, dim.width, dim.height);
    repaint();
  }
  
  private Panel createPanelProperties() throws Exception {
    TabControl tabControl = new TabControl(0);
    Panel panel = createPanelGeneral();
    tabControl.addPage(panel, JMFI18N.getResource("propertysheet.tab.general"));
    if (this.nVideoTrackCount > 0) {
      panel = createPanelVideo(this.vectorTrackFormats);
      tabControl.addPage(panel, JMFI18N.getResource("propertysheet.tab.video"));
    } 
    if (this.nAudioTrackCount > 0) {
      panel = createPanelAudio(this.vectorTrackFormats);
      tabControl.addPage(panel, JMFI18N.getResource("propertysheet.tab.audio"));
    } 
    if (!this.vectorMiscControls.isEmpty()) {
      panel = createPanelMisc();
      tabControl.addPage(panel, JMFI18N.getResource("propertysheet.tab.misc"));
    } 
    update();
    return tabControl;
  }
  
  private Panel createPanelGeneral() throws Exception {
    String strValue = null;
    Panel panelGeneral = new Panel(new BorderLayout());
    Panel panel = new Panel(new BorderLayout(8, 4));
    panelGeneral.add(panel, "North");
    Panel panelLabels = new Panel(new GridLayout(0, 1, 4, 4));
    panel.add(panelLabels, "West");
    Panel panelData = new Panel(new GridLayout(0, 1, 4, 4));
    panel.add(panelData, "Center");
    if (this.player instanceof BasicPlayer) {
      BasicPlayer playerBasic = (BasicPlayer)this.player;
      MediaLocator mediaLocator = playerBasic.getMediaLocator();
      if (mediaLocator != null)
        strValue = mediaLocator.toString(); 
      if (strValue != null) {
        Label label1 = new Label(JMFI18N.getResource("propertysheet.general.medialocation"), 2);
        panelLabels.add(label1);
        UrlLabel labelUrl = new UrlLabel(strValue);
        panelData.add(labelUrl);
      } 
      strValue = playerBasic.getContentType();
      if (strValue != null) {
        strValue = (new ContentDescriptor(strValue)).toString();
        Label label1 = new Label(JMFI18N.getResource("propertysheet.general.contenttype"), 2);
        panelLabels.add(label1);
        label1 = new Label(strValue);
        panelData.add(label1);
      } 
    } 
    Label label = new Label(JMFI18N.getResource("propertysheet.general.duration"), 2);
    panelLabels.add(label);
    this.labelDuration = new Label();
    panelData.add(this.labelDuration);
    label = new Label(JMFI18N.getResource("propertysheet.general.position"), 2);
    panelLabels.add(label);
    this.labelPosition = new Label();
    panelData.add(this.labelPosition);
    this.nAudioTrackCount = 0;
    this.nVideoTrackCount = 0;
    Control[] arrControls = this.player.getControls();
    for (int i = 0; i < arrControls.length; i++) {
      if (arrControls[i] != null) {
        if (arrControls[i] instanceof FormatControl && (
          !(arrControls[i] instanceof Owned) || (!(((Owned)arrControls[i]).getOwner() instanceof javax.media.protocol.SourceStream) && !(((Owned)arrControls[i]).getOwner() instanceof javax.media.protocol.DataSource)))) {
          Format format = ((FormatControl)arrControls[i]).getFormat();
          this.vectorTrackFormats.addElement(format);
          if (format instanceof AudioFormat) {
            this.nAudioTrackCount++;
          } else if (format instanceof VideoFormat) {
            this.nVideoTrackCount++;
          } 
        } 
        if (!(arrControls[i] instanceof javax.media.control.TrackControl))
          if (arrControls[i] instanceof BitRateControl) {
            BitRateControl controlBitRateTemp = (BitRateControl)arrControls[i];
            if (controlBitRateTemp instanceof Owned && ((Owned)controlBitRateTemp).getOwner() instanceof javax.media.Controller) {
              this.vectorControlBitRate.addElement(controlBitRateTemp);
              label = new Label(JMFI18N.getResource("propertysheet.general.bitrate"), 2);
              panelLabels.add(label);
              this.labelBitRate = new Label();
              this.vectorLabelBitRate.addElement(this.labelBitRate);
              panelData.add(this.labelBitRate);
            } else {
              this.vectorMiscControls.addElement(arrControls[i]);
            } 
          } else if (arrControls[i] instanceof FrameRateControl) {
            FrameRateControl controlFrameRateTemp = (FrameRateControl)arrControls[i];
            if (controlFrameRateTemp instanceof Owned && ((Owned)controlFrameRateTemp).getOwner() instanceof javax.media.Controller) {
              this.controlFrameRate = controlFrameRateTemp;
              label = new Label(JMFI18N.getResource("propertysheet.general.framerate"), 2);
              panelLabels.add(label);
              this.labelFrameRate = new Label();
              panelData.add(this.labelFrameRate);
            } else {
              this.vectorMiscControls.addElement(arrControls[i]);
            } 
          } else if (!(arrControls[i] instanceof javax.media.GainControl)) {
            if (!(arrControls[i] instanceof javax.media.control.MonitorControl))
              if (!(arrControls[i] instanceof Owned) || (!(((Owned)arrControls[i]).getOwner() instanceof javax.media.protocol.CaptureDevice) && !(((Owned)arrControls[i]).getOwner() instanceof javax.media.protocol.SourceStream) && !(((Owned)arrControls[i]).getOwner() instanceof javax.media.protocol.DataSource)))
                if (!(arrControls[i] instanceof javax.media.CachingControl))
                  this.vectorMiscControls.addElement(arrControls[i]);   
          }  
      } 
    } 
    return panelGeneral;
  }
  
  private Panel createPanelVideo(Vector vectorFormats) throws Exception {
    String[] arrColumnNames = { JMFI18N.getResource("propertysheet.video.track"), JMFI18N.getResource("propertysheet.video.encoding"), JMFI18N.getResource("propertysheet.video.size"), JMFI18N.getResource("propertysheet.video.framerate") };
    Panel panelVideo = new Panel(new BorderLayout());
    this.columnListVideo = new ColumnList(arrColumnNames);
    String[] arrValues = new String[arrColumnNames.length];
    int nCount = vectorFormats.size();
    int nTrackIndex = 0;
    for (int i = 0; i < nCount; i++) {
      Object objectFormat = vectorFormats.elementAt(i);
      if (objectFormat instanceof VideoFormat) {
        VideoFormat formatVideo = (VideoFormat)objectFormat;
        nTrackIndex++;
        arrValues[0] = new String("" + nTrackIndex);
        arrValues[1] = formatVideo.getEncoding();
        Dimension dimSize = formatVideo.getSize();
        if (dimSize == null) {
          arrValues[2] = new String(STR_UNKNOWN);
        } else {
          arrValues[2] = new String("" + dimSize.width + " x " + dimSize.height);
        } 
        float fValue = formatVideo.getFrameRate();
        if (fValue == -1.0F) {
          arrValues[3] = STR_UNKNOWN;
        } else {
          arrValues[3] = "" + fValue;
        } 
        this.columnListVideo.addRow((Object[])arrValues);
      } 
    } 
    this.columnListVideo.setColumnWidthAsPreferred();
    panelVideo.add(this.columnListVideo, "Center");
    return panelVideo;
  }
  
  private Panel createPanelAudio(Vector vectorFormats) throws Exception {
    String[] arrColumnNames = { JMFI18N.getResource("propertysheet.audio.track"), JMFI18N.getResource("propertysheet.audio.encoding"), JMFI18N.getResource("propertysheet.audio.samplerate"), JMFI18N.getResource("propertysheet.audio.bitspersample"), JMFI18N.getResource("propertysheet.audio.channels") };
    Panel panelAudio = new Panel(new BorderLayout());
    this.columnListAudio = new ColumnList(arrColumnNames);
    String[] arrValues = new String[arrColumnNames.length];
    int nCount = vectorFormats.size();
    int nTrackIndex = 0;
    for (int i = 0; i < nCount; i++) {
      Object objectFormat = vectorFormats.elementAt(i);
      if (objectFormat instanceof AudioFormat) {
        AudioFormat formatAudio = (AudioFormat)objectFormat;
        nTrackIndex++;
        arrValues[0] = new String("" + nTrackIndex);
        arrValues[1] = formatAudio.getEncoding();
        double dValue = formatAudio.getSampleRate();
        if (dValue == -1.0D) {
          arrValues[2] = STR_UNKNOWN;
        } else {
          arrValues[2] = "" + dValue;
        } 
        int nValue = formatAudio.getSampleSizeInBits();
        if (nValue == -1) {
          arrValues[3] = STR_UNKNOWN;
        } else {
          arrValues[3] = "" + nValue;
        } 
        nValue = formatAudio.getChannels();
        if (nValue == -1) {
          arrValues[4] = STR_UNKNOWN;
        } else if (nValue == 1) {
          arrValues[4] = "" + nValue + " (" + JMFI18N.getResource("propertysheet.audio.channels.mono") + ")";
        } else if (nValue == 2) {
          arrValues[4] = "" + nValue + " (" + JMFI18N.getResource("propertysheet.audio.channels.stereo") + ")";
        } else {
          arrValues[4] = "" + nValue;
        } 
        this.columnListAudio.addRow((Object[])arrValues);
      } 
    } 
    this.columnListAudio.setColumnWidthAsPreferred();
    panelAudio.add(this.columnListAudio, "Center");
    return panelAudio;
  }
  
  private Panel createPanelMisc() throws Exception {
    Panel panelMisc = new Panel(new BorderLayout(6, 6));
    Panel panel = panelMisc;
    int nSize = this.vectorMiscControls.size();
    for (int i = 0; i < nSize; i++) {
      Control control = this.vectorMiscControls.elementAt(i);
      Component comp = control.getControlComponent();
      if (comp != null && comp.getParent() == null) {
        Panel panelControl = new Panel(new BorderLayout(6, 6));
        panelControl.add(comp, "West");
        Panel panelNext = new Panel(new BorderLayout(6, 6));
        panelNext.add(panelControl, "North");
        panel.add(panelNext, "Center");
        panel = panelNext;
      } 
    } 
    return panelMisc;
  }
  
  private Panel createPanelButtons() throws Exception {
    Panel panelButtons = new Panel(new FlowLayout(2));
    Panel panel = new Panel(new GridLayout(1, 0, 6, 6));
    panelButtons.add(panel);
    this.buttonClose = new Button(JMFI18N.getResource("propertysheet.close"));
    this.buttonClose.addActionListener(this);
    panel.add(this.buttonClose);
    return panelButtons;
  }
  
  public void actionPerformed(ActionEvent e) {
    String strCmd = e.getActionCommand();
    if (strCmd.equals(this.buttonClose.getLabel()))
      setVisible(false); 
  }
  
  public void windowOpened(WindowEvent e) {}
  
  public void windowClosing(WindowEvent e) {
    setVisible(false);
  }
  
  public void windowClosed(WindowEvent e) {}
  
  public void windowIconified(WindowEvent e) {}
  
  public void windowDeiconified(WindowEvent e) {}
  
  public void windowActivated(WindowEvent e) {}
  
  public void windowDeactivated(WindowEvent e) {}
  
  void update() {
    updateBitRate();
    updateFrameRate();
    updateMediaTime();
    updateDuration();
  }
  
  void updateDuration() {
    if (this.labelDuration != null) {
      Time timeDuration = this.player.getDuration();
      this.labelDuration.setText(formatTime(timeDuration));
    } 
  }
  
  void updateBitRate() {
    if (this.vectorLabelBitRate.size() > 0)
      for (int i = 0; i < this.vectorLabelBitRate.size(); i++) {
        Label labelBitRate = this.vectorLabelBitRate.elementAt(i);
        BitRateControl controlBitRate = this.vectorControlBitRate.elementAt(i);
        int bitRate = controlBitRate.getBitRate();
        labelBitRate.setText(Float.toString(bitRate / 1000.0F) + " " + JMFI18N.getResource("propertysheet.kbps"));
      }  
  }
  
  void updateFrameRate() {
    if (this.labelFrameRate != null && this.controlFrameRate != null) {
      float frameRate = this.controlFrameRate.getFrameRate();
      this.labelFrameRate.setText(Float.toString(frameRate) + " " + JMFI18N.getResource("propertysheet.fps"));
    } 
  }
  
  void clearBRFR() {
    if (this.labelFrameRate != null)
      this.labelFrameRate.setText("0.0 " + JMFI18N.getResource("propertysheet.fps")); 
    if (this.labelBitRate != null)
      this.labelBitRate.setText("0.0 " + JMFI18N.getResource("propertysheet.kbps")); 
  }
  
  void updateMediaTime() {
    if (this.labelPosition != null) {
      Time timeMedia = this.player.getMediaTime();
      this.labelPosition.setText(formatTime(timeMedia));
    } 
  }
  
  private String formatTime(Time time) {
    String strTime = new String(STR_UNKNOWN);
    if (time == null || time == Time.TIME_UNKNOWN || time == Duration.DURATION_UNKNOWN)
      return strTime; 
    if (time == Duration.DURATION_UNBOUNDED)
      return STR_UNBOUNDED; 
    long nano = time.getNanoseconds();
    int seconds = (int)(nano / 1000000000L);
    int hours = seconds / 3600;
    int minutes = (seconds - hours * 3600) / 60;
    seconds = seconds - hours * 3600 - minutes * 60;
    nano = nano % 1000000000L / 10000000L;
    int hours10 = hours / 10;
    hours %= 10;
    int minutes10 = minutes / 10;
    minutes %= 10;
    int seconds10 = seconds / 10;
    seconds %= 10;
    long nano10 = nano / 10L;
    nano %= 10L;
    strTime = new String("" + hours10 + hours + ":" + minutes10 + minutes + ":" + seconds10 + seconds + "." + nano10 + nano);
    return strTime;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\PropertySheet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */