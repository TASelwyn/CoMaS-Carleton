package com.sun.media.ui;

import com.sun.media.controls.ProgressControl;
import com.sun.media.controls.SliderRegionControl;
import com.sun.media.util.JMFI18N;
import java.awt.BorderLayout;
import java.awt.CheckboxMenuItem;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.ItemSelectable;
import java.awt.Point;
import java.awt.PopupMenu;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.peer.ComponentPeer;
import java.util.Vector;
import javax.media.Control;
import javax.media.ControllerEvent;
import javax.media.ControllerListener;
import javax.media.Duration;
import javax.media.Format;
import javax.media.GainChangeEvent;
import javax.media.GainChangeListener;
import javax.media.GainControl;
import javax.media.Player;
import javax.media.Time;
import javax.media.control.FramePositioningControl;
import javax.media.control.TrackControl;
import javax.media.format.VideoFormat;

public class DefaultControlPanel extends BufferedPanelLight implements ActionListener, ItemListener, ControllerListener, GainChangeListener, ComponentListener {
  static final Color colorBackground = new Color(192, 192, 192);
  
  private static final String MENU_PROPERTIES = JMFI18N.getResource("mediaplayer.properties");
  
  private static final String MENU_RATE_1_4 = JMFI18N.getResource("mediaplayer.rate.1:4");
  
  private static final String MENU_RATE_1_2 = JMFI18N.getResource("mediaplayer.rate.1:2");
  
  private static final String MENU_RATE_1_1 = JMFI18N.getResource("mediaplayer.rate.1:1");
  
  private static final String MENU_RATE_2_1 = JMFI18N.getResource("mediaplayer.rate.2:1");
  
  private static final String MENU_RATE_4_1 = JMFI18N.getResource("mediaplayer.rate.4:1");
  
  private static final String MENU_RATE_8_1 = JMFI18N.getResource("mediaplayer.rate.8:1");
  
  private static final String MENU_MEDIA = JMFI18N.getResource("mediaplayer.menu.media");
  
  private static final String MENU_AUDIO = JMFI18N.getResource("mediaplayer.menu.audio");
  
  private static final String MENU_VIDEO = JMFI18N.getResource("mediaplayer.menu.video");
  
  Player player;
  
  Frame parentFrame = null;
  
  Container container = null;
  
  TransparentPanel panelLeft;
  
  TransparentPanel panelRight;
  
  TransparentPanel panelProgress;
  
  boolean boolAdded = false;
  
  ButtonComp buttonPlay = null;
  
  ButtonComp buttonStepBack = null;
  
  ButtonComp buttonStepFwd = null;
  
  AudioButton buttonAudio = null;
  
  ButtonComp buttonMedia = null;
  
  ProgressSlider progressSlider = null;
  
  CheckboxMenuItem menuItemCheck = null;
  
  PopupMenu menuPopup = null;
  
  WindowListener wl = null;
  
  private boolean firstTime = true;
  
  private boolean started = false;
  
  private Integer localLock = new Integer(0);
  
  GainControlComponent audioControls = null;
  
  PropertySheet propsSheet = null;
  
  FramePositioningControl controlFrame = null;
  
  ProgressControl progressControl = null;
  
  GainControl gainControl = null;
  
  SliderRegionControl regionControl = null;
  
  String urlName = null;
  
  long lFrameStep = 0L;
  
  private CheckboxMenuItem menuRate_1_4 = null;
  
  private CheckboxMenuItem menuRate_1_2 = null;
  
  private CheckboxMenuItem menuRate_1_1 = null;
  
  private CheckboxMenuItem menuRate_2_1 = null;
  
  private CheckboxMenuItem menuRate_4_1 = null;
  
  private CheckboxMenuItem menuRate_8_1 = null;
  
  private Vector vectorTracksAudio = new Vector();
  
  private Vector vectorTracksVideo = new Vector();
  
  private int pausecnt = -1;
  
  private boolean resetMediaTimeinPause = false;
  
  public DefaultControlPanel(Player player) {
    this.player = player;
    try {
      init();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public void addNotify() {
    boolean boolLightweight = true;
    if (!this.boolAdded) {
      Container containerParent = getParent();
      while (containerParent != null && boolLightweight == true) {
        ComponentPeer compPeer = containerParent.getPeer();
        containerParent = containerParent.getParent();
        if (containerParent == null)
          break; 
        if (compPeer != null && !(compPeer instanceof java.awt.peer.LightweightPeer))
          boolLightweight = false; 
      } 
      if (this.container != null) {
        this.container.remove(this.panelLeft);
        this.container.remove(this.panelRight);
        this.container.remove(this.panelProgress);
        if (this.container != this)
          remove(this.container); 
      } 
      if (boolLightweight == true) {
        this.container = this;
      } else {
        this.container = new BufferedPanel(new BorderLayout());
        this.container.setBackground(colorBackground);
        ((BufferedPanel)this.container).setBackgroundTile(BasicComp.fetchImage("texture3.gif"));
        add(this.container, "Center");
      } 
      this.container.add(this.panelLeft, "West");
      this.container.add(this.panelRight, "East");
      this.container.add(this.panelProgress, "Center");
      this.boolAdded = true;
    } 
    setVisible(true);
    super.addNotify();
    validate();
  }
  
  public void removeNotify() {
    super.removeNotify();
    if (this.boolAdded == true)
      this.boolAdded = false; 
  }
  
  protected void removePlayButton() {
    this.panelLeft.remove(this.buttonPlay);
  }
  
  private void init() throws Exception {
    getPlayerControls();
    if (this.gainControl != null)
      this.gainControl.addGainChangeListener(this); 
    setBackground(colorBackground);
    setLayout(new BorderLayout());
    addComponentListener(this);
    this.container = this;
    this.panelLeft = new TransparentPanel(new GridLayout(1, 0));
    this.container.add(this.panelLeft, "West");
    this.panelRight = new TransparentPanel(new GridLayout(1, 0));
    this.container.add(this.panelRight, "East");
    this.panelProgress = new TransparentPanel(new BorderLayout());
    this.container.add(this.panelProgress, "Center");
    this.buttonPlay = new ButtonComp("Play", "play.gif", "play-active.gif", "play-pressed.gif", "play-disabled.gif", "pause.gif", "pause-active.gif", "pause-pressed.gif", "pause-disabled.gif");
    this.buttonPlay.setActionListener(this);
    this.panelLeft.add(this.buttonPlay);
    if (this.controlFrame != null) {
      this.buttonStepBack = new ButtonComp("StepBack", "step-back.gif", "step-back-active.gif", "step-back-pressed.gif", "step-back-disabled.gif", "step-back.gif", "step-back-active.gif", "step-back-pressed.gif", "step-back-disabled.gif");
      this.buttonStepBack.setActionListener(this);
      this.buttonStepBack.setContMousePress(true);
      this.panelLeft.add(this.buttonStepBack);
      this.buttonStepFwd = new ButtonComp("StepForward", "step-fwd.gif", "step-fwd-active.gif", "step-fwd-pressed.gif", "step-fwd-disabled.gif", "step-fwd.gif", "step-fwd-active.gif", "step-fwd-pressed.gif", "step-fwd-disabled.gif");
      this.buttonStepFwd.setActionListener(this);
      this.buttonStepFwd.setContMousePress(true);
      this.panelLeft.add(this.buttonStepFwd);
    } 
    if (this.gainControl != null) {
      this.buttonAudio = new AudioButton(this.gainControl);
      this.buttonAudio.setActionListener(this);
      this.panelRight.add(this.buttonAudio);
    } 
    this.buttonMedia = new ButtonComp("Media", "media.gif", "media-active.gif", "media-pressed.gif", "media-disabled.gif", "media.gif", "media-active.gif", "media-pressed.gif", "media-disabled.gif");
    this.buttonMedia.setActionListener(this);
    this.panelRight.add(this.buttonMedia);
    this.progressSlider = new ProgressSlider("mediatime", this, this.player);
    this.progressSlider.setActionListener(this);
    this.panelProgress.add(this.progressSlider, "Center");
    Time duration = this.player.getDuration();
    if (duration == Duration.DURATION_UNBOUNDED || duration == Duration.DURATION_UNKNOWN)
      this.progressSlider.setEnabled(false); 
    updateButtonState();
    validate();
    Dimension dim = getPreferredSize();
    setSize(dim);
    setVisible(true);
    setBackgroundTile(BasicComp.fetchImage("texture3.gif"));
    this.player.addControllerListener(this);
    Control[] arrControls = this.player.getControls();
    int nCount = arrControls.length;
    int i;
    for (i = 0; i < nCount; i++) {
      if (arrControls[i] instanceof TrackControl) {
        TrackControl trackControl = (TrackControl)arrControls[i];
        Format format = trackControl.getFormat();
        if (format instanceof javax.media.format.AudioFormat) {
          this.vectorTracksAudio.addElement(trackControl);
        } else if (format instanceof VideoFormat) {
          this.vectorTracksVideo.addElement(trackControl);
          VideoFormat formatVideo = (VideoFormat)format;
          float frameRate = formatVideo.getFrameRate();
          this.lFrameStep = (long)(1.0E9F / frameRate);
        } 
      } 
    } 
    this.menuPopup = new PopupMenu(MENU_MEDIA);
    this.buttonMedia.setPopupMenu(this.menuPopup);
    nCount = this.vectorTracksAudio.size();
    boolean aTrackAudioIconEnabled = false;
    if (nCount > 1) {
      for (i = 0; i < nCount; i++) {
        TrackControl trackControl = this.vectorTracksAudio.elementAt(i);
        boolean boolEnable = false;
        if (!aTrackAudioIconEnabled && trackControl.isEnabled()) {
          aTrackAudioIconEnabled = true;
          boolEnable = true;
        } 
        this.menuItemCheck = new CheckboxMenuItem(MENU_AUDIO + " " + i, boolEnable);
        muteAudioTrack(trackControl, !boolEnable);
        this.menuItemCheck.addItemListener(this);
        this.menuPopup.add(this.menuItemCheck);
      } 
      this.menuPopup.addSeparator();
    } 
    this.menuRate_1_4 = new CheckboxMenuItem(MENU_RATE_1_4, false);
    this.menuRate_1_4.addItemListener(this);
    this.menuPopup.add(this.menuRate_1_4);
    this.menuRate_1_2 = new CheckboxMenuItem(MENU_RATE_1_2, false);
    this.menuRate_1_2.addItemListener(this);
    this.menuPopup.add(this.menuRate_1_2);
    this.menuRate_1_1 = new CheckboxMenuItem(MENU_RATE_1_1, true);
    this.menuRate_1_1.addItemListener(this);
    this.menuPopup.add(this.menuRate_1_1);
    this.menuRate_2_1 = new CheckboxMenuItem(MENU_RATE_2_1, false);
    this.menuRate_2_1.addItemListener(this);
    this.menuPopup.add(this.menuRate_2_1);
    this.menuRate_4_1 = new CheckboxMenuItem(MENU_RATE_4_1, false);
    this.menuRate_4_1.addItemListener(this);
    this.menuPopup.add(this.menuRate_4_1);
    this.menuRate_8_1 = new CheckboxMenuItem(MENU_RATE_8_1, false);
    this.menuRate_8_1.addItemListener(this);
    this.menuPopup.add(this.menuRate_8_1);
  }
  
  private void updateButtonState() {
    if (this.player == null) {
      this.buttonPlay.setEnabled(false);
    } else {
      this.buttonPlay.setEnabled(true);
      if (this.player.getState() == 600) {
        this.buttonPlay.setValue(true);
      } else {
        this.buttonPlay.setValue(false);
      } 
    } 
  }
  
  public void minicleanUp() {
    synchronized (this.localLock) {
      this.firstTime = true;
    } 
  }
  
  public void dispose() {
    synchronized (this.localLock) {
      if (this.player == null)
        return; 
      if (this.propsSheet != null) {
        this.propsSheet.dispose();
        this.propsSheet = null;
      } 
      if (this.progressSlider != null) {
        this.progressSlider.dispose();
        this.progressSlider = null;
      } 
      if (this.audioControls != null) {
        remove(this.audioControls);
        this.audioControls = null;
      } 
      if (this.buttonAudio != null) {
        this.buttonAudio.dispose();
        this.buttonAudio = null;
      } 
      this.player = null;
      this.gainControl = null;
      this.controlFrame = null;
      if (this.parentFrame != null && this.wl != null) {
        this.parentFrame.removeWindowListener(this.wl);
        this.parentFrame = null;
        this.wl = null;
      } 
      this.vectorTracksAudio.removeAllElements();
      this.vectorTracksVideo.removeAllElements();
      if (this.menuItemCheck != null)
        this.menuItemCheck.removeItemListener(this); 
      this.menuRate_1_4.removeItemListener(this);
      this.menuRate_1_2.removeItemListener(this);
      this.menuRate_8_1.removeItemListener(this);
      this.menuRate_4_1.removeItemListener(this);
      this.menuRate_2_1.removeItemListener(this);
      this.menuRate_1_1.removeItemListener(this);
      this.buttonMedia.setPopupMenu(null);
    } 
  }
  
  private void getPlayerControls() {
    if (this.player == null)
      return; 
    this.gainControl = this.player.getGainControl();
    Control control = this.player.getControl("javax.media.control.FramePositioningControl");
    if (control != null && control instanceof FramePositioningControl)
      this.controlFrame = (FramePositioningControl)control; 
  }
  
  public void actionPerformed(ActionEvent ae) {
    String command = ae.getActionCommand();
    if (command.equalsIgnoreCase(this.buttonPlay.getLabel()))
      playStop(); 
    if (this.buttonAudio != null && command.equalsIgnoreCase(this.buttonAudio.getLabel())) {
      audioMute();
    } else if (command.equalsIgnoreCase(this.buttonMedia.getLabel()) || command.equalsIgnoreCase(MENU_PROPERTIES)) {
      showPropsSheet();
    } else if (this.buttonStepBack != null && command.equalsIgnoreCase(this.buttonStepBack.getLabel())) {
      playStep(false);
    } else if (this.buttonStepFwd != null && command.equalsIgnoreCase(this.buttonStepFwd.getLabel())) {
      playStep(true);
    } 
  }
  
  public void itemStateChanged(ItemEvent event) {
    ItemSelectable item = event.getItemSelectable();
    int nState = event.getStateChange();
    Object objectItem = event.getItem();
    if (item == this.menuRate_1_4 && nState == 1) {
      this.menuRate_1_4.setState(false);
      this.player.setRate(0.25F);
    } else if (item == this.menuRate_1_2 && nState == 1) {
      this.menuRate_1_2.setState(false);
      this.player.setRate(0.5F);
    } else if (item == this.menuRate_1_1 && nState == 1) {
      this.menuRate_1_1.setState(false);
      this.player.setRate(1.0F);
    } else if (item == this.menuRate_2_1 && nState == 1) {
      this.menuRate_2_1.setState(false);
      this.player.setRate(2.0F);
    } else if (item == this.menuRate_4_1 && nState == 1) {
      this.menuRate_4_1.setState(false);
      this.player.setRate(4.0F);
    } else if (item == this.menuRate_8_1 && nState == 1) {
      this.menuRate_8_1.setState(false);
      this.player.setRate(8.0F);
    } else if (objectItem instanceof String) {
      String strItem = (String)objectItem;
      if (strItem.substring(0, 5).equalsIgnoreCase(MENU_AUDIO)) {
        int nIndex = Integer.valueOf(strItem.substring(6)).intValue();
        TrackControl trackControl = this.vectorTracksAudio.elementAt(nIndex);
        boolean boolEnabled = (event.getStateChange() == 1);
        muteAudioTrack(trackControl, !boolEnabled);
      } else if (strItem.substring(0, 5).equalsIgnoreCase(MENU_VIDEO)) {
      
      } 
    } 
  }
  
  void update() {
    if (this.propsSheet == null || this.player == null)
      return; 
    if (this.player.getState() == 600) {
      this.pausecnt = -1;
      this.propsSheet.update();
    } else if (this.pausecnt < 5) {
      this.pausecnt++;
      this.propsSheet.update();
    } else if (this.pausecnt == 5) {
      this.pausecnt++;
      this.propsSheet.clearBRFR();
    } else if (this.resetMediaTimeinPause) {
      this.resetMediaTimeinPause = false;
      this.propsSheet.updateMediaTime();
    } 
  }
  
  void resetPauseCount() {
    this.pausecnt = -1;
  }
  
  private void playStop() {
    boolean state = this.buttonPlay.getValue();
    synchronized (this.localLock) {
      if (this.player == null || this.buttonPlay == null)
        return; 
      if (state) {
        if (this.player.getTargetState() != 600) {
          this.buttonPlay.setEnabled(false);
          long lDuration = this.player.getDuration().getNanoseconds();
          long lMedia = this.player.getMediaNanoseconds();
          if (lMedia >= lDuration)
            this.player.setMediaTime(new Time(0L)); 
          this.player.start();
        } 
      } else if (this.player.getTargetState() == 600) {
        this.buttonPlay.setEnabled(false);
        this.player.stop();
      } 
    } 
  }
  
  private void audioMute() {
    if (this.gainControl == null)
      return; 
    boolean boolState = this.buttonAudio.getValue();
    this.gainControl.setMute(boolState);
  }
  
  private void playStep(boolean boolFwd) {
    if (this.controlFrame == null)
      return; 
    if (this.player.getTargetState() == 600) {
      this.buttonPlay.setEnabled(false);
      this.player.stop();
    } 
    this.controlFrame.skip(boolFwd ? 1 : -1);
  }
  
  public void controllerUpdate(ControllerEvent ce) {
    synchronized (this.localLock) {
      if (this.player == null)
        return; 
      if (ce instanceof javax.media.StartEvent) {
        this.buttonPlay.setValue(true);
        this.buttonPlay.setEnabled(true);
        if (this.buttonStepFwd != null)
          this.buttonStepFwd.setEnabled(true); 
        if (this.buttonStepBack != null)
          this.buttonStepBack.setEnabled(true); 
      } else if (ce instanceof javax.media.StopEvent || ce instanceof javax.media.ResourceUnavailableEvent) {
        this.buttonPlay.setValue(false);
        this.buttonPlay.setEnabled(true);
        Thread.yield();
        long lDuration = this.player.getDuration().getNanoseconds();
        long lMedia = this.player.getMediaNanoseconds();
        if (this.buttonStepFwd != null)
          if (lMedia < lDuration - 1L) {
            this.buttonStepFwd.setEnabled(true);
          } else {
            this.buttonStepFwd.setEnabled(false);
          }  
        if (this.buttonStepBack != null)
          if (lMedia > 0L) {
            this.buttonStepBack.setEnabled(true);
          } else {
            this.buttonStepBack.setEnabled(false);
          }  
      } else if (ce instanceof javax.media.DurationUpdateEvent) {
        Time duration = this.player.getDuration();
        if (duration == Duration.DURATION_UNKNOWN || duration == Duration.DURATION_UNBOUNDED) {
          this.progressSlider.setEnabled(false);
        } else {
          this.progressSlider.setEnabled(true);
        } 
        if (this.propsSheet != null)
          this.propsSheet.updateDuration(); 
      } else if (ce instanceof javax.media.MediaTimeSetEvent) {
        Thread.yield();
        long l1 = this.player.getDuration().getNanoseconds();
        long l2 = this.player.getMediaNanoseconds();
        if (this.buttonStepFwd != null)
          if (l2 < l1 - 1L) {
            this.buttonStepFwd.setEnabled(true);
          } else {
            this.buttonStepFwd.setEnabled(false);
          }  
        if (this.buttonStepBack != null)
          if (l2 > 0L) {
            this.buttonStepBack.setEnabled(true);
          } else {
            this.buttonStepBack.setEnabled(false);
          }  
        this.resetMediaTimeinPause = true;
      } else if (ce instanceof javax.media.RateChangeEvent) {
        this.menuRate_1_4.setState(false);
        this.menuRate_1_2.setState(false);
        this.menuRate_1_1.setState(false);
        this.menuRate_2_1.setState(false);
        this.menuRate_4_1.setState(false);
        this.menuRate_8_1.setState(false);
        float fRate = this.player.getRate();
        if (fRate < 0.5D) {
          this.menuRate_1_4.removeItemListener(this);
          this.menuRate_1_4.setState(true);
          this.menuRate_1_4.addItemListener(this);
        } else if (fRate < 1.0D) {
          this.menuRate_1_2.removeItemListener(this);
          this.menuRate_1_2.setState(true);
          this.menuRate_1_2.addItemListener(this);
        } else if (fRate > 4.0D) {
          this.menuRate_8_1.removeItemListener(this);
          this.menuRate_8_1.setState(true);
          this.menuRate_8_1.addItemListener(this);
        } else if (fRate > 2.0D) {
          this.menuRate_4_1.removeItemListener(this);
          this.menuRate_4_1.setState(true);
          this.menuRate_4_1.addItemListener(this);
        } else if (fRate > 1.0D) {
          this.menuRate_2_1.removeItemListener(this);
          this.menuRate_2_1.setState(true);
          this.menuRate_2_1.addItemListener(this);
        } else {
          this.menuRate_1_1.removeItemListener(this);
          this.menuRate_1_1.setState(true);
          this.menuRate_1_1.addItemListener(this);
        } 
      } 
    } 
  }
  
  public void gainChange(GainChangeEvent event) {
    boolean boolMute = this.gainControl.getMute();
    this.buttonAudio.setValue(boolMute);
  }
  
  public void componentResized(ComponentEvent e) {
    validate();
  }
  
  public void componentMoved(ComponentEvent e) {}
  
  public void componentShown(ComponentEvent e) {}
  
  public void componentHidden(ComponentEvent e) {}
  
  public void paint(Graphics g) {
    if (this.firstTime)
      findFrame(); 
    super.paint(g);
  }
  
  protected void findFrame() {
    synchronized (this.localLock) {
      if (this.firstTime) {
        this.firstTime = false;
        Component c = getParent();
        while (!(c instanceof Frame) && c != null)
          c = c.getParent(); 
        if (c instanceof Frame) {
          this.parentFrame = (Frame)c;
          ((Frame)c).addWindowListener(this.wl = new WindowAdapter(this) {
                private final DefaultControlPanel this$0;
                
                public void windowClosing(WindowEvent we) {
                  this.this$0.minicleanUp();
                }
              });
        } 
      } 
    } 
  }
  
  public Insets getInsets() {
    Insets insets = new Insets(1, 0, 0, 0);
    return insets;
  }
  
  private void showPropsSheet() {
    if (this.propsSheet == null)
      try {
        this.propsSheet = new PropertySheet(this.parentFrame, this.player);
        if (isShowing()) {
          Point point = getLocationOnScreen();
          Dimension dim = getSize();
          point.y += dim.height;
          this.propsSheet.setLocation(point);
        } 
      } catch (Exception e) {
        this.propsSheet = null;
      }  
    if (this.propsSheet != null)
      this.propsSheet.setVisible(true); 
  }
  
  private void muteAudioTrack(TrackControl trackControl, boolean boolMute) {
    Object[] arrControls = trackControl.getControls();
    int nCount = arrControls.length;
    for (int i = 0; i < nCount; i++) {
      if (arrControls[i] instanceof GainControl)
        ((GainControl)arrControls[i]).setMute(boolMute); 
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\DefaultControlPanel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */