package com.sun.media.ui;

import com.sun.media.controls.NumericControl;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class Slider extends BasicComp implements MouseListener, MouseMotionListener {
  Image imageGrabber;
  
  Image imageGrabberX;
  
  Image imageGrabberDown;
  
  Graphics paintG = null;
  
  boolean grabbed;
  
  boolean entered;
  
  int grabberPosition;
  
  int leftBorder = 8;
  
  int rightBorder = 8;
  
  int sliderWidth;
  
  int width;
  
  int height;
  
  int displayPercent;
  
  float[] detents;
  
  Dimension dimension;
  
  float lower = 0.0F;
  
  float upper = 1.0F;
  
  float range = 1.0F;
  
  float value = 0.5F;
  
  boolean dragging = false;
  
  boolean grabberVisible = true;
  
  public Slider() {
    this(null, null);
  }
  
  public Slider(float[] detents) {
    this(detents, null);
  }
  
  public Slider(float[] detents, Color background) {
    super("Slider");
    this.imageGrabber = BasicComp.fetchImage("grabber.gif");
    this.imageGrabberDown = BasicComp.fetchImage("grabber-pressed.gif");
    this.imageGrabberX = BasicComp.fetchImage("grabber-disabled.gif");
    this.detents = detents;
    if (background != null)
      setBackground(background); 
    this.width = 115;
    this.height = 18;
    this.displayPercent = 100;
    this.dimension = new Dimension(this.width, this.height);
    this.sliderWidth = this.width - this.leftBorder - this.rightBorder;
    setSize(this.width, this.height);
    setVisible(true);
    this.grabbed = false;
    this.entered = false;
    addMouseListener(this);
    addMouseMotionListener(this);
  }
  
  public void setEnabled(boolean state) {
    super.setEnabled(state);
    repaint();
  }
  
  public Point getPosition() {
    return new Point(this.grabberPosition + this.leftBorder, 10);
  }
  
  public void setDisplayPercent(int percent) {
    if (percent != this.displayPercent) {
      this.displayPercent = percent;
      if (this.displayPercent > 100) {
        this.displayPercent = 100;
      } else if (this.displayPercent < 0) {
        this.displayPercent = 0;
      } 
      repaint();
    } 
  }
  
  public boolean isGrabberVisible() {
    return this.grabberVisible;
  }
  
  public void setGrabberVisible(boolean visible) {
    if (this.grabberVisible != visible) {
      this.grabberVisible = visible;
      repaint();
    } 
  }
  
  public void paint(Graphics g) {
    Dimension size = getSize();
    int y = size.height / 2 - 2;
    this.paintG = g;
    int grabberX = this.grabberPosition + this.leftBorder - 5;
    g.setColor(getBackground().darker());
    g.drawRect(this.leftBorder, y, this.sliderWidth, 3);
    g.setColor(getBackground());
    g.draw3DRect(this.leftBorder, y, this.sliderWidth * this.displayPercent / 100, 3, false);
    if (this.detents != null && this.detents.length != 0) {
      this.paintG.setColor(Color.black);
      for (int i = 0; i < this.detents.length; i++) {
        int x = this.leftBorder + (int)(this.detents[i] * this.sliderWidth / this.range);
        this.paintG.drawLine(x, 12, x, 15);
      } 
    } 
    if (this.grabberVisible) {
      Image image;
      if (isEnabled()) {
        if (this.grabbed || this.entered) {
          image = this.imageGrabberDown;
        } else {
          image = this.imageGrabber;
        } 
      } else {
        image = this.imageGrabberX;
      } 
      this.paintG.drawImage(image, grabberX, 4, this);
    } 
  }
  
  private int limitGrabber(int mousex) {
    int x = mousex - this.leftBorder;
    if (x < 0) {
      x = 0;
    } else if (x > this.sliderWidth) {
      x = this.sliderWidth;
    } 
    return x;
  }
  
  private void setSliderPosition(float value, float range) {
    this.grabberPosition = (int)(value / range * this.sliderWidth);
  }
  
  private void seek() {
    if (this.control != null && this.control instanceof NumericControl) {
      NumericControl nc = (NumericControl)this.control;
      float lower = nc.getLowerLimit();
      float upper = nc.getUpperLimit();
      float value = this.grabberPosition / this.sliderWidth * (upper - lower) + lower;
      if (this.detents != null && this.detents.length > 0 && this.dragging) {
        float tolerance = (upper - lower) * 0.05F;
        for (int i = 0; i < this.detents.length; i++) {
          if (Math.abs(this.detents[i] - value) <= tolerance)
            value = this.detents[i]; 
        } 
      } 
      float result = nc.setValue(value);
      if (value != result)
        setSliderPosition(result - lower, upper - lower); 
    } 
    repaint();
  }
  
  public void mousePressed(MouseEvent me) {
    int modifier = me.getModifiers();
    if ((modifier & 0x8) == 0 && (modifier & 0x4) == 0)
      if (isEnabled()) {
        this.dragging = false;
        this.grabbed = true;
        this.grabberPosition = limitGrabber(me.getX());
        seek();
      }  
  }
  
  public void mouseReleased(MouseEvent me) {
    int modifier = me.getModifiers();
    if ((modifier & 0x8) == 0 && (modifier & 0x4) == 0)
      if (isEnabled()) {
        this.dragging = false;
        this.grabbed = false;
        repaint();
      }  
  }
  
  public void mouseDragged(MouseEvent me) {
    int modifier = me.getModifiers();
    if ((modifier & 0x8) == 0 && (modifier & 0x4) == 0)
      if (isEnabled()) {
        this.dragging = true;
        this.grabberPosition = limitGrabber(me.getX());
        seek();
      }  
  }
  
  public void mouseEntered(MouseEvent me) {
    this.entered = true;
    repaint();
  }
  
  public void mouseExited(MouseEvent me) {
    this.entered = false;
    repaint();
  }
  
  public void mouseClicked(MouseEvent me) {}
  
  public void mouseMoved(MouseEvent me) {}
  
  public void setSize(int width, int height) {
    super.setSize(width, height);
    this.paintG = null;
    repaint();
  }
  
  public Dimension getPreferredSize() {
    return this.dimension;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\Slider.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */