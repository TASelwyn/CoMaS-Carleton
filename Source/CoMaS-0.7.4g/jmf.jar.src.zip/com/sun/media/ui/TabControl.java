/*     */ package com.sun.media.ui;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Button;
/*     */ import java.awt.CardLayout;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Panel;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.ComponentListener;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TabControl
/*     */   extends Panel
/*     */   implements MouseListener, FocusListener, KeyListener, ComponentListener
/*     */ {
/*     */   public static final int ALIGN_TOP = 0;
/*     */   public static final int ALIGN_LEFT = 1;
/*     */   private Panel panelPageContainer;
/*  47 */   private CardLayout layoutCard = new CardLayout();
/*  48 */   private int nCurrentPage = -1;
/*     */   private Button buttonFocus;
/*     */   private boolean boolFocus = false;
/*  51 */   private int nAlignment = 0;
/*     */   
/*  53 */   private int MARGIN_PAGE_VERT = 6;
/*  54 */   private int MARGIN_PAGE_HORZ = 6;
/*     */   
/*  56 */   private String strPageToShowAfterPaint = null;
/*  57 */   private Cursor cursorNormal = new Cursor(0);
/*  58 */   private Cursor cursorWait = new Cursor(3);
/*     */   
/*  60 */   private Vector vectorTabs = new Vector();
/*  61 */   private int nTabHeightMax = 1;
/*  62 */   private int nTabWidthMax = 1;
/*     */ 
/*     */   
/*  65 */   private int nRowCount = 1;
/*     */ 
/*     */   
/*     */   public TabControl() {
/*  69 */     this(0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TabControl(int nAlignment) {
/*  75 */     this.nAlignment = nAlignment;
/*     */     try {
/*  77 */       init();
/*     */     } catch (Exception e) {
/*     */       
/*  80 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() throws Exception {
/*  89 */     setLayout(new BorderLayout());
/*  90 */     addComponentListener(this);
/*  91 */     addMouseListener(this);
/*     */     
/*  93 */     this.buttonFocus = new Button("Focus");
/*  94 */     add(this.buttonFocus);
/*  95 */     this.buttonFocus.addKeyListener(this);
/*  96 */     this.buttonFocus.addFocusListener(this);
/*     */     
/*  98 */     this.panelPageContainer = new Panel(this.layoutCard);
/*  99 */     add(this.panelPageContainer, "Center");
/*     */     
/* 101 */     Font fontOld = this.panelPageContainer.getFont();
/* 102 */     if (fontOld == null) {
/* 103 */       fontOld = new Font("Dialog", 0, 12);
/*     */     }
/* 105 */     Font font = new Font("Dialog", 0, 12);
/* 106 */     setFont(font);
/* 107 */     this.panelPageContainer.setFont(fontOld);
/*     */     
/* 109 */     setBackground(TabField.COLOR_BG);
/* 110 */     this.panelPageContainer.setBackground(TabField.COLOR_BG);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int addPage(Panel panelPage, String strTitle) {
/* 116 */     int nIndex = addPage(panelPage, strTitle, null);
/* 117 */     return nIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addPage(Panel panelPage, String strTitle, Image image) {
/* 126 */     int nIndex = this.vectorTabs.size();
/* 127 */     TabField tabField = new TabField(this, panelPage, strTitle, image);
/* 128 */     this.vectorTabs.addElement(tabField);
/*     */     
/* 130 */     this.panelPageContainer.add(panelPage, strTitle);
/* 131 */     if (nIndex == 0) {
/* 132 */       this.nCurrentPage = 0;
/* 133 */       this.layoutCard.show(this.panelPageContainer, strTitle);
/*     */     } 
/*     */     
/* 136 */     tabField.calculateTabDimension(getFontMetrics(getFont()));
/* 137 */     this.nTabHeightMax = Math.max(tabField.dim.height, this.nTabHeightMax);
/* 138 */     this.nTabWidthMax = Math.max(tabField.dim.width, this.nTabWidthMax);
/*     */     
/* 140 */     recalculateTabs();
/* 141 */     repaint();
/*     */     
/* 143 */     return nIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setPageImage(Panel panelPage, Image imageTab) {
/* 154 */     int nIndex = findPage(panelPage);
/* 155 */     if (nIndex < 0 || nIndex >= this.vectorTabs.size()) {
/* 156 */       return nIndex;
/*     */     }
/* 158 */     TabField tabField = this.vectorTabs.elementAt(nIndex);
/* 159 */     if (tabField.image == imageTab)
/* 160 */       return nIndex; 
/* 161 */     tabField.image = imageTab;
/*     */     
/* 163 */     this.nTabHeightMax = 1;
/* 164 */     this.nTabWidthMax = 1;
/* 165 */     int nCount = this.vectorTabs.size();
/* 166 */     for (int i = 0; i < nCount; i++) {
/* 167 */       tabField = this.vectorTabs.elementAt(i);
/* 168 */       tabField.calculateTabDimension(getFontMetrics(getFont()));
/* 169 */       this.nTabHeightMax = Math.max(tabField.dim.height, this.nTabHeightMax);
/* 170 */       this.nTabWidthMax = Math.max(tabField.dim.width, this.nTabWidthMax);
/*     */     } 
/*     */     
/* 173 */     recalculateTabs();
/* 174 */     repaint();
/* 175 */     return nIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize() {
/* 185 */     Dimension dim = super.getPreferredSize();
/*     */     
/* 187 */     if (this.nAlignment == 1) {
/* 188 */       dim.height = Math.max(dim.height, this.nTabHeightMax * this.vectorTabs.size() + 1);
/*     */     } else {
/* 190 */       int nRowWidth = 0;
/* 191 */       for (int i = 0; i < this.vectorTabs.size(); i++) {
/* 192 */         TabField tabField = this.vectorTabs.elementAt(i);
/* 193 */         nRowWidth += tabField.dim.width;
/*     */       } 
/* 195 */       dim.width = Math.max(dim.width, nRowWidth + 1);
/*     */     } 
/* 197 */     return dim;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Insets getInsets() {
/* 203 */     Insets insets = super.getInsets();
/* 204 */     if (this.nAlignment == 1) {
/* 205 */       insets = new Insets(insets.top + this.MARGIN_PAGE_VERT, insets.left + this.nRowCount * this.nTabWidthMax - 2 + this.MARGIN_PAGE_HORZ, insets.bottom + this.MARGIN_PAGE_VERT, insets.right + this.MARGIN_PAGE_HORZ);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 210 */       insets = new Insets(insets.top + this.nRowCount * this.nTabHeightMax - 2 + this.MARGIN_PAGE_VERT, insets.left + this.MARGIN_PAGE_HORZ, insets.bottom + this.MARGIN_PAGE_VERT, insets.right + this.MARGIN_PAGE_HORZ);
/*     */     } 
/*     */ 
/*     */     
/* 214 */     return insets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void update(Graphics g) {
/*     */     Graphics graphics;
/* 222 */     Rectangle rectClient = getBounds();
/*     */     
/* 224 */     if (rectClient.width < 1 || rectClient.height < 1)
/*     */       return; 
/* 226 */     Image image = createImage(rectClient.width, rectClient.height);
/* 227 */     if (image != null) {
/* 228 */       graphics = image.getGraphics();
/*     */     } else {
/* 230 */       graphics = g;
/*     */     } 
/* 232 */     paint(graphics);
/*     */     
/* 234 */     if (image != null) {
/* 235 */       g.drawImage(image, 0, 0, this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics graphics) {
/* 253 */     super.paint(graphics);
/*     */     
/* 255 */     Rectangle rectClient = getBounds();
/* 256 */     rectClient.x = 0;
/* 257 */     rectClient.y = 0;
/*     */     
/* 259 */     Rectangle rect = new Rectangle(rectClient);
/* 260 */     if (this.nAlignment == 1) {
/* 261 */       rect.x += this.nTabWidthMax * this.nRowCount - 2;
/* 262 */       rect.width -= this.nTabWidthMax * this.nRowCount - 2;
/*     */     } else {
/*     */       
/* 265 */       rect.y += this.nTabHeightMax * this.nRowCount - 2;
/* 266 */       rect.height -= this.nTabHeightMax * this.nRowCount - 2;
/*     */     } 
/* 268 */     rect.width--;
/* 269 */     rect.height--;
/*     */     
/* 271 */     graphics.setColor(TabField.COLOR_SHADOW_BOTTOM);
/* 272 */     graphics.drawRect(rect.x, rect.y, rect.width, rect.height);
/* 273 */     graphics.setColor(TabField.COLOR_SHADOW_TOP);
/* 274 */     graphics.drawLine(rect.x + 1, rect.y + 1, rect.x + 1, rect.y + rect.height - 2);
/* 275 */     graphics.drawLine(rect.x + 1, rect.y + 1, rect.x + rect.width - 2, rect.y + 1);
/*     */     
/* 277 */     Font fontNormal = getFont();
/*     */     
/* 279 */     Font fontBold = fontNormal;
/* 280 */     int nSize = this.vectorTabs.size();
/* 281 */     for (int i = nSize - 1; i >= 0; i--) {
/* 282 */       FontMetrics fontMetrics; TabField tabField = this.vectorTabs.elementAt(i);
/* 283 */       if (i == this.nCurrentPage) {
/* 284 */         if (this.nAlignment == 1) {
/* 285 */           tabField.drawCurrentTabLeft(graphics);
/*     */         } else {
/* 287 */           tabField.drawCurrentTabTop(graphics);
/*     */         }
/*     */       
/* 290 */       } else if (this.nAlignment == 1) {
/* 291 */         tabField.drawTabLeft(graphics);
/*     */       } else {
/* 293 */         tabField.drawTabTop(graphics);
/*     */       } 
/*     */       
/* 296 */       graphics.setColor(getForeground());
/* 297 */       Rectangle rectString = new Rectangle(tabField.rect);
/* 298 */       if (this.nAlignment == 1) {
/* 299 */         rectString.width = this.nTabWidthMax;
/*     */       } else {
/* 301 */         rectString.height = this.nTabHeightMax;
/*     */       } 
/* 303 */       if (tabField.image != null) {
/* 304 */         int nWidth = tabField.image.getWidth(this);
/* 305 */         rectString.x += nWidth + tabField.MARGIN_TAB_HORZ;
/* 306 */         rectString.width -= nWidth + tabField.MARGIN_TAB_HORZ;
/*     */       } 
/* 308 */       rectString.y++;
/* 309 */       if (i == this.nCurrentPage) {
/* 310 */         graphics.setFont(fontBold);
/* 311 */         fontMetrics = graphics.getFontMetrics(fontBold);
/* 312 */         if (this.boolFocus == true) {
/* 313 */           int m = fontMetrics.stringWidth(tabField.strTitle) + 6;
/* 314 */           int nHeight = fontMetrics.getHeight() + 1;
/* 315 */           int nX = rectString.x + (rectString.width - m) / 2;
/* 316 */           int nY = rectString.y + (this.nTabHeightMax - 2 - nHeight) / 2 + 1;
/* 317 */           drawDottedRectangle(graphics, nX, nY, m, nHeight);
/*     */         } 
/*     */       } else {
/*     */         
/* 321 */         graphics.setFont(fontNormal);
/* 322 */         fontMetrics = graphics.getFontMetrics(fontNormal);
/*     */       } 
/* 324 */       int j = rectString.x + (rectString.width - fontMetrics.stringWidth(tabField.strTitle)) / 2;
/* 325 */       int k = rectString.y + rectString.height - (rectString.height - fontMetrics.getHeight()) / 2 - fontMetrics.getMaxDescent();
/* 326 */       k--;
/* 327 */       if (i != this.nCurrentPage) {
/* 328 */         j++;
/* 329 */         k++;
/*     */       } 
/* 331 */       graphics.drawString(tabField.strTitle, j, k);
/*     */       
/* 333 */       if (tabField.image != null) {
/* 334 */         int m = tabField.image.getHeight(this);
/* 335 */         j = tabField.rect.x + tabField.MARGIN_TAB_HORZ;
/* 336 */         k = tabField.rect.y + (this.nTabHeightMax - m) / 2;
/* 337 */         if (i != this.nCurrentPage) {
/* 338 */           j++;
/* 339 */           k++;
/*     */         } 
/* 341 */         graphics.drawImage(tabField.image, j, k, this);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 346 */     if (this.strPageToShowAfterPaint != null) {
/* 347 */       this.layoutCard.show(this.panelPageContainer, this.strPageToShowAfterPaint);
/* 348 */       this.strPageToShowAfterPaint = null;
/* 349 */       setCursor(this.cursorNormal);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void drawDottedRectangle(Graphics graphics, int nX, int nY, int nWidth, int nHeight) {
/* 355 */     drawDottedLine(graphics, nX, nY, nX + nWidth - 1, nY);
/* 356 */     drawDottedLine(graphics, nX + nWidth - 1, nY, nX + nWidth - 1, nY + nHeight - 1);
/* 357 */     drawDottedLine(graphics, nX + nWidth - 1, nY + nHeight - 1, nX, nY + nHeight - 1);
/* 358 */     drawDottedLine(graphics, nX, nY + nHeight - 1, nX, nY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void drawDottedLine(Graphics graphics, int nX1, int nY1, int nX2, int nY2) {
/* 365 */     if (nX1 == nX2 && nY1 == nY2) {
/* 366 */       drawDot(graphics, nX1, nY1);
/*     */       return;
/*     */     } 
/* 369 */     if (nX1 > nX2) {
/* 370 */       int nX = nX1;
/* 371 */       nX1 = nX2;
/* 372 */       nX2 = nX;
/*     */     } 
/* 374 */     if (nY1 > nY2) {
/* 375 */       int nY = nY1;
/* 376 */       nY1 = nY2;
/* 377 */       nY2 = nY;
/*     */     } 
/* 379 */     if (nX2 - nX1 > nY2 - nY1) {
/* 380 */       double dDiv = (nY2 - nY1) / (nX2 - nX1);
/* 381 */       for (int i = nX1; i <= nX2; i++) {
/* 382 */         int j = (int)Math.rint(nY1 + (i - nX1) * dDiv);
/* 383 */         drawDot(graphics, i, j);
/*     */       } 
/*     */     } else {
/*     */       
/* 387 */       double d = ((nX2 - nX1) / (nY2 - nY1));
/* 388 */       for (int i = nY1; i <= nY2; i++) {
/* 389 */         int j = (int)Math.rint(nX1 + (i - nY1) * d);
/* 390 */         drawDot(graphics, j, i);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void drawDot(Graphics graphics, int nX, int nY) {
/* 397 */     if ((nX + nY) % 2 == 0) {
/* 398 */       graphics.drawLine(nX, nY, nX, nY);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseClicked(MouseEvent event) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void mousePressed(MouseEvent event) {
/* 410 */     int x = event.getX();
/* 411 */     int y = event.getY();
/*     */     
/* 413 */     int nTabCount = this.vectorTabs.size();
/* 414 */     for (int i = 0; i < nTabCount; i++) {
/* 415 */       TabField tabField = this.vectorTabs.elementAt(i);
/* 416 */       if (tabField.rect.contains(x, y)) {
/* 417 */         this.buttonFocus.requestFocus();
/* 418 */         this.nCurrentPage = i;
/* 419 */         this.strPageToShowAfterPaint = tabField.strTitle;
/* 420 */         setCursor(this.cursorWait);
/* 421 */         repaint();
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseReleased(MouseEvent event) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseEntered(MouseEvent event) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseExited(MouseEvent event) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void keyTyped(KeyEvent event) {}
/*     */ 
/*     */   
/*     */   public void keyPressed(KeyEvent event) {
/* 445 */     int nIndex = this.nCurrentPage;
/* 446 */     int nKeyCode = event.getKeyCode();
/* 447 */     if (nKeyCode == 40 || nKeyCode == 39) {
/* 448 */       nIndex++;
/*     */     }
/* 450 */     else if (nKeyCode == 38 || nKeyCode == 37) {
/* 451 */       nIndex--;
/*     */     } 
/*     */     
/* 454 */     if (nIndex >= this.vectorTabs.size())
/* 455 */       nIndex = this.vectorTabs.size() - 1; 
/* 456 */     if (nIndex < 0) {
/* 457 */       nIndex = 0;
/*     */     }
/* 459 */     if (this.nCurrentPage != nIndex) {
/* 460 */       this.nCurrentPage = nIndex;
/* 461 */       TabField tabField = this.vectorTabs.elementAt(nIndex);
/* 462 */       this.strPageToShowAfterPaint = tabField.strTitle;
/* 463 */       setCursor(this.cursorWait);
/* 464 */       repaint();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void keyReleased(KeyEvent event) {}
/*     */   
/*     */   public void focusGained(FocusEvent event) {
/* 472 */     if (this.boolFocus == true)
/*     */       return; 
/* 474 */     this.boolFocus = true;
/* 475 */     repaint();
/*     */   }
/*     */   
/*     */   public void focusLost(FocusEvent event) {
/* 479 */     if (!this.boolFocus)
/*     */       return; 
/* 481 */     this.boolFocus = false;
/* 482 */     repaint();
/*     */   }
/*     */   
/*     */   public void componentResized(ComponentEvent event) {
/* 486 */     recalculateTabs();
/* 487 */     doLayout();
/* 488 */     this.panelPageContainer.validate();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void componentMoved(ComponentEvent event) {}
/*     */ 
/*     */   
/*     */   public void componentShown(ComponentEvent event) {}
/*     */ 
/*     */   
/*     */   public void componentHidden(ComponentEvent event) {}
/*     */ 
/*     */   
/*     */   private void recalculateTabs() {
/* 503 */     int nRowSize = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 512 */     Rectangle rectClient = getBounds();
/* 513 */     rectClient.x = 0;
/* 514 */     rectClient.y = 0;
/* 515 */     if (rectClient.width < 1 || rectClient.height < 1) {
/*     */       return;
/*     */     }
/* 518 */     int nTabCount = this.vectorTabs.size();
/* 519 */     if (this.nAlignment == 1) {
/* 520 */       nRowSize = rectClient.height / this.nTabHeightMax;
/* 521 */       this.nRowCount = (nTabCount + nRowSize - 1) / nRowSize;
/* 522 */       int nOffsetX = this.nRowCount * this.nTabWidthMax;
/* 523 */       int nOffsetY = 0;
/* 524 */       for (int i = 0; i < nTabCount; i++) {
/* 525 */         if (i % nRowSize == 0) {
/* 526 */           nOffsetX -= this.nTabWidthMax;
/* 527 */           nOffsetY = 0;
/*     */         } 
/* 529 */         TabField tabField = this.vectorTabs.elementAt(i);
/* 530 */         tabField.rect.x = nOffsetX;
/* 531 */         tabField.rect.y = nOffsetY;
/* 532 */         tabField.rect.width = this.nTabWidthMax * (i / nRowSize + 1);
/* 533 */         tabField.rect.height = this.nTabHeightMax;
/* 534 */         tabField.nRowIndex = i / nRowSize;
/* 535 */         if (tabField.nRowIndex > 0) {
/* 536 */           tabField.rect.width -= 2;
/*     */         }
/* 538 */         nOffsetY += this.nTabHeightMax;
/*     */       } 
/*     */     } else {
/*     */       
/* 542 */       this.nRowCount = 1;
/* 543 */       int nRowWidth = 0; byte b;
/* 544 */       for (b = 0; b < nTabCount; b++) {
/* 545 */         TabField tabField = this.vectorTabs.elementAt(b);
/* 546 */         if (nRowWidth + tabField.dim.width > rectClient.width) {
/* 547 */           nRowWidth = 0;
/* 548 */           this.nRowCount++;
/*     */         } 
/* 550 */         nRowWidth += tabField.dim.width;
/*     */       } 
/* 552 */       int i = 0;
/* 553 */       int k = this.nRowCount * this.nTabHeightMax;
/* 554 */       int nRowIndex = 0;
/* 555 */       int j = 0;
/* 556 */       for (b = 0; b < nTabCount; b++) {
/* 557 */         if (b == j) {
/* 558 */           i = 0;
/* 559 */           k -= this.nTabHeightMax;
/* 560 */           nRowWidth = 0;
/* 561 */           for (j = b; j < nTabCount; j++) {
/* 562 */             TabField tabField1 = this.vectorTabs.elementAt(j);
/* 563 */             if (j > b && nRowWidth + tabField1.dim.width > rectClient.width) {
/*     */               break;
/*     */             }
/* 566 */             nRowWidth += tabField1.dim.width;
/* 567 */             tabField1.nRowIndex = nRowIndex;
/*     */           } 
/* 569 */           nRowSize = j - b;
/* 570 */           nRowIndex++;
/*     */         } 
/*     */         
/* 573 */         TabField tabField = this.vectorTabs.elementAt(b);
/* 574 */         tabField.rect.x = i;
/* 575 */         tabField.rect.y = k;
/* 576 */         tabField.rect.width = tabField.dim.width;
/* 577 */         if (this.nRowCount > 1 && nRowIndex < this.nRowCount) {
/* 578 */           tabField.rect.width += (rectClient.width - nRowWidth - 1) / nRowSize;
/* 579 */           tabField.rect.width += (j - b > (rectClient.width - nRowWidth - 1) % nRowSize) ? 0 : 1;
/*     */         } 
/* 581 */         tabField.rect.height = this.nTabHeightMax * nRowIndex;
/* 582 */         if (tabField.nRowIndex > 0)
/* 583 */           tabField.rect.height -= 2; 
/* 584 */         i += tabField.rect.width;
/*     */       } 
/*     */     } 
/* 587 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int findPage(Panel panelPage) {
/* 595 */     int i = this.vectorTabs.size() - 1;
/* 596 */     while (i >= 0) {
/* 597 */       TabField tabField = this.vectorTabs.elementAt(i);
/* 598 */       if (tabField.panelPage == panelPage)
/*     */         break; 
/* 600 */       i--;
/*     */     } 
/* 602 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\ui\TabControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */