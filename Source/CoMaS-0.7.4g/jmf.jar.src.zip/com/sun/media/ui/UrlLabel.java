package com.sun.media.ui;

import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Label;
import java.awt.Rectangle;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.io.File;

class UrlLabel extends Label implements ComponentListener {
  private String strLabel = null;
  
  public UrlLabel(String strLabel) {
    super(strLabel);
    this.strLabel = strLabel;
    addComponentListener(this);
  }
  
  public synchronized void setText(String strLabel) {
    this.strLabel = strLabel;
    setInternalLabel();
  }
  
  public String getText() {
    return this.strLabel;
  }
  
  public String toString() {
    return this.strLabel;
  }
  
  private void setInternalLabel() {
    Rectangle rect = getBounds();
    Font font = getFont();
    FontMetrics fontMetrics = getFontMetrics(font);
    String strLabel = this.strLabel;
    int nWidth = fontMetrics.stringWidth(strLabel);
    int nIndex1 = this.strLabel.lastIndexOf(File.separatorChar);
    int nIndex2 = nIndex1;
    while (nIndex2 >= 0 && nWidth > rect.width) {
      nIndex2 = this.strLabel.lastIndexOf(File.separatorChar, nIndex2 - 1);
      if (nIndex2 < 0) {
        strLabel = "..." + this.strLabel.substring(nIndex1);
      } else {
        strLabel = this.strLabel.substring(0, nIndex2 + 1) + "..." + this.strLabel.substring(nIndex1);
      } 
      nWidth = fontMetrics.stringWidth(strLabel);
    } 
    super.setText(strLabel);
  }
  
  public void componentResized(ComponentEvent event) {
    setInternalLabel();
  }
  
  public void componentMoved(ComponentEvent event) {}
  
  public void componentShown(ComponentEvent event) {}
  
  public void componentHidden(ComponentEvent event) {}
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\UrlLabel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */