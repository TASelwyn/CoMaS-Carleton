package com.sun.media.ui;

import java.awt.Container;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Panel;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.media.Control;

public class BasicComp extends Container {
  protected String label = null;
  
  private ActionListener al = null;
  
  static Panel panel = new Panel();
  
  Control control = null;
  
  int width;
  
  int height;
  
  protected BasicComp(String label) {
    this.label = label;
  }
  
  public void setActionListener(ActionListener al) {
    this.al = al;
  }
  
  protected void informListener() {
    if (this.al != null)
      this.al.actionPerformed(new ActionEvent(this, 1001, this.label)); 
  }
  
  public static synchronized Image fetchImage(String name) {
    Image image = null;
    byte[] bits = ImageLib.getImage(name);
    if (bits == null)
      return null; 
    image = Toolkit.getDefaultToolkit().createImage(bits);
    try {
      MediaTracker imageTracker = new MediaTracker(panel);
      imageTracker.addImage(image, 0);
      imageTracker.waitForID(0);
    } catch (InterruptedException e) {
      System.err.println("ImageLoader: Interrupted at waitForID");
    } 
    return image;
  }
  
  public String getLabel() {
    return this.label;
  }
}
