package com.sun.media.ui;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Point;
import javax.media.GainControl;

class AudioButton extends ButtonComp {
  private GainControl gainControl;
  
  private GainSlider sliderGain = null;
  
  public AudioButton(GainControl gainControl) {
    super("Audio", "audio.gif", "audio-active.gif", "audio-pressed.gif", "audio-disabled.gif", "mute.gif", "mute-active.gif", "mute-pressed.gif", "mute-disabled.gif");
    this.gainControl = gainControl;
    setMousePopup(true);
  }
  
  protected void processMousePopup() {
    if (isShowing() && this.gainControl.getLevel() >= 0.0F) {
      if (this.sliderGain == null)
        this.sliderGain = new GainSlider(this.gainControl, getFrame()); 
      Dimension dim = getSize();
      Point point = getLocationOnScreen();
      point.y += dim.height;
      this.sliderGain.setLocation(point);
      this.sliderGain.setVisible(!this.sliderGain.isVisible());
    } 
  }
  
  private Frame getFrame() {
    Frame frame = null;
    Component parent = this;
    while (parent != null && !(parent instanceof Frame))
      parent = parent.getParent(); 
    if (parent != null && parent instanceof Frame)
      frame = (Frame)parent; 
    return frame;
  }
  
  public void dispose() {
    this.gainControl = null;
    if (this.sliderGain != null) {
      this.sliderGain.dispose();
      this.sliderGain = null;
    } 
  }
}
