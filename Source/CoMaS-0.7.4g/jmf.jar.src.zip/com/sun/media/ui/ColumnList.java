package com.sun.media.ui;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;

public class ColumnList extends Canvas implements MouseListener, FocusListener, KeyListener, ComponentListener {
  public static final int TYPE_INTEGER = 1;
  
  public static final int TYPE_DOUBLE = 2;
  
  public static final int TYPE_STRING = 3;
  
  public static final int TYPE_DATE = 4;
  
  private static final int MARGIN_VERT = 2;
  
  private static final int MARGIN_HORZ = 6;
  
  private static final Color COLOR_HEADER_BG = Color.lightGray;
  
  private static final Color COLOR_HEADER_FG = Color.black;
  
  private static final Color COLOR_SHADOW_TOP = Color.white;
  
  private static final Color COLOR_SHADOW_BOTTOM = Color.darkGray;
  
  private static final Color COLOR_SEL_BG = Color.white;
  
  private static final Color COLOR_SEL_FG = Color.black;
  
  private Vector vectorColumns = new Vector();
  
  private Vector vectorRows = new Vector();
  
  private boolean boolFocus = false;
  
  private boolean boolSetColumnWidthAsPreferred = false;
  
  private int nScrollPosHorz = 0;
  
  private int nScrollPosVert = 0;
  
  private int nCurrentIndex = 0;
  
  private int nVisibleRows = 1;
  
  private Font fontHeader = new Font("Dialog", 0, 12);
  
  private Font fontItem = new Font("Dialog", 0, 12);
  
  private int nHeightHeader;
  
  private int nHeightRow;
  
  public ColumnList(String[] arrColumnNames) {
    int nCount = arrColumnNames.length;
    for (int i = 0; i < nCount; i++) {
      ColumnData column = new ColumnData(arrColumnNames[i], 3);
      this.vectorColumns.addElement(column);
    } 
    try {
      init();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void addRow(Object[] arrValues) {
    RowData rowData = new RowData(arrValues);
    this.vectorRows.addElement(rowData);
    repaint();
  }
  
  public void removeRow(int nRowIndex) {
    this.vectorRows.removeElementAt(nRowIndex);
    repaint();
  }
  
  public void setCellValue(Object value, int nRowIndex, int nColumnIndex) {
    RowData rowData = this.vectorRows.elementAt(nRowIndex);
    rowData.setValue(value, nColumnIndex);
    repaint();
  }
  
  public void setColumnWidth(int nWidth, int nColumnIndex) {
    ColumnData columnData = this.vectorColumns.elementAt(nColumnIndex);
    columnData.nWidth = nWidth;
    repaint();
  }
  
  public void setColumnWidth(int nWidth) {
    int nCount = this.vectorColumns.size();
    for (int i = 0; i < nCount; i++) {
      ColumnData columnData = this.vectorColumns.elementAt(i);
      columnData.nWidth = nWidth;
    } 
    repaint();
  }
  
  public void setColumnWidthAsPreferred(int nColumnIndex) {
    ColumnData columnData = this.vectorColumns.elementAt(nColumnIndex);
    int nWidth = getPreferredColumnWidth(nColumnIndex);
    columnData.nWidth = nWidth;
    repaint();
  }
  
  public void setColumnWidthAsPreferred() {
    int nCount = this.vectorColumns.size();
    int nWidthTotal = 0;
    int i;
    for (i = 0; i < nCount; i++) {
      ColumnData columnData = this.vectorColumns.elementAt(i);
      int nWidth = getPreferredColumnWidth(i);
      columnData.nWidth = nWidth;
      nWidthTotal += nWidth;
    } 
    Rectangle rect = getBounds();
    if (rect.width < 1)
      this.boolSetColumnWidthAsPreferred = true; 
    rect.width -= 2;
    if (rect.width > nWidthTotal) {
      int nWidthExtra = (rect.width - nWidthTotal) / nCount;
      nWidthTotal = rect.width;
      for (i = 0; i < nCount; i++) {
        ColumnData columnData = this.vectorColumns.elementAt(i);
        if (i < nCount - 1) {
          columnData.nWidth += nWidthExtra;
        } else {
          columnData.nWidth = nWidthTotal;
        } 
        nWidthTotal -= columnData.nWidth;
      } 
    } 
    repaint();
  }
  
  public Dimension getPreferredSize() {
    Dimension dim = new Dimension();
    dim.height += this.nHeightHeader;
    int nHeight = this.nHeightRow;
    nHeight *= this.vectorRows.size();
    dim.height += nHeight;
    int nCount = this.vectorColumns.size();
    for (int i = 0; i < nCount; i++) {
      int nWidth = getPreferredColumnWidth(i);
      dim.width += nWidth;
    } 
    dim.width += 3;
    dim.height += 3;
    return dim;
  }
  
  public boolean isFocusTraversable() {
    return true;
  }
  
  public void update(Graphics g) {
    Graphics graphics;
    Rectangle rectClient = getBounds();
    Image image = createImage(rectClient.width, rectClient.height);
    if (image != null) {
      graphics = image.getGraphics();
    } else {
      graphics = g;
    } 
    paint(graphics);
    if (image != null)
      g.drawImage(image, 0, 0, this); 
  }
  
  public void paint(Graphics graphics) {
    Rectangle rectClient = getBounds();
    rectClient.x = 0;
    rectClient.y = 0;
    Rectangle rect = new Rectangle(rectClient);
    super.paint(graphics);
    graphics.setColor(COLOR_SHADOW_BOTTOM);
    graphics.drawRect(rect.x, rect.y, rect.width - 2, rect.height - 2);
    graphics.setColor(COLOR_SHADOW_TOP);
    graphics.drawLine(rect.x + rect.width - 1, rect.y + 1, rect.x + rect.width - 1, rect.y + rect.height - 1);
    graphics.drawLine(rect.x + 1, rect.y + rect.height - 1, rect.x + rect.width - 1, rect.y + rect.height - 1);
    int nColCount = this.vectorColumns.size();
    int nRowCount = this.vectorRows.size();
    rect.x++;
    rect.y++;
    int nStartX = rect.x;
    FontMetrics fontMetrics = getFontMetrics(this.fontHeader);
    graphics.setFont(this.fontHeader);
    int nHeight = fontMetrics.getHeight();
    rect.height = this.nHeightHeader;
    int i;
    for (i = this.nScrollPosHorz; i < nColCount; i++) {
      ColumnData columnData = this.vectorColumns.elementAt(i);
      rect.width = columnData.nWidth;
      if (rect.x + rect.width > rectClient.x + rectClient.width - 1)
        rect.width = rectClient.x + rectClient.width - 1 - rect.x; 
      graphics.setColor(COLOR_HEADER_BG);
      graphics.fillRect(rect.x, rect.y, rect.width, rect.height);
      graphics.setColor(COLOR_SHADOW_TOP);
      graphics.drawLine(rect.x, rect.y, rect.x, rect.y + rect.height - 2);
      graphics.drawLine(rect.x, rect.y, rect.x + rect.width - 2, rect.y);
      graphics.setColor(COLOR_SHADOW_BOTTOM);
      graphics.drawLine(rect.x + rect.width - 1, rect.y + 1, rect.x + rect.width - 1, rect.y + rect.height - 1);
      graphics.drawLine(rect.x + 1, rect.y + rect.height - 1, rect.x + rect.width - 1, rect.y + rect.height - 1);
      String strValue = columnData.strName;
      int nLength = strValue.length();
      int nWidth = fontMetrics.stringWidth(strValue);
      while (nWidth > rect.width - 12 && nLength > 0) {
        nLength--;
        strValue = strValue.substring(0, nLength) + "...";
        nWidth = fontMetrics.stringWidth(strValue);
      } 
      int nX = rect.x + (rect.width - nWidth) / 2;
      int nY = rect.y + rect.height - (rect.height - nHeight) / 2 - fontMetrics.getMaxDescent();
      graphics.setColor(getForeground());
      graphics.drawString(strValue, nX, nY);
      rect.x += rect.width;
    } 
    Font font = getFont();
    fontMetrics = getFontMetrics(font);
    graphics.setFont(font);
    nHeight = fontMetrics.getHeight();
    rect.y += rect.height;
    rect.height = this.nHeightRow;
    for (int j = this.nScrollPosVert; j < nRowCount; j++) {
      rect.x = nStartX;
      if (j == this.nCurrentIndex) {
        rectClient.width -= 3;
        graphics.setColor(COLOR_SEL_BG);
        graphics.fillRect(rect.x, rect.y, rect.width, rect.height);
        graphics.setColor(COLOR_SEL_FG);
        if (this.boolFocus == true) {
          drawDottedLine(graphics, rect.x, rect.y, rect.x + rect.width - 1, rect.y);
          drawDottedLine(graphics, rect.x, rect.y + rect.height - 1, rect.x + rect.width - 1, rect.y + rect.height - 1);
        } 
      } else {
        graphics.setColor(getForeground());
      } 
      RowData rowData = this.vectorRows.elementAt(j);
      for (i = this.nScrollPosHorz; i < nColCount; i++) {
        ColumnData columnData = this.vectorColumns.elementAt(i);
        rect.width = columnData.nWidth;
        if (rect.x + rect.width > rectClient.x + rectClient.width - 1)
          rect.width = rectClient.x + rectClient.width - 1 - rect.x; 
        String str = rowData.getValue(i).toString();
        int i1 = str.length();
        int n = fontMetrics.stringWidth(str);
        while (n > rect.width - 12 && i1 > 0) {
          i1--;
          str = str.substring(0, i1) + "...";
          n = fontMetrics.stringWidth(str);
        } 
        int k = rect.x + 6;
        int m = rect.y + rect.height - (rect.height - nHeight) / 2 - fontMetrics.getMaxDescent();
        graphics.drawString(str, k, m);
        rect.x += rect.width;
      } 
      rect.y += rect.height;
    } 
  }
  
  public void mouseClicked(MouseEvent event) {}
  
  public void mousePressed(MouseEvent event) {
    int x = event.getX();
    int y = event.getY();
    y -= 1 + this.nHeightHeader;
    if (y >= 0) {
      int nIndex = y / this.nHeightRow;
      if (nIndex >= 0 && nIndex < this.vectorRows.size() - this.nScrollPosVert)
        this.nCurrentIndex = nIndex + this.nScrollPosVert; 
    } 
    requestFocus();
    repaint();
  }
  
  public void mouseReleased(MouseEvent event) {}
  
  public void mouseEntered(MouseEvent event) {}
  
  public void mouseExited(MouseEvent event) {}
  
  public void keyTyped(KeyEvent event) {}
  
  public void keyPressed(KeyEvent event) {
    int nKeyCode = event.getKeyCode();
    int nIndex = this.nCurrentIndex;
    if (nKeyCode == 40) {
      nIndex++;
    } else if (nKeyCode == 38) {
      nIndex--;
    } else if (nKeyCode == 36) {
      nIndex = 0;
    } else if (nKeyCode == 35) {
      nIndex = this.vectorRows.size() - 1;
    } else if (nKeyCode == 33) {
      nIndex -= this.nVisibleRows;
    } else if (nKeyCode == 34) {
      nIndex += this.nVisibleRows;
    } 
    if (nIndex > this.vectorRows.size() - 1)
      nIndex = this.vectorRows.size() - 1; 
    if (nIndex < 0)
      nIndex = 0; 
    if (nIndex != this.nCurrentIndex) {
      this.nCurrentIndex = nIndex;
      if (this.nScrollPosVert + this.nVisibleRows < this.nCurrentIndex)
        this.nScrollPosVert = this.nCurrentIndex - this.nVisibleRows + 1; 
      if (this.nScrollPosVert > this.nCurrentIndex)
        this.nScrollPosVert = this.nCurrentIndex; 
      repaint();
    } 
  }
  
  public void keyReleased(KeyEvent event) {}
  
  public void focusGained(FocusEvent event) {
    if (this.boolFocus == true)
      return; 
    this.boolFocus = true;
    repaint();
  }
  
  public void focusLost(FocusEvent event) {
    if (!this.boolFocus)
      return; 
    this.boolFocus = false;
    repaint();
  }
  
  public void componentResized(ComponentEvent event) {
    if (this.boolSetColumnWidthAsPreferred == true) {
      this.boolSetColumnWidthAsPreferred = false;
      setColumnWidthAsPreferred();
    } 
    Rectangle rect = getBounds();
    rect.height -= 3 + this.nHeightHeader;
    this.nVisibleRows = rect.height / this.nHeightRow;
    if (this.nVisibleRows < 1)
      this.nVisibleRows = 1; 
  }
  
  public void componentMoved(ComponentEvent event) {}
  
  public void componentShown(ComponentEvent event) {}
  
  public void componentHidden(ComponentEvent event) {}
  
  private void init() throws Exception {
    setFont(this.fontItem);
    computeHeights();
    setBackground(Color.white);
    addMouseListener(this);
    addKeyListener(this);
    addFocusListener(this);
    addComponentListener(this);
  }
  
  private int getPreferredColumnWidth(int nColumnIndex) {
    ColumnData columnData = this.vectorColumns.elementAt(nColumnIndex);
    FontMetrics fontMetrics = getFontMetrics(this.fontHeader);
    String strValue = columnData.strName;
    int nWidthMax = fontMetrics.stringWidth(strValue) + 12 + 2;
    Font font = getFont();
    fontMetrics = getFontMetrics(font);
    int nCount = this.vectorRows.size();
    for (int i = 0; i < nCount; i++) {
      RowData rowData = this.vectorRows.elementAt(i);
      strValue = rowData.getValue(nColumnIndex).toString();
      int nWidth = fontMetrics.stringWidth(strValue) + 12;
      nWidthMax = Math.max(nWidthMax, nWidth);
    } 
    return nWidthMax;
  }
  
  private void computeHeights() {
    FontMetrics fontMetrics = getFontMetrics(this.fontHeader);
    this.nHeightHeader = fontMetrics.getHeight();
    this.nHeightHeader += 2;
    this.nHeightHeader += 4;
    Font font = getFont();
    fontMetrics = getFontMetrics(font);
    this.nHeightRow = fontMetrics.getHeight();
    this.nHeightRow += 4;
  }
  
  private void drawDottedLine(Graphics graphics, int nX1, int nY1, int nX2, int nY2) {
    if (nX1 == nX2 && nY1 == nY2) {
      drawDot(graphics, nX1, nY1);
      return;
    } 
    if (nX1 > nX2) {
      int nX = nX1;
      nX1 = nX2;
      nX2 = nX;
    } 
    if (nY1 > nY2) {
      int nY = nY1;
      nY1 = nY2;
      nY2 = nY;
    } 
    if (nX2 - nX1 > nY2 - nY1) {
      double dDiv = (nY2 - nY1) / (nX2 - nX1);
      for (int i = nX1; i <= nX2; i++) {
        int j = (int)Math.rint(nY1 + (i - nX1) * dDiv);
        drawDot(graphics, i, j);
      } 
    } else {
      double d = ((nX2 - nX1) / (nY2 - nY1));
      for (int i = nY1; i <= nY2; i++) {
        int j = (int)Math.rint(nX1 + (i - nY1) * d);
        drawDot(graphics, j, i);
      } 
    } 
  }
  
  private void drawDot(Graphics graphics, int nX, int nY) {
    if ((nX + nY) % 2 == 0)
      graphics.drawLine(nX, nY, nX, nY); 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\ColumnList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */