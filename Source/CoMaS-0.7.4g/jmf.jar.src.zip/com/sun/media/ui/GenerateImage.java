package com.sun.media.ui;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.DirectColorModel;
import java.awt.image.IndexColorModel;
import java.awt.image.MemoryImageSource;

public class GenerateImage {
  private IndexColorModel icm = null;
  
  private DirectColorModel dcm = null;
  
  private Image image = null;
  
  private byte[] data = null;
  
  private int width;
  
  private int height;
  
  byte[] reds = new byte[256];
  
  byte[] greens = new byte[256];
  
  byte[] blues = new byte[256];
  
  private native int getColors(byte[] paramArrayOfbyte, int paramInt);
  
  private native boolean generateImage(String paramString);
  
  public GenerateImage() {
    int ncolors = getColors(this.reds, 0);
    getColors(this.greens, 1);
    getColors(this.blues, 2);
    this.icm = new IndexColorModel(8, 256, this.reds, this.greens, this.blues, 0);
  }
  
  public Image getImage(String imageName) {
    this.image = null;
    this.data = null;
    if (generateImage(imageName)) {
      createImage();
      return this.image;
    } 
    return null;
  }
  
  protected synchronized void createBuffer(int w, int h) {
    this.width = w;
    this.height = h;
    this.data = new byte[w * h];
  }
  
  protected synchronized void createImage() {
    MemoryImageSource mis = new MemoryImageSource(this.width, this.height, this.icm, this.data, 0, this.width);
    Toolkit tk = Toolkit.getDefaultToolkit();
    this.image = tk.createImage(mis);
    tk.prepareImage(this.image, this.width, this.height, null);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\GenerateImage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */