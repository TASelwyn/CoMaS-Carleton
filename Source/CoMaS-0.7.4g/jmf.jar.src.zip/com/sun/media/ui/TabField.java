package com.sun.media.ui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Panel;
import java.awt.Rectangle;

class TabField {
  Panel panelPage = null;
  
  String strTitle = null;
  
  Image image = null;
  
  Dimension dim = new Dimension();
  
  Rectangle rect = new Rectangle();
  
  int nRowIndex = 0;
  
  Component compOwner;
  
  int MARGIN_TAB_VERT = 5;
  
  int MARGIN_TAB_HORZ = 8;
  
  public static final Color COLOR_BG = Color.lightGray;
  
  public static final Color COLOR_FG = Color.black;
  
  public static final Color COLOR_SHADOW_TOP = Color.white;
  
  public static final Color COLOR_SHADOW_BOTTOM = Color.darkGray;
  
  public static final Color COLOR_TAB_BG = new Color(128, 128, 128);
  
  public static final Color COLOR_TAB_FG = Color.black;
  
  public static final Color COLOR_TAB_SHADOW_TOP = Color.lightGray;
  
  public static final Color COLOR_TAB_SHADOW_BOTTOM = Color.darkGray;
  
  public TabField(Component compOwner, Panel panelPage, String strTitle, Image image) {
    this.compOwner = compOwner;
    this.panelPage = panelPage;
    this.strTitle = strTitle;
    this.image = image;
  }
  
  public void calculateTabDimension(FontMetrics fontMetrics) {
    this.dim.width = fontMetrics.stringWidth(this.strTitle);
    this.dim.height = fontMetrics.getHeight();
    if (this.image != null) {
      this.dim.width += this.image.getWidth(this.compOwner) + this.MARGIN_TAB_HORZ;
      this.dim.height = Math.max(this.image.getHeight(this.compOwner), this.dim.height);
    } 
    this.dim.width += 2 * this.MARGIN_TAB_HORZ;
    this.dim.height += 2 * this.MARGIN_TAB_VERT;
    this.rect.width = this.dim.width;
    this.rect.height = this.dim.height;
  }
  
  public void drawTabTop(Graphics graphics) {
    int[] arrX = new int[5];
    int[] arrY = new int[5];
    graphics.setColor(COLOR_TAB_BG);
    arrX[0] = this.rect.x + 6;
    arrY[0] = this.rect.y + 2;
    arrX[1] = this.rect.x + this.rect.width - 0;
    arrY[1] = this.rect.y + 2;
    arrX[2] = this.rect.x + this.rect.width - 0;
    arrY[2] = this.rect.y + this.rect.height - 2;
    arrX[3] = this.rect.x + 2;
    arrY[3] = this.rect.y + this.rect.height - 2;
    arrX[4] = this.rect.x + 2;
    arrY[4] = this.rect.y + 6;
    graphics.fillPolygon(arrX, arrY, 5);
    graphics.setColor(COLOR_TAB_SHADOW_BOTTOM);
    graphics.drawLine(this.rect.x, this.rect.y + this.rect.height - 2, this.rect.x, this.rect.y + 6);
    graphics.drawLine(this.rect.x, this.rect.y + 6, this.rect.x + 6, this.rect.y);
    graphics.drawLine(this.rect.x + 6, this.rect.y, this.rect.x + this.rect.width - 1, this.rect.y);
    graphics.drawLine(this.rect.x + this.rect.width, this.rect.y + 1, this.rect.x + this.rect.width, this.rect.y + this.rect.height - 2);
    graphics.setColor(COLOR_TAB_SHADOW_TOP);
    graphics.drawLine(this.rect.x + 1, this.rect.y + this.rect.height - 3, this.rect.x + 1, this.rect.y + 6);
    graphics.drawLine(this.rect.x + 1, this.rect.y + 6, this.rect.x + 6, this.rect.y + 1);
    graphics.drawLine(this.rect.x + 6, this.rect.y + 1, this.rect.x + this.rect.width - 1, this.rect.y + 1);
  }
  
  public void drawTabLeft(Graphics graphics) {
    int[] arrX = new int[5];
    int[] arrY = new int[5];
    graphics.setColor(COLOR_TAB_BG);
    arrX[0] = this.rect.x + 2;
    arrY[0] = this.rect.y + 6;
    arrX[1] = this.rect.x + 2;
    arrY[1] = this.rect.y + this.rect.height - 0;
    arrX[2] = this.rect.x + this.rect.width - 2;
    arrY[2] = this.rect.y + this.rect.height - 0;
    arrX[3] = this.rect.x + this.rect.width - 2;
    arrY[3] = this.rect.y + 2;
    arrX[4] = this.rect.x + 6;
    arrY[4] = this.rect.y + 2;
    graphics.fillPolygon(arrX, arrY, 5);
    graphics.setColor(COLOR_TAB_SHADOW_BOTTOM);
    graphics.drawLine(this.rect.x + this.rect.width - 2, this.rect.y, this.rect.x + 6, this.rect.y);
    graphics.drawLine(this.rect.x + 6, this.rect.y, this.rect.x, this.rect.y + 6);
    graphics.drawLine(this.rect.x, this.rect.y + 6, this.rect.x, this.rect.y + this.rect.height - 1);
    graphics.drawLine(this.rect.x + 1, this.rect.y + this.rect.height, this.rect.x + this.rect.width - 2, this.rect.y + this.rect.height);
    graphics.setColor(COLOR_TAB_SHADOW_TOP);
    graphics.drawLine(this.rect.x + this.rect.width - 3, this.rect.y + 1, this.rect.x + 6, this.rect.y + 1);
    graphics.drawLine(this.rect.x + 6, this.rect.y + 1, this.rect.x + 1, this.rect.y + 6);
    graphics.drawLine(this.rect.x + 1, this.rect.y + 6, this.rect.x + 1, this.rect.y + this.rect.height - 1);
  }
  
  public void drawCurrentTabTop(Graphics graphics) {
    int[] arrX = new int[5];
    int[] arrY = new int[5];
    graphics.setColor(COLOR_BG);
    arrX[0] = this.rect.x + 6;
    arrY[0] = this.rect.y + 2;
    arrX[1] = this.rect.x + this.rect.width - 0;
    arrY[1] = this.rect.y + 2;
    arrX[2] = this.rect.x + this.rect.width - 0;
    arrY[2] = this.rect.y + this.rect.height - 0;
    arrX[3] = this.rect.x + 2;
    arrY[3] = this.rect.y + this.rect.height - 0;
    arrX[4] = this.rect.x + 2;
    arrY[4] = this.rect.y + 6;
    graphics.fillPolygon(arrX, arrY, 5);
    graphics.setColor(COLOR_SHADOW_BOTTOM);
    graphics.drawLine(this.rect.x, this.rect.y + this.rect.height - 2, this.rect.x, this.rect.y + 6);
    graphics.drawLine(this.rect.x, this.rect.y + 6, this.rect.x + 6, this.rect.y);
    graphics.drawLine(this.rect.x + 6, this.rect.y, this.rect.x + this.rect.width - 1, this.rect.y);
    graphics.drawLine(this.rect.x + this.rect.width, this.rect.y + 1, this.rect.x + this.rect.width, this.rect.y + this.rect.height - 2);
    graphics.setColor(COLOR_SHADOW_TOP);
    graphics.drawLine(this.rect.x + 1, this.rect.y + this.rect.height - 2, this.rect.x + 1, this.rect.y + 6);
    graphics.drawLine(this.rect.x + 1, this.rect.y + 6, this.rect.x + 6, this.rect.y + 1);
    graphics.drawLine(this.rect.x + 6, this.rect.y + 1, this.rect.x + this.rect.width - 1, this.rect.y + 1);
  }
  
  public void drawCurrentTabLeft(Graphics graphics) {
    int[] arrX = new int[5];
    int[] arrY = new int[5];
    graphics.setColor(COLOR_BG);
    arrX[0] = this.rect.x + 2;
    arrY[0] = this.rect.y + 6;
    arrX[1] = this.rect.x + 2;
    arrY[1] = this.rect.y + this.rect.height - 0;
    arrX[2] = this.rect.x + this.rect.width - 0;
    arrY[2] = this.rect.y + this.rect.height - 0;
    arrX[3] = this.rect.x + this.rect.width - 0;
    arrY[3] = this.rect.y + 2;
    arrX[4] = this.rect.x + 6;
    arrY[4] = this.rect.y + 2;
    graphics.fillPolygon(arrX, arrY, 5);
    graphics.setColor(COLOR_SHADOW_BOTTOM);
    graphics.drawLine(this.rect.x + this.rect.width - 2, this.rect.y, this.rect.x + 6, this.rect.y);
    graphics.drawLine(this.rect.x + 6, this.rect.y, this.rect.x, this.rect.y + 6);
    graphics.drawLine(this.rect.x, this.rect.y + 6, this.rect.x, this.rect.y + this.rect.height - 1);
    graphics.drawLine(this.rect.x + 1, this.rect.y + this.rect.height, this.rect.x + this.rect.width - 2, this.rect.y + this.rect.height);
    graphics.setColor(COLOR_SHADOW_TOP);
    graphics.drawLine(this.rect.x + this.rect.width - 2, this.rect.y + 1, this.rect.x + 6, this.rect.y + 1);
    graphics.drawLine(this.rect.x + 6, this.rect.y + 1, this.rect.x + 1, this.rect.y + 6);
    graphics.drawLine(this.rect.x + 1, this.rect.y + 6, this.rect.x + 1, this.rect.y + this.rect.height - 1);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\TabField.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */