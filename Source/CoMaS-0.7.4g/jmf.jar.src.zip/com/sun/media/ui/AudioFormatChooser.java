package com.sun.media.ui;

import com.sun.media.util.JMFI18N;
import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Choice;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Vector;
import javax.media.Format;
import javax.media.format.AudioFormat;

public class AudioFormatChooser extends Panel implements ItemListener {
  public static final String ACTION_TRACK_ENABLED = "ACTION_AUDIO_TRACK_ENABLED";
  
  public static final String ACTION_TRACK_DISABLED = "ACTION_AUDIO_TRACK_DISABLED";
  
  private AudioFormat formatOld;
  
  private Format[] arrSupportedFormats = null;
  
  private Vector vectorContSuppFormats = new Vector();
  
  private boolean boolDisplayEnableTrack;
  
  private ActionListener listenerEnableTrack;
  
  private boolean boolEnableTrackSaved = true;
  
  private Checkbox checkEnableTrack;
  
  private Label labelEncoding;
  
  private Choice comboEncoding;
  
  private Label labelSampleRate;
  
  private Choice comboSampleRate;
  
  private Label labelHz;
  
  private Label labelBitsPerSample;
  
  private CheckboxGroup groupBitsPerSample;
  
  private Checkbox checkBits8;
  
  private Checkbox checkBits16;
  
  private Label labelChannels;
  
  private CheckboxGroup groupChannels;
  
  private Checkbox checkMono;
  
  private Checkbox checkStereo;
  
  private Label labelEndian;
  
  private CheckboxGroup groupEndian;
  
  private Checkbox checkEndianBig;
  
  private Checkbox checkEndianLittle;
  
  private Checkbox checkSigned;
  
  private boolean boolEnable8 = false;
  
  private boolean boolEnable16 = false;
  
  private boolean boolEnableMono = false;
  
  private boolean boolEnableStereo = false;
  
  private boolean boolEnableEndianBig = false;
  
  private boolean boolEnableEndianLittle = false;
  
  private boolean boolEnableSigned = false;
  
  public AudioFormatChooser(Format[] arrFormats, AudioFormat formatDefault) {
    this(arrFormats, formatDefault, false, null);
  }
  
  public AudioFormatChooser(Format[] arrFormats, AudioFormat formatDefault, boolean boolDisplayEnableTrack, ActionListener listenerEnableTrack) {
    this.arrSupportedFormats = arrFormats;
    this.boolDisplayEnableTrack = boolDisplayEnableTrack;
    this.listenerEnableTrack = listenerEnableTrack;
    int nCount = this.arrSupportedFormats.length;
    for (int i = 0; i < nCount; i++) {
      if (this.arrSupportedFormats[i] instanceof AudioFormat)
        this.vectorContSuppFormats.addElement(this.arrSupportedFormats[i]); 
    } 
    if (isFormatSupported(formatDefault)) {
      this.formatOld = formatDefault;
    } else {
      this.formatOld = null;
    } 
    try {
      init();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public void setEnabled(boolean boolEnable) {
    super.setEnabled(boolEnable);
    if (this.checkEnableTrack != null)
      this.checkEnableTrack.setEnabled(boolEnable); 
    enableControls(boolEnable);
  }
  
  public Format getFormat() {
    byte b1, b2, b3;
    boolean bool;
    Format formatResult = null;
    String strEncoding = this.comboEncoding.getSelectedItem();
    String strSampleRate = this.comboSampleRate.getSelectedItem();
    double dSampleRate = Double.valueOf(strSampleRate).doubleValue();
    if (this.checkBits8.getState() == true && this.checkBits8.isEnabled() == true) {
      b1 = 8;
    } else if (this.checkBits16.getState() == true && this.checkBits16.isEnabled() == true) {
      b1 = 16;
    } else {
      b1 = -1;
    } 
    if (this.checkMono.getState() == true && this.checkMono.isEnabled() == true) {
      b2 = 1;
    } else if (this.checkStereo.getState() == true && this.checkStereo.isEnabled() == true) {
      b2 = 2;
    } else {
      b2 = -1;
    } 
    if (this.checkEndianBig.getState() == true && this.checkEndianBig.isEnabled() == true) {
      b3 = 1;
    } else if (this.checkEndianLittle.getState() == true && this.checkEndianLittle.isEnabled() == true) {
      b3 = 0;
    } else {
      b3 = -1;
    } 
    if (this.checkSigned.getState() == true) {
      bool = true;
    } else {
      bool = false;
    } 
    AudioFormat formatAudioNew = new AudioFormat(strEncoding, dSampleRate, b1, b2, b3, bool);
    int nSize = this.vectorContSuppFormats.size();
    for (int i = 0; i < nSize && formatResult == null; i++) {
      Object objectFormat = this.vectorContSuppFormats.elementAt(i);
      if (objectFormat instanceof AudioFormat) {
        AudioFormat formatAudio = (AudioFormat)objectFormat;
        if (isFormatGoodForEncoding(formatAudio))
          if (isFormatGoodForSampleRate(formatAudio))
            if (isFormatGoodForBitSize(formatAudio))
              if (isFormatGoodForChannels(formatAudio))
                if (isFormatGoodForEndian(formatAudio))
                  if (isFormatGoodForSigned(formatAudio))
                    if (formatAudio.matches((Format)formatAudioNew))
                      formatResult = formatAudio.intersects((Format)formatAudioNew);       
      } 
    } 
    return formatResult;
  }
  
  public void setCurrentFormat(AudioFormat formatDefault) {
    if (isFormatSupported(formatDefault))
      this.formatOld = formatDefault; 
    updateFields(this.formatOld);
  }
  
  public void setSupportedFormats(Format[] arrFormats, AudioFormat formatDefault) {
    this.arrSupportedFormats = arrFormats;
    int nCount = this.arrSupportedFormats.length;
    this.vectorContSuppFormats.removeAllElements();
    for (int i = 0; i < nCount; i++) {
      if (this.arrSupportedFormats[i] instanceof AudioFormat)
        this.vectorContSuppFormats.addElement(this.arrSupportedFormats[i]); 
    } 
    if (isFormatSupported(formatDefault)) {
      this.formatOld = formatDefault;
    } else {
      this.formatOld = null;
    } 
    setSupportedFormats(this.vectorContSuppFormats);
  }
  
  public void setSupportedFormats(Vector vectorContSuppFormats) {
    this.vectorContSuppFormats = vectorContSuppFormats;
    if (vectorContSuppFormats.isEmpty()) {
      this.checkEnableTrack.setState(false);
      this.checkEnableTrack.setEnabled(false);
      onEnableTrack(true);
      return;
    } 
    this.checkEnableTrack.setEnabled(true);
    this.checkEnableTrack.setState(this.boolEnableTrackSaved);
    onEnableTrack(true);
    if (!isFormatSupported(this.formatOld))
      this.formatOld = null; 
    updateFields(this.formatOld);
  }
  
  public void setTrackEnabled(boolean boolEnable) {
    this.boolEnableTrackSaved = boolEnable;
    if (this.checkEnableTrack == null)
      return; 
    this.checkEnableTrack.setState(boolEnable);
    onEnableTrack(true);
  }
  
  public boolean isTrackEnabled() {
    boolean boolEnabled = this.checkEnableTrack.getState();
    return boolEnabled;
  }
  
  private void init() throws Exception {
    setLayout(new BorderLayout(6, 6));
    Panel panel = this;
    this.checkEnableTrack = new Checkbox(JMFI18N.getResource("formatchooser.enabletrack"), true);
    this.checkEnableTrack.addItemListener(this);
    if (this.boolDisplayEnableTrack == true) {
      Panel panelGroup = new Panel(new BorderLayout());
      panel.add(panelGroup, "North");
      panelGroup.add(this.checkEnableTrack, "West");
    } 
    Panel panel1 = new Panel(new BorderLayout(6, 6));
    panel.add(panel1, "Center");
    panel = panel1;
    panel1 = new Panel(new BorderLayout());
    panel.add(panel1, "North");
    Panel panelLabel = new Panel(new GridLayout(0, 1, 6, 6));
    panel1.add(panelLabel, "West");
    Panel panelData = new Panel(new GridLayout(0, 1, 6, 6));
    panel1.add(panelData, "Center");
    this.labelEncoding = new Label(JMFI18N.getResource("formatchooser.encoding"), 0);
    panelLabel.add(this.labelEncoding);
    this.comboEncoding = new Choice();
    this.comboEncoding.addItemListener(this);
    panelData.add(this.comboEncoding);
    this.labelSampleRate = new Label(JMFI18N.getResource("formatchooser.samplerate"), 0);
    panelLabel.add(this.labelSampleRate);
    Panel panelEntry = new Panel(new BorderLayout(6, 6));
    panelData.add(panelEntry);
    this.comboSampleRate = new Choice();
    this.comboSampleRate.addItemListener(this);
    panelEntry.add(this.comboSampleRate, "Center");
    this.labelHz = new Label(JMFI18N.getResource("formatchooser.hz"));
    panelEntry.add(this.labelHz, "East");
    this.labelBitsPerSample = new Label(JMFI18N.getResource("formatchooser.bitspersample"), 0);
    panelLabel.add(this.labelBitsPerSample);
    panelEntry = new Panel(new GridLayout(1, 0, 6, 6));
    panelData.add(panelEntry);
    this.groupBitsPerSample = new CheckboxGroup();
    this.checkBits8 = new Checkbox(JMFI18N.getResource("formatchooser.8bit"), this.groupBitsPerSample, false);
    this.checkBits8.addItemListener(this);
    panelEntry.add(this.checkBits8);
    this.checkBits16 = new Checkbox(JMFI18N.getResource("formatchooser.16bit"), this.groupBitsPerSample, false);
    this.checkBits16.addItemListener(this);
    panelEntry.add(this.checkBits16);
    this.labelChannels = new Label(JMFI18N.getResource("formatchooser.channels"), 0);
    panelLabel.add(this.labelChannels);
    panelEntry = new Panel(new GridLayout(1, 0, 6, 6));
    panelData.add(panelEntry);
    this.groupChannels = new CheckboxGroup();
    this.checkMono = new Checkbox(JMFI18N.getResource("formatchooser.mono"), this.groupChannels, false);
    this.checkMono.addItemListener(this);
    panelEntry.add(this.checkMono);
    this.checkStereo = new Checkbox(JMFI18N.getResource("formatchooser.stereo"), this.groupChannels, false);
    this.checkStereo.addItemListener(this);
    panelEntry.add(this.checkStereo);
    this.labelEndian = new Label(JMFI18N.getResource("formatchooser.endian"), 0);
    panelLabel.add(this.labelEndian);
    panelEntry = new Panel(new GridLayout(1, 0, 6, 6));
    panelData.add(panelEntry);
    this.groupEndian = new CheckboxGroup();
    this.checkEndianBig = new Checkbox(JMFI18N.getResource("formatchooser.endian.big"), this.groupEndian, false);
    this.checkEndianBig.addItemListener(this);
    panelEntry.add(this.checkEndianBig);
    this.checkEndianLittle = new Checkbox(JMFI18N.getResource("formatchooser.endian.little"), this.groupEndian, false);
    this.checkEndianLittle.addItemListener(this);
    panelEntry.add(this.checkEndianLittle);
    panel1 = new Panel(new BorderLayout(6, 6));
    panel.add(panel1, "Center");
    panel = panel1;
    panel1 = new Panel(new BorderLayout());
    panel.add(panel1, "North");
    this.checkSigned = new Checkbox(JMFI18N.getResource("formatchooser.signed"), true);
    this.checkSigned.addItemListener(this);
    panel1.add(this.checkSigned, "West");
    updateFields(this.formatOld);
  }
  
  private void updateFields(AudioFormat formatDefault) {
    String strEncodingPref = null;
    Vector vectorEncoding = new Vector();
    boolean boolEnable = this.comboEncoding.isEnabled();
    this.comboEncoding.setEnabled(false);
    this.comboEncoding.removeAll();
    int nSize = this.vectorContSuppFormats.size();
    for (int i = 0; i < nSize; i++) {
      Object objectFormat = this.vectorContSuppFormats.elementAt(i);
      if (objectFormat instanceof AudioFormat) {
        AudioFormat formatAudio = (AudioFormat)objectFormat;
        String strEncoding = formatAudio.getEncoding().toUpperCase();
        if (!vectorEncoding.contains(strEncoding)) {
          this.comboEncoding.addItem(strEncoding);
          vectorEncoding.addElement(strEncoding);
          if (strEncodingPref == null)
            strEncodingPref = strEncoding; 
        } 
      } 
    } 
    if (formatDefault != null) {
      String str = formatDefault.getEncoding();
      this.comboEncoding.select(str);
    } else if (strEncodingPref != null) {
      this.comboEncoding.select(strEncodingPref);
    } else if (this.comboEncoding.getItemCount() > 0) {
      this.comboEncoding.select(0);
    } 
    updateFieldsFromEncoding(formatDefault);
    this.comboEncoding.setEnabled(boolEnable);
  }
  
  private void updateFieldsFromEncoding(AudioFormat formatDefault) {
    String strSampleRatePref = null;
    Vector vectorRates = new Vector();
    boolean boolEnable = this.comboSampleRate.isEnabled();
    this.comboSampleRate.setEnabled(false);
    this.comboSampleRate.removeAll();
    int nSize = this.vectorContSuppFormats.size();
    for (int i = 0; i < nSize; i++) {
      Object objectFormat = this.vectorContSuppFormats.elementAt(i);
      if (objectFormat instanceof AudioFormat) {
        AudioFormat formatAudio = (AudioFormat)objectFormat;
        if (isFormatGoodForEncoding(formatAudio)) {
          double dSampleRate = formatAudio.getSampleRate();
          String strSampleRate = Double.toString(dSampleRate);
          if (!vectorRates.contains(strSampleRate)) {
            this.comboSampleRate.addItem(strSampleRate);
            vectorRates.addElement(strSampleRate);
            if (strSampleRatePref == null)
              strSampleRatePref = strSampleRate; 
          } 
        } 
      } 
    } 
    if (formatDefault != null && isFormatGoodForEncoding(formatDefault)) {
      this.comboSampleRate.select(Double.toString(formatDefault.getSampleRate()));
    } else if (strSampleRatePref != null) {
      this.comboEncoding.select(strSampleRatePref);
    } else if (this.comboSampleRate.getItemCount() > 0) {
      this.comboSampleRate.select(0);
    } 
    updateFieldsFromRate(formatDefault);
    this.comboSampleRate.setEnabled(boolEnable);
  }
  
  private void updateFieldsFromRate(AudioFormat formatDefault) {
    int nBitsPref = -1;
    this.boolEnable8 = false;
    this.boolEnable16 = false;
    int nSize = this.vectorContSuppFormats.size();
    for (int i = 0; i < nSize; i++) {
      Object objectFormat = this.vectorContSuppFormats.elementAt(i);
      if (objectFormat instanceof AudioFormat) {
        AudioFormat formatAudio = (AudioFormat)objectFormat;
        if (isFormatGoodForEncoding(formatAudio))
          if (isFormatGoodForSampleRate(formatAudio)) {
            int nBits = formatAudio.getSampleSizeInBits();
            if (nBitsPref == -1)
              nBitsPref = nBits; 
            if (nBits == -1) {
              this.boolEnable8 = true;
              this.boolEnable16 = true;
            } else if (nBits == 8) {
              this.boolEnable8 = true;
            } else if (nBits == 16) {
              this.boolEnable16 = true;
            } 
          }  
      } 
    } 
    this.checkBits8.setEnabled(this.boolEnable8);
    this.checkBits16.setEnabled(this.boolEnable16);
    if (formatDefault != null && isFormatGoodForEncoding(formatDefault) && isFormatGoodForSampleRate(formatDefault)) {
      int j = formatDefault.getSampleSizeInBits();
      if (j == 8) {
        this.checkBits8.setState(true);
      } else if (j == 16) {
        this.checkBits16.setState(true);
      } 
    } else if (nBitsPref != -1) {
      if (nBitsPref == 8) {
        this.checkBits8.setState(true);
      } else if (nBitsPref == 16) {
        this.checkBits16.setState(true);
      } 
    } else if (this.boolEnable8 == true) {
      this.checkBits8.setState(true);
    } else {
      this.checkBits16.setState(true);
    } 
    updateFieldsFromBits(formatDefault);
  }
  
  private void updateFieldsFromBits(AudioFormat formatDefault) {
    int nChannelsPref = -1;
    this.boolEnableMono = false;
    this.boolEnableStereo = false;
    int nSize = this.vectorContSuppFormats.size();
    for (int i = 0; i < nSize; i++) {
      Object objectFormat = this.vectorContSuppFormats.elementAt(i);
      if (objectFormat instanceof AudioFormat) {
        AudioFormat formatAudio = (AudioFormat)objectFormat;
        if (isFormatGoodForEncoding(formatAudio))
          if (isFormatGoodForSampleRate(formatAudio))
            if (isFormatGoodForBitSize(formatAudio)) {
              int nChannels = formatAudio.getChannels();
              if (nChannelsPref == -1)
                nChannelsPref = nChannels; 
              if (nChannels == -1) {
                this.boolEnableMono = true;
                this.boolEnableStereo = true;
              } else if (nChannels == 1) {
                this.boolEnableMono = true;
              } else {
                this.boolEnableStereo = true;
              } 
            }   
      } 
    } 
    this.checkMono.setEnabled(this.boolEnableMono);
    this.checkStereo.setEnabled(this.boolEnableStereo);
    if (formatDefault != null && isFormatGoodForEncoding(formatDefault) && isFormatGoodForSampleRate(formatDefault) && isFormatGoodForBitSize(formatDefault)) {
      int j = formatDefault.getChannels();
      if (j == 1) {
        this.checkMono.setState(true);
      } else {
        this.checkStereo.setState(true);
      } 
    } else if (nChannelsPref != -1) {
      if (nChannelsPref == 1) {
        this.checkMono.setState(true);
      } else {
        this.checkStereo.setState(true);
      } 
    } else if (this.boolEnableMono == true) {
      this.checkMono.setState(true);
    } else {
      this.checkStereo.setState(true);
    } 
    updateFieldsFromChannels(formatDefault);
  }
  
  private void updateFieldsFromChannels(AudioFormat formatDefault) {
    int nEndianPref = -1;
    this.boolEnableEndianBig = false;
    this.boolEnableEndianLittle = false;
    int nSize = this.vectorContSuppFormats.size();
    for (int i = 0; i < nSize; i++) {
      Object objectFormat = this.vectorContSuppFormats.elementAt(i);
      if (objectFormat instanceof AudioFormat) {
        AudioFormat formatAudio = (AudioFormat)objectFormat;
        if (isFormatGoodForEncoding(formatAudio))
          if (isFormatGoodForSampleRate(formatAudio))
            if (isFormatGoodForBitSize(formatAudio))
              if (isFormatGoodForChannels(formatAudio)) {
                int nEndian = formatAudio.getEndian();
                if (nEndianPref == -1)
                  nEndianPref = nEndian; 
                if (nEndian == -1) {
                  this.boolEnableEndianBig = true;
                  this.boolEnableEndianLittle = true;
                } else if (nEndian == 1) {
                  this.boolEnableEndianBig = true;
                } else {
                  this.boolEnableEndianLittle = true;
                } 
              }    
      } 
    } 
    this.checkEndianBig.setEnabled(this.boolEnableEndianBig);
    this.checkEndianLittle.setEnabled(this.boolEnableEndianLittle);
    if (formatDefault != null && isFormatGoodForEncoding(formatDefault) && isFormatGoodForSampleRate(formatDefault) && isFormatGoodForBitSize(formatDefault) && isFormatGoodForChannels(formatDefault)) {
      int j = formatDefault.getEndian();
      if (j == 1) {
        this.checkEndianBig.setState(true);
      } else {
        this.checkEndianLittle.setState(true);
      } 
    } else if (nEndianPref != -1) {
      if (nEndianPref == 1) {
        this.checkEndianBig.setState(true);
      } else {
        this.checkEndianLittle.setState(true);
      } 
    } else if (this.boolEnableEndianBig == true) {
      this.checkEndianBig.setState(true);
    } else {
      this.checkEndianLittle.setState(true);
    } 
    if (this.checkBits16.getState() != true) {
      this.boolEnableEndianBig = false;
      this.boolEnableEndianLittle = false;
      this.checkEndianBig.setEnabled(this.boolEnableEndianBig);
      this.checkEndianLittle.setEnabled(this.boolEnableEndianLittle);
    } 
    updateFieldsFromEndian(formatDefault);
  }
  
  private void updateFieldsFromEndian(AudioFormat formatDefault) {
    int nSignedPref = -1;
    boolean boolSigned = false;
    boolean boolUnsigned = false;
    int nSize = this.vectorContSuppFormats.size();
    for (int i = 0; i < nSize; i++) {
      Object objectFormat = this.vectorContSuppFormats.elementAt(i);
      if (objectFormat instanceof AudioFormat) {
        AudioFormat formatAudio = (AudioFormat)objectFormat;
        if (isFormatGoodForEncoding(formatAudio))
          if (isFormatGoodForSampleRate(formatAudio))
            if (isFormatGoodForBitSize(formatAudio))
              if (isFormatGoodForChannels(formatAudio))
                if (isFormatGoodForEndian(formatAudio)) {
                  int nSigned = formatAudio.getSigned();
                  if (nSignedPref == -1)
                    nSignedPref = nSigned; 
                  if (nSigned == -1) {
                    boolSigned = true;
                    boolUnsigned = true;
                  } else if (nSigned == 1) {
                    boolSigned = true;
                  } else {
                    boolUnsigned = true;
                  } 
                }     
      } 
    } 
    this.boolEnableSigned = (boolSigned && boolUnsigned);
    this.checkSigned.setEnabled(this.boolEnableSigned);
    if (formatDefault != null && isFormatGoodForEncoding(formatDefault) && isFormatGoodForSampleRate(formatDefault) && isFormatGoodForBitSize(formatDefault) && isFormatGoodForChannels(formatDefault) && isFormatGoodForEndian(formatDefault)) {
      int j = formatDefault.getSigned();
      if (j == 1) {
        this.checkSigned.setState(true);
      } else {
        this.checkSigned.setState(false);
      } 
    } else if (nSignedPref != -1) {
      if (nSignedPref == 1) {
        this.checkSigned.setState(true);
      } else {
        this.checkSigned.setState(false);
      } 
    } else if (boolSigned == true) {
      this.checkSigned.setState(true);
    } else {
      this.checkSigned.setState(false);
    } 
    updateFieldsFromSigned(formatDefault);
  }
  
  private void updateFieldsFromSigned(AudioFormat formatDefault) {}
  
  private boolean isFormatGoodForEncoding(AudioFormat format) {
    boolean boolResult = false;
    String strEncoding = this.comboEncoding.getSelectedItem();
    if (strEncoding != null)
      boolResult = format.getEncoding().equalsIgnoreCase(strEncoding); 
    return boolResult;
  }
  
  private boolean isFormatGoodForSampleRate(AudioFormat format) {
    boolean boolResult = false;
    String strSampleRate = this.comboSampleRate.getSelectedItem();
    if (strSampleRate != null) {
      double dSampleRate = Double.valueOf(strSampleRate).doubleValue();
      if (format.getSampleRate() == -1.0D) {
        boolResult = true;
      } else if (format.getSampleRate() == dSampleRate) {
        boolResult = true;
      } 
    } 
    return boolResult;
  }
  
  private boolean isFormatGoodForBitSize(AudioFormat format) {
    byte b;
    boolean boolResult = false;
    if (this.checkBits8.getState() == true) {
      b = 8;
    } else if (this.checkBits16.getState() == true) {
      b = 16;
    } else {
      b = -1;
    } 
    if (format.getSampleSizeInBits() == -1) {
      boolResult = true;
    } else if (b == -1) {
      boolResult = true;
    } else if (format.getSampleSizeInBits() == b) {
      boolResult = true;
    } else if (format.getSampleSizeInBits() < 8) {
      boolResult = true;
    } 
    return boolResult;
  }
  
  private boolean isFormatGoodForChannels(AudioFormat format) {
    byte b;
    boolean boolResult = false;
    if (this.checkMono.getState() == true) {
      b = 1;
    } else if (this.checkStereo.getState() == true) {
      b = 2;
    } else {
      b = -1;
    } 
    if (format.getChannels() == -1) {
      boolResult = true;
    } else if (b == -1) {
      boolResult = true;
    } else if (format.getChannels() == b) {
      boolResult = true;
    } 
    return boolResult;
  }
  
  private boolean isFormatGoodForEndian(AudioFormat format) {
    byte b;
    boolean boolResult = false;
    if (this.checkEndianBig.getState() == true) {
      b = 1;
    } else if (this.checkStereo.getState() == true) {
      b = 0;
    } else {
      b = -1;
    } 
    if (format.getEndian() == -1) {
      boolResult = true;
    } else if (b == -1) {
      boolResult = true;
    } else if (format.getEndian() == b) {
      boolResult = true;
    } 
    return boolResult;
  }
  
  private boolean isFormatGoodForSigned(AudioFormat format) {
    boolean bool;
    boolean boolResult = false;
    if (this.checkSigned.getState() == true) {
      bool = true;
    } else {
      bool = false;
    } 
    if (format.getSigned() == -1) {
      boolResult = true;
    } else if (bool == -1) {
      boolResult = true;
    } else if (format.getSigned() == bool) {
      boolResult = true;
    } 
    return boolResult;
  }
  
  private boolean isFormatSupported(AudioFormat format) {
    boolean boolSupported = false;
    if (format == null)
      return boolSupported; 
    int nCount = this.vectorContSuppFormats.size();
    for (int i = 0; i < nCount && !boolSupported; i++) {
      AudioFormat formatAudio = this.vectorContSuppFormats.elementAt(i);
      if (formatAudio.matches((Format)format))
        boolSupported = true; 
    } 
    return boolSupported;
  }
  
  public void itemStateChanged(ItemEvent event) {
    Object objectSource = event.getSource();
    if (objectSource == this.checkEnableTrack) {
      this.boolEnableTrackSaved = this.checkEnableTrack.getState();
      onEnableTrack(true);
    } else if (objectSource == this.comboEncoding) {
      updateFieldsFromEncoding(this.formatOld);
    } else if (objectSource == this.comboSampleRate) {
      updateFieldsFromRate(this.formatOld);
    } else if (objectSource == this.checkBits8 || objectSource == this.checkBits16) {
      updateFieldsFromBits(this.formatOld);
    } else if (objectSource == this.checkMono || objectSource == this.checkStereo) {
      updateFieldsFromChannels(this.formatOld);
    } else if (objectSource == this.checkEndianBig || objectSource == this.checkEndianLittle) {
      updateFieldsFromEndian(this.formatOld);
    } else if (objectSource == this.checkSigned) {
      updateFieldsFromSigned(this.formatOld);
    } 
  }
  
  private void onEnableTrack(boolean notifyListener) {
    boolean boolEnable = this.checkEnableTrack.getState();
    enableControls((boolEnable && isEnabled()));
    if (notifyListener == true && this.listenerEnableTrack != null) {
      ActionEvent actionEvent;
      if (boolEnable == true) {
        actionEvent = new ActionEvent(this, 1001, "ACTION_AUDIO_TRACK_ENABLED");
      } else {
        actionEvent = new ActionEvent(this, 1001, "ACTION_AUDIO_TRACK_DISABLED");
      } 
      this.listenerEnableTrack.actionPerformed(actionEvent);
    } 
  }
  
  private void enableControls(boolean boolEnable) {
    this.labelEncoding.setEnabled(boolEnable);
    this.comboEncoding.setEnabled(boolEnable);
    this.labelSampleRate.setEnabled(boolEnable);
    this.comboSampleRate.setEnabled(boolEnable);
    this.labelHz.setEnabled(boolEnable);
    this.labelBitsPerSample.setEnabled(boolEnable);
    this.checkBits8.setEnabled((boolEnable && this.boolEnable8));
    this.checkBits16.setEnabled((boolEnable && this.boolEnable16));
    this.labelChannels.setEnabled(boolEnable);
    this.checkMono.setEnabled((boolEnable && this.boolEnableMono));
    this.checkStereo.setEnabled((boolEnable && this.boolEnableStereo));
    this.labelEndian.setEnabled(boolEnable);
    this.checkEndianBig.setEnabled((boolEnable && this.boolEnableEndianBig));
    this.checkEndianLittle.setEnabled((boolEnable && this.boolEnableEndianLittle));
    this.checkSigned.setEnabled((boolEnable && this.boolEnableSigned));
  }
}
