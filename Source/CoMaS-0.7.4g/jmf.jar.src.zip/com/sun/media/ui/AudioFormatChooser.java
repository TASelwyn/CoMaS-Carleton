/*     */ package com.sun.media.ui;
/*     */ 
/*     */ import com.sun.media.util.JMFI18N;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Checkbox;
/*     */ import java.awt.CheckboxGroup;
/*     */ import java.awt.Choice;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.Label;
/*     */ import java.awt.Panel;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.util.Vector;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ public class AudioFormatChooser
/*     */   extends Panel
/*     */   implements ItemListener {
/*     */   public static final String ACTION_TRACK_ENABLED = "ACTION_AUDIO_TRACK_ENABLED";
/*     */   public static final String ACTION_TRACK_DISABLED = "ACTION_AUDIO_TRACK_DISABLED";
/*     */   private AudioFormat formatOld;
/*  25 */   private Format[] arrSupportedFormats = null;
/*  26 */   private Vector vectorContSuppFormats = new Vector();
/*     */   
/*     */   private boolean boolDisplayEnableTrack;
/*     */   
/*     */   private ActionListener listenerEnableTrack;
/*     */   
/*     */   private boolean boolEnableTrackSaved = true;
/*     */   
/*     */   private Checkbox checkEnableTrack;
/*     */   private Label labelEncoding;
/*     */   private Choice comboEncoding;
/*     */   private Label labelSampleRate;
/*     */   private Choice comboSampleRate;
/*     */   private Label labelHz;
/*     */   private Label labelBitsPerSample;
/*     */   private CheckboxGroup groupBitsPerSample;
/*     */   private Checkbox checkBits8;
/*     */   private Checkbox checkBits16;
/*     */   private Label labelChannels;
/*     */   private CheckboxGroup groupChannels;
/*     */   private Checkbox checkMono;
/*     */   private Checkbox checkStereo;
/*     */   private Label labelEndian;
/*     */   private CheckboxGroup groupEndian;
/*     */   private Checkbox checkEndianBig;
/*     */   private Checkbox checkEndianLittle;
/*     */   private Checkbox checkSigned;
/*     */   private boolean boolEnable8 = false;
/*     */   private boolean boolEnable16 = false;
/*     */   private boolean boolEnableMono = false;
/*     */   private boolean boolEnableStereo = false;
/*     */   private boolean boolEnableEndianBig = false;
/*     */   private boolean boolEnableEndianLittle = false;
/*     */   private boolean boolEnableSigned = false;
/*     */   
/*     */   public AudioFormatChooser(Format[] arrFormats, AudioFormat formatDefault) {
/*  62 */     this(arrFormats, formatDefault, false, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AudioFormatChooser(Format[] arrFormats, AudioFormat formatDefault, boolean boolDisplayEnableTrack, ActionListener listenerEnableTrack) {
/*  71 */     this.arrSupportedFormats = arrFormats;
/*  72 */     this.boolDisplayEnableTrack = boolDisplayEnableTrack;
/*  73 */     this.listenerEnableTrack = listenerEnableTrack;
/*     */     
/*  75 */     int nCount = this.arrSupportedFormats.length;
/*  76 */     for (int i = 0; i < nCount; i++) {
/*  77 */       if (this.arrSupportedFormats[i] instanceof AudioFormat) {
/*  78 */         this.vectorContSuppFormats.addElement(this.arrSupportedFormats[i]);
/*     */       }
/*     */     } 
/*  81 */     if (isFormatSupported(formatDefault)) {
/*  82 */       this.formatOld = formatDefault;
/*     */     } else {
/*  84 */       this.formatOld = null;
/*     */     } 
/*     */     try {
/*  87 */       init();
/*     */     } catch (Exception e) {
/*     */       
/*  90 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean boolEnable) {
/*  95 */     super.setEnabled(boolEnable);
/*     */     
/*  97 */     if (this.checkEnableTrack != null)
/*  98 */       this.checkEnableTrack.setEnabled(boolEnable); 
/*  99 */     enableControls(boolEnable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format getFormat() {
/*     */     byte b1, b2, b3;
/*     */     boolean bool;
/* 112 */     Format formatResult = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     String strEncoding = this.comboEncoding.getSelectedItem();
/* 120 */     String strSampleRate = this.comboSampleRate.getSelectedItem();
/* 121 */     double dSampleRate = Double.valueOf(strSampleRate).doubleValue();
/*     */     
/* 123 */     if (this.checkBits8.getState() == true && this.checkBits8.isEnabled() == true) {
/* 124 */       b1 = 8;
/* 125 */     } else if (this.checkBits16.getState() == true && this.checkBits16.isEnabled() == true) {
/* 126 */       b1 = 16;
/*     */     } else {
/* 128 */       b1 = -1;
/*     */     } 
/* 130 */     if (this.checkMono.getState() == true && this.checkMono.isEnabled() == true) {
/* 131 */       b2 = 1;
/* 132 */     } else if (this.checkStereo.getState() == true && this.checkStereo.isEnabled() == true) {
/* 133 */       b2 = 2;
/*     */     } else {
/* 135 */       b2 = -1;
/*     */     } 
/* 137 */     if (this.checkEndianBig.getState() == true && this.checkEndianBig.isEnabled() == true) {
/* 138 */       b3 = 1;
/* 139 */     } else if (this.checkEndianLittle.getState() == true && this.checkEndianLittle.isEnabled() == true) {
/* 140 */       b3 = 0;
/*     */     } else {
/* 142 */       b3 = -1;
/*     */     } 
/* 144 */     if (this.checkSigned.getState() == true) {
/* 145 */       bool = true;
/*     */     } else {
/* 147 */       bool = false;
/*     */     } 
/* 149 */     AudioFormat formatAudioNew = new AudioFormat(strEncoding, dSampleRate, b1, b2, b3, bool);
/*     */     
/* 151 */     int nSize = this.vectorContSuppFormats.size();
/* 152 */     for (int i = 0; i < nSize && formatResult == null; i++) {
/* 153 */       Object objectFormat = this.vectorContSuppFormats.elementAt(i);
/* 154 */       if (objectFormat instanceof AudioFormat) {
/*     */         
/* 156 */         AudioFormat formatAudio = (AudioFormat)objectFormat;
/*     */         
/* 158 */         if (isFormatGoodForEncoding(formatAudio))
/*     */         {
/* 160 */           if (isFormatGoodForSampleRate(formatAudio))
/*     */           {
/* 162 */             if (isFormatGoodForBitSize(formatAudio))
/*     */             {
/* 164 */               if (isFormatGoodForChannels(formatAudio))
/*     */               {
/* 166 */                 if (isFormatGoodForEndian(formatAudio))
/*     */                 {
/* 168 */                   if (isFormatGoodForSigned(formatAudio))
/*     */                   {
/*     */                     
/* 171 */                     if (formatAudio.matches((Format)formatAudioNew))
/* 172 */                       formatResult = formatAudio.intersects((Format)formatAudioNew);  }  }  }  }  }  } 
/*     */       } 
/*     */     } 
/* 175 */     return formatResult;
/*     */   }
/*     */   
/*     */   public void setCurrentFormat(AudioFormat formatDefault) {
/* 179 */     if (isFormatSupported(formatDefault))
/* 180 */       this.formatOld = formatDefault; 
/* 181 */     updateFields(this.formatOld);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSupportedFormats(Format[] arrFormats, AudioFormat formatDefault) {
/* 188 */     this.arrSupportedFormats = arrFormats;
/*     */     
/* 190 */     int nCount = this.arrSupportedFormats.length;
/* 191 */     this.vectorContSuppFormats.removeAllElements();
/* 192 */     for (int i = 0; i < nCount; i++) {
/* 193 */       if (this.arrSupportedFormats[i] instanceof AudioFormat)
/* 194 */         this.vectorContSuppFormats.addElement(this.arrSupportedFormats[i]); 
/*     */     } 
/* 196 */     if (isFormatSupported(formatDefault)) {
/* 197 */       this.formatOld = formatDefault;
/*     */     } else {
/* 199 */       this.formatOld = null;
/* 200 */     }  setSupportedFormats(this.vectorContSuppFormats);
/*     */   }
/*     */   
/*     */   public void setSupportedFormats(Vector vectorContSuppFormats) {
/* 204 */     this.vectorContSuppFormats = vectorContSuppFormats;
/*     */     
/* 206 */     if (vectorContSuppFormats.isEmpty()) {
/* 207 */       this.checkEnableTrack.setState(false);
/* 208 */       this.checkEnableTrack.setEnabled(false);
/* 209 */       onEnableTrack(true);
/*     */       
/*     */       return;
/*     */     } 
/* 213 */     this.checkEnableTrack.setEnabled(true);
/* 214 */     this.checkEnableTrack.setState(this.boolEnableTrackSaved);
/* 215 */     onEnableTrack(true);
/*     */ 
/*     */     
/* 218 */     if (!isFormatSupported(this.formatOld)) {
/* 219 */       this.formatOld = null;
/*     */     }
/* 221 */     updateFields(this.formatOld);
/*     */   }
/*     */   
/*     */   public void setTrackEnabled(boolean boolEnable) {
/* 225 */     this.boolEnableTrackSaved = boolEnable;
/* 226 */     if (this.checkEnableTrack == null)
/*     */       return; 
/* 228 */     this.checkEnableTrack.setState(boolEnable);
/* 229 */     onEnableTrack(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTrackEnabled() {
/* 235 */     boolean boolEnabled = this.checkEnableTrack.getState();
/* 236 */     return boolEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() throws Exception {
/* 248 */     setLayout(new BorderLayout(6, 6));
/* 249 */     Panel panel = this;
/*     */     
/* 251 */     this.checkEnableTrack = new Checkbox(JMFI18N.getResource("formatchooser.enabletrack"), true);
/* 252 */     this.checkEnableTrack.addItemListener(this);
/* 253 */     if (this.boolDisplayEnableTrack == true) {
/* 254 */       Panel panelGroup = new Panel(new BorderLayout());
/* 255 */       panel.add(panelGroup, "North");
/* 256 */       panelGroup.add(this.checkEnableTrack, "West");
/*     */     } 
/*     */     
/* 259 */     Panel panel1 = new Panel(new BorderLayout(6, 6));
/* 260 */     panel.add(panel1, "Center");
/* 261 */     panel = panel1;
/* 262 */     panel1 = new Panel(new BorderLayout());
/* 263 */     panel.add(panel1, "North");
/*     */     
/* 265 */     Panel panelLabel = new Panel(new GridLayout(0, 1, 6, 6));
/* 266 */     panel1.add(panelLabel, "West");
/* 267 */     Panel panelData = new Panel(new GridLayout(0, 1, 6, 6));
/* 268 */     panel1.add(panelData, "Center");
/*     */     
/* 270 */     this.labelEncoding = new Label(JMFI18N.getResource("formatchooser.encoding"), 0);
/* 271 */     panelLabel.add(this.labelEncoding);
/* 272 */     this.comboEncoding = new Choice();
/* 273 */     this.comboEncoding.addItemListener(this);
/* 274 */     panelData.add(this.comboEncoding);
/*     */     
/* 276 */     this.labelSampleRate = new Label(JMFI18N.getResource("formatchooser.samplerate"), 0);
/* 277 */     panelLabel.add(this.labelSampleRate);
/* 278 */     Panel panelEntry = new Panel(new BorderLayout(6, 6));
/* 279 */     panelData.add(panelEntry);
/* 280 */     this.comboSampleRate = new Choice();
/* 281 */     this.comboSampleRate.addItemListener(this);
/* 282 */     panelEntry.add(this.comboSampleRate, "Center");
/* 283 */     this.labelHz = new Label(JMFI18N.getResource("formatchooser.hz"));
/* 284 */     panelEntry.add(this.labelHz, "East");
/*     */     
/* 286 */     this.labelBitsPerSample = new Label(JMFI18N.getResource("formatchooser.bitspersample"), 0);
/* 287 */     panelLabel.add(this.labelBitsPerSample);
/* 288 */     panelEntry = new Panel(new GridLayout(1, 0, 6, 6));
/* 289 */     panelData.add(panelEntry);
/* 290 */     this.groupBitsPerSample = new CheckboxGroup();
/* 291 */     this.checkBits8 = new Checkbox(JMFI18N.getResource("formatchooser.8bit"), this.groupBitsPerSample, false);
/* 292 */     this.checkBits8.addItemListener(this);
/* 293 */     panelEntry.add(this.checkBits8);
/* 294 */     this.checkBits16 = new Checkbox(JMFI18N.getResource("formatchooser.16bit"), this.groupBitsPerSample, false);
/* 295 */     this.checkBits16.addItemListener(this);
/* 296 */     panelEntry.add(this.checkBits16);
/*     */     
/* 298 */     this.labelChannels = new Label(JMFI18N.getResource("formatchooser.channels"), 0);
/* 299 */     panelLabel.add(this.labelChannels);
/* 300 */     panelEntry = new Panel(new GridLayout(1, 0, 6, 6));
/* 301 */     panelData.add(panelEntry);
/* 302 */     this.groupChannels = new CheckboxGroup();
/* 303 */     this.checkMono = new Checkbox(JMFI18N.getResource("formatchooser.mono"), this.groupChannels, false);
/* 304 */     this.checkMono.addItemListener(this);
/* 305 */     panelEntry.add(this.checkMono);
/* 306 */     this.checkStereo = new Checkbox(JMFI18N.getResource("formatchooser.stereo"), this.groupChannels, false);
/* 307 */     this.checkStereo.addItemListener(this);
/* 308 */     panelEntry.add(this.checkStereo);
/*     */     
/* 310 */     this.labelEndian = new Label(JMFI18N.getResource("formatchooser.endian"), 0);
/* 311 */     panelLabel.add(this.labelEndian);
/* 312 */     panelEntry = new Panel(new GridLayout(1, 0, 6, 6));
/* 313 */     panelData.add(panelEntry);
/* 314 */     this.groupEndian = new CheckboxGroup();
/* 315 */     this.checkEndianBig = new Checkbox(JMFI18N.getResource("formatchooser.endian.big"), this.groupEndian, false);
/* 316 */     this.checkEndianBig.addItemListener(this);
/* 317 */     panelEntry.add(this.checkEndianBig);
/* 318 */     this.checkEndianLittle = new Checkbox(JMFI18N.getResource("formatchooser.endian.little"), this.groupEndian, false);
/* 319 */     this.checkEndianLittle.addItemListener(this);
/* 320 */     panelEntry.add(this.checkEndianLittle);
/*     */     
/* 322 */     panel1 = new Panel(new BorderLayout(6, 6));
/* 323 */     panel.add(panel1, "Center");
/* 324 */     panel = panel1;
/* 325 */     panel1 = new Panel(new BorderLayout());
/* 326 */     panel.add(panel1, "North");
/*     */     
/* 328 */     this.checkSigned = new Checkbox(JMFI18N.getResource("formatchooser.signed"), true);
/* 329 */     this.checkSigned.addItemListener(this);
/* 330 */     panel1.add(this.checkSigned, "West");
/*     */     
/* 332 */     updateFields(this.formatOld);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateFields(AudioFormat formatDefault) {
/* 340 */     String strEncodingPref = null;
/*     */ 
/*     */     
/* 343 */     Vector vectorEncoding = new Vector();
/*     */ 
/*     */     
/* 346 */     boolean boolEnable = this.comboEncoding.isEnabled();
/* 347 */     this.comboEncoding.setEnabled(false);
/* 348 */     this.comboEncoding.removeAll();
/*     */     
/* 350 */     int nSize = this.vectorContSuppFormats.size();
/* 351 */     for (int i = 0; i < nSize; i++) {
/* 352 */       Object objectFormat = this.vectorContSuppFormats.elementAt(i);
/* 353 */       if (objectFormat instanceof AudioFormat) {
/*     */         
/* 355 */         AudioFormat formatAudio = (AudioFormat)objectFormat;
/*     */         
/* 357 */         String strEncoding = formatAudio.getEncoding().toUpperCase();
/* 358 */         if (!vectorEncoding.contains(strEncoding)) {
/*     */           
/* 360 */           this.comboEncoding.addItem(strEncoding);
/* 361 */           vectorEncoding.addElement(strEncoding);
/* 362 */           if (strEncodingPref == null)
/* 363 */             strEncodingPref = strEncoding; 
/*     */         } 
/*     */       } 
/* 366 */     }  if (formatDefault != null) {
/* 367 */       String str = formatDefault.getEncoding();
/* 368 */       this.comboEncoding.select(str);
/*     */     }
/* 370 */     else if (strEncodingPref != null) {
/* 371 */       this.comboEncoding.select(strEncodingPref);
/* 372 */     } else if (this.comboEncoding.getItemCount() > 0) {
/* 373 */       this.comboEncoding.select(0);
/*     */     } 
/* 375 */     updateFieldsFromEncoding(formatDefault);
/* 376 */     this.comboEncoding.setEnabled(boolEnable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateFieldsFromEncoding(AudioFormat formatDefault) {
/* 384 */     String strSampleRatePref = null;
/*     */ 
/*     */     
/* 387 */     Vector vectorRates = new Vector();
/*     */ 
/*     */     
/* 390 */     boolean boolEnable = this.comboSampleRate.isEnabled();
/* 391 */     this.comboSampleRate.setEnabled(false);
/* 392 */     this.comboSampleRate.removeAll();
/*     */     
/* 394 */     int nSize = this.vectorContSuppFormats.size();
/* 395 */     for (int i = 0; i < nSize; i++) {
/* 396 */       Object objectFormat = this.vectorContSuppFormats.elementAt(i);
/* 397 */       if (objectFormat instanceof AudioFormat) {
/*     */         
/* 399 */         AudioFormat formatAudio = (AudioFormat)objectFormat;
/* 400 */         if (isFormatGoodForEncoding(formatAudio))
/*     */         
/*     */         { 
/* 403 */           double dSampleRate = formatAudio.getSampleRate();
/* 404 */           String strSampleRate = Double.toString(dSampleRate);
/* 405 */           if (!vectorRates.contains(strSampleRate))
/*     */           
/* 407 */           { this.comboSampleRate.addItem(strSampleRate);
/* 408 */             vectorRates.addElement(strSampleRate);
/* 409 */             if (strSampleRatePref == null)
/* 410 */               strSampleRatePref = strSampleRate;  }  } 
/*     */       } 
/* 412 */     }  if (formatDefault != null && isFormatGoodForEncoding(formatDefault)) {
/* 413 */       this.comboSampleRate.select(Double.toString(formatDefault.getSampleRate()));
/* 414 */     } else if (strSampleRatePref != null) {
/* 415 */       this.comboEncoding.select(strSampleRatePref);
/* 416 */     } else if (this.comboSampleRate.getItemCount() > 0) {
/* 417 */       this.comboSampleRate.select(0);
/*     */     } 
/* 419 */     updateFieldsFromRate(formatDefault);
/* 420 */     this.comboSampleRate.setEnabled(boolEnable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateFieldsFromRate(AudioFormat formatDefault) {
/* 429 */     int nBitsPref = -1;
/*     */ 
/*     */     
/* 432 */     this.boolEnable8 = false;
/* 433 */     this.boolEnable16 = false;
/* 434 */     int nSize = this.vectorContSuppFormats.size();
/* 435 */     for (int i = 0; i < nSize; i++) {
/* 436 */       Object objectFormat = this.vectorContSuppFormats.elementAt(i);
/* 437 */       if (objectFormat instanceof AudioFormat) {
/*     */         
/* 439 */         AudioFormat formatAudio = (AudioFormat)objectFormat;
/* 440 */         if (isFormatGoodForEncoding(formatAudio))
/*     */         {
/* 442 */           if (isFormatGoodForSampleRate(formatAudio)) {
/*     */ 
/*     */             
/* 445 */             int nBits = formatAudio.getSampleSizeInBits();
/* 446 */             if (nBitsPref == -1) {
/* 447 */               nBitsPref = nBits;
/*     */             }
/* 449 */             if (nBits == -1)
/* 450 */             { this.boolEnable8 = true;
/* 451 */               this.boolEnable16 = true; }
/*     */             
/* 453 */             else if (nBits == 8)
/* 454 */             { this.boolEnable8 = true; }
/* 455 */             else if (nBits == 16)
/* 456 */             { this.boolEnable16 = true; } 
/*     */           }  } 
/*     */       } 
/* 459 */     }  this.checkBits8.setEnabled(this.boolEnable8);
/* 460 */     this.checkBits16.setEnabled(this.boolEnable16);
/*     */     
/* 462 */     if (formatDefault != null && isFormatGoodForEncoding(formatDefault) && isFormatGoodForSampleRate(formatDefault)) {
/*     */ 
/*     */       
/* 465 */       int j = formatDefault.getSampleSizeInBits();
/* 466 */       if (j == 8) {
/* 467 */         this.checkBits8.setState(true);
/* 468 */       } else if (j == 16) {
/* 469 */         this.checkBits16.setState(true);
/*     */       } 
/* 471 */     } else if (nBitsPref != -1) {
/* 472 */       if (nBitsPref == 8) {
/* 473 */         this.checkBits8.setState(true);
/* 474 */       } else if (nBitsPref == 16) {
/* 475 */         this.checkBits16.setState(true);
/*     */       }
/*     */     
/* 478 */     } else if (this.boolEnable8 == true) {
/* 479 */       this.checkBits8.setState(true);
/*     */     } else {
/* 481 */       this.checkBits16.setState(true);
/*     */     } 
/*     */     
/* 484 */     updateFieldsFromBits(formatDefault);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateFieldsFromBits(AudioFormat formatDefault) {
/* 493 */     int nChannelsPref = -1;
/*     */ 
/*     */     
/* 496 */     this.boolEnableMono = false;
/* 497 */     this.boolEnableStereo = false;
/*     */     
/* 499 */     int nSize = this.vectorContSuppFormats.size();
/* 500 */     for (int i = 0; i < nSize; i++) {
/* 501 */       Object objectFormat = this.vectorContSuppFormats.elementAt(i);
/* 502 */       if (objectFormat instanceof AudioFormat) {
/*     */         
/* 504 */         AudioFormat formatAudio = (AudioFormat)objectFormat;
/* 505 */         if (isFormatGoodForEncoding(formatAudio))
/*     */         {
/* 507 */           if (isFormatGoodForSampleRate(formatAudio))
/*     */           {
/* 509 */             if (isFormatGoodForBitSize(formatAudio)) {
/*     */ 
/*     */               
/* 512 */               int nChannels = formatAudio.getChannels();
/* 513 */               if (nChannelsPref == -1) {
/* 514 */                 nChannelsPref = nChannels;
/*     */               }
/* 516 */               if (nChannels == -1)
/* 517 */               { this.boolEnableMono = true;
/* 518 */                 this.boolEnableStereo = true; }
/*     */               
/* 520 */               else if (nChannels == 1)
/* 521 */               { this.boolEnableMono = true; }
/*     */               else
/* 523 */               { this.boolEnableStereo = true; } 
/*     */             }  }  } 
/*     */       } 
/* 526 */     }  this.checkMono.setEnabled(this.boolEnableMono);
/* 527 */     this.checkStereo.setEnabled(this.boolEnableStereo);
/*     */     
/* 529 */     if (formatDefault != null && isFormatGoodForEncoding(formatDefault) && isFormatGoodForSampleRate(formatDefault) && isFormatGoodForBitSize(formatDefault)) {
/*     */ 
/*     */ 
/*     */       
/* 533 */       int j = formatDefault.getChannels();
/* 534 */       if (j == 1) {
/* 535 */         this.checkMono.setState(true);
/*     */       } else {
/* 537 */         this.checkStereo.setState(true);
/*     */       } 
/* 539 */     } else if (nChannelsPref != -1) {
/* 540 */       if (nChannelsPref == 1) {
/* 541 */         this.checkMono.setState(true);
/*     */       } else {
/* 543 */         this.checkStereo.setState(true);
/*     */       }
/*     */     
/* 546 */     } else if (this.boolEnableMono == true) {
/* 547 */       this.checkMono.setState(true);
/*     */     } else {
/* 549 */       this.checkStereo.setState(true);
/*     */     } 
/*     */     
/* 552 */     updateFieldsFromChannels(formatDefault);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateFieldsFromChannels(AudioFormat formatDefault) {
/* 561 */     int nEndianPref = -1;
/*     */ 
/*     */     
/* 564 */     this.boolEnableEndianBig = false;
/* 565 */     this.boolEnableEndianLittle = false;
/*     */     
/* 567 */     int nSize = this.vectorContSuppFormats.size();
/* 568 */     for (int i = 0; i < nSize; i++) {
/* 569 */       Object objectFormat = this.vectorContSuppFormats.elementAt(i);
/* 570 */       if (objectFormat instanceof AudioFormat) {
/*     */         
/* 572 */         AudioFormat formatAudio = (AudioFormat)objectFormat;
/* 573 */         if (isFormatGoodForEncoding(formatAudio))
/*     */         {
/* 575 */           if (isFormatGoodForSampleRate(formatAudio))
/*     */           {
/* 577 */             if (isFormatGoodForBitSize(formatAudio))
/*     */             {
/* 579 */               if (isFormatGoodForChannels(formatAudio)) {
/*     */ 
/*     */                 
/* 582 */                 int nEndian = formatAudio.getEndian();
/* 583 */                 if (nEndianPref == -1) {
/* 584 */                   nEndianPref = nEndian;
/*     */                 }
/* 586 */                 if (nEndian == -1) {
/* 587 */                   this.boolEnableEndianBig = true;
/* 588 */                   this.boolEnableEndianLittle = true;
/*     */                 }
/* 590 */                 else if (nEndian == 1) {
/* 591 */                   this.boolEnableEndianBig = true;
/*     */                 } else {
/* 593 */                   this.boolEnableEndianLittle = true;
/*     */                 } 
/*     */               }  }  }  } 
/*     */       } 
/* 597 */     }  this.checkEndianBig.setEnabled(this.boolEnableEndianBig);
/* 598 */     this.checkEndianLittle.setEnabled(this.boolEnableEndianLittle);
/*     */     
/* 600 */     if (formatDefault != null && isFormatGoodForEncoding(formatDefault) && isFormatGoodForSampleRate(formatDefault) && isFormatGoodForBitSize(formatDefault) && isFormatGoodForChannels(formatDefault)) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 605 */       int j = formatDefault.getEndian();
/* 606 */       if (j == 1) {
/* 607 */         this.checkEndianBig.setState(true);
/*     */       } else {
/* 609 */         this.checkEndianLittle.setState(true);
/*     */       } 
/* 611 */     } else if (nEndianPref != -1) {
/* 612 */       if (nEndianPref == 1) {
/* 613 */         this.checkEndianBig.setState(true);
/*     */       } else {
/* 615 */         this.checkEndianLittle.setState(true);
/*     */       }
/*     */     
/* 618 */     } else if (this.boolEnableEndianBig == true) {
/* 619 */       this.checkEndianBig.setState(true);
/*     */     } else {
/* 621 */       this.checkEndianLittle.setState(true);
/*     */     } 
/*     */     
/* 624 */     if (this.checkBits16.getState() != true) {
/*     */       
/* 626 */       this.boolEnableEndianBig = false;
/* 627 */       this.boolEnableEndianLittle = false;
/* 628 */       this.checkEndianBig.setEnabled(this.boolEnableEndianBig);
/* 629 */       this.checkEndianLittle.setEnabled(this.boolEnableEndianLittle);
/*     */     } 
/*     */     
/* 632 */     updateFieldsFromEndian(formatDefault);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateFieldsFromEndian(AudioFormat formatDefault) {
/* 641 */     int nSignedPref = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 646 */     boolean boolSigned = false;
/* 647 */     boolean boolUnsigned = false;
/*     */     
/* 649 */     int nSize = this.vectorContSuppFormats.size();
/* 650 */     for (int i = 0; i < nSize; i++) {
/* 651 */       Object objectFormat = this.vectorContSuppFormats.elementAt(i);
/* 652 */       if (objectFormat instanceof AudioFormat) {
/*     */         
/* 654 */         AudioFormat formatAudio = (AudioFormat)objectFormat;
/* 655 */         if (isFormatGoodForEncoding(formatAudio))
/*     */         {
/* 657 */           if (isFormatGoodForSampleRate(formatAudio))
/*     */           {
/* 659 */             if (isFormatGoodForBitSize(formatAudio))
/*     */             {
/* 661 */               if (isFormatGoodForChannels(formatAudio))
/*     */               {
/* 663 */                 if (isFormatGoodForEndian(formatAudio)) {
/*     */ 
/*     */                   
/* 666 */                   int nSigned = formatAudio.getSigned();
/* 667 */                   if (nSignedPref == -1) {
/* 668 */                     nSignedPref = nSigned;
/*     */                   }
/* 670 */                   if (nSigned == -1)
/* 671 */                   { boolSigned = true;
/* 672 */                     boolUnsigned = true; }
/*     */                   
/* 674 */                   else if (nSigned == 1)
/* 675 */                   { boolSigned = true; }
/*     */                   else
/* 677 */                   { boolUnsigned = true; } 
/*     */                 }  }  }  }  } 
/*     */       } 
/* 680 */     }  this.boolEnableSigned = (boolSigned && boolUnsigned);
/* 681 */     this.checkSigned.setEnabled(this.boolEnableSigned);
/*     */     
/* 683 */     if (formatDefault != null && isFormatGoodForEncoding(formatDefault) && isFormatGoodForSampleRate(formatDefault) && isFormatGoodForBitSize(formatDefault) && isFormatGoodForChannels(formatDefault) && isFormatGoodForEndian(formatDefault)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 689 */       int j = formatDefault.getSigned();
/* 690 */       if (j == 1) {
/* 691 */         this.checkSigned.setState(true);
/*     */       } else {
/* 693 */         this.checkSigned.setState(false);
/*     */       } 
/* 695 */     } else if (nSignedPref != -1) {
/* 696 */       if (nSignedPref == 1) {
/* 697 */         this.checkSigned.setState(true);
/*     */       } else {
/* 699 */         this.checkSigned.setState(false);
/*     */       }
/*     */     
/* 702 */     } else if (boolSigned == true) {
/* 703 */       this.checkSigned.setState(true);
/*     */     } else {
/* 705 */       this.checkSigned.setState(false);
/*     */     } 
/*     */     
/* 708 */     updateFieldsFromSigned(formatDefault);
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateFieldsFromSigned(AudioFormat formatDefault) {}
/*     */ 
/*     */   
/*     */   private boolean isFormatGoodForEncoding(AudioFormat format) {
/* 716 */     boolean boolResult = false;
/*     */     
/* 718 */     String strEncoding = this.comboEncoding.getSelectedItem();
/* 719 */     if (strEncoding != null) {
/* 720 */       boolResult = format.getEncoding().equalsIgnoreCase(strEncoding);
/*     */     }
/* 722 */     return boolResult;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isFormatGoodForSampleRate(AudioFormat format) {
/* 728 */     boolean boolResult = false;
/*     */     
/* 730 */     String strSampleRate = this.comboSampleRate.getSelectedItem();
/* 731 */     if (strSampleRate != null) {
/* 732 */       double dSampleRate = Double.valueOf(strSampleRate).doubleValue();
/* 733 */       if (format.getSampleRate() == -1.0D) {
/* 734 */         boolResult = true;
/* 735 */       } else if (format.getSampleRate() == dSampleRate) {
/* 736 */         boolResult = true;
/*     */       } 
/* 738 */     }  return boolResult;
/*     */   }
/*     */   
/*     */   private boolean isFormatGoodForBitSize(AudioFormat format) {
/*     */     byte b;
/* 743 */     boolean boolResult = false;
/*     */     
/* 745 */     if (this.checkBits8.getState() == true) {
/* 746 */       b = 8;
/* 747 */     } else if (this.checkBits16.getState() == true) {
/* 748 */       b = 16;
/*     */     } else {
/* 750 */       b = -1;
/*     */     } 
/* 752 */     if (format.getSampleSizeInBits() == -1) {
/* 753 */       boolResult = true;
/* 754 */     } else if (b == -1) {
/* 755 */       boolResult = true;
/* 756 */     } else if (format.getSampleSizeInBits() == b) {
/* 757 */       boolResult = true;
/* 758 */     } else if (format.getSampleSizeInBits() < 8) {
/* 759 */       boolResult = true;
/*     */     } 
/* 761 */     return boolResult;
/*     */   }
/*     */   
/*     */   private boolean isFormatGoodForChannels(AudioFormat format) {
/*     */     byte b;
/* 766 */     boolean boolResult = false;
/*     */     
/* 768 */     if (this.checkMono.getState() == true) {
/* 769 */       b = 1;
/* 770 */     } else if (this.checkStereo.getState() == true) {
/* 771 */       b = 2;
/*     */     } else {
/* 773 */       b = -1;
/*     */     } 
/* 775 */     if (format.getChannels() == -1) {
/* 776 */       boolResult = true;
/* 777 */     } else if (b == -1) {
/* 778 */       boolResult = true;
/* 779 */     } else if (format.getChannels() == b) {
/* 780 */       boolResult = true;
/*     */     } 
/* 782 */     return boolResult;
/*     */   }
/*     */   
/*     */   private boolean isFormatGoodForEndian(AudioFormat format) {
/*     */     byte b;
/* 787 */     boolean boolResult = false;
/*     */     
/* 789 */     if (this.checkEndianBig.getState() == true) {
/* 790 */       b = 1;
/* 791 */     } else if (this.checkStereo.getState() == true) {
/* 792 */       b = 0;
/*     */     } else {
/* 794 */       b = -1;
/*     */     } 
/* 796 */     if (format.getEndian() == -1) {
/* 797 */       boolResult = true;
/* 798 */     } else if (b == -1) {
/* 799 */       boolResult = true;
/* 800 */     } else if (format.getEndian() == b) {
/* 801 */       boolResult = true;
/*     */     } 
/* 803 */     return boolResult;
/*     */   }
/*     */   
/*     */   private boolean isFormatGoodForSigned(AudioFormat format) {
/*     */     boolean bool;
/* 808 */     boolean boolResult = false;
/*     */     
/* 810 */     if (this.checkSigned.getState() == true) {
/* 811 */       bool = true;
/*     */     } else {
/* 813 */       bool = false;
/*     */     } 
/* 815 */     if (format.getSigned() == -1) {
/* 816 */       boolResult = true;
/* 817 */     } else if (bool == -1) {
/* 818 */       boolResult = true;
/* 819 */     } else if (format.getSigned() == bool) {
/* 820 */       boolResult = true;
/*     */     } 
/* 822 */     return boolResult;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isFormatSupported(AudioFormat format) {
/* 829 */     boolean boolSupported = false;
/*     */     
/* 831 */     if (format == null) {
/* 832 */       return boolSupported;
/*     */     }
/* 834 */     int nCount = this.vectorContSuppFormats.size();
/* 835 */     for (int i = 0; i < nCount && !boolSupported; i++) {
/* 836 */       AudioFormat formatAudio = this.vectorContSuppFormats.elementAt(i);
/* 837 */       if (formatAudio.matches((Format)format))
/* 838 */         boolSupported = true; 
/*     */     } 
/* 840 */     return boolSupported;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void itemStateChanged(ItemEvent event) {
/* 846 */     Object objectSource = event.getSource();
/* 847 */     if (objectSource == this.checkEnableTrack) {
/* 848 */       this.boolEnableTrackSaved = this.checkEnableTrack.getState();
/* 849 */       onEnableTrack(true);
/*     */     }
/* 851 */     else if (objectSource == this.comboEncoding) {
/* 852 */       updateFieldsFromEncoding(this.formatOld);
/*     */     }
/* 854 */     else if (objectSource == this.comboSampleRate) {
/* 855 */       updateFieldsFromRate(this.formatOld);
/*     */     }
/* 857 */     else if (objectSource == this.checkBits8 || objectSource == this.checkBits16) {
/* 858 */       updateFieldsFromBits(this.formatOld);
/*     */     }
/* 860 */     else if (objectSource == this.checkMono || objectSource == this.checkStereo) {
/* 861 */       updateFieldsFromChannels(this.formatOld);
/*     */     }
/* 863 */     else if (objectSource == this.checkEndianBig || objectSource == this.checkEndianLittle) {
/* 864 */       updateFieldsFromEndian(this.formatOld);
/*     */     }
/* 866 */     else if (objectSource == this.checkSigned) {
/* 867 */       updateFieldsFromSigned(this.formatOld);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void onEnableTrack(boolean notifyListener) {
/* 875 */     boolean boolEnable = this.checkEnableTrack.getState();
/* 876 */     enableControls((boolEnable && isEnabled()));
/*     */     
/* 878 */     if (notifyListener == true && this.listenerEnableTrack != null) {
/* 879 */       ActionEvent actionEvent; if (boolEnable == true) {
/* 880 */         actionEvent = new ActionEvent(this, 1001, "ACTION_AUDIO_TRACK_ENABLED");
/*     */       } else {
/* 882 */         actionEvent = new ActionEvent(this, 1001, "ACTION_AUDIO_TRACK_DISABLED");
/* 883 */       }  this.listenerEnableTrack.actionPerformed(actionEvent);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void enableControls(boolean boolEnable) {
/* 888 */     this.labelEncoding.setEnabled(boolEnable);
/* 889 */     this.comboEncoding.setEnabled(boolEnable);
/* 890 */     this.labelSampleRate.setEnabled(boolEnable);
/* 891 */     this.comboSampleRate.setEnabled(boolEnable);
/* 892 */     this.labelHz.setEnabled(boolEnable);
/* 893 */     this.labelBitsPerSample.setEnabled(boolEnable);
/* 894 */     this.checkBits8.setEnabled((boolEnable && this.boolEnable8));
/* 895 */     this.checkBits16.setEnabled((boolEnable && this.boolEnable16));
/* 896 */     this.labelChannels.setEnabled(boolEnable);
/* 897 */     this.checkMono.setEnabled((boolEnable && this.boolEnableMono));
/* 898 */     this.checkStereo.setEnabled((boolEnable && this.boolEnableStereo));
/* 899 */     this.labelEndian.setEnabled(boolEnable);
/* 900 */     this.checkEndianBig.setEnabled((boolEnable && this.boolEnableEndianBig));
/* 901 */     this.checkEndianLittle.setEnabled((boolEnable && this.boolEnableEndianLittle));
/* 902 */     this.checkSigned.setEnabled((boolEnable && this.boolEnableSigned));
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\medi\\ui\AudioFormatChooser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */