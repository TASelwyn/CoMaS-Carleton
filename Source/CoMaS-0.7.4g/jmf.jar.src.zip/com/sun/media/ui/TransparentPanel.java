package com.sun.media.ui;

import java.awt.Container;
import java.awt.LayoutManager;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;

class TransparentPanel extends Container implements ComponentListener {
  public TransparentPanel() {
    addComponentListener(this);
  }
  
  public TransparentPanel(LayoutManager mgrLayout) {
    setLayout(mgrLayout);
    addComponentListener(this);
  }
  
  public void componentResized(ComponentEvent e) {
    doLayout();
    repaint();
  }
  
  public void componentMoved(ComponentEvent e) {}
  
  public void componentShown(ComponentEvent e) {}
  
  public void componentHidden(ComponentEvent e) {}
}
