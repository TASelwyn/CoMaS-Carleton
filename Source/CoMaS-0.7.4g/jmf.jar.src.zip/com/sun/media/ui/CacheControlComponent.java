package com.sun.media.ui;

import com.sun.media.util.JMFI18N;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Label;
import javax.media.CachingControl;
import javax.media.ExtendedCachingControl;
import javax.media.Player;

public class CacheControlComponent extends BufferedPanel {
  protected CachingControl ctrl;
  
  private ExtendedCachingControl xtdctrl;
  
  protected Player player;
  
  protected ButtonComp cancelButton;
  
  protected ProgressBar progressBar;
  
  public CacheControlComponent(CachingControl ctrl, Player player) {
    this.ctrl = null;
    this.xtdctrl = null;
    this.player = null;
    this.cancelButton = null;
    this.progressBar = null;
    this.ctrl = ctrl;
    this.player = player;
    if (ctrl instanceof ExtendedCachingControl)
      this.xtdctrl = (ExtendedCachingControl)ctrl; 
    setBackground(DefaultControlPanel.colorBackground);
    setBackgroundTile(BasicComp.fetchImage("texture3.gif"));
    GridBagLayout gbl;
    setLayout(gbl = new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = 0;
    Label label = new Label(JMFI18N.getResource("mediaplayer.download"), 1);
    add(label);
    gbl.setConstraints(label, gbc);
    gbc.gridy++;
    gbc.gridwidth = 1;
    this.cancelButton = new CancelButton(this);
    add(this.cancelButton);
    gbl.setConstraints(this.cancelButton, gbc);
    gbc.gridx++;
    this.progressBar = new ProgressBar(ctrl);
    add(this.progressBar);
    gbl.setConstraints(this.progressBar, gbc);
  }
  
  public void addNotify() {
    super.addNotify();
    setSize(getPreferredSize());
  }
  
  public Component getProgressBar() {
    return this.progressBar;
  }
  
  class CancelButton extends ButtonComp {
    private final CacheControlComponent this$0;
    
    public CancelButton(CacheControlComponent this$0) {
      super("Suspend download", "pause.gif", "pause-active.gif", "pause-pressed.gif", "pause-disabled.gif", "play.gif", "play-active.gif", "play-pressed.gif", "play-disabled.gif");
      this.this$0 = this$0;
    }
    
    public void action() {
      super.action();
      if (this.this$0.player != null);
      if (this.this$0.xtdctrl != null)
        if (this.state) {
          this.this$0.xtdctrl.pauseDownload();
        } else {
          this.this$0.xtdctrl.resumeDownload();
        }  
    }
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\medi\\ui\CacheControlComponent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */