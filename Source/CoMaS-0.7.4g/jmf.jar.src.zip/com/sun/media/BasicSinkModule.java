/*     */ package com.sun.media;
/*     */ 
/*     */ import javax.media.Clock;
/*     */ import javax.media.IncompatibleTimeBaseException;
/*     */ import javax.media.Time;
/*     */ import javax.media.TimeBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BasicSinkModule
/*     */   extends BasicModule
/*     */ {
/*     */   private Clock clock;
/*     */   protected boolean prerolling = false;
/*  22 */   protected float rate = 1.0F;
/*     */   
/*  24 */   protected long stopTime = -1L;
/*     */   
/*     */   public void doStart() {
/*  27 */     super.doStart();
/*  28 */     if (this.clock != null)
/*  29 */       this.clock.syncStart(this.clock.getTimeBase().getTime()); 
/*     */   }
/*     */   
/*     */   public void doStop() {
/*  33 */     if (this.clock != null)
/*  34 */       this.clock.stop(); 
/*     */   }
/*     */   
/*     */   public void doSetMediaTime(Time t) {
/*  38 */     if (this.clock != null)
/*  39 */       this.clock.setMediaTime(t); 
/*     */   }
/*     */   
/*     */   public float doSetRate(float r) {
/*  43 */     if (this.clock != null) {
/*  44 */       this.rate = this.clock.setRate(r);
/*     */     } else {
/*  46 */       this.rate = r;
/*  47 */     }  return this.rate;
/*     */   }
/*     */   
/*     */   public void setTimeBase(TimeBase tb) throws IncompatibleTimeBaseException {
/*  51 */     if (this.clock != null)
/*  52 */       this.clock.setTimeBase(tb); 
/*     */   }
/*     */   
/*     */   public TimeBase getTimeBase() {
/*  56 */     if (this.clock != null) {
/*  57 */       return this.clock.getTimeBase();
/*     */     }
/*  59 */     return this.controller.getTimeBase();
/*     */   }
/*     */   
/*     */   public Time getMediaTime() {
/*  63 */     if (this.clock != null) {
/*  64 */       return this.clock.getMediaTime();
/*     */     }
/*  66 */     return this.controller.getMediaTime();
/*     */   }
/*     */   
/*     */   public long getMediaNanoseconds() {
/*  70 */     if (this.clock != null) {
/*  71 */       return this.clock.getMediaNanoseconds();
/*     */     }
/*  73 */     return this.controller.getMediaNanoseconds();
/*     */   }
/*     */   
/*     */   public Clock getClock() {
/*  77 */     return this.clock;
/*     */   }
/*     */   
/*     */   protected void setClock(Clock c) {
/*  81 */     this.clock = c;
/*     */   }
/*     */   
/*     */   public void setStopTime(Time t) {
/*  85 */     if (t == Clock.RESET) {
/*  86 */       this.stopTime = -1L;
/*     */     } else {
/*  88 */       this.stopTime = t.getNanoseconds();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPreroll(long wanted, long actual) {
/* 102 */     if (actual < wanted)
/* 103 */       this.prerolling = true; 
/*     */   }
/*     */   
/*     */   public void triggerReset() {}
/*     */   
/*     */   public void doneReset() {}
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\BasicSinkModule.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */