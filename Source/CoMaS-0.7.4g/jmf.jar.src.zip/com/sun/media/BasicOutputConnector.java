package com.sun.media;

import javax.media.Buffer;
import javax.media.Format;

public class BasicOutputConnector extends BasicConnector implements OutputConnector {
  protected InputConnector inputConnector = null;
  
  private boolean reset = false;
  
  public Format connectTo(InputConnector inputConnector, Format useThisFormat) {
    Format format = canConnectTo(inputConnector, useThisFormat);
    this.inputConnector = inputConnector;
    inputConnector.setOutputConnector(this);
    int bufferSize = Math.max(getSize(), inputConnector.getSize());
    this.circularBuffer = new CircularBuffer(bufferSize);
    inputConnector.setCircularBuffer(this.circularBuffer);
    return null;
  }
  
  public Format canConnectTo(InputConnector inputConnector, Format useThisFormat) {
    if (getProtocol() != inputConnector.getProtocol())
      throw new RuntimeException("protocols do not match:: "); 
    return null;
  }
  
  public InputConnector getInputConnector() {
    return this.inputConnector;
  }
  
  public void reset() {
    synchronized (this.circularBuffer) {
      this.reset = true;
      super.reset();
      if (this.inputConnector != null)
        this.inputConnector.reset(); 
      this.circularBuffer.notifyAll();
    } 
  }
  
  public boolean isEmptyBufferAvailable() {
    return this.circularBuffer.canWrite();
  }
  
  public Buffer getEmptyBuffer() {
    switch (this.protocol) {
      case 0:
        if (!isEmptyBufferAvailable() && this.reset)
          return null; 
        this.reset = false;
        return this.circularBuffer.getEmptyBuffer();
      case 1:
        synchronized (this.circularBuffer) {
          this.reset = false;
          while (!this.reset && !isEmptyBufferAvailable()) {
            try {
              this.circularBuffer.wait();
            } catch (Exception e) {}
          } 
          if (this.reset)
            return null; 
          Buffer buffer = this.circularBuffer.getEmptyBuffer();
          this.circularBuffer.notifyAll();
          return buffer;
        } 
    } 
    throw new RuntimeException();
  }
  
  public void writeReport() {
    switch (this.protocol) {
      case 0:
        synchronized (this.circularBuffer) {
          if (this.reset)
            return; 
          this.circularBuffer.writeReport();
        } 
        getInputConnector().getModule().connectorPushed(getInputConnector());
        return;
      case 1:
        synchronized (this.circularBuffer) {
          if (this.reset)
            return; 
          this.circularBuffer.writeReport();
          this.circularBuffer.notifyAll();
          return;
        } 
    } 
    throw new RuntimeException();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\BasicOutputConnector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */