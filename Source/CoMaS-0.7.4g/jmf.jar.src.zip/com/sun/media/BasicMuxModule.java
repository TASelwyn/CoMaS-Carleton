/*     */ package com.sun.media;
/*     */ 
/*     */ import com.sun.media.util.ElapseTime;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Clock;
/*     */ import javax.media.Drainable;
/*     */ import javax.media.Format;
/*     */ import javax.media.Multiplexer;
/*     */ import javax.media.Prefetchable;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ import javax.media.protocol.DataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicMuxModule
/*     */   extends BasicSinkModule
/*     */ {
/*     */   protected Multiplexer multiplexer;
/*     */   protected Format[] inputs;
/*     */   protected InputConnector[] ics;
/*     */   protected boolean[] prefetchMarkers;
/*     */   protected boolean[] endMarkers;
/*     */   protected boolean[] resettedMarkers;
/*     */   protected boolean[] stopAtTimeMarkers;
/*     */   protected boolean[] paused;
/*     */   protected boolean[] prerollTrack;
/*     */   private Object[] pauseSync;
/*     */   protected ElapseTime[] elapseTime;
/*     */   protected boolean prefetching = false;
/*     */   protected boolean started = false;
/*     */   private boolean closed = false;
/*     */   private boolean failed = false;
/*  37 */   private Object prefetchSync = new Object();
/*  38 */   private float frameRate = 30.0F;
/*  39 */   private float lastFramesBehind = -1.0F;
/*  40 */   private int framesPlayed = 0;
/*  41 */   private VideoFormat rtpVideoFormat = null;
/*  42 */   private VideoFormat firstVideoFormat = null;
/*  43 */   public static String ConnectorNamePrefix = "input";
/*     */   
/*  45 */   private long bitsWritten = 0L;
/*     */ 
/*     */   
/*  48 */   static AudioFormat mpegAudio = new AudioFormat("mpegaudio/rtp");
/*     */ 
/*     */   
/*     */   protected BasicMuxModule(Multiplexer m, Format[] inputs) {
/*  52 */     this.multiplexer = m;
/*  53 */     if (inputs != null) {
/*     */       
/*  55 */       this.ics = new InputConnector[inputs.length];
/*  56 */       for (int i = 0; i < inputs.length; i++) {
/*  57 */         InputConnector ic = new MyInputConnector(this);
/*  58 */         ic.setSize(1);
/*  59 */         ic.setModule(this);
/*  60 */         registerInputConnector(ConnectorNamePrefix + i, ic);
/*  61 */         this.ics[i] = ic;
/*  62 */         if (inputs[i] instanceof VideoFormat && this.firstVideoFormat == null) {
/*     */           
/*  64 */           this.firstVideoFormat = (VideoFormat)inputs[i];
/*  65 */           String encoding = inputs[i].getEncoding().toUpperCase();
/*  66 */           if (encoding.endsWith("RTP"))
/*  67 */             this.rtpVideoFormat = this.firstVideoFormat; 
/*     */         } 
/*     */       } 
/*  70 */       this.inputs = inputs;
/*     */     } 
/*  72 */     if (this.multiplexer != null && this.multiplexer instanceof Clock)
/*  73 */       setClock((Clock)this.multiplexer); 
/*  74 */     setProtocol(0);
/*     */   }
/*     */   
/*     */   public boolean isThreaded() {
/*  78 */     return false;
/*     */   }
/*     */   
/*     */   public boolean doRealize() {
/*  82 */     if (this.multiplexer == null || this.inputs == null)
/*  83 */       return false; 
/*     */     try {
/*  85 */       this.multiplexer.open();
/*     */     } catch (ResourceUnavailableException e) {
/*  87 */       return false;
/*     */     } 
/*  89 */     this.prefetchMarkers = new boolean[this.ics.length];
/*  90 */     this.endMarkers = new boolean[this.ics.length];
/*  91 */     this.resettedMarkers = new boolean[this.ics.length];
/*  92 */     this.stopAtTimeMarkers = new boolean[this.ics.length];
/*  93 */     this.paused = new boolean[this.ics.length];
/*  94 */     this.prerollTrack = new boolean[this.ics.length];
/*  95 */     this.pauseSync = new Object[this.ics.length];
/*  96 */     this.elapseTime = new ElapseTime[this.ics.length];
/*     */     
/*  98 */     for (int i = 0; i < this.ics.length; i++) {
/*  99 */       this.prerollTrack[i] = false;
/* 100 */       this.pauseSync[i] = new Object();
/* 101 */       this.elapseTime[i] = new ElapseTime();
/*     */     } 
/*     */     
/* 104 */     pause();
/*     */     
/* 106 */     return true;
/*     */   }
/*     */   
/*     */   public boolean doPrefetch() {
/* 110 */     if (!((PlaybackEngine)this.controller).prefetchEnabled) {
/* 111 */       return true;
/*     */     }
/* 113 */     resetPrefetchMarkers();
/* 114 */     this.prefetching = true;
/* 115 */     resume();
/* 116 */     return true;
/*     */   }
/*     */   
/*     */   public void doFailedPrefetch() {
/* 120 */     this.prefetching = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void abortPrefetch() {
/* 125 */     this.prefetching = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPreroll(long wanted, long actual) {
/* 132 */     super.setPreroll(wanted, actual);
/* 133 */     for (int i = 0; i < this.elapseTime.length; i++) {
/* 134 */       this.elapseTime[i].setValue(actual);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 140 */       if (this.inputs[i] instanceof AudioFormat && mpegAudio.matches(this.inputs[i])) {
/*     */         
/* 142 */         this.prerollTrack[i] = false;
/*     */       } else {
/* 144 */         this.prerollTrack[i] = true;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public void doStart() {
/* 149 */     super.doStart();
/* 150 */     resetEndMarkers();
/* 151 */     resetStopAtTimeMarkers();
/* 152 */     this.started = true;
/*     */     
/* 154 */     synchronized (this.prefetchSync) {
/* 155 */       this.prefetching = false;
/* 156 */       resume();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void doStop() {
/* 161 */     super.doStop();
/* 162 */     this.started = false;
/* 163 */     resetPrefetchMarkers();
/* 164 */     this.prefetching = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void doDealloc() {}
/*     */ 
/*     */   
/*     */   public void doClose() {
/* 172 */     this.multiplexer.close();
/* 173 */     this.closed = true;
/* 174 */     for (int i = 0; i < this.pauseSync.length; i++) {
/* 175 */       synchronized (this.pauseSync[i]) {
/* 176 */         this.pauseSync[i].notifyAll();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void pause() {
/* 186 */     for (int i = 0; i < this.paused.length; i++) {
/* 187 */       this.paused[i] = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void resume() {
/* 195 */     for (int i = 0; i < this.pauseSync.length; i++) {
/* 196 */       synchronized (this.pauseSync[i]) {
/* 197 */         this.paused[i] = false;
/* 198 */         this.pauseSync[i].notifyAll();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connectorPushed(InputConnector ic) {
/* 210 */     int idx = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     if (this.ics[0] == ic) {
/* 216 */       idx = 0;
/* 217 */     } else if (this.ics[1] == ic) {
/* 218 */       idx = 1;
/*     */     } else {
/* 220 */       for (int i = 2; i < this.ics.length; i++) {
/* 221 */         if (this.ics[i] == ic) {
/* 222 */           idx = i; break;
/*     */         } 
/*     */       } 
/* 225 */       if (idx == -1)
/*     */       {
/* 227 */         throw new RuntimeException("BasicMuxModule: unmatched input connector!");
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 239 */       if (this.paused[idx])
/*     */       {
/*     */ 
/*     */         
/* 243 */         synchronized (this.pauseSync[idx]) {
/*     */           try {
/* 245 */             while (this.paused[idx] && !this.closed)
/* 246 */               this.pauseSync[idx].wait(); 
/* 247 */           } catch (Exception e) {}
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 255 */       if (this.stopTime > -1L && (this.elapseTime[idx]).value >= this.stopTime) {
/* 256 */         this.paused[idx] = true;
/*     */         
/* 258 */         if (checkStopAtTime(idx)) {
/* 259 */           if (this.multiplexer instanceof Drainable)
/* 260 */             ((Drainable)this.multiplexer).drain(); 
/* 261 */           doStop();
/* 262 */           if (this.moduleListener != null) {
/* 263 */             this.moduleListener.stopAtTime(this);
/*     */           }
/*     */         } 
/*     */         continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 270 */     Buffer buffer = ic.getValidBuffer();
/* 271 */     int flags = buffer.getFlags();
/*     */     
/* 273 */     int rc = 0;
/*     */ 
/*     */     
/* 276 */     if (this.resetted) {
/*     */ 
/*     */ 
/*     */       
/* 280 */       if ((flags & 0x200) != 0)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 287 */         if (checkResetted(idx)) {
/* 288 */           this.resetted = false;
/* 289 */           doStop();
/* 290 */           if (this.moduleListener != null) {
/* 291 */             this.moduleListener.resetted(this);
/*     */           }
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 297 */       ic.readReport();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 302 */     if (this.failed || this.closed || buffer.isDiscard()) {
/* 303 */       ic.readReport();
/*     */       
/*     */       return;
/*     */     } 
/* 307 */     if (PlaybackEngine.DEBUG) this.jmd.moduleIn(this, 0, buffer, true);
/*     */ 
/*     */     
/* 310 */     if ((flags & 0x400) != 0 && this.moduleListener != null) {
/*     */       
/* 312 */       this.moduleListener.markedDataArrived(this, buffer);
/* 313 */       flags &= 0xFFFFFBFF;
/* 314 */       buffer.setFlags(flags);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 319 */     boolean dataPrerolled = false;
/*     */     
/* 321 */     Format format = buffer.getFormat();
/*     */     
/* 323 */     if (format == null) {
/*     */ 
/*     */       
/* 326 */       format = ic.getFormat();
/* 327 */       buffer.setFormat(format);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 332 */     if (this.elapseTime[idx].update(buffer.getLength(), buffer.getTimeStamp(), format)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 338 */       if (this.prerollTrack[idx]) {
/* 339 */         long target = getMediaNanoseconds();
/* 340 */         if ((this.elapseTime[idx]).value > target) {
/*     */           
/* 342 */           if (format instanceof AudioFormat && "LINEAR".equals(format.getEncoding())) {
/*     */             
/* 344 */             int remain = (int)ElapseTime.audioTimeToLen((this.elapseTime[idx]).value - target, (AudioFormat)format);
/*     */ 
/*     */ 
/*     */             
/* 348 */             int offset = buffer.getOffset() + buffer.getLength() - remain;
/*     */             
/* 350 */             if (offset >= 0) {
/* 351 */               buffer.setOffset(offset);
/* 352 */               buffer.setLength(remain);
/*     */             } 
/*     */           } 
/* 355 */           this.prerollTrack[idx] = false;
/* 356 */           this.elapseTime[idx].setValue(target);
/*     */         } else {
/* 358 */           dataPrerolled = true;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 363 */       if (this.stopTime > -1L && (this.elapseTime[idx]).value > this.stopTime && format instanceof AudioFormat) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 368 */         long exceeded = (this.elapseTime[idx]).value - this.stopTime;
/* 369 */         int exceededLen = (int)ElapseTime.audioTimeToLen(exceeded, (AudioFormat)format);
/*     */         
/* 371 */         if (buffer.getLength() > exceededLen) {
/* 372 */           buffer.setLength(buffer.getLength() - exceededLen);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 377 */     if (this.moduleListener != null && format instanceof VideoFormat) {
/*     */ 
/*     */       
/* 380 */       long mt = getMediaNanoseconds();
/*     */ 
/*     */       
/* 383 */       long lateBy = mt / 1000000L - buffer.getTimeStamp() / 1000000L - getLatency() / 1000000L;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 388 */       float fb = (float)lateBy * this.frameRate / 1000.0F;
/* 389 */       if (fb < 0.0F) {
/* 390 */         fb = 0.0F;
/*     */       }
/* 392 */       if (this.lastFramesBehind != fb && (flags & 0x20) == 0) {
/*     */         
/* 394 */         this.moduleListener.framesBehind(this, fb, ic);
/* 395 */         this.lastFramesBehind = fb;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 402 */       if (!dataPrerolled) {
/*     */ 
/*     */         
/*     */         try {
/* 406 */           rc = this.multiplexer.process(buffer, idx);
/*     */         } catch (Throwable e) {
/*     */           
/* 409 */           Log.dumpStack(e);
/* 410 */           if (this.moduleListener != null) {
/* 411 */             this.moduleListener.internalErrorOccurred(this);
/*     */           }
/*     */         } 
/*     */         
/* 415 */         if (rc == 0 && format == this.firstVideoFormat)
/*     */         {
/* 417 */           if (format == this.rtpVideoFormat) {
/* 418 */             if ((flags & 0x800) > 0)
/* 419 */               this.framesPlayed++; 
/*     */           } else {
/* 421 */             this.framesPlayed++;
/*     */           } 
/*     */         }
/*     */       } else {
/* 425 */         rc = 0;
/*     */       } 
/*     */       
/* 428 */       if ((rc & 0x8) != 0) {
/* 429 */         this.failed = true;
/* 430 */         if (this.moduleListener != null)
/* 431 */           this.moduleListener.pluginTerminated(this); 
/* 432 */         ic.readReport();
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 438 */       if (!this.prefetching || (this.multiplexer instanceof Prefetchable && !((Prefetchable)this.multiplexer).isPrefetched())) {
/*     */         continue;
/*     */       }
/*     */       
/* 442 */       synchronized (this.prefetchSync) {
/* 443 */         if (!this.started && this.prefetching && !this.resetted)
/* 444 */           this.paused[idx] = true; 
/* 445 */         if (checkPrefetch(idx)) {
/* 446 */           this.prefetching = false;
/*     */         }
/*     */       } 
/*     */       
/* 450 */       if (this.prefetching || this.moduleListener == null)
/* 451 */         continue;  this.moduleListener.bufferPrefetched(this);
/*     */     
/*     */     }
/* 454 */     while (!this.resetted && rc == 2);
/*     */     
/* 456 */     this.bitsWritten += buffer.getLength();
/*     */     
/* 458 */     if (buffer.isEOM()) {
/*     */       
/* 460 */       if (!this.resetted) {
/* 461 */         this.paused[idx] = true;
/*     */       }
/* 463 */       if (checkEnd(idx)) {
/* 464 */         doStop();
/* 465 */         if (this.moduleListener != null) {
/* 466 */           this.moduleListener.mediaEnded(this);
/*     */         }
/*     */       } 
/*     */     } 
/* 470 */     ic.readReport();
/* 471 */     if (PlaybackEngine.DEBUG) this.jmd.moduleIn(this, 0, buffer, false); 
/*     */   }
/*     */   
/*     */   void resetPrefetchMarkers() {
/* 475 */     synchronized (this.prefetchMarkers) {
/* 476 */       for (int i = 0; i < this.prefetchMarkers.length; i++)
/* 477 */         this.prefetchMarkers[i] = false; 
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean checkPrefetch(int idx) {
/* 482 */     synchronized (this.prefetchMarkers) {
/* 483 */       this.prefetchMarkers[idx] = true;
/* 484 */       for (int i = 0; i < this.prefetchMarkers.length; i++) {
/* 485 */         if (!this.prefetchMarkers[i])
/* 486 */           return false; 
/*     */       } 
/* 488 */       return true;
/*     */     } 
/*     */   }
/*     */   
/*     */   void resetEndMarkers() {
/* 493 */     synchronized (this.endMarkers) {
/* 494 */       for (int i = 0; i < this.endMarkers.length; i++)
/* 495 */         this.endMarkers[i] = false; 
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean checkEnd(int idx) {
/* 500 */     synchronized (this.endMarkers) {
/* 501 */       this.endMarkers[idx] = true;
/* 502 */       for (int i = 0; i < this.endMarkers.length; i++) {
/* 503 */         if (!this.endMarkers[i])
/* 504 */           return false; 
/*     */       } 
/* 506 */       return true;
/*     */     } 
/*     */   }
/*     */   
/*     */   void resetResettedMarkers() {
/* 511 */     synchronized (this.resettedMarkers) {
/* 512 */       for (int i = 0; i < this.resettedMarkers.length; i++)
/* 513 */         this.resettedMarkers[i] = false; 
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean checkResetted(int idx) {
/* 518 */     synchronized (this.resettedMarkers) {
/* 519 */       this.resettedMarkers[idx] = true;
/* 520 */       for (int i = 0; i < this.resettedMarkers.length; i++) {
/* 521 */         if (!this.resettedMarkers[i])
/* 522 */           return false; 
/*     */       } 
/* 524 */       return true;
/*     */     } 
/*     */   }
/*     */   
/*     */   void resetStopAtTimeMarkers() {
/* 529 */     synchronized (this.stopAtTimeMarkers) {
/* 530 */       for (int i = 0; i < this.stopAtTimeMarkers.length; i++)
/* 531 */         this.stopAtTimeMarkers[i] = false; 
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean checkStopAtTime(int idx) {
/* 536 */     synchronized (this.stopAtTimeMarkers) {
/* 537 */       this.stopAtTimeMarkers[idx] = true;
/* 538 */       for (int i = 0; i < this.stopAtTimeMarkers.length; i++) {
/* 539 */         if (!this.stopAtTimeMarkers[i])
/* 540 */           return false; 
/*     */       } 
/* 542 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void process() {}
/*     */   
/*     */   public void reset() {
/* 550 */     super.reset();
/* 551 */     resetResettedMarkers();
/* 552 */     this.prefetching = false;
/*     */   }
/*     */   
/*     */   public void triggerReset() {
/* 556 */     this.multiplexer.reset();
/* 557 */     synchronized (this.prefetchSync) {
/* 558 */       this.prefetching = false;
/* 559 */       if (this.resetted)
/* 560 */         resume(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public DataSource getDataOutput() {
/* 565 */     return this.multiplexer.getDataOutput();
/*     */   }
/*     */   
/*     */   public Multiplexer getMultiplexer() {
/* 569 */     return this.multiplexer;
/*     */   }
/*     */   
/*     */   public Object[] getControls() {
/* 573 */     return this.multiplexer.getControls();
/*     */   }
/*     */   
/*     */   public Object getControl(String s) {
/* 577 */     return this.multiplexer.getControl(s);
/*     */   }
/*     */   
/*     */   public void setFormat(Connector connector, Format format) {
/* 581 */     if (format instanceof VideoFormat) {
/* 582 */       float fr = ((VideoFormat)format).getFrameRate();
/* 583 */       if (fr != -1.0F)
/* 584 */         this.frameRate = fr; 
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getFramesPlayed() {
/* 589 */     return this.framesPlayed;
/*     */   }
/*     */   
/*     */   public void resetFramesPlayed() {
/* 593 */     this.framesPlayed = 0;
/*     */   }
/*     */   
/*     */   public long getBitsWritten() {
/* 597 */     return this.bitsWritten;
/*     */   }
/*     */   
/*     */   public void resetBitsWritten() {
/* 601 */     this.bitsWritten = 0L;
/*     */   }
/*     */   
/*     */   class MyInputConnector extends BasicInputConnector { public MyInputConnector(BasicMuxModule this$0) {
/* 605 */       this.this$0 = this$0;
/*     */     }
/*     */     private final BasicMuxModule this$0;
/*     */     public String toString() {
/* 609 */       return super.toString() + ": " + getFormat();
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\BasicMuxModule.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */