package com.sun.media;

import com.sun.media.util.ElapseTime;
import javax.media.Buffer;
import javax.media.Clock;
import javax.media.Drainable;
import javax.media.Format;
import javax.media.Multiplexer;
import javax.media.Prefetchable;
import javax.media.ResourceUnavailableException;
import javax.media.format.AudioFormat;
import javax.media.format.VideoFormat;
import javax.media.protocol.DataSource;

public class BasicMuxModule extends BasicSinkModule {
  protected Multiplexer multiplexer;
  
  protected Format[] inputs;
  
  protected InputConnector[] ics;
  
  protected boolean[] prefetchMarkers;
  
  protected boolean[] endMarkers;
  
  protected boolean[] resettedMarkers;
  
  protected boolean[] stopAtTimeMarkers;
  
  protected boolean[] paused;
  
  protected boolean[] prerollTrack;
  
  private Object[] pauseSync;
  
  protected ElapseTime[] elapseTime;
  
  protected boolean prefetching = false;
  
  protected boolean started = false;
  
  private boolean closed = false;
  
  private boolean failed = false;
  
  private Object prefetchSync = new Object();
  
  private float frameRate = 30.0F;
  
  private float lastFramesBehind = -1.0F;
  
  private int framesPlayed = 0;
  
  private VideoFormat rtpVideoFormat = null;
  
  private VideoFormat firstVideoFormat = null;
  
  public static String ConnectorNamePrefix = "input";
  
  private long bitsWritten = 0L;
  
  static AudioFormat mpegAudio = new AudioFormat("mpegaudio/rtp");
  
  protected BasicMuxModule(Multiplexer m, Format[] inputs) {
    this.multiplexer = m;
    if (inputs != null) {
      this.ics = new InputConnector[inputs.length];
      for (int i = 0; i < inputs.length; i++) {
        InputConnector ic = new MyInputConnector(this);
        ic.setSize(1);
        ic.setModule(this);
        registerInputConnector(ConnectorNamePrefix + i, ic);
        this.ics[i] = ic;
        if (inputs[i] instanceof VideoFormat && this.firstVideoFormat == null) {
          this.firstVideoFormat = (VideoFormat)inputs[i];
          String encoding = inputs[i].getEncoding().toUpperCase();
          if (encoding.endsWith("RTP"))
            this.rtpVideoFormat = this.firstVideoFormat; 
        } 
      } 
      this.inputs = inputs;
    } 
    if (this.multiplexer != null && this.multiplexer instanceof Clock)
      setClock((Clock)this.multiplexer); 
    setProtocol(0);
  }
  
  public boolean isThreaded() {
    return false;
  }
  
  public boolean doRealize() {
    if (this.multiplexer == null || this.inputs == null)
      return false; 
    try {
      this.multiplexer.open();
    } catch (ResourceUnavailableException e) {
      return false;
    } 
    this.prefetchMarkers = new boolean[this.ics.length];
    this.endMarkers = new boolean[this.ics.length];
    this.resettedMarkers = new boolean[this.ics.length];
    this.stopAtTimeMarkers = new boolean[this.ics.length];
    this.paused = new boolean[this.ics.length];
    this.prerollTrack = new boolean[this.ics.length];
    this.pauseSync = new Object[this.ics.length];
    this.elapseTime = new ElapseTime[this.ics.length];
    for (int i = 0; i < this.ics.length; i++) {
      this.prerollTrack[i] = false;
      this.pauseSync[i] = new Object();
      this.elapseTime[i] = new ElapseTime();
    } 
    pause();
    return true;
  }
  
  public boolean doPrefetch() {
    if (!((PlaybackEngine)this.controller).prefetchEnabled)
      return true; 
    resetPrefetchMarkers();
    this.prefetching = true;
    resume();
    return true;
  }
  
  public void doFailedPrefetch() {
    this.prefetching = false;
  }
  
  public void abortPrefetch() {
    this.prefetching = false;
  }
  
  public void setPreroll(long wanted, long actual) {
    super.setPreroll(wanted, actual);
    for (int i = 0; i < this.elapseTime.length; i++) {
      this.elapseTime[i].setValue(actual);
      if (this.inputs[i] instanceof AudioFormat && mpegAudio.matches(this.inputs[i])) {
        this.prerollTrack[i] = false;
      } else {
        this.prerollTrack[i] = true;
      } 
    } 
  }
  
  public void doStart() {
    super.doStart();
    resetEndMarkers();
    resetStopAtTimeMarkers();
    this.started = true;
    synchronized (this.prefetchSync) {
      this.prefetching = false;
      resume();
    } 
  }
  
  public void doStop() {
    super.doStop();
    this.started = false;
    resetPrefetchMarkers();
    this.prefetching = true;
  }
  
  public void doDealloc() {}
  
  public void doClose() {
    this.multiplexer.close();
    this.closed = true;
    for (int i = 0; i < this.pauseSync.length; i++) {
      synchronized (this.pauseSync[i]) {
        this.pauseSync[i].notifyAll();
      } 
    } 
  }
  
  void pause() {
    for (int i = 0; i < this.paused.length; i++)
      this.paused[i] = true; 
  }
  
  void resume() {
    for (int i = 0; i < this.pauseSync.length; i++) {
      synchronized (this.pauseSync[i]) {
        this.paused[i] = false;
        this.pauseSync[i].notifyAll();
      } 
    } 
  }
  
  public void connectorPushed(InputConnector ic) {
    int idx = -1;
    if (this.ics[0] == ic) {
      idx = 0;
    } else if (this.ics[1] == ic) {
      idx = 1;
    } else {
      for (int i = 2; i < this.ics.length; i++) {
        if (this.ics[i] == ic) {
          idx = i;
          break;
        } 
      } 
      if (idx == -1)
        throw new RuntimeException("BasicMuxModule: unmatched input connector!"); 
    } 
    while (true) {
      if (this.paused[idx])
        synchronized (this.pauseSync[idx]) {
          try {
            while (this.paused[idx] && !this.closed)
              this.pauseSync[idx].wait(); 
          } catch (Exception e) {}
        }  
      if (this.stopTime > -1L && (this.elapseTime[idx]).value >= this.stopTime) {
        this.paused[idx] = true;
        if (checkStopAtTime(idx)) {
          if (this.multiplexer instanceof Drainable)
            ((Drainable)this.multiplexer).drain(); 
          doStop();
          if (this.moduleListener != null)
            this.moduleListener.stopAtTime(this); 
        } 
        continue;
      } 
      break;
    } 
    Buffer buffer = ic.getValidBuffer();
    int flags = buffer.getFlags();
    int rc = 0;
    if (this.resetted) {
      if ((flags & 0x200) != 0)
        if (checkResetted(idx)) {
          this.resetted = false;
          doStop();
          if (this.moduleListener != null)
            this.moduleListener.resetted(this); 
        }  
      ic.readReport();
      return;
    } 
    if (this.failed || this.closed || buffer.isDiscard()) {
      ic.readReport();
      return;
    } 
    if (PlaybackEngine.DEBUG)
      this.jmd.moduleIn(this, 0, buffer, true); 
    if ((flags & 0x400) != 0 && this.moduleListener != null) {
      this.moduleListener.markedDataArrived(this, buffer);
      flags &= 0xFFFFFBFF;
      buffer.setFlags(flags);
    } 
    boolean dataPrerolled = false;
    Format format = buffer.getFormat();
    if (format == null) {
      format = ic.getFormat();
      buffer.setFormat(format);
    } 
    if (this.elapseTime[idx].update(buffer.getLength(), buffer.getTimeStamp(), format)) {
      if (this.prerollTrack[idx]) {
        long target = getMediaNanoseconds();
        if ((this.elapseTime[idx]).value > target) {
          if (format instanceof AudioFormat && "LINEAR".equals(format.getEncoding())) {
            int remain = (int)ElapseTime.audioTimeToLen((this.elapseTime[idx]).value - target, (AudioFormat)format);
            int offset = buffer.getOffset() + buffer.getLength() - remain;
            if (offset >= 0) {
              buffer.setOffset(offset);
              buffer.setLength(remain);
            } 
          } 
          this.prerollTrack[idx] = false;
          this.elapseTime[idx].setValue(target);
        } else {
          dataPrerolled = true;
        } 
      } 
      if (this.stopTime > -1L && (this.elapseTime[idx]).value > this.stopTime && format instanceof AudioFormat) {
        long exceeded = (this.elapseTime[idx]).value - this.stopTime;
        int exceededLen = (int)ElapseTime.audioTimeToLen(exceeded, (AudioFormat)format);
        if (buffer.getLength() > exceededLen)
          buffer.setLength(buffer.getLength() - exceededLen); 
      } 
    } 
    if (this.moduleListener != null && format instanceof VideoFormat) {
      long mt = getMediaNanoseconds();
      long lateBy = mt / 1000000L - buffer.getTimeStamp() / 1000000L - getLatency() / 1000000L;
      float fb = (float)lateBy * this.frameRate / 1000.0F;
      if (fb < 0.0F)
        fb = 0.0F; 
      if (this.lastFramesBehind != fb && (flags & 0x20) == 0) {
        this.moduleListener.framesBehind(this, fb, ic);
        this.lastFramesBehind = fb;
      } 
    } 
    do {
      if (!dataPrerolled) {
        try {
          rc = this.multiplexer.process(buffer, idx);
        } catch (Throwable e) {
          Log.dumpStack(e);
          if (this.moduleListener != null)
            this.moduleListener.internalErrorOccurred(this); 
        } 
        if (rc == 0 && format == this.firstVideoFormat)
          if (format == this.rtpVideoFormat) {
            if ((flags & 0x800) > 0)
              this.framesPlayed++; 
          } else {
            this.framesPlayed++;
          }  
      } else {
        rc = 0;
      } 
      if ((rc & 0x8) != 0) {
        this.failed = true;
        if (this.moduleListener != null)
          this.moduleListener.pluginTerminated(this); 
        ic.readReport();
        return;
      } 
      if (!this.prefetching || (this.multiplexer instanceof Prefetchable && !((Prefetchable)this.multiplexer).isPrefetched()))
        continue; 
      synchronized (this.prefetchSync) {
        if (!this.started && this.prefetching && !this.resetted)
          this.paused[idx] = true; 
        if (checkPrefetch(idx))
          this.prefetching = false; 
      } 
      if (this.prefetching || this.moduleListener == null)
        continue; 
      this.moduleListener.bufferPrefetched(this);
    } while (!this.resetted && rc == 2);
    this.bitsWritten += buffer.getLength();
    if (buffer.isEOM()) {
      if (!this.resetted)
        this.paused[idx] = true; 
      if (checkEnd(idx)) {
        doStop();
        if (this.moduleListener != null)
          this.moduleListener.mediaEnded(this); 
      } 
    } 
    ic.readReport();
    if (PlaybackEngine.DEBUG)
      this.jmd.moduleIn(this, 0, buffer, false); 
  }
  
  void resetPrefetchMarkers() {
    synchronized (this.prefetchMarkers) {
      for (int i = 0; i < this.prefetchMarkers.length; i++)
        this.prefetchMarkers[i] = false; 
    } 
  }
  
  boolean checkPrefetch(int idx) {
    synchronized (this.prefetchMarkers) {
      this.prefetchMarkers[idx] = true;
      for (int i = 0; i < this.prefetchMarkers.length; i++) {
        if (!this.prefetchMarkers[i])
          return false; 
      } 
      return true;
    } 
  }
  
  void resetEndMarkers() {
    synchronized (this.endMarkers) {
      for (int i = 0; i < this.endMarkers.length; i++)
        this.endMarkers[i] = false; 
    } 
  }
  
  boolean checkEnd(int idx) {
    synchronized (this.endMarkers) {
      this.endMarkers[idx] = true;
      for (int i = 0; i < this.endMarkers.length; i++) {
        if (!this.endMarkers[i])
          return false; 
      } 
      return true;
    } 
  }
  
  void resetResettedMarkers() {
    synchronized (this.resettedMarkers) {
      for (int i = 0; i < this.resettedMarkers.length; i++)
        this.resettedMarkers[i] = false; 
    } 
  }
  
  boolean checkResetted(int idx) {
    synchronized (this.resettedMarkers) {
      this.resettedMarkers[idx] = true;
      for (int i = 0; i < this.resettedMarkers.length; i++) {
        if (!this.resettedMarkers[i])
          return false; 
      } 
      return true;
    } 
  }
  
  void resetStopAtTimeMarkers() {
    synchronized (this.stopAtTimeMarkers) {
      for (int i = 0; i < this.stopAtTimeMarkers.length; i++)
        this.stopAtTimeMarkers[i] = false; 
    } 
  }
  
  boolean checkStopAtTime(int idx) {
    synchronized (this.stopAtTimeMarkers) {
      this.stopAtTimeMarkers[idx] = true;
      for (int i = 0; i < this.stopAtTimeMarkers.length; i++) {
        if (!this.stopAtTimeMarkers[i])
          return false; 
      } 
      return true;
    } 
  }
  
  protected void process() {}
  
  public void reset() {
    super.reset();
    resetResettedMarkers();
    this.prefetching = false;
  }
  
  public void triggerReset() {
    this.multiplexer.reset();
    synchronized (this.prefetchSync) {
      this.prefetching = false;
      if (this.resetted)
        resume(); 
    } 
  }
  
  public DataSource getDataOutput() {
    return this.multiplexer.getDataOutput();
  }
  
  public Multiplexer getMultiplexer() {
    return this.multiplexer;
  }
  
  public Object[] getControls() {
    return this.multiplexer.getControls();
  }
  
  public Object getControl(String s) {
    return this.multiplexer.getControl(s);
  }
  
  public void setFormat(Connector connector, Format format) {
    if (format instanceof VideoFormat) {
      float fr = ((VideoFormat)format).getFrameRate();
      if (fr != -1.0F)
        this.frameRate = fr; 
    } 
  }
  
  public int getFramesPlayed() {
    return this.framesPlayed;
  }
  
  public void resetFramesPlayed() {
    this.framesPlayed = 0;
  }
  
  public long getBitsWritten() {
    return this.bitsWritten;
  }
  
  public void resetBitsWritten() {
    this.bitsWritten = 0L;
  }
  
  class MyInputConnector extends BasicInputConnector {
    private final BasicMuxModule this$0;
    
    public MyInputConnector(BasicMuxModule this$0) {
      this.this$0 = this$0;
    }
    
    public String toString() {
      return super.toString() + ": " + getFormat();
    }
  }
}
