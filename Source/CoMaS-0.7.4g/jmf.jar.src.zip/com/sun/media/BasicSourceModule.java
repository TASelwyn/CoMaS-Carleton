package com.sun.media;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import com.sun.media.rtp.util.RTPTimeBase;
import com.sun.media.util.MediaThread;
import com.sun.media.util.jdk12;
import com.sun.media.util.jdk12PriorityAction;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Vector;
import javax.media.BadHeaderException;
import javax.media.Demultiplexer;
import javax.media.Duration;
import javax.media.Format;
import javax.media.IncompatibleSourceException;
import javax.media.PlugInManager;
import javax.media.ResourceUnavailableException;
import javax.media.SystemTimeBase;
import javax.media.Time;
import javax.media.Track;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.DataSource;
import javax.media.protocol.Positionable;
import javax.media.protocol.PullDataSource;
import javax.media.protocol.PullSourceStream;
import javax.media.protocol.PushDataSource;
import javax.media.protocol.PushSourceStream;
import javax.media.protocol.SourceStream;

public class BasicSourceModule extends BasicModule implements Duration, Positionable {
  PlaybackEngine engine;
  
  protected DataSource source;
  
  protected Demultiplexer parser;
  
  protected Track[] tracks = new Track[0];
  
  protected SourceThread[] loops;
  
  protected String[] connectorNames;
  
  protected long bitsRead = 0L;
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] m = new Method[1];
  
  private Class[] cl = new Class[1];
  
  private Object[][] args = new Object[1][0];
  
  Object resetSync = new Object();
  
  protected boolean started = false;
  
  protected SystemTimeBase systemTimeBase = new SystemTimeBase();
  
  protected long lastSystemTime = 0L;
  
  protected long originSystemTime = 0L;
  
  protected long currentSystemTime = 0L;
  
  protected Time lastPositionSet = new Time(0L);
  
  RTPTimeBase rtpMapperUpdatable = null;
  
  RTPTimeBase rtpMapper = null;
  
  long currentRTPTime = 0L;
  
  long oldOffset = 0L;
  
  boolean rtpOffsetInvalid = true;
  
  String cname = null;
  
  public String errMsg;
  
  int latencyTrack;
  
  static {
    try {
      jmfSecurity = JMFSecurityManager.getJMFSecurity();
      securityPrivelege = true;
    } catch (SecurityException e) {}
  }
  
  public static BasicSourceModule createModule(DataSource ds) throws IOException, IncompatibleSourceException {
    Demultiplexer parser = createDemultiplexer(ds);
    if (parser == null)
      return null; 
    return new BasicSourceModule(ds, parser);
  }
  
  protected static Demultiplexer createDemultiplexer(DataSource ds) throws IOException, IncompatibleSourceException {
    ContentDescriptor cd = new ContentDescriptor(ds.getContentType());
    Vector cnames = PlugInManager.getPlugInList((Format)cd, null, 1);
    Demultiplexer parser = null;
    IOException ioe = null;
    IncompatibleSourceException ise = null;
    for (int i = 0; i < cnames.size(); i++) {
      try {
        Class cls = BasicPlugIn.getClassForName(cnames.elementAt(i));
        Object p = cls.newInstance();
        if (p instanceof Demultiplexer) {
          parser = (Demultiplexer)p;
          try {
            parser.setSource(ds);
            break;
          } catch (IOException e) {
            parser = null;
            ioe = e;
          } catch (IncompatibleSourceException e) {
            parser = null;
            ise = e;
          } 
        } 
      } catch (ClassNotFoundException e) {
      
      } catch (InstantiationException e) {
      
      } catch (IllegalAccessException e) {}
    } 
    if (parser == null) {
      if (ioe != null)
        throw ioe; 
      if (ise != null)
        throw ise; 
    } 
    return parser;
  }
  
  protected BasicSourceModule(DataSource ds, Demultiplexer demux) {
    this.errMsg = null;
    this.latencyTrack = -1;
    this.source = ds;
    this.parser = demux;
    SourceStream stream = null;
    if (this.source instanceof PullDataSource) {
      PullSourceStream pullSourceStream = ((PullDataSource)this.source).getStreams()[0];
    } else if (this.source instanceof PushDataSource) {
      PushSourceStream pushSourceStream = ((PushDataSource)this.source).getStreams()[0];
    } 
  }
  
  public boolean doRealize() {
    try {
      this.parser.open();
    } catch (ResourceUnavailableException e) {
      this.errMsg = "Resource unavailable: " + e.getMessage();
      return false;
    } 
    try {
      this.parser.start();
      this.tracks = this.parser.getTracks();
    } catch (BadHeaderException e) {
      this.errMsg = "Bad header in the media: " + e.getMessage();
      this.parser.close();
      return false;
    } catch (IOException e) {
      this.errMsg = "IO exception: " + e.getMessage();
      this.parser.close();
      return false;
    } 
    if (this.tracks == null || this.tracks.length == 0) {
      this.errMsg = "The media has 0 track";
      this.parser.close();
      return false;
    } 
    if (jmfSecurity != null) {
      String permission = null;
      try {
        if (jmfSecurity.getName().startsWith("jmf-security")) {
          permission = "thread";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
          this.m[0].invoke(this.cl[0], this.args[0]);
          permission = "thread group";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
          this.m[0].invoke(this.cl[0], this.args[0]);
        } else if (jmfSecurity.getName().startsWith("internet")) {
          PolicyEngine.checkPermission(PermissionID.THREAD);
          PolicyEngine.assertPermission(PermissionID.THREAD);
        } 
      } catch (Exception e) {
        securityPrivelege = false;
      } 
    } 
    this.loops = new SourceThread[this.tracks.length];
    this.connectorNames = new String[this.tracks.length];
    for (int i = 0; i < this.tracks.length; i++) {
      MyOutputConnector oc = new MyOutputConnector(this.tracks[i]);
      oc.setProtocol(0);
      oc.setSize(1);
      this.connectorNames[i] = this.tracks[i].toString();
      registerOutputConnector(this.tracks[i].toString(), oc);
      this.loops[i] = null;
    } 
    this.engine = (PlaybackEngine)getController();
    if (this.engine == null || !this.engine.isRTP())
      this.parser.stop(); 
    return true;
  }
  
  SourceThread createSourceThread(int idx) {
    SourceThread thread = null;
    MyOutputConnector oc = (MyOutputConnector)getOutputConnector(this.connectorNames[idx]);
    if (oc == null || oc.getInputConnector() == null) {
      this.tracks[idx].setEnabled(false);
      return null;
    } 
    if (jmfSecurity != null) {
      String permission = null;
      try {
        if (jmfSecurity.getName().startsWith("jmf-security")) {
          permission = "thread";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
          this.m[0].invoke(this.cl[0], this.args[0]);
          permission = "thread group";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
          this.m[0].invoke(this.cl[0], this.args[0]);
        } else if (jmfSecurity.getName().startsWith("internet")) {
          PolicyEngine.checkPermission(PermissionID.THREAD);
          PolicyEngine.assertPermission(PermissionID.THREAD);
        } 
      } catch (Throwable e) {
        securityPrivelege = false;
      } 
    } 
    if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
      try {
        int i;
        Constructor cons = CreateSourceThreadAction.cons;
        Constructor pcons = jdk12PriorityAction.cons;
        thread = (SourceThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { SourceThread.class, this, oc, new Integer(idx) }) });
        if (this.tracks[idx].getFormat() instanceof javax.media.format.AudioFormat) {
          i = MediaThread.getAudioPriority();
        } else {
          i = MediaThread.getVideoPriority();
        } 
        thread.useVideoPriority();
        jdk12.doPrivM.invoke(jdk12.ac, new Object[] { pcons.newInstance(new Object[] { thread, new Integer(i) }) });
      } catch (Exception e) {
        thread = null;
      } 
    } else {
      thread = new SourceThread(this, oc, idx);
      if (this.tracks[idx].getFormat() instanceof javax.media.format.AudioFormat) {
        thread.useAudioPriority();
      } else {
        thread.useVideoPriority();
      } 
    } 
    if (thread == null)
      this.tracks[idx].setEnabled(false); 
    return thread;
  }
  
  public void doFailedRealize() {
    this.parser.stop();
    this.parser.close();
  }
  
  public void abortRealize() {
    this.parser.stop();
    this.parser.close();
  }
  
  public boolean doPrefetch() {
    super.doPrefetch();
    return true;
  }
  
  public void doFailedPrefetch() {}
  
  public void abortPrefetch() {
    doStop();
  }
  
  public void doStart() {
    this.lastSystemTime = this.systemTimeBase.getNanoseconds();
    this.originSystemTime = this.currentSystemTime;
    this.rtpOffsetInvalid = true;
    super.doStart();
    try {
      this.parser.start();
    } catch (IOException e) {}
    for (int i = 0; i < this.loops.length; i++) {
      this.loops[i] = createSourceThread(i);
      if (this.tracks[i].isEnabled() && (this.loops[i] != null || createSourceThread(i) != null))
        this.loops[i].start(); 
    } 
    this.started = true;
  }
  
  public void doStop() {
    this.started = false;
  }
  
  public void pause() {
    synchronized (this.resetSync) {
      for (int i = 0; i < this.loops.length; i++) {
        if (this.tracks[i].isEnabled() && this.loops[i] != null && !(this.loops[i]).resetted)
          this.loops[i].pause(); 
      } 
      this.parser.stop();
    } 
  }
  
  public void doDealloc() {}
  
  public void doClose() {
    this.parser.close();
    if (this.tracks == null)
      return; 
    for (int i = 0; i < this.tracks.length; i++) {
      if (this.loops[i] != null)
        this.loops[i].kill(); 
    } 
    if (this.rtpMapperUpdatable != null) {
      RTPTimeBase.returnMapperUpdatable(this.rtpMapperUpdatable);
      this.rtpMapperUpdatable = null;
    } 
  }
  
  public void reset() {
    synchronized (this.resetSync) {
      super.reset();
      for (int i = 0; i < this.loops.length; i++) {
        this.loops[i] = createSourceThread(i);
        if (this.tracks[i].isEnabled() && (this.loops[i] != null || createSourceThread(i) != null)) {
          (this.loops[i]).resetted = true;
          this.loops[i].start();
        } 
      } 
    } 
  }
  
  public String[] getOutputConnectorNames() {
    return this.connectorNames;
  }
  
  public Time getDuration() {
    return this.parser.getDuration();
  }
  
  public Time setPosition(Time when, int rounding) {
    Time t = this.parser.setPosition(when, rounding);
    if (this.lastPositionSet.getNanoseconds() == t.getNanoseconds()) {
      this.lastPositionSet = new Time(t.getNanoseconds() + 1L);
    } else {
      this.lastPositionSet = t;
    } 
    return t;
  }
  
  public boolean isPositionable() {
    return this.parser.isPositionable();
  }
  
  public boolean isRandomAccess() {
    return this.parser.isRandomAccess();
  }
  
  public Object[] getControls() {
    return this.parser.getControls();
  }
  
  public Object getControl(String s) {
    return this.parser.getControl(s);
  }
  
  public Demultiplexer getDemultiplexer() {
    return this.parser;
  }
  
  public void setFormat(Connector connector, Format format) {}
  
  public void process() {}
  
  public long getBitsRead() {
    return this.bitsRead;
  }
  
  public void resetBitsRead() {
    this.bitsRead = 0L;
  }
  
  boolean readHasBlocked() {
    if (this.loops == null)
      return false; 
    for (int i = 0; i < this.loops.length; i++) {
      if (this.loops[i] != null && (this.loops[i]).readBlocked)
        return true; 
    } 
    return false;
  }
  
  public void checkLatency() {
    if (this.latencyTrack > -1) {
      if (this.tracks[this.latencyTrack].isEnabled() && this.loops[this.latencyTrack] != null) {
        (this.loops[this.latencyTrack]).checkLatency = true;
        return;
      } 
      this.latencyTrack = -1;
    } 
    for (int i = 0; i < this.tracks.length; i++) {
      if (this.tracks[i].isEnabled()) {
        this.latencyTrack = i;
        if (this.tracks[i].getFormat() instanceof javax.media.format.VideoFormat)
          break; 
      } 
    } 
    if (this.latencyTrack > -1 && this.loops[this.latencyTrack] != null)
      (this.loops[this.latencyTrack]).checkLatency = true; 
  }
  
  protected boolean checkAllPaused() {
    for (int i = 0; i < this.loops.length; i++) {
      if (this.tracks[i].isEnabled() && this.loops[i] != null && !this.loops[i].isPaused())
        return false; 
    } 
    return true;
  }
}
