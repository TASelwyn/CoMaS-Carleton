package com.sun.media;

import javax.media.Format;

public interface Connector {
  public static final int ProtocolPush = 0;
  
  public static final int ProtocolSafe = 1;
  
  void setFormat(Format paramFormat);
  
  Format getFormat();
  
  void setSize(int paramInt);
  
  int getSize();
  
  void reset();
  
  String getName();
  
  void setName(String paramString);
  
  void setProtocol(int paramInt);
  
  int getProtocol();
  
  Object getCircularBuffer();
  
  void setCircularBuffer(Object paramObject);
  
  void setModule(Module paramModule);
  
  Module getModule();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\Connector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */