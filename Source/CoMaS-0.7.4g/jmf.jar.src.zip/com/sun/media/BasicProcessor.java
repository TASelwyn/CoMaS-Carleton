package com.sun.media;

import javax.media.NotConfiguredError;
import javax.media.NotRealizedError;
import javax.media.Processor;
import javax.media.control.TrackControl;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.DataSource;

public abstract class BasicProcessor extends BasicPlayer implements Processor {
  static String NOT_CONFIGURED_ERROR = "cannot be called before the Processor is configured";
  
  protected boolean isConfigurable() {
    return true;
  }
  
  public TrackControl[] getTrackControls() throws NotConfiguredError {
    if (getState() < 180)
      throw new NotConfiguredError("getTrackControls " + NOT_CONFIGURED_ERROR); 
    return new TrackControl[0];
  }
  
  public ContentDescriptor[] getSupportedContentDescriptors() throws NotConfiguredError {
    if (getState() < 180)
      throw new NotConfiguredError("getSupportedContentDescriptors " + NOT_CONFIGURED_ERROR); 
    return new ContentDescriptor[0];
  }
  
  public ContentDescriptor setContentDescriptor(ContentDescriptor ocd) throws NotConfiguredError {
    if (getState() < 180)
      throw new NotConfiguredError("setContentDescriptor " + NOT_CONFIGURED_ERROR); 
    return ocd;
  }
  
  public ContentDescriptor getContentDescriptor() throws NotConfiguredError {
    if (getState() < 180)
      throw new NotConfiguredError("getContentDescriptor " + NOT_CONFIGURED_ERROR); 
    return null;
  }
  
  public DataSource getDataOutput() throws NotRealizedError {
    if (getState() < 300)
      throw new NotRealizedError("getDataOutput cannot be called before the Processor is realized"); 
    return null;
  }
}
