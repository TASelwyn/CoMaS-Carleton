package com.sun.media;

import javax.media.Format;

public abstract class BasicConnector implements Connector {
  protected Module module = null;
  
  protected int minSize = 1;
  
  protected Format format = null;
  
  protected CircularBuffer circularBuffer = null;
  
  protected String name = null;
  
  protected int protocol = 0;
  
  public Object getCircularBuffer() {
    return this.circularBuffer;
  }
  
  public void setCircularBuffer(Object cicularBuffer) {
    this.circularBuffer = (CircularBuffer)cicularBuffer;
  }
  
  public void setFormat(Format format) {
    this.module.setFormat(this, format);
    this.format = format;
  }
  
  public Format getFormat() {
    return this.format;
  }
  
  public Module getModule() {
    return this.module;
  }
  
  public void setModule(Module module) {
    this.module = module;
  }
  
  public void setSize(int numOfBufferObjects) {
    this.minSize = numOfBufferObjects;
  }
  
  public int getSize() {
    return this.minSize;
  }
  
  public void reset() {
    this.circularBuffer.reset();
  }
  
  public String getName() {
    return this.name;
  }
  
  public void setName(String name) {
    this.name = name;
  }
  
  public void setProtocol(int protocol) {
    this.protocol = protocol;
  }
  
  public int getProtocol() {
    return this.protocol;
  }
  
  public void print() {
    this.circularBuffer.print();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\BasicConnector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */