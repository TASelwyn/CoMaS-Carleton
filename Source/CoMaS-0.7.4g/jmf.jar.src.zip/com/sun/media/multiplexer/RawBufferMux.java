package com.sun.media.multiplexer;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import com.sun.media.BasicClock;
import com.sun.media.BasicPlugIn;
import com.sun.media.CircularBuffer;
import com.sun.media.JMFSecurity;
import com.sun.media.JMFSecurityManager;
import com.sun.media.MediaTimeBase;
import com.sun.media.controls.MonitorAdapter;
import com.sun.media.protocol.BasicPushBufferDataSource;
import com.sun.media.protocol.BasicSourceStream;
import com.sun.media.util.MediaThread;
import com.sun.media.util.jdk12;
import com.sun.media.util.jdk12CreateThreadRunnableAction;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import javax.media.Buffer;
import javax.media.Clock;
import javax.media.ClockStoppedException;
import javax.media.Format;
import javax.media.IncompatibleTimeBaseException;
import javax.media.Multiplexer;
import javax.media.ResourceUnavailableException;
import javax.media.Time;
import javax.media.TimeBase;
import javax.media.format.AudioFormat;
import javax.media.format.VideoFormat;
import javax.media.protocol.BufferTransferHandler;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.DataSource;
import javax.media.protocol.PushBufferStream;

public class RawBufferMux extends BasicPlugIn implements Multiplexer, Clock {
  protected ContentDescriptor[] supported = null;
  
  protected ContentDescriptor contentDesc = null;
  
  protected RawBufferDataSource source = null;
  
  protected RawBufferSourceStream[] streams = null;
  
  protected BasicClock clock = null;
  
  protected RawMuxTimeBase timeBase = null;
  
  protected long[] mediaTime;
  
  protected int masterTrackID = -1;
  
  boolean sourceDisconnected = false;
  
  boolean allowDrop = false;
  
  boolean hasRead = false;
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] m = new Method[1];
  
  private Class[] cl = new Class[1];
  
  private Object[][] args = new Object[1][0];
  
  protected int numTracks = 0;
  
  protected Format[] trackFormats;
  
  protected MonitorAdapter[] mc = null;
  
  static AudioFormat mpegAudio = new AudioFormat("mpegaudio/rtp");
  
  Object timeSetSync;
  
  boolean started;
  
  long systemStartTime;
  
  long mediaStartTime;
  
  static {
    try {
      jmfSecurity = JMFSecurityManager.getJMFSecurity();
      securityPrivelege = true;
    } catch (SecurityException e) {}
  }
  
  public String getName() {
    return "Raw Buffer Multiplexer";
  }
  
  public void open() throws ResourceUnavailableException {
    initializeTracks(this.trackFormats);
    if (this.source == null || this.source.getStreams() == null)
      throw new ResourceUnavailableException("DataSource and SourceStreams were not created succesfully."); 
    try {
      this.source.connect();
    } catch (IOException e) {
      throw new ResourceUnavailableException(e.getMessage());
    } 
    int len = 0;
    this.mediaTime = new long[this.trackFormats.length];
    this.mc = new MonitorAdapter[this.trackFormats.length];
    int i;
    for (i = 0; i < this.trackFormats.length; i++) {
      this.mediaTime[i] = 0L;
      if (this.trackFormats[i] instanceof VideoFormat || this.trackFormats[i] instanceof AudioFormat) {
        this.mc[i] = new MonitorAdapter(this.trackFormats[i], this);
        if (this.mc[i] != null)
          len++; 
      } 
    } 
    int j = 0;
    this.controls = (Object[])new javax.media.Control[len];
    for (i = 0; i < this.mc.length; i++) {
      if (this.mc[i] != null)
        this.controls[j++] = this.mc[i]; 
    } 
  }
  
  public void close() {
    if (this.source != null) {
      try {
        this.source.stop();
        this.source.disconnect();
      } catch (IOException e) {}
      this.source = null;
    } 
    for (int i = 0; i < this.mc.length; i++) {
      if (this.mc[i] != null)
        this.mc[i].close(); 
    } 
  }
  
  public void reset() {
    for (int i = 0; i < this.streams.length; i++) {
      this.streams[i].reset();
      if (this.mc[i] != null)
        this.mc[i].reset(); 
    } 
  }
  
  public ContentDescriptor[] getSupportedOutputContentDescriptors(Format[] fmt) {
    return this.supported;
  }
  
  public Format[] getSupportedInputFormats() {
    return new Format[] { (Format)new AudioFormat(null), (Format)new VideoFormat(null) };
  }
  
  public DataSource getDataOutput() {
    return (DataSource)this.source;
  }
  
  public int setNumTracks(int nTracks) {
    this.numTracks = nTracks;
    this.trackFormats = new Format[nTracks];
    for (int i = 0; i < nTracks; i++)
      this.trackFormats[i] = null; 
    return nTracks;
  }
  
  public Format setInputFormat(Format input, int trackID) {
    if (trackID < this.numTracks)
      this.trackFormats[trackID] = input; 
    for (int i = 0; i < this.numTracks; i++) {
      if (this.trackFormats[i] == null)
        return input; 
    } 
    return input;
  }
  
  public boolean initializeTracks(Format[] trackFormats) {
    if (this.source.getStreams() != null)
      throw new Error("initializeTracks has been called previously. "); 
    this.source.initialize(trackFormats);
    this.streams = (RawBufferSourceStream[])this.source.getStreams();
    return true;
  }
  
  public int process(Buffer buffer, int trackID) {
    if ((buffer.getFlags() & 0x1000) != 0)
      buffer.setFlags(buffer.getFlags() & 0xFFFFEFFF | 0x100); 
    if (this.mc[trackID] != null && this.mc[trackID].isEnabled())
      this.mc[trackID].process(buffer); 
    if (this.streams == null || buffer == null || trackID >= this.streams.length)
      return 1; 
    updateTime(buffer, trackID);
    return this.streams[trackID].process(buffer);
  }
  
  protected void updateTime(Buffer buf, int trackID) {
    if (buf.getFormat() instanceof AudioFormat) {
      if (mpegAudio.matches(buf.getFormat())) {
        if (buf.getTimeStamp() < 0L) {
          if (this.systemStartTime >= 0L)
            this.mediaTime[trackID] = (this.mediaStartTime + System.currentTimeMillis() - this.systemStartTime) * 1000000L; 
        } else {
          this.mediaTime[trackID] = buf.getTimeStamp();
        } 
      } else {
        long t = ((AudioFormat)buf.getFormat()).computeDuration(buf.getLength());
        if (t >= 0L) {
          this.mediaTime[trackID] = this.mediaTime[trackID] + t;
        } else {
          this.mediaTime[trackID] = buf.getTimeStamp();
        } 
      } 
    } else if (buf.getTimeStamp() < 0L) {
      if (this.systemStartTime >= 0L)
        this.mediaTime[trackID] = (this.mediaStartTime + System.currentTimeMillis() - this.systemStartTime) * 1000000L; 
    } else {
      this.mediaTime[trackID] = buf.getTimeStamp();
    } 
    this.timeBase.update();
  }
  
  public ContentDescriptor setContentDescriptor(ContentDescriptor outputContentDescriptor) {
    if (BasicPlugIn.matches((Format)outputContentDescriptor, (Format[])this.supported) == null)
      return null; 
    this.contentDesc = outputContentDescriptor;
    this.source = new RawBufferDataSource(this);
    return this.contentDesc;
  }
  
  public RawBufferMux() {
    this.timeSetSync = new Object();
    this.started = false;
    this.systemStartTime = -1L;
    this.mediaStartTime = -1L;
    this.supported = new ContentDescriptor[1];
    this.supported[0] = new ContentDescriptor("raw");
    this.timeBase = new RawMuxTimeBase(this);
    this.clock = new BasicClock();
    try {
      this.clock.setTimeBase((TimeBase)this.timeBase);
    } catch (Exception e) {}
  }
  
  public void setTimeBase(TimeBase master) throws IncompatibleTimeBaseException {
    if (master != this.timeBase)
      throw new IncompatibleTimeBaseException(); 
  }
  
  public void syncStart(Time at) {
    synchronized (this.timeSetSync) {
      if (this.started)
        return; 
      this.started = true;
      this.clock.syncStart(at);
      this.timeBase.mediaStarted();
      this.systemStartTime = System.currentTimeMillis();
      this.mediaStartTime = getMediaNanoseconds() / 1000000L;
    } 
  }
  
  public void stop() {
    synchronized (this.timeSetSync) {
      if (!this.started)
        return; 
      this.started = false;
      this.clock.stop();
      this.timeBase.mediaStopped();
    } 
  }
  
  public void setStopTime(Time stopTime) {
    this.clock.setStopTime(stopTime);
  }
  
  public Time getStopTime() {
    return this.clock.getStopTime();
  }
  
  public void setMediaTime(Time now) {
    synchronized (this.timeSetSync) {
      this.clock.setMediaTime(now);
      for (int i = 0; i < this.mediaTime.length; i++)
        this.mediaTime[i] = now.getNanoseconds(); 
      this.timeBase.update();
      this.systemStartTime = System.currentTimeMillis();
      this.mediaStartTime = now.getNanoseconds() / 1000000L;
    } 
  }
  
  public Time getMediaTime() {
    return this.clock.getMediaTime();
  }
  
  public long getMediaNanoseconds() {
    return this.clock.getMediaNanoseconds();
  }
  
  public Time getSyncTime() {
    return this.clock.getSyncTime();
  }
  
  public TimeBase getTimeBase() {
    return this.clock.getTimeBase();
  }
  
  public Time mapToTimeBase(Time t) throws ClockStoppedException {
    return this.clock.mapToTimeBase(t);
  }
  
  public float getRate() {
    return this.clock.getRate();
  }
  
  public float setRate(float factor) {
    if (factor == this.clock.getRate())
      return factor; 
    return this.clock.setRate(1.0F);
  }
  
  class RawMuxTimeBase extends MediaTimeBase {
    long ticks;
    
    boolean updated;
    
    private final RawBufferMux this$0;
    
    RawMuxTimeBase(RawBufferMux this$0) {
      this.this$0 = this$0;
      this.ticks = 0L;
      this.updated = false;
    }
    
    public long getMediaTime() {
      if (this.this$0.masterTrackID >= 0)
        return this.this$0.mediaTime[this.this$0.masterTrackID]; 
      if (!this.updated)
        return this.ticks; 
      if (this.this$0.mediaTime.length == 1) {
        this.ticks = this.this$0.mediaTime[0];
      } else {
        this.ticks = this.this$0.mediaTime[0];
        for (int i = 1; i < this.this$0.mediaTime.length; i++) {
          if (this.this$0.mediaTime[i] < this.ticks)
            this.ticks = this.this$0.mediaTime[i]; 
        } 
      } 
      this.updated = false;
      return this.ticks;
    }
    
    public void update() {
      this.updated = true;
    }
  }
  
  class RawBufferDataSource extends BasicPushBufferDataSource {
    private final RawBufferMux this$0;
    
    public RawBufferDataSource(RawBufferMux this$0) {
      this.this$0 = this$0;
      if (this$0.contentDesc == null)
        return; 
      this.contentType = this$0.contentDesc.getContentType();
    }
    
    public PushBufferStream[] getStreams() {
      return (PushBufferStream[])this.this$0.streams;
    }
    
    public void start() throws IOException {
      super.start();
      for (int i = 0; i < this.this$0.streams.length; i++)
        this.this$0.streams[i].start(); 
    }
    
    public void stop() throws IOException {
      super.stop();
      for (int i = 0; i < this.this$0.streams.length; i++)
        this.this$0.streams[i].stop(); 
    }
    
    public void connect() throws IOException {
      super.connect();
      this.this$0.sourceDisconnected = false;
    }
    
    public void disconnect() {
      super.disconnect();
      this.this$0.sourceDisconnected = true;
      for (int i = 0; i < this.this$0.streams.length; i++) {
        this.this$0.streams[i].stop();
        this.this$0.streams[i].close();
      } 
    }
    
    private void initialize(Format[] trackFormats) {
      this.this$0.streams = new RawBufferMux.RawBufferSourceStream[trackFormats.length];
      for (int i = 0; i < trackFormats.length; i++)
        this.this$0.streams[i] = new RawBufferMux.RawBufferSourceStream(this.this$0, trackFormats[i]); 
    }
  }
  
  class RawBufferSourceStream extends BasicSourceStream implements PushBufferStream, Runnable {
    Format format;
    
    CircularBuffer bufferQ;
    
    boolean started;
    
    Object startReq;
    
    BufferTransferHandler handler;
    
    Thread streamThread;
    
    boolean closed;
    
    boolean draining;
    
    Object drainSync;
    
    private final RawBufferMux this$0;
    
    public RawBufferSourceStream(RawBufferMux this$0, Format fmt) {
      this.this$0 = this$0;
      this.format = null;
      this.started = false;
      this.startReq = new Integer(0);
      this.handler = null;
      this.streamThread = null;
      this.closed = false;
      this.draining = false;
      this.drainSync = new Object();
      this.contentDescriptor = this$0.contentDesc;
      this.format = fmt;
      this.bufferQ = new CircularBuffer(5);
      if (RawBufferMux.jmfSecurity != null) {
        String permission = null;
        try {
          if (RawBufferMux.jmfSecurity.getName().startsWith("jmf-security")) {
            permission = "thread";
            RawBufferMux.jmfSecurity.requestPermission(this$0.m, this$0.cl, this$0.args, 16);
            this$0.m[0].invoke(this$0.cl[0], this$0.args[0]);
            permission = "thread group";
            RawBufferMux.jmfSecurity.requestPermission(this$0.m, this$0.cl, this$0.args, 32);
            this$0.m[0].invoke(this$0.cl[0], this$0.args[0]);
          } else if (RawBufferMux.jmfSecurity.getName().startsWith("internet")) {
            PolicyEngine.checkPermission(PermissionID.THREAD);
            PolicyEngine.assertPermission(PermissionID.THREAD);
          } 
        } catch (Throwable e) {
          RawBufferMux.securityPrivelege = false;
        } 
      } 
      if (RawBufferMux.jmfSecurity != null && RawBufferMux.jmfSecurity.getName().startsWith("jdk12")) {
        RawBufferSourceStream rbss = this;
        try {
          Constructor cons = jdk12CreateThreadRunnableAction.cons;
          this.streamThread = (Thread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { MediaThread.class, this }) });
        } catch (Exception e) {}
      } else {
        this.streamThread = (Thread)new MediaThread(this, "RawBufferStream Thread");
      } 
      if (this.streamThread != null)
        this.streamThread.start(); 
    }
    
    public Format getFormat() {
      return this.format;
    }
    
    public void setTransferHandler(BufferTransferHandler handler) {
      this.handler = handler;
    }
    
    public void read(Buffer buffer) throws IOException {
      if (this.closed)
        throw new IOException("The source stream is closed"); 
      Buffer current = null;
      synchronized (this.bufferQ) {
        while (!this.bufferQ.canRead()) {
          try {
            this.bufferQ.wait();
          } catch (Exception e) {}
        } 
        current = this.bufferQ.read();
      } 
      if (current.isEOM())
        synchronized (this.drainSync) {
          if (this.draining) {
            this.draining = false;
            this.drainSync.notifyAll();
          } 
        }  
      Object data = buffer.getData();
      Object hdr = buffer.getHeader();
      buffer.copy(current);
      current.setData(data);
      current.setHeader(hdr);
      synchronized (this.bufferQ) {
        this.this$0.hasRead = true;
        this.bufferQ.readReport();
        this.bufferQ.notifyAll();
      } 
    }
    
    protected void start() {
      synchronized (this.startReq) {
        if (this.started)
          return; 
        this.started = true;
        this.startReq.notifyAll();
      } 
      synchronized (this.bufferQ) {
        this.this$0.hasRead = true;
        this.bufferQ.notifyAll();
      } 
    }
    
    protected void stop() {
      synchronized (this.startReq) {
        this.started = false;
      } 
      synchronized (this.bufferQ) {
        this.bufferQ.notifyAll();
      } 
    }
    
    protected void close() {
      this.closed = true;
      if (this.streamThread != null)
        try {
          reset();
          synchronized (this.startReq) {
            this.startReq.notifyAll();
          } 
        } catch (Exception e) {} 
    }
    
    protected void reset() {
      synchronized (this.bufferQ) {
        while (this.bufferQ.canRead()) {
          Buffer b = this.bufferQ.read();
          this.bufferQ.readReport();
        } 
        this.bufferQ.notifyAll();
      } 
      synchronized (this.drainSync) {
        if (this.draining) {
          this.draining = false;
          this.drainSync.notifyAll();
        } 
      } 
    }
    
    protected int process(Buffer filled) {
      Buffer buffer;
      synchronized (this.bufferQ) {
        if (this.this$0.allowDrop)
          if (!this.bufferQ.canWrite() && this.bufferQ.canRead()) {
            Buffer tmp = this.bufferQ.peek();
            if ((tmp.getFlags() & 0x20) == 0) {
              this.bufferQ.read();
              this.bufferQ.readReport();
            } 
          }  
        while (!this.bufferQ.canWrite() && !this.closed) {
          try {
            this.bufferQ.wait();
          } catch (Exception e) {}
        } 
        if (this.closed)
          return 0; 
        buffer = this.bufferQ.getEmptyBuffer();
      } 
      Object bdata = buffer.getData();
      Object bheader = buffer.getHeader();
      buffer.setData(filled.getData());
      buffer.setHeader(filled.getHeader());
      filled.setData(bdata);
      filled.setHeader(bheader);
      buffer.setLength(filled.getLength());
      buffer.setEOM(filled.isEOM());
      buffer.setFlags(filled.getFlags());
      buffer.setTimeStamp(filled.getTimeStamp());
      buffer.setFormat(filled.getFormat());
      buffer.setOffset(filled.getOffset());
      buffer.setSequenceNumber(filled.getSequenceNumber());
      if (filled.isEOM())
        this.draining = true; 
      synchronized (this.bufferQ) {
        this.bufferQ.writeReport();
        this.bufferQ.notifyAll();
      } 
      if (filled.isEOM())
        synchronized (this.drainSync) {
          try {
            if (this.draining)
              this.drainSync.wait(3000L); 
          } catch (Exception e) {}
        }  
      return 0;
    }
    
    public void run() {
      try {
        while (true) {
          synchronized (this.startReq) {
            while (!this.started && !this.closed)
              this.startReq.wait(); 
          } 
          synchronized (this.bufferQ) {
            do {
              if (!this.this$0.hasRead)
                this.bufferQ.wait(250L); 
              this.this$0.hasRead = false;
            } while (!this.bufferQ.canRead() && !this.closed && this.started);
          } 
          if (this.closed)
            return; 
          if (!this.started)
            continue; 
          if (this.handler != null)
            this.handler.transferData(this); 
        } 
      } catch (InterruptedException e) {
        System.err.println("Thread " + e.getMessage());
        return;
      } 
    }
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\multiplexer\RawBufferMux.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */