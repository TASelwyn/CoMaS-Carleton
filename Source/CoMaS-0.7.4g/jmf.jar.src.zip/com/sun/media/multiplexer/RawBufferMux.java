/*     */ package com.sun.media.multiplexer;
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.BasicClock;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.CircularBuffer;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.MediaTimeBase;
/*     */ import com.sun.media.controls.MonitorAdapter;
/*     */ import com.sun.media.protocol.BasicPushBufferDataSource;
/*     */ import com.sun.media.protocol.BasicSourceStream;
/*     */ import com.sun.media.util.MediaThread;
/*     */ import com.sun.media.util.jdk12;
/*     */ import com.sun.media.util.jdk12CreateThreadRunnableAction;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Clock;
/*     */ import javax.media.ClockStoppedException;
/*     */ import javax.media.Format;
/*     */ import javax.media.IncompatibleTimeBaseException;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.Time;
/*     */ import javax.media.TimeBase;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ import javax.media.protocol.BufferTransferHandler;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PushBufferStream;
/*     */ 
/*     */ public class RawBufferMux extends BasicPlugIn implements Multiplexer, Clock {
/*  34 */   protected ContentDescriptor[] supported = null;
/*     */ 
/*     */   
/*  37 */   protected ContentDescriptor contentDesc = null;
/*     */ 
/*     */   
/*  40 */   protected RawBufferDataSource source = null;
/*     */ 
/*     */   
/*  43 */   protected RawBufferSourceStream[] streams = null;
/*     */ 
/*     */ 
/*     */   
/*  47 */   protected BasicClock clock = null;
/*     */ 
/*     */   
/*  50 */   protected RawMuxTimeBase timeBase = null;
/*     */   protected long[] mediaTime;
/*  52 */   protected int masterTrackID = -1;
/*     */   
/*     */   boolean sourceDisconnected = false;
/*     */   
/*     */   boolean allowDrop = false;
/*     */   
/*     */   boolean hasRead = false;
/*  59 */   private static JMFSecurity jmfSecurity = null;
/*     */   private static boolean securityPrivelege = false;
/*  61 */   private Method[] m = new Method[1];
/*  62 */   private Class[] cl = new Class[1];
/*  63 */   private Object[][] args = new Object[1][0];
/*  64 */   protected int numTracks = 0;
/*     */   
/*     */   protected Format[] trackFormats;
/*     */   
/*  68 */   protected MonitorAdapter[] mc = null;
/*     */ 
/*     */   
/*  71 */   static AudioFormat mpegAudio = new AudioFormat("mpegaudio/rtp"); Object timeSetSync; boolean started; long systemStartTime; long mediaStartTime;
/*     */   
/*     */   static {
/*     */     try {
/*  75 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  76 */       securityPrivelege = true;
/*  77 */     } catch (SecurityException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 101 */     return "Raw Buffer Multiplexer";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() throws ResourceUnavailableException {
/* 115 */     initializeTracks(this.trackFormats);
/*     */     
/* 117 */     if (this.source == null || this.source.getStreams() == null)
/* 118 */       throw new ResourceUnavailableException("DataSource and SourceStreams were not created succesfully."); 
/*     */     try {
/* 120 */       this.source.connect();
/*     */     } catch (IOException e) {
/* 122 */       throw new ResourceUnavailableException(e.getMessage());
/*     */     } 
/*     */     
/* 125 */     int len = 0;
/*     */ 
/*     */     
/* 128 */     this.mediaTime = new long[this.trackFormats.length];
/* 129 */     this.mc = new MonitorAdapter[this.trackFormats.length];
/*     */     int i;
/* 131 */     for (i = 0; i < this.trackFormats.length; i++) {
/* 132 */       this.mediaTime[i] = 0L;
/* 133 */       if (this.trackFormats[i] instanceof VideoFormat || this.trackFormats[i] instanceof AudioFormat) {
/*     */         
/* 135 */         this.mc[i] = new MonitorAdapter(this.trackFormats[i], this);
/* 136 */         if (this.mc[i] != null) {
/* 137 */           len++;
/*     */         }
/*     */       } 
/*     */     } 
/* 141 */     int j = 0;
/* 142 */     this.controls = (Object[])new javax.media.Control[len];
/* 143 */     for (i = 0; i < this.mc.length; i++) {
/* 144 */       if (this.mc[i] != null) {
/* 145 */         this.controls[j++] = this.mc[i];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 157 */     if (this.source != null) {
/*     */       try {
/* 159 */         this.source.stop();
/* 160 */         this.source.disconnect();
/* 161 */       } catch (IOException e) {}
/*     */       
/* 163 */       this.source = null;
/*     */     } 
/*     */     
/* 166 */     for (int i = 0; i < this.mc.length; i++) {
/* 167 */       if (this.mc[i] != null) {
/* 168 */         this.mc[i].close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 177 */     for (int i = 0; i < this.streams.length; i++) {
/* 178 */       this.streams[i].reset();
/* 179 */       if (this.mc[i] != null) {
/* 180 */         this.mc[i].reset();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContentDescriptor[] getSupportedOutputContentDescriptors(Format[] fmt) {
/* 201 */     return this.supported;
/*     */   }
/*     */   
/*     */   public Format[] getSupportedInputFormats() {
/* 205 */     return new Format[] { (Format)new AudioFormat(null), (Format)new VideoFormat(null) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataSource getDataOutput() {
/* 219 */     return (DataSource)this.source;
/*     */   }
/*     */   
/*     */   public int setNumTracks(int nTracks) {
/* 223 */     this.numTracks = nTracks;
/* 224 */     this.trackFormats = new Format[nTracks];
/* 225 */     for (int i = 0; i < nTracks; i++)
/* 226 */       this.trackFormats[i] = null; 
/* 227 */     return nTracks;
/*     */   }
/*     */   
/*     */   public Format setInputFormat(Format input, int trackID) {
/* 231 */     if (trackID < this.numTracks)
/* 232 */       this.trackFormats[trackID] = input; 
/* 233 */     for (int i = 0; i < this.numTracks; i++) {
/* 234 */       if (this.trackFormats[i] == null) {
/* 235 */         return input;
/*     */       }
/*     */     } 
/* 238 */     return input;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean initializeTracks(Format[] trackFormats) {
/* 254 */     if (this.source.getStreams() != null)
/* 255 */       throw new Error("initializeTracks has been called previously. "); 
/* 256 */     this.source.initialize(trackFormats);
/* 257 */     this.streams = (RawBufferSourceStream[])this.source.getStreams();
/*     */     
/* 259 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int process(Buffer buffer, int trackID) {
/* 280 */     if ((buffer.getFlags() & 0x1000) != 0) {
/* 281 */       buffer.setFlags(buffer.getFlags() & 0xFFFFEFFF | 0x100);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 286 */     if (this.mc[trackID] != null && this.mc[trackID].isEnabled()) {
/* 287 */       this.mc[trackID].process(buffer);
/*     */     }
/* 289 */     if (this.streams == null || buffer == null || trackID >= this.streams.length)
/*     */     {
/* 291 */       return 1;
/*     */     }
/*     */     
/* 294 */     updateTime(buffer, trackID);
/*     */     
/* 296 */     return this.streams[trackID].process(buffer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateTime(Buffer buf, int trackID) {
/* 304 */     if (buf.getFormat() instanceof AudioFormat) {
/*     */       
/* 306 */       if (mpegAudio.matches(buf.getFormat())) {
/* 307 */         if (buf.getTimeStamp() < 0L) {
/* 308 */           if (this.systemStartTime >= 0L) {
/* 309 */             this.mediaTime[trackID] = (this.mediaStartTime + System.currentTimeMillis() - this.systemStartTime) * 1000000L;
/*     */           }
/*     */         } else {
/*     */           
/* 313 */           this.mediaTime[trackID] = buf.getTimeStamp();
/*     */         } 
/*     */       } else {
/*     */         
/* 317 */         long t = ((AudioFormat)buf.getFormat()).computeDuration(buf.getLength());
/* 318 */         if (t >= 0L) {
/* 319 */           this.mediaTime[trackID] = this.mediaTime[trackID] + t;
/*     */         } else {
/* 321 */           this.mediaTime[trackID] = buf.getTimeStamp();
/*     */         } 
/*     */       } 
/* 324 */     } else if (buf.getTimeStamp() < 0L) {
/*     */       
/* 326 */       if (this.systemStartTime >= 0L) {
/* 327 */         this.mediaTime[trackID] = (this.mediaStartTime + System.currentTimeMillis() - this.systemStartTime) * 1000000L;
/*     */       }
/*     */     } else {
/*     */       
/* 331 */       this.mediaTime[trackID] = buf.getTimeStamp();
/*     */     } 
/* 333 */     this.timeBase.update();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContentDescriptor setContentDescriptor(ContentDescriptor outputContentDescriptor) {
/* 352 */     if (BasicPlugIn.matches((Format)outputContentDescriptor, (Format[])this.supported) == null) {
/* 353 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 357 */     this.contentDesc = outputContentDescriptor;
/* 358 */     this.source = new RawBufferDataSource(this);
/*     */     
/* 360 */     return this.contentDesc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RawBufferMux() {
/* 368 */     this.timeSetSync = new Object();
/* 369 */     this.started = false;
/*     */ 
/*     */     
/* 372 */     this.systemStartTime = -1L;
/* 373 */     this.mediaStartTime = -1L; this.supported = new ContentDescriptor[1]; this.supported[0] = new ContentDescriptor("raw"); this.timeBase = new RawMuxTimeBase(this); this.clock = new BasicClock();
/*     */     try {
/*     */       this.clock.setTimeBase((TimeBase)this.timeBase);
/* 376 */     } catch (Exception e) {} } public void setTimeBase(TimeBase master) throws IncompatibleTimeBaseException { if (master != this.timeBase) {
/* 377 */       throw new IncompatibleTimeBaseException();
/*     */     } }
/*     */ 
/*     */   
/*     */   public void syncStart(Time at) {
/* 382 */     synchronized (this.timeSetSync) {
/* 383 */       if (this.started)
/* 384 */         return;  this.started = true;
/* 385 */       this.clock.syncStart(at);
/* 386 */       this.timeBase.mediaStarted();
/* 387 */       this.systemStartTime = System.currentTimeMillis();
/* 388 */       this.mediaStartTime = getMediaNanoseconds() / 1000000L;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void stop() {
/* 393 */     synchronized (this.timeSetSync) {
/* 394 */       if (!this.started)
/* 395 */         return;  this.started = false;
/* 396 */       this.clock.stop();
/* 397 */       this.timeBase.mediaStopped();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setStopTime(Time stopTime) {
/* 402 */     this.clock.setStopTime(stopTime);
/*     */   }
/*     */   
/*     */   public Time getStopTime() {
/* 406 */     return this.clock.getStopTime();
/*     */   }
/*     */   
/*     */   public void setMediaTime(Time now) {
/* 410 */     synchronized (this.timeSetSync) {
/* 411 */       this.clock.setMediaTime(now);
/* 412 */       for (int i = 0; i < this.mediaTime.length; i++)
/* 413 */         this.mediaTime[i] = now.getNanoseconds(); 
/* 414 */       this.timeBase.update();
/* 415 */       this.systemStartTime = System.currentTimeMillis();
/* 416 */       this.mediaStartTime = now.getNanoseconds() / 1000000L;
/*     */     } 
/*     */   }
/*     */   
/*     */   public Time getMediaTime() {
/* 421 */     return this.clock.getMediaTime();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getMediaNanoseconds() {
/* 426 */     return this.clock.getMediaNanoseconds();
/*     */   }
/*     */   
/*     */   public Time getSyncTime() {
/* 430 */     return this.clock.getSyncTime();
/*     */   }
/*     */ 
/*     */   
/*     */   public TimeBase getTimeBase() {
/* 435 */     return this.clock.getTimeBase();
/*     */   }
/*     */   
/*     */   public Time mapToTimeBase(Time t) throws ClockStoppedException {
/* 439 */     return this.clock.mapToTimeBase(t);
/*     */   }
/*     */   
/*     */   public float getRate() {
/* 443 */     return this.clock.getRate();
/*     */   }
/*     */   
/*     */   public float setRate(float factor) {
/* 447 */     if (factor == this.clock.getRate())
/* 448 */       return factor; 
/* 449 */     return this.clock.setRate(1.0F);
/*     */   }
/*     */   
/*     */   class RawMuxTimeBase extends MediaTimeBase {
/*     */     long ticks;
/*     */     boolean updated;
/*     */     private final RawBufferMux this$0;
/*     */     
/*     */     RawMuxTimeBase(RawBufferMux this$0) {
/* 458 */       this.this$0 = this$0;
/*     */       
/* 460 */       this.ticks = 0L;
/* 461 */       this.updated = false;
/*     */     }
/*     */     
/*     */     public long getMediaTime() {
/* 465 */       if (this.this$0.masterTrackID >= 0) {
/* 466 */         return this.this$0.mediaTime[this.this$0.masterTrackID];
/*     */       }
/*     */       
/* 469 */       if (!this.updated) {
/* 470 */         return this.ticks;
/*     */       }
/* 472 */       if (this.this$0.mediaTime.length == 1) {
/* 473 */         this.ticks = this.this$0.mediaTime[0];
/*     */       } else {
/* 475 */         this.ticks = this.this$0.mediaTime[0];
/* 476 */         for (int i = 1; i < this.this$0.mediaTime.length; i++) {
/* 477 */           if (this.this$0.mediaTime[i] < this.ticks) {
/* 478 */             this.ticks = this.this$0.mediaTime[i];
/*     */           }
/*     */         } 
/*     */       } 
/* 482 */       this.updated = false;
/*     */       
/* 484 */       return this.ticks;
/*     */     }
/*     */     
/*     */     public void update() {
/* 488 */       this.updated = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   class RawBufferDataSource
/*     */     extends BasicPushBufferDataSource
/*     */   {
/*     */     private final RawBufferMux this$0;
/*     */ 
/*     */     
/*     */     public RawBufferDataSource(RawBufferMux this$0) {
/* 501 */       this.this$0 = this$0;
/*     */       
/* 503 */       if (this$0.contentDesc == null)
/*     */         return; 
/* 505 */       this.contentType = this$0.contentDesc.getContentType();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PushBufferStream[] getStreams() {
/* 518 */       return (PushBufferStream[])this.this$0.streams;
/*     */     }
/*     */     
/*     */     public void start() throws IOException {
/* 522 */       super.start();
/*     */       
/* 524 */       for (int i = 0; i < this.this$0.streams.length; i++)
/* 525 */         this.this$0.streams[i].start(); 
/*     */     }
/*     */     
/*     */     public void stop() throws IOException {
/* 529 */       super.stop();
/*     */       
/* 531 */       for (int i = 0; i < this.this$0.streams.length; i++)
/* 532 */         this.this$0.streams[i].stop(); 
/*     */     }
/*     */     
/*     */     public void connect() throws IOException {
/* 536 */       super.connect();
/* 537 */       this.this$0.sourceDisconnected = false;
/*     */     }
/*     */     
/*     */     public void disconnect() {
/* 541 */       super.disconnect();
/* 542 */       this.this$0.sourceDisconnected = true;
/*     */       
/* 544 */       for (int i = 0; i < this.this$0.streams.length; i++) {
/* 545 */         this.this$0.streams[i].stop();
/* 546 */         this.this$0.streams[i].close();
/*     */       } 
/*     */     }
/*     */     
/*     */     private void initialize(Format[] trackFormats) {
/* 551 */       this.this$0.streams = new RawBufferMux.RawBufferSourceStream[trackFormats.length];
/* 552 */       for (int i = 0; i < trackFormats.length; i++) {
/* 553 */         this.this$0.streams[i] = new RawBufferMux.RawBufferSourceStream(this.this$0, trackFormats[i]);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   class RawBufferSourceStream
/*     */     extends BasicSourceStream
/*     */     implements PushBufferStream, Runnable
/*     */   {
/*     */     Format format;
/*     */     
/*     */     CircularBuffer bufferQ;
/*     */     
/*     */     boolean started;
/*     */     
/*     */     Object startReq;
/*     */     
/*     */     BufferTransferHandler handler;
/*     */     Thread streamThread;
/*     */     boolean closed;
/*     */     boolean draining;
/*     */     Object drainSync;
/*     */     private final RawBufferMux this$0;
/*     */     
/*     */     public RawBufferSourceStream(RawBufferMux this$0, Format fmt) {
/* 579 */       this.this$0 = this$0; this.format = null; this.started = false; this.startReq = new Integer(0); this.handler = null; this.streamThread = null; this.closed = false; this.draining = false;
/*     */       this.drainSync = new Object();
/* 581 */       this.contentDescriptor = this$0.contentDesc;
/* 582 */       this.format = fmt;
/* 583 */       this.bufferQ = new CircularBuffer(5);
/*     */       
/* 585 */       if (RawBufferMux.jmfSecurity != null) {
/* 586 */         String permission = null;
/*     */         try {
/* 588 */           if (RawBufferMux.jmfSecurity.getName().startsWith("jmf-security")) {
/* 589 */             permission = "thread";
/* 590 */             RawBufferMux.jmfSecurity.requestPermission(this$0.m, this$0.cl, this$0.args, 16);
/* 591 */             this$0.m[0].invoke(this$0.cl[0], this$0.args[0]);
/*     */             
/* 593 */             permission = "thread group";
/* 594 */             RawBufferMux.jmfSecurity.requestPermission(this$0.m, this$0.cl, this$0.args, 32);
/* 595 */             this$0.m[0].invoke(this$0.cl[0], this$0.args[0]);
/* 596 */           } else if (RawBufferMux.jmfSecurity.getName().startsWith("internet")) {
/* 597 */             PolicyEngine.checkPermission(PermissionID.THREAD);
/* 598 */             PolicyEngine.assertPermission(PermissionID.THREAD);
/*     */           }
/*     */         
/* 601 */         } catch (Throwable e) {
/*     */ 
/*     */ 
/*     */           
/* 605 */           RawBufferMux.securityPrivelege = false;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 610 */       if (RawBufferMux.jmfSecurity != null && RawBufferMux.jmfSecurity.getName().startsWith("jdk12")) {
/*     */         
/* 612 */         RawBufferSourceStream rbss = this;
/*     */         
/*     */         try {
/* 615 */           Constructor cons = jdk12CreateThreadRunnableAction.cons;
/*     */           
/* 617 */           this.streamThread = (Thread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { MediaThread.class, this }) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 625 */         catch (Exception e) {}
/*     */       } else {
/*     */         
/* 628 */         this.streamThread = (Thread)new MediaThread(this, "RawBufferStream Thread");
/*     */       } 
/* 630 */       if (this.streamThread != null) {
/* 631 */         this.streamThread.start();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Format getFormat() {
/* 641 */       return this.format;
/*     */     }
/*     */     
/*     */     public void setTransferHandler(BufferTransferHandler handler) {
/* 645 */       this.handler = handler;
/*     */     }
/*     */ 
/*     */     
/*     */     public void read(Buffer buffer) throws IOException {
/* 650 */       if (this.closed) {
/* 651 */         throw new IOException("The source stream is closed");
/*     */       }
/*     */       
/* 654 */       Buffer current = null;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 659 */       synchronized (this.bufferQ) {
/* 660 */         while (!this.bufferQ.canRead()) {
/*     */           try {
/* 662 */             this.bufferQ.wait();
/* 663 */           } catch (Exception e) {}
/*     */         } 
/* 665 */         current = this.bufferQ.read();
/*     */       } 
/*     */       
/* 668 */       if (current.isEOM()) {
/* 669 */         synchronized (this.drainSync) {
/* 670 */           if (this.draining) {
/* 671 */             this.draining = false;
/* 672 */             this.drainSync.notifyAll();
/*     */           } 
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 678 */       Object data = buffer.getData();
/* 679 */       Object hdr = buffer.getHeader();
/* 680 */       buffer.copy(current);
/* 681 */       current.setData(data);
/* 682 */       current.setHeader(hdr);
/*     */ 
/*     */       
/* 685 */       synchronized (this.bufferQ) {
/* 686 */         this.this$0.hasRead = true;
/* 687 */         this.bufferQ.readReport();
/* 688 */         this.bufferQ.notifyAll();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void start() {
/* 698 */       synchronized (this.startReq) {
/* 699 */         if (this.started)
/*     */           return; 
/* 701 */         this.started = true;
/* 702 */         this.startReq.notifyAll();
/*     */       } 
/* 704 */       synchronized (this.bufferQ) {
/* 705 */         this.this$0.hasRead = true;
/* 706 */         this.bufferQ.notifyAll();
/*     */       } 
/*     */     }
/*     */     
/*     */     protected void stop() {
/* 711 */       synchronized (this.startReq) {
/* 712 */         this.started = false;
/*     */       } 
/* 714 */       synchronized (this.bufferQ) {
/* 715 */         this.bufferQ.notifyAll();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected void close() {
/* 721 */       this.closed = true;
/* 722 */       if (this.streamThread != null) {
/*     */         
/*     */         try {
/* 725 */           reset();
/* 726 */           synchronized (this.startReq) {
/* 727 */             this.startReq.notifyAll();
/*     */           }
/*     */         
/* 730 */         } catch (Exception e) {}
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void reset() {
/* 738 */       synchronized (this.bufferQ) {
/* 739 */         while (this.bufferQ.canRead()) {
/* 740 */           Buffer b = this.bufferQ.read();
/* 741 */           this.bufferQ.readReport();
/*     */         } 
/* 743 */         this.bufferQ.notifyAll();
/*     */       } 
/*     */       
/* 746 */       synchronized (this.drainSync) {
/* 747 */         if (this.draining) {
/* 748 */           this.draining = false;
/* 749 */           this.drainSync.notifyAll();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected int process(Buffer filled) {
/*     */       Buffer buffer;
/* 757 */       synchronized (this.bufferQ) {
/* 758 */         if (this.this$0.allowDrop)
/*     */         {
/*     */ 
/*     */           
/* 762 */           if (!this.bufferQ.canWrite() && this.bufferQ.canRead()) {
/*     */ 
/*     */ 
/*     */             
/* 766 */             Buffer tmp = this.bufferQ.peek();
/* 767 */             if ((tmp.getFlags() & 0x20) == 0) {
/*     */               
/* 769 */               this.bufferQ.read();
/* 770 */               this.bufferQ.readReport();
/*     */             } 
/*     */           } 
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 777 */         while (!this.bufferQ.canWrite() && !this.closed) {
/*     */           try {
/* 779 */             this.bufferQ.wait();
/* 780 */           } catch (Exception e) {}
/*     */         } 
/* 782 */         if (this.closed)
/* 783 */           return 0; 
/* 784 */         buffer = this.bufferQ.getEmptyBuffer();
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 791 */       Object bdata = buffer.getData();
/* 792 */       Object bheader = buffer.getHeader();
/* 793 */       buffer.setData(filled.getData());
/* 794 */       buffer.setHeader(filled.getHeader());
/* 795 */       filled.setData(bdata);
/* 796 */       filled.setHeader(bheader);
/*     */ 
/*     */       
/* 799 */       buffer.setLength(filled.getLength());
/* 800 */       buffer.setEOM(filled.isEOM());
/* 801 */       buffer.setFlags(filled.getFlags());
/* 802 */       buffer.setTimeStamp(filled.getTimeStamp());
/* 803 */       buffer.setFormat(filled.getFormat());
/* 804 */       buffer.setOffset(filled.getOffset());
/* 805 */       buffer.setSequenceNumber(filled.getSequenceNumber());
/*     */ 
/*     */       
/* 808 */       if (filled.isEOM()) {
/* 809 */         this.draining = true;
/*     */       }
/* 811 */       synchronized (this.bufferQ) {
/* 812 */         this.bufferQ.writeReport();
/* 813 */         this.bufferQ.notifyAll();
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 818 */       if (filled.isEOM()) {
/* 819 */         synchronized (this.drainSync) {
/*     */           try {
/* 821 */             if (this.draining)
/*     */             {
/* 823 */               this.drainSync.wait(3000L);
/*     */             }
/* 825 */           } catch (Exception e) {}
/*     */         } 
/*     */       }
/*     */       
/* 829 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/*     */       try {
/*     */         while (true) {
/* 842 */           synchronized (this.startReq) {
/* 843 */             while (!this.started && !this.closed) {
/* 844 */               this.startReq.wait();
/*     */             }
/*     */           } 
/*     */           
/* 848 */           synchronized (this.bufferQ) {
/*     */ 
/*     */             
/*     */             do {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 864 */               if (!this.this$0.hasRead)
/* 865 */                 this.bufferQ.wait(250L); 
/* 866 */               this.this$0.hasRead = false;
/* 867 */             } while (!this.bufferQ.canRead() && !this.closed && this.started);
/*     */           } 
/*     */ 
/*     */           
/* 871 */           if (this.closed) {
/*     */             return;
/*     */           }
/*     */           
/* 875 */           if (!this.started) {
/*     */             continue;
/*     */           }
/*     */           
/* 879 */           if (this.handler != null)
/* 880 */             this.handler.transferData(this); 
/*     */         } 
/*     */       } catch (InterruptedException e) {
/* 883 */         System.err.println("Thread " + e.getMessage());
/*     */         return;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\multiplexer\RawBufferMux.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */