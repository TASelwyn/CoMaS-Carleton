package com.sun.media.multiplexer;

import com.sun.media.BasicClock;
import com.sun.media.BasicPlugIn;
import com.sun.media.MediaTimeBase;
import com.sun.media.Syncable;
import com.sun.media.controls.MonitorAdapter;
import com.sun.media.datasink.RandomAccess;
import java.awt.Component;
import java.io.IOException;
import javax.media.Buffer;
import javax.media.Clock;
import javax.media.ClockStoppedException;
import javax.media.Control;
import javax.media.Duration;
import javax.media.Format;
import javax.media.IncompatibleTimeBaseException;
import javax.media.Multiplexer;
import javax.media.Owned;
import javax.media.Time;
import javax.media.TimeBase;
import javax.media.control.StreamWriterControl;
import javax.media.format.AudioFormat;
import javax.media.format.VideoFormat;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.DataSource;
import javax.media.protocol.PushDataSource;
import javax.media.protocol.PushSourceStream;
import javax.media.protocol.Seekable;
import javax.media.protocol.SourceTransferHandler;

public abstract class BasicMux extends BasicPlugIn implements Multiplexer, Clock {
  protected Format[] supportedInputs;
  
  protected ContentDescriptor[] supportedOutputs;
  
  protected int numTracks = 0;
  
  protected Format[] inputs;
  
  protected BasicMuxDataSource source;
  
  protected BasicMuxPushStream stream;
  
  protected ContentDescriptor outputCD;
  
  protected boolean flushing = false;
  
  protected Integer sourceLock = new Integer(0);
  
  protected boolean eos = false;
  
  protected boolean firstBuffer = true;
  
  protected int fileSize = 0;
  
  protected int filePointer = 0;
  
  protected long fileSizeLimit = -1L;
  
  protected boolean streamSizeLimitSupported = true;
  
  protected boolean fileSizeLimitReached = false;
  
  protected SourceTransferHandler sth = null;
  
  protected boolean isLiveData = false;
  
  protected StreamWriterControl swc = null;
  
  protected MonitorAdapter[] mc = null;
  
  protected BasicMuxTimeBase timeBase = null;
  
  Object startup = new Integer(0);
  
  boolean readyToStart = false;
  
  long[] mediaTime;
  
  boolean[] ready;
  
  protected BasicClock clock = null;
  
  int master = 0;
  
  boolean mClosed = false;
  
  boolean dataReady;
  
  boolean startCompensated;
  
  Object dataLock;
  
  Buffer[] firstBuffers;
  
  boolean[] firstBuffersDone;
  
  int[] nonKeyCount;
  
  long masterTime;
  
  VideoFormat jpegFmt;
  
  VideoFormat mjpgFmt;
  
  VideoFormat rgbFmt;
  
  VideoFormat yuvFmt;
  
  protected int maxBufSize;
  
  protected byte[] buf;
  
  protected int bufOffset;
  
  protected int bufLength;
  
  Object timeSetSync;
  
  boolean started;
  
  long systemStartTime;
  
  public void open() {
    this.firstBuffer = true;
    this.firstBuffers = new Buffer[this.inputs.length];
    this.firstBuffersDone = new boolean[this.inputs.length];
    this.nonKeyCount = new int[this.inputs.length];
    this.mediaTime = new long[this.inputs.length];
    int i;
    for (i = 0; i < this.inputs.length; i++) {
      this.firstBuffers[i] = null;
      this.firstBuffersDone[i] = false;
      this.nonKeyCount[i] = 0;
      this.mediaTime[i] = 0L;
    } 
    this.ready = new boolean[this.inputs.length];
    resetReady();
    int len = 0;
    this.mc = new MonitorAdapter[this.inputs.length];
    for (i = 0; i < this.inputs.length; i++) {
      if (this.inputs[i] instanceof VideoFormat || this.inputs[i] instanceof AudioFormat) {
        this.mc[i] = new MonitorAdapter(this.inputs[i], this);
        if (this.mc[i] != null)
          len++; 
      } 
    } 
    int j = 0;
    this.controls = (Object[])new Control[len + 1];
    for (i = 0; i < this.mc.length; i++) {
      if (this.mc[i] != null)
        this.controls[j++] = this.mc[i]; 
    } 
    this.controls[j] = this.swc;
  }
  
  public void close() {
    if (this.sth != null) {
      writeFooter();
      write(null, 0, -1);
    } 
    for (int i = 0; i < this.mc.length; i++) {
      if (this.mc[i] != null)
        this.mc[i].close(); 
    } 
    synchronized (this.dataLock) {
      this.mClosed = true;
      this.dataLock.notifyAll();
    } 
  }
  
  public void reset() {
    for (int i = 0; i < this.mediaTime.length; i++) {
      this.mediaTime[i] = 0L;
      if (this.mc[i] != null)
        this.mc[i].reset(); 
    } 
    this.timeBase.update();
    resetReady();
    synchronized (this.sourceLock) {
      this.flushing = true;
      this.sourceLock.notifyAll();
    } 
  }
  
  private void resetReady() {
    for (int i = 0; i < this.ready.length; i++)
      this.ready[i] = false; 
    this.readyToStart = false;
    synchronized (this.startup) {
      this.startup.notifyAll();
    } 
  }
  
  private boolean checkReady() {
    if (this.readyToStart)
      return true; 
    for (int i = 0; i < this.ready.length; i++) {
      if (!this.ready[i])
        return false; 
    } 
    this.readyToStart = true;
    return true;
  }
  
  public Format[] getSupportedInputFormats() {
    return this.supportedInputs;
  }
  
  public ContentDescriptor[] getSupportedOutputContentDescriptors(Format[] inputs) {
    return this.supportedOutputs;
  }
  
  public int setNumTracks(int numTracks) {
    this.numTracks = numTracks;
    if (this.inputs == null) {
      this.inputs = new Format[numTracks];
    } else {
      Format[] newInputs = new Format[numTracks];
      for (int i = 0; i < this.inputs.length; i++)
        newInputs[i] = this.inputs[i]; 
      this.inputs = newInputs;
    } 
    return numTracks;
  }
  
  public Format setInputFormat(Format format, int trackID) {
    this.inputs[trackID] = format;
    return format;
  }
  
  public int process(Buffer buffer, int trackID) {
    if (buffer.isDiscard())
      return 0; 
    if (!this.isLiveData && (buffer.getFlags() & 0x8000) > 0)
      this.isLiveData = true; 
    while (this.source == null || !this.source.isConnected() || !this.source.isStarted()) {
      synchronized (this.sourceLock) {
        try {
          this.sourceLock.wait(500L);
        } catch (InterruptedException ie) {}
        if (this.flushing) {
          this.flushing = false;
          buffer.setLength(0);
          return 0;
        } 
      } 
    } 
    synchronized (this) {
      if (this.firstBuffer) {
        writeHeader();
        this.firstBuffer = false;
      } 
    } 
    if (this.numTracks > 1) {
      if ((buffer.getFlags() & 0x1000) != 0 && 
        buffer.getTimeStamp() <= 0L)
        return 0; 
      if (!this.startCompensated && 
        !compensateStart(buffer, trackID))
        return 0; 
    } 
    updateClock(buffer, trackID);
    if (this.mc[trackID] != null && this.mc[trackID].isEnabled())
      this.mc[trackID].process(buffer); 
    int processResult = doProcess(buffer, trackID);
    if (this.fileSizeLimitReached)
      processResult |= 0x8; 
    return processResult;
  }
  
  public BasicMux() {
    this.dataReady = false;
    this.startCompensated = false;
    this.dataLock = new Object();
    this.masterTime = -1L;
    this.jpegFmt = new VideoFormat("jpeg");
    this.mjpgFmt = new VideoFormat("mjpg");
    this.rgbFmt = new VideoFormat("rgb");
    this.yuvFmt = new VideoFormat("yuv");
    this.maxBufSize = 32768;
    this.buf = new byte[this.maxBufSize];
    this.timeSetSync = new Object();
    this.started = false;
    this.systemStartTime = System.currentTimeMillis() * 1000000L;
    this.timeBase = new BasicMuxTimeBase(this);
    this.clock = new BasicClock();
    try {
      this.clock.setTimeBase((TimeBase)this.timeBase);
    } catch (Exception e) {}
    this.swc = new SWC(this, this);
    this.controls = (Object[])new Control[] { (Control)this.swc };
  }
  
  private boolean compensateStart(Buffer buffer, int trackID) {
    synchronized (this.dataLock) {
      if (this.dataReady) {
        if (!this.firstBuffersDone[trackID]) {
          if (buffer.getTimeStamp() < this.masterTime)
            return false; 
          if (buffer.getFormat() instanceof VideoFormat) {
            Format fmt = buffer.getFormat();
            boolean isKey = (this.jpegFmt.matches(fmt) || this.mjpgFmt.matches(fmt) || this.rgbFmt.matches(fmt) || this.yuvFmt.matches(fmt));
            this.nonKeyCount[trackID] = this.nonKeyCount[trackID] + 1;
            if (isKey || (buffer.getFlags() & 0x10) != 0 || this.nonKeyCount[trackID] > 30) {
              buffer.setTimeStamp(this.masterTime);
              this.firstBuffersDone[trackID] = true;
            } else {
              return false;
            } 
          } else {
            buffer.setTimeStamp(this.masterTime);
            this.firstBuffersDone[trackID] = true;
          } 
          for (int m = 0; m < this.firstBuffersDone.length; m++) {
            if (!this.firstBuffersDone[m])
              return true; 
          } 
          this.startCompensated = true;
          return true;
        } 
        return true;
      } 
      if (buffer.getTimeStamp() < 0L) {
        this.startCompensated = true;
        this.dataReady = true;
        this.dataLock.notifyAll();
        return true;
      } 
      this.firstBuffers[trackID] = buffer;
      boolean done = true;
      for (int i = 0; i < this.firstBuffers.length; i++) {
        if (this.firstBuffers[i] == null)
          done = false; 
      } 
      if (!done) {
        while (!this.dataReady && !this.mClosed) {
          try {
            this.dataLock.wait();
          } catch (Exception e) {}
        } 
        if (this.mClosed || this.firstBuffers[trackID] == null)
          return false; 
        return true;
      } 
      this.masterTime = this.firstBuffers[0].getTimeStamp();
      for (int j = 0; j < this.firstBuffers.length; j++) {
        if (this.firstBuffers[j].getFormat() instanceof AudioFormat) {
          this.masterTime = this.firstBuffers[j].getTimeStamp();
          break;
        } 
        if (this.firstBuffers[j].getTimeStamp() < this.masterTime)
          this.masterTime = this.firstBuffers[j].getTimeStamp(); 
      } 
      this.startCompensated = true;
      for (int k = 0; k < this.firstBuffers.length; k++) {
        if (this.firstBuffers[k].getTimeStamp() >= this.masterTime) {
          this.firstBuffers[k].setTimeStamp(this.masterTime);
          this.firstBuffersDone[k] = true;
        } else {
          this.firstBuffers[k] = null;
          this.startCompensated = false;
        } 
      } 
      synchronized (this.dataLock) {
        this.dataReady = true;
        this.dataLock.notifyAll();
      } 
      return (this.firstBuffers[trackID] != null);
    } 
  }
  
  private void updateClock(Buffer buffer, int trackID) {
    if (!this.readyToStart && this.numTracks > 1)
      synchronized (this.startup) {
        this.ready[trackID] = true;
        if (checkReady()) {
          this.startup.notifyAll();
        } else {
          try {
            while (!this.readyToStart)
              this.startup.wait(1000L); 
          } catch (Exception e) {}
        } 
      }  
    long timestamp = buffer.getTimeStamp();
    if (timestamp <= 0L && buffer.getFormat() instanceof AudioFormat) {
      timestamp = this.mediaTime[trackID];
      this.mediaTime[trackID] = this.mediaTime[trackID] + getDuration(buffer);
    } else if (timestamp <= 0L) {
      this.mediaTime[trackID] = System.currentTimeMillis() * 1000000L - this.systemStartTime;
    } else {
      this.mediaTime[trackID] = timestamp;
    } 
    this.timeBase.update();
  }
  
  public ContentDescriptor setContentDescriptor(ContentDescriptor outputCD) {
    if (BasicPlugIn.matches((Format)outputCD, (Format[])this.supportedOutputs) == null)
      return null; 
    this.outputCD = outputCD;
    return outputCD;
  }
  
  public DataSource getDataOutput() {
    if (this.source == null) {
      this.source = new BasicMuxDataSource(this, this, this.outputCD);
      synchronized (this.sourceLock) {
        this.sourceLock.notifyAll();
      } 
    } 
    return (DataSource)this.source;
  }
  
  protected int doProcess(Buffer buffer, int trackID) {
    byte[] data = (byte[])buffer.getData();
    int dataLen = buffer.getLength();
    if (!buffer.isEOM())
      write(data, buffer.getOffset(), dataLen); 
    return 0;
  }
  
  protected int write(byte[] data, int offset, int length) {
    if (this.source == null || !this.source.isConnected())
      return length; 
    if (length > 0) {
      this.filePointer += length;
      if (this.filePointer > this.fileSize)
        this.fileSize = this.filePointer; 
      if (this.fileSizeLimit > 0L && this.fileSize >= this.fileSizeLimit)
        this.fileSizeLimitReached = true; 
    } 
    return this.stream.write(data, offset, length);
  }
  
  void setStream(BasicMuxPushStream ps) {
    this.stream = ps;
  }
  
  long getStreamSize() {
    return this.fileSize;
  }
  
  boolean needsSeekable() {
    return false;
  }
  
  protected int seek(int location) {
    if (this.source == null || !this.source.isConnected())
      return location; 
    this.filePointer = this.stream.seek(location);
    return this.filePointer;
  }
  
  boolean isEOS() {
    return this.eos;
  }
  
  protected void writeHeader() {}
  
  protected void writeFooter() {}
  
  protected void bufClear() {
    this.bufOffset = 0;
    this.bufLength = 0;
  }
  
  protected void bufSkip(int size) {
    this.bufOffset += size;
    this.bufLength += size;
    this.filePointer += size;
  }
  
  protected void bufWriteBytes(String s) {
    byte[] bytes = s.getBytes();
    bufWriteBytes(bytes);
  }
  
  protected void bufWriteBytes(byte[] bytes) {
    System.arraycopy(bytes, 0, this.buf, this.bufOffset, bytes.length);
    this.bufOffset += bytes.length;
    this.bufLength += bytes.length;
    this.filePointer += bytes.length;
  }
  
  protected void bufWriteInt(int value) {
    this.buf[this.bufOffset + 0] = (byte)(value >> 24 & 0xFF);
    this.buf[this.bufOffset + 1] = (byte)(value >> 16 & 0xFF);
    this.buf[this.bufOffset + 2] = (byte)(value >> 8 & 0xFF);
    this.buf[this.bufOffset + 3] = (byte)(value >> 0 & 0xFF);
    this.bufOffset += 4;
    this.bufLength += 4;
    this.filePointer += 4;
  }
  
  protected void bufWriteIntLittleEndian(int value) {
    this.buf[this.bufOffset + 3] = (byte)(value >>> 24 & 0xFF);
    this.buf[this.bufOffset + 2] = (byte)(value >>> 16 & 0xFF);
    this.buf[this.bufOffset + 1] = (byte)(value >>> 8 & 0xFF);
    this.buf[this.bufOffset + 0] = (byte)(value >>> 0 & 0xFF);
    this.bufOffset += 4;
    this.bufLength += 4;
    this.filePointer += 4;
  }
  
  protected void bufWriteShort(short value) {
    this.buf[this.bufOffset + 0] = (byte)(value >> 8 & 0xFF);
    this.buf[this.bufOffset + 1] = (byte)(value >> 0 & 0xFF);
    this.bufOffset += 2;
    this.bufLength += 2;
    this.filePointer += 2;
  }
  
  protected void bufWriteShortLittleEndian(short value) {
    this.buf[this.bufOffset + 1] = (byte)(value >> 8 & 0xFF);
    this.buf[this.bufOffset + 0] = (byte)(value >> 0 & 0xFF);
    this.bufOffset += 2;
    this.bufLength += 2;
    this.filePointer += 2;
  }
  
  protected void bufWriteByte(byte value) {
    this.buf[this.bufOffset] = value;
    this.bufOffset++;
    this.bufLength++;
    this.filePointer++;
  }
  
  protected void bufFlush() {
    this.filePointer -= this.bufLength;
    write(this.buf, 0, this.bufLength);
  }
  
  private long getDuration(Buffer buffer) {
    AudioFormat format = (AudioFormat)buffer.getFormat();
    long duration = format.computeDuration(buffer.getLength());
    if (duration < 0L)
      return 0L; 
    return duration;
  }
  
  public void setTimeBase(TimeBase master) throws IncompatibleTimeBaseException {
    if (master != this.timeBase)
      throw new IncompatibleTimeBaseException(); 
  }
  
  public void syncStart(Time at) {
    synchronized (this.timeSetSync) {
      if (this.started)
        return; 
      this.started = true;
      this.clock.syncStart(at);
      this.timeBase.mediaStarted();
      this.systemStartTime = System.currentTimeMillis() * 1000000L;
    } 
  }
  
  public void stop() {
    synchronized (this.timeSetSync) {
      if (!this.started)
        return; 
      this.started = false;
      this.clock.stop();
      this.timeBase.mediaStopped();
    } 
  }
  
  public void setStopTime(Time stopTime) {
    this.clock.setStopTime(stopTime);
  }
  
  public Time getStopTime() {
    return this.clock.getStopTime();
  }
  
  public void setMediaTime(Time now) {
    synchronized (this.timeSetSync) {
      this.clock.setMediaTime(now);
      for (int i = 0; i < this.mediaTime.length; i++)
        this.mediaTime[i] = now.getNanoseconds(); 
      this.timeBase.update();
    } 
  }
  
  public Time getMediaTime() {
    return this.clock.getMediaTime();
  }
  
  public long getMediaNanoseconds() {
    return this.clock.getMediaNanoseconds();
  }
  
  public Time getSyncTime() {
    return this.clock.getSyncTime();
  }
  
  public TimeBase getTimeBase() {
    return this.clock.getTimeBase();
  }
  
  public Time mapToTimeBase(Time t) throws ClockStoppedException {
    return this.clock.mapToTimeBase(t);
  }
  
  public float getRate() {
    return this.clock.getRate();
  }
  
  public float setRate(float factor) {
    if (factor == this.clock.getRate())
      return factor; 
    return this.clock.setRate(1.0F);
  }
  
  public boolean requireTwoPass() {
    return false;
  }
  
  class SWC implements StreamWriterControl, Owned {
    private BasicMux bmx;
    
    private final BasicMux this$0;
    
    public SWC(BasicMux this$0, BasicMux bmx) {
      this.this$0 = this$0;
      this.bmx = bmx;
    }
    
    public boolean setStreamSizeLimit(long limit) {
      this.bmx.fileSizeLimit = limit;
      return this.this$0.streamSizeLimitSupported;
    }
    
    public long getStreamSize() {
      return this.bmx.getStreamSize();
    }
    
    public Object getOwner() {
      return this.bmx;
    }
    
    public Component getControlComponent() {
      return null;
    }
  }
  
  class BasicMuxTimeBase extends MediaTimeBase {
    long ticks;
    
    boolean updated;
    
    private final BasicMux this$0;
    
    BasicMuxTimeBase(BasicMux this$0) {
      this.this$0 = this$0;
      this.ticks = 0L;
      this.updated = false;
    }
    
    public long getMediaTime() {
      if (!this.updated)
        return this.ticks; 
      if (this.this$0.mediaTime.length == 1) {
        this.ticks = this.this$0.mediaTime[0];
      } else {
        this.ticks = this.this$0.mediaTime[0];
        for (int i = 1; i < this.this$0.mediaTime.length; i++) {
          if (this.this$0.mediaTime[i] < this.ticks)
            this.ticks = this.this$0.mediaTime[i]; 
        } 
      } 
      this.updated = false;
      return this.ticks;
    }
    
    public void update() {
      this.updated = true;
    }
  }
  
  class BasicMuxDataSource extends PushDataSource {
    private BasicMux mux;
    
    private ContentDescriptor cd;
    
    private BasicMux.BasicMuxPushStream[] streams;
    
    private BasicMux.BasicMuxPushStream stream;
    
    private boolean connected;
    
    private boolean started;
    
    private final BasicMux this$0;
    
    public BasicMuxDataSource(BasicMux this$0, BasicMux mux, ContentDescriptor cd) {
      this.this$0 = this$0;
      this.connected = false;
      this.started = false;
      this.cd = cd;
      this.mux = mux;
    }
    
    public PushSourceStream[] getStreams() {
      if (this.streams == null) {
        this.streams = new BasicMux.BasicMuxPushStream[1];
        this.stream = new BasicMux.BasicMuxPushStream(this.this$0, this.cd);
        this.streams[0] = this.stream;
        this.this$0.setStream(this.stream);
      } 
      return (PushSourceStream[])this.streams;
    }
    
    public String getContentType() {
      return this.cd.getContentType();
    }
    
    public void connect() throws IOException {
      if (this.streams == null)
        getStreams(); 
      this.connected = true;
      synchronized (this.this$0.sourceLock) {
        this.this$0.sourceLock.notifyAll();
      } 
    }
    
    boolean isConnected() {
      return this.connected;
    }
    
    boolean isStarted() {
      return this.started;
    }
    
    public void disconnect() {
      this.connected = false;
    }
    
    public void start() throws IOException {
      if (this.streams == null || !this.connected)
        throw new IOException("Source not connected yet!"); 
      this.started = true;
      synchronized (this.this$0.sourceLock) {
        this.this$0.sourceLock.notifyAll();
      } 
    }
    
    public void stop() {
      this.started = false;
    }
    
    public Object[] getControls() {
      return (Object[])new Control[0];
    }
    
    public Object getControl(String s) {
      return null;
    }
    
    public Time getDuration() {
      return Duration.DURATION_UNKNOWN;
    }
  }
  
  class BasicMuxPushStream implements PushSourceStream {
    private ContentDescriptor cd;
    
    private byte[] data;
    
    private int dataLen;
    
    private int dataOff;
    
    private Integer writeLock;
    
    private final BasicMux this$0;
    
    public BasicMuxPushStream(BasicMux this$0, ContentDescriptor cd) {
      this.this$0 = this$0;
      this.writeLock = new Integer(0);
      this.cd = cd;
    }
    
    public ContentDescriptor getContentDescriptor() {
      return this.cd;
    }
    
    public long getContentLength() {
      return -1L;
    }
    
    public boolean endOfStream() {
      return this.this$0.isEOS();
    }
    
    synchronized int write(byte[] data, int offset, int length) {
      if (this.this$0.sth == null)
        return 0; 
      if (this.this$0.isLiveData && this.this$0.sth instanceof Syncable)
        ((Syncable)this.this$0.sth).setSyncEnabled(); 
      synchronized (this.writeLock) {
        this.data = data;
        this.dataOff = offset;
        this.dataLen = length;
        this.this$0.sth.transferData(this);
        while (this.dataLen > 0) {
          if (this.dataLen == length)
            try {
              this.writeLock.wait();
            } catch (InterruptedException ie) {} 
          if (this.this$0.sth == null)
            break; 
          if (this.dataLen > 0 && this.dataLen != length) {
            length = this.dataLen;
            this.this$0.sth.transferData(this);
          } 
        } 
      } 
      return length;
    }
    
    synchronized int seek(int location) {
      if (this.this$0.sth != null) {
        ((Seekable)this.this$0.sth).seek(location);
        int seekVal = (int)((Seekable)this.this$0.sth).tell();
        return seekVal;
      } 
      return -1;
    }
    
    public int read(byte[] buffer, int offset, int length) throws IOException {
      int transferred = 0;
      synchronized (this.writeLock) {
        if (this.dataLen == -1) {
          transferred = -1;
        } else {
          if (length >= this.dataLen) {
            transferred = this.dataLen;
          } else {
            transferred = length;
          } 
          System.arraycopy(this.data, this.dataOff, buffer, offset, transferred);
          this.dataLen -= transferred;
          this.dataOff += transferred;
        } 
        this.writeLock.notifyAll();
        return transferred;
      } 
    }
    
    public int getMinimumTransferSize() {
      return this.dataLen;
    }
    
    public void setTransferHandler(SourceTransferHandler sth) {
      synchronized (this.writeLock) {
        this.this$0.sth = sth;
        if (sth != null && this.this$0.needsSeekable() && !(sth instanceof Seekable))
          throw new Error("SourceTransferHandler needs to be seekable"); 
        boolean requireTwoPass = this.this$0.requireTwoPass();
        if (requireTwoPass && 
          sth != null && sth instanceof RandomAccess) {
          RandomAccess st = (RandomAccess)sth;
          st.setEnabled(true);
        } 
        this.writeLock.notifyAll();
      } 
    }
    
    public Object[] getControls() {
      return (Object[])new Control[0];
    }
    
    public Object getControl(String s) {
      return null;
    }
  }
}
