package com.sun.media.multiplexer.audio;

import com.sun.media.multiplexer.BasicMux;
import javax.media.Format;
import javax.media.format.AudioFormat;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.FileTypeDescriptor;

public class AIFFMux extends BasicMux {
  private Format format;
  
  private AudioFormat audioFormat;
  
  private int sampleSizeInBits;
  
  private double sampleRate;
  
  private int channels;
  
  private int blockAlign = 1;
  
  private int dataSizeOffset;
  
  private int maxFrames = 0;
  
  private int maxFramesOffset = 0;
  
  private String formType;
  
  private String aiffEncoding;
  
  private int headerSize = 0;
  
  private int dataSize = 0;
  
  private static int AIFCVersion1 = -1568648896;
  
  private static final String FormID = "FORM";
  
  private static final String FormatVersionID = "FVER";
  
  private static final String CommonID = "COMM";
  
  private static final String SoundDataID = "SSND";
  
  private static final int CommonIDSize = 18;
  
  Format bigEndian;
  
  public String getName() {
    return "AIFF Audio Multiplexer";
  }
  
  public int setNumTracks(int nTracks) {
    if (nTracks != 1)
      return 1; 
    return super.setNumTracks(nTracks);
  }
  
  protected void writeHeader() {
    bufClear();
    bufWriteBytes("FORM");
    bufWriteInt(0);
    bufWriteBytes(this.formType);
    if (this.formType.equals("AIFC")) {
      bufWriteBytes("FVER");
      bufWriteInt(4);
      bufWriteInt(AIFCVersion1);
    } 
    bufWriteBytes("COMM");
    int commonIDSize = 18;
    if (this.formType.equals("AIFC"))
      commonIDSize += 8; 
    bufWriteInt(commonIDSize);
    bufWriteShort((short)this.channels);
    this.maxFramesOffset = this.filePointer;
    bufWriteInt(this.maxFrames);
    bufWriteShort((short)this.sampleSizeInBits);
    int exponent = 16398;
    double highMantissa = this.sampleRate;
    while (highMantissa < 44000.0D) {
      highMantissa *= 2.0D;
      exponent--;
    } 
    bufWriteShort((short)exponent);
    bufWriteInt((int)highMantissa << 16);
    bufWriteInt(0);
    if (this.formType.equals("AIFC")) {
      bufWriteBytes(this.aiffEncoding);
      bufWriteBytes(this.aiffEncoding);
    } 
    bufWriteBytes("SSND");
    this.dataSizeOffset = this.filePointer;
    bufWriteInt(0);
    bufWriteInt(0);
    bufWriteInt(0);
    bufFlush();
    this.headerSize = this.filePointer;
  }
  
  public AIFFMux() {
    this.bigEndian = (Format)new AudioFormat(null, -1.0D, -1, -1, 1, 1);
    this.supportedInputs = new Format[1];
    this.supportedInputs[0] = (Format)new AudioFormat(null);
    this.supportedOutputs = new ContentDescriptor[1];
    this.supportedOutputs[0] = (ContentDescriptor)new FileTypeDescriptor("audio.x_aiff");
  }
  
  public Format setInputFormat(Format format, int trackID) {
    String reason = null;
    if (!(format instanceof AudioFormat))
      return null; 
    this.audioFormat = (AudioFormat)format;
    String encodingString = this.audioFormat.getEncoding();
    this.sampleSizeInBits = this.audioFormat.getSampleSizeInBits();
    this.sampleRate = this.audioFormat.getSampleRate();
    this.channels = this.audioFormat.getChannels();
    this.blockAlign = this.channels * this.sampleSizeInBits / 8;
    if (encodingString.equalsIgnoreCase("LINEAR")) {
      if (this.sampleSizeInBits > 8 && this.audioFormat.getEndian() == 0)
        return null; 
      if (this.audioFormat.getSigned() == 0)
        return null; 
      if (this.audioFormat.getEndian() == -1 || this.audioFormat.getSigned() == -1)
        format = this.audioFormat.intersects(this.bigEndian); 
      this.formType = "AIFF";
      this.aiffEncoding = "NONE";
    } else {
      this.formType = "AIFC";
      if (encodingString.equalsIgnoreCase("ULAW")) {
        this.aiffEncoding = "ulaw";
      } else if (encodingString.equalsIgnoreCase("alaw")) {
        this.aiffEncoding = "alaw";
      } else if (encodingString.equalsIgnoreCase("ima4")) {
        this.aiffEncoding = "ima4";
        this.blockAlign = 34 * this.channels;
      } else if (encodingString.equalsIgnoreCase("MAC3")) {
        this.aiffEncoding = encodingString;
        this.blockAlign = 2;
      } else if (encodingString.equalsIgnoreCase("MAC6")) {
        this.aiffEncoding = encodingString;
        this.blockAlign = 1;
      } else {
        reason = "Cannot handle encoding " + encodingString;
      } 
    } 
    if (reason == null) {
      this.inputs[0] = format;
      return format;
    } 
    return null;
  }
  
  protected void writeFooter() {
    byte[] dummy = { 0 };
    this.dataSize = this.filePointer - this.headerSize;
    if ((this.filePointer & 0x1) != 0)
      write(dummy, 0, 1); 
    bufClear();
    seek(4);
    bufWriteInt(this.fileSize);
    bufFlush();
    bufClear();
    seek(this.maxFramesOffset);
    this.maxFrames = this.dataSize / this.blockAlign;
    bufWriteInt(this.maxFrames);
    bufFlush();
    bufClear();
    seek(this.dataSizeOffset);
    bufWriteInt(this.dataSize + 8);
    bufFlush();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\multiplexer\audio\AIFFMux.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */