package com.sun.media.multiplexer.audio;

import com.sun.media.multiplexer.BasicMux;
import javax.media.Format;
import javax.media.format.AudioFormat;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.FileTypeDescriptor;

public class AUMux extends BasicMux {
  private static final int HEADER_SIZE = 24;
  
  private static final int UNKNOWN_ENCODING = -1;
  
  private AudioFormat audioFormat;
  
  private int sampleSizeInBits;
  
  private int encoding;
  
  private double sampleRate;
  
  private int channels;
  
  private static final int AU_SUN_MAGIC = 779316836;
  
  private static final int AU_ULAW_8 = 1;
  
  private static final int AU_ALAW_8 = 27;
  
  private static final int AU_LINEAR_8 = 2;
  
  private static final int AU_LINEAR_16 = 3;
  
  private static final int AU_LINEAR_24 = 4;
  
  private static final int AU_LINEAR_32 = 5;
  
  private static final int AU_FLOAT = 6;
  
  private static final int AU_DOUBLE = 7;
  
  Format bigEndian;
  
  public AUMux() {
    this.bigEndian = (Format)new AudioFormat(null, -1.0D, -1, -1, 1, 1);
    this.supportedInputs = new Format[1];
    this.supportedInputs[0] = (Format)new AudioFormat(null);
    this.supportedOutputs = new ContentDescriptor[1];
    this.supportedOutputs[0] = (ContentDescriptor)new FileTypeDescriptor("audio.basic");
  }
  
  public String getName() {
    return "Basic Audio Multiplexer";
  }
  
  public int setNumTracks(int nTracks) {
    if (nTracks != 1)
      return 1; 
    return super.setNumTracks(nTracks);
  }
  
  protected void writeHeader() {
    bufClear();
    bufWriteInt(779316836);
    bufWriteInt(24);
    bufWriteInt(-1);
    bufWriteInt(this.encoding);
    bufWriteInt((int)this.sampleRate);
    bufWriteInt(this.channels);
    bufFlush();
  }
  
  public Format setInputFormat(Format format, int trackID) {
    String reason = null;
    if (!(format instanceof AudioFormat))
      return null; 
    this.audioFormat = (AudioFormat)format;
    String encodingString = this.audioFormat.getEncoding();
    this.sampleSizeInBits = this.audioFormat.getSampleSizeInBits();
    if (encodingString.equalsIgnoreCase("LINEAR")) {
      if (this.sampleSizeInBits > 8 && this.audioFormat.getEndian() == 0)
        return null; 
      if (this.audioFormat.getSigned() == 0)
        return null; 
      if (this.audioFormat.getEndian() == -1 || this.audioFormat.getSigned() == -1)
        this.audioFormat = (AudioFormat)this.audioFormat.intersects(this.bigEndian); 
    } 
    this.encoding = getEncoding(encodingString, this.sampleSizeInBits);
    if (this.encoding == -1)
      reason = "No support for encoding " + encodingString; 
    this.sampleRate = this.audioFormat.getSampleRate();
    this.channels = this.audioFormat.getChannels();
    if (reason == null)
      return (Format)this.audioFormat; 
    return null;
  }
  
  protected void writeFooter() {
    seek(8);
    bufClear();
    bufWriteInt(this.fileSize - 24);
    bufFlush();
  }
  
  private int getEncoding(String encodingString, int sampleSizeInBits) {
    if (encodingString.equalsIgnoreCase("ULAW"))
      return 1; 
    if (encodingString.equalsIgnoreCase("alaw"))
      return 27; 
    if (encodingString.equalsIgnoreCase("LINEAR")) {
      if (sampleSizeInBits == 8)
        return 2; 
      if (sampleSizeInBits == 16)
        return 3; 
      if (sampleSizeInBits == 24)
        return 4; 
      if (sampleSizeInBits == 32)
        return 5; 
      return -1;
    } 
    if (encodingString.equalsIgnoreCase("float"))
      return 6; 
    if (encodingString.equalsIgnoreCase("double"))
      return 7; 
    return -1;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\multiplexer\audio\AUMux.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */