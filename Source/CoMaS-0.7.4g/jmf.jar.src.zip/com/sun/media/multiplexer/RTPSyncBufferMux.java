package com.sun.media.multiplexer;

import com.sun.media.rtp.FormatInfo;
import com.sun.media.rtp.RTPSessionMgr;
import javax.media.Format;
import javax.media.protocol.ContentDescriptor;

public class RTPSyncBufferMux extends RawSyncBufferMux {
  FormatInfo rtpFormats = new FormatInfo();
  
  public RTPSyncBufferMux() {
    this.supported = new ContentDescriptor[1];
    this.supported[0] = new ContentDescriptor("raw.rtp");
    this.monoIncrTime = true;
  }
  
  public String getName() {
    return "RTP Sync Buffer Multiplexer";
  }
  
  public Format setInputFormat(Format input, int trackID) {
    if (!RTPSessionMgr.formatSupported(input))
      return null; 
    return super.setInputFormat(input, trackID);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\multiplexer\RTPSyncBufferMux.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */