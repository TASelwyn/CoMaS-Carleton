package com.sun.media.multiplexer.video;

import com.sun.media.BasicPlugIn;
import com.sun.media.format.AviVideoFormat;
import com.sun.media.format.WavAudioFormat;
import com.sun.media.multiplexer.BasicMux;
import com.sun.media.parser.BasicPullParser;
import com.sun.media.util.ByteBuffer;
import java.awt.Dimension;
import java.io.IOException;
import java.util.Vector;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.format.AudioFormat;
import javax.media.format.RGBFormat;
import javax.media.format.VideoFormat;
import javax.media.format.YUVFormat;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.FileTypeDescriptor;

public class AVIMux extends BasicMux {
  private int[] suggestedBufferSizes;
  
  private int[] suggestedBufferSizeOffsets;
  
  private int[] scaleOffsets;
  
  private boolean[] endOfMediaStatus;
  
  private int numberOfEoms = 0;
  
  private int width = 0;
  
  private int height = 0;
  
  private static final int MAX_FRAMES_STORED = 20000;
  
  private static final int AVIH_HEADER_LENGTH = 56;
  
  private static final int STRH_HEADER_LENGTH = 56;
  
  private static final int STRF_VIDEO_HEADER_LENGTH = 40;
  
  private static final int STRF_AUDIO_HEADER_LENGTH = 16;
  
  static final String AUDIO = "auds";
  
  static final String VIDEO = "vids";
  
  static final int AVIF_HASINDEX = 16;
  
  static final int AVIF_MUSTUSEINDEX = 32;
  
  static final int AVIF_ISINTERLEAVED = 256;
  
  static final int AVIF_WASCAPTUREFILE = 65536;
  
  static final int AVIF_COPYRIGHTED = 131072;
  
  static final int AVIF_KEYFRAME = 16;
  
  private int usecPerFrame = -1;
  
  private float frameRate = -1.0F;
  
  private int maxBytesPerSecond;
  
  private int paddingGranularity;
  
  private long avgFrameTime;
  
  private int flags = 16;
  
  private int totalDataLength = 0;
  
  private int totalFrames = 0;
  
  private int totalVideoFrames = 0;
  
  private int initialFrames;
  
  private int[] reserved = new int[4];
  
  private Vector chunkList = new Vector(1);
  
  private final int BUF_SIZE = 16384;
  
  private ByteBuffer bbuf = new ByteBuffer(16384);
  
  private int chunkOffset = 4;
  
  private int moviOffset = 0;
  
  private int avihOffset = 0;
  
  private int hdrlSizeOffset = 0;
  
  private int totalStrlLength = 0;
  
  private int blockAlign = 1;
  
  private int samplesPerBlock = -1;
  
  private double sampleRate = 0.0D;
  
  private double audioDuration = 0.0D;
  
  private int averageBytesPerSecond = -1;
  
  private int mp3BitRate = -1;
  
  private long cumulativeInterFrameTimeVideo = 0L;
  
  private long previousTimeStampVideo = 0L;
  
  static final String LISTRECORDCHUNK = "rec ";
  
  static final String VIDEO_MAGIC = "dc";
  
  static final String VIDEO_MAGIC_JPEG = "db";
  
  static final String VIDEO_MAGIC_IV32a = "iv";
  
  static final String VIDEO_MAGIC_IV32b = "32";
  
  static final String VIDEO_MAGIC_IV31 = "31";
  
  static final String VIDEO_MAGIC_CVID = "id";
  
  static final String AUDIO_MAGIC = "wb";
  
  Format littleEndian;
  
  Format signed;
  
  Format unsigned;
  
  private Format[] createRGBFormats(Dimension size) {
    int NS = -1;
    Format[] rgbFormats = { (Format)new RGBFormat(size, size.width * size.height * 2, Format.byteArray, NS, 16, 31744, 992, 31, 2, size.width * 2, 1, 1), (Format)new RGBFormat(size, size.width * size.height * 3, Format.byteArray, NS, 24, 3, 2, 1, 3, size.width * 3, 1, NS), (Format)new RGBFormat(size, size.width * size.height * 4, Format.byteArray, NS, 32, 3, 2, 1, 4, size.width * 4, 1, NS) };
    return rgbFormats;
  }
  
  private Format[] createYUVFormats(Dimension size) {
    int NS = -1;
    Format[] yuvFormats = { (Format)new YUVFormat(size, size.width * size.height * 2, Format.byteArray, NS, 32, size.width * 2, size.width * 2, 1, 0, 2), (Format)new YUVFormat(size, size.width * size.height * 2, Format.byteArray, NS, 32, size.width * 2, size.width * 2, 0, 1, 3), (Format)new YUVFormat(size, size.width * size.height * 3 / 2, Format.byteArray, NS, 2, size.width, size.width / 2, 0, size.width * size.height, size.width * size.height * 5 / 4), (Format)new YUVFormat(size, size.width * size.height * 3 / 2, Format.byteArray, NS, 2, size.width, size.width / 2, 0, size.width * size.height * 5 / 4, size.width * size.height) };
    return yuvFormats;
  }
  
  public String getName() {
    return "AVI Multiplexer";
  }
  
  public AVIMux() {
    this.littleEndian = (Format)new AudioFormat(null, -1.0D, -1, -1, 0, -1);
    this.signed = (Format)new AudioFormat(null, -1.0D, -1, -1, 0, 1);
    this.unsigned = (Format)new AudioFormat(null, -1.0D, -1, -1, 0, 0);
    this.supportedInputs = new Format[2];
    this.supportedInputs[0] = (Format)new AudioFormat(null);
    this.supportedInputs[1] = (Format)new VideoFormat(null);
    this.supportedOutputs = new ContentDescriptor[1];
    this.supportedOutputs[0] = (ContentDescriptor)new FileTypeDescriptor("video.x_msvideo");
    this.chunkList.addElement(this.bbuf);
  }
  
  public Format setInputFormat(Format input, int trackID) {
    AudioFormat audioFormat;
    String reason = null;
    if (input instanceof AudioFormat) {
      AudioFormat af = (AudioFormat)input;
      WavAudioFormat wavAudioFormat = null;
      if (input instanceof WavAudioFormat)
        wavAudioFormat = (WavAudioFormat)input; 
      String encoding = af.getEncoding();
      if (encoding == null)
        return null; 
      if (encoding.equalsIgnoreCase("LINEAR"))
        if (af.getSampleSizeInBits() > 8) {
          if (af.getEndian() == 1)
            return null; 
          if (af.getSigned() == 0)
            return null; 
          if (af.getEndian() == -1 || af.getSigned() == -1)
            audioFormat = (AudioFormat)af.intersects(this.signed); 
        } else {
          if (af.getSigned() == 1)
            return null; 
          if (af.getEndian() == -1 || af.getSigned() == -1)
            audioFormat = (AudioFormat)af.intersects(this.unsigned); 
        }  
      Integer formatTag = (Integer)WavAudioFormat.reverseFormatMapper.get(encoding.toLowerCase());
      if (formatTag == null || af.getEncoding().equalsIgnoreCase("truespeech") || af.getEncoding().toLowerCase().startsWith("voxware")) {
        reason = "Cannot handle format";
        return null;
      } 
      short wFormatTag = formatTag.shortValue();
      switch (wFormatTag) {
        case 2:
        case 17:
        case 49:
          if (wavAudioFormat == null) {
            reason = "A WavAudioFormat is required  to provide encoding specific information for this encoding " + wFormatTag;
            return null;
          } 
          break;
      } 
    } else if (audioFormat instanceof VideoFormat) {
      VideoFormat vf = (VideoFormat)audioFormat;
      String encoding = vf.getEncoding();
      Dimension size = vf.getSize();
      if (size == null)
        size = new Dimension(320, 240); 
      if (encoding == null)
        return null; 
      if (encoding.equalsIgnoreCase("rgb")) {
        if (BasicPlugIn.matches((Format)vf, createRGBFormats(size)) == null)
          return null; 
      } else if (encoding.equalsIgnoreCase("yuv")) {
        if (BasicPlugIn.matches((Format)vf, createYUVFormats(size)) == null)
          return null; 
      } else {
        if (encoding.equalsIgnoreCase("jpeg"))
          return null; 
        if (encoding.length() > 4)
          return null; 
      } 
      this.frameRate = vf.getFrameRate();
      if (this.frameRate > 0.0F)
        this.usecPerFrame = (int)(1.0F / this.frameRate * 1000000.0F); 
      this.avgFrameTime = (this.usecPerFrame * 1000);
    } else {
      reason = "Can only support Audio and Video formats";
    } 
    if (reason != null)
      return null; 
    this.inputs[trackID] = (Format)audioFormat;
    return (Format)audioFormat;
  }
  
  public int setNumTracks(int nTracks) {
    if (nTracks > 2)
      return 2; 
    this.suggestedBufferSizeOffsets = new int[nTracks];
    this.suggestedBufferSizes = new int[nTracks];
    this.endOfMediaStatus = new boolean[nTracks];
    for (int i = 0; i < nTracks; i++) {
      this.suggestedBufferSizes[i] = -1;
      this.suggestedBufferSizeOffsets[i] = -1;
    } 
    return super.setNumTracks(nTracks);
  }
  
  public synchronized int doProcess(Buffer buffer, int trackID) {
    if (buffer.isEOM()) {
      this.numberOfEoms++;
      if (this.numberOfEoms >= this.numTracks)
        return super.doProcess(buffer, trackID); 
      return 0;
    } 
    if (buffer.getData() == null)
      return 0; 
    boolean isVideoFormat = buffer.getFormat() instanceof VideoFormat;
    if (isVideoFormat) {
      long timeStamp = buffer.getTimeStamp();
      if ((timeStamp - this.previousTimeStampVideo) > this.avgFrameTime * 1.9D) {
        int blankFrames = (int)((timeStamp - this.previousTimeStampVideo) / this.avgFrameTime);
        for (int i = 0; i < blankFrames; i++) {
          Buffer blankBuffer = new Buffer();
          blankBuffer.setTimeStamp(this.previousTimeStampVideo + i * this.avgFrameTime);
          blankBuffer.setFormat(buffer.getFormat());
          blankBuffer.setDuration(this.avgFrameTime);
          blankBuffer.setSequenceNumber(buffer.getSequenceNumber());
          blankBuffer.setFlags(buffer.getFlags() & 0xFFFFFFEF);
          int result = writeFrame(blankBuffer, trackID);
          if (result != 0)
            return result; 
        } 
      } 
    } 
    return writeFrame(buffer, trackID);
  }
  
  private int writeFrame(Buffer buffer, int trackID) {
    byte b;
    boolean isVideoFormat = buffer.getFormat() instanceof VideoFormat;
    int length = buffer.getLength();
    if ((length & 0x1) > 0) {
      b = 1;
    } else {
      b = 0;
    } 
    String aviEncodingMagic = getAviEncodingMagic(trackID, isVideoFormat);
    bufClear();
    bufWriteBytes(aviEncodingMagic);
    bufWriteIntLittleEndian(length + b);
    bufFlush();
    if (length > 0)
      write((byte[])buffer.getData(), buffer.getOffset(), length); 
    if (b > 0) {
      bufClear();
      bufWriteByte((byte)0);
      bufFlush();
    } 
    this.totalDataLength += length + b;
    if (length > this.suggestedBufferSizes[trackID])
      this.suggestedBufferSizes[trackID] = length; 
    if (this.bbuf.length == 16384) {
      this.bbuf = new ByteBuffer(16384);
      this.chunkList.addElement(this.bbuf);
    } 
    this.bbuf.writeBytes(aviEncodingMagic);
    int flag = ((buffer.getFlags() & 0x10) != 0) ? 16 : 0;
    this.bbuf.writeIntLittleEndian(flag);
    this.bbuf.writeIntLittleEndian(this.chunkOffset);
    this.bbuf.writeIntLittleEndian(length);
    this.chunkOffset += length + b + 8;
    if (isVideoFormat) {
      long timeStamp = buffer.getTimeStamp();
      if (this.totalVideoFrames > 0)
        this.cumulativeInterFrameTimeVideo += timeStamp - this.previousTimeStampVideo; 
      this.previousTimeStampVideo = timeStamp;
      this.totalVideoFrames++;
    } else if (this.samplesPerBlock != -1) {
      int numBlocks = length / this.blockAlign;
      int numSamples = numBlocks * this.samplesPerBlock;
      this.audioDuration += numSamples / this.sampleRate;
    } else if (this.averageBytesPerSecond > 0) {
      this.audioDuration += length / this.averageBytesPerSecond;
    } 
    this.totalFrames++;
    return 0;
  }
  
  protected void writeHeader() {
    for (int i = 0; i < this.inputs.length; i++) {
      if (this.inputs[i] instanceof AudioFormat) {
        AudioFormat af = (AudioFormat)this.inputs[i];
        WavAudioFormat wavAudioFormat = null;
        this.sampleRate = af.getSampleRate();
        if (af.getEncoding().equalsIgnoreCase("LINEAR"))
          this.samplesPerBlock = 1; 
        if (this.inputs[i] instanceof WavAudioFormat) {
          wavAudioFormat = (WavAudioFormat)this.inputs[i];
          byte[] codecSpecificHeader = wavAudioFormat.getCodecSpecificHeader();
          if (!af.getEncoding().equalsIgnoreCase("mpeglayer3") && codecSpecificHeader != null && codecSpecificHeader.length >= 2)
            try {
              this.samplesPerBlock = BasicPullParser.parseShortFromArray(codecSpecificHeader, false);
            } catch (IOException e) {
              System.err.println("Unable to parse codecSpecificHeader");
            }  
        } 
      } 
    } 
    bufClear();
    bufWriteBytes("RIFF");
    bufSkip(4);
    bufWriteBytes("AVI ");
    bufWriteBytes("LIST");
    this.hdrlSizeOffset = this.filePointer;
    bufSkip(4);
    bufWriteBytes("hdrl");
    bufWriteBytes("avih");
    bufWriteIntLittleEndian(56);
    this.avihOffset = this.filePointer;
    bufSkip(56);
    this.scaleOffsets = new int[this.numTracks];
    for (int j = 0; j < this.numTracks; j++) {
      Format format = this.inputs[j];
      boolean isVideo = format instanceof VideoFormat;
      bufWriteBytes("LIST");
      byte[] codecSpecificHeader = null;
      int extraByteLength = 0;
      AviVideoFormat aviVideoFormat = null;
      WavAudioFormat wavAudioFormat = null;
      int planes = 1;
      int depth = 24;
      String yuvEncoding = null;
      String encoding = format.getEncoding();
      int wFormatTag = -1;
      if (isVideo) {
        int bytesInBitmap = 40;
        RGBFormat rgbFormat = null;
        if (format instanceof RGBFormat) {
          rgbFormat = (RGBFormat)format;
        } else if (format instanceof YUVFormat) {
          YUVFormat yuv = (YUVFormat)format;
          if (yuv.getYuvType() == 32 && yuv.getStrideY() == (yuv.getSize()).width * 2 && yuv.getOffsetY() == 0 && yuv.getOffsetU() == 1 && yuv.getOffsetV() == 3) {
            yuvEncoding = "YUY2";
          } else if (yuv.getYuvType() == 32 && yuv.getStrideY() == (yuv.getSize()).width * 2 && yuv.getOffsetY() == 1 && yuv.getOffsetU() == 0 && yuv.getOffsetV() == 2) {
            yuvEncoding = "UYVY";
          } else if (yuv.getYuvType() == 32 && yuv.getStrideY() == (yuv.getSize()).width * 2 && yuv.getOffsetY() == 0 && yuv.getOffsetU() == 3 && yuv.getOffsetV() == 1) {
            yuvEncoding = "YVYU";
          } else if (yuv.getYuvType() == 2 && 
            yuv.getStrideY() == (yuv.getSize()).width && yuv.getStrideUV() == (yuv.getSize()).width / 2) {
            if (yuv.getOffsetU() < yuv.getOffsetV()) {
              yuvEncoding = "I420";
            } else {
              yuvEncoding = "YV12";
            } 
          } 
        } 
        if (format instanceof AviVideoFormat)
          aviVideoFormat = (AviVideoFormat)format; 
        if (aviVideoFormat != null) {
          planes = aviVideoFormat.getPlanes();
          depth = aviVideoFormat.getBitsPerPixel();
          codecSpecificHeader = aviVideoFormat.getCodecSpecificHeader();
        } else if (rgbFormat != null) {
          depth = rgbFormat.getBitsPerPixel();
        } 
      } else {
        if (format instanceof WavAudioFormat) {
          wavAudioFormat = (WavAudioFormat)format;
          codecSpecificHeader = wavAudioFormat.getCodecSpecificHeader();
        } 
        if (codecSpecificHeader == null) {
          Integer formatTag = (Integer)WavAudioFormat.reverseFormatMapper.get(encoding.toLowerCase());
          if (formatTag != null) {
            wFormatTag = formatTag.shortValue();
            if (wFormatTag == 85)
              extraByteLength = 12; 
          } 
        } 
      } 
      if (extraByteLength <= 0 && codecSpecificHeader != null)
        extraByteLength = codecSpecificHeader.length; 
      int strlLength = 0;
      if (isVideo) {
        strlLength = 116 + extraByteLength;
        bufWriteIntLittleEndian(strlLength);
      } else {
        if (extraByteLength > 0) {
          strlLength = 92 + extraByteLength + 2;
        } else {
          strlLength = 92;
        } 
        bufWriteIntLittleEndian(strlLength);
      } 
      this.totalStrlLength += strlLength;
      bufWriteBytes("strl");
      bufWriteBytes("strh");
      bufWriteIntLittleEndian(56);
      if (isVideo) {
        bufWriteBytes("vids");
        if (encoding.startsWith("rgb")) {
          encoding = "DIB ";
        } else if (yuvEncoding != null) {
          encoding = yuvEncoding;
        } 
        bufWriteBytes(encoding);
      } else {
        bufWriteBytes("auds");
        bufWriteIntLittleEndian(0);
      } 
      bufWriteIntLittleEndian(0);
      bufWriteIntLittleEndian(0);
      bufWriteIntLittleEndian(0);
      this.scaleOffsets[j] = this.filePointer;
      bufWriteIntLittleEndian(1);
      bufWriteIntLittleEndian(15);
      bufWriteIntLittleEndian(0);
      bufWriteIntLittleEndian(0);
      this.suggestedBufferSizeOffsets[j] = this.filePointer;
      bufWriteIntLittleEndian(0);
      bufWriteIntLittleEndian(10000);
      bufWriteIntLittleEndian(0);
      bufWriteIntLittleEndian(0);
      bufWriteIntLittleEndian(0);
      bufWriteBytes("strf");
      if (isVideo) {
        bufWriteIntLittleEndian(40 + extraByteLength);
        bufWriteIntLittleEndian(40 + extraByteLength);
        this.width = (((VideoFormat)format).getSize()).width;
        this.height = (((VideoFormat)format).getSize()).height;
        bufWriteIntLittleEndian(this.width);
        bufWriteIntLittleEndian(this.height);
        bufWriteShortLittleEndian((short)planes);
        bufWriteShortLittleEndian((short)depth);
        if (encoding.startsWith("DIB")) {
          bufWriteIntLittleEndian(0);
        } else {
          bufWriteBytes(encoding);
        } 
        int biSizeImage = 0;
        int biXPelsPerMeter = 0;
        int biYPelsPerMeter = 0;
        int biClrUsed = 0;
        int biClrImportant = 0;
        if (aviVideoFormat != null) {
          if (aviVideoFormat.getImageSize() != -1)
            biSizeImage = aviVideoFormat.getImageSize(); 
          if (aviVideoFormat.getXPelsPerMeter() != -1)
            biXPelsPerMeter = aviVideoFormat.getXPelsPerMeter(); 
          if (aviVideoFormat.getYPelsPerMeter() != -1)
            biYPelsPerMeter = aviVideoFormat.getYPelsPerMeter(); 
          if (aviVideoFormat.getClrUsed() != -1)
            biClrUsed = aviVideoFormat.getClrUsed(); 
          if (aviVideoFormat.getClrImportant() != -1)
            biClrImportant = aviVideoFormat.getClrImportant(); 
        } 
        bufWriteIntLittleEndian(biSizeImage);
        bufWriteIntLittleEndian(biXPelsPerMeter);
        bufWriteIntLittleEndian(biYPelsPerMeter);
        bufWriteIntLittleEndian(biClrUsed);
        bufWriteIntLittleEndian(biClrImportant);
      } else {
        AudioFormat audioFormat = (AudioFormat)format;
        if (extraByteLength > 0) {
          bufWriteIntLittleEndian(16 + extraByteLength + 2);
        } else {
          bufWriteIntLittleEndian(16);
        } 
        if (encoding.equals("unknown"))
          encoding = "LINEAR"; 
        Integer formatTag = (Integer)WavAudioFormat.reverseFormatMapper.get(encoding.toLowerCase());
        if (formatTag != null) {
          bufWriteShortLittleEndian(formatTag.shortValue());
          short numChannels = (short)audioFormat.getChannels();
          bufWriteShortLittleEndian(numChannels);
          bufWriteIntLittleEndian((int)audioFormat.getSampleRate());
          short sampleSizeInBits = (short)audioFormat.getSampleSizeInBits();
          if (wavAudioFormat != null) {
            this.averageBytesPerSecond = wavAudioFormat.getAverageBytesPerSecond();
            if (formatTag.shortValue() == 85)
              this.mp3BitRate = this.averageBytesPerSecond * 8; 
          } else if (formatTag.shortValue() == 85) {
            int frameRate = (int)audioFormat.getFrameRate();
            if (frameRate != -1) {
              this.averageBytesPerSecond = frameRate;
              this.mp3BitRate = this.averageBytesPerSecond * 8;
            } else {
              this.averageBytesPerSecond = (int)audioFormat.getSampleRate() * numChannels * sampleSizeInBits / 8;
            } 
          } else {
            this.averageBytesPerSecond = (int)audioFormat.getSampleRate() * numChannels * sampleSizeInBits / 8;
          } 
          bufWriteIntLittleEndian(this.averageBytesPerSecond);
          this.blockAlign = audioFormat.getFrameSizeInBits() / 8;
          if (this.blockAlign < 1)
            this.blockAlign = sampleSizeInBits * numChannels / 8; 
          if (this.blockAlign == 0)
            this.blockAlign = 1; 
          if (this.mp3BitRate > 0)
            this.blockAlign = 1; 
          bufWriteShortLittleEndian((short)this.blockAlign);
          bufWriteShortLittleEndian(sampleSizeInBits);
        } 
      } 
      if (extraByteLength > 0)
        if (!isVideo) {
          if (codecSpecificHeader != null) {
            bufWriteShortLittleEndian((short)codecSpecificHeader.length);
            bufWriteBytes(codecSpecificHeader);
          } else {
            Integer formatTag = (Integer)WavAudioFormat.reverseFormatMapper.get(encoding.toLowerCase());
            if (formatTag != null) {
              wFormatTag = formatTag.shortValue();
              if (wFormatTag == 85) {
                char c;
                AudioFormat af = (AudioFormat)this.inputs[j];
                int frameRate = (int)af.getFrameRate();
                if (frameRate > 0) {
                  float temp = 72.0F * frameRate * 8.0F / 8000.0F;
                  temp = (float)(temp * 8000.0D / af.getSampleRate());
                  c = (int)temp;
                } else {
                  c = 'ơ';
                } 
                bufWriteShortLittleEndian((short)12);
                bufWriteShortLittleEndian((short)1);
                bufWriteIntLittleEndian(2);
                bufWriteShortLittleEndian((short)c);
                bufWriteShortLittleEndian((short)1);
                bufWriteShortLittleEndian((short)1393);
              } 
            } 
          } 
        } else {
          bufWriteBytes(codecSpecificHeader);
        }  
    } 
    bufWriteBytes("LIST");
    this.moviOffset = this.filePointer;
    bufSkip(4);
    bufWriteBytes("movi");
    bufFlush();
    seek(this.hdrlSizeOffset);
    int hdrlSize = this.totalStrlLength + 56 + 4 * (3 + 2 * this.numTracks);
    bufClear();
    bufWriteIntLittleEndian(hdrlSize);
    bufFlush();
    seek(this.moviOffset + 8);
  }
  
  protected void writeFooter() {
    writeIDX1Chunk();
    writeAVIH();
    seek(this.moviOffset);
    bufClear();
    bufWriteIntLittleEndian(4 + this.totalDataLength + this.totalFrames * 8);
    bufFlush();
    for (int i = 0; i < this.numTracks; i++) {
      int offset = this.suggestedBufferSizeOffsets[i];
      if (offset > 0) {
        seek(offset);
        bufClear();
        bufWriteIntLittleEndian(this.suggestedBufferSizes[i]);
        bufFlush();
      } 
      seek(this.scaleOffsets[i]);
      if (this.inputs[i] instanceof VideoFormat) {
        int rateVal = 10000;
        bufClear();
        bufWriteIntLittleEndian(this.usecPerFrame / 100);
        bufWriteIntLittleEndian(rateVal);
        bufWriteIntLittleEndian(0);
        bufWriteIntLittleEndian(this.totalVideoFrames);
        bufFlush();
      } else {
        AudioFormat audioFormat = (AudioFormat)this.inputs[i];
        if (this.mp3BitRate > 0) {
          bufClear();
          bufWriteIntLittleEndian(8);
          bufFlush();
          bufClear();
          bufWriteIntLittleEndian(this.mp3BitRate);
          bufFlush();
          this.blockAlign = 1;
        } else {
          bufClear();
          bufWriteIntLittleEndian(this.blockAlign);
          bufFlush();
          int factor = 1;
          if (this.samplesPerBlock > 0)
            factor = this.samplesPerBlock; 
          int rate = (int)(audioFormat.getSampleRate() / factor * this.blockAlign);
          bufClear();
          bufWriteIntLittleEndian(rate);
          bufFlush();
        } 
        seek(this.filePointer + 16);
        bufClear();
        bufWriteIntLittleEndian(this.blockAlign);
        bufFlush();
      } 
    } 
    seek(4);
    bufClear();
    bufWriteIntLittleEndian(this.fileSize - 8);
    bufFlush();
  }
  
  private void writeIDX1Chunk() {
    bufClear();
    bufWriteBytes("idx1");
    bufWriteIntLittleEndian(this.totalFrames * 16);
    bufFlush();
    for (int i = 0; i < this.chunkList.size(); i++) {
      ByteBuffer bbuf = this.chunkList.elementAt(i);
      write(bbuf.buffer, 0, bbuf.length);
    } 
  }
  
  private void writeAVIH() {
    int audioFrames = 0;
    if (this.totalVideoFrames <= 0) {
      this.usecPerFrame = 1000;
      audioFrames = (int)(this.audioDuration * 1000000.0D / this.usecPerFrame);
    } else {
      int computedUsecPerFrame = (int)(this.cumulativeInterFrameTimeVideo / 1000.0D * (this.totalVideoFrames - 1));
      this.usecPerFrame = computedUsecPerFrame;
    } 
    seek(this.avihOffset);
    bufClear();
    bufWriteIntLittleEndian(this.usecPerFrame);
    bufWriteIntLittleEndian(this.maxBytesPerSecond);
    bufWriteIntLittleEndian(this.paddingGranularity);
    bufWriteIntLittleEndian(this.flags);
    if (this.totalVideoFrames > 0) {
      bufWriteIntLittleEndian(this.totalVideoFrames);
    } else {
      bufWriteIntLittleEndian(audioFrames);
    } 
    bufWriteIntLittleEndian(this.initialFrames);
    bufWriteIntLittleEndian(this.numTracks);
    bufWriteIntLittleEndian(0);
    bufWriteIntLittleEndian(this.width);
    bufWriteIntLittleEndian(this.height);
    bufWriteIntLittleEndian(0);
    bufWriteIntLittleEndian(0);
    bufWriteIntLittleEndian(0);
    bufWriteIntLittleEndian(0);
    bufFlush();
  }
  
  private String getAviEncodingMagic(int streamNumber, boolean isVideoFormat) {
    String str1, encoding = this.inputs[streamNumber].getEncoding().toLowerCase();
    if (isVideoFormat) {
      if (encoding.equalsIgnoreCase("cvid")) {
        str1 = "id";
      } else if (encoding.startsWith("iv32")) {
        str1 = "32";
      } else if (encoding.startsWith("iv31")) {
        str1 = "31";
      } else if (encoding.startsWith("iv")) {
        str1 = "iv";
      } else {
        str1 = "dc";
      } 
    } else {
      str1 = "wb";
    } 
    String streamPrefix = null;
    if (streamNumber == 0) {
      streamPrefix = "00";
    } else if (streamNumber == 1) {
      streamPrefix = "01";
    } else if (streamNumber == 2) {
      streamPrefix = "02";
    } else if (streamNumber == 3) {
      streamPrefix = "03";
    } else if (streamNumber == 4) {
      streamPrefix = "04";
    } 
    return streamPrefix + str1;
  }
}
