/*      */ package com.sun.media.multiplexer.video;
/*      */ 
/*      */ import com.sun.media.BasicPlugIn;
/*      */ import com.sun.media.Log;
/*      */ import com.sun.media.datasink.RandomAccess;
/*      */ import com.sun.media.multiplexer.BasicMux;
/*      */ import java.awt.Dimension;
/*      */ import java.util.Hashtable;
/*      */ import javax.media.Buffer;
/*      */ import javax.media.Format;
/*      */ import javax.media.format.AudioFormat;
/*      */ import javax.media.format.RGBFormat;
/*      */ import javax.media.format.VideoFormat;
/*      */ import javax.media.format.YUVFormat;
/*      */ import javax.media.protocol.ContentDescriptor;
/*      */ import javax.media.protocol.FileTypeDescriptor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class QuicktimeMux
/*      */   extends BasicMux
/*      */ {
/*   33 */   private int removeCount = 0;
/*      */   
/*      */   private boolean sourceConnected = false;
/*      */   private boolean sinkConnected = false;
/*      */   private boolean closed = false;
/*      */   private boolean opened = false;
/*   39 */   private int debugCounter = 0;
/*      */   private Hashtable streamNumberHash;
/*      */   private TrakInfo[] trakInfoArray;
/*   42 */   private int dataSize = 0;
/*      */   
/*      */   private Format[] rgbFormats;
/*      */   
/*      */   private Format[] yuvFormats;
/*      */   
/*      */   private int[] scaleOffsets;
/*      */   private boolean[] endOfMediaStatus;
/*   50 */   private int numberOfEoms = 0;
/*   51 */   private int numberOfTracks = 0;
/*   52 */   private int numberOfSupportedTracks = 0;
/*      */   
/*      */   private static final String VIDEO = "vide";
/*      */   
/*      */   private static final String AUDIO = "soun";
/*      */   
/*      */   private long mdatOffset;
/*      */   private long moovOffset;
/*      */   private int mdatLength;
/*      */   private int moovLength;
/*      */   private long mvhdDurationOffset;
/*   63 */   private static Hashtable audioFourccMapper = new Hashtable();
/*   64 */   private static Hashtable videoFourccMapper = new Hashtable();
/*      */   
/*   66 */   private final int movieTimeScale = 60000;
/*   67 */   private final int DEFAULT_FRAME_RATE = 15;
/*   68 */   private final int DEFAULT_FRAME_DURATION = 4000;
/*      */   
/*   70 */   private final int TRAK_ENABLED = 1;
/*   71 */   private final int TRAK_IN_MOVIE = 2;
/*      */   
/*      */   private static final int DATA_SELF_REFERENCE_FLAG = 1;
/*      */   
/*      */   private static final boolean ALWAYS_USE_ONE_ENTRY_FOR_STTS = false;
/*      */   
/*      */   private static final int EPSILON_DURATION = 1000000;
/*      */   
/*      */   private static final int MVHD_ATOM_SIZE = 100;
/*      */   
/*      */   private static final int TKHD_ATOM_SIZE = 84;
/*      */   
/*      */   private static final int MDHD_ATOM_SIZE = 24;
/*      */   
/*      */   private boolean requireTwoPass = true;
/*      */   
/*      */   Format bigEndian;
/*      */ 
/*      */   
/*      */   static {
/*   91 */     audioFourccMapper.put("alaw", "alaw");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   96 */     audioFourccMapper.put("ulaw", "ulaw");
/*      */     
/*   98 */     audioFourccMapper.put("ima4", "ima4");
/*   99 */     audioFourccMapper.put("gsm", "agsm");
/*  100 */     audioFourccMapper.put("MAC3", "MAC3");
/*  101 */     audioFourccMapper.put("MAC6", "MAC6");
/*      */     
/*  103 */     videoFourccMapper.put("rgb", "rgb");
/*  104 */     videoFourccMapper.put("cvid", "cvid");
/*  105 */     videoFourccMapper.put("jpeg", "jpeg");
/*  106 */     videoFourccMapper.put("h261", "h261");
/*  107 */     videoFourccMapper.put("h263", "h263");
/*  108 */     videoFourccMapper.put("iv32", "iv32");
/*  109 */     videoFourccMapper.put("iv41", "iv41");
/*  110 */     videoFourccMapper.put("iv50", "iv50");
/*  111 */     videoFourccMapper.put("mjpg", "mjpg");
/*  112 */     videoFourccMapper.put("mjpa", "mjpa");
/*  113 */     videoFourccMapper.put("mjpb", "mjpb");
/*  114 */     videoFourccMapper.put("mpeg", "mpeg");
/*  115 */     videoFourccMapper.put("rpza", "rpza");
/*  116 */     videoFourccMapper.put("yuv", "yuv2");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  149 */     return "Quicktime Multiplexer";
/*      */   }
/*      */ 
/*      */   
/*      */   public QuicktimeMux() {
/*  154 */     this.bigEndian = (Format)new AudioFormat(null, -1.0D, -1, -1, 1, -1);
/*      */     this.supportedInputs = new Format[2];
/*      */     this.supportedInputs[0] = (Format)new AudioFormat(null);
/*      */     this.supportedInputs[1] = (Format)new VideoFormat(null);
/*      */     this.supportedOutputs = new ContentDescriptor[1];
/*      */     this.supportedOutputs[0] = (ContentDescriptor)new FileTypeDescriptor("video.quicktime");
/*      */     int NS = -1;
/*      */     this.rgbFormats = new Format[] { (Format)new RGBFormat(null, NS, Format.byteArray, NS, 16, 31744, 992, 31, 2, NS, 0, 0), (Format)new RGBFormat(null, NS, Format.byteArray, NS, 24, 1, 2, 3, 3, NS, 0, NS), (Format)new RGBFormat(null, NS, Format.byteArray, NS, 32, 2, 3, 4, 4, NS, 0, NS) };
/*  162 */     this.yuvFormats = new Format[] { (Format)new YUVFormat(null, NS, Format.byteArray, NS, 96, NS, NS, 0, 1, 3) }; } public Format setInputFormat(Format input, int trackID) { if (this.trakInfoArray == null) {
/*  163 */       this.trakInfoArray = new TrakInfo[this.numTracks];
/*  164 */       this.endOfMediaStatus = new boolean[this.numTracks];
/*      */     } 
/*  166 */     if (!(input instanceof VideoFormat) && !(input instanceof AudioFormat)) {
/*      */       
/*  168 */       this.trakInfoArray[trackID] = new TrakInfo(this);
/*  169 */       (this.trakInfoArray[trackID]).format = input;
/*  170 */       (this.trakInfoArray[trackID]).supported = false;
/*  171 */       return input;
/*      */     } 
/*      */     
/*  174 */     String encoding = input.getEncoding();
/*  175 */     if (input instanceof VideoFormat) {
/*  176 */       if (videoFourccMapper.get(encoding.toLowerCase()) == null) {
/*  177 */         return null;
/*      */       }
/*  179 */       if (encoding.equalsIgnoreCase("rgb") && 
/*  180 */         BasicPlugIn.matches(input, this.rgbFormats) == null) {
/*  181 */         return null;
/*      */       }
/*  183 */       if (encoding.equalsIgnoreCase("yuv") && 
/*  184 */         BasicPlugIn.matches(input, this.yuvFormats) == null) {
/*  185 */         return null;
/*      */       }
/*  187 */       VideoTrakInfo vti = new VideoTrakInfo(this);
/*  188 */       this.trakInfoArray[trackID] = vti;
/*  189 */       vti.supported = true;
/*  190 */       vti.type = "vide";
/*  191 */       vti.encoding = encoding;
/*  192 */       vti.format = input;
/*      */       
/*  194 */       vti.videoFormat = (VideoFormat)null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  204 */     else if (input instanceof AudioFormat) {
/*      */       
/*  206 */       if (encoding.equalsIgnoreCase("LINEAR")) {
/*  207 */         AudioFormat af = (AudioFormat)input;
/*  208 */         if (af.getSampleSizeInBits() > 8) {
/*  209 */           if (af.getSigned() == 0)
/*  210 */             return null; 
/*  211 */           if (af.getEndian() == 0)
/*  212 */             return null; 
/*  213 */           if (af.getEndian() == -1) {
/*  214 */             input = af.intersects(this.bigEndian);
/*      */           }
/*      */         } 
/*  217 */       } else if (audioFourccMapper.get(encoding.toLowerCase()) == null) {
/*  218 */         return null;
/*      */       } 
/*      */       
/*  221 */       AudioTrakInfo ati = new AudioTrakInfo(this);
/*  222 */       this.trakInfoArray[trackID] = ati;
/*  223 */       ati.supported = true;
/*  224 */       ati.type = "soun";
/*  225 */       ati.encoding = encoding;
/*  226 */       ati.format = input;
/*  227 */       ati.audioFormat = (AudioFormat)input;
/*      */       
/*  229 */       ati.frameSizeInBytes = ati.audioFormat.getFrameSizeInBits() / 8;
/*  230 */       if (ati.frameSizeInBytes <= 0) {
/*  231 */         ati.frameSizeInBytes = ati.audioFormat.getSampleSizeInBits() * ati.audioFormat.getChannels() / 8;
/*      */       }
/*      */ 
/*      */       
/*  235 */       if (encoding.equalsIgnoreCase("ima4")) {
/*  236 */         ati.samplesPerBlock = 64;
/*  237 */       } else if (encoding.equalsIgnoreCase("gsm")) {
/*  238 */         ati.samplesPerBlock = 160;
/*  239 */       } else if (encoding.equalsIgnoreCase("MAC3")) {
/*  240 */         ati.samplesPerBlock = 6;
/*  241 */       } else if (encoding.equalsIgnoreCase("MAC6")) {
/*  242 */         ati.samplesPerBlock = 6;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  250 */     if ((this.trakInfoArray[trackID]).supported) {
/*  251 */       this.numberOfSupportedTracks++;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  256 */     this.inputs[trackID] = input;
/*  257 */     return input; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int doProcess(Buffer buffer, int trackID) {
/*  264 */     if (buffer.isEOM() && 
/*  265 */       !this.endOfMediaStatus[trackID]) {
/*  266 */       this.endOfMediaStatus[trackID] = true;
/*  267 */       this.numberOfEoms++;
/*  268 */       if (this.numberOfEoms == this.numTracks) {
/*  269 */         return super.doProcess(buffer, trackID);
/*      */       }
/*  271 */       return 0;
/*      */     } 
/*      */ 
/*      */     
/*  275 */     if (!(this.trakInfoArray[trackID]).initFormat) {
/*  276 */       if (this.trakInfoArray[trackID] instanceof VideoTrakInfo) {
/*  277 */         VideoTrakInfo videoTrakInfo = (VideoTrakInfo)this.trakInfoArray[trackID];
/*  278 */         videoTrakInfo.videoFormat = (VideoFormat)buffer.getFormat();
/*  279 */         videoTrakInfo.frameRate = videoTrakInfo.videoFormat.getFrameRate();
/*      */         
/*  281 */         if (videoTrakInfo.frameRate > 0.0F) {
/*  282 */           videoTrakInfo.frameDuration = (int)((1.0F / videoTrakInfo.frameRate * 60000.0F) + 0.5D);
/*      */         } else {
/*      */           
/*  285 */           videoTrakInfo.frameRate = 15.0F;
/*  286 */           videoTrakInfo.frameDuration = 4000;
/*      */         } 
/*      */       } 
/*  289 */       (this.trakInfoArray[trackID]).initFormat = true;
/*      */     } 
/*      */ 
/*      */     
/*  293 */     Object obj = buffer.getData();
/*  294 */     if (obj == null)
/*  295 */       return 1; 
/*  296 */     byte[] data = (byte[])obj;
/*  297 */     if (data == null)
/*  298 */       return 1; 
/*  299 */     int length = buffer.getLength();
/*      */     
/*  301 */     this.dataSize += length;
/*      */     
/*  303 */     TrakInfo trakInfo = this.trakInfoArray[trackID];
/*  304 */     write(data, 0, length);
/*  305 */     int chunkOffset = this.filePointer - length;
/*      */ 
/*      */     
/*  308 */     int chunkOffsetsIndex = trakInfo.chunkOffsetsIndex++;
/*  309 */     int numChunkOffsetsArraysUsed = trakInfo.numChunkOffsetsArraysUsed;
/*  310 */     trakInfo.chunkOffsetsArray[numChunkOffsetsArraysUsed - 1][chunkOffsetsIndex] = chunkOffset;
/*      */     
/*  312 */     if (++chunkOffsetsIndex >= 1000) {
/*  313 */       trakInfo.chunkOffsetsIndex = 0;
/*  314 */       trakInfo.chunkOffsetsArray[numChunkOffsetsArraysUsed] = new int[1000];
/*      */       
/*  316 */       trakInfo.numChunkOffsetsArraysUsed++;
/*  317 */       if (++numChunkOffsetsArraysUsed >= 1000) {
/*  318 */         System.err.println("Cannot create quicktime file with more than " + (1000 * 1000) + " chunks ");
/*      */ 
/*      */         
/*  321 */         return 1;
/*      */       } 
/*      */     } 
/*      */     
/*  325 */     String type = trakInfo.type;
/*  326 */     VideoTrakInfo vti = null;
/*  327 */     AudioTrakInfo ati = null;
/*      */     
/*  329 */     if (type.equals("vide")) {
/*  330 */       vti = (VideoTrakInfo)trakInfo;
/*      */ 
/*      */       
/*  333 */       int sampleSizeIndex = vti.sampleSizeIndex++;
/*  334 */       int numSampleSizeArraysUsed = vti.numSampleSizeArraysUsed;
/*  335 */       vti.sampleSize[numSampleSizeArraysUsed - 1][sampleSizeIndex] = length;
/*  336 */       if (vti.constantSampleSize && length != vti.sampleSize[0][0]) {
/*  337 */         vti.constantSampleSize = false;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  343 */       if (vti.minDuration >= 0L) {
/*  344 */         long timeStamp = buffer.getTimeStamp();
/*  345 */         if (timeStamp <= -1L) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  351 */           vti.minDuration = -1L;
/*  352 */         } else if (vti.totalFrames > 0) {
/*  353 */           long durationOfBufferData = timeStamp - vti.previousTimeStamp;
/*  354 */           if (durationOfBufferData < vti.minDuration) {
/*  355 */             vti.minDuration = durationOfBufferData;
/*  356 */           } else if (durationOfBufferData > vti.maxDuration) {
/*  357 */             vti.maxDuration = durationOfBufferData;
/*      */           } 
/*  359 */           int timeStampIndex = vti.timeStampIndex++;
/*  360 */           int numTimeStampArraysUsed = vti.numTimeStampArraysUsed;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  365 */           vti.timeStamps[numTimeStampArraysUsed - 1][timeStampIndex] = durationOfBufferData;
/*      */ 
/*      */           
/*  368 */           if (++timeStampIndex >= 1000) {
/*  369 */             vti.timeStampIndex = 0;
/*      */             
/*  371 */             vti.timeStamps[numTimeStampArraysUsed] = new long[1000];
/*      */             
/*  373 */             vti.numTimeStampArraysUsed++;
/*  374 */             if (++numTimeStampArraysUsed >= 1000) {
/*  375 */               System.err.println("Cannot create quicktime file with more than " + (1000 * 1000) + " frames ");
/*      */ 
/*      */               
/*  378 */               return 1;
/*      */             } 
/*      */           } 
/*      */         } 
/*  382 */         vti.previousTimeStamp = timeStamp;
/*      */       } 
/*      */ 
/*      */       
/*  386 */       if (++sampleSizeIndex >= 2000) {
/*  387 */         vti.sampleSizeIndex = 0;
/*  388 */         vti.sampleSize[numSampleSizeArraysUsed] = new int[2000];
/*      */         
/*  390 */         vti.numSampleSizeArraysUsed++;
/*  391 */         if (++numSampleSizeArraysUsed >= 1000) {
/*  392 */           System.err.println("Cannot create quicktime file with more than " + (1000 * 2000) + " samples ");
/*      */ 
/*      */           
/*  395 */           return 1;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  401 */       boolean keyframe = ((buffer.getFlags() & 0x10) > 0);
/*  402 */       if (keyframe) {
/*  403 */         int keyFrameIndex = vti.keyFrameIndex++;
/*      */         
/*  405 */         int numKeyFrameArraysUsed = vti.numKeyFrameArraysUsed;
/*  406 */         vti.keyFrames[numKeyFrameArraysUsed - 1][keyFrameIndex] = vti.totalFrames + 1;
/*      */ 
/*      */ 
/*      */         
/*  410 */         if (++keyFrameIndex >= 1000) {
/*  411 */           vti.keyFrameIndex = 0;
/*      */ 
/*      */           
/*  414 */           vti.keyFrames[numKeyFrameArraysUsed] = new int[1000];
/*      */           
/*  416 */           vti.numKeyFrameArraysUsed++;
/*  417 */           if (++numKeyFrameArraysUsed >= 1000) {
/*  418 */             System.err.println("Cannot create quicktime file with more than " + (1000 * 1000) + " keyframes ");
/*      */ 
/*      */ 
/*      */             
/*  422 */             return 1;
/*      */           }
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  431 */       ati = (AudioTrakInfo)trakInfo;
/*      */ 
/*      */       
/*  434 */       int samplesPerChunk = length / ati.frameSizeInBytes * ati.samplesPerBlock;
/*      */ 
/*      */       
/*  437 */       ati.numSamples += samplesPerChunk;
/*      */       
/*  439 */       if (ati.previousSamplesPerChunk != samplesPerChunk) {
/*      */         
/*  441 */         int samplesPerChunkIndex = ati.samplesPerChunkIndex;
/*  442 */         int numSamplesPerChunkArraysUsed = ati.numSamplesPerChunkArraysUsed;
/*      */         
/*  444 */         ati.samplesPerChunkArray[numSamplesPerChunkArraysUsed - 1][samplesPerChunkIndex] = trakInfo.totalFrames + 1;
/*      */ 
/*      */ 
/*      */         
/*  448 */         samplesPerChunkIndex++;
/*  449 */         ati.samplesPerChunkArray[numSamplesPerChunkArraysUsed - 1][samplesPerChunkIndex] = samplesPerChunk;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  454 */         ati.samplesPerChunkIndex = ++samplesPerChunkIndex;
/*  455 */         ati.previousSamplesPerChunk = samplesPerChunk;
/*      */ 
/*      */         
/*  458 */         if (++samplesPerChunkIndex >= 1000) {
/*  459 */           ati.samplesPerChunkIndex = 0;
/*  460 */           ati.samplesPerChunkArray[numSamplesPerChunkArraysUsed] = new int[1000];
/*      */           
/*  462 */           ati.numSamplesPerChunkArraysUsed++;
/*  463 */           if (++numSamplesPerChunkArraysUsed >= 1000) {
/*  464 */             System.err.println("Cannot create quicktime file with more than " + (1000 * 1000) + " chunks ");
/*      */ 
/*      */ 
/*      */             
/*  468 */             return 1;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  482 */     trakInfo.totalFrames++;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  495 */     return 0;
/*      */   }
/*      */   
/*      */   protected void writeHeader() {
/*  499 */     this.mdatOffset = this.filePointer;
/*  500 */     bufClear();
/*  501 */     bufWriteInt(0);
/*  502 */     bufWriteBytes("mdat");
/*  503 */     bufFlush();
/*  504 */     this.dataSize = 0;
/*      */   }
/*      */   
/*      */   public boolean requireTwoPass() {
/*  508 */     return this.requireTwoPass;
/*      */   }
/*      */   
/*      */   protected void writeFooter() {
/*  512 */     this.moovOffset = this.filePointer;
/*  513 */     seek((int)this.mdatOffset);
/*  514 */     bufClear();
/*  515 */     this.mdatLength = 8 + this.dataSize;
/*  516 */     bufWriteInt(this.mdatLength);
/*  517 */     bufFlush();
/*  518 */     seek((int)this.moovOffset);
/*  519 */     writeMOOV();
/*  520 */     int maxTrackDuration = -1;
/*      */     
/*  522 */     for (int i = 0; i < this.numTracks; i++) {
/*  523 */       if ((this.trakInfoArray[i]).supported) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  528 */         writeSize((this.trakInfoArray[i]).tkhdDurationOffset, (this.trakInfoArray[i]).duration);
/*      */         
/*  530 */         if ((this.trakInfoArray[i]).type.equals("vide")) {
/*  531 */           writeSize((this.trakInfoArray[i]).mdhdDurationOffset, (this.trakInfoArray[i]).duration);
/*      */         }
/*      */         
/*  534 */         if ((this.trakInfoArray[i]).duration > maxTrackDuration) {
/*  535 */           maxTrackDuration = (this.trakInfoArray[i]).duration;
/*      */         }
/*      */       } 
/*      */     } 
/*  539 */     writeSize(this.mvhdDurationOffset, maxTrackDuration);
/*      */ 
/*      */     
/*  542 */     if (this.requireTwoPass && this.sth != null && this.sth instanceof RandomAccess) {
/*      */       RandomAccess st;
/*      */       
/*  545 */       if ((st = (RandomAccess)this.sth).write(-1L, this.moovLength + this.mdatLength)) {
/*  546 */         updateSTCO();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  555 */         write(null, 0, -1);
/*      */ 
/*      */         
/*  558 */         st.write(this.moovOffset, this.moovLength);
/*  559 */         st.write(this.mdatOffset, this.mdatLength);
/*      */       } else {
/*      */         
/*  562 */         System.err.println("No space to write streamable file");
/*      */       } 
/*  564 */       st.write(-1L, -1);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private int writeMOOV() {
/*  570 */     long offset = this.filePointer;
/*  571 */     bufClear();
/*  572 */     bufWriteInt(0);
/*  573 */     bufWriteBytes("moov");
/*  574 */     bufFlush();
/*      */     
/*  576 */     int size = 8;
/*  577 */     size += writeMVHD();
/*      */     
/*  579 */     for (int i = 0; i < this.numTracks; i++) {
/*  580 */       if ((this.trakInfoArray[i]).supported)
/*      */       {
/*  582 */         size += writeTRAK(i, (this.trakInfoArray[i]).type); } 
/*      */     } 
/*  584 */     this.moovLength = size;
/*  585 */     return writeSize(offset, size);
/*      */   }
/*      */ 
/*      */   
/*      */   private int writeMVHD() {
/*  590 */     bufClear();
/*  591 */     bufWriteInt(108);
/*  592 */     bufWriteBytes("mvhd");
/*  593 */     bufWriteInt(0);
/*  594 */     bufWriteInt(0);
/*  595 */     bufWriteInt(0);
/*  596 */     bufWriteInt(60000);
/*  597 */     this.mvhdDurationOffset = this.filePointer;
/*  598 */     bufWriteInt(0);
/*  599 */     bufWriteInt(65536);
/*  600 */     bufWriteShort((short)255);
/*      */ 
/*      */     
/*  603 */     bufWriteInt(0);
/*  604 */     bufWriteInt(0);
/*  605 */     bufWriteShort((short)0);
/*      */     
/*  607 */     bufFlush();
/*  608 */     writeMatrix();
/*  609 */     bufClear();
/*  610 */     bufWriteInt(0);
/*  611 */     bufWriteInt(0);
/*  612 */     bufWriteInt(0);
/*  613 */     bufWriteInt(0);
/*  614 */     bufWriteInt(0);
/*  615 */     bufWriteInt(0);
/*  616 */     bufWriteInt(this.numberOfSupportedTracks + 1);
/*  617 */     bufFlush();
/*  618 */     return 108;
/*      */   }
/*      */ 
/*      */   
/*      */   private int writeSize(long offset, int size) {
/*  623 */     long currentOffset = this.filePointer;
/*  624 */     seek((int)offset);
/*  625 */     bufClear();
/*  626 */     bufWriteInt(size);
/*  627 */     bufFlush();
/*  628 */     seek((int)currentOffset);
/*  629 */     return size;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int writeTRAK(int streamNumber, String type) {
/*  636 */     long offset = this.filePointer;
/*  637 */     bufClear();
/*  638 */     bufWriteInt(0);
/*  639 */     bufWriteBytes("trak");
/*  640 */     bufFlush();
/*  641 */     int size = 8;
/*      */     
/*  643 */     size += writeTKHD(streamNumber, type);
/*  644 */     size += writeMDIA(streamNumber, type);
/*  645 */     return writeSize(offset, size);
/*      */   }
/*      */ 
/*      */   
/*      */   private int writeTKHD(int streamNumber, String type) {
/*  650 */     int width = 0;
/*  651 */     int height = 0;
/*  652 */     int duration = 0;
/*  653 */     int volume = 0;
/*      */ 
/*      */     
/*  656 */     if (type.equals("vide")) {
/*  657 */       VideoTrakInfo videoTrakInfo = (VideoTrakInfo)this.trakInfoArray[streamNumber];
/*  658 */       Dimension size = null;
/*  659 */       VideoFormat vf = videoTrakInfo.videoFormat;
/*  660 */       if (vf != null) {
/*  661 */         size = vf.getSize();
/*      */       }
/*  663 */       if (size != null) {
/*  664 */         width = size.width;
/*  665 */         height = size.height;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  672 */       duration = videoTrakInfo.duration;
/*      */     } else {
/*  674 */       AudioTrakInfo audioTrakInfo = (AudioTrakInfo)this.trakInfoArray[streamNumber];
/*      */       
/*  676 */       float sampleRate = (int)audioTrakInfo.audioFormat.getSampleRate();
/*  677 */       float epsilon = 0.01F;
/*  678 */       duration = (int)(audioTrakInfo.numSamples / sampleRate * 60000.0F + epsilon);
/*      */       
/*  680 */       audioTrakInfo.duration = duration;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  685 */       volume = 255;
/*      */     } 
/*      */     
/*  688 */     bufClear();
/*  689 */     bufWriteInt(92);
/*  690 */     bufWriteBytes("tkhd");
/*  691 */     bufWriteInt(3);
/*  692 */     bufWriteInt(0);
/*  693 */     bufWriteInt(0);
/*  694 */     bufWriteInt(streamNumber + 1);
/*      */     
/*  696 */     bufWriteInt(0);
/*  697 */     (this.trakInfoArray[streamNumber]).tkhdDurationOffset = this.filePointer;
/*  698 */     bufWriteInt(duration);
/*  699 */     bufWriteInt(0);
/*  700 */     bufWriteInt(0);
/*      */     
/*  702 */     bufWriteShort((short)0);
/*  703 */     bufWriteShort((short)0);
/*  704 */     bufWriteShort((short)volume);
/*  705 */     bufWriteShort((short)0);
/*  706 */     bufFlush();
/*  707 */     writeMatrix();
/*  708 */     bufClear();
/*  709 */     bufWriteInt(width * 65536);
/*  710 */     bufWriteInt(height * 65536);
/*  711 */     bufFlush();
/*  712 */     return 92;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int writeMDIA(int streamNumber, String type) {
/*  719 */     long offset = this.filePointer;
/*  720 */     bufClear();
/*  721 */     bufWriteInt(0);
/*  722 */     bufWriteBytes("mdia");
/*  723 */     bufFlush();
/*  724 */     int size = 8;
/*  725 */     size += writeMDHD(streamNumber, type);
/*  726 */     size += writeMhlrHdlr(streamNumber, type);
/*  727 */     size += writeMINF(streamNumber, type);
/*  728 */     return writeSize(offset, size);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeMatrix() {
/*  734 */     bufClear();
/*  735 */     bufWriteInt(65536);
/*  736 */     bufWriteInt(0);
/*  737 */     bufWriteInt(0);
/*  738 */     bufWriteInt(0);
/*  739 */     bufWriteInt(65536);
/*  740 */     bufWriteInt(0);
/*  741 */     bufWriteInt(0);
/*  742 */     bufWriteInt(0);
/*  743 */     bufWriteInt(1073741824);
/*  744 */     bufFlush();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int writeMDHD(int streamNumber, String type) {
/*  750 */     int timeScale = 0;
/*  751 */     int duration = 0;
/*  752 */     if (type.equals("vide")) {
/*      */ 
/*      */ 
/*      */       
/*  756 */       timeScale = 60000;
/*      */       
/*  758 */       VideoTrakInfo videoTrakInfo = (VideoTrakInfo)this.trakInfoArray[streamNumber];
/*  759 */       duration = videoTrakInfo.duration;
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  769 */       AudioTrakInfo audioTrakInfo = (AudioTrakInfo)this.trakInfoArray[streamNumber];
/*  770 */       timeScale = (int)audioTrakInfo.audioFormat.getSampleRate();
/*  771 */       duration = audioTrakInfo.numSamples;
/*      */     } 
/*      */     
/*  774 */     bufClear();
/*  775 */     bufWriteInt(32);
/*  776 */     bufWriteBytes("mdhd");
/*  777 */     bufWriteInt(1);
/*  778 */     bufWriteInt(0);
/*  779 */     bufWriteInt(0);
/*  780 */     bufWriteInt(timeScale);
/*  781 */     (this.trakInfoArray[streamNumber]).mdhdDurationOffset = this.filePointer;
/*  782 */     bufWriteInt(duration);
/*  783 */     bufWriteShort((short)0);
/*  784 */     bufWriteShort((short)0);
/*  785 */     bufFlush();
/*  786 */     return 32;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int writeMINF(int streamNumber, String type) {
/*  793 */     long offset = this.filePointer;
/*  794 */     bufClear();
/*  795 */     bufWriteInt(0);
/*  796 */     bufWriteBytes("minf");
/*  797 */     bufFlush();
/*  798 */     int size = 8;
/*  799 */     if (type.equals("vide")) {
/*  800 */       size += writeVMHD(streamNumber, type);
/*      */     } else {
/*  802 */       size += writeSMHD(streamNumber, type);
/*      */     } 
/*  804 */     size += writeDHlrHdlr(streamNumber, type);
/*  805 */     size += writeDINF(streamNumber, type);
/*  806 */     size += writeSTBL(streamNumber, type);
/*  807 */     return writeSize(offset, size);
/*      */   }
/*      */ 
/*      */   
/*      */   private int writeVMHD(int streamNumber, String type) {
/*  812 */     bufClear();
/*  813 */     bufWriteInt(20);
/*  814 */     bufWriteBytes("vmhd");
/*  815 */     bufWriteInt(1);
/*  816 */     bufWriteShort((short)64);
/*  817 */     bufWriteShort(-32768);
/*  818 */     bufWriteShort(-32768);
/*  819 */     bufWriteShort(-32768);
/*  820 */     bufFlush();
/*  821 */     return 20;
/*      */   }
/*      */   
/*      */   private int writeSMHD(int streamNumber, String type) {
/*  825 */     bufClear();
/*  826 */     bufWriteInt(16);
/*  827 */     bufWriteBytes("smhd");
/*  828 */     bufWriteInt(0);
/*  829 */     bufWriteShort((short)0);
/*  830 */     bufWriteShort((short)0);
/*  831 */     bufFlush();
/*  832 */     return 16;
/*      */   }
/*      */   
/*      */   private int writeMhlrHdlr(int streamNumber, String type) {
/*  836 */     bufClear();
/*  837 */     bufWriteInt(36);
/*  838 */     bufWriteBytes("hdlr");
/*  839 */     bufWriteInt(0);
/*  840 */     bufWriteBytes("mhlr");
/*  841 */     bufWriteBytes(type);
/*  842 */     bufWriteBytes("    ");
/*  843 */     bufWriteInt(0);
/*  844 */     bufWriteInt(0);
/*  845 */     bufWriteBytes("    ");
/*  846 */     bufFlush();
/*      */     
/*  848 */     return 36;
/*      */   }
/*      */ 
/*      */   
/*      */   private int writeDHlrHdlr(int streamNumber, String type) {
/*  853 */     bufClear();
/*  854 */     bufWriteInt(36);
/*  855 */     bufWriteBytes("hdlr");
/*  856 */     bufWriteInt(0);
/*  857 */     bufWriteBytes("dhlr");
/*  858 */     bufWriteBytes("alis");
/*  859 */     bufWriteBytes("    ");
/*  860 */     bufWriteInt(0);
/*  861 */     bufWriteInt(0);
/*  862 */     bufWriteBytes("    ");
/*  863 */     bufFlush();
/*      */     
/*  865 */     return 36;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int writeDINF(int streamNumber, String type) {
/*  883 */     bufClear();
/*  884 */     bufWriteInt(36);
/*  885 */     bufWriteBytes("dinf");
/*  886 */     bufWriteInt(28);
/*  887 */     bufWriteBytes("dref");
/*  888 */     bufWriteInt(0);
/*  889 */     bufWriteInt(1);
/*  890 */     bufWriteInt(12);
/*  891 */     bufWriteBytes("alis");
/*  892 */     bufWriteInt(1);
/*  893 */     bufFlush();
/*  894 */     return 36;
/*      */   }
/*      */ 
/*      */   
/*      */   private int writeSTBL(int streamNumber, String type) {
/*  899 */     long offset = this.filePointer;
/*  900 */     bufClear();
/*  901 */     bufWriteInt(0);
/*  902 */     bufWriteBytes("stbl");
/*  903 */     bufFlush();
/*  904 */     int size = 8;
/*  905 */     size += writeSTSD(streamNumber, type);
/*  906 */     size += writeSTTS(streamNumber, type);
/*  907 */     size += writeSTSS(streamNumber, type);
/*  908 */     size += writeSTSC(streamNumber, type);
/*  909 */     size += writeSTSZ(streamNumber, type);
/*  910 */     size += writeSTCO(streamNumber, type);
/*  911 */     return writeSize(offset, size);
/*      */   }
/*      */   
/*      */   private int writeSTSD(int streamNumber, String type) {
/*  915 */     long offset = this.filePointer;
/*  916 */     bufClear();
/*  917 */     bufWriteInt(0);
/*  918 */     bufWriteBytes("stsd");
/*  919 */     int size = 8;
/*  920 */     bufWriteInt(0);
/*  921 */     bufWriteInt(1);
/*  922 */     bufFlush();
/*  923 */     size += 8;
/*  924 */     if (type.equals("vide")) {
/*  925 */       size += writeVideoSampleDescription(streamNumber, type);
/*      */     } else {
/*      */       
/*  928 */       size += writeAudioSampleDescription(streamNumber, type);
/*      */     } 
/*  930 */     return writeSize(offset, size);
/*      */   }
/*      */   
/*      */   private int writeVideoSampleDescription(int streamNumber, String type) {
/*      */     byte b;
/*  935 */     VideoTrakInfo videoTrakInfo = (VideoTrakInfo)this.trakInfoArray[streamNumber];
/*  936 */     int width = (videoTrakInfo.videoFormat.getSize()).width;
/*  937 */     int height = (videoTrakInfo.videoFormat.getSize()).height;
/*      */     
/*  939 */     long offset = this.filePointer;
/*      */     
/*  941 */     bufClear();
/*  942 */     bufWriteInt(0);
/*      */     
/*  944 */     int size = 4;
/*  945 */     String encoding = videoTrakInfo.encoding;
/*  946 */     String fourcc = null;
/*      */     
/*  948 */     if (encoding.equalsIgnoreCase("rgb")) {
/*  949 */       RGBFormat rgbFormat = (RGBFormat)videoTrakInfo.format;
/*  950 */       b = rgbFormat.getBitsPerPixel();
/*  951 */       fourcc = "raw ";
/*      */     } else {
/*  953 */       fourcc = (String)videoFourccMapper.get(encoding.toLowerCase());
/*      */ 
/*      */       
/*  956 */       b = 24;
/*      */     } 
/*  958 */     bufWriteBytes(fourcc);
/*  959 */     size += 4;
/*      */     
/*  961 */     bufWriteInt(0);
/*  962 */     bufWriteShort((short)0);
/*  963 */     size += 6;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  970 */     bufWriteShort((short)1);
/*  971 */     size += 2;
/*      */ 
/*      */     
/*  974 */     bufWriteShort((short)0);
/*  975 */     bufWriteShort((short)0);
/*  976 */     bufWriteBytes("appl");
/*  977 */     bufWriteInt(1023);
/*  978 */     bufWriteInt(1023);
/*  979 */     bufWriteShort((short)width);
/*  980 */     bufWriteShort((short)height);
/*      */     
/*  982 */     bufWriteInt(4718592);
/*      */     
/*  984 */     bufWriteInt(4718592);
/*  985 */     bufWriteInt(0);
/*      */ 
/*      */     
/*  988 */     bufWriteShort((short)1);
/*      */     
/*  990 */     bufWriteBytes(fourcc);
/*  991 */     bufWriteBytes("                            ");
/*  992 */     bufWriteShort((short)b);
/*  993 */     bufWriteShort((short)-1);
/*  994 */     bufFlush();
/*  995 */     size += 70;
/*  996 */     return writeSize(offset, size);
/*      */   }
/*      */   
/*      */   private int writeAudioSampleDescription(int streamNumber, String type) {
/*      */     String str1;
/* 1001 */     AudioTrakInfo audioTrakInfo = (AudioTrakInfo)this.trakInfoArray[streamNumber];
/* 1002 */     AudioFormat audioFormat = audioTrakInfo.audioFormat;
/* 1003 */     int channels = audioFormat.getChannels();
/* 1004 */     int sampleSizeInBits = audioFormat.getSampleSizeInBits();
/* 1005 */     int sampleRate = (int)audioFormat.getSampleRate();
/*      */     
/* 1007 */     long offset = this.filePointer;
/*      */     
/* 1009 */     bufClear();
/* 1010 */     bufWriteInt(0);
/*      */     
/* 1012 */     int size = 4;
/* 1013 */     String encoding = audioTrakInfo.encoding;
/*      */     
/* 1015 */     if (encoding.equalsIgnoreCase("LINEAR")) {
/*      */ 
/*      */ 
/*      */       
/* 1019 */       if (sampleSizeInBits == 8 && audioFormat.getSigned() == 0) {
/*      */         
/* 1021 */         str1 = "raw ";
/*      */       } else {
/* 1023 */         str1 = "twos";
/*      */       } 
/*      */     } else {
/* 1026 */       str1 = (String)audioFourccMapper.get(encoding.toLowerCase());
/*      */     } 
/* 1028 */     bufWriteBytes(str1);
/* 1029 */     size += 4;
/*      */ 
/*      */     
/* 1032 */     bufWriteInt(0);
/* 1033 */     bufWriteShort((short)0);
/* 1034 */     size += 6;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1041 */     bufWriteShort((short)1);
/* 1042 */     size += 2;
/*      */ 
/*      */     
/* 1045 */     bufWriteShort((short)0);
/* 1046 */     bufWriteShort((short)0);
/* 1047 */     bufWriteInt(0);
/* 1048 */     bufWriteShort((short)channels);
/* 1049 */     bufWriteShort((short)sampleSizeInBits);
/* 1050 */     bufWriteShort((short)0);
/* 1051 */     bufWriteShort((short)0);
/* 1052 */     bufWriteInt(sampleRate * 65536);
/* 1053 */     bufFlush();
/* 1054 */     size += 20;
/* 1055 */     return writeSize(offset, size);
/*      */   }
/*      */   
/*      */   private int writeSTTS(int streamNumber, String type) {
/* 1059 */     long offset = this.filePointer;
/* 1060 */     bufClear();
/* 1061 */     bufWriteInt(0);
/* 1062 */     bufWriteBytes("stts");
/* 1063 */     int size = 8;
/* 1064 */     bufWriteInt(0);
/* 1065 */     size += 4;
/* 1066 */     if (type.equals("vide")) {
/* 1067 */       VideoTrakInfo vti = (VideoTrakInfo)this.trakInfoArray[streamNumber];
/*      */       
/* 1069 */       if (vti.minDuration <= -1L || vti.maxDuration - vti.minDuration < 1000000L) {
/*      */ 
/*      */ 
/*      */         
/* 1073 */         bufWriteInt(1);
/* 1074 */         size += 4;
/* 1075 */         bufWriteInt(vti.totalFrames);
/* 1076 */         bufWriteInt(vti.frameDuration);
/* 1077 */         vti.duration = vti.totalFrames * vti.frameDuration;
/* 1078 */         size += 8;
/*      */       } else {
/*      */         int j, k;
/*      */ 
/*      */         
/* 1083 */         bufWriteInt(vti.totalFrames);
/* 1084 */         size += 4;
/*      */         
/* 1086 */         vti.duration = 0;
/*      */         
/* 1088 */         long[][] timeStamps = vti.timeStamps;
/* 1089 */         int indexi = 0;
/* 1090 */         int indexj = 0;
/* 1091 */         long timeStamp = 0L;
/* 1092 */         int numEntries = vti.totalFrames - 1;
/* 1093 */         int bytesPerLoop = 8;
/* 1094 */         int actualBufSize = (this.maxBufSize - 200) / bytesPerLoop * bytesPerLoop;
/* 1095 */         int requiredSize = numEntries * bytesPerLoop;
/*      */ 
/*      */ 
/*      */         
/* 1099 */         if (requiredSize <= actualBufSize) {
/* 1100 */           j = 1;
/* 1101 */           k = numEntries;
/*      */         } else {
/* 1103 */           j = requiredSize / actualBufSize;
/* 1104 */           if (requiredSize / actualBufSize > j)
/* 1105 */             j++; 
/* 1106 */           k = actualBufSize / bytesPerLoop;
/*      */         } 
/* 1108 */         for (int ii = 0; ii < j; ii++) {
/* 1109 */           for (int jj = 0; jj < k; jj++) {
/* 1110 */             bufWriteInt(1);
/* 1111 */             timeStamp = timeStamps[indexi][indexj++];
/*      */             
/* 1113 */             int dur = (int)(0.5D + timeStamp / 1.0E9D * 60000.0D);
/* 1114 */             bufWriteInt(dur);
/* 1115 */             vti.duration += dur;
/* 1116 */             size += 8;
/* 1117 */             if (indexj >= 1000) {
/* 1118 */               indexi++;
/* 1119 */               indexj = 0;
/*      */             } 
/*      */           } 
/* 1122 */           bufFlush();
/* 1123 */           bufClear();
/* 1124 */           if (ii == j - 2) {
/* 1125 */             k = numEntries - (j - 1) * k;
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/* 1130 */         if (vti.totalFrames > 1) {
/* 1131 */           bufWriteInt(1);
/* 1132 */           int dur = (int)(timeStamp / 1.0E9D * 60000.0D);
/* 1133 */           bufWriteInt(dur);
/* 1134 */           size += 8;
/* 1135 */           vti.duration += dur;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1140 */       for (int i = 0; i < vti.numTimeStampArraysUsed; i++) {
/* 1141 */         vti.timeStamps[i] = null;
/*      */       }
/*      */     } else {
/*      */       
/* 1145 */       AudioTrakInfo ati = (AudioTrakInfo)this.trakInfoArray[streamNumber];
/* 1146 */       bufWriteInt(1);
/* 1147 */       size += 4;
/* 1148 */       bufWriteInt(ati.numSamples);
/* 1149 */       bufWriteInt(1);
/* 1150 */       size += 8;
/*      */     } 
/* 1152 */     if (this.bufLength > 0) {
/* 1153 */       bufFlush();
/*      */     }
/* 1155 */     return writeSize(offset, size);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int writeSTSS(int streamNumber, String type) {
/*      */     int i, j;
/* 1162 */     if (!type.equals("vide")) {
/* 1163 */       return 0;
/*      */     }
/* 1165 */     VideoTrakInfo vti = (VideoTrakInfo)this.trakInfoArray[streamNumber];
/* 1166 */     int numKeyFrameArraysUsed = vti.numKeyFrameArraysUsed;
/*      */     
/* 1168 */     int numKeyFrames = (numKeyFrameArraysUsed - 1) * 1000 + vti.keyFrameIndex;
/*      */ 
/*      */     
/* 1171 */     if (numKeyFrames == 0) {
/* 1172 */       Log.warning("Error: There should be atleast 1 keyframe in the track. All frames are now treated as keyframes");
/* 1173 */       return 0;
/*      */     } 
/*      */     
/* 1176 */     if (numKeyFrames == vti.totalFrames) {
/*      */       
/* 1178 */       for (int k = 0; k < numKeyFrameArraysUsed; k++) {
/* 1179 */         vti.keyFrames[k] = null;
/*      */       }
/* 1181 */       return 0;
/*      */     } 
/*      */     
/* 1184 */     long offset = this.filePointer;
/* 1185 */     bufClear();
/* 1186 */     bufWriteInt(0);
/* 1187 */     bufWriteBytes("stss");
/* 1188 */     int size = 8;
/* 1189 */     bufWriteInt(0);
/* 1190 */     size += 4;
/*      */     
/* 1192 */     int[][] keyFrames = vti.keyFrames;
/* 1193 */     bufWriteInt(numKeyFrames);
/* 1194 */     size += 4;
/*      */     
/* 1196 */     int numEntries = numKeyFrames;
/* 1197 */     int bytesPerLoop = 4;
/*      */ 
/*      */ 
/*      */     
/* 1201 */     int actualBufSize = (this.maxBufSize - 200) / bytesPerLoop * bytesPerLoop;
/* 1202 */     int requiredSize = numEntries * bytesPerLoop;
/*      */ 
/*      */ 
/*      */     
/* 1206 */     if (requiredSize <= actualBufSize) {
/* 1207 */       i = 1;
/* 1208 */       j = numEntries;
/*      */     } else {
/* 1210 */       i = requiredSize / actualBufSize;
/* 1211 */       if (requiredSize / actualBufSize > i)
/* 1212 */         i++; 
/* 1213 */       j = actualBufSize / bytesPerLoop;
/*      */     } 
/*      */     
/* 1216 */     int indexi = 0;
/* 1217 */     int indexj = 0;
/* 1218 */     for (int ii = 0; ii < i; ii++) {
/* 1219 */       for (int jj = 0; jj < j; jj++) {
/* 1220 */         bufWriteInt(keyFrames[indexi][indexj++]);
/* 1221 */         if (indexj >= 1000) {
/* 1222 */           indexi++;
/* 1223 */           indexj = 0;
/*      */         } 
/*      */       } 
/* 1226 */       bufFlush();
/* 1227 */       bufClear();
/* 1228 */       if (ii == i - 2) {
/* 1229 */         j = numEntries - (i - 1) * j;
/*      */       }
/*      */     } 
/* 1232 */     size += numKeyFrames * 4;
/*      */     
/* 1234 */     return writeSize(offset, size);
/*      */   }
/*      */   
/*      */   private int writeSTSC(int streamNumber, String type) {
/* 1238 */     long offset = this.filePointer;
/* 1239 */     bufClear();
/* 1240 */     bufWriteInt(0);
/* 1241 */     bufWriteBytes("stsc");
/* 1242 */     int size = 8;
/* 1243 */     bufWriteInt(0);
/* 1244 */     size += 4;
/*      */     
/* 1246 */     if (type.equals("vide")) {
/*      */       
/* 1248 */       VideoTrakInfo vti = (VideoTrakInfo)this.trakInfoArray[streamNumber];
/* 1249 */       bufWriteInt(1);
/* 1250 */       size += 4;
/* 1251 */       bufWriteInt(1);
/* 1252 */       bufWriteInt(1);
/* 1253 */       bufWriteInt(1);
/* 1254 */       size += 12;
/*      */     } else {
/*      */       int i, j;
/* 1257 */       AudioTrakInfo ati = (AudioTrakInfo)this.trakInfoArray[streamNumber];
/* 1258 */       int numberOfEntries = ((ati.numSamplesPerChunkArraysUsed - 1) * 1000 + ati.samplesPerChunkIndex) / 2;
/*      */ 
/*      */       
/* 1261 */       bufWriteInt(numberOfEntries);
/* 1262 */       size += 4;
/*      */       
/* 1264 */       int numEntries = numberOfEntries;
/* 1265 */       int bytesPerLoop = 12;
/* 1266 */       int actualBufSize = (this.maxBufSize - 200) / bytesPerLoop * bytesPerLoop;
/* 1267 */       int requiredSize = numEntries * bytesPerLoop;
/*      */ 
/*      */ 
/*      */       
/* 1271 */       if (requiredSize <= actualBufSize) {
/* 1272 */         i = 1;
/* 1273 */         j = numEntries;
/*      */       } else {
/* 1275 */         i = requiredSize / actualBufSize;
/* 1276 */         if (requiredSize / actualBufSize > i)
/* 1277 */           i++; 
/* 1278 */         j = actualBufSize / bytesPerLoop;
/*      */       } 
/* 1280 */       int indexi = 0;
/* 1281 */       int indexj = 0;
/* 1282 */       int[][] samplesPerChunkArray = ati.samplesPerChunkArray;
/* 1283 */       for (int ii = 0; ii < i; ii++) {
/* 1284 */         for (int jj = 0; jj < j; jj++) {
/* 1285 */           bufWriteInt(samplesPerChunkArray[indexi][indexj++]);
/* 1286 */           bufWriteInt(samplesPerChunkArray[indexi][indexj++]);
/* 1287 */           bufWriteInt(1);
/* 1288 */           if (indexj >= 1000) {
/* 1289 */             indexi++;
/* 1290 */             indexj = 0;
/*      */           } 
/*      */         } 
/* 1293 */         bufFlush();
/* 1294 */         bufClear();
/* 1295 */         if (ii == i - 2) {
/* 1296 */           j = numEntries - (i - 1) * j;
/*      */         }
/*      */       } 
/* 1299 */       size += numberOfEntries * 12;
/*      */     } 
/* 1301 */     if (this.bufLength > 0) {
/* 1302 */       bufFlush();
/*      */     }
/* 1304 */     return writeSize(offset, size);
/*      */   }
/*      */ 
/*      */   
/*      */   private int writeSTSZ(int streamNumber, String type) {
/* 1309 */     long offset = this.filePointer;
/* 1310 */     bufClear();
/* 1311 */     bufWriteInt(0);
/* 1312 */     bufWriteBytes("stsz");
/* 1313 */     int size = 8;
/* 1314 */     bufWriteInt(0);
/* 1315 */     size += 4;
/*      */ 
/*      */     
/* 1318 */     TrakInfo trakInfo = this.trakInfoArray[streamNumber];
/*      */ 
/*      */     
/* 1321 */     if (type.equals("soun")) {
/*      */       
/* 1323 */       bufWriteInt(1);
/* 1324 */       bufWriteInt(((AudioTrakInfo)trakInfo).numSamples);
/* 1325 */       size += 8;
/* 1326 */     } else if (type.equals("vide")) {
/* 1327 */       VideoTrakInfo vti = (VideoTrakInfo)trakInfo;
/* 1328 */       int numSampleSizeArraysUsed = vti.numSampleSizeArraysUsed;
/* 1329 */       int numberOfEntries = trakInfo.totalFrames;
/* 1330 */       if (trakInfo.constantSampleSize) {
/*      */ 
/*      */ 
/*      */         
/* 1334 */         int sampleSize = vti.sampleSize[0][0];
/* 1335 */         bufWriteInt(sampleSize);
/* 1336 */         bufWriteInt(numberOfEntries);
/* 1337 */         size += 8;
/*      */       } else {
/* 1339 */         int j, k, sampleSize[][] = vti.sampleSize;
/* 1340 */         bufWriteInt(0);
/* 1341 */         bufWriteInt(numberOfEntries);
/* 1342 */         size += 8;
/*      */         
/* 1344 */         int numEntries = numberOfEntries;
/* 1345 */         int bytesPerLoop = 4;
/* 1346 */         int actualBufSize = (this.maxBufSize - 200) / bytesPerLoop * bytesPerLoop;
/* 1347 */         int requiredSize = numEntries * bytesPerLoop;
/*      */ 
/*      */ 
/*      */         
/* 1351 */         if (requiredSize <= actualBufSize) {
/* 1352 */           j = 1;
/* 1353 */           k = numEntries;
/*      */         } else {
/* 1355 */           j = requiredSize / actualBufSize;
/* 1356 */           if (requiredSize / actualBufSize > j)
/* 1357 */             j++; 
/* 1358 */           k = actualBufSize / bytesPerLoop;
/*      */         } 
/* 1360 */         int indexi = 0;
/* 1361 */         int indexj = 0;
/*      */         
/* 1363 */         for (int ii = 0; ii < j; ii++) {
/* 1364 */           for (int jj = 0; jj < k; jj++) {
/* 1365 */             bufWriteInt(sampleSize[indexi][indexj++]);
/* 1366 */             if (indexj >= 2000) {
/* 1367 */               indexi++;
/* 1368 */               indexj = 0;
/*      */             } 
/*      */           } 
/* 1371 */           bufFlush();
/* 1372 */           bufClear();
/* 1373 */           if (ii == j - 2) {
/* 1374 */             k = numEntries - (j - 1) * k;
/*      */           }
/*      */         } 
/* 1377 */         size += numberOfEntries * 4;
/*      */       } 
/*      */       
/* 1380 */       for (int i = 0; i < numSampleSizeArraysUsed; i++) {
/* 1381 */         vti.sampleSize[i] = null;
/*      */       }
/*      */     } 
/*      */     
/* 1385 */     if (this.bufLength > 0) {
/* 1386 */       bufFlush();
/*      */     }
/* 1388 */     return writeSize(offset, size);
/*      */   }
/*      */   
/*      */   private int writeSTCO(int streamNumber, String type) {
/*      */     int i, j;
/* 1393 */     long offset = this.filePointer;
/* 1394 */     bufClear();
/* 1395 */     bufWriteInt(0);
/* 1396 */     bufWriteBytes("stco");
/* 1397 */     int size = 8;
/* 1398 */     bufWriteInt(0);
/* 1399 */     size += 4;
/*      */     
/* 1401 */     TrakInfo trakInfo = this.trakInfoArray[streamNumber];
/* 1402 */     int numChunkOffsetsArraysUsed = trakInfo.numChunkOffsetsArraysUsed;
/* 1403 */     int[][] chunkOffsetsArray = trakInfo.chunkOffsetsArray;
/*      */     
/* 1405 */     bufWriteInt(trakInfo.totalFrames);
/* 1406 */     size += 4;
/*      */     
/* 1408 */     int numEntries = trakInfo.totalFrames;
/* 1409 */     int bytesPerLoop = 4;
/* 1410 */     int actualBufSize = (this.maxBufSize - 200) / bytesPerLoop * bytesPerLoop;
/* 1411 */     int requiredSize = numEntries * bytesPerLoop;
/*      */ 
/*      */ 
/*      */     
/* 1415 */     if (requiredSize <= actualBufSize) {
/* 1416 */       i = 1;
/* 1417 */       j = numEntries;
/*      */     } else {
/* 1419 */       i = requiredSize / actualBufSize;
/* 1420 */       if (requiredSize / actualBufSize > i)
/* 1421 */         i++; 
/* 1422 */       j = actualBufSize / bytesPerLoop;
/*      */     } 
/* 1424 */     int indexi = 0;
/* 1425 */     int indexj = 0;
/* 1426 */     trakInfo.chunkOffsetOffset = this.filePointer;
/*      */ 
/*      */ 
/*      */     
/* 1430 */     for (int ii = 0; ii < i; ii++) {
/* 1431 */       for (int jj = 0; jj < j; jj++) {
/* 1432 */         int off = (int)(chunkOffsetsArray[indexi][indexj++] - this.mdatOffset);
/* 1433 */         bufWriteInt(off);
/* 1434 */         if (indexj >= 1000) {
/* 1435 */           indexi++;
/* 1436 */           indexj = 0;
/*      */         } 
/*      */       } 
/* 1439 */       bufFlush();
/* 1440 */       bufClear();
/* 1441 */       if (ii == i - 2) {
/* 1442 */         j = numEntries - (i - 1) * j;
/*      */       }
/*      */     } 
/* 1445 */     size += trakInfo.totalFrames * 4;
/* 1446 */     return writeSize(offset, size);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateSTCO() {
/* 1454 */     for (int streamNumber = 0; streamNumber < this.trakInfoArray.length; streamNumber++) {
/* 1455 */       int i, j; TrakInfo trakInfo = this.trakInfoArray[streamNumber];
/* 1456 */       int numChunkOffsetsArraysUsed = trakInfo.numChunkOffsetsArraysUsed;
/* 1457 */       int[][] chunkOffsetsArray = trakInfo.chunkOffsetsArray;
/*      */       
/* 1459 */       int chunkOffsetOffset = trakInfo.chunkOffsetOffset;
/* 1460 */       seek(chunkOffsetOffset);
/* 1461 */       bufClear();
/*      */       
/* 1463 */       int numEntries = trakInfo.totalFrames;
/* 1464 */       int bytesPerLoop = 4;
/* 1465 */       int actualBufSize = (this.maxBufSize - 200) / bytesPerLoop * bytesPerLoop;
/* 1466 */       int requiredSize = numEntries * bytesPerLoop;
/*      */ 
/*      */ 
/*      */       
/* 1470 */       if (requiredSize <= actualBufSize) {
/* 1471 */         i = 1;
/* 1472 */         j = numEntries;
/*      */       } else {
/* 1474 */         i = requiredSize / actualBufSize;
/* 1475 */         if (requiredSize / actualBufSize > i)
/* 1476 */           i++; 
/* 1477 */         j = actualBufSize / bytesPerLoop;
/*      */       } 
/* 1479 */       int indexi = 0;
/* 1480 */       int indexj = 0;
/*      */ 
/*      */       
/* 1483 */       for (int ii = 0; ii < i; ii++) {
/* 1484 */         for (int jj = 0; jj < j; jj++) {
/* 1485 */           int off = chunkOffsetsArray[indexi][indexj++] + this.moovLength;
/* 1486 */           bufWriteInt(off);
/* 1487 */           if (indexj >= 1000) {
/* 1488 */             indexi++;
/* 1489 */             indexj = 0;
/*      */           } 
/*      */         } 
/* 1492 */         bufFlush();
/* 1493 */         bufClear();
/* 1494 */         if (ii == i - 2) {
/* 1495 */           j = numEntries - (i - 1) * j;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private class TrakInfo
/*      */   {
/*      */     boolean initFormat;
/*      */     
/*      */     boolean supported;
/*      */     
/*      */     String type;
/*      */     
/*      */     String encoding;
/*      */     
/*      */     Format format;
/*      */     
/*      */     long tkhdDurationOffset;
/*      */     
/*      */     long mdhdDurationOffset;
/*      */     int totalFrames;
/*      */     int duration;
/*      */     boolean constantSampleSize;
/*      */     final int MAX_CHUNKOFFSETS_NUMARRAYS = 1000;
/*      */     final int MAX_CHUNKOFFSETS_ARRAYSIZE = 1000;
/*      */     int numChunkOffsetsArraysUsed;
/*      */     int chunkOffsetsIndex;
/*      */     int[][] chunkOffsetsArray;
/*      */     int chunkOffsetOffset;
/*      */     private final QuicktimeMux this$0;
/*      */     
/*      */     public TrakInfo(QuicktimeMux this$0) {
/* 1529 */       this.this$0 = this$0; this.initFormat = false; this.supported = false; this.tkhdDurationOffset = -1L; this.mdhdDurationOffset = -1L; this.totalFrames = 0; this.constantSampleSize = true; this.MAX_CHUNKOFFSETS_NUMARRAYS = 1000; this.MAX_CHUNKOFFSETS_ARRAYSIZE = 1000; this.numChunkOffsetsArraysUsed = 1; this.chunkOffsetsIndex = 0;
/* 1530 */       this.chunkOffsetsArray = new int[1000][];
/* 1531 */       this.chunkOffsetsArray[0] = new int[1000];
/*      */     }
/*      */     
/*      */     public String toString() {
/* 1535 */       if (!this.supported) {
/* 1536 */         System.out.println("No support for format " + this.format);
/*      */       }
/* 1538 */       return this.type + ": " + this.encoding + " : totalFrames " + this.totalFrames;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class VideoTrakInfo
/*      */     extends TrakInfo
/*      */   {
/*      */     VideoFormat videoFormat;
/*      */     
/*      */     float frameRate;
/*      */     
/*      */     int frameDuration;
/*      */     
/*      */     final int MAX_SAMPLE_SIZE_NUMARRAYS = 1000;
/*      */     
/*      */     final int MAX_SAMPLE_SIZE_ARRAYSIZE = 2000;
/*      */     
/*      */     int numSampleSizeArraysUsed;
/*      */     
/*      */     int sampleSizeIndex;
/*      */     
/*      */     int[][] sampleSize;
/*      */     
/*      */     final int MAX_KEYFRAME_NUMARRAYS = 1000;
/*      */     
/*      */     final int MAX_KEYFRAME_ARRAYSIZE = 1000;
/*      */     
/*      */     int numKeyFrameArraysUsed;
/*      */     int keyFrameIndex;
/*      */     int[][] keyFrames;
/*      */     final int MAX_TIMESTAMP_NUMARRAYS = 1000;
/*      */     final int MAX_TIMESTAMP_ARRAYSIZE = 1000;
/*      */     int numTimeStampArraysUsed;
/*      */     int timeStampIndex;
/*      */     long[][] timeStamps;
/*      */     long minDuration;
/*      */     long maxDuration;
/*      */     long previousTimeStamp;
/*      */     private final QuicktimeMux this$0;
/*      */     
/*      */     public VideoTrakInfo(QuicktimeMux this$0) {
/* 1580 */       super(this$0); this.this$0 = this$0; this.MAX_SAMPLE_SIZE_NUMARRAYS = 1000; this.MAX_SAMPLE_SIZE_ARRAYSIZE = 2000; this.numSampleSizeArraysUsed = 1; this.sampleSizeIndex = 0; this.MAX_KEYFRAME_NUMARRAYS = 1000; this.MAX_KEYFRAME_ARRAYSIZE = 1000; this.numKeyFrameArraysUsed = 1; this.keyFrameIndex = 0; this.MAX_TIMESTAMP_NUMARRAYS = 1000; this.MAX_TIMESTAMP_ARRAYSIZE = 1000; this.numTimeStampArraysUsed = 1; this.timeStampIndex = 0; this.minDuration = Long.MAX_VALUE; this.maxDuration = -1L;
/* 1581 */       this.sampleSize = new int[1000][];
/* 1582 */       this.sampleSize[0] = new int[2000];
/*      */       
/* 1584 */       this.keyFrames = new int[1000][];
/* 1585 */       this.keyFrames[0] = new int[1000];
/*      */       
/* 1587 */       this.timeStamps = new long[1000][];
/* 1588 */       this.timeStamps[0] = new long[1000];
/*      */     }
/*      */     
/*      */     public String toString() {
/* 1592 */       return super.toString() + " \n frameRate " + this.frameRate + " : frameDuration " + this.frameDuration;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class AudioTrakInfo
/*      */     extends TrakInfo
/*      */   {
/*      */     AudioFormat audioFormat;
/*      */     
/*      */     final int IMA4_SAMPLES_PER_BLOCK = 64;
/*      */     
/*      */     final int GSM_SAMPLES_PER_BLOCK = 160;
/*      */     
/*      */     final int MAC3_SAMPLES_PER_BLOCK = 6;
/*      */     
/*      */     final int MAC6_SAMPLES_PER_BLOCK = 6;
/*      */     int samplesPerBlock;
/*      */     int numSamples;
/*      */     int frameSizeInBytes;
/*      */     final int MAX_SAMPLESPERCHUNK_NUMARRAYS = 1000;
/*      */     final int MAX_SAMPLESPERCHUNK_ARRAYSIZE = 1000;
/*      */     int numSamplesPerChunkArraysUsed;
/*      */     int samplesPerChunkIndex;
/*      */     int[][] samplesPerChunkArray;
/*      */     int previousSamplesPerChunk;
/*      */     private final QuicktimeMux this$0;
/*      */     
/*      */     public AudioTrakInfo(QuicktimeMux this$0) {
/* 1621 */       super(this$0); this.this$0 = this$0; this.IMA4_SAMPLES_PER_BLOCK = 64; this.GSM_SAMPLES_PER_BLOCK = 160; this.MAC3_SAMPLES_PER_BLOCK = 6; this.MAC6_SAMPLES_PER_BLOCK = 6; this.samplesPerBlock = 1; this.numSamples = 0; this.MAX_SAMPLESPERCHUNK_NUMARRAYS = 1000; this.MAX_SAMPLESPERCHUNK_ARRAYSIZE = 1000; this.numSamplesPerChunkArraysUsed = 1; this.samplesPerChunkIndex = 0; this.previousSamplesPerChunk = -1;
/* 1622 */       this.samplesPerChunkArray = new int[1000][];
/* 1623 */       this.samplesPerChunkArray[0] = new int[1000];
/* 1624 */       this.samplesPerChunkArray[0][0] = 1;
/* 1625 */       this.samplesPerChunkArray[0][1] = -1;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\multiplexer\video\QuicktimeMux.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */