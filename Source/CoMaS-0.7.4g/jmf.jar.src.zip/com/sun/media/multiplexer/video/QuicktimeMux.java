package com.sun.media.multiplexer.video;

import com.sun.media.BasicPlugIn;
import com.sun.media.Log;
import com.sun.media.datasink.RandomAccess;
import com.sun.media.multiplexer.BasicMux;
import java.awt.Dimension;
import java.util.Hashtable;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.format.AudioFormat;
import javax.media.format.RGBFormat;
import javax.media.format.VideoFormat;
import javax.media.format.YUVFormat;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.FileTypeDescriptor;

public class QuicktimeMux extends BasicMux {
  private int removeCount = 0;
  
  private boolean sourceConnected = false;
  
  private boolean sinkConnected = false;
  
  private boolean closed = false;
  
  private boolean opened = false;
  
  private int debugCounter = 0;
  
  private Hashtable streamNumberHash;
  
  private TrakInfo[] trakInfoArray;
  
  private int dataSize = 0;
  
  private Format[] rgbFormats;
  
  private Format[] yuvFormats;
  
  private int[] scaleOffsets;
  
  private boolean[] endOfMediaStatus;
  
  private int numberOfEoms = 0;
  
  private int numberOfTracks = 0;
  
  private int numberOfSupportedTracks = 0;
  
  private static final String VIDEO = "vide";
  
  private static final String AUDIO = "soun";
  
  private long mdatOffset;
  
  private long moovOffset;
  
  private int mdatLength;
  
  private int moovLength;
  
  private long mvhdDurationOffset;
  
  private static Hashtable audioFourccMapper = new Hashtable();
  
  private static Hashtable videoFourccMapper = new Hashtable();
  
  private final int movieTimeScale = 60000;
  
  private final int DEFAULT_FRAME_RATE = 15;
  
  private final int DEFAULT_FRAME_DURATION = 4000;
  
  private final int TRAK_ENABLED = 1;
  
  private final int TRAK_IN_MOVIE = 2;
  
  private static final int DATA_SELF_REFERENCE_FLAG = 1;
  
  private static final boolean ALWAYS_USE_ONE_ENTRY_FOR_STTS = false;
  
  private static final int EPSILON_DURATION = 1000000;
  
  private static final int MVHD_ATOM_SIZE = 100;
  
  private static final int TKHD_ATOM_SIZE = 84;
  
  private static final int MDHD_ATOM_SIZE = 24;
  
  private boolean requireTwoPass = true;
  
  Format bigEndian;
  
  static {
    audioFourccMapper.put("alaw", "alaw");
    audioFourccMapper.put("ulaw", "ulaw");
    audioFourccMapper.put("ima4", "ima4");
    audioFourccMapper.put("gsm", "agsm");
    audioFourccMapper.put("MAC3", "MAC3");
    audioFourccMapper.put("MAC6", "MAC6");
    videoFourccMapper.put("rgb", "rgb");
    videoFourccMapper.put("cvid", "cvid");
    videoFourccMapper.put("jpeg", "jpeg");
    videoFourccMapper.put("h261", "h261");
    videoFourccMapper.put("h263", "h263");
    videoFourccMapper.put("iv32", "iv32");
    videoFourccMapper.put("iv41", "iv41");
    videoFourccMapper.put("iv50", "iv50");
    videoFourccMapper.put("mjpg", "mjpg");
    videoFourccMapper.put("mjpa", "mjpa");
    videoFourccMapper.put("mjpb", "mjpb");
    videoFourccMapper.put("mpeg", "mpeg");
    videoFourccMapper.put("rpza", "rpza");
    videoFourccMapper.put("yuv", "yuv2");
  }
  
  public String getName() {
    return "Quicktime Multiplexer";
  }
  
  public QuicktimeMux() {
    this.bigEndian = (Format)new AudioFormat(null, -1.0D, -1, -1, 1, -1);
    this.supportedInputs = new Format[2];
    this.supportedInputs[0] = (Format)new AudioFormat(null);
    this.supportedInputs[1] = (Format)new VideoFormat(null);
    this.supportedOutputs = new ContentDescriptor[1];
    this.supportedOutputs[0] = (ContentDescriptor)new FileTypeDescriptor("video.quicktime");
    int NS = -1;
    this.rgbFormats = new Format[] { (Format)new RGBFormat(null, NS, Format.byteArray, NS, 16, 31744, 992, 31, 2, NS, 0, 0), (Format)new RGBFormat(null, NS, Format.byteArray, NS, 24, 1, 2, 3, 3, NS, 0, NS), (Format)new RGBFormat(null, NS, Format.byteArray, NS, 32, 2, 3, 4, 4, NS, 0, NS) };
    this.yuvFormats = new Format[] { (Format)new YUVFormat(null, NS, Format.byteArray, NS, 96, NS, NS, 0, 1, 3) };
  }
  
  public Format setInputFormat(Format input, int trackID) {
    if (this.trakInfoArray == null) {
      this.trakInfoArray = new TrakInfo[this.numTracks];
      this.endOfMediaStatus = new boolean[this.numTracks];
    } 
    if (!(input instanceof VideoFormat) && !(input instanceof AudioFormat)) {
      this.trakInfoArray[trackID] = new TrakInfo(this);
      (this.trakInfoArray[trackID]).format = input;
      (this.trakInfoArray[trackID]).supported = false;
      return input;
    } 
    String encoding = input.getEncoding();
    if (input instanceof VideoFormat) {
      if (videoFourccMapper.get(encoding.toLowerCase()) == null)
        return null; 
      if (encoding.equalsIgnoreCase("rgb") && 
        BasicPlugIn.matches(input, this.rgbFormats) == null)
        return null; 
      if (encoding.equalsIgnoreCase("yuv") && 
        BasicPlugIn.matches(input, this.yuvFormats) == null)
        return null; 
      VideoTrakInfo vti = new VideoTrakInfo(this);
      this.trakInfoArray[trackID] = vti;
      vti.supported = true;
      vti.type = "vide";
      vti.encoding = encoding;
      vti.format = input;
      vti.videoFormat = (VideoFormat)null;
    } else if (input instanceof AudioFormat) {
      if (encoding.equalsIgnoreCase("LINEAR")) {
        AudioFormat af = (AudioFormat)input;
        if (af.getSampleSizeInBits() > 8) {
          if (af.getSigned() == 0)
            return null; 
          if (af.getEndian() == 0)
            return null; 
          if (af.getEndian() == -1)
            input = af.intersects(this.bigEndian); 
        } 
      } else if (audioFourccMapper.get(encoding.toLowerCase()) == null) {
        return null;
      } 
      AudioTrakInfo ati = new AudioTrakInfo(this);
      this.trakInfoArray[trackID] = ati;
      ati.supported = true;
      ati.type = "soun";
      ati.encoding = encoding;
      ati.format = input;
      ati.audioFormat = (AudioFormat)input;
      ati.frameSizeInBytes = ati.audioFormat.getFrameSizeInBits() / 8;
      if (ati.frameSizeInBytes <= 0)
        ati.frameSizeInBytes = ati.audioFormat.getSampleSizeInBits() * ati.audioFormat.getChannels() / 8; 
      if (encoding.equalsIgnoreCase("ima4")) {
        ati.samplesPerBlock = 64;
      } else if (encoding.equalsIgnoreCase("gsm")) {
        ati.samplesPerBlock = 160;
      } else if (encoding.equalsIgnoreCase("MAC3")) {
        ati.samplesPerBlock = 6;
      } else if (encoding.equalsIgnoreCase("MAC6")) {
        ati.samplesPerBlock = 6;
      } 
    } 
    if ((this.trakInfoArray[trackID]).supported)
      this.numberOfSupportedTracks++; 
    this.inputs[trackID] = input;
    return input;
  }
  
  public synchronized int doProcess(Buffer buffer, int trackID) {
    if (buffer.isEOM() && 
      !this.endOfMediaStatus[trackID]) {
      this.endOfMediaStatus[trackID] = true;
      this.numberOfEoms++;
      if (this.numberOfEoms == this.numTracks)
        return super.doProcess(buffer, trackID); 
      return 0;
    } 
    if (!(this.trakInfoArray[trackID]).initFormat) {
      if (this.trakInfoArray[trackID] instanceof VideoTrakInfo) {
        VideoTrakInfo videoTrakInfo = (VideoTrakInfo)this.trakInfoArray[trackID];
        videoTrakInfo.videoFormat = (VideoFormat)buffer.getFormat();
        videoTrakInfo.frameRate = videoTrakInfo.videoFormat.getFrameRate();
        if (videoTrakInfo.frameRate > 0.0F) {
          videoTrakInfo.frameDuration = (int)((1.0F / videoTrakInfo.frameRate * 60000.0F) + 0.5D);
        } else {
          videoTrakInfo.frameRate = 15.0F;
          videoTrakInfo.frameDuration = 4000;
        } 
      } 
      (this.trakInfoArray[trackID]).initFormat = true;
    } 
    Object obj = buffer.getData();
    if (obj == null)
      return 1; 
    byte[] data = (byte[])obj;
    if (data == null)
      return 1; 
    int length = buffer.getLength();
    this.dataSize += length;
    TrakInfo trakInfo = this.trakInfoArray[trackID];
    write(data, 0, length);
    int chunkOffset = this.filePointer - length;
    int chunkOffsetsIndex = trakInfo.chunkOffsetsIndex++;
    int numChunkOffsetsArraysUsed = trakInfo.numChunkOffsetsArraysUsed;
    trakInfo.chunkOffsetsArray[numChunkOffsetsArraysUsed - 1][chunkOffsetsIndex] = chunkOffset;
    if (++chunkOffsetsIndex >= 1000) {
      trakInfo.chunkOffsetsIndex = 0;
      trakInfo.chunkOffsetsArray[numChunkOffsetsArraysUsed] = new int[1000];
      trakInfo.numChunkOffsetsArraysUsed++;
      if (++numChunkOffsetsArraysUsed >= 1000) {
        System.err.println("Cannot create quicktime file with more than " + (1000 * 1000) + " chunks ");
        return 1;
      } 
    } 
    String type = trakInfo.type;
    VideoTrakInfo vti = null;
    AudioTrakInfo ati = null;
    if (type.equals("vide")) {
      vti = (VideoTrakInfo)trakInfo;
      int sampleSizeIndex = vti.sampleSizeIndex++;
      int numSampleSizeArraysUsed = vti.numSampleSizeArraysUsed;
      vti.sampleSize[numSampleSizeArraysUsed - 1][sampleSizeIndex] = length;
      if (vti.constantSampleSize && length != vti.sampleSize[0][0])
        vti.constantSampleSize = false; 
      if (vti.minDuration >= 0L) {
        long timeStamp = buffer.getTimeStamp();
        if (timeStamp <= -1L) {
          vti.minDuration = -1L;
        } else if (vti.totalFrames > 0) {
          long durationOfBufferData = timeStamp - vti.previousTimeStamp;
          if (durationOfBufferData < vti.minDuration) {
            vti.minDuration = durationOfBufferData;
          } else if (durationOfBufferData > vti.maxDuration) {
            vti.maxDuration = durationOfBufferData;
          } 
          int timeStampIndex = vti.timeStampIndex++;
          int numTimeStampArraysUsed = vti.numTimeStampArraysUsed;
          vti.timeStamps[numTimeStampArraysUsed - 1][timeStampIndex] = durationOfBufferData;
          if (++timeStampIndex >= 1000) {
            vti.timeStampIndex = 0;
            vti.timeStamps[numTimeStampArraysUsed] = new long[1000];
            vti.numTimeStampArraysUsed++;
            if (++numTimeStampArraysUsed >= 1000) {
              System.err.println("Cannot create quicktime file with more than " + (1000 * 1000) + " frames ");
              return 1;
            } 
          } 
        } 
        vti.previousTimeStamp = timeStamp;
      } 
      if (++sampleSizeIndex >= 2000) {
        vti.sampleSizeIndex = 0;
        vti.sampleSize[numSampleSizeArraysUsed] = new int[2000];
        vti.numSampleSizeArraysUsed++;
        if (++numSampleSizeArraysUsed >= 1000) {
          System.err.println("Cannot create quicktime file with more than " + (1000 * 2000) + " samples ");
          return 1;
        } 
      } 
      boolean keyframe = ((buffer.getFlags() & 0x10) > 0);
      if (keyframe) {
        int keyFrameIndex = vti.keyFrameIndex++;
        int numKeyFrameArraysUsed = vti.numKeyFrameArraysUsed;
        vti.keyFrames[numKeyFrameArraysUsed - 1][keyFrameIndex] = vti.totalFrames + 1;
        if (++keyFrameIndex >= 1000) {
          vti.keyFrameIndex = 0;
          vti.keyFrames[numKeyFrameArraysUsed] = new int[1000];
          vti.numKeyFrameArraysUsed++;
          if (++numKeyFrameArraysUsed >= 1000) {
            System.err.println("Cannot create quicktime file with more than " + (1000 * 1000) + " keyframes ");
            return 1;
          } 
        } 
      } 
    } else {
      ati = (AudioTrakInfo)trakInfo;
      int samplesPerChunk = length / ati.frameSizeInBytes * ati.samplesPerBlock;
      ati.numSamples += samplesPerChunk;
      if (ati.previousSamplesPerChunk != samplesPerChunk) {
        int samplesPerChunkIndex = ati.samplesPerChunkIndex;
        int numSamplesPerChunkArraysUsed = ati.numSamplesPerChunkArraysUsed;
        ati.samplesPerChunkArray[numSamplesPerChunkArraysUsed - 1][samplesPerChunkIndex] = trakInfo.totalFrames + 1;
        samplesPerChunkIndex++;
        ati.samplesPerChunkArray[numSamplesPerChunkArraysUsed - 1][samplesPerChunkIndex] = samplesPerChunk;
        ati.samplesPerChunkIndex = ++samplesPerChunkIndex;
        ati.previousSamplesPerChunk = samplesPerChunk;
        if (++samplesPerChunkIndex >= 1000) {
          ati.samplesPerChunkIndex = 0;
          ati.samplesPerChunkArray[numSamplesPerChunkArraysUsed] = new int[1000];
          ati.numSamplesPerChunkArraysUsed++;
          if (++numSamplesPerChunkArraysUsed >= 1000) {
            System.err.println("Cannot create quicktime file with more than " + (1000 * 1000) + " chunks ");
            return 1;
          } 
        } 
      } 
    } 
    trakInfo.totalFrames++;
    return 0;
  }
  
  protected void writeHeader() {
    this.mdatOffset = this.filePointer;
    bufClear();
    bufWriteInt(0);
    bufWriteBytes("mdat");
    bufFlush();
    this.dataSize = 0;
  }
  
  public boolean requireTwoPass() {
    return this.requireTwoPass;
  }
  
  protected void writeFooter() {
    this.moovOffset = this.filePointer;
    seek((int)this.mdatOffset);
    bufClear();
    this.mdatLength = 8 + this.dataSize;
    bufWriteInt(this.mdatLength);
    bufFlush();
    seek((int)this.moovOffset);
    writeMOOV();
    int maxTrackDuration = -1;
    for (int i = 0; i < this.numTracks; i++) {
      if ((this.trakInfoArray[i]).supported) {
        writeSize((this.trakInfoArray[i]).tkhdDurationOffset, (this.trakInfoArray[i]).duration);
        if ((this.trakInfoArray[i]).type.equals("vide"))
          writeSize((this.trakInfoArray[i]).mdhdDurationOffset, (this.trakInfoArray[i]).duration); 
        if ((this.trakInfoArray[i]).duration > maxTrackDuration)
          maxTrackDuration = (this.trakInfoArray[i]).duration; 
      } 
    } 
    writeSize(this.mvhdDurationOffset, maxTrackDuration);
    if (this.requireTwoPass && this.sth != null && this.sth instanceof RandomAccess) {
      RandomAccess st;
      if ((st = (RandomAccess)this.sth).write(-1L, this.moovLength + this.mdatLength)) {
        updateSTCO();
        write(null, 0, -1);
        st.write(this.moovOffset, this.moovLength);
        st.write(this.mdatOffset, this.mdatLength);
      } else {
        System.err.println("No space to write streamable file");
      } 
      st.write(-1L, -1);
    } 
  }
  
  private int writeMOOV() {
    long offset = this.filePointer;
    bufClear();
    bufWriteInt(0);
    bufWriteBytes("moov");
    bufFlush();
    int size = 8;
    size += writeMVHD();
    for (int i = 0; i < this.numTracks; i++) {
      if ((this.trakInfoArray[i]).supported)
        size += writeTRAK(i, (this.trakInfoArray[i]).type); 
    } 
    this.moovLength = size;
    return writeSize(offset, size);
  }
  
  private int writeMVHD() {
    bufClear();
    bufWriteInt(108);
    bufWriteBytes("mvhd");
    bufWriteInt(0);
    bufWriteInt(0);
    bufWriteInt(0);
    bufWriteInt(60000);
    this.mvhdDurationOffset = this.filePointer;
    bufWriteInt(0);
    bufWriteInt(65536);
    bufWriteShort((short)255);
    bufWriteInt(0);
    bufWriteInt(0);
    bufWriteShort((short)0);
    bufFlush();
    writeMatrix();
    bufClear();
    bufWriteInt(0);
    bufWriteInt(0);
    bufWriteInt(0);
    bufWriteInt(0);
    bufWriteInt(0);
    bufWriteInt(0);
    bufWriteInt(this.numberOfSupportedTracks + 1);
    bufFlush();
    return 108;
  }
  
  private int writeSize(long offset, int size) {
    long currentOffset = this.filePointer;
    seek((int)offset);
    bufClear();
    bufWriteInt(size);
    bufFlush();
    seek((int)currentOffset);
    return size;
  }
  
  private int writeTRAK(int streamNumber, String type) {
    long offset = this.filePointer;
    bufClear();
    bufWriteInt(0);
    bufWriteBytes("trak");
    bufFlush();
    int size = 8;
    size += writeTKHD(streamNumber, type);
    size += writeMDIA(streamNumber, type);
    return writeSize(offset, size);
  }
  
  private int writeTKHD(int streamNumber, String type) {
    int width = 0;
    int height = 0;
    int duration = 0;
    int volume = 0;
    if (type.equals("vide")) {
      VideoTrakInfo videoTrakInfo = (VideoTrakInfo)this.trakInfoArray[streamNumber];
      Dimension size = null;
      VideoFormat vf = videoTrakInfo.videoFormat;
      if (vf != null)
        size = vf.getSize(); 
      if (size != null) {
        width = size.width;
        height = size.height;
      } 
      duration = videoTrakInfo.duration;
    } else {
      AudioTrakInfo audioTrakInfo = (AudioTrakInfo)this.trakInfoArray[streamNumber];
      float sampleRate = (int)audioTrakInfo.audioFormat.getSampleRate();
      float epsilon = 0.01F;
      duration = (int)(audioTrakInfo.numSamples / sampleRate * 60000.0F + epsilon);
      audioTrakInfo.duration = duration;
      volume = 255;
    } 
    bufClear();
    bufWriteInt(92);
    bufWriteBytes("tkhd");
    bufWriteInt(3);
    bufWriteInt(0);
    bufWriteInt(0);
    bufWriteInt(streamNumber + 1);
    bufWriteInt(0);
    (this.trakInfoArray[streamNumber]).tkhdDurationOffset = this.filePointer;
    bufWriteInt(duration);
    bufWriteInt(0);
    bufWriteInt(0);
    bufWriteShort((short)0);
    bufWriteShort((short)0);
    bufWriteShort((short)volume);
    bufWriteShort((short)0);
    bufFlush();
    writeMatrix();
    bufClear();
    bufWriteInt(width * 65536);
    bufWriteInt(height * 65536);
    bufFlush();
    return 92;
  }
  
  private int writeMDIA(int streamNumber, String type) {
    long offset = this.filePointer;
    bufClear();
    bufWriteInt(0);
    bufWriteBytes("mdia");
    bufFlush();
    int size = 8;
    size += writeMDHD(streamNumber, type);
    size += writeMhlrHdlr(streamNumber, type);
    size += writeMINF(streamNumber, type);
    return writeSize(offset, size);
  }
  
  private void writeMatrix() {
    bufClear();
    bufWriteInt(65536);
    bufWriteInt(0);
    bufWriteInt(0);
    bufWriteInt(0);
    bufWriteInt(65536);
    bufWriteInt(0);
    bufWriteInt(0);
    bufWriteInt(0);
    bufWriteInt(1073741824);
    bufFlush();
  }
  
  private int writeMDHD(int streamNumber, String type) {
    int timeScale = 0;
    int duration = 0;
    if (type.equals("vide")) {
      timeScale = 60000;
      VideoTrakInfo videoTrakInfo = (VideoTrakInfo)this.trakInfoArray[streamNumber];
      duration = videoTrakInfo.duration;
    } else {
      AudioTrakInfo audioTrakInfo = (AudioTrakInfo)this.trakInfoArray[streamNumber];
      timeScale = (int)audioTrakInfo.audioFormat.getSampleRate();
      duration = audioTrakInfo.numSamples;
    } 
    bufClear();
    bufWriteInt(32);
    bufWriteBytes("mdhd");
    bufWriteInt(1);
    bufWriteInt(0);
    bufWriteInt(0);
    bufWriteInt(timeScale);
    (this.trakInfoArray[streamNumber]).mdhdDurationOffset = this.filePointer;
    bufWriteInt(duration);
    bufWriteShort((short)0);
    bufWriteShort((short)0);
    bufFlush();
    return 32;
  }
  
  private int writeMINF(int streamNumber, String type) {
    long offset = this.filePointer;
    bufClear();
    bufWriteInt(0);
    bufWriteBytes("minf");
    bufFlush();
    int size = 8;
    if (type.equals("vide")) {
      size += writeVMHD(streamNumber, type);
    } else {
      size += writeSMHD(streamNumber, type);
    } 
    size += writeDHlrHdlr(streamNumber, type);
    size += writeDINF(streamNumber, type);
    size += writeSTBL(streamNumber, type);
    return writeSize(offset, size);
  }
  
  private int writeVMHD(int streamNumber, String type) {
    bufClear();
    bufWriteInt(20);
    bufWriteBytes("vmhd");
    bufWriteInt(1);
    bufWriteShort((short)64);
    bufWriteShort(-32768);
    bufWriteShort(-32768);
    bufWriteShort(-32768);
    bufFlush();
    return 20;
  }
  
  private int writeSMHD(int streamNumber, String type) {
    bufClear();
    bufWriteInt(16);
    bufWriteBytes("smhd");
    bufWriteInt(0);
    bufWriteShort((short)0);
    bufWriteShort((short)0);
    bufFlush();
    return 16;
  }
  
  private int writeMhlrHdlr(int streamNumber, String type) {
    bufClear();
    bufWriteInt(36);
    bufWriteBytes("hdlr");
    bufWriteInt(0);
    bufWriteBytes("mhlr");
    bufWriteBytes(type);
    bufWriteBytes("    ");
    bufWriteInt(0);
    bufWriteInt(0);
    bufWriteBytes("    ");
    bufFlush();
    return 36;
  }
  
  private int writeDHlrHdlr(int streamNumber, String type) {
    bufClear();
    bufWriteInt(36);
    bufWriteBytes("hdlr");
    bufWriteInt(0);
    bufWriteBytes("dhlr");
    bufWriteBytes("alis");
    bufWriteBytes("    ");
    bufWriteInt(0);
    bufWriteInt(0);
    bufWriteBytes("    ");
    bufFlush();
    return 36;
  }
  
  private int writeDINF(int streamNumber, String type) {
    bufClear();
    bufWriteInt(36);
    bufWriteBytes("dinf");
    bufWriteInt(28);
    bufWriteBytes("dref");
    bufWriteInt(0);
    bufWriteInt(1);
    bufWriteInt(12);
    bufWriteBytes("alis");
    bufWriteInt(1);
    bufFlush();
    return 36;
  }
  
  private int writeSTBL(int streamNumber, String type) {
    long offset = this.filePointer;
    bufClear();
    bufWriteInt(0);
    bufWriteBytes("stbl");
    bufFlush();
    int size = 8;
    size += writeSTSD(streamNumber, type);
    size += writeSTTS(streamNumber, type);
    size += writeSTSS(streamNumber, type);
    size += writeSTSC(streamNumber, type);
    size += writeSTSZ(streamNumber, type);
    size += writeSTCO(streamNumber, type);
    return writeSize(offset, size);
  }
  
  private int writeSTSD(int streamNumber, String type) {
    long offset = this.filePointer;
    bufClear();
    bufWriteInt(0);
    bufWriteBytes("stsd");
    int size = 8;
    bufWriteInt(0);
    bufWriteInt(1);
    bufFlush();
    size += 8;
    if (type.equals("vide")) {
      size += writeVideoSampleDescription(streamNumber, type);
    } else {
      size += writeAudioSampleDescription(streamNumber, type);
    } 
    return writeSize(offset, size);
  }
  
  private int writeVideoSampleDescription(int streamNumber, String type) {
    byte b;
    VideoTrakInfo videoTrakInfo = (VideoTrakInfo)this.trakInfoArray[streamNumber];
    int width = (videoTrakInfo.videoFormat.getSize()).width;
    int height = (videoTrakInfo.videoFormat.getSize()).height;
    long offset = this.filePointer;
    bufClear();
    bufWriteInt(0);
    int size = 4;
    String encoding = videoTrakInfo.encoding;
    String fourcc = null;
    if (encoding.equalsIgnoreCase("rgb")) {
      RGBFormat rgbFormat = (RGBFormat)videoTrakInfo.format;
      b = rgbFormat.getBitsPerPixel();
      fourcc = "raw ";
    } else {
      fourcc = (String)videoFourccMapper.get(encoding.toLowerCase());
      b = 24;
    } 
    bufWriteBytes(fourcc);
    size += 4;
    bufWriteInt(0);
    bufWriteShort((short)0);
    size += 6;
    bufWriteShort((short)1);
    size += 2;
    bufWriteShort((short)0);
    bufWriteShort((short)0);
    bufWriteBytes("appl");
    bufWriteInt(1023);
    bufWriteInt(1023);
    bufWriteShort((short)width);
    bufWriteShort((short)height);
    bufWriteInt(4718592);
    bufWriteInt(4718592);
    bufWriteInt(0);
    bufWriteShort((short)1);
    bufWriteBytes(fourcc);
    bufWriteBytes("                            ");
    bufWriteShort((short)b);
    bufWriteShort((short)-1);
    bufFlush();
    size += 70;
    return writeSize(offset, size);
  }
  
  private int writeAudioSampleDescription(int streamNumber, String type) {
    String str1;
    AudioTrakInfo audioTrakInfo = (AudioTrakInfo)this.trakInfoArray[streamNumber];
    AudioFormat audioFormat = audioTrakInfo.audioFormat;
    int channels = audioFormat.getChannels();
    int sampleSizeInBits = audioFormat.getSampleSizeInBits();
    int sampleRate = (int)audioFormat.getSampleRate();
    long offset = this.filePointer;
    bufClear();
    bufWriteInt(0);
    int size = 4;
    String encoding = audioTrakInfo.encoding;
    if (encoding.equalsIgnoreCase("LINEAR")) {
      if (sampleSizeInBits == 8 && audioFormat.getSigned() == 0) {
        str1 = "raw ";
      } else {
        str1 = "twos";
      } 
    } else {
      str1 = (String)audioFourccMapper.get(encoding.toLowerCase());
    } 
    bufWriteBytes(str1);
    size += 4;
    bufWriteInt(0);
    bufWriteShort((short)0);
    size += 6;
    bufWriteShort((short)1);
    size += 2;
    bufWriteShort((short)0);
    bufWriteShort((short)0);
    bufWriteInt(0);
    bufWriteShort((short)channels);
    bufWriteShort((short)sampleSizeInBits);
    bufWriteShort((short)0);
    bufWriteShort((short)0);
    bufWriteInt(sampleRate * 65536);
    bufFlush();
    size += 20;
    return writeSize(offset, size);
  }
  
  private int writeSTTS(int streamNumber, String type) {
    long offset = this.filePointer;
    bufClear();
    bufWriteInt(0);
    bufWriteBytes("stts");
    int size = 8;
    bufWriteInt(0);
    size += 4;
    if (type.equals("vide")) {
      VideoTrakInfo vti = (VideoTrakInfo)this.trakInfoArray[streamNumber];
      if (vti.minDuration <= -1L || vti.maxDuration - vti.minDuration < 1000000L) {
        bufWriteInt(1);
        size += 4;
        bufWriteInt(vti.totalFrames);
        bufWriteInt(vti.frameDuration);
        vti.duration = vti.totalFrames * vti.frameDuration;
        size += 8;
      } else {
        int j, k;
        bufWriteInt(vti.totalFrames);
        size += 4;
        vti.duration = 0;
        long[][] timeStamps = vti.timeStamps;
        int indexi = 0;
        int indexj = 0;
        long timeStamp = 0L;
        int numEntries = vti.totalFrames - 1;
        int bytesPerLoop = 8;
        int actualBufSize = (this.maxBufSize - 200) / bytesPerLoop * bytesPerLoop;
        int requiredSize = numEntries * bytesPerLoop;
        if (requiredSize <= actualBufSize) {
          j = 1;
          k = numEntries;
        } else {
          j = requiredSize / actualBufSize;
          if (requiredSize / actualBufSize > j)
            j++; 
          k = actualBufSize / bytesPerLoop;
        } 
        for (int ii = 0; ii < j; ii++) {
          for (int jj = 0; jj < k; jj++) {
            bufWriteInt(1);
            timeStamp = timeStamps[indexi][indexj++];
            int dur = (int)(0.5D + timeStamp / 1.0E9D * 60000.0D);
            bufWriteInt(dur);
            vti.duration += dur;
            size += 8;
            if (indexj >= 1000) {
              indexi++;
              indexj = 0;
            } 
          } 
          bufFlush();
          bufClear();
          if (ii == j - 2)
            k = numEntries - (j - 1) * k; 
        } 
        if (vti.totalFrames > 1) {
          bufWriteInt(1);
          int dur = (int)(timeStamp / 1.0E9D * 60000.0D);
          bufWriteInt(dur);
          size += 8;
          vti.duration += dur;
        } 
      } 
      for (int i = 0; i < vti.numTimeStampArraysUsed; i++)
        vti.timeStamps[i] = null; 
    } else {
      AudioTrakInfo ati = (AudioTrakInfo)this.trakInfoArray[streamNumber];
      bufWriteInt(1);
      size += 4;
      bufWriteInt(ati.numSamples);
      bufWriteInt(1);
      size += 8;
    } 
    if (this.bufLength > 0)
      bufFlush(); 
    return writeSize(offset, size);
  }
  
  private int writeSTSS(int streamNumber, String type) {
    int i, j;
    if (!type.equals("vide"))
      return 0; 
    VideoTrakInfo vti = (VideoTrakInfo)this.trakInfoArray[streamNumber];
    int numKeyFrameArraysUsed = vti.numKeyFrameArraysUsed;
    int numKeyFrames = (numKeyFrameArraysUsed - 1) * 1000 + vti.keyFrameIndex;
    if (numKeyFrames == 0) {
      Log.warning("Error: There should be atleast 1 keyframe in the track. All frames are now treated as keyframes");
      return 0;
    } 
    if (numKeyFrames == vti.totalFrames) {
      for (int k = 0; k < numKeyFrameArraysUsed; k++)
        vti.keyFrames[k] = null; 
      return 0;
    } 
    long offset = this.filePointer;
    bufClear();
    bufWriteInt(0);
    bufWriteBytes("stss");
    int size = 8;
    bufWriteInt(0);
    size += 4;
    int[][] keyFrames = vti.keyFrames;
    bufWriteInt(numKeyFrames);
    size += 4;
    int numEntries = numKeyFrames;
    int bytesPerLoop = 4;
    int actualBufSize = (this.maxBufSize - 200) / bytesPerLoop * bytesPerLoop;
    int requiredSize = numEntries * bytesPerLoop;
    if (requiredSize <= actualBufSize) {
      i = 1;
      j = numEntries;
    } else {
      i = requiredSize / actualBufSize;
      if (requiredSize / actualBufSize > i)
        i++; 
      j = actualBufSize / bytesPerLoop;
    } 
    int indexi = 0;
    int indexj = 0;
    for (int ii = 0; ii < i; ii++) {
      for (int jj = 0; jj < j; jj++) {
        bufWriteInt(keyFrames[indexi][indexj++]);
        if (indexj >= 1000) {
          indexi++;
          indexj = 0;
        } 
      } 
      bufFlush();
      bufClear();
      if (ii == i - 2)
        j = numEntries - (i - 1) * j; 
    } 
    size += numKeyFrames * 4;
    return writeSize(offset, size);
  }
  
  private int writeSTSC(int streamNumber, String type) {
    long offset = this.filePointer;
    bufClear();
    bufWriteInt(0);
    bufWriteBytes("stsc");
    int size = 8;
    bufWriteInt(0);
    size += 4;
    if (type.equals("vide")) {
      VideoTrakInfo vti = (VideoTrakInfo)this.trakInfoArray[streamNumber];
      bufWriteInt(1);
      size += 4;
      bufWriteInt(1);
      bufWriteInt(1);
      bufWriteInt(1);
      size += 12;
    } else {
      int i, j;
      AudioTrakInfo ati = (AudioTrakInfo)this.trakInfoArray[streamNumber];
      int numberOfEntries = ((ati.numSamplesPerChunkArraysUsed - 1) * 1000 + ati.samplesPerChunkIndex) / 2;
      bufWriteInt(numberOfEntries);
      size += 4;
      int numEntries = numberOfEntries;
      int bytesPerLoop = 12;
      int actualBufSize = (this.maxBufSize - 200) / bytesPerLoop * bytesPerLoop;
      int requiredSize = numEntries * bytesPerLoop;
      if (requiredSize <= actualBufSize) {
        i = 1;
        j = numEntries;
      } else {
        i = requiredSize / actualBufSize;
        if (requiredSize / actualBufSize > i)
          i++; 
        j = actualBufSize / bytesPerLoop;
      } 
      int indexi = 0;
      int indexj = 0;
      int[][] samplesPerChunkArray = ati.samplesPerChunkArray;
      for (int ii = 0; ii < i; ii++) {
        for (int jj = 0; jj < j; jj++) {
          bufWriteInt(samplesPerChunkArray[indexi][indexj++]);
          bufWriteInt(samplesPerChunkArray[indexi][indexj++]);
          bufWriteInt(1);
          if (indexj >= 1000) {
            indexi++;
            indexj = 0;
          } 
        } 
        bufFlush();
        bufClear();
        if (ii == i - 2)
          j = numEntries - (i - 1) * j; 
      } 
      size += numberOfEntries * 12;
    } 
    if (this.bufLength > 0)
      bufFlush(); 
    return writeSize(offset, size);
  }
  
  private int writeSTSZ(int streamNumber, String type) {
    long offset = this.filePointer;
    bufClear();
    bufWriteInt(0);
    bufWriteBytes("stsz");
    int size = 8;
    bufWriteInt(0);
    size += 4;
    TrakInfo trakInfo = this.trakInfoArray[streamNumber];
    if (type.equals("soun")) {
      bufWriteInt(1);
      bufWriteInt(((AudioTrakInfo)trakInfo).numSamples);
      size += 8;
    } else if (type.equals("vide")) {
      VideoTrakInfo vti = (VideoTrakInfo)trakInfo;
      int numSampleSizeArraysUsed = vti.numSampleSizeArraysUsed;
      int numberOfEntries = trakInfo.totalFrames;
      if (trakInfo.constantSampleSize) {
        int sampleSize = vti.sampleSize[0][0];
        bufWriteInt(sampleSize);
        bufWriteInt(numberOfEntries);
        size += 8;
      } else {
        int j, k, sampleSize[][] = vti.sampleSize;
        bufWriteInt(0);
        bufWriteInt(numberOfEntries);
        size += 8;
        int numEntries = numberOfEntries;
        int bytesPerLoop = 4;
        int actualBufSize = (this.maxBufSize - 200) / bytesPerLoop * bytesPerLoop;
        int requiredSize = numEntries * bytesPerLoop;
        if (requiredSize <= actualBufSize) {
          j = 1;
          k = numEntries;
        } else {
          j = requiredSize / actualBufSize;
          if (requiredSize / actualBufSize > j)
            j++; 
          k = actualBufSize / bytesPerLoop;
        } 
        int indexi = 0;
        int indexj = 0;
        for (int ii = 0; ii < j; ii++) {
          for (int jj = 0; jj < k; jj++) {
            bufWriteInt(sampleSize[indexi][indexj++]);
            if (indexj >= 2000) {
              indexi++;
              indexj = 0;
            } 
          } 
          bufFlush();
          bufClear();
          if (ii == j - 2)
            k = numEntries - (j - 1) * k; 
        } 
        size += numberOfEntries * 4;
      } 
      for (int i = 0; i < numSampleSizeArraysUsed; i++)
        vti.sampleSize[i] = null; 
    } 
    if (this.bufLength > 0)
      bufFlush(); 
    return writeSize(offset, size);
  }
  
  private int writeSTCO(int streamNumber, String type) {
    int i, j;
    long offset = this.filePointer;
    bufClear();
    bufWriteInt(0);
    bufWriteBytes("stco");
    int size = 8;
    bufWriteInt(0);
    size += 4;
    TrakInfo trakInfo = this.trakInfoArray[streamNumber];
    int numChunkOffsetsArraysUsed = trakInfo.numChunkOffsetsArraysUsed;
    int[][] chunkOffsetsArray = trakInfo.chunkOffsetsArray;
    bufWriteInt(trakInfo.totalFrames);
    size += 4;
    int numEntries = trakInfo.totalFrames;
    int bytesPerLoop = 4;
    int actualBufSize = (this.maxBufSize - 200) / bytesPerLoop * bytesPerLoop;
    int requiredSize = numEntries * bytesPerLoop;
    if (requiredSize <= actualBufSize) {
      i = 1;
      j = numEntries;
    } else {
      i = requiredSize / actualBufSize;
      if (requiredSize / actualBufSize > i)
        i++; 
      j = actualBufSize / bytesPerLoop;
    } 
    int indexi = 0;
    int indexj = 0;
    trakInfo.chunkOffsetOffset = this.filePointer;
    for (int ii = 0; ii < i; ii++) {
      for (int jj = 0; jj < j; jj++) {
        int off = (int)(chunkOffsetsArray[indexi][indexj++] - this.mdatOffset);
        bufWriteInt(off);
        if (indexj >= 1000) {
          indexi++;
          indexj = 0;
        } 
      } 
      bufFlush();
      bufClear();
      if (ii == i - 2)
        j = numEntries - (i - 1) * j; 
    } 
    size += trakInfo.totalFrames * 4;
    return writeSize(offset, size);
  }
  
  private void updateSTCO() {
    for (int streamNumber = 0; streamNumber < this.trakInfoArray.length; streamNumber++) {
      int i, j;
      TrakInfo trakInfo = this.trakInfoArray[streamNumber];
      int numChunkOffsetsArraysUsed = trakInfo.numChunkOffsetsArraysUsed;
      int[][] chunkOffsetsArray = trakInfo.chunkOffsetsArray;
      int chunkOffsetOffset = trakInfo.chunkOffsetOffset;
      seek(chunkOffsetOffset);
      bufClear();
      int numEntries = trakInfo.totalFrames;
      int bytesPerLoop = 4;
      int actualBufSize = (this.maxBufSize - 200) / bytesPerLoop * bytesPerLoop;
      int requiredSize = numEntries * bytesPerLoop;
      if (requiredSize <= actualBufSize) {
        i = 1;
        j = numEntries;
      } else {
        i = requiredSize / actualBufSize;
        if (requiredSize / actualBufSize > i)
          i++; 
        j = actualBufSize / bytesPerLoop;
      } 
      int indexi = 0;
      int indexj = 0;
      for (int ii = 0; ii < i; ii++) {
        for (int jj = 0; jj < j; jj++) {
          int off = chunkOffsetsArray[indexi][indexj++] + this.moovLength;
          bufWriteInt(off);
          if (indexj >= 1000) {
            indexi++;
            indexj = 0;
          } 
        } 
        bufFlush();
        bufClear();
        if (ii == i - 2)
          j = numEntries - (i - 1) * j; 
      } 
    } 
  }
  
  private class TrakInfo {
    boolean initFormat;
    
    boolean supported;
    
    String type;
    
    String encoding;
    
    Format format;
    
    long tkhdDurationOffset;
    
    long mdhdDurationOffset;
    
    int totalFrames;
    
    int duration;
    
    boolean constantSampleSize;
    
    final int MAX_CHUNKOFFSETS_NUMARRAYS = 1000;
    
    final int MAX_CHUNKOFFSETS_ARRAYSIZE = 1000;
    
    int numChunkOffsetsArraysUsed;
    
    int chunkOffsetsIndex;
    
    int[][] chunkOffsetsArray;
    
    int chunkOffsetOffset;
    
    private final QuicktimeMux this$0;
    
    public TrakInfo(QuicktimeMux this$0) {
      this.this$0 = this$0;
      this.initFormat = false;
      this.supported = false;
      this.tkhdDurationOffset = -1L;
      this.mdhdDurationOffset = -1L;
      this.totalFrames = 0;
      this.constantSampleSize = true;
      this.MAX_CHUNKOFFSETS_NUMARRAYS = 1000;
      this.MAX_CHUNKOFFSETS_ARRAYSIZE = 1000;
      this.numChunkOffsetsArraysUsed = 1;
      this.chunkOffsetsIndex = 0;
      this.chunkOffsetsArray = new int[1000][];
      this.chunkOffsetsArray[0] = new int[1000];
    }
    
    public String toString() {
      if (!this.supported)
        System.out.println("No support for format " + this.format); 
      return this.type + ": " + this.encoding + " : totalFrames " + this.totalFrames;
    }
  }
  
  private class VideoTrakInfo extends TrakInfo {
    VideoFormat videoFormat;
    
    float frameRate;
    
    int frameDuration;
    
    final int MAX_SAMPLE_SIZE_NUMARRAYS = 1000;
    
    final int MAX_SAMPLE_SIZE_ARRAYSIZE = 2000;
    
    int numSampleSizeArraysUsed;
    
    int sampleSizeIndex;
    
    int[][] sampleSize;
    
    final int MAX_KEYFRAME_NUMARRAYS = 1000;
    
    final int MAX_KEYFRAME_ARRAYSIZE = 1000;
    
    int numKeyFrameArraysUsed;
    
    int keyFrameIndex;
    
    int[][] keyFrames;
    
    final int MAX_TIMESTAMP_NUMARRAYS = 1000;
    
    final int MAX_TIMESTAMP_ARRAYSIZE = 1000;
    
    int numTimeStampArraysUsed;
    
    int timeStampIndex;
    
    long[][] timeStamps;
    
    long minDuration;
    
    long maxDuration;
    
    long previousTimeStamp;
    
    private final QuicktimeMux this$0;
    
    public VideoTrakInfo(QuicktimeMux this$0) {
      super(this$0);
      this.this$0 = this$0;
      this.MAX_SAMPLE_SIZE_NUMARRAYS = 1000;
      this.MAX_SAMPLE_SIZE_ARRAYSIZE = 2000;
      this.numSampleSizeArraysUsed = 1;
      this.sampleSizeIndex = 0;
      this.MAX_KEYFRAME_NUMARRAYS = 1000;
      this.MAX_KEYFRAME_ARRAYSIZE = 1000;
      this.numKeyFrameArraysUsed = 1;
      this.keyFrameIndex = 0;
      this.MAX_TIMESTAMP_NUMARRAYS = 1000;
      this.MAX_TIMESTAMP_ARRAYSIZE = 1000;
      this.numTimeStampArraysUsed = 1;
      this.timeStampIndex = 0;
      this.minDuration = Long.MAX_VALUE;
      this.maxDuration = -1L;
      this.sampleSize = new int[1000][];
      this.sampleSize[0] = new int[2000];
      this.keyFrames = new int[1000][];
      this.keyFrames[0] = new int[1000];
      this.timeStamps = new long[1000][];
      this.timeStamps[0] = new long[1000];
    }
    
    public String toString() {
      return super.toString() + " \n frameRate " + this.frameRate + " : frameDuration " + this.frameDuration;
    }
  }
  
  private class AudioTrakInfo extends TrakInfo {
    AudioFormat audioFormat;
    
    final int IMA4_SAMPLES_PER_BLOCK = 64;
    
    final int GSM_SAMPLES_PER_BLOCK = 160;
    
    final int MAC3_SAMPLES_PER_BLOCK = 6;
    
    final int MAC6_SAMPLES_PER_BLOCK = 6;
    
    int samplesPerBlock;
    
    int numSamples;
    
    int frameSizeInBytes;
    
    final int MAX_SAMPLESPERCHUNK_NUMARRAYS = 1000;
    
    final int MAX_SAMPLESPERCHUNK_ARRAYSIZE = 1000;
    
    int numSamplesPerChunkArraysUsed;
    
    int samplesPerChunkIndex;
    
    int[][] samplesPerChunkArray;
    
    int previousSamplesPerChunk;
    
    private final QuicktimeMux this$0;
    
    public AudioTrakInfo(QuicktimeMux this$0) {
      super(this$0);
      this.this$0 = this$0;
      this.IMA4_SAMPLES_PER_BLOCK = 64;
      this.GSM_SAMPLES_PER_BLOCK = 160;
      this.MAC3_SAMPLES_PER_BLOCK = 6;
      this.MAC6_SAMPLES_PER_BLOCK = 6;
      this.samplesPerBlock = 1;
      this.numSamples = 0;
      this.MAX_SAMPLESPERCHUNK_NUMARRAYS = 1000;
      this.MAX_SAMPLESPERCHUNK_ARRAYSIZE = 1000;
      this.numSamplesPerChunkArraysUsed = 1;
      this.samplesPerChunkIndex = 0;
      this.previousSamplesPerChunk = -1;
      this.samplesPerChunkArray = new int[1000][];
      this.samplesPerChunkArray[0] = new int[1000];
      this.samplesPerChunkArray[0][0] = 1;
      this.samplesPerChunkArray[0][1] = -1;
    }
  }
}
