/*     */ package com.sun.media.multiplexer;
/*     */ 
/*     */ import com.sun.media.BasicClock;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.Time;
/*     */ import javax.media.TimeBase;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RawSyncBufferMux
/*     */   extends RawBufferMux
/*     */ {
/*     */   boolean mpegBFrame = false;
/*     */   boolean mpegPFrame = false;
/*     */   protected boolean monoIncrTime = false;
/*  28 */   private long monoStartTime = 0L;
/*  29 */   private long monoTime = 0L;
/*     */   
/*  31 */   private Object waitLock = new Object();
/*     */   
/*     */   private boolean resetted = false;
/*     */   
/*     */   private boolean masterTrackEnded = false;
/*  36 */   static AudioFormat mpegAudio = new AudioFormat("mpegaudio/rtp");
/*  37 */   static VideoFormat mpegVideo = new VideoFormat("mpeg/rtp");
/*     */ 
/*     */ 
/*     */   
/*     */   public RawSyncBufferMux() {
/*  42 */     this.timeBase = new RawBufferMux.RawMuxTimeBase(this);
/*     */     
/*  44 */     this.allowDrop = true;
/*  45 */     this.clock = new BasicClock();
/*     */     try {
/*  47 */       this.clock.setTimeBase((TimeBase)this.timeBase);
/*  48 */     } catch (Exception e) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean initializeTracks(Format[] trackFormats) {
/*  53 */     if (!super.initializeTracks(trackFormats)) {
/*  54 */       return false;
/*     */     }
/*  56 */     this.masterTrackID = 0;
/*  57 */     for (int i = 0; i < trackFormats.length; i++) {
/*  58 */       if (trackFormats[i] instanceof AudioFormat) {
/*  59 */         this.masterTrackID = i;
/*     */       }
/*     */     } 
/*  62 */     return true;
/*     */   }
/*     */   
/*     */   public void reset() {
/*  66 */     super.reset();
/*  67 */     this.mpegBFrame = false;
/*  68 */     this.mpegPFrame = false;
/*  69 */     synchronized (this.waitLock) {
/*  70 */       this.resetted = true;
/*  71 */       this.waitLock.notify();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  80 */     return "Raw Sync Buffer Multiplexer";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int process(Buffer buffer, int trackID) {
/* 101 */     if ((buffer.getFlags() & 0x1000) != 0) {
/* 102 */       buffer.setFlags(buffer.getFlags() & 0xFFFFEFFF | 0x100);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 107 */     if (this.mc[trackID] != null && this.mc[trackID].isEnabled()) {
/* 108 */       this.mc[trackID].process(buffer);
/*     */     }
/* 110 */     if (this.streams == null || buffer == null || trackID >= this.streams.length) {
/* 111 */       return 1;
/*     */     }
/*     */     
/* 114 */     if (buffer.isDiscard()) {
/* 115 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     if ((buffer.getFlags() & 0x40) == 0)
/*     */     {
/* 123 */       if (buffer.getFormat() instanceof AudioFormat) {
/*     */ 
/*     */ 
/*     */         
/* 127 */         if (mpegAudio.matches(buffer.getFormat()))
/* 128 */         { waitForPT(buffer.getTimeStamp(), trackID); }
/*     */         else
/* 130 */         { waitForPT(this.mediaTime[trackID], trackID); } 
/* 131 */       } else if (buffer.getTimeStamp() >= 0L) {
/* 132 */         if (mpegVideo.matches(buffer.getFormat()) && (buffer.getFlags() & 0x800) != 0) {
/*     */           
/* 134 */           byte[] payload = (byte[])buffer.getData();
/* 135 */           int offset = buffer.getOffset();
/* 136 */           int ptype = payload[offset + 2] & 0x7;
/* 137 */           if (ptype > 2) {
/*     */             
/* 139 */             this.mpegBFrame = true;
/* 140 */           } else if (ptype == 2) {
/*     */             
/* 142 */             this.mpegPFrame = true;
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 153 */           if (ptype > 2 || (ptype == 2 && !this.mpegBFrame) || (ptype == 1 && (this.mpegBFrame | this.mpegPFrame) == 0))
/*     */           {
/* 155 */             waitForPT(buffer.getTimeStamp(), trackID);
/*     */           }
/*     */         } else {
/* 158 */           waitForPT(buffer.getTimeStamp(), trackID);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 163 */     updateTime(buffer, trackID);
/*     */ 
/*     */ 
/*     */     
/* 167 */     buffer.setFlags(buffer.getFlags() | 0x60);
/*     */     
/* 169 */     if (!(buffer.getFormat() instanceof AudioFormat) || mpegAudio.matches(buffer.getFormat()))
/*     */     {
/*     */       
/* 172 */       if (this.monoIncrTime) {
/* 173 */         this.monoTime = this.monoStartTime + buffer.getTimeStamp() - this.mediaStartTime * 1000000L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 183 */         buffer.setTimeStamp(this.monoTime);
/*     */       } 
/*     */     }
/*     */     
/* 187 */     if (buffer.isEOM() && trackID == this.masterTrackID) {
/* 188 */       this.masterTrackEnded = true;
/*     */     }
/* 190 */     buffer.setHeader(new Long(System.currentTimeMillis()));
/*     */     
/* 192 */     return this.streams[trackID].process(buffer);
/*     */   }
/*     */   
/*     */   public void syncStart(Time at) {
/* 196 */     this.masterTrackEnded = false;
/* 197 */     super.syncStart(at);
/*     */   }
/*     */   
/*     */   public void setMediaTime(Time now) {
/* 201 */     super.setMediaTime(now);
/* 202 */     this.monoStartTime = this.monoTime + 10L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateTime(Buffer buf, int trackID) {
/* 211 */     if (buf.getFormat() instanceof AudioFormat) {
/*     */       
/* 213 */       if (mpegAudio.matches(buf.getFormat()))
/* 214 */       { if (buf.getTimeStamp() < 0L) {
/* 215 */           if (this.systemStartTime >= 0L) {
/* 216 */             this.mediaTime[trackID] = (this.mediaStartTime + System.currentTimeMillis() - this.systemStartTime) * 1000000L;
/*     */           }
/*     */         } else {
/* 219 */           this.mediaTime[trackID] = buf.getTimeStamp();
/*     */         }  }
/* 221 */       else { long t = ((AudioFormat)buf.getFormat()).computeDuration(buf.getLength());
/*     */         
/* 223 */         if (t >= 0L) {
/* 224 */           this.mediaTime[trackID] = this.mediaTime[trackID] + t;
/*     */         } else {
/* 226 */           this.mediaTime[trackID] = buf.getTimeStamp();
/*     */         }
/*     */          }
/*     */     
/* 230 */     } else if (buf.getTimeStamp() < 0L && this.systemStartTime >= 0L) {
/* 231 */       this.mediaTime[trackID] = (this.mediaStartTime + System.currentTimeMillis() - this.systemStartTime) * 1000000L;
/*     */     } else {
/*     */       
/* 234 */       this.mediaTime[trackID] = buf.getTimeStamp();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 239 */     this.timeBase.update();
/*     */   }
/*     */ 
/*     */   
/* 243 */   static int THRESHOLD = 80;
/* 244 */   static int LEEWAY = 5;
/*     */ 
/*     */   
/*     */   private void waitForPT(long pt, int trackID) {
/*     */     long l;
/* 249 */     pt /= 1000000L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 256 */     if (this.masterTrackID == -1 || trackID == this.masterTrackID) {
/* 257 */       if (this.systemStartTime < 0L) {
/* 258 */         l = 0L;
/*     */       } else {
/* 260 */         l = pt - this.mediaStartTime - System.currentTimeMillis() - this.systemStartTime;
/*     */       } 
/*     */     } else {
/* 263 */       l = pt - this.mediaTime[this.masterTrackID] / 1000000L;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 270 */     if (l > 2000L) {
/*     */       return;
/*     */     }
/* 273 */     while (l > LEEWAY && !this.masterTrackEnded) {
/* 274 */       if (l > THRESHOLD) {
/* 275 */         l = THRESHOLD;
/*     */       }
/* 277 */       synchronized (this.waitLock) {
/*     */         try {
/* 279 */           this.waitLock.wait(l);
/*     */         }
/* 281 */         catch (Exception e) {
/*     */           break;
/* 283 */         }  if (this.resetted) {
/* 284 */           this.resetted = false;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 289 */       if (this.masterTrackID == -1 || trackID == this.masterTrackID) {
/* 290 */         l = pt - this.mediaStartTime - System.currentTimeMillis() - this.systemStartTime;
/*     */         continue;
/*     */       } 
/* 293 */       l = pt - this.mediaTime[this.masterTrackID] / 1000000L;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\multiplexer\RawSyncBufferMux.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */