package com.sun.media.multiplexer;

import com.sun.media.BasicClock;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.Time;
import javax.media.TimeBase;
import javax.media.format.AudioFormat;
import javax.media.format.VideoFormat;

public class RawSyncBufferMux extends RawBufferMux {
  boolean mpegBFrame = false;
  
  boolean mpegPFrame = false;
  
  protected boolean monoIncrTime = false;
  
  private long monoStartTime = 0L;
  
  private long monoTime = 0L;
  
  private Object waitLock = new Object();
  
  private boolean resetted = false;
  
  private boolean masterTrackEnded = false;
  
  static AudioFormat mpegAudio = new AudioFormat("mpegaudio/rtp");
  
  static VideoFormat mpegVideo = new VideoFormat("mpeg/rtp");
  
  public RawSyncBufferMux() {
    this.timeBase = new RawBufferMux.RawMuxTimeBase(this);
    this.allowDrop = true;
    this.clock = new BasicClock();
    try {
      this.clock.setTimeBase((TimeBase)this.timeBase);
    } catch (Exception e) {}
  }
  
  public boolean initializeTracks(Format[] trackFormats) {
    if (!super.initializeTracks(trackFormats))
      return false; 
    this.masterTrackID = 0;
    for (int i = 0; i < trackFormats.length; i++) {
      if (trackFormats[i] instanceof AudioFormat)
        this.masterTrackID = i; 
    } 
    return true;
  }
  
  public void reset() {
    super.reset();
    this.mpegBFrame = false;
    this.mpegPFrame = false;
    synchronized (this.waitLock) {
      this.resetted = true;
      this.waitLock.notify();
    } 
  }
  
  public String getName() {
    return "Raw Sync Buffer Multiplexer";
  }
  
  public int process(Buffer buffer, int trackID) {
    if ((buffer.getFlags() & 0x1000) != 0)
      buffer.setFlags(buffer.getFlags() & 0xFFFFEFFF | 0x100); 
    if (this.mc[trackID] != null && this.mc[trackID].isEnabled())
      this.mc[trackID].process(buffer); 
    if (this.streams == null || buffer == null || trackID >= this.streams.length)
      return 1; 
    if (buffer.isDiscard())
      return 0; 
    if ((buffer.getFlags() & 0x40) == 0)
      if (buffer.getFormat() instanceof AudioFormat) {
        if (mpegAudio.matches(buffer.getFormat())) {
          waitForPT(buffer.getTimeStamp(), trackID);
        } else {
          waitForPT(this.mediaTime[trackID], trackID);
        } 
      } else if (buffer.getTimeStamp() >= 0L) {
        if (mpegVideo.matches(buffer.getFormat()) && (buffer.getFlags() & 0x800) != 0) {
          byte[] payload = (byte[])buffer.getData();
          int offset = buffer.getOffset();
          int ptype = payload[offset + 2] & 0x7;
          if (ptype > 2) {
            this.mpegBFrame = true;
          } else if (ptype == 2) {
            this.mpegPFrame = true;
          } 
          if (ptype > 2 || (ptype == 2 && !this.mpegBFrame) || (ptype == 1 && (this.mpegBFrame | this.mpegPFrame) == 0))
            waitForPT(buffer.getTimeStamp(), trackID); 
        } else {
          waitForPT(buffer.getTimeStamp(), trackID);
        } 
      }  
    updateTime(buffer, trackID);
    buffer.setFlags(buffer.getFlags() | 0x60);
    if (!(buffer.getFormat() instanceof AudioFormat) || mpegAudio.matches(buffer.getFormat()))
      if (this.monoIncrTime) {
        this.monoTime = this.monoStartTime + buffer.getTimeStamp() - this.mediaStartTime * 1000000L;
        buffer.setTimeStamp(this.monoTime);
      }  
    if (buffer.isEOM() && trackID == this.masterTrackID)
      this.masterTrackEnded = true; 
    buffer.setHeader(new Long(System.currentTimeMillis()));
    return this.streams[trackID].process(buffer);
  }
  
  public void syncStart(Time at) {
    this.masterTrackEnded = false;
    super.syncStart(at);
  }
  
  public void setMediaTime(Time now) {
    super.setMediaTime(now);
    this.monoStartTime = this.monoTime + 10L;
  }
  
  protected void updateTime(Buffer buf, int trackID) {
    if (buf.getFormat() instanceof AudioFormat) {
      if (mpegAudio.matches(buf.getFormat())) {
        if (buf.getTimeStamp() < 0L) {
          if (this.systemStartTime >= 0L)
            this.mediaTime[trackID] = (this.mediaStartTime + System.currentTimeMillis() - this.systemStartTime) * 1000000L; 
        } else {
          this.mediaTime[trackID] = buf.getTimeStamp();
        } 
      } else {
        long t = ((AudioFormat)buf.getFormat()).computeDuration(buf.getLength());
        if (t >= 0L) {
          this.mediaTime[trackID] = this.mediaTime[trackID] + t;
        } else {
          this.mediaTime[trackID] = buf.getTimeStamp();
        } 
      } 
    } else if (buf.getTimeStamp() < 0L && this.systemStartTime >= 0L) {
      this.mediaTime[trackID] = (this.mediaStartTime + System.currentTimeMillis() - this.systemStartTime) * 1000000L;
    } else {
      this.mediaTime[trackID] = buf.getTimeStamp();
    } 
    this.timeBase.update();
  }
  
  static int THRESHOLD = 80;
  
  static int LEEWAY = 5;
  
  private void waitForPT(long pt, int trackID) {
    long l;
    pt /= 1000000L;
    if (this.masterTrackID == -1 || trackID == this.masterTrackID) {
      if (this.systemStartTime < 0L) {
        l = 0L;
      } else {
        l = pt - this.mediaStartTime - System.currentTimeMillis() - this.systemStartTime;
      } 
    } else {
      l = pt - this.mediaTime[this.masterTrackID] / 1000000L;
    } 
    if (l > 2000L)
      return; 
    while (l > LEEWAY && !this.masterTrackEnded) {
      if (l > THRESHOLD)
        l = THRESHOLD; 
      synchronized (this.waitLock) {
        try {
          this.waitLock.wait(l);
        } catch (Exception e) {
          break;
        } 
        if (this.resetted) {
          this.resetted = false;
          break;
        } 
      } 
      if (this.masterTrackID == -1 || trackID == this.masterTrackID) {
        l = pt - this.mediaStartTime - System.currentTimeMillis() - this.systemStartTime;
        continue;
      } 
      l = pt - this.mediaTime[this.masterTrackID] / 1000000L;
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\multiplexer\RawSyncBufferMux.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */