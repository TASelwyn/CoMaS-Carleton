package com.sun.media;

import com.sun.media.controls.ProgressControl;
import com.sun.media.controls.StringControl;
import com.sun.media.util.JMFI18N;
import java.awt.Component;
import java.util.Vector;
import javax.media.Codec;
import javax.media.Control;
import javax.media.Format;
import javax.media.NotConfiguredError;
import javax.media.NotRealizedError;
import javax.media.PlugIn;
import javax.media.Renderer;
import javax.media.Track;
import javax.media.UnsupportedPlugInException;
import javax.media.control.FrameRateControl;
import javax.media.control.TrackControl;
import javax.media.format.AudioFormat;
import javax.media.format.VideoFormat;

public class BasicTrackControl implements TrackControl {
  static final String realizeErr = "Cannot get CodecControl before reaching the realized state.";
  
  static final String connectErr = "Cannot set a PlugIn before reaching the configured state.";
  
  PlaybackEngine engine;
  
  Track track;
  
  OutputConnector firstOC;
  
  OutputConnector lastOC;
  
  protected Vector modules = new Vector(7);
  
  protected BasicRendererModule rendererModule;
  
  protected BasicMuxModule muxModule = null;
  
  protected boolean prefetchFailed = false;
  
  protected boolean rendererFailed = false;
  
  float lastFrameRate;
  
  long lastStatsTime;
  
  public Format getOriginalFormat() {
    return this.track.getFormat();
  }
  
  public Format getFormat() {
    return this.track.getFormat();
  }
  
  public Format[] getSupportedFormats() {
    return new Format[] { this.track.getFormat() };
  }
  
  public boolean buildTrack(int trackID, int numTracks) {
    return false;
  }
  
  public Format setFormat(Format format) {
    if (format != null && format.matches(getFormat()))
      return getFormat(); 
    return null;
  }
  
  public void setCodecChain(Codec[] codec) throws NotConfiguredError, UnsupportedPlugInException {
    this;
    if (this.engine.getState() > 180)
      throw new NotConfiguredError("Cannot set a PlugIn before reaching the configured state."); 
    if (codec.length < 1)
      throw new UnsupportedPlugInException("No codec specified in the array."); 
  }
  
  public void setRenderer(Renderer renderer) throws NotConfiguredError {
    this;
    if (this.engine.getState() > 180)
      throw new NotConfiguredError("Cannot set a PlugIn before reaching the configured state."); 
  }
  
  public boolean prefetchTrack() {
    for (int j = 0; j < this.modules.size(); j++) {
      BasicModule bm = this.modules.elementAt(j);
      if (!bm.doPrefetch()) {
        setEnabled(false);
        this.prefetchFailed = true;
        if (bm instanceof BasicRendererModule)
          this.rendererFailed = true; 
        return false;
      } 
    } 
    if (this.prefetchFailed) {
      setEnabled(true);
      this.prefetchFailed = false;
      this.rendererFailed = false;
    } 
    return true;
  }
  
  public void startTrack() {
    for (int j = 0; j < this.modules.size(); j++)
      ((BasicModule)this.modules.elementAt(j)).doStart(); 
  }
  
  public void stopTrack() {
    for (int j = 0; j < this.modules.size(); j++)
      ((BasicModule)this.modules.elementAt(j)).doStop(); 
  }
  
  public boolean isCustomized() {
    return false;
  }
  
  public boolean isTimeBase() {
    return false;
  }
  
  public boolean isEnabled() {
    return this.track.isEnabled();
  }
  
  public void setEnabled(boolean enabled) {
    this.track.setEnabled(enabled);
  }
  
  protected ProgressControl progressControl() {
    return null;
  }
  
  protected FrameRateControl frameRateControl() {
    return null;
  }
  
  public void prError() {
    Log.error("  Unable to handle format: " + getOriginalFormat());
    Log.write("\n");
  }
  
  public Object[] getControls() throws NotRealizedError {
    if (this.engine.getState() < 300)
      throw new NotRealizedError("Cannot get CodecControl before reaching the realized state."); 
    OutputConnector oc = this.firstOC;
    PlugIn p = null;
    Vector cv = new Vector();
    InputConnector ic;
    while (oc != null && (ic = oc.getInputConnector()) != null) {
      Module m = ic.getModule();
      Object[] cs = m.getControls();
      if (cs != null)
        for (int i = 0; i < cs.length; i++)
          cv.addElement(cs[i]);  
      oc = m.getOutputConnector(null);
    } 
    int size = cv.size();
    Control[] controls = new Control[size];
    for (byte b = 0; b < size; b++)
      controls[b] = (Control)cv.elementAt(b); 
    return (Object[])controls;
  }
  
  public Object getControl(String type) {
    Class cls;
    try {
      cls = BasicPlugIn.getClassForName(type);
    } catch (ClassNotFoundException e) {
      return null;
    } 
    Object[] cs = getControls();
    for (int i = 0; i < cs.length; i++) {
      if (cls.isInstance(cs[i]))
        return cs[i]; 
    } 
    return null;
  }
  
  public Component getControlComponent() {
    return null;
  }
  
  public void updateFormat() {
    if (!this.track.isEnabled())
      return; 
    ProgressControl pc;
    if ((pc = progressControl()) == null)
      return; 
    if (this.track.getFormat() instanceof AudioFormat) {
      String channel = "";
      AudioFormat afmt = (AudioFormat)this.track.getFormat();
      StringControl sc = pc.getAudioCodec();
      sc.setValue(afmt.getEncoding());
      sc = pc.getAudioProperties();
      if (afmt.getChannels() == 1) {
        channel = JMFI18N.getResource("mediaengine.mono");
      } else {
        channel = JMFI18N.getResource("mediaengine.stereo");
      } 
      sc.setValue((afmt.getSampleRate() / 1000.0D) + JMFI18N.getResource("mediaengine.khz") + ", " + afmt.getSampleSizeInBits() + JMFI18N.getResource("mediaengine.-bit") + ", " + channel);
    } 
    if (this.track.getFormat() instanceof VideoFormat) {
      VideoFormat vfmt = (VideoFormat)this.track.getFormat();
      StringControl stringControl = pc.getVideoCodec();
      stringControl.setValue(vfmt.getEncoding());
      stringControl = pc.getVideoProperties();
      if (vfmt.getSize() != null)
        stringControl.setValue((vfmt.getSize()).width + " X " + (vfmt.getSize()).height); 
    } 
  }
  
  public BasicTrackControl(PlaybackEngine engine, Track track, OutputConnector oc) {
    this.lastFrameRate = 0.0F;
    this.lastStatsTime = 0L;
    this.engine = engine;
    this.track = track;
    this.firstOC = oc;
    this.lastOC = oc;
    setEnabled(track.isEnabled());
  }
  
  public void updateRates(long now) {
    float f1;
    FrameRateControl prc;
    if ((prc = frameRateControl()) == null)
      return; 
    if (!this.track.isEnabled() || !(this.track.getFormat() instanceof VideoFormat) || (this.rendererModule == null && this.muxModule == null))
      return; 
    if (now == this.lastStatsTime) {
      f1 = this.lastFrameRate;
    } else {
      int i;
      if (this.rendererModule != null) {
        i = this.rendererModule.getFramesPlayed();
      } else {
        i = this.muxModule.getFramesPlayed();
      } 
      f1 = i / (float)(now - this.lastStatsTime) * 1000.0F;
    } 
    float avg = (int)((this.lastFrameRate + f1) / 2.0F * 10.0F) / 10.0F;
    prc.setFrameRate(avg);
    this.lastFrameRate = f1;
    this.lastStatsTime = now;
    if (this.rendererModule != null) {
      this.rendererModule.resetFramesPlayed();
    } else {
      this.muxModule.resetFramesPlayed();
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\BasicTrackControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */