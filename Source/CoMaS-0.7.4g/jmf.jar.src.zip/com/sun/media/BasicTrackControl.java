/*     */ package com.sun.media;
/*     */ 
/*     */ import com.sun.media.controls.ProgressControl;
/*     */ import com.sun.media.controls.StringControl;
/*     */ import com.sun.media.util.JMFI18N;
/*     */ import java.awt.Component;
/*     */ import java.util.Vector;
/*     */ import javax.media.Codec;
/*     */ import javax.media.Control;
/*     */ import javax.media.Format;
/*     */ import javax.media.NotConfiguredError;
/*     */ import javax.media.NotRealizedError;
/*     */ import javax.media.PlugIn;
/*     */ import javax.media.Renderer;
/*     */ import javax.media.Track;
/*     */ import javax.media.UnsupportedPlugInException;
/*     */ import javax.media.control.FrameRateControl;
/*     */ import javax.media.control.TrackControl;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ public class BasicTrackControl
/*     */   implements TrackControl
/*     */ {
/*     */   static final String realizeErr = "Cannot get CodecControl before reaching the realized state.";
/*     */   static final String connectErr = "Cannot set a PlugIn before reaching the configured state.";
/*     */   PlaybackEngine engine;
/*     */   Track track;
/*     */   OutputConnector firstOC;
/*     */   OutputConnector lastOC;
/*  32 */   protected Vector modules = new Vector(7);
/*     */ 
/*     */   
/*     */   protected BasicRendererModule rendererModule;
/*     */   
/*  37 */   protected BasicMuxModule muxModule = null;
/*     */ 
/*     */   
/*     */   protected boolean prefetchFailed = false;
/*     */ 
/*     */   
/*     */   protected boolean rendererFailed = false;
/*     */ 
/*     */   
/*     */   float lastFrameRate;
/*     */ 
/*     */   
/*     */   long lastStatsTime;
/*     */ 
/*     */   
/*     */   public Format getOriginalFormat() {
/*  53 */     return this.track.getFormat();
/*     */   }
/*     */   
/*     */   public Format getFormat() {
/*  57 */     return this.track.getFormat();
/*     */   }
/*     */   
/*     */   public Format[] getSupportedFormats() {
/*  61 */     return new Format[] { this.track.getFormat() };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean buildTrack(int trackID, int numTracks) {
/*  68 */     return false;
/*     */   }
/*     */   
/*     */   public Format setFormat(Format format) {
/*  72 */     if (format != null && format.matches(getFormat()))
/*  73 */       return getFormat(); 
/*  74 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCodecChain(Codec[] codec) throws NotConfiguredError, UnsupportedPlugInException {
/*  79 */     this; if (this.engine.getState() > 180)
/*  80 */       throw new NotConfiguredError("Cannot set a PlugIn before reaching the configured state."); 
/*  81 */     if (codec.length < 1) {
/*  82 */       throw new UnsupportedPlugInException("No codec specified in the array.");
/*     */     }
/*     */   }
/*     */   
/*     */   public void setRenderer(Renderer renderer) throws NotConfiguredError {
/*  87 */     this; if (this.engine.getState() > 180) {
/*  88 */       throw new NotConfiguredError("Cannot set a PlugIn before reaching the configured state.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean prefetchTrack() {
/*  96 */     for (int j = 0; j < this.modules.size(); j++) {
/*  97 */       BasicModule bm = this.modules.elementAt(j);
/*  98 */       if (!bm.doPrefetch()) {
/*  99 */         setEnabled(false);
/* 100 */         this.prefetchFailed = true;
/* 101 */         if (bm instanceof BasicRendererModule)
/* 102 */           this.rendererFailed = true; 
/* 103 */         return false;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 108 */     if (this.prefetchFailed) {
/* 109 */       setEnabled(true);
/* 110 */       this.prefetchFailed = false;
/* 111 */       this.rendererFailed = false;
/*     */     } 
/* 113 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startTrack() {
/* 121 */     for (int j = 0; j < this.modules.size(); j++) {
/* 122 */       ((BasicModule)this.modules.elementAt(j)).doStart();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopTrack() {
/* 131 */     for (int j = 0; j < this.modules.size(); j++) {
/* 132 */       ((BasicModule)this.modules.elementAt(j)).doStop();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCustomized() {
/* 138 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTimeBase() {
/* 146 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/* 151 */     return this.track.isEnabled();
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/* 155 */     this.track.setEnabled(enabled);
/*     */   }
/*     */   
/*     */   protected ProgressControl progressControl() {
/* 159 */     return null;
/*     */   }
/*     */   
/*     */   protected FrameRateControl frameRateControl() {
/* 163 */     return null;
/*     */   }
/*     */   
/*     */   public void prError() {
/* 167 */     Log.error("  Unable to handle format: " + getOriginalFormat());
/* 168 */     Log.write("\n");
/*     */   }
/*     */   
/*     */   public Object[] getControls() throws NotRealizedError {
/* 172 */     if (this.engine.getState() < 300) {
/* 173 */       throw new NotRealizedError("Cannot get CodecControl before reaching the realized state.");
/*     */     }
/*     */     
/* 176 */     OutputConnector oc = this.firstOC;
/*     */     
/* 178 */     PlugIn p = null;
/*     */ 
/*     */     
/* 181 */     Vector cv = new Vector();
/*     */ 
/*     */     
/*     */     InputConnector ic;
/*     */     
/* 186 */     while (oc != null && (ic = oc.getInputConnector()) != null) {
/* 187 */       Module m = ic.getModule();
/* 188 */       Object[] cs = m.getControls();
/* 189 */       if (cs != null) {
/* 190 */         for (int i = 0; i < cs.length; i++) {
/* 191 */           cv.addElement(cs[i]);
/*     */         }
/*     */       }
/* 194 */       oc = m.getOutputConnector(null);
/*     */     } 
/*     */     
/* 197 */     int size = cv.size();
/* 198 */     Control[] controls = new Control[size];
/* 199 */     for (byte b = 0; b < size; b++) {
/* 200 */       controls[b] = (Control)cv.elementAt(b);
/*     */     }
/* 202 */     return (Object[])controls;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getControl(String type) {
/*     */     Class cls;
/*     */     try {
/* 209 */       cls = BasicPlugIn.getClassForName(type);
/*     */     } catch (ClassNotFoundException e) {
/* 211 */       return null;
/*     */     } 
/* 213 */     Object[] cs = getControls();
/* 214 */     for (int i = 0; i < cs.length; i++) {
/* 215 */       if (cls.isInstance(cs[i]))
/* 216 */         return cs[i]; 
/*     */     } 
/* 218 */     return null;
/*     */   }
/*     */   
/*     */   public Component getControlComponent() {
/* 222 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateFormat() {
/* 230 */     if (!this.track.isEnabled()) {
/*     */       return;
/*     */     }
/*     */     
/*     */     ProgressControl pc;
/* 235 */     if ((pc = progressControl()) == null) {
/*     */       return;
/*     */     }
/*     */     
/* 239 */     if (this.track.getFormat() instanceof AudioFormat) {
/* 240 */       String channel = "";
/* 241 */       AudioFormat afmt = (AudioFormat)this.track.getFormat();
/* 242 */       StringControl sc = pc.getAudioCodec();
/* 243 */       sc.setValue(afmt.getEncoding());
/* 244 */       sc = pc.getAudioProperties();
/* 245 */       if (afmt.getChannels() == 1) {
/* 246 */         channel = JMFI18N.getResource("mediaengine.mono");
/*     */       } else {
/* 248 */         channel = JMFI18N.getResource("mediaengine.stereo");
/* 249 */       }  sc.setValue((afmt.getSampleRate() / 1000.0D) + JMFI18N.getResource("mediaengine.khz") + ", " + afmt.getSampleSizeInBits() + JMFI18N.getResource("mediaengine.-bit") + ", " + channel);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 255 */     if (this.track.getFormat() instanceof VideoFormat) {
/* 256 */       VideoFormat vfmt = (VideoFormat)this.track.getFormat();
/* 257 */       StringControl stringControl = pc.getVideoCodec();
/* 258 */       stringControl.setValue(vfmt.getEncoding());
/* 259 */       stringControl = pc.getVideoProperties();
/* 260 */       if (vfmt.getSize() != null)
/* 261 */         stringControl.setValue((vfmt.getSize()).width + " X " + (vfmt.getSize()).height); 
/*     */     } 
/*     */   }
/*     */   
/* 265 */   public BasicTrackControl(PlaybackEngine engine, Track track, OutputConnector oc) { this.lastFrameRate = 0.0F;
/* 266 */     this.lastStatsTime = 0L;
/*     */     this.engine = engine;
/*     */     this.track = track;
/*     */     this.firstOC = oc;
/*     */     this.lastOC = oc;
/*     */     setEnabled(track.isEnabled()); } public void updateRates(long now) {
/*     */     float f1;
/*     */     FrameRateControl prc;
/* 274 */     if ((prc = frameRateControl()) == null) {
/*     */       return;
/*     */     }
/* 277 */     if (!this.track.isEnabled() || !(this.track.getFormat() instanceof VideoFormat) || (this.rendererModule == null && this.muxModule == null)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 284 */     if (now == this.lastStatsTime) {
/* 285 */       f1 = this.lastFrameRate;
/*     */     } else {
/*     */       int i;
/* 288 */       if (this.rendererModule != null) {
/* 289 */         i = this.rendererModule.getFramesPlayed();
/*     */       } else {
/* 291 */         i = this.muxModule.getFramesPlayed();
/* 292 */       }  f1 = i / (float)(now - this.lastStatsTime) * 1000.0F;
/*     */     } 
/*     */     
/* 295 */     float avg = (int)((this.lastFrameRate + f1) / 2.0F * 10.0F) / 10.0F;
/* 296 */     prc.setFrameRate(avg);
/* 297 */     this.lastFrameRate = f1;
/* 298 */     this.lastStatsTime = now;
/* 299 */     if (this.rendererModule != null) {
/* 300 */       this.rendererModule.resetFramesPlayed();
/*     */     } else {
/* 302 */       this.muxModule.resetFramesPlayed();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\sun\media\BasicTrackControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */