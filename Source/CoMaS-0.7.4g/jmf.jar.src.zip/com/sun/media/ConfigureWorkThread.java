package com.sun.media;

class ConfigureWorkThread extends StateTransitionWorkThread {
  public ConfigureWorkThread(BasicController mc) {
    this.controller = mc;
    setName(getName() + ": " + mc);
  }
  
  protected boolean process() {
    return this.controller.doConfigure();
  }
  
  protected void completed() {
    this.controller.completeConfigure();
  }
  
  protected void aborted() {
    this.controller.abortConfigure();
  }
  
  protected void failed() {
    this.controller.doFailedConfigure();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\sun\media\ConfigureWorkThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */