package com.sun.media;

class ConfigureWorkThread extends StateTransitionWorkThread {
  public ConfigureWorkThread(BasicController mc) {
    this.controller = mc;
    setName(getName() + ": " + mc);
  }
  
  protected boolean process() {
    return this.controller.doConfigure();
  }
  
  protected void completed() {
    this.controller.completeConfigure();
  }
  
  protected void aborted() {
    this.controller.abortConfigure();
  }
  
  protected void failed() {
    this.controller.doFailedConfigure();
  }
}
