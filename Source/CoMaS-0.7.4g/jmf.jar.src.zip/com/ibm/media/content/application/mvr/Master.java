package com.ibm.media.content.application.mvr;

import hm20masterorig;
import java.applet.Applet;
import java.net.URL;
import javax.media.Controller;
import javax.media.protocol.PullDataSource;

public class Master extends hm20masterorig {
  public Master$MasterContrAdaptor hmca = new Master$MasterContrAdaptor(this);
  
  public PullDataSource source;
  
  public URL mvrURLFILE;
  
  public String mvrFileForMaster;
  
  public byte[] trackDefs;
  
  public Object argsArray;
  
  public static void b6(Master paramMaster) {
    paramMaster.b9();
  }
  
  public Controller b8() {
    return (Controller)this.hmca;
  }
  
  private void b9() {
    try {
      String str1 = this.source.getLocator().toString();
      String str2;
      if ((str2 = this.mainApplet.getParameter("T1URL")) != null) {
        int i;
        if ((i = str2.lastIndexOf("###")) != -1)
          str2 = str2.substring(0, i); 
        if (str2.lastIndexOf("http://") == -1) {
          String str = new String("http://");
          str2 = str.concat(str2);
        } 
      } 
      String str3 = this.mainApplet.getParameter("T2URL");
      boolean bool = false;
      String str4 = this.mainApplet.getParameter("useDocumentBase");
      if (str4 != null && str4.equalsIgnoreCase("y"))
        bool = true; 
      URL uRL = bool ? this.mainApplet.getDocumentBase() : this.mainApplet.getCodeBase();
      this.mvrURLFILE = (str1 == null) ? uRL : new URL(uRL, str1);
      this.mvrFileForMaster = this.mvrURLFILE.toString();
      if (str3 != null) {
        this.mvrFileForMaster = this.mvrFileForMaster.concat("%%%");
        this.mvrFileForMaster = this.mvrFileForMaster.concat(str3);
      } 
      this.mvrFileForMaster = this.mvrFileForMaster.replace('\\', '/');
    } catch (Exception exception) {
      System.out.println("EX: " + exception);
    } 
  }
  
  public void a8(int paramInt, URL paramURL, String paramString) {
    if (paramInt == 2) {
      if (paramString == null)
        paramString = "_self"; 
      Master$MasterContrAdaptor.b6(this.hmca, paramURL, paramString);
    } else {
      super.a8(paramInt, paramURL, paramString);
    } 
  }
  
  public void setBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ((Handler$AppletAdaptor)this.mainApplet).cb(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void a5(short paramShort1, short paramShort2) {
    this.mainApplet.setSize(paramShort1, paramShort2);
  }
  
  public void ca(byte[] paramArrayOfbyte) {
    this.trackDefs = paramArrayOfbyte;
  }
  
  public Master(PullDataSource paramPullDataSource, Applet paramApplet) {
    this.source = paramPullDataSource;
    this.mainApplet = paramApplet;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\ibm\media\content\application\mvr\Master.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */