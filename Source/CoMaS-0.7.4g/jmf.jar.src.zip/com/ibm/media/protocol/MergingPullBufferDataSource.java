package com.ibm.media.protocol;

import java.io.IOException;
import javax.media.Time;
import javax.media.protocol.DataSource;
import javax.media.protocol.PullBufferDataSource;
import javax.media.protocol.PullBufferStream;

public class MergingPullBufferDataSource extends PullBufferDataSource {
  MergingDataSource superClass;
  
  PullBufferStream[] streams;
  
  public MergingPullBufferDataSource(PullBufferDataSource[] sources) {
    this.superClass = new MergingDataSource((DataSource[])sources);
  }
  
  public PullBufferStream[] getStreams() {
    if (this.streams == null) {
      int totalNoOfStreams = 0;
      for (int i = 0; i < this.superClass.sources.length; i++)
        totalNoOfStreams += (((PullBufferDataSource)this.superClass.sources[i]).getStreams()).length; 
      this.streams = new PullBufferStream[totalNoOfStreams];
      int totalIndex = 0;
      for (int sourceIndex = 0; sourceIndex < this.superClass.sources.length; sourceIndex++) {
        PullBufferStream[] s = ((PullBufferDataSource)this.superClass.sources[sourceIndex]).getStreams();
        for (int streamIndex = 0; streamIndex < s.length; streamIndex++)
          this.streams[totalIndex++] = s[streamIndex]; 
      } 
    } 
    return this.streams;
  }
  
  public String getContentType() {
    return this.superClass.getContentType();
  }
  
  public void connect() throws IOException {
    this.superClass.connect();
  }
  
  public void disconnect() {
    this.superClass.disconnect();
  }
  
  public void start() throws IOException {
    this.superClass.start();
  }
  
  public void stop() throws IOException {
    this.superClass.stop();
  }
  
  public Time getDuration() {
    return this.superClass.getDuration();
  }
  
  public Object[] getControls() {
    return this.superClass.getControls();
  }
  
  public Object getControl(String controlType) {
    return this.superClass.getControl(controlType);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\protocol\MergingPullBufferDataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */