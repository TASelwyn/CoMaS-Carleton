package com.ibm.media.protocol;

import java.io.IOException;
import java.util.Vector;
import javax.media.Time;
import javax.media.protocol.DataSource;
import javax.media.protocol.SourceStream;

class MergingDataSource extends DataSource {
  DataSource[] sources;
  
  SourceStream[] streams = null;
  
  Object[] controls = null;
  
  MergingDataSource(DataSource[] sources) {
    this.sources = sources;
  }
  
  public String getContentType() {
    if (this.sources.length == 1)
      return this.sources[0].getContentType(); 
    boolean isRaw = true;
    for (int index = 0; index < this.sources.length; index++) {
      if (!this.sources[index].getContentType().equals("raw")) {
        isRaw = false;
        break;
      } 
    } 
    if (isRaw)
      return "raw"; 
    if (this.sources.length == 1)
      return this.sources[0].getContentType(); 
    return "application.mixed-data";
  }
  
  public void connect() throws IOException {
    for (int i = 0; i < this.sources.length; i++)
      this.sources[i].connect(); 
  }
  
  public void disconnect() {
    for (int i = 0; i < this.sources.length; i++)
      this.sources[i].disconnect(); 
  }
  
  public void start() throws IOException {
    for (int i = 0; i < this.sources.length; i++)
      this.sources[i].start(); 
  }
  
  public void stop() throws IOException {
    for (int i = 0; i < this.sources.length; i++)
      this.sources[i].stop(); 
  }
  
  public Object[] getControls() {
    if (this.controls == null) {
      Vector vcontrols = new Vector(1);
      for (int i = 0; i < this.sources.length; i++) {
        Object[] cs = this.sources[i].getControls();
        if (cs.length > 0)
          for (int j = 0; j < cs.length; j++)
            vcontrols.addElement(cs[j]);  
      } 
      this.controls = new Object[vcontrols.size()];
      for (int c = 0; c < vcontrols.size(); c++)
        this.controls[c] = vcontrols.elementAt(c); 
    } 
    return this.controls;
  }
  
  public Object getControl(String controlType) {
    try {
      Class cls = Class.forName(controlType);
      Object[] cs = getControls();
      for (int i = 0; i < cs.length; i++) {
        if (cls.isInstance(cs[i]))
          return cs[i]; 
      } 
      return null;
    } catch (Exception e) {
      return null;
    } 
  }
  
  public Time getDuration() {
    Time longest = new Time(0L);
    for (int i = 0; i < this.sources.length; i++) {
      Time sourceDuration = this.sources[i].getDuration();
      if (sourceDuration.getSeconds() > longest.getSeconds())
        longest = sourceDuration; 
    } 
    return longest;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\protocol\MergingDataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */