/*    */ package com.ibm.media.protocol;
/*    */ 
/*    */ import java.util.Vector;
/*    */ import javax.media.CaptureDeviceInfo;
/*    */ import javax.media.control.FormatControl;
/*    */ import javax.media.protocol.CaptureDevice;
/*    */ import javax.media.protocol.PushBufferDataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MergingCDPushBDS
/*    */   extends MergingPushBufferDataSource
/*    */   implements CaptureDevice
/*    */ {
/* 18 */   FormatControl[] fcontrols = null;
/*    */   
/*    */   public MergingCDPushBDS(PushBufferDataSource[] sources) {
/* 21 */     super(sources);
/* 22 */     consolidateFormatControls(sources);
/*    */   }
/*    */   
/*    */   public FormatControl[] getFormatControls() {
/* 26 */     return this.fcontrols;
/*    */   }
/*    */   
/*    */   public CaptureDeviceInfo getCaptureDeviceInfo() {
/* 30 */     return null;
/*    */   }
/*    */   
/*    */   protected void consolidateFormatControls(PushBufferDataSource[] sources) {
/* 34 */     Vector fcs = new Vector(1);
/* 35 */     for (int i = 0; i < sources.length; i++) {
/* 36 */       if (sources[i] instanceof CaptureDevice) {
/* 37 */         CaptureDevice cd = (CaptureDevice)sources[i];
/* 38 */         FormatControl[] cdfcs = cd.getFormatControls();
/* 39 */         for (int j = 0; j < cdfcs.length; j++)
/* 40 */           fcs.addElement(cdfcs[j]); 
/*    */       } 
/*    */     } 
/* 43 */     if (fcs.size() > 0) {
/* 44 */       this.fcontrols = new FormatControl[fcs.size()];
/* 45 */       for (int f = 0; f < fcs.size(); f++)
/* 46 */         this.fcontrols[f] = fcs.elementAt(f); 
/*    */     } else {
/* 48 */       this.fcontrols = new FormatControl[0];
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\ibm\media\protocol\MergingCDPushBDS.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */