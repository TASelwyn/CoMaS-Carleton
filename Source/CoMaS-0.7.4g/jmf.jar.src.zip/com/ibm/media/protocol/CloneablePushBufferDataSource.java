/*     */ package com.ibm.media.protocol;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.media.Time;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PushBufferDataSource;
/*     */ import javax.media.protocol.PushBufferStream;
/*     */ import javax.media.protocol.SourceCloneable;
/*     */ import javax.media.protocol.SourceStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CloneablePushBufferDataSource
/*     */   extends PushBufferDataSource
/*     */   implements SourceCloneable
/*     */ {
/*     */   private SuperCloneableDataSource superClass;
/*     */   
/*     */   public CloneablePushBufferDataSource(PushBufferDataSource source) {
/*  34 */     this.superClass = new SuperCloneableDataSource((DataSource)source);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PushBufferStream[] getStreams() {
/*  48 */     if (this.superClass.streams == null) {
/*  49 */       this.superClass.streams = (SourceStream[])new PushBufferStream[this.superClass.streamsAdapters.length];
/*  50 */       for (int i = 0; i < this.superClass.streamsAdapters.length; i++) {
/*  51 */         this.superClass.streams[i] = this.superClass.streamsAdapters[i].getAdapter();
/*     */       }
/*     */     } 
/*  54 */     return (PushBufferStream[])this.superClass.streams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataSource createClone() {
/*  68 */     return this.superClass.createClone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/*  82 */     return this.superClass.getContentType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect() throws IOException {
/*  97 */     this.superClass.connect();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disconnect() {
/* 112 */     this.superClass.disconnect();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() throws IOException {
/* 125 */     this.superClass.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() throws IOException {
/* 135 */     this.superClass.stop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getControls() {
/* 150 */     return this.superClass.getControls();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getControl(String controlType) {
/* 167 */     return this.superClass.getControl(controlType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Time getDuration() {
/* 182 */     return this.superClass.getDuration();
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\ibm\media\protocol\CloneablePushBufferDataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */