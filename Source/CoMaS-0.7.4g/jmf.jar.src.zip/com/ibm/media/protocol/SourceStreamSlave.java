package com.ibm.media.protocol;

public interface SourceStreamSlave {
  void connect();
  
  void disconnect();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\ibm\media\protocol\SourceStreamSlave.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */