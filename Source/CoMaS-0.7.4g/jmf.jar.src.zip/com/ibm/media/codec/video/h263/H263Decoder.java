package com.ibm.media.codec.video.h263;

import java.awt.Point;

public class H263Decoder extends ReadStream {
  public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997-1999.";
  
  private static final boolean DEBUG = false;
  
  private static final int I_PICTURE = 0;
  
  private static final int P_PICTURE = 1;
  
  private static final int INTRA_STUFFING = -1;
  
  private static final int INTER_STUFFING = -1;
  
  private static final int ESCAPE_CODE = 7167;
  
  private static final int PSC = 32;
  
  private static final int GBSC_1 = 33;
  
  private static final int GBSC_17 = 49;
  
  private static final int GBSC_30 = 62;
  
  private static final int EOS = 63;
  
  private static final int INIT_FORMAT = 9;
  
  private static final int USER_DEFINED_FORMAT = 7;
  
  private static final int SUB_QCIF_FORMAT = 1;
  
  private static final int QCIF_PAL_FORMAT = 2;
  
  private static final int CIF_PAL_FORMAT = 3;
  
  private static final int W0 = 277;
  
  private static final int W1 = 362;
  
  private static final int W2 = 473;
  
  private static final int W3 = 669;
  
  public static final int H263_RC_PICTURE_NOT_DONE = 0;
  
  public static final int H263_RC_PICTURE_DONE = 1;
  
  public static final int H263_RC_PICTURE_FORMAT_NOT_SUPPORTED = 2;
  
  public static final int H263_RC_PICTURE_FORMAT_NOT_INITED = 3;
  
  public int TemporalReference;
  
  public int LastTemporalReference;
  
  private int rtpTemporalReference;
  
  private int HeaderPlus;
  
  private int TypeInformation;
  
  private int CodingType;
  
  private int UnrestrictedMV;
  
  private int DeblockingFilter;
  
  private int SourceFormat;
  
  private int CPM;
  
  private int Quantizer;
  
  private int GroupNumber;
  
  private int GOB_FrameID;
  
  private int[][] BlockData;
  
  private int[][] BlockPtr = new int[6][];
  
  private int[] BlockOffset = new int[6];
  
  private int[] FrameWidthBlock;
  
  private int LastValue;
  
  private int FrameWidth;
  
  private int FrameWidthDiv2;
  
  private int FrameWidthx8;
  
  private int FrameHeight;
  
  private int HorMV;
  
  private int VerMV;
  
  private int Half_HorMV;
  
  private int Half_VerMV;
  
  private int xFrameWidth;
  
  private int xFrameWidthDiv2;
  
  public FrameBuffer CurrentFrame;
  
  protected boolean frameDone;
  
  private boolean foundPSC = false;
  
  private boolean standardH263Only;
  
  private long prevTimeStamp = 0L;
  
  private FrameBuffer PreviousFrame;
  
  private FrameBuffer xPrevFrame;
  
  private int MB_address;
  
  private int FirstMBinGOB;
  
  private int MBperGOB;
  
  private int MBpositionInGOB;
  
  private int GOBperFrame;
  
  private boolean HeaderInGOB;
  
  private int CurrentLumiOffset;
  
  private int CurrentCromOffset;
  
  private int xCurrentLumiOffset;
  
  private int xCurrentCromOffset;
  
  private static final int[] LumiOffset = new int[36];
  
  private static final int[] CromOffset = new int[36];
  
  private static final int[] xLumiOffset = new int[36];
  
  private static final int[] xCromOffset = new int[36];
  
  private static final int[] CodedMap = new int[2048];
  
  private int[] MBtypeCurrGOB;
  
  private int[] MBtypePrevGOB;
  
  private Point[] MotVectCurrGOB;
  
  private Point[] MotVectPrevGOB;
  
  private int prevCBP;
  
  private static final int[] dQuant = new int[] { 1, 0, 3, 4 };
  
  private static final int[][] recLevel_tab = new int[32][128];
  
  private static final int[] clipQ_tab = new int[36];
  
  private static final int[] pre8x8_tab = new int[] { 
      512, 710, 669, 602, 512, 402, 277, 141, 710, 985, 
      928, 835, 710, 558, 384, 196, 669, 928, 874, 787, 
      669, 526, 362, 185, 602, 835, 787, 708, 602, 473, 
      326, 166, 512, 710, 669, 602, 512, 402, 277, 141, 
      402, 558, 526, 473, 402, 316, 218, 111, 277, 384, 
      362, 326, 277, 218, 150, 76, 141, 196, 185, 166, 
      141, 111, 76, 39 };
  
  private static final int[] STRENGTH = new int[31];
  
  private static final int[] zigzag_tab = new int[64];
  
  private static final int[] IntraMCBPC_VLC_tab0 = new int[64];
  
  private static final int[] IntraMCBPC_VLC_tab1 = new int[64];
  
  private static final int[] InterMCBPC_VLC_tab0 = new int[512];
  
  private static final int[] InterMCBPC_VLC_tab1 = new int[512];
  
  private static final int[] CBPY_VLC_tab0 = new int[64];
  
  private static final int[] CBPY_VLC_tab1 = new int[64];
  
  private static final int[] MVD1_VLC_tab0 = new int[256];
  
  private static final int[] MVD1_VLC_tab1 = new int[256];
  
  private static final int[] MVD2_VLC_tab0 = new int[256];
  
  private static final int[] MVD2_VLC_tab1 = new int[256];
  
  private static final int[] TCOEFF1_tab0 = new int[112];
  
  private static final int[] TCOEFF1_tab1 = new int[112];
  
  private static final int[] TCOEFF2_tab0 = new int[96];
  
  private static final int[] TCOEFF2_tab1 = new int[96];
  
  private static final int[] TCOEFF3_tab0 = new int[120];
  
  private static final int[] TCOEFF3_tab1 = new int[120];
  
  private static final int[] clipTable = new int[1024];
  
  private static final int[] DfiltClip = new int[512];
  
  final void init() {
    this.SourceFormat = 9;
  }
  
  public H263Decoder(boolean standardOnly) {
    this.standardH263Only = standardOnly;
    this.SourceFormat = 9;
    this.foundPSC = false;
    this.TemporalReference = 0;
    this.LastTemporalReference = 0;
    this.BlockData = new int[6][64];
    this.FrameWidthBlock = new int[6];
    this.MotVectCurrGOB = new Point[88];
    this.MotVectPrevGOB = new Point[88];
    for (int i = 0; i < 88; i++) {
      this.MotVectCurrGOB[i] = new Point(0, 0);
      this.MotVectPrevGOB[i] = new Point(0, 0);
    } 
    this.MBtypeCurrGOB = new int[22];
    this.MBtypePrevGOB = new int[22];
  }
  
  static {
    int row = 0, col = 0;
    int direction = 1;
    for (int i = 0; i < 32; i++) {
      int temp = row * 8 + col;
      zigzag_tab[i] = temp;
      zigzag_tab[63 - i] = 63 - temp;
      row -= direction;
      col += direction;
      if (col < 0) {
        direction = 1;
        col = 0;
      } 
      if (row < 0) {
        direction = -1;
        row = 0;
      } 
    } 
    for (int j = 0; j < 1024; j++)
      clipTable[j] = (j < 256) ? j : ((j < 512) ? 255 : 0); 
    for (int k = 0; k < recLevel_tab.length; k++) {
      for (int i10 = 0; i10 < (recLevel_tab[k]).length; i10++) {
        if (i10 == 0) {
          recLevel_tab[k][i10] = 0;
        } else {
          int temp = k * (2 * i10 + 1);
          recLevel_tab[k][i10] = (temp < -2048) ? -2048 : ((temp > 2047) ? 2047 : temp);
        } 
      } 
    } 
    for (int m = 0; m < clipQ_tab.length; m++) {
      int temp = m - 2;
      clipQ_tab[m] = (temp < 1) ? 1 : ((temp > 31) ? 31 : temp);
    } 
    for (int n = 1; n < IntraMCBPC_VLC_tab0.length; n++) {
      IntraMCBPC_VLC_tab0[n] = (n <= 3) ? (64 + n) : ((n <= 7) ? 64 : ((n <= 31) ? (n / 8 + 48) : 48));
      IntraMCBPC_VLC_tab1[n] = (n <= 3) ? 6 : ((n <= 7) ? 4 : ((n <= 31) ? 3 : 1));
    } 
    for (int i1 = 1; i1 < InterMCBPC_VLC_tab0.length; i1++) {
      InterMCBPC_VLC_tab0[i1] = (i1 <= 1) ? -1 : ((i1 <= 4) ? (69 - i1) : ((i1 <= 5) ? 19 : ((i1 <= 9) ? (53 - i1 / 2) : ((i1 <= 11) ? 35 : ((i1 <= 15) ? 51 : ((i1 <= 19) ? 34 : ((i1 <= 23) ? 33 : ((i1 <= 27) ? 18 : ((i1 <= 31) ? 17 : ((i1 <= 39) ? 64 : ((i1 <= 47) ? 3 : ((i1 <= 63) ? 48 : ((i1 <= 95) ? 2 : ((i1 <= 127) ? 1 : ((i1 <= 191) ? 32 : ((i1 < 256) ? 16 : 0))))))))))))))));
      InterMCBPC_VLC_tab1[i1] = (i1 <= 5) ? 9 : ((i1 <= 11) ? 8 : ((i1 <= 31) ? 7 : ((i1 <= 47) ? 6 : ((i1 <= 63) ? 5 : ((i1 <= 127) ? 4 : ((i1 <= 255) ? 3 : 1))))));
    } 
    for (int i2 = 2; i2 < CBPY_VLC_tab0.length; i2++) {
      CBPY_VLC_tab0[i2] = (i2 <= 2) ? 105 : ((i2 <= 3) ? 150 : ((i2 <= 5) ? 135 : ((i2 <= 7) ? 75 : ((i2 <= 9) ? 45 : ((i2 <= 11) ? 30 : ((i2 <= 15) ? 15 : ((i2 <= 19) ? 195 : ((i2 <= 23) ? 165 : ((i2 <= 27) ? 225 : ((i2 <= 31) ? 90 : ((i2 <= 35) ? 210 : ((i2 <= 39) ? 60 : ((i2 <= 43) ? 180 : ((i2 <= 47) ? 120 : 240))))))))))))));
      CBPY_VLC_tab1[i2] = (i2 <= 3) ? 6 : ((i2 <= 11) ? 5 : ((i2 <= 47) ? 4 : 2));
    } 
    for (int i3 = 6; i3 < MVD1_VLC_tab0.length; i3++) {
      MVD1_VLC_tab0[i3] = (i3 <= 11) ? ((10 - i3 / 2) * (1 - (i3 & 0x1) * 2)) : ((i3 <= 15) ? (4 * (1 - (i3 & 0x2))) : ((i3 <= 31) ? (3 * (1 - (0x1 & i3 >> 3) * 2)) : ((i3 <= 63) ? (2 * (1 - (0x1 & i3 >> 4) * 2)) : ((i3 < 128) ? (1 - (0x1 & i3 >> 5) * 2) : 0))));
      MVD1_VLC_tab1[i3] = (i3 <= 11) ? 8 : ((i3 <= 15) ? 7 : ((i3 <= 31) ? 5 : ((i3 <= 63) ? 4 : ((i3 <= 127) ? 3 : 1))));
    } 
    for (int i4 = 0; i4 < MVD2_VLC_tab0.length; i4++) {
      MVD2_VLC_tab0[i4] = (i4 < 5) ? 0 : ((i4 == 5) ? -32 : ((i4 <= 7) ? (31 * (1 - (i4 & 0x1) * 2)) : ((i4 <= 31) ? ((32 - (i4 >> 2)) * (1 - (0x1 & i4 >> 1) * 2)) : ((i4 <= 143) ? ((28 - (i4 >> 3)) * (1 - (0x1 & i4 >> 2) * 2)) : ((19 - (i4 >> 4)) * (1 - (0x1 & i4 >> 3) * 2))))));
      MVD2_VLC_tab1[i4] = (i4 <= 4) ? 5 : ((i4 <= 7) ? 13 : ((i4 <= 31) ? 12 : ((i4 <= 143) ? 11 : ((i4 <= 191) ? 10 : 5))));
    } 
    for (int i5 = 0; i5 < TCOEFF1_tab0.length; i5++) {
      TCOEFF1_tab0[i5] = (i5 <= 3) ? (4225 - i5 * 16) : ((i5 <= 6) ? (257 - i5 * 16) : ((i5 <= 7) ? 4 : ((i5 <= 15) ? (4225 - i5 / 2 * 16) : ((i5 <= 23) ? (273 - i5 / 2 * 16) : ((i5 <= 25) ? 18 : ((i5 <= 27) ? 3 : ((i5 <= 39) ? (193 - i5 / 4 * 16) : ((i5 <= 47) ? 4097 : ((i5 <= 79) ? 1 : ((i5 <= 95) ? 17 : ((i5 <= 103) ? 33 : 2)))))))))));
      TCOEFF1_tab1[i5] = (i5 <= 7) ? 7 : ((i5 <= 27) ? 6 : ((i5 <= 39) ? 5 : ((i5 <= 47) ? 4 : ((i5 <= 79) ? 2 : ((i5 <= 95) ? 3 : 4)))));
    } 
    for (int i6 = 0; i6 < TCOEFF2_tab0.length; i6++) {
      TCOEFF2_tab0[i6] = (i6 <= 1) ? (9 - i6) : ((i6 <= 17) ? (4497 - i6 / 2 * 16) : ((i6 <= 19) ? 4098 : ((i6 <= 35) ? (513 - i6 / 2 * 16) : ((i6 <= 39) ? (354 - i6 / 2 * 16) : ((i6 <= 43) ? (27 - i6 / 2) : ((i6 <= 75) ? (4529 - i6 / 4 * 16) : ((i6 <= 83) ? (529 - i6 / 4 * 16) : ((i6 <= 91) ? (349 - i6 / 4 * 15) : 5))))))));
      TCOEFF2_tab1[i6] = (i6 <= 1) ? 10 : ((i6 <= 43) ? 9 : 8);
    } 
    for (int i7 = 0; i7 < TCOEFF3_tab0.length; i7++) {
      TCOEFF3_tab0[i7] = (i7 <= 3) ? (4114 - i7 / 2 * 15) : ((i7 <= 7) ? (13 - i7 / 2) : ((i7 <= 23) ? (4577 - i7 / 4 * 16) : ((i7 <= 43) ? (242 - i7 / 4 * 16) : ((i7 <= 51) ? (227 - i7 / 4 * 16) : ((i7 <= 55) ? 20 : ((i7 <= 59) ? (i7 / 2 * 9 - 240) : ((i7 <= 63) ? (i7 / 2 * 16 - 111) : ((i7 <= 71) ? (i7 / 2 * 16 + 4049) : ((i7 <= 72) ? 22 : ((i7 <= 73) ? 36 : ((i7 <= 74) ? 67 : ((i7 <= 75) ? 83 : ((i7 <= 76) ? 99 : ((i7 <= 77) ? 162 : ((i7 <= 78) ? 401 : ((i7 <= 79) ? 417 : ((i7 <= 87) ? (i7 * 16 + 3345) : 7167)))))))))))))))));
      TCOEFF3_tab1[i7] = (i7 <= 7) ? 11 : ((i7 <= 55) ? 10 : ((i7 <= 71) ? 11 : ((i7 <= 87) ? 12 : 6)));
    } 
    for (int i8 = 0; i8 < 31; i8++)
      STRENGTH[i8] = (i8 < 6) ? ((i8 >> 1) + 1) : ((i8 < 9) ? 4 : ((i8 < 13) ? (i8 + 1 >> 1) : ((i8 + 2) / 3 + 2))); 
    for (int i9 = 0; i9 < 512; i9++)
      DfiltClip[i9] = (i9 < 128) ? 0 : ((i9 < 384) ? (i9 - 128) : 255); 
  }
  
  private final int ChangeFormat(int NewFormat, int UnrestrictedMV) {
    switch (NewFormat) {
      case 1:
        this.FrameWidth = 128;
        this.FrameHeight = 96;
        break;
      case 2:
        this.FrameWidth = 176;
        this.FrameHeight = 144;
        break;
      case 3:
        this.FrameWidth = 352;
        this.FrameHeight = 288;
        break;
      case 7:
        break;
      default:
        return 2;
    } 
    this.GOBperFrame = this.FrameHeight >> 4;
    this.MBperGOB = this.FrameWidth >> 4;
    for (int i = 0; i < this.GOBperFrame; i++) {
      LumiOffset[i] = (this.FrameWidth << 4) * i;
      CromOffset[i] = (this.FrameWidth << 2) * i;
      xLumiOffset[i] = 16 + (32 + this.FrameWidth << 4) * (i + 1);
      xCromOffset[i] = 8 + (16 + (this.FrameWidth >> 1) << 3) * (i + 1);
    } 
    this.FrameWidthDiv2 = this.FrameWidth >> 1;
    this.FrameWidthx8 = this.FrameWidth << 3;
    this.CurrentFrame = new FrameBuffer(this.FrameWidth, this.FrameHeight);
    this.PreviousFrame = new FrameBuffer(this.FrameWidth, this.FrameHeight);
    this.FrameWidthBlock[0] = this.FrameWidth;
    this.FrameWidthBlock[1] = this.FrameWidth;
    this.FrameWidthBlock[2] = this.FrameWidth;
    this.FrameWidthBlock[3] = this.FrameWidth;
    this.FrameWidthBlock[4] = this.FrameWidthDiv2;
    this.FrameWidthBlock[5] = this.FrameWidthDiv2;
    if (UnrestrictedMV == 1) {
      this.xFrameWidth = this.FrameWidth + 32;
      this.xFrameWidthDiv2 = this.xFrameWidth >> 1;
      this.xPrevFrame = new FrameBuffer(this.FrameWidth + 32, this.FrameHeight + 32);
    } else {
      this.xFrameWidth = this.FrameWidth;
      this.xFrameWidthDiv2 = this.xFrameWidth >> 1;
      this.xPrevFrame = null;
    } 
    this.SourceFormat = NewFormat;
    return 0;
  }
  
  public final int DecodeRtpPacket(byte[] inputBuffer, int inputOffset, int inputLength, byte[] packetHeader, int packetOffset, long timeStamp) {
    int mode = H263RtpPayloadParser.getMode(packetHeader, packetOffset);
    int startBit = H263RtpPayloadParser.getStartBit(packetHeader, packetOffset);
    int endBit = H263RtpPayloadParser.getEndBit(packetHeader, packetOffset);
    int src = H263RtpPayloadParser.getSRC(packetHeader, packetOffset);
    int rc = 0;
    this.rdptr = inputOffset;
    if (mode == 0) {
      boolean prevdone = false;
      if (false == this.frameDone && this.foundPSC && timeStamp != this.prevTimeStamp && timeStamp != 0L) {
        this.rtpTemporalReference = H263RtpPayloadParser.getTemporalReference(packetHeader, packetOffset);
        if (this.rtpTemporalReference != 0)
          this.TemporalReference = this.rtpTemporalReference; 
        this.frameDone = true;
        this.foundPSC = false;
        prevdone = true;
      } 
      this.prevTimeStamp = timeStamp;
      while (this.rdptr < inputLength + inputOffset) {
        try {
          rc = DecodeGobs(inputBuffer, this.rdptr);
        } catch (Exception e) {
          e.printStackTrace();
          System.out.println("[H263Decodeer::decodeRtpPacket] returning H263_RC_PICTURE_FORMAT_NOT_SUPPORTED");
          return 2;
        } 
      } 
      if (prevdone == true) {
        prevdone = false;
        return 1;
      } 
      return rc;
    } 
    if (mode == 1)
      return 2; 
    return 2;
  }
  
  public final int DecodePicture(byte[] ds_rdbfr, int ds_rdbfr_offset, boolean EntireFrame) {
    int rc = 0;
    if (EntireFrame) {
      this.frameDone = false;
      this.rdptr = ds_rdbfr_offset;
      while (rc == 0)
        rc = DecodeGobs(ds_rdbfr, this.rdptr); 
    } else {
      rc = DecodeGobs(ds_rdbfr, ds_rdbfr_offset);
    } 
    return rc;
  }
  
  public final int DecodeGobs(byte[] ds_rdbfr, int ds_rdbfr_offset) {
    int rc = 0;
    setInBuf(ds_rdbfr, ds_rdbfr_offset);
    GetNextStartCode();
    int startCode = getBits(22);
    if (startCode != 32 && startCode != 63 && !this.foundPSC)
      return 3; 
    if (startCode == 32) {
      this.foundPSC = true;
    } else if (startCode == 63) {
      return 0;
    } 
    if (startCode == 63) {
      GetNextStartCode();
      startCode = getBits(22);
    } 
    if (startCode != 32 && !this.foundPSC)
      return 0; 
    if (startCode == 32) {
      this.foundPSC = true;
      int tmpTemporalReference = getBits(8);
      this.TypeInformation = getBits(8);
      this.HeaderPlus = this.TypeInformation & 0x7;
      int srcFormat = this.HeaderPlus;
      if (this.HeaderPlus == 7) {
        rc = ParseHeaderPlus();
        if (rc == 2)
          return rc; 
      } else {
        this.TypeInformation = getBits(5);
        if ((this.TypeInformation & 0x7) != 0)
          return 2; 
        this.CodingType = this.TypeInformation >> 4 & 0x1;
        this.UnrestrictedMV = (this.TypeInformation & 0x8) >> 3;
      } 
      this.LastTemporalReference = this.TemporalReference;
      this.TemporalReference = tmpTemporalReference;
      this.Quantizer = getBits(5);
      if (this.HeaderPlus != 7) {
        this.CPM = getBits(1);
        if (this.CPM != 0)
          getBits(2); 
      } 
      int PEI = getBits(1);
      if (PEI == 1)
        return 2; 
      if (srcFormat != this.SourceFormat) {
        rc = ChangeFormat(srcFormat, this.UnrestrictedMV);
        if (rc == 2)
          return rc; 
      } 
      FrameBuffer tmpFrame = this.CurrentFrame;
      this.CurrentFrame = this.PreviousFrame;
      this.PreviousFrame = tmpFrame;
      this.BlockPtr[0] = this.CurrentFrame.Y;
      this.BlockPtr[1] = this.CurrentFrame.Y;
      this.BlockPtr[2] = this.CurrentFrame.Y;
      this.BlockPtr[3] = this.CurrentFrame.Y;
      this.BlockPtr[4] = this.CurrentFrame.Cb;
      this.BlockPtr[5] = this.CurrentFrame.Cr;
      if (this.CodingType == 0) {
        this.GroupNumber = 0;
        GetIntraPictMB();
      } else {
        if (this.UnrestrictedMV == 1) {
          this.xFrameWidth = this.FrameWidth + 32;
          this.xFrameWidthDiv2 = this.xFrameWidth >> 1;
          CopyExtendedFrame(this.PreviousFrame.Y, this.xPrevFrame.Y, this.FrameWidth, this.FrameHeight, this.xFrameWidth, 16);
          CopyExtendedFrame(this.PreviousFrame.Cb, this.xPrevFrame.Cb, this.FrameWidthDiv2, this.FrameHeight >> 1, this.xFrameWidthDiv2, 8);
          CopyExtendedFrame(this.PreviousFrame.Cr, this.xPrevFrame.Cr, this.FrameWidthDiv2, this.FrameHeight >> 1, this.xFrameWidthDiv2, 8);
        } 
        this.GroupNumber = 0;
        GetInterPictMB();
      } 
    } else if (startCode >= 33 && startCode <= 62) {
      int tmp = startCode & 0x1F;
      if (tmp != this.GroupNumber)
        this.GroupNumber = tmp; 
      if (this.CPM != 0)
        skipBits(2); 
      this.GOB_FrameID = getBits(2);
      this.Quantizer = getBits(5);
      if (this.CodingType == 0) {
        GetIntraPictMB();
      } else {
        GetInterPictMB();
      } 
    } else {
      return 2;
    } 
    if (this.GroupNumber == this.GOBperFrame) {
      this.frameDone = true;
      this.foundPSC = false;
      if (this.DeblockingFilter == 1)
        EdgeFilter(); 
      return 1;
    } 
    this.frameDone = false;
    return 0;
  }
  
  private final int ParseHeaderPlus() {
    int srcFormat = 0;
    int UFEP = getBits(3);
    if (UFEP == 1) {
      srcFormat = getBits(3);
      int tmpBits = getBits(1);
      if (tmpBits == 1)
        return 2; 
      this.UnrestrictedMV = getBits(1);
      tmpBits = getBits(4);
      if (tmpBits > 1)
        return 2; 
      this.DeblockingFilter = tmpBits & 0x1;
      tmpBits = getBits(9);
      if (tmpBits != 8)
        return 2; 
    } 
    this.CodingType = getBits(3);
    if (this.CodingType > 1)
      return 2; 
    int i = getBits(6);
    if (i != 1)
      return 2; 
    this.CPM = getBits(1);
    if (this.CPM != 0)
      getBits(2); 
    if (srcFormat == 6) {
      i = getBits(4);
      if (i != 2)
        return 2; 
      int PDI = getBits(9);
      i = PDI + 1 << 2;
      if (i != this.FrameWidth) {
        this.SourceFormat = 9;
        this.FrameWidth = i;
      } 
      i = getBits(1);
      PDI = getBits(9);
      i = PDI << 2;
      if (i != this.FrameHeight) {
        this.SourceFormat = 9;
        this.FrameHeight = i;
      } 
    } 
    return 1;
  }
  
  private final void EdgeFilter() {
    HorizEdgeFilter(this.CurrentFrame.Y, 0);
    VertEdgeFilter(this.CurrentFrame.Y, 0);
    HorizEdgeFilter(this.CurrentFrame.Cb, 1);
    VertEdgeFilter(this.CurrentFrame.Cb, 1);
    HorizEdgeFilter(this.CurrentFrame.Cr, 1);
    VertEdgeFilter(this.CurrentFrame.Cr, 1);
  }
  
  private final void HorizEdgeFilter(int[] rec, int divisor) {
    int width = this.FrameWidth >> divisor;
    int height = this.FrameHeight >> divisor;
    for (int j = 8; j < height; j += 8) {
      int mbr = j >> 4 - divisor;
      int mbr_above = j + (divisor - 1 << 3) >> 4;
      int index = j * width;
      for (int i = 0; i < width; i++, index++) {
        int mbc = i >> 4 - divisor;
        if (CodedMap[(mbr + 1) * (mbc + 1)] > 0 || CodedMap[(mbr_above + 1) * (mbc + 1)] > 0) {
          int delta = rec[index - (width << 1)] - (rec[index - width] << 2) + (rec[index] << 2) - rec[index + width] >> 3;
          int d1 = ((delta < 0) ? -1 : 1) * Math.max(0, Math.abs(delta) - Math.max(0, Math.abs(delta) - STRENGTH[this.Quantizer - 1] << 1));
          int d2 = Math.min(Math.abs(d1 >> 1), Math.max(-Math.abs(d1 >> 1), rec[index - (width << 1)] - rec[index + width] >> 2));
          rec[index + width] = rec[index + width] + d2;
          rec[index] = DfiltClip[rec[index] - d1 + 128];
          rec[index - width] = DfiltClip[rec[index - width] + d1 + 128];
          rec[index - (width << 1)] = rec[index - (width << 1)] - d2;
        } 
      } 
    } 
  }
  
  private final void VertEdgeFilter(int[] rec, int divisor) {
    int width = this.FrameWidth >> divisor;
    int height = this.FrameHeight >> divisor;
    for (int i = 8; i < width; i += 8) {
      int mbc = i >> 4 - divisor;
      int mbc_left = i + (divisor - 1 << 3) >> 4;
      int index = i;
      for (int j = 0; j < height; j++, index += width) {
        int mbr = j >> 4 - divisor;
        if (CodedMap[(mbr + 1) * (mbc + 1)] > 0 || CodedMap[(mbr + 1) * (mbc_left + 1)] > 0) {
          int delta = rec[index - 2] - (rec[index - 1] << 2) + (rec[index] << 2) - rec[index + 1] >> 3;
          int d1 = ((delta < 0) ? -1 : 1) * Math.max(0, Math.abs(delta) - Math.max(0, Math.abs(delta) - STRENGTH[this.Quantizer - 1] << 1));
          int d2 = Math.min(Math.abs(d1 >> 1), Math.max(-Math.abs(d1 >> 1), rec[index - 2] - rec[index + 1] >> 2));
          rec[index + 1] = rec[index + 1] + d2;
          rec[index] = DfiltClip[rec[index] - d1 + 128];
          rec[index - 1] = DfiltClip[rec[index - 1] + d1 + 128];
          rec[index - 2] = rec[index - 2] - d2;
        } 
      } 
    } 
  }
  
  private final void GetIntraPictMB() {
    int[] clipQ = clipQ_tab;
    do {
      this.FirstMBinGOB = this.GroupNumber * this.MBperGOB;
      this.CurrentLumiOffset = LumiOffset[this.GroupNumber];
      this.CurrentCromOffset = CromOffset[this.GroupNumber];
      this.MB_address = this.FirstMBinGOB;
      int MBinNextGOB = this.FirstMBinGOB + this.MBperGOB;
      for (; this.MB_address < MBinNextGOB; this.MB_address++) {
        int MCBPC;
        do {
          MCBPC = GetIntraMCBPC_VLC();
        } while (MCBPC == -1);
        int MBtype = MCBPC >> 4;
        int CBPY = GetCBPY_VLC() >> 4;
        if (MBtype == 4) {
          this.Quantizer = clipQ[this.Quantizer + dQuant[nextBits(2)]];
          skipBits(2);
        } 
        CodedMap[this.MB_address] = 2;
        this.BlockOffset[0] = this.CurrentLumiOffset;
        this.BlockOffset[1] = this.BlockOffset[0] + 8;
        this.BlockOffset[2] = this.BlockOffset[0] + this.FrameWidthx8;
        this.BlockOffset[3] = this.BlockOffset[2] + 8;
        this.BlockOffset[4] = this.CurrentCromOffset;
        this.BlockOffset[5] = this.CurrentCromOffset;
        int CBP = CBPY << 2 | MCBPC & 0x3;
        for (int cnt = 0; cnt < 6; cnt++) {
          int tempDC = getBits(8);
          if (tempDC == 255)
            tempDC = 128; 
          this.BlockData[cnt][0] = tempDC << 12;
          if ((CBP & 0x20) != 0)
            GetCoefficients(1, cnt); 
          idct8x8(this.BlockData[cnt], this.BlockPtr[cnt], this.BlockOffset[cnt], this.FrameWidthBlock[cnt], 1);
          CBP <<= 1;
        } 
        this.CurrentLumiOffset += 16;
        this.CurrentCromOffset += 8;
      } 
      this.GroupNumber++;
    } while (StartCodeFound() == 0 && this.GroupNumber < this.GOBperFrame);
  }
  
  private final void GetInterPictMB() {
    int MCBPC = 0;
    int[] clipQ = clipQ_tab;
    this.HeaderInGOB = true;
    do {
      this.FirstMBinGOB = this.GroupNumber * this.MBperGOB;
      this.CurrentLumiOffset = LumiOffset[this.GroupNumber];
      this.CurrentCromOffset = CromOffset[this.GroupNumber];
      this.xCurrentLumiOffset = xLumiOffset[this.GroupNumber];
      this.xCurrentCromOffset = xCromOffset[this.GroupNumber];
      this.MB_address = this.FirstMBinGOB;
      int MBinNextGOB = this.FirstMBinGOB + this.MBperGOB;
      for (; this.MB_address < MBinNextGOB; this.MB_address++) {
        int COD;
        this.MBpositionInGOB = this.MB_address - this.FirstMBinGOB;
        do {
          COD = getBits(1);
          if (COD != 0) {
            if (this.UnrestrictedMV != 0) {
              Copy16x16Pel(this.xPrevFrame.Y, this.xCurrentLumiOffset, this.CurrentFrame.Y, this.CurrentLumiOffset);
              Copy8x8Pel(this.xPrevFrame.Cr, this.xCurrentCromOffset, this.CurrentFrame.Cr, this.CurrentCromOffset);
              Copy8x8Pel(this.xPrevFrame.Cb, this.xCurrentCromOffset, this.CurrentFrame.Cb, this.CurrentCromOffset);
            } else {
              Copy16x16Pel(this.PreviousFrame.Y, this.CurrentLumiOffset, this.CurrentFrame.Y, this.CurrentLumiOffset);
              Copy8x8Pel(this.PreviousFrame.Cr, this.CurrentCromOffset, this.CurrentFrame.Cr, this.CurrentCromOffset);
              Copy8x8Pel(this.PreviousFrame.Cb, this.CurrentCromOffset, this.CurrentFrame.Cb, this.CurrentCromOffset);
            } 
            (this.MotVectCurrGOB[this.MBpositionInGOB]).x = 0;
            (this.MotVectCurrGOB[this.MBpositionInGOB]).y = 0;
            this.CurrentLumiOffset += 16;
            this.CurrentCromOffset += 8;
            this.xCurrentLumiOffset += 16;
            this.xCurrentCromOffset += 8;
            break;
          } 
          MCBPC = GetInterMCBPC_VLC();
        } while (MCBPC == -1);
        if (COD == 0) {
          int MBtype = MCBPC >> 4;
          this.BlockOffset[0] = this.CurrentLumiOffset;
          this.BlockOffset[1] = this.BlockOffset[0] + 8;
          this.BlockOffset[2] = this.BlockOffset[0] + this.FrameWidthx8;
          this.BlockOffset[3] = this.BlockOffset[2] + 8;
          this.BlockOffset[4] = this.CurrentCromOffset;
          this.BlockOffset[5] = this.CurrentCromOffset;
          if (MBtype >= 3) {
            CodedMap[this.MB_address] = 2;
            int CBPY = GetCBPY_VLC() >> 4;
            if (MBtype == 4) {
              this.Quantizer = clipQ[this.Quantizer + dQuant[nextBits(2)]];
              skipBits(2);
            } 
            int CBP = CBPY << 2 | MCBPC & 0x3;
            for (int cnt = 0; cnt < 6; cnt++) {
              int tempDC = getBits(8);
              if (tempDC == 255)
                tempDC = 128; 
              this.BlockData[cnt][0] = tempDC << 12;
              if ((CBP & 0x20) != 0)
                GetCoefficients(1, cnt); 
              idct8x8(this.BlockData[cnt], this.BlockPtr[cnt], this.BlockOffset[cnt], this.FrameWidthBlock[cnt], 1);
              CBP <<= 1;
            } 
            (this.MotVectCurrGOB[this.MBpositionInGOB]).x = 0;
            (this.MotVectCurrGOB[this.MBpositionInGOB]).y = 0;
          } else {
            CodedMap[this.MB_address] = 1;
            int i = GetCBPY_VLC();
            if (MBtype == 1) {
              this.Quantizer = clipQ[this.Quantizer + dQuant[nextBits(2)]];
              skipBits(2);
            } 
            FindMV();
            BasePredPel();
            int j = i << 2 | MCBPC & 0x3;
            for (int cnt = 0; cnt < 6; cnt++) {
              if ((j & 0x20) != 0) {
                GetCoefficients(0, cnt);
                idct8x8(this.BlockData[cnt], this.BlockPtr[cnt], this.BlockOffset[cnt], this.FrameWidthBlock[cnt], 0);
              } 
              j <<= 1;
            } 
          } 
          this.CurrentLumiOffset += 16;
          this.CurrentCromOffset += 8;
          this.xCurrentLumiOffset += 16;
          this.xCurrentCromOffset += 8;
        } else {
          CodedMap[this.MB_address] = 0;
        } 
      } 
      Point[] MotVectTemp = this.MotVectCurrGOB;
      this.MotVectCurrGOB = this.MotVectPrevGOB;
      this.MotVectPrevGOB = MotVectTemp;
      this.GroupNumber++;
      this.HeaderInGOB = false;
    } while (StartCodeFound() == 0 && this.GroupNumber < this.GOBperFrame);
  }
  
  private final void GetCoefficients(int startIndex, int cnt) {
    int j, bits = 0;
    int vlcValue = 0, vlcBits = 0;
    int[] zigzag = zigzag_tab;
    int[] pre8x8 = pre8x8_tab;
    int[][] recLevel = recLevel_tab;
    int[] tempData = this.BlockData[cnt];
    int[] TCOEFF10 = TCOEFF1_tab0;
    int[] TCOEFF11 = TCOEFF1_tab1;
    int[] TCOEFF20 = TCOEFF2_tab0;
    int[] TCOEFF21 = TCOEFF2_tab1;
    int[] TCOEFF30 = TCOEFF3_tab0;
    int[] TCOEFF31 = TCOEFF3_tab1;
    int i;
    for (i = startIndex; i < 64; i++)
      tempData[i] = 0; 
    i = startIndex - 1;
    do {
      int m;
      bits = nextBits(13);
      if (bits >= 1024) {
        int offset = (bits >> 6) - 16;
        vlcValue = TCOEFF10[offset];
        vlcBits = TCOEFF11[offset];
      } else if (bits >= 256) {
        int offset = (bits >> 3) - 32;
        vlcValue = TCOEFF20[offset];
        vlcBits = TCOEFF21[offset];
      } else {
        int offset = (bits >> 1) - 8;
        vlcValue = TCOEFF30[offset];
        vlcBits = TCOEFF31[offset];
      } 
      skipBits(vlcBits + 1);
      int value = vlcValue;
      if (value != 7167) {
        k = ((bits >> 12 - vlcBits & 0x1) != 0) ? -(value & 0xF) : (value & 0xF);
        m = value >> 4 & 0x3F;
        j = value & 0x1000;
      } else {
        value = getBits(15);
        k = value << 24 >> 24;
        m = value >> 8 & 0x3F;
        j = value & 0x4000;
      } 
      i += m + 1;
      i &= 0x3F;
      int index = zigzag[i];
      if (k == 0)
        continue; 
      int sign = (k < 0) ? 1 : 0;
      int k = Math.abs(k);
      if ((this.Quantizer & 0x1) != 0) {
        tempData[index] = pre8x8[index] * ((sign != 0) ? -recLevel[this.Quantizer][k] : recLevel[this.Quantizer][k]);
      } else {
        tempData[index] = pre8x8[index] * ((sign != 0) ? (1 - recLevel[this.Quantizer][k]) : (recLevel[this.Quantizer][k] - 1));
      } 
    } while (j == 0);
    this.LastValue = i;
  }
  
  private final int GetIntraMCBPC_VLC() {
    int bits = nextBits(9);
    if (bits == 1) {
      skipBits(9);
      return -1;
    } 
    int index = bits >> 3;
    int vlcValue = IntraMCBPC_VLC_tab0[index];
    int vlcBits = IntraMCBPC_VLC_tab1[index];
    skipBits(vlcBits);
    return vlcValue;
  }
  
  private final int GetCBPY_VLC() {
    int index = nextBits(6);
    int vlcValue = CBPY_VLC_tab0[index];
    int vlcBits = CBPY_VLC_tab1[index];
    skipBits(vlcBits);
    return vlcValue;
  }
  
  private final int GetInterMCBPC_VLC() {
    int index = nextBits(9);
    int vlcValue = InterMCBPC_VLC_tab0[index];
    int vlcBits = InterMCBPC_VLC_tab1[index];
    skipBits(vlcBits);
    return vlcValue;
  }
  
  private final int GetMVD_VLC() {
    int i, j, bits = nextBits(13);
    if (bits >= 192) {
      int index = bits >> 5;
      i = MVD1_VLC_tab0[index];
      j = MVD1_VLC_tab1[index];
    } else {
      int index = bits;
      i = MVD2_VLC_tab0[index];
      j = MVD2_VLC_tab1[index];
    } 
    skipBits(j);
    return i;
  }
  
  public final void CopyExtendedFrame(int[] src, int[] dest, int Width, int Height, int xWidth, int edge) {
    int imageSize = Width * Height;
    int xImageSize = xWidth * (Height + (edge << 1));
    int xStripe = xWidth * edge;
    int destIndex, srcIndex;
    for (srcIndex = 0, destIndex = xStripe + edge; srcIndex < imageSize; 
      srcIndex += Width, destIndex += xWidth)
      System.arraycopy(src, srcIndex, dest, destIndex, Width); 
    for (destIndex = xStripe, srcIndex = 0; destIndex < xImageSize - xStripe; 
      destIndex += xWidth, srcIndex += Width) {
      for (int Index = 0; Index < edge; Index++) {
        dest[destIndex + Index] = src[srcIndex];
        dest[destIndex + Width + edge + Index] = src[srcIndex + Width - 1];
      } 
    } 
    for (destIndex = 0; destIndex < xStripe; destIndex += xWidth) {
      System.arraycopy(dest, xStripe, dest, destIndex, edge);
      System.arraycopy(dest, xStripe + Width + edge, dest, destIndex + Width + edge, edge);
    } 
    for (destIndex = xImageSize - xStripe; destIndex < xImageSize; 
      destIndex += xWidth) {
      System.arraycopy(dest, xImageSize - xStripe - xWidth, dest, destIndex, edge);
      System.arraycopy(dest, xImageSize - xStripe - edge, dest, destIndex + Width + edge, edge);
    } 
    for (destIndex = edge; destIndex < xStripe + edge; destIndex += xWidth) {
      System.arraycopy(dest, xStripe + edge, dest, destIndex, Width);
      System.arraycopy(dest, xImageSize - xStripe - xWidth + edge, dest, destIndex + xImageSize - xStripe, Width);
    } 
  }
  
  private final void BasePredPel() {
    int arrayOfInt1[], arrayOfInt2[], i, x_vec = (this.MotVectCurrGOB[this.MBpositionInGOB]).x;
    int y_vec = (this.MotVectCurrGOB[this.MBpositionInGOB]).y;
    if (x_vec < -32 && this.MBpositionInGOB == 0) {
      x_vec = -32;
    } else if (x_vec > 32 && this.MBpositionInGOB == this.GOBperFrame - 1) {
      x_vec = 32;
    } 
    this.HorMV = x_vec >> 1;
    this.Half_HorMV = x_vec & 0x1;
    if (y_vec < -32 && this.GroupNumber == 0) {
      y_vec = -32;
    } else if (y_vec > 32 && this.GroupNumber == this.GOBperFrame - 1) {
      y_vec = 32;
    } 
    this.VerMV = y_vec >> 1;
    this.Half_VerMV = y_vec & 0x1;
    int dest[] = this.CurrentFrame.Y, destIndex = this.CurrentLumiOffset;
    if (this.UnrestrictedMV != 0) {
      arrayOfInt1 = this.xPrevFrame.Y;
      i = this.xCurrentLumiOffset + this.VerMV * this.xFrameWidth + this.HorMV;
    } else {
      arrayOfInt1 = this.PreviousFrame.Y;
      i = this.CurrentLumiOffset + this.VerMV * this.FrameWidth + this.HorMV;
    } 
    if (this.Half_HorMV != 0 && this.Half_VerMV != 0) {
      InterpF16x16Pel(arrayOfInt1, i, dest, destIndex);
    } else if (this.Half_HorMV != 0 || this.Half_VerMV != 0) {
      Interp16x16Pel(arrayOfInt1, i, dest, destIndex, this.Half_HorMV, this.Half_VerMV);
    } else {
      Copy16x16Pel(arrayOfInt1, i, dest, destIndex);
    } 
    this.Half_HorMV |= this.HorMV & 0x1;
    this.HorMV >>= 1;
    this.Half_VerMV |= this.VerMV & 0x1;
    this.VerMV >>= 1;
    dest = this.CurrentFrame.Cr;
    destIndex = this.CurrentCromOffset;
    int[] dest1 = this.CurrentFrame.Cb;
    if (this.UnrestrictedMV != 0) {
      arrayOfInt1 = this.xPrevFrame.Cr;
      i = this.xCurrentCromOffset + this.VerMV * this.xFrameWidthDiv2 + this.HorMV;
      arrayOfInt2 = this.xPrevFrame.Cb;
    } else {
      arrayOfInt1 = this.PreviousFrame.Cr;
      i = this.CurrentCromOffset + this.VerMV * this.FrameWidthDiv2 + this.HorMV;
      arrayOfInt2 = this.PreviousFrame.Cb;
    } 
    if (this.Half_HorMV != 0 && this.Half_VerMV != 0) {
      InterpF8x8Pel(arrayOfInt1, i, dest, destIndex);
      InterpF8x8Pel(arrayOfInt2, i, dest1, destIndex);
    } else if (this.Half_HorMV != 0 || this.Half_VerMV != 0) {
      Interp8x8Pel(arrayOfInt1, i, dest, destIndex, this.Half_HorMV, this.Half_VerMV);
      Interp8x8Pel(arrayOfInt2, i, dest1, destIndex, this.Half_HorMV, this.Half_VerMV);
    } else {
      Copy8x8Pel(arrayOfInt1, i, dest, destIndex);
      Copy8x8Pel(arrayOfInt2, i, dest1, destIndex);
    } 
  }
  
  private final void FindMV() {
    int i, j, k, m, MBpositionInGOB = this.MB_address - this.FirstMBinGOB;
    int HorMVD = GetMVD_VLC();
    int VerMVD = GetMVD_VLC();
    if (MBpositionInGOB == 0) {
      i = 0;
      j = 0;
    } else {
      i = (this.MotVectCurrGOB[MBpositionInGOB - 1]).x;
      j = (this.MotVectCurrGOB[MBpositionInGOB - 1]).y;
    } 
    if (this.HeaderInGOB) {
      (this.MotVectCurrGOB[MBpositionInGOB]).x = CALC_MVC(HorMVD, i);
      (this.MotVectCurrGOB[MBpositionInGOB]).y = CALC_MVC(VerMVD, j);
      return;
    } 
    int MV2x = (this.MotVectPrevGOB[MBpositionInGOB]).x;
    int MV2y = (this.MotVectPrevGOB[MBpositionInGOB]).y;
    if (MBpositionInGOB + 1 == this.MBperGOB) {
      k = 0;
      m = 0;
    } else {
      k = (this.MotVectPrevGOB[MBpositionInGOB + 1]).x;
      m = (this.MotVectPrevGOB[MBpositionInGOB + 1]).y;
    } 
    int MVx = median(i, MV2x, k);
    int MVy = median(j, MV2y, m);
    (this.MotVectCurrGOB[MBpositionInGOB]).x = CALC_MVC(HorMVD, MVx);
    (this.MotVectCurrGOB[MBpositionInGOB]).y = CALC_MVC(VerMVD, MVy);
  }
  
  private final int median(int mv1, int mv2, int mv3) {
    return (mv1 >= mv2) ? ((mv2 >= mv3) ? mv2 : ((mv1 >= mv3) ? mv3 : mv1)) : ((mv1 >= mv3) ? mv1 : ((mv2 >= mv3) ? mv3 : mv2));
  }
  
  private final int CALC_MVC(int MVd, int Pc) {
    return (this.UnrestrictedMV == 0) ? ((MVd + Pc + 96 & 0x3F) - 32) : ((Pc >= 33) ? (MVd + Pc & 0x3F) : ((Pc <= -32) ? -(-(MVd + Pc) & 0x3F) : (MVd + Pc)));
  }
  
  private final void Copy16x16Pel(int[] src, int srcIndex, int[] dest, int destIndex) {
    int frameW = this.FrameWidth, xframeW = this.xFrameWidth;
    for (int i = 0; i < 16; i++) {
      System.arraycopy(src, srcIndex, dest, destIndex, 16);
      destIndex += frameW;
      srcIndex += xframeW;
    } 
  }
  
  private final void Interp16x16Pel(int[] src, int srcIndex, int[] dest, int destIndex, int Hor, int Ver) {
    int offset1 = srcIndex;
    int offset2 = srcIndex + Ver * this.xFrameWidth + Hor;
    int frameW = this.FrameWidth, xframeW = this.xFrameWidth;
    for (int i = 0; i < 16; i++) {
      for (int j = 0; j < 16; j++)
        dest[destIndex + j] = src[offset1 + j] + src[offset2 + j] + 1 >> 1; 
      destIndex += frameW;
      offset1 += xframeW;
      offset2 += xframeW;
    } 
  }
  
  private final void InterpF16x16Pel(int[] src, int srcIndex, int[] dest, int destIndex) {
    int offset1 = srcIndex;
    int offset2 = srcIndex + this.xFrameWidth;
    int width1 = this.FrameWidth - 15;
    int width2 = this.xFrameWidth - 16;
    for (int i = 0; i < 16; i++) {
      int x10 = src[offset1++];
      int x11 = src[offset1++];
      int x12 = src[offset1++];
      int x13 = src[offset1++];
      int x14 = src[offset1++];
      int x15 = src[offset1++];
      int x16 = src[offset1++];
      int x17 = src[offset1++];
      int x18 = src[offset1++];
      int x19 = src[offset1++];
      int x110 = src[offset1++];
      int x111 = src[offset1++];
      int x112 = src[offset1++];
      int x113 = src[offset1++];
      int x114 = src[offset1++];
      int x115 = src[offset1++];
      int x116 = src[offset1];
      int x20 = src[offset2++];
      int x21 = src[offset2++];
      int x22 = src[offset2++];
      int x23 = src[offset2++];
      int x24 = src[offset2++];
      int x25 = src[offset2++];
      int x26 = src[offset2++];
      int x27 = src[offset2++];
      int x28 = src[offset2++];
      int x29 = src[offset2++];
      int x210 = src[offset2++];
      int x211 = src[offset2++];
      int x212 = src[offset2++];
      int x213 = src[offset2++];
      int x214 = src[offset2++];
      int x215 = src[offset2++];
      int x216 = src[offset2];
      dest[destIndex++] = x10 + x11 + x20 + x21 + 2 >> 2;
      dest[destIndex++] = x11 + x12 + x21 + x22 + 2 >> 2;
      dest[destIndex++] = x12 + x13 + x22 + x23 + 2 >> 2;
      dest[destIndex++] = x13 + x14 + x23 + x24 + 2 >> 2;
      dest[destIndex++] = x14 + x15 + x24 + x25 + 2 >> 2;
      dest[destIndex++] = x15 + x16 + x25 + x26 + 2 >> 2;
      dest[destIndex++] = x16 + x17 + x26 + x27 + 2 >> 2;
      dest[destIndex++] = x17 + x18 + x27 + x28 + 2 >> 2;
      dest[destIndex++] = x18 + x19 + x28 + x29 + 2 >> 2;
      dest[destIndex++] = x19 + x110 + x29 + x210 + 2 >> 2;
      dest[destIndex++] = x110 + x111 + x210 + x211 + 2 >> 2;
      dest[destIndex++] = x111 + x112 + x211 + x212 + 2 >> 2;
      dest[destIndex++] = x112 + x113 + x212 + x213 + 2 >> 2;
      dest[destIndex++] = x113 + x114 + x213 + x214 + 2 >> 2;
      dest[destIndex++] = x114 + x115 + x214 + x215 + 2 >> 2;
      dest[destIndex] = x115 + x116 + x215 + x216 + 2 >> 2;
      destIndex += width1;
      offset1 += width2;
      offset2 += width2;
    } 
  }
  
  private final void Copy8x8Pel(int[] src, int srcIndex, int[] dest, int destIndex) {
    int width1 = this.FrameWidthDiv2;
    int width2 = this.xFrameWidthDiv2;
    for (int i = 0; i < 8; i++) {
      System.arraycopy(src, srcIndex, dest, destIndex, 8);
      destIndex += width1;
      srcIndex += width2;
    } 
  }
  
  private final void Interp8x8Pel(int[] src, int srcIndex, int[] dest, int destIndex, int Hor, int Ver) {
    int offset1 = srcIndex;
    int offset2 = srcIndex + Ver * this.xFrameWidthDiv2 + Hor;
    int width1 = this.FrameWidthDiv2 - 8;
    int width2 = this.xFrameWidthDiv2 - 8;
    for (int i = 0; i < 8; i++) {
      for (int j = 0; j < 8; j++)
        dest[destIndex++] = src[offset1++] + src[offset2++] + 1 >> 1; 
      destIndex += width1;
      offset1 += width2;
      offset2 += width2;
    } 
  }
  
  private final void InterpF8x8Pel(int[] src, int srcIndex, int[] dest, int destIndex) {
    int offset1 = srcIndex;
    int offset2 = srcIndex + this.xFrameWidthDiv2;
    int width1 = this.FrameWidthDiv2 - 7;
    int width2 = this.xFrameWidthDiv2 - 8;
    for (int i = 0; i < 8; i++) {
      int x10 = src[offset1++];
      int x11 = src[offset1++];
      int x12 = src[offset1++];
      int x13 = src[offset1++];
      int x14 = src[offset1++];
      int x15 = src[offset1++];
      int x16 = src[offset1++];
      int x17 = src[offset1++];
      int x18 = src[offset1];
      int x20 = src[offset2++];
      int x21 = src[offset2++];
      int x22 = src[offset2++];
      int x23 = src[offset2++];
      int x24 = src[offset2++];
      int x25 = src[offset2++];
      int x26 = src[offset2++];
      int x27 = src[offset2++];
      int x28 = src[offset2];
      dest[destIndex++] = x10 + x11 + x20 + x21 + 2 >> 2;
      dest[destIndex++] = x11 + x12 + x21 + x22 + 2 >> 2;
      dest[destIndex++] = x12 + x13 + x22 + x23 + 2 >> 2;
      dest[destIndex++] = x13 + x14 + x23 + x24 + 2 >> 2;
      dest[destIndex++] = x14 + x15 + x24 + x25 + 2 >> 2;
      dest[destIndex++] = x15 + x16 + x25 + x26 + 2 >> 2;
      dest[destIndex++] = x16 + x17 + x26 + x27 + 2 >> 2;
      dest[destIndex] = x17 + x18 + x27 + x28 + 2 >> 2;
      destIndex += width1;
      offset1 += width2;
      offset2 += width2;
    } 
  }
  
  private final void GetNextStartCode() {
    while (nextBits(17) != 1)
      skipBits(1); 
  }
  
  private final int StartCodeFound() {
    int code = nextBits(16);
    if (code == 0) {
      int count = 0;
      while ((code = nextBits(17)) != 1 && count < 7) {
        skipBits(1);
        count++;
      } 
      if (code == 1)
        return 1; 
      return 0;
    } 
    return 0;
  }
  
  private final void idct8x8(int[] blk, int[] pixel, int pixOffset, int width, int flag) {
    int i8 = 7, i16 = 15, i24 = 23, i32 = 31, i40 = 39, i48 = 47;
    int i56 = 55;
    for (int i = -1; i < 7; ) {
      int blk_i = blk[++i];
      int blk_i8 = blk[++i8];
      int blk_i16 = blk[++i16];
      int blk_i24 = blk[++i24];
      int blk_i32 = blk[++i32];
      int blk_i40 = blk[++i40];
      int blk_i48 = blk[++i48];
      int blk_i56 = blk[++i56];
      if ((blk_i8 | blk_i16 | blk_i24 | blk_i32 | blk_i40 | blk_i48 | blk_i56) == 0) {
        blk[i56] = blk_i;
        blk[i48] = blk_i;
        blk[i40] = blk_i;
        blk[i32] = blk_i;
        blk[i24] = blk_i;
        blk[i16] = blk_i;
        blk[i8] = blk_i;
        continue;
      } 
      int x8 = blk_i + blk_i32;
      int x9 = blk_i - blk_i32;
      int x11 = blk_i16 + blk_i48;
      int x10 = (362 * (blk_i16 - blk_i48) >> 8) - x11;
      int x0 = x8 + x11;
      int x3 = x8 - x11;
      int x1 = x9 + x10;
      int x2 = x9 - x10;
      int y5 = blk_i40 + blk_i24;
      int y2 = blk_i40 - blk_i24;
      int y3 = blk_i8 + blk_i56;
      int y4 = blk_i8 - blk_i56;
      int x7 = y3 + y5;
      x9 = 362 * (y3 - y5) >> 8;
      int y1 = 473 * (y2 + y4) >> 8;
      x8 = (277 * y4 >> 8) - y1;
      x10 = (-669 * y2 >> 8) + y1;
      int x6 = x10 - x7;
      int x5 = x9 - x6;
      int x4 = x8 + x5;
      blk[i] = x0 + x7;
      blk[i8] = x1 + x6;
      blk[i16] = x2 + x5;
      blk[i24] = x3 - x4;
      blk[i32] = x3 + x4;
      blk[i40] = x2 - x5;
      blk[i48] = x1 - x6;
      blk[i56] = x0 - x7;
    } 
    int offset = 0;
    int[] clip = clipTable;
    for (int j = 0; j < 8; j++) {
      int o0, blk_o0 = blk[o0 = offset++];
      int o1, blk_o1 = blk[o1 = offset++];
      int o2, blk_o2 = blk[o2 = offset++];
      int o3, blk_o3 = blk[o3 = offset++];
      int o4, blk_o4 = blk[o4 = offset++];
      int o5, blk_o5 = blk[o5 = offset++];
      int o6, blk_o6 = blk[o6 = offset++];
      int o7, blk_o7 = blk[o7 = offset++];
      if ((blk_o1 | blk_o2 | blk_o3 | blk_o4 | blk_o5 | blk_o6 | blk_o7) == 0) {
        int temp = blk_o0 + 2048 >> 12;
        blk[o7] = temp;
        blk[o6] = temp;
        blk[o5] = temp;
        blk[o4] = temp;
        blk[o3] = temp;
        blk[o2] = temp;
        blk[o1] = temp;
        blk[o0] = temp;
        if (flag != 0) {
          temp = clip[0x3FF & temp];
          pixel[pixOffset++] = temp;
          pixel[pixOffset++] = temp;
          pixel[pixOffset++] = temp;
          pixel[pixOffset++] = temp;
          pixel[pixOffset++] = temp;
          pixel[pixOffset++] = temp;
          pixel[pixOffset++] = temp;
          pixel[pixOffset++] = temp;
        } else {
          pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + temp];
          pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + temp];
          pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + temp];
          pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + temp];
          pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + temp];
          pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + temp];
          pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + temp];
          pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + temp];
        } 
        pixOffset += width - 8;
      } else {
        int i6 = blk_o0 + blk_o4;
        int i7 = blk_o0 - blk_o4;
        int i10 = blk_o2 + blk_o6;
        int i9 = (362 * (blk_o2 - blk_o6) >> 8) - i10;
        int k = i6 + i10 + 2048;
        int i1 = i6 - i10 + 2048;
        int m = i7 + i9 + 2048;
        int n = i7 - i9 + 2048;
        int i15 = blk_o5 + blk_o3;
        int i12 = blk_o5 - blk_o3;
        int i13 = blk_o1 + blk_o7;
        int i14 = blk_o1 - blk_o7;
        int i5 = i13 + i15;
        i7 = 362 * (i13 - i15) >> 8;
        int i11 = 473 * (i12 + i14) >> 8;
        i6 = (277 * i14 >> 8) - i11;
        i9 = (-669 * i12 >> 8) + i11;
        int i4 = i9 - i5;
        int i3 = i7 - i4;
        int i2 = i6 + i3;
        if (flag != 0) {
          blk[o0] = k + i5 >> 12;
          pixel[pixOffset++] = clip[0x3FF & k + i5 >> 12];
          blk[o1] = m + i4 >> 12;
          pixel[pixOffset++] = clip[0x3FF & m + i4 >> 12];
          blk[o2] = n + i3 >> 12;
          pixel[pixOffset++] = clip[0x3FF & n + i3 >> 12];
          blk[o3] = i1 - i2 >> 12;
          pixel[pixOffset++] = clip[0x3FF & i1 - i2 >> 12];
          blk[o4] = i1 + i2 >> 12;
          pixel[pixOffset++] = clip[0x3FF & i1 + i2 >> 12];
          blk[o5] = n - i3 >> 12;
          pixel[pixOffset++] = clip[0x3FF & n - i3 >> 12];
          blk[o6] = m - i4 >> 12;
          pixel[pixOffset++] = clip[0x3FF & m - i4 >> 12];
          blk[o7] = k - i5 >> 12;
          pixel[pixOffset++] = clip[0x3FF & k - i5 >> 12];
        } else {
          blk[o0] = k + i5 >> 12;
          pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + (k + i5 >> 12)];
          blk[o1] = m + i4 >> 12;
          pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + (m + i4 >> 12)];
          blk[o2] = n + i3 >> 12;
          pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + (n + i3 >> 12)];
          blk[o3] = i1 - i2 >> 12;
          pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + (i1 - i2 >> 12)];
          blk[o4] = i1 + i2 >> 12;
          pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + (i1 + i2 >> 12)];
          blk[o5] = n - i3 >> 12;
          pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + (n - i3 >> 12)];
          blk[o6] = m - i4 >> 12;
          pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + (m - i4 >> 12)];
          blk[o7] = k - i5 >> 12;
          pixel[pixOffset] = clip[0x3FF & pixel[pixOffset++] + (k - i5 >> 12)];
        } 
        pixOffset += width - 8;
      } 
    } 
  }
  
  public void finalize() {
    this.CurrentFrame = null;
    this.PreviousFrame = null;
    this.xPrevFrame = null;
    this.MotVectCurrGOB = null;
    this.MotVectPrevGOB = null;
    this.MBtypeCurrGOB = null;
    this.MBtypePrevGOB = null;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\video\h263\H263Decoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */