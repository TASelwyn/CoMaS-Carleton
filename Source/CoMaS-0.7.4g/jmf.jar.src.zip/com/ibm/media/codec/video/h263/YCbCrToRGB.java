package com.ibm.media.codec.video.h263;

public class YCbCrToRGB {
  public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997, 1998.";
  
  private static final int[] E02xCr_Table = new int[256];
  
  private static final int[] E11xCb_Table = new int[256];
  
  private static final int[] E12xCr_Table = new int[256];
  
  private static final int[] E21xCb_Table = new int[256];
  
  private static final int[] Ex0xY_Table = new int[256];
  
  private static final int[] clipR = new int[1024];
  
  private static final int[] clipG = new int[1024];
  
  private static final int[] clipB = new int[1024];
  
  static {
    for (int i = 0; i < 256; i++) {
      E02xCr_Table[i] = (int)(1.596D * (i - 128));
      E11xCb_Table[i] = (int)(-0.392D * (i - 128));
      E12xCr_Table[i] = (int)(-0.813D * (i - 128));
      E21xCb_Table[i] = (int)(2.017D * (i - 128));
      Ex0xY_Table[i] = (int)(1.164D * (i - 16));
    } 
    for (int j = 0; j < 1024; j++) {
      int clip = (j < 256) ? j : ((j < 512) ? 255 : 0);
      clipB[j] = clip << 16;
      clipG[j] = clip << 8;
      clipR[j] = clip;
    } 
  }
  
  public static void convert(int[] Y, int[] Cb, int[] Cr, int[] pixData, int srcWidth, int srcHeight, int dstWidth, int dstHeight, int alpha, int colorDepth) {
    int srcDstOffset = srcWidth - dstWidth;
    if (srcDstOffset < 0)
      return; 
    int shiftedAlpha = alpha << 24;
    int dstIndex00 = 0, dstIndex10 = dstWidth;
    int yIndex00 = 0, yIndex10 = srcWidth;
    int cbIndex = 0, crIndex = 0;
    for (int i = 0; i < dstHeight; i += 2) {
      for (int j = 0; j < dstWidth; j += 2) {
        byte y00 = (byte)Y[yIndex00++];
        byte y01 = (byte)Y[yIndex00++];
        byte y10 = (byte)Y[yIndex10++];
        byte y11 = (byte)Y[yIndex10++];
        int Yval = Ex0xY_Table[0xFF & y00];
        int Cb_nCrCb_Idx = 0xFF & (byte)Cb[cbIndex++];
        int Cr_nCrCb_Idx = 0xFF & (byte)Cr[crIndex++];
        int partRed, red = Yval + (partRed = E02xCr_Table[Cr_nCrCb_Idx]);
        int partGreen, green = Yval + (partGreen = E11xCb_Table[Cb_nCrCb_Idx] + E12xCr_Table[Cr_nCrCb_Idx]);
        int partBlue, blue = Yval + (partBlue = E21xCb_Table[Cb_nCrCb_Idx]);
        int tempRGB = shiftedAlpha | clipR[red & 0x3FF] | clipG[green & 0x3FF] | clipB[blue & 0x3FF];
        pixData[dstIndex00++] = (y00 != y01) ? (shiftedAlpha | clipR[(Yval = Ex0xY_Table[y01 & 0xFF]) + partRed & 0x3FF] | clipG[Yval + partGreen & 0x3FF] | clipB[Yval + partBlue & 0x3FF]) : tempRGB;
        pixData[dstIndex10++] = (y00 != y10) ? (shiftedAlpha | clipR[(Yval = Ex0xY_Table[y10 & 0xFF]) + partRed & 0x3FF] | clipG[Yval + partGreen & 0x3FF] | clipB[Yval + partBlue & 0x3FF]) : tempRGB;
        pixData[dstIndex10++] = (y00 != y11) ? (shiftedAlpha | clipR[(Yval = Ex0xY_Table[y11 & 0xFF]) + partRed & 0x3FF] | clipG[Yval + partGreen & 0x3FF] | clipB[Yval + partBlue & 0x3FF]) : tempRGB;
      } 
      yIndex00 = yIndex10 + srcDstOffset;
      yIndex10 += srcWidth + srcDstOffset;
      dstIndex00 = dstIndex10;
      dstIndex10 += dstWidth;
      cbIndex += srcDstOffset / 2;
      crIndex += srcDstOffset / 2;
    } 
  }
}
