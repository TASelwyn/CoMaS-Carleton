package com.ibm.media.codec.video.h263;

import com.ibm.media.codec.video.VideoCodec;
import com.sun.media.BasicPlugIn;
import com.sun.media.JMFSecurityManager;
import java.awt.Dimension;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.ResourceUnavailableException;
import javax.media.format.RGBFormat;
import javax.media.format.VideoFormat;

public class JavaDecoder extends VideoCodec {
  private static final int rMask = 255;
  
  private static final int gMask = 65280;
  
  private static final int bMask = 16711680;
  
  private static final boolean DEBUG = false;
  
  private H263Decoder javaDecoder;
  
  private FrameBuffer outputFrame;
  
  static Class class$(String x0) {
    try {
      return Class.forName(x0);
    } catch (ClassNotFoundException x1) {
      throw new NoClassDefFoundError(x1.getMessage());
    } 
  }
  
  public static final int[] widths = new int[] { 0, 128, 176, 352, 704, 1408, 0, 0 };
  
  public static final int[] heights = new int[] { 0, 96, 144, 288, 576, 1152, 0, 0 };
  
  private int videoWidth = 176;
  
  private int videoHeight = 144;
  
  private boolean FormatSizeInitFlag = false;
  
  private int payloadLength = 4;
  
  static boolean nativeAvail = false;
  
  static Class array$I;
  
  static {
    if (BasicPlugIn.plugInExists("com.sun.media.codec.video.vh263.NativeDecoder", 2))
      try {
        JMFSecurityManager.loadLibrary("jmutil");
        JMFSecurityManager.loadLibrary("jmvh263");
        nativeAvail = true;
      } catch (Throwable t) {} 
  }
  
  public JavaDecoder() {
    this.supportedInputFormats = new VideoFormat[] { new VideoFormat("h263"), new VideoFormat("h263/rtp") };
    this.defaultOutputFormats = new VideoFormat[] { (VideoFormat)new RGBFormat() };
    this.PLUGIN_NAME = "H.263 Decoder";
  }
  
  protected Format[] getMatchingOutputFormats(Format in) {
    VideoFormat ivf = (VideoFormat)in;
    Dimension inSize = ivf.getSize();
    int maxDataLength = ivf.getMaxDataLength();
    if (ivf.getEncoding().equals("h263/rtp")) {
      this.supportedOutputFormats = new VideoFormat[] { (VideoFormat)new RGBFormat(new Dimension(this.videoWidth, this.videoHeight), this.videoWidth * this.videoHeight, (array$I == null) ? (array$I = class$("[I")) : array$I, ivf.getFrameRate(), 32, 255, 65280, 16711680, 1, this.videoWidth, 0, -1) };
    } else {
      this.supportedOutputFormats = new VideoFormat[] { (VideoFormat)new RGBFormat(new Dimension(inSize), inSize.width * inSize.height, (array$I == null) ? (array$I = class$("[I")) : array$I, ivf.getFrameRate(), 32, 255, 65280, 16711680, 1, inSize.width, 0, -1) };
    } 
    return (Format[])this.supportedOutputFormats;
  }
  
  public Format setInputFormat(Format format) {
    if (nativeAvail)
      return null; 
    if (super.setInputFormat(format) != null) {
      reset();
      return format;
    } 
    return null;
  }
  
  public void open() throws ResourceUnavailableException {
    initDecoder();
  }
  
  public void close() {
    this.javaDecoder = null;
  }
  
  public void reset() {
    initDecoder();
  }
  
  protected void videoResized() {
    initDecoder();
  }
  
  protected void initDecoder() {
    this.javaDecoder = new H263Decoder(true);
  }
  
  public int process(Buffer inputBuffer, Buffer outputBuffer) {
    boolean rtpData = false;
    if (!checkInputBuffer(inputBuffer))
      return 1; 
    if (isEOM(inputBuffer)) {
      propagateEOM(outputBuffer);
      return 0;
    } 
    VideoFormat ivf = (VideoFormat)inputBuffer.getFormat();
    int inLength = inputBuffer.getLength();
    int inMaxLength = ivf.getMaxDataLength();
    int outMaxLength = this.outputFormat.getMaxDataLength();
    int inputOffset = inputBuffer.getOffset();
    byte[] inData = (byte[])inputBuffer.getData();
    if (ivf.getEncoding().equals("h263/rtp")) {
      rtpData = true;
      this.payloadLength = getPayloadHeaderLength(inData, inputOffset);
      if (inData[inputOffset + this.payloadLength] == 0 && inData[inputOffset + this.payloadLength + 1] == 0 && (inData[inputOffset + this.payloadLength + 2] & 0xFC) == 128) {
        int s = inData[inputOffset + this.payloadLength + 4] >> 2 & 0x7;
        if (this.videoWidth != widths[s] || this.videoHeight != heights[s]) {
          this.videoWidth = widths[s];
          this.videoHeight = heights[s];
          this.outputFormat = (VideoFormat)new RGBFormat(new Dimension(this.videoWidth, this.videoHeight), this.videoWidth * this.videoHeight, (array$I == null) ? (array$I = class$("[I")) : array$I, ivf.getFrameRate(), 32, 255, 65280, 16711680, 1, this.videoWidth, 0, -1);
          outMaxLength = this.videoWidth * this.videoHeight;
          if (this.FormatSizeInitFlag)
            videoResized(); 
        } 
        this.FormatSizeInitFlag = true;
      } 
      if (false == this.FormatSizeInitFlag)
        return 1; 
    } 
    int[] outData = validateIntArraySize(outputBuffer, outMaxLength);
    if (inLength + 8 + inputOffset > inData.length) {
      int newLength = (inLength > inMaxLength) ? inLength : inMaxLength;
      byte[] tempArray = new byte[inputOffset + newLength + 8];
      System.arraycopy(inData, 0, tempArray, 0, inLength + inputOffset);
      inData = tempArray;
      inputBuffer.setData(tempArray);
    } 
    inData[inputOffset + inLength] = 0;
    inData[inputOffset + inLength + 1] = 0;
    inData[inputOffset + inLength + 2] = -4;
    inLength += 3;
    inputBuffer.setLength(inLength);
    if (rtpData)
      inLength -= this.payloadLength; 
    boolean ret = decodeData(inputBuffer, inLength, outputBuffer, rtpData);
    if (ret) {
      updateOutput(outputBuffer, (Format)this.outputFormat, outMaxLength, 0);
      return 0;
    } 
    return 4;
  }
  
  boolean decodeData(Buffer inputBuffer, int inputLength, Buffer outputBuffer, boolean rtpData) {
    int i, outData[] = (int[])outputBuffer.getData();
    byte[] inputData = (byte[])inputBuffer.getData();
    if (inputLength <= 0)
      return false; 
    this.javaDecoder.initBitstream();
    int inputOffset = inputBuffer.getOffset();
    if (rtpData) {
      i = this.javaDecoder.DecodeRtpPacket(inputData, inputOffset + this.payloadLength, inputLength, inputData, inputOffset, inputBuffer.getTimeStamp());
      if (i == 3)
        return false; 
    } else {
      i = this.javaDecoder.DecodePicture(inputData, inputOffset, true);
    } 
    if (i == 2)
      throw new RuntimeException("Currently this picture format is not supported!"); 
    if (i == 1) {
      int outWidth = (this.outputFormat.getSize()).width;
      int outHeight = (this.outputFormat.getSize()).height;
      this.outputFrame = this.javaDecoder.CurrentFrame;
      YCbCrToRGB.convert(this.outputFrame.Y, this.outputFrame.Cb, this.outputFrame.Cr, outData, this.outputFrame.width, this.outputFrame.height, outWidth, outHeight, 255, 4);
      return true;
    } 
    return false;
  }
  
  public static int getPayloadHeaderLength(byte[] input, int offset) {
    int l = 0;
    byte b = input[offset];
    if ((b & 0x80) != 0) {
      if ((b & 0x40) != 0) {
        l = 12;
      } else {
        l = 8;
      } 
    } else {
      l = 4;
    } 
    return l;
  }
  
  public boolean checkFormat(Format format) {
    if (format.getEncoding().equals("h263/rtp"))
      return true; 
    return super.checkFormat(format);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\video\h263\JavaDecoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */