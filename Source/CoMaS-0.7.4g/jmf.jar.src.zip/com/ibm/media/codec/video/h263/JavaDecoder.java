/*     */ package com.ibm.media.codec.video.h263;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import java.awt.Dimension;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.RGBFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ public class JavaDecoder extends VideoCodec {
/*     */   static Class class$(String x0) {
/*     */     
/*  12 */     try { return Class.forName(x0); } catch (ClassNotFoundException x1) { throw new NoClassDefFoundError(x1.getMessage()); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int rMask = 255;
/*     */ 
/*     */   
/*     */   private static final int gMask = 65280;
/*     */ 
/*     */   
/*     */   private static final int bMask = 16711680;
/*     */ 
/*     */   
/*     */   private static final boolean DEBUG = false;
/*     */ 
/*     */   
/*     */   private H263Decoder javaDecoder;
/*     */ 
/*     */   
/*     */   private FrameBuffer outputFrame;
/*     */ 
/*     */   
/*  37 */   public static final int[] widths = new int[] { 0, 128, 176, 352, 704, 1408, 0, 0 };
/*  38 */   public static final int[] heights = new int[] { 0, 96, 144, 288, 576, 1152, 0, 0 };
/*  39 */   private int videoWidth = 176;
/*  40 */   private int videoHeight = 144;
/*     */   private boolean FormatSizeInitFlag = false;
/*  42 */   private int payloadLength = 4;
/*     */   
/*     */   static boolean nativeAvail = false;
/*     */   static Class array$I;
/*     */   
/*     */   static {
/*  48 */     if (BasicPlugIn.plugInExists("com.sun.media.codec.video.vh263.NativeDecoder", 2)) {
/*     */       try {
/*  50 */         JMFSecurityManager.loadLibrary("jmutil");
/*  51 */         JMFSecurityManager.loadLibrary("jmvh263");
/*  52 */         nativeAvail = true;
/*  53 */       } catch (Throwable t) {}
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaDecoder() {
/*  59 */     this.supportedInputFormats = new VideoFormat[] { new VideoFormat("h263"), new VideoFormat("h263/rtp") };
/*  60 */     this.defaultOutputFormats = new VideoFormat[] { (VideoFormat)new RGBFormat() };
/*  61 */     this.PLUGIN_NAME = "H.263 Decoder";
/*     */   }
/*     */ 
/*     */   
/*     */   protected Format[] getMatchingOutputFormats(Format in) {
/*  66 */     VideoFormat ivf = (VideoFormat)in;
/*  67 */     Dimension inSize = ivf.getSize();
/*  68 */     int maxDataLength = ivf.getMaxDataLength();
/*     */     
/*  70 */     if (ivf.getEncoding().equals("h263/rtp")) {
/*  71 */       this.supportedOutputFormats = new VideoFormat[] { (VideoFormat)new RGBFormat(new Dimension(this.videoWidth, this.videoHeight), this.videoWidth * this.videoHeight, (array$I == null) ? (array$I = class$("[I")) : array$I, ivf.getFrameRate(), 32, 255, 65280, 16711680, 1, this.videoWidth, 0, -1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  92 */       this.supportedOutputFormats = new VideoFormat[] { (VideoFormat)new RGBFormat(new Dimension(inSize), inSize.width * inSize.height, (array$I == null) ? (array$I = class$("[I")) : array$I, ivf.getFrameRate(), 32, 255, 65280, 16711680, 1, inSize.width, 0, -1) };
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     return (Format[])this.supportedOutputFormats;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format setInputFormat(Format format) {
/* 113 */     if (nativeAvail)
/* 114 */       return null; 
/* 115 */     if (super.setInputFormat(format) != null) {
/* 116 */       reset();
/* 117 */       return format;
/*     */     } 
/* 119 */     return null;
/*     */   }
/*     */   
/*     */   public void open() throws ResourceUnavailableException {
/* 123 */     initDecoder();
/*     */   }
/*     */   
/*     */   public void close() {
/* 127 */     this.javaDecoder = null;
/*     */   }
/*     */   
/*     */   public void reset() {
/* 131 */     initDecoder();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void videoResized() {
/* 136 */     initDecoder();
/*     */   }
/*     */   
/*     */   protected void initDecoder() {
/* 140 */     this.javaDecoder = new H263Decoder(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int process(Buffer inputBuffer, Buffer outputBuffer) {
/* 147 */     boolean rtpData = false;
/*     */     
/* 149 */     if (!checkInputBuffer(inputBuffer)) {
/* 150 */       return 1;
/*     */     }
/*     */     
/* 153 */     if (isEOM(inputBuffer)) {
/* 154 */       propagateEOM(outputBuffer);
/* 155 */       return 0;
/*     */     } 
/*     */     
/* 158 */     VideoFormat ivf = (VideoFormat)inputBuffer.getFormat();
/* 159 */     int inLength = inputBuffer.getLength();
/* 160 */     int inMaxLength = ivf.getMaxDataLength();
/* 161 */     int outMaxLength = this.outputFormat.getMaxDataLength();
/* 162 */     int inputOffset = inputBuffer.getOffset();
/*     */     
/* 164 */     byte[] inData = (byte[])inputBuffer.getData();
/*     */     
/* 166 */     if (ivf.getEncoding().equals("h263/rtp")) {
/* 167 */       rtpData = true;
/* 168 */       this.payloadLength = getPayloadHeaderLength(inData, inputOffset);
/*     */       
/* 170 */       if (inData[inputOffset + this.payloadLength] == 0 && inData[inputOffset + this.payloadLength + 1] == 0 && (inData[inputOffset + this.payloadLength + 2] & 0xFC) == 128) {
/*     */         
/* 172 */         int s = inData[inputOffset + this.payloadLength + 4] >> 2 & 0x7;
/*     */ 
/*     */         
/* 175 */         if (this.videoWidth != widths[s] || this.videoHeight != heights[s]) {
/*     */           
/* 177 */           this.videoWidth = widths[s];
/* 178 */           this.videoHeight = heights[s];
/*     */ 
/*     */           
/* 181 */           this.outputFormat = (VideoFormat)new RGBFormat(new Dimension(this.videoWidth, this.videoHeight), this.videoWidth * this.videoHeight, (array$I == null) ? (array$I = class$("[I")) : array$I, ivf.getFrameRate(), 32, 255, 65280, 16711680, 1, this.videoWidth, 0, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 192 */           outMaxLength = this.videoWidth * this.videoHeight;
/*     */           
/* 194 */           if (this.FormatSizeInitFlag) {
/* 195 */             videoResized();
/*     */           }
/*     */         } 
/* 198 */         this.FormatSizeInitFlag = true;
/*     */       } 
/*     */ 
/*     */       
/* 202 */       if (false == this.FormatSizeInitFlag) {
/* 203 */         return 1;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 209 */     int[] outData = validateIntArraySize(outputBuffer, outMaxLength);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 217 */     if (inLength + 8 + inputOffset > inData.length) {
/*     */ 
/*     */       
/* 220 */       int newLength = (inLength > inMaxLength) ? inLength : inMaxLength;
/*     */       
/* 222 */       byte[] tempArray = new byte[inputOffset + newLength + 8];
/* 223 */       System.arraycopy(inData, 0, tempArray, 0, inLength + inputOffset);
/* 224 */       inData = tempArray;
/* 225 */       inputBuffer.setData(tempArray);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 233 */     inData[inputOffset + inLength] = 0;
/* 234 */     inData[inputOffset + inLength + 1] = 0;
/* 235 */     inData[inputOffset + inLength + 2] = -4;
/* 236 */     inLength += 3;
/* 237 */     inputBuffer.setLength(inLength);
/*     */     
/* 239 */     if (rtpData) {
/* 240 */       inLength -= this.payloadLength;
/*     */     }
/* 242 */     boolean ret = decodeData(inputBuffer, inLength, outputBuffer, rtpData);
/* 243 */     if (ret) {
/* 244 */       updateOutput(outputBuffer, (Format)this.outputFormat, outMaxLength, 0);
/* 245 */       return 0;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 250 */     return 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean decodeData(Buffer inputBuffer, int inputLength, Buffer outputBuffer, boolean rtpData) {
/* 261 */     int i, outData[] = (int[])outputBuffer.getData();
/* 262 */     byte[] inputData = (byte[])inputBuffer.getData();
/*     */ 
/*     */     
/* 265 */     if (inputLength <= 0) {
/* 266 */       return false;
/*     */     }
/*     */     
/* 269 */     this.javaDecoder.initBitstream();
/* 270 */     int inputOffset = inputBuffer.getOffset();
/* 271 */     if (rtpData) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 278 */       i = this.javaDecoder.DecodeRtpPacket(inputData, inputOffset + this.payloadLength, inputLength, inputData, inputOffset, inputBuffer.getTimeStamp());
/* 279 */       if (i == 3)
/*     */       {
/*     */         
/* 282 */         return false;
/*     */       }
/*     */     } else {
/*     */       
/* 286 */       i = this.javaDecoder.DecodePicture(inputData, inputOffset, true);
/*     */     } 
/*     */ 
/*     */     
/* 290 */     if (i == 2)
/*     */     {
/*     */       
/* 293 */       throw new RuntimeException("Currently this picture format is not supported!");
/*     */     }
/*     */     
/* 296 */     if (i == 1) {
/* 297 */       int outWidth = (this.outputFormat.getSize()).width;
/* 298 */       int outHeight = (this.outputFormat.getSize()).height;
/* 299 */       this.outputFrame = this.javaDecoder.CurrentFrame;
/* 300 */       YCbCrToRGB.convert(this.outputFrame.Y, this.outputFrame.Cb, this.outputFrame.Cr, outData, this.outputFrame.width, this.outputFrame.height, outWidth, outHeight, 255, 4);
/* 301 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 306 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getPayloadHeaderLength(byte[] input, int offset) {
/* 315 */     int l = 0;
/* 316 */     byte b = input[offset];
/*     */     
/* 318 */     if ((b & 0x80) != 0)
/* 319 */     { if ((b & 0x40) != 0) {
/* 320 */         l = 12;
/*     */       } else {
/* 322 */         l = 8;
/*     */       }  }
/* 324 */     else { l = 4; }
/*     */ 
/*     */     
/* 327 */     return l;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkFormat(Format format) {
/* 332 */     if (format.getEncoding().equals("h263/rtp")) {
/* 333 */       return true;
/*     */     }
/*     */     
/* 336 */     return super.checkFormat(format);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\ibm\media\codec\video\h263\JavaDecoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */