package com.ibm.media.codec.video.h263;

final class H263RtpPayloadParser {
  private static final boolean DEBUG = false;
  
  static int getMode(byte[] payload, int offset) {
    byte b;
    if ((payload[offset] & 0x80) == 0) {
      b = 0;
    } else if ((payload[offset] & 0x40) == 0) {
      b = 1;
    } else {
      b = 2;
    } 
    return b;
  }
  
  static int getStartBit(byte[] payload, int offset) {
    int startBit = (payload[offset] & 0x38) >> 3;
    return startBit;
  }
  
  static int getEndBit(byte[] payload, int offset) {
    int endBit = payload[offset] & 0x7;
    return endBit;
  }
  
  static int getSRC(byte[] payload, int offset) {
    return (payload[offset + 1] & 0xE0) >> 5;
  }
  
  static int getTemporalReference(byte[] payload, int offset) {
    int tr = payload[offset + 3] & 0xFF;
    return tr;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\video\h263\H263RtpPayloadParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */