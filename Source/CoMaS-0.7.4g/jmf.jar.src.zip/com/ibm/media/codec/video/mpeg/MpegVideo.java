package com.ibm.media.codec.video.mpeg;

import com.sun.media.BasicCodec;
import com.sun.media.BasicPlugIn;
import com.sun.media.JMFSecurityManager;
import java.awt.Component;
import java.awt.Dimension;
import javax.media.Buffer;
import javax.media.Control;
import javax.media.Format;
import javax.media.ResourceUnavailableException;
import javax.media.control.FrameProcessingControl;
import javax.media.control.QualityControl;
import javax.media.format.VideoFormat;
import javax.media.format.YUVFormat;

public class MpegVideo extends BasicCodec {
  public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1998, 1999.";
  
  static final int VERSION_BUF_LEN = 70;
  
  static final int MPEG_INTERNAL_BUF_SIZE = 65536;
  
  static final int IN_STREAM_BUF_LEN = 102400;
  
  static final int OUT_FRAME_BUF_LEN = 270000;
  
  static final int NO_PICTURE = 0;
  
  static final int I_PICTURE = 1;
  
  static final int P_PICTURE = 2;
  
  static final int B_PICTURE = 3;
  
  static final int D_PICTURE = 4;
  
  static final int MPEG_NOERROR = 0;
  
  static final int MPEG_ERROR = -1;
  
  static final int MPEG_PARAM_ERROR = -2;
  
  static final int MPEG_BUF_ERROR = -3;
  
  static final int MPEG_ALLOC_ERROR = -4;
  
  static final int MPEG_EOS = -5;
  
  private Object methodsSync = new Object();
  
  protected VideoFormat[] supportedInFormats = null;
  
  protected VideoFormat[] supportedOutFormats = null;
  
  protected VideoFormat inputFormat = null;
  
  protected VideoFormat outputFormat = null;
  
  private boolean corruptedFlag = false;
  
  private boolean firstTimeFlag = true;
  
  private boolean inputEOMFlag = false;
  
  private boolean processEOMFlag = false;
  
  private boolean resetFlag = true;
  
  private long accumulatedTimeNs = 0L;
  
  private double deltaPictureTimeNS = 0.0D;
  
  private double dAccumulatedTime = 0.0D;
  
  private long[] pdata = new long[1];
  
  private byte[] versionBuf = new byte[70];
  
  private int[] inBytesReq = new int[1];
  
  private int frameNumber = -1;
  
  private byte[] inBufByte = new byte[102400];
  
  private byte[] outBufByte = null;
  
  private int inDataOffset = 0;
  
  private int outBufOffset = 0;
  
  private int numDataBytes = 0;
  
  private int numFramesBehind = 0;
  
  private int dropCount = 0;
  
  private int[] imgWidth = new int[1];
  
  private int[] imgHeight = new int[1];
  
  private int[] imgType = new int[1];
  
  private int[] inBytesRead = new int[1];
  
  private int[] outBufWrote = new int[1];
  
  private static boolean available;
  
  private Control[] controls;
  
  private DC dc;
  
  static {
    try {
      JMFSecurityManager.loadLibrary("jmutil");
      JMFSecurityManager.loadLibrary("jmmpegv");
      available = true;
    } catch (Exception e) {
      available = false;
    } 
  }
  
  public String getName() {
    return "MPEG-1 Video Decoder";
  }
  
  public Format[] getSupportedInputFormats() {
    return (Format[])this.supportedInFormats;
  }
  
  public Format[] getSupportedOutputFormats(Format format) {
    if (format == null)
      return (Format[])this.supportedOutFormats; 
    if (format instanceof VideoFormat && BasicPlugIn.matches(format, (Format[])this.supportedInFormats) != null) {
      VideoFormat inf = (VideoFormat)format;
      Dimension size = inf.getSize();
      if (size == null || size.width == 0 || size.height == 0)
        size = new Dimension(320, 240); 
      int area = size.width * size.height;
      YUVFormat outf = new YUVFormat(size, area + (area >> 1), Format.byteArray, inf.getFrameRate(), 2, size.width, size.width >> 1, 0, area, area + (area >> 2));
      Format[] tempFormats = new Format[1];
      tempFormats[0] = (Format)outf;
      return tempFormats;
    } 
    return new Format[0];
  }
  
  public Format setInputFormat(Format in) {
    if (!(in instanceof VideoFormat) || BasicPlugIn.matches(in, (Format[])this.supportedInFormats) == null)
      return null; 
    this.inputFormat = (VideoFormat)in;
    return in;
  }
  
  public Format setOutputFormat(Format out) {
    if (out != null && out instanceof YUVFormat && ((YUVFormat)out).getYuvType() == 2) {
      this.outputFormat = (VideoFormat)out;
      return out;
    } 
    return null;
  }
  
  public void open() throws ResourceUnavailableException {
    if (!available)
      throw new ResourceUnavailableException("Can't find shared library jmmpegv"); 
    synchronized (this.methodsSync) {
      if (videoInitialize(this.pdata, this.versionBuf, 0, 70) != 0)
        throw new ResourceUnavailableException("MPEG video decoder initialization failed"); 
      available = false;
      this.inBytesReq[0] = 65536;
    } 
    float ftmp = this.inputFormat.getFrameRate();
    if (ftmp > 0.0F) {
      this.deltaPictureTimeNS = 1.0E9D / ftmp;
    } else {
      this.deltaPictureTimeNS = 0.0D;
    } 
  }
  
  public void reset() {
    synchronized (this.methodsSync) {
      this.corruptedFlag = false;
      this.inputEOMFlag = false;
      this.processEOMFlag = false;
      this.inBytesReq[0] = 65536;
      this.frameNumber = -1;
      this.inDataOffset = 0;
      this.outBufOffset = 0;
      this.numDataBytes = 0;
      this.numFramesBehind = 0;
      this.dropCount = 0;
      int rc = videoSeek(this.pdata[0]);
      if (rc != 0)
        this.corruptedFlag = true; 
      this.resetFlag = true;
    } 
  }
  
  public void close() {
    synchronized (this.methodsSync) {
      videoTerminate(this.pdata[0]);
      this.corruptedFlag = false;
      this.firstTimeFlag = true;
      this.inputEOMFlag = false;
      this.processEOMFlag = false;
      this.pdata = new long[1];
      this.inBytesReq[0] = 65536;
      this.frameNumber = -1;
      this.inDataOffset = 0;
      this.outBufOffset = 0;
      this.numDataBytes = 0;
      this.numFramesBehind = 0;
      this.dropCount = 0;
      available = true;
    } 
  }
  
  private boolean doInit(Buffer inbuffer, Buffer outbuffer) {
    int[] imgWidth = new int[1];
    int[] imgHeight = new int[1];
    Object data = inbuffer.getData();
    int bufLen = inbuffer.getLength();
    int offset = inbuffer.getOffset();
    if (bufLen < 512)
      return false; 
    int rc = initImageParam(this.pdata[0], (byte[])data, offset, bufLen, imgWidth, imgHeight);
    if (rc != 0)
      return false; 
    int frameWriteLen = (int)((imgWidth[0] * imgHeight[0]) * 1.5D);
    this.outBufByte = new byte[frameWriteLen];
    Dimension size = new Dimension(imgWidth[0], imgHeight[0]);
    int area = size.width * size.height;
    this.outputFormat = (VideoFormat)new YUVFormat(size, area + (area >> 1), Format.byteArray, this.inputFormat.getFrameRate(), 2, size.width, size.width >> 1, 0, area, area + (area >> 2));
    outbuffer.setFormat((Format)this.outputFormat);
    return true;
  }
  
  public int process(Buffer inbuffer, Buffer outbuffer) {
    this.imgWidth[0] = 0;
    this.imgHeight[0] = 0;
    this.imgType[0] = 0;
    this.inBytesRead[0] = 0;
    this.outBufWrote[0] = 0;
    int returnResult = 0;
    synchronized (this.methodsSync) {
      if (!checkInputBuffer(inbuffer))
        return 1; 
      if (this.processEOMFlag) {
        propagateEOM(outbuffer);
        return 0;
      } 
      if (this.corruptedFlag)
        return 1; 
      if (isEOM(inbuffer))
        this.inputEOMFlag = true; 
      if (this.firstTimeFlag) {
        if (!doInit(inbuffer, outbuffer))
          return 1; 
        this.firstTimeFlag = false;
      } 
      if (this.numDataBytes < this.inBytesReq[0] && !this.inputEOMFlag) {
        byte[] data = (byte[])inbuffer.getData();
        int bufLen = inbuffer.getLength();
        int offset = inbuffer.getOffset();
        int num2read = 102400 - this.numDataBytes - 1;
        if (this.numDataBytes > 0 && this.inDataOffset > 0)
          System.arraycopy(this.inBufByte, this.inDataOffset, this.inBufByte, 0, this.numDataBytes); 
        this.inDataOffset = 0;
        if (num2read > bufLen)
          num2read = bufLen; 
        if (num2read > 0)
          System.arraycopy(data, offset, this.inBufByte, this.numDataBytes, num2read); 
        if (num2read < bufLen)
          returnResult |= 0x2; 
        inbuffer.setOffset(offset + num2read);
        inbuffer.setLength(bufLen - num2read);
        if (bufLen == num2read)
          inbuffer.setOffset(0); 
        if (num2read > 0)
          this.numDataBytes += num2read; 
        if (this.numDataBytes < this.inBytesReq[0])
          return returnResult | 0x0 | 0x4; 
      } else if (this.inputEOMFlag) {
        if (this.processEOMFlag) {
          propagateEOM(outbuffer);
          return 0;
        } 
      } else {
        returnResult |= 0x2;
      } 
      this.frameNumber++;
      if ((inbuffer.getFlags() & 0x1000) == 0) {
        if (this.resetFlag) {
          this.accumulatedTimeNs = inbuffer.getTimeStamp();
          this.dAccumulatedTime = 1.0D * this.accumulatedTimeNs;
          this.resetFlag = false;
        } 
        outbuffer.setTimeStamp(this.accumulatedTimeNs);
        this.dAccumulatedTime += this.deltaPictureTimeNS;
        this.accumulatedTimeNs = (long)this.dAccumulatedTime;
      } else {
        outbuffer.setTimeStamp(inbuffer.getTimeStamp());
      } 
      outbuffer.setSequenceNumber(this.frameNumber);
      outbuffer.setFlags(outbuffer.getFlags() | 0x20);
      Object outData = validateData(outbuffer, 0, true);
      long outBytes = getNativeData(outData);
      int rc = videoDecode(this.pdata[0], this.inBufByte, this.inDataOffset, this.numDataBytes, this.numFramesBehind, outData, outBytes, 0, this.outputFormat.getMaxDataLength(), this.imgWidth, this.imgHeight, this.imgType, this.inBytesRead, this.outBufWrote, this.inBytesReq);
      if (rc != 0) {
        if (rc == -5) {
          propagateEOM(outbuffer);
          this.processEOMFlag = true;
          return 0;
        } 
        System.out.println("MPEG VIDEO: decode process error  rc:" + rc);
        System.out.flush();
        this.corruptedFlag = true;
        return 1;
      } 
      updateOutput(outbuffer, (Format)this.outputFormat, this.outBufWrote[0], 0);
      this.numDataBytes -= this.inBytesRead[0];
      this.inDataOffset += this.inBytesRead[0];
      if (this.outBufWrote[0] == 0) {
        outbuffer.setDiscard(true);
        returnResult |= 0x4;
        if (this.imgType[0] != 0)
          this.dropCount++; 
      } 
      return returnResult | 0x0;
    } 
  }
  
  public MpegVideo() {
    this.controls = null;
    this.dc = null;
    if (available) {
      this.supportedInFormats = new VideoFormat[2];
      this.supportedInFormats[0] = new VideoFormat("mpeg");
      this.supportedInFormats[1] = new VideoFormat("MPGI");
      this.supportedOutFormats = new VideoFormat[1];
      this.supportedOutFormats[0] = (VideoFormat)new YUVFormat(2);
    } else {
      this.supportedInFormats = new VideoFormat[0];
    } 
  }
  
  public Object[] getControls() {
    if (this.dc == null) {
      this.dc = new DC(this);
      this.controls = new Control[1];
      this.controls[0] = (Control)this.dc;
    } 
    return (Object[])this.controls;
  }
  
  protected void propagateEOM(Buffer outBuffer) {
    super.propagateEOM(outBuffer);
    outBuffer.setTimeStamp(this.accumulatedTimeNs);
    this.dAccumulatedTime += this.deltaPictureTimeNS;
    this.accumulatedTimeNs = (long)this.dAccumulatedTime;
  }
  
  void setMpegFramesBehind(int num) {
    this.numFramesBehind = num;
  }
  
  private native int videoInitialize(long[] paramArrayOflong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
  
  private native int initImageParam(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2);
  
  private native int videoDecode(long paramLong1, byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3, Object paramObject, long paramLong2, int paramInt4, int paramInt5, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, int[] paramArrayOfint4, int[] paramArrayOfint5, int[] paramArrayOfint6);
  
  private native int videoTerminate(long paramLong);
  
  private native int videoReset(long paramLong);
  
  private native int videoSeek(long paramLong);
  
  class DC implements FrameProcessingControl, QualityControl {
    private final MpegVideo this$0;
    
    DC(MpegVideo this$0) {
      this.this$0 = this$0;
    }
    
    public int getFramesDropped() {
      return 0;
    }
    
    public Component getControlComponent() {
      return null;
    }
    
    public boolean setMinimalProcessing(boolean on) {
      this.this$0.setMpegFramesBehind(5);
      return true;
    }
    
    public void setFramesBehind(float framesBehind) {
      this.this$0.setMpegFramesBehind((int)framesBehind);
    }
    
    public float setQuality(float quality) {
      return 1.0F;
    }
    
    public float getQuality() {
      return 1.0F;
    }
    
    public float getPreferredQuality() {
      return 1.0F;
    }
    
    public boolean isTemporalSpatialTradeoffSupported() {
      return false;
    }
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\video\mpeg\MpegVideo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */