package com.ibm.media.codec.audio.g723;

class LINEDEF {
  private static final int SubFrames = 4;
  
  int Crc;
  
  int LspId;
  
  int[] Olp = new int[2];
  
  SFSDEF[] Sfs = new SFSDEF[] { new SFSDEF(), new SFSDEF(), new SFSDEF(), new SFSDEF() };
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\g723\LINEDEF.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */