/*     */ package com.ibm.media.codec.audio;
/*     */ 
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PCMToPCM
/*     */   extends AudioCodec
/*     */ {
/*  18 */   private Format lastInputFormat = null;
/*  19 */   private Format lastOutputFormat = null;
/*  20 */   private int bias = 0;
/*  21 */   private int signMask = 0;
/*  22 */   private int inputSampleSize = 8;
/*  23 */   private int outputSampleSize = 8;
/*  24 */   private int numberOfInputChannels = 1;
/*  25 */   private int numberOfOutputChannels = 1;
/*     */ 
/*     */   
/*     */   private boolean channels2To1 = false;
/*     */ 
/*     */   
/*     */   private boolean channels1To2 = false;
/*     */   
/*     */   private boolean channels2To2 = false;
/*     */   
/*     */   private int inputLsbOffset;
/*     */   
/*     */   private int inputMsbOffset;
/*     */   
/*     */   private int outputLsbOffset;
/*     */   
/*     */   private int outputMsbOffset;
/*     */ 
/*     */   
/*     */   public PCMToPCM() {
/*  45 */     this.supportedInputFormats = new AudioFormat[] { new AudioFormat("LINEAR", -1.0D, 16, 1, -1, -1), new AudioFormat("LINEAR", -1.0D, 16, 2, -1, -1), new AudioFormat("LINEAR", -1.0D, 8, 1, -1, -1), new AudioFormat("LINEAR", -1.0D, 8, 2, -1, -1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     this.defaultOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR") };
/*  81 */     this.PLUGIN_NAME = "PCM to PCM converter";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Format[] getMatchingOutputFormats(Format in) {
/*  87 */     AudioFormat af = (AudioFormat)in;
/*  88 */     int otherChnl = (af.getChannels() == 1) ? 2 : 1;
/*     */     
/*  90 */     this.supportedOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR", af.getSampleRate(), 16, af.getChannels(), 0, 1, 16 * af.getChannels(), af.getFrameRate(), af.getDataType()), new AudioFormat("LINEAR", af.getSampleRate(), 16, otherChnl, 0, 1, 16 * otherChnl, af.getFrameRate(), af.getDataType()), new AudioFormat("LINEAR", af.getSampleRate(), 16, af.getChannels(), 1, 1, 16 * af.getChannels(), af.getFrameRate(), af.getDataType()), new AudioFormat("LINEAR", af.getSampleRate(), 16, otherChnl, 1, 1, 16 * otherChnl, af.getFrameRate(), af.getDataType()), new AudioFormat("LINEAR", af.getSampleRate(), 16, af.getChannels(), 0, 0, 16 * af.getChannels(), af.getFrameRate(), af.getDataType()), new AudioFormat("LINEAR", af.getSampleRate(), 16, otherChnl, 0, 0, 16 * otherChnl, af.getFrameRate(), af.getDataType()), new AudioFormat("LINEAR", af.getSampleRate(), 16, af.getChannels(), 1, 0, 16 * af.getChannels(), af.getFrameRate(), af.getDataType()), new AudioFormat("LINEAR", af.getSampleRate(), 16, otherChnl, 1, 0, 16 * otherChnl, af.getFrameRate(), af.getDataType()), new AudioFormat("LINEAR", af.getSampleRate(), 8, af.getChannels(), -1, 1, 8 * af.getChannels(), af.getFrameRate(), af.getDataType()), new AudioFormat("LINEAR", af.getSampleRate(), 8, otherChnl, -1, 1, 8 * otherChnl, af.getFrameRate(), af.getDataType()), new AudioFormat("LINEAR", af.getSampleRate(), 8, af.getChannels(), -1, 0, 8 * af.getChannels(), af.getFrameRate(), af.getDataType()), new AudioFormat("LINEAR", af.getSampleRate(), 8, otherChnl, -1, 0, 8 * otherChnl, af.getFrameRate(), af.getDataType()) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 231 */     return (Format[])this.supportedOutputFormats;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int process(Buffer inputBuffer, Buffer outputBuffer) {
/* 240 */     if (!checkInputBuffer(inputBuffer)) {
/* 241 */       return 1;
/*     */     }
/*     */     
/* 244 */     if (isEOM(inputBuffer)) {
/* 245 */       propagateEOM(outputBuffer);
/* 246 */       return 0;
/*     */     } 
/*     */     
/* 249 */     if (this.lastInputFormat != this.inputFormat || this.lastOutputFormat != this.outputFormat) {
/* 250 */       initConverter(this.inputFormat, this.outputFormat);
/*     */     }
/*     */     
/* 253 */     int inpLength = inputBuffer.getLength();
/* 254 */     int outLength = calculateOutputSize(inputBuffer.getLength());
/*     */     
/* 256 */     byte[] inpData = (byte[])inputBuffer.getData();
/* 257 */     byte[] outData = validateByteArraySize(outputBuffer, outLength);
/*     */     
/* 259 */     convert(inpData, inputBuffer.getOffset(), inpLength, outData, outputBuffer.getOffset());
/*     */     
/* 261 */     updateOutput(outputBuffer, (Format)this.outputFormat, outLength, outputBuffer.getOffset());
/* 262 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int calculateOutputSize(int inputLength) {
/* 269 */     int outputLength = inputLength;
/*     */     
/* 271 */     if (this.inputSampleSize == 8 && this.outputSampleSize == 16) {
/* 272 */       outputLength *= 2;
/*     */     }
/*     */     
/* 275 */     if (this.inputSampleSize == 16 && this.outputSampleSize == 8) {
/* 276 */       outputLength /= 2;
/*     */     }
/*     */     
/* 279 */     if (this.numberOfInputChannels == 1 && this.numberOfOutputChannels == 2) {
/* 280 */       outputLength *= 2;
/*     */     }
/*     */     
/* 283 */     if (this.numberOfInputChannels == 2 && this.numberOfOutputChannels == 1) {
/* 284 */       outputLength /= 2;
/*     */     }
/*     */     
/* 287 */     return outputLength;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void initConverter(AudioFormat inFormat, AudioFormat outFormat) {
/* 293 */     this.lastInputFormat = (Format)inFormat;
/* 294 */     this.lastOutputFormat = (Format)outFormat;
/*     */ 
/*     */     
/* 297 */     this.numberOfInputChannels = inFormat.getChannels();
/* 298 */     this.numberOfOutputChannels = outFormat.getChannels();
/*     */     
/* 300 */     this.inputSampleSize = inFormat.getSampleSizeInBits();
/* 301 */     this.outputSampleSize = outFormat.getSampleSizeInBits();
/*     */     
/* 303 */     if (inFormat.getEndian() == 1 || 8 == this.inputSampleSize) {
/* 304 */       this.inputLsbOffset = 1;
/* 305 */       this.inputMsbOffset = 0;
/*     */     } else {
/*     */       
/* 308 */       this.inputLsbOffset = -1;
/* 309 */       this.inputMsbOffset = 1;
/*     */     } 
/*     */ 
/*     */     
/* 313 */     int outputEndianess = outFormat.getEndian();
/* 314 */     if (outputEndianess == -1) {
/* 315 */       outputEndianess = inFormat.getEndian();
/*     */     }
/*     */     
/* 318 */     if (outputEndianess == 1 || 8 == this.outputSampleSize) {
/* 319 */       this.outputLsbOffset = 1;
/* 320 */       this.outputMsbOffset = 0;
/*     */     } else {
/*     */       
/* 323 */       this.outputLsbOffset = -1;
/* 324 */       this.outputMsbOffset = 1;
/*     */     } 
/*     */ 
/*     */     
/* 328 */     if (inFormat.getSigned() == 1) {
/* 329 */       this.signMask = -1;
/*     */     } else {
/*     */       
/* 332 */       this.signMask = 65535;
/*     */     } 
/*     */     
/* 335 */     if (inFormat.getSigned() == outFormat.getSigned() || outFormat.getSigned() == -1) {
/* 336 */       this.bias = 0;
/*     */     } else {
/*     */       
/* 339 */       this.bias = 32768;
/*     */     } 
/*     */ 
/*     */     
/* 343 */     if (this.numberOfInputChannels == 2 && this.numberOfOutputChannels == 1) {
/* 344 */       this.channels2To1 = true;
/*     */     } else {
/*     */       
/* 347 */       this.channels2To1 = false;
/*     */     } 
/* 349 */     if (this.numberOfInputChannels == 1 && this.numberOfOutputChannels == 2) {
/* 350 */       this.channels1To2 = true;
/*     */     } else {
/*     */       
/* 353 */       this.channels1To2 = false;
/*     */     } 
/*     */     
/* 356 */     if (this.numberOfInputChannels == 2 && this.numberOfOutputChannels == 2) {
/* 357 */       this.channels2To2 = true;
/*     */     } else {
/*     */       
/* 360 */       this.channels2To2 = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void convert(byte[] input, int inputOffset, int inputLength, byte[] outData, int outputOffset) {
/* 366 */     int sample1 = 0;
/* 367 */     int sample2 = 0;
/*     */ 
/*     */     
/* 370 */     outputOffset += this.outputMsbOffset;
/*     */     
/* 372 */     for (int i = inputOffset + this.inputMsbOffset; i < inputLength + inputOffset; ) {
/*     */       
/* 374 */       if (8 == this.inputSampleSize) {
/* 375 */         sample1 = input[i++] << 8;
/*     */         
/* 377 */         if (this.numberOfInputChannels == 2) {
/* 378 */           sample2 = input[i++] << 8;
/*     */         }
/*     */       } else {
/*     */         
/* 382 */         sample1 = (input[i] << 8) + (0xFF & input[i + this.inputLsbOffset]);
/* 383 */         i += 2;
/*     */         
/* 385 */         if (this.numberOfInputChannels == 2) {
/* 386 */           sample2 = (input[i] << 8) + (0xFF & input[i + this.inputLsbOffset]);
/* 387 */           i += 2;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 392 */       if (this.channels2To1) {
/* 393 */         sample1 = (sample1 & this.signMask) + (sample2 & this.signMask) >> 1;
/*     */       }
/*     */ 
/*     */       
/* 397 */       sample1 = (short)(sample1 + this.bias);
/*     */       
/* 399 */       if (this.channels2To2) {
/* 400 */         sample2 = (short)(sample2 + this.bias);
/*     */       }
/*     */       
/* 403 */       if (this.channels1To2) {
/* 404 */         sample2 = sample1;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 410 */       if (8 == this.outputSampleSize) {
/* 411 */         outData[outputOffset++] = (byte)(sample1 >> 8);
/*     */         
/* 413 */         if (this.numberOfOutputChannels == 2) {
/* 414 */           outData[outputOffset++] = (byte)(sample2 >> 8);
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/* 419 */       outData[outputOffset + this.outputLsbOffset] = (byte)sample1;
/* 420 */       outData[outputOffset] = (byte)(sample1 >> 8);
/* 421 */       outputOffset += 2;
/* 422 */       if (this.numberOfOutputChannels == 2) {
/* 423 */         outData[outputOffset + this.outputLsbOffset] = (byte)sample2;
/* 424 */         outData[outputOffset] = (byte)(sample2 >> 8);
/* 425 */         outputOffset += 2;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\ibm\media\codec\audio\PCMToPCM.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */