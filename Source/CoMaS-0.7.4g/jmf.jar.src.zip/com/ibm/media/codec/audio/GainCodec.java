package com.ibm.media.codec.audio;

import com.sun.media.BasicCodec;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.format.AudioFormat;

public class GainCodec extends BasicCodec {
  private static String GainCodec = "GainCodec";
  
  public float gain = 2.0F;
  
  public void setGain(float newGain) {
    this.gain = newGain;
  }
  
  public String getName() {
    return GainCodec;
  }
  
  public GainCodec() {
    this.inputFormats = new Format[] { (Format)new AudioFormat("LINEAR", -1.0D, 16, -1, -1, -1, -1, -1.0D, Format.shortArray) };
    this.outputFormats = new Format[] { (Format)new AudioFormat("LINEAR", -1.0D, 16, -1, -1, -1, -1, -1.0D, Format.shortArray) };
  }
  
  public Format[] getSupportedOutputFormats(Format in) {
    if (!(in instanceof AudioFormat))
      return this.outputFormats; 
    AudioFormat iaf = (AudioFormat)in;
    if (!iaf.getEncoding().equals("LINEAR") || iaf.getDataType() != Format.shortArray)
      return new Format[0]; 
    AudioFormat oaf = new AudioFormat("LINEAR", iaf.getSampleRate(), 16, iaf.getChannels(), 0, 1, iaf.getFrameSizeInBits(), iaf.getFrameRate(), Format.shortArray);
    return new Format[] { (Format)oaf };
  }
  
  public int process(Buffer inputBuffer, Buffer outputBuffer) {
    if (isEOM(inputBuffer)) {
      propagateEOM(outputBuffer);
      return 0;
    } 
    short[] inBuffer = (short[])inputBuffer.getData();
    int inLength = inputBuffer.getLength();
    int inOffset = inputBuffer.getOffset();
    int samplesNumber = inLength;
    short[] outBuffer = validateShortArraySize(outputBuffer, samplesNumber);
    for (int i = 0; i < samplesNumber; i++) {
      int sample = inBuffer[inOffset + i];
      sample = (int)(sample * this.gain);
      if (sample > 32767) {
        sample = 32767;
      } else if (sample < -32768) {
        sample = -32768;
      } 
      outBuffer[i] = (short)sample;
    } 
    updateOutput(outputBuffer, this.outputFormat, samplesNumber, 0);
    return 0;
  }
  
  public static void main(String[] args) {
    GainCodec codec = new GainCodec();
    Format[] ifmt = codec.getSupportedInputFormats();
    Format[] ofmt = codec.getSupportedOutputFormats(null);
    Buffer inp = new Buffer();
    Buffer out = new Buffer();
    short[] buffer = new short[100];
    for (int i = 0; i < 100; i++)
      buffer[i] = (short)(i + 20500); 
    inp.setData(buffer);
    inp.setLength(10);
    inp.setOffset(0);
    codec.setGain(1.6F);
    int rc = codec.process(inp, out);
    System.out.println("rc=" + rc);
    short[] outbuf = (short[])out.getData();
    System.out.println("length=" + out.getLength());
    System.out.println("offset=" + out.getOffset());
    for (int j = 0; j < outbuf.length; j++)
      System.out.println(j + " " + outbuf[j]); 
    inp.setLength(0);
    inp.setEOM(true);
    rc = codec.process(inp, out);
    System.out.println("rc=" + rc);
    outbuf = (short[])out.getData();
    System.out.println("length=" + out.getLength());
    System.out.println("offset=" + out.getOffset());
    for (int k = 0; k < outbuf.length; k++)
      System.out.println(k + " " + outbuf[k]); 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\GainCodec.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */