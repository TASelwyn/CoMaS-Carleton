package com.ibm.media.codec.audio.gsm;

import com.ibm.media.codec.audio.AudioCodec;
import com.sun.media.format.WavAudioFormat;
import javax.media.Format;
import javax.media.ResourceUnavailableException;
import javax.media.format.AudioFormat;

public class JavaEncoder_ms extends JavaEncoder {
  public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997,1999.";
  
  public JavaEncoder_ms() {
    ((AudioCodec)this).supportedInputFormats = new AudioFormat[] { new AudioFormat("LINEAR", -1.0D, 16, 1, 0, 1, -1, -1.0D, Format.byteArray) };
    ((AudioCodec)this).defaultOutputFormats = new AudioFormat[] { (AudioFormat)new WavAudioFormat("gsm/ms") };
    ((AudioCodec)this).PLUGIN_NAME = "MS GSM Encoder";
    this.historySize = 640;
  }
  
  protected Format[] getMatchingOutputFormats(Format in) {
    AudioFormat af = (AudioFormat)in;
    ((AudioCodec)this).supportedOutputFormats = new AudioFormat[] { (AudioFormat)new WavAudioFormat("gsm/ms", af.getSampleRate(), 0, af.getChannels(), 520, (int)(af.getSampleRate() * af.getChannels() / 320.0D * 65.0D), -1, -1, -1.0F, Format.byteArray, new byte[] { 64, 1 }) };
    return (Format[])((AudioCodec)this).supportedOutputFormats;
  }
  
  public void open() throws ResourceUnavailableException {
    this.encoder = new GsmEncoder_ms();
    this.encoder.gsm_encoder_reset();
  }
  
  protected int calculateOutputSize(int inputSize) {
    return calculateFramesNumber(inputSize) * 65;
  }
  
  protected int calculateFramesNumber(int inputSize) {
    return inputSize / 640;
  }
  
  protected boolean codecProcess(byte[] inpData, int readPtr, byte[] outData, int writePtr, int inpLength, int[] readBytes, int[] writeBytes, int[] frameNumber, int[] regions, int[] regionsTypes) {
    int inCount = 0;
    int outCount = 0;
    int channels = ((AudioCodec)this).inputFormat.getChannels();
    boolean isStereo = (channels == 2);
    int frames = inpLength / 640;
    regions[0] = writePtr;
    for (int frameCounter = 0; frameCounter < frames; frameCounter++) {
      this.encoder.gsm_encode_frame(inpData, readPtr, outData, writePtr);
      readPtr += 640;
      inCount += 640;
      outCount += 65;
      writePtr += 65;
      regions[frameCounter + 1] = outCount + writePtr;
      regionsTypes[frameCounter] = 0;
    } 
    readBytes[0] = inCount;
    writeBytes[0] = outCount;
    frameNumber[0] = frames;
    return true;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\gsm\JavaEncoder_ms.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */