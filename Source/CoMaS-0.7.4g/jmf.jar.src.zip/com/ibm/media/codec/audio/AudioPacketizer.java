package com.ibm.media.codec.audio;

import javax.media.Buffer;
import javax.media.Format;

public abstract class AudioPacketizer extends AudioCodec {
  protected byte[] history;
  
  protected int packetSize;
  
  protected int historyLength;
  
  protected int sample_count;
  
  public synchronized int process(Buffer inputBuffer, Buffer outputBuffer) {
    int inpLength = inputBuffer.getLength();
    int outLength = this.packetSize;
    byte[] inpData = (byte[])inputBuffer.getData();
    byte[] outData = validateByteArraySize(outputBuffer, outLength);
    if (inpLength + this.historyLength >= this.packetSize) {
      int copyFromHistory = Math.min(this.historyLength, this.packetSize);
      System.arraycopy(this.history, 0, outData, 0, copyFromHistory);
      int remainingBytes = this.packetSize - copyFromHistory;
      System.arraycopy(inpData, inputBuffer.getOffset(), outData, this.historyLength, remainingBytes);
      this.historyLength -= copyFromHistory;
      inputBuffer.setOffset(inputBuffer.getOffset() + remainingBytes);
      inputBuffer.setLength(inpLength - remainingBytes);
      updateOutput(outputBuffer, (Format)this.outputFormat, outLength, 0);
      return 2;
    } 
    if (inputBuffer.isEOM()) {
      System.arraycopy(this.history, 0, outData, 0, this.historyLength);
      System.arraycopy(inpData, inputBuffer.getOffset(), outData, this.historyLength, inpLength);
      updateOutput(outputBuffer, (Format)this.outputFormat, inpLength + this.historyLength, 0);
      this.historyLength = 0;
      return 0;
    } 
    System.arraycopy(inpData, inputBuffer.getOffset(), this.history, this.historyLength, inpLength);
    this.historyLength += inpLength;
    return 4;
  }
  
  public void reset() {
    this.historyLength = 0;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\AudioPacketizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */