package com.ibm.media.codec.audio.gsm;

import com.ibm.media.codec.audio.AudioCodec;
import com.sun.media.BasicPlugIn;
import com.sun.media.controls.SilenceSuppressionAdapter;
import javax.media.Buffer;
import javax.media.Codec;
import javax.media.Format;
import javax.media.ResourceUnavailableException;
import javax.media.format.AudioFormat;

public class JavaDecoder extends AudioCodec {
  public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997,1999.";
  
  protected GsmDecoder decoder;
  
  public JavaDecoder() {
    this.supportedInputFormats = new AudioFormat[] { new AudioFormat("gsm"), new AudioFormat("gsm/rtp") };
    this.defaultOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR") };
    this.PLUGIN_NAME = "GSM Decoder";
  }
  
  protected Format[] getMatchingOutputFormats(Format in) {
    AudioFormat af = (AudioFormat)in;
    this.supportedOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR", af.getSampleRate(), 16, af.getChannels(), 0, 1) };
    return (Format[])this.supportedOutputFormats;
  }
  
  public void open() throws ResourceUnavailableException {
    this.decoder = new GsmDecoder();
    this.decoder.decoderInit();
  }
  
  public void reset() {
    resetDecoder();
  }
  
  public void close() {
    freeDecoder();
  }
  
  public int process(Buffer inputBuffer, Buffer outputBuffer) {
    if (!checkInputBuffer(inputBuffer))
      return 1; 
    if (isEOM(inputBuffer)) {
      propagateEOM(outputBuffer);
      return 0;
    } 
    int inpLength = inputBuffer.getLength();
    int outLength = calculateOutputSize(inputBuffer.getLength());
    byte[] inpData = (byte[])inputBuffer.getData();
    byte[] outData = validateByteArraySize(outputBuffer, outLength);
    decode(inpData, inputBuffer.getOffset(), outData, 0, inpLength);
    updateOutput(outputBuffer, (Format)this.outputFormat, outLength, 0);
    return 0;
  }
  
  protected void freeDecoder() {
    this.decoder = null;
  }
  
  protected void resetDecoder() {
    this.decoder.decoderInit();
  }
  
  protected int calculateOutputSize(int inputSize) {
    return inputSize / 33 * 320;
  }
  
  protected void decode(byte[] inpData, int readPtr, byte[] outData, int writePtr, int inpLength) {
    int numberOfFrames = inpLength / 33;
    for (int n = 1; n <= numberOfFrames; n++, writePtr += 320, readPtr += 33)
      this.decoder.decodeFrame(inpData, readPtr, outData, writePtr); 
  }
  
  public Object[] getControls() {
    if (((BasicPlugIn)this).controls == null) {
      ((BasicPlugIn)this).controls = (Object[])new javax.media.Control[1];
      ((BasicPlugIn)this).controls[0] = new SilenceSuppressionAdapter((Codec)this, true, false);
    } 
    return ((BasicPlugIn)this).controls;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\gsm\JavaDecoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */