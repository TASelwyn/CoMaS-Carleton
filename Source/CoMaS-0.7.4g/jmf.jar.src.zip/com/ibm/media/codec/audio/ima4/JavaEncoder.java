/*     */ package com.ibm.media.codec.audio.ima4;
/*     */ 
/*     */ import com.ibm.media.codec.audio.AudioCodec;
/*     */ import com.ibm.media.codec.audio.BufferedEncoder;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaEncoder
/*     */   extends BufferedEncoder
/*     */ {
/*     */   private IMA4State ima4stateL;
/*     */   private IMA4State ima4stateR;
/*     */   
/*     */   public JavaEncoder() {
/*  39 */     ((AudioCodec)this).supportedInputFormats = new AudioFormat[] { new AudioFormat("LINEAR", -1.0D, 16, -1, 0, 1, -1, -1.0D, Format.byteArray) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  50 */     ((AudioCodec)this).defaultOutputFormats = new AudioFormat[] { new AudioFormat("ima4") };
/*  51 */     ((AudioCodec)this).PLUGIN_NAME = "IMA4 Encoder";
/*     */     
/*  53 */     this.historySize = 256;
/*     */   }
/*     */   
/*     */   protected Format[] getMatchingOutputFormats(Format in) {
/*  57 */     AudioFormat af = (AudioFormat)in;
/*     */     
/*  59 */     ((AudioCodec)this).supportedOutputFormats = new AudioFormat[] { new AudioFormat("ima4", af.getSampleRate(), 16, af.getChannels(), -1, -1, 272 * af.getChannels(), -1.0D, Format.byteArray) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     return (Format[])((AudioCodec)this).supportedOutputFormats;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() {
/*  78 */     this.ima4stateL = new IMA4State();
/*  79 */     this.ima4stateR = new IMA4State();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*  85 */     this.ima4stateL = null;
/*  86 */     this.ima4stateR = null;
/*     */   }
/*     */   
/*     */   public void codecReset() {
/*  90 */     this.ima4stateL.index = 0;
/*  91 */     this.ima4stateL.valprev = 0;
/*  92 */     this.ima4stateR.index = 0;
/*  93 */     this.ima4stateR.valprev = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int calculateOutputSize(int inputSize) {
/*  98 */     return calculateFramesNumber(inputSize) * 34 * 2;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int calculateFramesNumber(int inputSize) {
/* 103 */     return inputSize / 128;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean codecProcess(byte[] inpData, int readPtr, byte[] outData, int writePtr, int inpLength, int[] readBytes, int[] writeBytes, int[] frameNumber, int[] regions, int[] regiostypes) {
/* 113 */     int inCount = 0;
/* 114 */     int outCount = 0;
/* 115 */     int channels = ((AudioCodec)this).inputFormat.getChannels();
/* 116 */     boolean isStereo = (channels == 2);
/* 117 */     int stride = isStereo ? 2 : 0;
/*     */     
/* 119 */     int frames = inpLength / channels * 128;
/*     */     
/* 121 */     regions[0] = writePtr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 131 */     for (int frameCounter = 0; frameCounter < frames; frameCounter++) {
/*     */ 
/*     */ 
/*     */       
/* 135 */       if (this.ima4stateL.index > 88) {
/* 136 */         this.ima4stateL.index = 88;
/* 137 */       } else if (this.ima4stateL.index < 0) {
/* 138 */         this.ima4stateL.index = 0;
/*     */       } 
/*     */       
/* 141 */       this.ima4stateL.valprev &= 0xFFFFFF80;
/*     */       
/* 143 */       int stateL = this.ima4stateL.valprev | this.ima4stateL.index;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 149 */       outData[writePtr + outCount++] = (byte)(stateL >> 8);
/* 150 */       outData[writePtr + outCount++] = (byte)stateL;
/*     */       
/* 152 */       IMA4.encode(inpData, readPtr + inCount, outData, writePtr + outCount, 64, this.ima4stateL, stride);
/*     */       
/* 154 */       outCount += 32;
/*     */ 
/*     */ 
/*     */       
/* 158 */       if (isStereo) {
/*     */         
/* 160 */         if (this.ima4stateR.index > 88) {
/* 161 */           this.ima4stateR.index = 88;
/* 162 */         } else if (this.ima4stateR.index < 0) {
/* 163 */           this.ima4stateR.index = 0;
/*     */         } 
/*     */         
/* 166 */         this.ima4stateR.valprev &= 0xFFFFFF80;
/*     */         
/* 168 */         int stateR = this.ima4stateR.valprev | this.ima4stateR.index;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 174 */         outData[writePtr + outCount++] = (byte)(stateR >> 8);
/* 175 */         outData[writePtr + outCount++] = (byte)stateR;
/*     */         
/* 177 */         IMA4.encode(inpData, readPtr + inCount + 2, outData, writePtr + outCount, 64, this.ima4stateR, stride);
/*     */         
/* 179 */         outCount += 32;
/*     */         
/* 181 */         inCount += 256;
/*     */       } else {
/* 183 */         inCount += 128;
/*     */       } 
/*     */       
/* 186 */       regions[frameCounter + 1] = outCount + writePtr;
/* 187 */       this.regionsTypes[frameCounter] = 0;
/*     */     } 
/*     */ 
/*     */     
/* 191 */     readBytes[0] = inCount;
/* 192 */     writeBytes[0] = outCount;
/* 193 */     frameNumber[0] = frames;
/*     */     
/* 195 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\ibm\media\codec\audio\ima4\JavaEncoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */