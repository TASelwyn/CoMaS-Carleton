package com.ibm.media.codec.audio.gsm;

public class GsmDecoder_ms extends GsmDecoder {
  public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997,1999.";
  
  private boolean msFrameOdd;
  
  public boolean decodeFrame(byte[] src, int srcoffset, byte[] dst, int dstoffset) {
    this.msFrameOdd = true;
    super.decodeFrame(src, srcoffset, dst, dstoffset);
    this.msFrameOdd = false;
    super.decodeFrame(src, srcoffset, dst, dstoffset + 320);
    return true;
  }
  
  protected boolean UnpackBitStream(byte[] inByteStream, int inputIndex, int[] Parameters) {
    int paramIndex = 0;
    if (this.msFrameOdd) {
      Parameters[paramIndex++] = inByteStream[inputIndex] & 0x3F;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 6 & 0x3 | (inByteStream[++inputIndex] & 0xF) << 2;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 4 & 0xF | (inByteStream[++inputIndex] & 0x1) << 4;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 1 & 0x1F;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 6 & 0x3 | (inByteStream[++inputIndex] & 0x3) << 2;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 2 & 0xF;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 6 & 0x3 | (inByteStream[++inputIndex] & 0x1) << 2;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 1 & 0x7;
      for (int n = 0; n < 4; n++) {
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 4 & 0xF | (inByteStream[++inputIndex] & 0x7) << 4;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 3 & 0x3;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 5 & 0x3;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 7 & 0x1 | (inByteStream[++inputIndex] & 0x1F) << 1;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 5 & 0x7;
        Parameters[paramIndex++] = inByteStream[++inputIndex] & 0x7;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 3 & 0x7;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 6 & 0x3 | (inByteStream[++inputIndex] & 0x1) << 2;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 1 & 0x7;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 4 & 0x7;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 7 & 0x1 | (inByteStream[++inputIndex] & 0x3) << 1;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 2 & 0x7;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 5 & 0x7;
        Parameters[paramIndex++] = inByteStream[++inputIndex] & 0x7;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 3 & 0x7;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 6 & 0x3 | (inByteStream[++inputIndex] & 0x1) << 2;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 1 & 0x7;
      } 
    } else {
      inputIndex += 32;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 4 & 0xF | (inByteStream[++inputIndex] & 0x3) << 4;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 2 & 0x3F;
      Parameters[paramIndex++] = inByteStream[++inputIndex] & 0x1F;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 5 & 0x7 | (inByteStream[++inputIndex] & 0x3) << 3;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 2 & 0xF;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 6 & 0x3 | (inByteStream[++inputIndex] & 0x3) << 2;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 2 & 0x7;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 5 & 0x7;
      inputIndex++;
      for (byte b = 0; b < 4; b++) {
        Parameters[paramIndex++] = inByteStream[inputIndex] & Byte.MAX_VALUE;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 7 & 0x1 | (inByteStream[++inputIndex] & 0x1) << 1;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 1 & 0x3;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 3 & 0x1F | (inByteStream[++inputIndex] & 0x1) << 5;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 1 & 0x7;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 4 & 0x7;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 7 & 0x1 | (inByteStream[++inputIndex] & 0x3) << 1;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 2 & 0x7;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 5 & 0x7;
        Parameters[paramIndex++] = inByteStream[++inputIndex] & 0x7;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 3 & 0x7;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 6 & 0x3 | (inByteStream[++inputIndex] & 0x1) << 2;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 1 & 0x7;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 4 & 0x7;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 7 & 0x1 | (inByteStream[++inputIndex] & 0x3) << 1;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 2 & 0x7;
        Parameters[paramIndex++] = inByteStream[inputIndex] >> 5 & 0x7;
        inputIndex++;
      } 
    } 
    return true;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\gsm\GsmDecoder_ms.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */