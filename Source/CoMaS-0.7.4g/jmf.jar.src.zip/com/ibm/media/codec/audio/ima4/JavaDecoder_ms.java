/*     */ package com.ibm.media.codec.audio.ima4;
/*     */ 
/*     */ import com.ibm.media.codec.audio.AudioCodec;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.controls.SilenceSuppressionAdapter;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Codec;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaDecoder_ms
/*     */   extends AudioCodec
/*     */ {
/*     */   private IMA4State ima4state;
/*     */   
/*     */   public JavaDecoder_ms() {
/*  32 */     this.supportedInputFormats = new AudioFormat[] { new AudioFormat("ima4/ms") };
/*  33 */     this.defaultOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR") };
/*  34 */     this.PLUGIN_NAME = "IMA4 MS Decoder";
/*     */   }
/*     */   
/*     */   protected Format[] getMatchingOutputFormats(Format in) {
/*  38 */     AudioFormat af = (AudioFormat)in;
/*     */ 
/*     */     
/*  41 */     int fs = af.getFrameSizeInBits();
/*  42 */     int channels = af.getChannels();
/*     */     
/*  44 */     if (fs % 32 * channels != 0) {
/*  45 */       return new Format[0];
/*     */     }
/*  47 */     this.supportedOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR", af.getSampleRate(), 16, af.getChannels(), 1, 1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  58 */     return (Format[])this.supportedOutputFormats;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() {
/*  64 */     this.ima4state = new IMA4State();
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/*  69 */     this.ima4state = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int process(Buffer inputBuffer, Buffer outputBuffer) {
/*  77 */     if (!checkInputBuffer(inputBuffer)) {
/*  78 */       return 1;
/*     */     }
/*     */     
/*  81 */     if (isEOM(inputBuffer)) {
/*  82 */       propagateEOM(outputBuffer);
/*  83 */       return 0;
/*     */     } 
/*     */     
/*  86 */     int channels = this.outputFormat.getChannels();
/*  87 */     byte[] inData = (byte[])inputBuffer.getData();
/*  88 */     byte[] outData = validateByteArraySize(outputBuffer, inData.length * 4);
/*     */     
/*  90 */     int blockSize = this.inputFormat.getFrameSizeInBits() >> 3;
/*     */     
/*  92 */     int outLength = decodeJavaMSIMA4(inData, outData, inputBuffer.getLength(), outData.length, channels, blockSize);
/*     */ 
/*     */ 
/*     */     
/*  96 */     updateOutput(outputBuffer, (Format)this.outputFormat, outLength, 0);
/*     */     
/*  98 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int decodeJavaMSIMA4(byte[] inBuffer, byte[] outBuffer, int lenIn, int lenOut, int nChannels, int blockSize) {
/* 106 */     switch (nChannels) {
/*     */       case 1:
/* 108 */         return decodeMSIMA4mono(inBuffer, outBuffer, lenIn, lenOut, blockSize);
/*     */       case 2:
/* 110 */         return decodeMSIMA4stereo(inBuffer, outBuffer, lenIn, lenOut, blockSize);
/*     */     } 
/* 112 */     throw new RuntimeException("MSIMA4: Can only handle 1 or 2 channels\n");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int decodeMSIMA4mono(byte[] inBuffer, byte[] outBuffer, int lenIn, int lenOut, int blockSize) {
/* 118 */     int inCount = 0;
/* 119 */     int outCount = 0;
/*     */     
/* 121 */     lenIn = lenIn / blockSize * blockSize;
/*     */     
/* 123 */     while (inCount < lenIn) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 128 */       int prevVal = inBuffer[inCount++] & 0xFF;
/* 129 */       prevVal |= inBuffer[inCount++] << 8;
/*     */ 
/*     */       
/* 132 */       int index = inBuffer[inCount++] & 0xFF;
/*     */       
/* 134 */       if (index > 88) {
/* 135 */         index = 88;
/*     */       }
/* 137 */       inCount++;
/*     */       
/* 139 */       outBuffer[outCount++] = (byte)(prevVal >> 8);
/* 140 */       outBuffer[outCount++] = (byte)prevVal;
/*     */ 
/*     */       
/* 143 */       this.ima4state.valprev = prevVal;
/* 144 */       this.ima4state.index = index;
/*     */       
/* 146 */       IMA4.decode(inBuffer, inCount, outBuffer, outCount, blockSize - 4 << 1, this.ima4state, 0);
/*     */       
/* 148 */       inCount += blockSize - 4;
/*     */       
/* 150 */       outCount += blockSize - 4 << 2;
/*     */     } 
/*     */     
/* 153 */     return outCount;
/*     */   }
/*     */ 
/*     */   
/*     */   private int decodeMSIMA4stereo(byte[] inBuffer, byte[] outBuffer, int lenIn, int lenOut, int blockSize) {
/* 158 */     int inCount = 0;
/* 159 */     int outCount = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 173 */     lenIn = lenIn / blockSize * blockSize;
/*     */     
/* 175 */     for (int i = 0; i < outBuffer.length; i++) {
/* 176 */       outBuffer[i] = 0;
/*     */     }
/* 178 */     while (inCount < lenIn) {
/* 179 */       int storedinCount = inCount;
/* 180 */       int storedoutCount = outCount;
/*     */       
/* 182 */       int prevValL = inBuffer[inCount++] & 0xFF;
/* 183 */       prevValL |= inBuffer[inCount++] << 8;
/*     */       
/* 185 */       int indexL = inBuffer[inCount++] & 0xFF;
/*     */       
/* 187 */       if (indexL > 88) {
/* 188 */         indexL = 88;
/*     */       }
/* 190 */       inCount++;
/*     */       
/* 192 */       outBuffer[outCount++] = (byte)(prevValL >> 8);
/* 193 */       outBuffer[outCount++] = (byte)prevValL;
/*     */       
/* 195 */       outCount += 2;
/* 196 */       inCount += 4;
/*     */       
/* 198 */       this.ima4state.valprev = prevValL;
/* 199 */       this.ima4state.index = indexL;
/*     */       
/* 201 */       for (int j = blockSize - 8; j > 0; j -= 8) {
/* 202 */         IMA4.decode(inBuffer, inCount, outBuffer, outCount, 8, this.ima4state, 2);
/*     */         
/* 204 */         inCount += 8;
/* 205 */         outCount += 32;
/*     */       } 
/*     */ 
/*     */       
/* 209 */       inCount = storedinCount + 4;
/* 210 */       outCount = storedoutCount + 2;
/*     */ 
/*     */       
/* 213 */       int prevValR = inBuffer[inCount++] & 0xFF;
/* 214 */       prevValR |= inBuffer[inCount++] << 8;
/*     */       
/* 216 */       int indexR = inBuffer[inCount++] & 0xFF;
/*     */       
/* 218 */       if (indexR > 88) {
/* 219 */         indexR = 88;
/*     */       }
/* 221 */       inCount++;
/*     */       
/* 223 */       outBuffer[outCount++] = (byte)(prevValR >> 8);
/* 224 */       outBuffer[outCount++] = (byte)prevValR;
/* 225 */       this.ima4state.valprev = prevValR;
/* 226 */       this.ima4state.index = indexR;
/*     */       
/* 228 */       outCount += 2;
/* 229 */       inCount += 4;
/*     */       
/* 231 */       for (int k = blockSize - 8; k > 0; k -= 8) {
/* 232 */         IMA4.decode(inBuffer, inCount, outBuffer, outCount, 8, this.ima4state, 2);
/*     */         
/* 234 */         inCount += 8;
/* 235 */         outCount += 32;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 240 */       inCount = storedinCount + blockSize;
/* 241 */       outCount = storedoutCount + (blockSize - 8 << 2) + 4;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 248 */     return outCount;
/*     */   }
/*     */   
/*     */   public Object[] getControls() {
/* 252 */     if (((BasicPlugIn)this).controls == null) {
/* 253 */       ((BasicPlugIn)this).controls = (Object[])new javax.media.Control[1];
/* 254 */       ((BasicPlugIn)this).controls[0] = new SilenceSuppressionAdapter((Codec)this, false, false);
/*     */     } 
/* 256 */     return ((BasicPlugIn)this).controls;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\ibm\media\codec\audio\ima4\JavaDecoder_ms.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */