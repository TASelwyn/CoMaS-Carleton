package com.ibm.media.codec.audio.ima4;

import com.ibm.media.codec.audio.AudioCodec;
import com.sun.media.BasicPlugIn;
import com.sun.media.controls.SilenceSuppressionAdapter;
import javax.media.Buffer;
import javax.media.Codec;
import javax.media.Format;
import javax.media.format.AudioFormat;

public class JavaDecoder_ms extends AudioCodec {
  private IMA4State ima4state;
  
  public JavaDecoder_ms() {
    this.supportedInputFormats = new AudioFormat[] { new AudioFormat("ima4/ms") };
    this.defaultOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR") };
    this.PLUGIN_NAME = "IMA4 MS Decoder";
  }
  
  protected Format[] getMatchingOutputFormats(Format in) {
    AudioFormat af = (AudioFormat)in;
    int fs = af.getFrameSizeInBits();
    int channels = af.getChannels();
    if (fs % 32 * channels != 0)
      return new Format[0]; 
    this.supportedOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR", af.getSampleRate(), 16, af.getChannels(), 1, 1) };
    return (Format[])this.supportedOutputFormats;
  }
  
  public void open() {
    this.ima4state = new IMA4State();
  }
  
  public void close() {
    this.ima4state = null;
  }
  
  public int process(Buffer inputBuffer, Buffer outputBuffer) {
    if (!checkInputBuffer(inputBuffer))
      return 1; 
    if (isEOM(inputBuffer)) {
      propagateEOM(outputBuffer);
      return 0;
    } 
    int channels = this.outputFormat.getChannels();
    byte[] inData = (byte[])inputBuffer.getData();
    byte[] outData = validateByteArraySize(outputBuffer, inData.length * 4);
    int blockSize = this.inputFormat.getFrameSizeInBits() >> 3;
    int outLength = decodeJavaMSIMA4(inData, outData, inputBuffer.getLength(), outData.length, channels, blockSize);
    updateOutput(outputBuffer, (Format)this.outputFormat, outLength, 0);
    return 0;
  }
  
  private int decodeJavaMSIMA4(byte[] inBuffer, byte[] outBuffer, int lenIn, int lenOut, int nChannels, int blockSize) {
    switch (nChannels) {
      case 1:
        return decodeMSIMA4mono(inBuffer, outBuffer, lenIn, lenOut, blockSize);
      case 2:
        return decodeMSIMA4stereo(inBuffer, outBuffer, lenIn, lenOut, blockSize);
    } 
    throw new RuntimeException("MSIMA4: Can only handle 1 or 2 channels\n");
  }
  
  private int decodeMSIMA4mono(byte[] inBuffer, byte[] outBuffer, int lenIn, int lenOut, int blockSize) {
    int inCount = 0;
    int outCount = 0;
    lenIn = lenIn / blockSize * blockSize;
    while (inCount < lenIn) {
      int prevVal = inBuffer[inCount++] & 0xFF;
      prevVal |= inBuffer[inCount++] << 8;
      int index = inBuffer[inCount++] & 0xFF;
      if (index > 88)
        index = 88; 
      inCount++;
      outBuffer[outCount++] = (byte)(prevVal >> 8);
      outBuffer[outCount++] = (byte)prevVal;
      this.ima4state.valprev = prevVal;
      this.ima4state.index = index;
      IMA4.decode(inBuffer, inCount, outBuffer, outCount, blockSize - 4 << 1, this.ima4state, 0);
      inCount += blockSize - 4;
      outCount += blockSize - 4 << 2;
    } 
    return outCount;
  }
  
  private int decodeMSIMA4stereo(byte[] inBuffer, byte[] outBuffer, int lenIn, int lenOut, int blockSize) {
    int inCount = 0;
    int outCount = 0;
    lenIn = lenIn / blockSize * blockSize;
    for (int i = 0; i < outBuffer.length; i++)
      outBuffer[i] = 0; 
    while (inCount < lenIn) {
      int storedinCount = inCount;
      int storedoutCount = outCount;
      int prevValL = inBuffer[inCount++] & 0xFF;
      prevValL |= inBuffer[inCount++] << 8;
      int indexL = inBuffer[inCount++] & 0xFF;
      if (indexL > 88)
        indexL = 88; 
      inCount++;
      outBuffer[outCount++] = (byte)(prevValL >> 8);
      outBuffer[outCount++] = (byte)prevValL;
      outCount += 2;
      inCount += 4;
      this.ima4state.valprev = prevValL;
      this.ima4state.index = indexL;
      for (int j = blockSize - 8; j > 0; j -= 8) {
        IMA4.decode(inBuffer, inCount, outBuffer, outCount, 8, this.ima4state, 2);
        inCount += 8;
        outCount += 32;
      } 
      inCount = storedinCount + 4;
      outCount = storedoutCount + 2;
      int prevValR = inBuffer[inCount++] & 0xFF;
      prevValR |= inBuffer[inCount++] << 8;
      int indexR = inBuffer[inCount++] & 0xFF;
      if (indexR > 88)
        indexR = 88; 
      inCount++;
      outBuffer[outCount++] = (byte)(prevValR >> 8);
      outBuffer[outCount++] = (byte)prevValR;
      this.ima4state.valprev = prevValR;
      this.ima4state.index = indexR;
      outCount += 2;
      inCount += 4;
      for (int k = blockSize - 8; k > 0; k -= 8) {
        IMA4.decode(inBuffer, inCount, outBuffer, outCount, 8, this.ima4state, 2);
        inCount += 8;
        outCount += 32;
      } 
      inCount = storedinCount + blockSize;
      outCount = storedoutCount + (blockSize - 8 << 2) + 4;
    } 
    return outCount;
  }
  
  public Object[] getControls() {
    if (((BasicPlugIn)this).controls == null) {
      ((BasicPlugIn)this).controls = (Object[])new javax.media.Control[1];
      ((BasicPlugIn)this).controls[0] = new SilenceSuppressionAdapter((Codec)this, false, false);
    } 
    return ((BasicPlugIn)this).controls;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\ima4\JavaDecoder_ms.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */