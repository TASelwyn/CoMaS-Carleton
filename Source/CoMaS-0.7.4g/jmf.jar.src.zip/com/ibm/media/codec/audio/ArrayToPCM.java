package com.ibm.media.codec.audio;

import com.sun.media.BasicCodec;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.format.AudioFormat;

public class ArrayToPCM extends BasicCodec {
  private static String ArrayToPCM = "ArrayToPCM";
  
  public String getName() {
    return ArrayToPCM;
  }
  
  public ArrayToPCM() {
    this.inputFormats = new Format[] { (Format)new AudioFormat("LINEAR", -1.0D, -1, -1, -1, -1, -1, -1.0D, Format.byteArray) };
    this.outputFormats = new Format[] { (Format)new AudioFormat("LINEAR", -1.0D, 16, -1, -1, -1, -1, -1.0D, Format.shortArray) };
  }
  
  public Format[] getSupportedOutputFormats(Format in) {
    if (!(in instanceof AudioFormat))
      return this.outputFormats; 
    AudioFormat iaf = (AudioFormat)in;
    if (!iaf.getEncoding().equals("LINEAR") || iaf.getDataType() != Format.byteArray)
      return new Format[0]; 
    AudioFormat oaf = new AudioFormat("LINEAR", iaf.getSampleRate(), 16, iaf.getChannels(), 0, 1, iaf.getFrameSizeInBits(), iaf.getFrameRate(), Format.shortArray);
    return new Format[] { (Format)oaf };
  }
  
  public int process(Buffer inputBuffer, Buffer outputBuffer) {
    if (isEOM(inputBuffer))
      return 0; 
    byte[] inBuffer = (byte[])inputBuffer.getData();
    AudioFormat inFormat = (AudioFormat)inputBuffer.getFormat();
    boolean isSigned = (inFormat.getSigned() == 1);
    boolean isBigEndian = (inFormat.getEndian() == 1);
    int sampleSize = inFormat.getFrameSizeInBits() + 7 >> 3;
    int inLength = inputBuffer.getLength();
    int samplesNumber = (sampleSize == 1) ? inLength : (inLength >> 1);
    int outLength = samplesNumber;
    short[] outBuffer = validateShortArraySize(outputBuffer, outLength);
    int offset = isSigned ? 0 : 32768;
    int inOffset = 0;
    int outOffset = 0;
    if (sampleSize == 1) {
      for (int i = samplesNumber - 1; i >= 0; i--)
        outBuffer[i] = (short)((inBuffer[i] << 8) + offset); 
    } else if (isBigEndian) {
      for (int i = samplesNumber - 1; i >= 0; i--) {
        int sample1 = inBuffer[inOffset++] << 8;
        int sample2 = inBuffer[inOffset++] & 0xFF;
        outBuffer[outOffset++] = (short)((sample1 | sample2) + offset);
      } 
    } else {
      for (int i = samplesNumber - 1; i >= 0; i--) {
        int sample1 = inBuffer[inOffset++] & 0xFF;
        int sample2 = inBuffer[inOffset++] << 8;
        outBuffer[outOffset++] = (short)((sample1 | sample2) + offset);
      } 
    } 
    outputBuffer.setLength(samplesNumber);
    outputBuffer.setFormat(this.outputFormat);
    return 0;
  }
  
  public static void main(String[] args) {
    ArrayToPCM arrayToPCM = new ArrayToPCM();
    Format[] ifmt = arrayToPCM.getSupportedInputFormats();
    Format[] ofmt = arrayToPCM.getSupportedOutputFormats((Format)new AudioFormat("LINEAR", 8000.0D, 8, 2, 0, 0));
    for (int i = 0; i < ifmt.length; i++)
      System.out.println(ifmt[i]); 
    System.out.println("* out *");
    for (int j = 0; j < ofmt.length; j++)
      System.out.println(ofmt[j]); 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\ArrayToPCM.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */