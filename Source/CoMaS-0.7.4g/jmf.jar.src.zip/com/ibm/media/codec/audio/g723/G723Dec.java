/*      */ package com.ibm.media.codec.audio.g723;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class G723Dec
/*      */ {
/*      */   public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997, 1998.";
/*      */   private DecoderData decoderData;
/*      */   
/*      */   protected final void decoderOpen() {
/*   37 */     this.decoderData = new DecoderData();
/*   38 */     decoderReset();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void decoderReset() {
/*      */     int i;
/*   50 */     for (i = 0; i < 10; i++) {
/*   51 */       this.decoderData.PrevLsp[i] = fLspDcTable[i];
/*   52 */       this.decoderData.PostIirDl[i] = 0.0F; this.decoderData.PostFirDl[i] = 0.0F; this.decoderData.SyntIirDl[i] = 0.0F;
/*      */     } 
/*      */ 
/*      */     
/*   56 */     for (i = 0; i < this.decoderData.PrevExc.length; i++) {
/*   57 */       this.decoderData.PrevExc[i] = 0.0F;
/*      */     }
/*   59 */     this.decoderData.Ecount = 0;
/*   60 */     this.decoderData.InterGain = 0.0F;
/*   61 */     this.decoderData.InterIndx = 0;
/*   62 */     this.decoderData.Park = 0.0F;
/*   63 */     this.decoderData.Rseed = 0;
/*   64 */     this.decoderData.Gain = 1.0F;
/*      */     
/*   66 */     this.decoderData.BlockIndex = 0;
/*   67 */     this.decoderData.BlockCount = 0;
/*      */     
/*   69 */     this.decoderData.WrkRate = 0;
/*   70 */     this.decoderData.UsePf = true;
/*      */ 
/*      */     
/*   73 */     for (i = 0; i < 10; i++) {
/*   74 */       this.decoderData.PrevLsp[i] = fLspDcTable[i];
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  100 */   private final float[] decode_OutputBuffer = new float[240];
/*  101 */   private final float[] decode_QntLpc = new float[40];
/*  102 */   private final float[] decode_AcbkCont = new float[60];
/*  103 */   private final float[] decode_LspVect = new float[10];
/*  104 */   private final LINEDEF decode_Line = new LINEDEF();
/*  105 */   private final PFDEF[] decode_Pf = new PFDEF[] { new PFDEF(), new PFDEF(), new PFDEF(), new PFDEF() };
/*  106 */   private final int[] decode_flag = new int[1];
/*  107 */   private final int[] decode_Ftyp = new int[1];
/*  108 */   private final float[] decode_SyntIir = new float[250];
/*  109 */   private final float[] decode_PostFir = new float[250];
/*  110 */   private final float[] decode_PostIir = new float[250];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void decodeFrame(byte[] bits_input, int indexInp, byte[] outBuffer, int indexOut) {
/*  120 */     float[] OutputBuffer = this.decode_OutputBuffer;
/*  121 */     float[] DataBuff = OutputBuffer;
/*      */ 
/*      */ 
/*      */     
/*  125 */     float SfGain = 0.0F;
/*  126 */     float[] QntLpc = this.decode_QntLpc;
/*  127 */     float[] AcbkCont = this.decode_AcbkCont;
/*  128 */     float[] LspVect = this.decode_LspVect;
/*      */ 
/*      */     
/*  131 */     LINEDEF Line = this.decode_Line;
/*  132 */     PFDEF[] Pf = this.decode_Pf;
/*  133 */     int[] flag = this.decode_flag;
/*  134 */     int[] Ftyp = this.decode_Ftyp;
/*      */ 
/*      */     
/*  137 */     float[] SyntIir = this.decode_SyntIir;
/*  138 */     float[] PostFir = this.decode_PostFir;
/*  139 */     float[] PostIir = this.decode_PostIir;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  148 */     if (this.decoderData.BlockIndex == 0) {
/*  149 */       this.decoderData.BlockCount = 0;
/*  150 */       System.arraycopy(this.decoderData.PrevExc, 960, this.decoderData.PrevExc, 0, 145);
/*      */     } 
/*      */     
/*  153 */     int PrevExcIndex = this.decoderData.BlockIndex * 240 + 145;
/*  154 */     float[] PrevExc = this.decoderData.PrevExc;
/*      */     
/*  156 */     this.decoderData.BlockCount++;
/*  157 */     this.decoderData.BlockIndex = this.decoderData.BlockCount % 4;
/*      */     
/*      */     int i;
/*      */     
/*  161 */     for (i = 0; i < 10; i++) {
/*      */       
/*  163 */       SyntIir[10 - i - 1] = this.decoderData.SyntIirDl[i];
/*  164 */       PostFir[10 - i - 1] = this.decoderData.PostFirDl[i];
/*  165 */       PostIir[10 - i - 1] = this.decoderData.PostIirDl[i];
/*      */     } 
/*      */ 
/*      */     
/*  169 */     Line_Unpk(bits_input, indexInp, Ftyp, (short)0, flag, Line);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  194 */     if (Line.Crc != 0) {
/*  195 */       this.decoderData.Ecount++;
/*      */     } else {
/*  197 */       this.decoderData.Ecount = 0;
/*      */     } 
/*  199 */     if (this.decoderData.Ecount > 3) {
/*  200 */       this.decoderData.Ecount = 3;
/*      */     }
/*      */     
/*  203 */     Lsp_Inq(LspVect, this.decoderData.PrevLsp, Line.LspId, Line.Crc);
/*      */ 
/*      */     
/*  206 */     Lsp_Int(QntLpc, LspVect, this.decoderData.PrevLsp);
/*      */ 
/*      */     
/*  209 */     if (this.decoderData.Ecount == 0) {
/*  210 */       i = (Line.Sfs[2]).Mamp + (Line.Sfs[3]).Mamp >> 1;
/*  211 */       this.decoderData.InterGain = FcbkGainTable[i];
/*      */     } else {
/*  213 */       this.decoderData.InterGain *= 0.75F;
/*      */     } 
/*      */ 
/*      */     
/*  217 */     if (this.decoderData.Ecount == 0) {
/*      */       
/*  219 */       for (i = 0; i < 4; i++) {
/*      */ 
/*      */         
/*  222 */         Fcbk_Unpk(PrevExc, PrevExcIndex + 60 * i, Line.Sfs[i], Line.Olp[i >> 1], i);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  231 */         Decod_Acbk(AcbkCont, PrevExc, PrevExcIndex + 60 * i - 145, Line.Olp[i >> 1], (Line.Sfs[i]).AcLg, (Line.Sfs[i]).AcGn, this.decoderData.WrkRate);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  241 */         for (int j = 0; j < 60; j++) {
/*  242 */           PrevExc[PrevExcIndex + i * 60 + j] = PrevExc[PrevExcIndex + i * 60 + j] + AcbkCont[j];
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  247 */       System.arraycopy(PrevExc, PrevExcIndex, DataBuff, 0, 240);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  258 */       if (this.decoderData.UsePf)
/*      */       {
/*  260 */         for (i = 0; i < 4; i++) {
/*  261 */           Comp_Lpf(PrevExc, PrevExcIndex - 145, Line.Olp[i >> 1], i, Pf[i]);
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  268 */       if (this.decoderData.UsePf)
/*      */       {
/*      */ 
/*      */         
/*  272 */         for (i = 0; i < 4; i++) {
/*  273 */           Filt_Lpf(DataBuff, PrevExc, PrevExcIndex - 145, Pf[i], i);
/*      */         }
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  300 */     float[] Dpnt = DataBuff;
/*  301 */     int indexDpnt = 0;
/*      */     
/*  303 */     for (i = 0; i < 4; i++) {
/*      */ 
/*      */ 
/*      */       
/*  307 */       Synt(Dpnt, indexDpnt, QntLpc, i * 10, SyntIir, 10 + i * 60 - 1);
/*      */ 
/*      */ 
/*      */       
/*  311 */       if (this.decoderData.UsePf) {
/*  312 */         SfGain = Spf(Dpnt, indexDpnt, QntLpc, i * 10, PostFir, 10 + i * 60 - 1, PostIir, 10 + i * 60 - 1);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  317 */         Scale(Dpnt, indexDpnt, SfGain);
/*      */       } 
/*      */       
/*  320 */       indexDpnt += 60;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  325 */     for (i = 0; i < 10; i++) {
/*      */       
/*  327 */       this.decoderData.SyntIirDl[i] = SyntIir[250 - i - 1];
/*  328 */       this.decoderData.PostFirDl[i] = PostFir[250 - i - 1];
/*  329 */       this.decoderData.PostIirDl[i] = PostIir[250 - i - 1];
/*      */     } 
/*      */ 
/*      */     
/*  333 */     Fl2Sh(DataBuff, 240, outBuffer, indexOut);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void Fcbk_Unpk(float[] ExcBuf, int ExcBufIndex, SFSDEF Sfs, int pitch, int SfrNum) {
/*      */     int i;
/*      */     int j;
/*      */     int PlsNum;
/*      */     long CombCounter;
/*  369 */     switch (this.decoderData.WrkRate) {
/*      */       
/*      */       case 0:
/*  372 */         PlsNum = (SfrNum == 0 || SfrNum == 2) ? 6 : 5;
/*      */         
/*  374 */         for (i = ExcBufIndex; i < ExcBufIndex + 60; i++) {
/*  375 */           ExcBuf[i] = 0.0F;
/*      */         }
/*  377 */         if (Sfs.Ppos >= MaxPosTable[SfrNum]) {
/*      */           return;
/*      */         }
/*      */ 
/*      */         
/*  382 */         j = 6 - PlsNum;
/*      */         
/*  384 */         CombCounter = Sfs.Ppos;
/*      */         
/*  386 */         for (i = 0; i < 30; i++) {
/*      */           
/*  388 */           if (CombCounter < CombinatorialTable[j][i]) {
/*  389 */             j++;
/*      */             
/*  391 */             if ((Sfs.Pamp & 1 << 6 - j) != 0) {
/*  392 */               ExcBuf[Sfs.Grid + 2 * i + ExcBufIndex] = -FcbkGainTable[Sfs.Mamp];
/*      */             } else {
/*  394 */               ExcBuf[Sfs.Grid + 2 * i + ExcBufIndex] = FcbkGainTable[Sfs.Mamp];
/*      */             } 
/*  396 */             if (j == 6) {
/*      */               break;
/*      */             }
/*      */           } else {
/*  400 */             CombCounter -= CombinatorialTable[j][i];
/*      */           } 
/*      */         } 
/*      */         
/*  404 */         if (Sfs.Tran == 1) {
/*  405 */           Gen_Trn(ExcBuf, ExcBuf, ExcBufIndex, pitch);
/*      */         }
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void Comp_Lpf(float[] DecExc, int DecExcIndex, int pitch, int SfrNum, PFDEF Pf) {
/*  451 */     float Lcr0 = 0.0F, Lcr1 = 0.0F, Lcr2 = 0.0F, Lcr3 = 0.0F, Lcr4 = 0.0F;
/*      */ 
/*      */ 
/*      */     
/*  455 */     Pf.Indx = 0;
/*  456 */     Pf.Gain = 0.0F;
/*  457 */     Pf.ScGn = 1.0F;
/*      */ 
/*      */     
/*  460 */     int Bindx = Find_B(DecExc, DecExcIndex, pitch, SfrNum);
/*  461 */     int Findx = Find_F(DecExc, DecExcIndex, pitch, SfrNum);
/*      */ 
/*      */     
/*  464 */     if (Bindx == 0 && Findx == 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  469 */     int DecExcPointer = DecExcIndex + 145 + SfrNum * 60; int j;
/*  470 */     for (j = 0; j < 60; j += 2) {
/*      */       
/*  472 */       float DecExc0 = DecExc[DecExcPointer + j];
/*  473 */       float DecExc1 = DecExc[DecExcPointer + j + 1];
/*  474 */       Lcr0 += DecExc0 * DecExc0 + DecExc1 * DecExc1;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  481 */     DecExcPointer = DecExcIndex + 145 + SfrNum * 60;
/*  482 */     if (Bindx != 0) {
/*  483 */       for (j = 0; j < 60; j += 2) {
/*  484 */         float DecExc0 = DecExc[DecExcPointer + Bindx + j];
/*  485 */         float DecExc1 = DecExc[DecExcPointer + Bindx + j + 1];
/*      */         
/*  487 */         Lcr1 += DecExc[DecExcPointer + j] * DecExc0 + DecExc[DecExcPointer + j + 1] * DecExc1;
/*  488 */         Lcr2 += DecExc0 * DecExc0 + DecExc1 * DecExc1;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  494 */     DecExcPointer = DecExcIndex + 145 + SfrNum * 60;
/*  495 */     if (Findx != 0) {
/*  496 */       for (j = 0; j < 60; j += 2) {
/*  497 */         float DecExc0 = DecExc[DecExcPointer + Findx + j];
/*  498 */         float DecExc1 = DecExc[DecExcPointer + Findx + j + 1];
/*  499 */         Lcr3 += DecExc[DecExcPointer + j] * DecExc0 + DecExc[DecExcPointer + j + 1] * DecExc1;
/*  500 */         Lcr4 += DecExc0 * DecExc0 + DecExc1 * DecExc1;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  507 */     if (Bindx != 0.0F && Findx == 0.0F) {
/*  508 */       Get_Ind(Bindx, Lcr0, Lcr1, Lcr2, Pf);
/*      */     }
/*  510 */     if (Bindx == 0.0F && Findx != 0.0F) {
/*  511 */       Get_Ind(Findx, Lcr0, Lcr3, Lcr4, Pf);
/*      */     }
/*  513 */     if (Bindx != 0 && Findx != 0) {
/*  514 */       if (Lcr1 * Lcr1 * Lcr4 > Lcr3 * Lcr3 * Lcr2) {
/*  515 */         Get_Ind(Bindx, Lcr0, Lcr1, Lcr2, Pf);
/*      */       } else {
/*  517 */         Get_Ind(Findx, Lcr0, Lcr3, Lcr4, Pf);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int Find_B(float[] DecExc, int DecExcIndex, int pitch, int SfrNum) {
/*  545 */     int Indx = 0;
/*  546 */     int DecExcPointer = DecExcIndex + 145 + SfrNum * 60;
/*      */     
/*  548 */     float BestCorr = 0.0F;
/*  549 */     float corr6 = 0.0F, corr5 = 0.0F, corr4 = 0.0F, corr3 = 0.0F, corr2 = 0.0F, corr1 = 0.0F, corr0 = 0.0F;
/*      */     
/*  551 */     if (pitch > 142) {
/*  552 */       pitch = 142;
/*      */     }
/*      */     
/*  555 */     int DecExcCrossPointer = DecExcPointer - pitch - 3;
/*  556 */     for (int j = 0; j < 60; j++) {
/*      */       
/*  558 */       float DecExcPointer_j = DecExc[DecExcPointer + j];
/*      */       
/*  560 */       corr0 += DecExcPointer_j * DecExc[DecExcCrossPointer + j];
/*  561 */       corr1 += DecExcPointer_j * DecExc[DecExcCrossPointer + j - 1];
/*  562 */       corr2 += DecExcPointer_j * DecExc[DecExcCrossPointer + j - 2];
/*  563 */       corr3 += DecExcPointer_j * DecExc[DecExcCrossPointer + j - 3];
/*  564 */       corr4 += DecExcPointer_j * DecExc[DecExcCrossPointer + j - 4];
/*  565 */       corr5 += DecExcPointer_j * DecExc[DecExcCrossPointer + j - 5];
/*  566 */       corr6 += DecExcPointer_j * DecExc[DecExcCrossPointer + j - 6];
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  571 */     if (corr0 > BestCorr) {
/*  572 */       BestCorr = corr0;
/*  573 */       Indx = -(pitch - 3);
/*      */     } 
/*  575 */     if (corr1 > BestCorr) {
/*  576 */       BestCorr = corr1;
/*  577 */       Indx = -(pitch - 2);
/*      */     } 
/*  579 */     if (corr2 > BestCorr) {
/*  580 */       BestCorr = corr2;
/*  581 */       Indx = -(pitch - 1);
/*      */     } 
/*  583 */     if (corr3 > BestCorr) {
/*  584 */       BestCorr = corr3;
/*  585 */       Indx = -pitch;
/*      */     } 
/*  587 */     if (corr4 > BestCorr) {
/*  588 */       BestCorr = corr4;
/*  589 */       Indx = -(pitch + 1);
/*      */     } 
/*  591 */     if (corr5 > BestCorr) {
/*  592 */       BestCorr = corr5;
/*  593 */       Indx = -(pitch + 2);
/*      */     } 
/*  595 */     if (corr6 > BestCorr) {
/*  596 */       BestCorr = corr6;
/*  597 */       Indx = -(pitch + 3);
/*      */     } 
/*      */     
/*  600 */     return Indx;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int Find_F(float[] DecExc, int DecExcIndex, int pitch, int SfrNum) {
/*  623 */     int Indx = 0;
/*  624 */     int max = 240 - SfrNum * 60 - 60;
/*  625 */     int DecExcPointer = DecExcIndex + 145 + SfrNum * 60;
/*      */ 
/*      */ 
/*      */     
/*  629 */     if (pitch > 142) {
/*  630 */       pitch = 142;
/*      */     }
/*  632 */     float BestCorr = 0.0F;
/*  633 */     if (max > pitch + 3) {
/*  634 */       float corr0 = 0.0F, corr1 = 0.0F, corr2 = 0.0F, corr3 = 0.0F, corr4 = 0.0F, corr5 = 0.0F, corr6 = 0.0F;
/*      */       
/*  636 */       int DecExcCrossPointer = DecExcPointer + pitch - 3;
/*  637 */       for (int j = 0; j < 60; j++) {
/*      */         
/*  639 */         float DecExcPointer_j = DecExc[DecExcPointer + j];
/*      */         
/*  641 */         corr0 += DecExcPointer_j * DecExc[DecExcCrossPointer + j];
/*  642 */         corr1 += DecExcPointer_j * DecExc[DecExcCrossPointer + j + 1];
/*  643 */         corr2 += DecExcPointer_j * DecExc[DecExcCrossPointer + j + 2];
/*  644 */         corr3 += DecExcPointer_j * DecExc[DecExcCrossPointer + j + 3];
/*  645 */         corr4 += DecExcPointer_j * DecExc[DecExcCrossPointer + j + 4];
/*  646 */         corr5 += DecExcPointer_j * DecExc[DecExcCrossPointer + j + 5];
/*  647 */         corr6 += DecExcPointer_j * DecExc[DecExcCrossPointer + j + 6];
/*      */       } 
/*      */ 
/*      */       
/*  651 */       if (corr0 > BestCorr) {
/*  652 */         BestCorr = corr0;
/*  653 */         Indx = pitch - 3;
/*      */       } 
/*  655 */       if (corr1 > BestCorr) {
/*  656 */         BestCorr = corr1;
/*  657 */         Indx = pitch - 2;
/*      */       } 
/*  659 */       if (corr2 > BestCorr) {
/*  660 */         BestCorr = corr2;
/*  661 */         Indx = pitch - 1;
/*      */       } 
/*  663 */       if (corr3 > BestCorr) {
/*  664 */         BestCorr = corr3;
/*  665 */         Indx = pitch;
/*      */       } 
/*  667 */       if (corr4 > BestCorr) {
/*  668 */         BestCorr = corr4;
/*  669 */         Indx = pitch + 1;
/*      */       } 
/*  671 */       if (corr5 > BestCorr) {
/*  672 */         BestCorr = corr5;
/*  673 */         Indx = pitch + 2;
/*      */       } 
/*  675 */       if (corr6 > BestCorr) {
/*  676 */         BestCorr = corr6;
/*  677 */         Indx = pitch + 3;
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  683 */       for (int i = pitch - 3; i <= max; i++) {
/*  684 */         int j = DecExcPointer + i;
/*  685 */         float corr = 0.0F;
/*  686 */         for (byte b = 0; b < 60; b++)
/*      */         {
/*  688 */           corr += DecExc[DecExcPointer + b] * DecExc[j + b];
/*      */         }
/*  690 */         if (corr > BestCorr) {
/*  691 */           BestCorr = corr;
/*  692 */           Indx = i;
/*      */         } 
/*      */       } 
/*      */     } 
/*  696 */     return Indx;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void Get_Ind(int Ind, float Ten, float Ccr, float Enr, PFDEF Pf) {
/*  723 */     Pf.Indx = Ind;
/*      */     
/*  725 */     float LpfConstTable_WrkRate = (this.decoderData.WrkRate == 0) ? 0.1875F : 0.25F;
/*      */ 
/*      */     
/*  728 */     if (Ccr * Ccr > 0.25F * Ten * Enr) {
/*  729 */       if (Ccr >= Enr) {
/*  730 */         Pf.Gain = LpfConstTable_WrkRate;
/*      */       } else {
/*  732 */         Pf.Gain = LpfConstTable_WrkRate * Ccr / Enr;
/*      */       } 
/*      */       
/*  735 */       float denom = Ten + 2.0F * Pf.Gain * Ccr + Pf.Gain * Pf.Gain * Enr;
/*      */       
/*  737 */       if (denom < 1.17549435E-38F) {
/*  738 */         Pf.ScGn = 0.0F;
/*      */       } else {
/*  740 */         Pf.ScGn = (float)Math.sqrt((Ten / denom));
/*      */       } 
/*      */     } else {
/*  743 */       Pf.Gain = 0.0F;
/*  744 */       Pf.ScGn = 1.0F;
/*      */     } 
/*      */     
/*  747 */     Pf.Gain *= Pf.ScGn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void Filt_Lpf(float[] ExcBuf, float[] DecExc, int DecExcIndex, PFDEF Pf, int SfrNum) {
/*  769 */     float ScGn = Pf.ScGn;
/*  770 */     float Gain = Pf.Gain;
/*  771 */     int Indx = Pf.Indx;
/*      */     
/*  773 */     int ExcBufIndex = SfrNum * 60;
/*  774 */     int DecExcIndex1 = DecExcIndex + 145 + SfrNum * 60;
/*  775 */     int DecExcIndex2 = DecExcIndex + 145 + SfrNum * 60 + Indx;
/*      */     
/*  777 */     for (int i = 0; i < 60; i++) {
/*  778 */       ExcBuf[ExcBufIndex + i] = DecExc[DecExcIndex1 + i] * ScGn + DecExc[DecExcIndex2 + i] * Gain;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void Fl2Sh(float[] BufF, int Len, byte[] outBuffer, int indexOut) {
/*  798 */     int j = 0;
/*      */     
/*  800 */     for (int i = 0; i < Len; i++) {
/*      */       
/*  802 */       float sample = BufF[i];
/*      */       
/*  804 */       if (sample < -32767.0F) {
/*  805 */         sample = -32767.0F;
/*  806 */       } else if (sample > 32767.0F) {
/*  807 */         sample = 32767.0F;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  812 */       int TempInt = (int)sample;
/*      */       
/*  814 */       outBuffer[indexOut + j] = (byte)(TempInt & 0xFF);
/*  815 */       outBuffer[indexOut + j + 1] = (byte)(TempInt >> 8);
/*      */       
/*  817 */       j += 2;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final float Rand(int[] p) {
/*  834 */     int Temp = p[0];
/*  835 */     Temp &= 0xFFFF;
/*  836 */     Temp = Temp * 521 + 259;
/*  837 */     p[0] = (short)Temp;
/*  838 */     return (short)Temp * 3.0517578E-5F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void Scale(float[] signal, int indexSignal, float SfGain) {
/*  855 */     float AlphaGain = 0.0625F * SfGain;
/*  856 */     float local_Gain = this.decoderData.Gain;
/*      */     
/*  858 */     int iEnd = 60 + indexSignal;
/*      */     
/*  860 */     for (int i = indexSignal; i < iEnd; i++) {
/*      */       
/*  862 */       local_Gain = 0.9375F * local_Gain + AlphaGain;
/*      */       
/*  864 */       signal[i] = signal[i] * local_Gain * 1.0625F;
/*      */     } 
/*      */ 
/*      */     
/*  868 */     this.decoderData.Gain = local_Gain;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void Synt(float[] signal, int indexSig, float[] Lpc, int indexLpc, float[] iir, int indexIir) {
/*  890 */     float Lpc0 = Lpc[indexLpc + 0];
/*  891 */     float Lpc1 = Lpc[indexLpc + 1];
/*  892 */     float Lpc2 = Lpc[indexLpc + 2];
/*  893 */     float Lpc3 = Lpc[indexLpc + 3];
/*  894 */     float Lpc4 = Lpc[indexLpc + 4];
/*  895 */     float Lpc5 = Lpc[indexLpc + 5];
/*  896 */     float Lpc6 = Lpc[indexLpc + 6];
/*  897 */     float Lpc7 = Lpc[indexLpc + 7];
/*  898 */     float Lpc8 = Lpc[indexLpc + 8];
/*  899 */     float Lpc9 = Lpc[indexLpc + 9];
/*      */     
/*  901 */     int iEnd = 60 + indexSig;
/*  902 */     for (int i = indexSig; i < iEnd; i++) {
/*  903 */       float SigFilt = signal[i] + Lpc0 * iir[indexIir - 0] + Lpc1 * iir[indexIir - 1] + Lpc2 * iir[indexIir - 2] + Lpc3 * iir[indexIir - 3] + Lpc4 * iir[indexIir - 4] + Lpc5 * iir[indexIir - 5] + Lpc6 * iir[indexIir - 6] + Lpc7 * iir[indexIir - 7] + Lpc8 * iir[indexIir - 8] + Lpc9 * iir[indexIir - 9];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  914 */       signal[i] = SigFilt;
/*  915 */       iir[++indexIir] = SigFilt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final float Spf(float[] SyntSig, int idxSyntSig, float[] Lpc, int indexLpc, float[] fir, int idxFir, float[] iir, int idxIir) {
/*  947 */     float[] FirCoef = new float[10];
/*  948 */     float[] IirCoef = new float[10];
/*      */ 
/*      */ 
/*      */     
/*  952 */     float pole = 1.0F, zero = 1.0F; int i;
/*  953 */     for (i = 0; i < 10; i++) {
/*  954 */       IirCoef[i] = (pole *= 0.75F) * Lpc[i + indexLpc];
/*  955 */       FirCoef[i] = (zero *= 0.65F) * Lpc[i + indexLpc];
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  962 */     float corr = 0.0F;
/*  963 */     float enr = 0.0F;
/*      */     
/*  965 */     enr = SyntSig[idxSyntSig] * SyntSig[idxSyntSig];
/*      */     
/*  967 */     int loopStart = idxSyntSig;
/*  968 */     int loopEnd = loopStart + 60;
/*      */     
/*  970 */     for (i = loopStart + 1; i < loopEnd; i++) {
/*      */       
/*  972 */       float tmpValue = SyntSig[i];
/*  973 */       corr += tmpValue * SyntSig[i - 1];
/*  974 */       enr += tmpValue * tmpValue;
/*      */     } 
/*      */ 
/*      */     
/*  978 */     if (enr != 0.0D) {
/*  979 */       float TmpPark = corr / enr;
/*      */     } else {
/*      */       
/*  982 */       pole = 0.0F;
/*      */     } 
/*      */     
/*  985 */     float energy = enr;
/*      */ 
/*      */     
/*  988 */     this.decoderData.Park = 0.75F * this.decoderData.Park + 0.25F * pole;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  993 */     float IirCoef0 = IirCoef[0];
/*  994 */     float IirCoef1 = IirCoef[1];
/*  995 */     float IirCoef2 = IirCoef[2];
/*  996 */     float IirCoef3 = IirCoef[3];
/*  997 */     float IirCoef4 = IirCoef[4];
/*  998 */     float IirCoef5 = IirCoef[5];
/*  999 */     float IirCoef6 = IirCoef[6];
/* 1000 */     float IirCoef7 = IirCoef[7];
/* 1001 */     float IirCoef8 = IirCoef[8];
/* 1002 */     float IirCoef9 = IirCoef[9];
/*      */     
/* 1004 */     float FirCoef0 = FirCoef[0];
/* 1005 */     float FirCoef1 = FirCoef[1];
/* 1006 */     float FirCoef2 = FirCoef[2];
/* 1007 */     float FirCoef3 = FirCoef[3];
/* 1008 */     float FirCoef4 = FirCoef[4];
/* 1009 */     float FirCoef5 = FirCoef[5];
/* 1010 */     float FirCoef6 = FirCoef[6];
/* 1011 */     float FirCoef7 = FirCoef[7];
/* 1012 */     float FirCoef8 = FirCoef[8];
/* 1013 */     float FirCoef9 = FirCoef[9];
/*      */ 
/*      */     
/* 1016 */     float PostFilteredEnergy = 0.0F;
/* 1017 */     int j = idxSyntSig + 60;
/* 1018 */     float localPark = this.decoderData.Park;
/*      */     
/* 1020 */     for (i = idxSyntSig; i < j; i++) {
/*      */ 
/*      */ 
/*      */       
/* 1024 */       float FiltSig = SyntSig[i] + IirCoef0 * iir[idxIir] - FirCoef0 * fir[idxFir] + IirCoef1 * iir[idxIir - 1] - FirCoef1 * fir[idxFir - 1] + IirCoef2 * iir[idxIir - 2] - FirCoef2 * fir[idxFir - 2] + IirCoef3 * iir[idxIir - 3] - FirCoef3 * fir[idxFir - 3] + IirCoef4 * iir[idxIir - 4] - FirCoef4 * fir[idxFir - 4] + IirCoef5 * iir[idxIir - 5] - FirCoef5 * fir[idxFir - 5] + IirCoef6 * iir[idxIir - 6] - FirCoef6 * fir[idxFir - 6] + IirCoef7 * iir[idxIir - 7] - FirCoef7 * fir[idxFir - 7] + IirCoef8 * iir[idxIir - 8] - FirCoef8 * fir[idxFir - 8] + IirCoef9 * iir[idxIir - 9] - FirCoef9 * fir[idxFir - 9];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1036 */       fir[++idxFir] = SyntSig[i];
/* 1037 */       iir[++idxIir] = FiltSig;
/*      */ 
/*      */       
/* 1040 */       float tmp = FiltSig - 0.25F * iir[idxIir - 1] * localPark;
/* 1041 */       PostFilteredEnergy += tmp * tmp;
/*      */     } 
/*      */     
/* 1044 */     if (PostFilteredEnergy != 0.0D) {
/* 1045 */       return (float)Math.sqrt((energy / PostFilteredEnergy));
/*      */     }
/* 1047 */     return 1.0F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1244 */   private final int[] Line_Unpk_index = new int[1];
/* 1245 */   private final int[] Line_Unpk_BitStream = new int[192];
/*      */ 
/*      */ 
/*      */   
/*      */   private final void Line_Unpk(byte[] Vinp, int indexInp, int[] Ftyp, short Crc, int[] flag, LINEDEF Line) {
/* 1250 */     int[] BitStream = this.Line_Unpk_BitStream;
/*      */ 
/*      */     
/* 1253 */     short Bound_AcGn = 0;
/* 1254 */     int[] index = this.Line_Unpk_index;
/* 1255 */     index[0] = 0;
/*      */     
/* 1257 */     Line.Crc = Crc;
/*      */     
/* 1259 */     flag[0] = 0;
/*      */     
/* 1261 */     if (Crc != 0) {
/*      */       return;
/*      */     }
/*      */     
/*      */     int i;
/* 1266 */     for (i = 0; i < 192; i++) {
/* 1267 */       BitStream[i] = Vinp[indexInp + (i >> 3)] >> (i & 0x7) & 0x1;
/*      */     }
/*      */     
/* 1270 */     short frame_info = (short)Ser2Par(BitStream, index, 2);
/*      */ 
/*      */     
/* 1273 */     if (frame_info == 3 || frame_info == 2) {
/*      */ 
/*      */       
/* 1276 */       Line.Crc = 1;
/* 1277 */       flag[0] = 5;
/*      */       
/*      */       return;
/*      */     } 
/* 1281 */     if (frame_info == 3) {
/* 1282 */       Ftyp[0] = 0;
/* 1283 */       Line.LspId = 0;
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1288 */     Line.LspId = Ser2Par(BitStream, index, 24);
/*      */ 
/*      */ 
/*      */     
/* 1292 */     if (frame_info == 2) {
/*      */       
/* 1294 */       (Line.Sfs[0]).Mamp = (short)Ser2Par(BitStream, index, 6);
/* 1295 */       Ftyp[0] = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1305 */     Ftyp[0] = 1;
/*      */ 
/*      */     
/* 1308 */     int Temp = Ser2Par(BitStream, index, 7);
/*      */     
/* 1310 */     if (Temp <= 123) {
/* 1311 */       Line.Olp[0] = (short)Temp + 18;
/*      */     }
/*      */     else {
/*      */       
/* 1315 */       flag[0] = 3;
/* 1316 */       Line.Crc = 1;
/*      */       
/*      */       return;
/*      */     } 
/* 1320 */     (Line.Sfs[1]).AcLg = (short)Ser2Par(BitStream, index, 2);
/*      */     
/* 1322 */     Temp = Ser2Par(BitStream, index, 7);
/*      */     
/* 1324 */     if (Temp <= 123) {
/* 1325 */       Line.Olp[1] = (short)Temp + 18;
/*      */     }
/*      */     else {
/*      */       
/* 1329 */       flag[0] = 3;
/* 1330 */       Line.Crc = 1;
/*      */       
/*      */       return;
/*      */     } 
/* 1334 */     (Line.Sfs[3]).AcLg = (short)Ser2Par(BitStream, index, 2);
/*      */     
/* 1336 */     (Line.Sfs[0]).AcLg = 1;
/* 1337 */     (Line.Sfs[2]).AcLg = 1;
/*      */ 
/*      */     
/* 1340 */     for (i = 0; i < 4; i++) {
/*      */       
/* 1342 */       Temp = Ser2Par(BitStream, index, 12);
/*      */       
/* 1344 */       (Line.Sfs[i]).Tran = 0;
/* 1345 */       Bound_AcGn = 170;
/* 1346 */       if (this.decoderData.WrkRate == 0 && Line.Olp[i >> 1] < 58) {
/* 1347 */         (Line.Sfs[i]).Tran = (short)(Temp >> 11);
/* 1348 */         Temp = (int)(Temp & 0x7FFL);
/* 1349 */         Bound_AcGn = 85;
/*      */       } 
/* 1351 */       (Line.Sfs[i]).AcGn = (short)(Temp / 24);
/* 1352 */       if ((Line.Sfs[i]).AcGn < Bound_AcGn) {
/* 1353 */         (Line.Sfs[i]).Mamp = (short)(Temp % 24);
/*      */       }
/*      */       else {
/*      */         
/* 1357 */         flag[0] = 3;
/* 1358 */         Line.Crc = 1;
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     
/* 1364 */     for (i = 0; i < 4; i++) {
/* 1365 */       index[0] = index[0] + 1; (Line.Sfs[i]).Grid = BitStream[index[0]];
/*      */     } 
/* 1367 */     if (this.decoderData.WrkRate == 0) {
/*      */ 
/*      */       
/* 1370 */       if (frame_info != 0) {
/* 1371 */         flag[0] = 2;
/* 1372 */         Line.Crc = 1;
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 1378 */       index[0] = index[0] + 1;
/*      */ 
/*      */       
/* 1381 */       Temp = Ser2Par(BitStream, index, 13);
/* 1382 */       (Line.Sfs[0]).Ppos = Temp / 90 / 9;
/* 1383 */       (Line.Sfs[1]).Ppos = Temp / 90 % 9;
/* 1384 */       (Line.Sfs[2]).Ppos = Temp % 90 / 9;
/* 1385 */       (Line.Sfs[3]).Ppos = Temp % 90 % 9;
/*      */ 
/*      */       
/* 1388 */       (Line.Sfs[0]).Ppos = ((Line.Sfs[0]).Ppos << 16) + Ser2Par(BitStream, index, 16);
/* 1389 */       (Line.Sfs[1]).Ppos = ((Line.Sfs[1]).Ppos << 14) + Ser2Par(BitStream, index, 14);
/* 1390 */       (Line.Sfs[2]).Ppos = ((Line.Sfs[2]).Ppos << 16) + Ser2Par(BitStream, index, 16);
/* 1391 */       (Line.Sfs[3]).Ppos = ((Line.Sfs[3]).Ppos << 14) + Ser2Par(BitStream, index, 14);
/*      */ 
/*      */       
/* 1394 */       (Line.Sfs[0]).Pamp = (short)Ser2Par(BitStream, index, 6);
/* 1395 */       (Line.Sfs[1]).Pamp = (short)Ser2Par(BitStream, index, 5);
/* 1396 */       (Line.Sfs[2]).Pamp = (short)Ser2Par(BitStream, index, 6);
/* 1397 */       (Line.Sfs[3]).Pamp = (short)Ser2Par(BitStream, index, 5);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1423 */       flag[0] = 2;
/* 1424 */       Line.Crc = 1;
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int Ser2Par(int[] Pnt, int[] idxPnt, int Count) {
/* 1453 */     int Rez = 0;
/* 1454 */     int index = idxPnt[0];
/*      */     
/* 1456 */     for (int i = 0; i < Count; i++) {
/* 1457 */       Rez += Pnt[index++] << i;
/*      */     }
/* 1459 */     idxPnt[0] = index;
/* 1460 */     return Rez;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1478 */   private final float[] Gen_Trn_TmpBuf = new float[60];
/*      */ 
/*      */   
/*      */   private final void Gen_Trn(float[] DstBuf, float[] SrcBuf, int index, int period) {
/* 1482 */     float[] TmpBuf = this.Gen_Trn_TmpBuf;
/*      */     
/* 1484 */     int k = period;
/*      */ 
/*      */ 
/*      */     
/* 1488 */     System.arraycopy(SrcBuf, index, TmpBuf, 0, 60);
/* 1489 */     System.arraycopy(SrcBuf, index, DstBuf, index, 60);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1494 */     for (k = period; k < 60; k += period) {
/* 1495 */       for (int i = k; i < 60; i++) {
/* 1496 */         DstBuf[i + index] = DstBuf[i + index] + TmpBuf[i - k];
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void Get_Rez(float[] ResBuf, float[] PrevExc, int idxPrevExc, int Lag) {
/* 1521 */     int idxTemp = idxPrevExc + 145 - Lag - 2 - 3;
/*      */ 
/*      */     
/* 1524 */     if (idxTemp >= 0) {
/* 1525 */       ResBuf[0] = PrevExc[idxTemp];
/* 1526 */       ResBuf[1] = PrevExc[idxTemp + 1];
/* 1527 */       ResBuf[2] = PrevExc[idxTemp + 2];
/*      */     } 
/*      */     
/* 1530 */     ResBuf[3] = PrevExc[idxTemp + 3];
/* 1531 */     ResBuf[4] = PrevExc[idxTemp + 4];
/*      */     
/* 1533 */     int MaxHarm = 61 / Lag;
/* 1534 */     int index = 5;
/* 1535 */     idxTemp = idxPrevExc + 145 - Lag;
/* 1536 */     int loopEnd = idxTemp + Lag;
/* 1537 */     for (int i = 0; i < MaxHarm; i++) {
/* 1538 */       for (int k = idxTemp; k < loopEnd; k++, index++) {
/* 1539 */         ResBuf[index] = PrevExc[k];
/*      */       }
/*      */     } 
/*      */     
/* 1543 */     int size = 62 - index + 2 + 3;
/* 1544 */     idxTemp = idxPrevExc + 145 - Lag;
/* 1545 */     loopEnd = idxTemp + size;
/* 1546 */     for (int j = idxTemp; j < loopEnd; j++, index++) {
/* 1547 */       ResBuf[index] = PrevExc[j];
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1572 */   float[] Decod_Acbk_RezBuf = new float[67];
/*      */ 
/*      */   
/*      */   private final void Decod_Acbk(float[] CurExc, float[] PrevExc, int idxPrevExc, int pitch, int Lid, int Gid, int WrkRate) {
/* 1576 */     float[] RezBuf = this.Decod_Acbk_RezBuf;
/*      */ 
/*      */     
/* 1579 */     int idxsPnt = 0, idxRezBufPointer = 3;
/*      */ 
/*      */     
/* 1582 */     Get_Rez(RezBuf, PrevExc, idxPrevExc, pitch - 1 + Lid);
/*      */     
/* 1584 */     float[] RezBufPointer = RezBuf;
/*      */ 
/*      */     
/* 1587 */     int i = 0;
/* 1588 */     if (this.decoderData.WrkRate == 0) {
/* 1589 */       if (pitch >= 58) i = 1; 
/*      */     } else {
/* 1591 */       i = 1;
/*      */     } 
/*      */     
/* 1594 */     float[] sPnt = AcbkGainTablePtr[i];
/* 1595 */     idxsPnt += Gid * 20;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1600 */     float sPnt0 = sPnt[idxsPnt + 0];
/* 1601 */     float sPnt1 = sPnt[idxsPnt + 1];
/* 1602 */     float sPnt2 = sPnt[idxsPnt + 2];
/* 1603 */     float sPnt3 = sPnt[idxsPnt + 3];
/* 1604 */     float sPnt4 = sPnt[idxsPnt + 4];
/*      */     
/* 1606 */     for (i = 0; i < 60; i++) {
/* 1607 */       CurExc[i] = RezBufPointer[i + 3 + 0] * sPnt0 + RezBufPointer[i + 3 + 1] * sPnt1 + RezBufPointer[i + 3 + 2] * sPnt2 + RezBufPointer[i + 3 + 3] * sPnt3 + RezBufPointer[i + 3 + 4] * sPnt4;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void Lsp_Inq(float[] Lsp, float[] PrevLsp, int packed_indexes, int packet_loss) {
/*      */     float f1;
/*      */     float f2;
/* 1641 */     if (packet_loss == 0) {
/* 1642 */       f1 = 2.0F;
/* 1643 */       f2 = 0.375F;
/*      */     } else {
/*      */       
/* 1646 */       packed_indexes = 0;
/* 1647 */       f1 = 4.0F;
/* 1648 */       f2 = 0.71875F;
/*      */     } 
/*      */     
/*      */     int i;
/* 1652 */     for (i = 2; i >= 0; i--) {
/*      */       
/* 1654 */       int index = packed_indexes & 0xFF;
/* 1655 */       packed_indexes >>= 8;
/* 1656 */       float[] LspQntPnt = fBandQntTable[i];
/*      */ 
/*      */       
/* 1659 */       for (int j = 0; j < fBandInfoTable[i][1]; j++) {
/* 1660 */         Lsp[fBandInfoTable[i][0] + j] = LspQntPnt[index * fBandInfoTable[i][1] + j];
/*      */       }
/*      */     } 
/*      */     
/*      */     byte b;
/* 1665 */     for (b = 0; b < 10; b++) {
/* 1666 */       Lsp[b] = Lsp[b] + (PrevLsp[b] - fLspDcTable[b]) * f2;
/* 1667 */       Lsp[b] = Lsp[b] + fLspDcTable[b];
/*      */     } 
/*      */ 
/*      */     
/* 1671 */     for (i = 0; i < 10; i++) {
/*      */ 
/*      */ 
/*      */       
/* 1675 */       if (Lsp[0] < 3.0F) {
/* 1676 */         Lsp[0] = 3.0F;
/*      */       }
/*      */       
/* 1679 */       if (Lsp[9] > 252.0F) {
/* 1680 */         Lsp[9] = 252.0F;
/*      */       }
/*      */       
/* 1683 */       for (b = 1; b < 10; b++) {
/*      */         
/* 1685 */         float bandwidth = f1 + Lsp[b - 1] - Lsp[b];
/*      */ 
/*      */         
/* 1688 */         if (bandwidth > 0.0F) {
/* 1689 */           bandwidth *= 0.5F;
/* 1690 */           Lsp[b - 1] = Lsp[b - 1] - bandwidth;
/* 1691 */           Lsp[b] = Lsp[b] + bandwidth;
/*      */         } 
/*      */       } 
/*      */       
/* 1695 */       boolean stability_test = false;
/*      */       
/* 1697 */       for (b = 1; b < 10; b++) {
/* 1698 */         if ((Lsp[b] - Lsp[b - 1]) < f1 - 0.03125D) {
/* 1699 */           stability_test = true;
/*      */         }
/*      */       } 
/*      */       
/* 1703 */       if (!stability_test) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void Lsp_Int(float[] QntLpc, float[] CurrLsp, float[] PrevLsp) {
/* 1729 */     for (int i = 0; i < 4; i++) {
/*      */ 
/*      */       
/* 1732 */       float weight1 = (3 - i) * 0.25F;
/* 1733 */       float weight2 = 1.0F - weight1;
/*      */ 
/*      */       
/* 1736 */       for (int j = 0; j < 10; j++) {
/* 1737 */         this.lspParamLsp[j] = weight1 * PrevLsp[j] + weight2 * CurrLsp[j];
/*      */       }
/*      */       
/* 1740 */       LsptoA();
/*      */       
/* 1742 */       System.arraycopy(this.lspParamLsp, 0, QntLpc, 10 * i, 10);
/*      */     } 
/*      */     
/* 1745 */     System.arraycopy(CurrLsp, 0, PrevLsp, 0, 10);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1763 */   private final float[] lspArrayP = new float[6];
/*      */   
/* 1765 */   private final float[] lspArrayQ = new float[6];
/*      */   
/* 1767 */   private final float[] lspParamLsp = new float[10];
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void LsptoA() {
/* 1773 */     float[] P = this.lspArrayP;
/* 1774 */     float[] Q = this.lspArrayQ;
/* 1775 */     float[] Lsp = this.lspParamLsp;
/*      */     
/*      */     int i;
/*      */     
/* 1779 */     for (i = 0; i < 10; i++) {
/*      */       
/* 1781 */       int j = (int)Lsp[i];
/* 1782 */       float cos1 = CosFunction[j];
/* 1783 */       float cos2 = CosFunction[j + 1];
/*      */ 
/*      */       
/* 1786 */       Lsp[i] = ((Lsp[i] - j) * cos2 + ((j + 1) - Lsp[i]) * cos1) * -2.0F;
/*      */     } 
/*      */ 
/*      */     
/* 1790 */     P[0] = 1.0F;
/* 1791 */     P[1] = Lsp[0] + Lsp[2];
/* 1792 */     P[2] = 2.0F + Lsp[0] * Lsp[2];
/*      */     
/* 1794 */     Q[0] = 1.0F;
/* 1795 */     Q[1] = Lsp[1] + Lsp[3];
/* 1796 */     Q[2] = 2.0F + Lsp[1] * Lsp[3];
/*      */ 
/*      */ 
/*      */     
/* 1800 */     for (i = 2; i < 5; i++) {
/*      */ 
/*      */       
/* 1803 */       P[i + 1] = Lsp[2 * i + 0] * P[i] + 2.0F * P[i - 1];
/* 1804 */       Q[i + 1] = Lsp[2 * i + 1] * Q[i] + 2.0F * Q[i - 1];
/*      */ 
/*      */       
/* 1807 */       for (int j = i; j >= 2; j--) {
/* 1808 */         P[j] = P[j] + Lsp[2 * i + 0] * P[j - 1] + P[j - 2];
/* 1809 */         Q[j] = Q[j] + Lsp[2 * i + 1] * Q[j - 1] + Q[j - 2];
/*      */       } 
/*      */ 
/*      */       
/* 1813 */       P[1] = P[1] + Lsp[2 * i + 0];
/* 1814 */       Q[1] = Q[1] + Lsp[2 * i + 1];
/*      */     } 
/*      */ 
/*      */     
/* 1818 */     for (i = 0; i < 5; i++) {
/* 1819 */       Lsp[i] = -(P[i] + P[i + 1] - Q[i] + Q[i + 1]) * 0.5F;
/* 1820 */       Lsp[9 - i] = -(P[i] + P[i + 1] + Q[i] - Q[i + 1]) * 0.5F;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1832 */   private static final float[] fLspDcTable = G723Tables.fLspDcTable;
/* 1833 */   private static final float[] fBand0Tb8 = G723Tables.fBand0Tb8;
/* 1834 */   private static final float[] fBand1Tb8 = G723Tables.fBand1Tb8;
/* 1835 */   private static final float[] fBand2Tb8 = G723Tables.fBand2Tb8;
/* 1836 */   private static final float[][] fBandQntTable = new float[][] { fBand0Tb8, fBand1Tb8, fBand2Tb8 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1842 */   private static final float[] fAcbkGainTable085 = G723Tables.fAcbkGainTable085;
/* 1843 */   private static final float[] fAcbkGainTable170 = G723Tables.fAcbkGainTable170;
/* 1844 */   private static final float[][] AcbkGainTablePtr = new float[][] { fAcbkGainTable085, fAcbkGainTable170 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1849 */   private static final float[] FcbkGainTable = G723Tables.FcbkGainTable;
/* 1850 */   private static final float[] CosFunction = G723Tables.CosFunction;
/* 1851 */   private static final int[][] CombinatorialTable = G723Tables.CombinatorialTable;
/*      */   
/* 1853 */   private static final int[][] fBandInfoTable = new int[][] { { 0, 3 }, { 3, 3 }, { 6, 4 } };
/*      */ 
/*      */ 
/*      */   
/* 1857 */   private static final int[] MaxPosTable = new int[] { 593775, 142506, 593775, 142506 };
/*      */   private static final boolean INCLUDE_POST_FILTER = true;
/*      */   private static final int Rate63 = 0;
/*      */   private static final short CRC = 0;
/*      */   private static final int LpcOrder = 10;
/*      */   private static final int SubFrames = 4;
/*      */   private static final int Frame = 240;
/*      */   private static final int LpcFrame = 180;
/*      */   private static final int SubFrLen = 60;
/*      */   private static final int LspQntBands = 3;
/*      */   private static final int LspCbSize = 256;
/*      */   private static final int LspCbBits = 8;
/*      */   private static final float BandExpFactor = 0.994F;
/*      */   private static final float LspPredictor = 0.375F;
/*      */   private static final float LspPredictor2 = 0.71875F;
/*      */   private static final int ClPitchOrd = 5;
/*      */   private static final int PITCH_INDEX = 2;
/*      */   private static final int Pstep = 1;
/*      */   private static final int PitchMin = 18;
/*      */   private static final int PitchMax = 145;
/*      */   private static final int HIGH_RATE_BITSTREAM = 0;
/*      */   private static final int LOW_RATE_BITSTREAM = 1;
/*      */   private static final int SID_BITSTREAM = 2;
/*      */   private static final int UNTRANSMITTED_BITSTREAM = 3;
/*      */   private static final int G723_OK = 0;
/*      */   private static final int G723_ERR = 1;
/*      */   private static final int G723_RATE_MISMATCH = 2;
/*      */   private static final int G723_ILLEGAL_BITSTREAM = 3;
/*      */   private static final int G723_ILLEGAL_PARAMETER = 4;
/*      */   private static final int G723_VAD_BITSTREAM = 5;
/*      */   private static final int SILENCE_FRAME = 0;
/*      */   private static final int VOICE_FRAME = 1;
/*      */   private static final int SID_FRAME = 2;
/*      */   private static final int NumOfGainLev = 24;
/*      */   private static final int MaxPulseNum = 6;
/*      */   private static final int Sgrid = 2;
/*      */   private static final int DECODER_OUTPUT_SIZE = 240;
/*      */   private static final int NUM_OF_BLOCKS = 4;
/*      */   private static final int ErrMaxNum = 3;
/*      */   private static final float ALPHA = 0.0625F;
/*      */   private static final float FLT_MIN = 1.17549435E-38F;
/*      */   private static final float SHRT_MIN = -32767.0F;
/*      */   private static final float SHRT_MAX = 32767.0F;
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\ibm\media\codec\audio\g723\G723Dec.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */