/*     */ package com.ibm.media.codec.audio.ulaw;
/*     */ 
/*     */ import com.ibm.media.codec.audio.AudioCodec;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.controls.SilenceSuppressionAdapter;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Codec;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaDecoder
/*     */   extends AudioCodec
/*     */ {
/*  24 */   private static final byte[] lutTableL = new byte[256];
/*     */   
/*  26 */   private static final byte[] lutTableH = new byte[256];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaDecoder() {
/*  34 */     this.supportedInputFormats = new AudioFormat[] { new AudioFormat("ULAW") };
/*  35 */     this.defaultOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR") };
/*  36 */     this.PLUGIN_NAME = "Mu-Law Decoder";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Format[] getMatchingOutputFormats(Format in) {
/*  43 */     AudioFormat af = (AudioFormat)in;
/*     */     
/*  45 */     this.supportedOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR", af.getSampleRate(), 16, af.getChannels(), 0, 1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  55 */     return (Format[])this.supportedOutputFormats;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() {
/*  61 */     initTables();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int process(Buffer inputBuffer, Buffer outputBuffer) {
/*  68 */     if (!checkInputBuffer(inputBuffer)) {
/*  69 */       return 1;
/*     */     }
/*     */     
/*  72 */     if (isEOM(inputBuffer)) {
/*  73 */       propagateEOM(outputBuffer);
/*  74 */       return 0;
/*     */     } 
/*     */     
/*  77 */     int channels = this.outputFormat.getChannels();
/*  78 */     byte[] inData = (byte[])inputBuffer.getData();
/*  79 */     byte[] outData = validateByteArraySize(outputBuffer, inData.length * 2);
/*     */     
/*  81 */     int inpLength = inputBuffer.getLength();
/*  82 */     int outLength = 2 * inpLength;
/*     */     
/*  84 */     int inOffset = inputBuffer.getOffset();
/*  85 */     int outOffset = outputBuffer.getOffset();
/*  86 */     for (int i = 0; i < inpLength; i++) {
/*  87 */       int temp = inData[inOffset++] & 0xFF;
/*  88 */       outData[outOffset++] = lutTableL[temp];
/*  89 */       outData[outOffset++] = lutTableH[temp];
/*     */     } 
/*     */     
/*  92 */     updateOutput(outputBuffer, (Format)this.outputFormat, outLength, outputBuffer.getOffset());
/*     */     
/*  94 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private void initTables() {
/*  99 */     for (int i = 0; i < 256; i++) {
/* 100 */       int input = i ^ 0xFFFFFFFF;
/* 101 */       int mantissa = ((input & 0xF) << 3) + 132;
/* 102 */       int segment = (input & 0x70) >> 4;
/* 103 */       int value = mantissa << segment;
/*     */       
/* 105 */       value -= 132;
/*     */       
/* 107 */       if ((input & 0x80) != 0) {
/* 108 */         value = -value;
/*     */       }
/* 110 */       lutTableL[i] = (byte)value;
/* 111 */       lutTableH[i] = (byte)(value >> 8);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getControls() {
/* 117 */     if (((BasicPlugIn)this).controls == null) {
/* 118 */       ((BasicPlugIn)this).controls = (Object[])new javax.media.Control[1];
/* 119 */       ((BasicPlugIn)this).controls[0] = new SilenceSuppressionAdapter((Codec)this, false, false);
/*     */     } 
/* 121 */     return ((BasicPlugIn)this).controls;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\ibm\media\codec\audi\\ulaw\JavaDecoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */