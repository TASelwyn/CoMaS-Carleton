package com.ibm.media.codec.audio.gsm;

public class GsmEncoder {
  public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997,1999.";
  
  protected static final int ORDER = 8;
  
  protected static final int BLOCKSIZE = 160;
  
  protected static final int SBLOCKSIZE = 40;
  
  protected static final int SBLOCKS = 4;
  
  protected static final int SUBSAMPBLOCKS = 4;
  
  protected static final int SUBSAMPSIZE = 13;
  
  protected static final int nPARAMETERS = 77;
  
  private static final int INTERPLAR = 4;
  
  public static final boolean USE_VAD = true;
  
  public static final boolean NO_VAD = false;
  
  public static final boolean GSM_FULL = true;
  
  public static final boolean GSM_LIGHT = false;
  
  public boolean isVADsupported() {
    return this.vadSupportFlag;
  }
  
  public void setVAD(boolean newVAD) {
    this.data_vad_mode = this.vadSupportFlag ? newVAD : false;
  }
  
  public boolean getVAD() {
    return this.data_vad_mode;
  }
  
  public void setSIDupdateRate(int newSIDupdateRate) {
    this.sidUpdateRate = newSIDupdateRate;
  }
  
  protected int sidUpdateRate = 0;
  
  public static final int GSM_SPEECH_FRAME = 0;
  
  public static final int GSM_SID_FRAME = 1;
  
  public static final int GSM_SILENCE_FRAME = 2;
  
  public void setComplexity(boolean newcomplexity) {
    this.data_complexity_mode = newcomplexity;
  }
  
  public boolean getComplexity() {
    return this.data_complexity_mode;
  }
  
  public int getFrameType() {
    return this.frameType;
  }
  
  protected int frameType = 0;
  
  protected boolean vadSupportFlag;
  
  protected float data_buffer;
  
  protected float data_scaledSample;
  
  protected int data_blockNumber;
  
  protected float[] aux_correlations = new float[121];
  
  protected int[] data_Nc = new int[4];
  
  protected float[] data_LAR = new float[8];
  
  protected float[] data_currentxmax = new float[4];
  
  protected int[] data_Parameters = new int[77];
  
  protected int data_pParams;
  
  protected float[] data_wt = new float[50];
  
  protected float[] data_u = new float[9];
  
  protected float[] data_prevLARpp = new float[9];
  
  protected boolean data_complexity_mode;
  
  protected boolean data_vad_mode;
  
  protected float[] data_residual = new float[280];
  
  protected int data_residual_Index;
  
  protected float[] data_input = new float[160];
  
  protected float[] data_first_res = new float[160];
  
  protected float[] data_acf = new float[9];
  
  protected float[] data_r = new float[9];
  
  protected float[] data_LARpp = new float[9];
  
  protected float[] aux_decimated_subsegment = new float[20];
  
  protected float[] aux_decimated_q_frstbase = new float[60];
  
  protected float[] aux_decimated_correlations = new float[41];
  
  protected float[] aux_KK = new float[9];
  
  protected float[] aux_P = new float[9];
  
  protected float[] encode_outsegment = new float[40];
  
  protected int[] encode_pitchArray = new int[1];
  
  protected float[] aux_rp = new float[9];
  
  protected static float[] lut_A = new float[] { 0.0F, 20.0F, 20.0F, 20.0F, 20.0F, 13.637F, 15.0F, 8.334F, 8.824F };
  
  protected static float[] lut_INVA = new float[] { 0.0F, 0.05F, 0.05F, 0.05F, 0.05F, 0.07332991F, 0.06666667F, 0.11999041F, 0.11332729F };
  
  protected static float[] lut_MIC = new float[] { 0.0F, -32.0F, -32.0F, -16.0F, -16.0F, -8.0F, -8.0F, -4.0F, -4.0F };
  
  protected static float[] lut_MAC = new float[] { 0.0F, 31.0F, 31.0F, 15.0F, 15.0F, 7.0F, 7.0F, 3.0F, 3.0F };
  
  protected static float[] lut_B = new float[] { 0.0F, 0.0F, 0.0F, 4.0F, -5.0F, 0.184F, -3.5F, -0.666F, -2.235F };
  
  protected static int[] lut_k_start = new int[] { 0, 13, 27, 40, 160 };
  
  protected static int[] lut_lg2s = new int[32];
  
  private static final int GSM_MAGIC = 13;
  
  static {
    int temp_index = 0;
    lut_lg2s[temp_index++] = 1;
    lut_lg2s[temp_index++] = 2;
    for (int ii = 3; ii <= 6; ii++) {
      for (int jj = 1; jj <= 1 << ii - 2; jj++)
        lut_lg2s[temp_index++] = ii; 
    } 
  }
  
  public void gsm_encoder_close() {}
  
  public void gsm_encoder_reset() {
    this.data_buffer = 0.0F;
    this.data_scaledSample = 0.0F;
    int i;
    for (i = 0; i < this.data_first_res.length; i++)
      this.data_first_res[i] = 0.0F; 
    for (i = 0; i < this.data_residual.length; i++)
      this.data_residual[i] = 0.0F; 
    for (i = 0; i < this.data_u.length; i++)
      this.data_u[i] = 0.0F; 
    for (i = 0; i < this.data_prevLARpp.length; i++)
      this.data_prevLARpp[i] = 0.0F; 
    for (i = 0; i < this.data_wt.length; i++)
      this.data_wt[i] = 0.0F; 
    this.data_complexity_mode = true;
    this.data_vad_mode = false;
    this.data_Parameters[76] = 0;
    this.vadSupportFlag = false;
  }
  
  public void gsm_encode_frame(byte[] input_samples, int input_offset, byte[] output_bits, int output_offset) {
    float[] outsegment = this.encode_outsegment;
    float[] input = this.data_input;
    float[] first_res = this.data_first_res;
    float[] acf = this.data_acf;
    float[] r = this.data_r;
    float[] LARpp = this.data_LARpp;
    int[] pitchArray = this.encode_pitchArray;
    for (int i = 0; i < 160; i++) {
      int temp = input_samples[2 * i + input_offset] & 0xFF | input_samples[2 * i + input_offset + 1] << 8;
      input[i] = temp * 3.0517578E-5F;
    } 
    PreProcessing(input, first_res);
    Autocorrelations(first_res, acf);
    schurRecursion(acf, r);
    rToLAR(r, LARpp);
    latticeFilter(LARpp, first_res);
    this.data_residual_Index = 120;
    for (int blocknumber = 0; blocknumber < 4; blocknumber++) {
      float f1;
      this.data_blockNumber = blocknumber;
      if (this.data_complexity_mode == true) {
        f1 = calculatePitch(first_res, blocknumber * 40, pitchArray);
      } else {
        f1 = calculatePitch_Light(first_res, blocknumber * 40, pitchArray);
      } 
      int pitch = pitchArray[0];
      float gain = calculatePitchGain(f1, pitch);
      int offset = analizeSecondResidual(gain, pitch, first_res, blocknumber * 40, outsegment);
      quantizeSecondResidual(offset, outsegment);
      this.data_residual_Index += 40;
    } 
    if (true == this.data_vad_mode) {
      doVAD();
    } else {
      this.frameType = 0;
    } 
    packBitStream(output_bits, output_offset);
    System.arraycopy(this.data_residual, 160, this.data_residual, 0, 120);
  }
  
  protected void doVAD() {}
  
  void PreProcessing(float[] input, float[] output) {
    float buffer = this.data_buffer;
    float scaledSample = this.data_scaledSample;
    for (int i = 0; i < 160; i++) {
      float temp = scaledSample;
      scaledSample = input[i] * 0.5F;
      output[i] = buffer * -0.85998535F;
      buffer = scaledSample - temp + 0.9989929F * buffer;
      output[i] = output[i] + buffer + 1.0E-15F;
    } 
    this.data_buffer = buffer;
    this.data_scaledSample = scaledSample;
  }
  
  void Autocorrelations(float[] firstResidual, float[] AutoCorrelations) {
    for (int correlNumber = 0; correlNumber <= 8; correlNumber++) {
      float result = 0.0F;
      for (int i = correlNumber; i < 160; i++)
        result += firstResidual[i] * firstResidual[i - correlNumber]; 
      AutoCorrelations[correlNumber] = result;
    } 
  }
  
  void schurRecursion(float[] AutoCorrelations, float[] reflectionCoef) {
    float[] KK = this.aux_KK;
    float[] P = this.aux_P;
    if (AutoCorrelations[0] == 0.0F) {
      for (int i = 1; i <= 8; i++)
        reflectionCoef[i] = 0.0F; 
      return;
    } 
    P[0] = AutoCorrelations[0];
    byte b;
    for (b = 1; b <= 8; b++) {
      KK[9 - b] = AutoCorrelations[b];
      P[b] = AutoCorrelations[b];
    } 
    for (b = 1; b <= 8; b++) {
      float temp = (P[1] > 0.0F) ? P[1] : -P[1];
      if (P[0] < temp) {
        for (int k = b; k <= 8; k++)
          reflectionCoef[k] = 0.0F; 
        return;
      } 
      reflectionCoef[b] = temp / P[0];
      if (P[1] > 0.0D)
        reflectionCoef[b] = -reflectionCoef[b]; 
      if (b == 8)
        return; 
      P[0] = P[0] + P[1] * reflectionCoef[b];
      for (byte b1 = 1; b1 <= 8 - b; b1++) {
        P[b1] = P[b1 + 1] + KK[9 - b1] * reflectionCoef[b];
        KK[9 - b1] = KK[9 - b1] + P[b1 + 1] * reflectionCoef[b];
      } 
    } 
  }
  
  void rToLAR(float[] r, float[] LARpp) {
    float[] MIC = lut_MIC;
    float[] MAC = lut_MAC;
    float[] A = lut_A;
    float[] B = lut_B;
    float[] INVA = lut_INVA;
    int[] Parameters = this.data_Parameters;
    int pParams = 0;
    float[] LAR = this.data_LAR;
    for (int i = 1; i <= 8; i++) {
      float f;
      if (r[i] >= 1.0D) {
        f = MAC[i];
        LAR[i - 1] = 1.625F;
      } else if (r[i] <= -1.0D) {
        f = MIC[i];
        LAR[i - 1] = -1.625F;
      } else {
        float f1, f2, f3, reflectionCoef = r[i];
        if (reflectionCoef > 0.0F) {
          f2 = reflectionCoef;
          f3 = 1.0F;
        } else {
          f2 = -reflectionCoef;
          f3 = -1.0F;
        } 
        if (f2 < 0.675F) {
          f1 = reflectionCoef;
        } else if (f2 < 0.95F) {
          f1 = f3 * (2.0F * f2 - 0.675F);
        } else {
          f1 = f3 * (8.0F * f2 - 6.375F);
        } 
        LAR[i - 1] = f1;
        f = A[i] * f1 + B[i];
        if (f >= 0.0F) {
          f = (float)(f + 0.5D);
        } else {
          f = (float)(f - 0.5D);
        } 
        f = (int)f;
        if (f > MAC[i])
          f = MAC[i]; 
        if (f < MIC[i])
          f = MIC[i]; 
      } 
      f -= MIC[i];
      Parameters[pParams++] = (int)f;
      LARpp[i] = (f + MIC[i] - B[i]) * INVA[i];
    } 
    this.data_pParams = pParams;
  }
  
  void latticeFilter(float[] LARpp, float[] first_res) {
    float[] rp = this.aux_rp;
    float[] u = this.data_u;
    float[] prevLARpp = this.data_prevLARpp;
    int[] k_start = lut_k_start;
    for (int j = 0; j < 4; j++) {
      float PrevCoef = 0.75F - j * 0.25F;
      float PresentCoef = 1.0F - PrevCoef;
      for (int i = 1; i <= 8; i++) {
        float f1, f2, f3, lar = prevLARpp[i] * PrevCoef + LARpp[i] * PresentCoef;
        if (lar > 0.0F) {
          f2 = lar;
          f3 = 1.0F;
        } else {
          f2 = -lar;
          f3 = -1.0F;
        } 
        if (f2 < 0.675F) {
          f1 = lar;
        } else if (f2 < 1.225F) {
          f1 = f3 * (0.5F * f2 + 0.3375F);
        } else {
          f1 = f3 * (0.125F * f2 + 0.796875F);
        } 
        rp[i] = f1;
      } 
      float u0 = u[0], u1 = u[1], u2 = u[2], u3 = u[3];
      float u4 = u[4], u5 = u[5], u6 = u[6], u7 = u[7];
      float rp1 = rp[1], rp2 = rp[2], rp3 = rp[3], rp4 = rp[4];
      float rp5 = rp[5], rp6 = rp[6], rp7 = rp[7], rp8 = rp[8];
      int k_end = k_start[j + 1];
      for (int k = k_start[j]; k < k_end; k++) {
        float di = first_res[k];
        float temp2 = di;
        float temp = u0 + rp1 * di;
        di += rp1 * u0;
        u0 = temp2;
        temp2 = temp;
        temp = u1 + rp2 * di;
        di += rp2 * u1;
        u1 = temp2;
        temp2 = temp;
        temp = u2 + rp3 * di;
        di += rp3 * u2;
        u2 = temp2;
        temp2 = temp;
        temp = u3 + rp4 * di;
        di += rp4 * u3;
        u3 = temp2;
        temp2 = temp;
        temp = u4 + rp5 * di;
        di += rp5 * u4;
        u4 = temp2;
        temp2 = temp;
        temp = u5 + rp6 * di;
        di += rp6 * u5;
        u5 = temp2;
        temp2 = temp;
        temp = u6 + rp7 * di;
        di += rp7 * u6;
        u6 = temp2;
        temp2 = temp;
        temp = u7 + rp8 * di;
        di += rp8 * u7;
        u7 = temp2;
        temp2 = temp;
        first_res[k] = di;
      } 
      u[0] = u0;
      u[1] = u1;
      u[2] = u2;
      u[3] = u3;
      u[4] = u4;
      u[5] = u5;
      u[6] = u6;
      u[7] = u7;
      rp[1] = rp1;
      rp[2] = rp2;
      rp[3] = rp3;
      rp[4] = rp4;
      rp[5] = rp5;
      rp[6] = rp6;
      rp[7] = rp7;
      rp[8] = rp8;
    } 
    System.arraycopy(LARpp, 1, prevLARpp, 1, 8);
  }
  
  private float calculatePitch(float[] subsegment, int seg_offset, int[] pitch) {
    float max_corr = 0.0F;
    float[] correlations = this.aux_correlations;
    int[] Nc = this.data_Nc;
    int blocknumber = this.data_blockNumber;
    int residual_Index = this.data_residual_Index;
    float[] residual = this.data_residual;
    int pParams = this.data_pParams;
    int[] Parameters = this.data_Parameters;
    pitch[0] = 40;
    for (int ii = 40; ii <= 120; ii += 3) {
      float result1 = 0.0F;
      float result2 = 0.0F;
      float result3 = 0.0F;
      float residual_p1 = residual[residual_Index - 1 - ii];
      float residual_p0 = residual[residual_Index - 2 - ii];
      for (int jj = 0; jj < 40; jj += 2) {
        float subsegment_temp0 = subsegment[seg_offset + jj];
        float subsegment_temp1 = subsegment[seg_offset + jj + 1];
        int temp_index = residual_Index + jj - ii;
        float residual_n1 = residual_p1;
        float residual_n2 = residual_p0;
        residual_p1 = residual[temp_index + 1];
        residual_p0 = residual[temp_index];
        result1 += subsegment_temp0 * residual_p0 + subsegment_temp1 * residual_p1;
        result2 += subsegment_temp0 * residual_n1 + subsegment_temp1 * residual_p0;
        result3 += subsegment_temp0 * residual_n2 + subsegment_temp1 * residual_n1;
      } 
      correlations[ii] = result1;
      correlations[ii + 1] = result2;
      correlations[ii + 2] = result3;
    } 
    for (byte b = 40; b <= 120; b++) {
      if (max_corr < correlations[b]) {
        max_corr = correlations[b];
        pitch[0] = b;
      } 
    } 
    Parameters[pParams++] = pitch[0];
    Nc[blocknumber] = pitch[0];
    this.data_pParams = pParams;
    return max_corr;
  }
  
  private float calculatePitch_Light(float[] subsegment, int seg_offset, int[] pitch) {
    float max_corr = 0.0F;
    float[] correlations = this.aux_correlations;
    int[] Nc = this.data_Nc;
    int blocknumber = this.data_blockNumber;
    int residual_Index = this.data_residual_Index;
    float[] residual = this.data_residual;
    int pParams = this.data_pParams;
    int[] Parameters = this.data_Parameters;
    float[] decimated_subsegment = this.aux_decimated_subsegment;
    float[] decimated_q_frstbase = this.aux_decimated_q_frstbase;
    float[] decimated_correlations = this.aux_decimated_correlations;
    decimated_subsegment[0] = 0.5F * (subsegment[seg_offset + 0] + subsegment[seg_offset + 1]);
    int ii, jj;
    for (ii = 1, jj = 2; ii <= 19; ii++, jj += 2)
      decimated_subsegment[ii] = 0.25F * (subsegment[seg_offset + jj - 1] + subsegment[seg_offset + jj + 1]) + 0.5F * subsegment[seg_offset + jj]; 
    decimated_q_frstbase[0] = 0.5F * (residual[residual_Index - 120] + residual[residual_Index - 119]);
    for (ii = 1, jj = -118; ii <= 59; ii++, jj += 2) {
      int index = residual_Index + jj;
      decimated_q_frstbase[ii] = 0.25F * (residual[index - 1] + residual[index + 1]) + 0.5F * residual[index];
    } 
    int decimated_q_frstbase_index = 60;
    for (ii = 20; ii < 60; ii += 2) {
      float result1 = 0.0F, result2 = 0.0F;
      for (jj = 0; jj < 20; jj += 2) {
        float decimatedSubsegmentSample0 = decimated_subsegment[jj];
        float decimatedSubsegmentSample1 = decimated_subsegment[jj + 1];
        int index = decimated_q_frstbase_index + jj - ii;
        result1 += decimatedSubsegmentSample0 * decimated_q_frstbase[index] + decimatedSubsegmentSample1 * decimated_q_frstbase[index + 1];
        result2 += decimatedSubsegmentSample0 * decimated_q_frstbase[index - 1] + decimatedSubsegmentSample1 * decimated_q_frstbase[index];
      } 
      decimated_correlations[ii - 20] = result1;
      decimated_correlations[ii + 1 - 20] = result2;
    } 
    float f1 = 0.0F;
    for (jj = 0; jj < 20; jj++)
      f1 += decimated_subsegment[jj] * decimated_q_frstbase[decimated_q_frstbase_index + jj - ii]; 
    decimated_correlations[ii - 20] = f1;
    int decimated_pitch = 20;
    max_corr = 0.0F;
    for (jj = 20; jj <= 60; jj++) {
      if (max_corr < decimated_correlations[jj - 20]) {
        max_corr = decimated_correlations[jj - 20];
        decimated_pitch = jj;
      } 
    } 
    ii = 2 * decimated_pitch - 1;
    if (ii == 39)
      ii = 40; 
    if (ii == 119)
      ii = 118; 
    f1 = 0.0F;
    float f2 = 0.0F;
    float result3 = 0.0F;
    for (jj = 0; jj <= 39; jj++) {
      int index = residual_Index + jj - ii;
      float subsegmentSample = subsegment[seg_offset + jj];
      f1 += subsegmentSample * residual[index];
      f2 += subsegmentSample * residual[index - 1];
      result3 += subsegmentSample * residual[index - 2];
    } 
    correlations[ii] = f1;
    correlations[ii + 1] = f2;
    correlations[ii + 2] = result3;
    pitch[0] = 40;
    max_corr = 0.0F;
    for (jj = ii; jj <= ii + 2; jj++) {
      if (max_corr < correlations[jj]) {
        max_corr = correlations[jj];
        pitch[0] = jj;
      } 
    } 
    Parameters[pParams++] = pitch[0];
    Nc[blocknumber] = pitch[0];
    this.data_pParams = pParams;
    return max_corr;
  }
  
  private final float calculatePitchGain(float max_corr, int pitch) {
    float f1, residual[] = this.data_residual;
    int residual_Index = this.data_residual_Index;
    int pParams = this.data_pParams;
    int[] Parameters = this.data_Parameters;
    float power = 0.0F;
    int index = residual_Index - pitch;
    for (int i = 0; i < 40; i++) {
      float sample = residual[index++];
      power += sample * sample;
    } 
    if (max_corr <= 0.2D * power) {
      Parameters[pParams++] = 0;
      f1 = 0.1F;
    } else if (max_corr <= 0.5D * power) {
      Parameters[pParams++] = 1;
      f1 = 0.35F;
    } else if (max_corr <= 0.8D * power) {
      Parameters[pParams++] = 2;
      f1 = 0.65F;
    } else {
      Parameters[pParams++] = 3;
      f1 = 1.0F;
    } 
    this.data_pParams = pParams;
    return f1;
  }
  
  private final int analizeSecondResidual(float gain, int pitch, float[] subsegment, int subseg_ofs, float[] outsegment) {
    int Mc = 0;
    float EM = 0.0F;
    float[] wt = this.data_wt;
    int residual_Index = this.data_residual_Index;
    float[] residual = this.data_residual;
    int pParams = this.data_pParams;
    int[] Parameters = this.data_Parameters;
    int residual_index = residual_Index;
    for (int i = 0; i < 40; i++) {
      float pitchPredictSample = gain * residual[residual_index - pitch];
      residual[residual_index] = pitchPredictSample;
      wt[5 + i] = subsegment[subseg_ofs + i] - pitchPredictSample;
      residual_index++;
    } 
    for (int k = 0; k < 40; k++)
      outsegment[k] = -0.016357422F * (wt[k] + wt[k + 10]) + -0.045654297F * (wt[k + 1] + wt[k + 9]) + 0.25073242F * (wt[k + 3] + wt[k + 7]) + 0.70080566F * (wt[k + 4] + wt[k + 6]) + wt[k + 5]; 
    for (int j = 0; j <= 3; j++) {
      float temp = 0.0F;
      int index = j;
      for (int m = 0; m <= 12; m++) {
        float sample = outsegment[index];
        index += 3;
        temp += sample * sample;
      } 
      if (EM < temp) {
        Mc = j;
        EM = temp;
      } 
    } 
    Parameters[pParams++] = Mc;
    this.data_pParams = pParams;
    return Mc;
  }
  
  private final void quantizeSecondResidual(int Mc, float[] outsegment) {
    float f1;
    int blocknumber = this.data_blockNumber;
    float[] currentxmax = this.data_currentxmax;
    float[] residual = this.data_residual;
    int residual_Index = this.data_residual_Index;
    int[] lg2s = lut_lg2s;
    int pParams = this.data_pParams;
    int[] Parameters = this.data_Parameters;
    float xmax = 0.0F;
    int i;
    for (i = 0; i < 13; i++) {
      float temp = outsegment[Mc + i * 3];
      if (temp > xmax) {
        xmax = temp;
      } else if (-temp > xmax) {
        xmax = -temp;
      } 
    } 
    currentxmax[blocknumber] = xmax;
    if (xmax < 0.015625F) {
      int tempint = (int)(xmax * 1024.0F);
      Parameters[pParams++] = tempint;
      f1 = (31 + tempint * 32);
      int xmaxc = (int)(xmax * 1024.0F);
    } else {
      int j = (int)(32768.0F * xmax);
      j >>= 10;
      if (j < 31) {
        i = lg2s[j];
        int k = (int)((i << 3) + xmax * (1024 >> i));
        Parameters[pParams++] = k;
        f1 = ((256 << i) + (32 << i) - 1 + (k - 8 - 8 * i) * (32 << i));
      } else {
        Parameters[pParams++] = 63;
        byte b = 63;
        f1 = 32767.0F;
      } 
    } 
    float div_xmaxp = 1.0F / f1;
    for (i = 0; i < 13; i++) {
      int j = (int)(outsegment[Mc + i * 3] * div_xmaxp * 262144.0F);
      if (j > 7) {
        j = 7;
      } else if (j < -7) {
        j = -7;
      } 
      j = j + 7 >> 1;
      Parameters[pParams++] = j;
      residual[residual_Index + Mc + i * 3] = residual[residual_Index + Mc + i * 3] + (0.25F * j - 0.875F) * 3.0517578E-5F * f1;
    } 
    this.data_pParams = pParams;
  }
  
  protected void packBitStream(byte[] outputBits, int output_offset) {
    int[] Params = this.data_Parameters;
    int outPtr = output_offset;
    outputBits[outPtr++] = (byte)(0xD0 | Params[0] >> 2 & 0xF);
    outputBits[outPtr++] = (byte)((Params[0] & 0x3) << 6 | Params[1] & 0x3F);
    outputBits[outPtr++] = (byte)((Params[2] & 0x1F) << 3 | Params[3] >> 2 & 0x7);
    outputBits[outPtr++] = (byte)((Params[3] & 0x3) << 6 | (Params[4] & 0xF) << 2 | Params[5] >> 2 & 0x3);
    outputBits[outPtr++] = (byte)((Params[5] & 0x3) << 6 | (Params[6] & 0x7) << 3 | Params[7] & 0x7);
    int paramPtr = 8;
    for (int blocknum = 0; blocknum < 4; blocknum++) {
      outputBits[outPtr++] = (byte)((Params[paramPtr++] & 0x7F) << 1 | Params[paramPtr] >> 1 & 0x1);
      outputBits[outPtr++] = (byte)((Params[paramPtr++] & 0x1) << 7 | (Params[paramPtr++] & 0x3) << 5 | Params[paramPtr] >> 1 & 0x1F);
      outputBits[outPtr++] = (byte)((Params[paramPtr++] & 0x1) << 7 | (Params[paramPtr++] & 0x7) << 4 | (Params[paramPtr++] & 0x7) << 1 | Params[paramPtr] >> 2 & 0x1);
      outputBits[outPtr++] = (byte)((Params[paramPtr++] & 0x3) << 6 | (Params[paramPtr++] & 0x7) << 3 | Params[paramPtr++] & 0x7);
      outputBits[outPtr++] = (byte)((Params[paramPtr++] & 0x7) << 5 | (Params[paramPtr++] & 0x7) << 2 | Params[paramPtr] >> 1 & 0x3);
      outputBits[outPtr++] = (byte)((Params[paramPtr++] & 0x1) << 7 | (Params[paramPtr++] & 0x7) << 4 | (Params[paramPtr++] & 0x7) << 1 | Params[paramPtr] >> 2 & 0x1);
      outputBits[outPtr++] = (byte)((Params[paramPtr++] & 0x3) << 6 | (Params[paramPtr++] & 0x7) << 3 | Params[paramPtr++] & 0x7);
    } 
  }
}
