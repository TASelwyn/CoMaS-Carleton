/*     */ package com.ibm.media.codec.audio.g723;
/*     */ 
/*     */ import com.sun.media.controls.PacketSizeAdapter;
/*     */ import javax.media.Codec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PacketSizeAdapter
/*     */   extends PacketSizeAdapter
/*     */ {
/*     */   public PacketSizeAdapter(Codec newOwner, int newPacketSize, boolean newIsSetable) {
/* 114 */     super(newOwner, newPacketSize, newIsSetable);
/*     */   }
/*     */ 
/*     */   
/*     */   public int setPacketSize(int numBytes) {
/* 119 */     int numOfPackets = numBytes / 24;
/*     */     
/* 121 */     if (numOfPackets < 1) {
/* 122 */       numOfPackets = 1;
/*     */     }
/*     */     
/* 125 */     if (numOfPackets > 100) {
/* 126 */       numOfPackets = 100;
/*     */     }
/* 128 */     this.packetSize = numOfPackets * 24;
/*     */ 
/*     */     
/* 131 */     ((Packetizer)this.owner).setPacketSize(this.packetSize);
/*     */     
/* 133 */     return this.packetSize;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\ibm\media\codec\audio\g723\PacketSizeAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */