/*    */ package com.ibm.media.codec.audio.gsm;
/*    */ 
/*    */ import com.sun.media.BasicPlugIn;
/*    */ import com.sun.media.controls.SilenceSuppressionAdapter;
/*    */ import javax.media.Codec;
/*    */ import javax.media.ResourceUnavailableException;
/*    */ import javax.media.format.AudioFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaDecoder_ms
/*    */   extends JavaDecoder
/*    */ {
/*    */   public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997,1999.";
/*    */   
/*    */   public JavaDecoder_ms() {
/* 42 */     this.supportedInputFormats = new AudioFormat[] { new AudioFormat("gsm/ms") };
/* 43 */     this.PLUGIN_NAME = "GSM MS Decoder";
/*    */   }
/*    */   
/*    */   public void open() throws ResourceUnavailableException {
/* 47 */     this.decoder = new GsmDecoder_ms();
/* 48 */     this.decoder.decoderInit();
/*    */   }
/*    */ 
/*    */   
/*    */   protected int calculateOutputSize(int inputSize) {
/* 53 */     return inputSize / 65 * 640;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void decode(byte[] inpData, int readPtr, byte[] outData, int writePtr, int inpLength) {
/* 58 */     int numberOfFrames = inpLength / 65;
/*    */     
/* 60 */     for (int n = 1; n <= numberOfFrames; n++, writePtr += 640, readPtr += 65) {
/* 61 */       this.decoder.decodeFrame(inpData, readPtr, outData, writePtr);
/*    */     }
/*    */   }
/*    */   
/*    */   public Object[] getControls() {
/* 66 */     if (((BasicPlugIn)this).controls == null) {
/* 67 */       ((BasicPlugIn)this).controls = (Object[])new javax.media.Control[1];
/* 68 */       ((BasicPlugIn)this).controls[0] = new SilenceSuppressionAdapter((Codec)this, false, false);
/*    */     } 
/* 70 */     return ((BasicPlugIn)this).controls;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\ibm\media\codec\audio\gsm\JavaDecoder_ms.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */