/*     */ package com.ibm.media.codec.audio;
/*     */ 
/*     */ import com.sun.media.BasicCodec;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Many2one
/*     */   extends BasicCodec
/*     */ {
/*     */   public String getName() {
/*  21 */     return "many frames to one converter";
/*     */   }
/*     */   
/*  24 */   int counter = 0;
/*     */   boolean flagEOM = false;
/*  26 */   Format af = (Format)new AudioFormat("LINEAR", 8000.0D, 16, 1, 0, 1, -1, -1.0D, Byte.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format[] getSupportedInputFormats() {
/*  37 */     Format[] fmt = new Format[1];
/*  38 */     fmt[0] = this.af;
/*  39 */     return fmt;
/*     */   }
/*     */   
/*     */   public Format[] getSupportedOutputFormats(Format in) {
/*  43 */     Format[] fmt = new Format[1];
/*  44 */     fmt[0] = this.af;
/*  45 */     return fmt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int process(Buffer inputBuffer, Buffer outputBuffer) {
/*  55 */     if (this.flagEOM) {
/*  56 */       outputBuffer.setLength(0);
/*  57 */       outputBuffer.setEOM(true);
/*     */       
/*  59 */       this.flagEOM = false;
/*  60 */       return 0;
/*     */     } 
/*     */     
/*  63 */     if (outputBuffer.isDiscard()) {
/*  64 */       outputBuffer.setLength(0);
/*  65 */       outputBuffer.setOffset(0);
/*     */     } 
/*     */ 
/*     */     
/*  69 */     if (inputBuffer.isEOM()) {
/*     */ 
/*     */       
/*  72 */       if (outputBuffer.getLength() > 0) {
/*  73 */         this.flagEOM = true;
/*  74 */         return 2;
/*     */       } 
/*     */       
/*  77 */       outputBuffer.setLength(0);
/*  78 */       outputBuffer.setEOM(true);
/*  79 */       return 0;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     if (outputBuffer.getData() == null) {
/*  87 */       outputBuffer.setData(new byte[10000]);
/*     */     }
/*     */     
/*  90 */     System.arraycopy(inputBuffer.getData(), inputBuffer.getOffset(), outputBuffer.getData(), outputBuffer.getLength(), inputBuffer.getLength());
/*     */ 
/*     */ 
/*     */     
/*  94 */     outputBuffer.setLength(outputBuffer.getLength() + inputBuffer.getLength());
/*     */ 
/*     */     
/*  97 */     if (++this.counter == 5) {
/*  98 */       this.counter = 0;
/*  99 */       outputBuffer.setFormat(this.af);
/* 100 */       return 0;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 105 */     return 4;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\ibm\media\codec\audio\Many2one.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */