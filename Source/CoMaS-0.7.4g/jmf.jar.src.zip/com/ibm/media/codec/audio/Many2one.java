package com.ibm.media.codec.audio;

import com.sun.media.BasicCodec;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.format.AudioFormat;

public class Many2one extends BasicCodec {
  public String getName() {
    return "many frames to one converter";
  }
  
  int counter = 0;
  
  boolean flagEOM = false;
  
  Format af = (Format)new AudioFormat("LINEAR", 8000.0D, 16, 1, 0, 1, -1, -1.0D, Byte.class);
  
  public Format[] getSupportedInputFormats() {
    Format[] fmt = new Format[1];
    fmt[0] = this.af;
    return fmt;
  }
  
  public Format[] getSupportedOutputFormats(Format in) {
    Format[] fmt = new Format[1];
    fmt[0] = this.af;
    return fmt;
  }
  
  public int process(Buffer inputBuffer, Buffer outputBuffer) {
    if (this.flagEOM) {
      outputBuffer.setLength(0);
      outputBuffer.setEOM(true);
      this.flagEOM = false;
      return 0;
    } 
    if (outputBuffer.isDiscard()) {
      outputBuffer.setLength(0);
      outputBuffer.setOffset(0);
    } 
    if (inputBuffer.isEOM()) {
      if (outputBuffer.getLength() > 0) {
        this.flagEOM = true;
        return 2;
      } 
      outputBuffer.setLength(0);
      outputBuffer.setEOM(true);
      return 0;
    } 
    if (outputBuffer.getData() == null)
      outputBuffer.setData(new byte[10000]); 
    System.arraycopy(inputBuffer.getData(), inputBuffer.getOffset(), outputBuffer.getData(), outputBuffer.getLength(), inputBuffer.getLength());
    outputBuffer.setLength(outputBuffer.getLength() + inputBuffer.getLength());
    if (++this.counter == 5) {
      this.counter = 0;
      outputBuffer.setFormat(this.af);
      return 0;
    } 
    return 4;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\Many2one.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */