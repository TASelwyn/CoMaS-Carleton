/*     */ package com.ibm.media.codec.audio.gsm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GsmVadEncoder
/*     */   extends GsmEncoder
/*     */ {
/*     */   private static final float DIST_TH = 0.05F;
/*     */   private static final int PITCH_TH = 4;
/*     */   private static final int PITCH_PRECISION = 2;
/*     */   private static final float PTH = 6.984919E-5F;
/*     */   private static final float MARGIN = 0.018626451F;
/*     */   private static final float PLEV = 1.8626451E-4F;
/*     */   private static final float FAC = 3.0F;
/*     */   private static final int ADP = 8;
/*     */   private static final float INC = 16.0F;
/*     */   private static final float DEC = 32.0F;
/*     */   private static final float EPSILON = 1.0E-15F;
/*     */   private static final int NEW_SID = -1;
/*     */   private static final float MAX_LAR = 1.625F;
/*     */   private static final int E_PTH = 19;
/*     */   private static final int M_PTH = 18750;
/*     */   private static final int E_MARGIN = 27;
/*     */   private static final int M_MARGIN = 19531;
/*     */   private static final int E_PLEV = 20;
/*     */   private static final int M_PLEV = 25000;
/*     */   public static final int UPDATE_RATE = 10;
/*     */   private static final int nFRAMES = 4;
/*     */   int vad_sincelastSID;
/*     */   int vad_sinceSPEECHburst;
/*  46 */   float[][] vad_prevLARs = new float[4][8];
/*  47 */   float[][] vad_prevxmax = new float[4][4];
/*  48 */   int[] vad_prevSID = new int[77];
/*     */   int vad_hangover;
/*     */   int vad_LARindex;
/*     */   boolean vad_SP;
/*  52 */   float[] vad_LAR = new float[8];
/*  53 */   float[] vad_currentxmax = new float[4];
/*     */   
/*     */   int vad_blocknumber;
/*     */   
/*     */   int vad_lastsent;
/*     */   
/*     */   boolean vad_prevSP;
/*  60 */   float[] vad_rvad = new float[9];
/*  61 */   float[][] vad_sacf = new float[3][9];
/*  62 */   float[][] vad_sav0 = new float[4][9];
/*     */   
/*     */   int vad_sacfPt;
/*     */   int vad_sav0Pt;
/*     */   float vad_lastdm;
/*     */   int vad_oldlagcount;
/*     */   int vad_veryoldlagcount;
/*     */   int vad_adaptcount;
/*     */   int vad_burstcount;
/*     */   int vad_hangcount;
/*     */   int vad_oldlag;
/*     */   float vad_thvad;
/*     */   
/*     */   protected void doVAD() {
/*  76 */     vad_calculations();
/*     */     
/*  78 */     DisConTrans();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gsm_encoder_reset() {
/*  88 */     super.gsm_encoder_reset();
/*  89 */     this.vadSupportFlag = true;
/*  90 */     this.vad_sincelastSID = 24;
/*  91 */     this.vad_sinceSPEECHburst = 0;
/*     */     
/*  93 */     for (int i = 0; i < this.vad_prevLARs.length; i++) {
/*  94 */       for (int i2 = 0; i2 < (this.vad_prevLARs[i]).length; i2++) {
/*  95 */         this.vad_prevLARs[i][i2] = 0.0F;
/*     */       }
/*     */     } 
/*  98 */     for (int j = 0; j < this.vad_prevxmax.length; j++) {
/*  99 */       this.vad_prevxmax[j][0] = 0.0F;
/* 100 */       this.vad_prevxmax[j][1] = 0.0F;
/* 101 */       this.vad_prevxmax[j][2] = 0.0F;
/* 102 */       this.vad_prevxmax[j][3] = 0.0F;
/*     */     } 
/*     */ 
/*     */     
/* 106 */     for (int k = 0; k < this.vad_prevSID.length; k++) {
/* 107 */       this.vad_prevSID[k] = 0;
/*     */     }
/* 109 */     this.vad_prevSID[0] = 2;
/* 110 */     this.vad_prevSID[1] = 28;
/* 111 */     this.vad_prevSID[2] = 18;
/* 112 */     this.vad_prevSID[3] = 12;
/* 113 */     this.vad_prevSID[4] = 7;
/* 114 */     this.vad_prevSID[5] = 5;
/* 115 */     this.vad_prevSID[6] = 3;
/* 116 */     this.vad_prevSID[7] = 2;
/*     */     
/* 118 */     this.vad_hangover = 1;
/* 119 */     this.vad_LARindex = 0;
/* 120 */     this.vad_SP = true;
/* 121 */     this.vad_prevSP = true;
/* 122 */     this.vad_lastsent = 0;
/* 123 */     this.vad_rvad[0] = 6.0F;
/* 124 */     this.vad_rvad[1] = -4.0F;
/* 125 */     this.vad_rvad[2] = 1.0F;
/*     */     
/* 127 */     for (int m = 3; m < this.vad_rvad.length; m++) {
/* 128 */       this.vad_rvad[m] = 0.0F;
/*     */     }
/* 130 */     for (int n = 0; n < this.vad_sacf.length; n++) {
/* 131 */       for (int i2 = 0; i2 < (this.vad_sacf[n]).length; i2++)
/* 132 */         this.vad_sacf[n][i2] = 0.0F; 
/*     */     } 
/* 134 */     for (int i1 = 0; i1 < this.vad_sav0.length; i1++) {
/* 135 */       for (int i2 = 0; i2 < (this.vad_sav0[i1]).length; i2++)
/* 136 */         this.vad_sav0[i1][i2] = 0.0F; 
/*     */     } 
/* 138 */     this.vad_sacfPt = 0;
/* 139 */     this.vad_sav0Pt = 0;
/* 140 */     this.vad_lastdm = 0.0F;
/* 141 */     this.vad_oldlagcount = 0;
/* 142 */     this.vad_veryoldlagcount = 0;
/* 143 */     this.vad_adaptcount = 0;
/* 144 */     this.vad_burstcount = 0;
/* 145 */     this.vad_hangcount = -1;
/* 146 */     this.vad_oldlag = 40;
/* 147 */     this.vad_thvad = 2.3283064E-4F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void vad_calculations() {
/* 154 */     int[] lg2s = GsmEncoder.lut_lg2s;
/*     */     
/* 156 */     boolean vadF = VAD(this.data_acf, this.data_Nc);
/*     */     
/* 158 */     if (vadF) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 163 */       this.vad_sinceSPEECHburst = 0;
/* 164 */       this.vad_SP = true;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 169 */       this.vad_LARindex = (this.vad_LARindex == 3) ? 0 : (this.vad_LARindex + 1);
/*     */       int i;
/* 171 */       for (i = 0; i < 8; i++) {
/* 172 */         this.vad_prevLARs[this.vad_LARindex][i] = this.vad_LAR[i];
/*     */       }
/* 174 */       for (i = 0; i < 4; i++) {
/* 175 */         this.vad_prevxmax[this.vad_LARindex][i] = this.vad_currentxmax[i];
/*     */       }
/* 177 */       if (this.vad_sincelastSID < 24) {
/* 178 */         this.vad_sincelastSID++;
/*     */       }
/*     */     } else {
/*     */       
/* 182 */       if (this.vad_sinceSPEECHburst++ == 0) {
/* 183 */         this.vad_hangover = (this.vad_sincelastSID >= 24) ? 1 : 0;
/* 184 */       } else if (this.vad_sinceSPEECHburst > 4) {
/* 185 */         this.vad_hangover = -1;
/*     */       } 
/* 187 */       if (this.vad_hangover == 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 192 */         this.vad_LARindex = (this.vad_LARindex == 3) ? 0 : (this.vad_LARindex + 1); byte b;
/* 193 */         for (b = 0; b < 8; b++)
/* 194 */           this.vad_prevLARs[this.vad_LARindex][b] = this.data_LAR[b]; 
/* 195 */         for (b = 0; b < 4; b++)
/* 196 */           this.vad_prevxmax[this.vad_LARindex][b] = this.vad_currentxmax[b]; 
/* 197 */         if (this.vad_sincelastSID < 24)
/* 198 */           this.vad_sincelastSID++; 
/* 199 */         this.vad_SP = true;
/*     */       }
/* 201 */       else if (this.vad_hangover == 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 206 */         this.vad_LARindex = (this.vad_LARindex == 3) ? 0 : (this.vad_LARindex + 1); byte b;
/* 207 */         for (b = 0; b < 8; b++)
/* 208 */           this.vad_prevLARs[this.vad_LARindex][b] = this.data_LAR[b]; 
/* 209 */         for (b = 0; b < 4; b++)
/* 210 */           this.vad_prevxmax[this.vad_LARindex][b] = this.vad_currentxmax[b]; 
/* 211 */         for (b = 0; b < 77; b++)
/* 212 */           this.data_Parameters[b] = this.vad_prevSID[b]; 
/* 213 */         if (this.vad_sincelastSID < 24)
/* 214 */           this.vad_sincelastSID++; 
/* 215 */         this.vad_SP = false;
/*     */       } else {
/*     */         int i;
/*     */         
/* 219 */         for (i = 1; i <= 8; i++) {
/*     */           
/* 221 */           float LARinter = 0.25F * (this.vad_prevLARs[0][i - 1] + this.vad_prevLARs[1][i - 1] + this.vad_prevLARs[2][i - 1] + this.vad_prevLARs[3][i - 1]);
/*     */ 
/*     */ 
/*     */           
/* 225 */           LARinter = GsmEncoder.lut_A[i] * LARinter + GsmEncoder.lut_B[i];
/* 226 */           if (LARinter > GsmEncoder.lut_MAC[i])
/* 227 */             LARinter = GsmEncoder.lut_MAC[i]; 
/* 228 */           if (LARinter < GsmEncoder.lut_MIC[i])
/* 229 */             LARinter = GsmEncoder.lut_MIC[i]; 
/* 230 */           this.vad_prevSID[i - 1] = (int)(LARinter - GsmEncoder.lut_MIC[i] + 0.5F);
/*     */         } 
/*     */         
/* 233 */         float XMAXinter = 0.0F;
/*     */         
/* 235 */         for (i = 0; i < 4; i++) {
/* 236 */           for (int k = 0; k < 4; k++)
/* 237 */             XMAXinter += this.vad_prevxmax[k][i]; 
/*     */         } 
/* 239 */         XMAXinter *= 0.0625F;
/*     */         
/* 241 */         if (XMAXinter < 0.015625D) {
/* 242 */           XMAXinter *= 1024.0F;
/*     */         } else {
/*     */           
/* 245 */           int temp = (int)(32768.0D * XMAXinter);
/* 246 */           temp >>= 10;
/* 247 */           if (temp < 31) {
/*     */             
/* 249 */             i = lg2s[temp];
/* 250 */             XMAXinter = (i << 3) + XMAXinter * (1024 >> i);
/*     */           }
/*     */           else {
/*     */             
/* 254 */             XMAXinter = 63.0F;
/*     */           } 
/*     */         } 
/* 257 */         for (i = 0; i < 4; i++) {
/* 258 */           this.vad_prevSID[11 + 17 * i] = (int)XMAXinter;
/*     */         }
/*     */ 
/*     */         
/* 262 */         this.vad_LARindex = (this.vad_LARindex == 3) ? 0 : (this.vad_LARindex + 1);
/* 263 */         for (i = 0; i < 8; i++)
/* 264 */           this.vad_prevLARs[this.vad_LARindex][i] = this.data_LAR[i]; 
/* 265 */         for (i = 0; i < 4; i++) {
/* 266 */           this.vad_prevxmax[this.vad_LARindex][i] = this.vad_currentxmax[i];
/*     */         }
/* 268 */         for (i = 0; i < 77; i++)
/* 269 */           this.data_Parameters[i] = this.vad_prevSID[i]; 
/* 270 */         this.vad_sincelastSID = 0;
/* 271 */         this.vad_SP = false;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void DisConTrans() {
/* 281 */     boolean sendF = false;
/*     */ 
/*     */     
/* 284 */     if (this.vad_SP) {
/* 285 */       this.frameType = 0;
/* 286 */       sendF = true;
/* 287 */     } else if (!this.vad_SP && this.vad_prevSP) {
/* 288 */       this.frameType = 1;
/* 289 */       sendF = true;
/*     */     } 
/*     */     
/* 292 */     this.vad_prevSP = this.vad_SP;
/*     */ 
/*     */     
/* 295 */     if (sendF) {
/* 296 */       this.vad_lastsent = 0;
/*     */     
/*     */     }
/* 299 */     else if (this.sidUpdateRate > 0 && ++this.vad_lastsent >= this.sidUpdateRate) {
/*     */       
/* 301 */       this.vad_lastsent = 0;
/* 302 */       sendF = true;
/* 303 */       this.frameType = 1;
/*     */     } else {
/* 305 */       for (int i = 0; i < 77; i++) {
/* 306 */         this.data_Parameters[i] = 0;
/*     */       }
/* 308 */       this.frameType = 2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 338 */   float[] vadAux_av0 = new float[9];
/* 339 */   float[] vadAux_av1 = new float[9];
/* 340 */   float[] vadAux_refcoef = new float[9];
/* 341 */   float[] vadAux_rav1 = new float[9];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean VAD(float[] ACF, int[] Nc) {
/* 347 */     float[] av0 = this.vadAux_av0;
/* 348 */     float[] av1 = this.vadAux_av1;
/* 349 */     float[] refcoef = this.vadAux_refcoef;
/* 350 */     float[] rav1 = this.vadAux_rav1;
/*     */ 
/*     */ 
/*     */     
/* 354 */     float pvad = adaptiveFiltering(ACF);
/*     */     
/* 356 */     ACFaverage(ACF, av0, av1);
/*     */     
/* 358 */     schurRecursion(av1, refcoef);
/*     */     
/* 360 */     Step_up(refcoef, rav1);
/*     */     
/* 362 */     boolean statF = SpectralComp(rav1, av0);
/*     */     
/* 364 */     boolean pitchF = PitchDetect();
/*     */     
/* 366 */     ThresAdapt(pitchF, statF, ACF, rav1, pvad);
/*     */     
/* 368 */     boolean vadF = vad_decision(pvad);
/*     */     
/* 370 */     pitchCounting(Nc);
/*     */     
/* 372 */     return vadF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   float adaptiveFiltering(float[] ACF) {
/* 384 */     if (ACF[0] < 1.0E-15F) {
/* 385 */       float pvad = 0.0F;
/* 386 */       ACF[0] = 0.0F;
/* 387 */       return pvad;
/*     */     } 
/*     */     
/* 390 */     float f = 0.0F;
/* 391 */     for (int i = 1; i <= 8; i++) {
/* 392 */       f += this.vad_rvad[i] * ACF[i];
/*     */     }
/* 394 */     f = 2.0F * f + this.vad_rvad[0] * ACF[0];
/*     */     
/* 396 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void ACFaverage(float[] ACF, float[] av0, float[] av1) {
/* 406 */     int sacfPt = this.vad_sacfPt;
/* 407 */     int sav0Pt = this.vad_sav0Pt;
/*     */     
/* 409 */     for (int i = 0; i <= 8; i++) {
/* 410 */       av0[i] = ACF[i] + this.vad_sacf[0][i] + this.vad_sacf[1][i] + this.vad_sacf[2][i];
/* 411 */       this.vad_sacf[sacfPt][i] = ACF[i];
/* 412 */       av1[i] = this.vad_sav0[sav0Pt][i];
/* 413 */       this.vad_sav0[sav0Pt][i] = av0[i];
/*     */     } 
/*     */     
/* 416 */     this.vad_sacfPt = (sacfPt == 2) ? 0 : (sacfPt + 1);
/* 417 */     this.vad_sav0Pt = (sav0Pt == 3) ? 0 : (sav0Pt + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 434 */   float[] vadAux_coef = new float[9];
/* 435 */   float[] vadAux_tempcoef = new float[9];
/* 436 */   float[] vadAux_aav1 = new float[9];
/*     */ 
/*     */   
/*     */   void Step_up(float[] refcoef, float[] rav1) {
/* 440 */     float[] coef = this.vadAux_coef;
/* 441 */     float[] tempcoef = this.vadAux_tempcoef;
/* 442 */     float[] aav1 = this.vadAux_aav1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 449 */     coef[0] = 1.0F;
/* 450 */     coef[1] = refcoef[1];
/*     */     
/* 452 */     for (int m = 2; m < 9; m++) {
/*     */       int i;
/* 454 */       for (i = 1; i < m; i++)
/* 455 */         tempcoef[i] = coef[i] + refcoef[m] * coef[m - i]; 
/* 456 */       for (i = 1; i < m; i++)
/* 457 */         coef[i] = tempcoef[i]; 
/* 458 */       coef[m] = refcoef[m];
/*     */     } 
/*     */     byte b;
/* 461 */     for (b = 0; b <= 8; b++) {
/* 462 */       aav1[b] = coef[b];
/*     */     }
/* 464 */     for (b = 0; b <= 8; b++) {
/*     */       
/* 466 */       rav1[b] = 0.0F;
/* 467 */       for (int k = 0; k <= 8 - b; k++) {
/* 468 */         rav1[b] = rav1[b] + aav1[k] * aav1[k + b];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean SpectralComp(float[] rav1, float[] av0) {
/*     */     float f1;
/* 483 */     if (av0[0] < 1.0E-15F) {
/* 484 */       f1 = 0.0F;
/* 485 */       for (int i = 1; i <= 8; i++)
/* 486 */         f1 += rav1[i]; 
/* 487 */       f1 = 2.0F * f1 + rav1[0];
/*     */     } else {
/* 489 */       f1 = 0.0F;
/* 490 */       for (byte b = 1; b <= 8; b++)
/* 491 */         f1 += rav1[b] * av0[b]; 
/* 492 */       f1 = 2.0F * f1 + rav1[0] * av0[0];
/* 493 */       f1 /= av0[0];
/*     */     } 
/*     */     
/* 496 */     float difference = f1 - this.vad_lastdm;
/* 497 */     boolean statF = (difference < 0.05F && difference > -0.05F);
/*     */     
/* 499 */     this.vad_lastdm = f1;
/* 500 */     return statF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean PitchDetect() {
/* 509 */     return (this.vad_oldlagcount + this.vad_veryoldlagcount >= 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void ThresAdapt(boolean pitchF, boolean statF, float[] ACF, float[] rav1, float pvad) {
/* 520 */     float thvad = this.vad_thvad;
/*     */ 
/*     */     
/* 523 */     if (ACF[0] < 6.984919E-5F) {
/* 524 */       this.vad_thvad = 1.8626451E-4F;
/*     */       
/*     */       return;
/*     */     } 
/* 528 */     if (pitchF == true || !statF) {
/* 529 */       this.vad_adaptcount = 0;
/*     */       
/*     */       return;
/*     */     } 
/* 533 */     if (++this.vad_adaptcount <= 8) {
/*     */       return;
/*     */     }
/* 536 */     thvad -= thvad / 32.0F;
/* 537 */     float temp = pvad * 3.0F;
/* 538 */     if (thvad < temp) {
/*     */       
/* 540 */       thvad += thvad / 16.0F;
/* 541 */       if (temp < thvad)
/* 542 */         thvad = temp; 
/*     */     } 
/* 544 */     temp = pvad + 0.018626451F;
/* 545 */     if (thvad > temp) {
/* 546 */       thvad = temp;
/*     */     }
/* 548 */     this.vad_thvad = thvad;
/*     */     
/* 550 */     for (int i = 0; i <= 8; i++) {
/* 551 */       this.vad_rvad[i] = rav1[i];
/*     */     }
/* 553 */     this.vad_adaptcount = 9;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean vad_decision(float pvad) {
/*     */     boolean bool;
/* 569 */     if (pvad > this.vad_thvad) {
/* 570 */       bool = true;
/* 571 */       this.vad_burstcount++;
/* 572 */       if (this.vad_burstcount >= 3) {
/* 573 */         this.vad_hangcount = 5;
/* 574 */         this.vad_burstcount = 3;
/*     */       } 
/*     */     } else {
/* 577 */       bool = false;
/* 578 */       this.vad_burstcount = 0;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 585 */     if (this.vad_hangcount >= 0) {
/* 586 */       bool = true;
/* 587 */       this.vad_hangcount--;
/*     */     } 
/*     */     
/* 590 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void pitchCounting(int[] Nc) {
/* 606 */     int lagcount = 0;
/* 607 */     for (int i = 0; i <= 3; i++) {
/*     */       int j, k;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 613 */       if (this.vad_oldlag > Nc[i]) {
/* 614 */         j = Nc[i];
/* 615 */         k = this.vad_oldlag;
/*     */       } else {
/* 617 */         j = this.vad_oldlag;
/* 618 */         k = Nc[i];
/*     */       } 
/*     */       
/* 621 */       int smallag = k % j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 627 */       if (smallag < 2 || j - smallag < 2) {
/* 628 */         lagcount++;
/*     */       }
/* 630 */       this.vad_oldlag = Nc[i];
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 635 */     this.vad_veryoldlagcount = this.vad_oldlagcount;
/* 636 */     this.vad_oldlagcount = lagcount;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\ibm\media\codec\audio\gsm\GsmVadEncoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */