package com.ibm.media.codec.audio.gsm;

public class GsmVadEncoder extends GsmEncoder {
  private static final float DIST_TH = 0.05F;
  
  private static final int PITCH_TH = 4;
  
  private static final int PITCH_PRECISION = 2;
  
  private static final float PTH = 6.984919E-5F;
  
  private static final float MARGIN = 0.018626451F;
  
  private static final float PLEV = 1.8626451E-4F;
  
  private static final float FAC = 3.0F;
  
  private static final int ADP = 8;
  
  private static final float INC = 16.0F;
  
  private static final float DEC = 32.0F;
  
  private static final float EPSILON = 1.0E-15F;
  
  private static final int NEW_SID = -1;
  
  private static final float MAX_LAR = 1.625F;
  
  private static final int E_PTH = 19;
  
  private static final int M_PTH = 18750;
  
  private static final int E_MARGIN = 27;
  
  private static final int M_MARGIN = 19531;
  
  private static final int E_PLEV = 20;
  
  private static final int M_PLEV = 25000;
  
  public static final int UPDATE_RATE = 10;
  
  private static final int nFRAMES = 4;
  
  int vad_sincelastSID;
  
  int vad_sinceSPEECHburst;
  
  float[][] vad_prevLARs = new float[4][8];
  
  float[][] vad_prevxmax = new float[4][4];
  
  int[] vad_prevSID = new int[77];
  
  int vad_hangover;
  
  int vad_LARindex;
  
  boolean vad_SP;
  
  float[] vad_LAR = new float[8];
  
  float[] vad_currentxmax = new float[4];
  
  int vad_blocknumber;
  
  int vad_lastsent;
  
  boolean vad_prevSP;
  
  float[] vad_rvad = new float[9];
  
  float[][] vad_sacf = new float[3][9];
  
  float[][] vad_sav0 = new float[4][9];
  
  int vad_sacfPt;
  
  int vad_sav0Pt;
  
  float vad_lastdm;
  
  int vad_oldlagcount;
  
  int vad_veryoldlagcount;
  
  int vad_adaptcount;
  
  int vad_burstcount;
  
  int vad_hangcount;
  
  int vad_oldlag;
  
  float vad_thvad;
  
  protected void doVAD() {
    vad_calculations();
    DisConTrans();
  }
  
  public void gsm_encoder_reset() {
    super.gsm_encoder_reset();
    this.vadSupportFlag = true;
    this.vad_sincelastSID = 24;
    this.vad_sinceSPEECHburst = 0;
    for (int i = 0; i < this.vad_prevLARs.length; i++) {
      for (int i2 = 0; i2 < (this.vad_prevLARs[i]).length; i2++)
        this.vad_prevLARs[i][i2] = 0.0F; 
    } 
    for (int j = 0; j < this.vad_prevxmax.length; j++) {
      this.vad_prevxmax[j][0] = 0.0F;
      this.vad_prevxmax[j][1] = 0.0F;
      this.vad_prevxmax[j][2] = 0.0F;
      this.vad_prevxmax[j][3] = 0.0F;
    } 
    for (int k = 0; k < this.vad_prevSID.length; k++)
      this.vad_prevSID[k] = 0; 
    this.vad_prevSID[0] = 2;
    this.vad_prevSID[1] = 28;
    this.vad_prevSID[2] = 18;
    this.vad_prevSID[3] = 12;
    this.vad_prevSID[4] = 7;
    this.vad_prevSID[5] = 5;
    this.vad_prevSID[6] = 3;
    this.vad_prevSID[7] = 2;
    this.vad_hangover = 1;
    this.vad_LARindex = 0;
    this.vad_SP = true;
    this.vad_prevSP = true;
    this.vad_lastsent = 0;
    this.vad_rvad[0] = 6.0F;
    this.vad_rvad[1] = -4.0F;
    this.vad_rvad[2] = 1.0F;
    for (int m = 3; m < this.vad_rvad.length; m++)
      this.vad_rvad[m] = 0.0F; 
    for (int n = 0; n < this.vad_sacf.length; n++) {
      for (int i2 = 0; i2 < (this.vad_sacf[n]).length; i2++)
        this.vad_sacf[n][i2] = 0.0F; 
    } 
    for (int i1 = 0; i1 < this.vad_sav0.length; i1++) {
      for (int i2 = 0; i2 < (this.vad_sav0[i1]).length; i2++)
        this.vad_sav0[i1][i2] = 0.0F; 
    } 
    this.vad_sacfPt = 0;
    this.vad_sav0Pt = 0;
    this.vad_lastdm = 0.0F;
    this.vad_oldlagcount = 0;
    this.vad_veryoldlagcount = 0;
    this.vad_adaptcount = 0;
    this.vad_burstcount = 0;
    this.vad_hangcount = -1;
    this.vad_oldlag = 40;
    this.vad_thvad = 2.3283064E-4F;
  }
  
  void vad_calculations() {
    int[] lg2s = GsmEncoder.lut_lg2s;
    boolean vadF = VAD(this.data_acf, this.data_Nc);
    if (vadF) {
      this.vad_sinceSPEECHburst = 0;
      this.vad_SP = true;
      this.vad_LARindex = (this.vad_LARindex == 3) ? 0 : (this.vad_LARindex + 1);
      int i;
      for (i = 0; i < 8; i++)
        this.vad_prevLARs[this.vad_LARindex][i] = this.vad_LAR[i]; 
      for (i = 0; i < 4; i++)
        this.vad_prevxmax[this.vad_LARindex][i] = this.vad_currentxmax[i]; 
      if (this.vad_sincelastSID < 24)
        this.vad_sincelastSID++; 
    } else {
      if (this.vad_sinceSPEECHburst++ == 0) {
        this.vad_hangover = (this.vad_sincelastSID >= 24) ? 1 : 0;
      } else if (this.vad_sinceSPEECHburst > 4) {
        this.vad_hangover = -1;
      } 
      if (this.vad_hangover == 1) {
        this.vad_LARindex = (this.vad_LARindex == 3) ? 0 : (this.vad_LARindex + 1);
        byte b;
        for (b = 0; b < 8; b++)
          this.vad_prevLARs[this.vad_LARindex][b] = this.data_LAR[b]; 
        for (b = 0; b < 4; b++)
          this.vad_prevxmax[this.vad_LARindex][b] = this.vad_currentxmax[b]; 
        if (this.vad_sincelastSID < 24)
          this.vad_sincelastSID++; 
        this.vad_SP = true;
      } else if (this.vad_hangover == 0) {
        this.vad_LARindex = (this.vad_LARindex == 3) ? 0 : (this.vad_LARindex + 1);
        byte b;
        for (b = 0; b < 8; b++)
          this.vad_prevLARs[this.vad_LARindex][b] = this.data_LAR[b]; 
        for (b = 0; b < 4; b++)
          this.vad_prevxmax[this.vad_LARindex][b] = this.vad_currentxmax[b]; 
        for (b = 0; b < 77; b++)
          this.data_Parameters[b] = this.vad_prevSID[b]; 
        if (this.vad_sincelastSID < 24)
          this.vad_sincelastSID++; 
        this.vad_SP = false;
      } else {
        int i;
        for (i = 1; i <= 8; i++) {
          float LARinter = 0.25F * (this.vad_prevLARs[0][i - 1] + this.vad_prevLARs[1][i - 1] + this.vad_prevLARs[2][i - 1] + this.vad_prevLARs[3][i - 1]);
          LARinter = GsmEncoder.lut_A[i] * LARinter + GsmEncoder.lut_B[i];
          if (LARinter > GsmEncoder.lut_MAC[i])
            LARinter = GsmEncoder.lut_MAC[i]; 
          if (LARinter < GsmEncoder.lut_MIC[i])
            LARinter = GsmEncoder.lut_MIC[i]; 
          this.vad_prevSID[i - 1] = (int)(LARinter - GsmEncoder.lut_MIC[i] + 0.5F);
        } 
        float XMAXinter = 0.0F;
        for (i = 0; i < 4; i++) {
          for (int k = 0; k < 4; k++)
            XMAXinter += this.vad_prevxmax[k][i]; 
        } 
        XMAXinter *= 0.0625F;
        if (XMAXinter < 0.015625D) {
          XMAXinter *= 1024.0F;
        } else {
          int temp = (int)(32768.0D * XMAXinter);
          temp >>= 10;
          if (temp < 31) {
            i = lg2s[temp];
            XMAXinter = (i << 3) + XMAXinter * (1024 >> i);
          } else {
            XMAXinter = 63.0F;
          } 
        } 
        for (i = 0; i < 4; i++)
          this.vad_prevSID[11 + 17 * i] = (int)XMAXinter; 
        this.vad_LARindex = (this.vad_LARindex == 3) ? 0 : (this.vad_LARindex + 1);
        for (i = 0; i < 8; i++)
          this.vad_prevLARs[this.vad_LARindex][i] = this.data_LAR[i]; 
        for (i = 0; i < 4; i++)
          this.vad_prevxmax[this.vad_LARindex][i] = this.vad_currentxmax[i]; 
        for (i = 0; i < 77; i++)
          this.data_Parameters[i] = this.vad_prevSID[i]; 
        this.vad_sincelastSID = 0;
        this.vad_SP = false;
      } 
    } 
  }
  
  void DisConTrans() {
    boolean sendF = false;
    if (this.vad_SP) {
      this.frameType = 0;
      sendF = true;
    } else if (!this.vad_SP && this.vad_prevSP) {
      this.frameType = 1;
      sendF = true;
    } 
    this.vad_prevSP = this.vad_SP;
    if (sendF) {
      this.vad_lastsent = 0;
    } else if (this.sidUpdateRate > 0 && ++this.vad_lastsent >= this.sidUpdateRate) {
      this.vad_lastsent = 0;
      sendF = true;
      this.frameType = 1;
    } else {
      for (int i = 0; i < 77; i++)
        this.data_Parameters[i] = 0; 
      this.frameType = 2;
    } 
  }
  
  float[] vadAux_av0 = new float[9];
  
  float[] vadAux_av1 = new float[9];
  
  float[] vadAux_refcoef = new float[9];
  
  float[] vadAux_rav1 = new float[9];
  
  boolean VAD(float[] ACF, int[] Nc) {
    float[] av0 = this.vadAux_av0;
    float[] av1 = this.vadAux_av1;
    float[] refcoef = this.vadAux_refcoef;
    float[] rav1 = this.vadAux_rav1;
    float pvad = adaptiveFiltering(ACF);
    ACFaverage(ACF, av0, av1);
    schurRecursion(av1, refcoef);
    Step_up(refcoef, rav1);
    boolean statF = SpectralComp(rav1, av0);
    boolean pitchF = PitchDetect();
    ThresAdapt(pitchF, statF, ACF, rav1, pvad);
    boolean vadF = vad_decision(pvad);
    pitchCounting(Nc);
    return vadF;
  }
  
  float adaptiveFiltering(float[] ACF) {
    if (ACF[0] < 1.0E-15F) {
      float pvad = 0.0F;
      ACF[0] = 0.0F;
      return pvad;
    } 
    float f = 0.0F;
    for (int i = 1; i <= 8; i++)
      f += this.vad_rvad[i] * ACF[i]; 
    f = 2.0F * f + this.vad_rvad[0] * ACF[0];
    return f;
  }
  
  void ACFaverage(float[] ACF, float[] av0, float[] av1) {
    int sacfPt = this.vad_sacfPt;
    int sav0Pt = this.vad_sav0Pt;
    for (int i = 0; i <= 8; i++) {
      av0[i] = ACF[i] + this.vad_sacf[0][i] + this.vad_sacf[1][i] + this.vad_sacf[2][i];
      this.vad_sacf[sacfPt][i] = ACF[i];
      av1[i] = this.vad_sav0[sav0Pt][i];
      this.vad_sav0[sav0Pt][i] = av0[i];
    } 
    this.vad_sacfPt = (sacfPt == 2) ? 0 : (sacfPt + 1);
    this.vad_sav0Pt = (sav0Pt == 3) ? 0 : (sav0Pt + 1);
  }
  
  float[] vadAux_coef = new float[9];
  
  float[] vadAux_tempcoef = new float[9];
  
  float[] vadAux_aav1 = new float[9];
  
  void Step_up(float[] refcoef, float[] rav1) {
    float[] coef = this.vadAux_coef;
    float[] tempcoef = this.vadAux_tempcoef;
    float[] aav1 = this.vadAux_aav1;
    coef[0] = 1.0F;
    coef[1] = refcoef[1];
    for (int m = 2; m < 9; m++) {
      int i;
      for (i = 1; i < m; i++)
        tempcoef[i] = coef[i] + refcoef[m] * coef[m - i]; 
      for (i = 1; i < m; i++)
        coef[i] = tempcoef[i]; 
      coef[m] = refcoef[m];
    } 
    byte b;
    for (b = 0; b <= 8; b++)
      aav1[b] = coef[b]; 
    for (b = 0; b <= 8; b++) {
      rav1[b] = 0.0F;
      for (int k = 0; k <= 8 - b; k++)
        rav1[b] = rav1[b] + aav1[k] * aav1[k + b]; 
    } 
  }
  
  boolean SpectralComp(float[] rav1, float[] av0) {
    float f1;
    if (av0[0] < 1.0E-15F) {
      f1 = 0.0F;
      for (int i = 1; i <= 8; i++)
        f1 += rav1[i]; 
      f1 = 2.0F * f1 + rav1[0];
    } else {
      f1 = 0.0F;
      for (byte b = 1; b <= 8; b++)
        f1 += rav1[b] * av0[b]; 
      f1 = 2.0F * f1 + rav1[0] * av0[0];
      f1 /= av0[0];
    } 
    float difference = f1 - this.vad_lastdm;
    boolean statF = (difference < 0.05F && difference > -0.05F);
    this.vad_lastdm = f1;
    return statF;
  }
  
  boolean PitchDetect() {
    return (this.vad_oldlagcount + this.vad_veryoldlagcount >= 4);
  }
  
  void ThresAdapt(boolean pitchF, boolean statF, float[] ACF, float[] rav1, float pvad) {
    float thvad = this.vad_thvad;
    if (ACF[0] < 6.984919E-5F) {
      this.vad_thvad = 1.8626451E-4F;
      return;
    } 
    if (pitchF == true || !statF) {
      this.vad_adaptcount = 0;
      return;
    } 
    if (++this.vad_adaptcount <= 8)
      return; 
    thvad -= thvad / 32.0F;
    float temp = pvad * 3.0F;
    if (thvad < temp) {
      thvad += thvad / 16.0F;
      if (temp < thvad)
        thvad = temp; 
    } 
    temp = pvad + 0.018626451F;
    if (thvad > temp)
      thvad = temp; 
    this.vad_thvad = thvad;
    for (int i = 0; i <= 8; i++)
      this.vad_rvad[i] = rav1[i]; 
    this.vad_adaptcount = 9;
  }
  
  boolean vad_decision(float pvad) {
    boolean bool;
    if (pvad > this.vad_thvad) {
      bool = true;
      this.vad_burstcount++;
      if (this.vad_burstcount >= 3) {
        this.vad_hangcount = 5;
        this.vad_burstcount = 3;
      } 
    } else {
      bool = false;
      this.vad_burstcount = 0;
    } 
    if (this.vad_hangcount >= 0) {
      bool = true;
      this.vad_hangcount--;
    } 
    return bool;
  }
  
  void pitchCounting(int[] Nc) {
    int lagcount = 0;
    for (int i = 0; i <= 3; i++) {
      int j, k;
      if (this.vad_oldlag > Nc[i]) {
        j = Nc[i];
        k = this.vad_oldlag;
      } else {
        j = this.vad_oldlag;
        k = Nc[i];
      } 
      int smallag = k % j;
      if (smallag < 2 || j - smallag < 2)
        lagcount++; 
      this.vad_oldlag = Nc[i];
    } 
    this.vad_veryoldlagcount = this.vad_oldlagcount;
    this.vad_oldlagcount = lagcount;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\gsm\GsmVadEncoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */