package com.ibm.media.codec.audio.ima4;

class IMA4State {
  public int valprev;
  
  public int index;
}
