package com.ibm.media.codec.audio.dvi;

import com.ibm.media.codec.audio.AudioCodec;
import com.ibm.media.codec.audio.AudioPacketizer;
import com.sun.media.BasicPlugIn;
import com.sun.media.controls.SilenceSuppressionAdapter;
import javax.media.Buffer;
import javax.media.Codec;
import javax.media.Format;
import javax.media.ResourceUnavailableException;
import javax.media.format.AudioFormat;

public class JavaEncoder extends AudioPacketizer {
  private Buffer pcmBuffer = new Buffer();
  
  private DVIState dviState = new DVIState();
  
  private long currentSeq = 0L;
  
  public JavaEncoder() {
    this.packetSize = 240;
    ((AudioCodec)this).supportedInputFormats = new AudioFormat[] { new AudioFormat("LINEAR", -1.0D, 16, 1, 0, 1, -1, -1.0D, Format.byteArray) };
    ((AudioCodec)this).defaultOutputFormats = new AudioFormat[] { new AudioFormat("dvi/rtp", -1.0D, 4, 1, -1, -1, -1, -1.0D, Format.byteArray) };
    ((AudioCodec)this).PLUGIN_NAME = "DVI Encoder";
  }
  
  protected Format[] getMatchingOutputFormats(Format in) {
    AudioFormat af = (AudioFormat)in;
    ((AudioCodec)this).supportedOutputFormats = new AudioFormat[] { new AudioFormat("dvi/rtp", af.getSampleRate(), 4, 1, -1, -1, -1, -1.0D, Format.byteArray) };
    return (Format[])((AudioCodec)this).supportedOutputFormats;
  }
  
  public Format setOutputFormat(Format out) {
    Format f = super.setOutputFormat(out);
    AudioFormat af = (AudioFormat)f;
    if (af.getSampleRate() == 8000.0D) {
      this.packetSize = 240;
    } else if (af.getSampleRate() == 11025.0D) {
      this.packetSize = 330;
    } else if (af.getSampleRate() == 22050.0D) {
      this.packetSize = 660;
    } else if (af.getSampleRate() == 44100.0D) {
      this.packetSize = 1320;
    } 
    return f;
  }
  
  public int process(Buffer inputBuffer, Buffer outputBuffer) {
    int rc = super.process(inputBuffer, this.pcmBuffer);
    if ((rc & 0x4) != 0)
      return rc; 
    byte[] pcmData = (byte[])this.pcmBuffer.getData();
    int inpLength = this.pcmBuffer.getLength();
    int outLength = this.pcmBuffer.getLength() / 4;
    byte[] outData = validateByteArraySize(outputBuffer, outLength + 4);
    outData[0] = (byte)(this.dviState.valprev >> 8);
    outData[1] = (byte)this.dviState.valprev;
    outData[2] = (byte)this.dviState.index;
    outData[3] = 0;
    DVI.encode(pcmData, 0, outData, 4, inpLength >> 1, this.dviState);
    this.pcmBuffer.setOffset(0);
    this.pcmBuffer.setLength(0);
    outputBuffer.setSequenceNumber(this.currentSeq++);
    outputBuffer.setTimeStamp(this.pcmBuffer.getTimeStamp());
    updateOutput(outputBuffer, (Format)((AudioCodec)this).outputFormat, outLength + 4, 0);
    return rc;
  }
  
  public void open() throws ResourceUnavailableException {
    this.dviState = new DVIState();
    setPacketSize(this.packetSize);
    reset();
  }
  
  public void reset() {
    super.reset();
    this.dviState.valprev = 0;
    this.dviState.index = 0;
    this.pcmBuffer.setOffset(0);
    this.pcmBuffer.setLength(0);
  }
  
  public Object[] getControls() {
    if (((BasicPlugIn)this).controls == null) {
      ((BasicPlugIn)this).controls = (Object[])new javax.media.Control[2];
      ((BasicPlugIn)this).controls[0] = new PacketSizeAdapter((Codec)this, this.packetSize, true);
      ((BasicPlugIn)this).controls[1] = new SilenceSuppressionAdapter((Codec)this, false, false);
    } 
    return ((BasicPlugIn)this).controls;
  }
  
  public synchronized void setPacketSize(int newPacketSize) {
    this.packetSize = newPacketSize * 4;
    this.sample_count = this.packetSize / 2;
    if (this.history == null) {
      this.history = new byte[this.packetSize];
      return;
    } 
    if (this.packetSize > this.history.length) {
      byte[] newHistory = new byte[this.packetSize];
      System.arraycopy(this.history, 0, newHistory, 0, this.historyLength);
      this.history = newHistory;
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\dvi\JavaEncoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */