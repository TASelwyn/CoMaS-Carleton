package com.ibm.media.codec.audio.g723;

class DecoderData {
  private static final int LpcOrder = 10;
  
  private static final int Frame = 240;
  
  private static final int NUM_OF_BLOCKS = 4;
  
  private static final int PitchMin = 18;
  
  private static final int PitchMax = 145;
  
  int WrkRate;
  
  boolean UsePf;
  
  int Ecount;
  
  float InterGain;
  
  int InterIndx;
  
  int Rseed;
  
  float Park;
  
  float Gain;
  
  float[] PrevLsp = new float[10];
  
  float[] PrevExc = new float[1105];
  
  float[] SyntIirDl = new float[10];
  
  float[] PostFirDl = new float[10];
  
  float[] PostIirDl = new float[10];
  
  int BlockIndex;
  
  int BlockCount;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\g723\DecoderData.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */