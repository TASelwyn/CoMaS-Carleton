/*      */ package com.ibm.media.codec.audio.rc;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class RateConversion
/*      */ {
/*      */   public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997,1998.";
/*      */   public static final int RATE_CONVERSION_OK = -1;
/*      */   public static final int RATE_CONVERSION_NOT_SUPPORTED = -2;
/*      */   public static final int RATE_CONVERSION_NOT_INITIALIZED = -3;
/*      */   public static final int RATE_CONVERSION_ILLEGAL_PARAMETER = -4;
/*      */   public static final int RATE_CONVERSION_RECOMMENDED_INPUT_SIZE = 1056;
/*      */   public static final int RATE_CONVERSION_MAX_SUPPORTED_CHANNELS = 2;
/*      */   public static final int RATE_CONVERSION_MAX_OUTPUT_FACTOR = 5;
/*      */   public static final int RATE_CONVERSION_BIG_ENDIAN_FORMAT = 0;
/*      */   public static final int RATE_CONVERSION_LITTLE_ENDIAN_FORMAT = 1;
/*      */   public static final int RATE_CONVERSION_BYTE_FORMAT = 2;
/*      */   private static final boolean USE_REMOVE_DC = false;
/*      */   private boolean useMuLaw = false;
/*      */   private static final int MAX_RATE_IN = 11;
/*      */   private static final int UNROLLING_ORDER = 4;
/*      */   private static final int CORRECTION_FRAME_SIZE = 441;
/*      */   private static final int CONV_ERROR = -1;
/*      */   private static final int CONV_11to2 = 1;
/*      */   private static final int CONV_11to4 = 2;
/*      */   private static final int CONV_11to8 = 3;
/*      */   private static final int CONV_6to1 = 4;
/*      */   private static final int CONV_4to1 = 5;
/*      */   private static final int CONV_2to1 = 6;
/*      */   private static final int MAX_MEM_SIZE = 792;
/*      */   private static final float DCFACT = 0.9921875F;
/*      */   private static final float SHRT_MIN = -32767.0F;
/*      */   private static final float SHRT_MAX = 32767.0F;
/*      */   private static final float FRACTION_DELTA = 0.0022727272F;
/*      */   private static final float FRACTION_DELIMITER = 1.0011364F;
/*      */   private int bias;
/*      */   private int signMask;
/*      */   private int filterHistoryLength;
/*      */   private int decimFlag;
/*      */   private int numberOfInputChannels;
/*      */   private int numberOfOutputChannels;
/*      */   private boolean channels2To1 = false;
/*      */   private boolean channels1To2 = false;
/*      */   private boolean channels2To2 = false;
/*      */   private int rateIn;
/*      */   private int rateOut;
/*   89 */   private int[] index = new int[2];
/*      */ 
/*      */   
/*      */   private int inputRemainedSamples;
/*      */ 
/*      */   
/*      */   private int maxInputLength;
/*      */ 
/*      */   
/*      */   private int paddingLength;
/*      */   
/*      */   private int maxDrainedSamples;
/*      */   
/*      */   private int pcmType;
/*      */   
/*      */   private int inputSampleSize;
/*      */   
/*      */   private float[] poly;
/*      */   
/*      */   private float[] x1;
/*      */   
/*      */   private float[] x2;
/*      */   
/*      */   private float[] y1;
/*      */   
/*      */   private float[] y2;
/*      */   
/*      */   private boolean needInputCorrection;
/*      */   
/*      */   private boolean isDrained;
/*      */   
/*      */   private boolean isRateConversionInited;
/*      */   
/*      */   private int delay;
/*      */   
/*      */   private float lastInputSample1;
/*      */   
/*      */   private float lastInputSample2;
/*      */   
/*      */   private float frac;
/*      */   
/*      */   private float prev_fsample1;
/*      */   
/*      */   private float prev_fsample2;
/*      */   
/*  134 */   private float fractionDelta = 0.0022727272F;
/*      */   private float fractionDelimiter;
/*  136 */   private int precisionCountDelimiter = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int precisionCount;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int init(int maxInputBufferSize, int rateInput, int rateOutput, int inputChannels, int outputChannels, int pcmType, boolean signed, boolean useMuLaw) {
/*      */     int i, filterLength;
/*  173 */     this.useMuLaw = useMuLaw;
/*      */     
/*  175 */     this.inputSampleSize = 2;
/*      */     
/*  177 */     if (0 != pcmType && 1 != pcmType && 2 != pcmType) {
/*  178 */       return -4;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  189 */     if (signed) {
/*  190 */       this.bias = 0;
/*  191 */       this.signMask = -1;
/*      */     } else {
/*      */       
/*  194 */       this.bias = 32768;
/*  195 */       this.signMask = 65535;
/*      */     } 
/*      */     
/*  198 */     if (2 == pcmType) {
/*  199 */       this.inputSampleSize = 1;
/*      */     }
/*      */     
/*  202 */     this.pcmType = pcmType;
/*  203 */     this.maxInputLength = maxInputBufferSize / this.inputSampleSize * inputChannels;
/*  204 */     this.numberOfInputChannels = inputChannels;
/*  205 */     this.numberOfOutputChannels = outputChannels;
/*      */     
/*  207 */     if (this.numberOfInputChannels == 2 && this.numberOfOutputChannels == 1) {
/*  208 */       this.channels2To1 = true;
/*      */     } else {
/*      */       
/*  211 */       this.channels2To1 = false;
/*      */     } 
/*  213 */     if (this.numberOfInputChannels == 1 && this.numberOfOutputChannels == 2) {
/*  214 */       this.channels1To2 = true;
/*      */     } else {
/*      */       
/*  217 */       this.channels1To2 = false;
/*      */     } 
/*      */     
/*  220 */     if (this.numberOfInputChannels == 2 && this.numberOfOutputChannels == 2) {
/*  221 */       this.channels2To2 = true;
/*      */     } else {
/*      */       
/*  224 */       this.channels2To2 = false;
/*      */     } 
/*  226 */     this.needInputCorrection = false;
/*  227 */     this.delay = 0;
/*  228 */     this.decimFlag = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  235 */     if (rateInput == 44100 && rateOutput == 8000) {
/*  236 */       this.decimFlag = 1;
/*  237 */       this.rateIn = 11;
/*  238 */       this.rateOut = 2;
/*  239 */       this.needInputCorrection = true;
/*      */     }
/*  241 */     else if (rateInput == 22050 && rateOutput == 8000) {
/*  242 */       this.decimFlag = 2;
/*  243 */       this.rateIn = 11;
/*  244 */       this.rateOut = 4;
/*  245 */       this.needInputCorrection = true;
/*      */     }
/*  247 */     else if (rateInput == 11025 && rateOutput == 8000) {
/*  248 */       this.decimFlag = 3;
/*  249 */       this.rateIn = 11;
/*  250 */       this.rateOut = 8;
/*  251 */       this.needInputCorrection = true;
/*      */     }
/*  253 */     else if (rateInput == 48000 && rateOutput == 8000) {
/*  254 */       this.decimFlag = 4;
/*  255 */       this.rateIn = 6;
/*  256 */       this.rateOut = 1;
/*  257 */       this.needInputCorrection = false;
/*      */     }
/*  259 */     else if (rateInput == 32000 && rateOutput == 8000) {
/*  260 */       this.decimFlag = 5;
/*  261 */       this.rateIn = 4;
/*  262 */       this.rateOut = 1;
/*  263 */       this.needInputCorrection = false;
/*      */     }
/*  265 */     else if (rateInput == 16000 && rateOutput == 8000) {
/*  266 */       this.decimFlag = 6;
/*  267 */       this.rateIn = 2;
/*  268 */       this.rateOut = 1;
/*  269 */       this.needInputCorrection = false;
/*      */     
/*      */     }
/*  272 */     else if (rateInput == 11127 && rateOutput == 8000) {
/*  273 */       this.decimFlag = 3;
/*  274 */       this.rateIn = 11;
/*  275 */       this.rateOut = 8;
/*  276 */       this.needInputCorrection = true;
/*  277 */       this.fractionDelta = 0.011545454F;
/*  278 */       this.precisionCountDelimiter = 127;
/*      */     
/*      */     }
/*  281 */     else if (rateInput == 22254 && rateOutput == 8000) {
/*  282 */       this.decimFlag = 2;
/*  283 */       this.rateIn = 11;
/*  284 */       this.rateOut = 4;
/*  285 */       this.needInputCorrection = true;
/*      */       
/*  287 */       this.fractionDelta = 0.011545454F;
/*  288 */       this.precisionCountDelimiter = 127;
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  293 */     else if (rateInput == 22255 && rateOutput == 8000) {
/*  294 */       this.decimFlag = 2;
/*  295 */       this.rateIn = 11;
/*  296 */       this.rateOut = 4;
/*  297 */       this.needInputCorrection = true;
/*      */       
/*  299 */       this.fractionDelta = 0.011590909F;
/*  300 */       this.precisionCountDelimiter = 255;
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  306 */       close();
/*  307 */       return -2;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  316 */     switch (this.decimFlag) {
/*      */ 
/*      */       
/*      */       case 3:
/*  320 */         this.filterHistoryLength = 25;
/*  321 */         this.delay = 9;
/*  322 */         filterLength = 200;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 2:
/*  327 */         this.filterHistoryLength = 50;
/*  328 */         this.delay = 9;
/*  329 */         filterLength = 200;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 1:
/*  334 */         this.filterHistoryLength = 100;
/*  335 */         this.delay = 9;
/*  336 */         filterLength = 200;
/*      */         break;
/*      */       
/*      */       case 4:
/*  340 */         this.filterHistoryLength = 128;
/*  341 */         this.delay = 11;
/*  342 */         filterLength = 128;
/*      */         break;
/*      */       
/*      */       case 5:
/*  346 */         this.filterHistoryLength = 128;
/*  347 */         this.delay = 16;
/*  348 */         filterLength = 128;
/*      */         break;
/*      */       
/*      */       case 6:
/*  352 */         this.filterHistoryLength = 64;
/*  353 */         this.delay = 16;
/*  354 */         filterLength = 64;
/*      */         break;
/*      */       
/*      */       default:
/*  358 */         close();
/*  359 */         return -2;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  364 */     this.poly = new float[filterLength];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  371 */     this.x1 = new float[this.maxInputLength + this.filterHistoryLength + 4 * this.rateIn];
/*  372 */     this.y1 = new float[(this.maxInputLength + this.filterHistoryLength + 4 * this.rateIn) / this.rateIn * this.rateOut];
/*      */ 
/*      */     
/*  375 */     if (this.channels2To2) {
/*  376 */       this.x2 = new float[this.maxInputLength + this.filterHistoryLength + 4 * this.rateIn];
/*  377 */       this.y2 = new float[(this.maxInputLength + this.filterHistoryLength + 4 * this.rateIn) / this.rateIn * this.rateOut];
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  388 */     float gain = 1.0F;
/*  389 */     switch (this.decimFlag) {
/*      */ 
/*      */       
/*      */       case 1:
/*  393 */         gain = 2.0F;
/*  394 */         for (i = 0; i < 2; i++) {
/*  395 */           for (int j = 0; j < 100; j++) {
/*  396 */             this.poly[i * 100 + j] = RateConversionTables.filter11[i + j * 2] * gain;
/*      */           }
/*      */         } 
/*      */         break;
/*      */       case 2:
/*  401 */         gain = 4.0F;
/*  402 */         for (i = 0; i < 4; i++) {
/*  403 */           for (byte b = 0; b < 50; b++) {
/*  404 */             this.poly[i * 50 + b] = RateConversionTables.filter11[i + b * 4] * gain;
/*      */           }
/*      */         } 
/*      */         break;
/*      */       case 3:
/*  409 */         gain = 8.0F;
/*  410 */         for (i = 0; i < 8; i++) {
/*  411 */           for (byte b = 0; b < 25; b++) {
/*  412 */             this.poly[i * 25 + b] = RateConversionTables.filter11[i + b * 8] * gain;
/*      */           }
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 4:
/*  440 */         for (i = 0; i < 128; i++) {
/*  441 */           this.poly[i] = RateConversionTables.filter6[i];
/*      */         }
/*      */         break;
/*      */       case 5:
/*  445 */         for (i = 0; i < 128; i++) {
/*  446 */           this.poly[i] = RateConversionTables.filter4[i];
/*      */         }
/*      */         break;
/*      */       case 6:
/*  450 */         for (i = 0; i < 64; i++) {
/*  451 */           this.poly[i] = RateConversionTables.filter2[i];
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  457 */     this.paddingLength = this.filterHistoryLength / 2;
/*      */ 
/*      */     
/*  460 */     this.maxDrainedSamples = (int)(((this.paddingLength + 4 * this.rateIn * 2) * this.rateOut) / this.rateIn);
/*      */ 
/*      */     
/*  463 */     this.isRateConversionInited = true;
/*  464 */     this.fractionDelimiter = 1.0F + this.fractionDelta / 2.0F;
/*  465 */     reset();
/*      */ 
/*      */     
/*  468 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int reset() {
/*  482 */     if (false == this.isRateConversionInited) {
/*  483 */       return -3;
/*      */     }
/*  485 */     this.inputRemainedSamples = 0;
/*  486 */     this.isDrained = false;
/*      */     
/*  488 */     this.frac = 1.0F;
/*  489 */     this.precisionCount = this.precisionCountDelimiter - 1;
/*  490 */     this.prev_fsample1 = 0.0F;
/*  491 */     this.prev_fsample2 = 0.0F;
/*      */ 
/*      */     
/*      */     int i;
/*      */     
/*  496 */     for (i = 0; i < this.filterHistoryLength; i++) {
/*  497 */       this.x1[i] = 0.0F;
/*      */     }
/*      */     
/*  500 */     this.index[0] = 0;
/*      */ 
/*      */     
/*  503 */     if (this.channels2To2) {
/*  504 */       for (i = 0; i < this.filterHistoryLength; i++)
/*  505 */         this.x2[i] = 0.0F; 
/*  506 */       this.index[1] = 0;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  512 */     this.lastInputSample1 = 0.0F;
/*  513 */     this.lastInputSample2 = 0.0F;
/*      */ 
/*      */     
/*  516 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() {
/*  527 */     this.isRateConversionInited = false;
/*      */     
/*  529 */     this.x1 = null;
/*  530 */     this.x2 = null;
/*  531 */     this.y1 = null;
/*  532 */     this.y2 = null;
/*  533 */     this.poly = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDelay() {
/*  545 */     if (false == this.isRateConversionInited) {
/*  546 */       return -3;
/*      */     }
/*  548 */     int outputDelayLength = this.delay;
/*      */     
/*  550 */     if (false == this.useMuLaw) {
/*  551 */       outputDelayLength *= 2;
/*      */     }
/*      */     
/*  554 */     return outputDelayLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int process(byte[] inputData, int inputDataOffset, int inputDataLength, byte[] output, int outputDataOffset) {
/*  589 */     if (false == this.isRateConversionInited) {
/*  590 */       return -3;
/*      */     }
/*  592 */     if (false == this.isDrained && inputDataLength > this.maxInputLength * this.inputSampleSize * this.numberOfInputChannels)
/*      */     {
/*  594 */       enlargeBufferAllocation(inputDataLength);
/*      */     }
/*      */     
/*  597 */     if (0 == inputDataLength) {
/*  598 */       return 0;
/*      */     }
/*      */     
/*  601 */     int inputOffset = this.inputRemainedSamples + this.filterHistoryLength;
/*      */ 
/*      */     
/*  604 */     inputDataLength = extractInput(inputData, inputDataOffset, inputDataLength, inputOffset);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  617 */     int inputLength = inputDataLength + this.inputRemainedSamples;
/*  618 */     int inputBlocks = inputLength / 4 * this.rateIn;
/*  619 */     this.inputRemainedSamples = inputLength - inputBlocks * 4 * this.rateIn;
/*  620 */     inputLength -= this.inputRemainedSamples;
/*      */ 
/*      */     
/*  623 */     inputOffset = this.inputRemainedSamples + this.filterHistoryLength;
/*      */ 
/*      */ 
/*      */     
/*  627 */     if (inputLength == 0) {
/*  628 */       return 0;
/*      */     }
/*      */     
/*  631 */     int outputLength = inputLength / this.rateIn * this.rateOut;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  643 */     int numberOfChannels = 1;
/*  644 */     if (this.channels2To2) {
/*  645 */       numberOfChannels = 2;
/*      */     }
/*  647 */     for (int i = 0; i < numberOfChannels; i++) {
/*      */       float[] arrayOfFloat1; float[] arrayOfFloat2;
/*  649 */       if (i > 0) {
/*  650 */         arrayOfFloat1 = this.x2;
/*  651 */         arrayOfFloat2 = this.y2;
/*      */       } else {
/*  653 */         arrayOfFloat1 = this.x1;
/*  654 */         arrayOfFloat2 = this.y1;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  665 */       switch (this.decimFlag) {
/*      */ 
/*      */         
/*      */         case 3:
/*  669 */           this.index[i] = downsampleMtoL(arrayOfFloat1, arrayOfFloat2, this.index[i], this.poly, 25, 8, 11, (outputLength >> 5) * 11, outputLength >> 2);
/*      */           break;
/*      */         
/*      */         case 2:
/*  673 */           this.index[i] = downsampleMtoL(arrayOfFloat1, arrayOfFloat2, this.index[i], this.poly, 50, 4, 11, (outputLength >> 4) * 11, outputLength >> 2);
/*      */           break;
/*      */         
/*      */         case 1:
/*  677 */           this.index[i] = downsampleMtoL(arrayOfFloat1, arrayOfFloat2, this.index[i], this.poly, 100, 2, 11, (outputLength >> 3) * 11, outputLength >> 2);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 4:
/*  695 */           downsampleM(arrayOfFloat1, arrayOfFloat2, this.poly, 128, 6, outputLength);
/*      */           break;
/*      */         
/*      */         case 5:
/*  699 */           downsampleM(arrayOfFloat1, arrayOfFloat2, this.poly, 128, 4, outputLength);
/*      */           break;
/*      */         
/*      */         case 6:
/*  703 */           downsampleM(arrayOfFloat1, arrayOfFloat2, this.poly, 64, 2, outputLength);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  709 */       for (int j = 0; j < inputOffset; j++) {
/*  710 */         arrayOfFloat1[j] = arrayOfFloat1[j + inputLength];
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  720 */     if (false == this.useMuLaw) {
/*  721 */       if (this.numberOfOutputChannels == 1) {
/*  722 */         Fl2Byte(this.y1, outputLength, output, outputDataOffset);
/*  723 */         return 2 * outputLength;
/*      */       } 
/*      */ 
/*      */       
/*  727 */       if (this.channels1To2) {
/*  728 */         this.y2 = this.y1;
/*      */       }
/*      */       
/*  731 */       Fl2ByteStereo(this.y1, this.y2, outputLength, output, outputDataOffset);
/*  732 */       return 4 * outputLength;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  737 */     convertToMuLaw(this.y1, outputLength, output, outputDataOffset);
/*  738 */     return outputLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int drain(byte[] output, int outputOffset) {
/*  766 */     if (false == this.isRateConversionInited) {
/*  767 */       return -3;
/*      */     }
/*      */     
/*  770 */     int inputSamples = (this.paddingLength + 4 * this.rateIn) * this.numberOfInputChannels * this.inputSampleSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  777 */     this.isDrained = true;
/*      */     
/*  779 */     int actualOutputSamples = (int)(((this.paddingLength + this.inputRemainedSamples) * this.rateOut) / this.rateIn);
/*      */     
/*  781 */     if (false == this.useMuLaw) {
/*  782 */       actualOutputSamples *= 2;
/*      */     }
/*      */     
/*  785 */     int numberOfOutputSamples = process(null, 0, inputSamples, output, outputOffset);
/*      */     
/*  787 */     this.isDrained = false;
/*      */     
/*  789 */     if (actualOutputSamples < numberOfOutputSamples) {
/*  790 */       numberOfOutputSamples = actualOutputSamples;
/*      */     }
/*      */     
/*  793 */     return numberOfOutputSamples;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxOutputLength() {
/*  807 */     if (false == this.isRateConversionInited) {
/*  808 */       return -3;
/*      */     }
/*      */     
/*  811 */     int outputLength = (this.maxInputLength + this.rateIn * 4) * this.rateOut / this.rateIn;
/*      */     
/*  813 */     if (false == this.useMuLaw) {
/*  814 */       outputLength *= 2;
/*      */     }
/*      */     
/*  817 */     return outputLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxOutputLength(int inputLength) {
/*  832 */     if (false == this.isRateConversionInited) {
/*  833 */       return -3;
/*      */     }
/*  835 */     int inputSamples = inputLength / this.inputSampleSize * this.numberOfInputChannels;
/*      */ 
/*      */     
/*  838 */     int outputLength = (inputSamples + this.rateIn * 4) * this.rateOut / this.rateIn;
/*      */     
/*  840 */     if (false == this.useMuLaw) {
/*  841 */       outputLength *= 2;
/*      */     }
/*      */     
/*  844 */     outputLength *= this.numberOfOutputChannels;
/*      */     
/*  846 */     return outputLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDrainMaxLength() {
/*  860 */     if (false == this.isRateConversionInited) {
/*  861 */       return -3;
/*      */     }
/*      */     
/*  864 */     int drainMaxLength = this.maxDrainedSamples;
/*      */     
/*  866 */     if (false == this.useMuLaw) {
/*  867 */       drainMaxLength *= 2;
/*      */     }
/*      */     
/*  870 */     return drainMaxLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void convertToMuLaw(float[] inBuffer, int Len, byte[] outBuffer, int indexOut) {
/*  878 */     for (int i = 0; i < Len; i++) {
/*  879 */       boolean bool; float inSample = inBuffer[i];
/*      */       
/*  881 */       if (inSample < -32767.0F) {
/*  882 */         inSample = -32767.0F;
/*  883 */       } else if (inSample > 32767.0F) {
/*  884 */         inSample = 32767.0F;
/*      */       } 
/*  886 */       int sample = (int)inSample;
/*      */       
/*  888 */       if (sample >= 0) {
/*  889 */         bool = true;
/*      */       } else {
/*  891 */         sample = -sample;
/*  892 */         bool = false;
/*      */       } 
/*  894 */       sample = 132 + sample >> 3;
/*      */       
/*  896 */       if (sample < 32) {
/*  897 */         outBuffer[indexOut++] = (byte)(bool | 0x70 | 31 - (sample >> 0));
/*  898 */       } else if (sample < 64) {
/*  899 */         outBuffer[indexOut++] = (byte)(bool | 0x60 | 31 - (sample >> 1));
/*  900 */       } else if (sample < 128) {
/*  901 */         outBuffer[indexOut++] = (byte)(bool | 0x50 | 31 - (sample >> 2));
/*  902 */       } else if (sample < 256) {
/*  903 */         outBuffer[indexOut++] = (byte)(bool | 0x40 | 31 - (sample >> 3));
/*  904 */       } else if (sample < 512) {
/*  905 */         outBuffer[indexOut++] = (byte)(bool | 0x30 | 31 - (sample >> 4));
/*  906 */       } else if (sample < 1024) {
/*  907 */         outBuffer[indexOut++] = (byte)(bool | 0x20 | 31 - (sample >> 5));
/*  908 */       } else if (sample < 2048) {
/*  909 */         outBuffer[indexOut++] = (byte)(bool | 0x10 | 31 - (sample >> 6));
/*  910 */       } else if (sample < 4096) {
/*  911 */         outBuffer[indexOut++] = (byte)(bool | false | 31 - (sample >> 7));
/*      */       } else {
/*  913 */         outBuffer[indexOut++] = (byte)(bool | false | 0x0);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void Fl2Byte(float[] inBuffer, int Len, byte[] outBuffer, int indexOut) {
/*  922 */     int j = 0;
/*      */ 
/*      */     
/*  925 */     for (int i = 0; i < Len; i++) {
/*      */       
/*  927 */       float sample = inBuffer[i];
/*      */       
/*  929 */       if (sample < -32767.0F) {
/*  930 */         sample = -32767.0F;
/*  931 */       } else if (sample > 32767.0F) {
/*  932 */         sample = 32767.0F;
/*      */       } 
/*      */       
/*  935 */       int TempInt = (int)sample;
/*      */ 
/*      */       
/*  938 */       outBuffer[indexOut + j] = (byte)(TempInt & 0xFF);
/*  939 */       outBuffer[indexOut + j + 1] = (byte)(TempInt >> 8);
/*      */       
/*  941 */       j += 2;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void Fl2ByteStereo(float[] inBuffer1, float[] inBuffer2, int Len, byte[] outBuffer, int indexOut) {
/*  951 */     int j = 0;
/*      */ 
/*      */     
/*  954 */     for (int i = 0; i < Len; i++) {
/*  955 */       float sample = inBuffer1[i];
/*      */       
/*  957 */       if (sample < -32767.0F) {
/*  958 */         sample = -32767.0F;
/*  959 */       } else if (sample > 32767.0F) {
/*  960 */         sample = 32767.0F;
/*      */       } 
/*  962 */       int TempInt = (int)sample;
/*      */       
/*  964 */       outBuffer[indexOut + j] = (byte)(TempInt & 0xFF);
/*  965 */       outBuffer[indexOut + j + 1] = (byte)(TempInt >> 8);
/*      */       
/*  967 */       sample = inBuffer2[i];
/*      */       
/*  969 */       if (sample < -32767.0F) {
/*  970 */         sample = -32767.0F;
/*  971 */       } else if (sample > 32767.0F) {
/*  972 */         sample = 32767.0F;
/*      */       } 
/*      */       
/*  975 */       TempInt = (int)sample;
/*      */ 
/*      */       
/*  978 */       outBuffer[indexOut + j + 2] = (byte)(TempInt & 0xFF);
/*  979 */       outBuffer[indexOut + j + 3] = (byte)(TempInt >> 8);
/*      */       
/*  981 */       j += 4;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int extractInput(byte[] input, int inputOffset, int inputLength, int internalBufferOffset) {
/*      */     byte b1, b2;
/*  992 */     int internalBufferIndex = internalBufferOffset;
/*  993 */     float fsample1 = 0.0F;
/*  994 */     float fsample2 = 0.0F;
/*  995 */     int sample1 = 0;
/*  996 */     int sample2 = 0;
/*  997 */     int inputSample = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1002 */     if (this.isDrained) {
/* 1003 */       int length = inputLength / this.numberOfInputChannels * this.inputSampleSize;
/*      */       int j;
/* 1005 */       for (j = 0; j < length; j++) {
/* 1006 */         this.x1[internalBufferIndex + j] = 0.0F;
/*      */       }
/*      */       
/* 1009 */       if (this.channels2To2) {
/* 1010 */         for (j = 0; j < length; j++) {
/* 1011 */           this.x2[internalBufferIndex + j] = 0.0F;
/*      */         }
/*      */       }
/* 1014 */       return length;
/*      */     } 
/*      */     
/* 1017 */     if (this.pcmType == 1) {
/* 1018 */       b1 = -1;
/* 1019 */       b2 = 1;
/*      */     } else {
/*      */       
/* 1022 */       b1 = 1;
/* 1023 */       b2 = 0;
/*      */     } 
/*      */ 
/*      */     
/* 1027 */     for (int i = inputOffset + b2; i < inputLength + inputOffset; ) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1049 */       if (1 == this.inputSampleSize) {
/* 1050 */         sample1 = input[i++] << 8;
/*      */         
/* 1052 */         if (this.numberOfInputChannels == 2) {
/* 1053 */           sample2 = input[i++] << 8;
/*      */         }
/*      */       } else {
/*      */         
/* 1057 */         sample1 = (input[i] << 8) + (0xFF & input[i + b1]);
/* 1058 */         i += 2;
/*      */         
/* 1060 */         if (this.numberOfInputChannels == 2) {
/* 1061 */           sample2 = (input[i] << 8) + (0xFF & input[i + b1]);
/* 1062 */           i += 2;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1067 */       if (this.channels2To1) {
/* 1068 */         sample1 = (sample1 & this.signMask) + (sample2 & this.signMask) >> 1;
/*      */       }
/*      */ 
/*      */       
/* 1072 */       fsample1 = (short)(sample1 + this.bias);
/*      */       
/* 1074 */       if (this.channels2To2) {
/* 1075 */         fsample2 = (short)(sample2 + this.bias);
/*      */       }
/*      */ 
/*      */       
/* 1079 */       if (this.channels1To2) {
/* 1080 */         fsample2 = fsample1;
/*      */       }
/*      */       
/* 1083 */       if (this.needInputCorrection) {
/*      */         
/* 1085 */         if (this.frac > this.fractionDelimiter) {
/* 1086 */           this.precisionCount++;
/*      */           
/* 1088 */           if (this.precisionCount == this.precisionCountDelimiter) {
/* 1089 */             this.precisionCount = 0;
/* 1090 */             this.frac = this.fractionDelta;
/*      */           }
/*      */           else {
/*      */             
/* 1094 */             this.frac--;
/*      */           } 
/*      */           
/* 1097 */           this.prev_fsample1 = fsample1;
/*      */           
/* 1099 */           this.prev_fsample2 = fsample2;
/*      */           
/*      */           continue;
/*      */         } 
/* 1103 */         this.x1[internalBufferIndex] = this.prev_fsample1 * (1.0F - this.frac) + this.frac * fsample1;
/* 1104 */         this.prev_fsample1 = fsample1;
/*      */ 
/*      */         
/* 1107 */         if (this.channels2To2) {
/* 1108 */           this.x2[internalBufferIndex] = this.prev_fsample2 * (1.0F - this.frac) + this.frac * fsample2;
/* 1109 */           this.prev_fsample2 = fsample2;
/*      */         } 
/*      */ 
/*      */         
/* 1113 */         this.frac += this.fractionDelta;
/*      */       } else {
/*      */         
/* 1116 */         this.x1[internalBufferIndex] = fsample1;
/*      */ 
/*      */         
/* 1119 */         if (this.channels2To2) {
/* 1120 */           this.x2[internalBufferIndex] = fsample2;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1126 */       internalBufferIndex++;
/*      */     } 
/*      */     
/* 1129 */     return internalBufferIndex - internalBufferOffset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private float remove_dc(float[] input, int inputOffset, float previous_sample, int length) {
/* 1151 */     return 0.0F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int downsampleMtoL(float[] x, float[] y, int index, float[] poly, int poly_length, int interpolation_factor, int decimation_factor, int input_block_size, int output_block_size) {
/* 1177 */     int m = 0;
/* 1178 */     for (int n = 0; n < output_block_size; n++) {
/*      */       
/* 1180 */       float sum3 = 0.0F, sum2 = sum3, sum1 = sum2, sum0 = sum1;
/* 1181 */       int offset = index * poly_length;
/* 1182 */       for (int j = 0; j < poly_length; j++) {
/* 1183 */         float polySample = poly[offset + j];
/* 1184 */         sum0 += polySample * x[j + m];
/* 1185 */         sum1 += polySample * x[j + m + 1 * input_block_size];
/* 1186 */         sum2 += polySample * x[j + m + 2 * input_block_size];
/* 1187 */         sum3 += polySample * x[j + m + 3 * input_block_size];
/*      */       } 
/*      */       
/* 1190 */       y[n + 1 * output_block_size] = sum1;
/* 1191 */       y[n + 2 * output_block_size] = sum2;
/* 1192 */       y[n + 3 * output_block_size] = sum3;
/* 1193 */       y[n] = sum0;
/*      */       
/* 1195 */       while (index < decimation_factor) { index += interpolation_factor; m++; }
/* 1196 */        index -= decimation_factor;
/*      */     } 
/*      */     
/* 1199 */     return index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void downsampleM(float[] x, float[] y, float[] filter, int filter_length, int decimation_factor, int output_length) {
/* 1215 */     int filt_length = filter_length / 2;
/*      */ 
/*      */     
/* 1218 */     int offset_inc = decimation_factor * 4;
/*      */ 
/*      */     
/* 1221 */     int sym_offset = filter_length - 1;
/*      */ 
/*      */     
/* 1224 */     for (int offset1 = 0, n = 0; n < output_length; offset1 += offset_inc) {
/* 1225 */       float sum3 = 0.0F, sum2 = sum3, sum1 = sum2, sum0 = sum1;
/* 1226 */       int offset2 = offset1 + decimation_factor;
/* 1227 */       int offset3 = offset2 + decimation_factor;
/* 1228 */       int offset4 = offset3 + decimation_factor;
/*      */ 
/*      */       
/* 1231 */       for (int i = 0; i < filt_length; i++) {
/*      */         
/* 1233 */         float filterSample = filter[i];
/* 1234 */         sum0 += filterSample * (x[offset1 + i] + x[offset1 + sym_offset - i]);
/* 1235 */         sum1 += filterSample * (x[offset2 + i] + x[offset2 + sym_offset - i]);
/* 1236 */         sum2 += filterSample * (x[offset3 + i] + x[offset3 + sym_offset - i]);
/* 1237 */         sum3 += filterSample * (x[offset4 + i] + x[offset4 + sym_offset - i]);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1243 */       y[n++] = sum0;
/* 1244 */       y[n++] = sum1;
/* 1245 */       y[n++] = sum2;
/* 1246 */       y[n++] = sum3;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void enlargeBufferAllocation(int length) {
/* 1262 */     this.maxInputLength = length / this.inputSampleSize * this.numberOfInputChannels;
/*      */ 
/*      */     
/* 1265 */     float[] inputBuffer = new float[this.maxInputLength + this.filterHistoryLength + 4 * this.rateIn];
/* 1266 */     float[] outputBuffer = new float[(this.maxInputLength + this.filterHistoryLength + 4 * this.rateIn) / this.rateIn * this.rateOut];
/*      */     
/*      */     int i;
/* 1269 */     for (i = 0; i < this.x1.length; i++) {
/* 1270 */       inputBuffer[i] = this.x1[i];
/*      */     }
/*      */     
/* 1273 */     for (i = 0; i < this.y1.length; i++) {
/* 1274 */       outputBuffer[i] = this.y1[i];
/*      */     }
/*      */     
/* 1277 */     this.x1 = inputBuffer;
/* 1278 */     this.y1 = outputBuffer;
/*      */     
/* 1280 */     if (this.channels2To2) {
/* 1281 */       inputBuffer = new float[this.maxInputLength + this.filterHistoryLength + 4 * this.rateIn];
/* 1282 */       outputBuffer = new float[(this.maxInputLength + this.filterHistoryLength + 4 * this.rateIn) / this.rateIn * this.rateOut];
/*      */ 
/*      */       
/* 1285 */       for (i = 0; i < this.x2.length; i++) {
/* 1286 */         inputBuffer[i] = this.x2[i];
/*      */       }
/*      */       
/* 1289 */       for (i = 0; i < this.y2.length; i++) {
/* 1290 */         outputBuffer[i] = this.y2[i];
/*      */       }
/*      */       
/* 1293 */       this.x2 = inputBuffer;
/* 1294 */       this.y2 = outputBuffer;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\ibm\media\codec\audio\rc\RateConversion.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */