package com.ibm.media.codec.audio.gsm;

import com.ibm.media.codec.audio.AudioCodec;
import com.ibm.media.codec.audio.AudioPacketizer;
import com.sun.media.BasicPlugIn;
import javax.media.Codec;
import javax.media.Format;
import javax.media.ResourceUnavailableException;
import javax.media.format.AudioFormat;

public class Packetizer extends AudioPacketizer {
  public Packetizer() {
    this.packetSize = 99;
    ((AudioCodec)this).supportedInputFormats = new AudioFormat[] { new AudioFormat("gsm", 8000.0D, -1, 1, -1, -1, 264, -1.0D, Format.byteArray) };
    ((AudioCodec)this).defaultOutputFormats = new AudioFormat[] { new AudioFormat("gsm/rtp", 8000.0D, -1, 1, -1, -1, 264, -1.0D, Format.byteArray) };
    ((AudioCodec)this).PLUGIN_NAME = "GSM Packetizer";
  }
  
  protected Format[] getMatchingOutputFormats(Format in) {
    AudioFormat af = (AudioFormat)in;
    ((AudioCodec)this).supportedOutputFormats = new AudioFormat[] { new AudioFormat("gsm/rtp", 8000.0D, -1, 1, -1, -1, 264, -1.0D, Format.byteArray) };
    return (Format[])((AudioCodec)this).supportedOutputFormats;
  }
  
  public void open() throws ResourceUnavailableException {
    setPacketSize(this.packetSize);
    reset();
  }
  
  public Object[] getControls() {
    if (((BasicPlugIn)this).controls == null) {
      ((BasicPlugIn)this).controls = (Object[])new javax.media.Control[1];
      ((BasicPlugIn)this).controls[0] = new PacketSizeAdapter((Codec)this, this.packetSize, true);
    } 
    return ((BasicPlugIn)this).controls;
  }
  
  public synchronized void setPacketSize(int newPacketSize) {
    this.packetSize = newPacketSize;
    this.sample_count = this.packetSize / 33 * 160;
    if (this.history == null) {
      this.history = new byte[this.packetSize];
      return;
    } 
    if (this.packetSize > this.history.length) {
      byte[] newHistory = new byte[this.packetSize];
      System.arraycopy(this.history, 0, newHistory, 0, this.historyLength);
      this.history = newHistory;
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\codec\audio\gsm\Packetizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */