/*     */ package com.ibm.media.codec.audio.gsm;
/*     */ 
/*     */ import com.ibm.media.codec.audio.AudioCodec;
/*     */ import com.ibm.media.codec.audio.AudioPacketizer;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import javax.media.Codec;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Packetizer
/*     */   extends AudioPacketizer
/*     */ {
/*     */   public Packetizer() {
/*  24 */     this.packetSize = 99;
/*  25 */     ((AudioCodec)this).supportedInputFormats = new AudioFormat[] { new AudioFormat("gsm", 8000.0D, -1, 1, -1, -1, 264, -1.0D, Format.byteArray) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  38 */     ((AudioCodec)this).defaultOutputFormats = new AudioFormat[] { new AudioFormat("gsm/rtp", 8000.0D, -1, 1, -1, -1, 264, -1.0D, Format.byteArray) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  52 */     ((AudioCodec)this).PLUGIN_NAME = "GSM Packetizer";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Format[] getMatchingOutputFormats(Format in) {
/*  58 */     AudioFormat af = (AudioFormat)in;
/*     */     
/*  60 */     ((AudioCodec)this).supportedOutputFormats = new AudioFormat[] { new AudioFormat("gsm/rtp", 8000.0D, -1, 1, -1, -1, 264, -1.0D, Format.byteArray) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     return (Format[])((AudioCodec)this).supportedOutputFormats;
/*     */   }
/*     */   
/*     */   public void open() throws ResourceUnavailableException {
/*  77 */     setPacketSize(this.packetSize);
/*  78 */     reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getControls() {
/*  83 */     if (((BasicPlugIn)this).controls == null) {
/*  84 */       ((BasicPlugIn)this).controls = (Object[])new javax.media.Control[1];
/*  85 */       ((BasicPlugIn)this).controls[0] = new PacketSizeAdapter((Codec)this, this.packetSize, true);
/*     */     } 
/*  87 */     return ((BasicPlugIn)this).controls;
/*     */   }
/*     */   
/*     */   public synchronized void setPacketSize(int newPacketSize) {
/*  91 */     this.packetSize = newPacketSize;
/*     */     
/*  93 */     this.sample_count = this.packetSize / 33 * 160;
/*     */     
/*  95 */     if (this.history == null) {
/*  96 */       this.history = new byte[this.packetSize];
/*     */       
/*     */       return;
/*     */     } 
/* 100 */     if (this.packetSize > this.history.length) {
/* 101 */       byte[] newHistory = new byte[this.packetSize];
/* 102 */       System.arraycopy(this.history, 0, newHistory, 0, this.historyLength);
/* 103 */       this.history = newHistory;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\ibm\media\codec\audio\gsm\Packetizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */