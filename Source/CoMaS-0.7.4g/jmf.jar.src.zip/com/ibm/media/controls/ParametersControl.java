package com.ibm.media.controls;

import java.awt.Component;
import java.util.Hashtable;
import javax.media.Control;

public class ParametersControl implements Control {
  Hashtable parameters = new Hashtable();
  
  public String get(String param) {
    return (String)this.parameters.get(param);
  }
  
  public void set(String param, String value) {
    this.parameters.remove(param);
    this.parameters.put(param, value);
  }
  
  public Component getControlComponent() {
    return null;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\controls\ParametersControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */