package com.ibm.media.util;

import java.io.IOException;
import java.io.InputStream;
import javax.media.protocol.PullSourceStream;

public class PullSourceStream2InputStream extends InputStream {
  PullSourceStream pss;
  
  byte[] buffer = new byte[1];
  
  public PullSourceStream2InputStream(PullSourceStream pss) {
    this.pss = pss;
  }
  
  public int read() throws IOException {
    if (this.pss.endOfStream()) {
      System.out.println("end of stream");
      return -1;
    } 
    this.pss.read(this.buffer, 0, 1);
    return this.buffer[0];
  }
  
  public int read(byte[] b) throws IOException {
    return this.pss.read(b, 0, b.length);
  }
  
  public int read(byte[] b, int off, int len) throws IOException {
    return this.pss.read(b, off, len);
  }
  
  public long skip(long n) throws IOException {
    byte[] buffer = new byte[(int)n];
    int read = read(buffer);
    return read;
  }
  
  public int available() throws IOException {
    System.out.println("available was called");
    return 0;
  }
  
  public void close() throws IOException {}
  
  public boolean markSupported() {
    return false;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\medi\\util\PullSourceStream2InputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */