package com.ibm.media.bean.multiplayer;

import java.util.Vector;
import javax.media.bean.playerbean.MediaPlayer;

public class MediaGroup {
  public String mediaName;
  
  public String gifName;
  
  boolean isButtonGif = true;
  
  int index;
  
  String caption;
  
  MediaPlayer player = null;
  
  ImageButton button = null;
  
  Vector related = null;
  
  private MultiPlayerBean owner = null;
  
  int buttonWidth;
  
  int buttonHeight;
  
  public MediaGroup(String media, String gif, String caption, MultiPlayerBean o) {
    this.mediaName = media;
    this.gifName = gif;
    this.owner = o;
    this.index = this.owner.numOfMGroups++;
    this.owner.doDebug("Creating " + media + ", " + gif);
    if (gif == null || gif.compareTo("") == 0) {
      this.button = this.owner.formButton(this.owner.numOfMGroups);
    } else {
      this.button = this.owner.formButton(this.owner.getURL(gif), this.owner.numOfMGroups);
    } 
    this.buttonWidth = this.button.width;
    this.buttonHeight = this.button.height;
    this.caption = caption;
    this.owner.doDebug("Created: " + media + "\nNext Index: " + this.owner.numOfMGroups);
  }
  
  public MediaGroup(String media, String gif, boolean isGif, String caption, MultiPlayerBean o) {
    this.mediaName = media;
    this.gifName = gif;
    this.caption = caption;
    this.isButtonGif = isGif;
    this.owner = o;
    this.index = this.owner.numOfMGroups++;
  }
  
  protected void finalize() throws Throwable {
    super.finalize();
    this.button = null;
    this.owner = null;
    this.player = null;
    this.related = null;
  }
  
  public void setPlayer(MediaPlayer pb) {
    this.player = pb;
  }
  
  public MediaPlayer getPlayer() {
    return this.player;
  }
  
  public void setButton(ImageButton b) {
    this.button = b;
  }
  
  public ImageButton getButton() {
    return this.button;
  }
  
  public void setIsButtonGif(boolean b) {
    this.isButtonGif = b;
  }
  
  public boolean isButtonGif() {
    return this.isButtonGif;
  }
  
  public void delete() {
    this.owner.deleteMGroup(this.index);
    try {
      finalize();
    } catch (Throwable e) {}
  }
  
  public void setRelated(RelatedLink l) {
    this.owner.doDebug("setRelated: link=" + l.link);
    if (this.related == null)
      this.related = new Vector(); 
    int i = this.related.size() - 1;
    int j = 0;
    boolean insert = false;
    while (j < i && !insert) {
      if (l.startTime > ((RelatedLink)this.related.elementAt(j)).startTime)
        insert = true; 
    } 
    this.related.insertElementAt(l, j);
  }
  
  public void setIndex(int i) {
    this.index = i;
    if (this.button != null)
      this.button.setText(Integer.toString(i + 1)); 
  }
  
  public int getIndex() {
    return this.index;
  }
  
  public Vector getRelated() {
    return this.related;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\bean\multiplayer\MediaGroup.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */