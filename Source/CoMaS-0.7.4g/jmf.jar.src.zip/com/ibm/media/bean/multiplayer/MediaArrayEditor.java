/*     */ package com.ibm.media.bean.multiplayer;
/*     */ 
/*     */ import java.awt.Button;
/*     */ import java.awt.Choice;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.FileDialog;
/*     */ import java.awt.Font;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Label;
/*     */ import java.awt.List;
/*     */ import java.awt.Panel;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.TextField;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.beans.PropertyEditor;
/*     */ import java.beans.PropertyEditorSupport;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MediaArrayEditor
/*     */   extends PropertyEditorSupport
/*     */   implements PropertyEditor, Serializable, ActionListener, ItemListener
/*     */ {
/*  83 */   PropertyChangeSupport support = new PropertyChangeSupport(this);
/*  84 */   Panel guiP = new Panel();
/*     */   transient String[] oldValue;
/*  86 */   List media = new List(10); transient String[] newValue;
/*  87 */   List button = new List(10);
/*  88 */   Label mediaURL = new Label(JMFUtil.getBIString("MEDIA_URL"));
/*  89 */   Label buttonURL = new Label(JMFUtil.getBIString("BUTTON_IMAGE_URL"));
/*  90 */   Button add = new Button(JMFUtil.getBIString("ADD"));
/*  91 */   Button del = new Button(JMFUtil.getBIString("DELETE"));
/*  92 */   Button up = new Button(JMFUtil.getBIString("UP"));
/*  93 */   Button down = new Button(JMFUtil.getBIString("DOWN"));
/*  94 */   Label one = new Label("1", 1);
/*  95 */   Label two = new Label("2", 1);
/*  96 */   Label three = new Label("3", 1);
/*  97 */   Label four = new Label("4", 1);
/*  98 */   Label five = new Label("5", 1);
/*  99 */   Label six = new Label("6", 1);
/* 100 */   Label seven = new Label("7", 1);
/* 101 */   Label eight = new Label("8", 1);
/* 102 */   Label nine = new Label("9", 1);
/* 103 */   Label ten = new Label("10", 1);
/* 104 */   GridBagLayout gridbag = new GridBagLayout();
/* 105 */   GridBagConstraints c = new GridBagConstraints();
/*     */ 
/*     */   
/* 108 */   Panel addPanel = null;
/* 109 */   Choice mediaChoice = new Choice();
/* 110 */   Choice buttonChoice = new Choice();
/* 111 */   TextField mediaField = new TextField(20);
/* 112 */   TextField buttonField = new TextField(20);
/* 113 */   String codebase = "codebase/";
/* 114 */   String http = "http://";
/* 115 */   String fileS = "file:///";
/* 116 */   private String browseString = "...";
/* 117 */   private Button mediaBrowse = new Button(this.browseString);
/* 118 */   private Button buttonBrowse = new Button(this.browseString);
/* 119 */   private String browseDir = ".";
/*     */   
/* 121 */   Panel pan = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getCustomEditor() {
/* 128 */     if (this.pan == null) {
/* 129 */       this.pan = createGuiPanel();
/*     */     }
/* 131 */     if ((this.pan.getSize()).width > 600)
/* 132 */       this.pan.setSize(600, (this.pan.getSize()).height); 
/* 133 */     return this.pan;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAsText(String s) {
/* 145 */     setValue(JMFUtil.parseStringIntoArray(s));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAsText() {
/* 158 */     return JMFUtil.parseArrayIntoString(this.newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getJavaInitializationString() {
/* 175 */     StringBuffer initString = new StringBuffer("");
/*     */     
/* 177 */     if (this.newValue != null) {
/*     */       
/* 179 */       initString = new StringBuffer("new String[] {\"");
/* 180 */       for (int i = 0; i < this.newValue.length; i++) {
/*     */         
/* 182 */         initString.append(JMFUtil.convertString(this.newValue[i]));
/* 183 */         if (i + 1 != this.newValue.length)
/*     */         {
/* 185 */           initString.append("\",\"");
/*     */         }
/*     */       } 
/* 188 */       initString.append("\"}");
/*     */     } 
/* 190 */     return initString.toString() + ",this";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintValue(Graphics g, Rectangle r) {
/* 198 */     g.setColor(Color.black);
/* 199 */     g.draw3DRect(1, 1, r.width - 2, r.height - 2, true);
/* 200 */     g.setColor(Color.black);
/* 201 */     g.setFont(new Font("Helevetica", 1, 9));
/* 202 */     g.drawString(getAsText(), 5, r.height / 2 + 5);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supportsCustomEditor() {
/* 208 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPaintable() {
/* 214 */     return true;
/*     */   }
/*     */   
/*     */   public void setValue(Object val) {
/* 218 */     String newStrng = "";
/* 219 */     this.oldValue = this.newValue;
/* 220 */     if (val instanceof String)
/* 221 */     { this.newValue = JMFUtil.parseStringIntoArray((String)val); }
/* 222 */     else { this.newValue = (String[])val; }
/*     */ 
/*     */     
/* 225 */     newStrng = JMFUtil.parseArrayIntoString(this.newValue);
/* 226 */     doDebug("firePropertyChange in MediaNames: " + newStrng);
/* 227 */     this.support.firePropertyChange("mediaNames", (Object)null, this.newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue() {
/* 238 */     return this.newValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Panel createGuiPanel() {
/* 245 */     this.guiP.setLayout(this.gridbag);
/* 246 */     this.guiP.setBackground(Color.lightGray);
/* 247 */     this.guiP.setForeground(Color.black);
/*     */ 
/*     */ 
/*     */     
/* 251 */     this.c.gridx = 2;
/* 252 */     this.c.gridy = 1;
/* 253 */     this.c.gridwidth = 5;
/* 254 */     this.c.gridheight = 1;
/* 255 */     this.c.anchor = 10;
/* 256 */     this.c.fill = 2;
/* 257 */     this.c.weightx = 1.0D;
/* 258 */     this.c.weighty = 0.0D;
/* 259 */     this.mediaURL.setAlignment(1);
/* 260 */     this.guiP.add(this.mediaURL, this.c);
/*     */ 
/*     */     
/* 263 */     this.c.gridx = 7;
/* 264 */     this.c.gridy = 1;
/* 265 */     this.c.gridwidth = 5;
/* 266 */     this.c.gridheight = 1;
/* 267 */     this.c.anchor = 10;
/* 268 */     this.c.fill = 2;
/* 269 */     this.c.weightx = 1.0D;
/* 270 */     this.c.weighty = 0.0D;
/* 271 */     this.buttonURL.setAlignment(1);
/* 272 */     this.guiP.add(this.buttonURL, this.c);
/*     */     
/* 274 */     refreshLists();
/*     */ 
/*     */     
/* 277 */     this.c.gridx = 1;
/* 278 */     this.c.gridy = 2;
/* 279 */     this.c.gridwidth = 1;
/* 280 */     this.c.gridheight = 1;
/* 281 */     this.c.anchor = 10;
/* 282 */     this.c.fill = 2;
/* 283 */     this.c.weightx = 0.0D;
/* 284 */     this.c.weighty = 0.0D;
/* 285 */     this.guiP.add(this.one, this.c);
/*     */     
/* 287 */     this.c.gridx = 1;
/* 288 */     this.c.gridy = 3;
/* 289 */     this.c.gridwidth = 1;
/* 290 */     this.c.gridheight = 1;
/* 291 */     this.c.anchor = 10;
/* 292 */     this.c.fill = 2;
/* 293 */     this.c.weightx = 0.0D;
/* 294 */     this.c.weighty = 0.0D;
/* 295 */     this.guiP.add(this.two, this.c);
/*     */     
/* 297 */     this.c.gridx = 1;
/* 298 */     this.c.gridy = 4;
/* 299 */     this.c.gridwidth = 1;
/* 300 */     this.c.gridheight = 1;
/* 301 */     this.c.anchor = 10;
/* 302 */     this.c.fill = 2;
/* 303 */     this.c.weightx = 0.0D;
/* 304 */     this.c.weighty = 0.0D;
/* 305 */     this.guiP.add(this.three, this.c);
/*     */     
/* 307 */     this.c.gridx = 1;
/* 308 */     this.c.gridy = 5;
/* 309 */     this.c.gridwidth = 1;
/* 310 */     this.c.gridheight = 1;
/* 311 */     this.c.anchor = 10;
/* 312 */     this.c.fill = 2;
/* 313 */     this.c.weightx = 0.0D;
/* 314 */     this.c.weighty = 0.0D;
/* 315 */     this.guiP.add(this.four, this.c);
/*     */     
/* 317 */     this.c.gridx = 1;
/* 318 */     this.c.gridy = 6;
/* 319 */     this.c.gridwidth = 1;
/* 320 */     this.c.gridheight = 1;
/* 321 */     this.c.anchor = 10;
/* 322 */     this.c.fill = 2;
/* 323 */     this.c.weightx = 0.0D;
/* 324 */     this.c.weighty = 0.0D;
/* 325 */     this.guiP.add(this.five, this.c);
/*     */     
/* 327 */     this.c.gridx = 1;
/* 328 */     this.c.gridy = 7;
/* 329 */     this.c.gridwidth = 1;
/* 330 */     this.c.gridheight = 1;
/* 331 */     this.c.anchor = 10;
/* 332 */     this.c.fill = 2;
/* 333 */     this.c.weightx = 0.0D;
/* 334 */     this.c.weighty = 0.0D;
/* 335 */     this.guiP.add(this.six, this.c);
/*     */     
/* 337 */     this.c.gridx = 1;
/* 338 */     this.c.gridy = 8;
/* 339 */     this.c.gridwidth = 1;
/* 340 */     this.c.gridheight = 1;
/* 341 */     this.c.anchor = 10;
/* 342 */     this.c.fill = 2;
/* 343 */     this.c.weightx = 0.0D;
/* 344 */     this.c.weighty = 0.0D;
/* 345 */     this.guiP.add(this.seven, this.c);
/*     */     
/* 347 */     this.c.gridx = 1;
/* 348 */     this.c.gridy = 9;
/* 349 */     this.c.gridwidth = 1;
/* 350 */     this.c.gridheight = 1;
/* 351 */     this.c.anchor = 10;
/* 352 */     this.c.fill = 2;
/* 353 */     this.c.weightx = 0.0D;
/* 354 */     this.c.weighty = 0.0D;
/* 355 */     this.guiP.add(this.eight, this.c);
/*     */     
/* 357 */     this.c.gridx = 1;
/* 358 */     this.c.gridy = 10;
/* 359 */     this.c.gridwidth = 1;
/* 360 */     this.c.gridheight = 1;
/* 361 */     this.c.anchor = 10;
/* 362 */     this.c.fill = 2;
/* 363 */     this.c.weightx = 0.0D;
/* 364 */     this.c.weighty = 0.0D;
/* 365 */     this.guiP.add(this.nine, this.c);
/*     */     
/* 367 */     this.c.gridx = 1;
/* 368 */     this.c.gridy = 11;
/* 369 */     this.c.gridwidth = 1;
/* 370 */     this.c.gridheight = 1;
/* 371 */     this.c.anchor = 10;
/* 372 */     this.c.fill = 2;
/* 373 */     this.c.weightx = 0.0D;
/* 374 */     this.c.weighty = 0.0D;
/* 375 */     this.guiP.add(this.ten, this.c);
/*     */ 
/*     */     
/* 378 */     this.c.gridx = 2;
/* 379 */     this.c.gridy = 2;
/* 380 */     this.c.gridwidth = 5;
/* 381 */     this.c.gridheight = 10;
/* 382 */     this.c.anchor = 10;
/* 383 */     this.c.fill = 1;
/* 384 */     this.c.weightx = 1.0D;
/* 385 */     this.c.weighty = 1.0D;
/* 386 */     this.media.addItemListener(this);
/* 387 */     this.guiP.add(this.media, this.c);
/*     */ 
/*     */     
/* 390 */     this.c.gridx = 7;
/* 391 */     this.c.gridy = 2;
/* 392 */     this.c.gridwidth = 5;
/* 393 */     this.c.gridheight = 10;
/* 394 */     this.c.anchor = 10;
/* 395 */     this.c.fill = 1;
/* 396 */     this.c.weightx = 1.0D;
/* 397 */     this.c.weighty = 1.0D;
/* 398 */     this.button.addItemListener(this);
/* 399 */     this.guiP.add(this.button, this.c);
/*     */ 
/*     */     
/* 402 */     this.c.gridx = 2;
/* 403 */     this.c.gridy = 12;
/* 404 */     this.c.gridwidth = 5;
/* 405 */     this.c.gridheight = 1;
/* 406 */     this.c.anchor = 13;
/* 407 */     this.c.fill = 2;
/* 408 */     this.c.weightx = 1.0D;
/* 409 */     this.c.weighty = 0.0D;
/* 410 */     this.c.insets = new Insets(5, 0, 0, 5);
/* 411 */     this.mediaChoice.addItemListener(this);
/* 412 */     this.mediaChoice.add(this.codebase);
/* 413 */     this.mediaChoice.add(this.http);
/* 414 */     this.mediaChoice.add(this.fileS);
/* 415 */     this.mediaBrowse.addActionListener(this);
/* 416 */     this.mediaBrowse.setActionCommand("browseMedia");
/* 417 */     this.mediaBrowse.setEnabled(false);
/* 418 */     Component[] comp1 = { this.mediaChoice, this.mediaField, this.mediaBrowse };
/* 419 */     Panel p1 = JMFUtil.doGridbagLayout2(comp1, 3, 2);
/* 420 */     this.guiP.add(p1, this.c);
/*     */ 
/*     */     
/* 423 */     this.c.gridx = 7;
/* 424 */     this.c.gridy = 12;
/* 425 */     this.c.gridwidth = 5;
/* 426 */     this.c.gridheight = 1;
/* 427 */     this.c.anchor = 13;
/* 428 */     this.c.fill = 2;
/* 429 */     this.c.weightx = 1.0D;
/* 430 */     this.c.weighty = 0.0D;
/* 431 */     this.c.insets = new Insets(5, 0, 0, 5);
/* 432 */     this.buttonChoice.addItemListener(this);
/* 433 */     this.buttonChoice.add(this.codebase);
/* 434 */     this.buttonChoice.add(this.http);
/* 435 */     this.buttonChoice.add(this.fileS);
/* 436 */     this.buttonBrowse.addActionListener(this);
/* 437 */     this.buttonBrowse.setActionCommand("browseButton");
/* 438 */     this.buttonBrowse.setEnabled(false);
/* 439 */     Component[] comp2 = { this.buttonChoice, this.buttonField, this.buttonBrowse };
/* 440 */     Panel p2 = JMFUtil.doGridbagLayout2(comp2, 3, 2);
/* 441 */     this.guiP.add(p2, this.c);
/*     */ 
/*     */     
/* 444 */     this.c.gridx = 2;
/* 445 */     this.c.gridy = 13;
/* 446 */     this.c.gridwidth = 5;
/* 447 */     this.c.gridheight = 1;
/* 448 */     this.c.anchor = 16;
/* 449 */     this.c.fill = 2;
/* 450 */     this.c.weightx = 1.0D;
/* 451 */     this.c.weighty = 0.0D;
/* 452 */     this.add.setActionCommand("add");
/* 453 */     this.add.addActionListener(this);
/* 454 */     this.add.setEnabled(true);
/* 455 */     this.guiP.add(this.add, this.c);
/*     */ 
/*     */     
/* 458 */     this.c.gridx = 7;
/* 459 */     this.c.gridy = 13;
/* 460 */     this.c.gridwidth = 5;
/* 461 */     this.c.gridheight = 1;
/* 462 */     this.c.anchor = 18;
/* 463 */     this.c.fill = 2;
/* 464 */     this.c.weightx = 1.0D;
/* 465 */     this.c.weighty = 0.0D;
/* 466 */     this.del.setActionCommand("del");
/* 467 */     this.del.addActionListener(this);
/* 468 */     this.del.setEnabled(false);
/* 469 */     this.guiP.add(this.del, this.c);
/*     */ 
/*     */     
/* 472 */     this.c.gridx = 2;
/* 473 */     this.c.gridy = 14;
/* 474 */     this.c.gridwidth = 5;
/* 475 */     this.c.gridheight = 1;
/* 476 */     this.c.anchor = 16;
/* 477 */     this.c.fill = 2;
/* 478 */     this.c.weightx = 1.0D;
/* 479 */     this.c.weighty = 0.0D;
/* 480 */     this.up.setActionCommand("up");
/* 481 */     this.up.addActionListener(this);
/* 482 */     this.up.setEnabled(false);
/* 483 */     this.guiP.add(this.up, this.c);
/*     */ 
/*     */     
/* 486 */     this.c.gridx = 7;
/* 487 */     this.c.gridy = 14;
/* 488 */     this.c.gridwidth = 5;
/* 489 */     this.c.gridheight = 1;
/* 490 */     this.c.anchor = 18;
/* 491 */     this.c.fill = 2;
/* 492 */     this.c.weightx = 1.0D;
/* 493 */     this.c.weighty = 0.0D;
/* 494 */     this.down.setActionCommand("down");
/* 495 */     this.down.addActionListener(this);
/* 496 */     this.down.setEnabled(false);
/* 497 */     this.guiP.add(this.down, this.c);
/*     */     
/* 499 */     return this.guiP;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void refreshLists() {
/* 509 */     this.media.removeAll();
/* 510 */     this.button.removeAll();
/*     */     
/* 512 */     if (this.newValue != null) {
/* 513 */       for (int i = 0; i < this.newValue.length; i += 2) {
/*     */         
/* 515 */         this.media.add(this.newValue[i]);
/* 516 */         this.button.add(this.newValue[i + 1]);
/*     */       } 
/*     */     }
/* 519 */     this.media.setSize(75, 232);
/* 520 */     this.button.setSize(75, 232);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void actionPerformed(ActionEvent e) {
/* 534 */     if (e.getActionCommand().equals("add")) {
/*     */       
/* 536 */       processAdd();
/*     */     
/*     */     }
/* 539 */     else if (e.getActionCommand().equals("del")) {
/*     */       
/* 541 */       deleteGroup();
/*     */     
/*     */     }
/* 544 */     else if (e.getActionCommand().equals("up")) {
/*     */       
/* 546 */       moveSelectedUp();
/*     */     
/*     */     }
/* 549 */     else if (e.getActionCommand().equals("down")) {
/*     */       
/* 551 */       moveSelectedDown();
/*     */     
/*     */     }
/* 554 */     else if (e.getActionCommand().equals("browseMedia")) {
/*     */       
/* 556 */       getFile(this.mediaField);
/*     */     
/*     */     }
/* 559 */     else if (e.getActionCommand().equals("browseButton")) {
/*     */       
/* 561 */       getFile(this.buttonField);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void itemStateChanged(ItemEvent e) {
/* 576 */     Object o1 = e.getItemSelectable();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 581 */     if (o1 instanceof List) {
/*     */       
/* 583 */       List l1 = (List)o1;
/* 584 */       int i = ((Integer)e.getItem()).intValue();
/* 585 */       int state = e.getStateChange();
/*     */ 
/*     */       
/* 588 */       if (l1 == this.media || l1 == this.button) {
/*     */         List list;
/* 590 */         if (l1 == this.media) { list = this.button; }
/* 591 */         else { list = this.media; }
/*     */ 
/*     */         
/* 594 */         if (state == 1)
/*     */         {
/* 596 */           list.select(i);
/* 597 */           this.del.setEnabled(true);
/* 598 */           enableUpDown(i);
/*     */         
/*     */         }
/* 601 */         else if (state == 2)
/*     */         {
/* 603 */           list.deselect(i);
/* 604 */           this.down.setEnabled(false);
/* 605 */           this.up.setEnabled(false);
/* 606 */           this.del.setEnabled(false);
/*     */         }
/*     */       
/*     */       } 
/* 610 */     } else if (o1 instanceof Choice) {
/*     */       
/* 612 */       Choice c1 = (Choice)o1;
/* 613 */       String protocol = c1.getSelectedItem();
/* 614 */       if (c1 == this.mediaChoice) {
/*     */         
/* 616 */         if (protocol.equals(this.fileS)) {
/* 617 */           this.mediaBrowse.setEnabled(true);
/*     */         } else {
/* 619 */           this.mediaBrowse.setEnabled(false);
/*     */         } 
/* 621 */       } else if (c1 == this.buttonChoice) {
/*     */         
/* 623 */         if (protocol.equals(this.fileS)) {
/* 624 */           this.buttonBrowse.setEnabled(true);
/*     */         } else {
/* 626 */           this.buttonBrowse.setEnabled(false);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void processAdd() {
/* 634 */     StringBuffer mText = new StringBuffer();
/* 635 */     StringBuffer bText = new StringBuffer();
/* 636 */     String mString = this.mediaField.getText();
/* 637 */     String bString = this.buttonField.getText();
/* 638 */     String bChoice = this.buttonChoice.getSelectedItem();
/* 639 */     String mChoice = this.mediaChoice.getSelectedItem();
/*     */ 
/*     */ 
/*     */     
/* 643 */     if (mString.equals("")) {
/*     */       
/* 645 */       DTMsgBox.createAndGo(JMFUtil.getBIString("JMF_MultiPlayer"), JMFUtil.getBIString("NOVALUE"));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 650 */     if (!mChoice.equals(this.codebase)) {
/*     */       
/* 652 */       mText.append(mChoice);
/* 653 */       mText.append(mString);
/*     */     }
/*     */     else {
/*     */       
/* 657 */       mText.append(mString);
/*     */     } 
/*     */     
/* 660 */     if (!bString.equals("")) {
/*     */       
/* 662 */       if (!bChoice.equals(this.codebase)) {
/*     */         
/* 664 */         bText.append(bChoice);
/* 665 */         bText.append(bString);
/*     */       }
/*     */       else {
/*     */         
/* 669 */         bText.append(bString);
/*     */       } 
/*     */     } else {
/* 672 */       bText.append("");
/*     */     } 
/*     */     
/* 675 */     int l = 0;
/*     */     
/* 677 */     if (this.newValue != null) {
/* 678 */       l = this.newValue.length;
/*     */     }
/* 680 */     doDebug("Old length = " + l);
/* 681 */     String[] temp = new String[l + 2];
/* 682 */     JMFUtil.copyStringArray(this.newValue, temp);
/* 683 */     temp[l] = mText.toString();
/* 684 */     temp[l + 1] = bText.toString();
/* 685 */     this.media.add(temp[l]);
/* 686 */     this.button.add(temp[l + 1]);
/* 687 */     this.mediaField.setText("");
/* 688 */     this.buttonField.setText("");
/* 689 */     setValue(temp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void moveSelectedUp() {
/* 701 */     int i = this.media.getSelectedIndex();
/*     */     
/* 703 */     if (i != 0) {
/*     */       
/* 705 */       String mURL = this.media.getSelectedItem();
/* 706 */       String bURL = this.button.getSelectedItem();
/*     */ 
/*     */       
/* 709 */       this.media.remove(i);
/* 710 */       this.button.remove(i);
/*     */       
/* 712 */       this.media.add(mURL, i - 1);
/* 713 */       this.button.add(bURL, i - 1);
/*     */       
/* 715 */       this.media.select(i - 1);
/* 716 */       this.button.select(i - 1);
/*     */       
/* 718 */       this.newValue[i * 2] = this.newValue[(i - 1) * 2];
/* 719 */       this.newValue[i * 2 + 1] = this.newValue[(i - 1) * 2 + 1];
/* 720 */       this.newValue[(i - 1) * 2] = mURL;
/* 721 */       this.newValue[(i - 1) * 2 + 1] = bURL;
/*     */       
/* 723 */       setValue(this.newValue);
/*     */       
/* 725 */       enableUpDown(i - 1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void moveSelectedDown() {
/* 737 */     int i = this.media.getSelectedIndex();
/*     */     
/* 739 */     if (i != this.media.getItemCount() - 1) {
/*     */       
/* 741 */       String mURL = this.media.getSelectedItem();
/* 742 */       String bURL = this.button.getSelectedItem();
/*     */ 
/*     */       
/* 745 */       this.media.remove(i);
/* 746 */       this.button.remove(i);
/*     */       
/* 748 */       this.media.add(mURL, i + 1);
/* 749 */       this.button.add(bURL, i + 1);
/*     */       
/* 751 */       this.media.select(i + 1);
/* 752 */       this.button.select(i + 1);
/*     */       
/* 754 */       this.newValue[i * 2] = this.newValue[(i + 1) * 2];
/* 755 */       this.newValue[i * 2 + 1] = this.newValue[(i + 1) * 2 + 1];
/* 756 */       this.newValue[(i + 1) * 2] = mURL;
/* 757 */       this.newValue[(i + 1) * 2 + 1] = bURL;
/*     */       
/* 759 */       setValue(this.newValue);
/*     */       
/* 761 */       enableUpDown(i + 1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void enableUpDown(int i) {
/* 773 */     if (i < this.media.getItemCount() - 1) {
/*     */       
/* 775 */       this.down.setEnabled(true);
/*     */     }
/*     */     else {
/*     */       
/* 779 */       this.down.setEnabled(false);
/*     */     } 
/*     */     
/* 782 */     if (i > 0) {
/*     */       
/* 784 */       this.up.setEnabled(true);
/*     */     }
/*     */     else {
/*     */       
/* 788 */       this.up.setEnabled(false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void deleteGroup() {
/* 799 */     String[] temp = null;
/* 800 */     int j = this.media.getSelectedIndex();
/* 801 */     int index = j * 2;
/* 802 */     int newSize = 0;
/*     */ 
/*     */     
/* 805 */     if (this.newValue != null) {
/*     */       
/* 807 */       newSize = this.newValue.length - 2;
/* 808 */       doDebug("NewValue size = " + newSize);
/* 809 */       if (newSize > 0) {
/*     */         
/* 811 */         temp = new String[newSize];
/* 812 */         JMFUtil.copyShortenStringArray(this.newValue, temp, index, 2);
/*     */       } 
/*     */     } 
/* 815 */     doDebug("Temp = " + temp);
/*     */     
/* 817 */     this.media.remove(j);
/* 818 */     this.button.remove(j);
/*     */     
/* 820 */     if (this.media.getItemCount() > j + 1) {
/*     */       
/* 822 */       this.media.select(j);
/* 823 */       this.button.select(j);
/* 824 */       enableUpDown(j);
/*     */     }
/* 826 */     else if (this.media.getItemCount() > 0) {
/*     */       
/* 828 */       this.media.select(j - 1);
/* 829 */       this.button.select(j - 1);
/* 830 */       enableUpDown(j - 1);
/*     */     }
/*     */     else {
/*     */       
/* 834 */       enableUpDown(-1);
/* 835 */       this.del.setEnabled(false);
/*     */     } 
/*     */     
/* 838 */     setValue(temp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Frame getFrame(Component comp) {
/* 852 */     Point p = comp.getLocationOnScreen();
/* 853 */     Frame f = new Frame();
/* 854 */     f.setLocation(p);
/* 855 */     return f;
/*     */   }
/*     */   
/*     */   private void getFile(TextField tf) {
/*     */     String str1;
/* 860 */     doDebug("getFile " + tf);
/*     */     
/* 862 */     if (tf == this.mediaField) {
/* 863 */       str1 = JMFUtil.getBIString("SET_MEDIA_LOCATION");
/*     */     } else {
/* 865 */       str1 = JMFUtil.getBIString("SET_BUTTON_LOCATION");
/* 866 */     }  FileDialog fd = new FileDialog(getFrame(this.guiP), str1, 0);
/* 867 */     fd.setDirectory(this.browseDir);
/* 868 */     fd.setTitle(str1);
/* 869 */     fd.show();
/* 870 */     String filename = fd.getFile();
/* 871 */     if (fd.getDirectory() != null) {
/* 872 */       this.browseDir = fd.getDirectory();
/*     */     }
/* 874 */     if (filename != null && fd.getDirectory() != null)
/*     */     {
/* 876 */       filename = fd.getDirectory() + filename;
/*     */     }
/*     */     
/* 879 */     if (filename != null) {
/*     */       
/* 881 */       filename = filename.replace('\\', '/');
/* 882 */       tf.setText(filename);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doDebug(String s) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPropertyChangeListener(PropertyChangeListener listener) {
/* 903 */     this.support.addPropertyChangeListener(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removePropertyChangeListener(PropertyChangeListener listener) {
/* 916 */     this.support.removePropertyChangeListener(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getTags() {
/* 928 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\ibm\media\bean\multiplayer\MediaArrayEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */