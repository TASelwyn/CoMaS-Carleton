package com.ibm.media.bean.multiplayer;

import java.applet.Applet;
import java.applet.AppletContext;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.beans.Beans;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Vector;
import javax.media.ClockStartedError;
import javax.media.ControllerEvent;
import javax.media.ControllerListener;
import javax.media.Time;
import javax.media.bean.playerbean.MediaPlayer;

public class MultiPlayerBean extends Panel implements ActionListener, Serializable, ControllerListener, ComponentListener {
  transient Panel buttonPanel;
  
  transient Panel gifPanel;
  
  transient Panel scrollPanel;
  
  transient Panel utilPanel;
  
  transient Panel videoPanel;
  
  transient ImageButton up;
  
  transient ImageButton down;
  
  transient ImageButton left;
  
  transient ImageButton right;
  
  private MediaPlayer currentPlayer = null;
  
  transient Button infoButton;
  
  transient GridBagLayout gridbag = new GridBagLayout();
  
  transient GridBagConstraints constraint = new GridBagConstraints();
  
  private final String infoWindow = JMFUtil.getString("Info");
  
  private URL currentU = null;
  
  private boolean displayURL = false;
  
  private boolean panelVisible = true;
  
  private boolean fitVideo = true;
  
  private boolean looping = true;
  
  private boolean sequential = true;
  
  private URL mpCodeBase = null;
  
  private AppletContext mpAppletContext = null;
  
  private int currentNum;
  
  private int numOfClips = 0;
  
  protected int numOfMGroups = 0;
  
  private int preferredHeight = 400;
  
  private int preferredWidth = 300;
  
  private String linksString;
  
  private String[] mediaNames;
  
  private String[] links;
  
  public MediaGroup[] mGroups;
  
  private int maxMediaGroup = 10;
  
  private boolean loadOnInit = false;
  
  private boolean fixAspectRatio = true;
  
  private int startingButton = 1;
  
  private String buttonPosition = JMFUtil.getString("SOUTH");
  
  private int tabsize = 16;
  
  private boolean msVM = false;
  
  private PropertyChangeSupport changes = new PropertyChangeSupport(this);
  
  public MultiPlayerBean() {
    setup();
  }
  
  private void getContext(Object parent) {
    if (parent == null)
      parent = getParent(); 
    if (this.mpCodeBase != null)
      return; 
    if (parent instanceof Applet) {
      this.mpCodeBase = ((Applet)parent).getCodeBase();
      this.mpAppletContext = ((Applet)parent).getAppletContext();
    } 
  }
  
  private void setup() {
    getContext(null);
    if (!JMFUtil.msVersion()) {
      this.msVM = false;
      doDebug("Not Microsoft VM");
    } else {
      this.msVM = true;
      doDebug("Microsoft VM");
    } 
    setLayout(new BorderLayout(0, 0));
    setBackground(getBackground());
    this.currentPlayer = null;
    this.buttonPanel = new Panel();
    this.buttonPanel.setLayout(new BorderLayout(0, 0));
    this.buttonPanel.setBackground(getBackground());
    this.buttonPanel.setVisible(false);
    this.gifPanel = new Panel();
    this.gifPanel.setBackground(getBackground());
    this.gifPanel.setVisible(false);
    this.gifPanel.addComponentListener(this);
    this.scrollPanel = new Panel();
    this.scrollPanel.setLayout(new BorderLayout(0, 0));
    this.scrollPanel.setBackground(getBackground());
    this.scrollPanel.add("Center", this.gifPanel);
    this.buttonPanel.add("Center", this.scrollPanel);
    this.infoButton = new Button(JMFUtil.getString("Link"));
    this.infoButton.setActionCommand("info");
    this.infoButton.addActionListener(this);
    this.infoButton.setEnabled(true);
    this.infoButton.setVisible(true);
    this.utilPanel = new Panel();
    this.utilPanel.setBackground(getBackground());
    this.utilPanel.setVisible(false);
    this.utilPanel.add("Center", this.infoButton);
    this.videoPanel = new Panel(this) {
        private final MultiPlayerBean this$0;
        
        public Insets insets() {
          return new Insets(10, 10, 10, 10);
        }
      };
    this.videoPanel.setBounds((getBounds()).x, (getBounds()).y, (getSize()).width, (getSize()).height - (this.buttonPanel.getSize()).height);
    this.videoPanel.setLayout(new BorderLayout(0, 0));
    this.videoPanel.setBackground(getBackground());
    this.videoPanel.setVisible(true);
    this.utilPanel.setVisible(true);
    this.buttonPanel.setVisible(true);
    this.videoPanel.validate();
    setLayout(new BorderLayout());
    position();
  }
  
  private void position() {
    remove(this.videoPanel);
    remove(this.buttonPanel);
    if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("WEST"))) {
      add("Center", this.videoPanel);
      add("West", this.buttonPanel);
    } else if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("EAST"))) {
      add("Center", this.videoPanel);
      add("East", this.buttonPanel);
    } else if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("SOUTH"))) {
      add("Center", this.videoPanel);
      add("South", this.buttonPanel);
    } else if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("NORTH"))) {
      add("Center", this.videoPanel);
      add("North", this.buttonPanel);
    } else {
      add("Center", this.videoPanel);
    } 
    updateGifPanel();
  }
  
  private void createLeftRight(int height) {
    this.left = new ImageButton("<", true, this.tabsize, height);
    this.right = new ImageButton(">", true, this.tabsize, height);
    this.left.setActionCommand("left");
    this.right.setActionCommand("right");
    this.left.addActionListener(this);
    this.right.addActionListener(this);
    this.left.setBackground(Color.lightGray);
    this.right.setBackground(Color.lightGray);
  }
  
  private void createUpDown(int width) {
    this.up = new ImageButton("UP", true, width, this.tabsize);
    this.down = new ImageButton("DOWN", true, width, this.tabsize);
    this.up.setActionCommand("up");
    this.down.setActionCommand("down");
    this.up.addActionListener(this);
    this.down.addActionListener(this);
    this.up.setBackground(Color.lightGray);
    this.down.setBackground(Color.lightGray);
  }
  
  public void start() {
    doDebug("in start()");
    if (this.loadOnInit)
      for (int i = 0; i < this.numOfMGroups; i++)
        this.mGroups[i].setPlayer(formPlayer((this.mGroups[i]).mediaName));  
    this.videoPanel.setBounds((getBounds()).x, (getBounds()).y, (getSize()).width, (getSize()).height - (this.buttonPanel.getSize()).height);
    this.videoPanel.setVisible(true);
    pauseCurrent();
    setPlayer(1);
    validate();
    repaint();
  }
  
  public void stop() {
    doDebug("in stop()");
    if (this.currentPlayer != null)
      this.currentPlayer.stop(); 
  }
  
  public void destroy() {
    doDebug("in destroy()");
    this.currentPlayer.stop();
    this.currentPlayer.close();
    this.numOfClips = 0;
    System.out.println("out destroy");
  }
  
  public synchronized void controllerUpdate(ControllerEvent evt) {
    if (evt instanceof javax.media.EndOfMediaEvent) {
      if (!this.looping && this.currentPlayer != null)
        this.currentPlayer.setMediaTime(new Time(0L)); 
      if (this.sequential)
        nextPlayer(); 
    } 
  }
  
  public void actionPerformed(ActionEvent e) {
    if (e.getActionCommand().equalsIgnoreCase("info") && this.mpAppletContext != null) {
      doDebug("Info: currentNum = " + this.currentNum);
      if (this.mGroups[this.currentNum - 1].getRelated() != null) {
        Vector links = this.mGroups[this.currentNum - 1].getRelated();
        int numLinks = links.size();
        double currentTime = this.currentPlayer.getMediaTime().getSeconds();
        for (int i = 0; i < numLinks; i++) {
          RelatedLink l = links.elementAt(i);
          if (l.startTime <= currentTime)
            if (l.stopTime == 0L || l.stopTime >= currentTime) {
              this.mpAppletContext.showDocument(l.uLink, this.infoWindow);
              i = numLinks;
            }  
        } 
      } 
    } else if (e.getActionCommand().equalsIgnoreCase("left") || e.getActionCommand().equalsIgnoreCase("up")) {
      shiftButtons(-1);
    } 
    if (e.getActionCommand().equalsIgnoreCase("right") || e.getActionCommand().equalsIgnoreCase("down")) {
      shiftButtons(1);
    } else {
      int buttonIndex;
      try {
        buttonIndex = Integer.parseInt(e.getActionCommand());
      } catch (NumberFormatException n) {
        return;
      } 
      doDebug("Button " + buttonIndex + " pressed.");
      if (this.currentNum != buttonIndex) {
        pauseCurrent();
        setPlayer(buttonIndex);
      } 
    } 
  }
  
  protected URL getURL(String filename) {
    URL url = null;
    doDebug(filename);
    try {
      if ((((!filename.startsWith("http") && !filename.startsWith("file")) ? 1 : 0) & ((this.mpCodeBase != null) ? 1 : 0)) != 0) {
        url = new URL(this.mpCodeBase, filename);
      } else {
        url = new URL(filename);
      } 
    } catch (MalformedURLException e) {
      System.out.println(JMFUtil.getString("InvalidURL:") + filename);
      return null;
    } 
    return url;
  }
  
  private void videoResize() {
    doDebug("videoResize");
    MediaPlayer pb = this.currentPlayer;
    if (pb == null)
      return; 
    Dimension d = getSize();
    int height = d.height;
    int width = d.width;
    int maxHeight = 10;
    this.buttonPanel.validate();
    Dimension buttonD = this.buttonPanel.getSize();
    if (maxHeight < buttonD.height)
      maxHeight = buttonD.height; 
    pb.setBounds((getBounds()).x, (getBounds()).y, width, height - maxHeight);
    while (pb.getState() != 500 && pb.getState() != 600) {
      try {
        Thread.sleep(200L);
      } catch (InterruptedException ie) {}
    } 
  }
  
  private MediaPlayer formPlayer(String mediaName) {
    try {
      mediaName = mediaName.trim();
      if (mediaName.length() != 0) {
        doDebug("Forming player: " + mediaName + "| CodeBase = " + this.mpCodeBase);
        ClassLoader cl = getClass().getClassLoader();
        MediaPlayer pb = (MediaPlayer)Beans.instantiate(cl, "javax.media.bean.playerbean.MediaPlayer");
        if ((((!mediaName.startsWith("http") && !mediaName.startsWith("file")) ? 1 : 0) & ((this.mpCodeBase != null) ? 1 : 0)) != 0)
          mediaName = this.mpCodeBase + mediaName; 
        doDebug("loading: 111" + mediaName);
        pb.setMediaLocation(mediaName);
        pb.prefetch();
        pb.waitForState(500);
        System.out.println("Wait for state done");
        pb.addControllerListener(this);
        pb.addComponentListener(this);
        pb.setVisible(false);
        pb.setBackground(getBackground());
        pb.setMediaLocationVisible(this.displayURL);
        pb.setPlaybackLoop(this.looping);
        pb.setControlPanelVisible(this.panelVisible);
        this.numOfClips++;
        System.out.println("num of Clips=" + this.numOfClips);
        Dimension d = getSize();
        int height = d.height;
        int width = d.width;
        int maxHeight = 0;
        int pbHeight = 0;
        int pbWidth = 0;
        Dimension buttonD = this.buttonPanel.getSize();
        if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("NORTH")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("SOUTH"))) {
          pbHeight = height - buttonD.height;
          pbWidth = width;
        } else if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("WEST")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("EAST"))) {
          pbHeight = height;
          pbWidth = width - buttonD.width;
        } 
        if (this.fixAspectRatio) {
          Component vc = pb.getVisualComponent();
          float aspect = 1.0F;
          if (vc != null) {
            int cHeight = 0;
            if (pb.getControlPanelComponent() != null && this.panelVisible)
              cHeight = (pb.getControlPanelComponent().getSize()).height; 
            if (this.displayURL)
              cHeight += 23; 
            Dimension pbD = vc.getPreferredSize();
            aspect = JMFUtil.aspectRatio(pbD.width, pbD.height, 0);
            pbHeight = (int)(width / aspect) + cHeight;
            if (pbHeight > height) {
              pbWidth = (int)(aspect * (height - cHeight));
              pbHeight = height - maxHeight;
            } else {
              pbWidth = width;
            } 
          } 
        } 
        pb.setBounds((getBounds()).x, (getBounds()).y, pbWidth, pbHeight);
        doDebug("Number of Clips: " + this.numOfClips);
        return pb;
      } 
      return null;
    } catch (Exception e) {
      System.err.println(JMFUtil.getString("PlayerBeanNotGood") + e);
      e.printStackTrace();
      return null;
    } 
  }
  
  private boolean containsButton(Component but) {
    Component[] comps = this.gifPanel.getComponents();
    for (int i = 0; i < comps.length; i++) {
      if (comps[i] == but)
        return true; 
    } 
    return false;
  }
  
  protected ImageButton formButton(URL i, int index) {
    doDebug("Form image button");
    ImageButton newButton = new ImageButton(i);
    newButton.setActionCommand(Integer.toString(index));
    newButton.addActionListener(this);
    newButton.setEnabled(true);
    newButton.waitForImage(true);
    return newButton;
  }
  
  protected ImageButton formButton(int index) {
    doDebug("Form Index button");
    ImageButton newButton = new ImageButton(Integer.toString(index), true, 80, 60);
    newButton.setActionCommand(Integer.toString(index));
    newButton.addActionListener(this);
    newButton.waitForImage(true);
    return newButton;
  }
  
  public void pauseCurrent() {
    if (this.currentNum <= this.numOfMGroups && this.currentNum > 0) {
      ImageButton imgB = this.mGroups[this.currentNum - 1].getButton();
      imgB.setBorderColor(new Color(160, 160, 160));
      imgB.drawBorder(true);
    } 
    if (this.currentPlayer != null) {
      this.currentPlayer.stop();
      this.currentPlayer.close();
      this.currentPlayer.setVisible(false);
      this.videoPanel.remove((Component)this.currentPlayer);
      doDebug("Exiting PauseCurrent.");
    } 
  }
  
  private void changeCurrentPlayer(MediaPlayer newPB, int num) {
    this.currentNum = num;
    this.currentPlayer = newPB;
    doDebug("Switching current Player");
    this.currentPlayer.setVisible(true);
    this.videoPanel.add((Component)this.currentPlayer);
    JMFUtil.center(this.videoPanel, (Component)this.currentPlayer, true, this.currentPlayer.getMediaLocationHeight() + this.currentPlayer.getControlPanelHeight());
    this.videoPanel.setVisible(true);
    try {
      if (this.currentPlayer.getState() != 600) {
        this.currentPlayer.start();
      } else {
        System.out.println("Player already in started state.");
      } 
    } catch (ClockStartedError cse) {
      this.currentPlayer.close();
      this.currentPlayer.deallocate();
      this.currentPlayer.start();
    } 
    this.currentPlayer.setVisible(true);
    this.currentPlayer.waitForState(600);
    this.currentPlayer.invalidate();
    this.videoPanel.validate();
    this.videoPanel.setVisible(true);
  }
  
  public void nextPlayer() {
    if (this.numOfMGroups <= 1)
      return; 
    pauseCurrent();
    this.currentNum++;
    if (this.currentNum > this.numOfMGroups)
      this.currentNum = 1; 
    while (!containsButton(this.mGroups[this.currentNum - 1].getButton()))
      shiftButtons(1); 
    doDebug("Next Player");
    setPlayer(this.currentNum);
  }
  
  public void previousPlayer() {
    if (this.numOfMGroups <= 1)
      return; 
    pauseCurrent();
    this.currentNum--;
    if (this.currentNum < 1)
      this.currentNum = this.numOfMGroups; 
    while (!containsButton(this.mGroups[this.currentNum - 1].getButton()))
      shiftButtons(-1); 
    doDebug("Previous Player");
    setPlayer(this.currentNum);
  }
  
  public void setPlayer(int current) {
    MediaGroup mGrp = null;
    ImageButton imgBut = null;
    if (current < 1 || current > this.numOfMGroups)
      return; 
    mGrp = this.mGroups[current - 1];
    mGrp.setPlayer(formPlayer(mGrp.mediaName));
    if (!containsButton(mGrp.getButton())) {
      this.startingButton = this.currentNum;
      updateGifPanel();
    } 
    if (mGrp.getRelated() != null && this.mpAppletContext != null) {
      if (mGrp.getRelated().size() > 0) {
        if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("SOUTH")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("NORTH"))) {
          this.buttonPanel.add("South", this.utilPanel);
          validate();
        } else if (!this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("NONE"))) {
          this.videoPanel.add("South", this.utilPanel);
          validate();
        } 
      } else {
        this.buttonPanel.remove(this.utilPanel);
        this.videoPanel.remove(this.utilPanel);
        validate();
      } 
    } else {
      this.buttonPanel.remove(this.utilPanel);
      this.videoPanel.remove(this.utilPanel);
    } 
    imgBut = mGrp.getButton();
    imgBut.requestFocus();
    imgBut.setBorderColor(Color.darkGray);
    imgBut.drawBorder(false);
    this.currentPlayer = mGrp.getPlayer();
    changeCurrentPlayer(this.currentPlayer, current);
  }
  
  public boolean isFixAspectRatio() {
    return this.fixAspectRatio;
  }
  
  public void setFixAspectRatio(boolean f) {
    boolean old = this.fixAspectRatio;
    if (old != f)
      for (int i = 0; i < this.numOfClips; i++); 
    this.fixAspectRatio = f;
    this.changes.firePropertyChange("fixAspectRatio", new Boolean(old), new Boolean(f));
  }
  
  public String getButtonPosition() {
    return this.buttonPosition;
  }
  
  public void setButtonPosition(String p) {
    String old = this.buttonPosition;
    if (!old.equalsIgnoreCase(p)) {
      this.buttonPosition = p;
      position();
      this.changes.firePropertyChange("buttonPosition", new String(old), new String(p));
    } 
  }
  
  public boolean isSequentialPlay() {
    return this.sequential;
  }
  
  public void setSequentialPlay(boolean b) {
    boolean old = this.sequential;
    if (old != b) {
      this.sequential = b;
      this.changes.firePropertyChange("sequentialPlay", new Boolean(old), new Boolean(b));
    } 
  }
  
  public boolean isLooping() {
    return this.looping;
  }
  
  public void setLooping(boolean l) {
    boolean old = this.looping;
    if (old != l)
      for (int i = 0; i < this.numOfClips; i++)
        this.mGroups[i].getPlayer().setPlaybackLoop(l);  
    this.looping = l;
    this.changes.firePropertyChange("looping", new Boolean(old), new Boolean(l));
  }
  
  public boolean isPanelVisible() {
    return this.panelVisible;
  }
  
  public void setPanelVisible(boolean val) {
    if (this.panelVisible != val) {
      for (int i = 0; i < this.numOfClips; i++)
        this.mGroups[i].getPlayer().setControlPanelVisible(val); 
      validate();
      this.panelVisible = val;
      this.changes.firePropertyChange("panelVisible", new Boolean(!val), new Boolean(val));
    } 
  }
  
  public boolean isURLVisible() {
    return this.displayURL;
  }
  
  public void setURLVisible(boolean val) {
    if (this.displayURL != val) {
      for (int i = 0; i < this.numOfClips; i++)
        this.mGroups[i].getPlayer().setMediaLocationVisible(val); 
      validate();
      this.displayURL = val;
      this.changes.firePropertyChange("URLVisible", new Boolean(!val), new Boolean(val));
    } 
  }
  
  public boolean isFitVideo() {
    return this.fitVideo;
  }
  
  public void setFitVideo(boolean f) {
    boolean old = this.fitVideo;
    if (old != f) {
      for (int i = 0; i < this.numOfClips; i++);
      this.fitVideo = f;
    } 
  }
  
  public boolean getLoadOnInit() {
    return this.loadOnInit;
  }
  
  public void setLoadOnInit(boolean b) {
    boolean old = this.loadOnInit;
    if (old != b) {
      this.loadOnInit = b;
      this.changes.firePropertyChange("loadOnInit", new Boolean(old), new Boolean(b));
    } 
  }
  
  public void moveUp(int index) {
    MediaGroup mg = this.mGroups[index];
    if (index > 0) {
      this.mGroups[index] = this.mGroups[index - 1];
      this.mGroups[index - 1] = mg;
      this.mGroups[index].setIndex(index);
      this.mGroups[index - 1].setIndex(index - 1);
      this.mGroups[index].getButton().setActionCommand(Integer.toString(index + 1));
      this.mGroups[index - 1].getButton().setActionCommand(Integer.toString(index));
      if (switchLinkIndex(Integer.toString(index), Integer.toString(index + 1)))
        setLinks(this.links); 
      doDebug("ActionCommand = " + (index + 1));
      doDebug("ActionCommand = " + index);
    } 
    for (int i = index - 1; i < this.numOfMGroups; i++) {
      ImageButton b = this.mGroups[i].getButton();
      this.gifPanel.remove(b);
      this.gifPanel.add(b);
    } 
    validate();
  }
  
  public void moveDown(int index) {
    MediaGroup mg = this.mGroups[index];
    if (index < this.numOfMGroups - 1) {
      this.mGroups[index] = this.mGroups[index + 1];
      this.mGroups[index + 1] = mg;
      this.mGroups[index].setIndex(index);
      this.mGroups[index + 1].setIndex(index + 1);
      this.mGroups[index].getButton().setActionCommand(Integer.toString(index + 1));
      this.mGroups[index + 1].getButton().setActionCommand(Integer.toString(index + 2));
      if (switchLinkIndex(Integer.toString(index + 1), Integer.toString(index + 2)))
        setLinks(this.links); 
      doDebug("moveDown(i):ActionCommand=" + (index + 1));
      doDebug("moveDown(i):ActionCommand=" + (index + 2));
    } 
    for (int i = index; i < this.numOfMGroups; i++) {
      ImageButton b = this.mGroups[i].getButton();
      doDebug("Moving media " + (this.mGroups[i]).mediaName);
      this.gifPanel.remove(b);
      this.gifPanel.add(b);
    } 
    validate();
  }
  
  public void addMGroup(String mediaName, String buttonGif) {
    doDebug("adding media group - " + this.numOfMGroups);
    if (this.mGroups == null)
      this.mGroups = new MediaGroup[this.maxMediaGroup]; 
    if (this.numOfMGroups < this.maxMediaGroup) {
      this.mGroups[this.numOfMGroups] = new MediaGroup(mediaName, buttonGif, "", this);
    } else {
      System.out.println(JMFUtil.getString("MaxMGroup"));
    } 
    doDebug("Number of next media group = " + this.numOfMGroups);
  }
  
  public void deleteMGroup(int i) {
    boolean changed = false;
    String index = Integer.toString(i + 1);
    doDebug("i = " + i);
    doDebug("index = " + index);
    doDebug("MGroups length = " + this.mGroups.length);
    String[] temp = null;
    MediaGroup mg = this.mGroups[i];
    int linksLength = 0;
    if (this.links != null)
      linksLength = this.links.length; 
    for (int j = 0; j < linksLength; j += 4) {
      if (index.equals(this.links[j])) {
        changed = true;
        temp = new String[this.links.length - 4];
        JMFUtil.copyShortenStringArray(this.links, temp, j, 4);
      } 
    } 
    for (int k = i; k < this.numOfMGroups - 1; k++) {
      this.mGroups[k] = this.mGroups[k + 1];
      if (this.links != null) {
        index = Integer.toString(k + 1);
        if (changed) {
          for (int m = 0; m < temp.length; m += 4) {
            if (temp[m].equals(index))
              temp[m] = Integer.toString(k); 
          } 
        } else {
          temp = new String[linksLength];
          JMFUtil.copyStringArray(this.links, temp);
          for (int m = 0; m < temp.length; m += 4) {
            if (temp[m].equals(index)) {
              changed = true;
              temp[m] = Integer.toString(k);
            } 
          } 
        } 
      } 
    } 
    if (changed)
      setLinks(temp); 
    this.mGroups[this.numOfMGroups - 1] = null;
    this.numOfMGroups--;
    doDebug("Remove button " + mg.gifName);
    this.gifPanel.remove(mg.getButton());
    updateGifPanel();
    validate();
  }
  
  private boolean switchLinkIndex(String index1, String index2) {
    boolean changed = false;
    if (this.links != null)
      for (int i = 0; i < this.links.length; i += 4) {
        if (index1.equals(this.links[i])) {
          doDebug("Switched " + this.links[i] + " with " + index2);
          changed = true;
          this.links[i] = index2;
        } else if (index2.equals(this.links[i])) {
          doDebug("Switched " + this.links[i] + " with " + index1);
          changed = true;
          this.links[i] = index1;
        } 
      }  
    return changed;
  }
  
  public void replaceMGroup(int i, String mName, String gName) {
    if (i < this.numOfMGroups) {
      if (i < this.numOfMGroups - 1) {
        MediaGroup m1 = this.mGroups[i + 1];
        if ((m1.mediaName.equals(mName) & m1.gifName.equals(gName)) != 0) {
          moveDown(i);
          return;
        } 
      } 
      MediaGroup mg = this.mGroups[i];
      if (mg.getPlayer() != null) {
        MediaPlayer pb = mg.getPlayer();
        pb.close();
        pb.deallocate();
        mg.setPlayer(null);
      } 
      doDebug("Media Name = " + mName);
      doDebug("Gif Name = " + gName);
      mg.mediaName = mName;
      mg.gifName = gName;
      if (gName != null || gName.compareTo("") != 0) {
        mg.setButton(formButton(getURL(gName), i + 1));
      } else {
        mg.setButton(formButton(i + 1));
      } 
      doDebug("Replacing " + i);
      refreshAllButtons();
    } 
  }
  
  private void refreshAllButtons() {
    this.gifPanel.removeAll();
    for (int i = 0; i < this.numOfMGroups; i++)
      this.gifPanel.add(this.mGroups[i].getButton()); 
    validate();
  }
  
  public boolean addLink(int index, String l, long start, long end) {
    doDebug("adding link: index = " + index);
    doDebug("Link = " + l + " start=" + start + " stop=" + end);
    try {
      RelatedLink link = new RelatedLink(l, start, end, this);
      this.mGroups[index - 1].setRelated(link);
    } catch (MalformedURLException e) {
      System.out.println(JMFUtil.getString("InvalidURL"));
      return false;
    } 
    if (!duplicate(Integer.toString(index + 1), l, Long.toString(start), Long.toString(end))) {
      int len = 0;
      if (this.links != null)
        len = this.links.length; 
      String[] temp = new String[len + 4];
      JMFUtil.copyStringArray(this.links, temp);
      temp[len] = Integer.toString(index + 1);
      temp[len + 1] = l;
      temp[len + 2] = Long.toString(start);
      temp[len + 3] = Long.toString(end);
    } 
    return true;
  }
  
  private boolean duplicate(String mIndex, String url, String start, String stop) {
    if (this.links != null)
      for (int i = 0; i < this.links.length; i += 4) {
        if ((this.links[i].equals(mIndex) & this.links[i + 1].equals(url) & this.links[i + 2].equals(start) & this.links[i + 3].equals(stop)) != 0)
          return true; 
      }  
    return false;
  }
  
  public void setMGroups(MediaGroup[] indexprop) {
    MediaGroup[] oldValue = this.mGroups;
    this.mGroups = indexprop;
    this.changes.firePropertyChange("mGroups", oldValue, indexprop);
  }
  
  public void setMGroups(int index, MediaGroup indexprop) {
    MediaGroup[] oldValue = this.mGroups;
    this.mGroups[index] = indexprop;
    this.changes.firePropertyChange("mGroups", oldValue, this.mGroups);
  }
  
  public MediaGroup[] getMGroups() {
    return this.mGroups;
  }
  
  public MediaGroup getMGroups(int index) {
    return this.mGroups[index];
  }
  
  public void setMediaNames(String[] indexprop) {
    String[] oldValue = this.mediaNames;
    this.mediaNames = indexprop;
    doDebug("setmediaNames " + this.mediaNames);
    updateMGroups(this.mediaNames);
    updateLinks(this.links);
    doDebug("updateMGroups done");
    updateGifPanel();
    this.changes.firePropertyChange("mediaNames", oldValue, indexprop);
  }
  
  public void setMediaNames(String[] indexprop, Object t) {
    String[] oldValue = this.mediaNames;
    this.mediaNames = indexprop;
    doDebug("setmediaNames " + this.mediaNames);
    getContext(t);
    updateMGroups(this.mediaNames);
    updateLinks(this.links);
    doDebug("updateMGroups done");
    updateGifPanel();
    this.changes.firePropertyChange("mediaNames", oldValue, indexprop);
  }
  
  public void setMediaNames(int index, String indexprop) {
    String str1, str2, oldValue[] = this.mediaNames;
    this.mediaNames[index] = indexprop;
    if (index % 2 == 0) {
      str1 = this.mediaNames[index];
      str2 = this.mediaNames[index + 1];
    } else {
      str1 = this.mediaNames[index - 1];
      str2 = this.mediaNames[index];
    } 
    updateMGroups(index / 2, str1, str2);
    updateGifPanel();
    this.changes.firePropertyChange("mediaNames", oldValue, this.mediaNames);
  }
  
  private boolean updateMGroups(String[] mNames) {
    boolean changed = false;
    int mNamesLength = 0;
    int mindex = 0;
    if (mNames != null)
      mNamesLength = mNames.length; 
    doDebug("Updating MGroups " + mNamesLength);
    for (int i = 0; i < mNamesLength; i += 2) {
      mindex = i / 2;
      if (changed) {
        updateMGroups(mindex, mNames[i], mNames[i + 1]);
      } else {
        changed = updateMGroups(mindex, mNames[i], mNames[i + 1]);
      } 
    } 
    if (mNamesLength / 2 < this.numOfMGroups)
      for (int j = this.numOfMGroups - 1; j >= mNamesLength / 2; j--) {
        doDebug("Deleting mGroup " + j);
        this.mGroups[j].delete();
      }  
    return changed;
  }
  
  private boolean updateMGroups(int i, String mediaName, String gifName) {
    doDebug("Index=" + i + " Media=" + mediaName + " Gif=" + gifName);
    if (i < this.numOfMGroups) {
      MediaGroup m = this.mGroups[i];
      if (((!m.mediaName.equals(mediaName) ? 1 : 0) | (!m.gifName.equals(gifName) ? 1 : 0)) != 0) {
        replaceMGroup(i, mediaName, gifName);
        return true;
      } 
    } else {
      addMGroup(mediaName, gifName);
      return true;
    } 
    return false;
  }
  
  public String[] getMediaNames() {
    return this.mediaNames;
  }
  
  public String getMediaNames(int index) {
    return this.mediaNames[index];
  }
  
  public void setLinks(String[] indexprop) {
    String[] oldValue = this.links;
    boolean changed = false;
    this.links = indexprop;
    doDebug("Inside setLinks(String[])");
    changed = deleteLinks(this.links);
    doDebug("updating links...");
    if (updateLinks(this.links) | changed)
      this.changes.firePropertyChange("links", oldValue, indexprop); 
  }
  
  public void setLinks(int index, String indexprop) {
    String[] oldValue = this.links;
    String mediaNum = "";
    String relatedName = "";
    String startString = "";
    String stopString = "";
    this.links[index] = indexprop;
    if (index % 4 == 0) {
      mediaNum = this.links[index];
      relatedName = this.links[index + 1];
      startString = this.links[index + 2];
      stopString = this.links[index + 3];
    } else if (index % 4 == 1) {
      mediaNum = this.links[index - 1];
      relatedName = this.links[index];
      startString = this.links[index + 1];
      stopString = this.links[index + 2];
    } else if (index % 3 == 2) {
      mediaNum = this.links[index - 2];
      relatedName = this.links[index - 1];
      startString = this.links[index];
      stopString = this.links[index + 1];
    } else if (index % 3 == 4) {
      mediaNum = this.links[index - 3];
      relatedName = this.links[index - 2];
      startString = this.links[index - 1];
      stopString = this.links[index];
    } 
    if (updateLinks(mediaNum, relatedName, startString, stopString))
      this.changes.firePropertyChange("links", oldValue, this.links); 
  }
  
  private boolean deleteLinks(String[] linksList) {
    int index = 0;
    Vector rl = null;
    RelatedLink l = null;
    boolean changed = false;
    boolean match = false;
    for (int i = 0; i < this.numOfMGroups; i++) {
      rl = this.mGroups[i].getRelated();
      if (rl != null)
        for (int j = 0; j < rl.size(); j++) {
          l = rl.elementAt(j);
          match = false;
          if (linksList != null)
            for (int k = 0; k < linksList.length; k += 4) {
              if ((Integer.toString(i).equals(linksList[k]) & l.link.equals(linksList[k + 1]) & Long.toString(l.startTime).equals(linksList[k + 2]) & Long.toString(l.stopTime).equals(linksList[k + 3])) != 0) {
                match = true;
                break;
              } 
            }  
          if (!match) {
            rl.removeElementAt(j);
            changed = true;
          } 
        }  
    } 
    return changed;
  }
  
  private boolean updateLinks(String[] linksList) {
    boolean changed = false;
    if (linksList != null) {
      doDebug("links length: " + linksList.length);
      if (this.msVM)
        for (int j = 0; j < linksList.length; j++)
          String temp = linksList[j];  
      for (int i = 0; i < linksList.length; i += 4) {
        if (changed) {
          updateLinks(linksList[i], linksList[i + 1], linksList[i + 2], linksList[i + 3]);
        } else {
          changed = updateLinks(linksList[i], linksList[i + 1], linksList[i + 2], linksList[i + 3]);
        } 
      } 
    } 
    return changed;
  }
  
  private boolean updateLinks(String mediaNum, String relatedName, String startString, String stopString) {
    doDebug("MediaNum=" + mediaNum + " related=" + relatedName);
    doDebug("Start=" + startString + " Stop=" + stopString);
    int i = Integer.parseInt(mediaNum) - 1;
    long start = 0L;
    long stop = 0L;
    boolean dup = false;
    try {
      start = Long.parseLong(startString);
      stop = Long.parseLong(stopString);
    } catch (NumberFormatException n) {
      return false;
    } 
    if ((((i < this.numOfMGroups) ? 1 : 0) & ((i >= 0) ? 1 : 0)) != 0) {
      MediaGroup m = this.mGroups[i];
      Vector r = m.getRelated();
      RelatedLink rl = null;
      if (r != null)
        for (int j = 0; j < r.size(); j++) {
          rl = r.elementAt(j);
          if ((rl.link.equals(relatedName) & ((rl.startTime == start) ? 1 : 0) & ((rl.stopTime == stop) ? 1 : 0)) != 0) {
            dup = true;
            j = r.size();
            return false;
          } 
        }  
      if (!dup) {
        try {
          m.setRelated(new RelatedLink(relatedName, start, stop, this));
        } catch (MalformedURLException me) {
          System.out.println(JMFUtil.getBIString("BadURL") + relatedName);
          return false;
        } 
        return true;
      } 
    } 
    System.out.println(JMFUtil.getBIString("MEDIA_GROUP_BOUNDS"));
    return false;
  }
  
  public String[] getLinks() {
    return this.links;
  }
  
  public String getLinks(int index) {
    return this.links[index];
  }
  
  public void setAppletContext(AppletContext ac) {
    this.mpAppletContext = ac;
  }
  
  public void setCodeBase(URL cb) {
    this.mpCodeBase = cb;
  }
  
  public void addControllerListener(ControllerListener listener) {
    for (int i = 0; i < this.numOfClips; i++)
      this.mGroups[i].getPlayer().addControllerListener(listener); 
  }
  
  public void removeControllerListener(ControllerListener listener) {
    for (int i = 0; i < this.numOfClips; i++)
      this.mGroups[i].getPlayer().removeControllerListener(listener); 
  }
  
  public int getNumberOfMediaGroups() {
    return this.numOfMGroups;
  }
  
  public void setBounds(int x, int y, int w, int h) {
    super.setBounds(x, y, w, h);
    Dimension d = getSize();
    int height = d.height;
    int maxHeight = 10;
    Dimension buttonD = this.buttonPanel.getSize();
    if (maxHeight < buttonD.height)
      maxHeight = buttonD.height; 
    doDebug("Num of Clips = " + this.numOfClips);
    for (int i = 0; i < this.numOfClips; i++)
      this.mGroups[i].getPlayer().setBounds(x, y, w, h - maxHeight); 
    updateGifPanel();
  }
  
  public Dimension getPreferredSize() {
    if (Beans.isDesignTime())
      return new Dimension(this.preferredWidth, this.preferredHeight); 
    Dimension d = getSize();
    if (d.width == 0 || d.height == 0)
      return new Dimension(this.preferredWidth, this.preferredHeight); 
    return d;
  }
  
  public void addPropertyChangeListener(PropertyChangeListener c) {
    this.changes.addPropertyChangeListener(c);
  }
  
  public void removePropertyChangeListener(PropertyChangeListener c) {
    this.changes.removePropertyChangeListener(c);
  }
  
  protected void createTabs(int length) {
    if (this.up != null)
      this.scrollPanel.remove(this.up); 
    if (this.down != null)
      this.scrollPanel.remove(this.down); 
    if (this.left != null)
      this.scrollPanel.remove(this.left); 
    if (this.right != null)
      this.scrollPanel.remove(this.right); 
    if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("SOUTH")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("NORTH"))) {
      createLeftRight(length);
      this.scrollPanel.add("West", this.left);
      this.scrollPanel.add("East", this.right);
    } else if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("WEST")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("EAST"))) {
      createUpDown(length);
      this.scrollPanel.add("North", this.up);
      this.scrollPanel.add("South", this.down);
    } 
  }
  
  private void shiftButtons(int difference) {
    this.startingButton += difference;
    if (this.startingButton > this.numOfMGroups)
      this.startingButton -= this.numOfMGroups; 
    if (this.startingButton < 1)
      this.startingButton = this.numOfMGroups + this.startingButton; 
    updateGifPanel();
  }
  
  protected void updateGifPanel() {
    if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("NONE"))) {
      validate();
      return;
    } 
    if (this.numOfMGroups <= 0)
      return; 
    int numOfButtons = 0;
    int i = this.startingButton - 1;
    int stop = i + 1;
    if (stop == this.numOfMGroups)
      stop = 0; 
    int tabLength = 0;
    ImageButton iButton = this.mGroups[i].getButton();
    int gifLength = (getSize()).width;
    int buttonsLength = 0;
    tabLength = iButton.height;
    if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("WEST")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("EAST"))) {
      gifLength = (getSize()).height;
      buttonsLength = 0;
      tabLength = iButton.width;
    } 
    gifLength -= 2 * this.tabsize;
    boolean first = true;
    this.scrollPanel.setVisible(false);
    this.scrollPanel.removeAll();
    this.gifPanel.setVisible(false);
    this.gifPanel.removeAll();
    i++;
    if (i >= this.numOfMGroups)
      i = 0; 
    doDebug("ButtonsLength: " + buttonsLength);
    doDebug("Gif Length: " + gifLength);
    doDebug("i: " + i);
    doDebug("stop: " + stop);
    iButton = this.mGroups[i].getButton();
    while (first || i != stop) {
      first = false;
      if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("NORTH")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("SOUTH"))) {
        if (iButton.width + buttonsLength > gifLength)
          break; 
        numOfButtons++;
        buttonsLength += iButton.width;
        if (iButton.height > tabLength)
          tabLength = iButton.height; 
      } else if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("WEST")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("EAST"))) {
        if (iButton.height + buttonsLength > gifLength)
          break; 
        numOfButtons++;
        buttonsLength += iButton.height;
        if (iButton.width > tabLength)
          tabLength = iButton.width; 
      } 
      i++;
      if (i >= this.numOfMGroups)
        i = 0; 
    } 
    int gap = 0;
    if (numOfButtons > 1)
      gap = (gifLength - buttonsLength) / (numOfButtons - 1); 
    System.out.println("gap=" + gap + " gifLength=" + gifLength + " buttonsLength=" + buttonsLength);
    if (numOfButtons == 1) {
      this.gifPanel.setLayout(new FlowLayout());
    } else if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("NORTH")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("SOUTH"))) {
      this.gifPanel.setLayout(new GridLayout(1, numOfButtons, gap, 0));
    } else if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("WEST")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("EAST"))) {
      this.gifPanel.setLayout(new GridLayout(numOfButtons, 1, 0, gap));
    } 
    iButton = this.mGroups[this.startingButton - 1].getButton();
    buttonsLength = iButton.width;
    first = true;
    if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("WEST")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("EAST")))
      buttonsLength = iButton.height; 
    i = this.startingButton;
    if (i >= this.numOfMGroups)
      i = 0; 
    while (buttonsLength <= gifLength && (first || i != stop)) {
      first = false;
      this.gifPanel.add(iButton);
      iButton = this.mGroups[i].getButton();
      if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("NORTH")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("SOUTH"))) {
        buttonsLength += iButton.width;
      } else if (this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("WEST")) || this.buttonPosition.equalsIgnoreCase(JMFUtil.getString("EAST"))) {
        buttonsLength += iButton.height;
      } 
      i++;
      if (i >= this.numOfMGroups)
        i = 0; 
    } 
    if (buttonsLength > gifLength && i != stop)
      createTabs(tabLength); 
    this.scrollPanel.add("Center", this.gifPanel);
    this.gifPanel.setVisible(true);
    this.scrollPanel.setVisible(true);
    validate();
  }
  
  public void componentResized(ComponentEvent ce) {
    doDebug("Something is being resized.");
    doDebug("videoPanel=" + this.videoPanel);
    if (this.currentPlayer != null)
      doDebug("pb=" + this.currentPlayer); 
    if (ce.getSource() == this.gifPanel) {
      doDebug("resize gifPanel: " + this.gifPanel);
      videoResize();
      if (!this.msVM)
        updateGifPanel(); 
    } else if (ce.getSource() == this.currentPlayer) {
      doDebug("resize currentPlayer: " + this.currentPlayer.getSize());
      JMFUtil.center(this.videoPanel, (Component)this.currentPlayer, true, (this.currentPlayer.getPreferredSize()).height - (this.currentPlayer.getVisualComponent().getSize()).height);
    } 
  }
  
  public void componentMoved(ComponentEvent ce) {}
  
  public void componentHidden(ComponentEvent ce) {}
  
  public void componentShown(ComponentEvent ce) {}
  
  protected void doDebug(String s) {
    System.out.println(s);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\bean\multiplayer\MultiPlayerBean.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */