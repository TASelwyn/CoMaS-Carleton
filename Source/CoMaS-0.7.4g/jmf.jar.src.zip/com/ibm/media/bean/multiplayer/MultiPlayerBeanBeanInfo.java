package com.ibm.media.bean.multiplayer;

import java.awt.Image;
import java.beans.BeanDescriptor;
import java.beans.EventSetDescriptor;
import java.beans.IntrospectionException;
import java.beans.PropertyChangeListener;
import java.beans.PropertyDescriptor;
import java.beans.SimpleBeanInfo;
import javax.media.ControllerListener;

public class MultiPlayerBeanBeanInfo extends SimpleBeanInfo {
  public PropertyDescriptor[] getPropertyDescriptors() {
    try {
      PropertyDescriptor background = new PropertyDescriptor("background", beanClass);
      PropertyDescriptor foreground = new PropertyDescriptor("foreground", beanClass);
      PropertyDescriptor font = new PropertyDescriptor("font", beanClass);
      PropertyDescriptor UrlVisible = new PropertyDescriptor("URLVisible", beanClass);
      UrlVisible.setDisplayName(JMFUtil.getBIString("MEDIA_NAME_VISIBLE"));
      UrlVisible.setBound(true);
      PropertyDescriptor PanelVisible = new PropertyDescriptor("panelVisible", beanClass);
      PanelVisible.setDisplayName(JMFUtil.getBIString("CONTROL_PANEL_VISIBLE"));
      PanelVisible.setBound(true);
      PropertyDescriptor loop = new PropertyDescriptor("looping", beanClass);
      loop.setDisplayName(JMFUtil.getBIString("LOOP"));
      loop.setBound(true);
      PropertyDescriptor sequential = new PropertyDescriptor("sequentialPlay", beanClass);
      sequential.setDisplayName(JMFUtil.getBIString("SEQUENTIAL"));
      sequential.setBound(true);
      PropertyDescriptor fixAspect = new PropertyDescriptor("fixAspectRatio", beanClass);
      fixAspect.setDisplayName(JMFUtil.getBIString("FIXASPECT"));
      fixAspect.setBound(true);
      PropertyDescriptor buttonPosition = new PropertyDescriptor("buttonPosition", beanClass);
      buttonPosition.setDisplayName(JMFUtil.getBIString("BUTTONPOSITION"));
      buttonPosition.setBound(true);
      buttonPosition.setPropertyEditorClass(ButtonPositionEditor.class);
      PropertyDescriptor loadOnInit = new PropertyDescriptor("loadOnInit", beanClass);
      loadOnInit.setDisplayName(JMFUtil.getBIString("LOAD_ALL"));
      loadOnInit.setBound(true);
      PropertyDescriptor linkList = new PropertyDescriptor("links", beanClass);
      linkList.setBound(true);
      linkList.setPropertyEditorClass(LinksArrayEditor.class);
      linkList.setDisplayName(JMFUtil.getBIString("RELATED_LINKS"));
      PropertyDescriptor mediaNames = new PropertyDescriptor("mediaNames", beanClass);
      mediaNames.setBound(true);
      mediaNames.setPropertyEditorClass(MediaArrayEditor.class);
      mediaNames.setDisplayName(JMFUtil.getBIString("MEDIA_GROUP"));
      PropertyDescriptor[] rv = { 
          mediaNames, linkList, UrlVisible, PanelVisible, loop, sequential, fixAspect, buttonPosition, loadOnInit, background, 
          foreground, font };
      return rv;
    } catch (IntrospectionException e) {
      throw new Error(e.toString());
    } 
  }
  
  public int getDefaultPropertyIndex() {
    return 0;
  }
  
  public BeanDescriptor getBeanDescriptor() {
    return new BeanDescriptor(beanClass);
  }
  
  public EventSetDescriptor[] getEventSetDescriptors() {
    try {
      EventSetDescriptor cl = new EventSetDescriptor(beanClass, "controllerUpdate", ControllerListener.class, "controllerUpdate");
      EventSetDescriptor pc = new EventSetDescriptor(beanClass, "propertyChange", PropertyChangeListener.class, "propertyChange");
      cl.setDisplayName("Controller Events");
      EventSetDescriptor[] rv = { cl, pc };
      return rv;
    } catch (IntrospectionException e) {
      throw new Error(e.toString());
    } 
  }
  
  public Image getIcon(int ic) {
    switch (ic) {
      case 1:
        return loadImage("IconColor16.gif");
      case 2:
        return loadImage("IconColor32.gif");
      case 3:
        return loadImage("IconMono16.gif");
      case 4:
        return loadImage("IconMono32.gif");
    } 
    return null;
  }
  
  private static final Class beanClass = MultiPlayerBean.class;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\bean\multiplayer\MultiPlayerBeanBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */