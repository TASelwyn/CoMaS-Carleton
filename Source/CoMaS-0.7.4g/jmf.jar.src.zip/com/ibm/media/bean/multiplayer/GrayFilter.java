package com.ibm.media.bean.multiplayer;

import java.awt.image.RGBImageFilter;

class GrayFilter extends RGBImageFilter {
  private int darkness = -5263441;
  
  public GrayFilter() {
    this.canFilterIndexColorModel = true;
  }
  
  public GrayFilter(int darkness) {
    this();
    this.darkness = darkness;
  }
  
  public int filterRGB(int x, int y, int rgb) {
    return rgb & this.darkness;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\bean\multiplayer\GrayFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */