/*     */ package com.ibm.media.bean.multiplayer;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Frame;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Panel;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Toolkit;
/*     */ import java.util.ListResourceBundle;
/*     */ import java.util.Locale;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JMFUtil
/*     */ {
/*     */   private static Locale locale;
/*     */   private static ListResourceBundle res;
/*     */   private static ListResourceBundle beanInfoRes;
/*  50 */   private static String lang = null;
/*  51 */   private static String ctry = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getString(String key) {
/*  62 */     if (res == null) setResourceBundle(null); 
/*  63 */     return res.getString(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getLang() {
/*  74 */     return lang;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setResourceBundle(Locale l) {
/*  85 */     locale = Locale.getDefault();
/*     */     
/*     */     try {
/*  88 */       res = (ListResourceBundle)ResourceBundle.getBundle("com.ibm.media.bean.multiplayer.nls.JMFConst", locale);
/*     */     
/*     */     }
/*     */     catch (MissingResourceException m) {
/*     */       
/*  93 */       locale = new Locale("en", "US");
/*     */       
/*  95 */       res = (ListResourceBundle)ResourceBundle.getBundle("com.ibm.media.bean.multiplayer.nls.JMFConst", locale);
/*     */       
/*  97 */       System.out.println("Locale not supported, defaulting to english-US.");
/*     */     } 
/*  99 */     lang = locale.getLanguage();
/* 100 */     ctry = locale.getCountry();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getBIString(String key) {
/* 112 */     if (beanInfoRes == null) setBIResourceBundle(null); 
/* 113 */     return beanInfoRes.getString(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setBIResourceBundle(Locale l) {
/* 124 */     locale = Locale.getDefault();
/*     */     
/*     */     try {
/* 127 */       beanInfoRes = (ListResourceBundle)ResourceBundle.getBundle("com.ibm.media.bean.multiplayer.nls.MultiPlayerBeanInfoResources", locale);
/*     */     
/*     */     }
/*     */     catch (MissingResourceException m) {
/*     */       
/* 132 */       locale = new Locale("en", "US");
/*     */       
/* 134 */       beanInfoRes = (ListResourceBundle)ResourceBundle.getBundle("com.ibm.media.bean.multiplayer.nls.MultiPlayerBeanInfoResources", locale);
/*     */       
/* 136 */       System.out.println("Locale not supported, defaulting to english-US.");
/*     */     } 
/* 138 */     lang = locale.getLanguage();
/* 139 */     ctry = locale.getCountry();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Locale getLocale(String l) {
/* 153 */     if (l == null) return Locale.getDefault(); 
/* 154 */     String local = l.trim().toUpperCase();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 169 */     if (local.compareTo("FRANCE") == 0) return Locale.FRANCE; 
/* 170 */     if (local.compareTo("GERMANY") == 0) return Locale.GERMANY; 
/* 171 */     if (local.compareTo("ITALY") == 0) return Locale.ITALY; 
/* 172 */     if (local.compareTo("JAPAN") == 0) return Locale.JAPAN; 
/* 173 */     if (local.compareTo("KOREA") == 0) return Locale.KOREA; 
/* 174 */     if (local.compareTo("CHINA") == 0) return Locale.CHINA; 
/* 175 */     if (local.compareTo("PRC") == 0) return Locale.PRC; 
/* 176 */     if (local.compareTo("TAIWAN") == 0) return Locale.TAIWAN; 
/* 177 */     if (local.compareTo("UK") == 0) return Locale.UK; 
/* 178 */     if (local.compareTo("US") == 0) return Locale.US; 
/* 179 */     if (local.compareTo("CANADA") == 0) return Locale.CANADA; 
/* 180 */     if (local.compareTo("CANADA_FRENCH") == 0) return Locale.CANADA_FRENCH;
/*     */     
/* 182 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Panel doGridbagLayout2(Component[] comp, int column, int stretch) {
/* 191 */     Panel pan = new Panel();
/* 192 */     GridBagLayout gb = new GridBagLayout();
/* 193 */     GridBagConstraints c = new GridBagConstraints();
/* 194 */     pan.setLayout(gb);
/* 195 */     pan.setBackground(Color.lightGray);
/* 196 */     pan.setForeground(Color.black);
/*     */     
/* 198 */     c.insets = new Insets(1, 0, 0, 1);
/* 199 */     c.anchor = 17;
/* 200 */     for (int i = 0; i < comp.length; i++) {
/* 201 */       c.gridwidth = 1;
/* 202 */       c.weighty = 0.0D; c.weightx = 0.0D;
/* 203 */       c.fill = 0;
/* 204 */       if (i % column - column + 1 == 0)
/*     */       {
/* 206 */         c.gridwidth = 0;
/*     */       }
/* 208 */       if (i % column - stretch + 1 == 0) {
/*     */         
/* 210 */         c.fill = 2;
/* 211 */         c.weighty = 1.0D;
/* 212 */         c.weightx = 1.0D;
/*     */       } 
/* 214 */       gb.setConstraints(comp[i], c);
/* 215 */       pan.add(comp[i], c);
/*     */     } 
/* 217 */     return pan;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void centerComponent(Panel pan, Component comp) {
/* 229 */     doDebug("centerComponent");
/* 230 */     GridBagLayout gb = new GridBagLayout();
/* 231 */     GridBagConstraints c = new GridBagConstraints();
/* 232 */     pan.setLayout(gb);
/* 233 */     c.insets = new Insets(0, 0, 0, 0);
/* 234 */     c.anchor = 10;
/* 235 */     c.gridwidth = 1;
/* 236 */     c.gridheight = 1;
/* 237 */     c.weighty = 0.0D; c.weightx = 0.0D;
/* 238 */     c.fill = 0;
/* 239 */     gb.setConstraints(comp, c);
/* 240 */     pan.add(comp, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float aspectRatio(float width, float height, int controllerHeight) {
/* 253 */     return width / (height - controllerHeight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void center(Panel parent, Component comp, boolean fit, int dheight) {
/* 268 */     int pwidth = (parent.getSize()).width;
/* 269 */     int pheight = (parent.getSize()).height;
/* 270 */     comp.setBounds((parent.getInsets()).left, (parent.getInsets()).top, pwidth - (parent.getInsets()).left - (parent.getInsets()).right, pheight - (parent.getInsets()).top - (parent.getInsets()).bottom);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setCenterLocation(Frame self, Frame parent, int width, int height) {
/*     */     Rectangle rectangle;
/* 316 */     doDebug("setCenterLocation");
/*     */     
/* 318 */     if (parent != null) {
/* 319 */       rectangle = parent.getBounds();
/*     */     } else {
/*     */       
/* 322 */       Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
/* 323 */       rectangle = new Rectangle(new Point(0, 0), d);
/*     */     } 
/* 325 */     self.setSize(width, height);
/* 326 */     self.setLocation(rectangle.x + (rectangle.width - width) / 2, rectangle.y + (rectangle.height - height) / 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void copyStringArray(String[] oldArray, String[] newArray) {
/* 338 */     if ((((oldArray == null) ? 1 : 0) | ((newArray == null) ? 1 : 0)) != 0)
/*     */       return; 
/* 340 */     for (int i = 0; i < oldArray.length; i++)
/*     */     {
/* 342 */       newArray[i] = oldArray[i];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void copyShortenStringArray(String[] oldArray, String[] newArray, int index, int size) {
/* 356 */     if ((((oldArray == null) ? 1 : 0) | ((newArray == null) ? 1 : 0)) != 0)
/*     */       return; 
/* 358 */     for (int i = 0; i < newArray.length; i++) {
/*     */       
/* 360 */       if (i >= index) {
/* 361 */         newArray[i] = oldArray[i + size];
/*     */       } else {
/* 363 */         newArray[i] = oldArray[i];
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String parseArrayIntoString(String[] value) {
/* 376 */     StringBuffer property = new StringBuffer("");
/* 377 */     if (value != null)
/*     */     {
/* 379 */       for (int i = 0; i < value.length; i++) {
/*     */         
/* 381 */         property.append(value[i]);
/* 382 */         if (i != value.length - 1)
/*     */         {
/* 384 */           property.append(",");
/*     */         }
/* 386 */         doDebug(property.toString());
/*     */       } 
/*     */     }
/* 389 */     return property.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] parseStringIntoArray(String value) {
/* 401 */     if (value == null) return null; 
/* 402 */     if (value.length() == 0) return null;
/*     */     
/* 404 */     String temp = value;
/* 405 */     String sub = "";
/* 406 */     String[] tempArray = null;
/* 407 */     int length = 0;
/* 408 */     Vector strings = new Vector();
/* 409 */     int index = -1;
/*     */     
/* 411 */     doDebug("Value = " + value);
/*     */     
/* 413 */     index = temp.indexOf(",");
/* 414 */     length = temp.length();
/*     */ 
/*     */     
/* 417 */     while (index != -1) {
/*     */       
/* 419 */       sub = temp.substring(0, index);
/* 420 */       strings.addElement(sub);
/* 421 */       if (index + 1 < length) {
/* 422 */         temp = temp.substring(index + 1, length);
/*     */       }
/* 424 */       else if (index + 1 == length) {
/*     */         
/* 426 */         temp = "";
/* 427 */         strings.addElement("");
/*     */       } 
/* 429 */       index = temp.indexOf(",");
/* 430 */       length = temp.length();
/*     */     } 
/*     */     
/* 433 */     if ((((temp != null) ? 1 : 0) & ((length != 0) ? 1 : 0)) != 0)
/*     */     {
/* 435 */       strings.addElement(temp.substring(0, length));
/*     */     }
/*     */ 
/*     */     
/* 439 */     tempArray = new String[strings.size()];
/* 440 */     for (int i = 0; i < strings.size(); i++)
/*     */     {
/*     */       
/* 443 */       tempArray[i] = strings.elementAt(i);
/*     */     }
/*     */     
/* 446 */     return tempArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String convertString(String s) {
/* 457 */     if (s == null) return ""; 
/* 458 */     if (s.length() == 0) return s;
/*     */     
/* 460 */     int count = 0;
/* 461 */     int index = -1;
/*     */     
/* 463 */     StringBuffer newString = new StringBuffer(s);
/*     */     
/* 465 */     for (int i = 0; i < newString.length(); i++) {
/*     */       
/* 467 */       if (newString.charAt(i) == '\\' || newString.charAt(i) == '"') {
/*     */         
/* 469 */         newString.insert(i, "\\");
/* 470 */         i++;
/*     */       } 
/*     */     } 
/*     */     
/* 474 */     return newString.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean msVersion() {
/*     */     boolean bool;
/*     */     try {
/* 489 */       Class sysVerMgr = Class.forName("com.ms.util.SystemVersionManager");
/*     */       
/* 491 */       bool = true;
/*     */     
/*     */     }
/*     */     catch (Throwable e) {
/*     */       
/* 496 */       bool = false;
/*     */     } 
/* 498 */     return bool;
/*     */   }
/*     */   
/*     */   private static void doDebug(String s) {}
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\ibm\media\bean\multiplayer\JMFUtil.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */