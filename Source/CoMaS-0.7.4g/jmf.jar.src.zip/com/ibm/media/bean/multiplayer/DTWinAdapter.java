package com.ibm.media.bean.multiplayer;

import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class DTWinAdapter extends WindowAdapter {
  boolean doExit = false;
  
  public DTWinAdapter(boolean close) {
    this.doExit = close;
  }
  
  public void windowClosing(WindowEvent evt) {
    Frame f = (Frame)evt.getSource();
    f.setVisible(false);
    if (this.doExit) {
      f.dispose();
      System.exit(0);
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\bean\multiplayer\DTWinAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */