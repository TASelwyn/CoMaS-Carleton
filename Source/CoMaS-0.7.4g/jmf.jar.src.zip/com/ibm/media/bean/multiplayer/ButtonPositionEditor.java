package com.ibm.media.bean.multiplayer;

import java.beans.PropertyEditorSupport;

public class ButtonPositionEditor extends PropertyEditorSupport {
  String[] positionArr = new String[] { JMFUtil.getString("NORTH"), JMFUtil.getString("SOUTH"), JMFUtil.getString("EAST"), JMFUtil.getString("WEST"), JMFUtil.getString("NONE") };
  
  public String getJavaInitializationString() {
    String result = null;
    String propertyValue = getAsText();
    for (int i = 0; i < this.positionArr.length; i++) {
      if (propertyValue.equals(this.positionArr[i]))
        return "new java.lang.String(\"" + this.positionArr[i] + "\")"; 
    } 
    return null;
  }
  
  public String[] getTags() {
    return this.positionArr;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\bean\multiplayer\ButtonPositionEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */