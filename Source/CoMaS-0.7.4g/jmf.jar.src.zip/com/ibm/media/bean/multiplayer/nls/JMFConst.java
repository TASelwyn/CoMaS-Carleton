/*    */ package com.ibm.media.bean.multiplayer.nls;
/*    */ 
/*    */ import java.util.ListResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JMFConst
/*    */   extends ListResourceBundle
/*    */ {
/*    */   public static final String VERSION = "Version 0.1.0";
/*    */   public static final String PRODUCT = "Java Media Framework MultiPlayer Bean ";
/*    */   public static final String COPYRIGHT = "(c) Copyright IBM Corp. 1998. All Rights Reserved.";
/*    */   public static final String BaseINFO = "\r\nAuthor:Java Media Framework MultiPlayer Bean \r\nVersion 0.1.0";
/*    */   public static final String PleaseWAIT = " Please wait...";
/*    */   
/*    */   public Object[][] getContents() {
/* 18 */     return contents;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   static final Object[][] contents = new Object[][] { { "VERSION", "Version 0.1.0" }, { "PRODUCT", "Java Media Framework MultiPlayer Bean " }, { "COPYRIGHT", "(c) Copyright IBM Corp. 1998. All Rights Reserved." }, { "Info", "Info" }, { "Link", "Link" }, { "NORTH", "north" }, { "SOUTH", "south" }, { "WEST", "west" }, { "EAST", "east" }, { "NONE", "none" }, { "BadURL", "Incorrect URL - " }, { "InvalidURL", "Invalid URL" }, { "BadButtonImage", "Incorrect Button image. " }, { "BadCreateImage", "Couldn't create image: badly specified URL" }, { "PlayerBeanNotGood", "PlayerBean not good..." }, { "CantCreateBean", "Cannot create bean." }, { "MaxMGroup", "No more media groups can be added." } };
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\com\ibm\media\bean\multiplayer\nls\JMFConst.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */