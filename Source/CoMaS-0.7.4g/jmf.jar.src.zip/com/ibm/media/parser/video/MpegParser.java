package com.ibm.media.parser.video;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import com.sun.media.CircularBuffer;
import com.sun.media.JMFSecurity;
import com.sun.media.JMFSecurityManager;
import com.sun.media.format.WavAudioFormat;
import com.sun.media.parser.BasicPullParser;
import com.sun.media.util.jdk12;
import java.awt.Dimension;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import javax.media.BadHeaderException;
import javax.media.Buffer;
import javax.media.Duration;
import javax.media.Format;
import javax.media.IncompatibleSourceException;
import javax.media.Time;
import javax.media.Track;
import javax.media.TrackListener;
import javax.media.format.AudioFormat;
import javax.media.format.VideoFormat;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.DataSource;
import javax.media.protocol.PullSourceStream;
import javax.media.protocol.Seekable;

public class MpegParser extends BasicPullParser {
  boolean saveOutputFlag = false;
  
  String AoutName = "Audio.mpg";
  
  String VoutName = "Video.mpg";
  
  FileOutputStream aout;
  
  FileOutputStream vout;
  
  boolean throwOutputFlag = false;
  
  boolean hideAudioTracks = false;
  
  boolean hideVideoTracks = false;
  
  static final long NO_PTS_VAL = -3333333L;
  
  private static final float EPSILON_PTS = 45000.0F;
  
  private static final float EPSILON_NS = 5.0E8F;
  
  private static final long PRE_ROLLING_DELTA_NS = 500000000L;
  
  private static final byte UNKNOWN_TYPE = 0;
  
  private static final byte AUDIO_TYPE = 1;
  
  private static final byte VIDEO_TYPE = 2;
  
  private static final byte SYS11172_TYPE = 3;
  
  private static final int AUDIO_TRACK_BUF_SIZE = 100000;
  
  private static final int VIDEO_TRACK_BUF_SIZE = 200000;
  
  private static final int PACK_START_CODE = 442;
  
  private static final int SYSTEM_HEADER_START_CODE = 443;
  
  private static final int PACKET_START_CODE_24 = 1;
  
  private static final int END_CODE = 441;
  
  private static final int MIN_STREAM_CODE = 188;
  
  private static final int MAX_STREAM_CODE = 255;
  
  private static final int PRIVATE_STREAM2_CODE = 191;
  
  private static final int VIDEO_PICTURE_START_CODE = 256;
  
  private static final int VIDEO_SEQUENCE_HEADER_CODE = 435;
  
  private static final int VIDEO_GROUP_START_CODE = 440;
  
  private static final int MAX_AUDIO_STREAMS = 32;
  
  private static final int MAX_VIDEO_STREAMS = 16;
  
  private static final int MAX_NUM_STREAMS = 48;
  
  private static final int MIN_AUDIO_ID = 0;
  
  private static final int MAX_AUDIO_ID = 31;
  
  private static final int MIN_VIDEO_ID = 32;
  
  private static final int MAX_VIDEO_ID = 47;
  
  private static int MAX_TRACKS_SUPPORTED = 48;
  
  private static ContentDescriptor[] supportedFormat = new ContentDescriptor[] { new ContentDescriptor("audio.mpeg"), new ContentDescriptor("video.mpeg"), new ContentDescriptor("audio.mpeg") };
  
  private PullSourceStream stream = null;
  
  private TrackList[] trackList = new TrackList[MAX_TRACKS_SUPPORTED];
  
  private Track[] tracks = null;
  
  private Track[] videoTracks = null;
  
  private Track[] audioTracks = null;
  
  private int videoCount = 0;
  
  private int audioCount = 0;
  
  private int numSupportedTracks = 0;
  
  private int numTracks = 0;
  
  private int numPackets = 0;
  
  private int initTmpBufLen;
  
  private byte[] initTmpStreamBuf;
  
  private byte streamType = 0;
  
  private long streamContentLength = 0L;
  
  private SystemHeader sysHeader = new SystemHeader(this);
  
  private boolean sysHeaderSeen = false;
  
  boolean EOMflag = false;
  
  boolean parserErrorFlag = false;
  
  private boolean durationInitialized = false;
  
  private boolean sysPausedFlag = false;
  
  private boolean seekableStreamFlag = false;
  
  private boolean randomAccessStreamFlag = true;
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] mSecurity = new Method[1];
  
  private Class[] clSecurity = new Class[1];
  
  private Object[][] argsSecurity = new Object[1][0];
  
  private long startLocation = 0L;
  
  static {
    try {
      jmfSecurity = JMFSecurityManager.getJMFSecurity();
      securityPrivelege = true;
    } catch (SecurityException e) {}
  }
  
  private Time durationNs = Duration.DURATION_UNKNOWN;
  
  private Time lastSetPositionTime = new Time(0L);
  
  private long startPTS = -3333333L;
  
  long currentPTS = -3333333L;
  
  long endPTS = -3333333L;
  
  private long AVstartTimeNs = 0L;
  
  private long AVcurrentTimeNs = 0L;
  
  private long AVlastTimeNs = 0L;
  
  private long lastAudioNs = 0L;
  
  private MpegBufferThread mpThread = null;
  
  static int[][][] bitrates = new int[][][] { { { -1 }, { 
          0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 
          96, 112, 128, 144, 160, -1 }, { 
          0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 
          96, 112, 128, 144, 160, -1 }, { 
          0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 
          160, 176, 192, 224, 256, -1 } }, { { -1 } }, { { -1 }, { 
          0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 
          96, 112, 128, 144, 160, -1 }, { 
          0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 
          96, 112, 128, 144, 160, -1 }, { 
          0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 
          160, 176, 192, 224, 256, -1 } }, { { -1 }, { 
          0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 
          160, 192, 224, 256, 320, -1 }, { 
          0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 
          192, 224, 256, 320, 384, -1 }, { 
          0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 
          320, 352, 384, 416, 448, -1 } } };
  
  static int[][] samplerates = new int[][] { { 11025, 12000, 8000, -1 }, { -1 }, { 22050, 24000, 16000, -1 }, { 44100, 48000, 32000, -1 } };
  
  public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
    super.setSource(source);
    this.stream = (PullSourceStream)this.streams[0];
    this.streamContentLength = this.stream.getContentLength();
    this.seekableStreamFlag = this.streams[0] instanceof Seekable;
    if (!this.seekableStreamFlag)
      throw new IncompatibleSourceException("Mpeg Stream is not Seekable"); 
    this.randomAccessStreamFlag = (this.seekableStreamFlag && ((Seekable)this.streams[0]).isRandomAccess());
  }
  
  public ContentDescriptor[] getSupportedInputContentDescriptors() {
    return supportedFormat;
  }
  
  public void start() throws IOException {
    super.start();
    this.sysPausedFlag = false;
    if (this.mpThread != null)
      this.mpThread.start(); 
  }
  
  public void stop() {
    super.stop();
    this.sysPausedFlag = true;
    if (this.mpThread != null)
      this.mpThread.pause(); 
    for (int i = 0; i < this.numTracks; i++) {
      if (this.tracks[i] != null && this.tracks[i].isEnabled()) {
        TrackList info = ((MediaTrack)this.tracks[i]).getTrackInfo();
        info.releaseReadFrame();
      } 
    } 
  }
  
  public void close() {
    stop();
    flushInnerBuffers();
    super.close();
    if (this.mpThread != null)
      this.mpThread.kill(); 
  }
  
  public Track[] getTracks() throws IOException, BadHeaderException {
    if (this.streamType == 3) {
      if (this.hideAudioTracks && this.videoTracks != null)
        return this.videoTracks; 
      if (this.hideVideoTracks && this.audioTracks != null)
        return this.audioTracks; 
    } 
    if (this.tracks != null)
      return this.tracks; 
    try {
      this.initTmpBufLen = 100000;
      this.initTmpStreamBuf = new byte[this.initTmpBufLen];
      this.initTmpBufLen = detectStreamType(this.initTmpStreamBuf);
      switch (this.streamType) {
        case 1:
        case 2:
          initTrackAudioVideoOnly();
          break;
        case 3:
          initTrackSystemStream();
          break;
        default:
          throw new BadHeaderException("Couldn't detect stream type");
      } 
      initDuration();
      if (this.saveOutputFlag) {
        this.aout = new FileOutputStream(this.AoutName);
        this.vout = new FileOutputStream(this.VoutName);
      } 
      if (this.streamType == 3) {
        if (jmfSecurity != null) {
          String permission = null;
          try {
            if (jmfSecurity.getName().startsWith("jmf-security")) {
              permission = "thread";
              jmfSecurity.requestPermission(this.mSecurity, this.clSecurity, this.argsSecurity, 16);
              this.mSecurity[0].invoke(this.clSecurity[0], this.argsSecurity[0]);
              permission = "thread group";
              jmfSecurity.requestPermission(this.mSecurity, this.clSecurity, this.argsSecurity, 32);
              this.mSecurity[0].invoke(this.clSecurity[0], this.argsSecurity[0]);
            } else if (jmfSecurity.getName().startsWith("internet")) {
              PolicyEngine.checkPermission(PermissionID.THREAD);
              PolicyEngine.assertPermission(PermissionID.THREAD);
            } 
          } catch (Throwable e) {
            securityPrivelege = false;
          } 
        } 
        if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
          try {
            Constructor cons = jdk12CreateThreadAction.cons;
            this.mpThread = (MpegBufferThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { MpegBufferThread.class }) });
          } catch (Exception e) {
            System.err.println("MpegParser: Caught Exception " + e);
          } 
        } else {
          this.mpThread = new MpegBufferThread();
        } 
        if (this.mpThread != null) {
          this.mpThread.setParser(this);
          this.mpThread.start();
        } 
        if (this.saveOutputFlag || this.throwOutputFlag)
          try {
            Thread.sleep(30000L);
          } catch (InterruptedException e) {} 
      } 
      if (this.streamType == 3) {
        if (this.hideAudioTracks)
          return this.videoTracks; 
        if (this.hideVideoTracks)
          return this.audioTracks; 
      } 
      return this.tracks;
    } catch (BadDataException e) {
      this.parserErrorFlag = true;
      throw new BadHeaderException("Bad data");
    } catch (BadHeaderException e) {
      this.parserErrorFlag = true;
      throw e;
    } catch (IOException e) {
      updateEOMState();
      this.EOMflag = true;
      throw e;
    } 
  }
  
  private boolean isValidMp3Header(int code) {
    return ((code >>> 21 & 0x7FF) == 2047 && (code >>> 19 & 0x3) != 1 && (code >>> 17 & 0x3) != 0 && (code >>> 12 & 0xF) != 0 && (code >>> 12 & 0xF) != 15 && (code >>> 10 & 0x3) != 3 && (code & 0x3) != 2);
  }
  
  private int detectStreamType(byte[] streamBuf) throws IOException {
    int i = 0, videoCount = 0, audioCount = 0;
    boolean found = false;
    if (this.streamType != 0)
      return 0; 
    try {
      readBytes(this.stream, streamBuf, 4);
      while (!found && i < streamBuf.length - 5) {
        int code = (streamBuf[i] & 0xFF) << 24 | (streamBuf[i + 1] & 0xFF) << 16 | (streamBuf[i + 2] & 0xFF) << 8 | streamBuf[i + 3] & 0xFF;
        switch (code) {
          case 442:
            i++;
            readBytes(this.stream, streamBuf, i + 3, 1);
            if ((streamBuf[i + 3] & 0xFFFFFFF1) == 33) {
              this.streamType = 3;
              found = true;
            } 
            continue;
          case 435:
            if (i == 0) {
              this.streamType = 2;
              found = true;
            } 
          case 256:
          case 440:
            videoCount++;
            break;
          default:
            if ((code & 0xFFF00000) == -1048576 && (code & 0x60000) != 0 && isValidMp3Header(code)) {
              audioCount++;
              this.streamType = 1;
              found = true;
              this.startLocation = i;
            } 
            break;
        } 
        i++;
        readBytes(this.stream, streamBuf, i + 3, 1);
      } 
    } catch (IOException e) {
      if (this.streamType == 0)
        if (videoCount > 0) {
          this.streamType = 2;
        } else if (audioCount > 0) {
          this.streamType = 1;
        }  
      updateEOMState();
      this.EOMflag = true;
      throw e;
    } 
    if (this.streamType == 0)
      if (videoCount > 4) {
        this.streamType = 2;
      } else if (audioCount > 20) {
        this.streamType = 1;
      }  
    if (this.seekableStreamFlag && this.streamType == 1) {
      int duration = -1;
      Seekable s = (Seekable)this.stream;
      long currentPos = s.tell();
      s.seek(this.startLocation);
      int frameHeader = readInt(this.stream);
      int h_id = frameHeader >>> 19 & 0x3;
      int h_layer = frameHeader >>> 17 & 0x3;
      int h_bitrate = frameHeader >>> 12 & 0xF;
      int h_samplerate = frameHeader >>> 10 & 0x3;
      int h_padding = frameHeader >>> 9 & 0x1;
      int h_mode = frameHeader >>> 6 & 0x3;
      int bitrate = bitrates[h_id][h_layer][h_bitrate];
      int offset = ((h_id & 0x1) == 1) ? ((h_mode != 3) ? 36 : 21) : ((h_mode != 3) ? 21 : 13);
      s.seek(offset);
      String hdr = readString(this.stream);
      if (hdr.equals("Xing")) {
        int flags = readInt(this.stream);
        int frames = readInt(this.stream);
        int bytes = readInt(this.stream);
        int samplerate = samplerates[h_id][h_samplerate];
        int frameSize = 144000 * bitrate / samplerate + h_padding;
        duration = frameSize * frames / bitrate * 125;
        if (duration > 0) {
          this.durationInitialized = true;
          this.durationNs = new Time(duration);
        } 
      } 
      s.seek(currentPos);
    } 
    return i + 4;
  }
  
  private void initTrackAudioVideoOnly() throws IOException, BadHeaderException, BadDataException {
    int itmp = 0;
    this.numTracks = 1;
    this.tracks = new Track[1];
    this.trackList[0] = new TrackList();
    int possibleLen = (this.streamType == 1) ? 100000 : 200000;
    if (this.initTmpBufLen < possibleLen) {
      if (possibleLen > this.initTmpStreamBuf.length) {
        byte[] tmpBuf2 = new byte[possibleLen];
        System.arraycopy(this.initTmpStreamBuf, 0, tmpBuf2, 0, this.initTmpBufLen);
        this.initTmpStreamBuf = tmpBuf2;
      } 
      try {
        itmp = readBytes(this.stream, this.initTmpStreamBuf, this.initTmpBufLen, possibleLen - this.initTmpBufLen);
      } catch (IOException e) {
        updateEOMState();
        this.EOMflag = true;
      } 
      this.initTmpBufLen += itmp;
    } 
    TrackList trackInfo = this.trackList[0];
    do {
      extractStreamInfo(this.initTmpStreamBuf, 0, this.initTmpBufLen, true);
      if (trackInfo.infoFlag)
        break; 
      try {
        itmp = readBytes(this.stream, this.initTmpStreamBuf, possibleLen);
      } catch (IOException e) {
        updateEOMState();
        this.EOMflag = true;
        break;
      } 
      this.initTmpBufLen = itmp;
    } while (!trackInfo.infoFlag);
    if (!trackInfo.infoFlag) {
      this.numTracks = 0;
      this.tracks = null;
      throw new BadHeaderException("Sorry, No tracks found");
    } 
    ((Seekable)this.stream).seek(0L);
    this.initTmpBufLen = 0;
    this.EOMflag = false;
  }
  
  private void initTrackSystemStream() throws IOException, BadHeaderException, BadDataException {
    this.tracks = new Track[MAX_TRACKS_SUPPORTED];
    int i;
    for (i = 0; i < this.tracks.length; i++)
      this.tracks[i] = null; 
    for (i = 0; i < this.trackList.length; i++)
      this.trackList[i] = null; 
    mpegSystemParseBitstream(false, 0L, true, -3333333L);
    if (this.numTracks == 0)
      throw new BadHeaderException("Sorry, No tracks found"); 
    Track[] tmpTracks = new Track[this.numTracks];
    for (i = 0; i < this.numTracks; i++)
      tmpTracks[i] = this.tracks[i]; 
    this.tracks = tmpTracks;
    if (this.hideAudioTracks) {
      for (i = 0; i < this.numTracks; i++) {
        if (this.tracks[i] != null) {
          TrackList trackInfo = ((MediaTrack)this.tracks[i]).getTrackInfo();
          if (trackInfo.trackType == 2)
            this.videoCount++; 
        } 
      } 
      if (this.videoCount == 0)
        throw new BadHeaderException("Sorry, No video tracks found"); 
      this.videoTracks = new Track[this.videoCount];
      int v;
      for (i = 0, v = 0; i < this.numTracks; i++) {
        if (this.tracks[i] != null) {
          TrackList trackList = ((MediaTrack)this.tracks[i]).getTrackInfo();
          if (trackList.trackType == 2)
            this.videoTracks[v] = this.tracks[i]; 
        } 
      } 
    } 
    if (this.hideVideoTracks) {
      for (i = 0; i < this.numTracks; i++) {
        if (this.tracks[i] != null) {
          TrackList trackInfo = ((MediaTrack)this.tracks[i]).getTrackInfo();
          if (trackInfo.trackType == 1)
            this.audioCount++; 
        } 
      } 
      if (this.audioCount == 0)
        throw new BadHeaderException("Sorry, No video tracks found"); 
      this.audioTracks = new Track[this.audioCount];
      int v;
      for (i = 0, v = 0; i < this.numTracks; i++) {
        if (this.tracks[i] != null) {
          TrackList trackList = ((MediaTrack)this.tracks[i]).getTrackInfo();
          if (trackList.trackType == 1)
            this.audioTracks[v] = this.tracks[i]; 
        } 
      } 
    } 
  }
  
  public String getName() {
    return "Parser for MPEG-1 file format";
  }
  
  private long convPTStoNanoseconds(long val) {
    return val * 100000L / 9L;
  }
  
  private long convNanosecondsToPTS(long val) {
    return val * 9L / 100000L;
  }
  
  private long convBytesToTimeAV(long bytes) {
    long l;
    if (this.trackList[0] == null)
      return 0L; 
    if (this.streamType == 1) {
      if (((Audio)(this.trackList[0]).media).bitRate == 0) {
        l = 0L;
      } else {
        l = (bytes << 3L) / ((Audio)(this.trackList[0]).media).bitRate;
        l *= 1000000L;
      } 
    } else if (((Video)(this.trackList[0]).media).bitRate == 0) {
      l = 0L;
    } else {
      l = (bytes << 3L) / ((Video)(this.trackList[0]).media).bitRate;
      l *= 1000000000L;
    } 
    return l;
  }
  
  private long convTimeToBytesAV(long time) {
    long l;
    if (this.streamType == 1) {
      l = (time >> 3L) * ((Audio)(this.trackList[0]).media).bitRate;
      l /= 1000000L;
    } else {
      l = (time >> 3L) * ((Video)(this.trackList[0]).media).bitRate;
      l /= 1000000000L;
    } 
    return l;
  }
  
  public Time getDuration() {
    if (this.durationInitialized)
      return this.durationNs; 
    if (this.EOMflag)
      this.durationInitialized = true; 
    return this.durationNs;
  }
  
  private void initDuration() {
    if (this.streamContentLength != -1L)
      if (this.streamType == 3) {
        if (this.randomAccessStreamFlag)
          initDurationSystemSeekableRA(); 
      } else {
        updateDurationAudioVideoOnly();
      }  
  }
  
  private void updateDurationAudioVideoOnly() {
    if (this.durationInitialized)
      return; 
    this.AVstartTimeNs = 0L;
    this.AVcurrentTimeNs = 0L;
    this.AVlastTimeNs = convBytesToTimeAV(this.streamContentLength);
    this.durationNs = new Time(this.AVlastTimeNs - this.AVstartTimeNs);
    this.durationInitialized = true;
  }
  
  private void initDurationSystemSeekableRA() {
    long baseLocation = 0L;
    int saveNumPackets = this.numPackets;
    boolean saveEOMflag = this.EOMflag;
    baseLocation = ((Seekable)this.stream).tell();
    if (this.startPTS == -3333333L) {
      this.EOMflag = false;
      ((Seekable)this.stream).seek(0L);
      try {
        mpegSystemParseBitstream(true, 65536L, false, -3333333L);
      } catch (Exception e) {}
    } 
    if (this.startPTS == -3333333L)
      this.startPTS = 0L; 
    if (this.endPTS == -3333333L) {
      this.EOMflag = false;
      this.currentPTS = -3333333L;
      long ltmp = this.streamContentLength - 131072L;
      if (ltmp < 0L)
        ltmp = 0L; 
      ((Seekable)this.stream).seek(ltmp);
      try {
        mpegSystemParseBitstream(true, 131072L, false, -3333333L);
      } catch (Exception e) {}
      this.endPTS = this.currentPTS;
    } 
    if (this.endPTS == -3333333L)
      this.endPTS = this.startPTS; 
    long l1 = this.endPTS - this.startPTS;
    if (l1 < 0L) {
      l1 = 0L;
      this.parserErrorFlag = true;
    } 
    this.durationNs = new Time(convPTStoNanoseconds(l1));
    this.lastSetPositionTime = new Time(convPTStoNanoseconds(this.startPTS));
    ((Seekable)this.stream).seek(baseLocation);
    this.EOMflag = saveEOMflag;
    this.numPackets = saveNumPackets;
    this.durationInitialized = true;
  }
  
  void updateTrackEOM() {
    for (int i = 0; i < this.trackList.length; i++) {
      if (this.trackList[i] != null)
        this.trackList[i].generateEOM(); 
    } 
  }
  
  void updateEOMState() {
    if (!this.durationInitialized) {
      if (this.streamContentLength == -1L)
        this.streamContentLength = getLocation(this.stream); 
      if (this.streamType == 3) {
        if (this.startPTS == -3333333L)
          this.startPTS = 0L; 
        if (this.endPTS == -3333333L)
          this.endPTS = this.currentPTS; 
        if (this.endPTS == -3333333L)
          this.endPTS = this.startPTS; 
        long ltmp = this.endPTS - this.startPTS;
        if (ltmp < 0L) {
          ltmp = 0L;
          this.parserErrorFlag = true;
        } 
        this.durationNs = new Time(convPTStoNanoseconds(ltmp));
        this.durationInitialized = true;
      } else {
        updateDurationAudioVideoOnly();
      } 
    } 
  }
  
  public Time getMediaTime() {
    Time time;
    if (this.streamType == 3) {
      if (this.currentPTS == -3333333L) {
        time = new Time(0L);
      } else {
        time = new Time(convPTStoNanoseconds(this.currentPTS - this.startPTS));
      } 
    } else {
      this.AVcurrentTimeNs = convBytesToTimeAV(getLocation(this.stream));
      time = new Time(this.AVcurrentTimeNs);
    } 
    return time;
  }
  
  public Time setPosition(Time where, int rounding) {
    long l;
    Time newTime = null;
    if (!this.durationInitialized || this.durationNs == Duration.DURATION_UNKNOWN)
      return new Time(0L); 
    Time preWhere = new Time(where.getNanoseconds() - 500000000L);
    if (this.streamType == 3) {
      flushInnerBuffers();
      long preWherePTS = convNanosecondsToPTS(preWhere.getNanoseconds());
      preWherePTS += this.startPTS;
      long wherePTS = convNanosecondsToPTS(where.getNanoseconds());
      wherePTS += this.startPTS;
      long newPTS = setPositionSystemSeekableRA(preWherePTS, wherePTS);
      l = convPTStoNanoseconds(newPTS);
      this.lastAudioNs = l;
    } else {
      l = setPositionAudioVideoOnly(preWhere.getNanoseconds(), where.getNanoseconds());
      this.lastAudioNs = l;
    } 
    newTime = new Time(l);
    if (this.lastSetPositionTime.getNanoseconds() == l)
      l++; 
    this.lastSetPositionTime = new Time(l);
    this.EOMflag = false;
    this.parserErrorFlag = false;
    return newTime;
  }
  
  private long setPositionAudioVideoOnly(long where, long origWhere) {
    long l;
    if ((float)origWhere <= (float)this.AVstartTimeNs + 5.0E8F) {
      l = this.AVstartTimeNs;
      ((Seekable)this.stream).seek(0L);
    } else if ((float)origWhere >= (float)this.AVlastTimeNs - 5.0E8F) {
      l = this.AVlastTimeNs - this.AVstartTimeNs;
      ((Seekable)this.stream).seek(this.streamContentLength);
    } else {
      l = where;
      long pos = convTimeToBytesAV(where);
      ((Seekable)this.stream).seek(pos);
    } 
    return l;
  }
  
  private long setPositionSystemSeekableRA(long wherePTS, long origWherePTS) {
    long newTime = -3333333L;
    long lres = -1L;
    long saveStartPTS = this.startPTS;
    boolean saveEOMflag = this.EOMflag;
    boolean zeroPosFlag = false;
    if (this.endPTS == -3333333L || this.startPTS == -3333333L) {
      newTime = 0L;
      ((Seekable)this.stream).seek(0L);
    } else if ((float)origWherePTS <= (float)this.startPTS + 45000.0F) {
      newTime = 0L;
      ((Seekable)this.stream).seek(0L);
    } else if ((float)origWherePTS >= (float)this.endPTS - 45000.0F) {
      newTime = this.endPTS - this.startPTS;
      ((Seekable)this.stream).seek(this.streamContentLength);
    } else if ((float)(this.endPTS - this.startPTS) < 45000.0F) {
      newTime = 0L;
      ((Seekable)this.stream).seek(0L);
    } else {
      long pos = (long)((float)this.streamContentLength * (float)(wherePTS - this.startPTS) / (float)(this.endPTS - this.startPTS));
      long step = 20480L;
      pos -= step;
      if (pos < 0L)
        pos = 0L; 
      long range = this.streamContentLength - pos;
      while (true) {
        ((Seekable)this.stream).seek(pos);
        this.currentPTS = -3333333L;
        this.startPTS = -3333333L;
        this.EOMflag = false;
        try {
          lres = mpegSystemParseBitstream(true, range, false, wherePTS);
        } catch (IOException e) {
          lres = -2L;
          saveEOMflag = true;
        } catch (Exception e) {
          lres = -1L;
        } 
        if (lres >= 0L) {
          newTime = this.currentPTS - saveStartPTS;
          ((Seekable)this.stream).seek(lres);
          break;
        } 
        if (lres == -2L) {
          newTime = this.endPTS - saveStartPTS;
          ((Seekable)this.stream).seek(this.streamContentLength);
          break;
        } 
        pos -= step;
        if (pos <= 0L) {
          if (zeroPosFlag) {
            newTime = 0L;
            ((Seekable)this.stream).seek(0L);
            break;
          } 
          pos = 0L;
          zeroPosFlag = true;
        } 
        range = 3L * step;
      } 
      this.startPTS = saveStartPTS;
      this.EOMflag = saveEOMflag;
    } 
    return newTime;
  }
  
  long mpegSystemParseBitstream(boolean justLooking, long range, boolean justEnough, long newPTS) throws IOException, BadHeaderException, BadDataException {
    byte[] buf1 = new byte[1];
    int code = 0;
    boolean read4 = true, packFound = false;
    long baseLocation = getLocation(this.stream);
    long lastPacketLocation = baseLocation;
    long lastLastPacketLocation = baseLocation;
    long loc = baseLocation + 4L;
    long lastCurrentPTS = -3333333L;
    long savePTS = -3333333L;
    while (((!this.sysPausedFlag && !this.EOMflag) || justLooking || justEnough) && (
      !justEnough || needingMore())) {
      if (justLooking) {
        if (getLocation(this.stream) - baseLocation > range)
          break; 
        if (newPTS != -3333333L) {
          if (newPTS < this.startPTS)
            return -1L; 
          if (newPTS <= this.currentPTS) {
            if (newPTS == this.currentPTS)
              return lastPacketLocation; 
            this.currentPTS = lastCurrentPTS;
            return lastLastPacketLocation;
          } 
        } 
      } 
      if (read4) {
        code = readInt(this.stream, true);
      } else {
        readBytes(this.stream, buf1, 1);
        code = code << 8 & 0xFFFFFF00 | buf1[0] & 0xFF;
      } 
      switch (code) {
        case 442:
          parsePackHeader();
          read4 = true;
          packFound = true;
          continue;
        case 443:
          parseSystemHeader();
          read4 = true;
          continue;
        case 441:
          this.EOMflag = true;
          if (this.endPTS == -3333333L)
            this.endPTS = this.currentPTS; 
          if (!justLooking || newPTS != -3333333L)
            updateEOMState(); 
          continue;
      } 
      if (code >> 8 == 1 && (!justLooking || packFound & justLooking)) {
        if (justLooking && newPTS != -3333333L) {
          loc = getLocation(this.stream);
          savePTS = this.currentPTS;
        } 
        byte bval = (byte)(code & 0xFF);
        parsePacket(bval, justLooking);
        read4 = true;
        if (justLooking && newPTS != -3333333L)
          if (savePTS != this.currentPTS) {
            lastCurrentPTS = savePTS;
            lastLastPacketLocation = lastPacketLocation;
            lastPacketLocation = loc - 4L;
          }  
        continue;
      } 
      read4 = false;
    } 
    return this.EOMflag ? -2L : -1L;
  }
  
  private void parsePackHeader() throws IOException, BadDataException {
    byte[] buf1 = new byte[1];
    readBytes(this.stream, buf1, 1);
    if ((buf1[0] & 0xFFFFFFF0) != 32)
      throw new BadDataException("invalid pack header"); 
    if ((buf1[0] & 0x1) != 1)
      throw new BadDataException("illegal marker bit"); 
    skip(this.stream, 7);
  }
  
  private void parseSystemHeader() throws IOException, BadHeaderException {
    byte[] buf1 = new byte[1];
    int len = readShort(this.stream, true);
    if (this.sysHeaderSeen) {
      skip(this.stream, len);
    } else {
      this.sysHeader.resetSystemHeader();
      this.sysHeader.headerLen = len;
      int itmp = readInt(this.stream, true);
      len -= 4;
      if ((itmp & 0x80000100) != -2147483392)
        throw new BadHeaderException("illegal marker bits in system header"); 
      this.sysHeader.rateBound = (itmp & 0x7FFFFE00) >> 9;
      this.sysHeader.audioBound = (itmp & 0xFC) >> 2;
      this.sysHeader.fixedFlag = (itmp & 0x2) >> 1;
      this.sysHeader.CSPSFlag = itmp & 0x1;
      readBytes(this.stream, buf1, 1);
      byte bval = buf1[0];
      len--;
      if ((bval & 0x20) != 32)
        throw new BadHeaderException("illegal marker bits in system header"); 
      this.sysHeader.audioLockFlag = (bval & 0x80) >> 7;
      this.sysHeader.videoLockFlag = (bval & 0x40) >> 6;
      this.sysHeader.videoBound = bval & 0x1F;
      readBytes(this.stream, buf1, 1);
      len--;
      this.sysHeader.reserved = buf1[0];
      while (len > 1) {
        readBytes(this.stream, buf1, 1);
        bval = buf1[0];
        len--;
        if ((bval & Byte.MIN_VALUE) != -128)
          break; 
        if (bval == -72) {
          short stmp = readShort(this.stream, true);
          len -= 2;
          if ((stmp & 0xC000) != 49152)
            throw new BadHeaderException("illegal marker bits in system header"); 
          int size = stmp & 0x1FFF;
          this.sysHeader.allAudioSTDFlag = true;
          for (int i = 0; i <= 31; i++) {
            this.sysHeader.STDBufBoundScale[i] = 0;
            this.sysHeader.STDBufSizeBound[i] = size;
          } 
          continue;
        } 
        if (bval == -71) {
          short s = readShort(this.stream, true);
          len -= 2;
          if ((s & 0xC000) != 49152)
            throw new BadHeaderException("illegal marker bits in system header"); 
          int i = s & 0x1FFF;
          this.sysHeader.allVideoSTDFlag = true;
          for (byte b = 32; b <= 47; b++) {
            this.sysHeader.STDBufBoundScale[b] = 1;
            this.sysHeader.STDBufSizeBound[b] = i;
          } 
          continue;
        } 
        if ((bval & 0xFF) < 188 || (bval & 0xFF) > 255)
          throw new BadHeaderException("illegal track number in system header"); 
        int streamID = getStreamID(bval);
        if (streamID >= 0 && streamID < 48) {
          short s = readShort(this.stream, true);
          len -= 2;
          if ((s & 0xC000) != 49152)
            throw new BadHeaderException("illegal marker bits in system header"); 
          int scale = (s & 0x2000) >> 13;
          int i = s & 0x1FFF;
          this.sysHeader.streamFlags[streamID] = true;
          this.sysHeader.STDBufBoundScale[streamID] = scale;
          this.sysHeader.STDBufSizeBound[streamID] = i;
        } 
      } 
      if (len < 0)
        throw new BadHeaderException("illegal system header"); 
      if (len > 0)
        skip(this.stream, len); 
      this.sysHeaderSeen = true;
    } 
  }
  
  private void parsePacket(byte bval, boolean justLooking) throws IOException, BadDataException {
    int count = 0;
    int STDBufSize = 0;
    int STDBufScale = 0;
    int numWrittenToTmpBuf = 0;
    byte[] tmpBuf = null;
    byte[] buf1 = new byte[1];
    if ((bval & 0xFF) < 188 || (bval & 0xFF) > 255)
      throw new BadDataException("invalid stream(track) number"); 
    int streamID = getStreamID(bval);
    int packetLen = readShort(this.stream, true);
    buf1[0] = bval;
    if ((buf1[0] & 0xFF) != 191) {
      do {
        readBytes(this.stream, buf1, 1);
        count++;
      } while (buf1[0] == -1);
      if ((buf1[0] & 0xFFFFFFC0) == 64) {
        STDBufScale = (buf1[0] & 0x20) >> 5;
        STDBufSize = (buf1[0] & 0x1F) << 8;
        readBytes(this.stream, buf1, 1);
        STDBufSize |= buf1[0];
        readBytes(this.stream, buf1, 1);
        count += 2;
      } 
      if ((buf1[0] & 0xFFFFFFE0) == 32) {
        long pts = (buf1[0] & 0xE) << 29L;
        pts = pts << 31L >> 31L;
        if ((buf1[0] & 0x1) != 1)
          throw new BadDataException("illegal marker bit"); 
        int itmp = readInt(this.stream, true);
        count += 4;
        if ((itmp & 0x10001) != 65537)
          throw new BadDataException("illegal marker bit"); 
        int itmp2 = (itmp & 0xFFFE0000) >> 2;
        pts |= (itmp2 & 0x3FFFFFFF);
        pts |= ((itmp & 0xFFFE) >> 1);
        this.currentPTS = pts;
        if (this.startPTS == -3333333L) {
          this.startPTS = this.currentPTS;
          if (this.startPTS > 0L && (float)this.startPTS <= 45000.0F)
            this.startPTS = 0L; 
        } 
        if ((buf1[0] & 0xFFFFFFF0) == 48) {
          skip(this.stream, 5);
          count += 5;
        } 
      } else if (buf1[0] != 15) {
        throw new BadDataException("invalid packet");
      } 
    } 
    int dataSize = packetLen - count;
    if (justLooking) {
      skip(this.stream, dataSize);
      return;
    } 
    if (streamID < 0 || streamID >= 48) {
      skip(this.stream, dataSize);
    } else {
      if (this.trackList[streamID] == null)
        this.trackList[streamID] = new TrackList(); 
      TrackList trackInfo = this.trackList[streamID];
      if (!trackInfo.infoFlag) {
        tmpBuf = new byte[dataSize];
        numWrittenToTmpBuf = extractStreamInfo(tmpBuf, streamID, dataSize, false);
      } 
      if (!trackInfo.infoFlag) {
        this.trackList[streamID] = null;
        if (numWrittenToTmpBuf < dataSize)
          skip(this.stream, dataSize - numWrittenToTmpBuf); 
      } else {
        if (this.startPTS == -3333333L)
          trackInfo.startPTS = this.currentPTS; 
        trackInfo.copyStreamDataToInnerBuffer(tmpBuf, numWrittenToTmpBuf, dataSize - numWrittenToTmpBuf, this.currentPTS);
        trackInfo.numPackets++;
        if (dataSize > trackInfo.maxPacketSize)
          trackInfo.maxPacketSize = dataSize; 
      } 
    } 
    this.numPackets++;
  }
  
  private int extractStreamInfo(byte[] tmpBuf, int streamID, int dataLen, boolean AVOnlyState) throws IOException, BadDataException {
    int i;
    byte stype = 0;
    TrackList trackInfo = this.trackList[streamID];
    if (trackInfo.trackType == 0) {
      stype = AVOnlyState ? this.streamType : ((streamID < 32) ? 1 : 2);
      trackInfo.init(stype);
      this.sysHeader.streamFlags[streamID] = true;
      trackInfo.startPTS = this.currentPTS;
    } 
    if (stype == 1) {
      i = extractAudioInfo(tmpBuf, trackInfo, dataLen, AVOnlyState);
    } else {
      i = extractVideoInfo(tmpBuf, trackInfo, dataLen, AVOnlyState);
    } 
    if (trackInfo.infoFlag == true)
      if (AVOnlyState) {
        this.tracks[0] = new MediaTrack(this, trackInfo);
      } else {
        this.tracks[this.numTracks] = new MediaTrack(this, trackInfo);
        this.numTracks++;
      }  
    return i;
  }
  
  private int extractAudioInfo(byte[] tmpBuf, TrackList trackInfo, int dataLen, boolean AVOnlyState) throws IOException, BadDataException {
    Audio audio = new Audio();
    int[] samplingFrequencyTable = { 44100, 48000, 32000 };
    short[] bitrateIndexTableL2 = { 
        0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 
        192, 224, 256, 320, 384 };
    short[] bitrateIndexTableL23Ext = { 
        0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 
        96, 112, 128, 144, 160 };
    int numBytes = AVOnlyState ? dataLen : readBytes(this.stream, tmpBuf, dataLen);
    for (int i = (int)this.startLocation; i < numBytes - 3; i++) {
      if (tmpBuf[i] == -1 && (tmpBuf[i + 1] & 0xFFFFFFF0) == -16) {
        audio.ID = (tmpBuf[i + 1] & 0x8) >> 3;
        audio.layer = 4 - ((tmpBuf[i + 1] & 0x6) >> 1);
        audio.protection = tmpBuf[i + 1] & 0x1;
        int br = (tmpBuf[i + 2] & 0xF0) >> 4;
        int sr = (tmpBuf[i + 2] & 0xC) >> 2;
        if (sr < 0 || sr >= samplingFrequencyTable.length)
          throw new BadDataException("Non Standard sample rates not supported"); 
        audio.mode = (tmpBuf[i + 3] & 0xC0) >> 6;
        audio.modeExt = (tmpBuf[i + 3] & 0x30) >> 4;
        audio.channels = (audio.mode == 3) ? 1 : 2;
        audio.copyright = (tmpBuf[i + 3] & 0x8) >> 3;
        audio.original = (tmpBuf[i + 3] & 0x4) >> 2;
        audio.emphasis = tmpBuf[i + 3] & 0x3;
        audio.valid = (br != 15);
        if (audio.ID == 1) {
          audio.sampleRate = samplingFrequencyTable[sr];
          if (audio.layer == 3) {
            if (br < 2) {
              audio.bitRate = bitrateIndexTableL2[br];
            } else if (br == 2) {
              audio.bitRate = 40;
            } else {
              audio.bitRate = bitrateIndexTableL2[br - 1];
            } 
          } else if (audio.layer == 2) {
            audio.bitRate = bitrateIndexTableL2[br];
          } else {
            audio.bitRate = br << 5;
          } 
        } else {
          audio.sampleRate = samplingFrequencyTable[sr] >> 1;
          if (audio.layer == 3 || audio.layer == 2) {
            audio.bitRate = bitrateIndexTableL23Ext[br];
          } else if (br < 9) {
            audio.bitRate = bitrateIndexTableL2[br];
          } else if (br == 9) {
            audio.bitRate = 144;
          } else if (br == 10) {
            audio.bitRate = bitrateIndexTableL2[br - 1];
          } else if (br == 11) {
            audio.bitRate = 176;
          } else {
            audio.bitRate = bitrateIndexTableL2[br - 2];
          } 
        } 
        trackInfo.readFrameSize = audio.bitRate * 1000 >> 3;
        trackInfo.infoFlag = true;
        trackInfo.media = audio;
        break;
      } 
    } 
    return numBytes;
  }
  
  private int extractVideoInfo(byte[] tmpBuf, TrackList trackInfo, int dataLen, boolean AVOnlyState) throws IOException, BadDataException {
    Video video = new Video();
    float[] aspectRatioTable = { 
        0.0F, 1.0F, 0.6735F, 0.7031F, 0.7615F, 0.8055F, 0.8437F, 0.8935F, 0.9375F, 0.9815F, 
        1.0255F, 1.0695F, 1.125F, 1.1575F, 1.2015F, 1.0F };
    float[] pictureRateTable = { 
        0.0F, 23.976F, 24.0F, 25.0F, 29.97F, 30.0F, 50.0F, 59.94F, 60.0F, -1.0F, 
        -1.0F, -1.0F, -1.0F, -1.0F, -1.0F, -1.0F };
    int numBytes = AVOnlyState ? dataLen : readBytes(this.stream, tmpBuf, dataLen);
    for (int i = 0; i < numBytes - 10; i++) {
      int code = tmpBuf[i] << 24 & 0xFF000000 | tmpBuf[i + 1] << 16 & 0xFF0000 | tmpBuf[i + 2] << 8 & 0xFF00 | tmpBuf[i + 3] & 0xFF;
      if (code == 435) {
        video.width = (tmpBuf[i + 4 + 0] & 0xFF) << 4;
        video.width |= tmpBuf[i + 4 + 1] >> 4 & 0xF;
        video.height = (tmpBuf[i + 4 + 1] & 0xF) << 8;
        video.height |= tmpBuf[i + 4 + 2] & 0xFF;
        int pr = (tmpBuf[i + 4 + 3] & 0xF0) >> 4;
        video.pelAspectRatio = aspectRatioTable[pr];
        pr = tmpBuf[i + 4 + 3] & 0xF;
        video.pictureRate = pictureRateTable[pr];
        pr = (tmpBuf[i + 4 + 4] & 0xFF) << 10 | (tmpBuf[i + 4 + 5] & 0xFF) << 2 | (tmpBuf[i + 4 + 6] & 0xC0) >> 6;
        video.bitRate = pr * 400;
        if (video.pelAspectRatio == 0.0D || video.pictureRate == 0.0D)
          throw new BadDataException("video header corrupted"); 
        if (video.pictureRate < 23.0D) {
          trackInfo.readFrameSize = 65536;
        } else {
          trackInfo.readFrameSize = video.bitRate >> 3;
          if (trackInfo.readFrameSize > 100000)
            trackInfo.readFrameSize = 100000; 
        } 
        trackInfo.infoFlag = true;
        trackInfo.media = video;
        break;
      } 
    } 
    return numBytes;
  }
  
  private int getStreamID(byte bval) {
    return (bval & 0xFF) - 192;
  }
  
  private long getLocation() {
    return getLocation(this.stream);
  }
  
  boolean needingMore() {
    for (int i = 0; i < this.numTracks; i++) {
      if (this.tracks[i] != null) {
        TrackList trackInfo = ((MediaTrack)this.tracks[i]).getTrackInfo();
        if (trackInfo.bufQ.canRead())
          return false; 
      } 
    } 
    return true;
  }
  
  void flushInnerBuffers() {
    for (int i = 0; i < this.numTracks; i++) {
      if (this.tracks[i] != null) {
        TrackList trackInfo = ((MediaTrack)this.tracks[i]).getTrackInfo();
        synchronized (trackInfo.bufQ) {
          trackInfo.flushFlag = true;
          trackInfo.bufQ.notifyAll();
        } 
        trackInfo.flushBuffer();
      } 
    } 
  }
  
  void saveInnerBuffersToFiles() {
    for (int i = 0; i < this.numTracks; i++) {
      if (this.tracks[i] != null) {
        TrackList trackInfo = ((MediaTrack)this.tracks[i]).getTrackInfo();
        trackInfo.saveBufToFile();
      } 
    } 
  }
  
  void throwInnerBuffersContents() {
    for (int i = 0; i < this.numTracks; i++) {
      if (this.tracks[i] != null) {
        TrackList trackInfo = ((MediaTrack)this.tracks[i]).getTrackInfo();
        trackInfo.flushBuffer();
      } 
    } 
  }
  
  private abstract class Media {
    private final MpegParser this$0;
    
    private Media(MpegParser this$0) {
      MpegParser.this = MpegParser.this;
    }
    
    abstract Format createFormat();
  }
  
  private class Audio extends Media {
    boolean valid;
    
    int ID;
    
    int layer;
    
    int protection;
    
    int bitRate;
    
    int sampleRate;
    
    int mode;
    
    int modeExt;
    
    int copyright;
    
    int original;
    
    int emphasis;
    
    int channels;
    
    AudioFormat format;
    
    static Class array$B;
    
    private final MpegParser this$0;
    
    private Audio(MpegParser this$0) {
      MpegParser.this = MpegParser.this;
      this.valid = false;
      this.ID = 0;
      this.layer = 0;
      this.protection = 0;
      this.bitRate = 0;
      this.sampleRate = 0;
      this.mode = 0;
      this.modeExt = 0;
      this.copyright = 0;
      this.original = 0;
      this.emphasis = 0;
      this.channels = 0;
      this.format = null;
    }
    
    static Class class$(String x0) {
      try {
        return Class.forName(x0);
      } catch (ClassNotFoundException x1) {
        throw new NoClassDefFoundError(x1.getMessage());
      } 
    }
    
    Format createFormat() {
      String str;
      if (this.format != null)
        return (Format)this.format; 
      if (this.layer == 3) {
        str = "mpeglayer3";
      } else {
        str = "mpegaudio";
      } 
      int bitsPerSample = 16;
      int frameSizeInBits = ((this.layer == 1) ? 352 : 1024) * this.channels * bitsPerSample;
      int bytesPerSecond = this.bitRate * 1000 >> 3;
      this.format = (AudioFormat)new WavAudioFormat(str, this.sampleRate, bitsPerSample, this.channels, frameSizeInBits, bytesPerSecond, 0, 1, -1.0F, (array$B == null) ? (array$B = class$("[B")) : array$B, null);
      return (Format)this.format;
    }
    
    public String toString() {
      System.out.println("Audio Media: " + this.format);
      System.out.println("Number of channels " + this.channels);
      System.out.println("valid " + this.valid);
      System.out.println("ID " + this.ID);
      System.out.println("layer " + this.layer);
      System.out.println("protection " + this.protection);
      System.out.println("bitrate " + this.bitRate);
      System.out.println("sample rate " + this.sampleRate);
      System.out.println("Mode " + this.mode + " ext " + this.modeExt);
      System.out.println("copyright " + this.copyright);
      System.out.println("original " + this.original);
      System.out.println("emphasis " + this.emphasis);
      System.out.println("channels " + this.channels);
      return super.toString();
    }
  }
  
  private class Video extends Media {
    int width;
    
    int height;
    
    float pelAspectRatio;
    
    float pictureRate;
    
    int bitRate;
    
    VideoFormat format;
    
    static Class array$B;
    
    private final MpegParser this$0;
    
    private Video(MpegParser this$0) {
      MpegParser.this = MpegParser.this;
      this.width = 0;
      this.height = 0;
      this.pelAspectRatio = 0.0F;
      this.pictureRate = 0.0F;
      this.bitRate = 0;
      this.format = null;
    }
    
    static Class class$(String x0) {
      try {
        return Class.forName(x0);
      } catch (ClassNotFoundException x1) {
        throw new NoClassDefFoundError(x1.getMessage());
      } 
    }
    
    Format createFormat() {
      int size = (int)((this.width * this.height) * 1.5D);
      if (this.format != null)
        return (Format)this.format; 
      this.format = new VideoFormat("mpeg", new Dimension(this.width, this.height), size, (array$B == null) ? (array$B = class$("[B")) : array$B, this.pictureRate);
      return (Format)this.format;
    }
    
    public String toString() {
      System.out.println("Video Media: " + this.format);
      System.out.println("width " + this.width);
      System.out.println("height " + this.height);
      System.out.println("pixel aspect ratio " + this.pelAspectRatio);
      System.out.println("picture rate " + this.pictureRate);
      System.out.println("bitrate " + this.bitRate);
      return super.toString();
    }
  }
  
  private class TrackList {
    byte trackType;
    
    Time duration;
    
    long startPTS;
    
    boolean infoFlag;
    
    int numPackets;
    
    int maxPacketSize;
    
    int readFrameSize;
    
    MpegParser.Media media;
    
    boolean supported;
    
    boolean flushFlag;
    
    CircularBuffer bufQ;
    
    Buffer current;
    
    MpegParser parser;
    
    private final MpegParser this$0;
    
    private TrackList(MpegParser this$0) {
      MpegParser.this = MpegParser.this;
      this.trackType = 0;
      this.duration = Duration.DURATION_UNKNOWN;
      this.startPTS = -3333333L;
      this.infoFlag = false;
      this.numPackets = 0;
      this.maxPacketSize = 0;
      this.readFrameSize = 0;
      this.supported = false;
      this.flushFlag = false;
      this.bufQ = null;
      this.current = null;
      this.parser = MpegParser.this;
    }
    
    void init(byte stype) {
      this.supported = true;
      this.trackType = stype;
      if (this.trackType == 2) {
        this.bufQ = new CircularBuffer(15);
      } else {
        this.bufQ = new CircularBuffer(10);
      } 
    }
    
    int readyDataBytes() {
      return 1;
    }
    
    void copyStreamDataToInnerBuffer(byte[] in, int inSize, int size, long pts) throws IOException {
      int total = size;
      int len = 0;
      if (inSize > 0) {
        total += inSize;
      } else {
        inSize = 0;
      } 
      synchronized (this.bufQ) {
        byte[] arrayOfByte;
        if (this.current != null) {
          len = this.current.getLength();
          if (len != 0 && len + total >= this.readFrameSize) {
            this.bufQ.writeReport();
            this.bufQ.notify();
            this.current = null;
          } 
        } 
        this.flushFlag = false;
        if (this.current == null) {
          while (!this.bufQ.canWrite() && !this.flushFlag) {
            try {
              this.bufQ.wait();
            } catch (InterruptedException e) {}
          } 
          if (this.flushFlag)
            return; 
          this.current = this.bufQ.getEmptyBuffer();
          this.current.setFlags(0);
          this.current.setOffset(0);
          this.current.setLength(0);
          this.current.setTimeStamp(MpegParser.this.convPTStoNanoseconds(pts));
          int bsize = (total > this.readFrameSize) ? total : this.readFrameSize;
          arrayOfByte = (byte[])this.current.getData();
          if (arrayOfByte == null || arrayOfByte.length < bsize) {
            arrayOfByte = new byte[bsize];
            this.current.setData(arrayOfByte);
          } 
        } else {
          arrayOfByte = (byte[])this.current.getData();
        } 
        len = this.current.getLength();
        if (inSize > 0)
          System.arraycopy(in, 0, arrayOfByte, len, inSize); 
        this.parser.readBytes(MpegParser.this.stream, arrayOfByte, len + inSize, size);
        this.current.setLength(len + total);
      } 
    }
    
    void copyFromInnerBuffer(Buffer out) {
      synchronized (this.bufQ) {
        while (!this.bufQ.canRead() && !MpegParser.this.sysPausedFlag && !MpegParser.this.parserErrorFlag) {
          try {
            this.bufQ.wait();
          } catch (InterruptedException e) {}
        } 
        if (MpegParser.this.sysPausedFlag || MpegParser.this.parserErrorFlag) {
          out.setLength(0);
          out.setDiscard(true);
          return;
        } 
        Buffer buf = this.bufQ.read();
        byte[] saved = (byte[])out.getData();
        out.copy(buf);
        buf.setData(saved);
        this.bufQ.readReport();
        this.bufQ.notify();
      } 
    }
    
    void releaseReadFrame() {
      synchronized (this.bufQ) {
        this.bufQ.notifyAll();
      } 
    }
    
    void generateEOM() {
      synchronized (this.bufQ) {
        if (this.current != null) {
          this.bufQ.writeReport();
          this.bufQ.notify();
          this.current = null;
        } 
        while (!this.bufQ.canWrite()) {
          try {
            this.bufQ.wait();
          } catch (InterruptedException e) {}
        } 
        Buffer buf = this.bufQ.getEmptyBuffer();
        buf.setFlags(1);
        buf.setLength(0);
        this.bufQ.writeReport();
        this.bufQ.notify();
      } 
    }
    
    void flushBuffer() {
      synchronized (this.bufQ) {
        if (this.current != null) {
          this.current.setDiscard(true);
          this.bufQ.writeReport();
          this.current = null;
        } 
        while (this.bufQ.canRead()) {
          this.bufQ.read();
          this.bufQ.readReport();
        } 
        this.bufQ.notifyAll();
      } 
    }
    
    public String toString() {
      System.out.println("track type " + this.trackType + "(0 ?, 1 audio, 2 video)");
      System.out.println("start PTS " + this.startPTS);
      System.out.println("info flag " + this.infoFlag);
      System.out.println("number of packets " + this.numPackets);
      System.out.println("maximum packet size " + this.maxPacketSize);
      System.out.println("supported " + this.supported);
      System.out.println("duration (?) " + this.duration);
      return this.media.toString();
    }
    
    void saveBufToFile() {}
  }
  
  private class MediaTrack implements Track {
    private MpegParser.TrackList trackInfo;
    
    private boolean enabled;
    
    private long sequenceNumber;
    
    private Format format;
    
    private TrackListener listener;
    
    MpegParser parser;
    
    private final MpegParser this$0;
    
    MediaTrack(MpegParser this$0, MpegParser.TrackList trackInfo) {
      this.this$0 = this$0;
      this.sequenceNumber = 0L;
      this.parser = this.this$0;
      this.trackInfo = trackInfo;
      this.enabled = true;
      this.format = trackInfo.media.createFormat();
    }
    
    public void setTrackListener(TrackListener l) {
      this.listener = l;
    }
    
    public Format getFormat() {
      return this.format;
    }
    
    public void setEnabled(boolean t) {
      this.enabled = t;
    }
    
    public boolean isEnabled() {
      return this.enabled;
    }
    
    public Time getDuration() {
      return this.trackInfo.duration;
    }
    
    public Time getStartTime() {
      if (this.this$0.streamType == 3)
        return new Time(this.this$0.startPTS / 90000.0D); 
      return new Time(this.this$0.AVstartTimeNs);
    }
    
    public void readFrame(Buffer buffer) {
      if (buffer == null)
        return; 
      if (!this.enabled) {
        buffer.setDiscard(true);
        return;
      } 
      if (this.this$0.streamType == 3) {
        systemStreamReadFrame(buffer);
      } else {
        AudioVideoOnlyReadFrame(buffer);
      } 
      buffer.setFormat(this.format);
      buffer.setSequenceNumber(++this.sequenceNumber);
      if (this.format instanceof AudioFormat) {
        long tmp = buffer.getTimeStamp();
        buffer.setTimeStamp(this.this$0.lastAudioNs);
        this.this$0.lastAudioNs = tmp;
      } 
    }
    
    private void AudioVideoOnlyReadFrame(Buffer buffer) {
      byte[] arrayOfByte;
      if (this.this$0.sysPausedFlag || this.this$0.parserErrorFlag) {
        buffer.setLength(0);
        buffer.setDiscard(true);
      } 
      int size = this.trackInfo.readFrameSize;
      Object obj = buffer.getData();
      if (obj == null || !(obj instanceof byte[]) || ((byte[])obj).length < size) {
        arrayOfByte = new byte[size];
        buffer.setData(arrayOfByte);
      } else {
        arrayOfByte = (byte[])obj;
      } 
      int read1 = 0, read2 = size;
      int actualBytesRead = 0, counter = 0;
      if (this.this$0.initTmpBufLen > 0) {
        read1 = (this.this$0.initTmpBufLen > size) ? size : this.this$0.initTmpBufLen;
        System.arraycopy(this.this$0.initTmpStreamBuf, 0, arrayOfByte, 0, read1);
        this.this$0.initTmpBufLen -= read1;
        read2 -= read1;
        counter = read1;
      } 
      if (this.trackInfo.trackType == 1)
        buffer.setTimeStamp(this.this$0.convBytesToTimeAV(this.this$0.getLocation() - read1)); 
      if (read2 > 0 && !this.this$0.EOMflag)
        try {
          actualBytesRead = this.parser.readBytes(this.this$0.stream, arrayOfByte, read1, read2);
          if (actualBytesRead == -2) {
            if (read1 == 0) {
              buffer.setDiscard(true);
              return;
            } 
          } else {
            counter += actualBytesRead;
          } 
        } catch (IOException e) {
          this.this$0.updateEOMState();
          this.this$0.EOMflag = true;
          if (this.this$0.AVlastTimeNs == 0L) {
            this.this$0.AVcurrentTimeNs = this.this$0.convBytesToTimeAV(this.this$0.getLocation());
            this.this$0.AVlastTimeNs = this.this$0.AVcurrentTimeNs;
          } 
        }  
      if (this.this$0.EOMflag)
        if (read1 > 0) {
          buffer.setLength(read1);
          buffer.setOffset(0);
        } else {
          buffer.setLength(0);
          buffer.setEOM(true);
        }  
      buffer.setOffset(0);
      buffer.setLength(counter);
    }
    
    private void systemStreamReadFrame(Buffer buffer) {
      this.trackInfo.copyFromInnerBuffer(buffer);
      if (this.this$0.sysPausedFlag || this.this$0.parserErrorFlag)
        return; 
      for (int i = 0; i < this.this$0.numTracks; i++) {
        if (this.this$0.tracks[i] != null && 
          !this.this$0.tracks[i].isEnabled()) {
          MpegParser.TrackList AtrackInfo = ((MediaTrack)this.this$0.tracks[i]).getTrackInfo();
          AtrackInfo.flushBuffer();
        } 
      } 
      if (this.this$0.hideAudioTracks)
        for (int j = 0; j < this.this$0.numTracks; j++) {
          if (this.this$0.tracks[j] != null) {
            MpegParser.TrackList AtrackInfo = ((MediaTrack)this.this$0.tracks[j]).getTrackInfo();
            if (AtrackInfo.trackType == 1)
              AtrackInfo.flushBuffer(); 
          } 
        }  
      if (this.this$0.hideVideoTracks)
        for (int j = 0; j < this.this$0.numTracks; j++) {
          if (this.this$0.tracks[j] != null) {
            MpegParser.TrackList AtrackInfo = ((MediaTrack)this.this$0.tracks[j]).getTrackInfo();
            if (AtrackInfo.trackType == 2)
              AtrackInfo.flushBuffer(); 
          } 
        }  
    }
    
    public int mapTimeToFrame(Time t) {
      return 0;
    }
    
    public Time mapFrameToTime(int frameNumber) {
      return null;
    }
    
    private MpegParser.TrackList getTrackInfo() {
      return this.trackInfo;
    }
  }
  
  private class SystemHeader {
    int headerLen;
    
    int rateBound;
    
    int audioBound;
    
    int fixedFlag;
    
    int CSPSFlag;
    
    int audioLockFlag;
    
    int videoLockFlag;
    
    int videoBound;
    
    int reserved;
    
    boolean allAudioSTDFlag;
    
    boolean allVideoSTDFlag;
    
    boolean[] streamFlags;
    
    int[] STDBufBoundScale;
    
    int[] STDBufSizeBound;
    
    private final MpegParser this$0;
    
    SystemHeader(MpegParser this$0) {
      this.this$0 = this$0;
      this.headerLen = 0;
      this.rateBound = 0;
      this.audioBound = 0;
      this.fixedFlag = 0;
      this.CSPSFlag = 0;
      this.audioLockFlag = 0;
      this.videoLockFlag = 0;
      this.videoBound = 0;
      this.reserved = 0;
      this.allAudioSTDFlag = false;
      this.allVideoSTDFlag = false;
      this.streamFlags = new boolean[48];
      this.STDBufBoundScale = new int[48];
      this.STDBufSizeBound = new int[48];
      for (int i = 0; i < 48; i++) {
        this.streamFlags[i] = false;
        this.STDBufBoundScale[i] = 0;
        this.STDBufSizeBound[i] = 0;
      } 
    }
    
    void resetSystemHeader() {
      this.headerLen = 0;
      this.rateBound = 0;
      this.audioBound = 0;
      this.fixedFlag = 0;
      this.CSPSFlag = 0;
      this.audioLockFlag = 0;
      this.videoLockFlag = 0;
      this.videoBound = 0;
      this.reserved = 0;
      this.allAudioSTDFlag = false;
      this.allVideoSTDFlag = false;
      for (int i = 0; i < 48; i++) {
        this.streamFlags[i] = false;
        this.STDBufBoundScale[i] = 0;
        this.STDBufSizeBound[i] = 0;
      } 
    }
    
    void printFields() {
      System.out.println("headerLen " + this.headerLen);
      System.out.println("rateBound " + this.rateBound);
      System.out.println("audioBound " + this.audioBound);
      System.out.println("fixedFlag " + this.fixedFlag);
      System.out.println("CSPSFlag " + this.CSPSFlag);
      System.out.println("audioLockFlag " + this.audioLockFlag);
      System.out.println("videoLockFlag " + this.videoLockFlag);
      System.out.println("videoBound " + this.videoBound);
      System.out.println("reserved " + this.reserved);
      System.out.println("allAudioSTDFlag " + this.allAudioSTDFlag);
      System.out.println("allVideoSTDFlag " + this.allVideoSTDFlag);
      for (int i = 0; i < 48; i++) {
        if (this.streamFlags[i])
          System.out.println("[" + i + "]  STDBufBoundScale " + this.STDBufBoundScale[i] + "     STDBufSizeBound " + this.STDBufSizeBound[i]); 
      } 
    }
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\parser\video\MpegParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */