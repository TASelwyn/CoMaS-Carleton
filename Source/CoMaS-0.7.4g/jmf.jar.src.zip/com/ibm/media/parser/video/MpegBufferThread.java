package com.ibm.media.parser.video;

import com.sun.media.Log;
import com.sun.media.util.LoopThread;
import java.io.IOException;
import javax.media.BadHeaderException;

class MpegBufferThread extends LoopThread {
  private MpegParser parser;
  
  MpegBufferThread() {
    setName(getName() + " (MpegBufferThread)");
    useVideoPriority();
  }
  
  void setParser(MpegParser p) {
    this.parser = p;
  }
  
  public boolean process() {
    if (this.parser.EOMflag) {
      this.parser.updateTrackEOM();
      pause();
      return true;
    } 
    try {
      this.parser.mpegSystemParseBitstream(false, 0L, false, -3333333L);
    } catch (BadDataException e) {
      this.parser.parserErrorFlag = true;
    } catch (BadHeaderException e) {
      this.parser.parserErrorFlag = true;
    } catch (IOException e) {
      this.parser.updateEOMState();
      this.parser.EOMflag = true;
      if (this.parser.endPTS == -3333333L)
        this.parser.endPTS = this.parser.currentPTS; 
    } 
    if (this.parser.parserErrorFlag) {
      Log.error("MPEG parser error: possibly with a corrupted bitstream.");
      pause();
    } 
    return true;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\parser\video\MpegBufferThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */