package com.ibm.media;

import java.net.URL;
import javax.media.Controller;
import javax.media.ControllerEvent;

public class ReplaceURLEvent extends ControllerEvent {
  private URL u;
  
  public ReplaceURLEvent(Controller from, URL u) {
    super(from);
    this.u = u;
  }
  
  public URL getURL() {
    return this.u;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\com\ibm\media\ReplaceURLEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */