package codecLib.mpa;

import java.util.ResourceBundle;

class e {
  static String a(String paramString) {
    return ResourceBundle.getBundle("com.sun.medialib.codec.mpad.MPADExceptionStrings").getString(paramString);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\codecLib\mpa\e.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */