package codecLib.mpa;

class PolySynthesis implements Tables, Constants {
  protected float[][][] k = new float[12][2][272];
  
  protected int[] j = new int[12];
  
  static final float[] l = new float[] { 
      0.0F, 0.7071068F, 0.5411961F, 1.306563F, 0.5097956F, 0.6013449F, 0.8999762F, 2.5629156F, 0.5024193F, 0.5224986F, 
      0.5669441F, 0.6468218F, 0.7881546F, 1.0606776F, 1.7224472F, 5.1011486F, -0.500603F, -0.5054709F, -0.5154473F, -0.5310426F, 
      -0.5531039F, -0.582935F, -0.6225041F, -0.6748083F, -0.7445363F, -0.8393496F, -0.9725682F, -1.1694399F, -1.4841646F, -2.057781F, 
      -3.4076085F, -10.190008F };
  
  static final float[] m = new float[] { 
      0.0F, -4.425E-4F, 0.00325012F, -0.00700378F, 0.03108215F, -0.07862854F, 0.10031128F, -0.57203674F, 1.144989F, 0.57203674F, 
      0.10031128F, 0.07862854F, 0.03108215F, 0.00700378F, 0.00325012F, 4.425E-4F, -1.526E-5F, -4.7302E-4F, 0.00332642F, -0.00791931F, 
      0.03051758F, -0.08418274F, 0.09092712F, -0.6002197F, 1.1442871F, 0.54382324F, 0.1088562F, 0.07305908F, 0.03147888F, 0.00611877F, 
      0.00317383F, 3.9673E-4F, -1.526E-5F, -5.3406E-4F, 0.00338745F, -0.00886536F, 0.02978516F, -0.08970642F, 0.08068848F, -0.6282959F, 
      1.1422119F, 0.51560974F, 0.11657715F, 0.06752014F, 0.03173828F, 0.0052948F, 0.00308228F, 3.6621E-4F, -1.526E-5F, -5.7983E-4F, 
      0.00343323F, -0.00984192F, 0.02888489F, -0.09516907F, 0.06959534F, -0.6562195F, 1.1387634F, 0.48747253F, 0.12347412F, 0.06199646F, 
      0.03184509F, 0.00448608F, 0.00299072F, 3.2043E-4F, -1.526E-5F, -6.2561E-4F, 0.00346374F, -0.010849F, 0.02780151F, -0.10054016F, 
      0.05761719F, -0.6839142F, 1.1339264F, 0.45947266F, 0.12957764F, 0.05653381F, 0.03181457F, 0.00372315F, 0.00289917F, 2.8992E-4F, 
      -1.526E-5F, -6.8665E-4F, 0.003479F, -0.0118866F, 0.02653503F, -0.1058197F, 0.04478455F, -0.71131897F, 1.1277466F, 0.43165588F, 
      0.1348877F, 0.0511322F, 0.03166199F, 0.00300598F, 0.00279236F, 2.594E-4F, -1.526E-5F, -7.4768E-4F, 0.003479F, -0.01293945F, 
      0.02508545F, -0.11094666F, 0.03108215F, -0.7383728F, 1.120224F, 0.40408325F, 0.13945007F, 0.0458374F, 0.03138733F, 0.0023346F, 
      0.00268555F, 2.4414E-4F, -3.052E-5F, -8.0872E-4F, 0.00346374F, -0.01402283F, 0.02342224F, -0.11592102F, 0.01651001F, -0.7650299F, 
      1.1113739F, 0.37680054F, 0.14326477F, 0.04063415F, 0.03100586F, 0.00169373F, 0.00257873F, 2.1362E-4F, -3.052E-5F, -8.8501E-4F, 
      0.00341797F, -0.01512146F, 0.02157593F, -0.12069702F, 0.00106811F, -0.791214F, 1.1012115F, 0.34986877F, 0.1463623F, 0.03555298F, 
      0.03053284F, 0.00109863F, 0.00245666F, 1.9836E-4F, -3.052E-5F, -9.613E-4F, 0.00337219F, -0.01623535F, 0.01953125F, -0.1252594F, 
      -0.01522827F, -0.816864F, 1.0897827F, 0.32331848F, 0.1487732F, 0.03060913F, 0.02993774F, 5.4932E-4F, 0.00234985F, 1.6785E-4F, 
      -3.052E-5F, -0.0010376F, 0.00328064F, -0.01734924F, 0.01725769F, -0.12956238F, -0.03237915F, -0.84194946F, 1.0771179F, 0.2972107F, 
      0.15049744F, 0.02581787F, 0.02928162F, 3.052E-5F, 0.00224304F, 1.5259E-4F, -4.578E-5F, -0.00111389F, 0.00317383F, -0.01846313F, 
      0.01480103F, -0.1335907F, -0.050354F, -0.8663635F, 1.0632172F, 0.2715912F, 0.15159607F, 0.0211792F, 0.02853394F, -4.425E-4F, 
      0.00212097F, 1.3733E-4F, -4.578E-5F, -0.00120544F, 0.00305176F, -0.01957703F, 0.01211548F, -0.13729858F, -0.06916809F, -0.89009094F, 
      1.0481567F, 0.24650574F, 0.15206909F, 0.01670837F, 0.02772522F, -8.6975E-4F, 0.00201416F, 1.2207E-4F, -6.104E-5F, -0.001297F, 
      0.00288391F, -0.02069092F, 0.00923157F, -0.14067078F, -0.08877564F, -0.9130554F, 1.0319366F, 0.22198486F, 0.15196228F, 0.01242065F, 
      0.02684021F, -0.00126648F, 0.00190735F, 1.0681E-4F, -6.104E-5F, -0.00138855F, 0.00270081F, -0.02178955F, 0.00613403F, -0.14367676F, 
      -0.10916138F, -0.9351959F, 1.0146179F, 0.19805908F, 0.15130615F, 0.00831604F, 0.02590942F, -0.00161743F, 0.00178528F, 1.0681E-4F, 
      -7.629E-5F, -0.0014801F, 0.00248718F, -0.02285767F, 0.00282288F, -0.1462555F, -0.13031006F, -0.95648193F, 0.99624634F, 0.17478943F, 
      0.15011597F, 0.00439453F, 0.02493286F, -0.00193787F, 0.00169373F, 9.155E-5F, -0.00158691F, -0.02391052F, -0.14842224F, -0.9768524F, 
      0.15220642F, 6.8665E-4F, -0.00222778F, 7.629E-5F };
  
  public int kernel32(float[] paramArrayOffloat, int paramInt1, int paramInt2) {
    int k = this.j[paramInt2];
    this.j[paramInt2] = k + 15 & 0xF;
    float[] arrayOfFloat1 = this.k[paramInt2][k & 0x1];
    float[] arrayOfFloat2 = this.k[paramInt2][0x1 ^ k & 0x1];
    int m = k - (k & 0x1) & 0xF;
    int n = k - (0x1 ^ k & 0x1) & 0xF;
    do(arrayOfFloat2, n, arrayOfFloat1, m, paramArrayOffloat, paramInt1);
    int i = m;
    int j = m + 14 & 0xF;
    for (byte b1 = 1; b1 < 16; b1++) {
      float f1 = 0.0F;
      float f2 = 0.0F;
      for (byte b = 0; b < 4; b++) {
        float f3 = arrayOfFloat1[b1 * 16 + i];
        float f4 = arrayOfFloat1[b1 * 16 + i + 1];
        float f5 = arrayOfFloat1[b1 * 16 + j];
        float f6 = arrayOfFloat1[b1 * 16 + j + 1];
        float f7 = m[b * 2 + b1 * 16];
        float f8 = m[1 + b * 2 + b1 * 16];
        float f9 = m[14 - b * 2 + b1 * 16];
        float f10 = m[15 - b * 2 + b1 * 16];
        i += 2;
        i &= 0xF;
        j += 14;
        j &= 0xF;
        f1 += f3 * f7;
        f1 -= f4 * f8;
        f2 += f3 * f10;
        f2 += f4 * f9;
        f1 += f5 * f9;
        f1 -= f6 * f10;
        f2 += f5 * f8;
        f2 += f6 * f7;
      } 
      i ^= 0x8;
      j ^= 0x8;
      paramArrayOffloat[paramInt1 + b1] = f1;
      paramArrayOffloat[paramInt1 + 32 - b1] = f2;
    } 
    float f = 0.0F;
    byte b2;
    for (b2 = 0; b2 < 8; b2++) {
      float f1 = arrayOfFloat1[i];
      float f2 = arrayOfFloat1[i + 1];
      float f3 = m[2 * b2];
      float f4 = m[2 * b2 + 1];
      i += 2;
      i &= 0xF;
      f += f1 * f3 - f2 * f4;
    } 
    paramArrayOffloat[paramInt1 + 0] = f;
    f = 0.0F;
    for (b2 = 0; b2 < 4; b2++) {
      float f3 = m[2 * b2 + 256];
      float f4 = m[2 * b2 + 1 + 256];
      float f1 = arrayOfFloat1[257 + i];
      i += 2;
      i &= 0xF;
      float f2 = arrayOfFloat1[257 + i];
      i += 2;
      i &= 0xF;
      f -= f1 * f3;
      f -= f2 * f4;
    } 
    paramArrayOffloat[paramInt1 + 16] = f;
    return 0;
  }
  
  public int kernel16(float[] paramArrayOffloat, int paramInt1, int paramInt2) {
    int k = this.j[paramInt2];
    this.j[paramInt2] = k + 15 & 0xF;
    float[] arrayOfFloat1 = this.k[paramInt2][k & 0x1];
    float[] arrayOfFloat2 = this.k[paramInt2][0x1 ^ k & 0x1];
    int m = k - (k & 0x1) & 0xF;
    int n = k - (0x1 ^ k & 0x1) & 0xF;
    a(arrayOfFloat2, n, arrayOfFloat1, m, paramArrayOffloat, paramInt1);
    int i = m;
    int j = m + 14 & 0xF;
    for (byte b1 = 1; b1 < 8; b1++) {
      float f1 = 0.0F;
      float f2 = 0.0F;
      for (byte b = 0; b < 4; b++) {
        float f3 = arrayOfFloat1[b1 * 32 + i];
        float f4 = arrayOfFloat1[b1 * 32 + i + 1];
        float f5 = arrayOfFloat1[b1 * 32 + j];
        float f6 = arrayOfFloat1[b1 * 32 + j + 1];
        float f7 = m[b * 2 + b1 * 32];
        float f8 = m[1 + b * 2 + b1 * 32];
        float f9 = m[14 - b * 2 + b1 * 32];
        float f10 = m[15 - b * 2 + b1 * 32];
        i += 2;
        i &= 0xF;
        j += 14;
        j &= 0xF;
        f1 += f3 * f7;
        f1 -= f4 * f8;
        f2 += f3 * f10;
        f2 += f4 * f9;
        f1 += f5 * f9;
        f1 -= f6 * f10;
        f2 += f5 * f8;
        f2 += f6 * f7;
      } 
      i ^= 0x8;
      j ^= 0x8;
      paramArrayOffloat[paramInt1 + b1] = f1;
      paramArrayOffloat[paramInt1 + 16 - b1] = f2;
    } 
    float f = 0.0F;
    byte b2;
    for (b2 = 0; b2 < 8; b2++) {
      float f1 = arrayOfFloat1[i];
      float f2 = arrayOfFloat1[i + 1];
      float f3 = m[2 * b2];
      float f4 = m[2 * b2 + 1];
      i += 2;
      i &= 0xF;
      f += f1 * f3 - f2 * f4;
    } 
    paramArrayOffloat[paramInt1 + 0] = f;
    f = 0.0F;
    for (b2 = 0; b2 < 4; b2++) {
      float f3 = m[2 * b2 + 256];
      float f4 = m[2 * b2 + 1 + 256];
      float f1 = arrayOfFloat1[257 + i];
      i += 2;
      i &= 0xF;
      float f2 = arrayOfFloat1[257 + i];
      i += 2;
      i &= 0xF;
      f -= f1 * f3;
      f -= f2 * f4;
    } 
    paramArrayOffloat[paramInt1 + 8] = f;
    return 0;
  }
  
  public int kernel8(float[] paramArrayOffloat, int paramInt1, int paramInt2) {
    int k = this.j[paramInt2];
    this.j[paramInt2] = k + 15 & 0xF;
    float[] arrayOfFloat1 = this.k[paramInt2][k & 0x1];
    float[] arrayOfFloat2 = this.k[paramInt2][0x1 ^ k & 0x1];
    int m = k - (k & 0x1) & 0xF;
    int n = k - (0x1 ^ k & 0x1) & 0xF;
    if(arrayOfFloat2, n, arrayOfFloat1, m, paramArrayOffloat, paramInt1);
    int i = m;
    int j = m + 14 & 0xF;
    for (byte b1 = 1; b1 < 4; b1++) {
      float f1 = 0.0F;
      float f2 = 0.0F;
      for (byte b = 0; b < 4; b++) {
        float f3 = arrayOfFloat1[b1 * 64 + i];
        float f4 = arrayOfFloat1[b1 * 64 + i + 1];
        float f5 = arrayOfFloat1[b1 * 64 + j];
        float f6 = arrayOfFloat1[b1 * 64 + j + 1];
        float f7 = m[b * 2 + b1 * 64];
        float f8 = m[1 + b * 2 + b1 * 64];
        float f9 = m[14 - b * 2 + b1 * 64];
        float f10 = m[15 - b * 2 + b1 * 64];
        i += 2;
        i &= 0xF;
        j += 14;
        j &= 0xF;
        f1 += f3 * f7;
        f1 -= f4 * f8;
        f2 += f3 * f10;
        f2 += f4 * f9;
        f1 += f5 * f9;
        f1 -= f6 * f10;
        f2 += f5 * f8;
        f2 += f6 * f7;
      } 
      i ^= 0x8;
      j ^= 0x8;
      paramArrayOffloat[paramInt1 + b1] = f1;
      paramArrayOffloat[paramInt1 + 8 - b1] = f2;
    } 
    float f = 0.0F;
    byte b2;
    for (b2 = 0; b2 < 8; b2++) {
      float f1 = arrayOfFloat1[i];
      float f2 = arrayOfFloat1[i + 1];
      float f3 = m[2 * b2];
      float f4 = m[2 * b2 + 1];
      i += 2;
      i &= 0xF;
      f += f1 * f3 - f2 * f4;
    } 
    paramArrayOffloat[paramInt1 + 0] = f;
    f = 0.0F;
    for (b2 = 0; b2 < 4; b2++) {
      float f3 = m[2 * b2 + 256];
      float f4 = m[2 * b2 + 1 + 256];
      float f1 = arrayOfFloat1[257 + i];
      i += 2;
      i &= 0xF;
      float f2 = arrayOfFloat1[257 + i];
      i += 2;
      i &= 0xF;
      f -= f1 * f3;
      f -= f2 * f4;
    } 
    paramArrayOffloat[paramInt1 + 4] = f;
    return 0;
  }
  
  private static int do(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, float[] paramArrayOffloat3, int paramInt3) {
    float f1 = paramArrayOffloat3[paramInt3 + 0] + paramArrayOffloat3[paramInt3 + 31];
    float f2 = paramArrayOffloat3[paramInt3 + 1] + paramArrayOffloat3[paramInt3 + 30];
    float f17 = (paramArrayOffloat3[paramInt3 + 30] - paramArrayOffloat3[paramInt3 + 1]) * l[17];
    float f18 = (paramArrayOffloat3[paramInt3 + 31] - paramArrayOffloat3[paramInt3 + 0]) * l[16];
    float f15 = paramArrayOffloat3[paramInt3 + 14] + paramArrayOffloat3[paramInt3 + 17];
    float f16 = paramArrayOffloat3[paramInt3 + 15] + paramArrayOffloat3[paramInt3 + 16];
    float f31 = (paramArrayOffloat3[paramInt3 + 16] - paramArrayOffloat3[paramInt3 + 15]) * l[31];
    float f32 = (paramArrayOffloat3[paramInt3 + 17] - paramArrayOffloat3[paramInt3 + 14]) * l[30];
    float f33 = f1 - f16;
    float f34 = f2 - f15;
    f1 += f16;
    f16 = f33 * l[8];
    f2 += f15;
    f15 = f34 * l[9];
    float f7 = paramArrayOffloat3[paramInt3 + 6] + paramArrayOffloat3[paramInt3 + 25];
    float f8 = paramArrayOffloat3[paramInt3 + 7] + paramArrayOffloat3[paramInt3 + 24];
    float f23 = (paramArrayOffloat3[paramInt3 + 24] - paramArrayOffloat3[paramInt3 + 7]) * l[23];
    float f24 = (paramArrayOffloat3[paramInt3 + 25] - paramArrayOffloat3[paramInt3 + 6]) * l[22];
    float f9 = paramArrayOffloat3[paramInt3 + 8] + paramArrayOffloat3[paramInt3 + 23];
    float f10 = paramArrayOffloat3[paramInt3 + 9] + paramArrayOffloat3[paramInt3 + 22];
    float f25 = (paramArrayOffloat3[paramInt3 + 22] - paramArrayOffloat3[paramInt3 + 9]) * l[25];
    float f26 = (paramArrayOffloat3[paramInt3 + 23] - paramArrayOffloat3[paramInt3 + 8]) * l[24];
    f33 = f7 - f10;
    f34 = f8 - f9;
    f7 += f10;
    f10 = f33 * l[14];
    f8 += f9;
    f9 = f34 * l[15];
    f33 = f1 - f8;
    f34 = f2 - f7;
    f1 += f8;
    f8 = f33 * l[4];
    f2 += f7;
    f7 = f34 * l[5];
    float f3 = paramArrayOffloat3[paramInt3 + 2] + paramArrayOffloat3[paramInt3 + 29];
    float f4 = paramArrayOffloat3[paramInt3 + 3] + paramArrayOffloat3[paramInt3 + 28];
    float f19 = (paramArrayOffloat3[paramInt3 + 28] - paramArrayOffloat3[paramInt3 + 3]) * l[19];
    float f20 = (paramArrayOffloat3[paramInt3 + 29] - paramArrayOffloat3[paramInt3 + 2]) * l[18];
    float f13 = paramArrayOffloat3[paramInt3 + 12] + paramArrayOffloat3[paramInt3 + 19];
    float f14 = paramArrayOffloat3[paramInt3 + 13] + paramArrayOffloat3[paramInt3 + 18];
    float f29 = (paramArrayOffloat3[paramInt3 + 18] - paramArrayOffloat3[paramInt3 + 13]) * l[29];
    float f30 = (paramArrayOffloat3[paramInt3 + 19] - paramArrayOffloat3[paramInt3 + 12]) * l[28];
    f33 = f3 - f14;
    f34 = f4 - f13;
    f3 += f14;
    f14 = f33 * l[10];
    f4 += f13;
    f13 = f34 * l[11];
    float f5 = paramArrayOffloat3[paramInt3 + 4] + paramArrayOffloat3[paramInt3 + 27];
    float f6 = paramArrayOffloat3[paramInt3 + 5] + paramArrayOffloat3[paramInt3 + 26];
    float f21 = (paramArrayOffloat3[paramInt3 + 26] - paramArrayOffloat3[paramInt3 + 5]) * l[21];
    float f22 = (paramArrayOffloat3[paramInt3 + 27] - paramArrayOffloat3[paramInt3 + 4]) * l[20];
    float f11 = paramArrayOffloat3[paramInt3 + 10] + paramArrayOffloat3[paramInt3 + 21];
    float f12 = paramArrayOffloat3[paramInt3 + 11] + paramArrayOffloat3[paramInt3 + 20];
    float f27 = (paramArrayOffloat3[paramInt3 + 20] - paramArrayOffloat3[paramInt3 + 11]) * l[27];
    float f28 = (paramArrayOffloat3[paramInt3 + 21] - paramArrayOffloat3[paramInt3 + 10]) * l[26];
    f33 = f5 - f12;
    f34 = f6 - f11;
    f5 += f12;
    f12 = f33 * l[12];
    f6 += f11;
    f11 = f34 * l[13];
    f33 = f3 - f6;
    f34 = f4 - f5;
    f3 += f6;
    f6 = f33 * l[6];
    f4 += f5;
    f5 = f34 * l[7];
    f33 = f1 - f4;
    f34 = f2 - f3;
    f1 += f4;
    f4 = f33 * l[2];
    f2 += f3;
    f3 = f34 * l[3];
    f33 = f1 - f2;
    f34 = f4 - f3;
    f1 += f2;
    f2 = f33 * l[1];
    f3 += f4;
    f4 = f34 * l[1];
    f3 += f4;
    paramArrayOffloat1[paramInt1 + 0] = f2;
    paramArrayOffloat1[paramInt1 + 256] = f1;
    paramArrayOffloat1[paramInt1 + 128] = f3;
    paramArrayOffloat2[paramInt2 + 0] = f2;
    paramArrayOffloat2[paramInt2 + 128] = f4;
    f33 = f8 - f5;
    f34 = f7 - f6;
    f5 += f8;
    f8 = f33 * l[2];
    f6 += f7;
    f7 = f34 * l[3];
    f33 = f5 - f6;
    f34 = f8 - f7;
    f5 += f6;
    f6 = f33 * l[1];
    f7 += f8;
    f8 = f34 * l[1];
    f7 += f8;
    f5 += f7;
    f7 += f6;
    f6 += f8;
    paramArrayOffloat1[paramInt1 + 64] = f7;
    paramArrayOffloat1[paramInt1 + 192] = f5;
    paramArrayOffloat2[paramInt2 + 64] = f6;
    paramArrayOffloat2[paramInt2 + 192] = f8;
    f33 = f16 - f9;
    f34 = f15 - f10;
    f9 += f16;
    f16 = f33 * l[4];
    f10 += f15;
    f15 = f34 * l[5];
    f33 = f14 - f11;
    f34 = f13 - f12;
    f11 += f14;
    f14 = f33 * l[6];
    f12 += f13;
    f13 = f34 * l[7];
    f33 = f9 - f12;
    f34 = f10 - f11;
    f9 += f12;
    f12 = f33 * l[2];
    f10 += f11;
    f11 = f34 * l[3];
    f33 = f9 - f10;
    f34 = f12 - f11;
    f9 += f10;
    f10 = f33 * l[1];
    f11 += f12;
    f12 = f34 * l[1];
    f11 += f12;
    f33 = f16 - f13;
    f34 = f15 - f14;
    f13 += f16;
    f16 = f33 * l[2];
    f14 += f15;
    f15 = f34 * l[3];
    f33 = f13 - f14;
    f34 = f16 - f15;
    f13 += f14;
    f14 = f33 * l[1];
    f15 += f16;
    f16 = f34 * l[1];
    f15 += f16;
    f13 += f15;
    f15 += f14;
    f14 += f16;
    paramArrayOffloat1[paramInt1 + 32] = f15 + f10;
    paramArrayOffloat1[paramInt1 + 96] = f11 + f15;
    paramArrayOffloat1[paramInt1 + 160] = f13 + f11;
    paramArrayOffloat1[paramInt1 + 224] = f9 + f13;
    paramArrayOffloat2[paramInt2 + 32] = f10 + f14;
    paramArrayOffloat2[paramInt2 + 96] = f14 + f12;
    paramArrayOffloat2[paramInt2 + 160] = f12 + f16;
    paramArrayOffloat2[paramInt2 + 224] = f16;
    f1 = f31 + f18;
    f2 = f32 + f17;
    f15 = f17 - f32;
    f16 = f18 - f31;
    f15 *= l[9];
    f16 *= l[8];
    f7 = f25 + f24;
    f8 = f26 + f23;
    f9 = f23 - f26;
    f10 = f24 - f25;
    f9 *= l[15];
    f10 *= l[14];
    f33 = f1 - f8;
    f34 = f2 - f7;
    f1 += f8;
    f8 = f33 * l[4];
    f2 += f7;
    f7 = f34 * l[5];
    f3 = f29 + f20;
    f4 = f30 + f19;
    f13 = f19 - f30;
    f14 = f20 - f29;
    f13 *= l[11];
    f14 *= l[10];
    f5 = f27 + f22;
    f6 = f28 + f21;
    f11 = f21 - f28;
    f12 = f22 - f27;
    f11 *= l[13];
    f12 *= l[12];
    f33 = f3 - f6;
    f34 = f4 - f5;
    f3 += f6;
    f6 = f33 * l[6];
    f4 += f5;
    f5 = f34 * l[7];
    f33 = f1 - f4;
    f34 = f2 - f3;
    f1 += f4;
    f4 = f33 * l[2];
    f2 += f3;
    f3 = f34 * l[3];
    f33 = f1 - f2;
    f34 = f4 - f3;
    f1 += f2;
    f2 = f33 * l[1];
    f3 += f4;
    f4 = f34 * l[1];
    f3 += f4;
    f33 = f8 - f5;
    f34 = f7 - f6;
    f5 += f8;
    f8 = f33 * l[2];
    f6 += f7;
    f7 = f34 * l[3];
    f33 = f5 - f6;
    f34 = f8 - f7;
    f5 += f6;
    f6 = f33 * l[1];
    f7 += f8;
    f8 = f34 * l[1];
    f7 += f8;
    f5 += f7;
    f7 += f6;
    f6 += f8;
    f33 = f16 - f9;
    f34 = f15 - f10;
    f9 += f16;
    f16 = f33 * l[4];
    f10 += f15;
    f15 = f34 * l[5];
    f33 = f14 - f11;
    f34 = f13 - f12;
    f11 += f14;
    f14 = f33 * l[6];
    f12 += f13;
    f13 = f34 * l[7];
    f33 = f9 - f12;
    f34 = f10 - f11;
    f9 += f12;
    f12 = f33 * l[2];
    f10 += f11;
    f11 = f34 * l[3];
    f33 = f9 - f10;
    f34 = f12 - f11;
    f9 += f10;
    f10 = f33 * l[1];
    f11 += f12;
    f12 = f34 * l[1];
    f11 += f12;
    f33 = f16 - f13;
    f34 = f15 - f14;
    f13 += f16;
    f16 = f33 * l[2];
    f14 += f15;
    f15 = f34 * l[3];
    f33 = f13 - f14;
    f34 = f16 - f15;
    f13 += f14;
    f14 = f33 * l[1];
    f15 += f16;
    f16 = f34 * l[1];
    f15 += f16;
    f13 += f15;
    f15 += f14;
    f14 += f16;
    paramArrayOffloat1[paramInt1 + 16] = f2 + f15 + f10;
    paramArrayOffloat1[paramInt1 + 48] = f7 + f15 + f10;
    paramArrayOffloat1[paramInt1 + 80] = f7 + f11 + f15;
    paramArrayOffloat1[paramInt1 + 112] = f3 + f11 + f15;
    paramArrayOffloat1[paramInt1 + 144] = f3 + f13 + f11;
    paramArrayOffloat1[paramInt1 + 176] = f5 + f13 + f11;
    paramArrayOffloat1[paramInt1 + 208] = f5 + f9 + f13;
    paramArrayOffloat1[paramInt1 + 240] = f1 + f9 + f13;
    paramArrayOffloat2[paramInt2 + 16] = f2 + f10 + f14;
    paramArrayOffloat2[paramInt2 + 48] = f6 + f10 + f14;
    paramArrayOffloat2[paramInt2 + 80] = f6 + f14 + f12;
    paramArrayOffloat2[paramInt2 + 112] = f4 + f14 + f12;
    paramArrayOffloat2[paramInt2 + 144] = f4 + f12 + f16;
    paramArrayOffloat2[paramInt2 + 176] = f8 + f12 + f16;
    paramArrayOffloat2[paramInt2 + 208] = f8 + f16;
    paramArrayOffloat2[paramInt2 + 240] = f16;
    return 0;
  }
  
  private static int a(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, float[] paramArrayOffloat3, int paramInt3) {
    float f1 = paramArrayOffloat3[paramInt3 + 0] + paramArrayOffloat3[paramInt3 + 1 + 14];
    float f2 = paramArrayOffloat3[paramInt3 + 1] + paramArrayOffloat3[paramInt3 + 0 + 14];
    float f15 = (paramArrayOffloat3[paramInt3 + 1] - paramArrayOffloat3[paramInt3 + 0 + 14]) * l[9];
    float f16 = (paramArrayOffloat3[paramInt3 + 0] - paramArrayOffloat3[paramInt3 + 1 + 14]) * l[8];
    float f3 = paramArrayOffloat3[paramInt3 + 0 + 2] + paramArrayOffloat3[paramInt3 + 1 + 12];
    float f4 = paramArrayOffloat3[paramInt3 + 1 + 2] + paramArrayOffloat3[paramInt3 + 0 + 12];
    float f13 = (paramArrayOffloat3[paramInt3 + 1 + 2] - paramArrayOffloat3[paramInt3 + 0 + 12]) * l[11];
    float f14 = (paramArrayOffloat3[paramInt3 + 0 + 2] - paramArrayOffloat3[paramInt3 + 1 + 12]) * l[10];
    float f5 = paramArrayOffloat3[paramInt3 + 0 + 4] + paramArrayOffloat3[paramInt3 + 1 + 10];
    float f6 = paramArrayOffloat3[paramInt3 + 1 + 4] + paramArrayOffloat3[paramInt3 + 0 + 10];
    float f11 = (paramArrayOffloat3[paramInt3 + 1 + 4] - paramArrayOffloat3[paramInt3 + 0 + 10]) * l[13];
    float f12 = (paramArrayOffloat3[paramInt3 + 0 + 4] - paramArrayOffloat3[paramInt3 + 1 + 10]) * l[12];
    float f7 = paramArrayOffloat3[paramInt3 + 0 + 6] + paramArrayOffloat3[paramInt3 + 1 + 8];
    float f8 = paramArrayOffloat3[paramInt3 + 1 + 6] + paramArrayOffloat3[paramInt3 + 0 + 8];
    float f9 = (paramArrayOffloat3[paramInt3 + 1 + 6] - paramArrayOffloat3[paramInt3 + 0 + 8]) * l[15];
    float f10 = (paramArrayOffloat3[paramInt3 + 0 + 6] - paramArrayOffloat3[paramInt3 + 1 + 8]) * l[14];
    float f17 = f1 - f8;
    float f18 = f2 - f7;
    f1 += f8;
    f8 = f17 * l[4];
    f2 += f7;
    f7 = f18 * l[5];
    f17 = f3 - f6;
    f18 = f4 - f5;
    f3 += f6;
    f6 = f17 * l[6];
    f4 += f5;
    f5 = f18 * l[7];
    f17 = f1 - f4;
    f18 = f2 - f3;
    f1 += f4;
    f4 = f17 * l[2];
    f2 += f3;
    f3 = f18 * l[3];
    f17 = f8 - f5;
    f18 = f7 - f6;
    f5 += f8;
    f8 = f17 * l[2];
    f6 += f7;
    f7 = f18 * l[3];
    f17 = f1 - f2;
    f18 = f4 - f3;
    f1 += f2;
    f2 = f17 * l[1];
    f3 += f4;
    f4 = f18 * l[1];
    f3 += f4;
    paramArrayOffloat1[paramInt1 + 0] = f2;
    paramArrayOffloat1[paramInt1 + 256] = f1;
    paramArrayOffloat1[paramInt1 + 128] = f3;
    paramArrayOffloat2[paramInt2 + 0] = f2;
    paramArrayOffloat2[paramInt2 + 128] = f4;
    f17 = f5 - f6;
    f18 = f8 - f7;
    f5 += f6;
    f6 = f17 * l[1];
    f7 += f8;
    f8 = f18 * l[1];
    f7 += f8;
    f5 += f7;
    f7 += f6;
    f6 += f8;
    paramArrayOffloat1[paramInt1 + 64] = f7;
    paramArrayOffloat1[paramInt1 + 192] = f5;
    paramArrayOffloat2[paramInt2 + 64] = f6;
    paramArrayOffloat2[paramInt2 + 192] = f8;
    f17 = f16 - f9;
    f18 = f15 - f10;
    f9 += f16;
    f16 = f17 * l[4];
    f10 += f15;
    f15 = f18 * l[5];
    f17 = f14 - f11;
    f18 = f13 - f12;
    f11 += f14;
    f14 = f17 * l[6];
    f12 += f13;
    f13 = f18 * l[7];
    f17 = f9 - f12;
    f18 = f10 - f11;
    f9 += f12;
    f12 = f17 * l[2];
    f10 += f11;
    f11 = f18 * l[3];
    f17 = f16 - f13;
    f18 = f15 - f14;
    f13 += f16;
    f16 = f17 * l[2];
    f14 += f15;
    f15 = f18 * l[3];
    f17 = f9 - f10;
    f18 = f12 - f11;
    f9 += f10;
    f10 = f17 * l[1];
    f11 += f12;
    f12 = f18 * l[1];
    f11 += f12;
    f17 = f13 - f14;
    f18 = f16 - f15;
    f13 += f14;
    f14 = f17 * l[1];
    f15 += f16;
    f16 = f18 * l[1];
    f15 += f16;
    f13 += f15;
    f15 += f14;
    f14 += f16;
    paramArrayOffloat1[paramInt1 + 32] = f15 + f10;
    paramArrayOffloat1[paramInt1 + 96] = f11 + f15;
    paramArrayOffloat1[paramInt1 + 160] = f13 + f11;
    paramArrayOffloat1[paramInt1 + 224] = f9 + f13;
    paramArrayOffloat2[paramInt2 + 32] = f10 + f14;
    paramArrayOffloat2[paramInt2 + 96] = f14 + f12;
    paramArrayOffloat2[paramInt2 + 160] = f12 + f16;
    paramArrayOffloat2[paramInt2 + 224] = f16;
    return 0;
  }
  
  private static int if(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, float[] paramArrayOffloat3, int paramInt3) {
    float f1 = paramArrayOffloat3[paramInt3 + 0] + paramArrayOffloat3[paramInt3 + 1 + 6];
    float f2 = paramArrayOffloat3[paramInt3 + 1] + paramArrayOffloat3[paramInt3 + 0 + 6];
    float f7 = (paramArrayOffloat3[paramInt3 + 1] - paramArrayOffloat3[paramInt3 + 0 + 6]) * l[5];
    float f8 = (paramArrayOffloat3[paramInt3 + 0] - paramArrayOffloat3[paramInt3 + 1 + 6]) * l[4];
    float f3 = paramArrayOffloat3[paramInt3 + 0 + 2] + paramArrayOffloat3[paramInt3 + 1 + 4];
    float f4 = paramArrayOffloat3[paramInt3 + 1 + 2] + paramArrayOffloat3[paramInt3 + 0 + 4];
    float f5 = (paramArrayOffloat3[paramInt3 + 1 + 2] - paramArrayOffloat3[paramInt3 + 0 + 4]) * l[7];
    float f6 = (paramArrayOffloat3[paramInt3 + 0 + 2] - paramArrayOffloat3[paramInt3 + 1 + 4]) * l[6];
    float f9 = f1 - f4;
    float f10 = f2 - f3;
    f1 += f4;
    f4 = f9 * l[2];
    f2 += f3;
    f3 = f10 * l[3];
    f9 = f8 - f5;
    f10 = f7 - f6;
    f5 += f8;
    f8 = f9 * l[2];
    f6 += f7;
    f7 = f10 * l[3];
    f9 = f1 - f2;
    f10 = f4 - f3;
    f1 += f2;
    f2 = f9 * l[1];
    f3 += f4;
    f4 = f10 * l[1];
    f3 += f4;
    paramArrayOffloat1[paramInt1 + 0] = f2;
    paramArrayOffloat1[paramInt1 + 256] = f1;
    paramArrayOffloat1[paramInt1 + 128] = f3;
    paramArrayOffloat2[paramInt2 + 0] = f2;
    paramArrayOffloat2[paramInt2 + 128] = f4;
    f9 = f5 - f6;
    f10 = f8 - f7;
    f5 += f6;
    f6 = f9 * l[1];
    f7 += f8;
    f8 = f10 * l[1];
    f7 += f8;
    f5 += f7;
    f7 += f6;
    f6 += f8;
    paramArrayOffloat1[paramInt1 + 64] = f7;
    paramArrayOffloat1[paramInt1 + 192] = f5;
    paramArrayOffloat2[paramInt2 + 64] = f6;
    paramArrayOffloat2[paramInt2 + 192] = f8;
    return 0;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\codecLib\mpa\PolySynthesis.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */