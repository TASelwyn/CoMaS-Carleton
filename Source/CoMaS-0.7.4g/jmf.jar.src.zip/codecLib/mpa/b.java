package codecLib.mpa;

class b {
  private int int;
  
  private int for;
  
  private byte[] do;
  
  private int if;
  
  private int new;
  
  private int a;
  
  byte[] else() {
    return this.do;
  }
  
  int char() {
    return this.new;
  }
  
  int try() {
    return this.a;
  }
  
  void do(int paramInt) {
    this.for -= paramInt;
    this.int <<= paramInt;
    if (this.for <= 16) {
      this.int |= (this.do[this.if++] & 0xFF) << 24 - this.for;
      this.int |= (this.do[this.if++] & 0xFF) << 16 - this.for;
      this.for += 16;
    } 
  }
  
  void case() {
    this.int = ((this.do[this.if - 4] & 0xFF) << 24 | (this.do[this.if - 3] & 0xFF) << 16 | (this.do[this.if - 2] & 0xFF) << 8 | this.do[this.if - 1] & 0xFF) << 32 - this.for;
  }
  
  int for(int paramInt) {
    return this.int >>> 32 - paramInt;
  }
  
  void int() {
    do(this.for & 0x7);
  }
  
  int if() {
    return (this.if - this.new << 3) - this.for;
  }
  
  int goto() {
    return (this.a - this.if << 3) + this.for;
  }
  
  int byte() {
    return this.if - (this.for >> 3);
  }
  
  int for() {
    return this.if - (this.for + 7 >> 3);
  }
  
  int new() {
    return 32 - this.for & 0x7;
  }
  
  void a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    this.do = paramArrayOfbyte;
    this.if = paramInt1;
    this.new = paramInt1;
    this.a = paramInt1 + paramInt2;
    this.for = 0;
    this.int = 0;
    do(0);
    do(0);
  }
  
  int if(int paramInt) {
    int i = this.int >>> 32 - paramInt;
    this.for -= paramInt;
    this.int <<= paramInt;
    if (this.for <= 16) {
      this.int |= (this.do[this.if++] & 0xFF) << 24 - this.for;
      this.int |= (this.do[this.if++] & 0xFF) << 16 - this.for;
      this.for += 16;
    } 
    return i;
  }
  
  static void a(b paramb1, b paramb2) {
    paramb1.int = paramb2.int;
    paramb1.for = paramb2.for;
    paramb1.do = paramb2.do;
    paramb1.if = paramb2.if;
    paramb1.new = paramb2.new;
    paramb1.a = paramb2.a;
  }
  
  int do() {
    int i = this.int;
    this.for--;
    this.int <<= 1;
    if (this.for <= 16) {
      this.int |= (this.do[this.if++] & 0xFF) << 24 - this.for;
      this.int |= (this.do[this.if++] & 0xFF) << 16 - this.for;
      this.for += 16;
    } 
    return i;
  }
  
  int a() {
    int i = this.int;
    this.int <<= 16;
    this.int |= (this.do[this.if++] & 0xFF) << 40 - this.for;
    this.int |= (this.do[this.if++] & 0xFF) << 32 - this.for;
    return i;
  }
  
  void a(int paramInt) {
    paramInt += 32 - this.for;
    this.if -= 4;
    this.if += paramInt >> 3;
    paramInt &= 0x7;
    this.for = 0;
    this.int = 0;
    do(0);
    do(paramInt);
  }
  
  static void a(byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    if (paramInt5 <= 0)
      return; 
    int i = paramInt5;
    paramInt1 += paramInt3 >> 3;
    paramInt2 += paramInt4 >> 3;
    int j = paramInt3 & 0x7;
    int k = paramInt4 & 0x7;
    if (j != 0) {
      int m = (paramArrayOfbyte2[paramInt2] & 0xFF) << k | (paramArrayOfbyte2[paramInt2 + 1] & 0xFF) >> 8 - k;
      m = (m & 0xFF) >> j | (paramArrayOfbyte1[paramInt1] & 0xFF) >> 8 - j << 8 - j;
      paramArrayOfbyte1[paramInt1] = (byte)m;
      i -= 8 - j;
      paramInt1++;
      if (k < j) {
        k += 8 - j;
      } else {
        k = k + 8 - j & 0x7;
        paramInt2++;
      } 
    } 
    if (k == 0) {
      for (byte b1 = 0; b1 <= i >> 3; b1++)
        paramArrayOfbyte1[paramInt1 + b1] = paramArrayOfbyte2[paramInt2 + b1]; 
    } else {
      for (byte b1 = 0; b1 <= i >> 3; b1++)
        paramArrayOfbyte1[paramInt1 + b1] = (byte)((paramArrayOfbyte2[paramInt2 + b1] & 0xFF) << k | (paramArrayOfbyte2[paramInt2 + b1 + 1] & 0xFF) >> 8 - k); 
    } 
  }
  
  void a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt2 == 0) {
      for (byte b1 = 0; b1 < paramInt3; b1++)
        paramArrayOfbyte[paramInt1 + b1] = 0; 
    } else {
      for (byte b1 = 0; b1 < paramInt3; b1++)
        paramArrayOfbyte[paramInt1 + b1] = (byte)if(paramInt2); 
    } 
  }
  
  void a(short[] paramArrayOfshort, int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt2 == 0) {
      for (byte b1 = 0; b1 < paramInt3; b1++)
        paramArrayOfshort[paramInt1 + b1] = 0; 
    } else {
      for (byte b1 = 0; b1 < paramInt3; b1++)
        paramArrayOfshort[paramInt1 + b1] = (short)if(paramInt2); 
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\jmf.jar!\codecLib\mpa\b.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */