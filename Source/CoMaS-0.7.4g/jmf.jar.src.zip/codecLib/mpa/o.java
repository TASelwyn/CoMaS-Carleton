package codecLib.mpa;

class o extends Defines implements Tables {
  protected m F;
  
  protected c D;
  
  protected PolySynthesis C = new PolySynthesis();
  
  private byte[] B = new byte[12];
  
  private int[] E = new int[12];
  
  o(m paramm, c paramc) {
    this.F = paramm;
    this.D = paramc;
  }
  
  protected void a(int paramInt) {
    int j = this.F.bn.k;
    j += this.D.ao.cK;
    int i = 0;
    this.E[i] = 4;
    this.B[i++] = 0;
    if (this.F.bn.k == 2) {
      this.E[i] = 8;
      this.B[i++] = 1;
    } 
    if (this.D.ao.cy != 0) {
      this.E[i] = 16;
      this.B[i++] = 2;
    } 
    if (this.D.ao.cL != 0) {
      this.E[i] = 32;
      this.B[i++] = 3;
      if (this.D.ao.cL == 2) {
        this.E[i] = 64;
        this.B[i++] = 4;
      } 
    } else if (this.D.ao.cD != 0) {
      this.E[i] = 32768;
      this.B[i++] = 3;
      this.E[i] = 32768;
      this.B[i++] = 4;
    } 
    int k;
    for (k = 0; k < this.D.ao.cF; k++) {
      this.E[i] = 256 << k;
      this.B[i++] = (byte)(5 + k);
    } 
    if (paramInt == 2) {
      for (i = 0; i < j; i++) {
        if ((this.D.ao.cz & 0x3) == 0 || (this.E[i] & this.D.ao.cz) != 0) {
          float[] arrayOfFloat = this.F.bm[this.B[i]];
          int n = this.F.bo[this.B[i]];
          for (k = 0; k < 3; k++) {
            for (byte b = 0; b < 12; b++) {
              int i1 = 32 * (12 * k + b);
              System.arraycopy(this.F.bu[k][b][i], 0, arrayOfFloat, (i1 >> this.F.bz) + n, 32);
              switch (this.F.bz) {
                case 0:
                  this.C.kernel32(arrayOfFloat, (i1 >> this.F.bz) + n, i);
                  break;
                case 1:
                  this.C.kernel16(arrayOfFloat, (i1 >> this.F.bz) + n, i);
                  break;
                case 2:
                  this.C.kernel8(arrayOfFloat, (i1 >> this.F.bz) + n, i);
                  break;
              } 
            } 
          } 
        } 
      } 
      if (this.D.aB != 0) {
        k = 36 >> this.D.ac;
        int n = 1152 >> this.D.ac;
        for (i = j; i < j + this.D.ao.cF; i++) {
          if ((this.E[i] & this.D.ao.cz) != 0) {
            float[] arrayOfFloat = this.F.bm[this.B[i]];
            int i1 = this.F.bo[this.B[i]];
            for (byte b = 0; b < k; b++) {
              System.arraycopy(this.F.bu[b / 12][b % 12][i], 0, arrayOfFloat, (b * 32 >> this.F.bz) + i1, 32);
              switch (this.F.bz) {
                case 0:
                  this.C.kernel32(arrayOfFloat, (b * 32 >> this.F.bz) + i1, i);
                  break;
                case 1:
                  this.C.kernel16(arrayOfFloat, (b * 32 >> this.F.bz) + i1, i);
                  break;
                case 2:
                  this.C.kernel8(arrayOfFloat, (b * 32 >> this.F.bz) + i1, i);
                  break;
              } 
            } 
          } 
        } 
      } 
    } else {
      for (i = 0; i < j; i++) {
        float[] arrayOfFloat = this.F.bm[i];
        int n = this.F.bo[i];
        for (byte b = 0; b < 12; b++) {
          System.arraycopy(this.F.bu[this.F.bk][b][i], 0, arrayOfFloat, (b * 32 >> this.F.bz) + n, 32);
          switch (this.F.bz) {
            case 0:
              this.C.kernel32(arrayOfFloat, (b * 32 >> this.F.bz) + n, i);
              break;
            case 1:
              this.C.kernel16(arrayOfFloat, (b * 32 >> this.F.bz) + n, i);
              break;
            case 2:
              this.C.kernel8(arrayOfFloat, (b * 32 >> this.F.bz) + n, i);
              break;
          } 
        } 
      } 
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\codecLib\mpa\o.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */