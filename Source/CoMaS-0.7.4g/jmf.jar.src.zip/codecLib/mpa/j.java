package codecLib.mpa;

class j extends o {
  int G;
  
  int J;
  
  int H;
  
  byte[] I = new byte[64];
  
  private byte[] K = new byte[3776];
  
  j(m paramm, c paramc) {
    super(paramm, paramc);
  }
  
  void a() throws MPADException {
    boolean bool;
    b b = new b();
    int m = 0;
    int i = this.F.bn.k;
    int k = this.F.bn.try >> i - 1;
    if (this.F.bn.long == 0) {
      bool = true;
    } else if (k <= 48) {
      if (this.F.bn.i == 2) {
        bool = true;
      } else {
        bool = true;
      } 
    } else if (k <= 80) {
      bool = false;
    } else if (k <= 192) {
      if (this.F.bn.i == 1) {
        bool = false;
      } else {
        bool = true;
      } 
    } else {
      throw new MPADException(-1);
    } 
    this.F.bA = Tables.t_bal[bool];
    this.J = (Tables.t_bal[bool]).int;
    this.G = this.J;
    if (this.F.bn.goto == 1)
      this.G = (this.F.bn.else + 1) * 4; 
    int n = this.F.bv.if();
    if (this.F.bn.c == 0)
      b.a(b, this.F.bv); 
    do(i);
    for(i);
    if (this.F.bv.goto() < 0)
      throw new MPADException(-3); 
    if (this.F.br == 0 && this.F.bn.c == 0) {
      int i2 = this.F.bv.if() - n;
      m = this.F.bq.if(b, this.F.bn, i2);
      if (m != 0)
        throw new MPADException(-2); 
    } 
    if(i);
    if();
    int i1 = this.F.bn.do - this.F.bv.if() - n - this.F.bn.if;
    if (i1 < 0)
      throw new MPADException(-1); 
    if (this.F.bv.goto() < 0)
      throw new MPADException(-3); 
    if ((this.D.ao.cz & 0x3) == 0) {
      this.D.ao.cE = 0;
    } else if (i1 > 15) {
      if (i1 > this.F.bv.goto())
        throw new MPADException(-8); 
      b.a(this.K, 0, this.F.bv.else(), this.F.bv.for(), 0, this.F.bv.new(), i1);
      this.F.bv.a(this.K, 0, i1 + 7 >> 3);
      this.D.ao.cE = this.D.int(i1);
    } else {
      this.D.ao.cE = -1;
    } 
    if ((this.D.ao.cz & 0x3) != 3)
      a(2); 
  }
  
  private void do(int paramInt) {
    b b1 = this.F.bv;
    f f = this.F.bA;
    int i = this.G;
    int k = this.J;
    byte[][] arrayOfByte = this.F.bs[0];
    if (i > k)
      i = k; 
    if (paramInt == 1)
      i = 0; 
    byte b;
    for (b = 0; b < i; b++) {
      arrayOfByte[0][b] = (byte)b1.if(f.a[b]);
      arrayOfByte[1][b] = (byte)b1.if(f.a[b]);
    } 
    while (b < k) {
      arrayOfByte[0][b] = (byte)b1.if(f.a[b]);
      arrayOfByte[1][b] = (byte)b1.if(f.a[b]);
      b++;
    } 
  }
  
  private void for(int paramInt) {
    b b1 = this.F.bv;
    byte[][] arrayOfByte1 = this.F.bs[0];
    byte[] arrayOfByte = this.I;
    byte b = 0;
    if (paramInt == 1) {
      for (byte b2 = 0; b2 < this.J; b2++) {
        if (arrayOfByte1[0][b2] != 0) {
          arrayOfByte[b++] = (byte)b1.if(2);
        } else {
          arrayOfByte[b++] = 4;
        } 
      } 
    } else {
      for (byte b2 = 0; b2 < this.J; b2++) {
        if (arrayOfByte1[0][b2] != 0) {
          arrayOfByte[b++] = (byte)b1.if(2);
        } else {
          arrayOfByte[b++] = 4;
        } 
        if (arrayOfByte1[1][b2] != 0) {
          arrayOfByte[b++] = (byte)b1.if(2);
        } else {
          arrayOfByte[b++] = 4;
        } 
      } 
    } 
  }
  
  private void if(int paramInt) {
    byte[][][] arrayOfByte1 = this.F.bp;
    b b = this.F.bv;
    byte[] arrayOfByte = this.I;
    byte b2 = 0;
    for (byte b1 = 0; b1 < this.J; b1++) {
      for (byte b3 = 0; b3 < paramInt; b3++) {
        switch (arrayOfByte[b2++]) {
          case 0:
            arrayOfByte1[0][b3][b1] = (byte)b.if(6);
            arrayOfByte1[1][b3][b1] = (byte)b.if(6);
            arrayOfByte1[2][b3][b1] = (byte)b.if(6);
            break;
          case 1:
            arrayOfByte1[0][b3][b1] = (byte)b.if(6);
            arrayOfByte1[1][b3][b1] = (byte)b.if(6);
            arrayOfByte1[2][b3][b1] = (byte)b.if(6);
            break;
          case 2:
            arrayOfByte1[0][b3][b1] = (byte)b.if(6);
            arrayOfByte1[1][b3][b1] = (byte)b.if(6);
            arrayOfByte1[2][b3][b1] = (byte)b.if(6);
            break;
          case 3:
            arrayOfByte1[0][b3][b1] = (byte)b.if(6);
            arrayOfByte1[1][b3][b1] = (byte)b.if(6);
            arrayOfByte1[2][b3][b1] = (byte)b.if(6);
            break;
        } 
      } 
    } 
  }
  
  private void if() {
    byte[][] arrayOfByte = this.F.bs[0];
    byte[][][] arrayOfByte1 = this.F.bp;
    f f = this.F.bA;
    int i = this.F.bn.k;
    int k = this.G;
    int m = this.J;
    if (k > m)
      k = m; 
    if (i == 1)
      k = 0; 
    for (byte b = 0; b < 12; b++) {
      int n = b / 4;
      int i1 = 3 * (b - 4 * n);
      float[][][] arrayOfFloat = this.F.bu[n];
      byte b1;
      for (b1 = 0; b1 < k; b1++) {
        for (byte b2 = 0; b2 < 2; b2++) {
          if (arrayOfByte[b2][b1] != 0) {
            int i3;
            int i4;
            int i5;
            byte b4 = f.if[b1][arrayOfByte[b2][b1]];
            int i2 = Tables.t_alloc[b4];
            byte b3 = f.for[b1][arrayOfByte[b2][b1]];
            if (b3 > 0) {
              i3 = this.F.bv.if(b3);
              i4 = this.F.bv.if(b3);
              i5 = this.F.bv.if(b3);
            } else {
              int i7 = this.F.bv.if(-b3);
              int i6 = -b3 & 0x6;
              i6 /= 2;
              byte[] arrayOfByte2 = this.F.bw[i6];
              int i8 = i7 * 3;
              i3 = arrayOfByte2[i8];
              i4 = arrayOfByte2[i8 + 1];
              i5 = arrayOfByte2[i8 + 2];
            } 
            float f5 = Tables.t_d[b4];
            float f4 = Tables.t_c[b4];
            float f6 = Tables.t_finv_alloc[b4];
            float f7 = Tables.t_multiple[arrayOfByte1[b >> 2][b2][b1]];
            float f3 = f5;
            float f2 = f3;
            float f1 = f2;
            if ((i3 & i2) == 0)
              f1 -= f4; 
            if ((i4 & i2) == 0)
              f2 -= f4; 
            if ((i5 & i2) == 0)
              f3 -= f4; 
            f1 += (i3 & i2 - 1) * f6;
            f2 += (i4 & i2 - 1) * f6;
            f3 += (i5 & i2 - 1) * f6;
            f1 *= f7;
            f2 *= f7;
            f3 *= f7;
            arrayOfFloat[i1][b2][b1] = f1;
            arrayOfFloat[i1 + 1][b2][b1] = f2;
            arrayOfFloat[i1 + 2][b2][b1] = f3;
          } else {
            arrayOfFloat[i1][b2][b1] = 0.0F;
            arrayOfFloat[i1 + 1][b2][b1] = 0.0F;
            arrayOfFloat[i1 + 2][b2][b1] = 0.0F;
          } 
        } 
      } 
      while (b1 < m) {
        if (arrayOfByte[0][b1] != 0) {
          int i3;
          int i4;
          int i5;
          byte b3 = f.if[b1][arrayOfByte[0][b1]];
          int i2 = Tables.t_alloc[b3];
          byte b2 = f.for[b1][arrayOfByte[0][b1]];
          if (b2 > 0) {
            i3 = this.F.bv.if(b2);
            i4 = this.F.bv.if(b2);
            i5 = this.F.bv.if(b2);
          } else {
            int i7 = this.F.bv.if(-b2);
            int i6 = -b2 & 0x6;
            i6 /= 2;
            byte[] arrayOfByte2 = this.F.bw[i6];
            int i8 = i7 * 3;
            i3 = arrayOfByte2[i8];
            i4 = arrayOfByte2[i8 + 1];
            i5 = arrayOfByte2[i8 + 2];
          } 
          float f5 = Tables.t_d[b3];
          float f4 = Tables.t_c[b3];
          float f6 = Tables.t_finv_alloc[b3];
          float f7 = Tables.t_multiple[arrayOfByte1[b >> 2][0][b1]];
          float f3 = f5;
          float f2 = f3;
          float f1 = f2;
          if ((i3 & i2) == 0)
            f1 -= f4; 
          if ((i4 & i2) == 0)
            f2 -= f4; 
          if ((i5 & i2) == 0)
            f3 -= f4; 
          f1 += (i3 & i2 - 1) * f6;
          f2 += (i4 & i2 - 1) * f6;
          f3 += (i5 & i2 - 1) * f6;
          f1 *= f7;
          f2 *= f7;
          f3 *= f7;
          arrayOfFloat[i1][0][b1] = f1;
          arrayOfFloat[i1][1][b1] = f1;
          arrayOfFloat[i1 + 1][0][b1] = f2;
          arrayOfFloat[i1 + 1][1][b1] = f2;
          arrayOfFloat[i1 + 2][0][b1] = f3;
          arrayOfFloat[i1 + 2][1][b1] = f3;
        } else {
          arrayOfFloat[i1][0][b1] = 0.0F;
          arrayOfFloat[i1][1][b1] = 0.0F;
          arrayOfFloat[i1 + 1][0][b1] = 0.0F;
          arrayOfFloat[i1 + 1][1][b1] = 0.0F;
          arrayOfFloat[i1 + 2][0][b1] = 0.0F;
          arrayOfFloat[i1 + 2][1][b1] = 0.0F;
        } 
        b1++;
      } 
      while (b1 < 32) {
        arrayOfFloat[i1][0][b1] = 0.0F;
        arrayOfFloat[i1][1][b1] = 0.0F;
        arrayOfFloat[i1 + 1][0][b1] = 0.0F;
        arrayOfFloat[i1 + 1][1][b1] = 0.0F;
        arrayOfFloat[i1 + 2][0][b1] = 0.0F;
        arrayOfFloat[i1 + 2][1][b1] = 0.0F;
        b1++;
      } 
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\codecLib\mpa\j.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */