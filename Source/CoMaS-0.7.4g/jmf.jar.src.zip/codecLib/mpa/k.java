package codecLib.mpa;

class k extends o implements Constants {
  private byte[] M = new byte[2016];
  
  private int L;
  
  private static final int[] P = new int[] { 
      1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 
      1024, 2048, 4096, 8192, 16384, 32768 };
  
  private static final float[] N = new float[] { 
      0.0F, -1.0F, -3.0F, -7.0F, -15.0F, -31.0F, -63.0F, -127.0F, -255.0F, -511.0F, 
      -1023.0F, -2047.0F, -4095.0F, -8191.0F, -16383.0F };
  
  private static final float[] O = new float[] { 
      0.0F, 0.6666667F, 0.2857143F, 0.13333334F, 0.06451613F, 0.031746034F, 0.015748031F, 0.007843138F, 0.0039138943F, 0.0019550342F, 
      9.770396E-4F, 4.884005E-4F, 2.4417043E-4F, 1.2207776E-4F, 6.103702E-5F };
  
  k(m paramm, c paramc) {
    super(paramm, paramc);
  }
  
  private void a(byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2, int paramInt1, int paramInt2, float[][] paramArrayOffloat) {
    byte[] arrayOfByte1 = paramArrayOfbyte1[0];
    byte[] arrayOfByte2 = paramArrayOfbyte1[1];
    byte[] arrayOfByte3 = paramArrayOfbyte2[0];
    byte[] arrayOfByte4 = paramArrayOfbyte2[1];
    float[] arrayOfFloat1 = paramArrayOffloat[0];
    float[] arrayOfFloat2 = paramArrayOffloat[1];
    byte b;
    for (b = 0; b < paramInt2; b++) {
      byte b1;
      if (0 != (b1 = arrayOfByte1[b])) {
        int j = P[b1];
        int i = this.F.bv.if(b1 + 1);
        float f = 1.0F;
        if ((i & j) == 0)
          f = N[b1]; 
        f += (i & --j);
        arrayOfFloat1[b] = Tables.t_multiple[arrayOfByte3[b]] * f * O[b1];
      } else {
        arrayOfFloat1[b] = 0.0F;
      } 
      if (paramInt1 > 1)
        if (0 != (b1 = arrayOfByte2[b])) {
          int j = P[b1];
          int i = this.F.bv.if(b1 + 1);
          float f = 1.0F;
          if ((i & j) == 0)
            f = N[b1]; 
          f += (i & --j);
          arrayOfFloat2[b] = Tables.t_multiple[arrayOfByte4[b]] * f * O[b1];
        } else {
          arrayOfFloat2[b] = 0.0F;
        }  
    } 
    while (b < 32) {
      byte b1;
      if (0 != (b1 = arrayOfByte1[b])) {
        int j = P[b1];
        int i = this.F.bv.if(b1 + 1);
        float f = 1.0F;
        if ((i & j) == 0)
          f = N[b1]; 
        f += (i & --j);
        arrayOfFloat2[b] = Tables.t_multiple[arrayOfByte3[b]] * f * O[b1];
        arrayOfFloat1[b] = Tables.t_multiple[arrayOfByte3[b]] * f * O[b1];
      } else {
        arrayOfFloat2[b] = 0.0F;
        arrayOfFloat1[b] = 0.0F;
      } 
      b++;
    } 
  }
  
  void do() throws MPADException {
    int n = this.F.bv.if();
    byte[][] arrayOfByte1 = this.F.bs[this.F.bk];
    byte[][] arrayOfByte2 = this.F.bp[this.F.bk];
    float[][][] arrayOfFloat = this.F.bu[this.F.bk];
    int j = 32;
    if (this.F.bn.goto == 1)
      j = (this.F.bn.else + 1) * 4; 
    int m = this.F.bn.k;
    if (this.F.br == 0 && this.F.bn.c == 0) {
      int i2 = 128 + 4 * j * (m - 1);
      if (this.F.bv.goto() < i2)
        throw new MPADException(-3); 
      int i3 = this.F.bq.a(this.F.bv, this.F.bn, i2);
      if (i3 != 0)
        throw new MPADException(-2); 
    } 
    byte[] arrayOfByte3 = arrayOfByte1[0];
    byte[] arrayOfByte4 = arrayOfByte1[1];
    byte[] arrayOfByte5 = arrayOfByte2[0];
    byte[] arrayOfByte6 = arrayOfByte2[1];
    int i;
    for (i = 0; i < 32; i++) {
      arrayOfByte3[i] = 0;
      arrayOfByte4[i] = 0;
      arrayOfByte5[i] = 63;
      arrayOfByte6[i] = 63;
    } 
    arrayOfByte3 = arrayOfByte1[0];
    arrayOfByte4 = arrayOfByte1[1];
    if (m > 1) {
      for (i = 0; i < j; i++) {
        arrayOfByte3[i] = (byte)this.F.bv.if(4);
        arrayOfByte4[i] = (byte)this.F.bv.if(4);
      } 
      for (i = j; i < 32; i++) {
        arrayOfByte4[i] = (byte)this.F.bv.if(4);
        arrayOfByte3[i] = (byte)this.F.bv.if(4);
      } 
    } else {
      for (i = 0; i < 32; i++)
        arrayOfByte3[i] = (byte)this.F.bv.if(4); 
    } 
    arrayOfByte3 = arrayOfByte1[0];
    arrayOfByte4 = arrayOfByte1[1];
    arrayOfByte5 = arrayOfByte2[0];
    arrayOfByte6 = arrayOfByte2[1];
    if (m > 1) {
      for (i = 0; i < 32; i++) {
        if (arrayOfByte3[i] != 0)
          arrayOfByte5[i] = (byte)this.F.bv.if(6); 
        if (arrayOfByte4[i] != 0)
          arrayOfByte6[i] = (byte)this.F.bv.if(6); 
      } 
    } else {
      for (i = 0; i < 32; i++) {
        if (arrayOfByte3[i] != 0)
          arrayOfByte5[i] = (byte)this.F.bv.if(6); 
      } 
    } 
    if (this.F.bv.goto() < 0)
      throw new MPADException(-3); 
    for (byte b = 0; b < 12; b++)
      a(arrayOfByte1, arrayOfByte2, m, j, arrayOfFloat[b]); 
    if (this.F.bv.goto() < 0)
      throw new MPADException(-3); 
    int i1 = this.F.bn.do - this.F.bv.if() - n - this.F.bn.if;
    if (i1 < 0)
      throw new MPADException(-1); 
    if (this.F.bv.goto() < 0)
      throw new MPADException(-3); 
    if (i1 > this.F.bv.goto())
      this.D.ao.cE = -1; 
    if (this.F.bk == 0)
      this.L = 0; 
    i1--;
    if ((this.D.ao.cz & 0x3) == 0) {
      this.D.ao.cE = 0;
      this.F.bn.char = 384;
      a(1);
      if (++this.F.bk == 3)
        this.F.bk = 0; 
    } else {
      if (i1 > 0 && this.L >= 0) {
        b.a(this.M, 0, this.F.bv.else(), this.F.bv.for(), this.L, this.F.bv.new(), i1);
        this.L += i1;
      } else {
        this.L = -1;
        if ((this.D.ao.cz & 0x3) == 3) {
          this.D.ao.cE = -1;
          return;
        } 
      } 
      if (this.F.bk == 2 && this.L > 15) {
        b b2 = this.F.bv;
        int i2 = this.L;
        this.D.al.a(this.M, 0, this.L + 7 >> 3);
        this.F.bv = this.D.al;
        for (byte b1 = 0; b1 < m; b1++) {
          for (i = 0; i < 32; i++) {
            if (this.F.bs[0][b1][i] == 0)
              if (this.F.bs[1][b1][i] > 0) {
                this.F.bs[0][b1][i] = this.F.bs[1][b1][i];
              } else if (this.F.bs[2][b1][i] > 0) {
                this.F.bs[0][b1][i] = this.F.bs[2][b1][i];
              }  
          } 
        } 
        this.D.ao.cE = this.D.int(i2);
        this.F.bv = b2;
      } else if (this.F.bk != 2 && this.L >= 0) {
        this.D.ao.cE = 1;
      } else {
        this.D.ao.cE = -1;
      } 
      if (++this.F.bk == 3) {
        this.F.bk = 0;
        this.F.bn.char = 1152;
        if ((this.D.ao.cz & 0x3) != 3)
          a(2); 
      } 
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\jmf.jar!\codecLib\mpa\k.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */