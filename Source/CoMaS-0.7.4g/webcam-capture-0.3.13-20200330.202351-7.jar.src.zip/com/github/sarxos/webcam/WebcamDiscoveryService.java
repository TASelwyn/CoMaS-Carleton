package com.github.sarxos.webcam;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WebcamDiscoveryService implements Runnable {
  private static final Logger LOG = LoggerFactory.getLogger(WebcamDiscoveryService.class);
  
  private final WebcamDriver driver;
  
  private final WebcamDiscoverySupport support;
  
  private static final class WebcamsDiscovery implements Callable<List<Webcam>>, ThreadFactory {
    private final WebcamDriver driver;
    
    public WebcamsDiscovery(WebcamDriver driver) {
      this.driver = driver;
    }
    
    public List<Webcam> call() throws Exception {
      return WebcamDiscoveryService.toWebcams(this.driver.getDevices());
    }
    
    public Thread newThread(Runnable r) {
      Thread t = new Thread(r, "webcam-discovery-service");
      t.setDaemon(true);
      t.setUncaughtExceptionHandler(WebcamExceptionHandler.getInstance());
      return t;
    }
  }
  
  private volatile List<Webcam> webcams = null;
  
  private AtomicBoolean running = new AtomicBoolean(false);
  
  private AtomicBoolean enabled = new AtomicBoolean(true);
  
  private Thread runner = null;
  
  protected WebcamDiscoveryService(WebcamDriver driver) {
    if (driver == null)
      throw new IllegalArgumentException("Driver cannot be null!"); 
    this.driver = driver;
    this.support = (driver instanceof WebcamDiscoverySupport) ? (WebcamDiscoverySupport)driver : null;
  }
  
  private static List<Webcam> toWebcams(List<WebcamDevice> devices) {
    List<Webcam> webcams = new ArrayList<>();
    for (WebcamDevice device : devices)
      webcams.add(new Webcam(device)); 
    return webcams;
  }
  
  private static List<WebcamDevice> getDevices(List<Webcam> webcams) {
    List<WebcamDevice> devices = new ArrayList<>();
    for (Webcam webcam : webcams)
      devices.add(webcam.getDevice()); 
    return devices;
  }
  
  public List<Webcam> getWebcams(long timeout, TimeUnit tunit) throws TimeoutException {
    if (timeout < 0L)
      throw new IllegalArgumentException("Timeout cannot be negative"); 
    if (tunit == null)
      throw new IllegalArgumentException("Time unit cannot be null!"); 
    List<Webcam> tmp = null;
    synchronized (Webcam.class) {
      if (this.webcams == null) {
        WebcamsDiscovery discovery = new WebcamsDiscovery(this.driver);
        ExecutorService executor = Executors.newSingleThreadExecutor(discovery);
        Future<List<Webcam>> future = executor.submit(discovery);
        executor.shutdown();
        try {
          executor.awaitTermination(timeout, tunit);
          if (future.isDone()) {
            this.webcams = future.get();
          } else {
            future.cancel(true);
          } 
        } catch (InterruptedException e) {
          throw new RuntimeException(e);
        } catch (ExecutionException e) {
          throw new WebcamException(e);
        } 
        if (this.webcams == null)
          throw new TimeoutException(String.format("Webcams discovery timeout (%d ms) has been exceeded", new Object[] { Long.valueOf(timeout) })); 
        tmp = new ArrayList<>(this.webcams);
        if (Webcam.isHandleTermSignal())
          WebcamDeallocator.store(this.webcams.<Webcam>toArray(new Webcam[this.webcams.size()])); 
      } 
    } 
    if (tmp != null) {
      WebcamDiscoveryListener[] listeners = Webcam.getDiscoveryListeners();
      for (Webcam webcam : tmp)
        notifyWebcamFound(webcam, listeners); 
    } 
    return Collections.unmodifiableList(this.webcams);
  }
  
  public void scan() {
    WebcamDiscoveryListener[] listeners = Webcam.getDiscoveryListeners();
    List<WebcamDevice> tmpnew = this.driver.getDevices();
    List<WebcamDevice> tmpold = null;
    try {
      tmpold = getDevices(getWebcams(Long.MAX_VALUE, TimeUnit.MILLISECONDS));
    } catch (TimeoutException e) {
      throw new WebcamException(e);
    } 
    List<WebcamDevice> oldones = new LinkedList<>(tmpold);
    List<WebcamDevice> newones = new LinkedList<>(tmpnew);
    Iterator<WebcamDevice> oi = oldones.iterator();
    Iterator<WebcamDevice> ni = null;
    WebcamDevice od = null;
    WebcamDevice nd = null;
    while (oi.hasNext()) {
      od = oi.next();
      ni = newones.iterator();
      while (ni.hasNext()) {
        nd = ni.next();
        if (nd.getName().equals(od.getName())) {
          ni.remove();
          oi.remove();
        } 
      } 
    } 
    if (oldones.size() > 0) {
      List<Webcam> notified = new ArrayList<>();
      for (WebcamDevice device : oldones) {
        for (Webcam webcam : this.webcams) {
          if (webcam.getDevice().getName().equals(device.getName()))
            notified.add(webcam); 
        } 
      } 
      setCurrentWebcams(tmpnew);
      for (Webcam webcam : notified) {
        notifyWebcamGone(webcam, listeners);
        webcam.dispose();
      } 
    } 
    if (newones.size() > 0) {
      setCurrentWebcams(tmpnew);
      for (WebcamDevice device : newones) {
        for (Webcam webcam : this.webcams) {
          if (webcam.getDevice().getName().equals(device.getName()))
            notifyWebcamFound(webcam, listeners); 
        } 
      } 
    } 
  }
  
  public void run() {
    if (this.support == null)
      return; 
    if (!this.support.isScanPossible())
      return; 
    Object monitor = new Object();
    do {
      synchronized (monitor) {
        try {
          monitor.wait(this.support.getScanInterval());
        } catch (InterruptedException e) {
          break;
        } catch (Exception e) {
          throw new RuntimeException("Problem waiting on monitor", e);
        } 
      } 
      scan();
    } while (this.running.get());
    LOG.debug("Webcam discovery service loop has been stopped");
  }
  
  private void setCurrentWebcams(List<WebcamDevice> devices) {
    this.webcams = toWebcams(devices);
    if (Webcam.isHandleTermSignal()) {
      WebcamDeallocator.unstore();
      WebcamDeallocator.store(this.webcams.<Webcam>toArray(new Webcam[this.webcams.size()]));
    } 
  }
  
  private static void notifyWebcamGone(Webcam webcam, WebcamDiscoveryListener[] listeners) {
    WebcamDiscoveryEvent event = new WebcamDiscoveryEvent(webcam, 2);
    for (WebcamDiscoveryListener l : listeners) {
      try {
        l.webcamGone(event);
      } catch (Exception e) {
        LOG.error(String.format("Webcam gone, exception when calling listener %s", new Object[] { l.getClass() }), e);
      } 
    } 
  }
  
  private static void notifyWebcamFound(Webcam webcam, WebcamDiscoveryListener[] listeners) {
    WebcamDiscoveryEvent event = new WebcamDiscoveryEvent(webcam, 1);
    for (WebcamDiscoveryListener l : listeners) {
      try {
        l.webcamFound(event);
      } catch (Exception e) {
        LOG.error(String.format("Webcam found, exception when calling listener %s", new Object[] { l.getClass() }), e);
      } 
    } 
  }
  
  public void stop() {
    if (!this.running.compareAndSet(true, false))
      return; 
    try {
      this.runner.join();
    } catch (InterruptedException e) {
      throw new WebcamException("Joint interrupted");
    } 
    LOG.debug("Discovery service has been stopped");
    this.runner = null;
  }
  
  public void start() {
    if (!this.enabled.get()) {
      LOG.info("Discovery service has been disabled and thus it will not be started");
      return;
    } 
    if (this.support == null) {
      LOG.info("Discovery will not run - driver {} does not support this feature", this.driver.getClass().getSimpleName());
      return;
    } 
    if (!this.running.compareAndSet(false, true))
      return; 
    this.runner = new Thread(this, "webcam-discovery-service");
    this.runner.setUncaughtExceptionHandler(WebcamExceptionHandler.getInstance());
    this.runner.setDaemon(true);
    this.runner.start();
  }
  
  public boolean isRunning() {
    return this.running.get();
  }
  
  public void setEnabled(boolean enabled) {
    this.enabled.set(enabled);
  }
  
  protected void shutdown() {
    stop();
    if (this.webcams == null)
      return; 
    Iterator<Webcam> wi = this.webcams.iterator();
    while (wi.hasNext()) {
      Webcam webcam = wi.next();
      webcam.dispose();
    } 
    synchronized (Webcam.class) {
      this.webcams.clear();
      if (Webcam.isHandleTermSignal())
        WebcamDeallocator.unstore(); 
    } 
  }
}
