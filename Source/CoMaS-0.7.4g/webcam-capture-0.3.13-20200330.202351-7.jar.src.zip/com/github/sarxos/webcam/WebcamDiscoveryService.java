/*     */ package com.github.sarxos.webcam;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ public class WebcamDiscoveryService
/*     */   implements Runnable
/*     */ {
/*  24 */   private static final Logger LOG = LoggerFactory.getLogger(WebcamDiscoveryService.class);
/*     */   private final WebcamDriver driver;
/*     */   private final WebcamDiscoverySupport support;
/*     */   
/*     */   private static final class WebcamsDiscovery
/*     */     implements Callable<List<Webcam>>, ThreadFactory {
/*     */     public WebcamsDiscovery(WebcamDriver driver) {
/*  31 */       this.driver = driver;
/*     */     }
/*     */     private final WebcamDriver driver;
/*     */     
/*     */     public List<Webcam> call() throws Exception {
/*  36 */       return WebcamDiscoveryService.toWebcams(this.driver.getDevices());
/*     */     }
/*     */ 
/*     */     
/*     */     public Thread newThread(Runnable r) {
/*  41 */       Thread t = new Thread(r, "webcam-discovery-service");
/*  42 */       t.setDaemon(true);
/*  43 */       t.setUncaughtExceptionHandler(WebcamExceptionHandler.getInstance());
/*  44 */       return t;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   private volatile List<Webcam> webcams = null;
/*     */   
/*  53 */   private AtomicBoolean running = new AtomicBoolean(false);
/*  54 */   private AtomicBoolean enabled = new AtomicBoolean(true);
/*     */   
/*  56 */   private Thread runner = null;
/*     */ 
/*     */   
/*     */   protected WebcamDiscoveryService(WebcamDriver driver) {
/*  60 */     if (driver == null) {
/*  61 */       throw new IllegalArgumentException("Driver cannot be null!");
/*     */     }
/*     */     
/*  64 */     this.driver = driver;
/*  65 */     this.support = (driver instanceof WebcamDiscoverySupport) ? (WebcamDiscoverySupport)driver : null;
/*     */   }
/*     */   
/*     */   private static List<Webcam> toWebcams(List<WebcamDevice> devices) {
/*  69 */     List<Webcam> webcams = new ArrayList<>();
/*  70 */     for (WebcamDevice device : devices) {
/*  71 */       webcams.add(new Webcam(device));
/*     */     }
/*  73 */     return webcams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<WebcamDevice> getDevices(List<Webcam> webcams) {
/*  82 */     List<WebcamDevice> devices = new ArrayList<>();
/*  83 */     for (Webcam webcam : webcams) {
/*  84 */       devices.add(webcam.getDevice());
/*     */     }
/*  86 */     return devices;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Webcam> getWebcams(long timeout, TimeUnit tunit) throws TimeoutException {
/*  91 */     if (timeout < 0L) {
/*  92 */       throw new IllegalArgumentException("Timeout cannot be negative");
/*     */     }
/*     */     
/*  95 */     if (tunit == null) {
/*  96 */       throw new IllegalArgumentException("Time unit cannot be null!");
/*     */     }
/*     */     
/*  99 */     List<Webcam> tmp = null;
/*     */     
/* 101 */     synchronized (Webcam.class) {
/*     */       
/* 103 */       if (this.webcams == null) {
/*     */         
/* 105 */         WebcamsDiscovery discovery = new WebcamsDiscovery(this.driver);
/* 106 */         ExecutorService executor = Executors.newSingleThreadExecutor(discovery);
/* 107 */         Future<List<Webcam>> future = executor.submit(discovery);
/*     */         
/* 109 */         executor.shutdown();
/*     */ 
/*     */         
/*     */         try {
/* 113 */           executor.awaitTermination(timeout, tunit);
/*     */           
/* 115 */           if (future.isDone()) {
/* 116 */             this.webcams = future.get();
/*     */           } else {
/* 118 */             future.cancel(true);
/*     */           }
/*     */         
/* 121 */         } catch (InterruptedException e) {
/* 122 */           throw new RuntimeException(e);
/* 123 */         } catch (ExecutionException e) {
/* 124 */           throw new WebcamException(e);
/*     */         } 
/*     */         
/* 127 */         if (this.webcams == null) {
/* 128 */           throw new TimeoutException(String.format("Webcams discovery timeout (%d ms) has been exceeded", new Object[] { Long.valueOf(timeout) }));
/*     */         }
/*     */         
/* 131 */         tmp = new ArrayList<>(this.webcams);
/*     */         
/* 133 */         if (Webcam.isHandleTermSignal()) {
/* 134 */           WebcamDeallocator.store(this.webcams.<Webcam>toArray(new Webcam[this.webcams.size()]));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 139 */     if (tmp != null) {
/* 140 */       WebcamDiscoveryListener[] listeners = Webcam.getDiscoveryListeners();
/* 141 */       for (Webcam webcam : tmp) {
/* 142 */         notifyWebcamFound(webcam, listeners);
/*     */       }
/*     */     } 
/*     */     
/* 146 */     return Collections.unmodifiableList(this.webcams);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void scan() {
/* 154 */     WebcamDiscoveryListener[] listeners = Webcam.getDiscoveryListeners();
/*     */     
/* 156 */     List<WebcamDevice> tmpnew = this.driver.getDevices();
/* 157 */     List<WebcamDevice> tmpold = null;
/*     */     
/*     */     try {
/* 160 */       tmpold = getDevices(getWebcams(Long.MAX_VALUE, TimeUnit.MILLISECONDS));
/* 161 */     } catch (TimeoutException e) {
/* 162 */       throw new WebcamException(e);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 168 */     List<WebcamDevice> oldones = new LinkedList<>(tmpold);
/* 169 */     List<WebcamDevice> newones = new LinkedList<>(tmpnew);
/*     */     
/* 171 */     Iterator<WebcamDevice> oi = oldones.iterator();
/* 172 */     Iterator<WebcamDevice> ni = null;
/*     */     
/* 174 */     WebcamDevice od = null;
/* 175 */     WebcamDevice nd = null;
/*     */ 
/*     */ 
/*     */     
/* 179 */     while (oi.hasNext()) {
/*     */       
/* 181 */       od = oi.next();
/* 182 */       ni = newones.iterator();
/*     */       
/* 184 */       while (ni.hasNext()) {
/*     */         
/* 186 */         nd = ni.next();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 191 */         if (nd.getName().equals(od.getName())) {
/* 192 */           ni.remove();
/* 193 */           oi.remove();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 200 */     if (oldones.size() > 0) {
/*     */       
/* 202 */       List<Webcam> notified = new ArrayList<>();
/*     */       
/* 204 */       for (WebcamDevice device : oldones) {
/* 205 */         for (Webcam webcam : this.webcams) {
/* 206 */           if (webcam.getDevice().getName().equals(device.getName())) {
/* 207 */             notified.add(webcam);
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 213 */       setCurrentWebcams(tmpnew);
/*     */       
/* 215 */       for (Webcam webcam : notified) {
/* 216 */         notifyWebcamGone(webcam, listeners);
/* 217 */         webcam.dispose();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 222 */     if (newones.size() > 0) {
/*     */       
/* 224 */       setCurrentWebcams(tmpnew);
/*     */       
/* 226 */       for (WebcamDevice device : newones) {
/* 227 */         for (Webcam webcam : this.webcams) {
/* 228 */           if (webcam.getDevice().getName().equals(device.getName())) {
/* 229 */             notifyWebcamFound(webcam, listeners);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 242 */     if (this.support == null) {
/*     */       return;
/*     */     }
/* 245 */     if (!this.support.isScanPossible()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 252 */     Object monitor = new Object();
/*     */     
/*     */     do {
/* 255 */       synchronized (monitor) {
/*     */         try {
/* 257 */           monitor.wait(this.support.getScanInterval());
/* 258 */         } catch (InterruptedException e) {
/*     */           break;
/* 260 */         } catch (Exception e) {
/* 261 */           throw new RuntimeException("Problem waiting on monitor", e);
/*     */         } 
/*     */       } 
/*     */       
/* 265 */       scan();
/*     */     }
/* 267 */     while (this.running.get());
/*     */     
/* 269 */     LOG.debug("Webcam discovery service loop has been stopped");
/*     */   }
/*     */   
/*     */   private void setCurrentWebcams(List<WebcamDevice> devices) {
/* 273 */     this.webcams = toWebcams(devices);
/* 274 */     if (Webcam.isHandleTermSignal()) {
/* 275 */       WebcamDeallocator.unstore();
/* 276 */       WebcamDeallocator.store(this.webcams.<Webcam>toArray(new Webcam[this.webcams.size()]));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void notifyWebcamGone(Webcam webcam, WebcamDiscoveryListener[] listeners) {
/* 281 */     WebcamDiscoveryEvent event = new WebcamDiscoveryEvent(webcam, 2);
/* 282 */     for (WebcamDiscoveryListener l : listeners) {
/*     */       try {
/* 284 */         l.webcamGone(event);
/* 285 */       } catch (Exception e) {
/* 286 */         LOG.error(String.format("Webcam gone, exception when calling listener %s", new Object[] { l.getClass() }), e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void notifyWebcamFound(Webcam webcam, WebcamDiscoveryListener[] listeners) {
/* 292 */     WebcamDiscoveryEvent event = new WebcamDiscoveryEvent(webcam, 1);
/* 293 */     for (WebcamDiscoveryListener l : listeners) {
/*     */       try {
/* 295 */         l.webcamFound(event);
/* 296 */       } catch (Exception e) {
/* 297 */         LOG.error(String.format("Webcam found, exception when calling listener %s", new Object[] { l.getClass() }), e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 309 */     if (!this.running.compareAndSet(true, false)) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 314 */       this.runner.join();
/* 315 */     } catch (InterruptedException e) {
/* 316 */       throw new WebcamException("Joint interrupted");
/*     */     } 
/*     */     
/* 319 */     LOG.debug("Discovery service has been stopped");
/*     */     
/* 321 */     this.runner = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 331 */     if (!this.enabled.get()) {
/* 332 */       LOG.info("Discovery service has been disabled and thus it will not be started");
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 338 */     if (this.support == null) {
/* 339 */       LOG.info("Discovery will not run - driver {} does not support this feature", this.driver.getClass().getSimpleName());
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 345 */     if (!this.running.compareAndSet(false, true)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 351 */     this.runner = new Thread(this, "webcam-discovery-service");
/* 352 */     this.runner.setUncaughtExceptionHandler(WebcamExceptionHandler.getInstance());
/* 353 */     this.runner.setDaemon(true);
/* 354 */     this.runner.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRunning() {
/* 363 */     return this.running.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/* 374 */     this.enabled.set(enabled);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void shutdown() {
/* 382 */     stop();
/*     */     
/* 384 */     if (this.webcams == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 389 */     Iterator<Webcam> wi = this.webcams.iterator();
/* 390 */     while (wi.hasNext()) {
/* 391 */       Webcam webcam = wi.next();
/* 392 */       webcam.dispose();
/*     */     } 
/*     */     
/* 395 */     synchronized (Webcam.class) {
/*     */ 
/*     */ 
/*     */       
/* 399 */       this.webcams.clear();
/*     */ 
/*     */ 
/*     */       
/* 403 */       if (Webcam.isHandleTermSignal())
/* 404 */         WebcamDeallocator.unstore(); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamDiscoveryService.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */