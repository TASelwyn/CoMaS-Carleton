package com.github.sarxos.webcam;

public interface WebcamDiscoveryListener {
  void webcamFound(WebcamDiscoveryEvent paramWebcamDiscoveryEvent);
  
  void webcamGone(WebcamDiscoveryEvent paramWebcamDiscoveryEvent);
}
