package com.github.sarxos.webcam;

import java.awt.BorderLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WebcamViewer extends JFrame implements Runnable, WebcamListener, WindowListener, Thread.UncaughtExceptionHandler, ItemListener {
  private static final long serialVersionUID = 1L;
  
  private static final Logger LOG = LoggerFactory.getLogger(WebcamViewer.class);
  
  private Webcam webcam = null;
  
  private WebcamPanel panel = null;
  
  private WebcamPicker picker = null;
  
  public WebcamViewer() {
    SwingUtilities.invokeLater(this);
  }
  
  public void run() {
    setTitle("Webcam Capture Viewer");
    setDefaultCloseOperation(3);
    setLayout(new BorderLayout());
    addWindowListener(this);
    this.picker = new WebcamPicker();
    this.picker.addItemListener(this);
    this.webcam = this.picker.getSelectedWebcam();
    if (this.webcam == null) {
      LOG.error("No webcams found");
      System.exit(1);
    } 
    this.webcam.setViewSize(WebcamResolution.VGA.getSize());
    this.webcam.addWebcamListener(this);
    this.panel = new WebcamPanel(this.webcam, false);
    this.panel.setFPSDisplayed(true);
    add(this.picker, "North");
    add(this.panel, "Center");
    pack();
    setVisible(true);
    Thread t = new Thread() {
        public void run() {
          WebcamViewer.this.panel.start();
        }
      };
    t.setName("webcam-viewer-starter");
    t.setDaemon(true);
    t.setUncaughtExceptionHandler(this);
    t.start();
  }
  
  public void webcamOpen(WebcamEvent we) {
    LOG.info("Webcam open");
  }
  
  public void webcamClosed(WebcamEvent we) {
    LOG.info("Webcam closed");
  }
  
  public void webcamDisposed(WebcamEvent we) {
    LOG.info("Webcam disposed");
  }
  
  public void webcamImageObtained(WebcamEvent we) {}
  
  public void windowActivated(WindowEvent e) {}
  
  public void windowClosed(WindowEvent e) {
    this.webcam.close();
  }
  
  public void windowClosing(WindowEvent e) {}
  
  public void windowOpened(WindowEvent e) {}
  
  public void windowDeactivated(WindowEvent e) {}
  
  public void windowDeiconified(WindowEvent e) {
    LOG.info("Webcam viewer resumed");
    this.panel.resume();
  }
  
  public void windowIconified(WindowEvent e) {
    LOG.info("Webcam viewer paused");
    this.panel.pause();
  }
  
  public void uncaughtException(Thread t, Throwable e) {
    e.printStackTrace();
    LOG.error(String.format("Exception in thread %s", new Object[] { t.getName() }), e);
  }
  
  public void itemStateChanged(ItemEvent e) {
    if (e.getItem() == this.webcam)
      return; 
    if (this.webcam == null)
      return; 
    final WebcamPanel tmp = this.panel;
    remove(this.panel);
    this.webcam.removeWebcamListener(this);
    this.webcam = (Webcam)e.getItem();
    this.webcam.setViewSize(WebcamResolution.VGA.getSize());
    this.webcam.addWebcamListener(this);
    System.out.println("selected " + this.webcam.getName());
    this.panel = new WebcamPanel(this.webcam, false);
    add(this.panel, "Center");
    Thread t = new Thread() {
        public void run() {
          tmp.stop();
          WebcamViewer.this.panel.start();
        }
      };
    t.setDaemon(true);
    t.setUncaughtExceptionHandler(this);
    t.start();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamViewer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */