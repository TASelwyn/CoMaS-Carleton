package com.github.sarxos.webcam;

import com.github.sarxos.webcam.ds.buildin.WebcamDefaultDriver;
import com.github.sarxos.webcam.ds.cgt.WebcamCloseTask;
import com.github.sarxos.webcam.ds.cgt.WebcamDisposeTask;
import com.github.sarxos.webcam.ds.cgt.WebcamGetBufferTask;
import com.github.sarxos.webcam.ds.cgt.WebcamGetImageTask;
import com.github.sarxos.webcam.ds.cgt.WebcamOpenTask;
import com.github.sarxos.webcam.ds.cgt.WebcamReadBufferTask;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Webcam {
  private static final class ImageNotification implements Runnable {
    private final Webcam webcam;
    
    private final BufferedImage image;
    
    public ImageNotification(Webcam webcam, BufferedImage image) {
      this.webcam = webcam;
      this.image = image;
    }
    
    public void run() {
      if (this.image != null) {
        WebcamEvent we = new WebcamEvent(WebcamEventType.NEW_IMAGE, this.webcam, this.image);
        for (WebcamListener l : this.webcam.getWebcamListeners()) {
          try {
            l.webcamImageObtained(we);
          } catch (Exception e) {
            Webcam.LOG.error(String.format("Notify image acquired, exception when calling listener %s", new Object[] { l.getClass() }), e);
          } 
        } 
      } 
    }
  }
  
  private final class NotificationThreadFactory implements ThreadFactory {
    private NotificationThreadFactory() {}
    
    public Thread newThread(Runnable r) {
      Thread t = new Thread(r, String.format("notificator-[%s]", new Object[] { this.this$0.getName() }));
      t.setUncaughtExceptionHandler(WebcamExceptionHandler.getInstance());
      t.setDaemon(true);
      return t;
    }
  }
  
  private static final Logger LOG = LoggerFactory.getLogger(Webcam.class);
  
  private static final List<String> DRIVERS_LIST = new ArrayList<>();
  
  private static final List<Class<?>> DRIVERS_CLASS_LIST = new ArrayList<>();
  
  private static final List<WebcamDiscoveryListener> DISCOVERY_LISTENERS = Collections.synchronizedList(new ArrayList<>());
  
  private static volatile WebcamDriver driver = null;
  
  private static volatile WebcamDiscoveryService discovery = null;
  
  private static boolean deallocOnTermSignal = false;
  
  private static boolean autoOpen = false;
  
  private List<WebcamListener> listeners = new CopyOnWriteArrayList<>();
  
  private List<Dimension> customSizes = new ArrayList<>();
  
  private WebcamShutdownHook hook = null;
  
  private WebcamDevice device = null;
  
  private AtomicBoolean open = new AtomicBoolean(false);
  
  private AtomicBoolean disposed = new AtomicBoolean(false);
  
  private volatile boolean asynchronous = false;
  
  private volatile double fps = 0.0D;
  
  private volatile WebcamUpdater updater = null;
  
  private volatile WebcamImageTransformer transformer = null;
  
  private WebcamLock lock = null;
  
  private ExecutorService notificator = null;
  
  protected Webcam(WebcamDevice device) {
    if (device == null)
      throw new IllegalArgumentException("Webcam device cannot be null"); 
    this.device = device;
    this.lock = new WebcamLock(this);
  }
  
  protected void notifyWebcamImageAcquired(BufferedImage image) {
    if (getWebcamListenersCount() > 0)
      this.notificator.execute(new ImageNotification(this, image)); 
  }
  
  public boolean open() {
    return open(false);
  }
  
  public boolean open(boolean async) {
    return open(async, new WebcamUpdater.DefaultDelayCalculator());
  }
  
  public boolean open(boolean async, WebcamUpdater.DelayCalculator delayCalculator) {
    if (this.open.compareAndSet(false, true)) {
      assert this.lock != null;
      this.notificator = Executors.newSingleThreadExecutor(new NotificationThreadFactory());
      this.lock.lock();
      WebcamOpenTask task = new WebcamOpenTask(driver, this.device);
      try {
        task.open();
      } catch (InterruptedException e) {
        this.lock.unlock();
        this.open.set(false);
        LOG.debug("Thread has been interrupted in the middle of webcam opening process!", e);
        return false;
      } catch (WebcamException e) {
        this.lock.unlock();
        this.open.set(false);
        LOG.debug("Webcam exception when opening", e);
        throw e;
      } 
      LOG.debug("Webcam is now open {}", getName());
      try {
        Runtime.getRuntime().addShutdownHook(this.hook = new WebcamShutdownHook(this));
      } catch (IllegalStateException e) {
        LOG.debug("Shutdown in progress, do not open device");
        LOG.trace(e.getMessage(), e);
        close();
        return false;
      } 
      if (this.asynchronous = async) {
        if (this.updater == null)
          this.updater = new WebcamUpdater(this, delayCalculator); 
        this.updater.start();
      } 
      WebcamEvent we = new WebcamEvent(WebcamEventType.OPEN, this);
      Iterator<WebcamListener> wli = this.listeners.iterator();
      WebcamListener l = null;
      while (wli.hasNext()) {
        l = wli.next();
        try {
          l.webcamOpen(we);
        } catch (Exception e) {
          LOG.error(String.format("Notify webcam open, exception when calling listener %s", new Object[] { l.getClass() }), e);
        } 
      } 
    } else {
      LOG.debug("Webcam is already open {}", getName());
    } 
    return true;
  }
  
  public boolean close() {
    if (this.open.compareAndSet(true, false)) {
      LOG.debug("Closing webcam {}", getName());
      assert this.lock != null;
      WebcamCloseTask task = new WebcamCloseTask(driver, this.device);
      try {
        task.close();
      } catch (InterruptedException e) {
        this.open.set(true);
        LOG.debug("Thread has been interrupted before webcam was closed!", e);
        return false;
      } catch (WebcamException e) {
        this.open.set(true);
        throw e;
      } 
      if (this.asynchronous)
        this.updater.stop(); 
      removeShutdownHook();
      this.lock.unlock();
      WebcamEvent we = new WebcamEvent(WebcamEventType.CLOSED, this);
      Iterator<WebcamListener> wli = this.listeners.iterator();
      WebcamListener l = null;
      while (wli.hasNext()) {
        l = wli.next();
        try {
          l.webcamClosed(we);
        } catch (Exception e) {
          LOG.error(String.format("Notify webcam closed, exception when calling %s listener", new Object[] { l.getClass() }), e);
        } 
      } 
      this.notificator.shutdown();
      while (!this.notificator.isTerminated()) {
        try {
          this.notificator.awaitTermination(100L, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
          return false;
        } 
      } 
      LOG.debug("Webcam {} has been closed", getName());
    } else {
      LOG.debug("Webcam {} is already closed", getName());
    } 
    return true;
  }
  
  public WebcamDevice getDevice() {
    assert this.device != null;
    return this.device;
  }
  
  protected void dispose() {
    assert this.disposed != null;
    assert this.open != null;
    assert driver != null;
    assert this.device != null;
    assert this.listeners != null;
    if (!this.disposed.compareAndSet(false, true))
      return; 
    this.open.set(false);
    LOG.info("Disposing webcam {}", getName());
    WebcamDisposeTask task = new WebcamDisposeTask(driver, this.device);
    try {
      task.dispose();
    } catch (InterruptedException e) {
      LOG.error("Processor has been interrupted before webcam was disposed!", e);
      return;
    } 
    WebcamEvent we = new WebcamEvent(WebcamEventType.DISPOSED, this);
    Iterator<WebcamListener> wli = this.listeners.iterator();
    WebcamListener l = null;
    while (wli.hasNext()) {
      l = wli.next();
      try {
        l.webcamClosed(we);
        l.webcamDisposed(we);
      } catch (Exception e) {
        LOG.error(String.format("Notify webcam disposed, exception when calling %s listener", new Object[] { l.getClass() }), e);
      } 
    } 
    removeShutdownHook();
    LOG.debug("Webcam disposed {}", getName());
  }
  
  private void removeShutdownHook() {
    if (this.hook != null)
      try {
        Runtime.getRuntime().removeShutdownHook(this.hook);
      } catch (IllegalStateException e) {
        LOG.trace("Shutdown in progress, cannot remove hook");
      }  
  }
  
  protected BufferedImage transform(BufferedImage image) {
    if (image != null) {
      WebcamImageTransformer tr = getImageTransformer();
      if (tr != null)
        return tr.transform(image); 
    } 
    return image;
  }
  
  public boolean isOpen() {
    return this.open.get();
  }
  
  public Dimension getViewSize() {
    return this.device.getResolution();
  }
  
  public Dimension[] getViewSizes() {
    return this.device.getResolutions();
  }
  
  public void setCustomViewSizes(Dimension... sizes) {
    assert this.customSizes != null;
    if (sizes == null) {
      this.customSizes.clear();
      return;
    } 
    this.customSizes = Arrays.asList(sizes);
  }
  
  public Dimension[] getCustomViewSizes() {
    assert this.customSizes != null;
    return this.customSizes.<Dimension>toArray(new Dimension[this.customSizes.size()]);
  }
  
  public void setViewSize(Dimension size) {
    if (size == null)
      throw new IllegalArgumentException("Resolution cannot be null!"); 
    if (this.open.get())
      throw new IllegalStateException("Cannot change resolution when webcam is open, please close it first"); 
    Dimension current = getViewSize();
    if (current != null && current.width == size.width && current.height == size.height)
      return; 
    Dimension[] predefined = getViewSizes();
    Dimension[] custom = getCustomViewSizes();
    assert predefined != null;
    assert custom != null;
    boolean ok = false;
    for (Dimension d : predefined) {
      if (d.width == size.width && d.height == size.height) {
        ok = true;
        break;
      } 
    } 
    if (!ok)
      for (Dimension d : custom) {
        if (d.width == size.width && d.height == size.height) {
          ok = true;
          break;
        } 
      }  
    if (!ok) {
      StringBuilder sb = new StringBuilder("Incorrect dimension [");
      sb.append(size.width).append("x").append(size.height).append("] ");
      sb.append("possible ones are ");
      for (Dimension d : predefined)
        sb.append("[").append(d.width).append("x").append(d.height).append("] "); 
      for (Dimension d : custom)
        sb.append("[").append(d.width).append("x").append(d.height).append("] "); 
      throw new IllegalArgumentException(sb.toString());
    } 
    LOG.debug("Setting new resolution {}x{}", Integer.valueOf(size.width), Integer.valueOf(size.height));
    this.device.setResolution(size);
  }
  
  public BufferedImage getImage() {
    if (!isReady())
      return null; 
    long t1 = 0L;
    long t2 = 0L;
    if (this.asynchronous)
      return this.updater.getImage(); 
    t1 = System.currentTimeMillis();
    BufferedImage image = transform((new WebcamGetImageTask(driver, this.device)).getImage());
    t2 = System.currentTimeMillis();
    if (image == null)
      return null; 
    if (this.device instanceof WebcamDevice.FPSSource) {
      this.fps = ((WebcamDevice.FPSSource)this.device).getFPS();
    } else {
      this.fps = (4.0D * this.fps + (1000L / (t2 - t1 + 1L))) / 5.0D;
    } 
    notifyWebcamImageAcquired(image);
    return image;
  }
  
  public boolean isImageNew() {
    if (this.asynchronous)
      return this.updater.isImageNew(); 
    return true;
  }
  
  public double getFPS() {
    if (this.asynchronous)
      return this.updater.getFPS(); 
    return this.fps;
  }
  
  public ByteBuffer getImageBytes() {
    if (!isReady())
      return null; 
    assert driver != null;
    assert this.device != null;
    long t1 = 0L;
    long t2 = 0L;
    if (this.device instanceof WebcamDevice.BufferAccess) {
      t1 = System.currentTimeMillis();
      try {
        return (new WebcamGetBufferTask(driver, this.device)).getBuffer();
      } finally {
        t2 = System.currentTimeMillis();
        if (this.device instanceof WebcamDevice.FPSSource) {
          this.fps = ((WebcamDevice.FPSSource)this.device).getFPS();
        } else {
          this.fps = (4.0D * this.fps + (1000L / (t2 - t1 + 1L))) / 5.0D;
        } 
      } 
    } 
    throw new IllegalStateException(String.format("Driver %s does not support buffer access", new Object[] { driver.getClass().getName() }));
  }
  
  public void getImageBytes(ByteBuffer target) {
    if (!isReady())
      return; 
    assert driver != null;
    assert this.device != null;
    long t1 = 0L;
    long t2 = 0L;
    if (this.device instanceof WebcamDevice.BufferAccess) {
      t1 = System.currentTimeMillis();
      try {
        (new WebcamReadBufferTask(driver, this.device, target)).readBuffer();
      } finally {
        t2 = System.currentTimeMillis();
        if (this.device instanceof WebcamDevice.FPSSource) {
          this.fps = ((WebcamDevice.FPSSource)this.device).getFPS();
        } else {
          this.fps = (4.0D * this.fps + (1000L / (t2 - t1 + 1L))) / 5.0D;
        } 
      } 
    } else {
      throw new IllegalStateException(String.format("Driver %s does not support buffer access", new Object[] { driver.getClass().getName() }));
    } 
  }
  
  public void setParameters(Map<String, ?> parameters) {
    WebcamDevice device = getDevice();
    if (device instanceof WebcamDevice.Configurable) {
      ((WebcamDevice.Configurable)device).setParameters(parameters);
    } else {
      LOG.debug("Webcam device {} is not configurable", device);
    } 
  }
  
  private boolean isReady() {
    assert this.disposed != null;
    assert this.open != null;
    if (this.disposed.get()) {
      LOG.warn("Cannot get image, webcam has been already disposed");
      return false;
    } 
    if (!this.open.get())
      if (autoOpen) {
        open();
      } else {
        return false;
      }  
    return true;
  }
  
  public static List<Webcam> getWebcams() throws WebcamException {
    try {
      return getWebcams(Long.MAX_VALUE);
    } catch (TimeoutException e) {
      throw new RuntimeException(e);
    } 
  }
  
  public static List<Webcam> getWebcams(long timeout) throws TimeoutException, WebcamException {
    if (timeout < 0L)
      throw new IllegalArgumentException(String.format("Timeout cannot be negative (%d)", new Object[] { Long.valueOf(timeout) })); 
    return getWebcams(timeout, TimeUnit.MILLISECONDS);
  }
  
  public static synchronized List<Webcam> getWebcams(long timeout, TimeUnit tunit) throws TimeoutException, WebcamException {
    if (timeout < 0L)
      throw new IllegalArgumentException(String.format("Timeout cannot be negative (%d)", new Object[] { Long.valueOf(timeout) })); 
    if (tunit == null)
      throw new IllegalArgumentException("Time unit cannot be null!"); 
    WebcamDiscoveryService discovery = getDiscoveryService();
    assert discovery != null;
    List<Webcam> webcams = discovery.getWebcams(timeout, tunit);
    if (!discovery.isRunning())
      discovery.start(); 
    return webcams;
  }
  
  public static Webcam getDefault() throws WebcamException {
    try {
      return getDefault(Long.MAX_VALUE);
    } catch (TimeoutException e) {
      throw new RuntimeException(e);
    } 
  }
  
  public static Webcam getDefault(long timeout) throws TimeoutException, WebcamException {
    if (timeout < 0L)
      throw new IllegalArgumentException(String.format("Timeout cannot be negative (%d)", new Object[] { Long.valueOf(timeout) })); 
    return getDefault(timeout, TimeUnit.MILLISECONDS);
  }
  
  public static Webcam getDefault(long timeout, TimeUnit tunit) throws TimeoutException, WebcamException {
    if (timeout < 0L)
      throw new IllegalArgumentException(String.format("Timeout cannot be negative (%d)", new Object[] { Long.valueOf(timeout) })); 
    if (tunit == null)
      throw new IllegalArgumentException("Time unit cannot be null!"); 
    List<Webcam> webcams = getWebcams(timeout, tunit);
    assert webcams != null;
    if (!webcams.isEmpty())
      return webcams.get(0); 
    LOG.warn("No webcam has been detected!");
    return null;
  }
  
  public String getName() {
    assert this.device != null;
    return this.device.getName();
  }
  
  public String toString() {
    return String.format("Webcam %s", new Object[] { getName() });
  }
  
  public boolean addWebcamListener(WebcamListener l) {
    if (l == null)
      throw new IllegalArgumentException("Webcam listener cannot be null!"); 
    assert this.listeners != null;
    return this.listeners.add(l);
  }
  
  public WebcamListener[] getWebcamListeners() {
    assert this.listeners != null;
    return this.listeners.<WebcamListener>toArray(new WebcamListener[this.listeners.size()]);
  }
  
  public int getWebcamListenersCount() {
    assert this.listeners != null;
    return this.listeners.size();
  }
  
  public boolean removeWebcamListener(WebcamListener l) {
    assert this.listeners != null;
    return this.listeners.remove(l);
  }
  
  public static synchronized WebcamDriver getDriver() {
    if (driver != null)
      return driver; 
    if (driver == null)
      driver = WebcamDriverUtils.findDriver(DRIVERS_LIST, DRIVERS_CLASS_LIST); 
    if (driver == null)
      driver = (WebcamDriver)new WebcamDefaultDriver(); 
    LOG.info("{} capture driver will be used", driver.getClass().getSimpleName());
    return driver;
  }
  
  public static void setDriver(WebcamDriver wd) {
    if (wd == null)
      throw new IllegalArgumentException("Webcam driver cannot be null!"); 
    LOG.debug("Setting new capture driver {}", wd);
    resetDriver();
    driver = wd;
  }
  
  public static void setDriver(Class<? extends WebcamDriver> driverClass) {
    if (driverClass == null)
      throw new IllegalArgumentException("Webcam driver class cannot be null!"); 
    resetDriver();
    try {
      driver = driverClass.newInstance();
    } catch (InstantiationException e) {
      throw new WebcamException(e);
    } catch (IllegalAccessException e) {
      throw new WebcamException(e);
    } 
  }
  
  public static void resetDriver() {
    synchronized (DRIVERS_LIST) {
      DRIVERS_LIST.clear();
    } 
    if (discovery != null) {
      discovery.shutdown();
      discovery = null;
    } 
    driver = null;
  }
  
  public static void registerDriver(Class<? extends WebcamDriver> clazz) {
    if (clazz == null)
      throw new IllegalArgumentException("Webcam driver class to register cannot be null!"); 
    DRIVERS_CLASS_LIST.add(clazz);
    registerDriver(clazz.getCanonicalName());
  }
  
  public static void registerDriver(String clazzName) {
    if (clazzName == null)
      throw new IllegalArgumentException("Webcam driver class name to register cannot be null!"); 
    DRIVERS_LIST.add(clazzName);
  }
  
  public static void setHandleTermSignal(boolean on) {
    if (on)
      LOG.warn("Automated deallocation on TERM signal is now enabled! Make sure to not use it in production!"); 
    deallocOnTermSignal = on;
  }
  
  public static boolean isHandleTermSignal() {
    return deallocOnTermSignal;
  }
  
  public static void setAutoOpenMode(boolean on) {
    autoOpen = on;
  }
  
  public static boolean isAutoOpenMode() {
    return autoOpen;
  }
  
  public static boolean addDiscoveryListener(WebcamDiscoveryListener l) {
    if (l == null)
      throw new IllegalArgumentException("Webcam discovery listener cannot be null!"); 
    return DISCOVERY_LISTENERS.add(l);
  }
  
  public static WebcamDiscoveryListener[] getDiscoveryListeners() {
    return DISCOVERY_LISTENERS.<WebcamDiscoveryListener>toArray(new WebcamDiscoveryListener[DISCOVERY_LISTENERS.size()]);
  }
  
  public static boolean removeDiscoveryListener(WebcamDiscoveryListener l) {
    return DISCOVERY_LISTENERS.remove(l);
  }
  
  public static synchronized WebcamDiscoveryService getDiscoveryService() {
    if (discovery == null)
      discovery = new WebcamDiscoveryService(getDriver()); 
    return discovery;
  }
  
  public static synchronized WebcamDiscoveryService getDiscoveryServiceRef() {
    return discovery;
  }
  
  public WebcamImageTransformer getImageTransformer() {
    return this.transformer;
  }
  
  public void setImageTransformer(WebcamImageTransformer transformer) {
    this.transformer = transformer;
  }
  
  public WebcamLock getLock() {
    return this.lock;
  }
  
  protected static void shutdown() {
    WebcamDiscoveryService discovery = getDiscoveryServiceRef();
    if (discovery != null)
      discovery.stop(); 
    WebcamProcessor.getInstance().shutdown();
  }
  
  public static Webcam getWebcamByName(String name) {
    if (name == null)
      throw new IllegalArgumentException("Webcam name cannot be null"); 
    for (Webcam webcam : getWebcams()) {
      if (webcam.getName().equals(name))
        return webcam; 
    } 
    return null;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\Webcam.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */