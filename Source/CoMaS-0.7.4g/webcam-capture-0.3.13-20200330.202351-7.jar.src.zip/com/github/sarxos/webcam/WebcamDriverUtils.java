package com.github.sarxos.webcam;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WebcamDriverUtils {
  private static final Logger LOG = LoggerFactory.getLogger(WebcamDriverUtils.class);
  
  protected static WebcamDriver findDriver(List<String> names, List<Class<?>> classes) {
    for (String name : names) {
      LOG.info("Searching driver {}", name);
      Class<?> clazz = null;
      for (Class<?> c : classes) {
        if (c.getCanonicalName().equals(name)) {
          clazz = c;
          break;
        } 
      } 
      if (clazz == null)
        try {
          clazz = Class.forName(name);
        } catch (ClassNotFoundException e) {
          LOG.trace("Class not found {}, fall thru", name);
        }  
      if (clazz == null) {
        LOG.debug("Driver {} not found", name);
        continue;
      } 
      LOG.info("Webcam driver {} has been found", name);
      try {
        return (WebcamDriver)clazz.newInstance();
      } catch (InstantiationException e) {
        throw new RuntimeException(e);
      } catch (IllegalAccessException e) {
        throw new RuntimeException(e);
      } 
    } 
    return null;
  }
  
  protected static Class<?>[] getClasses(String pkgname, boolean flat) {
    List<File> dirs = new ArrayList<>();
    List<Class<?>> classes = new ArrayList<>();
    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    String path = pkgname.replace('.', '/');
    Enumeration<URL> resources = null;
    try {
      resources = classLoader.getResources(path);
    } catch (IOException e) {
      throw new RuntimeException("Cannot read path " + path, e);
    } 
    while (resources.hasMoreElements()) {
      URL resource = resources.nextElement();
      dirs.add(new File(resource.getFile()));
    } 
    for (File directory : dirs) {
      try {
        classes.addAll(findClasses(directory, pkgname, flat));
      } catch (ClassNotFoundException e) {
        throw new RuntimeException("Class not found", e);
      } 
    } 
    return (Class[])classes.<Class<?>[]>toArray((Class<?>[][])new Class[classes.size()]);
  }
  
  private static List<Class<?>> findClasses(File dir, String pkgname, boolean flat) throws ClassNotFoundException {
    List<Class<?>> classes = new ArrayList<>();
    if (!dir.exists())
      return classes; 
    File[] files = dir.listFiles();
    for (File file : files) {
      if (file.isDirectory() && !flat) {
        classes.addAll(findClasses(file, pkgname + "." + file.getName(), flat));
      } else if (file.getName().endsWith(".class")) {
        classes.add(Class.forName(pkgname + '.' + file.getName().substring(0, file.getName().length() - 6)));
      } 
    } 
    return classes;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamDriverUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */