/*     */ package com.github.sarxos.webcam;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebcamDriverUtils
/*     */ {
/*  16 */   private static final Logger LOG = LoggerFactory.getLogger(WebcamDriverUtils.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static WebcamDriver findDriver(List<String> names, List<Class<?>> classes) {
/*  31 */     for (String name : names) {
/*     */       
/*  33 */       LOG.info("Searching driver {}", name);
/*     */       
/*  35 */       Class<?> clazz = null;
/*     */       
/*  37 */       for (Class<?> c : classes) {
/*  38 */         if (c.getCanonicalName().equals(name)) {
/*  39 */           clazz = c;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*  44 */       if (clazz == null) {
/*     */         try {
/*  46 */           clazz = Class.forName(name);
/*  47 */         } catch (ClassNotFoundException e) {
/*  48 */           LOG.trace("Class not found {}, fall thru", name);
/*     */         } 
/*     */       }
/*     */       
/*  52 */       if (clazz == null) {
/*  53 */         LOG.debug("Driver {} not found", name);
/*     */         
/*     */         continue;
/*     */       } 
/*  57 */       LOG.info("Webcam driver {} has been found", name);
/*     */       
/*     */       try {
/*  60 */         return (WebcamDriver)clazz.newInstance();
/*  61 */       } catch (InstantiationException e) {
/*  62 */         throw new RuntimeException(e);
/*  63 */       } catch (IllegalAccessException e) {
/*  64 */         throw new RuntimeException(e);
/*     */       } 
/*     */     } 
/*     */     
/*  68 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Class<?>[] getClasses(String pkgname, boolean flat) {
/*  83 */     List<File> dirs = new ArrayList<>();
/*  84 */     List<Class<?>> classes = new ArrayList<>();
/*     */     
/*  86 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*  87 */     String path = pkgname.replace('.', '/');
/*     */     
/*  89 */     Enumeration<URL> resources = null;
/*     */     try {
/*  91 */       resources = classLoader.getResources(path);
/*  92 */     } catch (IOException e) {
/*  93 */       throw new RuntimeException("Cannot read path " + path, e);
/*     */     } 
/*     */     
/*  96 */     while (resources.hasMoreElements()) {
/*  97 */       URL resource = resources.nextElement();
/*  98 */       dirs.add(new File(resource.getFile()));
/*     */     } 
/*     */     
/* 101 */     for (File directory : dirs) {
/*     */       try {
/* 103 */         classes.addAll(findClasses(directory, pkgname, flat));
/* 104 */       } catch (ClassNotFoundException e) {
/* 105 */         throw new RuntimeException("Class not found", e);
/*     */       } 
/*     */     } 
/*     */     
/* 109 */     return (Class[])classes.<Class<?>[]>toArray((Class<?>[][])new Class[classes.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<Class<?>> findClasses(File dir, String pkgname, boolean flat) throws ClassNotFoundException {
/* 124 */     List<Class<?>> classes = new ArrayList<>();
/* 125 */     if (!dir.exists()) {
/* 126 */       return classes;
/*     */     }
/*     */     
/* 129 */     File[] files = dir.listFiles();
/* 130 */     for (File file : files) {
/* 131 */       if (file.isDirectory() && !flat) {
/* 132 */         classes.addAll(findClasses(file, pkgname + "." + file.getName(), flat));
/* 133 */       } else if (file.getName().endsWith(".class")) {
/* 134 */         classes.add(Class.forName(pkgname + '.' + file.getName().substring(0, file.getName().length() - 6)));
/*     */       } 
/*     */     } 
/*     */     
/* 138 */     return classes;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamDriverUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */