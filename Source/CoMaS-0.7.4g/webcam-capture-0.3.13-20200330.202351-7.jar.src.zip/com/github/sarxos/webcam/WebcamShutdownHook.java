/*    */ package com.github.sarxos.webcam;
/*    */ 
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WebcamShutdownHook
/*    */   extends Thread
/*    */ {
/* 18 */   private static final Logger LOG = LoggerFactory.getLogger(WebcamShutdownHook.class);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 23 */   private static int number = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 28 */   private Webcam webcam = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected WebcamShutdownHook(Webcam webcam) {
/* 36 */     super("shutdown-hook-" + ++number);
/* 37 */     this.webcam = webcam;
/* 38 */     setUncaughtExceptionHandler(WebcamExceptionHandler.getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   public void run() {
/* 43 */     LOG.info("Automatic {} deallocation", this.webcam.getName());
/* 44 */     this.webcam.dispose();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamShutdownHook.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */