package com.github.sarxos.webcam;

import java.awt.Component;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

public class WebcamPickerCellRenderer extends JLabel implements ListCellRenderer<Webcam> {
  private static final long serialVersionUID = 1L;
  
  private static final ImageIcon ICON = new ImageIcon(WebcamPickerCellRenderer.class.getResource("/com/github/sarxos/webcam/icons/camera-icon.png"));
  
  public WebcamPickerCellRenderer() {
    setOpaque(true);
    setHorizontalAlignment(2);
    setVerticalAlignment(0);
    setIcon(ICON);
  }
  
  public Component getListCellRendererComponent(JList<? extends Webcam> list, Webcam webcam, int i, boolean selected, boolean focused) {
    if (selected) {
      setBackground(list.getSelectionBackground());
      setForeground(list.getSelectionForeground());
    } else {
      setBackground(list.getBackground());
      setForeground(list.getForeground());
    } 
    setText(webcam.getName());
    setFont(list.getFont());
    return this;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamPickerCellRenderer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */