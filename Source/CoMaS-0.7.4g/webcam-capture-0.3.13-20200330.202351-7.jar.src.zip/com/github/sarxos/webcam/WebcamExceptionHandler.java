/*    */ package com.github.sarxos.webcam;
/*    */ 
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebcamExceptionHandler
/*    */   implements Thread.UncaughtExceptionHandler
/*    */ {
/* 17 */   private static final Logger LOG = LoggerFactory.getLogger(WebcamExceptionHandler.class);
/*    */   
/* 19 */   private static final WebcamExceptionHandler INSTANCE = new WebcamExceptionHandler();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void uncaughtException(Thread t, Throwable e) {
/* 27 */     Object context = LoggerFactory.getILoggerFactory();
/* 28 */     if (context instanceof org.slf4j.helpers.NOPLoggerFactory) {
/* 29 */       System.err.println(String.format("Exception in thread %s", new Object[] { t.getName() }));
/* 30 */       e.printStackTrace();
/*    */     } else {
/* 32 */       LOG.error(String.format("Exception in thread %s", new Object[] { t.getName() }), e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void handle(Throwable e) {
/* 37 */     INSTANCE.uncaughtException(Thread.currentThread(), e);
/*    */   }
/*    */   
/*    */   public static final WebcamExceptionHandler getInstance() {
/* 41 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamExceptionHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */