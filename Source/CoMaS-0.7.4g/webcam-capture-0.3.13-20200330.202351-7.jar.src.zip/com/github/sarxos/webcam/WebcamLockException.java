package com.github.sarxos.webcam;

public class WebcamLockException extends WebcamException {
  private static final long serialVersionUID = 1L;
  
  public WebcamLockException(String message, Throwable cause) {
    super(message, cause);
  }
  
  public WebcamLockException(String message) {
    super(message);
  }
  
  public WebcamLockException(Throwable cause) {
    super(cause);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamLockException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */