package com.github.sarxos.webcam;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

public interface WebcamMotionDetectorAlgorithm {
  BufferedImage filter(BufferedImage paramBufferedImage);
  
  boolean detect(BufferedImage paramBufferedImage1, BufferedImage paramBufferedImage2);
  
  Point getCog();
  
  double getArea();
  
  void setPointRange(int paramInt);
  
  void setMaxPoints(int paramInt);
  
  int getPointRange();
  
  int getMaxPoints();
  
  ArrayList<Point> getPoints();
  
  void setDoNotEngageZones(List<Rectangle> paramList);
}
