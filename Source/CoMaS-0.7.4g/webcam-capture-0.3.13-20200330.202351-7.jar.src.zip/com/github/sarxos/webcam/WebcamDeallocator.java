/*    */ package com.github.sarxos.webcam;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WebcamDeallocator
/*    */ {
/* 16 */   private static final WebcamSignalHandler HANDLER = new WebcamSignalHandler();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final Webcam[] webcams;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private WebcamDeallocator(Webcam[] devices) {
/* 27 */     this.webcams = devices;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected static void store(Webcam[] webcams) {
/* 36 */     if (HANDLER.get() == null) {
/* 37 */       HANDLER.set(new WebcamDeallocator(webcams));
/*    */     } else {
/* 39 */       throw new IllegalStateException("Deallocator is already set!");
/*    */     } 
/*    */   }
/*    */   
/*    */   protected static void unstore() {
/* 44 */     HANDLER.reset();
/*    */   }
/*    */   
/*    */   protected void deallocate() {
/* 48 */     for (Webcam w : this.webcams) {
/*    */       try {
/* 50 */         w.dispose();
/* 51 */       } catch (Throwable t) {
/* 52 */         caugh(t);
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   private void caugh(Throwable t) {
/* 58 */     File f = new File(String.format("webcam-capture-hs-%s", new Object[] { Long.valueOf(System.currentTimeMillis()) }));
/* 59 */     PrintStream ps = null;
/*    */     try {
/* 61 */       t.printStackTrace(ps = new PrintStream(f));
/* 62 */     } catch (FileNotFoundException e) {
/* 63 */       e.printStackTrace();
/*    */     } finally {
/* 65 */       if (ps != null)
/* 66 */         ps.close(); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamDeallocator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */