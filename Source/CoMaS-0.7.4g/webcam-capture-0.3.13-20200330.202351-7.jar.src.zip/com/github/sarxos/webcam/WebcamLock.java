/*     */ package com.github.sarxos.webcam;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebcamLock
/*     */ {
/*  30 */   private static final Logger LOG = LoggerFactory.getLogger(WebcamLock.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public static final long INTERVAL = 2000L;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Webcam webcam;
/*     */ 
/*     */ 
/*     */   
/*     */   private class LockUpdater
/*     */     extends Thread
/*     */   {
/*     */     public LockUpdater() {
/*  46 */       setName(String.format("webcam-lock-[%s]", new Object[] { WebcamLock.access$000(this$0).getName() }));
/*  47 */       setDaemon(true);
/*  48 */       setUncaughtExceptionHandler(WebcamExceptionHandler.getInstance());
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/*     */       do {
/*  54 */         if (WebcamLock.this.disabled.get()) {
/*     */           return;
/*     */         }
/*  57 */         WebcamLock.this.update();
/*     */         try {
/*  59 */           Thread.sleep(2000L);
/*  60 */         } catch (InterruptedException e) {
/*  61 */           WebcamLock.LOG.debug("Lock updater has been interrupted");
/*     */           return;
/*     */         } 
/*  64 */       } while (WebcamLock.this.locked.get());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   private Thread updater = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private final AtomicBoolean locked = new AtomicBoolean(false);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   private final AtomicBoolean disabled = new AtomicBoolean(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final File lock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected WebcamLock(Webcam webcam) {
/* 101 */     this.webcam = webcam;
/* 102 */     this.lock = new File(System.getProperty("java.io.tmpdir"), getLockName());
/* 103 */     this.lock.deleteOnExit();
/*     */   }
/*     */   
/*     */   private String getLockName() {
/* 107 */     return String.format(".webcam-lock-%d", new Object[] { Integer.valueOf(Math.abs(this.webcam.getName().hashCode())) });
/*     */   }
/*     */ 
/*     */   
/*     */   private void write(long value) {
/* 112 */     if (this.disabled.get()) {
/*     */       return;
/*     */     }
/*     */     
/* 116 */     String name = getLockName();
/*     */     
/* 118 */     File tmp = null;
/* 119 */     DataOutputStream dos = null;
/*     */ 
/*     */     
/*     */     try {
/* 123 */       tmp = File.createTempFile(String.format("%s-tmp", new Object[] { name }), "");
/* 124 */       tmp.deleteOnExit();
/*     */       
/* 126 */       dos = new DataOutputStream(new FileOutputStream(tmp));
/* 127 */       dos.writeLong(value);
/* 128 */       dos.flush();
/*     */     }
/* 130 */     catch (IOException e) {
/* 131 */       throw new RuntimeException(e);
/*     */     } finally {
/* 133 */       if (dos != null) {
/*     */         try {
/* 135 */           dos.close();
/* 136 */         } catch (IOException e) {
/* 137 */           throw new RuntimeException(e);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 142 */     if (!this.locked.get()) {
/*     */       return;
/*     */     }
/*     */     
/* 146 */     if (tmp.renameTo(this.lock)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 157 */     if (!this.lock.exists()) {
/*     */       try {
/* 159 */         if (this.lock.createNewFile()) {
/* 160 */           LOG.info("Lock file {} for {} has been created", this.lock, this.webcam);
/*     */         } else {
/* 162 */           throw new RuntimeException("Not able to create file " + this.lock);
/*     */         } 
/* 164 */       } catch (IOException e) {
/* 165 */         throw new RuntimeException(e);
/*     */       } 
/*     */     }
/*     */     
/* 169 */     FileOutputStream fos = null;
/* 170 */     FileInputStream fis = null;
/*     */     
/* 172 */     int k = 0;
/* 173 */     int n = -1;
/* 174 */     byte[] buffer = new byte[8];
/* 175 */     boolean rewritten = false;
/*     */ 
/*     */ 
/*     */     
/* 179 */     synchronized (this.webcam) {
/*     */       
/*     */       do {
/*     */         try {
/* 183 */           fos = new FileOutputStream(this.lock);
/* 184 */           fis = new FileInputStream(tmp);
/* 185 */           while ((n = fis.read(buffer)) != -1) {
/* 186 */             fos.write(buffer, 0, n);
/*     */           }
/* 188 */           rewritten = true;
/*     */         }
/* 190 */         catch (IOException e) {
/* 191 */           LOG.debug("Not able to rewrite lock file", e);
/*     */         } finally {
/* 193 */           if (fos != null) {
/*     */             try {
/* 195 */               fos.close();
/* 196 */             } catch (IOException e) {
/* 197 */               throw new RuntimeException(e);
/*     */             } 
/*     */           }
/* 200 */           if (fis != null) {
/*     */             try {
/* 202 */               fis.close();
/* 203 */             } catch (IOException e) {
/* 204 */               throw new RuntimeException(e);
/*     */             } 
/*     */           }
/*     */         } 
/* 208 */         if (rewritten) {
/*     */           break;
/*     */         }
/* 211 */       } while (k++ < 5);
/*     */     } 
/*     */     
/* 214 */     if (!rewritten) {
/* 215 */       throw new WebcamException("Not able to write lock file");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 220 */     if (!tmp.delete()) {
/* 221 */       tmp.deleteOnExit();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long read() {
/* 229 */     if (this.disabled.get()) {
/* 230 */       return -1L;
/*     */     }
/*     */     
/* 233 */     DataInputStream dis = null;
/*     */     
/* 235 */     long value = -1L;
/* 236 */     boolean broken = false;
/*     */     
/* 238 */     synchronized (this.webcam) {
/*     */       
/*     */       try {
/* 241 */         value = (dis = new DataInputStream(new FileInputStream(this.lock))).readLong();
/* 242 */       } catch (EOFException e) {
/* 243 */         LOG.debug("Webcam lock is broken - EOF when reading long variable from stream", e);
/* 244 */         broken = true;
/* 245 */       } catch (IOException e) {
/* 246 */         throw new RuntimeException(e);
/*     */       } finally {
/* 248 */         if (dis != null) {
/*     */           try {
/* 250 */             dis.close();
/* 251 */           } catch (IOException e) {
/* 252 */             throw new RuntimeException(e);
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 257 */       if (broken) {
/* 258 */         LOG.warn("Lock file {} for {} is broken - recreating it", this.lock, this.webcam);
/* 259 */         write(-1L);
/*     */       } 
/*     */     } 
/*     */     
/* 263 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   private void update() {
/* 268 */     if (this.disabled.get()) {
/*     */       return;
/*     */     }
/*     */     
/* 272 */     write(System.currentTimeMillis());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void lock() {
/* 280 */     if (this.disabled.get()) {
/*     */       return;
/*     */     }
/*     */     
/* 284 */     if (isLocked()) {
/* 285 */       throw new WebcamLockException(String.format("Webcam %s has already been locked", new Object[] { this.webcam.getName() }));
/*     */     }
/*     */     
/* 288 */     if (!this.locked.compareAndSet(false, true)) {
/*     */       return;
/*     */     }
/*     */     
/* 292 */     LOG.debug("Lock {}", this.webcam);
/*     */     
/* 294 */     update();
/*     */     
/* 296 */     this.updater = new LockUpdater();
/* 297 */     this.updater.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disable() {
/* 305 */     if (this.disabled.compareAndSet(false, true)) {
/* 306 */       LOG.info("Locking mechanism has been disabled in {}", this.webcam);
/* 307 */       if (this.updater != null) {
/* 308 */         this.updater.interrupt();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unlock() {
/* 320 */     if (this.disabled.get()) {
/*     */       return;
/*     */     }
/*     */     
/* 324 */     if (!this.locked.compareAndSet(true, false)) {
/*     */       return;
/*     */     }
/*     */     
/* 328 */     LOG.debug("Unlock {}", this.webcam);
/*     */     
/* 330 */     this.updater.interrupt();
/*     */     
/* 332 */     write(-1L);
/*     */     
/* 334 */     if (!this.lock.delete()) {
/* 335 */       this.lock.deleteOnExit();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLocked() {
/* 348 */     if (this.disabled.get()) {
/* 349 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 354 */     if (this.locked.get()) {
/* 355 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 360 */     if (!this.lock.exists()) {
/* 361 */       return false;
/*     */     }
/*     */     
/* 364 */     long now = System.currentTimeMillis();
/* 365 */     long tsp = read();
/*     */     
/* 367 */     LOG.trace("Lock timestamp {} now {} for {}", new Object[] { Long.valueOf(tsp), Long.valueOf(now), this.webcam });
/*     */     
/* 369 */     if (tsp > now - 4000L) {
/* 370 */       return true;
/*     */     }
/*     */     
/* 373 */     return false;
/*     */   }
/*     */   
/*     */   public File getLockFile() {
/* 377 */     return this.lock;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamLock.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */