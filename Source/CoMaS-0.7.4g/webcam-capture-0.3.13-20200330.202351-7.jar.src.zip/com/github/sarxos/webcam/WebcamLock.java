package com.github.sarxos.webcam;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WebcamLock {
  private static final Logger LOG = LoggerFactory.getLogger(WebcamLock.class);
  
  public static final long INTERVAL = 2000L;
  
  private final Webcam webcam;
  
  private class LockUpdater extends Thread {
    public LockUpdater() {
      setName(String.format("webcam-lock-[%s]", new Object[] { WebcamLock.access$000(this$0).getName() }));
      setDaemon(true);
      setUncaughtExceptionHandler(WebcamExceptionHandler.getInstance());
    }
    
    public void run() {
      do {
        if (WebcamLock.this.disabled.get())
          return; 
        WebcamLock.this.update();
        try {
          Thread.sleep(2000L);
        } catch (InterruptedException e) {
          WebcamLock.LOG.debug("Lock updater has been interrupted");
          return;
        } 
      } while (WebcamLock.this.locked.get());
    }
  }
  
  private Thread updater = null;
  
  private final AtomicBoolean locked = new AtomicBoolean(false);
  
  private final AtomicBoolean disabled = new AtomicBoolean(false);
  
  private final File lock;
  
  protected WebcamLock(Webcam webcam) {
    this.webcam = webcam;
    this.lock = new File(System.getProperty("java.io.tmpdir"), getLockName());
    this.lock.deleteOnExit();
  }
  
  private String getLockName() {
    return String.format(".webcam-lock-%d", new Object[] { Integer.valueOf(Math.abs(this.webcam.getName().hashCode())) });
  }
  
  private void write(long value) {
    if (this.disabled.get())
      return; 
    String name = getLockName();
    File tmp = null;
    DataOutputStream dos = null;
    try {
      tmp = File.createTempFile(String.format("%s-tmp", new Object[] { name }), "");
      tmp.deleteOnExit();
      dos = new DataOutputStream(new FileOutputStream(tmp));
      dos.writeLong(value);
      dos.flush();
    } catch (IOException e) {
      throw new RuntimeException(e);
    } finally {
      if (dos != null)
        try {
          dos.close();
        } catch (IOException e) {
          throw new RuntimeException(e);
        }  
    } 
    if (!this.locked.get())
      return; 
    if (tmp.renameTo(this.lock))
      return; 
    if (!this.lock.exists())
      try {
        if (this.lock.createNewFile()) {
          LOG.info("Lock file {} for {} has been created", this.lock, this.webcam);
        } else {
          throw new RuntimeException("Not able to create file " + this.lock);
        } 
      } catch (IOException e) {
        throw new RuntimeException(e);
      }  
    FileOutputStream fos = null;
    FileInputStream fis = null;
    int k = 0;
    int n = -1;
    byte[] buffer = new byte[8];
    boolean rewritten = false;
    synchronized (this.webcam) {
      do {
        try {
          fos = new FileOutputStream(this.lock);
          fis = new FileInputStream(tmp);
          while ((n = fis.read(buffer)) != -1)
            fos.write(buffer, 0, n); 
          rewritten = true;
        } catch (IOException e) {
          LOG.debug("Not able to rewrite lock file", e);
        } finally {
          if (fos != null)
            try {
              fos.close();
            } catch (IOException e) {
              throw new RuntimeException(e);
            }  
          if (fis != null)
            try {
              fis.close();
            } catch (IOException e) {
              throw new RuntimeException(e);
            }  
        } 
        if (rewritten)
          break; 
      } while (k++ < 5);
    } 
    if (!rewritten)
      throw new WebcamException("Not able to write lock file"); 
    if (!tmp.delete())
      tmp.deleteOnExit(); 
  }
  
  private long read() {
    if (this.disabled.get())
      return -1L; 
    DataInputStream dis = null;
    long value = -1L;
    boolean broken = false;
    synchronized (this.webcam) {
      try {
        value = (dis = new DataInputStream(new FileInputStream(this.lock))).readLong();
      } catch (EOFException e) {
        LOG.debug("Webcam lock is broken - EOF when reading long variable from stream", e);
        broken = true;
      } catch (IOException e) {
        throw new RuntimeException(e);
      } finally {
        if (dis != null)
          try {
            dis.close();
          } catch (IOException e) {
            throw new RuntimeException(e);
          }  
      } 
      if (broken) {
        LOG.warn("Lock file {} for {} is broken - recreating it", this.lock, this.webcam);
        write(-1L);
      } 
    } 
    return value;
  }
  
  private void update() {
    if (this.disabled.get())
      return; 
    write(System.currentTimeMillis());
  }
  
  public void lock() {
    if (this.disabled.get())
      return; 
    if (isLocked())
      throw new WebcamLockException(String.format("Webcam %s has already been locked", new Object[] { this.webcam.getName() })); 
    if (!this.locked.compareAndSet(false, true))
      return; 
    LOG.debug("Lock {}", this.webcam);
    update();
    this.updater = new LockUpdater();
    this.updater.start();
  }
  
  public void disable() {
    if (this.disabled.compareAndSet(false, true)) {
      LOG.info("Locking mechanism has been disabled in {}", this.webcam);
      if (this.updater != null)
        this.updater.interrupt(); 
    } 
  }
  
  public void unlock() {
    if (this.disabled.get())
      return; 
    if (!this.locked.compareAndSet(true, false))
      return; 
    LOG.debug("Unlock {}", this.webcam);
    this.updater.interrupt();
    write(-1L);
    if (!this.lock.delete())
      this.lock.deleteOnExit(); 
  }
  
  public boolean isLocked() {
    if (this.disabled.get())
      return false; 
    if (this.locked.get())
      return true; 
    if (!this.lock.exists())
      return false; 
    long now = System.currentTimeMillis();
    long tsp = read();
    LOG.trace("Lock timestamp {} now {} for {}", new Object[] { Long.valueOf(tsp), Long.valueOf(now), this.webcam });
    if (tsp > now - 4000L)
      return true; 
    return false;
  }
  
  public File getLockFile() {
    return this.lock;
  }
}
