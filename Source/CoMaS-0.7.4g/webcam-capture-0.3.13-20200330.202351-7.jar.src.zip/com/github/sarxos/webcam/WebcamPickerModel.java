/*    */ package com.github.sarxos.webcam;
/*    */ 
/*    */ import java.util.List;
/*    */ import javax.swing.DefaultComboBoxModel;
/*    */ 
/*    */ 
/*    */ public class WebcamPickerModel
/*    */   extends DefaultComboBoxModel<Webcam>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public WebcamPickerModel(List<Webcam> webcams) {
/* 13 */     super(webcams.toArray(new Webcam[webcams.size()]));
/*    */   }
/*    */ 
/*    */   
/*    */   public Webcam getSelectedItem() {
/* 18 */     return (Webcam)super.getSelectedItem();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setSelectedItem(Object webcam) {
/* 23 */     if (!(webcam instanceof Webcam)) {
/* 24 */       throw new IllegalArgumentException("Selected object has to be an Webcam instance");
/*    */     }
/* 26 */     super.setSelectedItem(webcam);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamPickerModel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */