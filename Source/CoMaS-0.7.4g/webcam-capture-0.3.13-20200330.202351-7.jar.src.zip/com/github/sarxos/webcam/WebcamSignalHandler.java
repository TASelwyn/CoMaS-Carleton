/*    */ package com.github.sarxos.webcam;
/*    */ 
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ import sun.misc.Signal;
/*    */ import sun.misc.SignalHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WebcamSignalHandler
/*    */   implements SignalHandler
/*    */ {
/* 19 */   private static final Logger LOG = LoggerFactory.getLogger(WebcamSignalHandler.class);
/*    */   
/* 21 */   private WebcamDeallocator deallocator = null;
/*    */   
/* 23 */   private SignalHandler handler = null;
/*    */   
/*    */   public WebcamSignalHandler() {
/* 26 */     this.handler = Signal.handle(new Signal("TERM"), this);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(Signal signal) {
/* 32 */     LOG.warn("Detected signal {} {}, calling deallocator", signal.getName(), Integer.valueOf(signal.getNumber()));
/*    */ 
/*    */     
/* 35 */     if (this.handler == SIG_DFL || this.handler == SIG_IGN) {
/*    */       return;
/*    */     }
/*    */     
/*    */     try {
/* 40 */       this.deallocator.deallocate();
/*    */     } finally {
/* 42 */       this.handler.handle(signal);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void set(WebcamDeallocator deallocator) {
/* 47 */     this.deallocator = deallocator;
/*    */   }
/*    */   
/*    */   public WebcamDeallocator get() {
/* 51 */     return this.deallocator;
/*    */   }
/*    */   
/*    */   public void reset() {
/* 55 */     this.deallocator = null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamSignalHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */