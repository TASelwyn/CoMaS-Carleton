package com.github.sarxos.webcam;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sun.misc.Signal;
import sun.misc.SignalHandler;

final class WebcamSignalHandler implements SignalHandler {
  private static final Logger LOG = LoggerFactory.getLogger(WebcamSignalHandler.class);
  
  private WebcamDeallocator deallocator = null;
  
  private SignalHandler handler = null;
  
  public WebcamSignalHandler() {
    this.handler = Signal.handle(new Signal("TERM"), this);
  }
  
  public void handle(Signal signal) {
    LOG.warn("Detected signal {} {}, calling deallocator", signal.getName(), Integer.valueOf(signal.getNumber()));
    if (this.handler == SIG_DFL || this.handler == SIG_IGN)
      return; 
    try {
      this.deallocator.deallocate();
    } finally {
      this.handler.handle(signal);
    } 
  }
  
  public void set(WebcamDeallocator deallocator) {
    this.deallocator = deallocator;
  }
  
  public WebcamDeallocator get() {
    return this.deallocator;
  }
  
  public void reset() {
    this.deallocator = null;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamSignalHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */