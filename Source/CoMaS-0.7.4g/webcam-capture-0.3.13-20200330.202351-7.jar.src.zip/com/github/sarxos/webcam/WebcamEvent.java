package com.github.sarxos.webcam;

import java.awt.image.BufferedImage;
import java.util.EventObject;

public class WebcamEvent extends EventObject {
  private static final long serialVersionUID = 1L;
  
  private BufferedImage image = null;
  
  private WebcamEventType type = null;
  
  public WebcamEvent(WebcamEventType type, Webcam w) {
    this(type, w, null);
  }
  
  public WebcamEvent(WebcamEventType type, Webcam w, BufferedImage image) {
    super(w);
    this.type = type;
    this.image = image;
  }
  
  public Webcam getSource() {
    return (Webcam)super.getSource();
  }
  
  public BufferedImage getImage() {
    return this.image;
  }
  
  public WebcamEventType getType() {
    return this.type;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */