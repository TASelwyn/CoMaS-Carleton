/*    */ package com.github.sarxos.webcam;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebcamEvent
/*    */   extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 19 */   private BufferedImage image = null;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 24 */   private WebcamEventType type = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WebcamEvent(WebcamEventType type, Webcam w) {
/* 33 */     this(type, w, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WebcamEvent(WebcamEventType type, Webcam w, BufferedImage image) {
/* 44 */     super(w);
/* 45 */     this.type = type;
/* 46 */     this.image = image;
/*    */   }
/*    */ 
/*    */   
/*    */   public Webcam getSource() {
/* 51 */     return (Webcam)super.getSource();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BufferedImage getImage() {
/* 62 */     return this.image;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WebcamEventType getType() {
/* 72 */     return this.type;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */