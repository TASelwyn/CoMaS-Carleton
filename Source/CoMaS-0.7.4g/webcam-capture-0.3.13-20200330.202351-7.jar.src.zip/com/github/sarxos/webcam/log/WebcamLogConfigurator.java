/*    */ package com.github.sarxos.webcam.log;
/*    */ 
/*    */ import ch.qos.logback.classic.LoggerContext;
/*    */ import ch.qos.logback.classic.joran.JoranConfigurator;
/*    */ import ch.qos.logback.core.Context;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebcamLogConfigurator
/*    */ {
/* 23 */   private static final Logger LOG = LoggerFactory.getLogger(WebcamLogConfigurator.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void configure(InputStream is) {
/* 32 */     ClassLoader cl = Thread.currentThread().getContextClassLoader();
/*    */ 
/*    */     
/*    */     try {
/* 36 */       String[] names = { "ch.qos.logback.classic.LoggerContext", "ch.qos.logback.classic.joran.JoranConfigurator" };
/*    */ 
/*    */ 
/*    */       
/* 40 */       for (String name : names) {
/* 41 */         Class.forName(name, false, cl);
/*    */       }
/*    */       
/* 44 */       LoggerContext context = (LoggerContext)LoggerFactory.getILoggerFactory();
/* 45 */       JoranConfigurator configurator = new JoranConfigurator();
/* 46 */       configurator.setContext((Context)context);
/* 47 */       context.reset();
/* 48 */       configurator.doConfigure(is);
/*    */     }
/* 50 */     catch (ClassNotFoundException e) {
/* 51 */       System.err.println("WLogC: Logback JARs are missing in classpath");
/* 52 */     } catch (NoClassDefFoundError e) {
/* 53 */       System.err.println("WLogC: Logback JARs are missing in classpath");
/* 54 */     } catch (Throwable e) {
/* 55 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void configure(File file) {
/* 65 */     FileInputStream fis = null;
/*    */     try {
/* 67 */       fis = new FileInputStream(file);
/* 68 */       configure(fis);
/* 69 */     } catch (FileNotFoundException e) {
/* 70 */       LOG.error("File not found " + file, e);
/* 71 */       e.printStackTrace();
/*    */     } finally {
/* 73 */       if (fis != null) {
/*    */         try {
/* 75 */           fis.close();
/* 76 */         } catch (IOException e) {
/* 77 */           LOG.error("Cannot close file " + file, e);
/* 78 */           e.printStackTrace();
/*    */         } 
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void configure(String file) {
/* 90 */     configure(new File(file));
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\log\WebcamLogConfigurator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */