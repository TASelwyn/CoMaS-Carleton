/*     */ package com.github.sarxos.webcam;
/*     */ 
/*     */ import com.github.sarxos.webcam.ds.cgt.WebcamGetImageTask;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebcamUpdater
/*     */   implements Runnable
/*     */ {
/*     */   public static interface DelayCalculator
/*     */   {
/*     */     long calculateDelay(long param1Long, double param1Double);
/*     */   }
/*     */   
/*     */   public static class DefaultDelayCalculator
/*     */     implements DelayCalculator
/*     */   {
/*     */     public long calculateDelay(long snapshotDuration, double deviceFps) {
/*  62 */       long delay = Math.max(20L - snapshotDuration, 0L);
/*  63 */       return delay;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class UpdaterThreadFactory
/*     */     implements ThreadFactory
/*     */   {
/*     */     private UpdaterThreadFactory() {}
/*     */ 
/*     */     
/*  74 */     private static final AtomicInteger number = new AtomicInteger(0);
/*     */ 
/*     */     
/*     */     public Thread newThread(Runnable r) {
/*  78 */       Thread t = new Thread(r, String.format("webcam-updater-thread-%d", new Object[] { Integer.valueOf(number.incrementAndGet()) }));
/*  79 */       t.setUncaughtExceptionHandler(WebcamExceptionHandler.getInstance());
/*  80 */       t.setDaemon(true);
/*  81 */       return t;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   private static final Logger LOG = LoggerFactory.getLogger(WebcamUpdater.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int TARGET_FPS = 50;
/*     */ 
/*     */   
/*  96 */   private static final UpdaterThreadFactory THREAD_FACTORY = new UpdaterThreadFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   private ScheduledExecutorService executor = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   private final AtomicReference<BufferedImage> image = new AtomicReference<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   private Webcam webcam = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   private volatile double fps = 0.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   private AtomicBoolean running = new AtomicBoolean(false);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile boolean imageNew = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private final DelayCalculator delayCalculator;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected WebcamUpdater(Webcam webcam) {
/* 136 */     this(webcam, new DefaultDelayCalculator());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebcamUpdater(Webcam webcam, DelayCalculator delayCalculator) {
/* 146 */     this.webcam = webcam;
/* 147 */     if (delayCalculator == null) {
/* 148 */       this.delayCalculator = new DefaultDelayCalculator();
/*     */     } else {
/* 150 */       this.delayCalculator = delayCalculator;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 159 */     if (this.running.compareAndSet(false, true)) {
/*     */       
/* 161 */       this.image.set((new WebcamGetImageTask(Webcam.getDriver(), this.webcam.getDevice())).getImage());
/*     */       
/* 163 */       this.executor = Executors.newSingleThreadScheduledExecutor(THREAD_FACTORY);
/* 164 */       this.executor.execute(this);
/*     */       
/* 166 */       LOG.debug("Webcam updater has been started");
/*     */     } else {
/* 168 */       LOG.debug("Webcam updater is already started");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 176 */     if (this.running.compareAndSet(true, false)) {
/*     */       
/* 178 */       this.executor.shutdown();
/* 179 */       while (!this.executor.isTerminated()) {
/*     */         try {
/* 181 */           this.executor.awaitTermination(100L, TimeUnit.MILLISECONDS);
/* 182 */         } catch (InterruptedException e) {
/*     */           return;
/*     */         } 
/*     */       } 
/*     */       
/* 187 */       LOG.debug("Webcam updater has been stopped");
/*     */     } else {
/* 189 */       LOG.debug("Webcam updater is already stopped");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 196 */     if (!this.running.get()) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 201 */       tick();
/* 202 */     } catch (Throwable t) {
/* 203 */       WebcamExceptionHandler.handle(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void tick() {
/* 209 */     if (!this.webcam.isOpen()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 215 */     WebcamDriver driver = Webcam.getDriver();
/* 216 */     WebcamDevice device = this.webcam.getDevice();
/*     */     
/* 218 */     assert driver != null;
/* 219 */     assert device != null;
/*     */     
/* 221 */     boolean imageOk = false;
/* 222 */     long t1 = System.currentTimeMillis();
/*     */     try {
/* 224 */       this.image.set(this.webcam.transform((new WebcamGetImageTask(driver, device)).getImage()));
/* 225 */       this.imageNew = true;
/* 226 */       imageOk = true;
/* 227 */     } catch (WebcamException e) {
/* 228 */       WebcamExceptionHandler.handle(e);
/*     */     } 
/* 230 */     long t2 = System.currentTimeMillis();
/*     */     
/* 232 */     double deviceFps = -1.0D;
/* 233 */     if (device instanceof WebcamDevice.FPSSource) {
/* 234 */       deviceFps = ((WebcamDevice.FPSSource)device).getFPS();
/*     */     }
/*     */     
/* 237 */     long duration = t2 - t1;
/* 238 */     long delay = this.delayCalculator.calculateDelay(duration, deviceFps);
/*     */     
/* 240 */     long delta = duration + 1L;
/* 241 */     if (deviceFps >= 0.0D) {
/* 242 */       this.fps = deviceFps;
/*     */     } else {
/* 244 */       this.fps = (4.0D * this.fps + (1000L / delta)) / 5.0D;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 249 */     if (this.webcam.isOpen()) {
/*     */       try {
/* 251 */         this.executor.schedule(this, delay, TimeUnit.MILLISECONDS);
/* 252 */       } catch (RejectedExecutionException e) {
/* 253 */         LOG.trace("Webcam update has been rejected", e);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 259 */     if (imageOk) {
/* 260 */       this.webcam.notifyWebcamImageAcquired(this.image.get());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage getImage() {
/* 275 */     int i = 0;
/* 276 */     while (this.image.get() == null) {
/*     */ 
/*     */       
/*     */       try {
/*     */ 
/*     */ 
/*     */         
/* 283 */         Thread.sleep(100L);
/* 284 */       } catch (InterruptedException e) {
/* 285 */         throw new RuntimeException(e);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 290 */       if (i++ > 100) {
/* 291 */         LOG.error("Image has not been found for more than 10 seconds");
/* 292 */         return null;
/*     */       } 
/*     */     } 
/*     */     
/* 296 */     this.imageNew = false;
/*     */     
/* 298 */     return this.image.get();
/*     */   }
/*     */   
/*     */   protected boolean isImageNew() {
/* 302 */     return this.imageNew;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getFPS() {
/* 312 */     return this.fps;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamUpdater.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */