package com.github.sarxos.webcam.ds.dummy;

import com.github.sarxos.webcam.WebcamDevice;
import com.github.sarxos.webcam.WebcamDiscoverySupport;
import com.github.sarxos.webcam.WebcamDriver;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class WebcamDummyDriver implements WebcamDriver, WebcamDiscoverySupport {
  private int count;
  
  public WebcamDummyDriver(int count) {
    this.count = count;
  }
  
  public long getScanInterval() {
    return 10000L;
  }
  
  public boolean isScanPossible() {
    return true;
  }
  
  public List<WebcamDevice> getDevices() {
    List<WebcamDevice> devices = new ArrayList<>();
    for (int i = 0; i < this.count; i++)
      devices.add(new WebcamDummyDevice(i)); 
    return Collections.unmodifiableList(devices);
  }
  
  public boolean isThreadSafe() {
    return false;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\ds\dummy\WebcamDummyDriver.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */