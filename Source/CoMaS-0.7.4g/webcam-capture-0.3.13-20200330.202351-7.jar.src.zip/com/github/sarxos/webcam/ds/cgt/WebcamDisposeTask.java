/*    */ package com.github.sarxos.webcam.ds.cgt;
/*    */ 
/*    */ import com.github.sarxos.webcam.WebcamDevice;
/*    */ import com.github.sarxos.webcam.WebcamDriver;
/*    */ import com.github.sarxos.webcam.WebcamTask;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebcamDisposeTask
/*    */   extends WebcamTask
/*    */ {
/*    */   public WebcamDisposeTask(WebcamDriver driver, WebcamDevice device) {
/* 16 */     super(driver, device);
/*    */   }
/*    */   
/*    */   public void dispose() throws InterruptedException {
/* 20 */     process();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void handle() {
/* 25 */     getDevice().dispose();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\ds\cgt\WebcamDisposeTask.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */