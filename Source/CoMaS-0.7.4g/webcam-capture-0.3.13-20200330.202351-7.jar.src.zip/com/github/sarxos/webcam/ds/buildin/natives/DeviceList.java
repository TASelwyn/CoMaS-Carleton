package com.github.sarxos.webcam.ds.buildin.natives;

import java.util.ArrayList;
import java.util.List;
import org.bridj.Pointer;
import org.bridj.StructObject;
import org.bridj.ann.Field;
import org.bridj.ann.Library;
import org.bridj.cpp.CPPObject;

@Library("OpenIMAJGrabber")
public class DeviceList extends CPPObject {
  public DeviceList() {}
  
  public DeviceList(Pointer pointer) {
    super(pointer, new Object[0]);
  }
  
  @Field(0)
  protected int nDevices() {
    return this.io.getIntField((StructObject)this, 0);
  }
  
  @Field(0)
  protected DeviceList nDevices(int nDevices) {
    this.io.setIntField((StructObject)this, 0, nDevices);
    return this;
  }
  
  @Field(1)
  protected Pointer<Pointer<Device>> devices() {
    return this.io.getPointerField((StructObject)this, 1);
  }
  
  @Field(1)
  protected DeviceList devices(Pointer<Pointer<Device>> devices) {
    this.io.setPointerField((StructObject)this, 1, devices);
    return this;
  }
  
  public native int getNumDevices();
  
  public native Pointer<Device> getDevice(int paramInt);
  
  public List<Device> asArrayList() {
    List<Device> devices = new ArrayList<>();
    for (int i = 0; i < getNumDevices(); i++)
      devices.add(getDevice(i).get()); 
    return devices;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\ds\buildin\natives\DeviceList.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */