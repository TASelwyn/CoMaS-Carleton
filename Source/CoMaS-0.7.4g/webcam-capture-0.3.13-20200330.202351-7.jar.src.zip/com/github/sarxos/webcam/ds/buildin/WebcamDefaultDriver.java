/*     */ package com.github.sarxos.webcam.ds.buildin;
/*     */ 
/*     */ import com.github.sarxos.webcam.WebcamDevice;
/*     */ import com.github.sarxos.webcam.WebcamDiscoverySupport;
/*     */ import com.github.sarxos.webcam.WebcamDriver;
/*     */ import com.github.sarxos.webcam.WebcamTask;
/*     */ import com.github.sarxos.webcam.ds.buildin.natives.Device;
/*     */ import com.github.sarxos.webcam.ds.buildin.natives.DeviceList;
/*     */ import com.github.sarxos.webcam.ds.buildin.natives.OpenIMAJGrabber;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.bridj.Pointer;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebcamDefaultDriver
/*     */   implements WebcamDriver, WebcamDiscoverySupport
/*     */ {
/*     */   static {
/*  30 */     if (!"true".equals(System.getProperty("webcam.debug")))
/*  31 */       System.setProperty("bridj.quiet", "true"); 
/*     */   }
/*     */   
/*     */   private static class WebcamNewGrabberTask
/*     */     extends WebcamTask
/*     */   {
/*  37 */     private AtomicReference<OpenIMAJGrabber> grabber = new AtomicReference<>();
/*     */     
/*     */     public WebcamNewGrabberTask(WebcamDriver driver) {
/*  40 */       super(driver, null);
/*     */     }
/*     */     
/*     */     public OpenIMAJGrabber newGrabber() {
/*     */       try {
/*  45 */         process();
/*  46 */       } catch (InterruptedException e) {
/*  47 */         WebcamDefaultDriver.LOG.error("Processor has been interrupted");
/*  48 */         return null;
/*     */       } 
/*  50 */       return this.grabber.get();
/*     */     }
/*     */ 
/*     */     
/*     */     protected void handle() {
/*  55 */       this.grabber.set(new OpenIMAJGrabber());
/*     */     }
/*     */   }
/*     */   
/*     */   private static class GetDevicesTask
/*     */     extends WebcamTask {
/*  61 */     private volatile List<WebcamDevice> devices = null;
/*  62 */     private volatile OpenIMAJGrabber grabber = null;
/*     */     
/*     */     public GetDevicesTask(WebcamDriver driver) {
/*  65 */       super(driver, null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<WebcamDevice> getDevices(OpenIMAJGrabber grabber) {
/*  76 */       this.grabber = grabber;
/*     */       
/*     */       try {
/*  79 */         process();
/*  80 */       } catch (InterruptedException e) {
/*  81 */         WebcamDefaultDriver.LOG.error("Processor has been interrupted");
/*  82 */         return Collections.emptyList();
/*     */       } 
/*     */       
/*  85 */       return this.devices;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected void handle() {
/*  91 */       this.devices = new ArrayList<>();
/*     */       
/*  93 */       Pointer<DeviceList> pointer = this.grabber.getVideoDevices();
/*  94 */       DeviceList list = (DeviceList)pointer.get();
/*     */       
/*  96 */       for (Device device : list.asArrayList()) {
/*  97 */         this.devices.add(new WebcamDefaultDevice(device));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   private static final Logger LOG = LoggerFactory.getLogger(WebcamDefaultDriver.class);
/*     */   
/* 107 */   private static OpenIMAJGrabber grabber = null;
/*     */ 
/*     */ 
/*     */   
/*     */   public List<WebcamDevice> getDevices() {
/* 112 */     LOG.debug("Searching devices");
/*     */     
/* 114 */     if (grabber == null) {
/*     */       
/* 116 */       WebcamNewGrabberTask task = new WebcamNewGrabberTask(this);
/* 117 */       grabber = task.newGrabber();
/*     */       
/* 119 */       if (grabber == null) {
/* 120 */         return Collections.emptyList();
/*     */       }
/*     */     } 
/*     */     
/* 124 */     List<WebcamDevice> devices = (new GetDevicesTask(this)).getDevices(grabber);
/*     */     
/* 126 */     if (LOG.isDebugEnabled()) {
/* 127 */       for (WebcamDevice device : devices) {
/* 128 */         LOG.debug("Found device {}", device.getName());
/*     */       }
/*     */     }
/*     */     
/* 132 */     return devices;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getScanInterval() {
/* 137 */     return 3000L;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isScanPossible() {
/* 142 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isThreadSafe() {
/* 147 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\ds\buildin\WebcamDefaultDriver.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */