package com.github.sarxos.webcam.ds.cgt;

import com.github.sarxos.webcam.WebcamDevice;
import com.github.sarxos.webcam.WebcamDriver;
import com.github.sarxos.webcam.WebcamTask;
import java.awt.image.BufferedImage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WebcamGetImageTask extends WebcamTask {
  private static final Logger LOG = LoggerFactory.getLogger(WebcamGetImageTask.class);
  
  private volatile BufferedImage image = null;
  
  public WebcamGetImageTask(WebcamDriver driver, WebcamDevice device) {
    super(driver, device);
  }
  
  public BufferedImage getImage() {
    try {
      process();
    } catch (InterruptedException e) {
      LOG.debug("Interrupted exception", e);
      return null;
    } 
    return this.image;
  }
  
  protected void handle() {
    WebcamDevice device = getDevice();
    if (!device.isOpen())
      return; 
    this.image = device.getImage();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\ds\cgt\WebcamGetImageTask.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */