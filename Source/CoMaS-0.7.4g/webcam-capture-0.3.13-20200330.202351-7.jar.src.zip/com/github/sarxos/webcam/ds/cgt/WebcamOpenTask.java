package com.github.sarxos.webcam.ds.cgt;

import com.github.sarxos.webcam.WebcamDevice;
import com.github.sarxos.webcam.WebcamDriver;
import com.github.sarxos.webcam.WebcamTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WebcamOpenTask extends WebcamTask {
  private static final Logger LOG = LoggerFactory.getLogger(WebcamOpenTask.class);
  
  public WebcamOpenTask(WebcamDriver driver, WebcamDevice device) {
    super(driver, device);
  }
  
  public void open() throws InterruptedException {
    process();
  }
  
  protected void handle() {
    WebcamDevice device = getDevice();
    if (device.isOpen())
      return; 
    if (device.getResolution() == null)
      device.setResolution(device.getResolutions()[0]); 
    LOG.info("Opening webcam {}", device.getName());
    device.open();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\ds\cgt\WebcamOpenTask.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */