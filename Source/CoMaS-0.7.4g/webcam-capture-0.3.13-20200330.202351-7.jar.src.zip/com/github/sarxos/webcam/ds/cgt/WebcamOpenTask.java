/*    */ package com.github.sarxos.webcam.ds.cgt;
/*    */ 
/*    */ import com.github.sarxos.webcam.WebcamDevice;
/*    */ import com.github.sarxos.webcam.WebcamDriver;
/*    */ import com.github.sarxos.webcam.WebcamTask;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ public class WebcamOpenTask
/*    */   extends WebcamTask
/*    */ {
/* 13 */   private static final Logger LOG = LoggerFactory.getLogger(WebcamOpenTask.class);
/*    */   
/*    */   public WebcamOpenTask(WebcamDriver driver, WebcamDevice device) {
/* 16 */     super(driver, device);
/*    */   }
/*    */   
/*    */   public void open() throws InterruptedException {
/* 20 */     process();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void handle() {
/* 26 */     WebcamDevice device = getDevice();
/*    */     
/* 28 */     if (device.isOpen()) {
/*    */       return;
/*    */     }
/*    */     
/* 32 */     if (device.getResolution() == null) {
/* 33 */       device.setResolution(device.getResolutions()[0]);
/*    */     }
/*    */     
/* 36 */     LOG.info("Opening webcam {}", device.getName());
/*    */     
/* 38 */     device.open();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\ds\cgt\WebcamOpenTask.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */