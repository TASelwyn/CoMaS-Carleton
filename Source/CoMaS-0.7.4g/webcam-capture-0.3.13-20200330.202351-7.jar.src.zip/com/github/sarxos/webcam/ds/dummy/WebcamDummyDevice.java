/*     */ package com.github.sarxos.webcam.ds.dummy;
/*     */ 
/*     */ import com.github.sarxos.webcam.WebcamDevice;
/*     */ import com.github.sarxos.webcam.WebcamException;
/*     */ import com.github.sarxos.webcam.WebcamResolution;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.GraphicsConfiguration;
/*     */ import java.awt.GraphicsEnvironment;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebcamDummyDevice
/*     */   implements WebcamDevice
/*     */ {
/*  26 */   private static final Dimension[] DIMENSIONS = new Dimension[] { WebcamResolution.QQVGA
/*  27 */       .getSize(), WebcamResolution.QVGA
/*  28 */       .getSize(), WebcamResolution.VGA
/*  29 */       .getSize() };
/*     */ 
/*     */   
/*  32 */   private AtomicBoolean open = new AtomicBoolean(false);
/*  33 */   private Dimension resolution = DIMENSIONS[0];
/*     */   
/*     */   private final String name;
/*     */   
/*     */   byte r;
/*     */   
/*     */   byte g;
/*     */   byte b;
/*     */   
/*     */   public String getName() {
/*  43 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension[] getResolutions() {
/*  48 */     return DIMENSIONS;
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getResolution() {
/*  53 */     return this.resolution;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setResolution(Dimension size) {
/*  58 */     this.resolution = size;
/*     */   }
/*     */   public WebcamDummyDevice(int number) {
/*  61 */     this.r = (byte)(int)(Math.random() * 127.0D);
/*  62 */     this.g = (byte)(int)(Math.random() * 127.0D);
/*  63 */     this.b = (byte)(int)(Math.random() * 127.0D);
/*     */     this.name = "Dummy Webcam " + number;
/*     */   }
/*     */   private void drawRect(Graphics2D g2, int w, int h) {
/*  67 */     int rx = (int)(w * Math.random() / 1.5D);
/*  68 */     int ry = (int)(h * Math.random() / 1.5D);
/*  69 */     int rw = (int)(w * Math.random() / 1.5D);
/*  70 */     int rh = (int)(w * Math.random() / 1.5D);
/*     */     
/*  72 */     g2.setColor(new Color((int)(2.147483647E9D * Math.random())));
/*  73 */     g2.fillRect(rx, ry, rw, rh);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage getImage() {
/*  79 */     if (!isOpen()) {
/*  80 */       throw new WebcamException("Webcam is not open");
/*     */     }
/*     */     
/*     */     try {
/*  84 */       Thread.sleep(33L);
/*  85 */     } catch (InterruptedException e) {
/*  86 */       return null;
/*     */     } 
/*     */     
/*  89 */     Dimension resolution = getResolution();
/*     */     
/*  91 */     int w = resolution.width;
/*  92 */     int h = resolution.height;
/*     */     
/*  94 */     String s = getName();
/*     */     
/*  96 */     GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
/*  97 */     GraphicsConfiguration gc = ge.getDefaultScreenDevice().getDefaultConfiguration();
/*  98 */     BufferedImage bi = gc.createCompatibleImage(w, h);
/*     */     
/* 100 */     Graphics2D g2 = ge.createGraphics(bi);
/* 101 */     this.r = (byte)(this.r + 1); this.g = (byte)(this.g + 1); this.b = (byte)(this.b + 1); g2.setBackground(new Color(Math.abs(this.r), Math.abs(this.g), Math.abs(this.b)));
/* 102 */     g2.clearRect(0, 0, w, h);
/*     */     
/* 104 */     drawRect(g2, w, h);
/* 105 */     drawRect(g2, w, h);
/* 106 */     drawRect(g2, w, h);
/* 107 */     drawRect(g2, w, h);
/* 108 */     drawRect(g2, w, h);
/*     */     
/* 110 */     Font font = new Font("sans-serif", 1, 16);
/*     */     
/* 112 */     g2.setFont(font);
/*     */     
/* 114 */     FontMetrics metrics = g2.getFontMetrics(font);
/* 115 */     int sw = (w - metrics.stringWidth(s)) / 2;
/* 116 */     int sh = (h - metrics.getHeight()) / 2 + metrics.getHeight() / 2;
/*     */     
/* 118 */     g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 119 */     g2.setColor(Color.BLACK);
/* 120 */     g2.drawString(s, sw + 1, sh + 1);
/* 121 */     g2.setColor(Color.WHITE);
/* 122 */     g2.drawString(s, sw, sh);
/*     */     
/* 124 */     g2.dispose();
/* 125 */     bi.flush();
/*     */     
/* 127 */     return bi;
/*     */   }
/*     */ 
/*     */   
/*     */   public void open() {
/* 132 */     if (this.open.compareAndSet(false, true));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 139 */     if (this.open.compareAndSet(true, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 146 */     close();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/* 151 */     return this.open.get();
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\ds\dummy\WebcamDummyDevice.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */