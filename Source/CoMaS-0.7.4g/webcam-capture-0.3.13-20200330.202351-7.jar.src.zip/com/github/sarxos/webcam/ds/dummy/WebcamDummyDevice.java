package com.github.sarxos.webcam.ds.dummy;

import com.github.sarxos.webcam.WebcamDevice;
import com.github.sarxos.webcam.WebcamException;
import com.github.sarxos.webcam.WebcamResolution;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.util.concurrent.atomic.AtomicBoolean;

public class WebcamDummyDevice implements WebcamDevice {
  private static final Dimension[] DIMENSIONS = new Dimension[] { WebcamResolution.QQVGA
      .getSize(), WebcamResolution.QVGA
      .getSize(), WebcamResolution.VGA
      .getSize() };
  
  private AtomicBoolean open = new AtomicBoolean(false);
  
  private Dimension resolution = DIMENSIONS[0];
  
  private final String name;
  
  byte r;
  
  byte g;
  
  byte b;
  
  public String getName() {
    return this.name;
  }
  
  public Dimension[] getResolutions() {
    return DIMENSIONS;
  }
  
  public Dimension getResolution() {
    return this.resolution;
  }
  
  public void setResolution(Dimension size) {
    this.resolution = size;
  }
  
  public WebcamDummyDevice(int number) {
    this.r = (byte)(int)(Math.random() * 127.0D);
    this.g = (byte)(int)(Math.random() * 127.0D);
    this.b = (byte)(int)(Math.random() * 127.0D);
    this.name = "Dummy Webcam " + number;
  }
  
  private void drawRect(Graphics2D g2, int w, int h) {
    int rx = (int)(w * Math.random() / 1.5D);
    int ry = (int)(h * Math.random() / 1.5D);
    int rw = (int)(w * Math.random() / 1.5D);
    int rh = (int)(w * Math.random() / 1.5D);
    g2.setColor(new Color((int)(2.147483647E9D * Math.random())));
    g2.fillRect(rx, ry, rw, rh);
  }
  
  public BufferedImage getImage() {
    if (!isOpen())
      throw new WebcamException("Webcam is not open"); 
    try {
      Thread.sleep(33L);
    } catch (InterruptedException e) {
      return null;
    } 
    Dimension resolution = getResolution();
    int w = resolution.width;
    int h = resolution.height;
    String s = getName();
    GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
    GraphicsConfiguration gc = ge.getDefaultScreenDevice().getDefaultConfiguration();
    BufferedImage bi = gc.createCompatibleImage(w, h);
    Graphics2D g2 = ge.createGraphics(bi);
    this.r = (byte)(this.r + 1);
    this.g = (byte)(this.g + 1);
    this.b = (byte)(this.b + 1);
    g2.setBackground(new Color(Math.abs(this.r), Math.abs(this.g), Math.abs(this.b)));
    g2.clearRect(0, 0, w, h);
    drawRect(g2, w, h);
    drawRect(g2, w, h);
    drawRect(g2, w, h);
    drawRect(g2, w, h);
    drawRect(g2, w, h);
    Font font = new Font("sans-serif", 1, 16);
    g2.setFont(font);
    FontMetrics metrics = g2.getFontMetrics(font);
    int sw = (w - metrics.stringWidth(s)) / 2;
    int sh = (h - metrics.getHeight()) / 2 + metrics.getHeight() / 2;
    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    g2.setColor(Color.BLACK);
    g2.drawString(s, sw + 1, sh + 1);
    g2.setColor(Color.WHITE);
    g2.drawString(s, sw, sh);
    g2.dispose();
    bi.flush();
    return bi;
  }
  
  public void open() {
    if (this.open.compareAndSet(false, true));
  }
  
  public void close() {
    if (this.open.compareAndSet(true, false));
  }
  
  public void dispose() {
    close();
  }
  
  public boolean isOpen() {
    return this.open.get();
  }
}
