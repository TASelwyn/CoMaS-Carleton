/*    */ package com.github.sarxos.webcam.ds.cgt;
/*    */ 
/*    */ import com.github.sarxos.webcam.WebcamDevice;
/*    */ import com.github.sarxos.webcam.WebcamDriver;
/*    */ import com.github.sarxos.webcam.WebcamTask;
/*    */ import java.nio.ByteBuffer;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebcamGetBufferTask
/*    */   extends WebcamTask
/*    */ {
/* 16 */   private static final Logger LOG = LoggerFactory.getLogger(WebcamGetBufferTask.class);
/*    */   
/* 18 */   private volatile ByteBuffer buffer = null;
/*    */   
/*    */   public WebcamGetBufferTask(WebcamDriver driver, WebcamDevice device) {
/* 21 */     super(driver, device);
/*    */   }
/*    */   
/*    */   public ByteBuffer getBuffer() {
/*    */     try {
/* 26 */       process();
/* 27 */     } catch (InterruptedException e) {
/* 28 */       LOG.debug("Image buffer request interrupted", e);
/* 29 */       return null;
/*    */     } 
/* 31 */     return this.buffer;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void handle() {
/* 37 */     WebcamDevice device = getDevice();
/* 38 */     if (!device.isOpen()) {
/*    */       return;
/*    */     }
/*    */     
/* 42 */     if (!(device instanceof WebcamDevice.BufferAccess)) {
/*    */       return;
/*    */     }
/*    */     
/* 46 */     this.buffer = ((WebcamDevice.BufferAccess)device).getImageBytes();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\ds\cgt\WebcamGetBufferTask.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */