/*    */ package com.github.sarxos.webcam.ds.cgt;
/*    */ 
/*    */ import com.github.sarxos.webcam.WebcamDevice;
/*    */ import com.github.sarxos.webcam.WebcamDriver;
/*    */ import com.github.sarxos.webcam.WebcamTask;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebcamReadBufferTask
/*    */   extends WebcamTask
/*    */ {
/* 13 */   private volatile ByteBuffer target = null;
/*    */   
/*    */   public WebcamReadBufferTask(WebcamDriver driver, WebcamDevice device, ByteBuffer target) {
/* 16 */     super(driver, device);
/* 17 */     this.target = target;
/*    */   }
/*    */   
/*    */   public ByteBuffer readBuffer() {
/*    */     try {
/* 22 */       process();
/* 23 */     } catch (InterruptedException e) {
/* 24 */       return null;
/*    */     } 
/* 26 */     return this.target;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void handle() {
/* 32 */     WebcamDevice device = getDevice();
/* 33 */     if (!device.isOpen()) {
/*    */       return;
/*    */     }
/*    */     
/* 37 */     if (!(device instanceof WebcamDevice.BufferAccess)) {
/*    */       return;
/*    */     }
/*    */     
/* 41 */     ((WebcamDevice.BufferAccess)device).getImageBytes(this.target);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\ds\cgt\WebcamReadBufferTask.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */