package com.github.sarxos.webcam;

import java.awt.Point;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WebcamMotionDetector {
  private static final Logger LOG = LoggerFactory.getLogger(WebcamMotionDetector.class);
  
  private static final AtomicInteger NT = new AtomicInteger(0);
  
  private static final ThreadFactory THREAD_FACTORY = new DetectorThreadFactory();
  
  public static final int DEFAULT_INTERVAL = 500;
  
  private static final class DetectorThreadFactory implements ThreadFactory {
    private DetectorThreadFactory() {}
    
    public Thread newThread(Runnable runnable) {
      Thread t = new Thread(runnable, String.format("motion-detector-%d", new Object[] { Integer.valueOf(WebcamMotionDetector.access$100().incrementAndGet()) }));
      t.setUncaughtExceptionHandler(WebcamExceptionHandler.getInstance());
      t.setDaemon(true);
      return t;
    }
  }
  
  private class Runner implements Runnable {
    private Runner() {}
    
    public void run() {
      WebcamMotionDetector.this.running.set(true);
      while (WebcamMotionDetector.this.running.get() && WebcamMotionDetector.this.webcam.isOpen()) {
        try {
          WebcamMotionDetector.this.detect();
          Thread.sleep(WebcamMotionDetector.this.interval);
        } catch (InterruptedException e) {
          break;
        } catch (Exception e) {
          WebcamExceptionHandler.handle(e);
        } 
      } 
      WebcamMotionDetector.this.running.set(false);
    }
  }
  
  private class Inverter implements Runnable {
    private Inverter() {}
    
    public void run() {
      int delay = 0;
      while (WebcamMotionDetector.this.running.get()) {
        try {
          Thread.sleep(10L);
        } catch (InterruptedException e) {
          break;
        } 
        delay = (WebcamMotionDetector.this.inertia != -1) ? WebcamMotionDetector.this.inertia : (2 * WebcamMotionDetector.this.interval);
        if (WebcamMotionDetector.this.lastMotionTimestamp + delay < System.currentTimeMillis())
          WebcamMotionDetector.this.motion = false; 
      } 
    }
  }
  
  private final ExecutorService executor = Executors.newFixedThreadPool(2, THREAD_FACTORY);
  
  private final List<WebcamMotionListener> listeners = new ArrayList<>();
  
  private final AtomicBoolean running = new AtomicBoolean(false);
  
  private volatile boolean motion = false;
  
  private BufferedImage previousOriginal = null;
  
  private BufferedImage previousFiltered = null;
  
  private Webcam webcam = null;
  
  private volatile int interval = 500;
  
  private volatile int inertia = -1;
  
  private volatile long lastMotionTimestamp = 0L;
  
  private final WebcamMotionDetectorAlgorithm algorithm;
  
  public WebcamMotionDetector(Webcam webcam, WebcamMotionDetectorAlgorithm algorithm, int interval) {
    this.webcam = webcam;
    this.algorithm = algorithm;
    setInterval(interval);
  }
  
  public WebcamMotionDetector(Webcam webcam, int pixelThreshold, double areaThreshold, int interval) {
    this(webcam, new WebcamMotionDetectorDefaultAlgorithm(pixelThreshold, areaThreshold), interval);
  }
  
  public WebcamMotionDetector(Webcam webcam, int pixelThreshold, double areaThreshold) {
    this(webcam, pixelThreshold, areaThreshold, 500);
  }
  
  public WebcamMotionDetector(Webcam webcam, int pixelThreshold) {
    this(webcam, pixelThreshold, 0.2D);
  }
  
  public WebcamMotionDetector(Webcam webcam) {
    this(webcam, 25);
  }
  
  public void start() {
    if (this.running.compareAndSet(false, true)) {
      this.webcam.open();
      this.executor.submit(new Runner());
      this.executor.submit(new Inverter());
    } 
  }
  
  public void stop() {
    if (this.running.compareAndSet(true, false)) {
      this.webcam.close();
      this.executor.shutdownNow();
    } 
  }
  
  protected void detect() {
    if (!this.webcam.isOpen()) {
      this.motion = false;
      return;
    } 
    BufferedImage currentOriginal = this.webcam.getImage();
    if (currentOriginal == null) {
      this.motion = false;
      return;
    } 
    BufferedImage currentFiltered = this.algorithm.filter(currentOriginal);
    boolean motionDetected = this.algorithm.detect(this.previousFiltered, currentFiltered);
    if (motionDetected) {
      this.motion = true;
      this.lastMotionTimestamp = System.currentTimeMillis();
      notifyMotionListeners(currentOriginal);
    } 
    this.previousOriginal = currentOriginal;
    this.previousFiltered = currentFiltered;
  }
  
  private void notifyMotionListeners(BufferedImage currentOriginal) {
    WebcamMotionEvent wme = new WebcamMotionEvent(this, this.previousOriginal, currentOriginal, this.algorithm.getArea(), this.algorithm.getCog(), this.algorithm.getPoints());
    for (WebcamMotionListener l : this.listeners) {
      try {
        l.motionDetected(wme);
      } catch (Exception e) {
        WebcamExceptionHandler.handle(e);
      } 
    } 
  }
  
  public boolean addMotionListener(WebcamMotionListener l) {
    return this.listeners.add(l);
  }
  
  public WebcamMotionListener[] getMotionListeners() {
    return this.listeners.<WebcamMotionListener>toArray(new WebcamMotionListener[this.listeners.size()]);
  }
  
  public boolean removeMotionListener(WebcamMotionListener l) {
    return this.listeners.remove(l);
  }
  
  public int getInterval() {
    return this.interval;
  }
  
  public void setInterval(int interval) {
    if (interval < 100)
      throw new IllegalArgumentException("Motion check interval cannot be less than 100 ms"); 
    this.interval = interval;
  }
  
  public void setPixelThreshold(int threshold) {
    ((WebcamMotionDetectorDefaultAlgorithm)this.algorithm).setPixelThreshold(threshold);
  }
  
  public void setAreaThreshold(double threshold) {
    ((WebcamMotionDetectorDefaultAlgorithm)this.algorithm).setAreaThreshold(threshold);
  }
  
  public void setInertia(int inertia) {
    if (inertia < 0)
      throw new IllegalArgumentException("Inertia time must not be negative!"); 
    this.inertia = inertia;
  }
  
  public void clearInertia() {
    this.inertia = -1;
  }
  
  public Webcam getWebcam() {
    return this.webcam;
  }
  
  public boolean isMotion() {
    if (!this.running.get())
      LOG.warn("Motion cannot be detected when detector is not running!"); 
    return this.motion;
  }
  
  public double getMotionArea() {
    return this.algorithm.getArea();
  }
  
  public Point getMotionCog() {
    Point cog = this.algorithm.getCog();
    if (cog == null) {
      int w = (this.webcam.getViewSize()).width;
      int h = (this.webcam.getViewSize()).height;
      cog = new Point(w / 2, h / 2);
    } 
    return cog;
  }
  
  public WebcamMotionDetectorAlgorithm getDetectorAlgorithm() {
    return this.algorithm;
  }
  
  public void setMaxMotionPoints(int i) {
    this.algorithm.setMaxPoints(i);
  }
  
  public int getMaxMotionPoints() {
    return this.algorithm.getMaxPoints();
  }
  
  public void setPointRange(int i) {
    this.algorithm.setPointRange(i);
  }
  
  public int getPointRange() {
    return this.algorithm.getPointRange();
  }
}
