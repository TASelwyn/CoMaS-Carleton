package com.github.sarxos.webcam;

import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.imageio.ImageIO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WebcamStreamer implements ThreadFactory, WebcamListener {
  private static final Logger LOG = LoggerFactory.getLogger(WebcamStreamer.class);
  
  private static final String BOUNDARY = "mjpegframe";
  
  private static final String CRLF = "\r\n";
  
  private class Acceptor implements Runnable {
    private Acceptor() {}
    
    public void run() {
      try (ServerSocket server = new ServerSocket(WebcamStreamer.this.port, 50, InetAddress.getByName("0.0.0.0"))) {
        while (WebcamStreamer.this.started.get())
          WebcamStreamer.this.executor.execute(new WebcamStreamer.Connection(server.accept())); 
      } catch (Exception e) {
        WebcamStreamer.LOG.error("Cannot accept socket connection", e);
      } 
    }
  }
  
  private class Connection implements Runnable {
    private Socket socket = null;
    
    public Connection(Socket socket) {
      this.socket = socket;
    }
    
    public void run() {
      BufferedReader br;
      BufferedOutputStream bos;
      WebcamStreamer.LOG.info("New connection from {}", this.socket.getRemoteSocketAddress());
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      try {
        br = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
        bos = new BufferedOutputStream(this.socket.getOutputStream());
      } catch (IOException e) {
        WebcamStreamer.LOG.error("Fatal I/O exception when creating socket streams", e);
        try {
          this.socket.close();
        } catch (IOException e1) {
          WebcamStreamer.LOG.error("Canot close socket connection from " + this.socket.getRemoteSocketAddress(), e1);
        } 
        return;
      } 
      try {
        while (br.ready())
          br.readLine(); 
      } catch (IOException e) {
        WebcamStreamer.LOG.error("Error when reading input", e);
        return;
      } 
      try {
        this.socket.setSoTimeout(0);
        this.socket.setKeepAlive(false);
        this.socket.setTcpNoDelay(true);
        label162: while (WebcamStreamer.this.started.get()) {
          StringBuilder sb = new StringBuilder();
          sb.append("HTTP/1.0 200 OK").append("\r\n");
          sb.append("Connection: close").append("\r\n");
          sb.append("Cache-Control: no-cache").append("\r\n");
          sb.append("Cache-Control: private").append("\r\n");
          sb.append("Pragma: no-cache").append("\r\n");
          sb.append("Content-type: multipart/x-mixed-replace; boundary=--").append("mjpegframe").append("\r\n");
          sb.append("\r\n");
          bos.write(sb.toString().getBytes());
          while (true) {
            if (!WebcamStreamer.this.webcam.isOpen() || this.socket.isInputShutdown() || this.socket.isClosed()) {
              br.close();
              bos.close();
              WebcamStreamer.LOG.info("Closing connection from {}", this.socket.getRemoteSocketAddress());
              for (Closeable closeable : new Closeable[] { br, bos, baos }) {
                try {
                  closeable.close();
                } catch (IOException e) {
                  WebcamStreamer.LOG.debug("Cannot close socket", e);
                } 
              } 
              try {
                this.socket.close();
              } catch (IOException e) {
                WebcamStreamer.LOG.debug("Cannot close socket", e);
              } 
              return;
            } 
            baos.reset();
            long now = System.currentTimeMillis();
            if (now > WebcamStreamer.this.last + WebcamStreamer.this.delay)
              WebcamStreamer.this.image = WebcamStreamer.this.webcam.getImage(); 
            ImageIO.write(WebcamStreamer.this.image, "JPG", baos);
            sb.delete(0, sb.length());
            sb.append("--").append("mjpegframe").append("\r\n");
            sb.append("Content-type: image/jpeg").append("\r\n");
            sb.append("Content-Length: ").append(baos.size()).append("\r\n");
            sb.append("\r\n");
            try {
              bos.write(sb.toString().getBytes());
              bos.write(baos.toByteArray());
              bos.write("\r\n".getBytes());
              bos.flush();
            } catch (SocketException e) {
              if (!this.socket.isConnected())
                WebcamStreamer.LOG.debug("Connection to client has been lost"); 
              if (this.socket.isClosed())
                WebcamStreamer.LOG.debug("Connection to client is closed"); 
              try {
                br.close();
                bos.close();
              } catch (SocketException se) {
                WebcamStreamer.LOG.debug("Exception when closing socket", se);
              } 
              WebcamStreamer.LOG.debug("Socket exception from " + this.socket.getRemoteSocketAddress(), e);
              WebcamStreamer.LOG.info("Closing connection from {}", this.socket.getRemoteSocketAddress());
              for (Closeable closeable : new Closeable[] { br, bos, baos }) {
                try {
                  closeable.close();
                } catch (IOException iOException) {
                  WebcamStreamer.LOG.debug("Cannot close socket", iOException);
                } 
              } 
              try {
                this.socket.close();
              } catch (IOException iOException) {
                WebcamStreamer.LOG.debug("Cannot close socket", iOException);
              } 
              return;
            } 
            Thread.sleep(WebcamStreamer.this.delay);
            if (!WebcamStreamer.this.started.get())
              continue label162; 
          } 
        } 
      } catch (Exception e) {
        String message = e.getMessage();
        if (message != null) {
          if (message.startsWith("Software caused connection abort")) {
            WebcamStreamer.LOG.info("User closed stream");
            return;
          } 
          if (message.startsWith("Broken pipe")) {
            WebcamStreamer.LOG.info("User connection broken");
            return;
          } 
        } 
        WebcamStreamer.LOG.error("Error", e);
        try {
          bos.write("HTTP/1.0 501 Internal Server Error\r\n\r\n\r\n".getBytes());
        } catch (IOException e1) {
          WebcamStreamer.LOG.error("Not ablte to write to output stream", e);
        } 
      } finally {
        WebcamStreamer.LOG.info("Closing connection from {}", this.socket.getRemoteSocketAddress());
        for (Closeable closeable : new Closeable[] { br, bos, baos }) {
          try {
            closeable.close();
          } catch (IOException e) {
            WebcamStreamer.LOG.debug("Cannot close socket", e);
          } 
        } 
        try {
          this.socket.close();
        } catch (IOException e) {
          WebcamStreamer.LOG.debug("Cannot close socket", e);
        } 
      } 
    }
  }
  
  private Webcam webcam = null;
  
  private double fps = 0.0D;
  
  private int number = 0;
  
  private int port = 0;
  
  private long last = -1L;
  
  private long delay = -1L;
  
  private BufferedImage image = null;
  
  private ExecutorService executor = Executors.newCachedThreadPool(this);
  
  private AtomicBoolean started = new AtomicBoolean(false);
  
  public WebcamStreamer(int port, Webcam webcam, double fps, boolean start) {
    if (webcam == null)
      throw new IllegalArgumentException("Webcam for streaming cannot be null"); 
    this.port = port;
    this.webcam = webcam;
    this.fps = fps;
    this.delay = (long)(1000.0D / fps);
    if (start)
      start(); 
  }
  
  public Thread newThread(Runnable r) {
    Thread thread = new Thread(r, String.format("streamer-thread-%s", new Object[] { Integer.valueOf(this.number++) }));
    thread.setUncaughtExceptionHandler(WebcamExceptionHandler.getInstance());
    thread.setDaemon(true);
    return thread;
  }
  
  public void start() {
    if (this.started.compareAndSet(false, true)) {
      this.webcam.addWebcamListener(this);
      this.webcam.open();
      this.executor.execute(new Acceptor());
    } 
  }
  
  public void stop() {
    if (this.started.compareAndSet(true, false)) {
      this.executor.shutdown();
      this.webcam.removeWebcamListener(this);
      this.webcam.close();
    } 
  }
  
  public void webcamOpen(WebcamEvent we) {
    start();
  }
  
  public void webcamClosed(WebcamEvent we) {
    stop();
  }
  
  public void webcamDisposed(WebcamEvent we) {}
  
  public void webcamImageObtained(WebcamEvent we) {}
  
  public double getFPS() {
    return this.fps;
  }
  
  public boolean isInitialized() {
    return this.started.get();
  }
  
  public int getPort() {
    return this.port;
  }
}
