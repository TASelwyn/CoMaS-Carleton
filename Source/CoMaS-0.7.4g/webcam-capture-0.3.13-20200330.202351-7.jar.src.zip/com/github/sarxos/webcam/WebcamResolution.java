/*     */ package com.github.sarxos.webcam;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum WebcamResolution
/*     */ {
/*  18 */   QQVGA(176, 144),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  23 */   HQVGA(240, 160),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  28 */   QVGA(320, 240),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  33 */   WQVGA(400, 240),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   HVGA(480, 320),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   VGA(640, 480),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   WVGA(768, 480),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   FWVGA(854, 480),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   SVGA(800, 600),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   DVGA(960, 640),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   WSVGA1(1024, 576),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   WSVGA2(1024, 600),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   XGA(1024, 768),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   XGAP(1152, 864),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   WXGA1(1366, 768),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   WXGA2(1280, 800),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   WXGAP(1440, 900),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   SXGA(1280, 1024),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   SXGAP(1400, 1050),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   WSXGAP(1680, 1050),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   UXGA(1600, 1200),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   WUXGA(1920, 1200),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   QWXGA(2048, 1152),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   QXGA(2048, 1536),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   WQXGA(2560, 1600),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 147 */   QSXGA(2560, 2048),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   WQSXGA(3200, 2048),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 157 */   QUXGA(3200, 2400),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 162 */   WQUXGA(3840, 2400),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 169 */   HXGA(4096, 3072),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 174 */   WHXGA(5120, 3200),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   HSXGA(5120, 4096),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 184 */   WHSXGA(6400, 4096),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 189 */   HUXGA(6400, 4800),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   WHUXGA(7680, 4800),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 201 */   NHD(640, 360),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 206 */   QHD(960, 540),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 211 */   HD(1280, 720),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 216 */   HDP(1600, 900),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 221 */   FHD(1920, 1080),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 226 */   FHDP(2160, 1440),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 231 */   DCI2K(2048, 1080),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 236 */   WQHD(2560, 1440),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 241 */   WQHDP(3200, 1800),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 246 */   UWQHD(3440, 1440),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 251 */   UW4K(3840, 1600),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 257 */   UHD4K(3840, 2160),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 262 */   DCI4K(4096, 2160),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 267 */   UW5K(5120, 2160),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 272 */   UHDP5K(5120, 2880),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 277 */   UW8K(7680, 3200),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 282 */   UHD8K(7680, 4320),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 289 */   PAL(768, 576),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 294 */   CIF(352, 288);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 301 */   private Dimension size = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   WebcamResolution(int width, int height) {
/* 309 */     this.size = new Dimension(width, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getSize() {
/* 318 */     return this.size;
/*     */   }
/*     */   
/*     */   public int getPixelsCount() {
/* 322 */     return this.size.width * this.size.height;
/*     */   }
/*     */   
/*     */   public Dimension getAspectRatio() {
/* 326 */     int factor = getCommonFactor(this.size.width, this.size.height);
/* 327 */     int wr = this.size.width / factor;
/* 328 */     int hr = this.size.height / factor;
/* 329 */     return new Dimension(wr, hr);
/*     */   }
/*     */   
/*     */   private int getCommonFactor(int width, int height) {
/* 333 */     return (height == 0) ? width : getCommonFactor(height, width % height);
/*     */   }
/*     */   
/*     */   public int getWidth() {
/* 337 */     return this.size.width;
/*     */   }
/*     */   
/*     */   public int getHeight() {
/* 341 */     return this.size.height;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 347 */     int w = this.size.width;
/* 348 */     int h = this.size.height;
/* 349 */     Dimension ratio = getAspectRatio();
/* 350 */     int rw = ratio.width;
/* 351 */     int rh = ratio.height;
/*     */     
/* 353 */     return super
/* 354 */       .toString() + ' ' + 
/* 355 */       w + 
/* 356 */       'x' + h + " (" + 
/* 357 */       rw + 
/* 358 */       ':' + rh + ')';
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {}
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamResolution.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */