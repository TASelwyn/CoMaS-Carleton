package com.github.sarxos.webcam;

public abstract class WebcamTask {
  private boolean doSync = true;
  
  private WebcamProcessor processor = null;
  
  private WebcamDevice device = null;
  
  private Throwable throwable = null;
  
  public WebcamTask(boolean threadSafe, WebcamDevice device) {
    this.doSync = !threadSafe;
    this.device = device;
    this.processor = WebcamProcessor.getInstance();
  }
  
  public WebcamTask(WebcamDriver driver, WebcamDevice device) {
    this(driver.isThreadSafe(), device);
  }
  
  public WebcamTask(WebcamDevice device) {
    this(false, device);
  }
  
  public WebcamDevice getDevice() {
    return this.device;
  }
  
  public void process() throws InterruptedException {
    boolean alreadyInSync = Thread.currentThread() instanceof WebcamProcessor.ProcessorThread;
    if (alreadyInSync) {
      handle();
    } else if (this.doSync) {
      if (this.processor == null)
        throw new RuntimeException("Driver should be synchronized, but processor is null"); 
      this.processor.process(this);
    } else {
      handle();
    } 
  }
  
  public Throwable getThrowable() {
    return this.throwable;
  }
  
  public void setThrowable(Throwable t) {
    this.throwable = t;
  }
  
  protected abstract void handle();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamTask.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */