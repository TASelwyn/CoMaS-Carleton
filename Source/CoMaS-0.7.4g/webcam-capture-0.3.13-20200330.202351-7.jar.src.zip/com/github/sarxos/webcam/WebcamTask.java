/*    */ package com.github.sarxos.webcam;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WebcamTask
/*    */ {
/*    */   private boolean doSync = true;
/*  8 */   private WebcamProcessor processor = null;
/*  9 */   private WebcamDevice device = null;
/* 10 */   private Throwable throwable = null;
/*    */   
/*    */   public WebcamTask(boolean threadSafe, WebcamDevice device) {
/* 13 */     this.doSync = !threadSafe;
/* 14 */     this.device = device;
/* 15 */     this.processor = WebcamProcessor.getInstance();
/*    */   }
/*    */   
/*    */   public WebcamTask(WebcamDriver driver, WebcamDevice device) {
/* 19 */     this(driver.isThreadSafe(), device);
/*    */   }
/*    */   
/*    */   public WebcamTask(WebcamDevice device) {
/* 23 */     this(false, device);
/*    */   }
/*    */   
/*    */   public WebcamDevice getDevice() {
/* 27 */     return this.device;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void process() throws InterruptedException {
/* 37 */     boolean alreadyInSync = Thread.currentThread() instanceof WebcamProcessor.ProcessorThread;
/*    */     
/* 39 */     if (alreadyInSync) {
/* 40 */       handle();
/*    */     }
/* 42 */     else if (this.doSync) {
/* 43 */       if (this.processor == null) {
/* 44 */         throw new RuntimeException("Driver should be synchronized, but processor is null");
/*    */       }
/* 46 */       this.processor.process(this);
/*    */     } else {
/* 48 */       handle();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Throwable getThrowable() {
/* 54 */     return this.throwable;
/*    */   }
/*    */   
/*    */   public void setThrowable(Throwable t) {
/* 58 */     this.throwable = t;
/*    */   }
/*    */   
/*    */   protected abstract void handle();
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamTask.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */