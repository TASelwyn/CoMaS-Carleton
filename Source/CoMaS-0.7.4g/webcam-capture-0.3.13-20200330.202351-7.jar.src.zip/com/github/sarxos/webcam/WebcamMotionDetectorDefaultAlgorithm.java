/*     */ package com.github.sarxos.webcam;
/*     */ 
/*     */ import com.github.sarxos.webcam.util.jh.JHBlurFilter;
/*     */ import com.github.sarxos.webcam.util.jh.JHGrayFilter;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebcamMotionDetectorDefaultAlgorithm
/*     */   implements WebcamMotionDetectorAlgorithm
/*     */ {
/*     */   public static final int DEFAULT_PIXEL_THREASHOLD = 25;
/*     */   public static final double DEFAULT_AREA_THREASHOLD = 0.2D;
/*     */   public static final double DEFAULT_AREA_THREASHOLD_MAX = 100.0D;
/*  41 */   private volatile int pixelThreshold = 25;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   private volatile double areaThreshold = 0.2D;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   private volatile double areaThresholdMax = 100.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   private double area = 0.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private Point cog = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   private final JHBlurFilter blur = new JHBlurFilter(6.0F, 6.0F, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private final JHGrayFilter gray = new JHGrayFilter();
/*     */   
/*  73 */   private List<Rectangle> doNotEnganeZones = Collections.emptyList();
/*     */   ArrayList<Point> points;
/*     */   ArrayList<Integer> thresholds;
/*     */   public static final int DEFAULT_RANGE = 50;
/*     */   public static final int DEFAULT_MAX_POINTS = 100;
/*     */   private int range;
/*     */   private int maxPoints;
/*     */   
/*     */   public WebcamMotionDetectorDefaultAlgorithm() {
/*  82 */     this(25, 0.2D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage filter(BufferedImage original) {
/*  98 */     BufferedImage modified = this.blur.filter(original, null);
/*  99 */     modified = this.gray.filter(modified, null);
/* 100 */     return modified;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean detect(BufferedImage previousModified, BufferedImage currentModified) {
/* 106 */     this.points.clear();
/* 107 */     this.thresholds.clear();
/*     */     
/* 109 */     int p = 0;
/*     */     
/* 111 */     int cogX = 0;
/* 112 */     int cogY = 0;
/*     */     
/* 114 */     int w = currentModified.getWidth();
/* 115 */     int h = currentModified.getHeight();
/*     */     
/* 117 */     int j = 0;
/*     */     
/* 119 */     if (previousModified != null) {
/* 120 */       for (int x = 0; x < w; x++) {
/* 121 */         for (int y = 0; y < h; y++) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 126 */           if (!isInDoNotEngageZone(x, y)) {
/*     */ 
/*     */ 
/*     */             
/* 130 */             int cpx = currentModified.getRGB(x, y);
/* 131 */             int ppx = previousModified.getRGB(x, y);
/* 132 */             int pid = combinePixels(cpx, ppx) & 0xFF;
/*     */             
/* 134 */             if (pid >= this.pixelThreshold) {
/* 135 */               Point pp = new Point(x, y);
/* 136 */               boolean keep = (j < this.maxPoints);
/*     */               
/* 138 */               if (keep) {
/* 139 */                 for (Point g : this.points) {
/* 140 */                   if ((g.x != pp.x || g.y != pp.y) && 
/* 141 */                     pp.distance(g) <= this.range) {
/* 142 */                     keep = false;
/*     */                     
/*     */                     break;
/*     */                   } 
/*     */                 } 
/*     */               }
/*     */               
/* 149 */               if (keep) {
/* 150 */                 this.points.add(new Point(x, y));
/* 151 */                 j++;
/*     */               } 
/*     */               
/* 154 */               cogX += x;
/* 155 */               cogY += y;
/* 156 */               p++;
/* 157 */               this.thresholds.add(Integer.valueOf(pid));
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/* 163 */     this.area = p * 100.0D / (w * h);
/*     */     
/* 165 */     if (this.area >= this.areaThreshold && this.area <= this.areaThresholdMax) {
/* 166 */       this.cog = new Point(cogX / p, cogY / p);
/* 167 */       return true;
/*     */     } 
/* 169 */     this.cog = new Point(w / 2, h / 2);
/* 170 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isInDoNotEngageZone(int x, int y) {
/* 183 */     for (Rectangle zone : this.doNotEnganeZones) {
/* 184 */       if (zone.contains(x, y)) {
/* 185 */         return true;
/*     */       }
/*     */     } 
/* 188 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Point getCog() {
/* 193 */     return this.cog;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getArea() {
/* 198 */     return this.area;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPixelThreshold(int threshold) {
/* 210 */     if (threshold < 0) {
/* 211 */       throw new IllegalArgumentException("Pixel intensity threshold cannot be negative!");
/*     */     }
/* 213 */     if (threshold > 255) {
/* 214 */       throw new IllegalArgumentException("Pixel intensity threshold cannot be higher than 255!");
/*     */     }
/* 216 */     this.pixelThreshold = threshold;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAreaThreshold(double threshold) {
/* 228 */     if (threshold < 0.0D) {
/* 229 */       throw new IllegalArgumentException("Area fraction threshold cannot be negative!");
/*     */     }
/* 231 */     if (threshold > 100.0D) {
/* 232 */       throw new IllegalArgumentException("Area fraction threshold cannot be higher than 100!");
/*     */     }
/* 234 */     this.areaThreshold = threshold;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxAreaThreshold(double threshold) {
/* 247 */     if (threshold < 0.0D) {
/* 248 */       throw new IllegalArgumentException("Area fraction threshold cannot be negative!");
/*     */     }
/* 250 */     if (threshold > 100.0D) {
/* 251 */       throw new IllegalArgumentException("Area fraction threshold cannot be higher than 100!");
/*     */     }
/* 253 */     this.areaThresholdMax = threshold;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int combinePixels(int rgb1, int rgb2) {
/* 260 */     int a1 = rgb1 >> 24 & 0xFF;
/* 261 */     int r1 = rgb1 >> 16 & 0xFF;
/* 262 */     int g1 = rgb1 >> 8 & 0xFF;
/* 263 */     int b1 = rgb1 & 0xFF;
/*     */ 
/*     */ 
/*     */     
/* 267 */     int a2 = rgb2 >> 24 & 0xFF;
/* 268 */     int r2 = rgb2 >> 16 & 0xFF;
/* 269 */     int g2 = rgb2 >> 8 & 0xFF;
/* 270 */     int b2 = rgb2 & 0xFF;
/*     */     
/* 272 */     r1 = clamp(Math.abs(r1 - r2));
/* 273 */     g1 = clamp(Math.abs(g1 - g2));
/* 274 */     b1 = clamp(Math.abs(b1 - b2));
/*     */ 
/*     */ 
/*     */     
/* 278 */     if (a1 != 255) {
/* 279 */       a1 = a1 * 255 / 255;
/* 280 */       int a3 = (255 - a1) * a2 / 255;
/* 281 */       r1 = clamp((r1 * a1 + r2 * a3) / 255);
/* 282 */       g1 = clamp((g1 * a1 + g2 * a3) / 255);
/* 283 */       b1 = clamp((b1 * a1 + b2 * a3) / 255);
/* 284 */       a1 = clamp(a1 + a3);
/*     */     } 
/*     */     
/* 287 */     return a1 << 24 | r1 << 16 | g1 << 8 | b1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int clamp(int c) {
/* 294 */     if (c < 0) {
/* 295 */       return 0;
/*     */     }
/* 297 */     if (c > 255) {
/* 298 */       return 255;
/*     */     }
/* 300 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebcamMotionDetectorDefaultAlgorithm(int pixelThreshold, double areaThreshold) {
/* 306 */     this.points = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 311 */     this.thresholds = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 330 */     this.range = 50;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 335 */     this.maxPoints = 100;
/*     */     setPixelThreshold(pixelThreshold);
/*     */     setAreaThreshold(areaThreshold);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPointRange(int i) {
/* 344 */     this.range = i;
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayList<Integer> getThresholds() {
/*     */     return this.thresholds;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPointRange() {
/* 354 */     return this.range;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxPoints(int i) {
/* 364 */     this.maxPoints = i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxPoints() {
/* 374 */     return this.maxPoints;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<Point> getPoints() {
/* 384 */     return this.points;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDoNotEngageZones(List<Rectangle> doNotEngageZones) {
/* 389 */     this.doNotEnganeZones = doNotEngageZones;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamMotionDetectorDefaultAlgorithm.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */