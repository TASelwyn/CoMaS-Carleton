package com.github.sarxos.webcam.util;

import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.imageio.ImageIO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MjpegInputStream extends DataInputStream {
  private static final Logger LOG = LoggerFactory.getLogger(MjpegInputStream.class);
  
  private final byte[] SOI_MARKER = new byte[] { -1, -40 };
  
  private final byte[] EOI_MARKER = new byte[] { -1, -39 };
  
  private final String CONTENT_LENGTH = "Content-Length".toLowerCase();
  
  private static final int HEADER_MAX_LENGTH = 100;
  
  private static final int FRAME_MAX_LENGTH = 100100;
  
  private boolean open = true;
  
  public MjpegInputStream(InputStream in) {
    super(new BufferedInputStream(in, 100100));
  }
  
  private int getEndOfSeqeunce(DataInputStream in, byte[] sequence) throws IOException {
    int s = 0;
    for (int i = 0; i < 100100; i++) {
      byte c = (byte)in.readUnsignedByte();
      if (c == sequence[s]) {
        s++;
        if (s == sequence.length)
          return i + 1; 
      } else {
        s = 0;
      } 
    } 
    return -1;
  }
  
  private int getStartOfSequence(DataInputStream in, byte[] sequence) throws IOException {
    int end = getEndOfSeqeunce(in, sequence);
    return (end < 0) ? -1 : (end - sequence.length);
  }
  
  private int parseContentLength(byte[] headerBytes) throws IOException, NumberFormatException {
    try(ByteArrayInputStream bais = new ByteArrayInputStream(headerBytes); 
        InputStreamReader isr = new InputStreamReader(bais); 
        BufferedReader br = new BufferedReader(isr)) {
      String line = null;
      while ((line = br.readLine()) != null) {
        if (line.toLowerCase().startsWith(this.CONTENT_LENGTH)) {
          String[] parts = line.split(":");
          if (parts.length == 2)
            return Integer.parseInt(parts[1].trim()); 
        } 
      } 
    } 
    return 0;
  }
  
  public BufferedImage readFrame() throws IOException {
    if (!this.open)
      return null; 
    mark(100100);
    int n = getStartOfSequence(this, this.SOI_MARKER);
    reset();
    byte[] header = new byte[n];
    readFully(header);
    int length = -1;
    try {
      length = parseContentLength(header);
    } catch (NumberFormatException e) {
      length = getEndOfSeqeunce(this, this.EOI_MARKER);
    } 
    if (length == 0)
      LOG.error("Invalid MJPEG stream, EOI (0xFF,0xD9) not found!"); 
    reset();
    byte[] frame = new byte[length];
    skipBytes(n);
    readFully(frame);
    try (ByteArrayInputStream bais = new ByteArrayInputStream(frame)) {
      return ImageIO.read(bais);
    } catch (IOException e) {
      return null;
    } 
  }
  
  public void close() throws IOException {
    try {
      super.close();
    } finally {
      this.open = false;
    } 
  }
  
  public boolean isClosed() {
    return !this.open;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webca\\util\MjpegInputStream.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */