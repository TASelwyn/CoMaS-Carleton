/*    */ package com.github.sarxos.webcam.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FilenameFilter;
/*    */ 
/*    */ public class NixVideoDevUtils
/*    */   implements FilenameFilter
/*    */ {
/*  9 */   private static final File DEV = new File("/dev");
/*    */ 
/*    */   
/*    */   public boolean accept(File dir, String name) {
/* 13 */     return (dir.getName().equals("dev") && name.startsWith("video") && name.length() > 5 && Character.isDigit(name.charAt(5)));
/*    */   }
/*    */ 
/*    */   
/*    */   public static File[] getVideoFiles() {
/* 18 */     String[] names = DEV.list(new NixVideoDevUtils());
/* 19 */     File[] files = new File[names.length];
/*    */     
/* 21 */     for (int i = 0; i < names.length; i++) {
/* 22 */       files[i] = new File(DEV, names[i]);
/*    */     }
/*    */     
/* 25 */     return files;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webca\\util\NixVideoDevUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */