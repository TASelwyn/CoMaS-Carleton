package com.github.sarxos.webcam.util;

import com.github.sarxos.webcam.WebcamException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;

public class WebcamInitializer {
  private final Initializable initializable;
  
  private final AtomicBoolean initialized = new AtomicBoolean(false);
  
  private final CountDownLatch latch = new CountDownLatch(1);
  
  public WebcamInitializer(Initializable initializable) {
    this.initializable = initializable;
  }
  
  public void initialize() {
    if (this.initialized.compareAndSet(false, true)) {
      try {
        this.initializable.initialize();
      } catch (Exception e) {
        throw new WebcamException(e);
      } finally {
        this.latch.countDown();
      } 
    } else {
      try {
        this.latch.await();
      } catch (InterruptedException e) {
        return;
      } 
    } 
  }
  
  public void teardown() {
    if (this.initialized.compareAndSet(true, false))
      try {
        this.initializable.teardown();
      } catch (Exception e) {
        throw new WebcamException(e);
      }  
  }
  
  public boolean isInitialized() {
    return this.initialized.get();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webca\\util\WebcamInitializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */