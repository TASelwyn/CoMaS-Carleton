package com.github.sarxos.webcam.util.jh;

import com.github.sarxos.webcam.util.ImageUtils;
import java.awt.image.BufferedImage;

public class JHNormalizeFilter extends JHFilter {
  public BufferedImage filter(BufferedImage src, BufferedImage dest) {
    int w = src.getWidth();
    int h = src.getHeight();
    int max = 1;
    int x;
    for (x = 0; x < w; x++) {
      for (int y = 0; y < h; y++) {
        int c = src.getRGB(x, y);
        int a = ImageUtils.clamp(c >> 24 & 0xFF);
        int r = ImageUtils.clamp(c >> 16 & 0xFF);
        int g = ImageUtils.clamp(c >> 8 & 0xFF);
        int b = ImageUtils.clamp(c & 0xFF);
        int i = a << 24 | r << 16 | g << 8 | b;
        if (i > max)
          max = i; 
      } 
    } 
    for (x = 0; x < w; x++) {
      for (int y = 0; y < h; y++) {
        int c = src.getRGB(x, y);
        int i = c * 256 / max;
        dest.setRGB(x, y, i);
      } 
    } 
    return dest;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webca\\util\jh\JHNormalizeFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */