/*     */ package com.github.sarxos.webcam.util.jh;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JHFlipFilter
/*     */   extends JHFilter
/*     */ {
/*     */   public static final int FLIP_90CW = 4;
/*     */   public static final int FLIP_90CCW = 5;
/*     */   public static final int FLIP_180 = 6;
/*     */   private int operation;
/*     */   
/*     */   public JHFlipFilter() {
/*  49 */     this(4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JHFlipFilter(int operation) {
/*  58 */     setOperation(operation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOperation(int operation) {
/*  68 */     this.operation = operation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOperation() {
/*  78 */     return this.operation;
/*     */   }
/*     */ 
/*     */   
/*     */   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
/*  83 */     int width = src.getWidth();
/*  84 */     int height = src.getHeight();
/*     */     
/*  86 */     int[] inPixels = getRGB(src, 0, 0, width, height, null);
/*     */     
/*  88 */     int w = width;
/*  89 */     int h = height;
/*     */     
/*  91 */     int newW = w;
/*  92 */     int newH = h;
/*  93 */     switch (this.operation) {
/*     */       case 4:
/*  95 */         newW = h;
/*  96 */         newH = w;
/*     */         break;
/*     */       case 5:
/*  99 */         newW = h;
/* 100 */         newH = w;
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 106 */     int[] newPixels = new int[newW * newH];
/*     */     
/* 108 */     for (int row = 0; row < h; row++) {
/* 109 */       for (int col = 0; col < w; col++) {
/* 110 */         int index = row * width + col;
/* 111 */         int newRow = row;
/* 112 */         int newCol = col;
/* 113 */         switch (this.operation) {
/*     */           case 4:
/* 115 */             newRow = col;
/* 116 */             newCol = h - row - 1;
/*     */             break;
/*     */           
/*     */           case 5:
/* 120 */             newRow = w - col - 1;
/* 121 */             newCol = row;
/*     */             break;
/*     */           case 6:
/* 124 */             newRow = h - row - 1;
/* 125 */             newCol = w - col - 1;
/*     */             break;
/*     */         } 
/* 128 */         int newIndex = newRow * newW + newCol;
/* 129 */         newPixels[newIndex] = inPixels[index];
/*     */       } 
/*     */     } 
/*     */     
/* 133 */     if (dst == null) {
/* 134 */       ColorModel dstCM = src.getColorModel();
/* 135 */       dst = new BufferedImage(dstCM, dstCM.createCompatibleWritableRaster(newW, newH), dstCM.isAlphaPremultiplied(), null);
/*     */     } 
/* 137 */     setRGB(dst, 0, 0, newW, newH, newPixels);
/*     */     
/* 139 */     return dst;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 144 */     switch (this.operation) {
/*     */       case 4:
/* 146 */         return "Rotate 90";
/*     */       case 5:
/* 148 */         return "Rotate -90";
/*     */       case 6:
/* 150 */         return "Rotate 180";
/*     */     } 
/* 152 */     return "Flip";
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webca\\util\jh\JHFlipFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */