package com.github.sarxos.webcam.util.jh;

import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;

public class JHFlipFilter extends JHFilter {
  public static final int FLIP_90CW = 4;
  
  public static final int FLIP_90CCW = 5;
  
  public static final int FLIP_180 = 6;
  
  private int operation;
  
  public JHFlipFilter() {
    this(4);
  }
  
  public JHFlipFilter(int operation) {
    setOperation(operation);
  }
  
  public void setOperation(int operation) {
    this.operation = operation;
  }
  
  public int getOperation() {
    return this.operation;
  }
  
  public BufferedImage filter(BufferedImage src, BufferedImage dst) {
    int width = src.getWidth();
    int height = src.getHeight();
    int[] inPixels = getRGB(src, 0, 0, width, height, null);
    int w = width;
    int h = height;
    int newW = w;
    int newH = h;
    switch (this.operation) {
      case 4:
        newW = h;
        newH = w;
        break;
      case 5:
        newW = h;
        newH = w;
        break;
    } 
    int[] newPixels = new int[newW * newH];
    for (int row = 0; row < h; row++) {
      for (int col = 0; col < w; col++) {
        int index = row * width + col;
        int newRow = row;
        int newCol = col;
        switch (this.operation) {
          case 4:
            newRow = col;
            newCol = h - row - 1;
            break;
          case 5:
            newRow = w - col - 1;
            newCol = row;
            break;
          case 6:
            newRow = h - row - 1;
            newCol = w - col - 1;
            break;
        } 
        int newIndex = newRow * newW + newCol;
        newPixels[newIndex] = inPixels[index];
      } 
    } 
    if (dst == null) {
      ColorModel dstCM = src.getColorModel();
      dst = new BufferedImage(dstCM, dstCM.createCompatibleWritableRaster(newW, newH), dstCM.isAlphaPremultiplied(), null);
    } 
    setRGB(dst, 0, 0, newW, newH, newPixels);
    return dst;
  }
  
  public String toString() {
    switch (this.operation) {
      case 4:
        return "Rotate 90";
      case 5:
        return "Rotate -90";
      case 6:
        return "Rotate 180";
    } 
    return "Flip";
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webca\\util\jh\JHFlipFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */