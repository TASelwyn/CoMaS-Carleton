package com.github.sarxos.webcam;

public interface WebcamDiscoverySupport {
  public static final long DEFAULT_SCAN_INTERVAL = 3000L;
  
  long getScanInterval();
  
  boolean isScanPossible();
}
