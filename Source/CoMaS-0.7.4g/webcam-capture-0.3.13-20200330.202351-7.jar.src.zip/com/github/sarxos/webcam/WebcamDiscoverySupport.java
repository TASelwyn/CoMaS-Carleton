package com.github.sarxos.webcam;

public interface WebcamDiscoverySupport {
  public static final long DEFAULT_SCAN_INTERVAL = 3000L;
  
  long getScanInterval();
  
  boolean isScanPossible();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamDiscoverySupport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */