package com.github.sarxos.webcam;

import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.nio.ByteBuffer;
import java.util.Map;

public interface WebcamDevice {
  String getName();
  
  Dimension[] getResolutions();
  
  Dimension getResolution();
  
  void setResolution(Dimension paramDimension);
  
  BufferedImage getImage();
  
  void open();
  
  void close();
  
  void dispose();
  
  boolean isOpen();
  
  public static interface Configurable {
    void setParameters(Map<String, ?> param1Map);
  }
  
  public static interface FPSSource {
    double getFPS();
  }
  
  public static interface BufferAccess {
    ByteBuffer getImageBytes();
    
    void getImageBytes(ByteBuffer param1ByteBuffer);
  }
}
