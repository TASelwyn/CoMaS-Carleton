package com.github.sarxos.webcam;

import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.nio.ByteBuffer;
import java.util.Map;

public interface WebcamDevice {
  String getName();
  
  Dimension[] getResolutions();
  
  Dimension getResolution();
  
  void setResolution(Dimension paramDimension);
  
  BufferedImage getImage();
  
  void open();
  
  void close();
  
  void dispose();
  
  boolean isOpen();
  
  public static interface Configurable {
    void setParameters(Map<String, ?> param1Map);
  }
  
  public static interface FPSSource {
    double getFPS();
  }
  
  public static interface BufferAccess {
    ByteBuffer getImageBytes();
    
    void getImageBytes(ByteBuffer param1ByteBuffer);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\webcam-capture-0.3.13-20200330.202351-7.jar!\com\github\sarxos\webcam\WebcamDevice.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */