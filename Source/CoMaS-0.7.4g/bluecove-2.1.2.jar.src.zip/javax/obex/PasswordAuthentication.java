package javax.obex;

import com.intel.bluetooth.Utils;

public class PasswordAuthentication {
  private byte[] userName;
  
  private byte[] password;
  
  public PasswordAuthentication(byte[] userName, byte[] password) {
    if (password == null)
      throw new NullPointerException("password is null"); 
    this.userName = Utils.clone(userName);
    this.password = Utils.clone(password);
  }
  
  public byte[] getUserName() {
    return Utils.clone(this.userName);
  }
  
  public byte[] getPassword() {
    return Utils.clone(this.password);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\javax\obex\PasswordAuthentication.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */