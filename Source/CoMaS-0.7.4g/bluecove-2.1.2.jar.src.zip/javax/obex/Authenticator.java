package javax.obex;

public interface Authenticator {
  PasswordAuthentication onAuthenticationChallenge(String paramString, boolean paramBoolean1, boolean paramBoolean2);
  
  byte[] onAuthenticationResponse(byte[] paramArrayOfbyte);
}
