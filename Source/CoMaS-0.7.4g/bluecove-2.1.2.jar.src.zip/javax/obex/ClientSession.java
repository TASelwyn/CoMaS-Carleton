package javax.obex;

import java.io.IOException;
import javax.microedition.io.Connection;

public interface ClientSession extends Connection {
  void setAuthenticator(Authenticator paramAuthenticator);
  
  HeaderSet createHeaderSet();
  
  void setConnectionID(long paramLong);
  
  long getConnectionID();
  
  HeaderSet connect(HeaderSet paramHeaderSet) throws IOException;
  
  HeaderSet disconnect(HeaderSet paramHeaderSet) throws IOException;
  
  HeaderSet setPath(HeaderSet paramHeaderSet, boolean paramBoolean1, boolean paramBoolean2) throws IOException;
  
  HeaderSet delete(HeaderSet paramHeaderSet) throws IOException;
  
  Operation get(HeaderSet paramHeaderSet) throws IOException;
  
  Operation put(HeaderSet paramHeaderSet) throws IOException;
}
