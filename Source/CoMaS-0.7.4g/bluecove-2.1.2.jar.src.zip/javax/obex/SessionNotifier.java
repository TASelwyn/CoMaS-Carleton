package javax.obex;

import java.io.IOException;
import javax.microedition.io.Connection;

public interface SessionNotifier extends Connection {
  Connection acceptAndOpen(ServerRequestHandler paramServerRequestHandler) throws IOException;
  
  Connection acceptAndOpen(ServerRequestHandler paramServerRequestHandler, Authenticator paramAuthenticator) throws IOException;
}
