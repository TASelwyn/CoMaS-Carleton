package javax.obex;

import java.io.IOException;
import javax.microedition.io.Connection;

public interface SessionNotifier extends Connection {
  Connection acceptAndOpen(ServerRequestHandler paramServerRequestHandler) throws IOException;
  
  Connection acceptAndOpen(ServerRequestHandler paramServerRequestHandler, Authenticator paramAuthenticator) throws IOException;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\javax\obex\SessionNotifier.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */