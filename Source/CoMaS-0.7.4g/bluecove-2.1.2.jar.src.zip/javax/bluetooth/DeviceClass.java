package javax.bluetooth;

import com.intel.bluetooth.BluetoothConsts;
import com.intel.bluetooth.DebugLog;

public class DeviceClass {
  private static final int SERVICE_MASK = 16769024;
  
  private static final int MAJOR_MASK = 7936;
  
  private static final int MINOR_MASK = 252;
  
  private int record;
  
  public DeviceClass(int record) {
    DebugLog.debug("new DeviceClass", record);
    this.record = record;
    if ((record & 0xFF000000) != 0)
      throw new IllegalArgumentException(); 
  }
  
  public int getServiceClasses() {
    return this.record & 0xFFE000;
  }
  
  public int getMajorDeviceClass() {
    return this.record & 0x1F00;
  }
  
  public int getMinorDeviceClass() {
    return this.record & 0xFC;
  }
  
  public String toString() {
    return BluetoothConsts.toString(this);
  }
}
