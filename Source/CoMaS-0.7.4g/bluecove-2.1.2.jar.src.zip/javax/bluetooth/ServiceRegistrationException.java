package javax.bluetooth;

import java.io.IOException;

public class ServiceRegistrationException extends IOException {
  private static final long serialVersionUID = 1L;
  
  public ServiceRegistrationException() {}
  
  public ServiceRegistrationException(String msg) {
    super(msg);
  }
}
