package javax.bluetooth;

import java.io.IOException;

public class BluetoothStateException extends IOException {
  private static final long serialVersionUID = 1L;
  
  public BluetoothStateException() {}
  
  public BluetoothStateException(String msg) {
    super(msg);
  }
}
