package javax.bluetooth;

import java.io.IOException;
import javax.microedition.io.Connection;

public interface L2CAPConnectionNotifier extends Connection {
  L2CAPConnection acceptAndOpen() throws IOException;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\javax\bluetooth\L2CAPConnectionNotifier.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */