/*     */ package javax.bluetooth;
/*     */ 
/*     */ import com.intel.bluetooth.BlueCoveImpl;
/*     */ import com.intel.bluetooth.BluetoothConnectionNotifierServiceRecordAccess;
/*     */ import com.intel.bluetooth.BluetoothStack;
/*     */ import com.intel.bluetooth.RemoteDeviceHelper;
/*     */ import com.intel.bluetooth.ServiceRecordsRegistry;
/*     */ import com.intel.bluetooth.UtilsJavaSE;
/*     */ import java.util.Hashtable;
/*     */ import javax.microedition.io.Connection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalDevice
/*     */ {
/*  52 */   private static Hashtable localDevices = new Hashtable();
/*     */ 
/*     */ 
/*     */   
/*     */   private BluetoothStack bluetoothStack;
/*     */ 
/*     */ 
/*     */   
/*     */   private DiscoveryAgent discoveryAgent;
/*     */ 
/*     */ 
/*     */   
/*     */   private String addressStr;
/*     */ 
/*     */ 
/*     */   
/*     */   private LocalDevice(BluetoothStack stack) throws BluetoothStateException {
/*  69 */     this.bluetoothStack = stack;
/*  70 */     this.discoveryAgent = new DiscoveryAgent(this.bluetoothStack);
/*  71 */     this.addressStr = RemoteDeviceHelper.formatBluetoothAddress(this.bluetoothStack.getLocalDeviceBluetoothAddress());
/*     */   }
/*     */   
/*     */   private static synchronized LocalDevice getLocalDeviceInstance() throws BluetoothStateException {
/*  75 */     BluetoothStack stack = BlueCoveImpl.instance().getBluetoothStack();
/*  76 */     LocalDevice localDevice = (LocalDevice)localDevices.get(stack);
/*  77 */     if (localDevice == null) {
/*  78 */       localDevice = new LocalDevice(stack);
/*  79 */       localDevices.put(stack, localDevice);
/*     */     } 
/*  81 */     return localDevice;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDevice getLocalDevice() throws BluetoothStateException {
/*  95 */     return getLocalDeviceInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPowerOn() {
/*     */     try {
/* 107 */       return BlueCoveImpl.instance().getBluetoothStack().isLocalDevicePowerOn();
/* 108 */     } catch (BluetoothStateException e) {
/* 109 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiscoveryAgent getDiscoveryAgent() {
/* 122 */     return this.discoveryAgent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFriendlyName() {
/* 133 */     return this.bluetoothStack.getLocalDeviceName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeviceClass getDeviceClass() {
/* 148 */     return this.bluetoothStack.getLocalDeviceClass();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setDiscoverable(int mode) throws BluetoothStateException {
/* 203 */     if (mode != 10390323 && mode != 10390272 && mode != 0 && (mode < 10390272 || mode > 10390335)) {
/* 204 */       throw new IllegalArgumentException("Invalid discoverable mode");
/*     */     }
/* 206 */     return this.bluetoothStack.setLocalDeviceDiscoverable(mode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getProperty(String property) {
/*     */     try {
/* 281 */       if ("bluetooth.api.version".equals(property))
/* 282 */         return "1.1.1"; 
/* 283 */       if ("obex.api.version".equals(property))
/* 284 */         return "1.1.1"; 
/* 285 */       if ("bluecove".equals(property))
/* 286 */         return BlueCoveImpl.version; 
/* 287 */       if ("bluecove.stack".equals(property))
/* 288 */         return BlueCoveImpl.instance().getBluetoothStack().getStackID(); 
/* 289 */       if ("bluecove.feature.l2cap".equals(property))
/* 290 */         return BlueCoveImpl.instance().getLocalDeviceFeature(1); 
/* 291 */       if ("bluecove.feature.service_attributes".equals(property))
/* 292 */         return BlueCoveImpl.instance().getLocalDeviceFeature(2); 
/* 293 */       if ("bluecove.feature.set_device_service_classes".equals(property))
/* 294 */         return BlueCoveImpl.instance().getLocalDeviceFeature(4); 
/* 295 */       if ("bluecove.feature.rssi".equals(property))
/* 296 */         return BlueCoveImpl.instance().getLocalDeviceFeature(8); 
/* 297 */       if ("bluecove.connections".equals(property)) {
/* 298 */         return String.valueOf(RemoteDeviceHelper.openConnections());
/*     */       }
/* 300 */       return BlueCoveImpl.instance().getBluetoothStack().getLocalDeviceProperty(property);
/* 301 */     } catch (BluetoothStateException e) {
/* 302 */       throw (RuntimeException)UtilsJavaSE.initCause(new RuntimeException(e.getMessage()), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDiscoverable() {
/* 319 */     return this.bluetoothStack.getLocalDeviceDiscoverable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBluetoothAddress() {
/* 330 */     return this.addressStr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceRecord getRecord(Connection notifier) {
/* 386 */     if (notifier == null) {
/* 387 */       throw new NullPointerException("notifier is null");
/*     */     }
/*     */     
/* 390 */     if (!(notifier instanceof BluetoothConnectionNotifierServiceRecordAccess)) {
/* 391 */       throw new IllegalArgumentException("connection is not a Bluetooth notifier");
/*     */     }
/*     */     
/* 394 */     return ((BluetoothConnectionNotifierServiceRecordAccess)notifier).getServiceRecord();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateRecord(ServiceRecord srvRecord) throws ServiceRegistrationException {
/* 488 */     if (srvRecord == null) {
/* 489 */       throw new NullPointerException("Service Record is null");
/*     */     }
/* 491 */     ServiceRecordsRegistry.updateServiceRecord(srvRecord);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\javax\bluetooth\LocalDevice.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */