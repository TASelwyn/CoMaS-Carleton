package javax.bluetooth;

public interface DiscoveryListener {
  public static final int INQUIRY_COMPLETED = 0;
  
  public static final int INQUIRY_TERMINATED = 5;
  
  public static final int INQUIRY_ERROR = 7;
  
  public static final int SERVICE_SEARCH_COMPLETED = 1;
  
  public static final int SERVICE_SEARCH_TERMINATED = 2;
  
  public static final int SERVICE_SEARCH_ERROR = 3;
  
  public static final int SERVICE_SEARCH_NO_RECORDS = 4;
  
  public static final int SERVICE_SEARCH_DEVICE_NOT_REACHABLE = 6;
  
  void deviceDiscovered(RemoteDevice paramRemoteDevice, DeviceClass paramDeviceClass);
  
  void servicesDiscovered(int paramInt, ServiceRecord[] paramArrayOfServiceRecord);
  
  void serviceSearchCompleted(int paramInt1, int paramInt2);
  
  void inquiryCompleted(int paramInt);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\javax\bluetooth\DiscoveryListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */