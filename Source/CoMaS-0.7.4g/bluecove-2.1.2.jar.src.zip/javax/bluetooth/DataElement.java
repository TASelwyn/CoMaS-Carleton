/*     */ package javax.bluetooth;
/*     */ 
/*     */ import com.intel.bluetooth.Utils;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataElement
/*     */ {
/*     */   public static final int NULL = 0;
/*     */   public static final int U_INT_1 = 8;
/*     */   public static final int U_INT_2 = 9;
/*     */   public static final int U_INT_4 = 10;
/*     */   public static final int U_INT_8 = 11;
/*     */   public static final int U_INT_16 = 12;
/*     */   public static final int INT_1 = 16;
/*     */   public static final int INT_2 = 17;
/*     */   public static final int INT_4 = 18;
/*     */   public static final int INT_8 = 19;
/*     */   public static final int INT_16 = 20;
/*     */   public static final int URL = 64;
/*     */   public static final int UUID = 24;
/*     */   public static final int BOOL = 40;
/*     */   public static final int STRING = 32;
/*     */   public static final int DATSEQ = 48;
/*     */   public static final int DATALT = 56;
/*     */   private Object value;
/*     */   private int valueType;
/*     */   
/*     */   public DataElement(int valueType) {
/* 280 */     switch (valueType) {
/*     */       case 0:
/* 282 */         this.value = null;
/*     */         break;
/*     */       case 48:
/*     */       case 56:
/* 286 */         this.value = new Vector();
/*     */         break;
/*     */       default:
/* 289 */         throw new IllegalArgumentException("valueType " + typeToString(valueType) + " is not DATSEQ, DATALT or NULL");
/*     */     } 
/*     */ 
/*     */     
/* 293 */     this.valueType = valueType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataElement(boolean bool) {
/* 307 */     this.value = bool ? Boolean.TRUE : Boolean.FALSE;
/* 308 */     this.valueType = 40;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataElement(int valueType, long value) {
/* 380 */     switch (valueType) {
/*     */       case 8:
/* 382 */         if (value < 0L || value > 255L) {
/* 383 */           throw new IllegalArgumentException(value + " not U_INT_1");
/*     */         }
/*     */         break;
/*     */       case 9:
/* 387 */         if (value < 0L || value > 65535L) {
/* 388 */           throw new IllegalArgumentException(value + " not U_INT_2");
/*     */         }
/*     */         break;
/*     */       case 10:
/* 392 */         if (value < 0L || value > 4294967295L) {
/* 393 */           throw new IllegalArgumentException(value + " not U_INT_4");
/*     */         }
/*     */         break;
/*     */       case 16:
/* 397 */         if (value < -128L || value > 127L) {
/* 398 */           throw new IllegalArgumentException(value + " not INT_1");
/*     */         }
/*     */         break;
/*     */       case 17:
/* 402 */         if (value < -32768L || value > 32767L) {
/* 403 */           throw new IllegalArgumentException(value + " not INT_2");
/*     */         }
/*     */         break;
/*     */       case 18:
/* 407 */         if (value < -2147483648L || value > 2147483647L) {
/* 408 */           throw new IllegalArgumentException(value + " not INT_4");
/*     */         }
/*     */         break;
/*     */       
/*     */       case 19:
/*     */         break;
/*     */       default:
/* 415 */         throw new IllegalArgumentException("type " + typeToString(valueType) + " can't be represented long");
/*     */     } 
/*     */     
/* 418 */     this.value = new Long(value);
/* 419 */     this.valueType = valueType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataElement(int valueType, Object value) {
/* 484 */     if (value == null) {
/* 485 */       throw new IllegalArgumentException("value param is null");
/*     */     }
/* 487 */     switch (valueType) {
/*     */       case 32:
/*     */       case 64:
/* 490 */         if (!(value instanceof String)) {
/* 491 */           throw new IllegalArgumentException("value param should be String");
/*     */         }
/*     */         break;
/*     */       case 24:
/* 495 */         if (!(value instanceof UUID)) {
/* 496 */           throw new IllegalArgumentException("value param should be UUID");
/*     */         }
/*     */         break;
/*     */       case 11:
/* 500 */         if (!(value instanceof byte[]) || ((byte[])value).length != 8) {
/* 501 */           throw new IllegalArgumentException("value param should be byte[8]");
/*     */         }
/*     */         break;
/*     */       case 12:
/*     */       case 20:
/* 506 */         if (!(value instanceof byte[]) || ((byte[])value).length != 16) {
/* 507 */           throw new IllegalArgumentException("value param should be byte[16]");
/*     */         }
/*     */         break;
/*     */       default:
/* 511 */         throw new IllegalArgumentException("type " + typeToString(valueType) + " can't be represented by Object");
/*     */     } 
/* 513 */     this.value = value;
/* 514 */     this.valueType = valueType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addElement(DataElement elem) {
/* 542 */     if (elem == null) {
/* 543 */       throw new NullPointerException("elem param is null");
/*     */     }
/* 545 */     switch (this.valueType) {
/*     */       case 48:
/*     */       case 56:
/* 548 */         ((Vector)this.value).addElement(elem);
/*     */         return;
/*     */     } 
/* 551 */     throw new ClassCastException("DataType is not DATSEQ or DATALT");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertElementAt(DataElement elem, int index) {
/* 593 */     if (elem == null) {
/* 594 */       throw new NullPointerException("elem param is null");
/*     */     }
/* 596 */     switch (this.valueType) {
/*     */       case 48:
/*     */       case 56:
/* 599 */         ((Vector)this.value).insertElementAt(elem, index);
/*     */         return;
/*     */     } 
/* 602 */     throw new ClassCastException("DataType is not DATSEQ or DATALT");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize() {
/* 620 */     switch (this.valueType) {
/*     */       case 48:
/*     */       case 56:
/* 623 */         return ((Vector)this.value).size();
/*     */     } 
/* 625 */     throw new ClassCastException("DataType is not DATSEQ or DATALT");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeElement(DataElement elem) {
/* 661 */     if (elem == null) {
/* 662 */       throw new NullPointerException("elem param is null");
/*     */     }
/* 664 */     switch (this.valueType) {
/*     */       case 48:
/*     */       case 56:
/* 667 */         return ((Vector)this.value).removeElement(elem);
/*     */     } 
/* 669 */     throw new ClassCastException("DataType is not DATSEQ or DATALT");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDataType() {
/* 700 */     return this.valueType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLong() {
/* 722 */     switch (this.valueType) {
/*     */       case 8:
/*     */       case 9:
/*     */       case 10:
/*     */       case 16:
/*     */       case 17:
/*     */       case 18:
/*     */       case 19:
/* 730 */         return ((Long)this.value).longValue();
/*     */     } 
/* 732 */     throw new ClassCastException("DataType is not INT");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBoolean() {
/* 750 */     if (this.valueType == 40) {
/* 751 */       return ((Boolean)this.value).booleanValue();
/*     */     }
/* 753 */     throw new ClassCastException("DataType is not BOOL");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue() {
/* 816 */     switch (this.valueType) {
/*     */       case 24:
/*     */       case 32:
/*     */       case 64:
/* 820 */         return this.value;
/*     */       
/*     */       case 11:
/*     */       case 12:
/*     */       case 20:
/* 825 */         return Utils.clone((byte[])this.value);
/*     */       case 48:
/*     */       case 56:
/* 828 */         return ((Vector)this.value).elements();
/*     */     } 
/* 830 */     throw new ClassCastException("DataType is simple java type");
/*     */   }
/*     */ 
/*     */   
/*     */   private static String typeToString(int type) {
/* 835 */     switch (type) {
/*     */       case 0:
/* 837 */         return "NULL";
/*     */       case 8:
/* 839 */         return "U_INT_1";
/*     */       case 9:
/* 841 */         return "U_INT_2";
/*     */       case 10:
/* 843 */         return "U_INT_4";
/*     */       case 11:
/* 845 */         return "U_INT_8";
/*     */       case 12:
/* 847 */         return "U_INT_16";
/*     */       case 16:
/* 849 */         return "INT_1";
/*     */       case 17:
/* 851 */         return "INT_2";
/*     */       case 18:
/* 853 */         return "INT_4";
/*     */       case 19:
/* 855 */         return "INT_8";
/*     */       case 20:
/* 857 */         return "INT_16";
/*     */       case 64:
/* 859 */         return "URL";
/*     */       case 32:
/* 861 */         return "STRING";
/*     */       case 24:
/* 863 */         return "UUID";
/*     */       case 48:
/* 865 */         return "DATSEQ";
/*     */       case 40:
/* 867 */         return "BOOL";
/*     */       case 56:
/* 869 */         return "DATALT";
/*     */     } 
/* 871 */     return "Unknown" + type;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*     */     byte[] b;
/*     */     StringBuffer buf;
/*     */     StringBuffer stringBuffer1;
/*     */     Enumeration e;
/*     */     int i;
/* 882 */     switch (this.valueType) {
/*     */       case 8:
/*     */       case 9:
/*     */       case 10:
/*     */       case 16:
/*     */       case 17:
/*     */       case 18:
/*     */       case 19:
/* 890 */         return typeToString(this.valueType) + " 0x" + Utils.toHexString(((Long)this.value).longValue());
/*     */       case 24:
/*     */       case 32:
/*     */       case 40:
/*     */       case 64:
/* 895 */         return typeToString(this.valueType) + " " + this.value.toString();
/*     */       case 11:
/*     */       case 12:
/*     */       case 20:
/* 899 */         b = (byte[])this.value;
/*     */         
/* 901 */         stringBuffer1 = new StringBuffer();
/* 902 */         stringBuffer1.append(typeToString(this.valueType)).append(" ");
/*     */         
/* 904 */         for (i = 0; i < b.length; i++) {
/* 905 */           stringBuffer1.append(Integer.toHexString(b[i] >> 4 & 0xF));
/* 906 */           stringBuffer1.append(Integer.toHexString(b[i] & 0xF));
/*     */         } 
/*     */         
/* 909 */         return stringBuffer1.toString();
/*     */       
/*     */       case 48:
/* 912 */         buf = new StringBuffer("DATSEQ {\n");
/*     */         
/* 914 */         for (e = ((Vector)this.value).elements(); e.hasMoreElements(); ) {
/* 915 */           buf.append(e.nextElement());
/* 916 */           buf.append("\n");
/*     */         } 
/*     */         
/* 919 */         buf.append("}");
/*     */         
/* 921 */         return buf.toString();
/*     */       
/*     */       case 56:
/* 924 */         buf = new StringBuffer("DATALT {\n");
/*     */         
/* 926 */         for (e = ((Vector)this.value).elements(); e.hasMoreElements(); ) {
/* 927 */           buf.append(e.nextElement());
/* 928 */           buf.append("\n");
/*     */         } 
/*     */         
/* 931 */         buf.append("}");
/*     */         
/* 933 */         return buf.toString();
/*     */     } 
/*     */     
/* 936 */     return "Unknown" + this.valueType;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\javax\bluetooth\DataElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */