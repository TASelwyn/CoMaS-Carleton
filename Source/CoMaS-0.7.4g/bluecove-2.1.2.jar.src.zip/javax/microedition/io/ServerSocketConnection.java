package javax.microedition.io;

import java.io.IOException;

public interface ServerSocketConnection extends StreamConnectionNotifier {
  String getLocalAddress() throws IOException;
  
  int getLocalPort() throws IOException;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\javax\microedition\io\ServerSocketConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */