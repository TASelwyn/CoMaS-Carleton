package javax.microedition.io;

public interface StreamConnection extends InputConnection, OutputConnection {}
