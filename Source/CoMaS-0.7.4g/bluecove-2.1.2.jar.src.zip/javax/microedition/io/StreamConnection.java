package javax.microedition.io;

public interface StreamConnection extends InputConnection, OutputConnection {}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\javax\microedition\io\StreamConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */