package javax.microedition.io;

import java.io.IOException;

public interface SocketConnection extends StreamConnection {
  public static final byte DELAY = 0;
  
  public static final byte LINGER = 1;
  
  public static final byte KEEPALIVE = 2;
  
  public static final byte RCVBUF = 3;
  
  public static final byte SNDBUF = 4;
  
  void setSocketOption(byte paramByte, int paramInt) throws IllegalArgumentException, IOException;
  
  int getSocketOption(byte paramByte) throws IllegalArgumentException, IOException;
  
  String getLocalAddress() throws IOException;
  
  int getLocalPort() throws IOException;
  
  String getAddress() throws IOException;
  
  int getPort() throws IOException;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\javax\microedition\io\SocketConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */