/*     */ package javax.microedition.io;
/*     */ 
/*     */ import com.intel.bluetooth.DebugLog;
/*     */ import com.intel.bluetooth.MicroeditionConnector;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Connector
/*     */ {
/*     */   public static final int READ = 1;
/*     */   public static final int WRITE = 2;
/*     */   public static final int READ_WRITE = 3;
/*     */   
/*     */   public static Connection open(String name) throws IOException {
/*  82 */     DebugLog.debug("open using BlueCove javax.microedition.io.Connector");
/*  83 */     return MicroeditionConnector.open(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Connection open(String name, int mode) throws IOException {
/*  97 */     return MicroeditionConnector.open(name, mode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Connection open(String name, int mode, boolean timeouts) throws IOException {
/* 113 */     return MicroeditionConnector.open(name, mode, timeouts);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DataInputStream openDataInputStream(String name) throws IOException {
/* 127 */     return MicroeditionConnector.openDataInputStream(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DataOutputStream openDataOutputStream(String name) throws IOException {
/* 141 */     return MicroeditionConnector.openDataOutputStream(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InputStream openInputStream(String name) throws IOException {
/* 154 */     return MicroeditionConnector.openInputStream(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static OutputStream openOutputStream(String name) throws IOException {
/* 167 */     return MicroeditionConnector.openOutputStream(name);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\javax\microedition\io\Connector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */