package javax.microedition.io;

public interface ContentConnection extends StreamConnection {
  String getType();
  
  String getEncoding();
  
  long getLength();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\javax\microedition\io\ContentConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */