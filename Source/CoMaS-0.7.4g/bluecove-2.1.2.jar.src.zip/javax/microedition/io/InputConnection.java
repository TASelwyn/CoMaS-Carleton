package javax.microedition.io;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;

public interface InputConnection extends Connection {
  InputStream openInputStream() throws IOException;
  
  DataInputStream openDataInputStream() throws IOException;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\javax\microedition\io\InputConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */