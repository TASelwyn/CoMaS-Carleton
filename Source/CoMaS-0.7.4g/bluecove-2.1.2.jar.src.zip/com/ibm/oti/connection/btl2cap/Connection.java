package com.ibm.oti.connection.btl2cap;

import com.intel.bluetooth.btl2cap.Connection;

public class Connection extends Connection {}
