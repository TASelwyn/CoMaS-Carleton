package com.ibm.oti.connection.btl2cap;

import com.intel.bluetooth.btl2cap.Connection;

public class Connection extends Connection {}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\ibm\oti\connection\btl2cap\Connection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */