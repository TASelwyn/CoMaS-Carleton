package com.ibm.oti.connection.btgoep;

import com.intel.bluetooth.btgoep.Connection;

public class Connection extends Connection {}
