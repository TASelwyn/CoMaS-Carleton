package com.ibm.oti.connection.btgoep;

import com.intel.bluetooth.btgoep.Connection;

public class Connection extends Connection {}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\ibm\oti\connection\btgoep\Connection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */