package com.ibm.oti.connection.btspp;

import com.intel.bluetooth.btspp.Connection;

public class Connection extends Connection {}
