/*    */ package com.intel.bluetooth;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NativeTestInterfaces
/*    */ {
/*    */   static boolean loadDllMS() {
/* 35 */     return NativeLibLoader.isAvailable("intelbth");
/*    */   }
/*    */   
/*    */   static boolean loadDllWIDCOMM() {
/* 39 */     return NativeLibLoader.isAvailable("bluecove");
/*    */   }
/*    */   
/*    */   static native byte[] testUUIDConversion(byte[] paramArrayOfbyte);
/*    */   
/*    */   static native long testReceiveBufferCreate(int paramInt);
/*    */   
/*    */   static native void testReceiveBufferClose(long paramLong);
/*    */   
/*    */   static native int testReceiveBufferWrite(long paramLong, byte[] paramArrayOfbyte);
/*    */   
/*    */   static native int testReceiveBufferRead(long paramLong, byte[] paramArrayOfbyte);
/*    */   
/*    */   static native int testReceiveBufferRead(long paramLong);
/*    */   
/*    */   static native int testReceiveBufferSkip(long paramLong, int paramInt);
/*    */   
/*    */   static native int testReceiveBufferAvailable(long paramLong);
/*    */   
/*    */   static native boolean testReceiveBufferIsOverflown(long paramLong);
/*    */   
/*    */   static native boolean testReceiveBufferIsCorrupted(long paramLong);
/*    */   
/*    */   static native void testThrowException(int paramInt) throws Exception;
/*    */   
/*    */   static native void testDebug(int paramInt, String paramString);
/*    */   
/*    */   static native byte[] testOsXDataElementConversion(int paramInt1, int paramInt2, long paramLong, byte[] paramArrayOfbyte);
/*    */   
/*    */   static native void testOsXRunnableLoop(int paramInt1, int paramInt2);
/*    */   
/*    */   static native boolean testWIDCOMMConstants();
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\NativeTestInterfaces.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */