/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.bluetooth.BluetoothStateException;
/*     */ import javax.bluetooth.DeviceClass;
/*     */ import javax.bluetooth.DiscoveryAgent;
/*     */ import javax.bluetooth.DiscoveryListener;
/*     */ import javax.bluetooth.RemoteDevice;
/*     */ import javax.bluetooth.ServiceRecord;
/*     */ import javax.bluetooth.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelectServiceHandler
/*     */   implements DiscoveryListener
/*     */ {
/*     */   private DiscoveryAgent agent;
/*  49 */   private Object inquiryCompletedEvent = new Object();
/*     */   
/*     */   private boolean inquiryCompleted;
/*     */   
/*  53 */   private Object serviceSearchCompletedEvent = new Object();
/*     */   
/*     */   private boolean serviceSearchCompleted;
/*     */   
/*  57 */   private Hashtable devicesProcessed = new Hashtable();
/*     */   
/*  59 */   private Vector serviceSearchDeviceQueue = new Vector();
/*     */   
/*     */   private ServiceRecord servRecordDiscovered;
/*     */   
/*     */   private static int threadNumber;
/*     */   
/*     */   private static synchronized int nextThreadNum() {
/*  66 */     return threadNumber++;
/*     */   }
/*     */   
/*     */   public SelectServiceHandler(DiscoveryAgent agent) {
/*  70 */     this.agent = agent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String selectService(UUID uuid, int security, boolean master) throws BluetoothStateException {
/* 120 */     if (uuid == null) {
/* 121 */       throw new NullPointerException("uuid is null");
/*     */     }
/* 123 */     switch (security) {
/*     */       case 0:
/*     */       case 1:
/*     */       case 2:
/*     */         break;
/*     */       default:
/* 129 */         throw new IllegalArgumentException();
/*     */     } 
/*     */     
/* 132 */     RemoteDevice[] devs = this.agent.retrieveDevices(1); int i;
/* 133 */     for (i = 0; devs != null && i < devs.length; i++) {
/* 134 */       ServiceRecord sr = findServiceOnDevice(uuid, devs[i]);
/* 135 */       if (sr != null) {
/* 136 */         return sr.getConnectionURL(security, master);
/*     */       }
/*     */     } 
/* 139 */     devs = this.agent.retrieveDevices(0);
/* 140 */     for (i = 0; devs != null && i < devs.length; i++) {
/* 141 */       ServiceRecord sr = findServiceOnDevice(uuid, devs[i]);
/* 142 */       if (sr != null) {
/* 143 */         return sr.getConnectionURL(security, master);
/*     */       }
/*     */     } 
/* 146 */     ParallelSearchServicesThread t = new ParallelSearchServicesThread(this, uuid);
/* 147 */     t.start();
/*     */     
/* 149 */     synchronized (this.inquiryCompletedEvent) {
/* 150 */       if (!this.agent.startInquiry(10390323, this)) {
/* 151 */         return null;
/*     */       }
/* 153 */       while (!this.inquiryCompleted) {
/*     */         try {
/* 155 */           this.inquiryCompletedEvent.wait();
/* 156 */         } catch (InterruptedException e) {
/* 157 */           return null;
/*     */         } 
/*     */       } 
/* 160 */       this.agent.cancelInquiry(this);
/*     */     } 
/*     */     
/* 163 */     if (this.servRecordDiscovered == null && !t.processedAll()) {
/* 164 */       synchronized (this.serviceSearchDeviceQueue) {
/* 165 */         this.serviceSearchDeviceQueue.notifyAll();
/*     */       } 
/*     */       try {
/* 168 */         t.join();
/* 169 */       } catch (InterruptedException e) {
/* 170 */         return null;
/*     */       } 
/*     */     } 
/* 173 */     t.interrupt();
/*     */     
/* 175 */     if (this.servRecordDiscovered != null) {
/* 176 */       return this.servRecordDiscovered.getConnectionURL(security, master);
/*     */     }
/*     */     
/* 179 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private class ParallelSearchServicesThread
/*     */     extends Thread
/*     */   {
/*     */     private boolean stoped;
/*     */     private int processedNext;
/*     */     private int processedSize;
/*     */     private UUID uuid;
/*     */     private final SelectServiceHandler this$0;
/*     */     
/*     */     ParallelSearchServicesThread(SelectServiceHandler this$0, UUID uuid) {
/* 193 */       super("SelectServiceThread-" + SelectServiceHandler.nextThreadNum()); this.this$0 = this$0; this.stoped = false; this.processedNext = 0; this.processedSize = 0;
/* 194 */       this.uuid = uuid;
/*     */     }
/*     */     
/*     */     boolean processedAll() {
/* 198 */       return (this.processedNext == this.this$0.serviceSearchDeviceQueue.size());
/*     */     }
/*     */     
/*     */     public void interrupt() {
/* 202 */       this.stoped = true;
/* 203 */       synchronized (this.this$0.serviceSearchDeviceQueue) {
/* 204 */         this.this$0.serviceSearchDeviceQueue.notifyAll();
/*     */       } 
/* 206 */       super.interrupt();
/*     */     }
/*     */     
/*     */     public void run() {
/* 210 */       label30: while (!this.stoped && this.this$0.servRecordDiscovered == null) {
/* 211 */         synchronized (this.this$0.serviceSearchDeviceQueue) {
/* 212 */           if (this.this$0.inquiryCompleted && this.processedSize == this.this$0.serviceSearchDeviceQueue.size()) {
/*     */             return;
/*     */           }
/* 215 */           if (this.processedSize == this.this$0.serviceSearchDeviceQueue.size()) {
/*     */             try {
/* 217 */               this.this$0.serviceSearchDeviceQueue.wait();
/* 218 */             } catch (InterruptedException e) {
/*     */               return;
/*     */             } 
/*     */           }
/* 222 */           this.processedSize = this.this$0.serviceSearchDeviceQueue.size();
/*     */         } 
/* 224 */         for (int i = this.processedNext; i < this.processedSize; i++) {
/* 225 */           RemoteDevice btDevice = this.this$0.serviceSearchDeviceQueue.elementAt(i);
/* 226 */           if (this.this$0.findServiceOnDevice(this.uuid, btDevice) != null) {
/*     */             break label30;
/*     */           }
/*     */         } 
/* 230 */         this.processedNext = this.processedSize + 1;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private ServiceRecord findServiceOnDevice(UUID uuid, RemoteDevice device) {
/* 237 */     if (this.devicesProcessed.containsKey(device)) {
/* 238 */       return null;
/*     */     }
/* 240 */     this.devicesProcessed.put(device, device);
/* 241 */     DebugLog.debug("searchServices on ", device);
/* 242 */     synchronized (this.serviceSearchCompletedEvent) {
/*     */       try {
/* 244 */         this.serviceSearchCompleted = false;
/* 245 */         this.agent.searchServices(null, new UUID[] { uuid }, device, this);
/* 246 */       } catch (BluetoothStateException e) {
/* 247 */         DebugLog.error("searchServices", (Throwable)e);
/* 248 */         return null;
/*     */       } 
/* 250 */       while (!this.serviceSearchCompleted) {
/*     */         try {
/* 252 */           this.serviceSearchCompletedEvent.wait();
/* 253 */         } catch (InterruptedException e) {
/* 254 */           return null;
/*     */         } 
/*     */       } 
/*     */     } 
/* 258 */     return this.servRecordDiscovered;
/*     */   }
/*     */   
/*     */   public void deviceDiscovered(RemoteDevice btDevice, DeviceClass cod) {
/* 262 */     if (this.devicesProcessed.containsKey(btDevice)) {
/*     */       return;
/*     */     }
/* 265 */     synchronized (this.serviceSearchDeviceQueue) {
/* 266 */       this.serviceSearchDeviceQueue.addElement(btDevice);
/* 267 */       this.serviceSearchDeviceQueue.notifyAll();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void inquiryCompleted(int discType) {
/* 272 */     synchronized (this.inquiryCompletedEvent) {
/* 273 */       this.inquiryCompleted = true;
/* 274 */       this.inquiryCompletedEvent.notifyAll();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void serviceSearchCompleted(int transID, int respCode) {
/* 279 */     synchronized (this.serviceSearchCompletedEvent) {
/* 280 */       this.serviceSearchCompleted = true;
/* 281 */       this.serviceSearchCompletedEvent.notifyAll();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void servicesDiscovered(int transID, ServiceRecord[] servRecord) {
/* 286 */     if (servRecord.length > 0 && this.servRecordDiscovered == null) {
/* 287 */       this.servRecordDiscovered = servRecord[0];
/* 288 */       synchronized (this.serviceSearchCompletedEvent) {
/* 289 */         this.serviceSearchCompleted = true;
/* 290 */         this.serviceSearchCompletedEvent.notifyAll();
/*     */       } 
/* 292 */       synchronized (this.inquiryCompletedEvent) {
/* 293 */         this.inquiryCompleted = true;
/* 294 */         this.inquiryCompletedEvent.notifyAll();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\SelectServiceHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */