package com.intel.bluetooth;

import java.util.Hashtable;
import java.util.Vector;
import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DeviceClass;
import javax.bluetooth.DiscoveryAgent;
import javax.bluetooth.DiscoveryListener;
import javax.bluetooth.RemoteDevice;
import javax.bluetooth.ServiceRecord;
import javax.bluetooth.UUID;

public class SelectServiceHandler implements DiscoveryListener {
  private DiscoveryAgent agent;
  
  private Object inquiryCompletedEvent = new Object();
  
  private boolean inquiryCompleted;
  
  private Object serviceSearchCompletedEvent = new Object();
  
  private boolean serviceSearchCompleted;
  
  private Hashtable devicesProcessed = new Hashtable();
  
  private Vector serviceSearchDeviceQueue = new Vector();
  
  private ServiceRecord servRecordDiscovered;
  
  private static int threadNumber;
  
  private static synchronized int nextThreadNum() {
    return threadNumber++;
  }
  
  public SelectServiceHandler(DiscoveryAgent agent) {
    this.agent = agent;
  }
  
  public String selectService(UUID uuid, int security, boolean master) throws BluetoothStateException {
    if (uuid == null)
      throw new NullPointerException("uuid is null"); 
    switch (security) {
      case 0:
      case 1:
      case 2:
        break;
      default:
        throw new IllegalArgumentException();
    } 
    RemoteDevice[] devs = this.agent.retrieveDevices(1);
    int i;
    for (i = 0; devs != null && i < devs.length; i++) {
      ServiceRecord sr = findServiceOnDevice(uuid, devs[i]);
      if (sr != null)
        return sr.getConnectionURL(security, master); 
    } 
    devs = this.agent.retrieveDevices(0);
    for (i = 0; devs != null && i < devs.length; i++) {
      ServiceRecord sr = findServiceOnDevice(uuid, devs[i]);
      if (sr != null)
        return sr.getConnectionURL(security, master); 
    } 
    ParallelSearchServicesThread t = new ParallelSearchServicesThread(this, uuid);
    t.start();
    synchronized (this.inquiryCompletedEvent) {
      if (!this.agent.startInquiry(10390323, this))
        return null; 
      while (!this.inquiryCompleted) {
        try {
          this.inquiryCompletedEvent.wait();
        } catch (InterruptedException e) {
          return null;
        } 
      } 
      this.agent.cancelInquiry(this);
    } 
    if (this.servRecordDiscovered == null && !t.processedAll()) {
      synchronized (this.serviceSearchDeviceQueue) {
        this.serviceSearchDeviceQueue.notifyAll();
      } 
      try {
        t.join();
      } catch (InterruptedException e) {
        return null;
      } 
    } 
    t.interrupt();
    if (this.servRecordDiscovered != null)
      return this.servRecordDiscovered.getConnectionURL(security, master); 
    return null;
  }
  
  private class ParallelSearchServicesThread extends Thread {
    private boolean stoped;
    
    private int processedNext;
    
    private int processedSize;
    
    private UUID uuid;
    
    private final SelectServiceHandler this$0;
    
    ParallelSearchServicesThread(SelectServiceHandler this$0, UUID uuid) {
      super("SelectServiceThread-" + SelectServiceHandler.nextThreadNum());
      this.this$0 = this$0;
      this.stoped = false;
      this.processedNext = 0;
      this.processedSize = 0;
      this.uuid = uuid;
    }
    
    boolean processedAll() {
      return (this.processedNext == this.this$0.serviceSearchDeviceQueue.size());
    }
    
    public void interrupt() {
      this.stoped = true;
      synchronized (this.this$0.serviceSearchDeviceQueue) {
        this.this$0.serviceSearchDeviceQueue.notifyAll();
      } 
      super.interrupt();
    }
    
    public void run() {
      label30: while (!this.stoped && this.this$0.servRecordDiscovered == null) {
        synchronized (this.this$0.serviceSearchDeviceQueue) {
          if (this.this$0.inquiryCompleted && this.processedSize == this.this$0.serviceSearchDeviceQueue.size())
            return; 
          if (this.processedSize == this.this$0.serviceSearchDeviceQueue.size())
            try {
              this.this$0.serviceSearchDeviceQueue.wait();
            } catch (InterruptedException e) {
              return;
            }  
          this.processedSize = this.this$0.serviceSearchDeviceQueue.size();
        } 
        for (int i = this.processedNext; i < this.processedSize; i++) {
          RemoteDevice btDevice = this.this$0.serviceSearchDeviceQueue.elementAt(i);
          if (this.this$0.findServiceOnDevice(this.uuid, btDevice) != null)
            break label30; 
        } 
        this.processedNext = this.processedSize + 1;
      } 
    }
  }
  
  private ServiceRecord findServiceOnDevice(UUID uuid, RemoteDevice device) {
    if (this.devicesProcessed.containsKey(device))
      return null; 
    this.devicesProcessed.put(device, device);
    DebugLog.debug("searchServices on ", device);
    synchronized (this.serviceSearchCompletedEvent) {
      try {
        this.serviceSearchCompleted = false;
        this.agent.searchServices(null, new UUID[] { uuid }, device, this);
      } catch (BluetoothStateException e) {
        DebugLog.error("searchServices", (Throwable)e);
        return null;
      } 
      while (!this.serviceSearchCompleted) {
        try {
          this.serviceSearchCompletedEvent.wait();
        } catch (InterruptedException e) {
          return null;
        } 
      } 
    } 
    return this.servRecordDiscovered;
  }
  
  public void deviceDiscovered(RemoteDevice btDevice, DeviceClass cod) {
    if (this.devicesProcessed.containsKey(btDevice))
      return; 
    synchronized (this.serviceSearchDeviceQueue) {
      this.serviceSearchDeviceQueue.addElement(btDevice);
      this.serviceSearchDeviceQueue.notifyAll();
    } 
  }
  
  public void inquiryCompleted(int discType) {
    synchronized (this.inquiryCompletedEvent) {
      this.inquiryCompleted = true;
      this.inquiryCompletedEvent.notifyAll();
    } 
  }
  
  public void serviceSearchCompleted(int transID, int respCode) {
    synchronized (this.serviceSearchCompletedEvent) {
      this.serviceSearchCompleted = true;
      this.serviceSearchCompletedEvent.notifyAll();
    } 
  }
  
  public void servicesDiscovered(int transID, ServiceRecord[] servRecord) {
    if (servRecord.length > 0 && this.servRecordDiscovered == null) {
      this.servRecordDiscovered = servRecord[0];
      synchronized (this.serviceSearchCompletedEvent) {
        this.serviceSearchCompleted = true;
        this.serviceSearchCompletedEvent.notifyAll();
      } 
      synchronized (this.inquiryCompletedEvent) {
        this.inquiryCompleted = true;
        this.inquiryCompletedEvent.notifyAll();
      } 
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\SelectServiceHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */