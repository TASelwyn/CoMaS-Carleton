/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.bluetooth.DataElement;
/*     */ import javax.bluetooth.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SDPInputStream
/*     */   extends InputStream
/*     */ {
/*     */   private InputStream source;
/*     */   private int pos;
/*     */   
/*     */   public SDPInputStream(InputStream in) {
/*  39 */     this.source = in;
/*  40 */     this.pos = 0;
/*     */   }
/*     */   
/*     */   public int read() throws IOException {
/*  44 */     return this.source.read();
/*     */   }
/*     */   
/*     */   private long readLong(int size) throws IOException {
/*  48 */     long result = 0L;
/*  49 */     for (int i = 0; i < size; i++) {
/*  50 */       result = result << 8L | read();
/*     */     }
/*  52 */     this.pos += size;
/*  53 */     return result;
/*     */   }
/*     */   
/*     */   private int readInteger(int size) throws IOException {
/*  57 */     int result = 0;
/*  58 */     for (int i = 0; i < size; i++) {
/*  59 */       result = result << 8 | read();
/*     */     }
/*  61 */     this.pos += size;
/*  62 */     return result;
/*     */   }
/*     */   
/*     */   private String hexString(byte[] b) throws IOException {
/*  66 */     StringBuffer buf = new StringBuffer();
/*  67 */     for (int i = 0; i < b.length; i++) {
/*  68 */       buf.append(Integer.toHexString(b[i] >> 4 & 0xF));
/*  69 */       buf.append(Integer.toHexString(b[i] & 0xF));
/*     */     } 
/*  71 */     return buf.toString();
/*     */   }
/*     */   
/*     */   private byte[] readBytes(int size) throws IOException {
/*  75 */     byte[] result = new byte[size];
/*  76 */     for (int i = 0; i < size; i++) {
/*  77 */       result[i] = (byte)read();
/*     */     }
/*  79 */     this.pos += size;
/*  80 */     return result; } public DataElement readElement() throws IOException { UUID uuid; int length; String strValue;
/*     */     DataElement element;
/*     */     int started, i;
/*     */     long end;
/*  84 */     int header = read();
/*  85 */     int type = header >> 3 & 0x1F;
/*  86 */     int sizeDescriptor = header & 0x7;
/*     */     
/*  88 */     this.pos++;
/*     */     
/*  90 */     switch (type) {
/*     */       case 0:
/*  92 */         return new DataElement(0);
/*     */       case 1:
/*  94 */         switch (sizeDescriptor) {
/*     */           case 0:
/*  96 */             return new DataElement(8, readLong(1));
/*     */           case 1:
/*  98 */             return new DataElement(9, readLong(2));
/*     */           case 2:
/* 100 */             return new DataElement(10, readLong(4));
/*     */           case 3:
/* 102 */             return new DataElement(11, readBytes(8));
/*     */           case 4:
/* 104 */             return new DataElement(12, readBytes(16));
/*     */         } 
/* 106 */         throw new IOException();
/*     */       
/*     */       case 2:
/* 109 */         switch (sizeDescriptor) {
/*     */           case 0:
/* 111 */             return new DataElement(16, (byte)(int)readLong(1));
/*     */           case 1:
/* 113 */             return new DataElement(17, (short)(int)readLong(2));
/*     */           case 2:
/* 115 */             return new DataElement(18, (int)readLong(4));
/*     */           case 3:
/* 117 */             return new DataElement(19, readLong(8));
/*     */           case 4:
/* 119 */             return new DataElement(20, readBytes(16));
/*     */         } 
/* 121 */         throw new IOException();
/*     */ 
/*     */       
/*     */       case 3:
/* 125 */         uuid = null;
/*     */         
/* 127 */         switch (sizeDescriptor) {
/*     */           case 1:
/* 129 */             uuid = new UUID(readLong(2));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 141 */             return new DataElement(24, uuid);case 2: uuid = new UUID(readLong(4)); return new DataElement(24, uuid);case 4: uuid = new UUID(hexString(readBytes(16)), false); return new DataElement(24, uuid);
/*     */         } 
/*     */         throw new IOException();
/*     */       case 4:
/* 145 */         length = -1;
/*     */         
/* 147 */         switch (sizeDescriptor) {
/*     */           case 5:
/* 149 */             length = readInteger(1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 160 */             strValue = Utils.newStringUTF8(readBytes(length));
/* 161 */             DebugLog.debug("DataElement.STRING", strValue, Integer.toString(length - strValue.length()));
/* 162 */             return new DataElement(32, strValue);case 6: length = readInteger(2); strValue = Utils.newStringUTF8(readBytes(length)); DebugLog.debug("DataElement.STRING", strValue, Integer.toString(length - strValue.length())); return new DataElement(32, strValue);case 7: length = readInteger(4); strValue = Utils.newStringUTF8(readBytes(length)); DebugLog.debug("DataElement.STRING", strValue, Integer.toString(length - strValue.length())); return new DataElement(32, strValue);
/*     */         }  throw new IOException();
/*     */       case 5:
/* 165 */         return new DataElement((readLong(1) != 0L));
/*     */ 
/*     */ 
/*     */       
/*     */       case 6:
/* 170 */         switch (sizeDescriptor) {
/*     */           case 5:
/* 172 */             length = readInteger(1);
/*     */             break;
/*     */           case 6:
/* 175 */             length = readInteger(2);
/*     */             break;
/*     */           case 7:
/* 178 */             length = readInteger(4);
/*     */             break;
/*     */           default:
/* 181 */             throw new IOException();
/*     */         } 
/*     */         
/* 184 */         element = new DataElement(48);
/*     */         
/* 186 */         started = this.pos;
/*     */         
/* 188 */         for (i = this.pos + length; this.pos < i;) {
/* 189 */           element.addElement(readElement());
/*     */         }
/* 191 */         if (started + length != this.pos) {
/* 192 */           throw new IOException("DATSEQ size corruption " + (started + length - this.pos));
/*     */         }
/* 194 */         return element;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 7:
/* 200 */         switch (sizeDescriptor) {
/*     */           case 5:
/* 202 */             length = readInteger(1);
/*     */             break;
/*     */           case 6:
/* 205 */             length = readInteger(2);
/*     */             break;
/*     */           case 7:
/* 208 */             length = readInteger(4);
/*     */             break;
/*     */           default:
/* 211 */             throw new IOException();
/*     */         } 
/*     */         
/* 214 */         element = new DataElement(56);
/*     */         
/* 216 */         started = this.pos;
/*     */         
/* 218 */         for (end = (this.pos + length); this.pos < end;) {
/* 219 */           element.addElement(readElement());
/*     */         }
/* 221 */         if (started + length != this.pos) {
/* 222 */           throw new IOException("DATALT size corruption " + (started + length - this.pos));
/*     */         }
/* 224 */         return element;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 8:
/* 230 */         switch (sizeDescriptor) {
/*     */           case 5:
/* 232 */             length = readInteger(1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 244 */             return new DataElement(64, Utils.newStringASCII(readBytes(length)));case 6: length = readInteger(2); return new DataElement(64, Utils.newStringASCII(readBytes(length)));case 7: length = readInteger(4); return new DataElement(64, Utils.newStringASCII(readBytes(length)));
/*     */         }  throw new IOException();
/*     */     } 
/* 247 */     throw new IOException("Unknown type " + type); }
/*     */ 
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\SDPInputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */