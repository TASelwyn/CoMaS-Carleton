package com.intel.bluetooth;

import java.io.IOException;
import java.io.InputStream;
import javax.bluetooth.DataElement;
import javax.bluetooth.UUID;

class SDPInputStream extends InputStream {
  private InputStream source;
  
  private int pos;
  
  public SDPInputStream(InputStream in) {
    this.source = in;
    this.pos = 0;
  }
  
  public int read() throws IOException {
    return this.source.read();
  }
  
  private long readLong(int size) throws IOException {
    long result = 0L;
    for (int i = 0; i < size; i++)
      result = result << 8L | read(); 
    this.pos += size;
    return result;
  }
  
  private int readInteger(int size) throws IOException {
    int result = 0;
    for (int i = 0; i < size; i++)
      result = result << 8 | read(); 
    this.pos += size;
    return result;
  }
  
  private String hexString(byte[] b) throws IOException {
    StringBuffer buf = new StringBuffer();
    for (int i = 0; i < b.length; i++) {
      buf.append(Integer.toHexString(b[i] >> 4 & 0xF));
      buf.append(Integer.toHexString(b[i] & 0xF));
    } 
    return buf.toString();
  }
  
  private byte[] readBytes(int size) throws IOException {
    byte[] result = new byte[size];
    for (int i = 0; i < size; i++)
      result[i] = (byte)read(); 
    this.pos += size;
    return result;
  }
  
  public DataElement readElement() throws IOException {
    UUID uuid;
    int length;
    String strValue;
    DataElement element;
    int started, i;
    long end;
    int header = read();
    int type = header >> 3 & 0x1F;
    int sizeDescriptor = header & 0x7;
    this.pos++;
    switch (type) {
      case 0:
        return new DataElement(0);
      case 1:
        switch (sizeDescriptor) {
          case 0:
            return new DataElement(8, readLong(1));
          case 1:
            return new DataElement(9, readLong(2));
          case 2:
            return new DataElement(10, readLong(4));
          case 3:
            return new DataElement(11, readBytes(8));
          case 4:
            return new DataElement(12, readBytes(16));
        } 
        throw new IOException();
      case 2:
        switch (sizeDescriptor) {
          case 0:
            return new DataElement(16, (byte)(int)readLong(1));
          case 1:
            return new DataElement(17, (short)(int)readLong(2));
          case 2:
            return new DataElement(18, (int)readLong(4));
          case 3:
            return new DataElement(19, readLong(8));
          case 4:
            return new DataElement(20, readBytes(16));
        } 
        throw new IOException();
      case 3:
        uuid = null;
        switch (sizeDescriptor) {
          case 1:
            uuid = new UUID(readLong(2));
            return new DataElement(24, uuid);
          case 2:
            uuid = new UUID(readLong(4));
            return new DataElement(24, uuid);
          case 4:
            uuid = new UUID(hexString(readBytes(16)), false);
            return new DataElement(24, uuid);
        } 
        throw new IOException();
      case 4:
        length = -1;
        switch (sizeDescriptor) {
          case 5:
            length = readInteger(1);
            strValue = Utils.newStringUTF8(readBytes(length));
            DebugLog.debug("DataElement.STRING", strValue, Integer.toString(length - strValue.length()));
            return new DataElement(32, strValue);
          case 6:
            length = readInteger(2);
            strValue = Utils.newStringUTF8(readBytes(length));
            DebugLog.debug("DataElement.STRING", strValue, Integer.toString(length - strValue.length()));
            return new DataElement(32, strValue);
          case 7:
            length = readInteger(4);
            strValue = Utils.newStringUTF8(readBytes(length));
            DebugLog.debug("DataElement.STRING", strValue, Integer.toString(length - strValue.length()));
            return new DataElement(32, strValue);
        } 
        throw new IOException();
      case 5:
        return new DataElement((readLong(1) != 0L));
      case 6:
        switch (sizeDescriptor) {
          case 5:
            length = readInteger(1);
            break;
          case 6:
            length = readInteger(2);
            break;
          case 7:
            length = readInteger(4);
            break;
          default:
            throw new IOException();
        } 
        element = new DataElement(48);
        started = this.pos;
        for (i = this.pos + length; this.pos < i;)
          element.addElement(readElement()); 
        if (started + length != this.pos)
          throw new IOException("DATSEQ size corruption " + (started + length - this.pos)); 
        return element;
      case 7:
        switch (sizeDescriptor) {
          case 5:
            length = readInteger(1);
            break;
          case 6:
            length = readInteger(2);
            break;
          case 7:
            length = readInteger(4);
            break;
          default:
            throw new IOException();
        } 
        element = new DataElement(56);
        started = this.pos;
        for (end = (this.pos + length); this.pos < end;)
          element.addElement(readElement()); 
        if (started + length != this.pos)
          throw new IOException("DATALT size corruption " + (started + length - this.pos)); 
        return element;
      case 8:
        switch (sizeDescriptor) {
          case 5:
            length = readInteger(1);
            return new DataElement(64, Utils.newStringASCII(readBytes(length)));
          case 6:
            length = readInteger(2);
            return new DataElement(64, Utils.newStringASCII(readBytes(length)));
          case 7:
            length = readInteger(4);
            return new DataElement(64, Utils.newStringASCII(readBytes(length)));
        } 
        throw new IOException();
    } 
    throw new IOException("Unknown type " + type);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\SDPInputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */