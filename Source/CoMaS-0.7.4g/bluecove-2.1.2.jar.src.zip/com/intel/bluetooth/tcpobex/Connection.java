/*     */ package com.intel.bluetooth.tcpobex;
/*     */ 
/*     */ import com.ibm.oti.connection.CreateConnection;
/*     */ import com.intel.bluetooth.BluetoothConnectionNotifierServiceRecordAccess;
/*     */ import com.intel.bluetooth.MicroeditionConnector;
/*     */ import java.io.IOException;
/*     */ import javax.bluetooth.ServiceRecord;
/*     */ import javax.bluetooth.ServiceRegistrationException;
/*     */ import javax.obex.Authenticator;
/*     */ import javax.obex.ClientSession;
/*     */ import javax.obex.HeaderSet;
/*     */ import javax.obex.Operation;
/*     */ import javax.obex.ServerRequestHandler;
/*     */ import javax.obex.SessionNotifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Connection
/*     */   implements CreateConnection, ClientSession, SessionNotifier, BluetoothConnectionNotifierServiceRecordAccess
/*     */ {
/*  59 */   private javax.microedition.io.Connection impl = null;
/*     */ 
/*     */   
/*     */   public void setParameters(String spec, int access, boolean timeout) throws IOException {
/*  63 */     this.impl = MicroeditionConnector.open("tcpobex:" + spec, access, timeout);
/*     */   }
/*     */   
/*     */   public javax.microedition.io.Connection setParameters2(String spec, int access, boolean timeout) throws IOException {
/*  67 */     setParameters(spec, access, timeout);
/*  68 */     return (javax.microedition.io.Connection)this;
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/*  72 */     this.impl.close();
/*     */   }
/*     */   
/*     */   public HeaderSet connect(HeaderSet headers) throws IOException {
/*  76 */     return ((ClientSession)this.impl).connect(headers);
/*     */   }
/*     */   
/*     */   public HeaderSet createHeaderSet() {
/*  80 */     return ((ClientSession)this.impl).createHeaderSet();
/*     */   }
/*     */   
/*     */   public HeaderSet delete(HeaderSet headers) throws IOException {
/*  84 */     return ((ClientSession)this.impl).delete(headers);
/*     */   }
/*     */   
/*     */   public HeaderSet disconnect(HeaderSet headers) throws IOException {
/*  88 */     return ((ClientSession)this.impl).disconnect(headers);
/*     */   }
/*     */   
/*     */   public Operation get(HeaderSet headers) throws IOException {
/*  92 */     return ((ClientSession)this.impl).get(headers);
/*     */   }
/*     */   
/*     */   public long getConnectionID() {
/*  96 */     return ((ClientSession)this.impl).getConnectionID();
/*     */   }
/*     */   
/*     */   public Operation put(HeaderSet headers) throws IOException {
/* 100 */     return ((ClientSession)this.impl).put(headers);
/*     */   }
/*     */   
/*     */   public void setAuthenticator(Authenticator auth) {
/* 104 */     ((ClientSession)this.impl).setAuthenticator(auth);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setConnectionID(long id) {
/* 109 */     ((ClientSession)this.impl).setConnectionID(id);
/*     */   }
/*     */   
/*     */   public HeaderSet setPath(HeaderSet headers, boolean backup, boolean create) throws IOException {
/* 113 */     return ((ClientSession)this.impl).setPath(headers, backup, create);
/*     */   }
/*     */   
/*     */   public javax.microedition.io.Connection acceptAndOpen(ServerRequestHandler handler) throws IOException {
/* 117 */     return ((SessionNotifier)this.impl).acceptAndOpen(handler);
/*     */   }
/*     */ 
/*     */   
/*     */   public javax.microedition.io.Connection acceptAndOpen(ServerRequestHandler handler, Authenticator auth) throws IOException {
/* 122 */     return ((SessionNotifier)this.impl).acceptAndOpen(handler, auth);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceRecord getServiceRecord() {
/* 131 */     return ((BluetoothConnectionNotifierServiceRecordAccess)this.impl).getServiceRecord();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateServiceRecord(boolean acceptAndOpen) throws ServiceRegistrationException {
/* 140 */     ((BluetoothConnectionNotifierServiceRecordAccess)this.impl).updateServiceRecord(acceptAndOpen);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\tcpobex\Connection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */