package com.intel.bluetooth;

import javax.bluetooth.DeviceClass;
import javax.bluetooth.DiscoveryListener;
import javax.bluetooth.RemoteDevice;
import javax.bluetooth.ServiceRecord;

class DiscoveryListenerAdapter implements DiscoveryListener {
  public void deviceDiscovered(RemoteDevice btDevice, DeviceClass cod) {}
  
  public void inquiryCompleted(int discType) {
    DebugLog.debug("inquiryCompleted", discType);
  }
  
  public void serviceSearchCompleted(int transID, int respCode) {
    DebugLog.debug("serviceSearchCompleted", respCode);
  }
  
  public void servicesDiscovered(int transID, ServiceRecord[] servRecord) {}
}
