package com.intel.bluetooth;

import com.intel.bluetooth.gcf.socket.ServerSocketConnection;
import com.intel.bluetooth.gcf.socket.SocketConnection;
import com.intel.bluetooth.obex.OBEXClientSessionImpl;
import com.intel.bluetooth.obex.OBEXConnectionParams;
import com.intel.bluetooth.obex.OBEXSessionNotifierImpl;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.bluetooth.BluetoothConnectionException;
import javax.bluetooth.UUID;
import javax.microedition.io.Connection;
import javax.microedition.io.ConnectionNotFoundException;
import javax.microedition.io.InputConnection;
import javax.microedition.io.OutputConnection;
import javax.microedition.io.StreamConnection;
import javax.microedition.io.StreamConnectionNotifier;

public abstract class MicroeditionConnector {
  public static final int READ = 1;
  
  public static final int WRITE = 2;
  
  public static final int READ_WRITE = 3;
  
  private static Hashtable suportScheme = new Hashtable();
  
  private static Hashtable srvParams = new Hashtable();
  
  private static Hashtable cliParams = new Hashtable();
  
  private static Hashtable cliParamsL2CAP = new Hashtable();
  
  private static Hashtable srvParamsL2CAP = new Hashtable();
  
  private static final String AUTHENTICATE = "authenticate";
  
  private static final String AUTHORIZE = "authorize";
  
  private static final String ENCRYPT = "encrypt";
  
  private static final String MASTER = "master";
  
  private static final String NAME = "name";
  
  private static final String RECEIVE_MTU = "receivemtu";
  
  private static final String TRANSMIT_MTU = "transmitmtu";
  
  private static final String EXT_BLUECOVE_L2CAP_PSM = "bluecovepsm";
  
  private static final String ANDROID = "android";
  
  static {
    cliParams.put("authenticate", "authenticate");
    cliParams.put("encrypt", "encrypt");
    cliParams.put("master", "master");
    copyAll(srvParams, cliParams);
    srvParams.put("authorize", "authorize");
    srvParams.put("name", "name");
    copyAll(cliParamsL2CAP, cliParams);
    cliParamsL2CAP.put("receivemtu", "receivemtu");
    cliParamsL2CAP.put("transmitmtu", "transmitmtu");
    copyAll(srvParamsL2CAP, cliParamsL2CAP);
    srvParamsL2CAP.put("authorize", "authorize");
    srvParamsL2CAP.put("name", "name");
    srvParamsL2CAP.put("bluecovepsm", "bluecovepsm");
    suportScheme.put("btspp", Boolean.TRUE);
    suportScheme.put("btgoep", Boolean.TRUE);
    suportScheme.put("tcpobex", Boolean.TRUE);
    suportScheme.put("btl2cap", Boolean.TRUE);
    suportScheme.put("socket", Boolean.TRUE);
  }
  
  static void copyAll(Hashtable dest, Hashtable src) {
    for (Enumeration en = src.keys(); en.hasMoreElements(); ) {
      Object key = en.nextElement();
      dest.put(key, src.get(key));
    } 
  }
  
  static String validParamName(Hashtable map, String paramName) {
    String validName = (String)map.get(paramName.toLowerCase());
    if (validName != null)
      return validName; 
    if ("android".equals(paramName))
      return "android"; 
    return null;
  }
  
  public static Connection open(String name) throws IOException {
    return openImpl(name, 3, false, true);
  }
  
  private static Connection openImpl(String name, int mode, boolean timeouts, boolean allowServer) throws IOException {
    boolean isServer;
    DebugLog.debug("connecting", name);
    String host = null;
    String portORuuid = null;
    Hashtable values = new Hashtable();
    int schemeEnd = name.indexOf("://");
    if (schemeEnd == -1)
      throw new ConnectionNotFoundException(name); 
    String scheme = name.substring(0, schemeEnd);
    if (!suportScheme.containsKey(scheme))
      throw new ConnectionNotFoundException(scheme); 
    boolean schemeBluetooth = (scheme.equals("btspp") || scheme.equals("btgoep") || scheme.equals("btl2cap"));
    boolean isL2CAP = scheme.equals("btl2cap");
    boolean isTCPOBEX = scheme.equals("tcpobex");
    BluetoothStack bluetoothStack = null;
    if (schemeBluetooth)
      bluetoothStack = BlueCoveImpl.instance().getBluetoothStack(); 
    int hostEnd = name.indexOf(':', scheme.length() + 3);
    if (hostEnd > -1) {
      Hashtable params;
      host = name.substring(scheme.length() + 3, hostEnd);
      isServer = host.equals("localhost");
      if (isTCPOBEX) {
        params = new Hashtable();
        isServer = (host.length() == 0);
      } else if (isL2CAP) {
        if (isServer) {
          params = srvParamsL2CAP;
        } else {
          params = cliParamsL2CAP;
        } 
      } else if (isServer) {
        params = srvParams;
      } else {
        params = cliParams;
      } 
      String paramsStr = name.substring(hostEnd + 1);
      UtilsStringTokenizer tok = new UtilsStringTokenizer(paramsStr, ";");
      if (tok.hasMoreTokens()) {
        portORuuid = tok.nextToken();
      } else {
        portORuuid = paramsStr;
      } 
      while (tok.hasMoreTokens()) {
        String t = tok.nextToken();
        int equals = t.indexOf('=');
        if (equals > -1) {
          String param = t.substring(0, equals);
          String value = t.substring(equals + 1);
          String validName = validParamName(params, param);
          if (validName != null) {
            String hasValue = (String)values.get(validName);
            if (hasValue != null && !hasValue.equals(value))
              throw new IllegalArgumentException("duplicate param [" + param + "] value [" + value + "]"); 
            values.put(validName, value);
            continue;
          } 
          throw new IllegalArgumentException("invalid param [" + param + "] value [" + value + "]");
        } 
        throw new IllegalArgumentException("invalid param [" + t + "]");
      } 
    } else if (isTCPOBEX) {
      host = name.substring(scheme.length() + 3);
      isServer = (host.length() == 0);
    } else {
      throw new IllegalArgumentException(name.substring(scheme.length() + 3));
    } 
    if (isTCPOBEX && (
      portORuuid == null || portORuuid.length() == 0))
      portORuuid = String.valueOf(650); 
    if (host == null || portORuuid == null)
      throw new IllegalArgumentException(); 
    BluetoothConnectionNotifierParams notifierParams = null;
    BluetoothConnectionParams connectionParams = null;
    boolean isAndroid = values.containsKey("android");
    int channel = 0;
    if (isServer) {
      if (!allowServer)
        throw new IllegalArgumentException("Can't use server connection URL"); 
      if (values.get("name") == null) {
        values.put("name", "BlueCove");
      } else if (schemeBluetooth) {
        validateBluetoothServiceName((String)values.get("name"));
      } 
      if (schemeBluetooth) {
        notifierParams = new BluetoothConnectionNotifierParams(new UUID(portORuuid, false), paramBoolean(values, "authenticate"), paramBoolean(values, "encrypt"), paramBoolean(values, "authorize"), (String)values.get("name"), paramBoolean(values, "master"));
        notifierParams.timeouts = timeouts;
        if (notifierParams.encrypt && !notifierParams.authenticate)
          if (values.get("authenticate") == null) {
            notifierParams.authenticate = true;
          } else {
            throw new BluetoothConnectionException(6, "encryption requires authentication");
          }  
        if (notifierParams.authorize && !notifierParams.authenticate)
          if (values.get("authenticate") == null) {
            notifierParams.authenticate = true;
          } else {
            throw new BluetoothConnectionException(6, "authorization requires authentication");
          }  
        if (isL2CAP) {
          String bluecove_ext_psm = (String)values.get("bluecovepsm");
          if (bluecove_ext_psm != null) {
            if ((bluetoothStack.getFeatureSet() & 0x10) == 0)
              throw new IllegalArgumentException("bluecovepsm extension not supported on this stack"); 
            int psm = Integer.parseInt(bluecove_ext_psm, 16);
            validateL2CAPPSM(psm, bluecove_ext_psm);
            notifierParams.bluecove_ext_psm = psm;
          } 
        } 
      } 
    } else {
      if (!isAndroid) {
        try {
          channel = Integer.parseInt(portORuuid, isL2CAP ? 16 : 10);
        } catch (NumberFormatException e) {
          throw new IllegalArgumentException("channel " + portORuuid);
        } 
        if (channel < 0)
          throw new IllegalArgumentException("channel " + portORuuid); 
      } 
      if (schemeBluetooth) {
        if (!isAndroid) {
          if (isL2CAP) {
            validateL2CAPPSM(channel, portORuuid);
          } else if (channel < 1 || channel > 30) {
            throw new IllegalArgumentException("RFCOMM channel " + portORuuid);
          } 
          connectionParams = new BluetoothConnectionParams(RemoteDeviceHelper.getAddress(host), channel, paramBoolean(values, "authenticate"), paramBoolean(values, "encrypt"));
        } else {
          try {
            connectionParams = Class.forName("com.intel.bluetooth.AndroidBluetoothConnectionParams").getConstructor(new Class[] { long.class, boolean.class, boolean.class }).newInstance(new Object[] { Long.valueOf(RemoteDeviceHelper.getAddress(host)), Boolean.valueOf(paramBoolean(values, "authenticate")), Boolean.valueOf(paramBoolean(values, "encrypt")) });
            connectionParams.getClass().getMethod("setServiceUUID", new Class[] { String.class }).invoke(connectionParams, new Object[] { portORuuid });
          } catch (Exception ex) {
            throw new BluetoothConnectionException(4, ex.toString());
          } 
        } 
        connectionParams.timeouts = timeouts;
        if (connectionParams.encrypt && !connectionParams.authenticate)
          if (values.get("authenticate") == null) {
            connectionParams.authenticate = true;
          } else {
            throw new BluetoothConnectionException(6, "encryption requires authentication");
          }  
        connectionParams.timeout = BlueCoveImpl.getConfigProperty("bluecove.connect.timeout", 120000);
      } 
    } 
    OBEXConnectionParams obexConnectionParams = null;
    if (scheme.equals("tcpobex") || scheme.equals("btgoep")) {
      obexConnectionParams = new OBEXConnectionParams();
      obexConnectionParams.timeouts = timeouts;
      obexConnectionParams.timeout = BlueCoveImpl.getConfigProperty("bluecove.obex.timeout", 120000);
      obexConnectionParams.mtu = BlueCoveImpl.getConfigProperty("bluecove.obex.mtu", 1024);
    } 
    if (scheme.equals("btspp")) {
      if (isServer)
        return new BluetoothRFCommConnectionNotifier(bluetoothStack, notifierParams); 
      return (Connection)new BluetoothRFCommClientConnection(bluetoothStack, connectionParams);
    } 
    if (scheme.equals("btgoep")) {
      if (isServer) {
        notifierParams.obex = true;
        return (Connection)new OBEXSessionNotifierImpl(new BluetoothRFCommConnectionNotifier(bluetoothStack, notifierParams), obexConnectionParams);
      } 
      return (Connection)new OBEXClientSessionImpl(new BluetoothRFCommClientConnection(bluetoothStack, connectionParams), obexConnectionParams);
    } 
    if (scheme.equals("btl2cap")) {
      if (isServer)
        return new BluetoothL2CAPConnectionNotifier(bluetoothStack, notifierParams, paramL2CAPMTU(values, "receivemtu"), paramL2CAPMTU(values, "transmitmtu")); 
      return (Connection)new BluetoothL2CAPClientConnection(bluetoothStack, connectionParams, paramL2CAPMTU(values, "receivemtu"), paramL2CAPMTU(values, "transmitmtu"));
    } 
    if (scheme.equals("tcpobex")) {
      if (isServer) {
        try {
          channel = Integer.parseInt(portORuuid);
        } catch (NumberFormatException e) {
          throw new IllegalArgumentException("port " + portORuuid);
        } 
        return (Connection)new OBEXSessionNotifierImpl((StreamConnectionNotifier)new ServerSocketConnection(channel), obexConnectionParams);
      } 
      return (Connection)new OBEXClientSessionImpl((StreamConnection)new SocketConnection(host, channel), obexConnectionParams);
    } 
    if (scheme.equals("socket")) {
      if (isServer) {
        try {
          channel = Integer.parseInt(portORuuid);
        } catch (NumberFormatException e) {
          throw new IllegalArgumentException("port " + portORuuid);
        } 
        return (Connection)new ServerSocketConnection(channel);
      } 
      return (Connection)new SocketConnection(host, channel);
    } 
    throw new ConnectionNotFoundException("scheme [" + scheme + "]");
  }
  
  private static void validateL2CAPPSM(int channel, String channelAsString) throws IllegalArgumentException {
    if (channel < 5 || channel > 65535)
      throw new IllegalArgumentException("PCM " + channelAsString); 
    if (channel < 4097 && !BlueCoveImpl.getConfigProperty("bluecove.jsr82.psm_minimum_off", false))
      throw new IllegalArgumentException("PCM " + channelAsString + ", PCM values restricted by JSR-82 to minimum " + 'ခ' + ", see BlueCoveConfigProperties.PROPERTY_JSR_82_PSM_MINIMUM_OFF"); 
    if ((channel & 0x100) != 0)
      throw new IllegalArgumentException("9th bit set in PCM " + channelAsString); 
    byte lsByte = (byte)(0xFF & channel);
    if (lsByte % 2 == 0)
      throw new IllegalArgumentException("PSM value " + channelAsString + " least significant byte must be odd"); 
    byte msByte = (byte)((0xFF00 & channel) >> 8);
    if (msByte % 2 == 1)
      throw new IllegalArgumentException("PSM value " + channelAsString + " most significant byte must be even"); 
  }
  
  private static void validateBluetoothServiceName(String serviceName) {
    if (serviceName.length() == 0)
      throw new IllegalArgumentException("zero length service name"); 
    String allowNameCharactes = " -_";
    for (int i = 0; i < serviceName.length(); ) {
      char c = serviceName.charAt(i);
      if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || " -_".indexOf(c) != -1) {
        i++;
        continue;
      } 
      throw new IllegalArgumentException("Illegal character '" + c + "' in service name");
    } 
  }
  
  private static boolean paramBoolean(Hashtable values, String name) {
    String v = (String)values.get(name);
    if (v == null)
      return false; 
    if ("true".equals(v))
      return true; 
    if ("false".equals(v))
      return false; 
    throw new IllegalArgumentException("invalid param value " + name + "=" + v);
  }
  
  private static int paramL2CAPMTU(Hashtable values, String name) {
    String v = (String)values.get(name);
    if (v == null) {
      if (name.equals("transmitmtu"))
        return -1; 
      return 672;
    } 
    try {
      int mtu = Integer.parseInt(v);
      if (mtu >= 48)
        return mtu; 
      if (mtu > 0 && mtu < 48 && name.equals("transmitmtu"))
        return 48; 
    } catch (NumberFormatException e) {
      throw new IllegalArgumentException("invalid MTU value " + v);
    } 
    throw new IllegalArgumentException("invalid MTU param value " + name + "=" + v);
  }
  
  public static Connection open(String name, int mode) throws IOException {
    return openImpl(name, mode, false, true);
  }
  
  public static Connection open(String name, int mode, boolean timeouts) throws IOException {
    return openImpl(name, mode, timeouts, true);
  }
  
  public static DataInputStream openDataInputStream(String name) throws IOException {
    return new DataInputStream(openInputStream(name));
  }
  
  public static DataOutputStream openDataOutputStream(String name) throws IOException {
    return new DataOutputStream(openOutputStream(name));
  }
  
  public static InputStream openInputStream(String name) throws IOException {
    InputConnection con = (InputConnection)openImpl(name, 1, false, false);
    try {
      return con.openInputStream();
    } finally {
      con.close();
    } 
  }
  
  public static OutputStream openOutputStream(String name) throws IOException {
    OutputConnection con = (OutputConnection)openImpl(name, 2, false, false);
    try {
      return con.openOutputStream();
    } finally {
      con.close();
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\MicroeditionConnector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */