/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import javax.bluetooth.BluetoothStateException;
/*     */ import javax.bluetooth.DataElement;
/*     */ import javax.bluetooth.LocalDevice;
/*     */ import javax.bluetooth.RemoteDevice;
/*     */ import javax.bluetooth.ServiceRecord;
/*     */ import javax.bluetooth.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ServiceRecordImpl
/*     */   implements ServiceRecord
/*     */ {
/*     */   private BluetoothStack bluetoothStack;
/*     */   private RemoteDevice device;
/*     */   private long handle;
/*     */   Hashtable attributes;
/*     */   protected boolean attributeUpdated;
/*     */   int deviceServiceClasses;
/*     */   int deviceServiceClassesRegistered;
/*     */   
/*     */   ServiceRecordImpl(BluetoothStack bluetoothStack, RemoteDevice device, long handle) {
/*  59 */     this.bluetoothStack = bluetoothStack;
/*     */     
/*  61 */     this.device = device;
/*     */     
/*  63 */     this.handle = handle;
/*     */     
/*  65 */     this.deviceServiceClassesRegistered = 0;
/*     */     
/*  67 */     this.attributes = new Hashtable();
/*     */   }
/*     */   
/*     */   byte[] toByteArray() throws IOException {
/*  71 */     DataElement rootSeq = new DataElement(48);
/*  72 */     boolean sort = true;
/*     */     
/*  74 */     int[] sortIDs = new int[this.attributes.size()];
/*  75 */     int k = 0;
/*  76 */     for (Enumeration e = this.attributes.keys(); e.hasMoreElements(); ) {
/*  77 */       Integer key = e.nextElement();
/*  78 */       sortIDs[k] = key.intValue();
/*  79 */       k++;
/*     */     } 
/*     */     
/*     */     int i;
/*  83 */     for (i = 0; i < sortIDs.length; i++) {
/*  84 */       for (int j = 0; j < sortIDs.length - i - 1; j++) {
/*  85 */         if (sortIDs[j] > sortIDs[j + 1]) {
/*  86 */           int temp = sortIDs[j];
/*  87 */           sortIDs[j] = sortIDs[j + 1];
/*  88 */           sortIDs[j + 1] = temp;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  93 */     for (i = 0; i < sortIDs.length; i++) {
/*  94 */       int attrID = sortIDs[i];
/*  95 */       rootSeq.addElement(new DataElement(9, attrID));
/*  96 */       rootSeq.addElement(getAttributeValue(attrID));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 106 */     SDPOutputStream sdpOut = new SDPOutputStream(out);
/* 107 */     sdpOut.writeElement(rootSeq);
/* 108 */     return out.toByteArray();
/*     */   }
/*     */   
/*     */   void loadByteArray(byte[] data) throws IOException {
/* 112 */     DataElement element = (new SDPInputStream(new ByteArrayInputStream(data))).readElement();
/* 113 */     if (element.getDataType() != 48) {
/* 114 */       throw new IOException("DATSEQ expected instead of " + element.getDataType());
/*     */     }
/* 116 */     Enumeration en = (Enumeration)element.getValue();
/* 117 */     while (en.hasMoreElements()) {
/* 118 */       DataElement id = en.nextElement();
/* 119 */       if (id.getDataType() != 9) {
/* 120 */         throw new IOException("U_INT_2 expected instead of " + id.getDataType());
/*     */       }
/* 122 */       DataElement value = en.nextElement();
/* 123 */       populateAttributeValue((int)id.getLong(), value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataElement getAttributeValue(int attrID) {
/* 137 */     if (attrID < 0 || attrID > 65535) {
/* 138 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 141 */     return (DataElement)this.attributes.get(new Integer(attrID));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RemoteDevice getHostDevice() {
/* 154 */     return this.device;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getAttributeIDs() {
/* 167 */     int[] attrIDs = new int[this.attributes.size()];
/*     */     
/* 169 */     int i = 0;
/*     */     
/* 171 */     for (Enumeration e = this.attributes.keys(); e.hasMoreElements();) {
/* 172 */       attrIDs[i++] = ((Integer)e.nextElement()).intValue();
/*     */     }
/*     */     
/* 175 */     return attrIDs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean populateRecord(int[] attrIDs) throws IOException {
/* 214 */     if (this.device == null) {
/* 215 */       throw new RuntimeException("This is local device service record");
/*     */     }
/*     */     
/* 218 */     if (attrIDs == null) {
/* 219 */       throw new NullPointerException("attrIDs is null");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 224 */     if (attrIDs.length == 0) {
/* 225 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 232 */     for (int i = 0; i < attrIDs.length; i++) {
/* 233 */       if (attrIDs[i] < 0 || attrIDs[i] > 65535) {
/* 234 */         throw new IllegalArgumentException();
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 243 */     int[] sortIDs = new int[attrIDs.length];
/* 244 */     System.arraycopy(attrIDs, 0, sortIDs, 0, attrIDs.length); int j;
/* 245 */     for (j = 0; j < sortIDs.length; j++) {
/* 246 */       for (int k = 0; k < sortIDs.length - j - 1; k++) {
/* 247 */         if (sortIDs[k] > sortIDs[k + 1]) {
/* 248 */           int temp = sortIDs[k];
/* 249 */           sortIDs[k] = sortIDs[k + 1];
/* 250 */           sortIDs[k + 1] = temp;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 257 */     for (j = 0; j < sortIDs.length - 1; j++) {
/* 258 */       if (sortIDs[j] == sortIDs[j + 1]) {
/* 259 */         throw new IllegalArgumentException();
/*     */       }
/* 261 */       DebugLog.debug0x("srvRec query for attr", sortIDs[j]);
/*     */     } 
/* 263 */     DebugLog.debug0x("srvRec query for attr", sortIDs[sortIDs.length - 1]);
/*     */     
/* 265 */     return this.bluetoothStack.populateServicesRecordAttributeValues(this, sortIDs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConnectionURL(int requiredSecurity, boolean mustBeMaster) {
/* 297 */     int commChannel = -1;
/*     */     
/* 299 */     DataElement protocolDescriptor = getAttributeValue(4);
/* 300 */     if (protocolDescriptor == null || protocolDescriptor.getDataType() != 48) {
/* 301 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 309 */     boolean isL2CAP = false;
/* 310 */     boolean isRFCOMM = false;
/* 311 */     boolean isOBEX = false;
/*     */     
/* 313 */     Enumeration protocolsSeqEnum = (Enumeration)protocolDescriptor.getValue();
/* 314 */     while (protocolsSeqEnum.hasMoreElements()) {
/* 315 */       DataElement elementSeq = protocolsSeqEnum.nextElement();
/*     */       
/* 317 */       if (elementSeq.getDataType() == 48) {
/* 318 */         Enumeration elementSeqEnum = (Enumeration)elementSeq.getValue();
/*     */         
/* 320 */         if (elementSeqEnum.hasMoreElements()) {
/* 321 */           DataElement protocolElement = elementSeqEnum.nextElement();
/* 322 */           if (protocolElement.getDataType() != 24) {
/*     */             continue;
/*     */           }
/* 325 */           Object uuid = protocolElement.getValue();
/* 326 */           if (BluetoothConsts.OBEX_PROTOCOL_UUID.equals(uuid)) {
/* 327 */             isOBEX = true;
/* 328 */             isRFCOMM = false;
/* 329 */             isL2CAP = false; continue;
/* 330 */           }  if (elementSeqEnum.hasMoreElements() && BluetoothConsts.RFCOMM_PROTOCOL_UUID.equals(uuid)) {
/*     */             long val;
/* 332 */             DataElement protocolPSMElement = elementSeqEnum.nextElement();
/*     */             
/* 334 */             switch (protocolPSMElement.getDataType()) {
/*     */               case 8:
/*     */               case 9:
/*     */               case 10:
/*     */               case 16:
/*     */               case 17:
/*     */               case 18:
/*     */               case 19:
/* 342 */                 val = protocolPSMElement.getLong();
/* 343 */                 if (val >= 1L && val <= 30L) {
/*     */                   
/* 345 */                   commChannel = (int)val;
/* 346 */                   isRFCOMM = true;
/* 347 */                   isL2CAP = false;
/*     */                 }  continue;
/*     */             }  continue;
/*     */           } 
/* 351 */           if (elementSeqEnum.hasMoreElements() && BluetoothConsts.L2CAP_PROTOCOL_UUID.equals(uuid)) {
/* 352 */             long pcm; DataElement protocolPSMElement = elementSeqEnum.nextElement();
/* 353 */             switch (protocolPSMElement.getDataType()) {
/*     */               case 8:
/*     */               case 9:
/*     */               case 10:
/*     */               case 16:
/*     */               case 17:
/*     */               case 18:
/*     */               case 19:
/* 361 */                 pcm = protocolPSMElement.getLong();
/* 362 */                 if (pcm >= 5L && pcm <= 65535L) {
/* 363 */                   commChannel = (int)pcm;
/* 364 */                   isL2CAP = true;
/*     */                 } 
/*     */             } 
/*     */ 
/*     */           
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 373 */     if (commChannel == -1) {
/* 374 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 380 */     StringBuffer buf = new StringBuffer();
/* 381 */     if (isOBEX) {
/* 382 */       buf.append("btgoep");
/* 383 */     } else if (isRFCOMM) {
/* 384 */       buf.append("btspp");
/* 385 */     } else if (isL2CAP) {
/* 386 */       buf.append("btl2cap");
/*     */     } else {
/* 388 */       return null;
/*     */     } 
/* 390 */     buf.append("://");
/*     */     
/* 392 */     if (this.device == null) {
/*     */       try {
/* 394 */         Object saveID = BlueCoveImpl.getCurrentThreadBluetoothStackID();
/*     */         try {
/* 396 */           BlueCoveImpl.setThreadBluetoothStack(this.bluetoothStack);
/* 397 */           buf.append(LocalDevice.getLocalDevice().getBluetoothAddress());
/*     */         } finally {
/* 399 */           if (saveID != null) {
/* 400 */             BlueCoveImpl.setThreadBluetoothStackID(saveID);
/*     */           }
/*     */         } 
/* 403 */       } catch (BluetoothStateException bse) {
/* 404 */         DebugLog.error("can't read LocalAddress", (Throwable)bse);
/* 405 */         buf.append("localhost");
/*     */       } 
/*     */     } else {
/* 408 */       buf.append(getHostDevice().getBluetoothAddress());
/*     */     } 
/*     */     
/* 411 */     buf.append(":");
/* 412 */     if (isL2CAP) {
/* 413 */       String hex = Integer.toHexString(commChannel);
/* 414 */       for (int i = hex.length(); i < 4; i++) {
/* 415 */         buf.append('0');
/*     */       }
/* 417 */       buf.append(hex);
/*     */     } else {
/* 419 */       buf.append(commChannel);
/*     */     } 
/*     */     
/* 422 */     switch (requiredSecurity) {
/*     */       case 0:
/* 424 */         buf.append(";authenticate=false;encrypt=false");
/*     */         break;
/*     */       case 1:
/* 427 */         buf.append(";authenticate=true;encrypt=false");
/*     */         break;
/*     */       case 2:
/* 430 */         buf.append(";authenticate=true;encrypt=true");
/*     */         break;
/*     */       default:
/* 433 */         throw new IllegalArgumentException();
/*     */     } 
/*     */     
/* 436 */     if (mustBeMaster) {
/* 437 */       buf.append(";master=true");
/*     */     } else {
/* 439 */       buf.append(";master=false");
/*     */     } 
/*     */     
/* 442 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   int getChannel(UUID protocolUUID) {
/* 447 */     int channel = -1;
/*     */     
/* 449 */     DataElement protocolDescriptor = getAttributeValue(4);
/* 450 */     if (protocolDescriptor == null || protocolDescriptor.getDataType() != 48) {
/* 451 */       return -1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 459 */     Enumeration protocolsSeqEnum = (Enumeration)protocolDescriptor.getValue();
/* 460 */     while (protocolsSeqEnum.hasMoreElements()) {
/* 461 */       DataElement elementSeq = protocolsSeqEnum.nextElement();
/*     */       
/* 463 */       if (elementSeq.getDataType() == 48) {
/* 464 */         Enumeration elementSeqEnum = (Enumeration)elementSeq.getValue();
/*     */         
/* 466 */         if (elementSeqEnum.hasMoreElements()) {
/* 467 */           DataElement protocolElement = elementSeqEnum.nextElement();
/* 468 */           if (protocolElement.getDataType() != 24) {
/*     */             continue;
/*     */           }
/* 471 */           Object uuid = protocolElement.getValue();
/* 472 */           if (elementSeqEnum.hasMoreElements() && protocolUUID.equals(uuid)) {
/*     */             
/* 474 */             DataElement protocolPSMElement = elementSeqEnum.nextElement();
/*     */             
/* 476 */             switch (protocolPSMElement.getDataType()) {
/*     */               case 8:
/*     */               case 9:
/*     */               case 10:
/*     */               case 16:
/*     */               case 17:
/*     */               case 18:
/*     */               case 19:
/* 484 */                 channel = (int)protocolPSMElement.getLong();
/*     */             } 
/*     */           
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 491 */     return channel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDeviceServiceClasses(int classes) {
/* 540 */     if (this.device != null) {
/* 541 */       throw new RuntimeException("Service record obtained from a remote device");
/*     */     }
/* 543 */     if ((classes & 0xFF002003) != 0) {
/* 544 */       throw new IllegalArgumentException();
/*     */     }
/* 546 */     if ((classes & 0x1FFC) != 0) {
/* 547 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 550 */     if ((this.bluetoothStack.getFeatureSet() & 0x4) == 0) {
/* 551 */       throw new NotSupportedRuntimeException(this.bluetoothStack.getStackID());
/*     */     }
/*     */     
/* 554 */     this.deviceServiceClasses = classes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setAttributeValue(int attrID, DataElement attrValue) {
/* 591 */     if (this.device != null) {
/* 592 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 595 */     if (attrID < 0 || attrID > 65535) {
/* 596 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 599 */     if (attrID == 0) {
/* 600 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 607 */     this.attributeUpdated = true;
/* 608 */     if (attrValue == null) {
/* 609 */       return (this.attributes.remove(new Integer(attrID)) != null);
/*     */     }
/* 611 */     this.attributes.put(new Integer(attrID), attrValue);
/* 612 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void populateAttributeValue(int attrID, DataElement attrValue) {
/* 620 */     if (attrID < 0 || attrID > 65535) {
/* 621 */       throw new IllegalArgumentException();
/*     */     }
/* 623 */     if (attrValue == null) {
/* 624 */       this.attributes.remove(new Integer(attrID));
/*     */     } else {
/* 626 */       this.attributes.put(new Integer(attrID), attrValue);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 632 */     StringBuffer buf = new StringBuffer("{\n");
/*     */     
/* 634 */     for (Enumeration e = this.attributes.keys(); e.hasMoreElements(); ) {
/* 635 */       Integer i = e.nextElement();
/*     */       
/* 637 */       buf.append("0x");
/* 638 */       buf.append(Integer.toHexString(i.intValue()));
/* 639 */       buf.append(":\n\t");
/*     */       
/* 641 */       DataElement d = (DataElement)this.attributes.get(i);
/*     */       
/* 643 */       buf.append(d);
/* 644 */       buf.append("\n");
/*     */     } 
/*     */     
/* 647 */     buf.append("}");
/*     */     
/* 649 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getHandle() {
/* 656 */     return this.handle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setHandle(long handle) {
/* 663 */     this.handle = handle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasServiceClassUUID(UUID uuid) {
/* 670 */     DataElement attrDataElement = getAttributeValue(1);
/* 671 */     if (attrDataElement == null || attrDataElement.getDataType() != 48 || attrDataElement.getSize() == 0)
/*     */     {
/*     */       
/* 674 */       return false;
/*     */     }
/*     */     
/* 677 */     Object value = attrDataElement.getValue();
/* 678 */     if (value == null || !(value instanceof Enumeration)) {
/* 679 */       DebugLog.debug("Bogus Value in DATSEQ");
/* 680 */       if (value != null) {
/* 681 */         DebugLog.error("DATSEQ class " + value.getClass().getName());
/*     */       }
/* 683 */       return false;
/*     */     } 
/* 685 */     for (Enumeration e = (Enumeration)value; e.hasMoreElements(); ) {
/* 686 */       Object element = e.nextElement();
/* 687 */       if (!(element instanceof DataElement)) {
/* 688 */         DebugLog.debug("Bogus element in DATSEQ, " + value.getClass().getName());
/*     */         continue;
/*     */       } 
/* 691 */       DataElement dataElement = (DataElement)element;
/* 692 */       if (dataElement.getDataType() == 24 && uuid.equals(dataElement.getValue())) {
/* 693 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 697 */     return false;
/*     */   }
/*     */   
/*     */   boolean hasProtocolClassUUID(UUID uuid) {
/* 701 */     DataElement protocolDescriptor = getAttributeValue(4);
/* 702 */     if (protocolDescriptor == null || protocolDescriptor.getDataType() != 48)
/*     */     {
/* 704 */       return false;
/*     */     }
/*     */     
/* 707 */     Enumeration protocolsSeqEnum = (Enumeration)protocolDescriptor.getValue();
/* 708 */     while (protocolsSeqEnum.hasMoreElements()) {
/* 709 */       DataElement elementSeq = protocolsSeqEnum.nextElement();
/*     */       
/* 711 */       if (elementSeq.getDataType() == 48) {
/* 712 */         Enumeration elementSeqEnum = (Enumeration)elementSeq.getValue();
/* 713 */         if (elementSeqEnum.hasMoreElements()) {
/* 714 */           DataElement protocolElement = elementSeqEnum.nextElement();
/* 715 */           if (protocolElement.getDataType() != 24) {
/*     */             continue;
/*     */           }
/* 718 */           if (uuid.equals(protocolElement.getValue())) {
/* 719 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 724 */     return false;
/*     */   }
/*     */   DataElement clone(DataElement de) {
/*     */     Enumeration en;
/* 728 */     DataElement c = null;
/*     */     
/* 730 */     switch (de.getDataType()) {
/*     */       case 8:
/*     */       case 9:
/*     */       case 10:
/*     */       case 16:
/*     */       case 17:
/*     */       case 18:
/* 737 */         c = new DataElement(de.getDataType(), de.getLong());
/*     */         break;
/*     */       case 12:
/*     */       case 19:
/*     */       case 20:
/*     */       case 24:
/*     */       case 32:
/*     */       case 64:
/* 745 */         c = new DataElement(de.getDataType(), de.getValue());
/*     */         break;
/*     */       case 0:
/* 748 */         c = new DataElement(de.getDataType());
/*     */         break;
/*     */       case 40:
/* 751 */         c = new DataElement(de.getBoolean());
/*     */         break;
/*     */       case 48:
/*     */       case 56:
/* 755 */         c = new DataElement(de.getDataType());
/* 756 */         for (en = (Enumeration)de.getValue(); en.hasMoreElements(); ) {
/* 757 */           DataElement dataElement = en.nextElement();
/* 758 */           c.addElement(clone(dataElement));
/*     */         } 
/*     */         break;
/*     */     } 
/* 762 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void populateRFCOMMAttributes(long handle, int channel, UUID uuid, String name, boolean obex) {
/* 770 */     populateAttributeValue(0, new DataElement(10, handle));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 776 */     DataElement serviceClassIDList = new DataElement(48);
/* 777 */     serviceClassIDList.addElement(new DataElement(24, uuid));
/* 778 */     if (!obex) {
/* 779 */       serviceClassIDList.addElement(new DataElement(24, BluetoothConsts.SERIAL_PORT_UUID));
/*     */     }
/*     */     
/* 782 */     populateAttributeValue(1, serviceClassIDList);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 788 */     DataElement protocolDescriptorList = new DataElement(48);
/*     */     
/* 790 */     DataElement L2CAPDescriptor = new DataElement(48);
/* 791 */     L2CAPDescriptor.addElement(new DataElement(24, BluetoothConsts.L2CAP_PROTOCOL_UUID));
/* 792 */     protocolDescriptorList.addElement(L2CAPDescriptor);
/*     */     
/* 794 */     DataElement RFCOMMDescriptor = new DataElement(48);
/* 795 */     RFCOMMDescriptor.addElement(new DataElement(24, BluetoothConsts.RFCOMM_PROTOCOL_UUID));
/* 796 */     RFCOMMDescriptor.addElement(new DataElement(8, channel));
/* 797 */     protocolDescriptorList.addElement(RFCOMMDescriptor);
/*     */     
/* 799 */     if (obex) {
/* 800 */       DataElement OBEXDescriptor = new DataElement(48);
/* 801 */       OBEXDescriptor.addElement(new DataElement(24, BluetoothConsts.OBEX_PROTOCOL_UUID));
/* 802 */       protocolDescriptorList.addElement(OBEXDescriptor);
/*     */     } 
/*     */     
/* 805 */     populateAttributeValue(4, protocolDescriptorList);
/*     */     
/* 807 */     if (name != null) {
/* 808 */       populateAttributeValue(256, new DataElement(32, name));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void populateL2CAPAttributes(int handle, int channel, UUID uuid, String name) {
/* 815 */     populateAttributeValue(0, new DataElement(10, handle));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 821 */     DataElement serviceClassIDList = new DataElement(48);
/* 822 */     serviceClassIDList.addElement(new DataElement(24, uuid));
/*     */     
/* 824 */     populateAttributeValue(1, serviceClassIDList);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 829 */     DataElement protocolDescriptorList = new DataElement(48);
/*     */     
/* 831 */     DataElement L2CAPDescriptor = new DataElement(48);
/* 832 */     L2CAPDescriptor.addElement(new DataElement(24, BluetoothConsts.L2CAP_PROTOCOL_UUID));
/* 833 */     L2CAPDescriptor.addElement(new DataElement(9, channel));
/* 834 */     protocolDescriptorList.addElement(L2CAPDescriptor);
/*     */     
/* 836 */     populateAttributeValue(4, protocolDescriptorList);
/*     */     
/* 838 */     if (name != null)
/* 839 */       populateAttributeValue(256, new DataElement(32, name)); 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\ServiceRecordImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */