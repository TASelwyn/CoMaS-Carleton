package com.intel.bluetooth;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DataElement;
import javax.bluetooth.LocalDevice;
import javax.bluetooth.RemoteDevice;
import javax.bluetooth.ServiceRecord;
import javax.bluetooth.UUID;

class ServiceRecordImpl implements ServiceRecord {
  private BluetoothStack bluetoothStack;
  
  private RemoteDevice device;
  
  private long handle;
  
  Hashtable attributes;
  
  protected boolean attributeUpdated;
  
  int deviceServiceClasses;
  
  int deviceServiceClassesRegistered;
  
  ServiceRecordImpl(BluetoothStack bluetoothStack, RemoteDevice device, long handle) {
    this.bluetoothStack = bluetoothStack;
    this.device = device;
    this.handle = handle;
    this.deviceServiceClassesRegistered = 0;
    this.attributes = new Hashtable();
  }
  
  byte[] toByteArray() throws IOException {
    DataElement rootSeq = new DataElement(48);
    boolean sort = true;
    int[] sortIDs = new int[this.attributes.size()];
    int k = 0;
    for (Enumeration e = this.attributes.keys(); e.hasMoreElements(); ) {
      Integer key = e.nextElement();
      sortIDs[k] = key.intValue();
      k++;
    } 
    int i;
    for (i = 0; i < sortIDs.length; i++) {
      for (int j = 0; j < sortIDs.length - i - 1; j++) {
        if (sortIDs[j] > sortIDs[j + 1]) {
          int temp = sortIDs[j];
          sortIDs[j] = sortIDs[j + 1];
          sortIDs[j + 1] = temp;
        } 
      } 
    } 
    for (i = 0; i < sortIDs.length; i++) {
      int attrID = sortIDs[i];
      rootSeq.addElement(new DataElement(9, attrID));
      rootSeq.addElement(getAttributeValue(attrID));
    } 
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    SDPOutputStream sdpOut = new SDPOutputStream(out);
    sdpOut.writeElement(rootSeq);
    return out.toByteArray();
  }
  
  void loadByteArray(byte[] data) throws IOException {
    DataElement element = (new SDPInputStream(new ByteArrayInputStream(data))).readElement();
    if (element.getDataType() != 48)
      throw new IOException("DATSEQ expected instead of " + element.getDataType()); 
    Enumeration en = (Enumeration)element.getValue();
    while (en.hasMoreElements()) {
      DataElement id = en.nextElement();
      if (id.getDataType() != 9)
        throw new IOException("U_INT_2 expected instead of " + id.getDataType()); 
      DataElement value = en.nextElement();
      populateAttributeValue((int)id.getLong(), value);
    } 
  }
  
  public DataElement getAttributeValue(int attrID) {
    if (attrID < 0 || attrID > 65535)
      throw new IllegalArgumentException(); 
    return (DataElement)this.attributes.get(new Integer(attrID));
  }
  
  public RemoteDevice getHostDevice() {
    return this.device;
  }
  
  public int[] getAttributeIDs() {
    int[] attrIDs = new int[this.attributes.size()];
    int i = 0;
    for (Enumeration e = this.attributes.keys(); e.hasMoreElements();)
      attrIDs[i++] = ((Integer)e.nextElement()).intValue(); 
    return attrIDs;
  }
  
  public boolean populateRecord(int[] attrIDs) throws IOException {
    if (this.device == null)
      throw new RuntimeException("This is local device service record"); 
    if (attrIDs == null)
      throw new NullPointerException("attrIDs is null"); 
    if (attrIDs.length == 0)
      throw new IllegalArgumentException(); 
    for (int i = 0; i < attrIDs.length; i++) {
      if (attrIDs[i] < 0 || attrIDs[i] > 65535)
        throw new IllegalArgumentException(); 
    } 
    int[] sortIDs = new int[attrIDs.length];
    System.arraycopy(attrIDs, 0, sortIDs, 0, attrIDs.length);
    int j;
    for (j = 0; j < sortIDs.length; j++) {
      for (int k = 0; k < sortIDs.length - j - 1; k++) {
        if (sortIDs[k] > sortIDs[k + 1]) {
          int temp = sortIDs[k];
          sortIDs[k] = sortIDs[k + 1];
          sortIDs[k + 1] = temp;
        } 
      } 
    } 
    for (j = 0; j < sortIDs.length - 1; j++) {
      if (sortIDs[j] == sortIDs[j + 1])
        throw new IllegalArgumentException(); 
      DebugLog.debug0x("srvRec query for attr", sortIDs[j]);
    } 
    DebugLog.debug0x("srvRec query for attr", sortIDs[sortIDs.length - 1]);
    return this.bluetoothStack.populateServicesRecordAttributeValues(this, sortIDs);
  }
  
  public String getConnectionURL(int requiredSecurity, boolean mustBeMaster) {
    int commChannel = -1;
    DataElement protocolDescriptor = getAttributeValue(4);
    if (protocolDescriptor == null || protocolDescriptor.getDataType() != 48)
      return null; 
    boolean isL2CAP = false;
    boolean isRFCOMM = false;
    boolean isOBEX = false;
    Enumeration protocolsSeqEnum = (Enumeration)protocolDescriptor.getValue();
    while (protocolsSeqEnum.hasMoreElements()) {
      DataElement elementSeq = protocolsSeqEnum.nextElement();
      if (elementSeq.getDataType() == 48) {
        Enumeration elementSeqEnum = (Enumeration)elementSeq.getValue();
        if (elementSeqEnum.hasMoreElements()) {
          DataElement protocolElement = elementSeqEnum.nextElement();
          if (protocolElement.getDataType() != 24)
            continue; 
          Object uuid = protocolElement.getValue();
          if (BluetoothConsts.OBEX_PROTOCOL_UUID.equals(uuid)) {
            isOBEX = true;
            isRFCOMM = false;
            isL2CAP = false;
            continue;
          } 
          if (elementSeqEnum.hasMoreElements() && BluetoothConsts.RFCOMM_PROTOCOL_UUID.equals(uuid)) {
            long val;
            DataElement protocolPSMElement = elementSeqEnum.nextElement();
            switch (protocolPSMElement.getDataType()) {
              case 8:
              case 9:
              case 10:
              case 16:
              case 17:
              case 18:
              case 19:
                val = protocolPSMElement.getLong();
                if (val >= 1L && val <= 30L) {
                  commChannel = (int)val;
                  isRFCOMM = true;
                  isL2CAP = false;
                } 
                continue;
            } 
            continue;
          } 
          if (elementSeqEnum.hasMoreElements() && BluetoothConsts.L2CAP_PROTOCOL_UUID.equals(uuid)) {
            long pcm;
            DataElement protocolPSMElement = elementSeqEnum.nextElement();
            switch (protocolPSMElement.getDataType()) {
              case 8:
              case 9:
              case 10:
              case 16:
              case 17:
              case 18:
              case 19:
                pcm = protocolPSMElement.getLong();
                if (pcm >= 5L && pcm <= 65535L) {
                  commChannel = (int)pcm;
                  isL2CAP = true;
                } 
            } 
          } 
        } 
      } 
    } 
    if (commChannel == -1)
      return null; 
    StringBuffer buf = new StringBuffer();
    if (isOBEX) {
      buf.append("btgoep");
    } else if (isRFCOMM) {
      buf.append("btspp");
    } else if (isL2CAP) {
      buf.append("btl2cap");
    } else {
      return null;
    } 
    buf.append("://");
    if (this.device == null) {
      try {
        Object saveID = BlueCoveImpl.getCurrentThreadBluetoothStackID();
        try {
          BlueCoveImpl.setThreadBluetoothStack(this.bluetoothStack);
          buf.append(LocalDevice.getLocalDevice().getBluetoothAddress());
        } finally {
          if (saveID != null)
            BlueCoveImpl.setThreadBluetoothStackID(saveID); 
        } 
      } catch (BluetoothStateException bse) {
        DebugLog.error("can't read LocalAddress", (Throwable)bse);
        buf.append("localhost");
      } 
    } else {
      buf.append(getHostDevice().getBluetoothAddress());
    } 
    buf.append(":");
    if (isL2CAP) {
      String hex = Integer.toHexString(commChannel);
      for (int i = hex.length(); i < 4; i++)
        buf.append('0'); 
      buf.append(hex);
    } else {
      buf.append(commChannel);
    } 
    switch (requiredSecurity) {
      case 0:
        buf.append(";authenticate=false;encrypt=false");
        break;
      case 1:
        buf.append(";authenticate=true;encrypt=false");
        break;
      case 2:
        buf.append(";authenticate=true;encrypt=true");
        break;
      default:
        throw new IllegalArgumentException();
    } 
    if (mustBeMaster) {
      buf.append(";master=true");
    } else {
      buf.append(";master=false");
    } 
    return buf.toString();
  }
  
  int getChannel(UUID protocolUUID) {
    int channel = -1;
    DataElement protocolDescriptor = getAttributeValue(4);
    if (protocolDescriptor == null || protocolDescriptor.getDataType() != 48)
      return -1; 
    Enumeration protocolsSeqEnum = (Enumeration)protocolDescriptor.getValue();
    while (protocolsSeqEnum.hasMoreElements()) {
      DataElement elementSeq = protocolsSeqEnum.nextElement();
      if (elementSeq.getDataType() == 48) {
        Enumeration elementSeqEnum = (Enumeration)elementSeq.getValue();
        if (elementSeqEnum.hasMoreElements()) {
          DataElement protocolElement = elementSeqEnum.nextElement();
          if (protocolElement.getDataType() != 24)
            continue; 
          Object uuid = protocolElement.getValue();
          if (elementSeqEnum.hasMoreElements() && protocolUUID.equals(uuid)) {
            DataElement protocolPSMElement = elementSeqEnum.nextElement();
            switch (protocolPSMElement.getDataType()) {
              case 8:
              case 9:
              case 10:
              case 16:
              case 17:
              case 18:
              case 19:
                channel = (int)protocolPSMElement.getLong();
            } 
          } 
        } 
      } 
    } 
    return channel;
  }
  
  public void setDeviceServiceClasses(int classes) {
    if (this.device != null)
      throw new RuntimeException("Service record obtained from a remote device"); 
    if ((classes & 0xFF002003) != 0)
      throw new IllegalArgumentException(); 
    if ((classes & 0x1FFC) != 0)
      throw new IllegalArgumentException(); 
    if ((this.bluetoothStack.getFeatureSet() & 0x4) == 0)
      throw new NotSupportedRuntimeException(this.bluetoothStack.getStackID()); 
    this.deviceServiceClasses = classes;
  }
  
  public boolean setAttributeValue(int attrID, DataElement attrValue) {
    if (this.device != null)
      throw new IllegalArgumentException(); 
    if (attrID < 0 || attrID > 65535)
      throw new IllegalArgumentException(); 
    if (attrID == 0)
      throw new IllegalArgumentException(); 
    this.attributeUpdated = true;
    if (attrValue == null)
      return (this.attributes.remove(new Integer(attrID)) != null); 
    this.attributes.put(new Integer(attrID), attrValue);
    return true;
  }
  
  void populateAttributeValue(int attrID, DataElement attrValue) {
    if (attrID < 0 || attrID > 65535)
      throw new IllegalArgumentException(); 
    if (attrValue == null) {
      this.attributes.remove(new Integer(attrID));
    } else {
      this.attributes.put(new Integer(attrID), attrValue);
    } 
  }
  
  public String toString() {
    StringBuffer buf = new StringBuffer("{\n");
    for (Enumeration e = this.attributes.keys(); e.hasMoreElements(); ) {
      Integer i = e.nextElement();
      buf.append("0x");
      buf.append(Integer.toHexString(i.intValue()));
      buf.append(":\n\t");
      DataElement d = (DataElement)this.attributes.get(i);
      buf.append(d);
      buf.append("\n");
    } 
    buf.append("}");
    return buf.toString();
  }
  
  long getHandle() {
    return this.handle;
  }
  
  void setHandle(long handle) {
    this.handle = handle;
  }
  
  boolean hasServiceClassUUID(UUID uuid) {
    DataElement attrDataElement = getAttributeValue(1);
    if (attrDataElement == null || attrDataElement.getDataType() != 48 || attrDataElement.getSize() == 0)
      return false; 
    Object value = attrDataElement.getValue();
    if (value == null || !(value instanceof Enumeration)) {
      DebugLog.debug("Bogus Value in DATSEQ");
      if (value != null)
        DebugLog.error("DATSEQ class " + value.getClass().getName()); 
      return false;
    } 
    for (Enumeration e = (Enumeration)value; e.hasMoreElements(); ) {
      Object element = e.nextElement();
      if (!(element instanceof DataElement)) {
        DebugLog.debug("Bogus element in DATSEQ, " + value.getClass().getName());
        continue;
      } 
      DataElement dataElement = (DataElement)element;
      if (dataElement.getDataType() == 24 && uuid.equals(dataElement.getValue()))
        return true; 
    } 
    return false;
  }
  
  boolean hasProtocolClassUUID(UUID uuid) {
    DataElement protocolDescriptor = getAttributeValue(4);
    if (protocolDescriptor == null || protocolDescriptor.getDataType() != 48)
      return false; 
    Enumeration protocolsSeqEnum = (Enumeration)protocolDescriptor.getValue();
    while (protocolsSeqEnum.hasMoreElements()) {
      DataElement elementSeq = protocolsSeqEnum.nextElement();
      if (elementSeq.getDataType() == 48) {
        Enumeration elementSeqEnum = (Enumeration)elementSeq.getValue();
        if (elementSeqEnum.hasMoreElements()) {
          DataElement protocolElement = elementSeqEnum.nextElement();
          if (protocolElement.getDataType() != 24)
            continue; 
          if (uuid.equals(protocolElement.getValue()))
            return true; 
        } 
      } 
    } 
    return false;
  }
  
  DataElement clone(DataElement de) {
    Enumeration en;
    DataElement c = null;
    switch (de.getDataType()) {
      case 8:
      case 9:
      case 10:
      case 16:
      case 17:
      case 18:
        c = new DataElement(de.getDataType(), de.getLong());
        break;
      case 12:
      case 19:
      case 20:
      case 24:
      case 32:
      case 64:
        c = new DataElement(de.getDataType(), de.getValue());
        break;
      case 0:
        c = new DataElement(de.getDataType());
        break;
      case 40:
        c = new DataElement(de.getBoolean());
        break;
      case 48:
      case 56:
        c = new DataElement(de.getDataType());
        for (en = (Enumeration)de.getValue(); en.hasMoreElements(); ) {
          DataElement dataElement = en.nextElement();
          c.addElement(clone(dataElement));
        } 
        break;
    } 
    return c;
  }
  
  void populateRFCOMMAttributes(long handle, int channel, UUID uuid, String name, boolean obex) {
    populateAttributeValue(0, new DataElement(10, handle));
    DataElement serviceClassIDList = new DataElement(48);
    serviceClassIDList.addElement(new DataElement(24, uuid));
    if (!obex)
      serviceClassIDList.addElement(new DataElement(24, BluetoothConsts.SERIAL_PORT_UUID)); 
    populateAttributeValue(1, serviceClassIDList);
    DataElement protocolDescriptorList = new DataElement(48);
    DataElement L2CAPDescriptor = new DataElement(48);
    L2CAPDescriptor.addElement(new DataElement(24, BluetoothConsts.L2CAP_PROTOCOL_UUID));
    protocolDescriptorList.addElement(L2CAPDescriptor);
    DataElement RFCOMMDescriptor = new DataElement(48);
    RFCOMMDescriptor.addElement(new DataElement(24, BluetoothConsts.RFCOMM_PROTOCOL_UUID));
    RFCOMMDescriptor.addElement(new DataElement(8, channel));
    protocolDescriptorList.addElement(RFCOMMDescriptor);
    if (obex) {
      DataElement OBEXDescriptor = new DataElement(48);
      OBEXDescriptor.addElement(new DataElement(24, BluetoothConsts.OBEX_PROTOCOL_UUID));
      protocolDescriptorList.addElement(OBEXDescriptor);
    } 
    populateAttributeValue(4, protocolDescriptorList);
    if (name != null)
      populateAttributeValue(256, new DataElement(32, name)); 
  }
  
  void populateL2CAPAttributes(int handle, int channel, UUID uuid, String name) {
    populateAttributeValue(0, new DataElement(10, handle));
    DataElement serviceClassIDList = new DataElement(48);
    serviceClassIDList.addElement(new DataElement(24, uuid));
    populateAttributeValue(1, serviceClassIDList);
    DataElement protocolDescriptorList = new DataElement(48);
    DataElement L2CAPDescriptor = new DataElement(48);
    L2CAPDescriptor.addElement(new DataElement(24, BluetoothConsts.L2CAP_PROTOCOL_UUID));
    L2CAPDescriptor.addElement(new DataElement(9, channel));
    protocolDescriptorList.addElement(L2CAPDescriptor);
    populateAttributeValue(4, protocolDescriptorList);
    if (name != null)
      populateAttributeValue(256, new DataElement(32, name)); 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\ServiceRecordImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */