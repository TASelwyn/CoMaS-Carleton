package com.intel.bluetooth;

import java.io.IOException;

class BluetoothRFCommClientConnection extends BluetoothRFCommConnection {
  public BluetoothRFCommClientConnection(BluetoothStack bluetoothStack, BluetoothConnectionParams params) throws IOException {
    super(bluetoothStack, bluetoothStack.connectionRfOpenClientConnection(params));
    boolean initOK = false;
    try {
      this.securityOpt = bluetoothStack.rfGetSecurityOpt(this.handle, Utils.securityOpt(params.authenticate, params.encrypt));
      RemoteDeviceHelper.connected(this);
      initOK = true;
    } finally {
      if (!initOK)
        try {
          bluetoothStack.connectionRfCloseClientConnection(this.handle);
        } catch (IOException e) {
          DebugLog.error("close error", e);
        }  
    } 
  }
  
  void closeConnectionHandle(long handle) throws IOException {
    RemoteDeviceHelper.disconnected(this);
    this.bluetoothStack.connectionRfCloseClientConnection(handle);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothRFCommClientConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */