/*    */ package com.intel.bluetooth;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BluetoothRFCommClientConnection
/*    */   extends BluetoothRFCommConnection
/*    */ {
/*    */   public BluetoothRFCommClientConnection(BluetoothStack bluetoothStack, BluetoothConnectionParams params) throws IOException {
/* 37 */     super(bluetoothStack, bluetoothStack.connectionRfOpenClientConnection(params));
/* 38 */     boolean initOK = false;
/*    */     try {
/* 40 */       this.securityOpt = bluetoothStack.rfGetSecurityOpt(this.handle, Utils.securityOpt(params.authenticate, params.encrypt));
/*    */       
/* 42 */       RemoteDeviceHelper.connected(this);
/* 43 */       initOK = true;
/*    */     } finally {
/* 45 */       if (!initOK) {
/*    */         try {
/* 47 */           bluetoothStack.connectionRfCloseClientConnection(this.handle);
/* 48 */         } catch (IOException e) {
/* 49 */           DebugLog.error("close error", e);
/*    */         } 
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   void closeConnectionHandle(long handle) throws IOException {
/* 56 */     RemoteDeviceHelper.disconnected(this);
/* 57 */     this.bluetoothStack.connectionRfCloseClientConnection(handle);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothRFCommClientConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */