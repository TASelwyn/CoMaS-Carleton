package com.intel.bluetooth;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.bluetooth.BluetoothConnectionException;
import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DataElement;
import javax.bluetooth.DeviceClass;
import javax.bluetooth.DiscoveryListener;
import javax.bluetooth.RemoteDevice;
import javax.bluetooth.ServiceRecord;
import javax.bluetooth.ServiceRegistrationException;
import javax.bluetooth.UUID;

class BluetoothStackOSX implements BluetoothStack, BluetoothStackExtension {
  public static final boolean debug = false;
  
  private static BluetoothStackOSX singleInstance = null;
  
  private static final int ATTR_RETRIEVABLE_MAX = 256;
  
  private final Vector deviceDiscoveryListeners = new Vector();
  
  private final Hashtable deviceDiscoveryListenerReportedDevices = new Hashtable();
  
  private int receive_mtu_max = -1;
  
  private int localDeviceSupportedSoftwareVersion;
  
  private long lastDeviceDiscoveryTime = 0L;
  
  private int localDeviceServiceClasses = 0;
  
  private Thread localDeviceServiceClassMaintainer = null;
  
  private static final int BLUETOOTH_SOFTWARE_VERSION_2_0_0 = 20000;
  
  public BluetoothStack.LibraryInformation[] requireNativeLibraries() {
    return BluetoothStack.LibraryInformation.library("bluecove");
  }
  
  public String getStackID() {
    return "mac";
  }
  
  public String toString() {
    return getStackID();
  }
  
  public int getFeatureSet() {
    if (this.localDeviceSupportedSoftwareVersion >= 20000)
      return 0x7 | (isLocalDeviceFeatureRSSI() ? 8 : 0); 
    return 3;
  }
  
  public void initialize() throws BluetoothStateException {
    if (singleInstance != null)
      throw new BluetoothStateException("Only one instance of " + getStackID() + " stack supported"); 
    String sysVersion = System.getProperty("os.version");
    String jreDataModel = System.getProperty("sun.arch.data.model");
    boolean osIsLeopard = (sysVersion != null && sysVersion.startsWith("10.5"));
    boolean jreIs64Bit = "64".equals(jreDataModel);
    if (osIsLeopard && jreIs64Bit)
      throw new BluetoothStateException("Mac OS X 10.5 not supported with a 64 bit JRE"); 
    this.localDeviceSupportedSoftwareVersion = getLocalDeviceSupportedSoftwareVersion();
    DebugLog.debug("localDeviceSupportedSoftwareVersion", this.localDeviceSupportedSoftwareVersion);
    if (!initializeImpl())
      throw new BluetoothStateException("OS X BluetoothStack not found"); 
    singleInstance = this;
  }
  
  public void destroy() {
    if (this.localDeviceSupportedSoftwareVersion >= 20000)
      setLocalDeviceServiceClassesImpl(0); 
    singleInstance = null;
  }
  
  public boolean isCurrentThreadInterruptedCallback() {
    return UtilsJavaSE.isCurrentThreadInterrupted();
  }
  
  public DeviceClass getLocalDeviceClass() {
    return new DeviceClass(getDeviceClassImpl());
  }
  
  private class MaintainDeviceServiceClassesThread extends Thread {
    private final BluetoothStackOSX this$0;
    
    MaintainDeviceServiceClassesThread(BluetoothStackOSX this$0) {
      super("MaintainDeviceServiceClassesThread");
      this.this$0 = this$0;
    }
    
    public void run() {
      boolean updated = true;
      while (true) {
        try {
          int delay = 120000;
          if (!updated)
            delay = 1000; 
          Thread.sleep(delay);
        } catch (InterruptedException e) {
          break;
        } 
        if (this.this$0.localDeviceServiceClasses != 0) {
          updated = this.this$0.setLocalDeviceServiceClassesImpl(this.this$0.localDeviceServiceClasses);
          continue;
        } 
        if (!updated)
          updated = true; 
      } 
    }
  }
  
  public synchronized void setLocalDeviceServiceClasses(int classOfDevice) {
    if (this.localDeviceSupportedSoftwareVersion < 20000)
      return; 
    if (classOfDevice != this.localDeviceServiceClasses)
      setLocalDeviceServiceClassesImpl(classOfDevice); 
    this.localDeviceServiceClasses = classOfDevice;
    if (classOfDevice != 0 && this.localDeviceServiceClassMaintainer == null) {
      this.localDeviceServiceClassMaintainer = new MaintainDeviceServiceClassesThread(this);
      UtilsJavaSE.threadSetDaemon(this.localDeviceServiceClassMaintainer);
      this.localDeviceServiceClassMaintainer.start();
    } 
  }
  
  public String getLocalDeviceProperty(String property) {
    if ("bluetooth.connected.devices.max".equals(property))
      return isLocalDeviceFeatureParkMode() ? "255" : "7"; 
    if ("bluetooth.sd.trans.max".equals(property))
      return "7"; 
    if ("bluetooth.connected.inquiry.scan".equals(property))
      return "true"; 
    if ("bluetooth.connected.page.scan".equals(property))
      return "true"; 
    if ("bluetooth.connected.inquiry".equals(property))
      return "true"; 
    if ("bluetooth.connected.page".equals(property))
      return "true"; 
    if ("bluetooth.sd.attr.retrievable.max".equals(property))
      return String.valueOf(256); 
    if ("bluetooth.master.switch".equals(property))
      return "false"; 
    if ("bluetooth.l2cap.receiveMTU.max".equals(property))
      return String.valueOf(receiveMTUMAX()); 
    if ("bluecove.radio.version".equals(property))
      return getLocalDeviceVersion(); 
    if ("bluecove.radio.manufacturer".equals(property))
      return String.valueOf(getLocalDeviceManufacturer()); 
    if ("bluecove.stack.version".equals(property))
      return getLocalDeviceSoftwareVersionInfo(); 
    return null;
  }
  
  private int receiveMTUMAX() {
    if (this.receive_mtu_max < 0)
      this.receive_mtu_max = getLocalDeviceL2CAPMTUMaximum(); 
    return this.receive_mtu_max;
  }
  
  public int getLocalDeviceDiscoverable() {
    if (getLocalDeviceDiscoverableImpl())
      return 10390323; 
    return 0;
  }
  
  public boolean setLocalDeviceDiscoverable(int mode) throws BluetoothStateException {
    if (getLocalDeviceDiscoverable() == mode)
      return true; 
    return false;
  }
  
  private void verifyDeviceReady() throws BluetoothStateException {
    if (!isLocalDevicePowerOn())
      throw new BluetoothStateException("Bluetooth Device is not ready"); 
  }
  
  public RemoteDevice[] retrieveDevices(int option) {
    Vector devices = new Vector();
    RetrieveDevicesCallback retrieveDevicesCallback = new RetrieveDevicesCallback(this, devices) {
        private final Vector val$devices;
        
        private final BluetoothStackOSX this$0;
        
        public void deviceFoundCallback(long deviceAddr, int deviceClass, String deviceName, boolean paired) {
          DebugLog.debug("device found", deviceAddr);
          RemoteDevice remoteDevice = RemoteDeviceHelper.createRemoteDevice(this.this$0, deviceAddr, deviceName, paired);
          if (!this.val$devices.contains(remoteDevice))
            this.val$devices.add(remoteDevice); 
        }
      };
    if (retrieveDevicesImpl(option, retrieveDevicesCallback))
      return RemoteDeviceHelper.remoteDeviceListToArray(devices); 
    return null;
  }
  
  public Boolean isRemoteDeviceTrusted(long address) {
    return new Boolean(isRemoteDeviceTrustedImpl(address));
  }
  
  public Boolean isRemoteDeviceAuthenticated(long address) {
    return new Boolean(isRemoteDeviceAuthenticatedImpl(address));
  }
  
  public int readRemoteDeviceRSSI(long address) throws IOException {
    return readRemoteDeviceRSSIImpl(address);
  }
  
  public boolean authenticateRemoteDevice(long address) throws IOException {
    return authenticateRemoteDeviceImpl(address);
  }
  
  public boolean authenticateRemoteDevice(long address, String passkey) throws IOException {
    return false;
  }
  
  public void removeAuthenticationWithRemoteDevice(long address) throws IOException {
    throw new NotSupportedIOException(getStackID());
  }
  
  public boolean startInquiry(int accessCode, DiscoveryListener listener) throws BluetoothStateException {
    long sinceDiscoveryLast = System.currentTimeMillis() - this.lastDeviceDiscoveryTime;
    long acceptableInterval = 7000L;
    if (sinceDiscoveryLast < acceptableInterval)
      try {
        Thread.sleep(acceptableInterval - sinceDiscoveryLast);
      } catch (InterruptedException e) {
        throw new BluetoothStateException();
      }  
    this.deviceDiscoveryListeners.addElement(listener);
    this.deviceDiscoveryListenerReportedDevices.put(listener, new Vector());
    DeviceInquiryRunnable inquiryRunnable = new DeviceInquiryRunnable(this) {
        private final BluetoothStackOSX this$0;
        
        public int runDeviceInquiry(DeviceInquiryThread startedNotify, int accessCode, DiscoveryListener listener) throws BluetoothStateException {
          try {
            return this.this$0.runDeviceInquiryImpl(this, startedNotify, accessCode, DeviceInquiryThread.getConfigDeviceInquiryDuration(), listener);
          } finally {
            this.this$0.lastDeviceDiscoveryTime = System.currentTimeMillis();
            this.this$0.deviceDiscoveryListeners.removeElement(listener);
            this.this$0.deviceDiscoveryListenerReportedDevices.remove(listener);
          } 
        }
        
        public void deviceDiscoveredCallback(DiscoveryListener listener, long deviceAddr, int deviceClass, String deviceName, boolean paired) {
          if (!this.this$0.deviceDiscoveryListeners.contains(listener))
            return; 
          RemoteDevice remoteDevice = RemoteDeviceHelper.createRemoteDevice(this.this$0, deviceAddr, deviceName, paired);
          Vector reported = (Vector)this.this$0.deviceDiscoveryListenerReportedDevices.get(listener);
          if (reported == null || reported.contains(remoteDevice))
            return; 
          reported.addElement(remoteDevice);
          DeviceClass cod = new DeviceClass(deviceClass);
          DebugLog.debug("deviceDiscoveredCallback address", remoteDevice.getBluetoothAddress());
          DebugLog.debug("deviceDiscoveredCallback deviceClass", cod);
          listener.deviceDiscovered(remoteDevice, cod);
        }
      };
    return DeviceInquiryThread.startInquiry(this, inquiryRunnable, accessCode, listener);
  }
  
  public boolean cancelInquiry(DiscoveryListener listener) {
    if (!this.deviceDiscoveryListeners.removeElement(listener))
      return false; 
    return deviceInquiryCancelImpl();
  }
  
  public int searchServices(int[] attrSet, UUID[] uuidSet, RemoteDevice device, DiscoveryListener listener) throws BluetoothStateException {
    SearchServicesRunnable searchRunnable = new SearchServicesRunnable(this) {
        private final BluetoothStackOSX this$0;
        
        public int runSearchServices(SearchServicesThread sst, int[] attrSet, UUID[] uuidSet, RemoteDevice device, DiscoveryListener listener) throws BluetoothStateException {
          int recordsSize;
          sst.searchServicesStartedCallback();
          try {
            recordsSize = this.this$0.runSearchServicesImpl(RemoteDeviceHelper.getAddress(device), sst.getTransID());
          } catch (SearchServicesDeviceNotReachableException e) {
            return 6;
          } catch (SearchServicesTerminatedException e) {
            return 2;
          } catch (SearchServicesException e) {
            return 3;
          } 
          if (sst.isTerminated())
            return 2; 
          if (recordsSize == 0)
            return 4; 
          Vector records = new Vector();
          int[] uuidFilerAttrIDs = { 1, 4 };
          int[] requiredAttrIDs = { 0, 2, 3 };
          int i;
          label38: for (i = 0; i < recordsSize; i++) {
            ServiceRecordImpl sr = new ServiceRecordImpl(this.this$0, device, i);
            try {
              sr.populateRecord(uuidFilerAttrIDs);
              for (int u = 0; u < uuidSet.length; u++) {
                if (!sr.hasServiceClassUUID(uuidSet[u]) && !sr.hasProtocolClassUUID(uuidSet[u]))
                  continue label38; 
              } 
              records.addElement(sr);
              sr.populateRecord(requiredAttrIDs);
              if (attrSet != null)
                sr.populateRecord(attrSet); 
              DebugLog.debug("ServiceRecord (" + i + ")", sr);
            } catch (Exception e) {
              DebugLog.debug("populateRecord error", e);
            } 
            if (sst.isTerminated()) {
              DebugLog.debug("SERVICE_SEARCH_TERMINATED " + sst.getTransID());
              return 2;
            } 
          } 
          if (records.size() != 0) {
            DebugLog.debug("SERVICE_SEARCH_COMPLETED " + sst.getTransID());
            ServiceRecord[] fileteredRecords = (ServiceRecord[])Utils.vector2toArray(records, (Object[])new ServiceRecord[records.size()]);
            listener.servicesDiscovered(sst.getTransID(), fileteredRecords);
            return 1;
          } 
          return 4;
        }
      };
    return SearchServicesThread.startSearchServices(this, searchRunnable, attrSet, uuidSet, device, listener);
  }
  
  public boolean cancelServiceSearch(int transID) {
    SearchServicesThread sst = SearchServicesThread.getServiceSearchThread(transID);
    if (sst != null)
      synchronized (this) {
        if (!sst.isTerminated()) {
          sst.setTerminated();
          cancelServiceSearchImpl(transID);
          return true;
        } 
      }  
    return false;
  }
  
  public boolean populateServicesRecordAttributeValues(ServiceRecordImpl serviceRecord, int[] attrIDs) throws IOException {
    if (attrIDs.length > 256)
      throw new IllegalArgumentException(); 
    boolean anyRetrived = false;
    long address = RemoteDeviceHelper.getAddress(serviceRecord.getHostDevice());
    for (int i = 0; i < attrIDs.length; i++) {
      int id = attrIDs[i];
      try {
        byte[] blob = getServiceAttributeImpl(address, serviceRecord.getHandle(), id);
        if (blob != null) {
          DataElement element = (new SDPInputStream(new ByteArrayInputStream(blob))).readElement();
          serviceRecord.populateAttributeValue(id, element);
          anyRetrived = true;
        } 
      } catch (Throwable e) {}
    } 
    return anyRetrived;
  }
  
  public long connectionRfOpenClientConnection(BluetoothConnectionParams params) throws IOException {
    if (params.encrypt)
      throw new BluetoothConnectionException(2, "encrypt mode not supported"); 
    Object lock = RemoteDeviceHelper.createRemoteDevice(this, params.address, null, false);
    synchronized (lock) {
      return connectionRfOpenClientConnectionImpl(params.address, params.channel, params.authenticate, params.encrypt, params.timeout);
    } 
  }
  
  public boolean rfEncrypt(long address, long handle, boolean on) throws IOException {
    return false;
  }
  
  public long rfServerOpen(BluetoothConnectionNotifierParams params, ServiceRecordImpl serviceRecord) throws IOException {
    verifyDeviceReady();
    if (params.encrypt)
      throw new BluetoothConnectionException(2, "encrypt mode not supported"); 
    byte[] uuidValue = Utils.UUIDToByteArray(params.uuid);
    long handle = rfServerCreateImpl(uuidValue, params.obex, params.name, params.authenticate, params.encrypt);
    boolean success = false;
    try {
      int channel = rfServerGetChannelID(handle);
      serviceRecord.populateRFCOMMAttributes(handle, channel, params.uuid, params.name, params.obex);
      success = true;
    } finally {
      if (!success)
        rfServerCloseImpl(handle); 
    } 
    return handle;
  }
  
  public void rfServerClose(long handle, ServiceRecordImpl serviceRecord) throws IOException {
    rfServerCloseImpl(handle);
  }
  
  public void rfServerUpdateServiceRecord(long handle, ServiceRecordImpl serviceRecord, boolean acceptAndOpen) throws ServiceRegistrationException {
    sdpServiceUpdateServiceRecord(handle, 'R', serviceRecord);
  }
  
  public void connectionRfCloseServerConnection(long handle) throws IOException {
    connectionRfCloseClientConnection(handle);
  }
  
  private void sdpServiceAddAttribute(long handle, char handleType, int attrID, DataElement element) throws ServiceRegistrationException {
    byte[] bs, bu;
    Enumeration e;
    int type = element.getDataType();
    switch (type) {
      case 0:
        sdpServiceAddAttribute(handle, handleType, attrID, type, 0L, null);
        return;
      case 40:
        sdpServiceAddAttribute(handle, handleType, attrID, type, element.getBoolean() ? 1L : 0L, null);
        return;
      case 8:
      case 9:
      case 10:
      case 16:
      case 17:
      case 18:
      case 19:
        sdpServiceAddAttribute(handle, handleType, attrID, type, element.getLong(), null);
        return;
      case 11:
      case 12:
      case 20:
        sdpServiceAddAttribute(handle, handleType, attrID, type, 0L, (byte[])element.getValue());
        return;
      case 24:
        sdpServiceAddAttribute(handle, handleType, attrID, type, 0L, Utils.UUIDToByteArray((UUID)element.getValue()));
        return;
      case 32:
        bs = Utils.getUTF8Bytes((String)element.getValue());
        sdpServiceAddAttribute(handle, handleType, attrID, type, 0L, bs);
        return;
      case 64:
        bu = Utils.getASCIIBytes((String)element.getValue());
        sdpServiceAddAttribute(handle, handleType, attrID, type, 0L, bu);
        return;
      case 48:
      case 56:
        sdpServiceSequenceAttributeStart(handle, handleType, attrID, type);
        for (e = (Enumeration)element.getValue(); e.hasMoreElements(); ) {
          DataElement child = e.nextElement();
          sdpServiceAddAttribute(handle, handleType, -1, child);
        } 
        sdpServiceSequenceAttributeEnd(handle, handleType, attrID);
        return;
    } 
    throw new IllegalArgumentException();
  }
  
  private void sdpServiceUpdateServiceRecord(long handle, char handleType, ServiceRecordImpl serviceRecord) throws ServiceRegistrationException {
    int[] ids = serviceRecord.getAttributeIDs();
    if (ids == null || ids.length == 0)
      return; 
    for (int i = 0; i < ids.length; i++) {
      int attrID = ids[i];
      switch (attrID) {
        case 0:
        case 4:
        case 256:
          break;
        default:
          sdpServiceAddAttribute(handle, handleType, attrID, serviceRecord.getAttributeValue(attrID));
          break;
      } 
    } 
    sdpServiceUpdateServiceRecordPublish(handle, handleType);
  }
  
  public void connectionRfFlush(long handle) throws IOException {}
  
  public void connectionRfWrite(long handle, int b) throws IOException {
    byte[] buf = new byte[1];
    buf[0] = (byte)(b & 0xFF);
    connectionRfWrite(handle, buf, 0, 1);
  }
  
  private void validateMTU(int receiveMTU, int transmitMTU) {
    if (receiveMTU > receiveMTUMAX())
      throw new IllegalArgumentException("invalid ReceiveMTU value " + receiveMTU); 
  }
  
  public long l2OpenClientConnection(BluetoothConnectionParams params, int receiveMTU, int transmitMTU) throws IOException {
    validateMTU(receiveMTU, transmitMTU);
    if (params.encrypt)
      throw new BluetoothConnectionException(2, "encrypt mode not supported"); 
    Object lock = RemoteDeviceHelper.createRemoteDevice(this, params.address, null, false);
    synchronized (lock) {
      return l2OpenClientConnectionImpl(params.address, params.channel, params.authenticate, params.encrypt, receiveMTU, transmitMTU, params.timeout);
    } 
  }
  
  public long l2ServerOpen(BluetoothConnectionNotifierParams params, int receiveMTU, int transmitMTU, ServiceRecordImpl serviceRecord) throws IOException {
    verifyDeviceReady();
    validateMTU(receiveMTU, transmitMTU);
    if (params.encrypt)
      throw new BluetoothConnectionException(2, "encrypt mode not supported"); 
    byte[] uuidValue = Utils.UUIDToByteArray(params.uuid);
    long handle = l2ServerOpenImpl(uuidValue, params.authenticate, params.encrypt, params.name, receiveMTU, transmitMTU, params.bluecove_ext_psm);
    int channel = l2ServerPSM(handle);
    int serviceRecordHandle = (int)handle;
    serviceRecord.populateL2CAPAttributes(serviceRecordHandle, channel, params.uuid, params.name);
    return handle;
  }
  
  public void l2ServerUpdateServiceRecord(long handle, ServiceRecordImpl serviceRecord, boolean acceptAndOpen) throws ServiceRegistrationException {
    sdpServiceUpdateServiceRecord(handle, 'L', serviceRecord);
  }
  
  public void l2CloseServerConnection(long handle) throws IOException {
    l2CloseClientConnection(handle);
  }
  
  public void l2ServerClose(long handle, ServiceRecordImpl serviceRecord) throws IOException {
    l2ServerCloseImpl(handle);
  }
  
  public boolean l2Encrypt(long address, long handle, boolean on) throws IOException {
    return false;
  }
  
  public native boolean isNativeCodeLoaded();
  
  public native int getLibraryVersion();
  
  public native int detectBluetoothStack();
  
  private native boolean initializeImpl();
  
  public native void enableNativeDebug(Class paramClass, boolean paramBoolean);
  
  public native String getLocalDeviceBluetoothAddress() throws BluetoothStateException;
  
  public native String getLocalDeviceName();
  
  private native int getDeviceClassImpl();
  
  private native boolean setLocalDeviceServiceClassesImpl(int paramInt);
  
  public native boolean isLocalDevicePowerOn();
  
  private native boolean isLocalDeviceFeatureSwitchRoles();
  
  private native boolean isLocalDeviceFeatureParkMode();
  
  private native boolean isLocalDeviceFeatureRSSI();
  
  private native int getLocalDeviceL2CAPMTUMaximum();
  
  private native int getLocalDeviceSupportedSoftwareVersion();
  
  private native String getLocalDeviceSoftwareVersionInfo();
  
  private native int getLocalDeviceManufacturer();
  
  private native String getLocalDeviceVersion();
  
  private native boolean getLocalDeviceDiscoverableImpl();
  
  private native boolean retrieveDevicesImpl(int paramInt, RetrieveDevicesCallback paramRetrieveDevicesCallback);
  
  private native boolean isRemoteDeviceTrustedImpl(long paramLong);
  
  private native boolean isRemoteDeviceAuthenticatedImpl(long paramLong);
  
  private native int readRemoteDeviceRSSIImpl(long paramLong) throws IOException;
  
  private native boolean authenticateRemoteDeviceImpl(long paramLong) throws IOException;
  
  public native String getRemoteDeviceFriendlyName(long paramLong) throws IOException;
  
  private native int runDeviceInquiryImpl(DeviceInquiryRunnable paramDeviceInquiryRunnable, DeviceInquiryThread paramDeviceInquiryThread, int paramInt1, int paramInt2, DiscoveryListener paramDiscoveryListener) throws BluetoothStateException;
  
  private native boolean deviceInquiryCancelImpl();
  
  private native int runSearchServicesImpl(long paramLong, int paramInt) throws BluetoothStateException, SearchServicesException;
  
  private native void cancelServiceSearchImpl(int paramInt);
  
  private native byte[] getServiceAttributeImpl(long paramLong1, long paramLong2, int paramInt);
  
  private native long connectionRfOpenClientConnectionImpl(long paramLong, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2) throws IOException;
  
  public native void connectionRfCloseClientConnection(long paramLong) throws IOException;
  
  public native int rfGetSecurityOpt(long paramLong, int paramInt) throws IOException;
  
  private native long rfServerCreateImpl(byte[] paramArrayOfbyte, boolean paramBoolean1, String paramString, boolean paramBoolean2, boolean paramBoolean3) throws IOException;
  
  private native int rfServerGetChannelID(long paramLong) throws IOException;
  
  private native void rfServerCloseImpl(long paramLong) throws IOException;
  
  public native long rfServerAcceptAndOpenRfServerConnection(long paramLong) throws IOException;
  
  private native void sdpServiceUpdateServiceRecordPublish(long paramLong, char paramChar) throws ServiceRegistrationException;
  
  private native void sdpServiceAddAttribute(long paramLong1, char paramChar, int paramInt1, int paramInt2, long paramLong2, byte[] paramArrayOfbyte) throws ServiceRegistrationException;
  
  private native void sdpServiceSequenceAttributeStart(long paramLong, char paramChar, int paramInt1, int paramInt2) throws ServiceRegistrationException;
  
  private native void sdpServiceSequenceAttributeEnd(long paramLong, char paramChar, int paramInt) throws ServiceRegistrationException;
  
  public native int connectionRfRead(long paramLong) throws IOException;
  
  public native int connectionRfRead(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
  
  public native int connectionRfReadAvailable(long paramLong) throws IOException;
  
  public native void connectionRfWrite(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
  
  public native long getConnectionRfRemoteAddress(long paramLong) throws IOException;
  
  private native long l2OpenClientConnectionImpl(long paramLong, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3, int paramInt4) throws IOException;
  
  public native void l2CloseClientConnection(long paramLong) throws IOException;
  
  private native long l2ServerOpenImpl(byte[] paramArrayOfbyte, boolean paramBoolean1, boolean paramBoolean2, String paramString, int paramInt1, int paramInt2, int paramInt3) throws IOException;
  
  public native int l2ServerPSM(long paramLong) throws IOException;
  
  public native long l2ServerAcceptAndOpenServerConnection(long paramLong) throws IOException;
  
  private native void l2ServerCloseImpl(long paramLong) throws IOException;
  
  public native int l2GetSecurityOpt(long paramLong, int paramInt) throws IOException;
  
  public native boolean l2Ready(long paramLong) throws IOException;
  
  public native int l2Receive(long paramLong, byte[] paramArrayOfbyte) throws IOException;
  
  public native void l2Send(long paramLong, byte[] paramArrayOfbyte, int paramInt) throws IOException;
  
  public native int l2GetReceiveMTU(long paramLong) throws IOException;
  
  public native int l2GetTransmitMTU(long paramLong) throws IOException;
  
  public native long l2RemoteAddress(long paramLong) throws IOException;
}
