/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.bluetooth.BluetoothStateException;
/*     */ import javax.bluetooth.DiscoveryListener;
/*     */ import javax.bluetooth.RemoteDevice;
/*     */ import javax.bluetooth.ServiceRecord;
/*     */ import javax.bluetooth.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SearchServicesThread
/*     */   extends Thread
/*     */ {
/*  45 */   private static int transIDGenerator = 0;
/*     */   
/*  47 */   private static Hashtable threads = new Hashtable();
/*     */   
/*     */   private BluetoothStack stack;
/*     */   
/*     */   private SearchServicesRunnable serachRunnable;
/*     */   
/*     */   private int transID;
/*     */   
/*     */   private int[] attrSet;
/*     */   
/*  57 */   private Vector servicesRecords = new Vector();
/*     */   
/*     */   UUID[] uuidSet;
/*     */   
/*     */   private RemoteDevice device;
/*     */   
/*     */   private DiscoveryListener listener;
/*     */   
/*     */   private BluetoothStateException startException;
/*     */   
/*     */   private boolean started = false;
/*     */   
/*     */   private boolean finished = false;
/*     */   
/*     */   private boolean terminated = false;
/*     */   
/*  73 */   private Object serviceSearchStartedEvent = new Object();
/*     */   
/*     */   private static synchronized int nextThreadNum() {
/*  76 */     return ++transIDGenerator;
/*     */   }
/*     */ 
/*     */   
/*     */   private SearchServicesThread(int transID, BluetoothStack stack, SearchServicesRunnable serachRunnable, int[] attrSet, UUID[] uuidSet, RemoteDevice device, DiscoveryListener listener) {
/*  81 */     super("SearchServicesThread-" + transID);
/*  82 */     this.stack = stack;
/*  83 */     this.serachRunnable = serachRunnable;
/*  84 */     this.transID = transID;
/*  85 */     this.attrSet = attrSet;
/*  86 */     this.listener = listener;
/*  87 */     this.uuidSet = uuidSet;
/*  88 */     this.device = RemoteDeviceHelper.getStackBoundDevice(stack, device);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int startSearchServices(BluetoothStack stack, SearchServicesRunnable searchRunnable, int[] attrSet, UUID[] uuidSet, RemoteDevice device, DiscoveryListener listener) throws BluetoothStateException {
/*     */     SearchServicesThread t;
/*  98 */     synchronized (threads) {
/*  99 */       int runningCount = countRunningSearchServicesThreads(stack);
/* 100 */       int concurrentAllow = Integer.valueOf(stack.getLocalDeviceProperty("bluetooth.sd.trans.max")).intValue();
/* 101 */       if (runningCount >= concurrentAllow) {
/* 102 */         throw new BluetoothStateException("Already running " + runningCount + " service discovery transactions");
/*     */       }
/* 104 */       t = new SearchServicesThread(nextThreadNum(), stack, searchRunnable, attrSet, uuidSet, device, listener);
/* 105 */       threads.put(new Integer(t.getTransID()), t);
/*     */     } 
/*     */     
/* 108 */     UtilsJavaSE.threadSetDaemon(t);
/* 109 */     synchronized (t.serviceSearchStartedEvent) {
/* 110 */       t.start();
/* 111 */       while (!t.started && !t.finished) {
/*     */         try {
/* 113 */           t.serviceSearchStartedEvent.wait();
/* 114 */         } catch (InterruptedException e) {
/* 115 */           return 0;
/*     */         } 
/* 117 */         if (t.startException != null) {
/* 118 */           throw t.startException;
/*     */         }
/*     */       } 
/*     */     } 
/* 122 */     if (t.started) {
/* 123 */       return t.getTransID();
/*     */     }
/*     */     
/* 126 */     throw new BluetoothStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   private static int countRunningSearchServicesThreads(BluetoothStack stack) {
/* 131 */     int count = 0;
/* 132 */     for (Enumeration en = threads.elements(); en.hasMoreElements(); ) {
/* 133 */       SearchServicesThread t = en.nextElement();
/* 134 */       if (t.stack == stack) {
/* 135 */         count++;
/*     */       }
/*     */     } 
/* 138 */     return count;
/*     */   }
/*     */   
/*     */   static SearchServicesThread getServiceSearchThread(int transID) {
/* 142 */     return (SearchServicesThread)threads.get(new Integer(transID));
/*     */   }
/*     */   
/*     */   public void run() {
/* 146 */     int respCode = 3;
/*     */     try {
/* 148 */       BlueCoveImpl.setThreadBluetoothStack(this.stack);
/* 149 */       respCode = this.serachRunnable.runSearchServices(this, this.attrSet, this.uuidSet, this.device, this.listener);
/* 150 */     } catch (BluetoothStateException e) {
/* 151 */       this.startException = e;
/*     */       return;
/*     */     } finally {
/* 154 */       this.finished = true;
/* 155 */       unregisterThread();
/* 156 */       synchronized (this.serviceSearchStartedEvent) {
/* 157 */         this.serviceSearchStartedEvent.notifyAll();
/*     */       } 
/* 159 */       DebugLog.debug("runSearchServices ends", getTransID());
/* 160 */       if (this.started) {
/* 161 */         Utils.j2meUsagePatternDellay();
/* 162 */         this.listener.serviceSearchCompleted(getTransID(), respCode);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void unregisterThread() {
/* 168 */     synchronized (threads) {
/* 169 */       threads.remove(new Integer(getTransID()));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void searchServicesStartedCallback() {
/* 174 */     DebugLog.debug("searchServicesStartedCallback", getTransID());
/* 175 */     this.started = true;
/* 176 */     synchronized (this.serviceSearchStartedEvent) {
/* 177 */       this.serviceSearchStartedEvent.notifyAll();
/*     */     } 
/*     */   }
/*     */   
/*     */   int getTransID() {
/* 182 */     return this.transID;
/*     */   }
/*     */   
/*     */   boolean setTerminated() {
/* 186 */     if (isTerminated()) {
/* 187 */       return false;
/*     */     }
/* 189 */     this.terminated = true;
/* 190 */     unregisterThread();
/* 191 */     return true;
/*     */   }
/*     */   
/*     */   boolean isTerminated() {
/* 195 */     return this.terminated;
/*     */   }
/*     */   
/*     */   RemoteDevice getDevice() {
/* 199 */     return this.device;
/*     */   }
/*     */   
/*     */   DiscoveryListener getListener() {
/* 203 */     return this.listener;
/*     */   }
/*     */   
/*     */   void addServicesRecords(ServiceRecord servRecord) {
/* 207 */     this.servicesRecords.addElement(servRecord);
/*     */   }
/*     */   
/*     */   Vector getServicesRecords() {
/* 211 */     return this.servicesRecords;
/*     */   }
/*     */   
/*     */   public int[] getAttrSet() {
/* 215 */     int[] requiredAttrIDs = { 0, 1, 2, 3, 4 };
/*     */ 
/*     */     
/* 218 */     if (this.attrSet == null) {
/* 219 */       return requiredAttrIDs;
/*     */     }
/*     */     
/* 222 */     int len = requiredAttrIDs.length + this.attrSet.length;
/* 223 */     for (int i = 0; i < this.attrSet.length; i++) {
/* 224 */       for (int k = 0; k < requiredAttrIDs.length; k++) {
/* 225 */         if (requiredAttrIDs[k] == this.attrSet[i]) {
/* 226 */           len--;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 232 */     int[] allIDs = new int[len];
/* 233 */     System.arraycopy(requiredAttrIDs, 0, allIDs, 0, requiredAttrIDs.length);
/* 234 */     int appendPosition = requiredAttrIDs.length;
/* 235 */     for (int j = 0; j < this.attrSet.length; j++) {
/* 236 */       int k = 0; while (true) { if (k < requiredAttrIDs.length) {
/* 237 */           if (requiredAttrIDs[k] == this.attrSet[j])
/*     */             break;  k++;
/*     */           continue;
/*     */         } 
/* 241 */         allIDs[appendPosition] = this.attrSet[j];
/* 242 */         appendPosition++; break; }
/*     */     
/* 244 */     }  return allIDs;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\SearchServicesThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */