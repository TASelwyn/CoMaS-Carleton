package com.intel.bluetooth;

import java.io.IOException;

class BluetoothL2CAPServerConnection extends BluetoothL2CAPConnection implements BluetoothServerConnection {
  protected BluetoothL2CAPServerConnection(BluetoothStack bluetoothStack, long handle, int transmitMTU, int securityOpt) throws IOException {
    super(bluetoothStack, handle);
    boolean initOK = false;
    try {
      this.securityOpt = securityOpt;
      this.transmitMTU = getTransmitMTU();
      if (transmitMTU > 0 && transmitMTU < this.transmitMTU)
        this.transmitMTU = transmitMTU; 
      RemoteDeviceHelper.connected(this);
      initOK = true;
    } finally {
      if (!initOK)
        try {
          bluetoothStack.l2CloseServerConnection(this.handle);
        } catch (IOException e) {
          DebugLog.error("close error", e);
        }  
    } 
  }
  
  void closeConnectionHandle(long handle) throws IOException {
    RemoteDeviceHelper.disconnected(this);
    this.bluetoothStack.l2CloseServerConnection(handle);
  }
}
