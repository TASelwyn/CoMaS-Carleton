package com.intel.bluetooth;

public interface BluetoothServerConnection {}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothServerConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */