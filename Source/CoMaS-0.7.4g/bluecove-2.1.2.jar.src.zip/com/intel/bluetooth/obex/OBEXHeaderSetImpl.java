package com.intel.bluetooth.obex;

import com.intel.bluetooth.DebugLog;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.TimeZone;
import java.util.Vector;
import javax.obex.HeaderSet;

class OBEXHeaderSetImpl implements HeaderSet {
  static final int OBEX_HDR_COUNT = 192;
  
  static final int OBEX_HDR_NAME = 1;
  
  static final int OBEX_HDR_TYPE = 66;
  
  static final int OBEX_HDR_LENGTH = 195;
  
  static final int OBEX_HDR_TIME = 68;
  
  static final int OBEX_HDR_TIME2 = 196;
  
  static final int OBEX_HDR_DESCRIPTION = 5;
  
  static final int OBEX_HDR_TARGET = 70;
  
  static final int OBEX_HDR_HTTP = 71;
  
  static final int OBEX_HDR_BODY = 72;
  
  static final int OBEX_HDR_BODY_END = 73;
  
  static final int OBEX_HDR_WHO = 74;
  
  static final int OBEX_HDR_CONNECTION = 203;
  
  static final int OBEX_HDR_APP_PARAM = 76;
  
  static final int OBEX_HDR_AUTH_CHALLENGE = 77;
  
  static final int OBEX_HDR_AUTH_RESPONSE = 78;
  
  static final int OBEX_HDR_OBJECTCLASS = 79;
  
  static final int OBEX_HDR_CREATOR = 207;
  
  static final int OBEX_HDR_WANUUID = 80;
  
  static final int OBEX_HDR_SESSIONPARAM = 82;
  
  static final int OBEX_HDR_SESSIONSEQ = 147;
  
  static final int OBEX_HDR_USER = 48;
  
  static final int OBEX_HDR_HI_MASK = 192;
  
  static final int OBEX_HDR_ID_MASK = 63;
  
  static final int OBEX_STRING = 0;
  
  static final int OBEX_BYTE_STREAM = 64;
  
  static final int OBEX_BYTE = 128;
  
  static final int OBEX_INT = 192;
  
  private static final int OBEX_MAX_FIELD_LEN = 255;
  
  private int responseCode;
  
  private Hashtable headerValues;
  
  private Vector authResponses;
  
  private Vector authChallenges;
  
  private static final int NO_RESPONSE_CODE = -2147483648;
  
  OBEXHeaderSetImpl() {
    this(-2147483648);
  }
  
  private OBEXHeaderSetImpl(int responseCode) {
    this.headerValues = new Hashtable();
    this.responseCode = responseCode;
    this.authResponses = null;
    this.authChallenges = null;
  }
  
  static void validateCreatedHeaderSet(HeaderSet headers) {
    if (headers == null)
      return; 
    if (!(headers instanceof OBEXHeaderSetImpl))
      throw new IllegalArgumentException("Illegal HeaderSet type"); 
    if (((OBEXHeaderSetImpl)headers).responseCode != Integer.MIN_VALUE)
      throw new IllegalArgumentException("Illegal HeaderSet"); 
  }
  
  private void validateHeaderID(int headerID) throws IllegalArgumentException {
    if (headerID < 0 || headerID > 255)
      throw new IllegalArgumentException("Expected header ID in range 0 to 255"); 
    int identifier = headerID & 0x3F;
    if (identifier >= 16 && identifier < 47)
      throw new IllegalArgumentException("Reserved header ID"); 
  }
  
  public void setHeader(int headerID, Object headerValue) {
    validateHeaderID(headerID);
    if (headerValue == null) {
      this.headerValues.remove(new Integer(headerID));
    } else {
      if (headerID == 68 || headerID == 196) {
        if (!(headerValue instanceof Calendar))
          throw new IllegalArgumentException("Expected java.util.Calendar"); 
      } else if (headerID == 66) {
        if (!(headerValue instanceof String))
          throw new IllegalArgumentException("Expected java.lang.String"); 
      } else {
        long v;
        switch (headerID & 0xC0) {
          case 0:
            if (!(headerValue instanceof String))
              throw new IllegalArgumentException("Expected java.lang.String"); 
            break;
          case 64:
            if (!(headerValue instanceof byte[]))
              throw new IllegalArgumentException("Expected byte[]"); 
            break;
          case 128:
            if (!(headerValue instanceof Byte))
              throw new IllegalArgumentException("Expected java.lang.Byte"); 
            break;
          case 192:
            if (!(headerValue instanceof Long))
              throw new IllegalArgumentException("Expected java.lang.Long"); 
            v = ((Long)headerValue).longValue();
            if (v < 0L || v > 4294967295L)
              throw new IllegalArgumentException("Expected long in range 0 to 2^32-1"); 
            break;
          default:
            throw new IllegalArgumentException("Unsupported encoding " + (headerID & 0xC0));
        } 
      } 
      this.headerValues.put(new Integer(headerID), headerValue);
    } 
  }
  
  public Object getHeader(int headerID) throws IOException {
    validateHeaderID(headerID);
    return this.headerValues.get(new Integer(headerID));
  }
  
  public int[] getHeaderList() throws IOException {
    if (this.headerValues.size() == 0)
      return null; 
    int[] headerIDArray = new int[this.headerValues.size()];
    int i = 0;
    for (Enumeration e = this.headerValues.keys(); e.hasMoreElements();)
      headerIDArray[i++] = ((Integer)e.nextElement()).intValue(); 
    return headerIDArray;
  }
  
  public int getResponseCode() throws IOException {
    if (this.responseCode == Integer.MIN_VALUE)
      throw new IOException(); 
    return this.responseCode;
  }
  
  boolean hasIncommingData() {
    return (this.headerValues.contains(new Integer(72)) || this.headerValues.contains(new Integer(73)));
  }
  
  static OBEXHeaderSetImpl cloneHeaders(HeaderSet headers) throws IOException {
    if (headers == null)
      return null; 
    if (!(headers instanceof OBEXHeaderSetImpl))
      throw new IllegalArgumentException("Illegal HeaderSet type"); 
    OBEXHeaderSetImpl hs = new OBEXHeaderSetImpl(((OBEXHeaderSetImpl)headers).responseCode);
    int[] headerIDArray = headers.getHeaderList();
    for (int i = 0; headerIDArray != null && i < headerIDArray.length; i++) {
      int headerID = headerIDArray[i];
      if (headerID != 72 && headerID != 73)
        hs.setHeader(headerID, headers.getHeader(headerID)); 
    } 
    return hs;
  }
  
  static HeaderSet appendHeaders(HeaderSet dst, HeaderSet src) throws IOException {
    int[] headerIDArray = src.getHeaderList();
    for (int i = 0; headerIDArray != null && i < headerIDArray.length; i++) {
      int headerID = headerIDArray[i];
      if (headerID != 72 && headerID != 73)
        dst.setHeader(headerID, src.getHeader(headerID)); 
    } 
    return dst;
  }
  
  public synchronized void createAuthenticationChallenge(String realm, boolean isUserIdRequired, boolean isFullAccess) {
    if (this.authChallenges == null)
      this.authChallenges = new Vector(); 
    this.authChallenges.addElement(OBEXAuthentication.createChallenge(realm, isUserIdRequired, isFullAccess));
  }
  
  synchronized void addAuthenticationResponse(byte[] authResponse) {
    if (this.authResponses == null)
      this.authResponses = new Vector(); 
    this.authResponses.addElement(authResponse);
  }
  
  boolean hasAuthenticationChallenge() {
    if (this.authChallenges == null)
      return false; 
    return !this.authChallenges.isEmpty();
  }
  
  Enumeration getAuthenticationChallenges() {
    return this.authChallenges.elements();
  }
  
  boolean hasAuthenticationResponses() {
    if (this.authResponses == null)
      return false; 
    return !this.authResponses.isEmpty();
  }
  
  Enumeration getAuthenticationResponses() {
    return this.authResponses.elements();
  }
  
  static long readObexInt(byte[] data, int off) throws IOException {
    long l = 0L;
    for (int i = 0; i < 4; i++) {
      l <<= 8L;
      l += (data[off + i] & 0xFF);
    } 
    return l;
  }
  
  static void writeObexInt(OutputStream out, int headerID, long data) throws IOException {
    byte[] b = new byte[5];
    b[0] = (byte)headerID;
    b[1] = (byte)(int)(data >>> 24L & 0xFFL);
    b[2] = (byte)(int)(data >>> 16L & 0xFFL);
    b[3] = (byte)(int)(data >>> 8L & 0xFFL);
    b[4] = (byte)(int)(data >>> 0L & 0xFFL);
    out.write(b);
  }
  
  static void writeObexLen(OutputStream out, int headerID, int len) throws IOException {
    byte[] b = new byte[3];
    b[0] = (byte)headerID;
    if (len < 0 || len > 65535)
      throw new IOException("very large data" + len); 
    b[1] = OBEXUtils.hiByte(len);
    b[2] = OBEXUtils.loByte(len);
    out.write(b);
  }
  
  static void writeObexASCII(OutputStream out, int headerID, String value) throws IOException {
    writeObexLen(out, headerID, 3 + value.length() + 1);
    out.write(value.getBytes("iso-8859-1"));
    out.write(0);
  }
  
  static void writeObexUnicode(OutputStream out, int headerID, String value) throws IOException {
    if (value.length() == 0) {
      writeObexLen(out, headerID, 3);
      return;
    } 
    byte[] b = OBEXUtils.getUTF16Bytes(value);
    writeObexLen(out, headerID, 3 + b.length + 2);
    out.write(b);
    out.write(new byte[] { 0, 0 });
  }
  
  static byte[] toByteArray(HeaderSet headers) throws IOException {
    if (headers == null)
      return new byte[0]; 
    ByteArrayOutputStream buf = new ByteArrayOutputStream();
    int[] headerIDArray = headers.getHeaderList();
    for (int i = 0; headerIDArray != null && i < headerIDArray.length; i++) {
      int hi = headerIDArray[i];
      if (hi == 68) {
        Calendar c = (Calendar)headers.getHeader(hi);
        writeObexLen(buf, hi, 19);
        writeTimeISO8601(buf, c);
      } else if (hi == 196) {
        Calendar c = (Calendar)headers.getHeader(hi);
        writeObexInt(buf, hi, c.getTime().getTime() / 1000L);
      } else if (hi == 66) {
        writeObexASCII(buf, hi, (String)headers.getHeader(hi));
      } else {
        byte[] data;
        switch (hi & 0xC0) {
          case 0:
            writeObexUnicode(buf, hi, (String)headers.getHeader(hi));
            break;
          case 64:
            data = (byte[])headers.getHeader(hi);
            writeObexLen(buf, hi, 3 + data.length);
            buf.write(data);
            break;
          case 128:
            buf.write(hi);
            buf.write(((Byte)headers.getHeader(hi)).byteValue());
            break;
          case 192:
            writeObexInt(buf, hi, ((Long)headers.getHeader(hi)).longValue());
            break;
          default:
            throw new IOException("Unsupported encoding " + (hi & 0xC0));
        } 
      } 
    } 
    if (headerIDArray != null && headerIDArray.length != 0)
      DebugLog.debug("written headers", headerIDArray.length); 
    if (((OBEXHeaderSetImpl)headers).hasAuthenticationChallenge())
      for (Enumeration iter = ((OBEXHeaderSetImpl)headers).authChallenges.elements(); iter.hasMoreElements(); ) {
        byte[] authChallenge = iter.nextElement();
        writeObexLen(buf, 77, 3 + authChallenge.length);
        buf.write(authChallenge);
        DebugLog.debug("written AUTH_CHALLENGE");
      }  
    if (((OBEXHeaderSetImpl)headers).hasAuthenticationResponses())
      for (Enumeration iter = ((OBEXHeaderSetImpl)headers).authResponses.elements(); iter.hasMoreElements(); ) {
        byte[] authResponse = iter.nextElement();
        writeObexLen(buf, 78, 3 + authResponse.length);
        buf.write(authResponse);
        DebugLog.debug("written AUTH_RESPONSE");
      }  
    return buf.toByteArray();
  }
  
  static OBEXHeaderSetImpl readHeaders(byte[] buf, int off) throws IOException {
    return readHeaders(new OBEXHeaderSetImpl(-2147483648), buf, off);
  }
  
  static OBEXHeaderSetImpl readHeaders(byte responseCode, byte[] buf, int off) throws IOException {
    return readHeaders(new OBEXHeaderSetImpl(0xFF & responseCode), buf, off);
  }
  
  private static OBEXHeaderSetImpl readHeaders(OBEXHeaderSetImpl hs, byte[] buf, int off) throws IOException {
    int count = 0;
    while (off < buf.length) {
      byte[] data;
      long intValue;
      int hi = 0xFF & buf[off];
      int len = 0;
      switch (hi & 0xC0) {
        case 0:
          len = OBEXUtils.bytesToShort(buf[off + 1], buf[off + 2]);
          if (len == 3) {
            hs.setHeader(hi, "");
            break;
          } 
          data = new byte[len - 5];
          System.arraycopy(buf, off + 3, data, 0, data.length);
          hs.setHeader(hi, OBEXUtils.newStringUTF16(data));
          break;
        case 64:
          len = OBEXUtils.bytesToShort(buf[off + 1], buf[off + 2]);
          data = new byte[len - 3];
          System.arraycopy(buf, off + 3, data, 0, data.length);
          if (hi == 66) {
            if (data[data.length - 1] != 0) {
              hs.setHeader(hi, new String(data, "iso-8859-1"));
              break;
            } 
            hs.setHeader(hi, new String(data, 0, data.length - 1, "iso-8859-1"));
            break;
          } 
          if (hi == 68) {
            hs.setHeader(hi, readTimeISO8601(data));
            break;
          } 
          if (hi == 77) {
            synchronized (hs) {
              if (hs.authChallenges == null)
                hs.authChallenges = new Vector(); 
            } 
            hs.authChallenges.addElement(data);
            DebugLog.debug("received AUTH_CHALLENGE");
            break;
          } 
          if (hi == 78) {
            synchronized (hs) {
              if (hs.authResponses == null)
                hs.authResponses = new Vector(); 
            } 
            hs.authResponses.addElement(data);
            DebugLog.debug("received AUTH_RESPONSE");
            break;
          } 
          hs.setHeader(hi, data);
          break;
        case 128:
          len = 2;
          hs.setHeader(hi, new Byte(buf[off + 1]));
          break;
        case 192:
          len = 5;
          intValue = readObexInt(buf, off + 1);
          if (hi == 196) {
            Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
            cal.setTime(new Date(intValue * 1000L));
            hs.setHeader(hi, cal);
            break;
          } 
          hs.setHeader(hi, new Long(intValue));
          break;
        default:
          throw new IOException("Unsupported encoding " + (hi & 0xC0));
      } 
      off += len;
      count++;
    } 
    if (count != 0)
      DebugLog.debug("read headers", count); 
    return hs;
  }
  
  private static byte[] d4(int i) {
    byte[] b = new byte[4];
    int d = 1000;
    for (int k = 0; k < 4; k++) {
      b[k] = (byte)(i / d + 48);
      i %= d;
      d /= 10;
    } 
    return b;
  }
  
  private static byte[] d2(int i) {
    byte[] b = new byte[2];
    b[0] = (byte)(i / 10 + 48);
    b[1] = (byte)(i % 10 + 48);
    return b;
  }
  
  static void writeTimeISO8601(OutputStream out, Calendar c) throws IOException {
    Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
    cal.setTime(c.getTime());
    out.write(d4(cal.get(1)));
    out.write(d2(cal.get(2) + 1));
    out.write(d2(cal.get(5)));
    out.write(84);
    out.write(d2(cal.get(11)));
    out.write(d2(cal.get(12)));
    out.write(d2(cal.get(13)));
    out.write(90);
  }
  
  static Calendar readTimeISO8601(byte[] data) throws IOException {
    boolean utc = false;
    if (data.length != 16 && data.length != 15)
      throw new IOException("Invalid ISO-8601 date length " + new String(data) + " length " + data.length); 
    if (data[8] != 84)
      throw new IOException("Invalid ISO-8601 date " + new String(data)); 
    if (data.length == 16) {
      if (data[15] != 90)
        throw new IOException("Invalid ISO-8601 date " + new String(data)); 
      utc = true;
    } 
    Calendar cal = utc ? Calendar.getInstance(TimeZone.getTimeZone("UTC")) : Calendar.getInstance();
    cal.set(1, Integer.valueOf(new String(data, 0, 4)).intValue());
    cal.set(2, Integer.valueOf(new String(data, 4, 2)).intValue() - 1);
    cal.set(5, Integer.valueOf(new String(data, 6, 2)).intValue());
    cal.set(11, Integer.valueOf(new String(data, 9, 2)).intValue());
    cal.set(12, Integer.valueOf(new String(data, 11, 2)).intValue());
    cal.set(13, Integer.valueOf(new String(data, 13, 2)).intValue());
    return cal;
  }
}
