/*     */ package com.intel.bluetooth.obex;
/*     */ 
/*     */ import com.intel.bluetooth.DebugLog;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.TimeZone;
/*     */ import java.util.Vector;
/*     */ import javax.obex.HeaderSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OBEXHeaderSetImpl
/*     */   implements HeaderSet
/*     */ {
/*     */   static final int OBEX_HDR_COUNT = 192;
/*     */   static final int OBEX_HDR_NAME = 1;
/*     */   static final int OBEX_HDR_TYPE = 66;
/*     */   static final int OBEX_HDR_LENGTH = 195;
/*     */   static final int OBEX_HDR_TIME = 68;
/*     */   static final int OBEX_HDR_TIME2 = 196;
/*     */   static final int OBEX_HDR_DESCRIPTION = 5;
/*     */   static final int OBEX_HDR_TARGET = 70;
/*     */   static final int OBEX_HDR_HTTP = 71;
/*     */   static final int OBEX_HDR_BODY = 72;
/*     */   static final int OBEX_HDR_BODY_END = 73;
/*     */   static final int OBEX_HDR_WHO = 74;
/*     */   static final int OBEX_HDR_CONNECTION = 203;
/*     */   static final int OBEX_HDR_APP_PARAM = 76;
/*     */   static final int OBEX_HDR_AUTH_CHALLENGE = 77;
/*     */   static final int OBEX_HDR_AUTH_RESPONSE = 78;
/*     */   static final int OBEX_HDR_OBJECTCLASS = 79;
/*     */   static final int OBEX_HDR_CREATOR = 207;
/*     */   static final int OBEX_HDR_WANUUID = 80;
/*     */   static final int OBEX_HDR_SESSIONPARAM = 82;
/*     */   static final int OBEX_HDR_SESSIONSEQ = 147;
/*     */   static final int OBEX_HDR_USER = 48;
/*     */   static final int OBEX_HDR_HI_MASK = 192;
/*     */   static final int OBEX_HDR_ID_MASK = 63;
/*     */   static final int OBEX_STRING = 0;
/*     */   static final int OBEX_BYTE_STREAM = 64;
/*     */   static final int OBEX_BYTE = 128;
/*     */   static final int OBEX_INT = 192;
/*     */   private static final int OBEX_MAX_FIELD_LEN = 255;
/*     */   private int responseCode;
/*     */   private Hashtable headerValues;
/*     */   private Vector authResponses;
/*     */   private Vector authChallenges;
/*     */   private static final int NO_RESPONSE_CODE = -2147483648;
/*     */   
/*     */   OBEXHeaderSetImpl() {
/* 143 */     this(-2147483648);
/*     */   }
/*     */   
/*     */   private OBEXHeaderSetImpl(int responseCode) {
/* 147 */     this.headerValues = new Hashtable();
/* 148 */     this.responseCode = responseCode;
/* 149 */     this.authResponses = null;
/* 150 */     this.authChallenges = null;
/*     */   }
/*     */   
/*     */   static void validateCreatedHeaderSet(HeaderSet headers) {
/* 154 */     if (headers == null) {
/*     */       return;
/*     */     }
/* 157 */     if (!(headers instanceof OBEXHeaderSetImpl)) {
/* 158 */       throw new IllegalArgumentException("Illegal HeaderSet type");
/*     */     }
/* 160 */     if (((OBEXHeaderSetImpl)headers).responseCode != Integer.MIN_VALUE) {
/* 161 */       throw new IllegalArgumentException("Illegal HeaderSet");
/*     */     }
/*     */   }
/*     */   
/*     */   private void validateHeaderID(int headerID) throws IllegalArgumentException {
/* 166 */     if (headerID < 0 || headerID > 255) {
/* 167 */       throw new IllegalArgumentException("Expected header ID in range 0 to 255");
/*     */     }
/* 169 */     int identifier = headerID & 0x3F;
/* 170 */     if (identifier >= 16 && identifier < 47) {
/* 171 */       throw new IllegalArgumentException("Reserved header ID");
/*     */     }
/*     */   }
/*     */   
/*     */   public void setHeader(int headerID, Object headerValue) {
/* 176 */     validateHeaderID(headerID);
/* 177 */     if (headerValue == null) {
/* 178 */       this.headerValues.remove(new Integer(headerID));
/*     */     } else {
/*     */       
/* 181 */       if (headerID == 68 || headerID == 196) {
/* 182 */         if (!(headerValue instanceof Calendar)) {
/* 183 */           throw new IllegalArgumentException("Expected java.util.Calendar");
/*     */         }
/* 185 */       } else if (headerID == 66) {
/* 186 */         if (!(headerValue instanceof String))
/* 187 */           throw new IllegalArgumentException("Expected java.lang.String"); 
/*     */       } else {
/*     */         long v;
/* 190 */         switch (headerID & 0xC0) {
/*     */           case 0:
/* 192 */             if (!(headerValue instanceof String)) {
/* 193 */               throw new IllegalArgumentException("Expected java.lang.String");
/*     */             }
/*     */             break;
/*     */           case 64:
/* 197 */             if (!(headerValue instanceof byte[])) {
/* 198 */               throw new IllegalArgumentException("Expected byte[]");
/*     */             }
/*     */             break;
/*     */           case 128:
/* 202 */             if (!(headerValue instanceof Byte)) {
/* 203 */               throw new IllegalArgumentException("Expected java.lang.Byte");
/*     */             }
/*     */             break;
/*     */           case 192:
/* 207 */             if (!(headerValue instanceof Long)) {
/* 208 */               throw new IllegalArgumentException("Expected java.lang.Long");
/*     */             }
/* 210 */             v = ((Long)headerValue).longValue();
/* 211 */             if (v < 0L || v > 4294967295L) {
/* 212 */               throw new IllegalArgumentException("Expected long in range 0 to 2^32-1");
/*     */             }
/*     */             break;
/*     */           default:
/* 216 */             throw new IllegalArgumentException("Unsupported encoding " + (headerID & 0xC0));
/*     */         } 
/*     */       } 
/* 219 */       this.headerValues.put(new Integer(headerID), headerValue);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object getHeader(int headerID) throws IOException {
/* 224 */     validateHeaderID(headerID);
/* 225 */     return this.headerValues.get(new Integer(headerID));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getHeaderList() throws IOException {
/* 234 */     if (this.headerValues.size() == 0)
/*     */     {
/* 236 */       return null;
/*     */     }
/* 238 */     int[] headerIDArray = new int[this.headerValues.size()];
/* 239 */     int i = 0;
/* 240 */     for (Enumeration e = this.headerValues.keys(); e.hasMoreElements();) {
/* 241 */       headerIDArray[i++] = ((Integer)e.nextElement()).intValue();
/*     */     }
/* 243 */     return headerIDArray;
/*     */   }
/*     */   
/*     */   public int getResponseCode() throws IOException {
/* 247 */     if (this.responseCode == Integer.MIN_VALUE) {
/* 248 */       throw new IOException();
/*     */     }
/* 250 */     return this.responseCode;
/*     */   }
/*     */   
/*     */   boolean hasIncommingData() {
/* 254 */     return (this.headerValues.contains(new Integer(72)) || this.headerValues.contains(new Integer(73)));
/*     */   }
/*     */ 
/*     */   
/*     */   static OBEXHeaderSetImpl cloneHeaders(HeaderSet headers) throws IOException {
/* 259 */     if (headers == null) {
/* 260 */       return null;
/*     */     }
/* 262 */     if (!(headers instanceof OBEXHeaderSetImpl)) {
/* 263 */       throw new IllegalArgumentException("Illegal HeaderSet type");
/*     */     }
/* 265 */     OBEXHeaderSetImpl hs = new OBEXHeaderSetImpl(((OBEXHeaderSetImpl)headers).responseCode);
/*     */     
/* 267 */     int[] headerIDArray = headers.getHeaderList();
/* 268 */     for (int i = 0; headerIDArray != null && i < headerIDArray.length; i++) {
/* 269 */       int headerID = headerIDArray[i];
/*     */       
/* 271 */       if (headerID != 72 && headerID != 73)
/*     */       {
/*     */         
/* 274 */         hs.setHeader(headerID, headers.getHeader(headerID)); } 
/*     */     } 
/* 276 */     return hs;
/*     */   }
/*     */   
/*     */   static HeaderSet appendHeaders(HeaderSet dst, HeaderSet src) throws IOException {
/* 280 */     int[] headerIDArray = src.getHeaderList();
/* 281 */     for (int i = 0; headerIDArray != null && i < headerIDArray.length; i++) {
/* 282 */       int headerID = headerIDArray[i];
/* 283 */       if (headerID != 72 && headerID != 73)
/*     */       {
/*     */         
/* 286 */         dst.setHeader(headerID, src.getHeader(headerID)); } 
/*     */     } 
/* 288 */     return dst;
/*     */   }
/*     */   
/*     */   public synchronized void createAuthenticationChallenge(String realm, boolean isUserIdRequired, boolean isFullAccess) {
/* 292 */     if (this.authChallenges == null) {
/* 293 */       this.authChallenges = new Vector();
/*     */     }
/* 295 */     this.authChallenges.addElement(OBEXAuthentication.createChallenge(realm, isUserIdRequired, isFullAccess));
/*     */   }
/*     */   
/*     */   synchronized void addAuthenticationResponse(byte[] authResponse) {
/* 299 */     if (this.authResponses == null) {
/* 300 */       this.authResponses = new Vector();
/*     */     }
/* 302 */     this.authResponses.addElement(authResponse);
/*     */   }
/*     */   
/*     */   boolean hasAuthenticationChallenge() {
/* 306 */     if (this.authChallenges == null) {
/* 307 */       return false;
/*     */     }
/* 309 */     return !this.authChallenges.isEmpty();
/*     */   }
/*     */   
/*     */   Enumeration getAuthenticationChallenges() {
/* 313 */     return this.authChallenges.elements();
/*     */   }
/*     */   
/*     */   boolean hasAuthenticationResponses() {
/* 317 */     if (this.authResponses == null) {
/* 318 */       return false;
/*     */     }
/* 320 */     return !this.authResponses.isEmpty();
/*     */   }
/*     */   
/*     */   Enumeration getAuthenticationResponses() {
/* 324 */     return this.authResponses.elements();
/*     */   }
/*     */   
/*     */   static long readObexInt(byte[] data, int off) throws IOException {
/* 328 */     long l = 0L;
/* 329 */     for (int i = 0; i < 4; i++) {
/* 330 */       l <<= 8L;
/* 331 */       l += (data[off + i] & 0xFF);
/*     */     } 
/* 333 */     return l;
/*     */   }
/*     */   
/*     */   static void writeObexInt(OutputStream out, int headerID, long data) throws IOException {
/* 337 */     byte[] b = new byte[5];
/* 338 */     b[0] = (byte)headerID;
/* 339 */     b[1] = (byte)(int)(data >>> 24L & 0xFFL);
/* 340 */     b[2] = (byte)(int)(data >>> 16L & 0xFFL);
/* 341 */     b[3] = (byte)(int)(data >>> 8L & 0xFFL);
/* 342 */     b[4] = (byte)(int)(data >>> 0L & 0xFFL);
/* 343 */     out.write(b);
/*     */   }
/*     */   
/*     */   static void writeObexLen(OutputStream out, int headerID, int len) throws IOException {
/* 347 */     byte[] b = new byte[3];
/* 348 */     b[0] = (byte)headerID;
/* 349 */     if (len < 0 || len > 65535) {
/* 350 */       throw new IOException("very large data" + len);
/*     */     }
/* 352 */     b[1] = OBEXUtils.hiByte(len);
/* 353 */     b[2] = OBEXUtils.loByte(len);
/* 354 */     out.write(b);
/*     */   }
/*     */   
/*     */   static void writeObexASCII(OutputStream out, int headerID, String value) throws IOException {
/* 358 */     writeObexLen(out, headerID, 3 + value.length() + 1);
/* 359 */     out.write(value.getBytes("iso-8859-1"));
/* 360 */     out.write(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void writeObexUnicode(OutputStream out, int headerID, String value) throws IOException {
/* 370 */     if (value.length() == 0) {
/* 371 */       writeObexLen(out, headerID, 3);
/*     */       return;
/*     */     } 
/* 374 */     byte[] b = OBEXUtils.getUTF16Bytes(value);
/* 375 */     writeObexLen(out, headerID, 3 + b.length + 2);
/* 376 */     out.write(b);
/* 377 */     out.write(new byte[] { 0, 0 });
/*     */   }
/*     */   
/*     */   static byte[] toByteArray(HeaderSet headers) throws IOException {
/* 381 */     if (headers == null) {
/* 382 */       return new byte[0];
/*     */     }
/* 384 */     ByteArrayOutputStream buf = new ByteArrayOutputStream();
/* 385 */     int[] headerIDArray = headers.getHeaderList();
/* 386 */     for (int i = 0; headerIDArray != null && i < headerIDArray.length; i++) {
/* 387 */       int hi = headerIDArray[i];
/* 388 */       if (hi == 68) {
/* 389 */         Calendar c = (Calendar)headers.getHeader(hi);
/* 390 */         writeObexLen(buf, hi, 19);
/* 391 */         writeTimeISO8601(buf, c);
/* 392 */       } else if (hi == 196) {
/* 393 */         Calendar c = (Calendar)headers.getHeader(hi);
/* 394 */         writeObexInt(buf, hi, c.getTime().getTime() / 1000L);
/* 395 */       } else if (hi == 66) {
/*     */         
/* 397 */         writeObexASCII(buf, hi, (String)headers.getHeader(hi));
/*     */       } else {
/* 399 */         byte[] data; switch (hi & 0xC0) {
/*     */           case 0:
/* 401 */             writeObexUnicode(buf, hi, (String)headers.getHeader(hi));
/*     */             break;
/*     */           case 64:
/* 404 */             data = (byte[])headers.getHeader(hi);
/* 405 */             writeObexLen(buf, hi, 3 + data.length);
/* 406 */             buf.write(data);
/*     */             break;
/*     */           case 128:
/* 409 */             buf.write(hi);
/* 410 */             buf.write(((Byte)headers.getHeader(hi)).byteValue());
/*     */             break;
/*     */           case 192:
/* 413 */             writeObexInt(buf, hi, ((Long)headers.getHeader(hi)).longValue());
/*     */             break;
/*     */           default:
/* 416 */             throw new IOException("Unsupported encoding " + (hi & 0xC0));
/*     */         } 
/*     */       } 
/*     */     } 
/* 420 */     if (headerIDArray != null && headerIDArray.length != 0) {
/* 421 */       DebugLog.debug("written headers", headerIDArray.length);
/*     */     }
/* 423 */     if (((OBEXHeaderSetImpl)headers).hasAuthenticationChallenge()) {
/* 424 */       for (Enumeration iter = ((OBEXHeaderSetImpl)headers).authChallenges.elements(); iter.hasMoreElements(); ) {
/* 425 */         byte[] authChallenge = iter.nextElement();
/* 426 */         writeObexLen(buf, 77, 3 + authChallenge.length);
/* 427 */         buf.write(authChallenge);
/* 428 */         DebugLog.debug("written AUTH_CHALLENGE");
/*     */       } 
/*     */     }
/* 431 */     if (((OBEXHeaderSetImpl)headers).hasAuthenticationResponses()) {
/* 432 */       for (Enumeration iter = ((OBEXHeaderSetImpl)headers).authResponses.elements(); iter.hasMoreElements(); ) {
/* 433 */         byte[] authResponse = iter.nextElement();
/* 434 */         writeObexLen(buf, 78, 3 + authResponse.length);
/* 435 */         buf.write(authResponse);
/* 436 */         DebugLog.debug("written AUTH_RESPONSE");
/*     */       } 
/*     */     }
/* 439 */     return buf.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static OBEXHeaderSetImpl readHeaders(byte[] buf, int off) throws IOException {
/* 446 */     return readHeaders(new OBEXHeaderSetImpl(-2147483648), buf, off);
/*     */   }
/*     */   
/*     */   static OBEXHeaderSetImpl readHeaders(byte responseCode, byte[] buf, int off) throws IOException {
/* 450 */     return readHeaders(new OBEXHeaderSetImpl(0xFF & responseCode), buf, off);
/*     */   }
/*     */   
/*     */   private static OBEXHeaderSetImpl readHeaders(OBEXHeaderSetImpl hs, byte[] buf, int off) throws IOException {
/* 454 */     int count = 0;
/* 455 */     while (off < buf.length) {
/* 456 */       byte[] data; long intValue; int hi = 0xFF & buf[off];
/* 457 */       int len = 0;
/* 458 */       switch (hi & 0xC0) {
/*     */         case 0:
/* 460 */           len = OBEXUtils.bytesToShort(buf[off + 1], buf[off + 2]);
/* 461 */           if (len == 3) {
/* 462 */             hs.setHeader(hi, ""); break;
/*     */           } 
/* 464 */           data = new byte[len - 5];
/* 465 */           System.arraycopy(buf, off + 3, data, 0, data.length);
/* 466 */           hs.setHeader(hi, OBEXUtils.newStringUTF16(data));
/*     */           break;
/*     */         
/*     */         case 64:
/* 470 */           len = OBEXUtils.bytesToShort(buf[off + 1], buf[off + 2]);
/* 471 */           data = new byte[len - 3];
/* 472 */           System.arraycopy(buf, off + 3, data, 0, data.length);
/* 473 */           if (hi == 66) {
/* 474 */             if (data[data.length - 1] != 0) {
/* 475 */               hs.setHeader(hi, new String(data, "iso-8859-1")); break;
/*     */             } 
/* 477 */             hs.setHeader(hi, new String(data, 0, data.length - 1, "iso-8859-1")); break;
/*     */           } 
/* 479 */           if (hi == 68) {
/* 480 */             hs.setHeader(hi, readTimeISO8601(data)); break;
/* 481 */           }  if (hi == 77) {
/* 482 */             synchronized (hs) {
/* 483 */               if (hs.authChallenges == null) {
/* 484 */                 hs.authChallenges = new Vector();
/*     */               }
/*     */             } 
/* 487 */             hs.authChallenges.addElement(data);
/* 488 */             DebugLog.debug("received AUTH_CHALLENGE"); break;
/* 489 */           }  if (hi == 78) {
/* 490 */             synchronized (hs) {
/* 491 */               if (hs.authResponses == null) {
/* 492 */                 hs.authResponses = new Vector();
/*     */               }
/*     */             } 
/* 495 */             hs.authResponses.addElement(data);
/* 496 */             DebugLog.debug("received AUTH_RESPONSE"); break;
/*     */           } 
/* 498 */           hs.setHeader(hi, data);
/*     */           break;
/*     */         
/*     */         case 128:
/* 502 */           len = 2;
/* 503 */           hs.setHeader(hi, new Byte(buf[off + 1]));
/*     */           break;
/*     */         case 192:
/* 506 */           len = 5;
/* 507 */           intValue = readObexInt(buf, off + 1);
/* 508 */           if (hi == 196) {
/* 509 */             Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
/* 510 */             cal.setTime(new Date(intValue * 1000L));
/* 511 */             hs.setHeader(hi, cal); break;
/*     */           } 
/* 513 */           hs.setHeader(hi, new Long(intValue));
/*     */           break;
/*     */         
/*     */         default:
/* 517 */           throw new IOException("Unsupported encoding " + (hi & 0xC0));
/*     */       } 
/* 519 */       off += len;
/* 520 */       count++;
/*     */     } 
/* 522 */     if (count != 0) {
/* 523 */       DebugLog.debug("read headers", count);
/*     */     }
/* 525 */     return hs;
/*     */   }
/*     */   
/*     */   private static byte[] d4(int i) {
/* 529 */     byte[] b = new byte[4];
/* 530 */     int d = 1000;
/* 531 */     for (int k = 0; k < 4; k++) {
/* 532 */       b[k] = (byte)(i / d + 48);
/* 533 */       i %= d;
/* 534 */       d /= 10;
/*     */     } 
/* 536 */     return b;
/*     */   }
/*     */   
/*     */   private static byte[] d2(int i) {
/* 540 */     byte[] b = new byte[2];
/* 541 */     b[0] = (byte)(i / 10 + 48);
/* 542 */     b[1] = (byte)(i % 10 + 48);
/* 543 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void writeTimeISO8601(OutputStream out, Calendar c) throws IOException {
/* 550 */     Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
/* 551 */     cal.setTime(c.getTime());
/* 552 */     out.write(d4(cal.get(1)));
/* 553 */     out.write(d2(cal.get(2) + 1));
/* 554 */     out.write(d2(cal.get(5)));
/* 555 */     out.write(84);
/* 556 */     out.write(d2(cal.get(11)));
/* 557 */     out.write(d2(cal.get(12)));
/* 558 */     out.write(d2(cal.get(13)));
/* 559 */     out.write(90);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Calendar readTimeISO8601(byte[] data) throws IOException {
/* 566 */     boolean utc = false;
/* 567 */     if (data.length != 16 && data.length != 15)
/* 568 */       throw new IOException("Invalid ISO-8601 date length " + new String(data) + " length " + data.length); 
/* 569 */     if (data[8] != 84)
/* 570 */       throw new IOException("Invalid ISO-8601 date " + new String(data)); 
/* 571 */     if (data.length == 16) {
/* 572 */       if (data[15] != 90) {
/* 573 */         throw new IOException("Invalid ISO-8601 date " + new String(data));
/*     */       }
/* 575 */       utc = true;
/*     */     } 
/*     */     
/* 578 */     Calendar cal = utc ? Calendar.getInstance(TimeZone.getTimeZone("UTC")) : Calendar.getInstance();
/* 579 */     cal.set(1, Integer.valueOf(new String(data, 0, 4)).intValue());
/* 580 */     cal.set(2, Integer.valueOf(new String(data, 4, 2)).intValue() - 1);
/* 581 */     cal.set(5, Integer.valueOf(new String(data, 6, 2)).intValue());
/* 582 */     cal.set(11, Integer.valueOf(new String(data, 9, 2)).intValue());
/* 583 */     cal.set(12, Integer.valueOf(new String(data, 11, 2)).intValue());
/* 584 */     cal.set(13, Integer.valueOf(new String(data, 13, 2)).intValue());
/* 585 */     return cal;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXHeaderSetImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */