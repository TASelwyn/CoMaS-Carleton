package com.intel.bluetooth.obex;

import com.intel.bluetooth.DebugLog;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

class OBEXServerOperationPut extends OBEXServerOperation implements OBEXOperationReceive, OBEXOperationDelivery {
  protected OBEXServerOperationPut(OBEXServerSessionImpl session, OBEXHeaderSetImpl receivedHeaders, boolean finalPacket) throws IOException {
    super(session, receivedHeaders);
    this.inputStream = new OBEXOperationInputStream(this);
    processIncommingData(receivedHeaders, finalPacket);
  }
  
  public InputStream openInputStream() throws IOException {
    if (this.isClosed)
      throw new IOException("operation closed"); 
    if (this.inputStreamOpened)
      throw new IOException("input stream already open"); 
    DebugLog.debug("openInputStream");
    this.inputStreamOpened = true;
    return this.inputStream;
  }
  
  public OutputStream openOutputStream() throws IOException {
    if (this.isClosed)
      throw new IOException("operation closed"); 
    if (this.outputStream != null)
      throw new IOException("output stream already open"); 
    this.outputStream = new OBEXOperationOutputStream(this.session.mtu, this);
    return this.outputStream;
  }
  
  public void close() throws IOException {
    DebugLog.debug("server close put operation");
    if (this.inputStream != null) {
      this.inputStream.close();
      this.inputStream = null;
    } 
    if (this.outputStream != null) {
      this.outputStream.close();
      this.outputStream = null;
    } 
    super.close();
  }
  
  protected boolean readRequestPacket() throws IOException {
    OBEXHeaderSetImpl requestHeaders;
    byte[] b = this.session.readPacket();
    int opcode = b[0] & 0xFF;
    boolean finalPacket = ((opcode & 0x80) != 0);
    if (finalPacket) {
      DebugLog.debug("server operation got final packet");
      this.finalPacketReceived = true;
    } 
    switch (opcode) {
      case 2:
      case 130:
        requestHeaders = OBEXHeaderSetImpl.readHeaders(b[0], b, 3);
        if (!this.session.handleAuthenticationResponse(requestHeaders)) {
          this.errorReceived = true;
          this.session.writePacket(193, null);
        } else {
          OBEXHeaderSetImpl.appendHeaders(this.receivedHeaders, requestHeaders);
          processIncommingData(requestHeaders, finalPacket);
        } 
        return finalPacket;
      case 255:
        processAbort();
        return finalPacket;
    } 
    this.errorReceived = true;
    DebugLog.debug0x("server operation invalid request", OBEXUtils.toStringObexResponseCodes(opcode), opcode);
    this.session.writePacket(192, null);
    return finalPacket;
  }
  
  public void receiveData(OBEXOperationInputStream is) throws IOException {
    if (this.finalPacketReceived || this.errorReceived) {
      is.appendData(null, true);
      return;
    } 
    DebugLog.debug("server operation reply continue");
    this.session.writePacket(144, this.sendHeaders);
    this.sendHeaders = null;
    readRequestPacket();
  }
  
  public void deliverPacket(boolean finalPacket, byte[] buffer) throws IOException {
    if (this.session.requestSent) {
      readRequestPacket();
      if (this.session.requestSent)
        throw new IOException("Client not requesting data"); 
    } 
    OBEXHeaderSetImpl dataHeaders = OBEXSessionBase.createOBEXHeaderSetImpl();
    int opcode = 144;
    int dataHeaderID = 72;
    if (finalPacket)
      dataHeaderID = 73; 
    dataHeaders.setHeader(dataHeaderID, buffer);
    if (this.sendHeaders != null) {
      OBEXHeaderSetImpl.appendHeaders(dataHeaders, this.sendHeaders);
      this.sendHeaders = null;
    } 
    this.session.writePacket(opcode, dataHeaders);
    readRequestPacket();
  }
  
  private void processAbort() throws IOException {
    this.isAborted = true;
    this.session.writePacket(160, null);
    close();
    throw new IOException("Operation aborted by client");
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXServerOperationPut.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */