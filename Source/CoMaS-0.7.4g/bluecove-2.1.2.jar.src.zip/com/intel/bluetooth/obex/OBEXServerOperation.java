/*     */ package com.intel.bluetooth.obex;
/*     */ 
/*     */ import com.intel.bluetooth.DebugLog;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.obex.HeaderSet;
/*     */ import javax.obex.Operation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class OBEXServerOperation
/*     */   implements Operation, OBEXOperation
/*     */ {
/*     */   protected OBEXServerSessionImpl session;
/*     */   protected HeaderSet receivedHeaders;
/*     */   protected OBEXHeaderSetImpl sendHeaders;
/*     */   protected boolean isClosed = false;
/*     */   protected boolean isAborted = false;
/*     */   protected boolean finalPacketReceived = false;
/*     */   protected boolean requestEnded = false;
/*     */   protected boolean errorReceived = false;
/*     */   protected boolean incommingDataReceived = false;
/*     */   protected OBEXOperationOutputStream outputStream;
/*     */   protected boolean outputStreamOpened = false;
/*     */   protected OBEXOperationInputStream inputStream;
/*     */   protected boolean inputStreamOpened = false;
/*     */   
/*     */   protected OBEXServerOperation(OBEXServerSessionImpl session, OBEXHeaderSetImpl receivedHeaders) throws IOException {
/*  66 */     this.session = session;
/*  67 */     this.receivedHeaders = receivedHeaders;
/*  68 */     if (receivedHeaders.hasAuthenticationChallenge()) {
/*  69 */       this.sendHeaders = OBEXSessionBase.createOBEXHeaderSetImpl();
/*  70 */       this.session.handleAuthenticationChallenge(receivedHeaders, this.sendHeaders);
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean exchangeRequestPhasePackets() throws IOException {
/*  75 */     this.session.writePacket(144, null);
/*  76 */     return readRequestPacket();
/*     */   }
/*     */   
/*     */   protected abstract boolean readRequestPacket() throws IOException;
/*     */   
/*     */   void writeResponse(int responseCode) throws IOException {
/*  82 */     DebugLog.debug0x("server operation reply final", responseCode);
/*  83 */     this.session.writePacket(responseCode, this.sendHeaders);
/*  84 */     this.sendHeaders = null;
/*  85 */     if (responseCode == 160) {
/*  86 */       while (!this.finalPacketReceived && !this.session.isClosed()) {
/*  87 */         DebugLog.debug("server waits to receive final packet");
/*  88 */         readRequestPacket();
/*  89 */         if (!this.errorReceived) {
/*  90 */           this.session.writePacket(responseCode, null);
/*     */         }
/*     */       } 
/*     */     } else {
/*  94 */       DebugLog.debug("sent final reply");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processIncommingData(HeaderSet dataHeaders, boolean eof) throws IOException {
/* 100 */     if (this.inputStream == null) {
/*     */       return;
/*     */     }
/* 103 */     byte[] data = (byte[])dataHeaders.getHeader(72);
/* 104 */     if (data == null) {
/* 105 */       data = (byte[])dataHeaders.getHeader(73);
/* 106 */       if (data != null) {
/* 107 */         eof = true;
/*     */       }
/*     */     } 
/* 110 */     if (data != null) {
/* 111 */       this.incommingDataReceived = true;
/* 112 */       DebugLog.debug("server received Data eof: " + eof + " len:", data.length);
/* 113 */       this.inputStream.appendData(data, eof);
/* 114 */     } else if (eof) {
/* 115 */       this.inputStream.appendData(null, eof);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void abort() throws IOException {
/* 125 */     throw new IOException("Can't abort server operation");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HeaderSet getReceivedHeaders() throws IOException {
/* 134 */     return OBEXHeaderSetImpl.cloneHeaders(this.receivedHeaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getResponseCode() throws IOException {
/* 143 */     throw new IOException("Operation object was created by an OBEX server");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendHeaders(HeaderSet headers) throws IOException {
/* 152 */     if (headers == null) {
/* 153 */       throw new NullPointerException("headers are null");
/*     */     }
/* 155 */     OBEXHeaderSetImpl.validateCreatedHeaderSet(headers);
/* 156 */     if (this.isClosed) {
/* 157 */       throw new IOException("operation closed");
/*     */     }
/* 159 */     if (this.sendHeaders != null) {
/* 160 */       OBEXHeaderSetImpl.appendHeaders(this.sendHeaders, headers);
/*     */     } else {
/* 162 */       this.sendHeaders = (OBEXHeaderSetImpl)headers;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEncoding() {
/* 173 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLength() {
/*     */     Long len;
/*     */     try {
/* 185 */       len = (Long)this.receivedHeaders.getHeader(195);
/* 186 */     } catch (IOException e) {
/* 187 */       return -1L;
/*     */     } 
/* 189 */     if (len == null) {
/* 190 */       return -1L;
/*     */     }
/* 192 */     return len.longValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/*     */     try {
/* 203 */       return (String)this.receivedHeaders.getHeader(66);
/* 204 */     } catch (IOException e) {
/* 205 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataInputStream openDataInputStream() throws IOException {
/* 215 */     return new DataInputStream(super.openInputStream());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataOutputStream openDataOutputStream() throws IOException {
/* 224 */     return new DataOutputStream(super.openOutputStream());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 233 */     this.isClosed = true;
/*     */   }
/*     */   
/*     */   public boolean isClosed() {
/* 237 */     return this.isClosed;
/*     */   }
/*     */   
/*     */   public boolean isIncommingDataReceived() {
/* 241 */     return this.incommingDataReceived;
/*     */   }
/*     */   
/*     */   public boolean isErrorReceived() {
/* 245 */     return this.errorReceived;
/*     */   }
/*     */   
/*     */   public abstract InputStream openInputStream() throws IOException;
/*     */   
/*     */   public abstract OutputStream openOutputStream() throws IOException;
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXServerOperation.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */