package com.intel.bluetooth.obex;

public class OBEXConnectionParams {
  public static final int DEFAULT_TIMEOUT = 120000;
  
  public static final int OBEX_DEFAULT_MTU = 1024;
  
  public boolean timeouts;
  
  public int timeout = 120000;
  
  public int mtu = 1024;
}
