package com.intel.bluetooth.obex;

public class OBEXConnectionParams {
  public static final int DEFAULT_TIMEOUT = 120000;
  
  public static final int OBEX_DEFAULT_MTU = 1024;
  
  public boolean timeouts;
  
  public int timeout = 120000;
  
  public int mtu = 1024;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXConnectionParams.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */