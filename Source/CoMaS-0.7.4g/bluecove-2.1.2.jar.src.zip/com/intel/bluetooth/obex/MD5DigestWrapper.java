package com.intel.bluetooth.obex;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

class MD5DigestWrapper {
  private MessageDigest md5impl;
  
  MD5DigestWrapper() {
    try {
      this.md5impl = MessageDigest.getInstance("MD5");
    } catch (NoSuchAlgorithmException e) {
      throw new RuntimeException(e.getMessage());
    } 
  }
  
  void update(byte[] input) {
    this.md5impl.update(input);
  }
  
  byte[] digest() {
    return this.md5impl.digest();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\MD5DigestWrapper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */