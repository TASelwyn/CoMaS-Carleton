package com.intel.bluetooth.obex;

import java.io.IOException;
import java.io.InputStream;

class UnsupportedInputStream extends InputStream {
  public int read() throws IOException {
    throw new IOException("Input not supported in current operation");
  }
}
