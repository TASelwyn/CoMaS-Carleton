package com.intel.bluetooth.obex;

import com.intel.bluetooth.DebugLog;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.obex.HeaderSet;

class OBEXServerOperationGet extends OBEXServerOperation implements OBEXOperationDelivery, OBEXOperationReceive {
  protected OBEXServerOperationGet(OBEXServerSessionImpl session, OBEXHeaderSetImpl receivedHeaders, boolean finalPacket) throws IOException {
    super(session, receivedHeaders);
    if (finalPacket) {
      this.requestEnded = true;
      this.finalPacketReceived = true;
    } 
    this.inputStream = new OBEXOperationInputStream(this);
    processIncommingData(receivedHeaders, finalPacket);
  }
  
  public InputStream openInputStream() throws IOException {
    if (this.isClosed)
      throw new IOException("operation closed"); 
    if (this.inputStreamOpened)
      throw new IOException("input stream already open"); 
    this.inputStreamOpened = true;
    return this.inputStream;
  }
  
  public OutputStream openOutputStream() throws IOException {
    if (this.isClosed)
      throw new IOException("operation closed"); 
    if (this.outputStream != null)
      throw new IOException("output stream already open"); 
    this.requestEnded = true;
    this.outputStream = new OBEXOperationOutputStream(this.session.mtu, this);
    this.session.writePacket(144, this.sendHeaders);
    this.sendHeaders = null;
    return this.outputStream;
  }
  
  public void close() throws IOException {
    if (this.outputStream != null) {
      this.outputStream.close();
      this.outputStream = null;
    } 
    this.inputStream.close();
    super.close();
  }
  
  protected boolean readRequestPacket() throws IOException {
    HeaderSet requestHeaders;
    byte[] b = this.session.readPacket();
    int opcode = b[0] & 0xFF;
    boolean finalPacket = ((opcode & 0x80) != 0);
    if (finalPacket) {
      DebugLog.debug("server operation got final packet");
      this.finalPacketReceived = true;
    } 
    switch (opcode) {
      case 3:
      case 131:
        if (finalPacket)
          this.requestEnded = true; 
        requestHeaders = OBEXHeaderSetImpl.readHeaders(b[0], b, 3);
        OBEXHeaderSetImpl.appendHeaders(this.receivedHeaders, requestHeaders);
        processIncommingData(requestHeaders, finalPacket);
        return finalPacket;
      case 255:
        processAbort();
        return finalPacket;
    } 
    this.errorReceived = true;
    DebugLog.debug0x("server operation invalid request", OBEXUtils.toStringObexResponseCodes(opcode), opcode);
    this.session.writePacket(192, null);
    return finalPacket;
  }
  
  public void receiveData(OBEXOperationInputStream is) throws IOException {
    if (this.requestEnded || this.errorReceived) {
      this.inputStream.appendData(null, true);
      return;
    } 
    DebugLog.debug("server operation reply continue");
    this.session.writePacket(144, this.sendHeaders);
    this.sendHeaders = null;
    readRequestPacket();
  }
  
  public void deliverPacket(boolean finalPacket, byte[] buffer) throws IOException {
    if (this.session.requestSent) {
      readRequestPacket();
      if (this.session.requestSent)
        throw new IOException("Client not requesting data"); 
    } 
    OBEXHeaderSetImpl dataHeaders = OBEXSessionBase.createOBEXHeaderSetImpl();
    int opcode = 144;
    int dataHeaderID = 72;
    if (finalPacket)
      dataHeaderID = 73; 
    dataHeaders.setHeader(dataHeaderID, buffer);
    if (this.sendHeaders != null) {
      OBEXHeaderSetImpl.appendHeaders(dataHeaders, this.sendHeaders);
      this.sendHeaders = null;
    } 
    this.session.writePacket(opcode, dataHeaders);
    readRequestPacket();
  }
  
  private void processAbort() throws IOException {
    this.finalPacketReceived = true;
    this.requestEnded = true;
    this.isAborted = true;
    this.session.writePacket(160, null);
    throw new IOException("Operation aborted");
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXServerOperationGet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */