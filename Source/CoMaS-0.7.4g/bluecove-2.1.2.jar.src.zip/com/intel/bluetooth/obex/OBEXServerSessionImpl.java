/*     */ package com.intel.bluetooth.obex;
/*     */ 
/*     */ import com.intel.bluetooth.BlueCoveImpl;
/*     */ import com.intel.bluetooth.BluetoothServerConnection;
/*     */ import com.intel.bluetooth.DebugLog;
/*     */ import com.intel.bluetooth.UtilsJavaSE;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import javax.microedition.io.StreamConnection;
/*     */ import javax.obex.Authenticator;
/*     */ import javax.obex.ServerRequestHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OBEXServerSessionImpl
/*     */   extends OBEXSessionBase
/*     */   implements Runnable, BluetoothServerConnection
/*     */ {
/*     */   private ServerRequestHandler handler;
/*     */   private OBEXServerOperation operation;
/*     */   private boolean closeRequested = false;
/*     */   private volatile boolean delayClose = false;
/*  50 */   private Object canCloseEvent = new Object();
/*     */   
/*     */   private Object stackID;
/*     */   
/*     */   private Thread handlerThread;
/*     */   
/*     */   private static int threadNumber;
/*     */   
/*     */   private static synchronized int nextThreadNum() {
/*  59 */     return threadNumber++;
/*     */   }
/*     */   
/*  62 */   static int errorCount = 0;
/*     */ 
/*     */   
/*     */   OBEXServerSessionImpl(StreamConnection connection, ServerRequestHandler handler, Authenticator authenticator, OBEXConnectionParams obexConnectionParams) throws IOException {
/*  66 */     super(connection, obexConnectionParams);
/*  67 */     this.requestSent = true;
/*  68 */     this.handler = handler;
/*  69 */     this.authenticator = authenticator;
/*  70 */     this.stackID = BlueCoveImpl.getCurrentThreadBluetoothStackID();
/*  71 */     this.handlerThread = new Thread(this, "OBEXServerSessionThread-" + nextThreadNum());
/*  72 */     UtilsJavaSE.threadSetDaemon(this.handlerThread);
/*     */   }
/*     */   
/*     */   void startSessionHandlerThread() {
/*  76 */     this.handlerThread.start();
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/*  81 */     Thread.yield();
/*     */     try {
/*  83 */       if (this.stackID != null) {
/*  84 */         BlueCoveImpl.setThreadBluetoothStackID(this.stackID);
/*     */       }
/*  86 */       while (!isClosed() && !this.closeRequested) {
/*  87 */         if (!handleRequest()) {
/*     */           return;
/*     */         }
/*     */       } 
/*  91 */     } catch (Throwable e) {
/*  92 */       synchronized (OBEXServerSessionImpl.class) {
/*  93 */         errorCount++;
/*     */       } 
/*  95 */       if (this.isConnected) {
/*  96 */         DebugLog.error("OBEXServerSession error", e);
/*     */       } else {
/*  98 */         DebugLog.debug("OBEXServerSession error", e);
/*     */       } 
/*     */     } finally {
/* 101 */       DebugLog.debug("OBEXServerSession ends");
/*     */       try {
/* 103 */         super.close();
/* 104 */       } catch (IOException e) {
/* 105 */         DebugLog.debug("OBEXServerSession close error", e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 111 */     this.closeRequested = true;
/* 112 */     while (this.delayClose) {
/* 113 */       synchronized (this.canCloseEvent) {
/*     */         try {
/* 115 */           if (this.delayClose) {
/* 116 */             this.canCloseEvent.wait(700L);
/*     */           }
/* 118 */         } catch (InterruptedException e) {}
/*     */         
/* 120 */         this.delayClose = false;
/*     */       } 
/*     */     } 
/* 123 */     if (!isClosed()) {
/* 124 */       DebugLog.debug("OBEXServerSession close");
/*     */       
/* 126 */       if (this.operation != null) {
/* 127 */         this.operation.close();
/* 128 */         this.operation = null;
/*     */       } 
/*     */     } 
/* 131 */     super.close();
/*     */   }
/*     */   private boolean handleRequest() throws IOException {
/*     */     byte[] b;
/* 135 */     DebugLog.debug("OBEXServerSession handleRequest");
/* 136 */     this.delayClose = false;
/*     */     
/*     */     try {
/* 139 */       b = readPacket();
/* 140 */     } catch (EOFException e) {
/* 141 */       if (this.isConnected) {
/* 142 */         throw e;
/*     */       }
/* 144 */       DebugLog.debug("OBEXServerSession got EOF");
/* 145 */       close();
/* 146 */       return false;
/*     */     } 
/* 148 */     this.delayClose = true;
/*     */     try {
/* 150 */       int opcode = b[0] & 0xFF;
/* 151 */       boolean finalPacket = ((opcode & 0x80) != 0);
/* 152 */       if (finalPacket) {
/* 153 */         DebugLog.debug("OBEXServerSession got operation finalPacket");
/*     */       }
/* 155 */       switch (opcode) {
/*     */         case 128:
/* 157 */           processConnect(b);
/*     */           break;
/*     */         case 129:
/* 160 */           processDisconnect(b);
/*     */           break;
/*     */         case 2:
/*     */         case 130:
/* 164 */           processPut(b, finalPacket);
/*     */           break;
/*     */         case 5:
/*     */         case 133:
/* 168 */           processSetPath(b, finalPacket);
/*     */           break;
/*     */         case 255:
/* 171 */           processAbort();
/*     */           break;
/*     */         case 3:
/*     */         case 131:
/* 175 */           processGet(b, finalPacket);
/*     */           break;
/*     */         default:
/* 178 */           writePacket(209, null); break;
/*     */       } 
/*     */     } finally {
/* 181 */       this.delayClose = false;
/*     */     } 
/* 183 */     synchronized (this.canCloseEvent) {
/* 184 */       this.canCloseEvent.notifyAll();
/*     */     } 
/* 186 */     return true;
/*     */   }
/*     */   private void processConnect(byte[] b) throws IOException {
/*     */     int rc;
/* 190 */     DebugLog.debug("Connect operation");
/* 191 */     if (b[3] != 16) {
/* 192 */       throw new IOException("Unsupported client OBEX version " + b[3]);
/*     */     }
/* 194 */     if (b.length < 7) {
/* 195 */       throw new IOException("Corrupted OBEX data");
/*     */     }
/* 197 */     int requestedMTU = OBEXUtils.bytesToShort(b[5], b[6]);
/* 198 */     if (requestedMTU < 255) {
/* 199 */       throw new IOException("Invalid MTU " + requestedMTU);
/*     */     }
/* 201 */     this.mtu = requestedMTU;
/* 202 */     DebugLog.debug("mtu selected", this.mtu);
/*     */ 
/*     */     
/* 205 */     OBEXHeaderSetImpl replyHeaders = OBEXSessionBase.createOBEXHeaderSetImpl();
/* 206 */     OBEXHeaderSetImpl requestHeaders = OBEXHeaderSetImpl.readHeaders(b, 7);
/* 207 */     if (!handleAuthenticationResponse(requestHeaders)) {
/* 208 */       rc = 193;
/*     */     } else {
/* 210 */       handleAuthenticationChallenge(requestHeaders, replyHeaders);
/* 211 */       rc = 208;
/*     */       try {
/* 213 */         rc = this.handler.onConnect(requestHeaders, replyHeaders);
/* 214 */       } catch (Throwable e) {
/* 215 */         DebugLog.error("onConnect", e);
/*     */       } 
/*     */     } 
/* 218 */     byte[] connectResponse = new byte[4];
/* 219 */     connectResponse[0] = 16;
/* 220 */     connectResponse[1] = 0;
/* 221 */     connectResponse[2] = OBEXUtils.hiByte(this.obexConnectionParams.mtu);
/* 222 */     connectResponse[3] = OBEXUtils.loByte(this.obexConnectionParams.mtu);
/* 223 */     writePacketWithFlags(rc, connectResponse, replyHeaders);
/* 224 */     if (rc == 160) {
/* 225 */       this.isConnected = true;
/*     */     }
/*     */   }
/*     */   
/*     */   boolean handleAuthenticationResponse(OBEXHeaderSetImpl incomingHeaders) throws IOException {
/* 230 */     return handleAuthenticationResponse(incomingHeaders, this.handler);
/*     */   }
/*     */   
/*     */   private boolean validateConnection() throws IOException {
/* 234 */     if (this.isConnected) {
/* 235 */       return true;
/*     */     }
/* 237 */     writePacket(192, null);
/* 238 */     return false;
/*     */   }
/*     */   
/*     */   private void processDisconnect(byte[] b) throws IOException {
/* 242 */     DebugLog.debug("Disconnect operation");
/* 243 */     if (!validateConnection()) {
/*     */       return;
/*     */     }
/* 246 */     OBEXHeaderSetImpl requestHeaders = OBEXHeaderSetImpl.readHeaders(b, 3);
/* 247 */     OBEXHeaderSetImpl replyHeaders = OBEXSessionBase.createOBEXHeaderSetImpl();
/* 248 */     int rc = 160;
/*     */     try {
/* 250 */       this.handler.onDisconnect(requestHeaders, replyHeaders);
/* 251 */     } catch (Throwable e) {
/* 252 */       rc = 211;
/* 253 */       DebugLog.error("onDisconnect", e);
/*     */     } 
/* 255 */     this.isConnected = false;
/* 256 */     writePacket(rc, replyHeaders);
/*     */   }
/*     */   
/*     */   private void processDelete(OBEXHeaderSetImpl requestHeaders) throws IOException {
/* 260 */     DebugLog.debug("Delete operation");
/* 261 */     OBEXHeaderSetImpl replyHeaders = OBEXSessionBase.createOBEXHeaderSetImpl();
/* 262 */     handleAuthenticationChallenge(requestHeaders, replyHeaders);
/* 263 */     int rc = 160;
/*     */     try {
/* 265 */       rc = this.handler.onDelete(requestHeaders, replyHeaders);
/* 266 */     } catch (Throwable e) {
/* 267 */       rc = 211;
/* 268 */       DebugLog.error("onDelete", e);
/*     */     } 
/* 270 */     writePacket(rc, replyHeaders);
/*     */   }
/*     */   
/*     */   private void processPut(byte[] b, boolean finalPacket) throws IOException {
/* 274 */     DebugLog.debug("Put/Delete operation");
/* 275 */     if (!validateConnection()) {
/*     */       return;
/*     */     }
/* 278 */     OBEXHeaderSetImpl requestHeaders = OBEXHeaderSetImpl.readHeaders(b, 3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 288 */     if (!handleAuthenticationResponse(requestHeaders, this.handler)) {
/* 289 */       writePacket(193, null);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 294 */     if (finalPacket && !requestHeaders.hasIncommingData()) {
/* 295 */       processDelete(requestHeaders);
/*     */       return;
/*     */     } 
/* 298 */     DebugLog.debug("Put operation");
/* 299 */     this.operation = new OBEXServerOperationPut(this, requestHeaders, finalPacket);
/*     */     try {
/* 301 */       int rc = 160;
/*     */       try {
/* 303 */         rc = this.handler.onPut(this.operation);
/* 304 */       } catch (Throwable e) {
/* 305 */         rc = 211;
/* 306 */         DebugLog.error("onPut", e);
/*     */       } 
/* 308 */       if (!this.operation.isAborted) {
/* 309 */         this.operation.writeResponse(rc);
/*     */       }
/*     */     } finally {
/* 312 */       this.operation.close();
/* 313 */       this.operation = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void processGet(byte[] b, boolean finalPacket) throws IOException {
/* 318 */     DebugLog.debug("Get operation");
/* 319 */     if (!validateConnection()) {
/*     */       return;
/*     */     }
/* 322 */     OBEXHeaderSetImpl requestHeaders = OBEXHeaderSetImpl.readHeaders(b, 3);
/*     */     
/* 324 */     if (!handleAuthenticationResponse(requestHeaders, this.handler)) {
/* 325 */       writePacket(193, null);
/*     */       
/*     */       return;
/*     */     } 
/* 329 */     this.operation = new OBEXServerOperationGet(this, requestHeaders, finalPacket);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 339 */       int rc = 160;
/*     */       try {
/* 341 */         rc = this.handler.onGet(this.operation);
/* 342 */       } catch (Throwable e) {
/* 343 */         rc = 211;
/* 344 */         DebugLog.error("onGet", e);
/*     */       } 
/* 346 */       if (!this.operation.isAborted) {
/* 347 */         this.operation.writeResponse(rc);
/*     */       }
/*     */     } finally {
/* 350 */       this.operation.close();
/* 351 */       this.operation = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void processAbort() throws IOException {
/* 356 */     DebugLog.debug("Abort operation");
/* 357 */     if (!validateConnection()) {
/*     */       return;
/*     */     }
/* 360 */     if (this.operation != null) {
/* 361 */       this.operation.isAborted = true;
/* 362 */       this.operation.close();
/* 363 */       this.operation = null;
/* 364 */       writePacket(160, null);
/*     */     } else {
/* 366 */       writePacket(192, null);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void processSetPath(byte[] b, boolean finalPacket) throws IOException {
/* 371 */     DebugLog.debug("SetPath operation");
/* 372 */     if (!validateConnection()) {
/*     */       return;
/*     */     }
/* 375 */     if (b.length < 5) {
/* 376 */       throw new IOException("Corrupted OBEX data");
/*     */     }
/* 378 */     OBEXHeaderSetImpl requestHeaders = OBEXHeaderSetImpl.readHeaders(b, 5);
/*     */ 
/*     */     
/* 381 */     boolean backup = ((b[3] & 0x1) != 0);
/* 382 */     boolean create = ((b[3] & 0x2) == 0);
/* 383 */     DebugLog.debug("setPath backup", backup);
/* 384 */     DebugLog.debug("setPath create", create);
/*     */     
/* 386 */     if (!handleAuthenticationResponse(requestHeaders, this.handler)) {
/* 387 */       writePacket(193, null);
/*     */       
/*     */       return;
/*     */     } 
/* 391 */     OBEXHeaderSetImpl replyHeaders = OBEXSessionBase.createOBEXHeaderSetImpl();
/* 392 */     handleAuthenticationChallenge(requestHeaders, replyHeaders);
/* 393 */     int rc = 160;
/*     */     try {
/* 395 */       rc = this.handler.onSetPath(requestHeaders, replyHeaders, backup, create);
/* 396 */     } catch (Throwable e) {
/* 397 */       rc = 211;
/* 398 */       DebugLog.error("onSetPath", e);
/*     */     } 
/* 400 */     writePacket(rc, replyHeaders);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXServerSessionImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */