package com.intel.bluetooth.obex;

import com.intel.bluetooth.BlueCoveImpl;
import com.intel.bluetooth.BluetoothServerConnection;
import com.intel.bluetooth.DebugLog;
import com.intel.bluetooth.UtilsJavaSE;
import java.io.EOFException;
import java.io.IOException;
import javax.microedition.io.StreamConnection;
import javax.obex.Authenticator;
import javax.obex.ServerRequestHandler;

class OBEXServerSessionImpl extends OBEXSessionBase implements Runnable, BluetoothServerConnection {
  private ServerRequestHandler handler;
  
  private OBEXServerOperation operation;
  
  private boolean closeRequested = false;
  
  private volatile boolean delayClose = false;
  
  private Object canCloseEvent = new Object();
  
  private Object stackID;
  
  private Thread handlerThread;
  
  private static int threadNumber;
  
  private static synchronized int nextThreadNum() {
    return threadNumber++;
  }
  
  static int errorCount = 0;
  
  OBEXServerSessionImpl(StreamConnection connection, ServerRequestHandler handler, Authenticator authenticator, OBEXConnectionParams obexConnectionParams) throws IOException {
    super(connection, obexConnectionParams);
    this.requestSent = true;
    this.handler = handler;
    this.authenticator = authenticator;
    this.stackID = BlueCoveImpl.getCurrentThreadBluetoothStackID();
    this.handlerThread = new Thread(this, "OBEXServerSessionThread-" + nextThreadNum());
    UtilsJavaSE.threadSetDaemon(this.handlerThread);
  }
  
  void startSessionHandlerThread() {
    this.handlerThread.start();
  }
  
  public void run() {
    Thread.yield();
    try {
      if (this.stackID != null)
        BlueCoveImpl.setThreadBluetoothStackID(this.stackID); 
      while (!isClosed() && !this.closeRequested) {
        if (!handleRequest())
          return; 
      } 
    } catch (Throwable e) {
      synchronized (OBEXServerSessionImpl.class) {
        errorCount++;
      } 
      if (this.isConnected) {
        DebugLog.error("OBEXServerSession error", e);
      } else {
        DebugLog.debug("OBEXServerSession error", e);
      } 
    } finally {
      DebugLog.debug("OBEXServerSession ends");
      try {
        super.close();
      } catch (IOException e) {
        DebugLog.debug("OBEXServerSession close error", e);
      } 
    } 
  }
  
  public void close() throws IOException {
    this.closeRequested = true;
    while (this.delayClose) {
      synchronized (this.canCloseEvent) {
        try {
          if (this.delayClose)
            this.canCloseEvent.wait(700L); 
        } catch (InterruptedException e) {}
        this.delayClose = false;
      } 
    } 
    if (!isClosed()) {
      DebugLog.debug("OBEXServerSession close");
      if (this.operation != null) {
        this.operation.close();
        this.operation = null;
      } 
    } 
    super.close();
  }
  
  private boolean handleRequest() throws IOException {
    byte[] b;
    DebugLog.debug("OBEXServerSession handleRequest");
    this.delayClose = false;
    try {
      b = readPacket();
    } catch (EOFException e) {
      if (this.isConnected)
        throw e; 
      DebugLog.debug("OBEXServerSession got EOF");
      close();
      return false;
    } 
    this.delayClose = true;
    try {
      int opcode = b[0] & 0xFF;
      boolean finalPacket = ((opcode & 0x80) != 0);
      if (finalPacket)
        DebugLog.debug("OBEXServerSession got operation finalPacket"); 
      switch (opcode) {
        case 128:
          processConnect(b);
          break;
        case 129:
          processDisconnect(b);
          break;
        case 2:
        case 130:
          processPut(b, finalPacket);
          break;
        case 5:
        case 133:
          processSetPath(b, finalPacket);
          break;
        case 255:
          processAbort();
          break;
        case 3:
        case 131:
          processGet(b, finalPacket);
          break;
        default:
          writePacket(209, null);
          break;
      } 
    } finally {
      this.delayClose = false;
    } 
    synchronized (this.canCloseEvent) {
      this.canCloseEvent.notifyAll();
    } 
    return true;
  }
  
  private void processConnect(byte[] b) throws IOException {
    int rc;
    DebugLog.debug("Connect operation");
    if (b[3] != 16)
      throw new IOException("Unsupported client OBEX version " + b[3]); 
    if (b.length < 7)
      throw new IOException("Corrupted OBEX data"); 
    int requestedMTU = OBEXUtils.bytesToShort(b[5], b[6]);
    if (requestedMTU < 255)
      throw new IOException("Invalid MTU " + requestedMTU); 
    this.mtu = requestedMTU;
    DebugLog.debug("mtu selected", this.mtu);
    OBEXHeaderSetImpl replyHeaders = OBEXSessionBase.createOBEXHeaderSetImpl();
    OBEXHeaderSetImpl requestHeaders = OBEXHeaderSetImpl.readHeaders(b, 7);
    if (!handleAuthenticationResponse(requestHeaders)) {
      rc = 193;
    } else {
      handleAuthenticationChallenge(requestHeaders, replyHeaders);
      rc = 208;
      try {
        rc = this.handler.onConnect(requestHeaders, replyHeaders);
      } catch (Throwable e) {
        DebugLog.error("onConnect", e);
      } 
    } 
    byte[] connectResponse = new byte[4];
    connectResponse[0] = 16;
    connectResponse[1] = 0;
    connectResponse[2] = OBEXUtils.hiByte(this.obexConnectionParams.mtu);
    connectResponse[3] = OBEXUtils.loByte(this.obexConnectionParams.mtu);
    writePacketWithFlags(rc, connectResponse, replyHeaders);
    if (rc == 160)
      this.isConnected = true; 
  }
  
  boolean handleAuthenticationResponse(OBEXHeaderSetImpl incomingHeaders) throws IOException {
    return handleAuthenticationResponse(incomingHeaders, this.handler);
  }
  
  private boolean validateConnection() throws IOException {
    if (this.isConnected)
      return true; 
    writePacket(192, null);
    return false;
  }
  
  private void processDisconnect(byte[] b) throws IOException {
    DebugLog.debug("Disconnect operation");
    if (!validateConnection())
      return; 
    OBEXHeaderSetImpl requestHeaders = OBEXHeaderSetImpl.readHeaders(b, 3);
    OBEXHeaderSetImpl replyHeaders = OBEXSessionBase.createOBEXHeaderSetImpl();
    int rc = 160;
    try {
      this.handler.onDisconnect(requestHeaders, replyHeaders);
    } catch (Throwable e) {
      rc = 211;
      DebugLog.error("onDisconnect", e);
    } 
    this.isConnected = false;
    writePacket(rc, replyHeaders);
  }
  
  private void processDelete(OBEXHeaderSetImpl requestHeaders) throws IOException {
    DebugLog.debug("Delete operation");
    OBEXHeaderSetImpl replyHeaders = OBEXSessionBase.createOBEXHeaderSetImpl();
    handleAuthenticationChallenge(requestHeaders, replyHeaders);
    int rc = 160;
    try {
      rc = this.handler.onDelete(requestHeaders, replyHeaders);
    } catch (Throwable e) {
      rc = 211;
      DebugLog.error("onDelete", e);
    } 
    writePacket(rc, replyHeaders);
  }
  
  private void processPut(byte[] b, boolean finalPacket) throws IOException {
    DebugLog.debug("Put/Delete operation");
    if (!validateConnection())
      return; 
    OBEXHeaderSetImpl requestHeaders = OBEXHeaderSetImpl.readHeaders(b, 3);
    if (!handleAuthenticationResponse(requestHeaders, this.handler)) {
      writePacket(193, null);
      return;
    } 
    if (finalPacket && !requestHeaders.hasIncommingData()) {
      processDelete(requestHeaders);
      return;
    } 
    DebugLog.debug("Put operation");
    this.operation = new OBEXServerOperationPut(this, requestHeaders, finalPacket);
    try {
      int rc = 160;
      try {
        rc = this.handler.onPut(this.operation);
      } catch (Throwable e) {
        rc = 211;
        DebugLog.error("onPut", e);
      } 
      if (!this.operation.isAborted)
        this.operation.writeResponse(rc); 
    } finally {
      this.operation.close();
      this.operation = null;
    } 
  }
  
  private void processGet(byte[] b, boolean finalPacket) throws IOException {
    DebugLog.debug("Get operation");
    if (!validateConnection())
      return; 
    OBEXHeaderSetImpl requestHeaders = OBEXHeaderSetImpl.readHeaders(b, 3);
    if (!handleAuthenticationResponse(requestHeaders, this.handler)) {
      writePacket(193, null);
      return;
    } 
    this.operation = new OBEXServerOperationGet(this, requestHeaders, finalPacket);
    try {
      int rc = 160;
      try {
        rc = this.handler.onGet(this.operation);
      } catch (Throwable e) {
        rc = 211;
        DebugLog.error("onGet", e);
      } 
      if (!this.operation.isAborted)
        this.operation.writeResponse(rc); 
    } finally {
      this.operation.close();
      this.operation = null;
    } 
  }
  
  private void processAbort() throws IOException {
    DebugLog.debug("Abort operation");
    if (!validateConnection())
      return; 
    if (this.operation != null) {
      this.operation.isAborted = true;
      this.operation.close();
      this.operation = null;
      writePacket(160, null);
    } else {
      writePacket(192, null);
    } 
  }
  
  private void processSetPath(byte[] b, boolean finalPacket) throws IOException {
    DebugLog.debug("SetPath operation");
    if (!validateConnection())
      return; 
    if (b.length < 5)
      throw new IOException("Corrupted OBEX data"); 
    OBEXHeaderSetImpl requestHeaders = OBEXHeaderSetImpl.readHeaders(b, 5);
    boolean backup = ((b[3] & 0x1) != 0);
    boolean create = ((b[3] & 0x2) == 0);
    DebugLog.debug("setPath backup", backup);
    DebugLog.debug("setPath create", create);
    if (!handleAuthenticationResponse(requestHeaders, this.handler)) {
      writePacket(193, null);
      return;
    } 
    OBEXHeaderSetImpl replyHeaders = OBEXSessionBase.createOBEXHeaderSetImpl();
    handleAuthenticationChallenge(requestHeaders, replyHeaders);
    int rc = 160;
    try {
      rc = this.handler.onSetPath(requestHeaders, replyHeaders, backup, create);
    } catch (Throwable e) {
      rc = 211;
      DebugLog.error("onSetPath", e);
    } 
    writePacket(rc, replyHeaders);
  }
}
