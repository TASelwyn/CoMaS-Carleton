package com.intel.bluetooth.obex;

import java.io.IOException;
import javax.microedition.io.Connection;

public abstract class BlueCoveOBEX {
  public static int getPacketSize(Connection c) {
    if (c instanceof OBEXSessionBase)
      return ((OBEXSessionBase)c).getPacketSize(); 
    throw new IllegalArgumentException("Not a BlueCove OBEX Session " + c.getClass().getName());
  }
  
  public static void setPacketSize(Connection c, int mtu) throws IOException {
    if (c instanceof OBEXSessionBase) {
      ((OBEXSessionBase)c).setPacketSize(mtu);
    } else {
      throw new IllegalArgumentException("Not a BlueCove OBEX Session " + c.getClass().getName());
    } 
  }
  
  public static String obexResponseCodes(int responseCode) {
    return OBEXUtils.toStringObexResponseCodes(responseCode);
  }
}
