/*     */ package com.intel.bluetooth.obex;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OBEXOperationOutputStream
/*     */   extends OutputStream
/*     */ {
/*     */   private final OBEXOperationDelivery operation;
/*     */   private byte[] buffer;
/*     */   private int bufferLength;
/*  37 */   private Object lock = new Object();
/*     */   
/*     */   private boolean isClosed = false;
/*     */   
/*     */   OBEXOperationOutputStream(int mtu, OBEXOperationDelivery op) {
/*  42 */     this.operation = op;
/*  43 */     this.buffer = new byte[mtu - 11];
/*  44 */     this.bufferLength = 0;
/*     */   }
/*     */   
/*     */   public void write(int i) throws IOException {
/*  48 */     write(new byte[] { (byte)i }, 0, 1);
/*     */   }
/*     */   
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/*  52 */     if (this.operation.isClosed() || this.isClosed) {
/*  53 */       throw new IOException("stream closed");
/*     */     }
/*  55 */     if (b == null)
/*  56 */       throw new NullPointerException(); 
/*  57 */     if (off < 0 || len < 0 || off + len > b.length)
/*  58 */       throw new IndexOutOfBoundsException(); 
/*  59 */     if (len == 0) {
/*     */       return;
/*     */     }
/*     */     
/*  63 */     synchronized (this.lock) {
/*  64 */       int written = 0;
/*  65 */       while (written < len) {
/*  66 */         int available = this.buffer.length - this.bufferLength;
/*  67 */         if (len - written < available) {
/*  68 */           available = len - written;
/*     */         }
/*  70 */         System.arraycopy(b, off + written, this.buffer, this.bufferLength, available);
/*  71 */         this.bufferLength += available;
/*  72 */         written += available;
/*  73 */         if (this.bufferLength == this.buffer.length) {
/*  74 */           this.operation.deliverPacket(false, this.buffer);
/*  75 */           this.bufferLength = 0;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void flush() throws IOException {
/*  82 */     if (this.bufferLength > 0) {
/*  83 */       deliverBuffer(false);
/*     */     }
/*     */   }
/*     */   
/*     */   void deliverBuffer(boolean finalPacket) throws IOException {
/*  88 */     synchronized (this.lock) {
/*  89 */       byte[] b = new byte[this.bufferLength];
/*  90 */       System.arraycopy(this.buffer, 0, b, 0, this.bufferLength);
/*  91 */       this.operation.deliverPacket(finalPacket, b);
/*  92 */       this.bufferLength = 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   void abort() {
/*  97 */     synchronized (this.lock) {
/*  98 */       this.isClosed = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 103 */     if (!this.isClosed)
/* 104 */       synchronized (this.lock) {
/* 105 */         this.isClosed = true;
/* 106 */         if (!this.operation.isClosed())
/* 107 */           deliverBuffer(true); 
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXOperationOutputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */