package com.intel.bluetooth.obex;

import java.io.IOException;
import java.io.OutputStream;

class OBEXOperationOutputStream extends OutputStream {
  private final OBEXOperationDelivery operation;
  
  private byte[] buffer;
  
  private int bufferLength;
  
  private Object lock = new Object();
  
  private boolean isClosed = false;
  
  OBEXOperationOutputStream(int mtu, OBEXOperationDelivery op) {
    this.operation = op;
    this.buffer = new byte[mtu - 11];
    this.bufferLength = 0;
  }
  
  public void write(int i) throws IOException {
    write(new byte[] { (byte)i }, 0, 1);
  }
  
  public void write(byte[] b, int off, int len) throws IOException {
    if (this.operation.isClosed() || this.isClosed)
      throw new IOException("stream closed"); 
    if (b == null)
      throw new NullPointerException(); 
    if (off < 0 || len < 0 || off + len > b.length)
      throw new IndexOutOfBoundsException(); 
    if (len == 0)
      return; 
    synchronized (this.lock) {
      int written = 0;
      while (written < len) {
        int available = this.buffer.length - this.bufferLength;
        if (len - written < available)
          available = len - written; 
        System.arraycopy(b, off + written, this.buffer, this.bufferLength, available);
        this.bufferLength += available;
        written += available;
        if (this.bufferLength == this.buffer.length) {
          this.operation.deliverPacket(false, this.buffer);
          this.bufferLength = 0;
        } 
      } 
    } 
  }
  
  public void flush() throws IOException {
    if (this.bufferLength > 0)
      deliverBuffer(false); 
  }
  
  void deliverBuffer(boolean finalPacket) throws IOException {
    synchronized (this.lock) {
      byte[] b = new byte[this.bufferLength];
      System.arraycopy(this.buffer, 0, b, 0, this.bufferLength);
      this.operation.deliverPacket(finalPacket, b);
      this.bufferLength = 0;
    } 
  }
  
  void abort() {
    synchronized (this.lock) {
      this.isClosed = true;
    } 
  }
  
  public void close() throws IOException {
    if (!this.isClosed)
      synchronized (this.lock) {
        this.isClosed = true;
        if (!this.operation.isClosed())
          deliverBuffer(true); 
      }  
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXOperationOutputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */