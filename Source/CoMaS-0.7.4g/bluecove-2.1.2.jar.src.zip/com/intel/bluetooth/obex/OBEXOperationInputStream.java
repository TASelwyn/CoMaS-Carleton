package com.intel.bluetooth.obex;

import java.io.IOException;
import java.io.InputStream;

class OBEXOperationInputStream extends InputStream {
  private final OBEXOperation operation;
  
  private byte[] buffer;
  
  private int readPos;
  
  private int appendPos;
  
  private Object lock;
  
  private boolean isClosed;
  
  private boolean eofReceived;
  
  OBEXOperationInputStream(OBEXOperation op) {
    this.buffer = new byte[256];
    this.readPos = 0;
    this.appendPos = 0;
    this.lock = new Object();
    this.isClosed = false;
    this.eofReceived = false;
    this.operation = op;
  }
  
  public int read() throws IOException {
    if (this.isClosed)
      throw new IOException("Stream closed"); 
    if (this.operation.isClosed() && this.appendPos == this.readPos)
      return -1; 
    synchronized (this.lock) {
      while (!this.eofReceived && this.operation instanceof OBEXOperationReceive && !this.isClosed && !this.operation.isClosed() && this.appendPos == this.readPos)
        ((OBEXOperationReceive)this.operation).receiveData(this); 
      if (this.appendPos == this.readPos)
        return -1; 
      return this.buffer[this.readPos++] & 0xFF;
    } 
  }
  
  public int available() throws IOException {
    synchronized (this.lock) {
      return this.appendPos - this.readPos;
    } 
  }
  
  public void close() throws IOException {
    this.isClosed = true;
    synchronized (this.lock) {
      this.lock.notifyAll();
    } 
  }
  
  void appendData(byte[] b, boolean eof) {
    if (this.isClosed || this.eofReceived)
      return; 
    synchronized (this.lock) {
      if (eof)
        this.eofReceived = true; 
      if (b != null && b.length != 0) {
        if (this.appendPos + b.length > this.buffer.length) {
          int newSize = (b.length + this.appendPos - this.readPos) * 2;
          if (newSize < this.buffer.length)
            newSize = this.buffer.length; 
          byte[] newBuffer = new byte[newSize];
          System.arraycopy(this.buffer, this.readPos, newBuffer, 0, this.appendPos - this.readPos);
          this.buffer = newBuffer;
          this.appendPos -= this.readPos;
          this.readPos = 0;
        } 
        System.arraycopy(b, 0, this.buffer, this.appendPos, b.length);
        this.appendPos += b.length;
      } 
      this.lock.notifyAll();
    } 
  }
}
