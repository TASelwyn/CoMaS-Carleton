package com.intel.bluetooth.obex;

import java.io.IOException;

interface OBEXOperationDelivery extends OBEXOperation {
  void deliverPacket(boolean paramBoolean, byte[] paramArrayOfbyte) throws IOException;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXOperationDelivery.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */