/*    */ package com.intel.bluetooth.obex;
/*    */ 
/*    */ import com.intel.bluetooth.DebugLog;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OBEXClientOperationPut
/*    */   extends OBEXClientOperation
/*    */ {
/*    */   OBEXClientOperationPut(OBEXClientSessionImpl session, OBEXHeaderSetImpl sendHeaders) throws IOException {
/* 36 */     super(session, '\002', sendHeaders);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InputStream openInputStream() throws IOException {
/* 45 */     validateOperationIsOpen();
/* 46 */     if (this.inputStreamOpened) {
/* 47 */       throw new IOException("input stream already open");
/*    */     }
/* 49 */     DebugLog.debug("openInputStream");
/* 50 */     this.inputStreamOpened = true;
/* 51 */     this.operationInProgress = true;
/* 52 */     return this.inputStream;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public OutputStream openOutputStream() throws IOException {
/* 61 */     validateOperationIsOpen();
/* 62 */     if (this.outputStreamOpened) {
/* 63 */       throw new IOException("output already open");
/*    */     }
/* 65 */     this.outputStreamOpened = true;
/* 66 */     this.outputStream = new OBEXOperationOutputStream(this.session.mtu, this);
/* 67 */     this.operationInProgress = true;
/* 68 */     return this.outputStream;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXClientOperationPut.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */