package com.intel.bluetooth.obex;

interface OBEXOperation {
  boolean isClosed();
}
