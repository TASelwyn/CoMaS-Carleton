/*     */ package com.intel.bluetooth.obex;
/*     */ 
/*     */ import com.intel.bluetooth.DebugLog;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.obex.HeaderSet;
/*     */ import javax.obex.Operation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class OBEXClientOperation
/*     */   implements Operation, OBEXOperation, OBEXOperationReceive, OBEXOperationDelivery
/*     */ {
/*     */   static final boolean SHORT_REQUEST_PHASE = true;
/*     */   protected OBEXClientSessionImpl session;
/*     */   protected char operationId;
/*     */   protected HeaderSet replyHeaders;
/*     */   protected boolean isClosed;
/*     */   protected boolean operationInProgress;
/*     */   protected boolean operationInContinue;
/*     */   protected OBEXOperationOutputStream outputStream;
/*     */   protected boolean outputStreamOpened = false;
/*     */   protected OBEXOperationInputStream inputStream;
/*     */   protected boolean inputStreamOpened = false;
/*     */   protected boolean errorReceived = false;
/*     */   protected boolean requestEnded = false;
/*     */   protected boolean finalBodyReceived = false;
/*  73 */   protected OBEXHeaderSetImpl startOperationHeaders = null;
/*     */   
/*     */   private boolean authenticationResponseCreated = false;
/*     */   
/*     */   protected Object lock;
/*     */ 
/*     */   
/*     */   OBEXClientOperation(OBEXClientSessionImpl session, char operationId, OBEXHeaderSetImpl sendHeaders) throws IOException {
/*  81 */     this.session = session;
/*  82 */     this.operationId = operationId;
/*  83 */     this.isClosed = false;
/*  84 */     this.operationInProgress = false;
/*  85 */     this.lock = new Object();
/*  86 */     this.inputStream = new OBEXOperationInputStream(this);
/*  87 */     startOperation(sendHeaders);
/*     */   }
/*     */   
/*     */   static boolean isShortRequestPhase() {
/*  91 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void startOperation(OBEXHeaderSetImpl sendHeaders) throws IOException {
/*  96 */     this.startOperationHeaders = sendHeaders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receiveData(OBEXOperationInputStream is) throws IOException {
/* 110 */     exchangePacket(this.startOperationHeaders);
/* 111 */     this.startOperationHeaders = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deliverPacket(boolean finalPacket, byte[] buffer) throws IOException {
/* 123 */     if (this.requestEnded) {
/*     */       return;
/*     */     }
/* 126 */     if (this.startOperationHeaders != null) {
/* 127 */       exchangePacket(this.startOperationHeaders);
/* 128 */       this.startOperationHeaders = null;
/*     */     } 
/* 130 */     int dataHeaderID = 72;
/* 131 */     if (finalPacket) {
/* 132 */       this.operationId = (char)(this.operationId | 0x80);
/* 133 */       dataHeaderID = 73;
/* 134 */       DebugLog.debug("client Request Phase ended");
/* 135 */       this.requestEnded = true;
/*     */     } 
/* 137 */     OBEXHeaderSetImpl dataHeaders = OBEXSessionBase.createOBEXHeaderSetImpl();
/* 138 */     dataHeaders.setHeader(dataHeaderID, buffer);
/* 139 */     exchangePacket(dataHeaders);
/*     */   }
/*     */   
/*     */   protected void endRequestPhase() throws IOException {
/* 143 */     if (this.requestEnded) {
/*     */       return;
/*     */     }
/* 146 */     DebugLog.debug("client ends Request Phase");
/* 147 */     this.operationInProgress = false;
/* 148 */     this.requestEnded = true;
/* 149 */     this.operationId = (char)(this.operationId | 0x80);
/*     */     
/* 151 */     exchangePacket(this.startOperationHeaders);
/* 152 */     this.startOperationHeaders = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void exchangePacket(OBEXHeaderSetImpl headers) throws IOException {
/* 159 */     boolean success = false;
/*     */     try {
/* 161 */       this.session.writePacket(this.operationId, headers);
/* 162 */       byte[] b = this.session.readPacket();
/* 163 */       OBEXHeaderSetImpl dataHeaders = OBEXHeaderSetImpl.readHeaders(b[0], b, 3);
/* 164 */       this.session.handleAuthenticationResponse(dataHeaders, null);
/* 165 */       int responseCode = dataHeaders.getResponseCode();
/* 166 */       DebugLog.debug0x("client operation got reply", OBEXUtils.toStringObexResponseCodes(responseCode), responseCode);
/* 167 */       switch (responseCode) {
/*     */         case 193:
/* 169 */           if (!this.authenticationResponseCreated && dataHeaders.hasAuthenticationChallenge()) {
/* 170 */             DebugLog.debug("client resend request with auth response");
/*     */             
/* 172 */             OBEXHeaderSetImpl retryHeaders = OBEXHeaderSetImpl.cloneHeaders(headers);
/* 173 */             this.session.handleAuthenticationChallenge(dataHeaders, retryHeaders);
/* 174 */             this.authenticationResponseCreated = true;
/* 175 */             exchangePacket(retryHeaders); break;
/*     */           } 
/* 177 */           this.errorReceived = true;
/* 178 */           this.operationInContinue = false;
/* 179 */           processIncommingHeaders(dataHeaders);
/* 180 */           throw new IOException("Authentication Failure");
/*     */ 
/*     */         
/*     */         case 160:
/* 184 */           processIncommingHeaders(dataHeaders);
/* 185 */           processIncommingData(dataHeaders, true);
/* 186 */           this.operationInProgress = false;
/* 187 */           this.operationInContinue = false;
/*     */           break;
/*     */         case 144:
/* 190 */           processIncommingHeaders(dataHeaders);
/* 191 */           processIncommingData(dataHeaders, false);
/* 192 */           this.operationInContinue = true;
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         default:
/* 203 */           this.errorReceived = true;
/* 204 */           this.operationInContinue = false;
/*     */           
/* 206 */           processIncommingHeaders(dataHeaders);
/* 207 */           processIncommingData(dataHeaders, true);
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 216 */       success = true;
/*     */     } finally {
/* 218 */       if (!success) {
/* 219 */         this.errorReceived = true;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void processIncommingHeaders(HeaderSet dataHeaders) throws IOException {
/* 225 */     if (this.replyHeaders != null)
/*     */     {
/* 227 */       OBEXHeaderSetImpl.appendHeaders(dataHeaders, this.replyHeaders);
/*     */     }
/*     */ 
/*     */     
/* 231 */     this.replyHeaders = dataHeaders;
/*     */   }
/*     */   
/*     */   protected void processIncommingData(HeaderSet dataHeaders, boolean eof) throws IOException {
/* 235 */     byte[] data = (byte[])dataHeaders.getHeader(72);
/* 236 */     if (data == null) {
/* 237 */       data = (byte[])dataHeaders.getHeader(73);
/* 238 */       if (data != null) {
/* 239 */         this.finalBodyReceived = true;
/* 240 */         eof = true;
/*     */       } 
/*     */     } 
/* 243 */     if (data != null) {
/* 244 */       DebugLog.debug("client received Data eof: " + eof + " len: ", data.length);
/* 245 */       this.inputStream.appendData(data, eof);
/* 246 */     } else if (eof) {
/* 247 */       this.inputStream.appendData(null, eof);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void abort() throws IOException {
/* 257 */     validateOperationIsOpen();
/* 258 */     if (!this.operationInProgress && !this.operationInContinue) {
/* 259 */       throw new IOException("the transaction has already ended");
/*     */     }
/* 261 */     synchronized (this.lock) {
/* 262 */       if (this.outputStream != null) {
/* 263 */         this.outputStream.abort();
/*     */       }
/* 265 */       this.inputStream.close();
/*     */     } 
/* 267 */     writeAbort();
/*     */   }
/*     */   
/*     */   private void writeAbort() throws IOException {
/*     */     try {
/* 272 */       this.session.writePacket(255, null);
/* 273 */       this.requestEnded = true;
/* 274 */       byte[] b = this.session.readPacket();
/* 275 */       HeaderSet dataHeaders = OBEXHeaderSetImpl.readHeaders(b[0], b, 3);
/* 276 */       if (dataHeaders.getResponseCode() != 160) {
/* 277 */         throw new IOException("Fails to abort operation, received " + OBEXUtils.toStringObexResponseCodes(dataHeaders.getResponseCode()));
/*     */       }
/*     */     } finally {
/*     */       
/* 281 */       this.isClosed = true;
/* 282 */       closeStream();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void closeStream() throws IOException {
/*     */     try {
/* 288 */       receiveOperationEnd();
/*     */     } finally {
/* 290 */       this.operationInProgress = false;
/* 291 */       this.inputStream.close();
/* 292 */       closeOutputStream();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void receiveOperationEnd() throws IOException {
/* 297 */     while (!isClosed() && this.operationInContinue) {
/* 298 */       DebugLog.debug("operation expects operation end");
/* 299 */       receiveData(this.inputStream);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void closeOutputStream() throws IOException {
/* 304 */     if (this.outputStream != null) {
/* 305 */       synchronized (this.lock) {
/* 306 */         if (this.outputStream != null) {
/* 307 */           this.outputStream.close();
/*     */         }
/* 309 */         this.outputStream = null;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   protected void validateOperationIsOpen() throws IOException {
/* 315 */     if (this.isClosed) {
/* 316 */       throw new IOException("operation closed");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HeaderSet getReceivedHeaders() throws IOException {
/* 326 */     validateOperationIsOpen();
/* 327 */     endRequestPhase();
/* 328 */     return OBEXHeaderSetImpl.cloneHeaders(this.replyHeaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getResponseCode() throws IOException {
/* 339 */     validateOperationIsOpen();
/* 340 */     endRequestPhase();
/* 341 */     closeOutputStream();
/* 342 */     receiveOperationEnd();
/* 343 */     return this.replyHeaders.getResponseCode();
/*     */   }
/*     */   
/*     */   public void sendHeaders(HeaderSet headers) throws IOException {
/* 347 */     if (headers == null) {
/* 348 */       throw new NullPointerException("headers are null");
/*     */     }
/* 350 */     OBEXHeaderSetImpl.validateCreatedHeaderSet(headers);
/* 351 */     validateOperationIsOpen();
/* 352 */     if (this.requestEnded) {
/* 353 */       throw new IOException("the request phase has already ended");
/*     */     }
/* 355 */     if (this.startOperationHeaders != null) {
/* 356 */       exchangePacket(this.startOperationHeaders);
/* 357 */       this.startOperationHeaders = null;
/*     */     } 
/* 359 */     exchangePacket((OBEXHeaderSetImpl)headers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEncoding() {
/* 369 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLength() {
/*     */     Long len;
/*     */     try {
/* 381 */       len = (Long)this.replyHeaders.getHeader(195);
/* 382 */     } catch (IOException e) {
/* 383 */       return -1L;
/*     */     } 
/* 385 */     if (len == null) {
/* 386 */       return -1L;
/*     */     }
/* 388 */     return len.longValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/*     */     try {
/* 399 */       return (String)this.replyHeaders.getHeader(66);
/* 400 */     } catch (IOException e) {
/* 401 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public DataInputStream openDataInputStream() throws IOException {
/* 406 */     return new DataInputStream(super.openInputStream());
/*     */   }
/*     */   
/*     */   public DataOutputStream openDataOutputStream() throws IOException {
/* 410 */     return new DataOutputStream(super.openOutputStream());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*     */     try {
/* 420 */       endRequestPhase();
/*     */     } finally {
/* 422 */       closeStream();
/* 423 */       if (!this.isClosed) {
/* 424 */         this.isClosed = true;
/* 425 */         DebugLog.debug("client operation closed");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isClosed() {
/* 431 */     return (this.isClosed || this.errorReceived);
/*     */   }
/*     */   
/*     */   public abstract InputStream openInputStream() throws IOException;
/*     */   
/*     */   public abstract OutputStream openOutputStream() throws IOException;
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXClientOperation.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */