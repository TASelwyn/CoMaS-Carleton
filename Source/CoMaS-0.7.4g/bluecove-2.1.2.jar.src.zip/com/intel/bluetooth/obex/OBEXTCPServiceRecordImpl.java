/*     */ package com.intel.bluetooth.obex;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.bluetooth.DataElement;
/*     */ import javax.bluetooth.RemoteDevice;
/*     */ import javax.bluetooth.ServiceRecord;
/*     */ import javax.microedition.io.ServerSocketConnection;
/*     */ import javax.microedition.io.SocketConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OBEXTCPServiceRecordImpl
/*     */   implements ServiceRecord
/*     */ {
/*     */   private String host;
/*     */   private String port;
/*     */   
/*     */   OBEXTCPServiceRecordImpl(ServerSocketConnection notifier) {
/*     */     try {
/*  49 */       this.port = String.valueOf(notifier.getLocalPort());
/*  50 */       this.host = notifier.getLocalAddress();
/*  51 */     } catch (IOException e) {
/*  52 */       this.host = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   OBEXTCPServiceRecordImpl(SocketConnection connection) {
/*     */     try {
/*  58 */       this.port = String.valueOf(connection.getPort());
/*  59 */       this.host = connection.getAddress();
/*  60 */     } catch (IOException e) {
/*  61 */       this.host = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConnectionURL(int requiredSecurity, boolean mustBeMaster) {
/*  69 */     if (this.host == null) {
/*  70 */       return null;
/*     */     }
/*  72 */     return "tcpobex://" + this.host + ":" + this.port;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getAttributeIDs() {
/*  79 */     throw new IllegalArgumentException("Not a Bluetooth ServiceRecord");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataElement getAttributeValue(int attrID) {
/*  86 */     throw new IllegalArgumentException("Not a Bluetooth ServiceRecord");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RemoteDevice getHostDevice() {
/*  93 */     throw new IllegalArgumentException("Not a Bluetooth ServiceRecord");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean populateRecord(int[] attrIDs) throws IOException {
/* 100 */     throw new IllegalArgumentException("Not a Bluetooth ServiceRecord");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setAttributeValue(int attrID, DataElement attrValue) {
/* 107 */     throw new IllegalArgumentException("Not a Bluetooth ServiceRecord");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDeviceServiceClasses(int classes) {
/* 114 */     throw new IllegalArgumentException("Not a Bluetooth ServiceRecord");
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXTCPServiceRecordImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */