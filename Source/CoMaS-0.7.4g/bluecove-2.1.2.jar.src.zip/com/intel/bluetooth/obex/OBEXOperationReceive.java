package com.intel.bluetooth.obex;

import java.io.IOException;

interface OBEXOperationReceive extends OBEXOperation {
  void receiveData(OBEXOperationInputStream paramOBEXOperationInputStream) throws IOException;
}
