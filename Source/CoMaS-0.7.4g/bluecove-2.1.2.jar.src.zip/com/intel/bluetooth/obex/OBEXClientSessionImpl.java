package com.intel.bluetooth.obex;

import com.intel.bluetooth.DebugLog;
import com.intel.bluetooth.Utils;
import java.io.IOException;
import java.util.Vector;
import javax.microedition.io.StreamConnection;
import javax.obex.Authenticator;
import javax.obex.ClientSession;
import javax.obex.HeaderSet;
import javax.obex.Operation;

public class OBEXClientSessionImpl extends OBEXSessionBase implements ClientSession {
  protected OBEXClientOperation operation;
  
  private static final String FQCN = OBEXClientSessionImpl.class.getName();
  
  private static final Vector fqcnSet = new Vector();
  
  static {
    fqcnSet.addElement(FQCN);
  }
  
  public OBEXClientSessionImpl(StreamConnection conn, OBEXConnectionParams obexConnectionParams) throws IOException, Error {
    super(conn, obexConnectionParams);
    Utils.isLegalAPICall(fqcnSet);
    this.requestSent = false;
    this.isConnected = false;
    this.operation = null;
  }
  
  public HeaderSet createHeaderSet() {
    return OBEXSessionBase.createOBEXHeaderSet();
  }
  
  public HeaderSet connect(HeaderSet headers) throws IOException {
    return connectImpl(headers, false);
  }
  
  private HeaderSet connectImpl(HeaderSet headers, boolean retry) throws IOException {
    OBEXSessionBase.validateCreatedHeaderSet(headers);
    if (this.isConnected)
      throw new IOException("Session already connected"); 
    byte[] connectRequest = new byte[4];
    connectRequest[0] = 16;
    connectRequest[1] = 0;
    connectRequest[2] = OBEXUtils.hiByte(this.obexConnectionParams.mtu);
    connectRequest[3] = OBEXUtils.loByte(this.obexConnectionParams.mtu);
    writePacketWithFlags(128, connectRequest, (OBEXHeaderSetImpl)headers);
    byte[] b = readPacket();
    if (b.length < 6) {
      if (b.length == 3)
        throw new IOException("Invalid response from OBEX server " + OBEXUtils.toStringObexResponseCodes(b[0])); 
      throw new IOException("Invalid response from OBEX server");
    } 
    int serverMTU = OBEXUtils.bytesToShort(b[5], b[6]);
    if (serverMTU < 255)
      throw new IOException("Invalid MTU " + serverMTU); 
    if (serverMTU < this.mtu)
      this.mtu = serverMTU; 
    DebugLog.debug("mtu selected", this.mtu);
    OBEXHeaderSetImpl responseHeaders = OBEXHeaderSetImpl.readHeaders(b[0], b, 7);
    Object connID = responseHeaders.getHeader(203);
    if (connID != null)
      this.connectionID = ((Long)connID).longValue(); 
    validateAuthenticationResponse((OBEXHeaderSetImpl)headers, responseHeaders);
    if (!retry && responseHeaders.getResponseCode() == 193 && responseHeaders.hasAuthenticationChallenge()) {
      HeaderSet replyHeaders = OBEXHeaderSetImpl.cloneHeaders(headers);
      handleAuthenticationChallenge(responseHeaders, (OBEXHeaderSetImpl)replyHeaders);
      return connectImpl(replyHeaders, true);
    } 
    if (responseHeaders.getResponseCode() == 160)
      this.isConnected = true; 
    return responseHeaders;
  }
  
  public HeaderSet disconnect(HeaderSet headers) throws IOException {
    OBEXSessionBase.validateCreatedHeaderSet(headers);
    canStartOperation();
    if (!this.isConnected)
      throw new IOException("Session not connected"); 
    writePacket(129, (OBEXHeaderSetImpl)headers);
    byte[] b = readPacket();
    this.isConnected = false;
    if (this.operation != null) {
      this.operation.close();
      this.operation = null;
    } 
    return OBEXHeaderSetImpl.readHeaders(b[0], b, 3);
  }
  
  public void setConnectionID(long id) {
    if (id < 0L || id > 4294967295L)
      throw new IllegalArgumentException("Invalid connectionID " + id); 
    this.connectionID = id;
  }
  
  public long getConnectionID() {
    return this.connectionID;
  }
  
  protected void canStartOperation() throws IOException {
    if (!this.isConnected)
      throw new IOException("Session not connected"); 
    if (this.operation != null) {
      if (!this.operation.isClosed())
        throw new IOException("Client is already in an operation"); 
      this.operation = null;
    } 
  }
  
  public HeaderSet setPath(HeaderSet headers, boolean backup, boolean create) throws IOException {
    OBEXSessionBase.validateCreatedHeaderSet(headers);
    canStartOperation();
    return setPathImpl(headers, backup, create, false);
  }
  
  private HeaderSet setPathImpl(HeaderSet headers, boolean backup, boolean create, boolean authentRetry) throws IOException {
    byte[] request = new byte[2];
    request[0] = (byte)((backup ? true : false) | (create ? false : true));
    request[1] = 0;
    writePacketWithFlags(133, request, (OBEXHeaderSetImpl)headers);
    byte[] b = readPacket();
    OBEXHeaderSetImpl responseHeaders = OBEXHeaderSetImpl.readHeaders(b[0], b, 3);
    validateAuthenticationResponse((OBEXHeaderSetImpl)headers, responseHeaders);
    if (!authentRetry && responseHeaders.getResponseCode() == 193 && responseHeaders.hasAuthenticationChallenge()) {
      OBEXHeaderSetImpl retryHeaders = OBEXHeaderSetImpl.cloneHeaders(headers);
      handleAuthenticationChallenge(responseHeaders, retryHeaders);
      return setPathImpl(retryHeaders, backup, create, true);
    } 
    return responseHeaders;
  }
  
  public Operation get(HeaderSet headers) throws IOException {
    OBEXSessionBase.validateCreatedHeaderSet(headers);
    canStartOperation();
    this.operation = new OBEXClientOperationGet(this, (OBEXHeaderSetImpl)headers);
    return this.operation;
  }
  
  public Operation put(HeaderSet headers) throws IOException {
    OBEXSessionBase.validateCreatedHeaderSet(headers);
    canStartOperation();
    this.operation = new OBEXClientOperationPut(this, (OBEXHeaderSetImpl)headers);
    return this.operation;
  }
  
  public HeaderSet delete(HeaderSet headers) throws IOException {
    OBEXSessionBase.validateCreatedHeaderSet(headers);
    canStartOperation();
    return deleteImp(headers, false);
  }
  
  HeaderSet deleteImp(HeaderSet headers, boolean authentRetry) throws IOException {
    writePacket(130, (OBEXHeaderSetImpl)headers);
    byte[] b = readPacket();
    OBEXHeaderSetImpl responseHeaders = OBEXHeaderSetImpl.readHeaders(b[0], b, 3);
    validateAuthenticationResponse((OBEXHeaderSetImpl)headers, responseHeaders);
    if (!authentRetry && responseHeaders.getResponseCode() == 193 && responseHeaders.hasAuthenticationChallenge()) {
      OBEXHeaderSetImpl retryHeaders = OBEXHeaderSetImpl.cloneHeaders(headers);
      handleAuthenticationChallenge(responseHeaders, retryHeaders);
      return deleteImp(retryHeaders, true);
    } 
    return responseHeaders;
  }
  
  public void setAuthenticator(Authenticator auth) {
    if (auth == null)
      throw new NullPointerException("auth is null"); 
    this.authenticator = auth;
  }
  
  public void close() throws IOException {
    try {
      if (this.operation != null) {
        this.operation.close();
        this.operation = null;
      } 
    } finally {
      super.close();
    } 
  }
}
