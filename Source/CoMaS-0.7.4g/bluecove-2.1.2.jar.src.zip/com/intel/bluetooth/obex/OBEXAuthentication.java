package com.intel.bluetooth.obex;

import com.intel.bluetooth.DebugLog;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Vector;
import javax.obex.Authenticator;
import javax.obex.PasswordAuthentication;
import javax.obex.ServerRequestHandler;

class OBEXAuthentication {
  private static byte[] privateKey;
  
  private static long uniqueTimestamp = 0L;
  
  private static final byte[] COLUMN = new byte[] { 58 };
  
  static class Challenge {
    private String realm;
    
    private boolean isUserIdRequired;
    
    private boolean isFullAccess;
    
    byte[] nonce;
    
    Challenge(byte[] data) throws IOException {
      read(data);
    }
    
    Challenge(String realm, boolean isUserIdRequired, boolean isFullAccess, byte[] nonce) {
      this.realm = realm;
      this.isUserIdRequired = isUserIdRequired;
      this.isFullAccess = isFullAccess;
      this.nonce = nonce;
    }
    
    byte[] write() {
      ByteArrayOutputStream buf = new ByteArrayOutputStream();
      buf.write(0);
      buf.write(16);
      buf.write(this.nonce, 0, 16);
      byte options = (byte)((this.isUserIdRequired ? 1 : 0) | (!this.isFullAccess ? 2 : 0));
      buf.write(1);
      buf.write(1);
      buf.write(options);
      if (this.realm != null) {
        byte[] arrayOfByte;
        boolean bool;
        try {
          arrayOfByte = OBEXUtils.getUTF16Bytes(this.realm);
          bool = true;
        } catch (UnsupportedEncodingException e) {
          try {
            arrayOfByte = this.realm.getBytes("iso-8859-1");
          } catch (UnsupportedEncodingException e1) {
            arrayOfByte = new byte[0];
          } 
          bool = true;
        } 
        buf.write(2);
        buf.write(arrayOfByte.length + 1);
        buf.write(bool);
        buf.write(arrayOfByte, 0, arrayOfByte.length);
      } 
      return buf.toByteArray();
    }
    
    void read(byte[] data) throws IOException {
      DebugLog.debug("authChallenge", data);
      for (int i = 0; i < data.length; ) {
        byte options;
        int charSetCode;
        byte[] chars;
        int tag = data[i] & 0xFF;
        int len = data[i + 1] & 0xFF;
        i += 2;
        switch (tag) {
          case 0:
            if (len != 16)
              throw new IOException("OBEX Digest Challenge error in tag Nonce"); 
            this.nonce = new byte[16];
            System.arraycopy(data, i, this.nonce, 0, 16);
            break;
          case 1:
            options = data[i];
            DebugLog.debug("authChallenge options", options);
            this.isUserIdRequired = ((options & 0x1) != 0);
            this.isFullAccess = ((options & 0x2) == 0);
            break;
          case 2:
            charSetCode = data[i] & 0xFF;
            chars = new byte[len - 1];
            System.arraycopy(data, i + 1, chars, 0, chars.length);
            if (charSetCode == 255) {
              this.realm = OBEXUtils.newStringUTF16(chars);
              break;
            } 
            if (charSetCode == 0) {
              this.realm = new String(chars, "ASCII");
              break;
            } 
            if (charSetCode <= 9) {
              this.realm = new String(chars, "ISO-8859-" + charSetCode);
              break;
            } 
            DebugLog.error("Unsupported charset code " + charSetCode + " in Challenge");
            this.realm = new String(chars, 0, len - 1, "ASCII");
            break;
          default:
            DebugLog.error("invalid authChallenge tag " + tag);
            break;
        } 
        i += len;
      } 
    }
    
    public boolean isUserIdRequired() {
      return this.isUserIdRequired;
    }
    
    public boolean isFullAccess() {
      return this.isFullAccess;
    }
    
    public String getRealm() {
      return this.realm;
    }
  }
  
  static class DigestResponse {
    byte[] requestDigest;
    
    byte[] userName;
    
    byte[] nonce;
    
    byte[] write() {
      ByteArrayOutputStream buf = new ByteArrayOutputStream();
      buf.write(0);
      buf.write(16);
      buf.write(this.requestDigest, 0, 16);
      if (this.userName != null) {
        buf.write(1);
        buf.write(this.userName.length);
        buf.write(this.userName, 0, this.userName.length);
      } 
      buf.write(2);
      buf.write(16);
      buf.write(this.nonce, 0, 16);
      return buf.toByteArray();
    }
    
    void read(byte[] data) throws IOException {
      for (int i = 0; i < data.length; ) {
        int tag = data[i] & 0xFF;
        int len = data[i + 1] & 0xFF;
        i += 2;
        switch (tag) {
          case 0:
            if (len != 16)
              throw new IOException("OBEX Digest Response error in tag request-digest"); 
            this.requestDigest = new byte[16];
            System.arraycopy(data, i, this.requestDigest, 0, 16);
            break;
          case 1:
            this.userName = new byte[len];
            System.arraycopy(data, i, this.userName, 0, this.userName.length);
            break;
          case 2:
            if (len != 16)
              throw new IOException("OBEX Digest Response error in tag Nonce"); 
            this.nonce = new byte[16];
            System.arraycopy(data, i, this.nonce, 0, 16);
            break;
        } 
        i += len;
      } 
    }
  }
  
  static byte[] createChallenge(String realm, boolean isUserIdRequired, boolean isFullAccess) {
    Challenge challenge = new Challenge(realm, isUserIdRequired, isFullAccess, createNonce());
    return challenge.write();
  }
  
  static boolean handleAuthenticationResponse(OBEXHeaderSetImpl incomingHeaders, Authenticator authenticator, ServerRequestHandler serverHandler, Vector authChallengesSent) throws IOException {
    if (!incomingHeaders.hasAuthenticationResponses())
      return false; 
    for (Enumeration iter = incomingHeaders.getAuthenticationResponses(); iter.hasMoreElements(); ) {
      byte[] authResponse = iter.nextElement();
      DigestResponse dr = new DigestResponse();
      dr.read(authResponse);
      DebugLog.debug("got nonce", dr.nonce);
      Challenge challengeSent = null;
      for (Enumeration challengeIter = authChallengesSent.elements(); challengeIter.hasMoreElements(); ) {
        Challenge c = challengeIter.nextElement();
        if (equals(c.nonce, dr.nonce)) {
          challengeSent = c;
          break;
        } 
      } 
      if (challengeSent == null)
        throw new IOException("Authentication response for unknown challenge"); 
      byte[] password = authenticator.onAuthenticationResponse(dr.userName);
      if (password == null)
        throw new IOException("Authentication request failed, password is not supplied"); 
      MD5DigestWrapper md5 = new MD5DigestWrapper();
      md5.update(dr.nonce);
      md5.update(COLUMN);
      md5.update(password);
      byte[] claulated = md5.digest();
      if (!equals(dr.requestDigest, claulated)) {
        DebugLog.debug("got digest", dr.requestDigest);
        DebugLog.debug("  expected", claulated);
        if (serverHandler != null) {
          serverHandler.onAuthenticationFailure(dr.userName);
          continue;
        } 
        throw new IOException("Authentication failure");
      } 
      return true;
    } 
    return false;
  }
  
  static void handleAuthenticationChallenge(OBEXHeaderSetImpl incomingHeaders, OBEXHeaderSetImpl replyHeaders, Authenticator authenticator) throws IOException {
    if (!incomingHeaders.hasAuthenticationChallenge())
      return; 
    for (Enumeration iter = incomingHeaders.getAuthenticationChallenges(); iter.hasMoreElements(); ) {
      byte[] authChallenge = iter.nextElement();
      Challenge challenge = new Challenge(authChallenge);
      PasswordAuthentication pwd = authenticator.onAuthenticationChallenge(challenge.getRealm(), challenge.isUserIdRequired(), challenge.isFullAccess());
      DigestResponse dr = new DigestResponse();
      dr.nonce = challenge.nonce;
      DebugLog.debug("got nonce", dr.nonce);
      if (challenge.isUserIdRequired())
        dr.userName = pwd.getUserName(); 
      MD5DigestWrapper md5 = new MD5DigestWrapper();
      md5.update(dr.nonce);
      md5.update(COLUMN);
      md5.update(pwd.getPassword());
      dr.requestDigest = md5.digest();
      DebugLog.debug("send digest", dr.requestDigest);
      replyHeaders.addAuthenticationResponse(dr.write());
    } 
  }
  
  private static synchronized byte[] createNonce() {
    MD5DigestWrapper md5 = new MD5DigestWrapper();
    md5.update(createTimestamp());
    md5.update(COLUMN);
    md5.update(getPrivateKey());
    return md5.digest();
  }
  
  static boolean equals(byte[] digest1, byte[] digest2) {
    for (int i = 0; i < 16; i++) {
      if (digest1[i] != digest2[i])
        return false; 
    } 
    return true;
  }
  
  private static synchronized byte[] getPrivateKey() {
    if (privateKey != null)
      return privateKey; 
    MD5DigestWrapper md5 = new MD5DigestWrapper();
    md5.update(createTimestamp());
    privateKey = md5.digest();
    return privateKey;
  }
  
  private static synchronized byte[] createTimestamp() {
    long t = System.currentTimeMillis();
    if (t <= uniqueTimestamp)
      t = uniqueTimestamp + 1L; 
    uniqueTimestamp = t;
    byte[] buf = new byte[8];
    for (int i = 0; i < buf.length; i++) {
      buf[i] = (byte)(int)(t >> buf.length - 1 << 3);
      t <<= 8L;
    } 
    return buf;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXAuthentication.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */