/*     */ package com.intel.bluetooth.obex;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class OBEXUtils
/*     */ {
/*     */   static void readFully(InputStream is, OBEXConnectionParams obexConnectionParams, byte[] b) throws IOException, EOFException {
/*  44 */     readFully(is, obexConnectionParams, b, 0, b.length);
/*     */   }
/*     */ 
/*     */   
/*     */   static void readFully(InputStream is, OBEXConnectionParams obexConnectionParams, byte[] b, int off, int len) throws IOException, EOFException {
/*  49 */     if (len < 0) {
/*  50 */       throw new IndexOutOfBoundsException();
/*     */     }
/*  52 */     int got = 0;
/*  53 */     while (got < len) {
/*  54 */       if (obexConnectionParams.timeouts) {
/*  55 */         long endOfDellay = System.currentTimeMillis() + obexConnectionParams.timeout;
/*  56 */         int available = 0;
/*     */         do {
/*  58 */           available = is.available();
/*  59 */           if (available != 0)
/*  60 */             continue;  if (System.currentTimeMillis() > endOfDellay) {
/*  61 */             throw new InterruptedIOException("OBEX read timeout; received " + got + " form " + len + " expected");
/*     */           }
/*     */           try {
/*  64 */             Thread.sleep(100L);
/*  65 */           } catch (InterruptedException e) {
/*  66 */             throw new InterruptedIOException();
/*     */           }
/*     */         
/*  69 */         } while (available == 0);
/*     */       } 
/*  71 */       int rc = is.read(b, off + got, len - got);
/*  72 */       if (rc < 0) {
/*  73 */         throw new EOFException("EOF while reading OBEX packet; received " + got + " form " + len + " expected");
/*     */       }
/*  75 */       got += rc;
/*     */     } 
/*     */   }
/*     */   
/*     */   static String newStringUTF16Simple(byte[] bytes) throws UnsupportedEncodingException {
/*  80 */     StringBuffer buf = new StringBuffer();
/*  81 */     for (int i = 0; i < bytes.length; i += 2) {
/*  82 */       buf.append((char)bytesToShort(bytes[i], bytes[i + 1]));
/*     */     }
/*  84 */     return buf.toString();
/*     */   }
/*     */   
/*     */   static String newStringUTF16(byte[] bytes) throws UnsupportedEncodingException {
/*     */     try {
/*  89 */       return new String(bytes, "UTF-16BE");
/*  90 */     } catch (IllegalArgumentException e) {
/*     */       
/*  92 */       return newStringUTF16Simple(bytes);
/*  93 */     } catch (UnsupportedEncodingException e) {
/*     */       
/*  95 */       return newStringUTF16Simple(bytes);
/*     */     } 
/*     */   }
/*     */   
/*     */   static byte[] getUTF16BytesSimple(String str) throws UnsupportedEncodingException {
/* 100 */     ByteArrayOutputStream buf = new ByteArrayOutputStream();
/* 101 */     int len = str.length();
/* 102 */     for (int i = 0; i < len; i++) {
/* 103 */       char c = str.charAt(i);
/* 104 */       buf.write(hiByte(c));
/* 105 */       buf.write(loByte(c));
/*     */     } 
/* 107 */     return buf.toByteArray();
/*     */   }
/*     */   
/*     */   static byte[] getUTF16Bytes(String str) throws UnsupportedEncodingException {
/*     */     try {
/* 112 */       return str.getBytes("UTF-16BE");
/* 113 */     } catch (IllegalArgumentException e) {
/*     */       
/* 115 */       return getUTF16BytesSimple(str);
/* 116 */     } catch (UnsupportedEncodingException e) {
/*     */       
/* 118 */       return getUTF16BytesSimple(str);
/*     */     } 
/*     */   }
/*     */   
/*     */   static byte hiByte(int value) {
/* 123 */     return (byte)(value >> 8 & 0xFF);
/*     */   }
/*     */   
/*     */   static byte loByte(int value) {
/* 127 */     return (byte)(0xFF & value);
/*     */   }
/*     */   
/*     */   static int bytesToShort(byte valueHi, byte valueLo) {
/* 131 */     return (valueHi << 8 & 0xFF00) + (valueLo & 0xFF);
/*     */   }
/*     */   
/*     */   public static String toStringObexResponseCodes(byte code) {
/* 135 */     return toStringObexResponseCodes(code & 0xFF);
/*     */   }
/*     */   
/*     */   public static String toStringObexResponseCodes(int code) {
/* 139 */     switch (code) {
/*     */       case 128:
/* 141 */         return "CONNECT";
/*     */       case 129:
/* 143 */         return "DISCONNECT";
/*     */       case 255:
/* 145 */         return "ABORT";
/*     */       case 7:
/* 147 */         return "SESSION";
/*     */       case 135:
/* 149 */         return "SESSION FINAL";
/*     */       case 2:
/* 151 */         return "PUT";
/*     */       case 130:
/* 153 */         return "PUT FINAL";
/*     */       case 3:
/* 155 */         return "GET";
/*     */       case 131:
/* 157 */         return "GET FINAL";
/*     */       case 5:
/* 159 */         return "SETPATH";
/*     */       case 133:
/* 161 */         return "SETPATH FINAL";
/*     */       case 144:
/* 163 */         return "OBEX_RESPONSE_CONTINUE";
/*     */       case 160:
/* 165 */         return "OBEX_HTTP_OK";
/*     */       case 161:
/* 167 */         return "OBEX_HTTP_CREATED";
/*     */       case 162:
/* 169 */         return "OBEX_HTTP_ACCEPTED";
/*     */       case 163:
/* 171 */         return "OBEX_HTTP_NOT_AUTHORITATIVE";
/*     */       case 164:
/* 173 */         return "OBEX_HTTP_NO_CONTENT";
/*     */       case 165:
/* 175 */         return "OBEX_HTTP_RESET";
/*     */       case 166:
/* 177 */         return "OBEX_HTTP_PARTIAL";
/*     */       case 176:
/* 179 */         return "OBEX_HTTP_MULT_CHOICE";
/*     */       case 177:
/* 181 */         return "OBEX_HTTP_MOVED_PERM";
/*     */       case 178:
/* 183 */         return "OBEX_HTTP_MOVED_TEMP";
/*     */       case 179:
/* 185 */         return "OBEX_HTTP_SEE_OTHER";
/*     */       case 180:
/* 187 */         return "OBEX_HTTP_NOT_MODIFIED";
/*     */       case 181:
/* 189 */         return "OBEX_HTTP_USE_PROXY";
/*     */       case 192:
/* 191 */         return "OBEX_HTTP_BAD_REQUEST";
/*     */       case 193:
/* 193 */         return "OBEX_HTTP_UNAUTHORIZED";
/*     */       case 194:
/* 195 */         return "OBEX_HTTP_PAYMENT_REQUIRED";
/*     */       case 195:
/* 197 */         return "OBEX_HTTP_FORBIDDEN";
/*     */       case 196:
/* 199 */         return "OBEX_HTTP_NOT_FOUND";
/*     */       case 197:
/* 201 */         return "OBEX_HTTP_BAD_METHOD";
/*     */       case 198:
/* 203 */         return "OBEX_HTTP_NOT_ACCEPTABLE";
/*     */       case 199:
/* 205 */         return "OBEX_HTTP_PROXY_AUTH";
/*     */       case 200:
/* 207 */         return "OBEX_HTTP_TIMEOUT";
/*     */       case 201:
/* 209 */         return "OBEX_HTTP_CONFLICT";
/*     */       case 202:
/* 211 */         return "OBEX_HTTP_GONE";
/*     */       case 203:
/* 213 */         return "OBEX_HTTP_LENGTH_REQUIRED";
/*     */       case 204:
/* 215 */         return "OBEX_HTTP_PRECON_FAILED";
/*     */       case 205:
/* 217 */         return "OBEX_HTTP_ENTITY_TOO_LARGE";
/*     */       case 206:
/* 219 */         return "OBEX_HTTP_REQ_TOO_LARGE";
/*     */       case 207:
/* 221 */         return "OBEX_HTTP_UNSUPPORTED_TYPE";
/*     */       case 208:
/* 223 */         return "OBEX_HTTP_INTERNAL_ERROR";
/*     */       case 209:
/* 225 */         return "OBEX_HTTP_NOT_IMPLEMENTED";
/*     */       case 210:
/* 227 */         return "OBEX_HTTP_BAD_GATEWAY";
/*     */       case 211:
/* 229 */         return "OBEX_HTTP_UNAVAILABLE";
/*     */       case 212:
/* 231 */         return "OBEX_HTTP_GATEWAY_TIMEOUT";
/*     */       case 213:
/* 233 */         return "OBEX_HTTP_VERSION";
/*     */       case 224:
/* 235 */         return "OBEX_DATABASE_FULL";
/*     */       case 225:
/* 237 */         return "OBEX_DATABASE_LOCKED";
/*     */     } 
/* 239 */     return "Unknown 0x" + Integer.toHexString(code);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */