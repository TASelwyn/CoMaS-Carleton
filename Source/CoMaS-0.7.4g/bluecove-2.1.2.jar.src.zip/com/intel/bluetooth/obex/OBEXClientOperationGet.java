/*    */ package com.intel.bluetooth.obex;
/*    */ 
/*    */ import com.intel.bluetooth.DebugLog;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OBEXClientOperationGet
/*    */   extends OBEXClientOperation
/*    */ {
/*    */   OBEXClientOperationGet(OBEXClientSessionImpl session, OBEXHeaderSetImpl sendHeaders) throws IOException {
/* 36 */     super(session, '\003', sendHeaders);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InputStream openInputStream() throws IOException {
/* 45 */     validateOperationIsOpen();
/* 46 */     if (this.inputStreamOpened) {
/* 47 */       throw new IOException("input stream already open");
/*    */     }
/* 49 */     DebugLog.debug("openInputStream");
/* 50 */     this.inputStreamOpened = true;
/* 51 */     endRequestPhase();
/* 52 */     return this.inputStream;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public OutputStream openOutputStream() throws IOException {
/* 61 */     validateOperationIsOpen();
/* 62 */     if (this.outputStreamOpened) {
/* 63 */       throw new IOException("output already open");
/*    */     }
/* 65 */     if (this.requestEnded) {
/* 66 */       throw new IOException("the request phase has already ended");
/*    */     }
/* 68 */     this.outputStreamOpened = true;
/* 69 */     this.outputStream = new OBEXOperationOutputStream(this.session.mtu, this);
/* 70 */     return this.outputStream;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\obex\OBEXClientOperationGet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */