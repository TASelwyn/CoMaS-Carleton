/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BluetoothRFCommInputStream
/*     */   extends InputStream
/*     */ {
/*     */   private volatile BluetoothRFCommConnection conn;
/*     */   
/*     */   public BluetoothRFCommInputStream(BluetoothRFCommConnection conn) {
/*  34 */     this.conn = conn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int available() throws IOException {
/*  43 */     if (this.conn == null) {
/*  44 */       throw new IOException("Stream closed");
/*     */     }
/*  46 */     return this.conn.bluetoothStack.connectionRfReadAvailable(this.conn.handle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/*  63 */     if (this.conn == null) {
/*  64 */       throw new IOException("Stream closed");
/*     */     }
/*     */     try {
/*  67 */       return this.conn.bluetoothStack.connectionRfRead(this.conn.handle);
/*  68 */     } catch (IOException e) {
/*  69 */       if (isClosed()) {
/*  70 */         return -1;
/*     */       }
/*  72 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 126 */     if (off < 0 || len < 0 || off + len > b.length) {
/* 127 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */     
/* 130 */     if (this.conn == null) {
/* 131 */       throw new IOException("Stream closed");
/*     */     }
/* 133 */     if (len == 0)
/*     */     {
/* 135 */       return 0;
/*     */     }
/*     */     
/*     */     try {
/* 139 */       return this.conn.bluetoothStack.connectionRfRead(this.conn.handle, b, off, len);
/* 140 */     } catch (IOException e) {
/* 141 */       if (isClosed()) {
/* 142 */         return -1;
/*     */       }
/* 144 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 161 */     BluetoothRFCommConnection c = this.conn;
/* 162 */     if (c != null) {
/* 163 */       this.conn = null;
/* 164 */       c.streamClosed();
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean isClosed() {
/* 169 */     return (this.conn == null);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothRFCommInputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */