package com.intel.bluetooth;

import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DiscoveryListener;
import javax.bluetooth.RemoteDevice;
import javax.bluetooth.UUID;

interface SearchServicesRunnable {
  int runSearchServices(SearchServicesThread paramSearchServicesThread, int[] paramArrayOfint, UUID[] paramArrayOfUUID, RemoteDevice paramRemoteDevice, DiscoveryListener paramDiscoveryListener) throws BluetoothStateException;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\SearchServicesRunnable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */