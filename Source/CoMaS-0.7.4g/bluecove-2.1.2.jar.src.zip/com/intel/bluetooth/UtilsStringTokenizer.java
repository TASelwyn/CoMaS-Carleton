/*    */ package com.intel.bluetooth;
/*    */ 
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class UtilsStringTokenizer
/*    */ {
/*    */   private int currentPosition;
/*    */   private int newPosition;
/*    */   private String str;
/*    */   private String delimiter;
/*    */   
/*    */   public UtilsStringTokenizer(String str, String delimiter) {
/* 54 */     this.str = str;
/* 55 */     this.delimiter = delimiter;
/* 56 */     this.currentPosition = 0;
/* 57 */     nextPosition();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean hasMoreTokens() {
/* 64 */     return (this.newPosition != -1 && this.currentPosition < this.newPosition);
/*    */   }
/*    */   
/*    */   private void nextPosition() {
/* 68 */     this.newPosition = this.str.indexOf(this.delimiter, this.currentPosition);
/* 69 */     if (this.newPosition == -1) {
/* 70 */       this.newPosition = this.str.length();
/* 71 */     } else if (this.newPosition == this.currentPosition) {
/*    */       
/* 73 */       this.currentPosition++;
/* 74 */       nextPosition();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String nextToken() throws NoSuchElementException {
/* 85 */     if (!hasMoreTokens()) {
/* 86 */       throw new NoSuchElementException();
/*    */     }
/*    */     
/* 89 */     String next = this.str.substring(this.currentPosition, this.newPosition);
/*    */     
/* 91 */     this.currentPosition = this.newPosition + 1;
/* 92 */     nextPosition();
/* 93 */     return next;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\UtilsStringTokenizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */