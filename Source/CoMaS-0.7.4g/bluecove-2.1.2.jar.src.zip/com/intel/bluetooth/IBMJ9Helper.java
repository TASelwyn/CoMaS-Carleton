package com.intel.bluetooth;

import com.ibm.oti.vm.VM;
import java.io.IOException;

class IBMJ9Helper {
  static synchronized void loadLibrary(String libname) throws IOException {
    VM.loadLibrary(libname);
  }
  
  static void addShutdownClass(Runnable hook) {
    VM.addShutdownClass(hook);
  }
}
