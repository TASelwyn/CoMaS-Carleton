package com.intel.bluetooth.btgoep;

import com.ibm.oti.connection.CreateConnection;
import com.intel.bluetooth.BluetoothConnectionAccess;
import com.intel.bluetooth.BluetoothConnectionAccessAdapter;
import com.intel.bluetooth.BluetoothConnectionNotifierServiceRecordAccess;
import com.intel.bluetooth.MicroeditionConnector;
import java.io.IOException;
import javax.bluetooth.ServiceRecord;
import javax.bluetooth.ServiceRegistrationException;
import javax.obex.Authenticator;
import javax.obex.ClientSession;
import javax.obex.HeaderSet;
import javax.obex.Operation;
import javax.obex.ServerRequestHandler;
import javax.obex.SessionNotifier;

public class Connection extends BluetoothConnectionAccessAdapter implements CreateConnection, ClientSession, SessionNotifier, BluetoothConnectionNotifierServiceRecordAccess {
  private javax.microedition.io.Connection impl = null;
  
  public void setParameters(String spec, int access, boolean timeout) throws IOException {
    this.impl = MicroeditionConnector.open("btgoep:" + spec, access, timeout);
  }
  
  public javax.microedition.io.Connection setParameters2(String spec, int access, boolean timeout) throws IOException {
    setParameters(spec, access, timeout);
    return (javax.microedition.io.Connection)this;
  }
  
  protected BluetoothConnectionAccess getImpl() {
    return (BluetoothConnectionAccess)this.impl;
  }
  
  public void close() throws IOException {
    this.impl.close();
  }
  
  public HeaderSet connect(HeaderSet headers) throws IOException {
    return ((ClientSession)this.impl).connect(headers);
  }
  
  public HeaderSet createHeaderSet() {
    return ((ClientSession)this.impl).createHeaderSet();
  }
  
  public HeaderSet delete(HeaderSet headers) throws IOException {
    return ((ClientSession)this.impl).delete(headers);
  }
  
  public HeaderSet disconnect(HeaderSet headers) throws IOException {
    return ((ClientSession)this.impl).disconnect(headers);
  }
  
  public Operation get(HeaderSet headers) throws IOException {
    return ((ClientSession)this.impl).get(headers);
  }
  
  public long getConnectionID() {
    return ((ClientSession)this.impl).getConnectionID();
  }
  
  public Operation put(HeaderSet headers) throws IOException {
    return ((ClientSession)this.impl).put(headers);
  }
  
  public void setAuthenticator(Authenticator auth) {
    ((ClientSession)this.impl).setAuthenticator(auth);
  }
  
  public void setConnectionID(long id) {
    ((ClientSession)this.impl).setConnectionID(id);
  }
  
  public HeaderSet setPath(HeaderSet headers, boolean backup, boolean create) throws IOException {
    return ((ClientSession)this.impl).setPath(headers, backup, create);
  }
  
  public javax.microedition.io.Connection acceptAndOpen(ServerRequestHandler handler) throws IOException {
    return ((SessionNotifier)this.impl).acceptAndOpen(handler);
  }
  
  public javax.microedition.io.Connection acceptAndOpen(ServerRequestHandler handler, Authenticator auth) throws IOException {
    return ((SessionNotifier)this.impl).acceptAndOpen(handler, auth);
  }
  
  public ServiceRecord getServiceRecord() {
    return ((BluetoothConnectionNotifierServiceRecordAccess)this.impl).getServiceRecord();
  }
  
  public void updateServiceRecord(boolean acceptAndOpen) throws ServiceRegistrationException {
    ((BluetoothConnectionNotifierServiceRecordAccess)this.impl).updateServiceRecord(acceptAndOpen);
  }
}
