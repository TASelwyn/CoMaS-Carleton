/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ import java.util.WeakHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WeakVectorFactory
/*     */ {
/*     */   public static interface WeakVector
/*     */   {
/*     */     void addElement(Object param1Object);
/*     */     
/*     */     int size();
/*     */     
/*     */     boolean removeElement(Object param1Object);
/*     */     
/*     */     boolean contains(Object param1Object);
/*     */     
/*     */     Object firstElement();
/*     */     
/*     */     Enumeration elements();
/*     */     
/*     */     void removeAllElements();
/*     */   }
/*     */   
/*     */   public static WeakVector createWeakVector() {
/*     */     try {
/*  62 */       return new WeakVectorOnWeakHashMapImpl();
/*  63 */     } catch (Throwable e) {
/*  64 */       return new WeakVectorOnVectorImpl();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class WeakVectorOnVectorImpl
/*     */     implements WeakVector
/*     */   {
/*  73 */     private Vector vectorImpl = new Vector();
/*     */ 
/*     */     
/*     */     public void addElement(Object obj) {
/*  77 */       this.vectorImpl.addElement(obj);
/*     */     }
/*     */     
/*     */     public boolean contains(Object elem) {
/*  81 */       return this.vectorImpl.contains(elem);
/*     */     }
/*     */     
/*     */     public Object firstElement() {
/*  85 */       return this.vectorImpl.firstElement();
/*     */     }
/*     */     
/*     */     public Enumeration elements() {
/*  89 */       return this.vectorImpl.elements();
/*     */     }
/*     */     
/*     */     public boolean removeElement(Object obj) {
/*  93 */       return this.vectorImpl.removeElement(obj);
/*     */     }
/*     */     
/*     */     public int size() {
/*  97 */       return this.vectorImpl.size();
/*     */     }
/*     */     
/*     */     public void removeAllElements() {
/* 101 */       this.vectorImpl.removeAllElements();
/*     */     }
/*     */     
/*     */     private WeakVectorOnVectorImpl() {}
/*     */   }
/*     */   
/*     */   private static class WeakVectorOnWeakHashMapImpl
/*     */     implements WeakVector {
/*     */     private WeakHashMap mapImpl;
/*     */     
/*     */     private static class EnumerationAdapter implements Enumeration {
/*     */       Iterator iterator;
/*     */       
/*     */       public EnumerationAdapter(Iterator iterator) {
/* 115 */         this.iterator = iterator;
/*     */       }
/*     */       
/*     */       public boolean hasMoreElements() {
/* 119 */         return this.iterator.hasNext();
/*     */       }
/*     */       
/*     */       public Object nextElement() {
/* 123 */         return this.iterator.next();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     private WeakVectorOnWeakHashMapImpl() {
/* 129 */       this.mapImpl = new WeakHashMap();
/*     */     }
/*     */ 
/*     */     
/*     */     public void addElement(Object obj) {
/* 134 */       this.mapImpl.put(obj, new Object());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean contains(Object elem) {
/* 139 */       return this.mapImpl.containsKey(elem);
/*     */     }
/*     */     
/*     */     public Object firstElement() {
/* 143 */       return this.mapImpl.keySet().iterator().next();
/*     */     }
/*     */     
/*     */     public Enumeration elements() {
/* 147 */       return new EnumerationAdapter(this.mapImpl.keySet().iterator());
/*     */     }
/*     */     
/*     */     public boolean removeElement(Object obj) {
/* 151 */       return (this.mapImpl.remove(obj) != null);
/*     */     }
/*     */     
/*     */     public int size() {
/* 155 */       return this.mapImpl.size();
/*     */     }
/*     */     
/*     */     public void removeAllElements() {
/* 159 */       this.mapImpl.clear();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\WeakVectorFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */