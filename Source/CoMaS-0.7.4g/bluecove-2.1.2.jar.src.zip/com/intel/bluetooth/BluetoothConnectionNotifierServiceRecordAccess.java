package com.intel.bluetooth;

import javax.bluetooth.ServiceRecord;
import javax.bluetooth.ServiceRegistrationException;

public interface BluetoothConnectionNotifierServiceRecordAccess {
  ServiceRecord getServiceRecord();
  
  void updateServiceRecord(boolean paramBoolean) throws ServiceRegistrationException;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothConnectionNotifierServiceRecordAccess.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */