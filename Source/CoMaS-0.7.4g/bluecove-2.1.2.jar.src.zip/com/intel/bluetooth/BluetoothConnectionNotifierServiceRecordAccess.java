package com.intel.bluetooth;

import javax.bluetooth.ServiceRecord;
import javax.bluetooth.ServiceRegistrationException;

public interface BluetoothConnectionNotifierServiceRecordAccess {
  ServiceRecord getServiceRecord();
  
  void updateServiceRecord(boolean paramBoolean) throws ServiceRegistrationException;
}
