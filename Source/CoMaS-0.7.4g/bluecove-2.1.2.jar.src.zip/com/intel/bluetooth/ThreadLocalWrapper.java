/*    */ package com.intel.bluetooth;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ThreadLocalWrapper
/*    */ {
/*    */   static boolean java11 = false;
/*    */   private Object threadLocal;
/*    */   private Object java11Object;
/*    */   
/*    */   ThreadLocalWrapper() {
/* 41 */     if (java11) {
/*    */       return;
/*    */     }
/*    */     try {
/* 45 */       this.threadLocal = new ThreadLocal();
/* 46 */     } catch (Throwable ejava11) {
/* 47 */       java11 = true;
/*    */     } 
/*    */   }
/*    */   
/*    */   public Object get() {
/* 52 */     if (java11) {
/* 53 */       return this.java11Object;
/*    */     }
/* 55 */     return ((ThreadLocal)this.threadLocal).get();
/*    */   }
/*    */ 
/*    */   
/*    */   public void set(Object value) {
/* 60 */     if (java11) {
/* 61 */       this.java11Object = value;
/*    */     } else {
/* 63 */       ((ThreadLocal)this.threadLocal).set(value);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\ThreadLocalWrapper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */