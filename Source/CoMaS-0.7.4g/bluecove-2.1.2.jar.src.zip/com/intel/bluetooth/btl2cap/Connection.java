/*     */ package com.intel.bluetooth.btl2cap;
/*     */ 
/*     */ import com.ibm.oti.connection.CreateConnection;
/*     */ import com.intel.bluetooth.BluetoothConnectionAccess;
/*     */ import com.intel.bluetooth.BluetoothConnectionAccessAdapter;
/*     */ import com.intel.bluetooth.BluetoothConnectionNotifierServiceRecordAccess;
/*     */ import com.intel.bluetooth.MicroeditionConnector;
/*     */ import java.io.IOException;
/*     */ import javax.bluetooth.L2CAPConnection;
/*     */ import javax.bluetooth.L2CAPConnectionNotifier;
/*     */ import javax.bluetooth.ServiceRecord;
/*     */ import javax.bluetooth.ServiceRegistrationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Connection
/*     */   extends BluetoothConnectionAccessAdapter
/*     */   implements CreateConnection, L2CAPConnection, L2CAPConnectionNotifier, BluetoothConnectionNotifierServiceRecordAccess
/*     */ {
/*  57 */   javax.microedition.io.Connection impl = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BluetoothConnectionAccess getImpl() {
/*  66 */     return (BluetoothConnectionAccess)this.impl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameters(String spec, int access, boolean timeout) throws IOException {
/*  76 */     this.impl = MicroeditionConnector.open("btl2cap:" + spec, access, timeout);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public javax.microedition.io.Connection setParameters2(String spec, int access, boolean timeout) throws IOException {
/*  86 */     setParameters(spec, access, timeout);
/*  87 */     return (javax.microedition.io.Connection)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  96 */     this.impl.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getReceiveMTU() throws IOException {
/* 105 */     return ((L2CAPConnection)this.impl).getReceiveMTU();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTransmitMTU() throws IOException {
/* 114 */     return ((L2CAPConnection)this.impl).getTransmitMTU();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean ready() throws IOException {
/* 123 */     return ((L2CAPConnection)this.impl).ready();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int receive(byte[] inBuf) throws IOException {
/* 132 */     return ((L2CAPConnection)this.impl).receive(inBuf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(byte[] data) throws IOException {
/* 141 */     ((L2CAPConnection)this.impl).send(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public L2CAPConnection acceptAndOpen() throws IOException {
/* 150 */     return ((L2CAPConnectionNotifier)this.impl).acceptAndOpen();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceRecord getServiceRecord() {
/* 159 */     return ((BluetoothConnectionNotifierServiceRecordAccess)this.impl).getServiceRecord();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateServiceRecord(boolean acceptAndOpen) throws ServiceRegistrationException {
/* 168 */     ((BluetoothConnectionNotifierServiceRecordAccess)this.impl).updateServiceRecord(acceptAndOpen);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\btl2cap\Connection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */