/*     */ package com.intel.bluetooth.gcf.socket;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.Socket;
/*     */ import javax.microedition.io.SocketConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SocketConnection
/*     */   implements SocketConnection
/*     */ {
/*     */   protected Socket socket;
/*     */   
/*     */   public SocketConnection() {}
/*     */   
/*     */   public SocketConnection(String host, int port) throws IOException {
/*  42 */     this.socket = new Socket(host, port);
/*     */   }
/*     */   
/*     */   public SocketConnection(Socket socket) {
/*  46 */     this.socket = socket;
/*     */   }
/*     */   
/*     */   public String getAddress() throws IOException {
/*  50 */     if (this.socket == null || this.socket.isClosed()) {
/*  51 */       throw new IOException();
/*     */     }
/*     */     
/*  54 */     return this.socket.getInetAddress().toString();
/*     */   }
/*     */   
/*     */   public String getLocalAddress() throws IOException {
/*  58 */     if (this.socket == null || this.socket.isClosed()) {
/*  59 */       throw new IOException();
/*     */     }
/*     */     
/*  62 */     return this.socket.getLocalAddress().toString();
/*     */   }
/*     */   
/*     */   public int getLocalPort() throws IOException {
/*  66 */     if (this.socket == null || this.socket.isClosed()) {
/*  67 */       throw new IOException();
/*     */     }
/*     */     
/*  70 */     return this.socket.getLocalPort();
/*     */   }
/*     */   
/*     */   public int getPort() throws IOException {
/*  74 */     if (this.socket == null || this.socket.isClosed()) {
/*  75 */       throw new IOException();
/*     */     }
/*     */     
/*  78 */     return this.socket.getPort();
/*     */   }
/*     */   
/*     */   public int getSocketOption(byte option) throws IllegalArgumentException, IOException {
/*     */     int value;
/*  83 */     if (this.socket != null && this.socket.isClosed()) {
/*  84 */       throw new IOException();
/*     */     }
/*  86 */     switch (option) {
/*     */       case 0:
/*  88 */         if (this.socket.getTcpNoDelay()) {
/*  89 */           return 1;
/*     */         }
/*  91 */         return 0;
/*     */       
/*     */       case 1:
/*  94 */         value = this.socket.getSoLinger();
/*  95 */         if (value == -1) {
/*  96 */           return 0;
/*     */         }
/*  98 */         return value;
/*     */       
/*     */       case 2:
/* 101 */         if (this.socket.getKeepAlive()) {
/* 102 */           return 1;
/*     */         }
/* 104 */         return 0;
/*     */       
/*     */       case 3:
/* 107 */         return this.socket.getReceiveBufferSize();
/*     */       case 4:
/* 109 */         return this.socket.getSendBufferSize();
/*     */     } 
/* 111 */     throw new IllegalArgumentException();
/*     */   }
/*     */   
/*     */   public void setSocketOption(byte option, int value) throws IllegalArgumentException, IOException {
/*     */     int delay;
/*     */     int keepalive;
/* 117 */     if (this.socket.isClosed()) {
/* 118 */       throw new IOException();
/*     */     }
/* 120 */     switch (option) {
/*     */       
/*     */       case 0:
/* 123 */         if (value == 0) {
/* 124 */           delay = 0;
/*     */         } else {
/* 126 */           delay = 1;
/*     */         } 
/* 128 */         this.socket.setTcpNoDelay(!(delay == 0));
/*     */         return;
/*     */       case 1:
/* 131 */         if (value < 0) {
/* 132 */           throw new IllegalArgumentException();
/*     */         }
/* 134 */         this.socket.setSoLinger(!(value == 0), value);
/*     */         return;
/*     */       
/*     */       case 2:
/* 138 */         if (value == 0) {
/* 139 */           keepalive = 0;
/*     */         } else {
/* 141 */           keepalive = 1;
/*     */         } 
/* 143 */         this.socket.setKeepAlive(!(keepalive == 0));
/*     */         return;
/*     */       case 3:
/* 146 */         if (value <= 0) {
/* 147 */           throw new IllegalArgumentException();
/*     */         }
/* 149 */         this.socket.setReceiveBufferSize(value);
/*     */         return;
/*     */       case 4:
/* 152 */         if (value <= 0) {
/* 153 */           throw new IllegalArgumentException();
/*     */         }
/* 155 */         this.socket.setSendBufferSize(value);
/*     */         return;
/*     */     } 
/* 158 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 165 */     this.socket.close();
/*     */   }
/*     */   
/*     */   public InputStream openInputStream() throws IOException {
/* 169 */     return this.socket.getInputStream();
/*     */   }
/*     */   
/*     */   public DataInputStream openDataInputStream() throws IOException {
/* 173 */     return new DataInputStream(openInputStream());
/*     */   }
/*     */   
/*     */   public OutputStream openOutputStream() throws IOException {
/* 177 */     return this.socket.getOutputStream();
/*     */   }
/*     */   
/*     */   public DataOutputStream openDataOutputStream() throws IOException {
/* 181 */     return new DataOutputStream(openOutputStream());
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\gcf\socket\SocketConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */