package com.intel.bluetooth.gcf.socket;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import javax.microedition.io.ServerSocketConnection;
import javax.microedition.io.StreamConnection;

public class ServerSocketConnection implements ServerSocketConnection {
  private ServerSocket serverSocket;
  
  public ServerSocketConnection(int port) throws IOException {
    this.serverSocket = new ServerSocket(port);
  }
  
  public String getLocalAddress() throws IOException {
    InetAddress localHost = InetAddress.getLocalHost();
    return localHost.getHostAddress();
  }
  
  public int getLocalPort() throws IOException {
    return this.serverSocket.getLocalPort();
  }
  
  public StreamConnection acceptAndOpen() throws IOException {
    return (StreamConnection)new SocketConnection(this.serverSocket.accept());
  }
  
  public void close() throws IOException {
    this.serverSocket.close();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\gcf\socket\ServerSocketConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */