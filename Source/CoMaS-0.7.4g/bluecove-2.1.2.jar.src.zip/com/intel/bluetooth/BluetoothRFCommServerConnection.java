package com.intel.bluetooth;

import java.io.IOException;

class BluetoothRFCommServerConnection extends BluetoothRFCommConnection implements BluetoothServerConnection {
  protected BluetoothRFCommServerConnection(BluetoothStack bluetoothStack, long handle, int securityOpt) throws IOException {
    super(bluetoothStack, handle);
    boolean initOK = false;
    try {
      this.securityOpt = securityOpt;
      RemoteDeviceHelper.connected(this);
      initOK = true;
    } finally {
      if (!initOK)
        try {
          bluetoothStack.connectionRfCloseServerConnection(this.handle);
        } catch (IOException e) {
          DebugLog.error("close error", e);
        }  
    } 
  }
  
  void closeConnectionHandle(long handle) throws IOException {
    RemoteDeviceHelper.disconnected(this);
    this.bluetoothStack.connectionRfCloseServerConnection(handle);
  }
}
