/*    */ package com.intel.bluetooth;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BluetoothRFCommServerConnection
/*    */   extends BluetoothRFCommConnection
/*    */   implements BluetoothServerConnection
/*    */ {
/*    */   protected BluetoothRFCommServerConnection(BluetoothStack bluetoothStack, long handle, int securityOpt) throws IOException {
/* 38 */     super(bluetoothStack, handle);
/* 39 */     boolean initOK = false;
/*    */     try {
/* 41 */       this.securityOpt = securityOpt;
/* 42 */       RemoteDeviceHelper.connected(this);
/* 43 */       initOK = true;
/*    */     } finally {
/* 45 */       if (!initOK) {
/*    */         try {
/* 47 */           bluetoothStack.connectionRfCloseServerConnection(this.handle);
/* 48 */         } catch (IOException e) {
/* 49 */           DebugLog.error("close error", e);
/*    */         } 
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   void closeConnectionHandle(long handle) throws IOException {
/* 56 */     RemoteDeviceHelper.disconnected(this);
/* 57 */     this.bluetoothStack.connectionRfCloseServerConnection(handle);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothRFCommServerConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */