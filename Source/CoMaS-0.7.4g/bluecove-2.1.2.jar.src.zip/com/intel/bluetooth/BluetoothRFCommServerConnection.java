package com.intel.bluetooth;

import java.io.IOException;

class BluetoothRFCommServerConnection extends BluetoothRFCommConnection implements BluetoothServerConnection {
  protected BluetoothRFCommServerConnection(BluetoothStack bluetoothStack, long handle, int securityOpt) throws IOException {
    super(bluetoothStack, handle);
    boolean initOK = false;
    try {
      this.securityOpt = securityOpt;
      RemoteDeviceHelper.connected(this);
      initOK = true;
    } finally {
      if (!initOK)
        try {
          bluetoothStack.connectionRfCloseServerConnection(this.handle);
        } catch (IOException e) {
          DebugLog.error("close error", e);
        }  
    } 
  }
  
  void closeConnectionHandle(long handle) throws IOException {
    RemoteDeviceHelper.disconnected(this);
    this.bluetoothStack.connectionRfCloseServerConnection(handle);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothRFCommServerConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */