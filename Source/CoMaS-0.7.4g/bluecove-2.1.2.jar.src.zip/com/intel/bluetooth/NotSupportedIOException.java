package com.intel.bluetooth;

import java.io.IOException;

public class NotSupportedIOException extends IOException {
  private static final long serialVersionUID = 1L;
  
  public NotSupportedIOException() {
    super("Not Supported");
  }
  
  public NotSupportedIOException(String stackName) {
    super("Not Supported on " + stackName);
  }
}
