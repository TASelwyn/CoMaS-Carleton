package com.intel.bluetooth;

import java.security.AccessControlContext;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.bluetooth.BluetoothStateException;

public class BlueCoveImpl {
  public static final String BLUETOOTH_API_VERSION = "1.1.1";
  
  public static final String OBEX_API_VERSION = "1.1.1";
  
  public static final int versionMajor1 = 2;
  
  public static final int versionMajor2 = 1;
  
  public static final int versionMinor = 1;
  
  public static final int versionBuild = 0;
  
  public static final String versionSufix = "-SNAPSHOT";
  
  public static final String version = String.valueOf(2) + "." + String.valueOf(1) + "." + String.valueOf(1) + "-SNAPSHOT";
  
  public static final int nativeLibraryVersionExpected = 2010100;
  
  public static final String STACK_WINSOCK = "winsock";
  
  public static final String STACK_WIDCOMM = "widcomm";
  
  public static final String STACK_BLUESOLEIL = "bluesoleil";
  
  public static final String STACK_TOSHIBA = "toshiba";
  
  public static final String STACK_BLUEZ = "bluez";
  
  public static final String STACK_BLUEZ_DBUS = "bluez-dbus";
  
  public static final String STACK_OSX = "mac";
  
  public static final String STACK_EMULATOR = "emulator";
  
  public static final String STACK_ANDROID_2_X = "android_2.x";
  
  private static final boolean oneDLLbuild = false;
  
  public static final String NATIVE_LIB_MS = "intelbth";
  
  public static final String NATIVE_LIB_WIDCOMM = "bluecove";
  
  public static final String NATIVE_LIB_TOSHIBA = "bluecove";
  
  public static final String NATIVE_LIB_BLUEZ = "bluecove";
  
  public static final String NATIVE_LIB_OSX = "bluecove";
  
  public static final String NATIVE_LIB_BLUESOLEIL = "intelbth";
  
  static final int BLUECOVE_STACK_DETECT_MICROSOFT = 1;
  
  static final int BLUECOVE_STACK_DETECT_WIDCOMM = 2;
  
  static final int BLUECOVE_STACK_DETECT_BLUESOLEIL = 4;
  
  static final int BLUECOVE_STACK_DETECT_TOSHIBA = 8;
  
  static final int BLUECOVE_STACK_DETECT_OSX = 16;
  
  public static final int BLUECOVE_STACK_DETECT_BLUEZ = 32;
  
  public static final int BLUECOVE_STACK_DETECT_EMULATOR = 64;
  
  public static final int BLUECOVE_STACK_DETECT_BLUEZ_DBUS = 128;
  
  public static final int BLUECOVE_STACK_DETECT_ANDROID_1_X = 256;
  
  public static final int BLUECOVE_STACK_DETECT_ANDROID_2_X = 512;
  
  static final String TRUE = "true";
  
  static final String FALSE = "false";
  
  private static final String FQCN = BlueCoveImpl.class.getName();
  
  private static final Vector fqcnSet = new Vector();
  
  private Object accessControlContext;
  
  private static ShutdownHookThread shutdownHookRegistered;
  
  private static BlueCoveImpl instance;
  
  private static BluetoothStackHolder singleStack;
  
  private static ThreadLocalWrapper threadStack;
  
  private static BluetoothStackHolder threadStackIDDefault;
  
  private static Hashtable resourceConfigProperties = new Hashtable();
  
  private static Hashtable stacks = new Hashtable();
  
  private static Vector initializationProperties = new Vector();
  
  static {
    fqcnSet.addElement(FQCN);
    for (int i = 0; i < BlueCoveConfigProperties.INITIALIZATION_PROPERTIES.length; i++)
      initializationProperties.addElement(BlueCoveConfigProperties.INITIALIZATION_PROPERTIES[i]); 
  }
  
  private static class BluetoothStackHolder {
    private BluetoothStack bluetoothStack;
    
    Hashtable configProperties = new Hashtable();
    
    private static BluetoothStack getBluetoothStack() throws BluetoothStateException {
      return BlueCoveImpl.instance().getBluetoothStack();
    }
    
    public String toString() {
      if (this.bluetoothStack == null)
        return "not initialized"; 
      return this.bluetoothStack.toString();
    }
    
    private BluetoothStackHolder() {}
  }
  
  private class AsynchronousShutdownThread extends Thread {
    final Object monitor;
    
    int shutdownStart;
    
    private final BlueCoveImpl this$0;
    
    AsynchronousShutdownThread(BlueCoveImpl this$0) {
      super("BluecoveAsynchronousShutdownThread");
      this.this$0 = this$0;
      this.monitor = new Object();
      this.shutdownStart = 0;
    }
    
    public void run() {
      synchronized (this.monitor) {
        while (this.shutdownStart == 0) {
          try {
            this.monitor.wait();
          } catch (InterruptedException e) {
            return;
          } 
        } 
      } 
      if (this.shutdownStart == -1)
        return; 
      if (!BlueCoveImpl.stacks.isEmpty()) {
        for (Enumeration en = BlueCoveImpl.stacks.elements(); en.hasMoreElements(); ) {
          BlueCoveImpl.BluetoothStackHolder s = en.nextElement();
          if (s.bluetoothStack != null)
            try {
              s.bluetoothStack.destroy();
            } finally {
              s.bluetoothStack = null;
            }  
        } 
        BlueCoveImpl.stacks.clear();
        System.out.println("BlueCove stack shutdown completed");
      } 
      synchronized (this.monitor) {
        this.monitor.notifyAll();
      } 
    }
    
    void deRegister() {
      this.shutdownStart = -1;
      synchronized (this.monitor) {
        this.monitor.notifyAll();
      } 
    }
  }
  
  private class ShutdownHookThread extends Thread {
    BlueCoveImpl.AsynchronousShutdownThread shutdownHookThread;
    
    private final BlueCoveImpl this$0;
    
    ShutdownHookThread(BlueCoveImpl this$0, BlueCoveImpl.AsynchronousShutdownThread shutdownHookThread) {
      super("BluecoveShutdownHookThread");
      this.this$0 = this$0;
      this.shutdownHookThread = shutdownHookThread;
    }
    
    public void run() {
      Object monitor = this.shutdownHookThread.monitor;
      synchronized (monitor) {
        this.shutdownHookThread.shutdownStart = 1;
        monitor.notifyAll();
        if (!BlueCoveImpl.stacks.isEmpty())
          try {
            monitor.wait(7000L);
          } catch (InterruptedException e) {} 
      } 
    }
    
    void deRegister() {
      BlueCoveImpl.shutdownHookRegistered = null;
      UtilsJavaSE.runtimeRemoveShutdownHook(this);
      this.shutdownHookThread.deRegister();
    }
  }
  
  public static synchronized BlueCoveImpl instance() {
    if (instance == null)
      instance = new BlueCoveImpl(); 
    return instance;
  }
  
  private BlueCoveImpl() {
    try {
      this.accessControlContext = AccessController.getContext();
    } catch (Throwable javaME) {}
    DebugLog.isDebugEnabled();
    copySystemProperties(null);
  }
  
  static int getNativeLibraryVersion() {
    return 2010100;
  }
  
  private synchronized void createShutdownHook() {
    if (shutdownHookRegistered != null)
      return; 
    AsynchronousShutdownThread shutdownHookThread = new AsynchronousShutdownThread(this);
    if (UtilsJavaSE.runtimeAddShutdownHook(shutdownHookRegistered = new ShutdownHookThread(this, shutdownHookThread))) {
      UtilsJavaSE.threadSetDaemon(shutdownHookThread);
      shutdownHookThread.start();
    } 
  }
  
  private int getStackId(String stack) {
    if ("widcomm".equalsIgnoreCase(stack))
      return 2; 
    if ("bluesoleil".equalsIgnoreCase(stack))
      return 4; 
    if ("toshiba".equalsIgnoreCase(stack))
      return 8; 
    if ("winsock".equalsIgnoreCase(stack))
      return 1; 
    if ("bluez".equalsIgnoreCase(stack))
      return 32; 
    if ("bluez-dbus".equalsIgnoreCase(stack))
      return 128; 
    if ("winsock".equalsIgnoreCase(stack))
      return 16; 
    if ("emulator".equalsIgnoreCase(stack))
      return 64; 
    return 0;
  }
  
  private Class loadStackClass(String classPropertyName, String classNamesDefault) throws BluetoothStateException {
    String classNames = getConfigProperty(classPropertyName);
    if (classNames == null)
      classNames = classNamesDefault; 
    UtilsStringTokenizer tok = new UtilsStringTokenizer(classNames, "|");
    while (tok.hasMoreTokens()) {
      String className = tok.nextToken();
      try {
        return Class.forName(className);
      } catch (ClassNotFoundException e) {
        DebugLog.error(className, e);
      } 
    } 
    throw new BluetoothStateException("BlueCove " + classNames + " not available");
  }
  
  private BluetoothStack newStackInstance(Class ctackClass) throws BluetoothStateException {
    String className = ctackClass.getName();
    try {
      return ctackClass.newInstance();
    } catch (InstantiationException e) {
      DebugLog.error(className, e);
    } catch (IllegalAccessException e) {
      DebugLog.error(className, e);
    } 
    throw new BluetoothStateException("BlueCove " + className + " can't instantiate");
  }
  
  private BluetoothStack loadStack(String classPropertyName, String classNameDefault) throws BluetoothStateException {
    return newStackInstance(loadStackClass(classPropertyName, classNameDefault));
  }
  
  static void loadNativeLibraries(BluetoothStack stack) throws BluetoothStateException {
    try {
      if (UtilsJavaSE.canCallNotLoadedNativeMethod && stack.isNativeCodeLoaded())
        return; 
    } catch (Error e) {}
    BluetoothStack.LibraryInformation[] libs = stack.requireNativeLibraries();
    if (libs == null || libs.length == 0)
      return; 
    for (int i = 0; i < libs.length; i++) {
      Class c = (libs[i]).stackClass;
      if (c == null)
        c = stack.getClass(); 
      if (!NativeLibLoader.isAvailable((libs[i]).libraryName, c, (libs[i]).required)) {
        if ((libs[i]).required)
          throw new BluetoothStateException("BlueCove library " + (libs[i]).libraryName + " not available;" + NativeLibLoader.getLoadErrors((libs[i]).libraryName)); 
        DebugLog.debug("library " + (libs[i]).libraryName + " not available");
      } 
    } 
  }
  
  private static boolean isNativeLibrariesAvailable(BluetoothStack stack) {
    try {
      if (UtilsJavaSE.canCallNotLoadedNativeMethod)
        return stack.isNativeCodeLoaded(); 
    } catch (Error e) {}
    BluetoothStack.LibraryInformation[] libs = stack.requireNativeLibraries();
    if (libs == null || libs.length == 0)
      return true; 
    for (int i = 0; i < libs.length; i++) {
      Class c = (libs[i]).stackClass;
      if (c == null)
        c = stack.getClass(); 
      if (!NativeLibLoader.isAvailable((libs[i]).libraryName, c))
        return false; 
    } 
    return true;
  }
  
  private BluetoothStack detectStack() throws BluetoothStateException {
    BluetoothStack detectorStack = null;
    String stackFirstDetector = getConfigProperty("bluecove.stack.first");
    String stackSelected = getConfigProperty("bluecove.stack");
    if (stackFirstDetector == null)
      stackFirstDetector = stackSelected; 
    if ("emulator".equals(stackSelected)) {
      detectorStack = loadStack("bluecove.emulator.class", "com.intel.bluetooth.BluetoothEmulator");
    } else {
      Class stackClass;
      String androidBluetoothStack;
      switch (NativeLibLoader.getOS()) {
        case 1:
        case 5:
          stackClass = loadStackClass("bluecove.bluez.class", "com.intel.bluetooth.BluetoothStackBlueZ|com.intel.bluetooth.BluetoothStackBlueZDBus");
          detectorStack = newStackInstance(stackClass);
          loadNativeLibraries(detectorStack);
          stackSelected = detectorStack.getStackID();
          break;
        case 6:
          androidBluetoothStack = "com.intel.bluetooth.BluetoothStackAndroid";
          try {
            Class androidStackClass = Class.forName(androidBluetoothStack);
            detectorStack = newStackInstance(androidStackClass);
            stackSelected = detectorStack.getStackID();
          } catch (ClassNotFoundException ex) {
            throw new BluetoothStateException("BlueCove " + androidBluetoothStack + " not available");
          } 
          break;
        case 4:
          detectorStack = new BluetoothStackOSX();
          loadNativeLibraries(detectorStack);
          stackSelected = detectorStack.getStackID();
          break;
        case 2:
        case 3:
          detectorStack = createDetectorOnWindows(stackFirstDetector);
          if (DebugLog.isDebugEnabled())
            detectorStack.enableNativeDebug(DebugLog.class, true); 
          break;
        default:
          throw new BluetoothStateException("BlueCove not available");
      } 
    } 
    int libraryVersion = detectorStack.getLibraryVersion();
    if (2010100 != libraryVersion) {
      DebugLog.fatal("BlueCove native library version mismatch " + libraryVersion + " expected " + 2010100);
      throw new BluetoothStateException("BlueCove native library version mismatch");
    } 
    if (stackSelected == null) {
      int aval = detectorStack.detectBluetoothStack();
      DebugLog.debug("BluetoothStack detected", aval);
      int detectorID = getStackId(detectorStack.getStackID());
      if ((aval & detectorID) != 0) {
        stackSelected = detectorStack.getStackID();
      } else if ((aval & 0x1) != 0) {
        stackSelected = "winsock";
      } else if ((aval & 0x2) != 0) {
        stackSelected = "widcomm";
      } else if ((aval & 0x4) != 0) {
        stackSelected = "bluesoleil";
      } else if ((aval & 0x8) != 0) {
        stackSelected = "toshiba";
      } else if ((aval & 0x10) != 0) {
        stackSelected = "mac";
      } else {
        DebugLog.fatal("BluetoothStack not detected");
        throw new BluetoothStateException("BluetoothStack not detected");
      } 
    } else {
      DebugLog.debug("BluetoothStack selected", stackSelected);
    } 
    BluetoothStack stack = setBluetoothStack(stackSelected, detectorStack);
    stackSelected = stack.getStackID();
    copySystemProperties(stack);
    if (!stackSelected.equals("emulator"))
      System.out.println("BlueCove version " + version + " on " + stackSelected); 
    return stack;
  }
  
  public static Vector getLocalDevicesID() throws BluetoothStateException {
    Vector v = new Vector();
    String ids = BluetoothStackHolder.getBluetoothStack().getLocalDeviceProperty("bluecove.local_devices_ids");
    if (ids != null) {
      UtilsStringTokenizer tok = new UtilsStringTokenizer(ids, ",");
      while (tok.hasMoreTokens())
        v.addElement(tok.nextToken()); 
    } 
    return v;
  }
  
  public static synchronized void useThreadLocalBluetoothStack() {
    if (threadStack == null)
      threadStack = new ThreadLocalWrapper(); 
    BluetoothStackHolder s = (BluetoothStackHolder)threadStack.get();
    if (s == null) {
      if (singleStack != null) {
        s = singleStack;
        singleStack = null;
      } else {
        s = new BluetoothStackHolder();
      } 
      threadStack.set(s);
    } 
  }
  
  public static synchronized Object getThreadBluetoothStackID() throws BluetoothStateException {
    useThreadLocalBluetoothStack();
    BluetoothStackHolder.getBluetoothStack();
    return threadStack.get();
  }
  
  public static synchronized Object getCurrentThreadBluetoothStackID() {
    if (threadStack == null)
      return null; 
    return threadStack.get();
  }
  
  public static synchronized void setThreadBluetoothStackID(Object stackID) {
    if (stackID != null && !(stackID instanceof BluetoothStackHolder))
      throw new IllegalArgumentException("stackID is not valid"); 
    if (threadStack == null)
      throw new IllegalArgumentException("ThreadLocal configuration is not initialized"); 
    threadStack.set(stackID);
  }
  
  public static synchronized void releaseThreadBluetoothStack() {
    if (threadStack == null)
      throw new IllegalArgumentException("ThreadLocal configuration is not initialized"); 
    threadStack.set(null);
  }
  
  public static synchronized void setDefaultThreadBluetoothStackID(Object stackID) {
    if (stackID != null && !(stackID instanceof BluetoothStackHolder))
      throw new IllegalArgumentException("stackID is not valid"); 
    if (threadStack == null)
      throw new IllegalArgumentException("ThreadLocal configuration is not initialized"); 
    threadStackIDDefault = (BluetoothStackHolder)stackID;
  }
  
  static synchronized void setThreadBluetoothStack(BluetoothStack bluetoothStack) {
    if (threadStack == null)
      return; 
    BluetoothStackHolder s = (BluetoothStackHolder)threadStack.get();
    if (s != null && s.bluetoothStack == bluetoothStack)
      return; 
    BluetoothStackHolder sh = (BluetoothStackHolder)stacks.get(bluetoothStack);
    if (sh == null)
      throw new RuntimeException("ThreadLocal not found for BluetoothStack"); 
    threadStack.set(sh);
  }
  
  public static synchronized void shutdownThreadBluetoothStack() {
    if (threadStack == null)
      return; 
    BluetoothStackHolder s = (BluetoothStackHolder)threadStack.get();
    if (s == null)
      return; 
    if (threadStackIDDefault == s)
      threadStackIDDefault = null; 
    s.configProperties.clear();
    if (s.bluetoothStack != null) {
      BluetoothConnectionNotifierBase.shutdownConnections(s.bluetoothStack);
      RemoteDeviceHelper.shutdownConnections(s.bluetoothStack);
      s.bluetoothStack.destroy();
      stacks.remove(s.bluetoothStack);
      s.bluetoothStack = null;
    } 
  }
  
  public static synchronized void shutdown() {
    for (Enumeration en = stacks.elements(); en.hasMoreElements(); ) {
      BluetoothStackHolder s = en.nextElement();
      s.configProperties.clear();
      if (s.bluetoothStack != null) {
        BluetoothConnectionNotifierBase.shutdownConnections(s.bluetoothStack);
        RemoteDeviceHelper.shutdownConnections(s.bluetoothStack);
        try {
          s.bluetoothStack.destroy();
        } finally {
          s.bluetoothStack = null;
        } 
      } 
    } 
    stacks.clear();
    singleStack = null;
    threadStackIDDefault = null;
    if (shutdownHookRegistered != null)
      shutdownHookRegistered.deRegister(); 
    clearSystemProperties();
  }
  
  public static void setConfigProperty(String name, String value) {
    setConfigObject(name, value);
  }
  
  public static void setConfigObject(String name, Object value) {
    if (name == null)
      throw new NullPointerException("key is null"); 
    BluetoothStackHolder sh = currentStackHolder(true);
    if (sh.bluetoothStack != null && initializationProperties.contains(name))
      throw new IllegalArgumentException("BlueCove Stack already initialized"); 
    if (value == null) {
      sh.configProperties.remove(name);
    } else {
      sh.configProperties.put(name, value);
    } 
  }
  
  public static Object getConfigObject(String key) {
    if (key == null)
      throw new NullPointerException("key is null"); 
    Object value = null;
    BluetoothStackHolder sh = currentStackHolder(false);
    if (sh != null)
      value = sh.configProperties.get(key); 
    if (value == null)
      try {
        value = System.getProperty(key);
      } catch (SecurityException webstart) {} 
    if (value == null)
      synchronized (resourceConfigProperties) {
        Object casheValue = resourceConfigProperties.get(key);
        if (casheValue != null) {
          if (casheValue instanceof String)
            value = casheValue; 
        } else {
          value = Utils.getResourceProperty(BlueCoveImpl.class, key);
          if (value == null) {
            resourceConfigProperties.put(key, new Object());
          } else {
            resourceConfigProperties.put(key, value);
          } 
        } 
      }  
    return value;
  }
  
  public static String getConfigProperty(String key) {
    return (String)getConfigObject(key);
  }
  
  public static boolean getConfigProperty(String key, boolean defaultValue) {
    String value = getConfigProperty(key);
    if (value != null)
      return ("true".equals(value) || "1".equals(value)); 
    return defaultValue;
  }
  
  static int getConfigProperty(String key, int defaultValue) {
    String value = getConfigProperty(key);
    if (value != null)
      return Integer.parseInt(value); 
    return defaultValue;
  }
  
  static String[] getSystemPropertiesList() {
    String[] p = { "bluetooth.master.switch", "bluetooth.sd.attr.retrievable.max", "bluetooth.connected.devices.max", "bluetooth.l2cap.receiveMTU.max", "bluetooth.sd.trans.max", "bluetooth.connected.inquiry.scan", "bluetooth.connected.page.scan", "bluetooth.connected.inquiry", "bluetooth.connected.page" };
    return p;
  }
  
  static void clearSystemProperties() {
    UtilsJavaSE.setSystemProperty("bluetooth.api.version", null);
    UtilsJavaSE.setSystemProperty("obex.api.version", null);
    String[] property = getSystemPropertiesList();
    for (int i = 0; i < property.length; i++)
      UtilsJavaSE.setSystemProperty(property[i], null); 
  }
  
  void copySystemProperties(BluetoothStack bluetoothStack) {
    UtilsJavaSE.setSystemProperty("bluetooth.api.version", "1.1.1");
    UtilsJavaSE.setSystemProperty("obex.api.version", "1.1.1");
    if (bluetoothStack != null) {
      String[] property = getSystemPropertiesList();
      for (int i = 0; i < property.length; i++)
        UtilsJavaSE.setSystemProperty(property[i], bluetoothStack.getLocalDeviceProperty(property[i])); 
    } 
  }
  
  public String getLocalDeviceFeature(int featureID) throws BluetoothStateException {
    return ((BluetoothStackHolder.getBluetoothStack().getFeatureSet() & featureID) != 0) ? "true" : "false";
  }
  
  private BluetoothStack createDetectorOnWindows(String stackFirst) throws BluetoothStateException {
    if (stackFirst != null) {
      DebugLog.debug("detector stack", stackFirst);
      if ("widcomm".equalsIgnoreCase(stackFirst)) {
        BluetoothStack detectorStack = new BluetoothStackWIDCOMM();
        if (isNativeLibrariesAvailable(detectorStack))
          return detectorStack; 
      } else if ("bluesoleil".equalsIgnoreCase(stackFirst)) {
        BluetoothStack detectorStack = new BluetoothStackBlueSoleil();
        if (isNativeLibrariesAvailable(detectorStack))
          return detectorStack; 
      } else if ("winsock".equalsIgnoreCase(stackFirst)) {
        BluetoothStack detectorStack = new BluetoothStackMicrosoft();
        if (isNativeLibrariesAvailable(detectorStack))
          return detectorStack; 
      } else if ("toshiba".equalsIgnoreCase(stackFirst)) {
        BluetoothStack detectorStack = new BluetoothStackToshiba();
        if (isNativeLibrariesAvailable(detectorStack))
          return detectorStack; 
      } else {
        throw new IllegalArgumentException("Invalid BlueCove detector stack [" + stackFirst + "]");
      } 
    } 
    BluetoothStack stack = new BluetoothStackMicrosoft();
    if (isNativeLibrariesAvailable(stack))
      return stack; 
    stack = new BluetoothStackWIDCOMM();
    if (isNativeLibrariesAvailable(stack))
      return stack; 
    throw new BluetoothStateException("BlueCove libraries not available");
  }
  
  public String setBluetoothStack(String stack) throws BluetoothStateException {
    return setBluetoothStack(stack, null).getStackID();
  }
  
  private synchronized BluetoothStack setBluetoothStack(String stack, BluetoothStack detectorStack) throws BluetoothStateException {
    BluetoothStack newStack;
    if (singleStack != null) {
      if (singleStack.bluetoothStack != null) {
        singleStack.bluetoothStack.destroy();
        stacks.remove(singleStack.bluetoothStack);
        singleStack.bluetoothStack = null;
      } 
    } else if (threadStack != null) {
      BluetoothStackHolder s = (BluetoothStackHolder)threadStack.get();
      if (s != null && s.bluetoothStack != null) {
        s.bluetoothStack.destroy();
        stacks.remove(s.bluetoothStack);
        s.bluetoothStack = null;
      } 
    } 
    if (detectorStack != null && detectorStack.getStackID().equalsIgnoreCase(stack)) {
      newStack = detectorStack;
    } else if ("widcomm".equalsIgnoreCase(stack)) {
      newStack = new BluetoothStackWIDCOMM();
    } else if ("bluesoleil".equalsIgnoreCase(stack)) {
      newStack = new BluetoothStackBlueSoleil();
    } else if ("toshiba".equalsIgnoreCase(stack)) {
      newStack = new BluetoothStackToshiba();
    } else {
      newStack = new BluetoothStackMicrosoft();
    } 
    loadNativeLibraries(newStack);
    int libraryVersion = newStack.getLibraryVersion();
    if (2010100 != libraryVersion) {
      DebugLog.fatal("BlueCove native library version mismatch " + libraryVersion + " expected " + 2010100);
      throw new BluetoothStateException("BlueCove native library version mismatch");
    } 
    if (DebugLog.isDebugEnabled())
      newStack.enableNativeDebug(DebugLog.class, true); 
    newStack.initialize();
    createShutdownHook();
    BluetoothStackHolder sh = currentStackHolder(true);
    sh.bluetoothStack = newStack;
    stacks.put(newStack, sh);
    if (threadStack != null)
      threadStack.set(sh); 
    return newStack;
  }
  
  public void enableNativeDebug(boolean on) {
    BluetoothStackHolder s = currentStackHolder(false);
    if (s != null && s.bluetoothStack != null)
      s.bluetoothStack.enableNativeDebug(DebugLog.class, on); 
  }
  
  private static BluetoothStackHolder currentStackHolder(boolean create) {
    if (threadStack != null) {
      BluetoothStackHolder s = (BluetoothStackHolder)threadStack.get();
      if (s == null && threadStackIDDefault != null)
        return threadStackIDDefault; 
      if (s == null && create) {
        s = new BluetoothStackHolder();
        threadStack.set(s);
      } 
      return s;
    } 
    if (singleStack == null && create)
      singleStack = new BluetoothStackHolder(); 
    return singleStack;
  }
  
  public synchronized BluetoothStack getBluetoothStack() throws BluetoothStateException {
    BluetoothStack stack;
    Utils.isLegalAPICall(fqcnSet);
    BluetoothStackHolder sh = currentStackHolder(false);
    if (sh != null && sh.bluetoothStack != null)
      return sh.bluetoothStack; 
    if (sh == null && threadStack != null)
      throw new BluetoothStateException("No BluetoothStack or Adapter for current thread"); 
    if (this.accessControlContext == null) {
      stack = detectStack();
    } else {
      stack = detectStackPrivileged();
    } 
    return stack;
  }
  
  private BluetoothStack detectStackPrivileged() throws BluetoothStateException {
    try {
      return AccessController.<BluetoothStack>doPrivileged(new PrivilegedExceptionAction(this) {
            private final BlueCoveImpl this$0;
            
            public Object run() throws BluetoothStateException {
              return this.this$0.detectStack();
            }
          },  (AccessControlContext)this.accessControlContext);
    } catch (PrivilegedActionException e) {
      Throwable cause = UtilsJavaSE.getCause(e);
      if (cause instanceof BluetoothStateException)
        throw (BluetoothStateException)cause; 
      throw (BluetoothStateException)UtilsJavaSE.initCause(new BluetoothStateException(e.getMessage()), cause);
    } 
  }
}
