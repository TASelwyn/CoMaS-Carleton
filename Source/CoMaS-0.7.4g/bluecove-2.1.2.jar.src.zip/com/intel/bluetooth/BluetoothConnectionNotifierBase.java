package com.intel.bluetooth;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DataElement;
import javax.bluetooth.ServiceRecord;
import javax.bluetooth.ServiceRegistrationException;
import javax.microedition.io.Connection;

abstract class BluetoothConnectionNotifierBase implements Connection, BluetoothConnectionNotifierServiceRecordAccess {
  private static Hashtable stackConnections = new Hashtable();
  
  protected BluetoothStack bluetoothStack;
  
  protected volatile long handle;
  
  protected ServiceRecordImpl serviceRecord;
  
  protected boolean closed;
  
  protected int securityOpt;
  
  static void shutdownConnections(BluetoothStack bluetoothStack) {
    Vector connections;
    synchronized (stackConnections) {
      connections = (Vector)stackConnections.get(bluetoothStack);
    } 
    if (connections == null)
      return; 
    Vector c2shutdown = new Vector();
    c2shutdown = Utils.clone(connections.elements());
    for (Enumeration en = c2shutdown.elements(); en.hasMoreElements(); ) {
      BluetoothConnectionNotifierBase c = en.nextElement();
      try {
        c.shutdown();
      } catch (IOException e) {
        DebugLog.debug("connection shutdown", e);
      } 
    } 
  }
  
  protected BluetoothConnectionNotifierBase(BluetoothStack bluetoothStack, BluetoothConnectionNotifierParams params) throws BluetoothStateException, Error {
    this.bluetoothStack = bluetoothStack;
    this.closed = false;
    if (params.name == null)
      throw new NullPointerException("Service name is null"); 
    this.serviceRecord = new ServiceRecordImpl(this.bluetoothStack, null, 0L);
  }
  
  protected void connectionCreated() {
    Vector connections;
    synchronized (stackConnections) {
      connections = (Vector)stackConnections.get(this.bluetoothStack);
      if (connections == null) {
        connections = new Vector();
        stackConnections.put(this.bluetoothStack, connections);
      } 
    } 
    connections.addElement(this);
  }
  
  protected abstract void stackServerClose(long paramLong) throws IOException;
  
  public void close() throws IOException {
    if (!this.closed)
      shutdown(); 
  }
  
  public void shutdown() throws IOException {
    this.closed = true;
    if (this.handle != 0L) {
      Vector connections;
      long synchronizedHandle;
      DebugLog.debug("closing ConnectionNotifier", this.handle);
      synchronized (stackConnections) {
        connections = (Vector)stackConnections.get(this.bluetoothStack);
      } 
      connections.removeElement(this);
      synchronized (this) {
        synchronizedHandle = this.handle;
        this.handle = 0L;
      } 
      if (synchronizedHandle != 0L) {
        ServiceRecordsRegistry.unregister(this.serviceRecord);
        if (this.serviceRecord.deviceServiceClasses != 0 && (this.bluetoothStack.getFeatureSet() & 0x4) != 0)
          this.bluetoothStack.setLocalDeviceServiceClasses(ServiceRecordsRegistry.getDeviceServiceClasses()); 
        stackServerClose(synchronizedHandle);
      } 
    } 
  }
  
  public ServiceRecord getServiceRecord() {
    if (this.closed)
      throw new IllegalArgumentException("ConnectionNotifier is closed"); 
    ServiceRecordsRegistry.register(this, this.serviceRecord);
    return this.serviceRecord;
  }
  
  protected void validateServiceRecord(ServiceRecord srvRecord) {
    DataElement protocolDescriptor = srvRecord.getAttributeValue(4);
    if (protocolDescriptor == null || protocolDescriptor.getDataType() != 48)
      throw new IllegalArgumentException("ProtocolDescriptorList is mandatory"); 
    DataElement serviceClassIDList = srvRecord.getAttributeValue(1);
    if (serviceClassIDList == null || serviceClassIDList.getDataType() != 48 || serviceClassIDList.getSize() == 0)
      throw new IllegalArgumentException("ServiceClassIDList is mandatory"); 
    boolean isL2CAPpresent = false;
    Enumeration protocolsSeqEnum = (Enumeration)protocolDescriptor.getValue();
    while (protocolsSeqEnum.hasMoreElements()) {
      DataElement elementSeq = protocolsSeqEnum.nextElement();
      if (elementSeq.getDataType() == 48) {
        Enumeration elementSeqEnum = (Enumeration)elementSeq.getValue();
        if (elementSeqEnum.hasMoreElements()) {
          DataElement protocolElement = elementSeqEnum.nextElement();
          if (protocolElement.getDataType() == 24 && BluetoothConsts.L2CAP_PROTOCOL_UUID.equals(protocolElement.getValue())) {
            isL2CAPpresent = true;
            break;
          } 
        } 
      } 
    } 
    if (!isL2CAPpresent)
      throw new IllegalArgumentException("L2CAP UUID is mandatory in ProtocolDescriptorList"); 
  }
  
  protected abstract void updateStackServiceRecord(ServiceRecordImpl paramServiceRecordImpl, boolean paramBoolean) throws ServiceRegistrationException;
  
  public void updateServiceRecord(boolean acceptAndOpen) throws ServiceRegistrationException {
    if (this.serviceRecord.attributeUpdated || !acceptAndOpen) {
      try {
        validateServiceRecord(this.serviceRecord);
      } catch (IllegalArgumentException e) {
        if (acceptAndOpen)
          throw new ServiceRegistrationException(e.getMessage()); 
        throw e;
      } 
      try {
        updateStackServiceRecord(this.serviceRecord, acceptAndOpen);
      } finally {
        this.serviceRecord.attributeUpdated = false;
      } 
    } 
    if (this.serviceRecord.deviceServiceClasses != this.serviceRecord.deviceServiceClassesRegistered && (this.bluetoothStack.getFeatureSet() & 0x4) != 0) {
      this.bluetoothStack.setLocalDeviceServiceClasses(ServiceRecordsRegistry.getDeviceServiceClasses());
      this.serviceRecord.deviceServiceClassesRegistered = this.serviceRecord.deviceServiceClasses;
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothConnectionNotifierBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */