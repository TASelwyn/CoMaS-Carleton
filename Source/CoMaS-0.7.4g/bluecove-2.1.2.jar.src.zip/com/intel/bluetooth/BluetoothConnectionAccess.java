package com.intel.bluetooth;

import java.io.IOException;
import javax.bluetooth.RemoteDevice;

public interface BluetoothConnectionAccess {
  BluetoothStack getBluetoothStack();
  
  long getRemoteAddress() throws IOException;
  
  boolean isClosed();
  
  void markAuthenticated();
  
  int getSecurityOpt();
  
  void shutdown() throws IOException;
  
  boolean encrypt(long paramLong, boolean paramBoolean) throws IOException;
  
  RemoteDevice getRemoteDevice();
  
  void setRemoteDevice(RemoteDevice paramRemoteDevice);
}
