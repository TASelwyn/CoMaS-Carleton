package com.intel.bluetooth;

import java.io.IOException;
import javax.bluetooth.RemoteDevice;

public interface BluetoothConnectionAccess {
  BluetoothStack getBluetoothStack();
  
  long getRemoteAddress() throws IOException;
  
  boolean isClosed();
  
  void markAuthenticated();
  
  int getSecurityOpt();
  
  void shutdown() throws IOException;
  
  boolean encrypt(long paramLong, boolean paramBoolean) throws IOException;
  
  RemoteDevice getRemoteDevice();
  
  void setRemoteDevice(RemoteDevice paramRemoteDevice);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothConnectionAccess.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */