package com.intel.bluetooth;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.Priority;

class DebugLog4jAppender implements DebugLog.LoggerAppenderExt {
  private static final String FQCN = DebugLog.class.getName();
  
  private Logger logger = Logger.getLogger("com.intel.bluetooth");
  
  public void appendLog(int level, String message, Throwable throwable) {
    switch (level) {
      case 1:
        this.logger.log(FQCN, (Priority)Level.DEBUG, message, throwable);
        break;
      case 4:
        this.logger.log(FQCN, (Priority)Level.ERROR, message, throwable);
        break;
    } 
  }
  
  public boolean isLogEnabled(int level) {
    switch (level) {
      case 1:
        return this.logger.isDebugEnabled();
      case 4:
        return true;
    } 
    return false;
  }
}
