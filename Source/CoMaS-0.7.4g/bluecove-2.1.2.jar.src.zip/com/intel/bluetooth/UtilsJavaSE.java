package com.intel.bluetooth;

import java.security.PrivilegedActionException;
import java.util.Properties;
import java.util.Vector;

public class UtilsJavaSE {
  static final boolean javaSECompiledOut = false;
  
  static interface JavaSE5Features {
    void clearProperty(String param1String);
  }
  
  static class StackTraceLocation {
    public String className;
    
    public String methodName;
    
    public String fileName;
    
    public int lineNumber;
  }
  
  static final int javaSpecificationVersion = getJavaSpecificationVersion();
  
  static boolean java13 = false;
  
  static boolean java14 = false;
  
  static boolean detectJava5Helper = true;
  
  static JavaSE5Features java5Helper;
  
  static final boolean ibmJ9midp = detectJ9midp();
  
  static final boolean canCallNotLoadedNativeMethod = !ibmJ9midp;
  
  private static boolean detectJ9midp() {
    String ibmJ9config;
    try {
      ibmJ9config = System.getProperty("com.ibm.oti.configuration");
    } catch (SecurityException webstart) {
      return false;
    } 
    return (ibmJ9config != null && ibmJ9config.indexOf("midp") != -1);
  }
  
  private static int getJavaSpecificationVersion() {
    try {
      String javaV = System.getProperty("java.specification.version");
      if (javaV == null || javaV.length() < 3)
        return 0; 
      return Integer.valueOf(javaV.substring(2, 3)).intValue();
    } catch (Throwable e) {
      return 0;
    } 
  }
  
  private static void detectJava5Helper() {
    if (java13 || ibmJ9midp || !detectJava5Helper || javaSpecificationVersion < 5)
      return; 
    detectJava5Helper = false;
    try {
      Class klass = Class.forName("com.intel.bluetooth.UtilsJavaSE5");
      java5Helper = (JavaSE5Features)klass.newInstance();
      DebugLog.debug("Use java 1.5+ features:", vmInfo());
    } catch (Throwable e) {}
  }
  
  static StackTraceLocation getLocation(Vector fqcnSet) {
    if (java13 || ibmJ9midp)
      return null; 
    if (!java14)
      try {
        Class.forName("java.lang.StackTraceElement");
        java14 = true;
        DebugLog.debug("Java 1.4+ detected:", vmInfo());
      } catch (ClassNotFoundException e) {
        java13 = true;
        return null;
      }  
    try {
      return getLocationJava14(fqcnSet);
    } catch (Throwable e) {
      java13 = true;
      return null;
    } 
  }
  
  static String vmInfo() {
    try {
      return System.getProperty("java.version") + "; " + System.getProperty("java.vm.name") + "; " + System.getProperty("java.vendor");
    } catch (SecurityException ignore) {
      return "";
    } 
  }
  
  private static StackTraceLocation getLocationJava14(Vector fqcnSet) {
    StackTraceElement[] ste = (new Throwable()).getStackTrace();
    for (int i = 0; i < ste.length - 1; i++) {
      if (fqcnSet.contains(ste[i].getClassName())) {
        String nextClassName = ste[i + 1].getClassName();
        if (!nextClassName.startsWith("java.") && !nextClassName.startsWith("sun."))
          if (!fqcnSet.contains(nextClassName)) {
            StackTraceElement st = ste[i + 1];
            StackTraceLocation loc = new StackTraceLocation();
            loc.className = st.getClassName();
            loc.methodName = st.getMethodName();
            loc.fileName = st.getFileName();
            loc.lineNumber = st.getLineNumber();
            return loc;
          }  
      } 
    } 
    return null;
  }
  
  public static void threadSetDaemon(Thread thread) {
    try {
      if (!ibmJ9midp)
        thread.setDaemon(true); 
    } catch (Throwable javaJ9) {}
  }
  
  static boolean runtimeAddShutdownHook(Thread thread) {
    try {
      if (ibmJ9midp) {
        IBMJ9Helper.addShutdownClass(thread);
        return true;
      } 
      Runtime.getRuntime().addShutdownHook(thread);
      return true;
    } catch (Throwable java12) {
      return false;
    } 
  }
  
  static void runtimeRemoveShutdownHook(Thread thread) {
    try {
      if (!ibmJ9midp)
        Runtime.getRuntime().removeShutdownHook(thread); 
    } catch (Throwable java12) {}
  }
  
  static void setSystemProperty(String propertyName, String propertyValue) {
    if (ibmJ9midp)
      return; 
    boolean propertySet = false;
    try {
      Properties props = System.getProperties();
      if (propertyValue != null) {
        props.put(propertyName, propertyValue);
        propertySet = propertyValue.equals(System.getProperty(propertyName));
      } else {
        props.remove(propertyName);
        propertySet = (System.getProperty(propertyName) == null);
      } 
    } catch (SecurityException e) {}
    if (!propertySet)
      try {
        if (propertyValue != null) {
          System.setProperty(propertyName, propertyValue);
        } else {
          detectJava5Helper();
          if (java5Helper != null)
            java5Helper.clearProperty(propertyName); 
        } 
      } catch (Throwable java11) {} 
  }
  
  public static Throwable initCause(Throwable throwable, Throwable cause) {
    if (!java14 || cause == null)
      return throwable; 
    try {
      return throwable.initCause(cause);
    } catch (Throwable j9pp10) {
      return throwable;
    } 
  }
  
  static boolean isCurrentThreadInterrupted() {
    if (ibmJ9midp)
      return false; 
    return Thread.interrupted();
  }
  
  static Throwable getCause(PrivilegedActionException e) {
    try {
      return e.getCause();
    } catch (Throwable j9pp10) {
      try {
        return e.getException();
      } catch (Throwable ignore) {
        return null;
      } 
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\UtilsJavaSE.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */