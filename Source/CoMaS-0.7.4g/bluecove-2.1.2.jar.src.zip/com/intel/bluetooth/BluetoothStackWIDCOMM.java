package com.intel.bluetooth;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DataElement;
import javax.bluetooth.DeviceClass;
import javax.bluetooth.DiscoveryListener;
import javax.bluetooth.RemoteDevice;
import javax.bluetooth.ServiceRecord;
import javax.bluetooth.ServiceRegistrationException;
import javax.bluetooth.UUID;

class BluetoothStackWIDCOMM implements BluetoothStack, BluetoothStackExtension {
  private static BluetoothStackWIDCOMM singleInstance = null;
  
  private boolean initialized = false;
  
  private Vector deviceDiscoveryListeners = new Vector();
  
  private Hashtable deviceDiscoveryListenerFoundDevices = new Hashtable();
  
  private Hashtable deviceDiscoveryListenerReportedDevices = new Hashtable();
  
  private static final int ATTR_RETRIEVABLE_MAX = 256;
  
  private static final int RECEIVE_MTU_MAX = 1024;
  
  static final short NULL_DESC_TYPE = 0;
  
  static final short UINT_DESC_TYPE = 1;
  
  static final short TWO_COMP_INT_DESC_TYPE = 2;
  
  static final short UUID_DESC_TYPE = 3;
  
  static final short TEXT_STR_DESC_TYPE = 4;
  
  static final short BOOLEAN_DESC_TYPE = 5;
  
  static final short DATA_ELE_SEQ_DESC_TYPE = 6;
  
  static final short DATA_ELE_ALT_DESC_TYPE = 7;
  
  static final short URL_DESC_TYPE = 8;
  
  static Class class$com$intel$bluetooth$BluetoothStackWIDCOMM;
  
  public String getStackID() {
    return "widcomm";
  }
  
  public String toString() {
    return getStackID();
  }
  
  public int getFeatureSet() {
    int nativeBuildFeaturs = nativeBuildFeatures();
    return 0x13 | ((nativeBuildFeaturs > 0) ? 8 : 0);
  }
  
  public BluetoothStack.LibraryInformation[] requireNativeLibraries() {
    return BluetoothStack.LibraryInformation.library("bluecove");
  }
  
  public void initialize() throws BluetoothStateException {
    if (singleInstance != null)
      throw new BluetoothStateException("Only one instance of " + getStackID() + " stack supported"); 
    if (!initializeImpl())
      throw new RuntimeException("WIDCOMM BluetoothStack not found"); 
    this.initialized = true;
    singleInstance = this;
  }
  
  public void destroy() {
    if (singleInstance != this)
      throw new RuntimeException("Destroy invalid instance"); 
    if (this.initialized) {
      uninitialize();
      this.initialized = false;
      DebugLog.debug("WIDCOMM destroyed");
    } 
    singleInstance = null;
  }
  
  protected void finalize() {
    destroy();
  }
  
  public DeviceClass getLocalDeviceClass() {
    return new DeviceClass(getDeviceClassImpl());
  }
  
  public void setLocalDeviceServiceClasses(int classOfDevice) {
    throw new NotSupportedRuntimeException(getStackID());
  }
  
  public boolean setLocalDeviceDiscoverable(int mode) throws BluetoothStateException {
    int curentMode = getLocalDeviceDiscoverable();
    if (curentMode == mode)
      return true; 
    return false;
  }
  
  private synchronized void verifyDeviceReady() throws BluetoothStateException {
    if (!isLocalDevicePowerOn())
      throw new BluetoothStateException("Bluetooth Device is not ready"); 
  }
  
  public int getLocalDeviceDiscoverable() {
    if (isStackServerUp() && isLocalDeviceDiscoverable())
      return 10390323; 
    return 0;
  }
  
  public String getLocalDeviceProperty(String property) {
    if ("bluetooth.connected.devices.max".equals(property))
      return "7"; 
    if ("bluetooth.sd.trans.max".equals(property))
      return "1"; 
    if ("bluetooth.connected.inquiry.scan".equals(property))
      return "true"; 
    if ("bluetooth.connected.page.scan".equals(property))
      return "true"; 
    if ("bluetooth.connected.inquiry".equals(property))
      return "true"; 
    if ("bluetooth.connected.page".equals(property))
      return "true"; 
    if ("bluetooth.sd.attr.retrievable.max".equals(property))
      return String.valueOf(256); 
    if ("bluetooth.master.switch".equals(property))
      return "false"; 
    if ("bluetooth.l2cap.receiveMTU.max".equals(property))
      return String.valueOf(1024); 
    if ("bluecove.radio.version".equals(property))
      return String.valueOf(getDeviceVersion()); 
    if ("bluecove.radio.manufacturer".equals(property))
      return String.valueOf(getDeviceManufacturer()); 
    if ("bluecove.stack.version".equals(property))
      return getBTWVersionInfo(); 
    if (property.startsWith("bluecove.nativeFunction:")) {
      String functionDescr = property.substring(property.indexOf(':') + 1, property.length());
      int paramIdx = functionDescr.indexOf(':');
      if (paramIdx == -1)
        throw new RuntimeException("Invalid native function " + functionDescr + "; arguments expected"); 
      String function = functionDescr.substring(0, paramIdx);
      long address = RemoteDeviceHelper.getAddress(functionDescr.substring(function.length() + 1, functionDescr.length()));
      if ("getRemoteDeviceVersionInfo".equals(function))
        return getRemoteDeviceVersionInfo(address); 
      if ("cancelSniffMode".equals(function))
        return String.valueOf(cancelSniffMode(address)); 
      if ("setSniffMode".equals(function))
        return String.valueOf(setSniffMode(address)); 
      if ("getRemoteDeviceRSSI".equals(function))
        return String.valueOf(getRemoteDeviceRSSI(address)); 
      if ("getRemoteDeviceLinkMode".equals(function)) {
        if (isRemoteDeviceConnected(address))
          return getRemoteDeviceLinkMode(address); 
        return "disconnected";
      } 
    } 
    return null;
  }
  
  public boolean isCurrentThreadInterruptedCallback() {
    return UtilsJavaSE.isCurrentThreadInterrupted();
  }
  
  public RemoteDevice[] retrieveDevices(int option) {
    return null;
  }
  
  public Boolean isRemoteDeviceTrusted(long address) {
    return null;
  }
  
  public Boolean isRemoteDeviceAuthenticated(long address) {
    return null;
  }
  
  public int readRemoteDeviceRSSI(long address) throws IOException {
    return getRemoteDeviceRSSI(address);
  }
  
  public boolean authenticateRemoteDevice(long address) throws IOException {
    return false;
  }
  
  public boolean authenticateRemoteDevice(long address, String passkey) throws IOException {
    return authenticateRemoteDeviceImpl(address, passkey);
  }
  
  public void removeAuthenticationWithRemoteDevice(long address) throws IOException {
    removeAuthenticationWithRemoteDeviceImpl(address);
  }
  
  public boolean startInquiry(int accessCode, DiscoveryListener listener) throws BluetoothStateException {
    this.deviceDiscoveryListeners.addElement(listener);
    if (BlueCoveImpl.getConfigProperty("bluecove.inquiry.report_asap", false))
      this.deviceDiscoveryListenerFoundDevices.put(listener, new Hashtable()); 
    this.deviceDiscoveryListenerReportedDevices.put(listener, new Vector());
    DeviceInquiryRunnable inquiryRunnable = new DeviceInquiryRunnable(this) {
        private final BluetoothStackWIDCOMM this$0;
        
        public int runDeviceInquiry(DeviceInquiryThread startedNotify, int accessCode, DiscoveryListener listener) throws BluetoothStateException {
          try {
            int discType = this.this$0.runDeviceInquiryImpl(this, startedNotify, accessCode, listener);
            if (discType == 0) {
              Hashtable previouslyFound = (Hashtable)this.this$0.deviceDiscoveryListenerFoundDevices.get(listener);
              if (previouslyFound != null) {
                Vector reported = (Vector)this.this$0.deviceDiscoveryListenerReportedDevices.get(listener);
                for (Enumeration en = previouslyFound.keys(); en.hasMoreElements(); ) {
                  RemoteDevice remoteDevice = en.nextElement();
                  if (reported.contains(remoteDevice))
                    continue; 
                  reported.addElement(remoteDevice);
                  Integer deviceClassInt = (Integer)previouslyFound.get(remoteDevice);
                  DeviceClass deviceClass = new DeviceClass(deviceClassInt.intValue());
                  listener.deviceDiscovered(remoteDevice, deviceClass);
                  if (!this.this$0.deviceDiscoveryListeners.contains(listener))
                    return 5; 
                } 
              } 
            } 
            return discType;
          } finally {
            this.this$0.deviceDiscoveryListeners.removeElement(listener);
            this.this$0.deviceDiscoveryListenerFoundDevices.remove(listener);
            this.this$0.deviceDiscoveryListenerReportedDevices.remove(listener);
          } 
        }
        
        public void deviceDiscoveredCallback(DiscoveryListener listener, long deviceAddr, int deviceClass, String deviceName, boolean paired) {
          DebugLog.debug("deviceDiscoveredCallback deviceName", deviceName);
          if (!this.this$0.deviceDiscoveryListeners.contains(listener))
            return; 
          RemoteDevice remoteDevice = RemoteDeviceHelper.createRemoteDevice(this.this$0, deviceAddr, deviceName, paired);
          Vector reported = (Vector)this.this$0.deviceDiscoveryListenerReportedDevices.get(listener);
          if (reported == null || reported.contains(remoteDevice))
            return; 
          Hashtable previouslyFound = (Hashtable)this.this$0.deviceDiscoveryListenerFoundDevices.get(listener);
          if (previouslyFound != null) {
            Integer deviceClassInt = (Integer)previouslyFound.get(remoteDevice);
            if (deviceClassInt == null) {
              previouslyFound.put(remoteDevice, new Integer(deviceClass));
            } else if (deviceClass != 0) {
              previouslyFound.put(remoteDevice, new Integer(deviceClass));
            } 
          } else {
            DeviceClass cod = new DeviceClass(deviceClass);
            reported.addElement(remoteDevice);
            DebugLog.debug("deviceDiscoveredCallback address", remoteDevice.getBluetoothAddress());
            DebugLog.debug("deviceDiscoveredCallback deviceClass", cod);
            listener.deviceDiscovered(remoteDevice, cod);
          } 
        }
      };
    return DeviceInquiryThread.startInquiry(this, inquiryRunnable, accessCode, listener);
  }
  
  public boolean cancelInquiry(DiscoveryListener listener) {
    if (!this.deviceDiscoveryListeners.removeElement(listener))
      return false; 
    return deviceInquiryCancelImpl();
  }
  
  public String getRemoteDeviceFriendlyName(long address) throws IOException {
    if (this.deviceDiscoveryListeners.size() != 0)
      return peekRemoteDeviceFriendlyName(address); 
    DiscoveryListener listener = new DiscoveryListenerAdapter();
    if (startInquiry(10390323, listener)) {
      String name = peekRemoteDeviceFriendlyName(address);
      cancelInquiry(listener);
      return name;
    } 
    return null;
  }
  
  public int searchServices(int[] attrSet, UUID[] uuidSet, RemoteDevice device, DiscoveryListener listener) throws BluetoothStateException {
    SearchServicesRunnable searchRunnable = new SearchServicesRunnable(this) {
        private final BluetoothStackWIDCOMM this$0;
        
        public int runSearchServices(SearchServicesThread sst, int[] attrSet, UUID[] uuidSet, RemoteDevice device, DiscoveryListener listener) throws BluetoothStateException {
          synchronized ((BluetoothStackWIDCOMM.class$com$intel$bluetooth$BluetoothStackWIDCOMM == null) ? (BluetoothStackWIDCOMM.class$com$intel$bluetooth$BluetoothStackWIDCOMM = BluetoothStackWIDCOMM.class$("com.intel.bluetooth.BluetoothStackWIDCOMM")) : BluetoothStackWIDCOMM.class$com$intel$bluetooth$BluetoothStackWIDCOMM) {
            long[] handles;
            byte[] uuidValue = Utils.UUIDToByteArray(BluetoothConsts.L2CAP_PROTOCOL_UUID);
            for (int u = 0; u < uuidSet.length; u++) {
              if (!uuidSet[u].equals(BluetoothConsts.L2CAP_PROTOCOL_UUID))
                if (uuidSet[u].equals(BluetoothConsts.RFCOMM_PROTOCOL_UUID)) {
                  uuidValue = Utils.UUIDToByteArray(uuidSet[u]);
                } else {
                  uuidValue = Utils.UUIDToByteArray(uuidSet[u]);
                  break;
                }  
            } 
            try {
              handles = this.this$0.runSearchServicesImpl(sst, uuidValue, RemoteDeviceHelper.getAddress(device));
            } catch (SearchServicesTerminatedException e) {
              DebugLog.debug("SERVICE_SEARCH_TERMINATED");
              return 2;
            } 
            if (handles == null) {
              DebugLog.debug("SERVICE_SEARCH_ERROR");
              return 3;
            } 
            if (handles.length > 0) {
              Vector records = new Vector();
              int[] uuidFilerAttrIDs = { 1, 4 };
              int[] requiredAttrIDs = { 0, 2, 3 };
              int i;
              label55: for (i = 0; i < handles.length; i++) {
                ServiceRecordImpl sr = new ServiceRecordImpl(this.this$0, device, handles[i]);
                try {
                  sr.populateRecord(uuidFilerAttrIDs);
                  for (int j = 0; j < uuidSet.length; j++) {
                    if (!sr.hasServiceClassUUID(uuidSet[j]) && !sr.hasProtocolClassUUID(uuidSet[j]))
                      continue label55; 
                  } 
                  if (!this.this$0.isServiceRecordDiscoverable(RemoteDeviceHelper.getAddress(device), sr.getHandle()))
                    continue; 
                  records.addElement(sr);
                  sr.populateRecord(requiredAttrIDs);
                  if (attrSet != null)
                    sr.populateRecord(attrSet); 
                  DebugLog.debug("ServiceRecord (" + i + ") sr.handle", handles[i]);
                  DebugLog.debug("ServiceRecord (" + i + ")", sr);
                } catch (Exception e) {
                  DebugLog.debug("populateRecord error", e);
                } 
                if (sst.isTerminated()) {
                  DebugLog.debug("SERVICE_SEARCH_TERMINATED");
                  return 2;
                } 
                continue;
              } 
              if (records.size() != 0) {
                DebugLog.debug("SERVICE_SEARCH_COMPLETED");
                ServiceRecord[] fileteredRecords = (ServiceRecord[])Utils.vector2toArray(records, (Object[])new ServiceRecord[records.size()]);
                listener.servicesDiscovered(sst.getTransID(), fileteredRecords);
                return 1;
              } 
            } 
            DebugLog.debug("SERVICE_SEARCH_NO_RECORDS");
            return 4;
          } 
        }
      };
    return SearchServicesThread.startSearchServices(this, searchRunnable, attrSet, uuidSet, device, listener);
  }
  
  static Class class$(String x0) {
    try {
      return Class.forName(x0);
    } catch (ClassNotFoundException x1) {
      throw new NoClassDefFoundError(x1.getMessage());
    } 
  }
  
  public boolean cancelServiceSearch(int transID) {
    SearchServicesThread sst = SearchServicesThread.getServiceSearchThread(transID);
    if (sst != null)
      synchronized (this) {
        if (!sst.isTerminated()) {
          sst.setTerminated();
          cancelServiceSearchImpl();
          return true;
        } 
      }  
    return false;
  }
  
  public boolean populateServicesRecordAttributeValues(ServiceRecordImpl serviceRecord, int[] attrIDs) throws IOException {
    if (attrIDs.length > 256)
      throw new IllegalArgumentException(); 
    boolean anyRetrived = false;
    for (int i = 0; i < attrIDs.length; i++) {
      int id = attrIDs[i];
      try {
        byte[] sdpStruct = getServiceAttribute(id, serviceRecord.getHandle());
        if (sdpStruct != null) {
          DataElement element = (new BluetoothStackWIDCOMMSDPInputStream(new ByteArrayInputStream(sdpStruct))).readElement();
          if (id == 4) {
            Enumeration protocolsSeqEnum = (Enumeration)element.getValue();
            if (protocolsSeqEnum.hasMoreElements()) {
              DataElement protocolElement = protocolsSeqEnum.nextElement();
              if (protocolElement.getDataType() != 48) {
                DataElement newMainSeq = new DataElement(48);
                newMainSeq.addElement(element);
                element = newMainSeq;
              } 
            } 
          } 
          serviceRecord.populateAttributeValue(id, element);
          anyRetrived = true;
        } 
      } catch (Throwable e) {}
    } 
    return anyRetrived;
  }
  
  public long connectionRfOpenClientConnection(BluetoothConnectionParams params) throws IOException {
    verifyDeviceReady();
    return connectionRfOpenClientConnectionImpl(params.address, params.channel, params.authenticate, params.encrypt, params.timeout);
  }
  
  public void connectionRfCloseClientConnection(long handle) throws IOException {
    closeRfCommPortImpl(handle);
  }
  
  public void connectionRfWrite(long handle, int b) throws IOException {
    byte[] buf = new byte[1];
    buf[0] = (byte)(b & 0xFF);
    connectionRfWriteImpl(handle, buf, 0, 1);
  }
  
  public void connectionRfWrite(long handle, byte[] b, int off, int len) throws IOException {
    int maxNativeBuffer = 65535;
    if (len < 65535) {
      connectionRfWriteImpl(handle, b, off, len);
    } else {
      int done = 0;
      while (done < len) {
        int l = len - done;
        if (l > 65535)
          l = 65535; 
        connectionRfWriteImpl(handle, b, off + done, l);
        done += 65535;
      } 
    } 
  }
  
  public void connectionRfFlush(long handle) throws IOException {}
  
  public int rfGetSecurityOpt(long handle, int expected) throws IOException {
    return expected;
  }
  
  public boolean rfEncrypt(long address, long handle, boolean on) throws IOException {
    return false;
  }
  
  public long rfServerOpen(BluetoothConnectionNotifierParams params, ServiceRecordImpl serviceRecord) throws IOException {
    verifyDeviceReady();
    byte[] uuidValue = Utils.UUIDToByteArray(params.uuid);
    byte[] uuidValue2 = params.obex ? null : Utils.UUIDToByteArray(BluetoothConsts.SERIAL_PORT_UUID);
    long handle = rfServerOpenImpl(uuidValue, uuidValue2, params.obex, params.name, params.authenticate, params.encrypt);
    int channel = rfServerSCN(handle);
    DebugLog.debug("serverSCN", channel);
    long serviceRecordHandle = handle;
    serviceRecord.populateRFCOMMAttributes(serviceRecordHandle, channel, params.uuid, params.name, params.obex);
    return handle;
  }
  
  private byte[] long2byte(long value, int len) {
    byte[] cvalue = new byte[len];
    long l = value;
    for (int i = len - 1; i >= 0; i--) {
      cvalue[i] = (byte)(int)(l & 0xFFL);
      l >>= 8L;
    } 
    return cvalue;
  }
  
  public void rfServerUpdateServiceRecord(long handle, ServiceRecordImpl serviceRecord, boolean acceptAndOpen) throws ServiceRegistrationException {
    sdpServiceUpdateServiceRecord(handle, 'r', serviceRecord);
  }
  
  private byte[] sdpServiceSequenceAttribute(Enumeration en) throws ServiceRegistrationException {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    SDPOutputStream sdpOut = new SDPOutputStream(out);
    try {
      while (en.hasMoreElements())
        sdpOut.writeElement(en.nextElement()); 
    } catch (IOException e) {
      throw new ServiceRegistrationException(e.getMessage());
    } 
    return out.toByteArray();
  }
  
  private void sdpServiceUpdateServiceRecord(long handle, char handleType, ServiceRecordImpl serviceRecord) throws ServiceRegistrationException {
    int[] ids = serviceRecord.getAttributeIDs();
    if (ids == null || ids.length == 0)
      return; 
    DataElement serviceClassIDList = serviceRecord.getAttributeValue(1);
    if (serviceClassIDList.getDataType() != 48)
      throw new ServiceRegistrationException("Invalid serviceClassIDList"); 
    Enumeration en = (Enumeration)serviceClassIDList.getValue();
    Vector uuids = new Vector();
    while (en.hasMoreElements()) {
      DataElement u = en.nextElement();
      if (u.getDataType() != 24)
        throw new ServiceRegistrationException("Invalid serviceClassIDList element " + u); 
      uuids.add(u.getValue());
    } 
    if (uuids.size() > 0) {
      byte[][] uuidValues = new byte[uuids.size()][];
      for (int u = 0; u < uuidValues.length; u++)
        uuidValues[u] = Utils.UUIDToByteArray((UUID)uuids.elementAt(u)); 
      sdpServiceAddServiceClassIdList(handle, handleType, uuidValues);
    } 
    for (int i = 0; i < ids.length; i++) {
      DataElement d;
      int id = ids[i];
      switch (id) {
        case 0:
        case 1:
        case 4:
        case 256:
          break;
        default:
          d = serviceRecord.getAttributeValue(id);
          switch (d.getDataType()) {
            case 8:
              sdpServiceAddAttribute(handle, handleType, id, (short)1, long2byte(d.getLong(), 1));
              break;
            case 9:
              sdpServiceAddAttribute(handle, handleType, id, (short)1, long2byte(d.getLong(), 2));
              break;
            case 10:
              sdpServiceAddAttribute(handle, handleType, id, (short)1, long2byte(d.getLong(), 4));
              break;
            case 11:
            case 12:
              sdpServiceAddAttribute(handle, handleType, id, (short)1, (byte[])d.getValue());
              break;
            case 16:
              sdpServiceAddAttribute(handle, handleType, id, (short)2, long2byte(d.getLong(), 1));
              break;
            case 17:
              sdpServiceAddAttribute(handle, handleType, id, (short)2, long2byte(d.getLong(), 2));
              break;
            case 18:
              sdpServiceAddAttribute(handle, handleType, id, (short)2, long2byte(d.getLong(), 4));
              break;
            case 19:
              sdpServiceAddAttribute(handle, handleType, id, (short)2, long2byte(d.getLong(), 8));
              break;
            case 20:
              sdpServiceAddAttribute(handle, handleType, id, (short)2, (byte[])d.getValue());
              break;
            case 64:
              sdpServiceAddAttribute(handle, handleType, id, (short)8, Utils.getASCIIBytes(d.getValue().toString()));
              break;
            case 32:
              sdpServiceAddAttribute(handle, handleType, id, (short)4, Utils.getUTF8Bytes(d.getValue().toString()));
              break;
            case 0:
              sdpServiceAddAttribute(handle, handleType, id, (short)0, null);
              break;
            case 40:
              sdpServiceAddAttribute(handle, handleType, id, (short)5, new byte[] { (byte)(d.getBoolean() ? 1 : 0) });
              break;
            case 24:
              sdpServiceAddAttribute(handle, handleType, id, (short)3, BluetoothStackWIDCOMMSDPInputStream.getUUIDHexBytes((UUID)d.getValue()));
              break;
            case 48:
              sdpServiceAddAttribute(handle, handleType, id, (short)6, sdpServiceSequenceAttribute((Enumeration)d.getValue()));
              break;
            case 56:
              sdpServiceAddAttribute(handle, handleType, id, (short)7, sdpServiceSequenceAttribute((Enumeration)d.getValue()));
              break;
          } 
          throw new ServiceRegistrationException("Invalid " + d.getDataType());
      } 
    } 
  }
  
  public void rfServerClose(long handle, ServiceRecordImpl serviceRecord) throws IOException {
    rfServerCloseImpl(handle);
  }
  
  private void validateMTU(int receiveMTU, int transmitMTU) {
    if (receiveMTU > 1024)
      throw new IllegalArgumentException("invalid ReceiveMTU value " + receiveMTU); 
  }
  
  public long l2OpenClientConnection(BluetoothConnectionParams params, int receiveMTU, int transmitMTU) throws IOException {
    verifyDeviceReady();
    validateMTU(receiveMTU, transmitMTU);
    return l2OpenClientConnectionImpl(params.address, params.channel, params.authenticate, params.encrypt, receiveMTU, transmitMTU, params.timeout);
  }
  
  public long l2ServerOpen(BluetoothConnectionNotifierParams params, int receiveMTU, int transmitMTU, ServiceRecordImpl serviceRecord) throws IOException {
    verifyDeviceReady();
    validateMTU(receiveMTU, transmitMTU);
    byte[] uuidValue = Utils.UUIDToByteArray(params.uuid);
    long handle = l2ServerOpenImpl(uuidValue, params.authenticate, params.encrypt, params.name, receiveMTU, transmitMTU, params.bluecove_ext_psm);
    int channel = l2ServerPSM(handle);
    int serviceRecordHandle = (int)handle;
    serviceRecord.populateL2CAPAttributes(serviceRecordHandle, channel, params.uuid, params.name);
    return handle;
  }
  
  public void l2ServerUpdateServiceRecord(long handle, ServiceRecordImpl serviceRecord, boolean acceptAndOpen) throws ServiceRegistrationException {
    sdpServiceUpdateServiceRecord(handle, 'l', serviceRecord);
  }
  
  public void l2ServerClose(long handle, ServiceRecordImpl serviceRecord) throws IOException {
    l2ServerCloseImpl(handle);
  }
  
  public int l2GetSecurityOpt(long handle, int expected) throws IOException {
    return expected;
  }
  
  public boolean l2Encrypt(long address, long handle, boolean on) throws IOException {
    return false;
  }
  
  private native int nativeBuildFeatures();
  
  public native boolean isNativeCodeLoaded();
  
  public native int getLibraryVersion();
  
  public native int detectBluetoothStack();
  
  public native void enableNativeDebug(Class paramClass, boolean paramBoolean);
  
  public native boolean initializeImpl();
  
  private native void uninitialize();
  
  public native String getLocalDeviceBluetoothAddress() throws BluetoothStateException;
  
  public native String getLocalDeviceName();
  
  private native int getDeviceClassImpl();
  
  private native boolean isStackServerUp();
  
  public native boolean isLocalDeviceDiscoverable();
  
  public native boolean isLocalDevicePowerOn();
  
  private native String getBTWVersionInfo();
  
  private native int getDeviceVersion();
  
  private native int getDeviceManufacturer();
  
  private native boolean authenticateRemoteDeviceImpl(long paramLong, String paramString) throws IOException;
  
  private native void removeAuthenticationWithRemoteDeviceImpl(long paramLong) throws IOException;
  
  private native boolean isRemoteDeviceConnected(long paramLong);
  
  private native String getRemoteDeviceLinkMode(long paramLong);
  
  private native String getRemoteDeviceVersionInfo(long paramLong);
  
  private native boolean setSniffMode(long paramLong);
  
  private native boolean cancelSniffMode(long paramLong);
  
  private native int getRemoteDeviceRSSI(long paramLong);
  
  private native int runDeviceInquiryImpl(DeviceInquiryRunnable paramDeviceInquiryRunnable, DeviceInquiryThread paramDeviceInquiryThread, int paramInt, DiscoveryListener paramDiscoveryListener) throws BluetoothStateException;
  
  private native boolean deviceInquiryCancelImpl();
  
  native String getRemoteDeviceFriendlyName(long paramLong, int paramInt1, int paramInt2) throws IOException;
  
  native String peekRemoteDeviceFriendlyName(long paramLong);
  
  private native long[] runSearchServicesImpl(SearchServicesThread paramSearchServicesThread, byte[] paramArrayOfbyte, long paramLong) throws BluetoothStateException, SearchServicesTerminatedException;
  
  private native void cancelServiceSearchImpl();
  
  private native byte[] getServiceAttribute(int paramInt, long paramLong) throws IOException;
  
  private native boolean isServiceRecordDiscoverable(long paramLong1, long paramLong2) throws IOException;
  
  private native long connectionRfOpenClientConnectionImpl(long paramLong, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2) throws IOException;
  
  private native void closeRfCommPortImpl(long paramLong) throws IOException;
  
  public native long getConnectionRfRemoteAddress(long paramLong) throws IOException;
  
  public native int connectionRfRead(long paramLong) throws IOException;
  
  public native int connectionRfRead(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
  
  public native int connectionRfReadAvailable(long paramLong) throws IOException;
  
  private native void connectionRfWriteImpl(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
  
  private synchronized native long rfServerOpenImpl(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, boolean paramBoolean1, String paramString, boolean paramBoolean2, boolean paramBoolean3) throws IOException;
  
  private native int rfServerSCN(long paramLong) throws IOException;
  
  private native void sdpServiceAddAttribute(long paramLong, char paramChar, int paramInt, short paramShort, byte[] paramArrayOfbyte) throws ServiceRegistrationException;
  
  private native void sdpServiceAddServiceClassIdList(long paramLong, char paramChar, byte[][] paramArrayOfbyte) throws ServiceRegistrationException;
  
  public native long rfServerAcceptAndOpenRfServerConnection(long paramLong) throws IOException;
  
  public native void connectionRfCloseServerConnection(long paramLong) throws IOException;
  
  private native void rfServerCloseImpl(long paramLong) throws IOException;
  
  private native long l2OpenClientConnectionImpl(long paramLong, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3, int paramInt4) throws IOException;
  
  public native void l2CloseClientConnection(long paramLong) throws IOException;
  
  private synchronized native long l2ServerOpenImpl(byte[] paramArrayOfbyte, boolean paramBoolean1, boolean paramBoolean2, String paramString, int paramInt1, int paramInt2, int paramInt3) throws IOException;
  
  public native int l2ServerPSM(long paramLong) throws IOException;
  
  public native long l2ServerAcceptAndOpenServerConnection(long paramLong) throws IOException;
  
  public native void l2CloseServerConnection(long paramLong) throws IOException;
  
  private native void l2ServerCloseImpl(long paramLong) throws IOException;
  
  public native int l2GetReceiveMTU(long paramLong) throws IOException;
  
  public native int l2GetTransmitMTU(long paramLong) throws IOException;
  
  public native boolean l2Ready(long paramLong) throws IOException;
  
  public native int l2Receive(long paramLong, byte[] paramArrayOfbyte) throws IOException;
  
  public native void l2Send(long paramLong, byte[] paramArrayOfbyte, int paramInt) throws IOException;
  
  public native long l2RemoteAddress(long paramLong) throws IOException;
}
