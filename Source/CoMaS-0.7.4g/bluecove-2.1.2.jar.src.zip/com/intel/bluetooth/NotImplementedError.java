package com.intel.bluetooth;

public class NotImplementedError extends Error {
  private static final long serialVersionUID = 1L;
  
  public static final boolean enabled = true;
  
  public NotImplementedError() {
    super("Not Implemented");
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\NotImplementedError.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */