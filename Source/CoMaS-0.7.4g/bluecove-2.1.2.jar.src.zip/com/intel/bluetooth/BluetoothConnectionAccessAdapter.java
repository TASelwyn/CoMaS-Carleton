package com.intel.bluetooth;

import java.io.IOException;
import javax.bluetooth.RemoteDevice;

public abstract class BluetoothConnectionAccessAdapter implements BluetoothConnectionAccess {
  protected abstract BluetoothConnectionAccess getImpl();
  
  public long getRemoteAddress() throws IOException {
    return getImpl().getRemoteAddress();
  }
  
  public RemoteDevice getRemoteDevice() {
    return getImpl().getRemoteDevice();
  }
  
  public boolean isClosed() {
    return getImpl().isClosed();
  }
  
  public void shutdown() throws IOException {
    getImpl().shutdown();
  }
  
  public void markAuthenticated() {
    getImpl().markAuthenticated();
  }
  
  public int getSecurityOpt() {
    return getImpl().getSecurityOpt();
  }
  
  public boolean encrypt(long address, boolean on) throws IOException {
    return getImpl().encrypt(address, on);
  }
  
  public void setRemoteDevice(RemoteDevice remoteDevice) {
    getImpl().setRemoteDevice(remoteDevice);
  }
  
  public BluetoothStack getBluetoothStack() {
    return getImpl().getBluetoothStack();
  }
}
