/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NativeLibLoader
/*     */ {
/*     */   static final int OS_UNSUPPORTED = -1;
/*     */   static final int OS_LINUX = 1;
/*     */   static final int OS_WINDOWS = 2;
/*     */   static final int OS_WINDOWS_CE = 3;
/*     */   static final int OS_MAC_OS_X = 4;
/*     */   static final int OS_ANDROID_1_X = 5;
/*     */   static final int OS_ANDROID_2_X = 6;
/*  64 */   private static int os = 0;
/*     */   
/*  66 */   private static Hashtable libsState = new Hashtable();
/*     */   
/*  68 */   private static Object bluecoveDllDir = null;
/*     */   
/*     */   private static class LibState
/*     */   {
/*     */     private LibState() {}
/*     */     
/*     */     boolean triedToLoadAlredy = false;
/*     */     boolean libraryAvailable = false;
/*  76 */     StringBuffer loadErrors = new StringBuffer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getOS() {
/*  84 */     if (os != 0) {
/*  85 */       return os;
/*     */     }
/*  87 */     String sysName = System.getProperty("os.name");
/*  88 */     if (sysName == null) {
/*  89 */       DebugLog.fatal("Native Library not available on unknown platform");
/*  90 */       os = -1;
/*     */     } else {
/*  92 */       sysName = sysName.toLowerCase();
/*  93 */       if (sysName.indexOf("windows") != -1) {
/*  94 */         if (sysName.indexOf("ce") != -1) {
/*  95 */           os = 3;
/*     */         } else {
/*  97 */           os = 2;
/*     */         } 
/*  99 */       } else if (sysName.indexOf("mac os x") != -1) {
/* 100 */         os = 4;
/* 101 */       } else if (sysName.indexOf("linux") != -1) {
/* 102 */         String javaRuntimeName = System.getProperty("java.runtime.name");
/* 103 */         if (javaRuntimeName != null && javaRuntimeName.toLowerCase().indexOf("android runtime") != -1) {
/*     */           try {
/* 105 */             int androidApiLevel = Class.forName("android.os.Build$VERSION").getField("SDK_INT").getInt(null);
/*     */             
/* 107 */             if (androidApiLevel >= 5) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 113 */               Class.forName("com.intel.bluetooth.BluetoothStackAndroid");
/* 114 */               os = 6;
/*     */             } else {
/* 116 */               os = 5;
/*     */             } 
/* 118 */           } catch (Exception ex) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 126 */             os = 5;
/*     */           } 
/*     */         } else {
/* 129 */           os = 1;
/*     */         } 
/*     */       } else {
/* 132 */         DebugLog.fatal("Native Library not available on platform " + sysName);
/* 133 */         os = -1;
/*     */       } 
/*     */     } 
/* 136 */     return os;
/*     */   }
/*     */   
/*     */   static boolean isAvailable(String name) {
/* 140 */     return isAvailable(name, null);
/*     */   }
/*     */   
/*     */   static String getLoadErrors(String name) {
/* 144 */     LibState state = (LibState)libsState.get(name);
/* 145 */     if (state == null || state.loadErrors == null) {
/* 146 */       return "";
/*     */     }
/* 148 */     return state.loadErrors.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean isAvailable(String name, Class stackClass) {
/* 153 */     return isAvailable(name, stackClass, true);
/*     */   }
/*     */   
/*     */   static boolean isAvailable(String name, Class stackClass, boolean requiredLibrary) {
/* 157 */     LibState state = (LibState)libsState.get(name);
/* 158 */     if (state == null) {
/* 159 */       state = new LibState();
/* 160 */       libsState.put(name, state);
/*     */     } 
/* 162 */     if (state.triedToLoadAlredy) {
/* 163 */       return state.libraryAvailable;
/*     */     }
/* 165 */     state.loadErrors = new StringBuffer();
/* 166 */     String libName = name;
/* 167 */     String libFileName = libName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 175 */     String sysName = System.getProperty("os.name");
/*     */     
/* 177 */     String sysArch = System.getProperty("os.arch");
/* 178 */     if (sysArch != null) {
/* 179 */       sysArch = sysArch.toLowerCase();
/*     */     } else {
/* 181 */       sysArch = "";
/*     */     } 
/*     */     
/* 184 */     switch (getOS()) {
/*     */       case -1:
/* 186 */         state.loadErrors.append("Native Library " + name + " not available on [" + sysName + "] platform");
/* 187 */         DebugLog.fatal("Native Library " + name + " not available on [" + sysName + "] platform");
/* 188 */         state.triedToLoadAlredy = true;
/* 189 */         state.libraryAvailable = false;
/* 190 */         return state.libraryAvailable;
/*     */       case 3:
/* 192 */         libName = libName + "_ce";
/* 193 */         libFileName = libName;
/* 194 */         libFileName = libFileName + ".dll";
/*     */         break;
/*     */       case 2:
/* 197 */         if (sysArch.indexOf("amd64") != -1 || sysArch.indexOf("x86_64") != -1) {
/* 198 */           libName = libName + "_x64";
/* 199 */           libFileName = libName;
/*     */         } 
/* 201 */         libFileName = libFileName + ".dll";
/*     */         break;
/*     */       case 4:
/* 204 */         libFileName = "lib" + libFileName + ".jnilib";
/*     */         break;
/*     */       case 1:
/* 207 */         if (sysArch.indexOf("i386") == -1 && sysArch.length() != 0)
/*     */         {
/* 209 */           if (sysArch.indexOf("amd64") != -1 || sysArch.indexOf("x86_64") != -1) {
/* 210 */             libName = libName + "_x64";
/* 211 */           } else if (sysArch.indexOf("x86") == -1) {
/*     */ 
/*     */ 
/*     */             
/* 215 */             libName = libName + "_" + sysArch;
/*     */           }  } 
/* 217 */         libFileName = libName;
/* 218 */         libFileName = "lib" + libFileName + ".so";
/*     */         break;
/*     */       case 5:
/* 221 */         libFileName = "lib" + libFileName + ".so";
/*     */         break;
/*     */       
/*     */       case 6:
/* 225 */         state.libraryAvailable = true;
/*     */         break;
/*     */       default:
/* 228 */         state.loadErrors.append("Native Library " + name + " not available on [" + sysName + "] platform");
/* 229 */         DebugLog.fatal("Native Library " + name + " not available on platform " + sysName);
/* 230 */         state.triedToLoadAlredy = true;
/* 231 */         state.libraryAvailable = false;
/* 232 */         return state.libraryAvailable;
/*     */     } 
/*     */     
/* 235 */     String path = System.getProperty("bluecove.native.path");
/* 236 */     if (path != null && 
/* 237 */       !UtilsJavaSE.ibmJ9midp) {
/* 238 */       state.libraryAvailable = tryloadPath(path, libFileName, state.loadErrors);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 245 */     boolean useResource = true;
/* 246 */     String d = System.getProperty("bluecove.native.resource");
/* 247 */     if ((d != null && d.equalsIgnoreCase("false")) || getOS() == 5 || getOS() == 6) {
/* 248 */       useResource = false;
/*     */     }
/*     */     
/* 251 */     if (!state.libraryAvailable && useResource && !UtilsJavaSE.ibmJ9midp) {
/* 252 */       state.libraryAvailable = loadAsSystemResource(libFileName, stackClass, state.loadErrors);
/*     */     }
/*     */ 
/*     */     
/* 256 */     if (!state.libraryAvailable && getOS() == 1 && !UtilsJavaSE.ibmJ9midp) {
/* 257 */       state.libraryAvailable = tryloadPath(createLinuxPackagePath(sysArch), libFileName, state.loadErrors);
/*     */     }
/*     */     
/* 260 */     if (!state.libraryAvailable) {
/* 261 */       if (!UtilsJavaSE.ibmJ9midp) {
/* 262 */         state.libraryAvailable = tryload(libName, state.loadErrors);
/*     */       } else {
/* 264 */         state.libraryAvailable = tryloadIBMj9MIDP(libName);
/*     */       } 
/*     */     }
/*     */     
/* 268 */     if (!state.libraryAvailable) {
/* 269 */       if (requiredLibrary) {
/* 270 */         System.err.println("Native Library " + libName + " not available");
/*     */       }
/* 272 */       DebugLog.debug("java.library.path", System.getProperty("java.library.path"));
/*     */     } 
/* 274 */     state.triedToLoadAlredy = true;
/* 275 */     return state.libraryAvailable;
/*     */   }
/*     */   
/*     */   private static String createLinuxPackagePath(String sysArch) {
/* 279 */     if (sysArch.indexOf("64") != -1) {
/* 280 */       return "/usr/lib64/bluecove/" + BlueCoveImpl.version;
/*     */     }
/* 282 */     return "/usr/lib/bluecove/" + BlueCoveImpl.version;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean tryload(String name, StringBuffer loadErrors) {
/*     */     try {
/* 288 */       System.loadLibrary(name);
/* 289 */       DebugLog.debug("Library loaded", name);
/* 290 */     } catch (Throwable e) {
/* 291 */       DebugLog.error("Library " + name + " not loaded ", e);
/* 292 */       loadErrors.append("\nload [").append(name).append("] ").append(e.getMessage());
/* 293 */       return false;
/*     */     } 
/* 295 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean tryloadIBMj9MIDP(String name) {
/*     */     try {
/* 300 */       IBMJ9Helper.loadLibrary(name);
/* 301 */       DebugLog.debug("Library loaded", name);
/* 302 */     } catch (Throwable e) {
/* 303 */       DebugLog.error("Library " + name + " not loaded ", e);
/* 304 */       return false;
/*     */     } 
/* 306 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean tryloadPath(String path, String name, StringBuffer loadErrors) {
/* 310 */     UtilsStringTokenizer tok = new UtilsStringTokenizer(path, File.pathSeparator);
/* 311 */     while (tok.hasMoreTokens()) {
/* 312 */       String dirPath = tok.nextToken();
/* 313 */       File dir = new File(dirPath);
/* 314 */       if (dir.isDirectory() && 
/* 315 */         tryloadFile(dir, name, loadErrors)) {
/* 316 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 320 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean tryloadFile(File path, String name, StringBuffer loadErrors) {
/* 324 */     File f = new File(path, name);
/* 325 */     if (!f.canRead()) {
/* 326 */       DebugLog.debug("Native Library " + f.getAbsolutePath() + " not found");
/* 327 */       return false;
/*     */     } 
/*     */     try {
/* 330 */       System.load(f.getAbsolutePath());
/* 331 */       DebugLog.debug("Library loaded", f.getAbsolutePath());
/* 332 */       return true;
/* 333 */     } catch (Throwable e) {
/* 334 */       DebugLog.error("Can't load library from path " + path, e);
/* 335 */       loadErrors.append("\nload [").append(f.getAbsolutePath()).append("] ").append(e.getMessage());
/* 336 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean tryloadPathIBMj9MIDP(String path, String name) {
/*     */     try {
/* 342 */       IBMJ9Helper.loadLibrary(path + "\\" + name);
/* 343 */       DebugLog.debug("Library loaded", path + "\\" + name);
/* 344 */     } catch (Throwable e) {
/* 345 */       DebugLog.error("Can't load library from path " + path + "\\" + name, e);
/* 346 */       return false;
/*     */     } 
/* 348 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean loadAsSystemResource(String libFileName, Class stackClass, StringBuffer loadErrors) {
/* 352 */     InputStream is = null;
/*     */     try {
/* 354 */       ClassLoader clo = null;
/*     */       try {
/* 356 */         if (stackClass != null) {
/* 357 */           clo = stackClass.getClassLoader();
/* 358 */           DebugLog.debug("Use stack ClassLoader");
/*     */         } else {
/* 360 */           clo = NativeLibLoader.class.getClassLoader();
/*     */         } 
/* 362 */       } catch (Throwable j9) {}
/*     */       
/* 364 */       if (clo == null) {
/* 365 */         DebugLog.debug("Use System ClassLoader");
/* 366 */         is = ClassLoader.getSystemResourceAsStream(libFileName);
/*     */       } else {
/* 368 */         is = clo.getResourceAsStream(libFileName);
/*     */       } 
/* 370 */     } catch (Throwable e) {
/* 371 */       DebugLog.error("Native Library " + libFileName + " is not a Resource !");
/* 372 */       loadErrors.append("\nresource not found ").append(libFileName);
/* 373 */       return false;
/*     */     } 
/* 375 */     if (is == null) {
/* 376 */       DebugLog.error("Native Library " + libFileName + " is not a Resource !");
/* 377 */       loadErrors.append("\nresource not found ").append(libFileName);
/* 378 */       return false;
/*     */     } 
/* 380 */     File fd = makeTempName(libFileName);
/*     */     try {
/* 382 */       if (!copy2File(is, fd)) {
/* 383 */         loadErrors.append("\ncan't create temp file");
/* 384 */         return false;
/*     */       } 
/*     */     } finally {
/*     */       try {
/* 388 */         is.close();
/* 389 */       } catch (IOException ignore) {
/* 390 */         is = null;
/*     */       } 
/*     */     } 
/*     */     try {
/* 394 */       fd.deleteOnExit();
/* 395 */     } catch (Throwable e) {}
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 400 */       System.load(fd.getAbsolutePath());
/* 401 */       DebugLog.debug("Library loaded from", fd);
/* 402 */     } catch (Throwable e) {
/* 403 */       DebugLog.fatal("Can't load library file ", e);
/* 404 */       loadErrors.append("\nload resource [").append(fd.getAbsolutePath()).append("] ").append(e.getMessage());
/* 405 */       File debugFileCreated = new File(fd.getAbsolutePath());
/* 406 */       if (!debugFileCreated.canRead()) {
/* 407 */         DebugLog.fatal("File " + fd.getAbsolutePath() + " magicaly disappeared");
/*     */       }
/* 409 */       return false;
/*     */     } 
/* 411 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean copy2File(InputStream is, File fd) {
/* 415 */     FileOutputStream fos = null;
/*     */     try {
/* 417 */       fos = new FileOutputStream(fd);
/* 418 */       byte[] b = new byte[1000];
/*     */       int len;
/* 420 */       while ((len = is.read(b)) >= 0) {
/* 421 */         fos.write(b, 0, len);
/*     */       }
/* 423 */       return true;
/* 424 */     } catch (Throwable e) {
/* 425 */       DebugLog.debug("Can't create temp file ", e);
/* 426 */       System.err.println("Can't create temp file " + fd.getAbsolutePath());
/* 427 */       return false;
/*     */     } finally {
/* 429 */       if (fos != null) {
/*     */         try {
/* 431 */           fos.close();
/* 432 */         } catch (IOException ignore) {
/* 433 */           fos = null;
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static File makeTempName(String libFileName) {
/* 440 */     if (bluecoveDllDir != null) {
/* 441 */       File f = new File((File)bluecoveDllDir, libFileName);
/* 442 */       DebugLog.debug("tmp file", f.getAbsolutePath());
/* 443 */       return f;
/*     */     } 
/* 445 */     String tmpDir = System.getProperty("java.io.tmpdir");
/* 446 */     if (tmpDir == null || tmpDir.length() == 0)
/*     */     {
/* 448 */       tmpDir = "temp";
/*     */     }
/* 450 */     String uname = System.getProperty("user.name");
/* 451 */     int count = 0;
/* 452 */     File fd = null;
/* 453 */     File dir = null;
/*     */     label48: while (true) {
/* 455 */       if (count > 10) {
/* 456 */         DebugLog.debug("Can't create temporary dir " + dir.getAbsolutePath());
/* 457 */         return new File(tmpDir, libFileName);
/*     */       } 
/* 459 */       dir = new File(tmpDir, "bluecove_" + uname + "_" + count++);
/* 460 */       if (dir.exists()) {
/* 461 */         if (!dir.isDirectory()) {
/*     */           continue;
/*     */         }
/*     */         
/*     */         try {
/* 466 */           File[] files = dir.listFiles();
/* 467 */           for (int i = 0; i < files.length; i++) {
/* 468 */             if (!files[i].delete()) {
/*     */               continue label48;
/*     */             }
/*     */           } 
/* 472 */         } catch (Throwable e) {}
/*     */       } 
/*     */ 
/*     */       
/* 476 */       if (!dir.exists() && !dir.mkdirs()) {
/* 477 */         DebugLog.debug("Can't create temporary dir ", dir.getAbsolutePath());
/*     */         continue;
/*     */       } 
/*     */       try {
/* 481 */         dir.deleteOnExit();
/* 482 */       } catch (Throwable e) {}
/*     */ 
/*     */       
/* 485 */       fd = new File(dir, libFileName);
/* 486 */       if (fd.exists() && !fd.delete()) {
/*     */         continue;
/*     */       }
/*     */       try {
/* 490 */         if (!fd.createNewFile()) {
/* 491 */           DebugLog.debug("Can't create file in temporary dir ", fd.getAbsolutePath()); continue;
/*     */         } 
/*     */         break;
/* 494 */       } catch (IOException e) {
/* 495 */         DebugLog.debug("Can't create file in temporary dir ", fd.getAbsolutePath());
/*     */       }
/* 497 */       catch (Throwable e) {
/*     */         break;
/*     */       } 
/* 500 */     }  bluecoveDllDir = dir;
/* 501 */     DebugLog.debug("set dll dir", dir.getAbsolutePath());
/*     */ 
/*     */     
/* 504 */     return fd;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\NativeLibLoader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */