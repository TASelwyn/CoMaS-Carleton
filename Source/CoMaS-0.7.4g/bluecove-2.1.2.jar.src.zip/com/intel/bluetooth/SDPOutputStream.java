package com.intel.bluetooth;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Enumeration;
import javax.bluetooth.DataElement;
import javax.bluetooth.UUID;

class SDPOutputStream extends OutputStream {
  OutputStream dst;
  
  public SDPOutputStream(OutputStream out) {
    this.dst = out;
  }
  
  public void write(int oneByte) throws IOException {
    this.dst.write(oneByte);
  }
  
  private void writeLong(long l, int size) throws IOException {
    for (int i = 0; i < size; i++) {
      write((int)(l >> size - 1 << 3));
      l <<= 8L;
    } 
  }
  
  private void writeBytes(byte[] b) throws IOException {
    for (int i = 0; i < b.length; i++)
      write(b[i]); 
  }
  
  static int getLength(DataElement d) {
    long uuid;
    byte[] b;
    int result;
    Enumeration e;
    switch (d.getDataType()) {
      case 0:
        return 1;
      case 8:
      case 16:
      case 40:
        return 2;
      case 9:
      case 17:
        return 3;
      case 10:
      case 18:
        return 5;
      case 11:
      case 19:
        return 9;
      case 12:
      case 20:
        return 17;
      case 24:
        uuid = Utils.UUIDTo32Bit((UUID)d.getValue());
        if (uuid == -1L)
          return 17; 
        if (uuid <= 65535L)
          return 3; 
        return 5;
      case 32:
        if (BlueCoveImpl.getConfigProperty("bluecove.sdp.string_encoding_ascii", false)) {
          b = Utils.getASCIIBytes((String)d.getValue());
        } else {
          b = Utils.getUTF8Bytes((String)d.getValue());
        } 
        if (b.length < 256)
          return b.length + 2; 
        if (b.length < 65536)
          return b.length + 3; 
        return b.length + 5;
      case 64:
        b = Utils.getASCIIBytes((String)d.getValue());
        if (b.length < 256)
          return b.length + 2; 
        if (b.length < 65536)
          return b.length + 3; 
        return b.length + 5;
      case 48:
      case 56:
        result = 1;
        for (e = (Enumeration)d.getValue(); e.hasMoreElements();)
          result += getLength(e.nextElement()); 
        if (result < 255) {
          result++;
        } else if (result < 65535) {
          result += 2;
        } else {
          result += 4;
        } 
        return result;
    } 
    throw new IllegalArgumentException();
  }
  
  void writeElement(DataElement d) throws IOException {
    long uuid;
    byte[] arrayOfByte1;
    int sizeDescriptor;
    byte[] b;
    int len;
    int lenSize;
    Enumeration enumeration1;
    Enumeration e;
    switch (d.getDataType()) {
      case 0:
        write(0);
        return;
      case 8:
        write(8);
        writeLong(d.getLong(), 1);
        return;
      case 9:
        write(9);
        writeLong(d.getLong(), 2);
        return;
      case 10:
        write(10);
        writeLong(d.getLong(), 4);
        return;
      case 11:
        write(11);
        writeBytes((byte[])d.getValue());
        return;
      case 12:
        write(12);
        writeBytes((byte[])d.getValue());
        return;
      case 16:
        write(16);
        writeLong(d.getLong(), 1);
        return;
      case 17:
        write(17);
        writeLong(d.getLong(), 2);
        return;
      case 18:
        write(18);
        writeLong(d.getLong(), 4);
        return;
      case 19:
        write(19);
        writeLong(d.getLong(), 8);
        return;
      case 20:
        write(20);
        writeBytes((byte[])d.getValue());
        return;
      case 24:
        uuid = Utils.UUIDTo32Bit((UUID)d.getValue());
        if (uuid == -1L) {
          write(28);
          writeBytes(Utils.UUIDToByteArray((UUID)d.getValue()));
        } else if (uuid <= 65535L) {
          write(25);
          writeLong(uuid, 2);
        } else {
          write(26);
          writeLong(uuid, 4);
        } 
        return;
      case 32:
        if (BlueCoveImpl.getConfigProperty("bluecove.sdp.string_encoding_ascii", false)) {
          arrayOfByte1 = Utils.getASCIIBytes((String)d.getValue());
        } else {
          arrayOfByte1 = Utils.getUTF8Bytes((String)d.getValue());
        } 
        if (arrayOfByte1.length < 256) {
          write(37);
          writeLong(arrayOfByte1.length, 1);
        } else if (arrayOfByte1.length < 65536) {
          write(38);
          writeLong(arrayOfByte1.length, 2);
        } else {
          write(39);
          writeLong(arrayOfByte1.length, 4);
        } 
        writeBytes(arrayOfByte1);
        return;
      case 40:
        write(40);
        writeLong(d.getBoolean() ? 1L : 0L, 1);
        return;
      case 48:
        len = getLength(d);
        if (len < 257) {
          sizeDescriptor = 5;
          lenSize = 1;
        } else if (len < 65538) {
          sizeDescriptor = 6;
          lenSize = 2;
        } else {
          sizeDescriptor = 7;
          lenSize = 4;
        } 
        len -= 1 + lenSize;
        write(0x30 | sizeDescriptor);
        writeLong(len, lenSize);
        for (enumeration1 = (Enumeration)d.getValue(); enumeration1.hasMoreElements();)
          writeElement(enumeration1.nextElement()); 
        return;
      case 56:
        len = getLength(d) - 5;
        if (len < 255) {
          sizeDescriptor = 5;
          lenSize = 1;
        } else if (len < 65535) {
          sizeDescriptor = 6;
          lenSize = 2;
        } else {
          sizeDescriptor = 7;
          lenSize = 4;
        } 
        write(0x38 | sizeDescriptor);
        writeLong(len, lenSize);
        for (e = (Enumeration)d.getValue(); e.hasMoreElements();)
          writeElement(e.nextElement()); 
        return;
      case 64:
        b = Utils.getASCIIBytes((String)d.getValue());
        if (b.length < 256) {
          write(69);
          writeLong(b.length, 1);
        } else if (b.length < 65536) {
          write(70);
          writeLong(b.length, 2);
        } else {
          write(71);
          writeLong(b.length, 4);
        } 
        writeBytes(b);
        return;
    } 
    throw new IOException();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\SDPOutputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */