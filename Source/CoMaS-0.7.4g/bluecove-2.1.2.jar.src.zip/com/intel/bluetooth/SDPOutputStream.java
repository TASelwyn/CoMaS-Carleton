/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Enumeration;
/*     */ import javax.bluetooth.DataElement;
/*     */ import javax.bluetooth.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SDPOutputStream
/*     */   extends OutputStream
/*     */ {
/*     */   OutputStream dst;
/*     */   
/*     */   public SDPOutputStream(OutputStream out) {
/*  38 */     this.dst = out;
/*     */   }
/*     */   
/*     */   public void write(int oneByte) throws IOException {
/*  42 */     this.dst.write(oneByte);
/*     */   }
/*     */   
/*     */   private void writeLong(long l, int size) throws IOException {
/*  46 */     for (int i = 0; i < size; i++) {
/*  47 */       write((int)(l >> size - 1 << 3));
/*  48 */       l <<= 8L;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeBytes(byte[] b) throws IOException {
/*  53 */     for (int i = 0; i < b.length; i++)
/*  54 */       write(b[i]); 
/*     */   } static int getLength(DataElement d) { long uuid;
/*     */     byte[] b;
/*     */     int result;
/*     */     Enumeration e;
/*  59 */     switch (d.getDataType()) {
/*     */       case 0:
/*  61 */         return 1;
/*     */       
/*     */       case 8:
/*     */       case 16:
/*     */       case 40:
/*  66 */         return 2;
/*     */       
/*     */       case 9:
/*     */       case 17:
/*  70 */         return 3;
/*     */       
/*     */       case 10:
/*     */       case 18:
/*  74 */         return 5;
/*     */       
/*     */       case 11:
/*     */       case 19:
/*  78 */         return 9;
/*     */       
/*     */       case 12:
/*     */       case 20:
/*  82 */         return 17;
/*     */       
/*     */       case 24:
/*  85 */         uuid = Utils.UUIDTo32Bit((UUID)d.getValue());
/*  86 */         if (uuid == -1L)
/*  87 */           return 17; 
/*  88 */         if (uuid <= 65535L) {
/*  89 */           return 3;
/*     */         }
/*  91 */         return 5;
/*     */ 
/*     */       
/*     */       case 32:
/*  95 */         if (BlueCoveImpl.getConfigProperty("bluecove.sdp.string_encoding_ascii", false)) {
/*  96 */           b = Utils.getASCIIBytes((String)d.getValue());
/*     */         } else {
/*  98 */           b = Utils.getUTF8Bytes((String)d.getValue());
/*     */         } 
/* 100 */         if (b.length < 256)
/* 101 */           return b.length + 2; 
/* 102 */         if (b.length < 65536) {
/* 103 */           return b.length + 3;
/*     */         }
/* 105 */         return b.length + 5;
/*     */ 
/*     */       
/*     */       case 64:
/* 109 */         b = Utils.getASCIIBytes((String)d.getValue());
/*     */         
/* 111 */         if (b.length < 256)
/* 112 */           return b.length + 2; 
/* 113 */         if (b.length < 65536) {
/* 114 */           return b.length + 3;
/*     */         }
/* 116 */         return b.length + 5;
/*     */ 
/*     */ 
/*     */       
/*     */       case 48:
/*     */       case 56:
/* 122 */         result = 1;
/*     */         
/* 124 */         for (e = (Enumeration)d.getValue(); e.hasMoreElements();) {
/* 125 */           result += getLength(e.nextElement());
/*     */         }
/* 127 */         if (result < 255) {
/* 128 */           result++;
/* 129 */         } else if (result < 65535) {
/* 130 */           result += 2;
/*     */         } else {
/* 132 */           result += 4;
/*     */         } 
/*     */         
/* 135 */         return result;
/*     */     } 
/*     */ 
/*     */     
/* 139 */     throw new IllegalArgumentException(); } void writeElement(DataElement d) throws IOException { long uuid; byte[] arrayOfByte1; int sizeDescriptor; byte[] b;
/*     */     int len;
/*     */     int lenSize;
/*     */     Enumeration enumeration1;
/*     */     Enumeration e;
/* 144 */     switch (d.getDataType()) {
/*     */       case 0:
/* 146 */         write(0);
/*     */         return;
/*     */       
/*     */       case 8:
/* 150 */         write(8);
/* 151 */         writeLong(d.getLong(), 1);
/*     */         return;
/*     */       case 9:
/* 154 */         write(9);
/* 155 */         writeLong(d.getLong(), 2);
/*     */         return;
/*     */       case 10:
/* 158 */         write(10);
/* 159 */         writeLong(d.getLong(), 4);
/*     */         return;
/*     */       case 11:
/* 162 */         write(11);
/* 163 */         writeBytes((byte[])d.getValue());
/*     */         return;
/*     */       case 12:
/* 166 */         write(12);
/* 167 */         writeBytes((byte[])d.getValue());
/*     */         return;
/*     */       
/*     */       case 16:
/* 171 */         write(16);
/* 172 */         writeLong(d.getLong(), 1);
/*     */         return;
/*     */       case 17:
/* 175 */         write(17);
/* 176 */         writeLong(d.getLong(), 2);
/*     */         return;
/*     */       case 18:
/* 179 */         write(18);
/* 180 */         writeLong(d.getLong(), 4);
/*     */         return;
/*     */       case 19:
/* 183 */         write(19);
/* 184 */         writeLong(d.getLong(), 8);
/*     */         return;
/*     */       case 20:
/* 187 */         write(20);
/* 188 */         writeBytes((byte[])d.getValue());
/*     */         return;
/*     */       
/*     */       case 24:
/* 192 */         uuid = Utils.UUIDTo32Bit((UUID)d.getValue());
/* 193 */         if (uuid == -1L) {
/* 194 */           write(28);
/* 195 */           writeBytes(Utils.UUIDToByteArray((UUID)d.getValue()));
/* 196 */         } else if (uuid <= 65535L) {
/* 197 */           write(25);
/* 198 */           writeLong(uuid, 2);
/*     */         } else {
/* 200 */           write(26);
/* 201 */           writeLong(uuid, 4);
/*     */         } 
/*     */         return;
/*     */ 
/*     */       
/*     */       case 32:
/* 207 */         if (BlueCoveImpl.getConfigProperty("bluecove.sdp.string_encoding_ascii", false)) {
/* 208 */           arrayOfByte1 = Utils.getASCIIBytes((String)d.getValue());
/*     */         } else {
/* 210 */           arrayOfByte1 = Utils.getUTF8Bytes((String)d.getValue());
/*     */         } 
/*     */         
/* 213 */         if (arrayOfByte1.length < 256) {
/* 214 */           write(37);
/* 215 */           writeLong(arrayOfByte1.length, 1);
/* 216 */         } else if (arrayOfByte1.length < 65536) {
/* 217 */           write(38);
/* 218 */           writeLong(arrayOfByte1.length, 2);
/*     */         } else {
/* 220 */           write(39);
/* 221 */           writeLong(arrayOfByte1.length, 4);
/*     */         } 
/*     */         
/* 224 */         writeBytes(arrayOfByte1);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 40:
/* 229 */         write(40);
/* 230 */         writeLong(d.getBoolean() ? 1L : 0L, 1);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 48:
/* 235 */         len = getLength(d);
/*     */         
/* 237 */         if (len < 257) {
/* 238 */           sizeDescriptor = 5;
/* 239 */           lenSize = 1;
/* 240 */         } else if (len < 65538) {
/* 241 */           sizeDescriptor = 6;
/* 242 */           lenSize = 2;
/*     */         } else {
/* 244 */           sizeDescriptor = 7;
/* 245 */           lenSize = 4;
/*     */         } 
/* 247 */         len -= 1 + lenSize;
/* 248 */         write(0x30 | sizeDescriptor);
/* 249 */         writeLong(len, lenSize);
/*     */         
/* 251 */         for (enumeration1 = (Enumeration)d.getValue(); enumeration1.hasMoreElements();) {
/* 252 */           writeElement(enumeration1.nextElement());
/*     */         }
/*     */         return;
/*     */ 
/*     */ 
/*     */       
/*     */       case 56:
/* 259 */         len = getLength(d) - 5;
/*     */         
/* 261 */         if (len < 255) {
/* 262 */           sizeDescriptor = 5;
/* 263 */           lenSize = 1;
/* 264 */         } else if (len < 65535) {
/* 265 */           sizeDescriptor = 6;
/* 266 */           lenSize = 2;
/*     */         } else {
/* 268 */           sizeDescriptor = 7;
/* 269 */           lenSize = 4;
/*     */         } 
/* 271 */         write(0x38 | sizeDescriptor);
/* 272 */         writeLong(len, lenSize);
/*     */         
/* 274 */         for (e = (Enumeration)d.getValue(); e.hasMoreElements();) {
/* 275 */           writeElement(e.nextElement());
/*     */         }
/*     */         return;
/*     */ 
/*     */       
/*     */       case 64:
/* 281 */         b = Utils.getASCIIBytes((String)d.getValue());
/*     */         
/* 283 */         if (b.length < 256) {
/* 284 */           write(69);
/* 285 */           writeLong(b.length, 1);
/* 286 */         } else if (b.length < 65536) {
/* 287 */           write(70);
/* 288 */           writeLong(b.length, 2);
/*     */         } else {
/* 290 */           write(71);
/* 291 */           writeLong(b.length, 4);
/*     */         } 
/*     */         
/* 294 */         writeBytes(b);
/*     */         return;
/*     */     } 
/*     */ 
/*     */     
/* 299 */     throw new IOException(); }
/*     */ 
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\SDPOutputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */