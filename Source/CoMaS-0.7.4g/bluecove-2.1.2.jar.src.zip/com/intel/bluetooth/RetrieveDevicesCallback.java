package com.intel.bluetooth;

interface RetrieveDevicesCallback {
  void deviceFoundCallback(long paramLong, int paramInt, String paramString, boolean paramBoolean);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\RetrieveDevicesCallback.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */