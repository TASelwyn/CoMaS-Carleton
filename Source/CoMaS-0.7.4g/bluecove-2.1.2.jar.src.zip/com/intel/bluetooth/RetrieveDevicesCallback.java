package com.intel.bluetooth;

interface RetrieveDevicesCallback {
  void deviceFoundCallback(long paramLong, int paramInt, String paramString, boolean paramBoolean);
}
