/*    */ package com.intel.bluetooth;
/*    */ 
/*    */ import javax.bluetooth.UUID;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BluetoothConnectionNotifierParams
/*    */ {
/*    */   UUID uuid;
/*    */   boolean authenticate;
/*    */   boolean encrypt;
/*    */   boolean authorize;
/*    */   String name;
/*    */   boolean master;
/*    */   boolean obex;
/*    */   boolean timeouts;
/* 56 */   int bluecove_ext_psm = 0;
/*    */ 
/*    */ 
/*    */   
/*    */   public BluetoothConnectionNotifierParams(UUID uuid, boolean authenticate, boolean encrypt, boolean authorize, String name, boolean master) {
/* 61 */     this.uuid = uuid;
/* 62 */     this.authenticate = authenticate;
/* 63 */     this.encrypt = encrypt;
/* 64 */     this.authorize = authorize;
/* 65 */     this.name = name;
/* 66 */     this.master = master;
/* 67 */     this.obex = false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothConnectionNotifierParams.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */