package com.intel.bluetooth;

import javax.bluetooth.UUID;

class BluetoothConnectionNotifierParams {
  UUID uuid;
  
  boolean authenticate;
  
  boolean encrypt;
  
  boolean authorize;
  
  String name;
  
  boolean master;
  
  boolean obex;
  
  boolean timeouts;
  
  int bluecove_ext_psm = 0;
  
  public BluetoothConnectionNotifierParams(UUID uuid, boolean authenticate, boolean encrypt, boolean authorize, String name, boolean master) {
    this.uuid = uuid;
    this.authenticate = authenticate;
    this.encrypt = encrypt;
    this.authorize = authorize;
    this.name = name;
    this.master = master;
    this.obex = false;
  }
}
