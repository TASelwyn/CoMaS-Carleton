package com.intel.bluetooth;

public interface BlueCoveLocalDeviceProperties {
  public static final String LOCAL_DEVICE_PROPERTY_BLUECOVE_VERSION = "bluecove";
  
  public static final String LOCAL_DEVICE_PROPERTY_STACK = "bluecove.stack";
  
  public static final String LOCAL_DEVICE_PROPERTY_STACK_VERSION = "bluecove.stack.version";
  
  public static final String LOCAL_DEVICE_PROPERTY_FEATURE_L2CAP = "bluecove.feature.l2cap";
  
  public static final String LOCAL_DEVICE_PROPERTY_FEATURE_SERVICE_ATTRIBUTES = "bluecove.feature.service_attributes";
  
  public static final String LOCAL_DEVICE_PROPERTY_FEATURE_SET_DEVICE_SERVICE_CLASSES = "bluecove.feature.set_device_service_classes";
  
  public static final String LOCAL_DEVICE_PROPERTY_FEATURE_RSSI = "bluecove.feature.rssi";
  
  public static final String LOCAL_DEVICE_PROPERTY_OPEN_CONNECTIONS = "bluecove.connections";
  
  public static final String LOCAL_DEVICE_PROPERTY_DEVICE_ID = "bluecove.deviceID";
  
  public static final String LOCAL_DEVICE_DEVICES_LIST = "bluecove.local_devices_ids";
  
  public static final String LOCAL_DEVICE_RADIO_VERSION = "bluecove.radio.version";
  
  public static final String LOCAL_DEVICE_RADIO_MANUFACTURER = "bluecove.radio.manufacturer";
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BlueCoveLocalDeviceProperties.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */