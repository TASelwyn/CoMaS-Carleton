/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.bluetooth.DataElement;
/*     */ import javax.bluetooth.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BluetoothStackWIDCOMMSDPInputStream
/*     */   extends InputStream
/*     */ {
/*     */   public static final boolean debug = false;
/*     */   private InputStream source;
/*     */   static final int ATTR_TYPE_INT = 0;
/*     */   static final int ATTR_TYPE_TWO_COMP = 1;
/*     */   static final int ATTR_TYPE_UUID = 2;
/*     */   static final int ATTR_TYPE_BOOL = 3;
/*     */   static final int ATTR_TYPE_ARRAY = 4;
/*     */   static final int MAX_SEQ_ENTRIES = 20;
/*     */   static final int MAX_ATTR_LEN_OLD = 256;
/*     */   private int valueSize;
/*     */   
/*     */   public int read() throws IOException {
/*     */     return this.source.read();
/*     */   }
/*     */   
/*     */   private long readLong(int size) throws IOException {
/*     */     long result = 0L;
/*     */     for (int i = 0; i < size; i++)
/*     */       result += read() << 8 * i; 
/*     */     return result;
/*     */   }
/*     */   
/*     */   private long readLongDebug(int size) throws IOException {
/*     */     long result = 0L;
/*     */     for (int i = 0; i < size; i++) {
/*     */       int data = read();
/*     */       result += data << 8 * i;
/*     */     } 
/*     */     return result;
/*     */   }
/*     */   
/*     */   protected BluetoothStackWIDCOMMSDPInputStream(InputStream in) throws IOException {
/* 114 */     this.valueSize = 0;
/*     */     this.source = in;
/*     */     readVersionInfo(); } private void readVersionInfo() throws IOException {
/* 117 */     this.valueSize = readInt();
/*     */   } private int readInt() throws IOException {
/*     */     return (int)readLong(4);
/*     */   }
/*     */   public DataElement readElement() throws IOException {
/* 122 */     DataElement result = null;
/* 123 */     DataElement mainSeq = null;
/* 124 */     DataElement currentSeq = null;
/* 125 */     int elements = readInt();
/* 126 */     if (elements < 0 || elements > 20) {
/* 127 */       throw new IOException("Unexpected number of elements " + elements);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 132 */     for (int i = 0; i < elements; i++) {
/*     */       DataElement dataElement;
/*     */       
/*     */       UUID uuid;
/* 136 */       int type = readInt();
/* 137 */       int length = readInt();
/* 138 */       boolean start_of_seq = (readInt() != 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 144 */       if (length < 0 || this.valueSize < length) {
/* 145 */         throw new IOException("Unexpected length " + length);
/*     */       }
/*     */       
/* 148 */       switch (type) {
/*     */         case 0:
/* 150 */           switch (length) {
/*     */             case 1:
/* 152 */               dataElement = new DataElement(8, readLong(1));
/*     */               break;
/*     */             case 2:
/* 155 */               dataElement = new DataElement(9, readLong(2));
/*     */               break;
/*     */             case 4:
/* 158 */               dataElement = new DataElement(10, readLong(4));
/*     */               break;
/*     */             case 8:
/* 161 */               dataElement = new DataElement(11, readBytes(8));
/*     */               break;
/*     */             case 16:
/* 164 */               dataElement = new DataElement(12, readBytes(16));
/*     */               break;
/*     */           } 
/* 167 */           throw new IOException("Unknown U_INT length " + length);
/*     */ 
/*     */         
/*     */         case 1:
/* 171 */           switch (length) {
/*     */             case 1:
/* 173 */               dataElement = new DataElement(16, (byte)(int)readLong(1));
/*     */               break;
/*     */             case 2:
/* 176 */               dataElement = new DataElement(17, (short)(int)readLong(2));
/*     */               break;
/*     */             case 4:
/* 179 */               dataElement = new DataElement(18, (int)readLong(4));
/*     */               break;
/*     */             case 8:
/* 182 */               dataElement = new DataElement(19, readLongDebug(8));
/*     */               break;
/*     */             case 16:
/* 185 */               dataElement = new DataElement(20, readBytes(16));
/*     */               break;
/*     */           } 
/* 188 */           throw new IOException("Unknown INT length " + length);
/*     */ 
/*     */         
/*     */         case 2:
/* 192 */           uuid = null;
/* 193 */           switch (length) {
/*     */             case 2:
/* 195 */               uuid = new UUID(readLong(2));
/*     */               break;
/*     */             case 4:
/* 198 */               uuid = new UUID(readLong(4));
/*     */               break;
/*     */             case 16:
/* 201 */               uuid = new UUID(hexString(readBytes(16)), false);
/*     */               break;
/*     */             default:
/* 204 */               throw new IOException("Unknown UUID length " + length);
/*     */           } 
/* 206 */           dataElement = new DataElement(24, uuid);
/*     */           break;
/*     */         case 3:
/* 209 */           dataElement = new DataElement((readLong(length) != 0L));
/*     */           break;
/*     */         case 4:
/* 212 */           dataElement = new DataElement(32, Utils.newStringUTF8(readBytes(length)));
/*     */           break;
/*     */         default:
/* 215 */           throw new IOException("Unknown data type " + type);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 222 */       if (start_of_seq) {
/* 223 */         DataElement newSeq = new DataElement(48);
/* 224 */         newSeq.addElement(dataElement);
/* 225 */         dataElement = newSeq;
/*     */         
/* 227 */         if (i != 0)
/*     */         {
/* 229 */           if (mainSeq != null) {
/* 230 */             mainSeq.addElement(newSeq);
/*     */           } else {
/*     */             
/* 233 */             mainSeq = new DataElement(48);
/* 234 */             result = mainSeq;
/* 235 */             mainSeq.addElement(currentSeq);
/* 236 */             mainSeq.addElement(newSeq);
/*     */           } 
/*     */         }
/* 239 */         currentSeq = newSeq;
/* 240 */       } else if (currentSeq != null) {
/* 241 */         currentSeq.addElement(dataElement);
/*     */       } 
/*     */       
/* 244 */       if (result == null) {
/* 245 */         result = dataElement;
/*     */       }
/*     */       
/* 248 */       if (i < elements - 1 && skip((this.valueSize - length)) != (this.valueSize - length)) {
/* 249 */         throw new IOException("Unexpected end of data");
/*     */       }
/*     */     } 
/* 252 */     return result;
/*     */   }
/*     */   
/*     */   private byte[] readBytes(int size) throws IOException {
/*     */     byte[] result = new byte[size];
/*     */     for (int i = 0; i < size; i++)
/*     */       result[i] = (byte)read(); 
/*     */     return result;
/*     */   }
/*     */   
/*     */   static String hexString(byte[] b) {
/*     */     StringBuffer buf = new StringBuffer();
/*     */     for (int i = 0; i < b.length; i++) {
/*     */       buf.append(Integer.toHexString(b[i] >> 4 & 0xF));
/*     */       buf.append(Integer.toHexString(b[i] & 0xF));
/*     */     } 
/*     */     return buf.toString();
/*     */   }
/*     */   
/*     */   static byte[] getUUIDHexBytes(UUID uuid) {
/*     */     return Utils.UUIDToByteArray(uuid);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothStackWIDCOMMSDPInputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */