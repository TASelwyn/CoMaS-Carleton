/*     */ package com.intel.bluetooth.btspp;
/*     */ 
/*     */ import com.ibm.oti.connection.CreateConnection;
/*     */ import com.intel.bluetooth.BluetoothConnectionAccess;
/*     */ import com.intel.bluetooth.BluetoothConnectionAccessAdapter;
/*     */ import com.intel.bluetooth.BluetoothConnectionNotifierServiceRecordAccess;
/*     */ import com.intel.bluetooth.MicroeditionConnector;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.bluetooth.ServiceRecord;
/*     */ import javax.bluetooth.ServiceRegistrationException;
/*     */ import javax.microedition.io.InputConnection;
/*     */ import javax.microedition.io.OutputConnection;
/*     */ import javax.microedition.io.StreamConnection;
/*     */ import javax.microedition.io.StreamConnectionNotifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Connection
/*     */   extends BluetoothConnectionAccessAdapter
/*     */   implements CreateConnection, StreamConnection, StreamConnectionNotifier, BluetoothConnectionNotifierServiceRecordAccess
/*     */ {
/*  62 */   javax.microedition.io.Connection impl = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BluetoothConnectionAccess getImpl() {
/*  71 */     return (BluetoothConnectionAccess)this.impl;
/*     */   }
/*     */   
/*     */   public void setParameters(String spec, int access, boolean timeout) throws IOException {
/*  75 */     this.impl = MicroeditionConnector.open("btspp:" + spec, access, timeout);
/*     */   }
/*     */   
/*     */   public javax.microedition.io.Connection setParameters2(String spec, int access, boolean timeout) throws IOException {
/*  79 */     setParameters(spec, access, timeout);
/*  80 */     return (javax.microedition.io.Connection)this;
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/*  84 */     this.impl.close();
/*     */   }
/*     */   
/*     */   public DataInputStream openDataInputStream() throws IOException {
/*  88 */     return ((InputConnection)this.impl).openDataInputStream();
/*     */   }
/*     */   
/*     */   public InputStream openInputStream() throws IOException {
/*  92 */     return ((InputConnection)this.impl).openInputStream();
/*     */   }
/*     */   
/*     */   public DataOutputStream openDataOutputStream() throws IOException {
/*  96 */     return ((OutputConnection)this.impl).openDataOutputStream();
/*     */   }
/*     */   
/*     */   public OutputStream openOutputStream() throws IOException {
/* 100 */     return ((OutputConnection)this.impl).openOutputStream();
/*     */   }
/*     */   
/*     */   public StreamConnection acceptAndOpen() throws IOException {
/* 104 */     return ((StreamConnectionNotifier)this.impl).acceptAndOpen();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceRecord getServiceRecord() {
/* 113 */     return ((BluetoothConnectionNotifierServiceRecordAccess)this.impl).getServiceRecord();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateServiceRecord(boolean acceptAndOpen) throws ServiceRegistrationException {
/* 122 */     ((BluetoothConnectionNotifierServiceRecordAccess)this.impl).updateServiceRecord(acceptAndOpen);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\btspp\Connection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */