package com.intel.bluetooth;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Vector;
import javax.bluetooth.UUID;

public abstract class Utils {
  private static final String blueCoveImplPackage = getPackage(MicroeditionConnector.class.getName());
  
  private static String getPackage(String className) {
    int pStart = className.lastIndexOf('.');
    if (pStart == -1)
      return ""; 
    return className.substring(0, pStart);
  }
  
  public static byte[] UUIDToByteArray(String uuidStringValue) {
    byte[] uuidValue = new byte[16];
    if (uuidStringValue.indexOf('-') != -1)
      throw new NumberFormatException("The '-' character is not allowed in UUID: " + uuidStringValue); 
    for (int i = 0; i < 16; i++)
      uuidValue[i] = (byte)Integer.parseInt(uuidStringValue.substring(i * 2, i * 2 + 2), 16); 
    return uuidValue;
  }
  
  static byte[] UUIDToByteArray(UUID uuid) {
    return UUIDToByteArray(uuid.toString());
  }
  
  public static String UUIDByteArrayToString(byte[] uuidValue) {
    StringBuffer buf = new StringBuffer();
    for (int i = 0; i < uuidValue.length; i++) {
      buf.append(Integer.toHexString(uuidValue[i] >> 4 & 0xF));
      buf.append(Integer.toHexString(uuidValue[i] & 0xF));
    } 
    return buf.toString();
  }
  
  static long UUIDTo32Bit(UUID uuid) {
    if (uuid == null)
      return -1L; 
    String str = uuid.toString().toUpperCase();
    int shortIdx = str.indexOf("00001000800000805F9B34FB");
    if (shortIdx != -1 && shortIdx + "00001000800000805F9B34FB".length() == str.length())
      return Long.parseLong(str.substring(0, shortIdx), 16); 
    return -1L;
  }
  
  static boolean is32Bit(UUID uuid) {
    return (UUIDTo32Bit(uuid) != -1L);
  }
  
  public static int securityOpt(boolean authenticate, boolean encrypt) {
    int security = 0;
    if (authenticate) {
      if (encrypt) {
        security = 2;
      } else {
        security = 1;
      } 
    } else if (encrypt) {
      throw new IllegalArgumentException("Illegal encrypt configuration");
    } 
    return security;
  }
  
  static boolean isStringSet(String str) {
    return (str != null && str.length() > 0);
  }
  
  static String loadString(InputStream inputstream) {
    if (inputstream == null)
      return null; 
    try {
      byte[] buf = new byte[256];
      int len = inputstream.read(buf);
      return new String(buf, 0, len);
    } catch (IOException e) {
      return null;
    } finally {
      try {
        inputstream.close();
      } catch (IOException ignore) {}
    } 
  }
  
  static String getResourceProperty(Class owner, String resourceName) {
    try {
      String value = loadString(owner.getResourceAsStream("/" + resourceName));
      if (value != null) {
        int cr = value.indexOf('\n');
        if (cr != -1)
          value = value.substring(0, cr - 1); 
      } 
      return value;
    } catch (Throwable e) {
      return null;
    } 
  }
  
  public static byte[] clone(byte[] value) {
    if (value == null)
      return null; 
    int length = value.length;
    byte[] bClone = new byte[length];
    System.arraycopy(value, 0, bClone, 0, length);
    return bClone;
  }
  
  public static Vector clone(Enumeration en) {
    Vector copy = new Vector();
    while (en.hasMoreElements())
      copy.addElement(en.nextElement()); 
    return copy;
  }
  
  static String newStringUTF8(byte[] bytes) {
    try {
      return new String(bytes, "UTF-8");
    } catch (IllegalArgumentException e) {
      return new String(bytes);
    } catch (UnsupportedEncodingException e) {
      return new String(bytes);
    } 
  }
  
  static byte[] getUTF8Bytes(String str) {
    try {
      return str.getBytes("UTF-8");
    } catch (IllegalArgumentException e) {
      return str.getBytes();
    } catch (UnsupportedEncodingException e) {
      return str.getBytes();
    } 
  }
  
  static String newStringASCII(byte[] bytes) {
    try {
      return new String(bytes, "US-ASCII");
    } catch (IllegalArgumentException e) {
      return new String(bytes);
    } catch (UnsupportedEncodingException e) {
      return new String(bytes);
    } 
  }
  
  static byte[] getASCIIBytes(String str) {
    try {
      return str.getBytes("US-ASCII");
    } catch (IllegalArgumentException e) {
      return str.getBytes();
    } catch (UnsupportedEncodingException e) {
      return str.getBytes();
    } 
  }
  
  static Object[] vector2toArray(Vector vector, Object[] anArray) {
    vector.copyInto(anArray);
    return anArray;
  }
  
  public static String toHexString(long l) {
    StringBuffer buf = new StringBuffer();
    String lo = Integer.toHexString((int)l);
    if (l > 4294967295L) {
      String hi = Integer.toHexString((int)(l >> 32L));
      buf.append(hi);
      for (int i = lo.length(); i < 8; i++)
        buf.append('0'); 
    } 
    buf.append(lo);
    return buf.toString();
  }
  
  static void j2meUsagePatternDellay() {
    try {
      Thread.sleep(100L);
    } catch (InterruptedException e) {}
  }
  
  static class TimerThread extends Thread {
    long delay;
    
    Runnable run;
    
    public TimerThread(long delay, Runnable run) {
      this.delay = delay;
      this.run = run;
    }
    
    public void run() {
      try {
        Thread.sleep(this.delay);
        this.run.run();
      } catch (InterruptedException e) {}
    }
  }
  
  static TimerThread schedule(long delay, Runnable run) {
    TimerThread t = new TimerThread(delay, run);
    UtilsJavaSE.threadSetDaemon(t);
    t.start();
    return t;
  }
  
  public static void isLegalAPICall(Vector fqcnSet) throws Error {
    UtilsJavaSE.StackTraceLocation ste = UtilsJavaSE.getLocation(fqcnSet);
    if (ste != null) {
      if (ste.className.startsWith("javax.bluetooth."))
        return; 
      if (ste.className.startsWith(blueCoveImplPackage + "."))
        return; 
      throw new Error("Illegal use of the JSR-82 API");
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\Utils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */