/*     */ package com.intel.bluetooth;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ import javax.bluetooth.L2CAPConnection;
/*     */ import javax.bluetooth.L2CAPConnectionNotifier;
/*     */ import javax.bluetooth.ServiceRecord;
/*     */ import javax.bluetooth.ServiceRegistrationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BluetoothL2CAPConnectionNotifier
/*     */   extends BluetoothConnectionNotifierBase
/*     */   implements L2CAPConnectionNotifier
/*     */ {
/*     */   private int transmitMTU;
/*  43 */   private int psm = -1;
/*     */ 
/*     */   
/*     */   public BluetoothL2CAPConnectionNotifier(BluetoothStack bluetoothStack, BluetoothConnectionNotifierParams params, int receiveMTU, int transmitMTU) throws IOException {
/*  47 */     super(bluetoothStack, params);
/*     */     
/*  49 */     this.handle = bluetoothStack.l2ServerOpen(params, receiveMTU, transmitMTU, this.serviceRecord);
/*     */     
/*  51 */     this.psm = this.serviceRecord.getChannel(BluetoothConsts.L2CAP_PROTOCOL_UUID);
/*     */     
/*  53 */     this.transmitMTU = transmitMTU;
/*     */     
/*  55 */     this.serviceRecord.attributeUpdated = false;
/*     */     
/*  57 */     this.securityOpt = Utils.securityOpt(params.authenticate, params.encrypt);
/*     */     
/*  59 */     connectionCreated();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public L2CAPConnection acceptAndOpen() throws IOException {
/*  68 */     if (this.closed) {
/*  69 */       throw new IOException("Notifier is closed");
/*     */     }
/*  71 */     updateServiceRecord(true);
/*     */     try {
/*  73 */       long clientHandle = this.bluetoothStack.l2ServerAcceptAndOpenServerConnection(this.handle);
/*  74 */       int clientSecurityOpt = this.bluetoothStack.l2GetSecurityOpt(clientHandle, this.securityOpt);
/*  75 */       return new BluetoothL2CAPServerConnection(this.bluetoothStack, clientHandle, this.transmitMTU, clientSecurityOpt);
/*  76 */     } catch (InterruptedIOException e) {
/*  77 */       throw e;
/*  78 */     } catch (IOException e) {
/*  79 */       if (this.closed) {
/*  80 */         throw new InterruptedIOException("Notifier has been closed; " + e.getMessage());
/*     */       }
/*  82 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stackServerClose(long handle) throws IOException {
/*  92 */     this.bluetoothStack.l2ServerClose(handle, this.serviceRecord);
/*     */   }
/*     */   
/*     */   protected void validateServiceRecord(ServiceRecord srvRecord) {
/*  96 */     if (this.psm != this.serviceRecord.getChannel(BluetoothConsts.L2CAP_PROTOCOL_UUID)) {
/*  97 */       throw new IllegalArgumentException("Must not change the PSM");
/*     */     }
/*  99 */     super.validateServiceRecord(srvRecord);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateStackServiceRecord(ServiceRecordImpl serviceRecord, boolean acceptAndOpen) throws ServiceRegistrationException {
/* 110 */     this.bluetoothStack.l2ServerUpdateServiceRecord(this.handle, serviceRecord, acceptAndOpen);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\BluetoothL2CAPConnectionNotifier.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */