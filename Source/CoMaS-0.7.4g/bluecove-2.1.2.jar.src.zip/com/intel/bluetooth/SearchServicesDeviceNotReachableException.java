package com.intel.bluetooth;

class SearchServicesDeviceNotReachableException extends SearchServicesException {
  private static final long serialVersionUID = 1L;
  
  public SearchServicesDeviceNotReachableException() {}
  
  public SearchServicesDeviceNotReachableException(String s) {
    super(s);
  }
}
