/*    */ package com.intel.bluetooth;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SearchServicesDeviceNotReachableException
/*    */   extends SearchServicesException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public SearchServicesDeviceNotReachableException() {}
/*    */   
/*    */   public SearchServicesDeviceNotReachableException(String s) {
/* 40 */     super(s);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\SearchServicesDeviceNotReachableException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */