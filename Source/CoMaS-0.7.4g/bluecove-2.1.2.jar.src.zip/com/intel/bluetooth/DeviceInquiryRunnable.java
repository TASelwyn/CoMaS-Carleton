package com.intel.bluetooth;

import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DiscoveryListener;

interface DeviceInquiryRunnable {
  int runDeviceInquiry(DeviceInquiryThread paramDeviceInquiryThread, int paramInt, DiscoveryListener paramDiscoveryListener) throws BluetoothStateException;
  
  void deviceDiscoveredCallback(DiscoveryListener paramDiscoveryListener, long paramLong, int paramInt, String paramString, boolean paramBoolean);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\intel\bluetooth\DeviceInquiryRunnable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */