package com.intel.bluetooth;

import java.util.Enumeration;
import java.util.Hashtable;
import javax.bluetooth.ServiceRecord;
import javax.bluetooth.ServiceRegistrationException;

public abstract class ServiceRecordsRegistry {
  private static Hashtable serviceRecordsMap = new Hashtable();
  
  static synchronized void register(BluetoothConnectionNotifierServiceRecordAccess notifier, ServiceRecordImpl serviceRecord) {
    serviceRecordsMap.put(serviceRecord, notifier);
  }
  
  static synchronized void unregister(ServiceRecordImpl serviceRecord) {
    serviceRecordsMap.remove(serviceRecord);
  }
  
  static synchronized int getDeviceServiceClasses() {
    int deviceServiceClasses = 0;
    for (Enumeration en = serviceRecordsMap.keys(); en.hasMoreElements(); ) {
      ServiceRecordImpl serviceRecord = en.nextElement();
      deviceServiceClasses |= serviceRecord.deviceServiceClasses;
    } 
    return deviceServiceClasses;
  }
  
  public static void updateServiceRecord(ServiceRecord srvRecord) throws ServiceRegistrationException {
    BluetoothConnectionNotifierServiceRecordAccess owner;
    synchronized (ServiceRecordsRegistry.class) {
      owner = (BluetoothConnectionNotifierServiceRecordAccess)serviceRecordsMap.get(srvRecord);
    } 
    if (owner == null)
      throw new IllegalArgumentException("Service record is not registered"); 
    owner.updateServiceRecord(false);
  }
}
