/*    */ package com.intel.bluetooth;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.Hashtable;
/*    */ import javax.bluetooth.ServiceRecord;
/*    */ import javax.bluetooth.ServiceRegistrationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ServiceRecordsRegistry
/*    */ {
/* 49 */   private static Hashtable serviceRecordsMap = new Hashtable();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static synchronized void register(BluetoothConnectionNotifierServiceRecordAccess notifier, ServiceRecordImpl serviceRecord) {
/* 57 */     serviceRecordsMap.put(serviceRecord, notifier);
/*    */   }
/*    */   
/*    */   static synchronized void unregister(ServiceRecordImpl serviceRecord) {
/* 61 */     serviceRecordsMap.remove(serviceRecord);
/*    */   }
/*    */   
/*    */   static synchronized int getDeviceServiceClasses() {
/* 65 */     int deviceServiceClasses = 0;
/* 66 */     for (Enumeration en = serviceRecordsMap.keys(); en.hasMoreElements(); ) {
/* 67 */       ServiceRecordImpl serviceRecord = en.nextElement();
/* 68 */       deviceServiceClasses |= serviceRecord.deviceServiceClasses;
/*    */     } 
/* 70 */     return deviceServiceClasses;
/*    */   }
/*    */   
/*    */   public static void updateServiceRecord(ServiceRecord srvRecord) throws ServiceRegistrationException {
/*    */     BluetoothConnectionNotifierServiceRecordAccess owner;
/* 75 */     synchronized (ServiceRecordsRegistry.class) {
/* 76 */       owner = (BluetoothConnectionNotifierServiceRecordAccess)serviceRecordsMap.get(srvRecord);
/*    */     } 
/* 78 */     if (owner == null) {
/* 79 */       throw new IllegalArgumentException("Service record is not registered");
/*    */     }
/* 81 */     owner.updateServiceRecord(false);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bluecove-2.1.2.jar!\com\intel\bluetooth\ServiceRecordsRegistry.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */