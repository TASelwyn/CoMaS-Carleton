package com.sun.midp.io.j2me.btgoep;

import com.intel.bluetooth.MicroeditionConnector;
import com.sun.cdc.io.ConnectionBaseInterface;
import java.io.IOException;
import javax.microedition.io.Connection;

public class Protocol implements ConnectionBaseInterface {
  public Connection openPrim(String name, int mode, boolean timeouts) throws IOException {
    return MicroeditionConnector.open("btgoep:" + name, mode, timeouts);
  }
}
