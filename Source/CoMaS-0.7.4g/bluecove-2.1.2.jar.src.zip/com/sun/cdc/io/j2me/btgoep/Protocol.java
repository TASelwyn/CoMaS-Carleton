package com.sun.cdc.io.j2me.btgoep;

import com.intel.bluetooth.MicroeditionConnector;
import com.sun.cdc.io.ConnectionBaseInterface;
import java.io.IOException;
import javax.microedition.io.Connection;

public class Protocol implements ConnectionBaseInterface {
  public Connection openPrim(String name, int mode, boolean timeouts) throws IOException {
    return MicroeditionConnector.open("btgoep:" + name, mode, timeouts);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bluecove-2.1.2.jar!\com\sun\cdc\io\j2me\btgoep\Protocol.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */