package edu.carleton.testing;

import edu.carleton.services.ServiceListener;
import edu.carleton.services.ServiceLocator;
import edu.carleton.services.ServicePublisher;
import java.io.IOException;
import java.net.SocketException;

public class ServiceDiscoveryTest {
  public static void main(String[] args) throws SocketException, IOException, InterruptedException {
    ServicePublisher sp = new ServicePublisher("test");
    sp.publish("EDIR", "http://192.168.86.201:8080/COMP4601-Directory/rest/directory/");
    ServiceListener l = new ServiceListener() {
        public void onAdd(String service, String endpoint) {
          System.out.println("ServiceDiscoveryTest Added: " + service + " " + endpoint);
        }
        
        public void onRemove(String service, String endpoint) {
          System.out.println("ServiceDiscoveryTest Removed: " + service + " " + endpoint);
        }
      };
    ServiceLocator sl = new ServiceLocator(l);
    sl.open();
    sl.subscribe("EDIR");
    Thread.sleep(5000L);
    sp.unpublish("EDIR", "http://192.168.86.201:8080/COMP4601-Directory/rest/directory/");
    Thread.sleep(5000L);
    sp.close();
    sl.close();
  }
}
