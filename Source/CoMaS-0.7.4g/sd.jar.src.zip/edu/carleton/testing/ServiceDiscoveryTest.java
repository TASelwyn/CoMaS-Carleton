/*    */ package edu.carleton.testing;
/*    */ 
/*    */ import edu.carleton.services.ServiceListener;
/*    */ import edu.carleton.services.ServiceLocator;
/*    */ import edu.carleton.services.ServicePublisher;
/*    */ import java.io.IOException;
/*    */ import java.net.SocketException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServiceDiscoveryTest
/*    */ {
/*    */   public static void main(String[] args) throws SocketException, IOException, InterruptedException {
/* 23 */     ServicePublisher sp = new ServicePublisher("test");
/* 24 */     sp.publish("EDIR", "http://192.168.86.201:8080/COMP4601-Directory/rest/directory/");
/*    */     
/* 26 */     ServiceListener l = new ServiceListener() {
/*    */         public void onAdd(String service, String endpoint) {
/* 28 */           System.out.println("ServiceDiscoveryTest Added: " + service + " " + endpoint);
/*    */         }
/*    */         public void onRemove(String service, String endpoint) {
/* 31 */           System.out.println("ServiceDiscoveryTest Removed: " + service + " " + endpoint);
/*    */         }
/*    */       };
/* 34 */     ServiceLocator sl = new ServiceLocator(l);
/* 35 */     sl.open();
/* 36 */     sl.subscribe("EDIR");
/*    */     
/* 38 */     Thread.sleep(5000L);
/* 39 */     sp.unpublish("EDIR", "http://192.168.86.201:8080/COMP4601-Directory/rest/directory/");
/* 40 */     Thread.sleep(5000L);
/* 41 */     sp.close();
/* 42 */     sl.close();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\sd.jar!\edu\carleton\testing\ServiceDiscoveryTest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */