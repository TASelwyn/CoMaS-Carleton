package edu.carleton.services;

import java.io.Closeable;
import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.concurrent.atomic.AtomicBoolean;

public class ServiceUtility {
  public static final int PUBLISH = 1;
  
  public static final int UNPUBLISH = 2;
  
  public static final int SUBSCRIBE = 3;
  
  public static final int UNSUBSCRIBE = 4;
  
  protected static int MULTICAST_PORT = 4321;
  
  protected static int MULTICAST_BROWSER_PORT = MULTICAST_PORT - 1;
  
  protected static int MULTICAST_RETURN_PORT = MULTICAST_PORT + 1;
  
  protected static String MULTICAST_IP = "230.0.0.0";
  
  protected static String DELIMETER = "#";
  
  protected static String VALID_STRING_PATTERN = "^[A-Za-z0-9+/]+={0,2}$";
  
  protected static boolean DEBUG = false;
  
  public static void setDebug(boolean debug) {
    DEBUG = debug;
  }
  
  public static void setPort(int port) {
    MULTICAST_PORT = port;
    MULTICAST_RETURN_PORT = port + 1;
    MULTICAST_BROWSER_PORT = port - 1;
  }
  
  public static void setIP(String ip) {
    MULTICAST_IP = ip;
  }
  
  public static int getPort() {
    return MULTICAST_PORT;
  }
  
  public static int getReturnPort() {
    return MULTICAST_RETURN_PORT;
  }
  
  public static int getBrowserPort() {
    return MULTICAST_BROWSER_PORT;
  }
  
  public static String getIP() {
    return MULTICAST_IP;
  }
  
  public static String findInterface() throws SocketException {
    String i_f = null;
    Enumeration<NetworkInterface> ni = NetworkInterface.getNetworkInterfaces();
    while (ni.hasMoreElements()) {
      NetworkInterface i = ni.nextElement();
      Enumeration<InetAddress> ia = i.getInetAddresses();
      while (ia.hasMoreElements()) {
        InetAddress a = ia.nextElement();
        if (DEBUG)
          System.out.println(String.valueOf(i.getDisplayName()) + " Up: " + i.isUp() + " Multi: " + 
              i.supportsMulticast() + " linkLocal: " + a.isLinkLocalAddress() + " address: " + 
              a.getHostAddress()); 
        if (i.supportsMulticast() && !a.isLoopbackAddress() && !a.isAnyLocalAddress() && 
          !a.isLinkLocalAddress())
          i_f = i.getDisplayName(); 
      } 
    } 
    if (DEBUG)
      System.out.println("Interface: " + i_f); 
    return i_f;
  }
  
  public static String findIP() throws SocketException {
    String i_f = null;
    Enumeration<NetworkInterface> ni = NetworkInterface.getNetworkInterfaces();
    while (ni.hasMoreElements()) {
      NetworkInterface i = ni.nextElement();
      Enumeration<InetAddress> ia = i.getInetAddresses();
      while (ia.hasMoreElements()) {
        InetAddress a = ia.nextElement();
        if (DEBUG)
          System.out.println(String.valueOf(i.getDisplayName()) + " Up: " + i.isUp() + " Multi: " + 
              i.supportsMulticast() + " linkLocal: " + a.isLinkLocalAddress() + " address: " + 
              a.getHostAddress()); 
        if (i.supportsMulticast() && !a.isLoopbackAddress() && !a.isAnyLocalAddress() && 
          !a.isLinkLocalAddress())
          i_f = a.getHostAddress(); 
      } 
    } 
    if (DEBUG)
      System.out.println("IP: " + i_f); 
    return i_f;
  }
  
  public static void closeOnExit(Closeable closeable) {
    Runtime.getRuntime().addShutdownHook(new Thread(new CloseOnExit(closeable)));
  }
  
  private static class CloseOnExit implements Runnable {
    final Closeable closeable;
    
    CloseOnExit(Closeable closeable) {
      this.closeable = closeable;
    }
    
    public void run() {
      try {
        this.closeable.close();
      } catch (IOException iOException) {}
    }
  }
  
  public static class ProcessorThread extends Thread {
    private AtomicBoolean isRunning;
    
    private Processor publisher;
    
    public ProcessorThread(Processor publisher) {
      this.isRunning = new AtomicBoolean(false);
      this.publisher = publisher;
    }
    
    public void run() {
      this.isRunning.set(true);
      while (this.isRunning.get()) {
        try {
          this.publisher.process();
        } catch (ProcessingException e) {
          if (!this.isRunning.get() && 
            ServiceUtility.DEBUG)
            System.out.println(String.valueOf(this.publisher.getClass().getSimpleName()) + " has stopped"); 
        } 
      } 
    }
    
    public void close() {
      this.isRunning.set(false);
    }
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\sd.jar!\edu\carleton\services\ServiceUtility.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */