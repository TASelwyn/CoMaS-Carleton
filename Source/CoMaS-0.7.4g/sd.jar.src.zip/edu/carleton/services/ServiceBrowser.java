package edu.carleton.services;

import edu.carleton.encryption.AES;
import java.io.Closeable;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.StandardProtocolFamily;
import java.net.StandardSocketOptions;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.nio.channels.MembershipKey;

public class ServiceBrowser implements Processor, Closeable {
  private ServiceUtility.ProcessorThread reader;
  
  private DatagramChannel datagramChannel;
  
  private MembershipKey membershipKey;
  
  private ServiceListener listener;
  
  public ServiceBrowser(ServiceListener listener) throws SocketException, IOException {
    this(ServiceUtility.MULTICAST_IP, ServiceUtility.findInterface(), ServiceUtility.findIP(), ServiceUtility.MULTICAST_BROWSER_PORT, listener);
  }
  
  ServiceBrowser(String ip, String iface, String i_ip, int port, ServiceListener listener) throws SocketException, IOException {
    open(ip, iface, i_ip, port);
    this.listener = listener;
    ServiceUtility.closeOnExit(this);
  }
  
  private void open(String ip, String iface, String i_ip, int port) throws IOException {
    this.datagramChannel = DatagramChannel.open(StandardProtocolFamily.INET);
    NetworkInterface networkInterface = NetworkInterface.getByName(iface);
    if (networkInterface == null)
      networkInterface = NetworkInterface.getByInetAddress(InetAddress.getByName(i_ip)); 
    this.datagramChannel.setOption(StandardSocketOptions.SO_REUSEADDR, Boolean.valueOf(true));
    this.datagramChannel.bind(new InetSocketAddress(port));
    this.datagramChannel.setOption(StandardSocketOptions.IP_MULTICAST_IF, networkInterface);
    this.datagramChannel.configureBlocking(true);
    InetAddress inetAddress = InetAddress.getByName(ip);
    this.membershipKey = this.datagramChannel.join(inetAddress, networkInterface);
    this.reader = new ServiceUtility.ProcessorThread(this);
    this.reader.start();
  }
  
  public void close() throws IOException {
    this.reader.close();
    this.reader.interrupt();
    this.membershipKey.drop();
    if (this.datagramChannel.isOpen())
      this.datagramChannel.close(); 
  }
  
  private String read() throws IOException {
    ByteBuffer byteBuffer = ByteBuffer.allocate(1024);
    this.datagramChannel.receive(byteBuffer);
    byteBuffer.flip();
    byte[] bytes = new byte[byteBuffer.limit()];
    byteBuffer.get(bytes, 0, byteBuffer.limit());
    return new String(bytes);
  }
  
  public void process() throws ProcessingException {
    String msg = null;
    String encryptedMessage = null;
    try {
      encryptedMessage = read();
      encryptedMessage = encryptedMessage.trim();
      msg = AES.decrypt(encryptedMessage);
      if (ServiceUtility.DEBUG)
        System.out.println("ServiceBrowser: [" + msg + "]"); 
    } catch (IOException e) {
      throw new ProcessingException(e.getMessage());
    } 
    String[] fields = msg.split(ServiceUtility.DELIMETER);
    if (fields == null)
      throw new ProcessingException("Unknown message format: " + msg); 
    if (fields.length != 3)
      throw new ProcessingException("Illegal number of fields: " + fields.length); 
    if (fields[0].equals("added")) {
      this.listener.onAdd(fields[1], fields[2]);
    } else if (fields[0].equals("removed")) {
      this.listener.onRemove(fields[1], fields[2]);
    } 
  }
}
