package edu.carleton.services;

public interface ServiceListener {
  void onAdd(String paramString1, String paramString2);
  
  void onRemove(String paramString1, String paramString2);
}
