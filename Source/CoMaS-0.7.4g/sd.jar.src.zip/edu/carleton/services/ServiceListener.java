package edu.carleton.services;

public interface ServiceListener {
  void onAdd(String paramString1, String paramString2);
  
  void onRemove(String paramString1, String paramString2);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\sd.jar!\edu\carleton\services\ServiceListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */