/*     */ package edu.carleton.services;
/*     */ 
/*     */ import edu.carleton.encryption.AES;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.net.DatagramPacket;
/*     */ import java.net.DatagramSocket;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.NetworkInterface;
/*     */ import java.net.SocketAddress;
/*     */ import java.net.SocketException;
/*     */ import java.net.StandardProtocolFamily;
/*     */ import java.net.StandardSocketOptions;
/*     */ import java.net.UnknownHostException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.DatagramChannel;
/*     */ import java.nio.channels.MembershipKey;
/*     */ import java.util.Enumeration;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.CopyOnWriteArraySet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServicePublisher
/*     */   implements Processor, Closeable
/*     */ {
/*     */   private String name;
/*     */   private ServiceUtility.ProcessorThread reader;
/*     */   private InetSocketAddress inetSocketAddress;
/*     */   private DatagramChannel datagramChannel;
/*     */   private MembershipKey membershipKey;
/*     */   private DatagramChannel datagramChannelPublish;
/*     */   private ConcurrentHashMap<String, String> map;
/*     */   private CopyOnWriteArraySet<Subscriber> subscribers;
/*     */   
/*     */   public ServicePublisher(String name) throws SocketException, IOException {
/*  43 */     this(name, ServiceUtility.MULTICAST_IP, ServiceUtility.findInterface(), ServiceUtility.MULTICAST_PORT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ServicePublisher(String name, String ip, String iface, int port) throws SocketException, IOException {
/*  57 */     this.name = name.toLowerCase().trim();
/*  58 */     this.map = new ConcurrentHashMap<>();
/*  59 */     this.subscribers = new CopyOnWriteArraySet<>();
/*  60 */     open(ip, iface, port);
/*  61 */     openPublish(ip, iface, port - 1);
/*  62 */     ServiceUtility.closeOnExit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void open(String ip, String iface, int port) throws IOException {
/*  75 */     this.datagramChannel = DatagramChannel.open(StandardProtocolFamily.INET);
/*  76 */     NetworkInterface networkInterface = NetworkInterface.getByName(iface);
/*  77 */     this.datagramChannel.setOption(StandardSocketOptions.SO_REUSEADDR, Boolean.valueOf(true));
/*  78 */     this.datagramChannel.bind(new InetSocketAddress(port));
/*  79 */     this.datagramChannel.setOption(StandardSocketOptions.IP_MULTICAST_IF, networkInterface);
/*  80 */     this.datagramChannel.configureBlocking(true);
/*  81 */     InetAddress inetAddress = InetAddress.getByName(ip);
/*  82 */     this.membershipKey = this.datagramChannel.join(inetAddress, networkInterface);
/*  83 */     this.reader = new ServiceUtility.ProcessorThread(this);
/*  84 */     this.reader.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void openPublish(String ip, String iface, int port) throws IOException {
/*  96 */     this.datagramChannelPublish = DatagramChannel.open();
/*  97 */     this.datagramChannelPublish.bind((SocketAddress)null);
/*  98 */     NetworkInterface networkInterface = NetworkInterface.getByName(iface);
/*  99 */     this.datagramChannelPublish.setOption(StandardSocketOptions.IP_MULTICAST_IF, networkInterface);
/* 100 */     this.inetSocketAddress = new InetSocketAddress(ip, port);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 108 */     this.reader.close();
/* 109 */     this.reader.interrupt();
/* 110 */     this.membershipKey.drop();
/* 111 */     if (this.datagramChannel.isOpen())
/* 112 */       this.datagramChannel.close(); 
/* 113 */     unpublishAll();
/* 114 */     if (this.datagramChannelPublish.isOpen()) {
/* 115 */       this.datagramChannelPublish.close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(String message) throws IOException {
/* 124 */     String encryptedMessage = AES.encrypt(message);
/* 125 */     ByteBuffer byteBuffer = ByteBuffer.wrap(encryptedMessage.getBytes("UTF-8"));
/* 126 */     this.datagramChannelPublish.send(byteBuffer, this.inetSocketAddress);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String read() throws IOException {
/* 136 */     ByteBuffer byteBuffer = ByteBuffer.allocate(1024);
/* 137 */     this.datagramChannel.receive(byteBuffer);
/* 138 */     byteBuffer.flip();
/* 139 */     byte[] bytes = new byte[byteBuffer.limit()];
/* 140 */     byteBuffer.get(bytes, 0, byteBuffer.limit());
/* 141 */     return new String(bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void process() throws ProcessingException {
/* 153 */     String msg = null;
/* 154 */     String encryptedMessage = null;
/*     */     try {
/* 156 */       encryptedMessage = read();
/*     */       
/* 158 */       encryptedMessage = encryptedMessage.trim();
/* 159 */       msg = AES.decrypt(encryptedMessage);
/* 160 */       if (ServiceUtility.DEBUG)
/* 161 */         System.out.println("ServicePublisher: [" + msg + "]"); 
/* 162 */     } catch (IOException e) {
/* 163 */       throw new ProcessingException(e.getMessage());
/*     */     } 
/*     */     
/* 166 */     String[] fields = msg.split(ServiceUtility.DELIMETER);
/* 167 */     int port = 0;
/* 168 */     if (fields == null)
/* 169 */       throw new ProcessingException("Unknown message format: " + msg); 
/* 170 */     if (fields.length != 4) {
/* 171 */       throw new ProcessingException("Illegal number of fields: " + fields.length);
/*     */     }
/*     */     
/*     */     try {
/* 175 */       port = Integer.valueOf(fields[3]).intValue();
/* 176 */     } catch (NumberFormatException e) {
/* 177 */       throw new ProcessingException("Illegal port field value: " + fields[3]);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 182 */       if (fields[0].equals("subscribe"))
/* 183 */       { subscribe(fields[1], fields[2], port); }
/* 184 */       else if (fields[0].equals("unsubscribe"))
/* 185 */       { unsubscribe(fields[1], fields[2], port); } 
/* 186 */     } catch (IOException e) {
/* 187 */       throw new ProcessingException(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void unpublishAll() throws IOException {
/* 196 */     Enumeration<String> keys = this.map.keys();
/* 197 */     while (keys.hasMoreElements()) {
/* 198 */       String service = keys.nextElement();
/* 199 */       String endpoint = this.map.get(service);
/* 200 */       unpublish(service, endpoint);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void publish(String service, String endpoint) throws IOException {
/* 212 */     this.map.put(service, endpoint);
/* 213 */     send("added" + ServiceUtility.DELIMETER + this.name + "." + service + ServiceUtility.DELIMETER + endpoint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unpublish(String service, String endpoint) throws IOException {
/* 224 */     send("removed" + ServiceUtility.DELIMETER + this.name + "." + service + ServiceUtility.DELIMETER + endpoint);
/* 225 */     this.map.remove(service);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Subscriber get(String ipAddress, int port) throws SocketException, UnknownHostException {
/* 238 */     Subscriber subscriber = new Subscriber(ipAddress, port);
/* 239 */     for (Subscriber client : this.subscribers) {
/* 240 */       if (client.equals(subscriber))
/* 241 */         return client; 
/* 242 */     }  return subscriber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void subscribe(String service, String ipAddress, int port) throws SocketException, UnknownHostException {
/* 255 */     String endpoint = this.map.get(service);
/* 256 */     Subscriber subscriber = get(ipAddress, port);
/* 257 */     subscriber.open();
/* 258 */     subscriber.update(service, 3, endpoint);
/* 259 */     if (!subscriber.isClosed() && 
/* 260 */       !this.subscribers.contains(subscriber)) {
/* 261 */       this.subscribers.add(subscriber);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsubscribe(String service, String ipAddress, int port) throws SocketException, UnknownHostException {
/* 275 */     String endpoint = this.map.get(service);
/* 276 */     Subscriber subscriber = get(ipAddress, port);
/* 277 */     Subscriber toRemove = null;
/* 278 */     for (Subscriber c : this.subscribers) {
/* 279 */       if (c.equals(subscriber)) {
/* 280 */         c.update(service, 4, endpoint);
/* 281 */         if (!c.isSubscribed())
/* 282 */           toRemove = c; 
/*     */       } 
/*     */     } 
/* 285 */     this.subscribers.remove(toRemove);
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws SocketException, IOException {
/* 289 */     ServicePublisher sp = new ServicePublisher("test-comas");
/* 290 */     sp.publish("test", "https://sikaman.dyndns.org:8443/CMS/rest/index.jade");
/* 291 */     sp.close();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class Subscriber
/*     */   {
/*     */     CopyOnWriteArraySet<String> services;
/*     */ 
/*     */     
/*     */     DatagramSocket socket;
/*     */ 
/*     */     
/*     */     InetAddress address;
/*     */ 
/*     */     
/*     */     int port;
/*     */ 
/*     */     
/*     */     public Subscriber(String ipAddress, int port) throws SocketException, UnknownHostException {
/* 311 */       this.address = InetAddress.getByName(ipAddress);
/* 312 */       this.port = port;
/* 313 */       this.services = new CopyOnWriteArraySet<>();
/*     */     }
/*     */     
/*     */     public void open() throws SocketException {
/* 317 */       if (this.socket == null)
/* 318 */         this.socket = new DatagramSocket(); 
/*     */     }
/*     */     
/*     */     public synchronized void update(String service, int action, String endpoint) {
/* 322 */       if (isSubscribedTo(service)) {
/* 323 */         if (action == 2 || action == 4) {
/* 324 */           send("removed" + ServiceUtility.DELIMETER + ServicePublisher.this.name + "." + service + ServiceUtility.DELIMETER + endpoint);
/* 325 */           unsubscribe(service);
/*     */         } 
/* 327 */       } else if (action == 3 || action == 1) {
/* 328 */         if (endpoint != null) {
/* 329 */           send("added" + ServiceUtility.DELIMETER + ServicePublisher.this.name + "." + service + ServiceUtility.DELIMETER + endpoint);
/*     */         }
/* 331 */         subscribe(service);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void send(String message) {
/*     */       try {
/* 342 */         String encryptedMessage = AES.encrypt(message);
/* 343 */         if (ServiceUtility.DEBUG)
/* 344 */           System.out.println("ServicePublisher send: [" + encryptedMessage + "]"); 
/* 345 */         byte[] msg = encryptedMessage.getBytes("UTF-8");
/* 346 */         DatagramPacket packet = new DatagramPacket(msg, msg.length, this.address, this.port);
/* 347 */         this.socket.send(packet);
/* 348 */       } catch (IOException e) {
/* 349 */         close();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void close() {
/* 357 */       if (this.socket != null) {
/* 358 */         this.socket.close();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void subscribe(String service) {
/* 366 */       if (this.services.contains(service))
/*     */         return; 
/* 368 */       this.services.add(service);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void unsubscribe(String service) {
/* 376 */       if (service.equals("*")) {
/* 377 */         this.services.clear();
/*     */       } else {
/* 379 */         this.services.remove(service);
/* 380 */       }  if (!isSubscribed()) {
/* 381 */         close();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSubscribedTo(String service) {
/* 390 */       if (service.equals("*")) {
/* 391 */         return true;
/*     */       }
/* 393 */       return this.services.contains(service);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isClosed() {
/* 401 */       if (this.socket == null)
/* 402 */         return true; 
/* 403 */       return this.socket.isClosed();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSubscribed() {
/* 411 */       return (!this.services.isEmpty() && !isClosed());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Subscriber subscriber) {
/* 421 */       return (this.address.getHostAddress().equals(subscriber.address.getHostAddress()) && this.port == subscriber.port);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 428 */       return String.valueOf(this.address.getHostAddress()) + ":" + this.port + " " + this.services;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\sd.jar!\edu\carleton\services\ServicePublisher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */