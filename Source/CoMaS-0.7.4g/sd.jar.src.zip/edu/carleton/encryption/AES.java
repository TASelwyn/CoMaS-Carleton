/*     */ package edu.carleton.encryption;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Base64;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AES
/*     */ {
/*     */   private static SecretKeySpec secretKey;
/*     */   private static byte[] key;
/*  25 */   private static String myDefaultKey = "1956196319931995";
/*  26 */   private static String digestAlgorithm = "SHA-256";
/*  27 */   private static String defaultCipher = "AES/ECB/PKCS5Padding";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setDefaultKey(String myKey) {
/*  36 */     myDefaultKey = myKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setDigestAlgorithm(String digest) {
/*  46 */     digestAlgorithm = digest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setCipher(String cipher) {
/*  56 */     defaultCipher = cipher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setKey(String myKey) throws NoSuchAlgorithmException, UnsupportedEncodingException {
/*  68 */     MessageDigest sha = null;
/*     */     
/*  70 */     key = myKey.getBytes("UTF-8");
/*  71 */     sha = MessageDigest.getInstance(digestAlgorithm);
/*  72 */     key = sha.digest(key);
/*  73 */     key = Arrays.copyOf(key, 16);
/*  74 */     secretKey = new SecretKeySpec(key, "AES");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized String encrypt(String strToEncrypt) throws IOException {
/*  85 */     return encrypt(strToEncrypt, myDefaultKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized String encrypt(String strToEncrypt, String secret) throws IOException {
/*     */     try {
/*  98 */       setKey(secret);
/*  99 */       Cipher cipher = Cipher.getInstance(defaultCipher);
/* 100 */       cipher.init(1, secretKey);
/* 101 */       return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes()));
/* 102 */     } catch (Exception e) {
/* 103 */       throw new IOException("Error while encrypting: " + e.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized String decrypt(String strToDecrypt) throws IOException {
/* 115 */     return decrypt(strToDecrypt, myDefaultKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized String decrypt(String strToDecrypt, String secret) throws IOException {
/*     */     try {
/* 128 */       setKey(secret);
/* 129 */       Cipher cipher = Cipher.getInstance(defaultCipher);
/* 130 */       cipher.init(2, secretKey);
/* 131 */       return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
/* 132 */     } catch (Exception e) {
/* 133 */       throw new IOException("Error while decrypting: " + e.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) throws IOException {
/* 144 */     String secretKey = myDefaultKey;
/*     */     
/* 146 */     String originalString = "subscribed#EDIR#/COMP4601-Directory/rest/directory/#4223";
/* 147 */     String encryptedString = encrypt(originalString, secretKey);
/* 148 */     String decryptedString = decrypt(encryptedString, secretKey);
/*     */     
/* 150 */     System.out.println(originalString);
/* 151 */     System.out.println(encryptedString);
/* 152 */     System.out.println(decryptedString);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\sd.jar!\edu\carleton\encryption\AES.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */