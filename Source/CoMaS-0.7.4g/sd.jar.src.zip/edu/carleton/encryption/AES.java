package edu.carleton.encryption;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class AES {
  private static SecretKeySpec secretKey;
  
  private static byte[] key;
  
  private static String myDefaultKey = "1956196319931995";
  
  private static String digestAlgorithm = "SHA-256";
  
  private static String defaultCipher = "AES/ECB/PKCS5Padding";
  
  public static synchronized void setDefaultKey(String myKey) {
    myDefaultKey = myKey;
  }
  
  public static synchronized void setDigestAlgorithm(String digest) {
    digestAlgorithm = digest;
  }
  
  public static synchronized void setCipher(String cipher) {
    defaultCipher = cipher;
  }
  
  public static synchronized void setKey(String myKey) throws NoSuchAlgorithmException, UnsupportedEncodingException {
    MessageDigest sha = null;
    key = myKey.getBytes("UTF-8");
    sha = MessageDigest.getInstance(digestAlgorithm);
    key = sha.digest(key);
    key = Arrays.copyOf(key, 16);
    secretKey = new SecretKeySpec(key, "AES");
  }
  
  public static synchronized String encrypt(String strToEncrypt) throws IOException {
    return encrypt(strToEncrypt, myDefaultKey);
  }
  
  public static synchronized String encrypt(String strToEncrypt, String secret) throws IOException {
    try {
      setKey(secret);
      Cipher cipher = Cipher.getInstance(defaultCipher);
      cipher.init(1, secretKey);
      return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes()));
    } catch (Exception e) {
      throw new IOException("Error while encrypting: " + e.toString());
    } 
  }
  
  public static synchronized String decrypt(String strToDecrypt) throws IOException {
    return decrypt(strToDecrypt, myDefaultKey);
  }
  
  public static synchronized String decrypt(String strToDecrypt, String secret) throws IOException {
    try {
      setKey(secret);
      Cipher cipher = Cipher.getInstance(defaultCipher);
      cipher.init(2, secretKey);
      return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
    } catch (Exception e) {
      throw new IOException("Error while decrypting: " + e.toString());
    } 
  }
  
  public static void main(String[] args) throws IOException {
    String secretKey = myDefaultKey;
    String originalString = "subscribed#EDIR#/COMP4601-Directory/rest/directory/#4223";
    String encryptedString = encrypt(originalString, secretKey);
    String decryptedString = decrypt(encryptedString, secretKey);
    System.out.println(originalString);
    System.out.println(encryptedString);
    System.out.println(decryptedString);
  }
}
