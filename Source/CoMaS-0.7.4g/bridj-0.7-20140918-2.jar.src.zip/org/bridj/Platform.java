package org.bridj;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import org.bridj.util.ProcessUtils;
import org.bridj.util.StringUtils;

public class Platform {
  static final String osName = System.getProperty("os.name", "");
  
  private static boolean inited;
  
  static final String BridJLibraryName = "bridj";
  
  public static final int POINTER_SIZE;
  
  public static final int WCHAR_T_SIZE;
  
  public static final int SIZE_T_SIZE;
  
  public static final int TIME_T_SIZE;
  
  public static final int CLONG_SIZE;
  
  static final ClassLoader systemClassLoader;
  
  public static ClassLoader getClassLoader() {
    return getClassLoader(BridJ.class);
  }
  
  public static ClassLoader getClassLoader(Class<?> cl) {
    ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
    if (contextClassLoader != null)
      return contextClassLoader; 
    ClassLoader classLoader = (cl == null) ? null : cl.getClassLoader();
    return (classLoader == null) ? systemClassLoader : classLoader;
  }
  
  public static InputStream getResourceAsStream(String path) {
    URL url = getResource(path);
    try {
      return (url != null) ? url.openStream() : null;
    } catch (IOException ex) {
      if (BridJ.verbose)
        BridJ.warning("Failed to get resource '" + path + "'", ex); 
      return null;
    } 
  }
  
  public static URL getResource(String path) {
    if (!path.startsWith("/"))
      path = "/" + path; 
    URL in = BridJ.class.getResource(path);
    if (in != null)
      return in; 
    ClassLoader[] cls = { BridJ.class.getClassLoader(), Thread.currentThread().getContextClassLoader(), systemClassLoader };
    for (ClassLoader cl : cls) {
      if (cl != null && (in = cl.getResource(path)) != null)
        return in; 
    } 
    return null;
  }
  
  static final List<String> embeddedLibraryResourceRoots = new ArrayList<String>();
  
  public static synchronized void addEmbeddedLibraryResourceRoot(String root) {
    embeddedLibraryResourceRoots.add(0, root);
  }
  
  static Set<File> temporaryExtractedLibraryCanonicalFiles = Collections.synchronizedSet(new LinkedHashSet<File>());
  
  static void addTemporaryExtractedLibraryFileToDeleteOnExit(File file) throws IOException {
    File canonicalFile = file.getCanonicalFile();
    temporaryExtractedLibraryCanonicalFiles.add(canonicalFile);
    canonicalFile.deleteOnExit();
  }
  
  private static final String arch = System.getProperty("os.arch");
  
  private static boolean is64Bits;
  
  private static File extractedLibrariesTempDir;
  
  private static List<NativeLibrary> nativeLibraries;
  
  public static boolean useUnicodeVersionOfWindowsAPIs;
  
  static final long DELETE_OLD_BINARIES_AFTER_MILLIS = 86400000L;
  
  static final int maxTempFileAttempts = 20;
  
  static {
    String dataModel = System.getProperty("sun.arch.data.model", System.getProperty("com.ibm.vm.bitmode"));
    if ("32".equals(dataModel)) {
      is64Bits = false;
    } else if ("64".equals(dataModel)) {
      is64Bits = true;
    } else {
      is64Bits = (arch.contains("64") || arch.equalsIgnoreCase("sparcv9"));
    } 
    systemClassLoader = createClassLoader();
    addEmbeddedLibraryResourceRoot("libs/");
    if (!isAndroid()) {
      addEmbeddedLibraryResourceRoot("lib/");
      addEmbeddedLibraryResourceRoot("org/bridj/lib/");
      if (!"v0_7_0".equals(""))
        addEmbeddedLibraryResourceRoot("org/bridj/v0_7_0/lib/"); 
    } 
    try {
      extractedLibrariesTempDir = createTempDir("BridJExtractedLibraries");
      initLibrary();
    } catch (Throwable th) {
      th.printStackTrace();
    } 
    POINTER_SIZE = sizeOf_ptrdiff_t();
    WCHAR_T_SIZE = sizeOf_wchar_t();
    SIZE_T_SIZE = sizeOf_size_t();
    TIME_T_SIZE = sizeOf_time_t();
    CLONG_SIZE = sizeOf_long();
    is64Bits = (POINTER_SIZE == 8);
    Runtime.getRuntime().addShutdownHook(new Thread() {
          public void run() {
            Platform.shutdown();
          }
        });
    nativeLibraries = new ArrayList<NativeLibrary>();
    useUnicodeVersionOfWindowsAPIs = (!"false".equals(System.getProperty("bridj.useUnicodeVersionOfWindowsAPIs")) && !"0".equals(System.getenv("BRIDJ_USE_UNICODE_VERSION_OF_WINDOWS_APIS")));
  }
  
  static void addNativeLibrary(NativeLibrary library) {
    synchronized (nativeLibraries) {
      nativeLibraries.add(library);
    } 
  }
  
  private static void shutdown() {
    deleteTemporaryExtractedLibraryFiles();
  }
  
  private static void releaseNativeLibraries() {
    synchronized (nativeLibraries) {
      for (int iLibrary = nativeLibraries.size(); iLibrary-- != 0; ) {
        NativeLibrary lib = nativeLibraries.get(iLibrary);
        try {
          lib.release();
        } catch (Throwable th) {
          BridJ.error("Failed to release library '" + lib.path + "' : " + th, th);
        } 
      } 
    } 
  }
  
  private static void deleteTemporaryExtractedLibraryFiles() {
    synchronized (temporaryExtractedLibraryCanonicalFiles) {
      temporaryExtractedLibraryCanonicalFiles.add(extractedLibrariesTempDir);
      List<File> filesToDeleteAfterExit = new ArrayList<File>();
      for (File tempFile : temporaryExtractedLibraryCanonicalFiles) {
        if (tempFile.delete()) {
          if (BridJ.verbose)
            BridJ.info("Deleted temporary library file '" + tempFile + "'"); 
          continue;
        } 
        filesToDeleteAfterExit.add(tempFile);
      } 
      if (!filesToDeleteAfterExit.isEmpty()) {
        if (BridJ.verbose)
          BridJ.info("Attempting to delete " + filesToDeleteAfterExit.size() + " files after JVM exit : " + StringUtils.implode(filesToDeleteAfterExit, ", ")); 
        try {
          ProcessUtils.startJavaProcess(DeleteFiles.class, filesToDeleteAfterExit);
        } catch (Throwable ex) {
          BridJ.error("Failed to launch process to delete files after JVM exit : " + ex, ex);
        } 
      } 
    } 
  }
  
  public static class DeleteFiles {
    static final long TRY_DELETE_EVERY_MILLIS = 50L;
    
    static final long FAIL_AFTER_MILLIS = 10000L;
    
    static boolean delete(List<File> files) {
      for (Iterator<File> it = files.iterator(); it.hasNext(); ) {
        File file = it.next();
        if (file.delete())
          it.remove(); 
      } 
      return files.isEmpty();
    }
    
    public static void main(String[] args) {
      try {
        List<File> files = new LinkedList<File>();
        for (String arg : args)
          files.add(new File(arg)); 
        long start = System.currentTimeMillis();
        while (!delete(files)) {
          long elapsed = System.currentTimeMillis() - start;
          if (elapsed > 10000L) {
            BridJ.error("Failed to delete the following files : " + StringUtils.implode(files));
            System.exit(1);
          } 
          Thread.sleep(50L);
        } 
      } catch (Throwable th) {
        th.printStackTrace();
      } finally {
        System.exit(0);
      } 
    }
  }
  
  static ClassLoader createClassLoader() {
    List<URL> urls = new ArrayList<URL>();
    for (String propName : new String[] { "java.class.path", "sun.boot.class.path" }) {
      String prop = System.getProperty(propName);
      if (prop != null)
        for (String path : prop.split(File.pathSeparator)) {
          path = path.trim();
          if (path.length() != 0) {
            URL uRL;
            try {
              uRL = new URL(path);
            } catch (MalformedURLException ex) {
              try {
                uRL = (new File(path)).toURI().toURL();
              } catch (MalformedURLException ex2) {
                uRL = null;
              } 
            } 
            if (uRL != null)
              urls.add(uRL); 
          } 
        }  
    } 
    return new URLClassLoader(urls.<URL>toArray(new URL[urls.size()]));
  }
  
  static String getenvOrProperty(String envName, String javaName, String defaultValue) {
    String value = System.getenv(envName);
    if (value == null)
      value = System.getProperty(javaName); 
    if (value == null)
      value = defaultValue; 
    return value;
  }
  
  public static synchronized void initLibrary() {
    if (inited)
      return; 
    inited = true;
    try {
      boolean loaded = false;
      String forceLibFile = getenvOrProperty("BRIDJ_LIBRARY", "bridj.library", null);
      String lib = null;
      if (forceLibFile != null)
        try {
          System.load(lib = forceLibFile);
          loaded = true;
        } catch (Throwable ex) {
          BridJ.error("Failed to load forced library " + forceLibFile, ex);
        }  
      if (!loaded) {
        if (!isAndroid())
          try {
            File libFile = extractEmbeddedLibraryResource("bridj");
            if (libFile == null)
              throw new FileNotFoundException("Failed to extract embedded library 'bridj' (could be a classloader issue, or missing binary in resource path " + StringUtils.implode(embeddedLibraryResourceRoots, ", ") + ")"); 
            if (BridJ.veryVerbose)
              BridJ.info("Loading library " + libFile); 
            System.load(lib = libFile.toString());
            BridJ.setNativeLibraryFile("bridj", libFile);
            loaded = true;
          } catch (IOException ex) {
            BridJ.error("Failed to load 'bridj'", ex);
          }  
        if (!loaded)
          System.loadLibrary("bridj"); 
      } 
      if (BridJ.veryVerbose)
        BridJ.info("Loaded library " + lib); 
      init();
      if (BridJ.logCalls)
        BridJ.info("Calls logs enabled"); 
    } catch (Throwable ex) {
      throw new RuntimeException("Failed to initialize " + BridJ.class.getSimpleName() + " (" + ex + ")", ex);
    } 
  }
  
  public static boolean isLinux() {
    return (isUnix() && osName.toLowerCase().contains("linux"));
  }
  
  public static boolean isMacOSX() {
    return (isUnix() && (osName.startsWith("Mac") || osName.startsWith("Darwin")));
  }
  
  public static boolean isSolaris() {
    return (isUnix() && (osName.startsWith("SunOS") || osName.startsWith("Solaris")));
  }
  
  public static boolean isBSD() {
    return (isUnix() && (osName.contains("BSD") || isMacOSX()));
  }
  
  public static boolean isUnix() {
    return (File.separatorChar == '/');
  }
  
  public static boolean isWindows() {
    return (File.separatorChar == '\\');
  }
  
  public static boolean isWindows7() {
    return osName.equals("Windows 7");
  }
  
  private static String getArch() {
    return arch;
  }
  
  public static String getMachine() {
    String arch = getArch();
    if (arch.equals("amd64") || arch.equals("x86_64")) {
      if (is64Bits())
        return "x86_64"; 
      return "i386";
    } 
    return arch;
  }
  
  public static boolean isAndroid() {
    return ("dalvik".equalsIgnoreCase(System.getProperty("java.vm.name")) && isLinux());
  }
  
  public static boolean isArm() {
    String arch = getArch();
    return "arm".equals(arch);
  }
  
  public static boolean isSparc() {
    String arch = getArch();
    return ("sparc".equals(arch) || "sparcv9".equals(arch));
  }
  
  public static boolean is64Bits() {
    return is64Bits;
  }
  
  public static boolean isAmd64Arch() {
    String arch = getArch();
    return arch.equals("x86_64");
  }
  
  static List<String> getPossibleFileNames(String name) {
    List<String> fileNames = new ArrayList<String>(1);
    if (isWindows()) {
      fileNames.add(name + ".dll");
      fileNames.add(name + ".drv");
    } else {
      String jniName = "lib" + name + ".jnilib";
      if (isMacOSX()) {
        fileNames.add("lib" + name + ".dylib");
        fileNames.add(jniName);
      } else {
        fileNames.add("lib" + name + ".so");
        fileNames.add(name + ".so");
        fileNames.add(jniName);
      } 
    } 
    assert !fileNames.isEmpty();
    if (name.contains("."))
      fileNames.add(name); 
    return fileNames;
  }
  
  static synchronized List<String> getEmbeddedLibraryPaths(String name) {
    List<String> paths = new ArrayList<String>(embeddedLibraryResourceRoots.size());
    for (String root : embeddedLibraryResourceRoots) {
      if (root == null)
        continue; 
      if (isWindows()) {
        paths.add(root + (is64Bits() ? "win64/" : "win32/"));
        continue;
      } 
      if (isMacOSX()) {
        if (isArm()) {
          paths.add(root + "iphoneos_arm32_arm/");
          continue;
        } 
        paths.add(root + "darwin_universal/");
        if (isAmd64Arch())
          paths.add(root + "darwin_x64/"); 
        continue;
      } 
      if (isAndroid()) {
        assert root.equals("libs/");
        paths.add(root + "armeabi/");
        continue;
      } 
      if (isLinux()) {
        if (isArm()) {
          paths.add(root + getARMLinuxLibDir());
          paths.add(root + getARMLinuxLibDir().replace("_arm", "_arm32_arm"));
          continue;
        } 
        paths.add(root + (is64Bits() ? "linux_x64/" : "linux_x86/"));
        continue;
      } 
      if (isSolaris()) {
        if (isSparc()) {
          paths.add(root + (is64Bits() ? "sunos_sparc64/" : "sunos_sparc/"));
          continue;
        } 
        paths.add(root + (is64Bits() ? "sunos_x64/" : "sunos_x86/"));
      } 
    } 
    if (paths.isEmpty())
      throw new RuntimeException("Platform not supported ! (os.name='" + osName + "', os.arch='" + System.getProperty("os.arch") + "')"); 
    return paths;
  }
  
  static synchronized List<String> getEmbeddedLibraryResource(String name) {
    List<String> paths = getEmbeddedLibraryPaths(name);
    List<String> fileNames = getPossibleFileNames(name);
    List<String> ret = new ArrayList<String>(paths.size() * fileNames.size());
    for (String path : paths) {
      for (String fileName : fileNames)
        ret.add(path + fileName); 
    } 
    if (BridJ.veryVerbose)
      BridJ.info("Embedded resource paths for library '" + name + "': " + ret); 
    return ret;
  }
  
  static void tryDeleteFilesInSameDirectory(final File legitFile, final Pattern fileNamePattern, long atLeastOlderThanMillis) {
    final long maxModifiedDateForDeletion = System.currentTimeMillis() - atLeastOlderThanMillis;
    (new Thread(new Runnable() {
          public void run() {
            File dir = legitFile.getParentFile();
            String legitFileName = legitFile.getName();
            try {
              for (String name : dir.list()) {
                if (!name.equals(legitFileName))
                  if (fileNamePattern.matcher(name).matches()) {
                    File file = new File(dir, name);
                    if (file.lastModified() <= maxModifiedDateForDeletion)
                      if (file.delete() && BridJ.verbose)
                        BridJ.info("Deleted old binary file '" + file + "'");  
                  }  
              } 
            } catch (SecurityException ex) {
              BridJ.warning("Failed to delete files matching '" + fileNamePattern + "' in directory '" + dir + "'", ex);
            } catch (Throwable ex) {
              BridJ.error("Unexpected error : " + ex, ex);
            } 
          }
        })).start();
  }
  
  static File extractEmbeddedLibraryResource(String name) throws IOException {
    String firstLibraryResource = null;
    List<String> libraryResources = getEmbeddedLibraryResource(name);
    if (BridJ.veryVerbose)
      BridJ.info("Library resources for " + name + ": " + libraryResources); 
    for (String libraryResource : libraryResources) {
      if (firstLibraryResource == null)
        firstLibraryResource = libraryResource; 
      int i = libraryResource.lastIndexOf('.');
      byte[] b = new byte[8196];
      InputStream in = getResourceAsStream(libraryResource);
      if (in == null) {
        File f = new File(libraryResource);
        if (!f.exists())
          f = new File(f.getName()); 
        if (f.exists())
          return f.getCanonicalFile(); 
        continue;
      } 
      String fileName = (new File(libraryResource)).getName();
      File libFile = new File(extractedLibrariesTempDir, fileName);
      OutputStream out = new BufferedOutputStream(new FileOutputStream(libFile));
      int len;
      while ((len = in.read(b)) > 0)
        out.write(b, 0, len); 
      out.close();
      in.close();
      addTemporaryExtractedLibraryFileToDeleteOnExit(libFile);
      addTemporaryExtractedLibraryFileToDeleteOnExit(libFile.getParentFile());
      return libFile;
    } 
    return null;
  }
  
  static File createTempDir(String prefix) throws IOException {
    for (int i = 0; i < 20; i++) {
      File dir = File.createTempFile(prefix, "");
      if (dir.delete() && dir.mkdirs())
        return dir; 
    } 
    throw new RuntimeException("Failed to create temp dir with prefix '" + prefix + "' despite " + '\024' + " attempts!");
  }
  
  public static final void open(URL url) throws NoSuchMethodException {
    if (url.getProtocol().equals("file")) {
      open(new File(url.getFile()));
    } else if (isMacOSX()) {
      execArgs(new String[] { "open", url.toString() });
    } else if (isWindows()) {
      execArgs(new String[] { "rundll32", "url.dll,FileProtocolHandler", url.toString() });
    } else if (isUnix() && hasUnixCommand("gnome-open")) {
      execArgs(new String[] { "gnome-open", url.toString() });
    } else if (isUnix() && hasUnixCommand("konqueror")) {
      execArgs(new String[] { "konqueror", url.toString() });
    } else if (isUnix() && hasUnixCommand("mozilla")) {
      execArgs(new String[] { "mozilla", url.toString() });
    } else {
      throw new NoSuchMethodException("Cannot open urls on this platform");
    } 
  }
  
  public static final void open(File file) throws NoSuchMethodException {
    if (isMacOSX()) {
      execArgs(new String[] { "open", file.getAbsolutePath() });
    } else if (isWindows()) {
      if (file.isDirectory()) {
        execArgs(new String[] { "explorer", file.getAbsolutePath() });
      } else {
        execArgs(new String[] { "start", file.getAbsolutePath() });
      } 
    } else if (isUnix() && hasUnixCommand("gnome-open")) {
      execArgs(new String[] { "gnome-open", file.toString() });
    } else if (isUnix() && hasUnixCommand("konqueror")) {
      execArgs(new String[] { "konqueror", file.toString() });
    } else if (isSolaris() && file.isDirectory()) {
      execArgs(new String[] { "/usr/dt/bin/dtfile", "-folder", file.getAbsolutePath() });
    } else {
      throw new NoSuchMethodException("Cannot open files on this platform");
    } 
  }
  
  public static final void show(File file) throws NoSuchMethodException, IOException {
    if (isWindows()) {
      exec("explorer /e,/select,\"" + file.getCanonicalPath() + "\"");
    } else {
      open(file.getAbsoluteFile().getParentFile());
    } 
  }
  
  static final void execArgs(String... cmd) throws NoSuchMethodException {
    try {
      Runtime.getRuntime().exec(cmd);
    } catch (Exception ex) {
      ex.printStackTrace();
      throw new NoSuchMethodException(ex.toString());
    } 
  }
  
  static final void exec(String cmd) throws NoSuchMethodException {
    try {
      Runtime.getRuntime().exec(cmd).waitFor();
    } catch (Exception ex) {
      ex.printStackTrace();
      throw new NoSuchMethodException(ex.toString());
    } 
  }
  
  static final boolean hasUnixCommand(String name) {
    try {
      Process p = Runtime.getRuntime().exec(new String[] { "which", name });
      return (p.waitFor() == 0);
    } catch (Exception ex) {
      ex.printStackTrace();
      return false;
    } 
  }
  
  private static final boolean contains(String data, String[] search) {
    if (null != data && null != search)
      for (int i = 0; i < search.length; i++) {
        if (data.indexOf(search[i]) >= 0)
          return true; 
      }  
    return false;
  }
  
  private static String getBashVersionInfo() {
    String versionInfo = "";
    try {
      String cmd = "bash --version";
      Process p = Runtime.getRuntime().exec(cmd);
      p.waitFor();
      BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
      String line = reader.readLine();
      if (p.exitValue() == 0)
        while (line != null) {
          if (!line.isEmpty()) {
            versionInfo = line;
            break;
          } 
          line = reader.readLine();
        }  
    } catch (IOException ioe) {
      ioe.printStackTrace();
    } catch (InterruptedException ie) {
      ie.printStackTrace();
    } 
    return versionInfo;
  }
  
  private static boolean hasReadElfTag(String tag) {
    String tagValue = getReadElfTag(tag);
    if (tagValue != null && !tagValue.isEmpty())
      return true; 
    return false;
  }
  
  private static String getReadElfTag(String tag) {
    String tagValue = null;
    try {
      String cmd = "/usr/bin/readelf -A /proc/self/exe";
      Process p = Runtime.getRuntime().exec(cmd);
      p.waitFor();
      if (p.exitValue() == 0) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line = reader.readLine();
        while (line != null) {
          line = line.trim();
          if (line.startsWith(tag) && line.contains(":")) {
            String[] lineParts = line.split(":", 2);
            if (lineParts.length > 1)
              tagValue = lineParts[1].trim(); 
            break;
          } 
          line = reader.readLine();
        } 
      } 
    } catch (IOException ioe) {
      ioe.printStackTrace();
    } catch (InterruptedException ie) {
      ie.printStackTrace();
    } 
    return tagValue;
  }
  
  private static final String getARMLinuxLibDir() {
    boolean isHF = ((Boolean)AccessController.<Boolean>doPrivileged(new PrivilegedAction<Boolean>() {
          private final String[] gnueabihf = new String[] { "gnueabihf", "armhf" };
          
          public Boolean run() {
            if (Platform.contains(System.getProperty("sun.boot.library.path"), this.gnueabihf) || Platform.contains(System.getProperty("java.library.path"), this.gnueabihf) || Platform.contains(System.getProperty("java.home"), this.gnueabihf) || Platform.getBashVersionInfo().contains("gnueabihf") || Platform.hasReadElfTag("Tag_ABI_HardFP_use"))
              return Boolean.valueOf(true); 
            return Boolean.valueOf(false);
          }
        })).booleanValue();
    return "linux_arm" + (isHF ? "hf" : "el") + "/";
  }
  
  private static native void init();
  
  static native int sizeOf_size_t();
  
  static native int sizeOf_time_t();
  
  static native int sizeOf_wchar_t();
  
  static native int sizeOf_ptrdiff_t();
  
  static native int sizeOf_long();
  
  static native int getMaxDirectMappingArgCount();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\Platform.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */