package org.bridj;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bridj.demangling.Demangler;

public class HeadersReconstructor {
  public static void reconstructHeaders(Iterable<NativeLibrary> libraries, PrintWriter out) {
    List<Demangler.MemberRef> orphanMembers = new ArrayList<Demangler.MemberRef>();
    Map<Demangler.TypeRef, List<Demangler.MemberRef>> membersByClass = new HashMap<Demangler.TypeRef, List<Demangler.MemberRef>>();
    for (NativeLibrary library : libraries) {
      for (Demangler.Symbol symbol : library.getSymbols()) {
        Demangler.MemberRef mr = symbol.getParsedRef();
        if (mr == null)
          continue; 
        Demangler.TypeRef et = mr.getEnclosingType();
        if (et == null) {
          orphanMembers.add(mr);
          continue;
        } 
        List<Demangler.MemberRef> mrs = membersByClass.get(et);
        if (mrs == null)
          membersByClass.put(et, mrs = new ArrayList<Demangler.MemberRef>()); 
        mrs.add(mr);
      } 
    } 
    for (Demangler.TypeRef tr : membersByClass.keySet())
      out.println("class " + tr + ";"); 
    for (Demangler.MemberRef mr : orphanMembers)
      out.println(mr + ";"); 
    for (Map.Entry<Demangler.TypeRef, List<Demangler.MemberRef>> e : membersByClass.entrySet()) {
      Demangler.TypeRef tr = e.getKey();
      List<Demangler.MemberRef> mrs = e.getValue();
      out.println("class " + tr + " \n{");
      for (Demangler.MemberRef mr : mrs)
        out.println("\t" + mr + ";"); 
      out.println("}");
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\HeadersReconstructor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */