/*    */ package org.bridj;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.bridj.demangling.Demangler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HeadersReconstructor
/*    */ {
/*    */   public static void reconstructHeaders(Iterable<NativeLibrary> libraries, PrintWriter out) {
/* 48 */     List<Demangler.MemberRef> orphanMembers = new ArrayList<Demangler.MemberRef>();
/* 49 */     Map<Demangler.TypeRef, List<Demangler.MemberRef>> membersByClass = new HashMap<Demangler.TypeRef, List<Demangler.MemberRef>>();
/* 50 */     for (NativeLibrary library : libraries) {
/* 51 */       for (Demangler.Symbol symbol : library.getSymbols()) {
/* 52 */         Demangler.MemberRef mr = symbol.getParsedRef();
/* 53 */         if (mr == null) {
/*    */           continue;
/*    */         }
/*    */         
/* 57 */         Demangler.TypeRef et = mr.getEnclosingType();
/* 58 */         if (et == null) {
/* 59 */           orphanMembers.add(mr); continue;
/*    */         } 
/* 61 */         List<Demangler.MemberRef> mrs = membersByClass.get(et);
/* 62 */         if (mrs == null) {
/* 63 */           membersByClass.put(et, mrs = new ArrayList<Demangler.MemberRef>());
/*    */         }
/* 65 */         mrs.add(mr);
/*    */       } 
/*    */     } 
/*    */     
/* 69 */     for (Demangler.TypeRef tr : membersByClass.keySet()) {
/* 70 */       out.println("class " + tr + ";");
/*    */     }
/*    */     
/* 73 */     for (Demangler.MemberRef mr : orphanMembers) {
/* 74 */       out.println(mr + ";");
/*    */     }
/*    */     
/* 77 */     for (Map.Entry<Demangler.TypeRef, List<Demangler.MemberRef>> e : membersByClass.entrySet()) {
/* 78 */       Demangler.TypeRef tr = e.getKey();
/* 79 */       List<Demangler.MemberRef> mrs = e.getValue();
/* 80 */       out.println("class " + tr + " \n{");
/* 81 */       for (Demangler.MemberRef mr : mrs) {
/* 82 */         out.println("\t" + mr + ";");
/*    */       }
/* 84 */       out.println("}");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\HeadersReconstructor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */