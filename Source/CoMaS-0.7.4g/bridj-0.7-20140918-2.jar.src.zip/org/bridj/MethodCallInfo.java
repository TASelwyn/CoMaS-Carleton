package org.bridj;

import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import org.bridj.ann.CLong;
import org.bridj.ann.Constructor;
import org.bridj.ann.Convention;
import org.bridj.ann.DisableDirect;
import org.bridj.ann.Ptr;
import org.bridj.ann.SetsLastError;
import org.bridj.ann.Virtual;
import org.bridj.dyncall.DyncallLibrary;
import org.bridj.util.AnnotationUtils;
import org.bridj.util.Utils;

public class MethodCallInfo {
  List<CallIO> callIOs;
  
  private Class<?> declaringClass;
  
  long nativeClass;
  
  int returnValueType;
  
  int[] paramsValueTypes;
  
  Method method;
  
  String methodName;
  
  String symbolName;
  
  private long forwardedPointer;
  
  String dcSignature;
  
  String javaSignature;
  
  String asmSignature;
  
  Object javaCallback;
  
  boolean isGenericCallback;
  
  boolean isObjCBlock;
  
  int virtualIndex = -1;
  
  int virtualTableOffset = 0;
  
  private int dcCallingConvention = 0;
  
  boolean isVarArgs;
  
  boolean isStatic;
  
  boolean isCPlusPlus;
  
  boolean direct;
  
  boolean startsWithThis;
  
  boolean bNeedsThisPointer;
  
  boolean throwsLastError;
  
  boolean setsLastError;
  
  boolean hasCC;
  
  public MethodCallInfo(Method method) {
    this(method, method);
  }
  
  static boolean derivesFrom(Class<?> c, String className) {
    while (c != null) {
      if (c.getName().equals(className))
        return true; 
      c = c.getSuperclass();
    } 
    return false;
  }
  
  public MethodCallInfo(Type genericReturnType, Type[] parameterTypes, boolean prependJNIPointers) {
    this(genericReturnType, new Annotation[0], parameterTypes, new Annotation[parameterTypes.length][], prependJNIPointers);
  }
  
  public MethodCallInfo(Type genericReturnType, Annotation[] returnAnnotations, Type[] parameterTypes, Annotation[][] paramsAnnotations, boolean prependJNIPointers) {
    init(null, Utils.getClass(genericReturnType), genericReturnType, returnAnnotations, Utils.getClasses(parameterTypes), parameterTypes, paramsAnnotations, prependJNIPointers, false, true);
  }
  
  public MethodCallInfo(Method method, Method definition) {
    setMethod(method);
    setDeclaringClass(method.getDeclaringClass());
    this.symbolName = this.methodName;
    int modifiers = method.getModifiers();
    this.isStatic = Modifier.isStatic(modifiers);
    this.isVarArgs = method.isVarArgs();
    boolean isNative = Modifier.isNative(modifiers);
    boolean isVirtual = AnnotationUtils.isAnnotationPresent(Virtual.class, definition, new Annotation[0]);
    boolean isDirectModeAllowed = (AnnotationUtils.getInheritableAnnotation(DisableDirect.class, definition, new Annotation[0]) == null && BridJ.isDirectModeEnabled());
    this.isCPlusPlus = (!this.isStatic && derivesFrom(method.getDeclaringClass(), "org.bridj.cpp.CPPObject"));
    this.isObjCBlock = (!this.isStatic && derivesFrom(method.getDeclaringClass(), "org.bridj.objc.ObjCBlock"));
    init(method, method.getReturnType(), method.getGenericReturnType(), method.getAnnotations(), method.getParameterTypes(), method.getGenericParameterTypes(), method.getParameterAnnotations(), isNative, isVirtual, isDirectModeAllowed);
    Convention cc = (Convention)AnnotationUtils.getInheritableAnnotation(Convention.class, definition, new Annotation[0]);
    if (cc != null)
      setCallingConvention(cc.value()); 
    List<Class<?>> exceptionTypes = Arrays.asList(definition.getExceptionTypes());
    if (!exceptionTypes.isEmpty()) {
      this.direct = false;
      if (exceptionTypes.contains(LastError.class)) {
        this.throwsLastError = true;
        this.setsLastError = true;
      } 
    } 
    if (AnnotationUtils.getInheritableAnnotation(SetsLastError.class, definition, new Annotation[0]) != null) {
      this.direct = false;
      this.setsLastError = true;
    } 
  }
  
  protected void init(AnnotatedElement annotatedElement, Class<?> returnType, Type genericReturnType, Annotation[] returnAnnotations, Class[] parameterTypes, Type[] genericParameterTypes, Annotation[][] paramsAnnotations, boolean prependJNIPointers, boolean isVirtual, boolean isDirectModeAllowed) {
    assert returnType != null;
    assert genericReturnType != null;
    assert parameterTypes != null;
    assert genericParameterTypes != null;
    assert returnAnnotations != null;
    assert parameterTypes.length == genericParameterTypes.length;
    assert paramsAnnotations.length == genericParameterTypes.length;
    int nParams = genericParameterTypes.length;
    this.paramsValueTypes = new int[nParams];
    this.direct = isDirectModeAllowed;
    StringBuilder javaSig = new StringBuilder(64);
    StringBuilder asmSig = new StringBuilder(64);
    StringBuilder dcSig = new StringBuilder(16);
    javaSig.append('(');
    asmSig.append('(');
    if (prependJNIPointers)
      dcSig.append('p').append('p'); 
    if (BridJ.debug)
      BridJ.info("Analyzing " + ((this.declaringClass == null) ? "anonymous method" : (this.declaringClass.getName() + "." + this.methodName))); 
    if (this.isObjCBlock)
      appendToSignature(0, NativeConstants.ValueType.ePointerValue, Pointer.class, Pointer.class, null, dcSig, null); 
    for (int iParam = 0; iParam < nParams; iParam++) {
      Type genericParameterType = genericParameterTypes[iParam];
      Class<?> parameterType = parameterTypes[iParam];
      NativeConstants.ValueType paramValueType = getValueType(iParam, nParams, parameterType, genericParameterType, null, paramsAnnotations[iParam]);
      if (BridJ.veryVerbose)
        BridJ.info("\tparam " + paramValueType); 
      this.paramsValueTypes[iParam] = paramValueType.ordinal();
      appendToSignature(iParam, paramValueType, parameterType, genericParameterType, javaSig, dcSig, asmSig);
    } 
    javaSig.append(')');
    asmSig.append(')');
    dcSig.append(')');
    NativeConstants.ValueType retType = getValueType(-1, nParams, returnType, genericReturnType, annotatedElement, returnAnnotations);
    if (BridJ.veryVerbose)
      BridJ.info("\treturns " + retType); 
    appendToSignature(-1, retType, returnType, genericReturnType, javaSig, dcSig, asmSig);
    this.returnValueType = retType.ordinal();
    this.javaSignature = javaSig.toString();
    this.asmSignature = asmSig.toString();
    this.dcSignature = dcSig.toString();
    this.isCPlusPlus = (this.isCPlusPlus || isVirtual);
    if (this.isCPlusPlus && !this.isStatic) {
      if (!this.startsWithThis)
        this.direct = false; 
      this.bNeedsThisPointer = true;
      if (Platform.isWindows() && 
        !Platform.is64Bits())
        setDcCallingConvention(5); 
    } 
    if (nParams > Platform.getMaxDirectMappingArgCount())
      this.direct = false; 
    if (BridJ.veryVerbose) {
      BridJ.info("\t-> direct " + this.direct);
      BridJ.info("\t-> javaSignature " + this.javaSignature);
      BridJ.info("\t-> callIOs " + this.callIOs);
      BridJ.info("\t-> asmSignature " + this.asmSignature);
      BridJ.info("\t-> dcSignature " + this.dcSignature);
    } 
    if (BridJ.veryVerbose)
      BridJ.info((this.direct ? "[mappable as direct] " : "[not mappable as direct] ") + this.method); 
  }
  
  public boolean hasCallingConvention() {
    return this.hasCC;
  }
  
  public void setCallingConvention(Convention.Style style) {
    if (style == null)
      return; 
    if (!Platform.isWindows() || Platform.is64Bits())
      return; 
    switch (style) {
      case eVoidValue:
        this.direct = false;
        setDcCallingConvention(Platform.isWindows() ? 3 : 0);
        break;
      case eIntValue:
      case eLongValue:
        this.direct = false;
        setDcCallingConvention(2);
        break;
      case eCLongValue:
        this.direct = false;
        setDcCallingConvention(Platform.isWindows() ? 5 : 0);
        break;
    } 
    if (BridJ.veryVerbose)
      BridJ.info("Setting CC " + style + " (-> " + this.dcCallingConvention + ") for " + this.methodName); 
  }
  
  void addCallIO(CallIO handler) {
    if (this.callIOs == null)
      this.callIOs = new ArrayList<CallIO>(); 
    assert handler != null;
    this.callIOs.add(handler);
  }
  
  public CallIO[] getCallIOs() {
    if (this.callIOs == null)
      return new CallIO[0]; 
    return this.callIOs.<CallIO>toArray(new CallIO[this.callIOs.size()]);
  }
  
  public void prependCallbackCC() {
    char cc = getDcCallbackConvention(getDcCallingConvention());
    if (cc == '\000')
      return; 
    this.dcSignature = String.valueOf('_') + String.valueOf(cc) + this.dcSignature;
  }
  
  public String getDcSignature() {
    return this.dcSignature;
  }
  
  public String getJavaSignature() {
    return this.javaSignature;
  }
  
  public String getASMSignature() {
    return this.asmSignature;
  }
  
  boolean getBoolAnnotation(Class<? extends Annotation> ac, AnnotatedElement element, Annotation... directAnnotations) {
    Annotation ann = AnnotationUtils.getAnnotation(ac, element, directAnnotations);
    return (ann != null);
  }
  
  public NativeConstants.ValueType getValueType(int iParam, int nParams, Class<?> c, Type t, AnnotatedElement element, Annotation... directAnnotations) {
    boolean isPtr = AnnotationUtils.isAnnotationPresent(Ptr.class, element, directAnnotations);
    boolean isCLong = AnnotationUtils.isAnnotationPresent(CLong.class, element, directAnnotations);
    Constructor cons = (Constructor)AnnotationUtils.getAnnotation(Constructor.class, element, directAnnotations);
    if (isPtr || cons != null || isCLong) {
      if (c != Long.class && c != long.class)
        throw new RuntimeException("Annotation should only be used on a long parameter, not on a " + c.getName()); 
      if (isPtr) {
        if (!Platform.is64Bits())
          this.direct = false; 
      } else if (isCLong) {
        if (Platform.CLONG_SIZE != 8)
          this.direct = false; 
      } else if (cons != null) {
        this.isCPlusPlus = true;
        this.startsWithThis = true;
        if (iParam != 0)
          throw new RuntimeException("Annotation " + Constructor.class.getName() + " cannot have more than one (long) argument"); 
      } 
      return isCLong ? NativeConstants.ValueType.eCLongValue : NativeConstants.ValueType.eSizeTValue;
    } 
    if (c == null || c.equals(void.class))
      return NativeConstants.ValueType.eVoidValue; 
    if (c == Integer.class || c == int.class)
      return NativeConstants.ValueType.eIntValue; 
    if (c == Long.class || c == long.class)
      return (!isPtr || Platform.is64Bits()) ? NativeConstants.ValueType.eLongValue : NativeConstants.ValueType.eIntValue; 
    if (c == Short.class || c == short.class)
      return NativeConstants.ValueType.eShortValue; 
    if (c == Byte.class || c == byte.class)
      return NativeConstants.ValueType.eByteValue; 
    if (c == Boolean.class || c == boolean.class)
      return NativeConstants.ValueType.eBooleanValue; 
    if (c == Float.class || c == float.class) {
      usesFloats();
      return NativeConstants.ValueType.eFloatValue;
    } 
    if (c == char.class || c == char.class) {
      if (Platform.WCHAR_T_SIZE != 2)
        this.direct = false; 
      return NativeConstants.ValueType.eWCharValue;
    } 
    if (c == Double.class || c == double.class) {
      usesFloats();
      return NativeConstants.ValueType.eDoubleValue;
    } 
    if (c == CLong.class) {
      this.direct = false;
      return NativeConstants.ValueType.eCLongObjectValue;
    } 
    if (c == SizeT.class) {
      this.direct = false;
      return NativeConstants.ValueType.eSizeTObjectValue;
    } 
    if (c == TimeT.class) {
      this.direct = false;
      return NativeConstants.ValueType.eTimeTObjectValue;
    } 
    if (Pointer.class.isAssignableFrom(c)) {
      this.direct = false;
      CallIO cio = CallIO.Utils.createPointerCallIO(c, t);
      if (BridJ.veryVerbose)
        BridJ.info("CallIO : " + cio); 
      addCallIO(cio);
      return NativeConstants.ValueType.ePointerValue;
    } 
    if (c.isArray() && iParam == nParams - 1) {
      this.direct = false;
      return NativeConstants.ValueType.eEllipsis;
    } 
    if (ValuedEnum.class.isAssignableFrom(c)) {
      this.direct = false;
      CallIO cio = CallIO.Utils.createValuedEnumCallIO(Utils.getClass(Utils.getUniqueParameterizedTypeParameter(t)));
      if (BridJ.veryVerbose)
        BridJ.info("CallIO : " + cio); 
      addCallIO(cio);
      return NativeConstants.ValueType.eIntFlagSet;
    } 
    if (NativeObject.class.isAssignableFrom(c)) {
      Pointer<DyncallLibrary.DCstruct> pStruct = null;
      if (StructObject.class.isAssignableFrom(c)) {
        StructIO io = StructIO.getInstance(c, t);
        try {
          pStruct = DyncallStructs.buildDCstruct(io.desc);
        } catch (Throwable th) {
          BridJ.error("Unable to create low-level struct metadata for " + Utils.toString(t) + " : won't be able to use it as a by-value function argument.", th);
        } 
      } 
      addCallIO(new CallIO.NativeObjectHandler((Class)c, t, pStruct));
      this.direct = false;
      return NativeConstants.ValueType.eNativeObjectValue;
    } 
    throw new NoSuchElementException("No " + NativeConstants.ValueType.class.getSimpleName() + " for class " + c.getName());
  }
  
  void usesFloats() {}
  
  public void appendToSignature(int iParam, NativeConstants.ValueType type, Class<?> parameterType, Type genericParameterType, StringBuilder javaSig, StringBuilder dcSig, StringBuilder asmSig) {
    char dcChar;
    String javaChar, asmChar = null;
    switch (type) {
      case eVoidValue:
        dcChar = 'v';
        javaChar = "V";
        break;
      case eIntValue:
        dcChar = 'i';
        javaChar = "I";
        break;
      case eLongValue:
        dcChar = 'l';
        javaChar = "J";
        break;
      case eCLongValue:
        javaChar = "J";
        dcChar = 'j';
        if (Platform.CLONG_SIZE != 8)
          this.direct = false; 
        break;
      case eSizeTValue:
        javaChar = "J";
        if (Platform.SIZE_T_SIZE == 8) {
          dcChar = 'l';
          break;
        } 
        dcChar = 'i';
        this.direct = false;
        break;
      case eShortValue:
        dcChar = 's';
        javaChar = "S";
        break;
      case eDoubleValue:
        dcChar = 'd';
        javaChar = "D";
        break;
      case eFloatValue:
        dcChar = 'f';
        javaChar = "F";
        break;
      case eByteValue:
        dcChar = 'c';
        javaChar = "B";
        break;
      case eBooleanValue:
        dcChar = 'B';
        javaChar = "Z";
        break;
      case eWCharValue:
        switch (Platform.WCHAR_T_SIZE) {
          case 1:
            dcChar = 'c';
            this.direct = false;
            break;
          case 2:
            dcChar = 's';
            break;
          case 4:
            dcChar = 'i';
            this.direct = false;
            break;
          default:
            throw new RuntimeException("Unhandled sizeof(wchar_t) in GetJavaTypeSignature: " + Platform.WCHAR_T_SIZE);
        } 
        javaChar = "C";
        break;
      case eIntFlagSet:
        dcChar = 'i';
        javaChar = "L" + parameterType.getName().replace('.', '/') + ";";
        this.direct = false;
        break;
      case eCLongObjectValue:
        dcChar = 'p';
        javaChar = "Lorg/bridj/CLong;";
        this.direct = false;
        break;
      case eSizeTObjectValue:
        dcChar = 'p';
        javaChar = "Lorg/bridj/SizeT;";
        this.direct = false;
        break;
      case eTimeTObjectValue:
        dcChar = 'p';
        javaChar = "Lorg/bridj/TimeT;";
        this.direct = false;
        break;
      case ePointerValue:
        dcChar = 'p';
        javaChar = "L" + parameterType.getName().replace('.', '/') + ";";
        this.direct = false;
        break;
      case eNativeObjectValue:
        dcChar = 'T';
        javaChar = "L" + parameterType.getName().replace('.', '/') + ";";
        this.direct = false;
        break;
      case eEllipsis:
        javaChar = "[Ljava/lang/Object;";
        dcChar = '?';
        break;
      default:
        this.direct = false;
        throw new RuntimeException("Unhandled " + NativeConstants.ValueType.class.getSimpleName() + ": " + type);
    } 
    if (genericParameterType instanceof ParameterizedType && iParam < 0) {
      ParameterizedType pt = (ParameterizedType)genericParameterType;
      Type[] ts = pt.getActualTypeArguments();
      if (ts != null && ts.length == 1) {
        Type t = ts[0];
        if (t instanceof ParameterizedType)
          t = ((ParameterizedType)t).getRawType(); 
        if (t instanceof Class) {
          Class c = (Class)t;
          if (javaChar.endsWith(";"))
            asmChar = javaChar.substring(0, javaChar.length() - 1) + "<*L" + c.getName().replace('.', '/') + ";>"; 
        } 
      } 
    } 
    if (javaSig != null)
      javaSig.append(javaChar); 
    if (asmChar == null)
      asmChar = javaChar; 
    if (asmSig != null)
      asmSig.append(asmChar); 
    if (dcSig != null)
      dcSig.append(dcChar); 
  }
  
  public void setMethod(Method method) {
    this.method = method;
    if (method != null)
      this.methodName = method.getName(); 
    if (this.declaringClass == null)
      setDeclaringClass(method.getDeclaringClass()); 
  }
  
  public void setJavaSignature(String javaSignature) {
    this.javaSignature = javaSignature;
  }
  
  public Method getMethod() {
    return this.method;
  }
  
  public void setDeclaringClass(Class<?> declaringClass) {
    this.declaringClass = declaringClass;
  }
  
  public Class<?> getDeclaringClass() {
    return this.declaringClass;
  }
  
  public void setForwardedPointer(long forwardedPointer) {
    this.forwardedPointer = forwardedPointer;
  }
  
  public long getForwardedPointer() {
    return this.forwardedPointer;
  }
  
  public void setVirtualIndex(int virtualIndex) {
    this.virtualIndex = virtualIndex;
    if (BridJ.veryVerbose)
      BridJ.info("\t-> virtualIndex " + virtualIndex); 
  }
  
  public int getVirtualIndex() {
    return this.virtualIndex;
  }
  
  public String getSymbolName() {
    return this.symbolName;
  }
  
  public void setSymbolName(String symbolName) {
    this.symbolName = symbolName;
  }
  
  static char getDcCallbackConvention(int dcCallingConvention) {
    switch (dcCallingConvention) {
      case 2:
        return 's';
      case 3:
        return 'F';
      case 4:
        return 'f';
      case 5:
        return '+';
    } 
    return Character.MIN_VALUE;
  }
  
  public void setDcCallingConvention(int dcCallingConvention) {
    this.hasCC = true;
    this.dcCallingConvention = dcCallingConvention;
  }
  
  public int getDcCallingConvention() {
    return this.dcCallingConvention;
  }
  
  public Object getJavaCallback() {
    return this.javaCallback;
  }
  
  public void setJavaCallback(Object javaCallback) {
    this.javaCallback = javaCallback;
  }
  
  public void setGenericCallback(boolean genericCallback) {
    this.isGenericCallback = genericCallback;
  }
  
  public boolean isGenericCallback() {
    return this.isGenericCallback;
  }
  
  public void setNativeClass(long nativeClass) {
    this.nativeClass = nativeClass;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\MethodCallInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */