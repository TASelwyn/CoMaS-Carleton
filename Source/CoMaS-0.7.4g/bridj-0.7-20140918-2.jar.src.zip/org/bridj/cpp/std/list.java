package org.bridj.cpp.std;

import java.lang.reflect.Type;
import java.util.NoSuchElementException;
import org.bridj.BridJ;
import org.bridj.NativeObject;
import org.bridj.Pointer;
import org.bridj.StructObject;
import org.bridj.ann.Array;
import org.bridj.ann.Field;
import org.bridj.ann.Library;
import org.bridj.ann.Ptr;
import org.bridj.ann.Struct;
import org.bridj.ann.Template;
import org.bridj.cpp.CPPObject;
import org.bridj.cpp.CPPRuntime;

@Template({Type.class})
@Struct(customizer = STL.class)
public class list<T> extends CPPObject {
  protected volatile Type _T;
  
  @Library("c")
  @Ptr
  protected static native long malloc(@Ptr long paramLong);
  
  @Library("c")
  protected static native void free(@Ptr long paramLong);
  
  @Template({Type.class})
  public static class list_node<T> extends CPPObject {
    @Deprecated
    @Field(0)
    public Pointer<list_node<T>> next() {
      return this.io.getPointerField((StructObject)this, 0);
    }
    
    @Deprecated
    @Field(0)
    public void next(Pointer<list_node<T>> value) {
      this.io.setPointerField((StructObject)this, 0, value);
    }
    
    @Deprecated
    @Field(1)
    public Pointer<list_node<T>> prev() {
      return this.io.getPointerField((StructObject)this, 1);
    }
    
    @Field(1)
    public void prev(Pointer<list_node<T>> value) {
      this.io.setPointerField((StructObject)this, 1, value);
    }
    
    @Deprecated
    @Field(2)
    @Array({1L})
    public Pointer<T> data() {
      return this.io.getPointerField((StructObject)this, 2);
    }
    
    public list_node(Type t) {
      super((Void)null, -2, new Object[] { t });
    }
    
    public list_node(Pointer<? extends list_node> peer, Type t) {
      super(peer, new Object[] { t });
      if (!isValid())
        throw new RuntimeException("Invalid list internal data ! Are you trying to use an unsupported version of the STL ?"); 
    }
    
    protected boolean isValid() {
      long next = Pointer.getPeer(next());
      long prev = Pointer.getPeer(prev());
      if (next == 0L && prev == 0L)
        return false; 
      return true;
    }
    
    public T get() {
      return (T)data().get();
    }
    
    public void set(T value) {
      data().set(value);
    }
  }
  
  protected Type T() {
    if (this._T == null) {
      CPPRuntime.getInstance();
      this._T = (Type)CPPRuntime.getTemplateParameters(this, list.class)[0];
    } 
    return this._T;
  }
  
  protected list_node<T> createNode() {
    Type T = T();
    long size = BridJ.sizeOf(T);
    return new list_node<T>(Pointer.pointerToAddress(malloc(size)), T);
  }
  
  protected void deleteNode(list_node<T> node) {
    free(Pointer.getAddress((NativeObject)node, list_node.class));
  }
  
  @Deprecated
  @Field(0)
  public Pointer<list_node<T>> next() {
    return this.io.getPointerField((StructObject)this, 0);
  }
  
  @Deprecated
  @Field(0)
  public void next(Pointer<list_node<T>> value) {
    this.io.setPointerField((StructObject)this, 0, value);
  }
  
  @Deprecated
  @Field(1)
  public Pointer<list_node<T>> prev() {
    return this.io.getPointerField((StructObject)this, 1);
  }
  
  @Deprecated
  @Field(1)
  public void prev(Pointer<list_node<T>> value) {
    this.io.setPointerField((StructObject)this, 1, value);
  }
  
  public list(Type t) {
    super((Void)null, -2, new Object[] { t });
  }
  
  public list(Pointer<? extends list<T>> peer, Type t) {
    super(peer, new Object[] { t });
  }
  
  private void checkNotEmpty() {
    if (isRoot(next()) && isRoot(prev()))
      throw new NoSuchElementException(); 
  }
  
  public boolean empty() {
    return (next() != null);
  }
  
  public T front() {
    checkNotEmpty();
    return ((list_node<T>)next().get()).get();
  }
  
  public T back() {
    checkNotEmpty();
    Pointer<list_node<T>> prev = prev(), next = next();
    Pointer<list_node<T>> nextPrev = (next == null) ? null : ((list_node<T>)next.get()).prev();
    Pointer<list_node<T>> prevNext = (prev == null) ? null : ((list_node<T>)prev.get()).next();
    int[] nextValues = (next == null) ? null : next.getInts(20);
    int[] prevValues = (prev == null) ? null : prev.getInts(20);
    list_node<T> n = (list_node<T>)prev.get();
    int[] values = Pointer.pointerTo((NativeObject)n).getInts(20);
    return n.get();
  }
  
  private boolean same(Pointer a, Pointer b) {
    return (Pointer.getPeer(a) == Pointer.getPeer(b));
  }
  
  private boolean isRoot(Pointer a) {
    return same(a, Pointer.getPointer((NativeObject)this));
  }
  
  protected void hook(Pointer<list_node<T>> prev, Pointer<list_node<T>> next, T value) {
    list_node<T> tmp = createNode();
    Pointer<list_node<T>> pTmp = Pointer.getPointer((NativeObject)tmp);
    tmp.set(value);
    tmp.next(next);
    tmp.prev(prev);
    if (!isRoot(next))
      ((list_node<T>)next.get()).prev(pTmp); 
    if (!isRoot(prev))
      ((list_node<T>)prev.get()).next(pTmp); 
  }
  
  public void push_back(T value) {
    hook(prev(), null, value);
  }
  
  public void push_front(T value) {
    hook(null, next(), value);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\std\list.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */