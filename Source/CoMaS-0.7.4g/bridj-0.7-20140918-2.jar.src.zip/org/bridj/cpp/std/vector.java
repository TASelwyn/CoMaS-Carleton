/*     */ package org.bridj.cpp.std;
/*     */ 
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.NoSuchElementException;
/*     */ import org.bridj.BridJ;
/*     */ import org.bridj.Pointer;
/*     */ import org.bridj.StructObject;
/*     */ import org.bridj.ann.Field;
/*     */ import org.bridj.ann.Struct;
/*     */ import org.bridj.ann.Template;
/*     */ import org.bridj.cpp.CPPObject;
/*     */ import org.bridj.cpp.CPPRuntime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Template({Type.class})
/*     */ @Struct(customizer = STL.class)
/*     */ public class vector<T>
/*     */   extends CPPObject
/*     */ {
/*     */   @Deprecated
/*     */   @Field(0)
/*     */   public Pointer<T> _M_start() {
/*  63 */     return this.io.getPointerField((StructObject)this, 0);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   @Field(1)
/*     */   public Pointer<T> _M_finish() {
/*  69 */     return this.io.getPointerField((StructObject)this, 1);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   @Field(2)
/*     */   public Pointer<T> _M_end_of_storage() {
/*  75 */     return this.io.getPointerField((StructObject)this, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public vector(Type t) {
/*  80 */     super((Void)null, -2, new Object[] { t });
/*     */   }
/*     */   
/*     */   public vector(Pointer<? extends vector<T>> peer, Type t) {
/*  84 */     super(peer, new Object[] { t });
/*  85 */     if (!isValid()) {
/*  86 */       throw new RuntimeException("Invalid vector internal data ! Are you trying to use an unsupported version of the STL ?");
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean isValid() {
/*  91 */     long start = Pointer.getPeer(_M_start());
/*  92 */     long finish = Pointer.getPeer(_M_finish());
/*  93 */     long eos = Pointer.getPeer(_M_end_of_storage());
/*  94 */     if (start == 0L || finish == 0L || eos == 0L) {
/*  95 */       return false;
/*     */     }
/*  97 */     return (start <= finish && finish <= eos);
/*     */   }
/*     */   
/*     */   private void checkNotEmpty() {
/* 101 */     checkIndex(0L);
/*     */   }
/*     */   
/*     */   private void checkIndex(long i) {
/* 105 */     long size = size();
/* 106 */     if (i < 0L || i >= size) {
/* 107 */       throw new NoSuchElementException("index " + i + " (size = " + size + ")");
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean empty() {
/* 112 */     return (size() == 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public T get(long index) {
/* 117 */     checkIndex(index);
/* 118 */     Pointer<T> p = _M_start().as(T());
/* 119 */     return (T)p.get(index);
/*     */   }
/*     */   
/*     */   public T get(int index) {
/* 123 */     return get(index);
/*     */   }
/*     */   
/*     */   public T front() {
/* 127 */     return get(0);
/*     */   }
/*     */   
/*     */   public T back() {
/* 131 */     return get(size() - 1L);
/*     */   }
/*     */   
/*     */   public void push_back(T value) {
/* 135 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   protected Type T() {
/* 139 */     CPPRuntime.getInstance(); return (Type)CPPRuntime.getTemplateParameters(this, vector.class)[0];
/*     */   }
/*     */   
/*     */   protected long byteSize() {
/* 143 */     return _M_finish().getPeer() - _M_start().getPeer();
/*     */   }
/*     */   
/*     */   public long size() {
/* 147 */     long byteSize = byteSize();
/* 148 */     long elementSize = BridJ.sizeOf(T());
/*     */     
/* 150 */     return byteSize / elementSize;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\std\vector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */