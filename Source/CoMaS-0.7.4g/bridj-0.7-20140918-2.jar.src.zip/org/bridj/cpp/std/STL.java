/*    */ package org.bridj.cpp.std;
/*    */ 
/*    */ import org.bridj.Platform;
/*    */ import org.bridj.Pointer;
/*    */ import org.bridj.StructCustomizer;
/*    */ import org.bridj.StructDescription;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class STL
/*    */   extends StructCustomizer
/*    */ {
/*    */   public void afterBuild(StructDescription desc) {
/* 49 */     if (!Platform.isWindows()) {
/*    */       return;
/*    */     }
/*    */     
/* 53 */     Class<vector> c = desc.getStructClass();
/* 54 */     if (c == vector.class) {
/*    */       
/* 56 */       desc.prependBytes((3 * Pointer.SIZE));
/* 57 */     } else if (c == list.class || c == list.list_node.class) {
/* 58 */       desc.setFieldOffset("prev", (5 * Pointer.SIZE), false);
/* 59 */       if (c == list.list_node.class)
/* 60 */         desc.setFieldOffset("data", (6 * Pointer.SIZE), false); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\std\STL.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */