/*      */ package org.bridj.cpp;
/*      */ 
/*      */ import java.io.FileNotFoundException;
/*      */ import java.lang.reflect.AnnotatedElement;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.GenericDeclaration;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.lang.reflect.ParameterizedType;
/*      */ import java.lang.reflect.Type;
/*      */ import java.lang.reflect.TypeVariable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ import org.bridj.BridJ;
/*      */ import org.bridj.BridJRuntime;
/*      */ import org.bridj.CRuntime;
/*      */ import org.bridj.Callback;
/*      */ import org.bridj.DynamicFunction;
/*      */ import org.bridj.DynamicFunctionFactory;
/*      */ import org.bridj.MethodCallInfo;
/*      */ import org.bridj.NativeEntities;
/*      */ import org.bridj.NativeLibrary;
/*      */ import org.bridj.NativeObject;
/*      */ import org.bridj.NativeObjectInterface;
/*      */ import org.bridj.Platform;
/*      */ import org.bridj.Pointer;
/*      */ import org.bridj.PointerIO;
/*      */ import org.bridj.SizeT;
/*      */ import org.bridj.ann.Convention;
/*      */ import org.bridj.ann.Template;
/*      */ import org.bridj.ann.Virtual;
/*      */ import org.bridj.demangling.Demangler;
/*      */ import org.bridj.util.Pair;
/*      */ import org.bridj.util.Utils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CPPRuntime
/*      */   extends CRuntime
/*      */ {
/*      */   public static final int DEFAULT_CONSTRUCTOR = -1;
/*      */   public static final int SKIP_CONSTRUCTOR = -2;
/*      */   
/*      */   public static CPPRuntime getInstance() {
/*  102 */     return (CPPRuntime)BridJ.getRuntimeByRuntimeClass(CPPRuntime.class);
/*      */   }
/*      */ 
/*      */   
/*      */   public Type getType(NativeObject instance) {
/*  107 */     if (!(instance instanceof CPPObject)) {
/*  108 */       return super.getType(instance);
/*      */     }
/*      */     
/*  111 */     Class<?> cls = instance.getClass();
/*  112 */     return new CPPType(cls, getTemplateParameters((CPPObject)instance, cls));
/*      */   }
/*      */   
/*      */   public static Object[] getTemplateParameters(CPPObject object, Class<?> typeClass) {
/*  116 */     synchronized (object) {
/*  117 */       Object[] params = null;
/*  118 */       if (object.templateParameters != null) {
/*  119 */         params = object.templateParameters.get(typeClass);
/*      */       }
/*  121 */       return params;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static Type[] getTemplateTypeParameters(CPPObject object, Type type) {
/*  126 */     if (!(type instanceof ParameterizedType)) {
/*  127 */       return new Type[0];
/*      */     }
/*  129 */     Class<?> typeClass = Utils.getClass(type);
/*  130 */     ParameterizedType pt = (ParameterizedType)type;
/*  131 */     Object[] params = getTemplateParameters(object, typeClass);
/*  132 */     Template t = typeClass.<Template>getAnnotation(Template.class);
/*  133 */     if (t == null) {
/*  134 */       throw new RuntimeException("No " + Template.class.getName() + " annotation on class " + typeClass.getName());
/*      */     }
/*  136 */     if ((t.paramNames()).length != params.length) {
/*  137 */       throw new RuntimeException(Template.class.getName() + " annotation's paramNames on class " + typeClass.getName() + " (" + Arrays.asList(t.paramNames()) + " does not match count of actual template params " + Arrays.asList(params));
/*      */     }
/*  139 */     if ((t.paramNames()).length != (t.value()).length) {
/*  140 */       throw new RuntimeException(Template.class.getName() + " annotation's paramNames and value lengths on class " + typeClass.getName() + " don't match");
/*      */     }
/*  142 */     int typeParamCount = (pt.getActualTypeArguments()).length;
/*  143 */     Type[] ret = new Type[typeParamCount];
/*  144 */     int typeParamIndex = 0;
/*  145 */     for (int i = 0, n = params.length; i < typeParamCount; i++) {
/*  146 */       Object value = t.value()[i];
/*  147 */       if (Type.class.isInstance(value)) {
/*  148 */         ret[typeParamIndex++] = (Type)value;
/*      */       }
/*      */     } 
/*  151 */     assert typeParamIndex == typeParamCount;
/*  152 */     return ret;
/*      */   }
/*      */   
/*      */   public void setTemplateParameters(CPPObject object, Class<?> typeClass, Object[] params) {
/*  156 */     synchronized (object) {
/*  157 */       if (object.templateParameters == null) {
/*  158 */         object.templateParameters = Collections.singletonMap(typeClass, params);
/*      */       } else {
/*      */         
/*      */         try {
/*  162 */           object.templateParameters.put(typeClass, params);
/*  163 */         } catch (Throwable th) {
/*  164 */           object.templateParameters = (Map)new HashMap<Class<?>, Object>(object.templateParameters);
/*  165 */           object.templateParameters.put(typeClass, params);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static int getAnnotatedTemplateTypeVariableIndexInArguments(TypeVariable<?> var) {
/*  182 */     GenericDeclaration d = (GenericDeclaration)var.getGenericDeclaration();
/*  183 */     AnnotatedElement e = d;
/*      */     
/*  185 */     Template t = e.<Template>getAnnotation(Template.class);
/*  186 */     if (t == null) {
/*  187 */       throw new RuntimeException(e + " is not a C++ class template (misses the @" + Template.class.getName() + " annotation)");
/*      */     }
/*      */     
/*  190 */     int iTypeVar = Arrays.<TypeVariable<?>>asList(d.getTypeParameters()).indexOf(var);
/*  191 */     int nTypes = 0, iParam = -1;
/*  192 */     Class<?>[] values = t.value();
/*  193 */     for (int i = 0, n = values.length; i < n; i++) {
/*  194 */       Class<?> c = values[i];
/*  195 */       if (c == Class.class || c == Type.class) {
/*  196 */         nTypes++;
/*      */       }
/*      */       
/*  199 */       if (nTypes == iTypeVar) {
/*  200 */         iParam = i;
/*      */         break;
/*      */       } 
/*      */     } 
/*  204 */     if (iParam < 0) {
/*  205 */       throw new RuntimeException("Couldn't find the type variable " + var + " (offset " + iTypeVar + ") in the @" + Template.class.getName() + " annotation : " + Arrays.asList(values));
/*      */     }
/*      */     
/*  208 */     return iParam;
/*      */   }
/*      */   
/*      */   protected ClassTypeVariableExtractor createClassTypeVariableExtractor(TypeVariable<Class<?>> var) {
/*  212 */     final Class<?> typeClass = var.getGenericDeclaration();
/*  213 */     final int iTypeInParams = getAnnotatedTemplateTypeVariableIndexInArguments(var);
/*  214 */     return new ClassTypeVariableExtractor() {
/*      */         public Type extract(CPPObject instance) {
/*  216 */           typeClass.cast(instance);
/*  217 */           Object[] params = CPPRuntime.getTemplateParameters(instance, typeClass);
/*  218 */           if (params == null) {
/*  219 */             throw new RuntimeException("No type parameters found in this instance : " + instance);
/*      */           }
/*      */           
/*  222 */           return (Type)params[iTypeInParams];
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   protected MethodTypeVariableExtractor createMethodTypeVariableExtractor(TypeVariable<?> var) {
/*  228 */     GenericDeclaration d = (GenericDeclaration)var.getGenericDeclaration();
/*  229 */     if (d instanceof Class) {
/*  230 */       Class<?> clazz = (Class)d;
/*  231 */       final ClassTypeVariableExtractor ce = createClassTypeVariableExtractor((TypeVariable)var);
/*  232 */       return new MethodTypeVariableExtractor() {
/*      */           public Type extract(CPPObject instance, Object[] methodTemplateParameters) {
/*  234 */             return ce.extract(instance);
/*      */           }
/*      */         };
/*      */     } 
/*  238 */     Method method = (Method)d;
/*  239 */     final Class<?> typeClass = method.getDeclaringClass();
/*      */     
/*  241 */     final int iTypeInParams = getAnnotatedTemplateTypeVariableIndexInArguments(var);
/*  242 */     return new MethodTypeVariableExtractor() {
/*      */         public Type extract(CPPObject instance, Object[] methodTemplateParameters) {
/*  244 */           typeClass.cast(instance);
/*  245 */           return (Type)methodTemplateParameters[iTypeInParams];
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends NativeObject> Class<? extends T> getActualInstanceClass(Pointer<T> pInstance, Type officialType) {
/*  277 */     return Utils.getClass(officialType);
/*      */   }
/*  279 */   Map<Class<?>, Integer> virtualMethodsCounts = new HashMap<Class<?>, Integer>(); volatile MemoryOperators memoryOperators;
/*      */   
/*      */   public int getVirtualMethodsCount(Class<?> type) {
/*  282 */     Integer count = this.virtualMethodsCounts.get(type);
/*  283 */     if (count == null) {
/*  284 */       List<VirtMeth> mets = new ArrayList<VirtMeth>();
/*  285 */       listVirtualMethods(type, mets);
/*      */ 
/*      */       
/*  288 */       this.virtualMethodsCounts.put(type, count = Integer.valueOf(mets.size()));
/*      */     } 
/*  290 */     return count.intValue();
/*      */   }
/*      */   
/*      */   protected static class VirtMeth {
/*      */     Method implementation;
/*      */     Method definition;
/*      */   }
/*      */   
/*      */   protected void listVirtualMethods(Class<?> type, List<VirtMeth> out) {
/*  299 */     if (!CPPObject.class.isAssignableFrom(type)) {
/*      */       return;
/*      */     }
/*      */     
/*  303 */     Class<?> sup = type.getSuperclass();
/*  304 */     if (sup != CPPObject.class) {
/*  305 */       listVirtualMethods(sup, out);
/*      */     }
/*      */     
/*  308 */     int nParentMethods = out.size();
/*      */     
/*  310 */     Map<Integer, VirtMeth> newVirtuals = new TreeMap<Integer, VirtMeth>();
/*      */ 
/*      */     
/*  313 */     label28: for (Method method : type.getDeclaredMethods()) {
/*  314 */       String methodName = Demangler.getMethodName(method);
/*  315 */       Type[] methodParameterTypes = method.getGenericParameterTypes();
/*  316 */       for (int iParentMethod = 0; iParentMethod < nParentMethods; iParentMethod++) {
/*  317 */         VirtMeth pvm = out.get(iParentMethod);
/*  318 */         Method parentMethod = pvm.definition;
/*  319 */         if (parentMethod.getDeclaringClass() != type)
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*  324 */           if (Demangler.getMethodName(parentMethod).equals(methodName) && isOverridenSignature(parentMethod.getGenericParameterTypes(), methodParameterTypes, 0)) {
/*  325 */             VirtMeth vm = new VirtMeth();
/*  326 */             vm.definition = pvm.definition;
/*  327 */             vm.implementation = method;
/*  328 */             out.set(iParentMethod, vm);
/*      */             continue label28;
/*      */           } 
/*      */         }
/*      */       } 
/*  333 */       Virtual virtual = method.<Virtual>getAnnotation(Virtual.class);
/*  334 */       if (virtual != null) {
/*  335 */         VirtMeth vm = new VirtMeth();
/*  336 */         vm.definition = vm.implementation = method;
/*  337 */         newVirtuals.put(Integer.valueOf(virtual.value()), vm);
/*      */       } 
/*      */     } 
/*  340 */     out.addAll(newVirtuals.values());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void registerNativeMethod(Class<?> type, NativeLibrary typeLibrary, Method method, NativeLibrary methodLibrary, NativeEntities.Builder builder, CRuntime.MethodCallInfoBuilder methodCallInfoBuilder) throws FileNotFoundException {
/*  346 */     int modifiers = method.getModifiers();
/*  347 */     boolean isCPPClass = CPPObject.class.isAssignableFrom(method.getDeclaringClass());
/*      */ 
/*      */     
/*  350 */     if (!isCPPClass) {
/*  351 */       super.registerNativeMethod(type, typeLibrary, method, methodLibrary, builder, methodCallInfoBuilder);
/*      */       
/*      */       return;
/*      */     } 
/*  355 */     MethodCallInfo mci = methodCallInfoBuilder.apply(method);
/*      */     
/*  357 */     Virtual va = method.<Virtual>getAnnotation(Virtual.class);
/*  358 */     if (va == null) {
/*  359 */       Demangler.Symbol symbol = methodLibrary.getSymbol(method);
/*  360 */       mci.setForwardedPointer((symbol == null) ? 0L : symbol.getAddress());
/*  361 */       if (mci.getForwardedPointer() == 0L) {
/*  362 */         assert BridJ.error("Method " + method.toGenericString() + " is not virtual but its address could not be resolved in the library.");
/*      */         return;
/*      */       } 
/*  365 */       if (Modifier.isStatic(modifiers)) {
/*  366 */         builder.addFunction(mci);
/*  367 */         if (BridJ.debug) {
/*  368 */           BridJ.info("Registering " + method + " as function or static C++ method " + symbol.getName());
/*      */         }
/*      */       } else {
/*  371 */         builder.addFunction(mci);
/*  372 */         if (BridJ.debug)
/*  373 */           BridJ.info("Registering " + method + " as C++ method " + symbol.getName()); 
/*      */       } 
/*      */     } else {
/*      */       int absoluteVirtualIndex;
/*  377 */       if (Modifier.isStatic(modifiers)) {
/*  378 */         BridJ.warning("Method " + method.toGenericString() + " is native and maps to a function, but is not static.");
/*      */       }
/*      */       
/*  381 */       int theoreticalVirtualIndex = va.value();
/*  382 */       int theoreticalAbsoluteVirtualIndex = (theoreticalVirtualIndex < 0) ? -1 : getAbsoluteVirtualIndex(method, theoreticalVirtualIndex, type);
/*      */ 
/*      */ 
/*      */       
/*  386 */       Pointer<Pointer<?>> pVirtualTable = (isCPPClass && typeLibrary != null) ? Pointer.pointerToAddress(getVirtualTable(type, typeLibrary), Pointer.class) : null;
/*  387 */       if (pVirtualTable == null) {
/*  388 */         if (theoreticalAbsoluteVirtualIndex < 0) {
/*  389 */           BridJ.error("Method " + method.toGenericString() + " is virtual but the virtual table of class " + type.getName() + " was not found and the virtual method index is not provided in its @Virtual annotation.");
/*      */           return;
/*      */         } 
/*  392 */         absoluteVirtualIndex = theoreticalAbsoluteVirtualIndex;
/*      */       } else {
/*  394 */         int guessedAbsoluteVirtualIndex = getPositionInVirtualTable(pVirtualTable, method, typeLibrary);
/*  395 */         if (guessedAbsoluteVirtualIndex < 0) {
/*  396 */           if (theoreticalAbsoluteVirtualIndex < 0) {
/*  397 */             BridJ.error("Method " + method.toGenericString() + " is virtual but its position could not be found in the virtual table.");
/*      */             return;
/*      */           } 
/*  400 */           absoluteVirtualIndex = theoreticalAbsoluteVirtualIndex;
/*      */         } else {
/*      */           
/*  403 */           if (theoreticalAbsoluteVirtualIndex >= 0 && guessedAbsoluteVirtualIndex != theoreticalAbsoluteVirtualIndex) {
/*  404 */             BridJ.warning("Method " + method.toGenericString() + " has @Virtual annotation indicating virtual index " + theoreticalAbsoluteVirtualIndex + ", but analysis of the actual virtual table rather indicates it has index " + guessedAbsoluteVirtualIndex + " (using the guess)");
/*      */           }
/*  406 */           absoluteVirtualIndex = guessedAbsoluteVirtualIndex;
/*      */         } 
/*      */       } 
/*  409 */       mci.setVirtualIndex(absoluteVirtualIndex);
/*  410 */       if (BridJ.debug) {
/*  411 */         BridJ.info("Registering " + method.toGenericString() + " as virtual C++ method with absolute virtual table index = " + absoluteVirtualIndex);
/*      */       }
/*  413 */       builder.addVirtualMethod(mci);
/*      */     } 
/*      */   }
/*      */   
/*      */   int getAbsoluteVirtualIndex(Method method, int virtualIndex, Class<?> type) {
/*  418 */     Class<?> superclass = type.getSuperclass();
/*  419 */     int virtualOffset = getVirtualMethodsCount(superclass);
/*  420 */     boolean isNewVirtual = true;
/*  421 */     if (superclass != null) {
/*      */       
/*      */       try {
/*  424 */         superclass.getMethod(Demangler.getMethodName(method), method.getParameterTypes());
/*  425 */         isNewVirtual = false;
/*  426 */       } catch (NoSuchMethodException ex) {}
/*      */     }
/*      */     
/*  429 */     int absoluteVirtualIndex = isNewVirtual ? (virtualOffset + virtualIndex) : virtualIndex;
/*  430 */     return absoluteVirtualIndex;
/*      */   }
/*      */ 
/*      */   
/*      */   public static class MemoryOperators
/*      */   {
/*      */     protected DynamicFunction<Pointer<?>> newFct;
/*      */     protected DynamicFunction<Pointer<?>> newArrayFct;
/*      */     protected DynamicFunction<Void> deleteFct;
/*      */     protected DynamicFunction<Void> deleteArrayFct;
/*      */     
/*      */     protected MemoryOperators() {}
/*      */     
/*      */     public MemoryOperators(NativeLibrary library) {
/*  444 */       for (Demangler.Symbol sym : library.getSymbols()) {
/*      */         try {
/*  446 */           Demangler.MemberRef parsedRef = sym.getParsedRef();
/*  447 */           Demangler.IdentLike n = parsedRef.getMemberName();
/*      */           
/*  449 */           if (Demangler.SpecialName.New.equals(n)) {
/*  450 */             this.newFct = Pointer.pointerToAddress(sym.getAddress()).asDynamicFunction(null, Pointer.class, new Type[] { SizeT.class }); continue;
/*  451 */           }  if (Demangler.SpecialName.NewArray.equals(n)) {
/*  452 */             this.newFct = Pointer.pointerToAddress(sym.getAddress()).asDynamicFunction(null, Pointer.class, new Type[] { SizeT.class }); continue;
/*  453 */           }  if (Demangler.SpecialName.Delete.equals(n)) {
/*  454 */             this.newFct = Pointer.pointerToAddress(sym.getAddress()).asDynamicFunction(null, Void.class, new Type[] { Pointer.class }); continue;
/*  455 */           }  if (Demangler.SpecialName.DeleteArray.equals(n)) {
/*  456 */             this.newFct = Pointer.pointerToAddress(sym.getAddress()).asDynamicFunction(null, Void.class, new Type[] { Pointer.class });
/*      */           }
/*      */         }
/*  459 */         catch (Exception ex) {}
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public Pointer<?> cppNew(long size) {
/*  465 */       return (Pointer)this.newFct.apply(new Object[] { new SizeT(size) });
/*      */     }
/*      */     
/*      */     public Pointer<?> cppNewArray(long size) {
/*  469 */       return (Pointer)this.newArrayFct.apply(new Object[] { new SizeT(size) });
/*      */     }
/*      */     
/*      */     public void cppDelete(Pointer<?> ptr) {
/*  473 */       this.deleteFct.apply(new Object[] { ptr });
/*      */     }
/*      */     
/*      */     public void cppDeleteArray(Pointer<?> ptr) {
/*  477 */       this.deleteArrayFct.apply(new Object[] { ptr });
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized MemoryOperators getMemoryOperators() {
/*  483 */     if (this.memoryOperators == null) {
/*      */       try {
/*  485 */         NativeLibrary libStdCpp = BridJ.getNativeLibrary("stdc++");
/*  486 */         this.memoryOperators = new MemoryOperators(libStdCpp);
/*  487 */       } catch (Exception ex) {
/*  488 */         BridJ.error(null, ex);
/*      */       } 
/*      */     }
/*  491 */     return this.memoryOperators;
/*      */   }
/*      */   
/*      */   int getPositionInVirtualTable(Method method, NativeLibrary library) {
/*  495 */     Class<?> type = method.getDeclaringClass();
/*  496 */     Pointer<Pointer<?>> pVirtualTable = Pointer.pointerToAddress(getVirtualTable(type, library), Pointer.class);
/*  497 */     return getPositionInVirtualTable(pVirtualTable, method, library);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPositionInVirtualTable(Pointer<Pointer<?>> pVirtualTable, Method method, NativeLibrary library) {
/*  502 */     int methodsOffset = 0;
/*  503 */     String className = Demangler.getClassName(method.getDeclaringClass());
/*  504 */     for (int iVirtual = 0;; iVirtual++) {
/*  505 */       Pointer<?> pMethod = (Pointer)pVirtualTable.get((methodsOffset + iVirtual));
/*  506 */       String virtualMethodName = (pMethod == null) ? null : library.getSymbolName(pMethod.getPeer());
/*      */       
/*  508 */       if (virtualMethodName == null) {
/*  509 */         if (BridJ.debug) {
/*  510 */           BridJ.info("\tVtable(" + className + ")[" + iVirtual + "] = null");
/*      */         }
/*  512 */         return -1;
/*      */       } 
/*      */       try {
/*  515 */         Demangler.MemberRef mr = library.parseSymbol(virtualMethodName);
/*  516 */         if (BridJ.debug) {
/*  517 */           BridJ.info("\tVtable(" + className + ")[" + iVirtual + "] = " + virtualMethodName + " = " + mr);
/*      */         }
/*  519 */         if (mr != null && mr.matchesSignature(method))
/*  520 */           return iVirtual; 
/*  521 */         if (library.isMSVC() && !mr.matchesEnclosingType(method)) {
/*      */           break;
/*      */         }
/*  524 */       } catch (org.bridj.demangling.Demangler.DemanglingException ex) {
/*  525 */         BridJ.warning("Failed to demangle '" + virtualMethodName + "' during inspection of virtual table for '" + method.toGenericString() + "' : " + ex);
/*      */       } 
/*      */     } 
/*      */     
/*  529 */     return -1;
/*      */   }
/*      */   
/*      */   static int getDefaultDyncallCppConvention() {
/*  533 */     int convention = 0;
/*  534 */     if (!Platform.is64Bits() && Platform.isWindows()) {
/*  535 */       convention = 5;
/*      */     }
/*  537 */     return convention;
/*      */   }
/*      */   
/*      */   private String ptrToString(Pointer<?> ptr, NativeLibrary library) {
/*  541 */     return (ptr == null) ? "null" : (Long.toHexString(ptr.getPeer()) + " (" + library.getSymbolName(ptr.getPeer()) + ")");
/*      */   }
/*      */   
/*      */   @Convention(Convention.Style.ThisCall)
/*      */   public static abstract class CPPDestructor extends Callback {
/*      */     public abstract void destroy(long param1Long);
/*      */   }
/*      */   
/*  549 */   Set<Type> typesThatDontNeedASyntheticVirtualTable = new HashSet<Type>();
/*  550 */   Map<Type, VTable> syntheticVirtualTables = new HashMap<Type, VTable>();
/*      */   
/*      */   protected boolean installRegularVTablePtr(Type type, NativeLibrary library, Pointer<?> peer) {
/*  553 */     long vtablePtr = getVirtualTable(type, library);
/*  554 */     if (vtablePtr != 0L) {
/*  555 */       if (BridJ.debug) {
/*  556 */         BridJ.info("Installing regular vtable pointer " + Pointer.pointerToAddress(vtablePtr) + " to instance at " + peer + " (type = " + Utils.toString(type) + ")");
/*      */       }
/*  558 */       peer.setSizeT(vtablePtr);
/*  559 */       return true;
/*      */     } 
/*  561 */     return false;
/*      */   }
/*      */   
/*      */   protected boolean installSyntheticVTablePtr(Type type, NativeLibrary library, Pointer<?> peer) {
/*  565 */     synchronized (this.syntheticVirtualTables) {
/*  566 */       VTable vtable = this.syntheticVirtualTables.get(type);
/*  567 */       if (vtable == null && 
/*  568 */         !this.typesThatDontNeedASyntheticVirtualTable.contains(type)) {
/*  569 */         List<VirtMeth> methods = new ArrayList<VirtMeth>();
/*  570 */         listVirtualMethods(Utils.getClass(type), methods);
/*  571 */         boolean needsASyntheticVirtualTable = false;
/*  572 */         for (VirtMeth method : methods) {
/*  573 */           if (!Modifier.isNative(method.implementation.getModifiers())) {
/*  574 */             needsASyntheticVirtualTable = true;
/*      */             break;
/*      */           } 
/*      */         } 
/*  578 */         if (needsASyntheticVirtualTable) {
/*  579 */           Type parentType = Utils.getParent(type);
/*  580 */           Pointer<Pointer> parentVTablePtr = null;
/*  581 */           if (CPPObject.class.isAssignableFrom(Utils.getClass(parentType))) {
/*  582 */             parentVTablePtr = peer.getPointer(Pointer.class);
/*  583 */             if (BridJ.debug) {
/*  584 */               BridJ.info("Found parent virtual table pointer = " + ptrToString(parentVTablePtr, library));
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  593 */           this.syntheticVirtualTables.put(type, vtable = synthetizeVirtualTable(type, parentVTablePtr, methods, library));
/*      */         } else {
/*  595 */           this.typesThatDontNeedASyntheticVirtualTable.add(type);
/*      */         } 
/*      */       } 
/*      */       
/*  599 */       if (vtable != null) {
/*  600 */         if (BridJ.debug) {
/*  601 */           BridJ.info("Installing synthetic vtable pointer " + vtable.ptr + " to instance at " + peer + " (type = " + Utils.toString(type) + ", " + vtable.callbacks.size() + " callbacks)");
/*      */         }
/*  603 */         peer.setPointer(vtable.ptr);
/*  604 */         return (vtable.ptr != null);
/*      */       } 
/*  606 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   static class VTable
/*      */   {
/*      */     Pointer<Pointer<?>> ptr;
/*  614 */     Map<Method, Pointer<?>> callbacks = new HashMap<Method, Pointer<?>>();
/*      */   }
/*      */   
/*      */   protected VTable synthetizeVirtualTable(Type type, Pointer<Pointer> parentVTablePtr, List<VirtMeth> methods, NativeLibrary library) {
/*  618 */     int nMethods = methods.size();
/*      */     
/*  620 */     VTable vtable = new VTable();
/*  621 */     vtable.ptr = Pointer.allocatePointers(nMethods + 2).next(2L);
/*      */     
/*  623 */     Class<?> c = Utils.getClass(type);
/*  624 */     for (int iMethod = 0; iMethod < nMethods; iMethod++) {
/*  625 */       Object object; VirtMeth vm = methods.get(iMethod);
/*      */       
/*  627 */       if (Modifier.isNative(vm.implementation.getModifiers())) {
/*  628 */         object = (parentVTablePtr == null) ? null : (Pointer)parentVTablePtr.get(iMethod);
/*      */       } else {
/*      */         try {
/*  631 */           MethodCallInfo mci = new MethodCallInfo(vm.implementation, vm.definition);
/*  632 */           mci.setDeclaringClass(vm.implementation.getDeclaringClass());
/*  633 */           object = createCToJavaCallback(mci, c);
/*  634 */           vtable.callbacks.put(vm.implementation, (Pointer<?>)object);
/*  635 */         } catch (Throwable th) {
/*  636 */           BridJ.error("Failed to register overridden method " + vm.implementation + " for type " + type + " (original method = " + vm.definition + ")", th);
/*  637 */           object = null;
/*      */         } 
/*      */       } 
/*  640 */       vtable.ptr.set(iMethod, object);
/*      */     } 
/*  642 */     return vtable;
/*      */   }
/*      */   
/*      */   static int getTemplateParametersCount(Class<?> typeClass) {
/*  646 */     Template t = typeClass.<Template>getAnnotation(Template.class);
/*      */     
/*  648 */     int templateParametersCount = (t == null) ? 0 : (t.value()).length;
/*  649 */     return templateParametersCount;
/*      */   }
/*  651 */   Map<Pair<Type, Integer>, DynamicFunction> constructors = new HashMap<Pair<Type, Integer>, DynamicFunction>();
/*      */   
/*      */   DynamicFunction getConstructor(Class<?> typeClass, final Type type, NativeLibrary lib, int constructorId) {
/*  654 */     Pair<Type, Integer> key = new Pair(type, Integer.valueOf(constructorId));
/*  655 */     DynamicFunction constructor = this.constructors.get(key);
/*  656 */     if (constructor == null) {
/*      */       try {
/*      */         final Constructor<?> constr;
/*      */         try {
/*  660 */           constr = findConstructor(typeClass, constructorId, true);
/*      */           
/*  662 */           if (BridJ.debug) {
/*  663 */             BridJ.info("Found constructor for " + Utils.toString(type) + " : " + constr);
/*      */           }
/*  665 */         } catch (NoSuchMethodException ex) {
/*  666 */           if (BridJ.debug) {
/*  667 */             BridJ.info("No constructor for " + Utils.toString(type));
/*      */           }
/*  669 */           return null;
/*      */         } 
/*  671 */         Demangler.Symbol symbol = (lib == null) ? null : lib.getFirstMatchingSymbol(new NativeLibrary.SymbolAccepter() {
/*      */               public boolean accept(Demangler.Symbol symbol) {
/*  673 */                 return symbol.matchesConstructor((constr.getDeclaringClass() == Utils.getClass(type)) ? type : constr.getDeclaringClass(), constr);
/*      */               }
/*      */             });
/*  676 */         if (symbol == null) {
/*  677 */           if (BridJ.debug) {
/*  678 */             BridJ.info("No matching constructor for " + Utils.toString(type) + " (" + constr + ")");
/*      */           }
/*  680 */           return null;
/*      */         } 
/*      */         
/*  683 */         if (BridJ.debug) {
/*  684 */           BridJ.info("Registering constructor " + constr + " as " + symbol.getName());
/*      */         }
/*      */ 
/*      */         
/*  688 */         int templateParametersCount = getTemplateParametersCount(typeClass);
/*      */         
/*  690 */         Class<?>[] consParamTypes = constr.getParameterTypes();
/*  691 */         Class<?>[] consThisParamTypes = new Class[consParamTypes.length + 1 - templateParametersCount];
/*  692 */         consThisParamTypes[0] = Pointer.class;
/*  693 */         System.arraycopy(consParamTypes, templateParametersCount, consThisParamTypes, 1, consParamTypes.length - templateParametersCount);
/*      */         
/*  695 */         DynamicFunctionFactory constructorFactory = getDynamicFunctionFactory(lib, Convention.Style.ThisCall, void.class, (Type[])consThisParamTypes);
/*      */         
/*  697 */         constructor = constructorFactory.newInstance(Pointer.pointerToAddress(symbol.getAddress()));
/*  698 */         this.constructors.put(key, constructor);
/*  699 */       } catch (Throwable th) {
/*  700 */         th.printStackTrace();
/*  701 */         throw new RuntimeException("Unable to create constructor " + constructorId + " for " + type + " : " + th, th);
/*      */       } 
/*      */     }
/*  704 */     return constructor;
/*      */   }
/*  706 */   Map<Type, CPPDestructor> destructors = new HashMap<Type, CPPDestructor>();
/*      */   
/*      */   CPPDestructor getDestructor(final Class<?> typeClass, Type type, NativeLibrary lib) {
/*  709 */     CPPDestructor destructor = this.destructors.get(type);
/*  710 */     if (destructor == null) {
/*  711 */       Demangler.Symbol symbol = lib.getFirstMatchingSymbol(new NativeLibrary.SymbolAccepter() {
/*      */             public boolean accept(Demangler.Symbol symbol) {
/*  713 */               return symbol.matchesDestructor(typeClass);
/*      */             }
/*      */           });
/*  716 */       if (BridJ.debug && symbol != null) {
/*  717 */         BridJ.info("Registering destructor of " + Utils.toString(type) + " as " + symbol.getName());
/*      */       }
/*      */       
/*  720 */       if (symbol != null) {
/*  721 */         this.destructors.put(type, destructor = (CPPDestructor)Pointer.pointerToAddress(symbol.getAddress(), CPPDestructor.class).get());
/*      */       }
/*      */     } 
/*  724 */     return destructor;
/*      */   }
/*      */   
/*      */   Pointer.Releaser newCPPReleaser(Type type) {
/*      */     try {
/*  729 */       Class<?> typeClass = Utils.getClass(type);
/*  730 */       NativeLibrary lib = BridJ.getNativeLibrary(typeClass);
/*  731 */       return newCPPReleaser(type, typeClass, lib);
/*  732 */     } catch (Throwable th) {
/*  733 */       throw new RuntimeException("Failed to create a C++ destructor for type " + Utils.toString(type) + " : " + th, th);
/*      */     } 
/*      */   }
/*      */   
/*      */   Pointer.Releaser newCPPReleaser(final Type type, Class<?> typeClass, NativeLibrary lib) throws FileNotFoundException {
/*  738 */     Pointer.Releaser releaser = null;
/*      */ 
/*      */     
/*  741 */     if (lib != null && BridJ.enableDestructors) {
/*  742 */       final CPPDestructor destructor = getDestructor(typeClass, type, lib);
/*  743 */       if (destructor != null) {
/*  744 */         releaser = new Pointer.Releaser() {
/*      */             public void release(Pointer<?> p) {
/*  746 */               if (BridJ.debug) {
/*  747 */                 BridJ.info("Destructing instance of C++ type " + Utils.toString(type) + " (address = " + p + ", destructor = " + Pointer.getPointer((NativeObject)destructor) + ")");
/*      */               }
/*      */ 
/*      */               
/*  751 */               long peer = p.getPeer();
/*  752 */               destructor.destroy(peer);
/*  753 */               BridJ.setJavaObjectFromNativePeer(peer, null);
/*      */             }
/*      */           };
/*      */       }
/*      */     } 
/*  758 */     return releaser;
/*      */   }
/*      */   
/*      */   protected <T extends CPPObject> Pointer<T> newCPPInstance(T instance, Type type, int constructorId, Object... args) {
/*  762 */     Pointer<T> peer = null;
/*      */     try {
/*  764 */       Class<T> typeClass = Utils.getClass(type);
/*  765 */       NativeLibrary lib = BridJ.getNativeLibrary(typeClass);
/*      */       
/*  767 */       if (BridJ.debug) {
/*  768 */         BridJ.info("Creating C++ instance of type " + type + " with args " + Arrays.<Object>asList(args));
/*      */       }
/*  770 */       Pointer.Releaser releaser = newCPPReleaser(type, typeClass, lib);
/*      */       
/*  772 */       long size = sizeOf(type, null);
/*  773 */       peer = Pointer.allocateBytes(PointerIO.getInstance(type), size, releaser).as(type);
/*      */       
/*  775 */       DynamicFunction constructor = (constructorId == -2) ? null : getConstructor(typeClass, type, lib, constructorId);
/*      */       
/*  777 */       if (lib != null && CPPObject.class.isAssignableFrom(typeClass)) {
/*  778 */         installRegularVTablePtr(type, lib, peer);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  784 */       if (constructor != null) {
/*  785 */         Object[] consThisArgs = new Object[1 + args.length];
/*  786 */         consThisArgs[0] = peer;
/*  787 */         System.arraycopy(args, 0, consThisArgs, 1, args.length);
/*      */         
/*  789 */         constructor.apply(consThisArgs);
/*      */       } 
/*      */ 
/*      */       
/*  793 */       if (CPPObject.class.isAssignableFrom(typeClass) && 
/*  794 */         installSyntheticVTablePtr(type, lib, peer)) {
/*  795 */         BridJ.setJavaObjectFromNativePeer(peer.getPeer(), (NativeObject)instance);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  800 */       return peer;
/*  801 */     } catch (Exception ex) {
/*  802 */       ex.printStackTrace();
/*  803 */       if (peer != null) {
/*  804 */         peer.release();
/*      */       }
/*  806 */       throw new RuntimeException("Failed to allocate new instance of type " + type, ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  836 */   Map<Type, Long> vtables = new HashMap<Type, Long>();
/*      */   
/*      */   long getVirtualTable(Type type, NativeLibrary library) {
/*  839 */     Long vtable = this.vtables.get(type);
/*  840 */     if (vtable == null) {
/*  841 */       final Class<?> typeClass = Utils.getClass(type);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  853 */       Demangler.Symbol symbol = library.getFirstMatchingSymbol(new NativeLibrary.SymbolAccepter() {
/*      */             public boolean accept(Demangler.Symbol symbol) {
/*  855 */               return symbol.matchesVirtualTable(typeClass);
/*      */             }
/*      */           });
/*  858 */       if (symbol != null) {
/*  859 */         if (BridJ.debug) {
/*  860 */           BridJ.info("Registering vtable of " + Utils.toString(type) + " as " + symbol.getName());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  873 */       else if (getVirtualMethodsCount(typeClass) > 0 && warnAboutMissingVTables()) {
/*  874 */         BridJ.error("Failed to find a vtable for type " + Utils.toString(type));
/*      */       } 
/*      */       
/*  877 */       if (symbol != null) {
/*  878 */         long address = symbol.getAddress();
/*  879 */         vtable = Long.valueOf(library.isMSVC() ? address : (address + (2 * Pointer.SIZE)));
/*      */       } else {
/*  881 */         vtable = Long.valueOf(0L);
/*      */       } 
/*  883 */       this.vtables.put(type, vtable);
/*      */     } 
/*      */     
/*  886 */     return vtable.longValue();
/*      */   }
/*      */   
/*      */   protected boolean warnAboutMissingVTables() {
/*  890 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean shouldWarnIfNoFieldsInStruct() {
/*  895 */     return false;
/*      */   }
/*      */   
/*      */   public class CPPTypeInfo<T extends CPPObject> extends CRuntime.CTypeInfo<T> { protected final int typeParamCount;
/*      */     protected Object[] templateParameters;
/*      */     Map<TypeVariable<Class<?>>, CPPRuntime.ClassTypeVariableExtractor> classTypeVariableExtractors;
/*      */     Map<TypeVariable<?>, CPPRuntime.MethodTypeVariableExtractor> methodTypeVariableExtractors;
/*      */     
/*      */     public CPPTypeInfo(Type type) {
/*  904 */       super(CPPRuntime.this, type);
/*  905 */       Class<?> typeClass = Utils.getClass(type);
/*  906 */       this.typeParamCount = (typeClass.getTypeParameters()).length;
/*  907 */       if (this.typeParamCount > 0 && !(type instanceof ParameterizedType)) {
/*  908 */         throw new RuntimeException("Class " + typeClass.getName() + " takes type parameters");
/*      */       }
/*  910 */       this.templateParameters = getTemplateParameters(type);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected T newCastInstance() throws NoSuchMethodException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
/*  917 */       if (this.templateParameters.length == 0) {
/*  918 */         return (T)super.newCastInstance();
/*      */       }
/*      */       
/*  921 */       Class<?> cc = getCastClass();
/*  922 */       for (Constructor<CPPObject> c : cc.getConstructors()) {
/*  923 */         if (Utils.parametersComplyToSignature(this.templateParameters, c.getParameterTypes())) {
/*  924 */           c.setAccessible(true);
/*  925 */           return (T)c.newInstance(this.templateParameters);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  930 */       throw new RuntimeException("Failed to find template constructor in class " + cc.getName());
/*      */     }
/*      */     
/*      */     public Type resolveClassType(CPPObject instance, TypeVariable<?> var) {
/*  934 */       return getClassTypeVariableExtractor((TypeVariable)var).extract(instance);
/*      */     }
/*      */     
/*      */     public Type resolveMethodType(CPPObject instance, Object[] methodTemplateParameters, TypeVariable<?> var) {
/*  938 */       return getMethodTypeVariableExtractor(var).extract(instance, methodTemplateParameters);
/*      */     }
/*      */     
/*      */     protected synchronized CPPRuntime.ClassTypeVariableExtractor getClassTypeVariableExtractor(TypeVariable<Class<?>> var) {
/*  942 */       if (this.classTypeVariableExtractors == null) {
/*  943 */         this.classTypeVariableExtractors = new HashMap<TypeVariable<Class<?>>, CPPRuntime.ClassTypeVariableExtractor>();
/*      */       }
/*  945 */       CPPRuntime.ClassTypeVariableExtractor e = this.classTypeVariableExtractors.get(var);
/*  946 */       if (e == null) {
/*  947 */         this.classTypeVariableExtractors.put(var, e = CPPRuntime.this.createClassTypeVariableExtractor(var));
/*      */       }
/*  949 */       return e;
/*      */     }
/*      */     
/*      */     protected synchronized CPPRuntime.MethodTypeVariableExtractor getMethodTypeVariableExtractor(TypeVariable<?> var) {
/*  953 */       if (this.methodTypeVariableExtractors == null) {
/*  954 */         this.methodTypeVariableExtractors = new HashMap<TypeVariable<?>, CPPRuntime.MethodTypeVariableExtractor>();
/*      */       }
/*  956 */       CPPRuntime.MethodTypeVariableExtractor e = this.methodTypeVariableExtractors.get(var);
/*  957 */       if (e == null) {
/*  958 */         this.methodTypeVariableExtractors.put(var, e = CPPRuntime.this.createMethodTypeVariableExtractor(var));
/*      */       }
/*  960 */       return e;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public long sizeOf() {
/*  966 */       return super.sizeOf();
/*      */     }
/*      */ 
/*      */     
/*      */     public T createReturnInstance() {
/*      */       try {
/*  972 */         T instance = newCastInstance();
/*  973 */         initialize(instance, -2, this.templateParameters);
/*      */         
/*  975 */         return instance;
/*  976 */       } catch (Throwable th) {
/*  977 */         throw new RuntimeException("Failed to create a return instance for type " + Utils.toString(this.type) + " : " + th, th);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public T cast(Pointer peer) {
/*  983 */       if (BridJ.isCastingNativeObjectReturnTypeInCurrentThread()) {
/*  984 */         peer = peer.withReleaser(CPPRuntime.this.newCPPReleaser(this.type));
/*      */       }
/*  986 */       CPPObject cPPObject = (CPPObject)super.cast(peer);
/*  987 */       CPPRuntime.this.setTemplateParameters(cPPObject, this.typeClass, this.templateParameters);
/*  988 */       return (T)cPPObject;
/*      */     }
/*      */ 
/*      */     
/*      */     public void initialize(T instance, Pointer peer) {
/*  993 */       CPPRuntime.this.setTemplateParameters((CPPObject)instance, this.typeClass, this.templateParameters);
/*  994 */       super.initialize((NativeObject)instance, peer);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void initialize(T instance, int constructorId, Object... targsAndArgs) {
/* 1000 */       if (instance instanceof CPPObject) {
/* 1001 */         T t = instance;
/*      */         
/* 1003 */         int[] position = { 0 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1009 */         Type cppType = this.type;
/* 1010 */         CPPRuntime.this.setTemplateParameters((CPPObject)instance, this.typeClass, this.templateParameters);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1016 */         CPPRuntime.this.setNativeObjectPeer((NativeObjectInterface)instance, CPPRuntime.this.newCPPInstance(instance, cppType, constructorId, targsAndArgs));
/* 1017 */         super.initialize((NativeObject)instance, -1, new Object[0]);
/*      */       } else {
/* 1019 */         super.initialize((NativeObject)instance, constructorId, targsAndArgs);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public T clone(T instance) throws CloneNotSupportedException {
/* 1025 */       if (instance instanceof CPPObject);
/*      */ 
/*      */       
/* 1028 */       return (T)super.clone((NativeObject)instance);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void destroy(T instance) {}
/*      */ 
/*      */     
/*      */     private Object[] getTemplateParameters(Type type) {
/* 1037 */       if (!(type instanceof CPPType)) {
/* 1038 */         return new Object[0];
/*      */       }
/* 1040 */       return ((CPPType)type).getTemplateParameters();
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends NativeObject> BridJRuntime.TypeInfo<T> getTypeInfo(Type type) {
/* 1047 */     return (BridJRuntime.TypeInfo)new CPPTypeInfo<CPPObject>(type);
/*      */   }
/*      */ 
/*      */   
/*      */   public Type getType(Class<?> cls, Object[] targsAndArgs, int[] typeParamCount) {
/* 1052 */     Template tpl = cls.<Template>getAnnotation(Template.class);
/* 1053 */     int targsCount = (tpl != null) ? (tpl.value()).length : (cls.getTypeParameters()).length;
/* 1054 */     if (typeParamCount != null) {
/* 1055 */       assert typeParamCount.length == 1;
/* 1056 */       typeParamCount[0] = targsCount;
/*      */     } 
/* 1058 */     return new CPPType(cls, Utils.takeLeft(targsAndArgs, targsCount));
/*      */   }
/*      */   
/*      */   public <T extends CPPObject> CPPTypeInfo<T> getCPPTypeInfo(Type type) {
/* 1062 */     return (CPPTypeInfo<T>)getTypeInfo(type);
/*      */   }
/*      */   
/*      */   protected static interface MethodTypeVariableExtractor {
/*      */     Type extract(CPPObject param1CPPObject, Object[] param1ArrayOfObject);
/*      */   }
/*      */   
/*      */   protected static interface ClassTypeVariableExtractor {
/*      */     Type extract(CPPObject param1CPPObject);
/*      */   }
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\CPPRuntime.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */