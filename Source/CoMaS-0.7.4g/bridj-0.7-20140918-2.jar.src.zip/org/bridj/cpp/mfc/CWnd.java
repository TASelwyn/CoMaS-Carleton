package org.bridj.cpp.mfc;

import org.bridj.Pointer;
import org.bridj.ann.Virtual;

public class CWnd extends MFCObject {
  @Virtual
  public native int SendMessage(int paramInt1, int paramInt2, int paramInt3);
  
  @Virtual
  public native void SetWindowText(Pointer<CString> paramPointer);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\mfc\CWnd.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */