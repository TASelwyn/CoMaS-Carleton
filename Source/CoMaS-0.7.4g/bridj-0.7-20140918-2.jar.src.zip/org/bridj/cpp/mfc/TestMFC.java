/*    */ package org.bridj.cpp.mfc;
/*    */ 
/*    */ import org.bridj.Pointer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TestMFC
/*    */ {
/*    */   public static void main(String[] args) {
/* 46 */     CWnd wnd = new CWnd()
/*    */       {
/*    */         @OnMessage(OnMessage.Type.WM_KEYDOWN)
/*    */         public void OnKeyDown(int a, int b, int c) {}
/*    */ 
/*    */ 
/*    */         
/*    */         @OnCommand(57600)
/*    */         public void OnSomething() {}
/*    */ 
/*    */         
/*    */         @OnCommandEx({57603, 57607})
/*    */         public boolean OnSomethingEx(int id) {
/* 59 */           return true;
/*    */         }
/*    */ 
/*    */         
/*    */         @OnUpdateCommand(57600)
/*    */         public void OnUpdateSomething(Pointer<CCmdUI> pCmdUI) {
/* 65 */           if (pCmdUI == null) {
/*    */             return;
/*    */           }
/*    */           
/* 69 */           ((CCmdUI)pCmdUI.get()).Enable(true);
/*    */         }
/*    */         
/*    */         @OnRegisteredMessage("MYAPP_MYMESSAGE")
/*    */         public void OnMyMessage(int a, int b, int c) {}
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\mfc\TestMFC.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */