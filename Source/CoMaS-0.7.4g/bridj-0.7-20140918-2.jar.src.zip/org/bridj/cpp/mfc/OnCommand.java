package org.bridj.cpp.mfc;

public @interface OnCommand {
  int value();
}
