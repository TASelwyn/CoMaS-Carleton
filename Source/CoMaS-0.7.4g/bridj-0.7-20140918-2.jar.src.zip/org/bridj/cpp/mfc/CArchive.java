package org.bridj.cpp.mfc;

public class CArchive extends CObject {}
