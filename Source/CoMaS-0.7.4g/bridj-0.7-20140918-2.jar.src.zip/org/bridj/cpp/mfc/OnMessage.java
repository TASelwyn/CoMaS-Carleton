/*    */ package org.bridj.cpp.mfc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public @interface OnMessage
/*    */ {
/*    */   Type value();
/*    */   
/*    */   public enum Type
/*    */   {
/* 44 */     WM_KEYDOWN("OnKeyDown", AFXSignature.AfxSig_vwww),
/* 45 */     WM_LBUTTONDOWN("OnLButtonDown", AFXSignature.AfxSig_vwp);
/*    */     
/*    */     Type(String defaultName, AFXSignature afxSig) {
/* 48 */       this.afxSig = afxSig;
/* 49 */       this.defaultName = defaultName;
/*    */     }
/*    */     
/*    */     final String defaultName;
/*    */     final AFXSignature afxSig;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\mfc\OnMessage.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */