package org.bridj.cpp.mfc;

import org.bridj.Pointer;
import org.bridj.ann.Field;
import org.bridj.func.Fun0;

public class CRuntimeClass extends MFCObject {
  @Field(0)
  public native Pointer<Byte> m_lpszClassName();
  
  public native void m_lpszClassName(Pointer<Byte> paramPointer);
  
  @Field(1)
  public native int m_nObjectSize();
  
  public native void m_nObjectSize(int paramInt);
  
  @Field(2)
  public native int m_wSchema();
  
  public native void m_wSchema(int paramInt);
  
  @Field(3)
  public native Pointer<Fun0<Pointer<CObject>>> m_pfnCreateObject();
  
  public native void m_pfnCreateObject(Pointer<Fun0<Pointer<CObject>>> paramPointer);
  
  @Field(4)
  public native Pointer<CRuntimeClass> m_pBaseClass();
  
  public native void m_pBaseClass(Pointer<CRuntimeClass> paramPointer);
  
  public native Pointer<CObject> CreateObject();
  
  public native boolean IsDerivedFrom(Pointer<CRuntimeClass> paramPointer);
  
  public static native Pointer<CRuntimeClass> FromName(Pointer<Byte> paramPointer);
  
  public static native Pointer<CRuntimeClass> FromName$2(Pointer<Character> paramPointer);
  
  public static native Pointer<CObject> CreateObject(Pointer<Byte> paramPointer);
  
  public static native Pointer<CObject> CreateObject$2(Pointer<Character> paramPointer);
  
  public native void Store(Pointer<CArchive> paramPointer);
  
  public static native Pointer<CRuntimeClass> Load(Pointer<CArchive> paramPointer, Pointer<Integer> paramPointer1);
  
  @Field(5)
  public native Pointer<CRuntimeClass> m_pNextClass();
  
  public native void m_pNextClass(Pointer<CRuntimeClass> paramPointer);
  
  @Field(6)
  public native Pointer<?> m_pClassInit();
  
  public native void m_pClassInit(Pointer<?> paramPointer);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\mfc\CRuntimeClass.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */