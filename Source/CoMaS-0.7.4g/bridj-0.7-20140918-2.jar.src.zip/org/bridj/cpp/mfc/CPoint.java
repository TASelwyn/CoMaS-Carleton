package org.bridj.cpp.mfc;

import org.bridj.StructObject;
import org.bridj.ann.Field;

public class CPoint extends StructObject {
  @Field(0)
  public native int x();
  
  @Field(0)
  public native void x(int paramInt);
  
  @Field(0)
  public native int y();
  
  @Field(0)
  public native void y(int paramInt);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\mfc\CPoint.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */