package org.bridj.cpp.mfc;

import java.lang.reflect.Method;

public class MessageMapBuilder {
  void add(Method method, OnCommand onCommand) {
    throw new UnsupportedOperationException("Not yet implemented");
  }
  
  void add(Method method, OnCommandEx onCommandEx) {
    throw new UnsupportedOperationException("Not yet implemented");
  }
  
  void add(Method method, OnUpdateCommand onUpdateCommand) {
    throw new UnsupportedOperationException("Not yet implemented");
  }
  
  void add(Method method, OnRegisteredMessage onRegisteredMessage) {
    throw new UnsupportedOperationException("Not yet implemented");
  }
  
  void add(Method method, OnMessage onMessage) {
    throw new UnsupportedOperationException("Not yet implemented");
  }
  
  boolean isEmpty() {
    throw new UnsupportedOperationException("Not yet implemented");
  }
  
  void register(MFCRuntime rt, Class<?> type) {
    throw new UnsupportedOperationException("Not yet implemented");
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\mfc\MessageMapBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */