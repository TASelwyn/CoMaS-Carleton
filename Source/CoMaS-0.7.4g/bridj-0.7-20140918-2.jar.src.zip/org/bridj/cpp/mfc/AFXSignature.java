package org.bridj.cpp.mfc;

import org.bridj.Pointer;

public enum AFXSignature {
  AfxSig_vwww(void.class, new Class[] { int.class, int.class, int.class }),
  AfxSig_vwp(void.class, new Class[] { Pointer.class, CPoint.class });
  
  final Class<?> returnType;
  
  final Class<?>[] paramTypes;
  
  AFXSignature(Class<?> returnType, Class<?>... paramTypes) {
    this.returnType = returnType;
    this.paramTypes = paramTypes;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\mfc\AFXSignature.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */