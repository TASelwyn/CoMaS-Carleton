/*     */ package org.bridj.cpp.mfc;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.bridj.Callback;
/*     */ import org.bridj.NativeObject;
/*     */ import org.bridj.Pointer;
/*     */ import org.bridj.cpp.CPPRuntime;
/*     */ import org.bridj.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MFCRuntime
/*     */   extends CPPRuntime
/*     */ {
/*     */   Method mfcGetMessageMap;
/*     */   String mfcGetMessageMapMangling;
/*     */   Callback mfcGetMessageMapCallback;
/*  55 */   Set<Class<?>> hasMessageMap = new HashSet<Class<?>>();
/*     */ 
/*     */   
/*     */   public <T extends NativeObject> Class<? extends T> getActualInstanceClass(Pointer<T> pInstance, Type officialType) {
/*  59 */     Class<?> officialTypeClass = Utils.getClass(officialType);
/*     */     
/*  61 */     if (CObject.class.isAssignableFrom(officialTypeClass)) {
/*  62 */       Pointer<CRuntimeClass> pClass = (new CObject((Pointer)pInstance, this)).GetRuntimeClass();
/*  63 */       if (pClass != null) {
/*  64 */         CRuntimeClass rtc = (CRuntimeClass)pClass.get();
/*     */         try {
/*  66 */           Class<? extends T> type = (Class)getMFCClass(rtc.m_lpszClassName());
/*  67 */           if (officialTypeClass == null || officialTypeClass.isAssignableFrom(type)) {
/*  68 */             return type;
/*     */           }
/*  70 */         } catch (ClassNotFoundException ex) {}
/*     */         
/*  72 */         return (Class)officialTypeClass;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  77 */     return super.getActualInstanceClass(pInstance, officialType);
/*     */   }
/*     */   
/*     */   private Class<?> getMFCClass(Pointer<Byte> mLpszClassName) throws ClassNotFoundException {
/*  81 */     throw new ClassNotFoundException(mLpszClassName.getCString());
/*     */   }
/*     */ 
/*     */   
/*     */   public void getExtraFieldsOfNewClass(Class<?> type, Map<String, Type> out) {
/*  86 */     if (!this.hasMessageMap.contains(type)) {
/*     */       return;
/*     */     }
/*     */     
/*  90 */     out.put("messageMap", Pointer.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public void getOverriddenVirtualMethods(Map<String, Pointer<?>> out) {
/*  95 */     out.put("mfcGetMessageMap", Pointer.getPointer((NativeObject)this.mfcGetMessageMapCallback));
/*     */   }
/*     */ 
/*     */   
/*     */   public void register(Type type) {
/* 100 */     super.register(type);
/* 101 */     Class<?> typeClass = Utils.getClass(type);
/*     */     
/* 103 */     MessageMapBuilder map = new MessageMapBuilder();
/* 104 */     for (Method method : typeClass.getMethods()) {
/*     */       
/* 106 */       OnCommand onCommand = method.<OnCommand>getAnnotation(OnCommand.class);
/* 107 */       if (onCommand != null) {
/* 108 */         map.add(method, onCommand);
/*     */       }
/*     */       
/* 111 */       OnCommandEx onCommandEx = method.<OnCommandEx>getAnnotation(OnCommandEx.class);
/* 112 */       if (onCommandEx != null) {
/* 113 */         map.add(method, onCommandEx);
/*     */       }
/*     */       
/* 116 */       OnUpdateCommand onUpdateCommand = method.<OnUpdateCommand>getAnnotation(OnUpdateCommand.class);
/* 117 */       if (onUpdateCommand != null) {
/* 118 */         map.add(method, onUpdateCommand);
/*     */       }
/*     */       
/* 121 */       OnRegisteredMessage onRegisteredMessage = method.<OnRegisteredMessage>getAnnotation(OnRegisteredMessage.class);
/* 122 */       if (onRegisteredMessage != null) {
/* 123 */         map.add(method, onRegisteredMessage);
/*     */       }
/*     */       
/* 126 */       OnMessage onMessage = method.<OnMessage>getAnnotation(OnMessage.class);
/* 127 */       if (onMessage != null) {
/* 128 */         map.add(method, onMessage);
/*     */       }
/*     */     } 
/* 131 */     if (!map.isEmpty())
/* 132 */       map.register(this, typeClass); 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\mfc\MFCRuntime.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */