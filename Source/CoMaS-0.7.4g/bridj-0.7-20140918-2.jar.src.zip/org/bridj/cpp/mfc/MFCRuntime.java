package org.bridj.cpp.mfc;

import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.bridj.Callback;
import org.bridj.NativeObject;
import org.bridj.Pointer;
import org.bridj.cpp.CPPRuntime;
import org.bridj.util.Utils;

public class MFCRuntime extends CPPRuntime {
  Method mfcGetMessageMap;
  
  String mfcGetMessageMapMangling;
  
  Callback mfcGetMessageMapCallback;
  
  Set<Class<?>> hasMessageMap = new HashSet<Class<?>>();
  
  public <T extends NativeObject> Class<? extends T> getActualInstanceClass(Pointer<T> pInstance, Type officialType) {
    Class<?> officialTypeClass = Utils.getClass(officialType);
    if (CObject.class.isAssignableFrom(officialTypeClass)) {
      Pointer<CRuntimeClass> pClass = (new CObject((Pointer)pInstance, this)).GetRuntimeClass();
      if (pClass != null) {
        CRuntimeClass rtc = (CRuntimeClass)pClass.get();
        try {
          Class<? extends T> type = (Class)getMFCClass(rtc.m_lpszClassName());
          if (officialTypeClass == null || officialTypeClass.isAssignableFrom(type))
            return type; 
        } catch (ClassNotFoundException ex) {}
        return (Class)officialTypeClass;
      } 
    } 
    return super.getActualInstanceClass(pInstance, officialType);
  }
  
  private Class<?> getMFCClass(Pointer<Byte> mLpszClassName) throws ClassNotFoundException {
    throw new ClassNotFoundException(mLpszClassName.getCString());
  }
  
  public void getExtraFieldsOfNewClass(Class<?> type, Map<String, Type> out) {
    if (!this.hasMessageMap.contains(type))
      return; 
    out.put("messageMap", Pointer.class);
  }
  
  public void getOverriddenVirtualMethods(Map<String, Pointer<?>> out) {
    out.put("mfcGetMessageMap", Pointer.getPointer((NativeObject)this.mfcGetMessageMapCallback));
  }
  
  public void register(Type type) {
    super.register(type);
    Class<?> typeClass = Utils.getClass(type);
    MessageMapBuilder map = new MessageMapBuilder();
    for (Method method : typeClass.getMethods()) {
      OnCommand onCommand = method.<OnCommand>getAnnotation(OnCommand.class);
      if (onCommand != null)
        map.add(method, onCommand); 
      OnCommandEx onCommandEx = method.<OnCommandEx>getAnnotation(OnCommandEx.class);
      if (onCommandEx != null)
        map.add(method, onCommandEx); 
      OnUpdateCommand onUpdateCommand = method.<OnUpdateCommand>getAnnotation(OnUpdateCommand.class);
      if (onUpdateCommand != null)
        map.add(method, onUpdateCommand); 
      OnRegisteredMessage onRegisteredMessage = method.<OnRegisteredMessage>getAnnotation(OnRegisteredMessage.class);
      if (onRegisteredMessage != null)
        map.add(method, onRegisteredMessage); 
      OnMessage onMessage = method.<OnMessage>getAnnotation(OnMessage.class);
      if (onMessage != null)
        map.add(method, onMessage); 
    } 
    if (!map.isEmpty())
      map.register(this, typeClass); 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\mfc\MFCRuntime.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */