/*    */ package org.bridj.cpp;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.bridj.Pointer;
/*    */ import org.bridj.StructObject;
/*    */ import org.bridj.ann.Runtime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Runtime(CPPRuntime.class)
/*    */ public abstract class CPPObject
/*    */   extends StructObject
/*    */ {
/*    */   Map<Class<?>, Object[]> templateParameters;
/*    */   
/*    */   protected CPPObject() {}
/*    */   
/*    */   protected CPPObject(Pointer<? extends CPPObject> peer, Object... targs) {
/* 59 */     super(peer, targs);
/*    */   }
/*    */ 
/*    */   
/*    */   protected CPPObject(Void voidArg, int constructorId, Object... args) {
/* 64 */     super(voidArg, constructorId, args);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\CPPObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */