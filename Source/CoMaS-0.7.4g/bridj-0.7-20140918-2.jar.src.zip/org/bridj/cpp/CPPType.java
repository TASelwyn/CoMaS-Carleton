/*     */ package org.bridj.cpp;
/*     */ 
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.bridj.ann.Template;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CPPType
/*     */   implements ParameterizedType
/*     */ {
/*     */   private final Type[] actualTypeArguments;
/*     */   private final Type ownerType;
/*     */   private final Type rawType;
/*     */   private final Object[] templateParameters;
/*     */   
/*     */   public CPPType(Type ownerType, Type rawType, Object... templateParameters) {
/*  62 */     this.ownerType = ownerType;
/*  63 */     this.templateParameters = (templateParameters == null) ? new Object[0] : templateParameters;
/*  64 */     this.actualTypeArguments = getTypes(this.templateParameters);
/*  65 */     this.rawType = rawType;
/*     */   }
/*     */   
/*     */   public CPPType(Type rawType, Object... templateParameters) {
/*  69 */     this(null, rawType, templateParameters);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Type[] getTypes(Object[] objects) {
/*  74 */     int n = (objects == null) ? 0 : objects.length;
/*  75 */     List<Type> ret = new ArrayList<Type>(n);
/*  76 */     for (int i = 0; i < n; i++) {
/*  77 */       Object o = objects[i];
/*  78 */       if (o instanceof Type) {
/*  79 */         ret.add((Type)o);
/*     */       }
/*     */     } 
/*  82 */     return ret.<Type>toArray(new Type[ret.size()]);
/*     */   }
/*     */   
/*     */   static Object[] cons(Class firstClass, Object... flattenedClassesAndParams) {
/*  86 */     Object[] a = new Object[flattenedClassesAndParams.length + 1];
/*  87 */     a[0] = firstClass;
/*  88 */     System.arraycopy(flattenedClassesAndParams, 0, a, 1, flattenedClassesAndParams.length);
/*  89 */     return a;
/*     */   }
/*     */   
/*     */   public static Type getCPPType(Object... flattenedClassesAndParams) {
/*  93 */     int[] position = { 0 };
/*  94 */     Type t = parseCPPType(flattenedClassesAndParams, position);
/*  95 */     if (position[0] < flattenedClassesAndParams.length) {
/*  96 */       parseError("Unexpected trailing parameters", flattenedClassesAndParams, position);
/*     */     }
/*     */     
/*  99 */     return t;
/*     */   }
/*     */   
/*     */   static void parseError(String message, Object[] flattenedClassesAndParams, int[] position) {
/* 103 */     throw new IllegalArgumentException("Error while parsing C++ type in " + Arrays.asList(flattenedClassesAndParams) + " at offset " + position[0] + " : " + message);
/*     */   }
/*     */   
/*     */   static void notEOF(String message, Object[] flattenedClassesAndParams, int[] position) {
/* 107 */     if (position[0] >= flattenedClassesAndParams.length) {
/* 108 */       throw new IllegalArgumentException("EOF while parsing C++ type in " + Arrays.asList(flattenedClassesAndParams) + " at offset " + position[0] + " : " + message);
/*     */     }
/*     */   }
/*     */   
/*     */   static Type parseCPPType(Object[] flattenedClassesAndParams, int[] position) {
/* 113 */     notEOF("expecting class", flattenedClassesAndParams, position);
/* 114 */     Object oc = flattenedClassesAndParams[position[0]];
/* 115 */     if (!(oc instanceof Class)) {
/* 116 */       parseError("expected class", flattenedClassesAndParams, position);
/*     */     }
/* 118 */     Class<?> c = (Class)oc;
/* 119 */     position[0] = position[0] + 1;
/* 120 */     Template t = c.<Template>getAnnotation(Template.class);
/*     */     
/* 122 */     Class<?>[] paramTypes = (t == null) ? null : t.value();
/* 123 */     int nParams = (paramTypes == null) ? 0 : paramTypes.length;
/* 124 */     Object[] params = new Object[nParams];
/* 125 */     for (int iParam = 0; iParam < nParams; iParam++) {
/* 126 */       notEOF("expecting param " + iParam + " for template " + c.getName(), flattenedClassesAndParams, position);
/* 127 */       Object param = flattenedClassesAndParams[position[0]];
/* 128 */       Type<?> paramType = paramTypes[iParam];
/* 129 */       if (paramType.equals(Class.class) && param.getClass().equals(Class.class)) {
/* 130 */         param = parseCPPType(flattenedClassesAndParams, position);
/*     */       } else {
/* 132 */         if (!((Class)paramType).isInstance(param)) {
/* 133 */           parseError("bad type for template param " + iParam + " : expected a " + paramType + ", got " + param, flattenedClassesAndParams, position);
/*     */         }
/* 135 */         position[0] = position[0] + 1;
/*     */       } 
/* 137 */       params[iParam] = param;
/*     */     } 
/* 139 */     return (nParams == 0) ? c : new CPPType(c, params);
/*     */   }
/*     */ 
/*     */   
/*     */   public Type[] getActualTypeArguments() {
/* 144 */     return (Type[])this.actualTypeArguments.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getOwnerType() {
/* 149 */     return this.ownerType;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getRawType() {
/* 154 */     return this.rawType;
/*     */   }
/*     */   
/*     */   public Object[] getTemplateParameters() {
/* 158 */     return (Object[])this.templateParameters.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 163 */     int h = getRawType().hashCode();
/* 164 */     if (getOwnerType() != null) {
/* 165 */       h ^= getOwnerType().hashCode();
/*     */     }
/* 167 */     for (int i = 0, n = this.templateParameters.length; i < n; i++) {
/* 168 */       h ^= this.templateParameters[i].hashCode();
/*     */     }
/* 170 */     return h;
/*     */   }
/*     */   
/*     */   static boolean eq(Object a, Object b) {
/* 174 */     if (((a == null) ? true : false) != ((b == null) ? true : false)) {
/* 175 */       return false;
/*     */     }
/* 177 */     if (a != null && !a.equals(b)) {
/* 178 */       return false;
/*     */     }
/* 180 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 185 */     if (o == null || !(o instanceof CPPType)) {
/* 186 */       return false;
/*     */     }
/*     */     
/* 189 */     CPPType t = (CPPType)o;
/* 190 */     if (!eq(getRawType(), t.getRawType())) {
/* 191 */       return false;
/*     */     }
/* 193 */     if (!eq(getOwnerType(), t.getOwnerType())) {
/* 194 */       return false;
/*     */     }
/*     */     
/* 197 */     Object[] tp = t.templateParameters;
/* 198 */     if (this.templateParameters.length != tp.length) {
/* 199 */       return false;
/*     */     }
/*     */     
/* 202 */     for (int i = 0, n = this.templateParameters.length; i < n; i++) {
/* 203 */       if (!eq(this.templateParameters[i], tp[i])) {
/* 204 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 208 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 213 */     StringBuilder b = new StringBuilder();
/* 214 */     if (getOwnerType() != null) {
/* 215 */       b.append(getOwnerType()).append('.');
/*     */     }
/*     */     
/* 218 */     b.append(getRawType());
/* 219 */     int n = this.templateParameters.length;
/* 220 */     if (n != 0) {
/* 221 */       b.append('<');
/* 222 */       for (int i = 0; i < n; i++) {
/* 223 */         if (i > 0) {
/* 224 */           b.append(", ");
/*     */         }
/* 226 */         b.append(this.templateParameters[i]);
/*     */       } 
/* 228 */       b.append('>');
/*     */     } 
/* 230 */     return b.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\CPPType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */