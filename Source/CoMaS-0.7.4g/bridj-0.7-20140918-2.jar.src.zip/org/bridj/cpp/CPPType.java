package org.bridj.cpp;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.bridj.ann.Template;

public class CPPType implements ParameterizedType {
  private final Type[] actualTypeArguments;
  
  private final Type ownerType;
  
  private final Type rawType;
  
  private final Object[] templateParameters;
  
  public CPPType(Type ownerType, Type rawType, Object... templateParameters) {
    this.ownerType = ownerType;
    this.templateParameters = (templateParameters == null) ? new Object[0] : templateParameters;
    this.actualTypeArguments = getTypes(this.templateParameters);
    this.rawType = rawType;
  }
  
  public CPPType(Type rawType, Object... templateParameters) {
    this(null, rawType, templateParameters);
  }
  
  private static Type[] getTypes(Object[] objects) {
    int n = (objects == null) ? 0 : objects.length;
    List<Type> ret = new ArrayList<Type>(n);
    for (int i = 0; i < n; i++) {
      Object o = objects[i];
      if (o instanceof Type)
        ret.add((Type)o); 
    } 
    return ret.<Type>toArray(new Type[ret.size()]);
  }
  
  static Object[] cons(Class firstClass, Object... flattenedClassesAndParams) {
    Object[] a = new Object[flattenedClassesAndParams.length + 1];
    a[0] = firstClass;
    System.arraycopy(flattenedClassesAndParams, 0, a, 1, flattenedClassesAndParams.length);
    return a;
  }
  
  public static Type getCPPType(Object... flattenedClassesAndParams) {
    int[] position = { 0 };
    Type t = parseCPPType(flattenedClassesAndParams, position);
    if (position[0] < flattenedClassesAndParams.length)
      parseError("Unexpected trailing parameters", flattenedClassesAndParams, position); 
    return t;
  }
  
  static void parseError(String message, Object[] flattenedClassesAndParams, int[] position) {
    throw new IllegalArgumentException("Error while parsing C++ type in " + Arrays.asList(flattenedClassesAndParams) + " at offset " + position[0] + " : " + message);
  }
  
  static void notEOF(String message, Object[] flattenedClassesAndParams, int[] position) {
    if (position[0] >= flattenedClassesAndParams.length)
      throw new IllegalArgumentException("EOF while parsing C++ type in " + Arrays.asList(flattenedClassesAndParams) + " at offset " + position[0] + " : " + message); 
  }
  
  static Type parseCPPType(Object[] flattenedClassesAndParams, int[] position) {
    notEOF("expecting class", flattenedClassesAndParams, position);
    Object oc = flattenedClassesAndParams[position[0]];
    if (!(oc instanceof Class))
      parseError("expected class", flattenedClassesAndParams, position); 
    Class<?> c = (Class)oc;
    position[0] = position[0] + 1;
    Template t = c.<Template>getAnnotation(Template.class);
    Class<?>[] paramTypes = (t == null) ? null : t.value();
    int nParams = (paramTypes == null) ? 0 : paramTypes.length;
    Object[] params = new Object[nParams];
    for (int iParam = 0; iParam < nParams; iParam++) {
      notEOF("expecting param " + iParam + " for template " + c.getName(), flattenedClassesAndParams, position);
      Object param = flattenedClassesAndParams[position[0]];
      Type<?> paramType = paramTypes[iParam];
      if (paramType.equals(Class.class) && param.getClass().equals(Class.class)) {
        param = parseCPPType(flattenedClassesAndParams, position);
      } else {
        if (!((Class)paramType).isInstance(param))
          parseError("bad type for template param " + iParam + " : expected a " + paramType + ", got " + param, flattenedClassesAndParams, position); 
        position[0] = position[0] + 1;
      } 
      params[iParam] = param;
    } 
    return (nParams == 0) ? c : new CPPType(c, params);
  }
  
  public Type[] getActualTypeArguments() {
    return (Type[])this.actualTypeArguments.clone();
  }
  
  public Type getOwnerType() {
    return this.ownerType;
  }
  
  public Type getRawType() {
    return this.rawType;
  }
  
  public Object[] getTemplateParameters() {
    return (Object[])this.templateParameters.clone();
  }
  
  public int hashCode() {
    int h = getRawType().hashCode();
    if (getOwnerType() != null)
      h ^= getOwnerType().hashCode(); 
    for (int i = 0, n = this.templateParameters.length; i < n; i++)
      h ^= this.templateParameters[i].hashCode(); 
    return h;
  }
  
  static boolean eq(Object a, Object b) {
    if (((a == null) ? true : false) != ((b == null) ? true : false))
      return false; 
    if (a != null && !a.equals(b))
      return false; 
    return true;
  }
  
  public boolean equals(Object o) {
    if (o == null || !(o instanceof CPPType))
      return false; 
    CPPType t = (CPPType)o;
    if (!eq(getRawType(), t.getRawType()))
      return false; 
    if (!eq(getOwnerType(), t.getOwnerType()))
      return false; 
    Object[] tp = t.templateParameters;
    if (this.templateParameters.length != tp.length)
      return false; 
    for (int i = 0, n = this.templateParameters.length; i < n; i++) {
      if (!eq(this.templateParameters[i], tp[i]))
        return false; 
    } 
    return true;
  }
  
  public String toString() {
    StringBuilder b = new StringBuilder();
    if (getOwnerType() != null)
      b.append(getOwnerType()).append('.'); 
    b.append(getRawType());
    int n = this.templateParameters.length;
    if (n != 0) {
      b.append('<');
      for (int i = 0; i < n; i++) {
        if (i > 0)
          b.append(", "); 
        b.append(this.templateParameters[i]);
      } 
      b.append('>');
    } 
    return b.toString();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\CPPType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */