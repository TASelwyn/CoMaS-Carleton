package org.bridj.cpp.com;

@IID("00020401-0000-0000-C000-000000000046")
public class ITypeInfo extends IUnknown {}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\com\ITypeInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */