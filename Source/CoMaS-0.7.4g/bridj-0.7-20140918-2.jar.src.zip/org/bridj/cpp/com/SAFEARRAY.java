/*     */ package org.bridj.cpp.com;
/*     */ 
/*     */ import org.bridj.CRuntime;
/*     */ import org.bridj.Pointer;
/*     */ import org.bridj.StructObject;
/*     */ import org.bridj.ann.Array;
/*     */ import org.bridj.ann.Field;
/*     */ import org.bridj.ann.Runtime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Runtime(CRuntime.class)
/*     */ public class SAFEARRAY
/*     */   extends StructObject
/*     */ {
/*     */   @Field(0)
/*     */   public short cDims() {
/*  57 */     return this.io.getShortField(this, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   @Field(0)
/*     */   public SAFEARRAY cDims(short cDims) {
/*  63 */     this.io.setShortField(this, 0, cDims);
/*  64 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final short cDims_$eq(short cDims) {
/*  69 */     cDims(cDims);
/*  70 */     return cDims;
/*     */   }
/*     */ 
/*     */   
/*     */   @Field(1)
/*     */   public short fFeatures() {
/*  76 */     return this.io.getShortField(this, 1);
/*     */   }
/*     */ 
/*     */   
/*     */   @Field(1)
/*     */   public SAFEARRAY fFeatures(short fFeatures) {
/*  82 */     this.io.setShortField(this, 1, fFeatures);
/*  83 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final short fFeatures_$eq(short fFeatures) {
/*  88 */     fFeatures(fFeatures);
/*  89 */     return fFeatures;
/*     */   }
/*     */ 
/*     */   
/*     */   @Field(2)
/*     */   public int cbElements() {
/*  95 */     return this.io.getIntField(this, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   @Field(2)
/*     */   public SAFEARRAY cbElements(int cbElements) {
/* 101 */     this.io.setIntField(this, 2, cbElements);
/* 102 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int cbElements_$eq(int cbElements) {
/* 107 */     cbElements(cbElements);
/* 108 */     return cbElements;
/*     */   }
/*     */ 
/*     */   
/*     */   @Field(3)
/*     */   public int cLocks() {
/* 114 */     return this.io.getIntField(this, 3);
/*     */   }
/*     */ 
/*     */   
/*     */   @Field(3)
/*     */   public SAFEARRAY cLocks(int cLocks) {
/* 120 */     this.io.setIntField(this, 3, cLocks);
/* 121 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int cLocks_$eq(int cLocks) {
/* 126 */     cLocks(cLocks);
/* 127 */     return cLocks;
/*     */   }
/*     */ 
/*     */   
/*     */   @Field(4)
/*     */   public Pointer<?> pvData() {
/* 133 */     return this.io.getPointerField(this, 4);
/*     */   }
/*     */ 
/*     */   
/*     */   @Field(4)
/*     */   public SAFEARRAY pvData(Pointer<?> pvData) {
/* 139 */     this.io.setPointerField(this, 4, pvData);
/* 140 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Pointer<?> pvData_$eq(Pointer<?> pvData) {
/* 145 */     pvData(pvData);
/* 146 */     return pvData;
/*     */   }
/*     */ 
/*     */   
/*     */   @Array({1L})
/*     */   @Field(5)
/*     */   public Pointer<SAFEARRAYBOUND> rgsabound() {
/* 153 */     return this.io.getPointerField(this, 5);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\com\SAFEARRAY.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */