/*     */ package org.bridj.cpp.com;
/*     */ 
/*     */ import org.bridj.CRuntime;
/*     */ import org.bridj.StructObject;
/*     */ import org.bridj.ann.CLong;
/*     */ import org.bridj.ann.Field;
/*     */ import org.bridj.ann.Runtime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Runtime(CRuntime.class)
/*     */ public class RECT
/*     */   extends StructObject
/*     */ {
/*     */   @CLong
/*     */   @Field(0)
/*     */   public long left() {
/*  57 */     return this.io.getCLongField(this, 0);
/*     */   }
/*     */   
/*     */   @CLong
/*     */   @Field(0)
/*     */   public RECT left(long left) {
/*  63 */     this.io.setCLongField(this, 0, left);
/*  64 */     return this;
/*     */   }
/*     */   
/*     */   public final long left_$eq(long left) {
/*  68 */     left(left);
/*  69 */     return left;
/*     */   }
/*     */   
/*     */   @CLong
/*     */   @Field(1)
/*     */   public long top() {
/*  75 */     return this.io.getCLongField(this, 1);
/*     */   }
/*     */   
/*     */   @CLong
/*     */   @Field(1)
/*     */   public RECT top(long top) {
/*  81 */     this.io.setCLongField(this, 1, top);
/*  82 */     return this;
/*     */   }
/*     */   
/*     */   public final long top_$eq(long top) {
/*  86 */     top(top);
/*  87 */     return top;
/*     */   }
/*     */   
/*     */   @CLong
/*     */   @Field(2)
/*     */   public long right() {
/*  93 */     return this.io.getCLongField(this, 2);
/*     */   }
/*     */   
/*     */   @CLong
/*     */   @Field(2)
/*     */   public RECT right(long right) {
/*  99 */     this.io.setCLongField(this, 2, right);
/* 100 */     return this;
/*     */   }
/*     */   
/*     */   public final long right_$eq(long right) {
/* 104 */     right(right);
/* 105 */     return right;
/*     */   }
/*     */   
/*     */   @CLong
/*     */   @Field(3)
/*     */   public long bottom() {
/* 111 */     return this.io.getCLongField(this, 3);
/*     */   }
/*     */   
/*     */   @CLong
/*     */   @Field(3)
/*     */   public RECT bottom(long bottom) {
/* 117 */     this.io.setCLongField(this, 3, bottom);
/* 118 */     return this;
/*     */   }
/*     */   
/*     */   public final long bottom_$eq(long bottom) {
/* 122 */     bottom(bottom);
/* 123 */     return bottom;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\com\RECT.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */