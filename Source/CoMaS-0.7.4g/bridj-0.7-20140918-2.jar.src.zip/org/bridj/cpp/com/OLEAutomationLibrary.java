/*      */ package org.bridj.cpp.com;@Library("oleaut32")
/*      */ @Runtime(CPPRuntime.class)
/*      */ public class OLEAutomationLibrary { public static final int NUMPRS_TRAILING_WHITE = 2; public static final int VAR_TIMEVALUEONLY = 1; public static final int VARIANT_USE_NLS = 128; public static final int VTDATEGRE_MIN = -657434; public static final int ACTIVEOBJECT_WEAK = 1; public static final int NUMPRS_EXPONENT = 2048; public static final int NUMPRS_USE_ALL = 4096; public static final int NUMPRS_THOUSANDS = 512; public static final int STDOLE_MINORVERNUM = 0; public static final int VARIANT_LOCALBOOL = 16; public static final int VARIANT_NOVALUEPROP = 1; public static final int NUMPRS_PARENS = 128; public static final int VARCMP_GT = 2; public static final int VARCMP_LT = 0; public static final int NUMPRS_STD = 8191; public static final int VAR_CALENDAR_GREGORIAN = 256; public static final int NUMPRS_LEADING_PLUS = 4; public static final int LOAD_TLB_AS_64BIT = 64; public static final int LOCALE_USE_NLS = 268435456; public static final int VTDATEGRE_MAX = 2958465; public static final int NUMPRS_DECIMAL = 256; public static final int STDOLE_MAJORVERNUM = 1; public static final int NUMPRS_INEXACT = 131072; public static final int VARIANT_CALENDAR_THAI = 32; public static final int VARCMP_EQ = 1; public static final int ACTIVEOBJECT_STRONG = 0; public static final int NUMPRS_TRAILING_PLUS = 8; public static final int STDOLE2_MINORVERNUM = 0; public static final int VARIANT_NOUSEROVERRIDE = 4; public static final int NUMPRS_CURRENCY = 1024; public static final int VAR_CALENDAR_THAI = 128; public static final int STDOLE2_LCID = 0; public static final int VAR_FOURDIGITYEARS = 64; public static final int DISPATCH_PROPERTYPUT = 4; public static final int VARIANT_CALENDAR_GREGORIAN = 64; public static final int NUMPRS_HEX_OCT = 64; public static final int NUMPRS_LEADING_WHITE = 1; public static final int DISPATCH_PROPERTYPUTREF = 8; public static final int ID_DEFAULTINST = -2; public static final int VAR_LOCALBOOL = 16; public static final int STDOLE_LCID = 0; public static final int NUMPRS_TRAILING_MINUS = 32; public static final int NUMPRS_LEADING_MINUS = 16; public static final int VARIANT_ALPHABOOL = 2; public static final int VAR_VALIDDATE = 4; public static final int VARIANT_CALENDAR_HIJRI = 8; public static final int VAR_DATEVALUEONLY = 2; public static final int STDOLE2_MAJORVERNUM = 2; public static final int LOAD_TLB_AS_32BIT = 32; public static final int NUMPRS_NEG = 65536; public static final int VAR_CALENDAR_HIJRI = 8; public static final int DISPATCH_METHOD = 1; public static final int VARCMP_NULL = 3; public static final int DISPATCH_PROPERTYGET = 2; public static final int VAR_FORMAT_NOSUBSTITUTE = 32; public static final int MASK_TO_RESET_TLB_BITS = -97; public static native int OaBuildVersion(); public static native Pointer<Byte> SysAllocString(Pointer<Character> paramPointer); public static native Pointer<Byte> SysAllocStringByteLen(int paramInt); public static native Pointer<Byte> SysAllocStringLen(Pointer<Character> paramPointer, int paramInt); public static native void SysFreeString(Pointer<Byte> paramPointer); public static native int SysReAllocString(Pointer<Pointer<Byte>> paramPointer, Pointer<Character> paramPointer1); public static native int SysReAllocStringLen(Pointer<Pointer<Byte>> paramPointer, Pointer<Character> paramPointer1, int paramInt); public static native int SysStringByteLen(Pointer<Byte> paramPointer); public static native int SysStringLen(Pointer<Byte> paramPointer); public static native int SetErrorInfo(int paramInt, Pointer<IErrorInfo> paramPointer); public static native int GetErrorInfo(int paramInt, Pointer<Pointer<IErrorInfo>> paramPointer); public static native int CreateErrorInfo(Pointer<Pointer<ICreateErrorInfo>> paramPointer); public static native Pointer<SAFEARRAY> SafeArrayCreate(short paramShort, int paramInt, Pointer<SAFEARRAYBOUND> paramPointer); public static native Pointer<SAFEARRAY> SafeArrayCreateEx(short paramShort, int paramInt, Pointer<SAFEARRAYBOUND> paramPointer); public static native Pointer<SAFEARRAY> SafeArrayCreateVector(short paramShort, @CLong long paramLong, int paramInt); public static native Pointer<SAFEARRAY> SafeArrayCreateVectorEx(short paramShort, @CLong long paramLong, int paramInt); public static native int SafeArrayAllocDescriptor(int paramInt, Pointer<Pointer<SAFEARRAY>> paramPointer); public static native int SafeArrayAllocDescriptorEx(short paramShort, int paramInt, Pointer<Pointer<SAFEARRAY>> paramPointer); public static native int SafeArrayAllocData(Pointer<SAFEARRAY> paramPointer); public static native int SafeArrayDestroyDescriptor(Pointer<SAFEARRAY> paramPointer); public static native int SafeArrayPutElement(Pointer<SAFEARRAY> paramPointer, Pointer<CLong> paramPointer1, Pointer<?> paramPointer2); public static native int SafeArrayGetElement(Pointer<SAFEARRAY> paramPointer, Pointer<CLong> paramPointer1, Pointer<?> paramPointer2); public static native int SafeArrayLock(Pointer<SAFEARRAY> paramPointer); public static native int SafeArrayUnlock(Pointer<SAFEARRAY> paramPointer); public static native int SafeArrayGetUBound(Pointer<SAFEARRAY> paramPointer, int paramInt, Pointer<CLong> paramPointer1); public static native int SafeArrayGetLBound(Pointer<SAFEARRAY> paramPointer, int paramInt, Pointer<CLong> paramPointer1); public static native int SafeArrayGetDim(Pointer<SAFEARRAY> paramPointer); public static native int SafeArrayGetElemsize(Pointer<SAFEARRAY> paramPointer); public static native int SafeArrayGetVartype(Pointer<SAFEARRAY> paramPointer, Pointer<Short> paramPointer1); public static native int SafeArrayAccessData(Pointer<SAFEARRAY> paramPointer, Pointer<Pointer<?>> paramPointer1); public static native int SafeArrayUnaccessData(Pointer<SAFEARRAY> paramPointer); public static native int SafeArrayPtrOfIndex(Pointer<SAFEARRAY> paramPointer, Pointer<CLong> paramPointer1, Pointer<Pointer<?>> paramPointer2); public static native int SafeArrayCopyData(Pointer<SAFEARRAY> paramPointer1, Pointer<SAFEARRAY> paramPointer2); public static native int SafeArrayDestroyData(Pointer<SAFEARRAY> paramPointer); public static native int SafeArrayDestroy(Pointer<SAFEARRAY> paramPointer); public static native int SafeArrayCopy(Pointer<SAFEARRAY> paramPointer, Pointer<Pointer<SAFEARRAY>> paramPointer1); public static native int SafeArrayRedim(Pointer<SAFEARRAY> paramPointer, Pointer<SAFEARRAYBOUND> paramPointer1); public static native int SafeArraySetRecordInfo(Pointer<SAFEARRAY> paramPointer, Pointer<IRecordInfo> paramPointer1); public static native int SafeArrayGetRecordInfo(Pointer<SAFEARRAY> paramPointer, Pointer<Pointer<IRecordInfo>> paramPointer1); public static native int SafeArraySetIID(Pointer<SAFEARRAY> paramPointer, Pointer<GUID> paramPointer1); public static native int SafeArrayGetIID(Pointer<SAFEARRAY> paramPointer, Pointer<GUID> paramPointer1); public static native int VectorFromBstr(Pointer<Byte> paramPointer, Pointer<Pointer<SAFEARRAY>> paramPointer1); public static native int BstrFromVector(Pointer<SAFEARRAY> paramPointer, Pointer<Pointer<Byte>> paramPointer1); public static native int RegisterActiveObject(Pointer<IUnknown> paramPointer, int paramInt); public static native int RevokeActiveObject(int paramInt); public static native int GetActiveObject(Pointer<Pointer<IUnknown>> paramPointer); public static native int GetRecordInfoFromTypeInfo(Pointer<ITypeInfo> paramPointer, Pointer<Pointer<IRecordInfo>> paramPointer1); public static native int GetRecordInfoFromGuids(Pointer<GUID> paramPointer1, int paramInt1, int paramInt2, int paramInt3, Pointer<GUID> paramPointer2, Pointer<Pointer<IRecordInfo>> paramPointer); public static native void VariantInit(Pointer<VARIANT> paramPointer); public static native int VariantClear(Pointer<VARIANT> paramPointer); public static native int VariantCopy(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2); public static native int VariantCopyInd(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2); public static native int VariantChangeType(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2, short paramShort1, short paramShort2); public static native int VariantChangeTypeEx(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2, int paramInt, short paramShort1, short paramShort2); public static native int VarUI1FromI2(short paramShort, Pointer<Byte> paramPointer); public static native int VarUI1FromI4(@CLong long paramLong, Pointer<Byte> paramPointer); public static native int VarUI1FromI8(long paramLong, Pointer<Byte> paramPointer); public static native int VarUI1FromR4(float paramFloat, Pointer<Byte> paramPointer); public static native int VarUI1FromR8(double paramDouble, Pointer<Byte> paramPointer); public static native int VarUI1FromDate(DATE paramDATE, Pointer<Byte> paramPointer); public static native int VarUI1FromBool(short paramShort, Pointer<Byte> paramPointer); public static native int VarUI1FromI1(byte paramByte, Pointer<Byte> paramPointer); public static native int VarUI1FromUI2(short paramShort, Pointer<Byte> paramPointer); public static native int VarUI1FromUI4(int paramInt, Pointer<Byte> paramPointer); public static native int VarUI1FromUI8(long paramLong, Pointer<Byte> paramPointer); public static native int VarUI1FromStr(Pointer<Character> paramPointer, int paramInt1, int paramInt2, Pointer<Byte> paramPointer1); public static native int VarUI1FromCy(CY paramCY, Pointer<Byte> paramPointer); public static native int VarUI1FromDec(Pointer<DECIMAL> paramPointer, Pointer<Byte> paramPointer1); public static native int VarUI1FromDisp(Pointer<IDispatch> paramPointer, int paramInt, Pointer<Byte> paramPointer1); public static native int VarI2FromUI1(byte paramByte, Pointer<Short> paramPointer); public static native int VarI2FromI4(@CLong long paramLong, Pointer<Short> paramPointer); public static native int VarI2FromI8(long paramLong, Pointer<Short> paramPointer); public static native int VarI2FromR4(float paramFloat, Pointer<Short> paramPointer); public static native int VarI2FromR8(double paramDouble, Pointer<Short> paramPointer); public static native int VarI2FromDate(DATE paramDATE, Pointer<Short> paramPointer); public static native int VarI2FromBool(short paramShort, Pointer<Short> paramPointer); public static native int VarI2FromI1(byte paramByte, Pointer<Short> paramPointer); public static native int VarI2FromUI2(short paramShort, Pointer<Short> paramPointer); public static native int VarI2FromUI4(int paramInt, Pointer<Short> paramPointer); public static native int VarI2FromUI8(long paramLong, Pointer<Short> paramPointer); public static native int VarI2FromStr(Pointer<Character> paramPointer, int paramInt1, int paramInt2, Pointer<Short> paramPointer1); public static native int VarI2FromCy(CY paramCY, Pointer<Short> paramPointer); public static native int VarI2FromDec(Pointer<DECIMAL> paramPointer, Pointer<Short> paramPointer1); public static native int VarI2FromDisp(Pointer<IDispatch> paramPointer, int paramInt, Pointer<Short> paramPointer1); public static native int VarI4FromUI1(byte paramByte, Pointer<CLong> paramPointer); public static native int VarI4FromI2(short paramShort, Pointer<CLong> paramPointer); public static native int VarI4FromI8(long paramLong, Pointer<CLong> paramPointer); public static native int VarI4FromR4(float paramFloat, Pointer<CLong> paramPointer); public static native int VarI4FromR8(double paramDouble, Pointer<CLong> paramPointer); public static native int VarI4FromDate(DATE paramDATE, Pointer<CLong> paramPointer); public static native int VarI4FromBool(short paramShort, Pointer<CLong> paramPointer); public static native int VarI4FromI1(byte paramByte, Pointer<CLong> paramPointer); public static native int VarI4FromUI2(short paramShort, Pointer<CLong> paramPointer); public static native int VarI4FromUI4(int paramInt, Pointer<CLong> paramPointer); public static native int VarI4FromUI8(long paramLong, Pointer<CLong> paramPointer); public static native int VarI4FromStr(Pointer<Character> paramPointer, int paramInt1, int paramInt2, Pointer<CLong> paramPointer1); public static native int VarI4FromCy(CY paramCY, Pointer<CLong> paramPointer); public static native int VarI4FromDec(Pointer<DECIMAL> paramPointer, Pointer<CLong> paramPointer1); public static native int VarI4FromDisp(Pointer<IDispatch> paramPointer, int paramInt, Pointer<CLong> paramPointer1); public static native int VarI8FromUI1(byte paramByte, Pointer<Long> paramPointer); public static native int VarI8FromI2(short paramShort, Pointer<Long> paramPointer); public static native int VarI8FromI4(@CLong long paramLong, Pointer<Long> paramPointer); public static native int VarI8FromR4(float paramFloat, Pointer<Long> paramPointer); public static native int VarI8FromR8(double paramDouble, Pointer<Long> paramPointer); public static native int VarI8FromDate(DATE paramDATE, Pointer<Long> paramPointer); public static native int VarI8FromStr(Pointer<Character> paramPointer, int paramInt1, int paramInt2, Pointer<Long> paramPointer1); public static native int VarI8FromBool(short paramShort, Pointer<Long> paramPointer); public static native int VarI8FromI1(byte paramByte, Pointer<Long> paramPointer); public static native int VarI8FromUI2(short paramShort, Pointer<Long> paramPointer); public static native int VarI8FromUI4(int paramInt, Pointer<Long> paramPointer); public static native int VarI8FromUI8(long paramLong, Pointer<Long> paramPointer); public static native int VarI8FromDec(Pointer<DECIMAL> paramPointer, Pointer<Long> paramPointer1); public static native int VarI8FromInt(int paramInt, Pointer<Long> paramPointer); public static native int VarI8FromCy(CY paramCY, Pointer<Long> paramPointer); public static native int VarI8FromDisp(Pointer<IDispatch> paramPointer, int paramInt, Pointer<Long> paramPointer1); public static native int VarR4FromUI1(byte paramByte, Pointer<Float> paramPointer); public static native int VarR4FromI2(short paramShort, Pointer<Float> paramPointer); public static native int VarR4FromI4(@CLong long paramLong, Pointer<Float> paramPointer); public static native int VarR4FromI8(long paramLong, Pointer<Float> paramPointer); public static native int VarR4FromR8(double paramDouble, Pointer<Float> paramPointer); public static native int VarR4FromDate(DATE paramDATE, Pointer<Float> paramPointer); public static native int VarR4FromBool(short paramShort, Pointer<Float> paramPointer); public static native int VarR4FromI1(byte paramByte, Pointer<Float> paramPointer); public static native int VarR4FromUI2(short paramShort, Pointer<Float> paramPointer); public static native int VarR4FromUI4(int paramInt, Pointer<Float> paramPointer); public static native int VarR4FromUI8(long paramLong, Pointer<Float> paramPointer); public static native int VarR4FromStr(Pointer<Character> paramPointer, int paramInt1, int paramInt2, Pointer<Float> paramPointer1); public static native int VarR4FromCy(CY paramCY, Pointer<Float> paramPointer); public static native int VarR4FromDec(Pointer<DECIMAL> paramPointer, Pointer<Float> paramPointer1); public static native int VarR4FromDisp(Pointer<IDispatch> paramPointer, int paramInt, Pointer<Float> paramPointer1); public static native int VarR8FromUI1(byte paramByte, Pointer<Double> paramPointer); public static native int VarR8FromI2(short paramShort, Pointer<Double> paramPointer); public static native int VarR8FromI4(@CLong long paramLong, Pointer<Double> paramPointer); public static native int VarR8FromI8(long paramLong, Pointer<Double> paramPointer); public static native int VarR8FromR4(float paramFloat, Pointer<Double> paramPointer); public static native int VarR8FromDate(DATE paramDATE, Pointer<Double> paramPointer); public static native int VarR8FromBool(short paramShort, Pointer<Double> paramPointer); public static native int VarR8FromI1(byte paramByte, Pointer<Double> paramPointer); public static native int VarR8FromUI2(short paramShort, Pointer<Double> paramPointer); public static native int VarR8FromUI4(int paramInt, Pointer<Double> paramPointer); public static native int VarR8FromUI8(long paramLong, Pointer<Double> paramPointer); public static native int VarR8FromStr(Pointer<Character> paramPointer, int paramInt1, int paramInt2, Pointer<Double> paramPointer1); public static native int VarR8FromCy(CY paramCY, Pointer<Double> paramPointer); public static native int VarR8FromDec(Pointer<DECIMAL> paramPointer, Pointer<Double> paramPointer1); public static native int VarR8FromDisp(Pointer<IDispatch> paramPointer, int paramInt, Pointer<Double> paramPointer1); public static native int VarDateFromUI1(byte paramByte, Pointer<DATE> paramPointer); public static native int VarDateFromI2(short paramShort, Pointer<DATE> paramPointer); public static native int VarDateFromI4(@CLong long paramLong, Pointer<DATE> paramPointer); public static native int VarDateFromI8(long paramLong, Pointer<DATE> paramPointer); public static native int VarDateFromR4(float paramFloat, Pointer<DATE> paramPointer); public static native int VarDateFromR8(double paramDouble, Pointer<DATE> paramPointer); public static native int VarDateFromStr(Pointer<Character> paramPointer, int paramInt1, int paramInt2, Pointer<DATE> paramPointer1); public static native int VarDateFromI1(byte paramByte, Pointer<DATE> paramPointer); public static native int VarDateFromUI2(short paramShort, Pointer<DATE> paramPointer); public static native int VarDateFromUI4(int paramInt, Pointer<DATE> paramPointer); public static native int VarDateFromUI8(long paramLong, Pointer<DATE> paramPointer); public static native int VarDateFromBool(short paramShort, Pointer<DATE> paramPointer); public static native int VarDateFromCy(CY paramCY, Pointer<DATE> paramPointer); public static native int VarDateFromDec(Pointer<DECIMAL> paramPointer, Pointer<DATE> paramPointer1); public static native int VarDateFromDisp(Pointer<IDispatch> paramPointer, int paramInt, Pointer<DATE> paramPointer1); public static native int VarCyFromUI1(byte paramByte, Pointer<CY> paramPointer); public static native int VarCyFromI2(short paramShort, Pointer<CY> paramPointer); public static native int VarCyFromI4(@CLong long paramLong, Pointer<CY> paramPointer); public static native int VarCyFromI8(long paramLong, Pointer<CY> paramPointer); public static native int VarCyFromR4(float paramFloat, Pointer<CY> paramPointer); public static native int VarCyFromR8(double paramDouble, Pointer<CY> paramPointer); public static native int VarCyFromDate(DATE paramDATE, Pointer<CY> paramPointer); public static native int VarCyFromStr(Pointer<Character> paramPointer, int paramInt1, int paramInt2, Pointer<CY> paramPointer1); public static native int VarCyFromBool(short paramShort, Pointer<CY> paramPointer); public static native int VarCyFromI1(byte paramByte, Pointer<CY> paramPointer); public static native int VarCyFromUI2(short paramShort, Pointer<CY> paramPointer); public static native int VarCyFromUI4(int paramInt, Pointer<CY> paramPointer); public static native int VarCyFromUI8(long paramLong, Pointer<CY> paramPointer); public static native int VarCyFromDec(Pointer<DECIMAL> paramPointer, Pointer<CY> paramPointer1); public static native int VarCyFromDisp(Pointer<IDispatch> paramPointer, int paramInt, Pointer<CY> paramPointer1); public static native int VarBstrFromUI1(byte paramByte, int paramInt1, int paramInt2, Pointer<Pointer<Byte>> paramPointer); public static native int VarBstrFromI2(short paramShort, int paramInt1, int paramInt2, Pointer<Pointer<Byte>> paramPointer); public static native int VarBstrFromI4(@CLong long paramLong, int paramInt1, int paramInt2, Pointer<Pointer<Byte>> paramPointer); public static native int VarBstrFromI8(long paramLong, int paramInt1, int paramInt2, Pointer<Pointer<Byte>> paramPointer); public static native int VarBstrFromR4(float paramFloat, int paramInt1, int paramInt2, Pointer<Pointer<Byte>> paramPointer); public static native int VarBstrFromR8(double paramDouble, int paramInt1, int paramInt2, Pointer<Pointer<Byte>> paramPointer); public static native int VarBstrFromDate(DATE paramDATE, int paramInt1, int paramInt2, Pointer<Pointer<Byte>> paramPointer); public static native int VarBstrFromBool(short paramShort, int paramInt1, int paramInt2, Pointer<Pointer<Byte>> paramPointer); public static native int VarBstrFromI1(byte paramByte, int paramInt1, int paramInt2, Pointer<Pointer<Byte>> paramPointer); public static native int VarBstrFromUI2(short paramShort, int paramInt1, int paramInt2, Pointer<Pointer<Byte>> paramPointer); public static native int VarBstrFromUI8(long paramLong, int paramInt1, int paramInt2, Pointer<Pointer<Byte>> paramPointer); public static native int VarBstrFromUI4(int paramInt1, int paramInt2, int paramInt3, Pointer<Pointer<Byte>> paramPointer); public static native int VarBstrFromCy(CY paramCY, int paramInt1, int paramInt2, Pointer<Pointer<Byte>> paramPointer); public static native int VarBstrFromDec(Pointer<DECIMAL> paramPointer, int paramInt1, int paramInt2, Pointer<Pointer<Byte>> paramPointer1); public static native int VarBstrFromDisp(Pointer<IDispatch> paramPointer, int paramInt1, int paramInt2, Pointer<Pointer<Byte>> paramPointer1); public static native int VarBoolFromUI1(byte paramByte, Pointer<Short> paramPointer); public static native int VarBoolFromI2(short paramShort, Pointer<Short> paramPointer); public static native int VarBoolFromI4(@CLong long paramLong, Pointer<Short> paramPointer); public static native int VarBoolFromI8(long paramLong, Pointer<Short> paramPointer); public static native int VarBoolFromR4(float paramFloat, Pointer<Short> paramPointer); public static native int VarBoolFromR8(double paramDouble, Pointer<Short> paramPointer); public static native int VarBoolFromDate(DATE paramDATE, Pointer<Short> paramPointer); public static native int VarBoolFromStr(Pointer<Character> paramPointer, int paramInt1, int paramInt2, Pointer<Short> paramPointer1); public static native int VarBoolFromI1(byte paramByte, Pointer<Short> paramPointer); public static native int VarBoolFromUI2(short paramShort, Pointer<Short> paramPointer); public static native int VarBoolFromUI4(int paramInt, Pointer<Short> paramPointer); public static native int VarBoolFromUI8(long paramLong, Pointer<Short> paramPointer); public static native int VarBoolFromCy(CY paramCY, Pointer<Short> paramPointer); public static native int VarBoolFromDec(Pointer<DECIMAL> paramPointer, Pointer<Short> paramPointer1);
/*      */   public static native int VarBoolFromDisp(Pointer<IDispatch> paramPointer, int paramInt, Pointer<Short> paramPointer1);
/*      */   public static native int VarI1FromUI1(byte paramByte, Pointer<Byte> paramPointer);
/*      */   public static native int VarI1FromI2(short paramShort, Pointer<Byte> paramPointer);
/*      */   public static native int VarI1FromI4(@CLong long paramLong, Pointer<Byte> paramPointer);
/*      */   public static native int VarI1FromI8(long paramLong, Pointer<Byte> paramPointer);
/*      */   public static native int VarI1FromR4(float paramFloat, Pointer<Byte> paramPointer);
/*      */   public static native int VarI1FromR8(double paramDouble, Pointer<Byte> paramPointer);
/*      */   public static native int VarI1FromDate(DATE paramDATE, Pointer<Byte> paramPointer);
/*      */   public static native int VarI1FromStr(Pointer<Character> paramPointer, int paramInt1, int paramInt2, Pointer<Byte> paramPointer1);
/*      */   public static native int VarI1FromBool(short paramShort, Pointer<Byte> paramPointer);
/*      */   public static native int VarI1FromUI2(short paramShort, Pointer<Byte> paramPointer);
/*      */   public static native int VarI1FromUI4(int paramInt, Pointer<Byte> paramPointer);
/*      */   public static native int VarI1FromUI8(long paramLong, Pointer<Byte> paramPointer);
/*      */   public static native int VarI1FromCy(CY paramCY, Pointer<Byte> paramPointer);
/*      */   public static native int VarI1FromDec(Pointer<DECIMAL> paramPointer, Pointer<Byte> paramPointer1);
/*      */   public static native int VarI1FromDisp(Pointer<IDispatch> paramPointer, int paramInt, Pointer<Byte> paramPointer1);
/*      */   public static native int VarUI2FromUI1(byte paramByte, Pointer<Short> paramPointer);
/*      */   public static native int VarUI2FromI2(short paramShort, Pointer<Short> paramPointer);
/*      */   public static native int VarUI2FromI4(@CLong long paramLong, Pointer<Short> paramPointer);
/*      */   public static native int VarUI2FromI8(long paramLong, Pointer<Short> paramPointer);
/*      */   public static native int VarUI2FromR4(float paramFloat, Pointer<Short> paramPointer);
/*      */   public static native int VarUI2FromR8(double paramDouble, Pointer<Short> paramPointer);
/*      */   public static native int VarUI2FromDate(DATE paramDATE, Pointer<Short> paramPointer);
/*      */   public static native int VarUI2FromStr(Pointer<Character> paramPointer, int paramInt1, int paramInt2, Pointer<Short> paramPointer1);
/*      */   public static native int VarUI2FromBool(short paramShort, Pointer<Short> paramPointer);
/*      */   public static native int VarUI2FromI1(byte paramByte, Pointer<Short> paramPointer);
/*      */   public static native int VarUI2FromUI4(int paramInt, Pointer<Short> paramPointer);
/*      */   public static native int VarUI2FromUI8(long paramLong, Pointer<Short> paramPointer);
/*      */   public static native int VarUI2FromCy(CY paramCY, Pointer<Short> paramPointer);
/*      */   public static native int VarUI2FromDec(Pointer<DECIMAL> paramPointer, Pointer<Short> paramPointer1);
/*      */   public static native int VarUI2FromDisp(Pointer<IDispatch> paramPointer, int paramInt, Pointer<Short> paramPointer1);
/*      */   public static native int VarUI4FromStr(Pointer<Character> paramPointer, int paramInt1, int paramInt2, Pointer<Integer> paramPointer1);
/*      */   public static native int VarUI4FromUI1(byte paramByte, Pointer<Integer> paramPointer);
/*      */   public static native int VarUI4FromI2(short paramShort, Pointer<Integer> paramPointer);
/*      */   public static native int VarUI4FromI4(@CLong long paramLong, Pointer<Integer> paramPointer);
/*      */   public static native int VarUI4FromI8(long paramLong, Pointer<Integer> paramPointer);
/*      */   public static native int VarUI4FromR4(float paramFloat, Pointer<Integer> paramPointer);
/*      */   public static native int VarUI4FromR8(double paramDouble, Pointer<Integer> paramPointer);
/*      */   public static native int VarUI4FromDate(DATE paramDATE, Pointer<Integer> paramPointer);
/*      */   public static native int VarUI4FromBool(short paramShort, Pointer<Integer> paramPointer);
/*      */   public static native int VarUI4FromI1(byte paramByte, Pointer<Integer> paramPointer);
/*      */   public static native int VarUI4FromUI2(short paramShort, Pointer<Integer> paramPointer);
/*      */   public static native int VarUI4FromUI8(long paramLong, Pointer<Integer> paramPointer);
/*      */   public static native int VarUI4FromCy(CY paramCY, Pointer<Integer> paramPointer);
/*      */   public static native int VarUI4FromDec(Pointer<DECIMAL> paramPointer, Pointer<Integer> paramPointer1);
/*      */   public static native int VarUI4FromDisp(Pointer<IDispatch> paramPointer, int paramInt, Pointer<Integer> paramPointer1);
/*      */   public static native int VarUI8FromUI1(byte paramByte, Pointer<Long> paramPointer);
/*      */   public static native int VarUI8FromI2(short paramShort, Pointer<Long> paramPointer);
/*      */   public static native int VarUI8FromI4(@CLong long paramLong, Pointer<Long> paramPointer);
/*      */   public static native int VarUI8FromI8(long paramLong, Pointer<Long> paramPointer);
/*      */   public static native int VarUI8FromR4(float paramFloat, Pointer<Long> paramPointer);
/*      */   public static native int VarUI8FromR8(double paramDouble, Pointer<Long> paramPointer);
/*      */   public static native int VarUI8FromDate(DATE paramDATE, Pointer<Long> paramPointer);
/*      */   public static native int VarUI8FromStr(Pointer<Character> paramPointer, int paramInt1, int paramInt2, Pointer<Long> paramPointer1);
/*      */   public static native int VarUI8FromBool(short paramShort, Pointer<Long> paramPointer);
/*      */   public static native int VarUI8FromI1(byte paramByte, Pointer<Long> paramPointer);
/*      */   public static native int VarUI8FromUI2(short paramShort, Pointer<Long> paramPointer);
/*      */   public static native int VarUI8FromUI4(int paramInt, Pointer<Long> paramPointer);
/*      */   public static native int VarUI8FromDec(Pointer<DECIMAL> paramPointer, Pointer<Long> paramPointer1);
/*      */   public static native int VarUI8FromInt(int paramInt, Pointer<Long> paramPointer);
/*      */   static {
/*   65 */     BridJ.register();
/*      */   } public static native int VarUI8FromCy(CY paramCY, Pointer<Long> paramPointer); public static native int VarUI8FromDisp(Pointer<IDispatch> paramPointer, int paramInt, Pointer<Long> paramPointer1); public static native int VarDecFromUI1(byte paramByte, Pointer<DECIMAL> paramPointer); public static native int VarDecFromI2(short paramShort, Pointer<DECIMAL> paramPointer); public static native int VarDecFromI4(@CLong long paramLong, Pointer<DECIMAL> paramPointer); public static native int VarDecFromI8(long paramLong, Pointer<DECIMAL> paramPointer); public static native int VarDecFromR4(float paramFloat, Pointer<DECIMAL> paramPointer); public static native int VarDecFromR8(double paramDouble, Pointer<DECIMAL> paramPointer); public static native int VarDecFromDate(DATE paramDATE, Pointer<DECIMAL> paramPointer); public static native int VarDecFromStr(Pointer<Character> paramPointer, int paramInt1, int paramInt2, Pointer<DECIMAL> paramPointer1); public static native int VarDecFromBool(short paramShort, Pointer<DECIMAL> paramPointer); public static native int VarDecFromI1(byte paramByte, Pointer<DECIMAL> paramPointer); public static native int VarDecFromUI2(short paramShort, Pointer<DECIMAL> paramPointer); public static native int VarDecFromUI4(int paramInt, Pointer<DECIMAL> paramPointer); public static native int VarDecFromUI8(long paramLong, Pointer<DECIMAL> paramPointer); public static native int VarDecFromCy(CY paramCY, Pointer<DECIMAL> paramPointer); public static native int VarDecFromDisp(Pointer<IDispatch> paramPointer, int paramInt, Pointer<DECIMAL> paramPointer1); public static native int VarR4CmpR8(float paramFloat, double paramDouble); public static native int VarR8Pow(double paramDouble1, double paramDouble2, Pointer<Double> paramPointer); public static native int VarR8Round(double paramDouble, int paramInt, Pointer<Double> paramPointer); public static native int VarDecAbs(Pointer<DECIMAL> paramPointer1, Pointer<DECIMAL> paramPointer2); public static native int VarDecAdd(Pointer<DECIMAL> paramPointer1, Pointer<DECIMAL> paramPointer2, Pointer<DECIMAL> paramPointer3); public static native int VarDecCmp(Pointer<DECIMAL> paramPointer1, Pointer<DECIMAL> paramPointer2); public static native int VarDecCmpR8(Pointer<DECIMAL> paramPointer, double paramDouble); public static native int VarDecDiv(Pointer<DECIMAL> paramPointer1, Pointer<DECIMAL> paramPointer2, Pointer<DECIMAL> paramPointer3); public static native int VarDecFix(Pointer<DECIMAL> paramPointer1, Pointer<DECIMAL> paramPointer2); public static native int VarDecInt(Pointer<DECIMAL> paramPointer1, Pointer<DECIMAL> paramPointer2); public static native int VarDecMul(Pointer<DECIMAL> paramPointer1, Pointer<DECIMAL> paramPointer2, Pointer<DECIMAL> paramPointer3); public static native int VarDecNeg(Pointer<DECIMAL> paramPointer1, Pointer<DECIMAL> paramPointer2); public static native int VarDecRound(Pointer<DECIMAL> paramPointer1, int paramInt, Pointer<DECIMAL> paramPointer2); public static native int VarDecSub(Pointer<DECIMAL> paramPointer1, Pointer<DECIMAL> paramPointer2, Pointer<DECIMAL> paramPointer3); public static native int VarCyAbs(CY paramCY, Pointer<CY> paramPointer); public static native int VarCyAdd(CY paramCY1, CY paramCY2, Pointer<CY> paramPointer); public static native int VarCyCmp(CY paramCY1, CY paramCY2); public static native int VarCyCmpR8(CY paramCY, double paramDouble); public static native int VarCyFix(CY paramCY, Pointer<CY> paramPointer); public static native int VarCyInt(CY paramCY, Pointer<CY> paramPointer); public static native int VarCyMul(CY paramCY1, CY paramCY2, Pointer<CY> paramPointer); public static native int VarCyMulI4(CY paramCY, @CLong long paramLong, Pointer<CY> paramPointer); public static native int VarCyMulI8(CY paramCY, long paramLong, Pointer<CY> paramPointer); public static native int VarCyNeg(CY paramCY, Pointer<CY> paramPointer); public static native int VarCyRound(CY paramCY, int paramInt, Pointer<CY> paramPointer); public static native int VarCySub(CY paramCY1, CY paramCY2, Pointer<CY> paramPointer); public static native int VarAdd(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2, Pointer<VARIANT> paramPointer3); public static native int VarAnd(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2, Pointer<VARIANT> paramPointer3); public static native int VarCat(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2, Pointer<VARIANT> paramPointer3); public static native int VarDiv(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2, Pointer<VARIANT> paramPointer3); public static native int VarEqv(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2, Pointer<VARIANT> paramPointer3); public static native int VarIdiv(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2, Pointer<VARIANT> paramPointer3); public static native int VarImp(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2, Pointer<VARIANT> paramPointer3); public static native int VarMod(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2, Pointer<VARIANT> paramPointer3); public static native int VarMul(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2, Pointer<VARIANT> paramPointer3); public static native int VarOr(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2, Pointer<VARIANT> paramPointer3); public static native int VarPow(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2, Pointer<VARIANT> paramPointer3); public static native int VarSub(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2, Pointer<VARIANT> paramPointer3);
/*      */   public static native int VarXor(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2, Pointer<VARIANT> paramPointer3);
/*      */   public static native int VarAbs(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2);
/*      */   public static native int VarFix(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2);
/*      */   public static native int VarInt(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2);
/*      */   public static native int VarNeg(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2);
/*      */   public static native int VarNot(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2);
/*      */   public static native int VarRound(Pointer<VARIANT> paramPointer1, int paramInt, Pointer<VARIANT> paramPointer2);
/*      */   public static native int VarCmp(Pointer<VARIANT> paramPointer1, Pointer<VARIANT> paramPointer2, int paramInt1, int paramInt2);
/*      */   public static native int VarBstrCmp(Pointer<Byte> paramPointer1, Pointer<Byte> paramPointer2, int paramInt1, int paramInt2);
/*      */   public static native int VarBstrCat(Pointer<Byte> paramPointer1, Pointer<Byte> paramPointer2, Pointer<Pointer<Byte>> paramPointer);
/*      */   public static native int VarParseNumFromStr(Pointer<Character> paramPointer, int paramInt1, int paramInt2, Pointer<NUMPARSE> paramPointer1, Pointer<Byte> paramPointer2);
/*      */   public static native int VarNumFromParseNum(Pointer<NUMPARSE> paramPointer, Pointer<Byte> paramPointer1, int paramInt, Pointer<VARIANT> paramPointer2);
/*      */   public static native int DosDateTimeToVariantTime(short paramShort1, short paramShort2, Pointer<Double> paramPointer);
/*      */   public static native int VariantTimeToDosDateTime(double paramDouble, Pointer<Short> paramPointer1, Pointer<Short> paramPointer2);
/*      */   public static native int VariantTimeToSystemTime(double paramDouble, Pointer<SYSTEMTIME> paramPointer);
/*      */   public static native int SystemTimeToVariantTime(Pointer<SYSTEMTIME> paramPointer, Pointer<Double> paramPointer1);
/*      */   public static native int VarDateFromUdate(Pointer<UDATE> paramPointer, int paramInt, Pointer<DATE> paramPointer1);
/*      */   public static native int VarDateFromUdateEx(Pointer<UDATE> paramPointer, int paramInt1, int paramInt2, Pointer<DATE> paramPointer1);
/*      */   public static native int VarUdateFromDate(DATE paramDATE, int paramInt, Pointer<UDATE> paramPointer);
/*      */   public static native int VarWeekdayName(int paramInt1, int paramInt2, int paramInt3, int paramInt4, Pointer<Pointer<Byte>> paramPointer);
/*      */   public static native int VarMonthName(int paramInt1, int paramInt2, int paramInt3, Pointer<Pointer<Byte>> paramPointer);
/*      */   public static native int GetAltMonthNames(int paramInt, Pointer<Pointer<Pointer<Character>>> paramPointer);
/*      */   public static native int VarFormat(Pointer<VARIANT> paramPointer, Pointer<Character> paramPointer1, int paramInt1, int paramInt2, int paramInt3, Pointer<Pointer<Byte>> paramPointer2);
/*      */   public static native int VarFormatCurrency(Pointer<VARIANT> paramPointer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, Pointer<Pointer<Byte>> paramPointer1);
/*      */   public static native int VarFormatDateTime(Pointer<VARIANT> paramPointer, int paramInt1, int paramInt2, Pointer<Pointer<Byte>> paramPointer1);
/*      */   public static native int VarFormatNumber(Pointer<VARIANT> paramPointer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, Pointer<Pointer<Byte>> paramPointer1);
/*      */   public static native int VarFormatPercent(Pointer<VARIANT> paramPointer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, Pointer<Pointer<Byte>> paramPointer1);
/*      */   public static native int VarFormatFromTokens(Pointer<VARIANT> paramPointer, Pointer<Character> paramPointer1, int paramInt1, Pointer<Pointer<Byte>> paramPointer2, int paramInt2);
/*      */   public static native int VarTokenizeFormatString(Pointer<Character> paramPointer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Pointer<Integer> paramPointer1);
/*      */   public static native int DispGetParam(Pointer<DISPPARAMS> paramPointer, int paramInt, short paramShort, Pointer<VARIANT> paramPointer1, Pointer<Integer> paramPointer2);
/*      */   public static native int DispGetIDsOfNames(Pointer<ITypeInfo> paramPointer, Pointer<Pointer<Character>> paramPointer1, int paramInt, Pointer<CLong> paramPointer2);
/*      */   public static native int DispInvoke(Pointer<?> paramPointer, Pointer<ITypeInfo> paramPointer1, @CLong long paramLong, short paramShort, Pointer<DISPPARAMS> paramPointer2, Pointer<VARIANT> paramPointer3, Pointer<EXCEPINFO> paramPointer4, Pointer<Integer> paramPointer5);
/*      */   public static native int CreateDispTypeInfo(Pointer<INTERFACEDATA> paramPointer, int paramInt, Pointer<Pointer<ITypeInfo>> paramPointer1);
/*      */   public static native int CreateStdDispatch(Pointer<IUnknown> paramPointer, Pointer<?> paramPointer1, Pointer<ITypeInfo> paramPointer2, Pointer<Pointer<IUnknown>> paramPointer3);
/*      */   public static native int DispCallFunc(Pointer<?> paramPointer, ValuedEnum<CALLCONV> paramValuedEnum, short paramShort, int paramInt, Pointer<Short> paramPointer1, Pointer<Pointer<VARIANT>> paramPointer2, Pointer<VARIANT> paramPointer3);
/*      */   public static native int LHashValOfNameSysA(ValuedEnum<SYSKIND> paramValuedEnum, int paramInt);
/*      */   public static native int LHashValOfNameSys(ValuedEnum<SYSKIND> paramValuedEnum, int paramInt);
/*      */   public static native int CreateTypeLib(ValuedEnum<SYSKIND> paramValuedEnum, Pointer<Character> paramPointer, Pointer<Pointer<ICreateTypeLib>> paramPointer1);
/*      */   public static native int CreateTypeLib2(ValuedEnum<SYSKIND> paramValuedEnum, Pointer<Pointer<ICreateTypeLib2>> paramPointer);
/*      */   public static native int LoadRegTypeLib(Pointer<GUID> paramPointer, short paramShort1, short paramShort2, int paramInt, Pointer<Pointer<ITypeLib>> paramPointer1);
/*      */   public static native int LoadTypeLib(Pointer<Character> paramPointer, Pointer<Pointer<ITypeLib>> paramPointer1);
/*      */   public static native int LoadTypeLibEx(ValuedEnum<REGKIND> paramValuedEnum, Pointer<Pointer<ITypeLib>> paramPointer);
/*      */   public static native int QueryPathOfRegTypeLib(Pointer<GUID> paramPointer, short paramShort1, short paramShort2, int paramInt, Pointer<Pointer<Byte>> paramPointer1);
/*      */   public static native int RegisterTypeLib(Pointer<ITypeLib> paramPointer, Pointer<Character> paramPointer1, Pointer<Character> paramPointer2);
/*      */   public static native int UnRegisterTypeLib(Pointer<GUID> paramPointer, short paramShort1, short paramShort2, int paramInt, ValuedEnum<SYSKIND> paramValuedEnum);
/*      */   public static native int RegisterTypeLibForUser(Pointer<ITypeLib> paramPointer, Pointer<Character> paramPointer1, Pointer<Character> paramPointer2);
/*      */   public static native int UnRegisterTypeLibForUser(Pointer<GUID> paramPointer, short paramShort1, short paramShort2, int paramInt, ValuedEnum<SYSKIND> paramValuedEnum);
/*      */   public static native void ClearCustData(Pointer<CUSTDATA> paramPointer);
/*      */   public static class ITypeLib extends CPPObject {}
/*      */   public static class ICreateTypeLib extends CPPObject {}
/*      */   public static class ICreateTypeLib2 extends CPPObject {}
/*      */   public static class ICreateErrorInfo extends CPPObject {}
/*      */   public static class IErrorInfo extends CPPObject {}
/*  120 */   public enum SYSKIND implements IntValuedEnum<SYSKIND> { SYS_WIN16(0L),
/*  121 */     SYS_WIN32(1L),
/*  122 */     SYS_MAC(2L); public final long value;
/*      */     
/*      */     SYSKIND(long value) {
/*  125 */       this.value = value;
/*      */     }
/*      */ 
/*      */     
/*      */     public long value() {
/*  130 */       return this.value;
/*      */     }
/*      */     
/*      */     public Iterator<SYSKIND> iterator() {
/*  134 */       return Collections.<SYSKIND>singleton(this).iterator();
/*      */     }
/*      */     
/*      */     public static ValuedEnum<SYSKIND> fromValue(long value) {
/*  138 */       return FlagSet.fromValue(value, (Enum[])values());
/*      */     } }
/*      */ 
/*      */   
/*      */   public enum CALLCONV
/*      */     implements IntValuedEnum<CALLCONV> {
/*  144 */     CC_FASTCALL(0L),
/*  145 */     CC_CDECL(1L),
/*  146 */     CC_MSCPASCAL(2L),
/*  147 */     CC_PASCAL(CC_MSCPASCAL.value()),
/*  148 */     CC_MACPASCAL(CC_MSCPASCAL.value() + 1L),
/*  149 */     CC_STDCALL(CC_MSCPASCAL.value() + 2L),
/*  150 */     CC_FPFASTCALL(CC_MSCPASCAL.value() + 3L),
/*  151 */     CC_SYSCALL(CC_MSCPASCAL.value() + 4L),
/*  152 */     CC_MPWCDECL(CC_MSCPASCAL.value() + 5L),
/*  153 */     CC_MPWPASCAL(CC_MSCPASCAL.value() + 6L),
/*  154 */     CC_MAX(CC_MSCPASCAL.value() + 7L); public final long value;
/*      */     
/*      */     CALLCONV(long value) {
/*  157 */       this.value = value;
/*      */     }
/*      */ 
/*      */     
/*      */     public long value() {
/*  162 */       return this.value;
/*      */     }
/*      */     
/*      */     public Iterator<CALLCONV> iterator() {
/*  166 */       return Collections.<CALLCONV>singleton(this).iterator();
/*      */     }
/*      */     
/*      */     public static ValuedEnum<CALLCONV> fromValue(long value) {
/*  170 */       return FlagSet.fromValue(value, (Enum[])values());
/*      */     }
/*      */   }
/*      */   
/*      */   public enum REGKIND
/*      */     implements IntValuedEnum<REGKIND> {
/*  176 */     REGKIND_DEFAULT(0L),
/*  177 */     REGKIND_REGISTER(1L),
/*  178 */     REGKIND_NONE(2L); public final long value;
/*      */     
/*      */     REGKIND(long value) {
/*  181 */       this.value = value;
/*      */     }
/*      */ 
/*      */     
/*      */     public long value() {
/*  186 */       return this.value;
/*      */     }
/*      */     
/*      */     public Iterator<REGKIND> iterator() {
/*  190 */       return Collections.<REGKIND>singleton(this).iterator();
/*      */     }
/*      */     
/*      */     public static ValuedEnum<REGKIND> fromValue(long value) {
/*  194 */       return FlagSet.fromValue(value, (Enum[])values());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DATE
/*      */     extends StructObject {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DISPPARAMS
/*      */     extends StructObject {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class EXCEPINFO
/*      */     extends StructObject {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class CUSTDATAITEM
/*      */     extends StructObject
/*      */   {
/*      */     @Field(0)
/*      */     public GUID guid() {
/*  297 */       return (GUID)this.io.getNativeObjectField(this, 0);
/*      */     }
/*      */ 
/*      */     
/*      */     @Field(1)
/*      */     public VARIANT varValue() {
/*  303 */       return (VARIANT)this.io.getNativeObjectField(this, 1);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class CUSTDATA
/*      */     extends StructObject
/*      */   {
/*      */     @Field(0)
/*      */     public int cCustData() {
/*  318 */       return this.io.getIntField(this, 0);
/*      */     }
/*      */     
/*      */     @Field(0)
/*      */     public CUSTDATA cCustData(int cCustData) {
/*  323 */       this.io.setIntField(this, 0, cCustData);
/*  324 */       return this;
/*      */     }
/*      */     
/*      */     public final int cCustData_$eq(int cCustData) {
/*  328 */       cCustData(cCustData);
/*  329 */       return cCustData;
/*      */     }
/*      */ 
/*      */     
/*      */     @Field(1)
/*      */     public Pointer<OLEAutomationLibrary.CUSTDATAITEM> prgCustData() {
/*  335 */       return this.io.getPointerField(this, 1);
/*      */     }
/*      */ 
/*      */     
/*      */     @Field(1)
/*      */     public CUSTDATA prgCustData(Pointer<OLEAutomationLibrary.CUSTDATAITEM> prgCustData) {
/*  341 */       this.io.setPointerField(this, 1, prgCustData);
/*  342 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final Pointer<OLEAutomationLibrary.CUSTDATAITEM> prgCustData_$eq(Pointer<OLEAutomationLibrary.CUSTDATAITEM> prgCustData) {
/*  347 */       prgCustData(prgCustData);
/*  348 */       return prgCustData;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class SYSTEMTIME
/*      */     extends StructObject
/*      */   {
/*      */     @Field(0)
/*      */     public short wYear() {
/*  363 */       return this.io.getShortField(this, 0);
/*      */     }
/*      */     
/*      */     @Field(0)
/*      */     public SYSTEMTIME wYear(short wYear) {
/*  368 */       this.io.setShortField(this, 0, wYear);
/*  369 */       return this;
/*      */     }
/*      */     
/*      */     public final short wYear_$eq(short wYear) {
/*  373 */       wYear(wYear);
/*  374 */       return wYear;
/*      */     }
/*      */     
/*      */     @Field(1)
/*      */     public short wMonth() {
/*  379 */       return this.io.getShortField(this, 1);
/*      */     }
/*      */     
/*      */     @Field(1)
/*      */     public SYSTEMTIME wMonth(short wMonth) {
/*  384 */       this.io.setShortField(this, 1, wMonth);
/*  385 */       return this;
/*      */     }
/*      */     
/*      */     public final short wMonth_$eq(short wMonth) {
/*  389 */       wMonth(wMonth);
/*  390 */       return wMonth;
/*      */     }
/*      */     
/*      */     @Field(2)
/*      */     public short wDayOfWeek() {
/*  395 */       return this.io.getShortField(this, 2);
/*      */     }
/*      */     
/*      */     @Field(2)
/*      */     public SYSTEMTIME wDayOfWeek(short wDayOfWeek) {
/*  400 */       this.io.setShortField(this, 2, wDayOfWeek);
/*  401 */       return this;
/*      */     }
/*      */     
/*      */     public final short wDayOfWeek_$eq(short wDayOfWeek) {
/*  405 */       wDayOfWeek(wDayOfWeek);
/*  406 */       return wDayOfWeek;
/*      */     }
/*      */     
/*      */     @Field(3)
/*      */     public short wDay() {
/*  411 */       return this.io.getShortField(this, 3);
/*      */     }
/*      */     
/*      */     @Field(3)
/*      */     public SYSTEMTIME wDay(short wDay) {
/*  416 */       this.io.setShortField(this, 3, wDay);
/*  417 */       return this;
/*      */     }
/*      */     
/*      */     public final short wDay_$eq(short wDay) {
/*  421 */       wDay(wDay);
/*  422 */       return wDay;
/*      */     }
/*      */     
/*      */     @Field(4)
/*      */     public short wHour() {
/*  427 */       return this.io.getShortField(this, 4);
/*      */     }
/*      */     
/*      */     @Field(4)
/*      */     public SYSTEMTIME wHour(short wHour) {
/*  432 */       this.io.setShortField(this, 4, wHour);
/*  433 */       return this;
/*      */     }
/*      */     
/*      */     public final short wHour_$eq(short wHour) {
/*  437 */       wHour(wHour);
/*  438 */       return wHour;
/*      */     }
/*      */     
/*      */     @Field(5)
/*      */     public short wMinute() {
/*  443 */       return this.io.getShortField(this, 5);
/*      */     }
/*      */     
/*      */     @Field(5)
/*      */     public SYSTEMTIME wMinute(short wMinute) {
/*  448 */       this.io.setShortField(this, 5, wMinute);
/*  449 */       return this;
/*      */     }
/*      */     
/*      */     public final short wMinute_$eq(short wMinute) {
/*  453 */       wMinute(wMinute);
/*  454 */       return wMinute;
/*      */     }
/*      */     
/*      */     @Field(6)
/*      */     public short wSecond() {
/*  459 */       return this.io.getShortField(this, 6);
/*      */     }
/*      */     
/*      */     @Field(6)
/*      */     public SYSTEMTIME wSecond(short wSecond) {
/*  464 */       this.io.setShortField(this, 6, wSecond);
/*  465 */       return this;
/*      */     }
/*      */     
/*      */     public final short wSecond_$eq(short wSecond) {
/*  469 */       wSecond(wSecond);
/*  470 */       return wSecond;
/*      */     }
/*      */     
/*      */     @Field(7)
/*      */     public short wMilliseconds() {
/*  475 */       return this.io.getShortField(this, 7);
/*      */     }
/*      */     
/*      */     @Field(7)
/*      */     public SYSTEMTIME wMilliseconds(short wMilliseconds) {
/*  480 */       this.io.setShortField(this, 7, wMilliseconds);
/*  481 */       return this;
/*      */     }
/*      */     
/*      */     public final short wMilliseconds_$eq(short wMilliseconds) {
/*  485 */       wMilliseconds(wMilliseconds);
/*  486 */       return wMilliseconds;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class UDATE
/*      */     extends StructObject
/*      */   {
/*      */     @Field(0)
/*      */     public OLEAutomationLibrary.SYSTEMTIME st() {
/*  502 */       return (OLEAutomationLibrary.SYSTEMTIME)this.io.getNativeObjectField(this, 0);
/*      */     }
/*      */ 
/*      */     
/*      */     @Field(1)
/*      */     public short wDayOfYear() {
/*  508 */       return this.io.getShortField(this, 1);
/*      */     }
/*      */ 
/*      */     
/*      */     @Field(1)
/*      */     public UDATE wDayOfYear(short wDayOfYear) {
/*  514 */       this.io.setShortField(this, 1, wDayOfYear);
/*  515 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final short wDayOfYear_$eq(short wDayOfYear) {
/*  520 */       wDayOfYear(wDayOfYear);
/*  521 */       return wDayOfYear;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class NUMPARSE
/*      */     extends StructObject
/*      */   {
/*      */     @Field(0)
/*      */     public int cDig() {
/*  540 */       return this.io.getIntField(this, 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(0)
/*      */     public NUMPARSE cDig(int cDig) {
/*  549 */       this.io.setIntField(this, 0, cDig);
/*  550 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final int cDig_$eq(int cDig) {
/*  555 */       cDig(cDig);
/*  556 */       return cDig;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(1)
/*      */     public int dwInFlags() {
/*  565 */       return this.io.getIntField(this, 1);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(1)
/*      */     public NUMPARSE dwInFlags(int dwInFlags) {
/*  574 */       this.io.setIntField(this, 1, dwInFlags);
/*  575 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final int dwInFlags_$eq(int dwInFlags) {
/*  580 */       dwInFlags(dwInFlags);
/*  581 */       return dwInFlags;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(2)
/*      */     public int dwOutFlags() {
/*  590 */       return this.io.getIntField(this, 2);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(2)
/*      */     public NUMPARSE dwOutFlags(int dwOutFlags) {
/*  599 */       this.io.setIntField(this, 2, dwOutFlags);
/*  600 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final int dwOutFlags_$eq(int dwOutFlags) {
/*  605 */       dwOutFlags(dwOutFlags);
/*  606 */       return dwOutFlags;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(3)
/*      */     public int cchUsed() {
/*  615 */       return this.io.getIntField(this, 3);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(3)
/*      */     public NUMPARSE cchUsed(int cchUsed) {
/*  624 */       this.io.setIntField(this, 3, cchUsed);
/*  625 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final int cchUsed_$eq(int cchUsed) {
/*  630 */       cchUsed(cchUsed);
/*  631 */       return cchUsed;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(4)
/*      */     public int nBaseShift() {
/*  640 */       return this.io.getIntField(this, 4);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(4)
/*      */     public NUMPARSE nBaseShift(int nBaseShift) {
/*  649 */       this.io.setIntField(this, 4, nBaseShift);
/*  650 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final int nBaseShift_$eq(int nBaseShift) {
/*  655 */       nBaseShift(nBaseShift);
/*  656 */       return nBaseShift;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(5)
/*      */     public int nPwr10() {
/*  665 */       return this.io.getIntField(this, 5);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(5)
/*      */     public NUMPARSE nPwr10(int nPwr10) {
/*  674 */       this.io.setIntField(this, 5, nPwr10);
/*  675 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final int nPwr10_$eq(int nPwr10) {
/*  680 */       nPwr10(nPwr10);
/*  681 */       return nPwr10;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class PARAMDATA
/*      */     extends StructObject
/*      */   {
/*      */     @Field(0)
/*      */     public Pointer<Character> szName() {
/*  700 */       return this.io.getPointerField(this, 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(0)
/*      */     public PARAMDATA szName(Pointer<Character> szName) {
/*  709 */       this.io.setPointerField(this, 0, szName);
/*  710 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final Pointer<Character> szName_$eq(Pointer<Character> szName) {
/*  715 */       szName(szName);
/*  716 */       return szName;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(1)
/*      */     public short vt() {
/*  725 */       return this.io.getShortField(this, 1);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(1)
/*      */     public PARAMDATA vt(short vt) {
/*  734 */       this.io.setShortField(this, 1, vt);
/*  735 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final short vt_$eq(short vt) {
/*  740 */       vt(vt);
/*  741 */       return vt;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class METHODDATA
/*      */     extends StructObject
/*      */   {
/*      */     @Field(0)
/*      */     public Pointer<Character> szName() {
/*  760 */       return this.io.getPointerField(this, 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(0)
/*      */     public METHODDATA szName(Pointer<Character> szName) {
/*  769 */       this.io.setPointerField(this, 0, szName);
/*  770 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final Pointer<Character> szName_$eq(Pointer<Character> szName) {
/*  775 */       szName(szName);
/*  776 */       return szName;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(1)
/*      */     public Pointer<OLEAutomationLibrary.PARAMDATA> ppdata() {
/*  785 */       return this.io.getPointerField(this, 1);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(1)
/*      */     public METHODDATA ppdata(Pointer<OLEAutomationLibrary.PARAMDATA> ppdata) {
/*  794 */       this.io.setPointerField(this, 1, ppdata);
/*  795 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final Pointer<OLEAutomationLibrary.PARAMDATA> ppdata_$eq(Pointer<OLEAutomationLibrary.PARAMDATA> ppdata) {
/*  800 */       ppdata(ppdata);
/*  801 */       return ppdata;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CLong
/*      */     @Field(2)
/*      */     public long dispid() {
/*  811 */       return this.io.getCLongField(this, 2);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @CLong
/*      */     @Field(2)
/*      */     public METHODDATA dispid(long dispid) {
/*  821 */       this.io.setCLongField(this, 2, dispid);
/*  822 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final long dispid_$eq(long dispid) {
/*  827 */       dispid(dispid);
/*  828 */       return dispid;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(3)
/*      */     public int iMeth() {
/*  837 */       return this.io.getIntField(this, 3);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(3)
/*      */     public METHODDATA iMeth(int iMeth) {
/*  846 */       this.io.setIntField(this, 3, iMeth);
/*  847 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final int iMeth_$eq(int iMeth) {
/*  852 */       iMeth(iMeth);
/*  853 */       return iMeth;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(4)
/*      */     public ValuedEnum<OLEAutomationLibrary.CALLCONV> cc() {
/*  862 */       return (ValuedEnum<OLEAutomationLibrary.CALLCONV>)this.io.getEnumField(this, 4);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(4)
/*      */     public METHODDATA cc(ValuedEnum<OLEAutomationLibrary.CALLCONV> cc) {
/*  871 */       this.io.setEnumField(this, 4, cc);
/*  872 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final ValuedEnum<OLEAutomationLibrary.CALLCONV> cc_$eq(ValuedEnum<OLEAutomationLibrary.CALLCONV> cc) {
/*  877 */       cc(cc);
/*  878 */       return cc;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(5)
/*      */     public int cArgs() {
/*  887 */       return this.io.getIntField(this, 5);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(5)
/*      */     public METHODDATA cArgs(int cArgs) {
/*  896 */       this.io.setIntField(this, 5, cArgs);
/*  897 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final int cArgs_$eq(int cArgs) {
/*  902 */       cArgs(cArgs);
/*  903 */       return cArgs;
/*      */     }
/*      */ 
/*      */     
/*      */     @Field(6)
/*      */     public short wFlags() {
/*  909 */       return this.io.getShortField(this, 6);
/*      */     }
/*      */ 
/*      */     
/*      */     @Field(6)
/*      */     public METHODDATA wFlags(short wFlags) {
/*  915 */       this.io.setShortField(this, 6, wFlags);
/*  916 */       return this;
/*      */     }
/*      */     
/*      */     public final short wFlags_$eq(short wFlags) {
/*  920 */       wFlags(wFlags);
/*  921 */       return wFlags;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(7)
/*      */     public short vtReturn() {
/*  930 */       return this.io.getShortField(this, 7);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(7)
/*      */     public METHODDATA vtReturn(short vtReturn) {
/*  939 */       this.io.setShortField(this, 7, vtReturn);
/*  940 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final short vtReturn_$eq(short vtReturn) {
/*  945 */       vtReturn(vtReturn);
/*  946 */       return vtReturn;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class INTERFACEDATA
/*      */     extends StructObject
/*      */   {
/*      */     @Field(0)
/*      */     public Pointer<OLEAutomationLibrary.METHODDATA> pmethdata() {
/*  965 */       return this.io.getPointerField(this, 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(0)
/*      */     public INTERFACEDATA pmethdata(Pointer<OLEAutomationLibrary.METHODDATA> pmethdata) {
/*  974 */       this.io.setPointerField(this, 0, pmethdata);
/*  975 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final Pointer<OLEAutomationLibrary.METHODDATA> pmethdata_$eq(Pointer<OLEAutomationLibrary.METHODDATA> pmethdata) {
/*  980 */       pmethdata(pmethdata);
/*  981 */       return pmethdata;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(1)
/*      */     public int cMembers() {
/*  990 */       return this.io.getIntField(this, 1);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Field(1)
/*      */     public INTERFACEDATA cMembers(int cMembers) {
/*  999 */       this.io.setIntField(this, 1, cMembers);
/* 1000 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public final int cMembers_$eq(int cMembers) {
/* 1005 */       cMembers(cMembers);
/* 1006 */       return cMembers;
/*      */     }
/*      */   } }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\com\OLEAutomationLibrary.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */