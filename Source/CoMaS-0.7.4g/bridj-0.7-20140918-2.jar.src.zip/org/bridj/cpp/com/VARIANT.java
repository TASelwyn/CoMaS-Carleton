package org.bridj.cpp.com;

import org.bridj.NativeObject;
import org.bridj.Pointer;
import org.bridj.StructObject;
import org.bridj.ann.CLong;
import org.bridj.ann.Field;
import org.bridj.ann.Runtime;
import org.bridj.ann.Union;

@Runtime(COMRuntime.class)
public class VARIANT extends StructObject {
  public VARIANT(Object value) {
    setValue(value);
  }
  
  public VARIANT() {}
  
  public VARIANT clone() {
    return COMRuntime.clone(this);
  }
  
  @Field(0)
  public __VARIANT_NAME_1_union __VARIANT_NAME_1() {
    return (__VARIANT_NAME_1_union)this.io.getNativeObjectField(this, 0);
  }
  
  @Union
  public static class __VARIANT_NAME_1_union extends StructObject {
    @Field(0)
    public __tagVARIANT __VARIANT_NAME_2() {
      return (__tagVARIANT)this.io.getNativeObjectField(this, 0);
    }
    
    @Field(1)
    public DECIMAL decVal() {
      return (DECIMAL)this.io.getNativeObjectField(this, 1);
    }
    
    public static class __tagVARIANT extends StructObject {
      @Field(0)
      public short vt() {
        return this.io.getShortField(this, 0);
      }
      
      @Field(0)
      public __tagVARIANT vt(short vt) {
        this.io.setShortField(this, 0, vt);
        return this;
      }
      
      public final short vt_$eq(short vt) {
        vt(vt);
        return vt;
      }
      
      @Field(1)
      public short wReserved1() {
        return this.io.getShortField(this, 1);
      }
      
      @Field(1)
      public __tagVARIANT wReserved1(short wReserved1) {
        this.io.setShortField(this, 1, wReserved1);
        return this;
      }
      
      public final short wReserved1_$eq(short wReserved1) {
        wReserved1(wReserved1);
        return wReserved1;
      }
      
      @Field(2)
      public short wReserved2() {
        return this.io.getShortField(this, 2);
      }
      
      @Field(2)
      public __tagVARIANT wReserved2(short wReserved2) {
        this.io.setShortField(this, 2, wReserved2);
        return this;
      }
      
      public final short wReserved2_$eq(short wReserved2) {
        wReserved2(wReserved2);
        return wReserved2;
      }
      
      @Field(3)
      public short wReserved3() {
        return this.io.getShortField(this, 3);
      }
      
      @Field(3)
      public __tagVARIANT wReserved3(short wReserved3) {
        this.io.setShortField(this, 3, wReserved3);
        return this;
      }
      
      public final short wReserved3_$eq(short wReserved3) {
        wReserved3(wReserved3);
        return wReserved3;
      }
      
      @Field(4)
      public __VARIANT_NAME_3_union __VARIANT_NAME_3() {
        return (__VARIANT_NAME_3_union)this.io.getNativeObjectField(this, 4);
      }
      
      @Union
      public static class __VARIANT_NAME_3_union extends StructObject {
        @Field(0)
        public long llval() {
          return this.io.getLongField(this, 0);
        }
        
        @Field(0)
        public __VARIANT_NAME_3_union llval(long llval) {
          this.io.setLongField(this, 0, llval);
          return this;
        }
        
        public final long llval_$eq(long llval) {
          llval(llval);
          return llval;
        }
        
        @CLong
        @Field(1)
        public long lVal() {
          return this.io.getCLongField(this, 1);
        }
        
        @CLong
        @Field(1)
        public __VARIANT_NAME_3_union lVal(long lVal) {
          this.io.setCLongField(this, 1, lVal);
          return this;
        }
        
        public final long lVal_$eq(long lVal) {
          lVal(lVal);
          return lVal;
        }
        
        @Field(2)
        public byte bVal() {
          return this.io.getByteField(this, 2);
        }
        
        @Field(2)
        public __VARIANT_NAME_3_union bVal(byte bVal) {
          this.io.setByteField(this, 2, bVal);
          return this;
        }
        
        public final byte bVal_$eq(byte bVal) {
          bVal(bVal);
          return bVal;
        }
        
        @Field(3)
        public short iVal() {
          return this.io.getShortField(this, 3);
        }
        
        @Field(3)
        public __VARIANT_NAME_3_union iVal(short iVal) {
          this.io.setShortField(this, 3, iVal);
          return this;
        }
        
        public final short iVal_$eq(short iVal) {
          iVal(iVal);
          return iVal;
        }
        
        @Field(4)
        public float fltVal() {
          return this.io.getFloatField(this, 4);
        }
        
        @Field(4)
        public __VARIANT_NAME_3_union fltVal(float fltVal) {
          this.io.setFloatField(this, 4, fltVal);
          return this;
        }
        
        public final float fltVal_$eq(float fltVal) {
          fltVal(fltVal);
          return fltVal;
        }
        
        @Field(5)
        public double dblVal() {
          return this.io.getDoubleField(this, 5);
        }
        
        @Field(5)
        public __VARIANT_NAME_3_union dblVal(double dblVal) {
          this.io.setDoubleField(this, 5, dblVal);
          return this;
        }
        
        public final double dblVal_$eq(double dblVal) {
          dblVal(dblVal);
          return dblVal;
        }
        
        @Field(6)
        public int boolVal() {
          return this.io.getIntField(this, 6);
        }
        
        @Field(6)
        public __VARIANT_NAME_3_union boolVal(int boolVal) {
          this.io.setIntField(this, 6, boolVal);
          return this;
        }
        
        public final int boolVal_$eq(int boolVal) {
          boolVal(boolVal);
          return boolVal;
        }
        
        @Field(7)
        public int bool() {
          return this.io.getIntField(this, 7);
        }
        
        @Field(7)
        public __VARIANT_NAME_3_union bool(int bool) {
          this.io.setIntField(this, 7, bool);
          return this;
        }
        
        public final int bool_$eq(int bool) {
          bool(bool);
          return bool;
        }
        
        @Field(8)
        public int scode() {
          return this.io.getIntField(this, 8);
        }
        
        @Field(8)
        public __VARIANT_NAME_3_union scode(int scode) {
          this.io.setIntField(this, 8, scode);
          return this;
        }
        
        public final int scode_$eq(int scode) {
          scode(scode);
          return scode;
        }
        
        @Field(9)
        public CY cyVal() {
          return (CY)this.io.getNativeObjectField(this, 9);
        }
        
        @Field(10)
        public double date() {
          return this.io.getDoubleField(this, 10);
        }
        
        @Field(10)
        public __VARIANT_NAME_3_union date(double date) {
          this.io.setDoubleField(this, 10, date);
          return this;
        }
        
        public final double date_$eq(double date) {
          date(date);
          return date;
        }
        
        @Field(11)
        public Pointer<Byte> bstrVal() {
          return this.io.getPointerField(this, 11);
        }
        
        @Field(11)
        public __VARIANT_NAME_3_union bstrVal(Pointer<Byte> bstrVal) {
          this.io.setPointerField(this, 11, bstrVal);
          return this;
        }
        
        public final Pointer<Byte> bstrVal_$eq(Pointer<Byte> bstrVal) {
          bstrVal(bstrVal);
          return bstrVal;
        }
        
        @Field(12)
        public Pointer<IUnknown> punkVal() {
          return this.io.getPointerField(this, 12);
        }
        
        @Field(12)
        public __VARIANT_NAME_3_union punkVal(Pointer<IUnknown> punkVal) {
          this.io.setPointerField(this, 12, punkVal);
          return this;
        }
        
        public final Pointer<IUnknown> punkVal_$eq(Pointer<IUnknown> punkVal) {
          punkVal(punkVal);
          return punkVal;
        }
        
        @Field(13)
        public Pointer<IDispatch> pdispVal() {
          return this.io.getPointerField(this, 13);
        }
        
        @Field(13)
        public __VARIANT_NAME_3_union pdispVal(Pointer<IDispatch> pdispVal) {
          this.io.setPointerField(this, 13, pdispVal);
          return this;
        }
        
        public final Pointer<IDispatch> pdispVal_$eq(Pointer<IDispatch> pdispVal) {
          pdispVal(pdispVal);
          return pdispVal;
        }
        
        @Field(14)
        public Pointer<SAFEARRAY> parray() {
          return this.io.getPointerField(this, 14);
        }
        
        @Field(14)
        public __VARIANT_NAME_3_union parray(Pointer<SAFEARRAY> parray) {
          this.io.setPointerField(this, 14, parray);
          return this;
        }
        
        public final Pointer<SAFEARRAY> parray_$eq(Pointer<SAFEARRAY> parray) {
          parray(parray);
          return parray;
        }
        
        @Field(15)
        public Pointer<Byte> pbVal() {
          return this.io.getPointerField(this, 15);
        }
        
        @Field(15)
        public __VARIANT_NAME_3_union pbVal(Pointer<Byte> pbVal) {
          this.io.setPointerField(this, 15, pbVal);
          return this;
        }
        
        public final Pointer<Byte> pbVal_$eq(Pointer<Byte> pbVal) {
          pbVal(pbVal);
          return pbVal;
        }
        
        @Field(16)
        public Pointer<Short> piVal() {
          return this.io.getPointerField(this, 16);
        }
        
        @Field(16)
        public __VARIANT_NAME_3_union piVal(Pointer<Short> piVal) {
          this.io.setPointerField(this, 16, piVal);
          return this;
        }
        
        public final Pointer<Short> piVal_$eq(Pointer<Short> piVal) {
          piVal(piVal);
          return piVal;
        }
        
        @Field(17)
        public Pointer<CLong> plVal() {
          return this.io.getPointerField(this, 17);
        }
        
        @Field(17)
        public __VARIANT_NAME_3_union plVal(Pointer<CLong> plVal) {
          this.io.setPointerField(this, 17, plVal);
          return this;
        }
        
        public final Pointer<CLong> plVal_$eq(Pointer<CLong> plVal) {
          plVal(plVal);
          return plVal;
        }
        
        @Field(18)
        public Pointer<Long> pllVal() {
          return this.io.getPointerField(this, 18);
        }
        
        @Field(18)
        public __VARIANT_NAME_3_union pllVal(Pointer<Long> pllVal) {
          this.io.setPointerField(this, 18, pllVal);
          return this;
        }
        
        public final Pointer<Long> pllVal_$eq(Pointer<Long> pllVal) {
          pllVal(pllVal);
          return pllVal;
        }
        
        @Field(19)
        public Pointer<Float> pfltVal() {
          return this.io.getPointerField(this, 19);
        }
        
        @Field(19)
        public __VARIANT_NAME_3_union pfltVal(Pointer<Float> pfltVal) {
          this.io.setPointerField(this, 19, pfltVal);
          return this;
        }
        
        public final Pointer<Float> pfltVal_$eq(Pointer<Float> pfltVal) {
          pfltVal(pfltVal);
          return pfltVal;
        }
        
        @Field(20)
        public Pointer<Double> pdblVal() {
          return this.io.getPointerField(this, 20);
        }
        
        @Field(20)
        public __VARIANT_NAME_3_union pdblVal(Pointer<Double> pdblVal) {
          this.io.setPointerField(this, 20, pdblVal);
          return this;
        }
        
        public final Pointer<Double> pdblVal_$eq(Pointer<Double> pdblVal) {
          pdblVal(pdblVal);
          return pdblVal;
        }
        
        @Field(21)
        public Pointer<Integer> pboolVal() {
          return this.io.getPointerField(this, 21);
        }
        
        @Field(21)
        public __VARIANT_NAME_3_union pboolVal(Pointer<Integer> pboolVal) {
          this.io.setPointerField(this, 21, pboolVal);
          return this;
        }
        
        public final Pointer<Integer> pboolVal_$eq(Pointer<Integer> pboolVal) {
          pboolVal(pboolVal);
          return pboolVal;
        }
        
        @Field(22)
        public Pointer<Integer> pbool() {
          return this.io.getPointerField(this, 22);
        }
        
        @Field(22)
        public __VARIANT_NAME_3_union pbool(Pointer<Integer> pbool) {
          this.io.setPointerField(this, 22, pbool);
          return this;
        }
        
        public final Pointer<Integer> pbool_$eq(Pointer<Integer> pbool) {
          pbool(pbool);
          return pbool;
        }
        
        @Field(23)
        public Pointer<Integer> pscode() {
          return this.io.getPointerField(this, 23);
        }
        
        @Field(23)
        public __VARIANT_NAME_3_union pscode(Pointer<Integer> pscode) {
          this.io.setPointerField(this, 23, pscode);
          return this;
        }
        
        public final Pointer<Integer> pscode_$eq(Pointer<Integer> pscode) {
          pscode(pscode);
          return pscode;
        }
        
        @Field(24)
        public Pointer<CY> pcyVal() {
          return this.io.getPointerField(this, 24);
        }
        
        @Field(24)
        public __VARIANT_NAME_3_union pcyVal(Pointer<CY> pcyVal) {
          this.io.setPointerField(this, 24, pcyVal);
          return this;
        }
        
        public final Pointer<CY> pcyVal_$eq(Pointer<CY> pcyVal) {
          pcyVal(pcyVal);
          return pcyVal;
        }
        
        @Field(25)
        public Pointer<Double> pdate() {
          return this.io.getPointerField(this, 25);
        }
        
        @Field(25)
        public __VARIANT_NAME_3_union pdate(Pointer<Double> pdate) {
          this.io.setPointerField(this, 25, pdate);
          return this;
        }
        
        public final Pointer<Double> pdate_$eq(Pointer<Double> pdate) {
          pdate(pdate);
          return pdate;
        }
        
        @Field(26)
        public Pointer<Pointer<Byte>> pbstrVal() {
          return this.io.getPointerField(this, 26);
        }
        
        @Field(26)
        public __VARIANT_NAME_3_union pbstrVal(Pointer<Pointer<Byte>> pbstrVal) {
          this.io.setPointerField(this, 26, pbstrVal);
          return this;
        }
        
        public final Pointer<Pointer<Byte>> pbstrVal_$eq(Pointer<Pointer<Byte>> pbstrVal) {
          pbstrVal(pbstrVal);
          return pbstrVal;
        }
        
        @Field(27)
        public Pointer<Pointer<IUnknown>> ppunkVal() {
          return this.io.getPointerField(this, 27);
        }
        
        @Field(27)
        public __VARIANT_NAME_3_union ppunkVal(Pointer<Pointer<IUnknown>> ppunkVal) {
          this.io.setPointerField(this, 27, ppunkVal);
          return this;
        }
        
        public final Pointer<Pointer<IUnknown>> ppunkVal_$eq(Pointer<Pointer<IUnknown>> ppunkVal) {
          ppunkVal(ppunkVal);
          return ppunkVal;
        }
        
        @Field(28)
        public Pointer<Pointer<IDispatch>> ppdispVal() {
          return this.io.getPointerField(this, 28);
        }
        
        @Field(28)
        public __VARIANT_NAME_3_union ppdispVal(Pointer<Pointer<IDispatch>> ppdispVal) {
          this.io.setPointerField(this, 28, ppdispVal);
          return this;
        }
        
        public final Pointer<Pointer<IDispatch>> ppdispVal_$eq(Pointer<Pointer<IDispatch>> ppdispVal) {
          ppdispVal(ppdispVal);
          return ppdispVal;
        }
        
        @Field(29)
        public Pointer<Pointer<SAFEARRAY>> pparray() {
          return this.io.getPointerField(this, 29);
        }
        
        @Field(29)
        public __VARIANT_NAME_3_union pparray(Pointer<Pointer<SAFEARRAY>> pparray) {
          this.io.setPointerField(this, 29, pparray);
          return this;
        }
        
        public final Pointer<Pointer<SAFEARRAY>> pparray_$eq(Pointer<Pointer<SAFEARRAY>> pparray) {
          pparray(pparray);
          return pparray;
        }
        
        @Field(30)
        public Pointer<VARIANT> pvarVal() {
          return this.io.getPointerField(this, 30);
        }
        
        @Field(30)
        public __VARIANT_NAME_3_union pvarVal(Pointer<VARIANT> pvarVal) {
          this.io.setPointerField(this, 30, pvarVal);
          return this;
        }
        
        public final Pointer<VARIANT> pvarVal_$eq(Pointer<VARIANT> pvarVal) {
          pvarVal(pvarVal);
          return pvarVal;
        }
        
        @Field(31)
        public Pointer<Pointer<?>> byref() {
          return this.io.getPointerField(this, 31);
        }
        
        @Field(31)
        public __VARIANT_NAME_3_union byref(Pointer<Pointer<?>> byref) {
          this.io.setPointerField(this, 31, byref);
          return this;
        }
        
        public final Pointer<Pointer<?>> byref_$eq(Pointer<Pointer<?>> byref) {
          byref(byref);
          return byref;
        }
        
        @Field(32)
        public byte cVal() {
          return this.io.getByteField(this, 32);
        }
        
        @Field(32)
        public __VARIANT_NAME_3_union cVal(byte cVal) {
          this.io.setByteField(this, 32, cVal);
          return this;
        }
        
        public final byte cVal_$eq(byte cVal) {
          cVal(cVal);
          return cVal;
        }
        
        @Field(33)
        public short uiVal() {
          return this.io.getShortField(this, 33);
        }
        
        @Field(33)
        public __VARIANT_NAME_3_union uiVal(short uiVal) {
          this.io.setShortField(this, 33, uiVal);
          return this;
        }
        
        public final short uiVal_$eq(short uiVal) {
          uiVal(uiVal);
          return uiVal;
        }
        
        @Field(34)
        public int ulVal() {
          return this.io.getIntField(this, 34);
        }
        
        @Field(34)
        public __VARIANT_NAME_3_union ulVal(int ulVal) {
          this.io.setIntField(this, 34, ulVal);
          return this;
        }
        
        public final int ulVal_$eq(int ulVal) {
          ulVal(ulVal);
          return ulVal;
        }
        
        @Field(35)
        public long ullVal() {
          return this.io.getLongField(this, 35);
        }
        
        @Field(35)
        public __VARIANT_NAME_3_union ullVal(long ullVal) {
          this.io.setLongField(this, 35, ullVal);
          return this;
        }
        
        public final long ullVal_$eq(long ullVal) {
          ullVal(ullVal);
          return ullVal;
        }
        
        @Field(36)
        public int intVal() {
          return this.io.getIntField(this, 36);
        }
        
        @Field(36)
        public __VARIANT_NAME_3_union intVal(int intVal) {
          this.io.setIntField(this, 36, intVal);
          return this;
        }
        
        public final int intVal_$eq(int intVal) {
          intVal(intVal);
          return intVal;
        }
        
        @Field(37)
        public int uintVal() {
          return this.io.getIntField(this, 37);
        }
        
        @Field(37)
        public __VARIANT_NAME_3_union uintVal(int uintVal) {
          this.io.setIntField(this, 37, uintVal);
          return this;
        }
        
        public final int uintVal_$eq(int uintVal) {
          uintVal(uintVal);
          return uintVal;
        }
        
        @Field(38)
        public Pointer<DECIMAL> pdecVal() {
          return this.io.getPointerField(this, 38);
        }
        
        @Field(38)
        public __VARIANT_NAME_3_union pdecVal(Pointer<DECIMAL> pdecVal) {
          this.io.setPointerField(this, 38, pdecVal);
          return this;
        }
        
        public final Pointer<DECIMAL> pdecVal_$eq(Pointer<DECIMAL> pdecVal) {
          pdecVal(pdecVal);
          return pdecVal;
        }
        
        @Field(39)
        public Pointer<Byte> pcVal() {
          return this.io.getPointerField(this, 39);
        }
        
        @Field(39)
        public __VARIANT_NAME_3_union pcVal(Pointer<Byte> pcVal) {
          this.io.setPointerField(this, 39, pcVal);
          return this;
        }
        
        public final Pointer<Byte> pcVal_$eq(Pointer<Byte> pcVal) {
          pcVal(pcVal);
          return pcVal;
        }
        
        @Field(40)
        public Pointer<Short> puiVal() {
          return this.io.getPointerField(this, 40);
        }
        
        @Field(40)
        public __VARIANT_NAME_3_union puiVal(Pointer<Short> puiVal) {
          this.io.setPointerField(this, 40, puiVal);
          return this;
        }
        
        public final Pointer<Short> puiVal_$eq(Pointer<Short> puiVal) {
          puiVal(puiVal);
          return puiVal;
        }
        
        @Field(41)
        public Pointer<Integer> pulVal() {
          return this.io.getPointerField(this, 41);
        }
        
        @Field(41)
        public __VARIANT_NAME_3_union pulVal(Pointer<Integer> pulVal) {
          this.io.setPointerField(this, 41, pulVal);
          return this;
        }
        
        public final Pointer<Integer> pulVal_$eq(Pointer<Integer> pulVal) {
          pulVal(pulVal);
          return pulVal;
        }
        
        @Field(42)
        public Pointer<Long> pullVal() {
          return this.io.getPointerField(this, 42);
        }
        
        @Field(42)
        public __VARIANT_NAME_3_union pullVal(Pointer<Long> pullVal) {
          this.io.setPointerField(this, 42, pullVal);
          return this;
        }
        
        public final Pointer<Long> pullVal_$eq(Pointer<Long> pullVal) {
          pullVal(pullVal);
          return pullVal;
        }
        
        @Field(43)
        public Pointer<Integer> pintVal() {
          return this.io.getPointerField(this, 43);
        }
        
        @Field(43)
        public __VARIANT_NAME_3_union pintVal(Pointer<Integer> pintVal) {
          this.io.setPointerField(this, 43, pintVal);
          return this;
        }
        
        public final Pointer<Integer> pintVal_$eq(Pointer<Integer> pintVal) {
          pintVal(pintVal);
          return pintVal;
        }
        
        @Field(44)
        public Pointer<Integer> puintVal() {
          return this.io.getPointerField(this, 44);
        }
        
        @Field(44)
        public __VARIANT_NAME_3_union puintVal(Pointer<Integer> puintVal) {
          this.io.setPointerField(this, 44, puintVal);
          return this;
        }
        
        public final Pointer<Integer> puintVal_$eq(Pointer<Integer> puintVal) {
          puintVal(puintVal);
          return puintVal;
        }
        
        @Field(45)
        public __tagBRECORD __VARIANT_NAME_4() {
          return (__tagBRECORD)this.io.getNativeObjectField(this, 45);
        }
        
        public static class __tagBRECORD extends StructObject {
          @Field(0)
          public Pointer<?> pvRecord() {
            return this.io.getPointerField(this, 0);
          }
          
          @Field(0)
          public __tagBRECORD pvRecord(Pointer<?> pvRecord) {
            this.io.setPointerField(this, 0, pvRecord);
            return this;
          }
          
          public final Pointer<?> pvRecord_$eq(Pointer<?> pvRecord) {
            pvRecord(pvRecord);
            return pvRecord;
          }
          
          @Field(1)
          public Pointer<IRecordInfo> pRecInfo() {
            return this.io.getPointerField(this, 1);
          }
          
          @Field(1)
          public __tagBRECORD pRecInfo(Pointer<IRecordInfo> pRecInfo) {
            this.io.setPointerField(this, 1, pRecInfo);
            return this;
          }
          
          public final Pointer<IRecordInfo> pRecInfo_$eq(Pointer<IRecordInfo> pRecInfo) {
            pRecInfo(pRecInfo);
            return pRecInfo;
          }
        }
      }
    }
  }
  
  public Object getValue() {
    return COMRuntime.getValue(this);
  }
  
  public VARIANT setValue(Object value) {
    return COMRuntime.setValue(this, value);
  }
  
  public String toString() {
    return COMRuntime.toString(this);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\com\VARIANT.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */