package org.bridj.cpp.com;

import org.bridj.Pointer;

public class COMCallableWrapper extends IDispatch {
  Object instance;
  
  public COMCallableWrapper(Object instance) {
    this.instance = instance;
  }
  
  public int GetIDsOfNames(Pointer riid, Pointer<Pointer<Character>> rgszNames, int cNames, int lcid, Pointer<Integer> rgDispId) {
    return -2147467263;
  }
  
  public int Invoke(int dispIdMember, Pointer<Byte> riid, int lcid, short wFlags, Pointer<IDispatch.DISPPARAMS> pDispParams, Pointer<VARIANT> pVarResult, Pointer<IDispatch.EXCEPINFO> pExcepInfo, Pointer<Integer> puArgErr) {
    return -2147467263;
  }
  
  public int GetTypeInfo(int iTInfo, int lcid, Pointer<Pointer<ITypeInfo>> ppTInfo) {
    return -2147467263;
  }
  
  public int GetTypeInfoCount(Pointer<Integer> pctinfo) {
    return -2147467263;
  }
}
