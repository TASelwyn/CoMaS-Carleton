/*    */ package org.bridj.cpp.com;
/*    */ 
/*    */ import org.bridj.Pointer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class COMCallableWrapper
/*    */   extends IDispatch
/*    */ {
/*    */   Object instance;
/*    */   
/*    */   public COMCallableWrapper(Object instance) {
/* 45 */     this.instance = instance;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int GetIDsOfNames(Pointer riid, Pointer<Pointer<Character>> rgszNames, int cNames, int lcid, Pointer<Integer> rgDispId) {
/* 55 */     return -2147467263;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int Invoke(int dispIdMember, Pointer<Byte> riid, int lcid, short wFlags, Pointer<IDispatch.DISPPARAMS> pDispParams, Pointer<VARIANT> pVarResult, Pointer<IDispatch.EXCEPINFO> pExcepInfo, Pointer<Integer> puArgErr) {
/* 65 */     return -2147467263;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int GetTypeInfo(int iTInfo, int lcid, Pointer<Pointer<ITypeInfo>> ppTInfo) {
/* 72 */     return -2147467263;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int GetTypeInfoCount(Pointer<Integer> pctinfo) {
/* 78 */     return -2147467263;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\com\COMCallableWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */