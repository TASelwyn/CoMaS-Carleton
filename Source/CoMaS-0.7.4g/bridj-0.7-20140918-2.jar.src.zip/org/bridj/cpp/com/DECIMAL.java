/*     */ package org.bridj.cpp.com;
/*     */ 
/*     */ import org.bridj.CRuntime;
/*     */ import org.bridj.StructObject;
/*     */ import org.bridj.ann.Field;
/*     */ import org.bridj.ann.Runtime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Runtime(CRuntime.class)
/*     */ public class DECIMAL
/*     */   extends StructObject
/*     */ {
/*     */   @Field(0)
/*     */   public short wReserved() {
/*  56 */     return this.io.getShortField(this, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   @Field(0)
/*     */   public DECIMAL wReserved(short wReserved) {
/*  62 */     this.io.setShortField(this, 0, wReserved);
/*  63 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final short wReserved_$eq(short wReserved) {
/*  68 */     wReserved(wReserved);
/*  69 */     return wReserved;
/*     */   }
/*     */   
/*     */   @Field(1)
/*     */   public byte scale() {
/*  74 */     return this.io.getByteField(this, 1);
/*     */   }
/*     */   
/*     */   @Field(1)
/*     */   public DECIMAL scale(byte scale) {
/*  79 */     this.io.setByteField(this, 1, scale);
/*  80 */     return this;
/*     */   }
/*     */   
/*     */   public final byte scale_$eq(byte scale) {
/*  84 */     scale(scale);
/*  85 */     return scale;
/*     */   }
/*     */   
/*     */   @Field(2)
/*     */   public byte sign() {
/*  90 */     return this.io.getByteField(this, 2);
/*     */   }
/*     */   
/*     */   @Field(2)
/*     */   public DECIMAL sign(byte sign) {
/*  95 */     this.io.setByteField(this, 2, sign);
/*  96 */     return this;
/*     */   }
/*     */   
/*     */   public final byte sign_$eq(byte sign) {
/* 100 */     sign(sign);
/* 101 */     return sign;
/*     */   }
/*     */ 
/*     */   
/*     */   @Field(3)
/*     */   public int Hi32() {
/* 107 */     return this.io.getIntField(this, 3);
/*     */   }
/*     */ 
/*     */   
/*     */   @Field(3)
/*     */   public DECIMAL Hi32(int Hi32) {
/* 113 */     this.io.setIntField(this, 3, Hi32);
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int Hi32_$eq(int Hi32) {
/* 119 */     Hi32(Hi32);
/* 120 */     return Hi32;
/*     */   }
/*     */   
/*     */   @Field(4)
/*     */   public long Lo64() {
/* 125 */     return this.io.getLongField(this, 4);
/*     */   }
/*     */   
/*     */   @Field(4)
/*     */   public DECIMAL Lo64(long Lo64) {
/* 130 */     this.io.setLongField(this, 4, Lo64);
/* 131 */     return this;
/*     */   }
/*     */   
/*     */   public final long Lo64_$eq(long Lo64) {
/* 135 */     Lo64(Lo64);
/* 136 */     return Lo64;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\com\DECIMAL.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */