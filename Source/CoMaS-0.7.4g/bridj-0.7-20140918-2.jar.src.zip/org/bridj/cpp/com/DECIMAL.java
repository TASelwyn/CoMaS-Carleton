package org.bridj.cpp.com;

import org.bridj.CRuntime;
import org.bridj.StructObject;
import org.bridj.ann.Field;
import org.bridj.ann.Runtime;

@Runtime(CRuntime.class)
public class DECIMAL extends StructObject {
  @Field(0)
  public short wReserved() {
    return this.io.getShortField(this, 0);
  }
  
  @Field(0)
  public DECIMAL wReserved(short wReserved) {
    this.io.setShortField(this, 0, wReserved);
    return this;
  }
  
  public final short wReserved_$eq(short wReserved) {
    wReserved(wReserved);
    return wReserved;
  }
  
  @Field(1)
  public byte scale() {
    return this.io.getByteField(this, 1);
  }
  
  @Field(1)
  public DECIMAL scale(byte scale) {
    this.io.setByteField(this, 1, scale);
    return this;
  }
  
  public final byte scale_$eq(byte scale) {
    scale(scale);
    return scale;
  }
  
  @Field(2)
  public byte sign() {
    return this.io.getByteField(this, 2);
  }
  
  @Field(2)
  public DECIMAL sign(byte sign) {
    this.io.setByteField(this, 2, sign);
    return this;
  }
  
  public final byte sign_$eq(byte sign) {
    sign(sign);
    return sign;
  }
  
  @Field(3)
  public int Hi32() {
    return this.io.getIntField(this, 3);
  }
  
  @Field(3)
  public DECIMAL Hi32(int Hi32) {
    this.io.setIntField(this, 3, Hi32);
    return this;
  }
  
  public final int Hi32_$eq(int Hi32) {
    Hi32(Hi32);
    return Hi32;
  }
  
  @Field(4)
  public long Lo64() {
    return this.io.getLongField(this, 4);
  }
  
  @Field(4)
  public DECIMAL Lo64(long Lo64) {
    this.io.setLongField(this, 4, Lo64);
    return this;
  }
  
  public final long Lo64_$eq(long Lo64) {
    Lo64(Lo64);
    return Lo64;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\com\DECIMAL.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */