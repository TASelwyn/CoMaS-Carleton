/*     */ package org.bridj.cpp.com;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import org.bridj.FlagSet;
/*     */ import org.bridj.IntValuedEnum;
/*     */ import org.bridj.ValuedEnum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum VARENUM
/*     */   implements IntValuedEnum<VARENUM>
/*     */ {
/*  42 */   VT_EMPTY(0L),
/*  43 */   VT_NULL(1L),
/*  44 */   VT_I2(2L),
/*  45 */   VT_I4(3L),
/*  46 */   VT_R4(4L),
/*  47 */   VT_R8(5L),
/*  48 */   VT_CY(6L),
/*  49 */   VT_DATE(7L),
/*  50 */   VT_BSTR(8L),
/*  51 */   VT_DISPATCH(9L),
/*  52 */   VT_ERROR(10L),
/*  53 */   VT_BOOL(11L),
/*  54 */   VT_VARIANT(12L),
/*  55 */   VT_UNKNOWN(13L),
/*  56 */   VT_DECIMAL(14L),
/*  57 */   VT_I1(16L),
/*  58 */   VT_UI1(17L),
/*  59 */   VT_UI2(18L),
/*  60 */   VT_UI4(19L),
/*  61 */   VT_I8(20L),
/*  62 */   VT_UI8(21L),
/*  63 */   VT_INT(22L),
/*  64 */   VT_UINT(23L),
/*  65 */   VT_VOID(24L),
/*  66 */   VT_HRESULT(25L),
/*  67 */   VT_PTR(26L),
/*  68 */   VT_SAFEARRAY(27L),
/*  69 */   VT_CARRAY(28L),
/*  70 */   VT_USERDEFINED(29L),
/*  71 */   VT_LPSTR(30L),
/*  72 */   VT_LPWSTR(31L),
/*  73 */   VT_FILETIME(64L),
/*  74 */   VT_BLOB(65L),
/*  75 */   VT_STREAM(66L),
/*  76 */   VT_STORAGE(67L),
/*  77 */   VT_STREAMED_OBJECT(68L),
/*  78 */   VT_STORED_OBJECT(69L),
/*  79 */   VT_BLOB_OBJECT(70L),
/*  80 */   VT_CF(71L),
/*  81 */   VT_CLSID(72L),
/*  82 */   VT_VECTOR(4096L),
/*  83 */   VT_ARRAY(8192L),
/*  84 */   VT_BYREF(16384L),
/*  85 */   VT_RESERVED(32768L),
/*  86 */   VT_ILLEGAL(65535L),
/*  87 */   VT_ILLEGALMASKED(4095L),
/*  88 */   VT_TYPEMASK(4095L);
/*     */   
/*     */   VARENUM(long value) {
/*  91 */     this.value = value;
/*     */   }
/*     */   public final long value;
/*     */   
/*     */   public long value() {
/*  96 */     return this.value;
/*     */   }
/*     */   
/*     */   public Iterator<VARENUM> iterator() {
/* 100 */     return Collections.<VARENUM>singleton(this).iterator();
/*     */   }
/*     */   
/*     */   public static ValuedEnum<VARENUM> fromValue(long value) {
/* 104 */     return FlagSet.fromValue(value, (Enum[])values());
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\com\VARENUM.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */