package org.bridj.cpp.com.shell;

import org.bridj.cpp.com.CLSID;
import org.bridj.cpp.com.IDispatch;
import org.bridj.cpp.com.IID;

@IID("85CB6900-4D95-11CF-960C-0080C7F4EE85")
@CLSID("9BA05972-F6A8-11CF-A442-00A0C90A8F39")
public class IShellWindows extends IDispatch {}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\com\shell\IShellWindows.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */