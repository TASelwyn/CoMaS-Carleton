/*     */ package org.bridj.cpp.com.shell;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import org.bridj.FlagSet;
/*     */ import org.bridj.IntValuedEnum;
/*     */ import org.bridj.Pointer;
/*     */ import org.bridj.ValuedEnum;
/*     */ import org.bridj.ann.Array;
/*     */ import org.bridj.ann.Field;
/*     */ import org.bridj.ann.Virtual;
/*     */ 
/*     */ @IID("EA1AFB91-9E28-4B86-90E9-9E9F8A5EEFAF")
/*     */ @CLSID("56FDF344-FD6D-11d0-958A-006097C9A090")
/*     */ public class ITaskbarList3 extends ITaskbarList2 {
/*     */   @Virtual(0)
/*     */   public native int SetProgressValue(Pointer<Integer> paramPointer, long paramLong1, long paramLong2);
/*     */   
/*     */   @Virtual(1)
/*     */   public native int SetProgressState(Pointer<Integer> paramPointer, ValuedEnum<TbpFlag> paramValuedEnum);
/*     */   
/*     */   @Virtual(2)
/*     */   public native void RegisterTab(Pointer<Integer> paramPointer1, Pointer<Integer> paramPointer2);
/*     */   
/*     */   @Virtual(3)
/*     */   public native void UnregisterTab(Pointer<Integer> paramPointer);
/*     */   
/*     */   @Virtual(4)
/*     */   public native void SetTabOrder(Pointer<Integer> paramPointer1, Pointer<Integer> paramPointer2);
/*     */   
/*     */   @Virtual(5)
/*     */   public native void SetTabActive(Pointer<Integer> paramPointer1, Pointer<Integer> paramPointer2, int paramInt);
/*     */   
/*     */   @Virtual(6)
/*     */   public native void ThumbBarAddButtons(Pointer<Integer> paramPointer, int paramInt, Pointer<THUMBBUTTON> paramPointer1);
/*     */   
/*     */   @Virtual(7)
/*     */   public native void ThumbBarUpdateButtons(Pointer<Integer> paramPointer, int paramInt, Pointer<THUMBBUTTON> paramPointer1);
/*     */   
/*     */   @Virtual(8)
/*     */   public native void ThumbBarSetImageList(Pointer<Integer> paramPointer1, Pointer<Integer> paramPointer2);
/*     */   
/*     */   @Virtual(9)
/*     */   public native void SetOverlayIcon(Pointer<Integer> paramPointer, Pointer<?> paramPointer1, Pointer<Character> paramPointer2);
/*     */   
/*     */   @Virtual(10)
/*     */   public native void SetThumbnailTooltip(Pointer<Integer> paramPointer, Pointer<Character> paramPointer1);
/*     */   
/*     */   @Virtual(11)
/*     */   public native void SetThumbnailClip(Pointer<Integer> paramPointer, Pointer<RECT> paramPointer1);
/*     */   
/*     */   public enum THUMBBUTTONMASK implements IntValuedEnum<THUMBBUTTONMASK> {
/*  52 */     THB_BITMAP(1),
/*  53 */     THB_ICON(2),
/*  54 */     THB_TOOLTIP(4),
/*  55 */     THB_FLAGS(8); public final int value;
/*     */     
/*     */     THUMBBUTTONMASK(int value) {
/*  58 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long value() {
/*  64 */       return this.value;
/*     */     }
/*     */     
/*     */     public Iterator<THUMBBUTTONMASK> iterator() {
/*  68 */       return Collections.<THUMBBUTTONMASK>singleton(this).iterator();
/*     */     }
/*     */     
/*     */     public static ValuedEnum<THUMBBUTTONMASK> fromValue(long value) {
/*  72 */       return FlagSet.fromValue(value, (Enum[])values());
/*     */     }
/*     */   }
/*     */   
/*     */   public enum THUMBBUTTONFLAGS
/*     */     implements IntValuedEnum<THUMBBUTTONFLAGS>
/*     */   {
/*  79 */     THBF_ENABLED(0),
/*  80 */     THBF_DISABLED(1),
/*  81 */     THBF_DISMISSONCLICK(2),
/*  82 */     THBF_NOBACKGROUND(4),
/*  83 */     THBF_HIDDEN(8),
/*  84 */     THBF_NONINTERACTIVE(16); final int value;
/*     */     
/*     */     THUMBBUTTONFLAGS(int value) {
/*  87 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long value() {
/*  93 */       return this.value;
/*     */     }
/*     */     
/*     */     public Iterator<THUMBBUTTONFLAGS> iterator() {
/*  97 */       return Collections.<THUMBBUTTONFLAGS>singleton(this).iterator();
/*     */     }
/*     */     
/*     */     public static ValuedEnum<THUMBBUTTONFLAGS> fromValue(long value) {
/* 101 */       return FlagSet.fromValue(value, (Enum[])values());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class THUMBBUTTON
/*     */     extends StructObject
/*     */   {
/*     */     @Field(0)
/*     */     public native ValuedEnum<ITaskbarList3.THUMBBUTTONMASK> dwMask();
/*     */     
/*     */     public native void dwMask(ValuedEnum<ITaskbarList3.THUMBBUTTONMASK> param1ValuedEnum);
/*     */     
/*     */     @Field(1)
/*     */     public native int iId();
/*     */     
/*     */     public native void iId(int param1Int);
/*     */     
/*     */     @Field(2)
/*     */     public native int iBitmap();
/*     */     
/*     */     public native void iBitmap(int param1Int);
/*     */     
/*     */     @Field(3)
/*     */     public native Pointer<?> hIcon();
/*     */     
/*     */     public native void hIcon(Pointer<?> param1Pointer);
/*     */     
/*     */     @Field(4)
/*     */     @Array({260L})
/*     */     public native Pointer<Character> szTip();
/*     */     
/*     */     public native void szTip(Pointer<Character> param1Pointer);
/*     */     
/*     */     @Field(5)
/*     */     public native ValuedEnum<ITaskbarList3.THUMBBUTTONFLAGS> dwFlags();
/*     */     
/*     */     public native void dwFlags(ValuedEnum<ITaskbarList3.THUMBBUTTONFLAGS> param1ValuedEnum);
/*     */   }
/*     */   
/*     */   public enum TbpFlag
/*     */     implements IntValuedEnum<TbpFlag>
/*     */   {
/* 144 */     TBPF_NOPROGRESS(0),
/* 145 */     TBPF_INDETERMINATE(1),
/* 146 */     TBPF_NORMAL(2),
/* 147 */     TBPF_ERROR(4),
/* 148 */     TBPF_PAUSED(8); public final int value;
/*     */     
/*     */     TbpFlag(int value) {
/* 151 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long value() {
/* 157 */       return this.value;
/*     */     }
/*     */     
/*     */     public Iterator<TbpFlag> iterator() {
/* 161 */       return Collections.<TbpFlag>singleton(this).iterator();
/*     */     }
/*     */     
/*     */     public static ValuedEnum<TbpFlag> fromValue(long value) {
/* 165 */       return FlagSet.fromValue(value, (Enum[])values());
/*     */     }
/*     */   }
/*     */   
/*     */   public class RECT {}
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\com\shell\ITaskbarList3.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */