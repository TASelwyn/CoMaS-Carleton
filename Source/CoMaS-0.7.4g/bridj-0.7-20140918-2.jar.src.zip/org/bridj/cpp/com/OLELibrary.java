package org.bridj.cpp.com;

import org.bridj.BridJ;
import org.bridj.Pointer;
import org.bridj.ann.Library;
import org.bridj.ann.Name;
import org.bridj.ann.Ptr;
import org.bridj.ann.Runtime;
import org.bridj.cpp.CPPRuntime;

@Library("ole32")
@Runtime(CPPRuntime.class)
public class OLELibrary {
  static {
    BridJ.register();
  }
  
  public static void CoTaskMemFree(Pointer<?> ptr) {
    CoTaskMemFree(Pointer.getPeer(ptr));
  }
  
  public static Pointer<?> CoTaskMemRealloc(Pointer<?> ptr, @Ptr long cb) {
    return Pointer.pointerToAddress(CoTaskMemRealloc(Pointer.getPeer(ptr), cb));
  }
  
  public static native Pointer<?> CoTaskMemAlloc(@Ptr long paramLong);
  
  @Name("CoTaskMemAlloc")
  @Ptr
  public static native long CoTaskMemAlloc$raw(@Ptr long paramLong);
  
  public static native void CoTaskMemFree(@Ptr long paramLong);
  
  @Ptr
  public static native long CoTaskMemRealloc(@Ptr long paramLong1, @Ptr long paramLong2);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\cpp\com\OLELibrary.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */