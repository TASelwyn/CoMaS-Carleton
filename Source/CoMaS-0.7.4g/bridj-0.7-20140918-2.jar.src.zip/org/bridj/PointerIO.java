package org.bridj;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.nio.Buffer;
import java.util.concurrent.ConcurrentHashMap;
import org.bridj.util.Utils;

public abstract class PointerIO<T> {
  final Type targetType;
  
  final Class<?> typedPointerClass;
  
  final int targetSize;
  
  final int targetAlignment = -1;
  
  public PointerIO(Type targetType, int targetSize, Class<?> typedPointerClass) {
    this.targetType = targetType;
    this.targetSize = targetSize;
    this.typedPointerClass = typedPointerClass;
  }
  
  public Object getArray(Pointer<T> pointer, long byteOffset, int length) {
    return pointer.offset(byteOffset).toArray(length);
  }
  
  public <B extends Buffer> B getBuffer(Pointer<T> pointer, long byteOffset, int length) {
    throw new UnsupportedOperationException("Cannot create a Buffer instance of elements of type " + getTargetType());
  }
  
  public void setArray(Pointer<T> pointer, long byteOffset, Object array) {
    Object[] a = (Object[])array;
    for (int i = 0, n = a.length; i < n; i++)
      set(pointer, i, (T)a[i]); 
  }
  
  public T castTarget(long peer) {
    throw new UnsupportedOperationException("Cannot cast pointer to " + this.targetType);
  }
  
  PointerIO<Pointer<T>> getReferenceIO() {
    return new CommonPointerIOs.PointerPointerIO<T>(this);
  }
  
  public long getTargetSize() {
    return this.targetSize;
  }
  
  public long getTargetAlignment() {
    return getTargetSize();
  }
  
  public boolean isTypedPointer() {
    return (this.typedPointerClass != null);
  }
  
  public Class<?> getTypedPointerClass() {
    return this.typedPointerClass;
  }
  
  public Type getTargetType() {
    return this.targetType;
  }
  
  static Class<?> getClass(Type type) {
    if (type instanceof Class)
      return (Class)type; 
    if (type instanceof ParameterizedType)
      return getClass(((ParameterizedType)type).getRawType()); 
    return null;
  }
  
  private static final PointerIO<Pointer> PointerIO = (PointerIO)getPointerInstance((PointerIO)null);
  
  public static <T> PointerIO<Pointer<T>> getPointerInstance(Type target) {
    return getPointerInstance(getInstance(target));
  }
  
  public static <T> PointerIO<Pointer<T>> getPointerInstance(PointerIO<T> targetIO) {
    return new CommonPointerIOs.PointerPointerIO<T>(targetIO);
  }
  
  public static <T> PointerIO<Pointer<T>> getArrayInstance(PointerIO<T> targetIO, long[] dimensions, int iDimension) {
    return new CommonPointerIOs.PointerArrayIO<T>(targetIO, dimensions, iDimension);
  }
  
  static <T> PointerIO<T> getArrayIO(Object array) {
    if (array instanceof int[])
      return (PointerIO)CommonPointerIOs.intIO; 
    if (array instanceof long[])
      return (PointerIO)CommonPointerIOs.longIO; 
    if (array instanceof short[])
      return (PointerIO)CommonPointerIOs.shortIO; 
    if (array instanceof byte[])
      return (PointerIO)CommonPointerIOs.byteIO; 
    if (array instanceof char[])
      return (PointerIO)CommonPointerIOs.charIO; 
    if (array instanceof float[])
      return (PointerIO)CommonPointerIOs.floatIO; 
    if (array instanceof double[])
      return (PointerIO)CommonPointerIOs.doubleIO; 
    if (array instanceof boolean[])
      return (PointerIO)CommonPointerIOs.booleanIO; 
    return getInstance(array.getClass().getComponentType());
  }
  
  private static final ConcurrentHashMap<StructIO, PointerIO<?>> structIOs = new ConcurrentHashMap<StructIO, PointerIO<?>>();
  
  public static <S extends StructObject> PointerIO<S> getInstance(StructIO s) {
    PointerIO<StructObject> io = (PointerIO)structIOs.get(s);
    if (io == null) {
      io = new CommonPointerIOs.StructPointerIO<StructObject>(s);
      PointerIO<StructObject> previousIO = (PointerIO)structIOs.putIfAbsent(s, io);
      if (previousIO != null)
        io = previousIO; 
    } 
    return (PointerIO)io;
  }
  
  private static final ConcurrentHashMap<Type, PointerIO<?>> ios = new ConcurrentHashMap<Type, PointerIO<?>>();
  
  static {
    ios.put(Pointer.class, PointerIO);
    ios.put(SizeT.class, CommonPointerIOs.SizeTIO);
    ios.put(TimeT.class, CommonPointerIOs.TimeTIO);
    ios.put(CLong.class, CommonPointerIOs.CLongIO);
    PointerIO<Integer> pointerIO6 = CommonPointerIOs.intIO;
    ios.put(int.class, pointerIO6);
    ios.put(Integer.class, pointerIO6);
    PointerIO<Long> pointerIO5 = CommonPointerIOs.longIO;
    ios.put(long.class, pointerIO5);
    ios.put(Long.class, pointerIO5);
    PointerIO<Short> pointerIO4 = CommonPointerIOs.shortIO;
    ios.put(short.class, pointerIO4);
    ios.put(Short.class, pointerIO4);
    PointerIO<Byte> pointerIO3 = CommonPointerIOs.byteIO;
    ios.put(byte.class, pointerIO3);
    ios.put(Byte.class, pointerIO3);
    PointerIO<Character> pointerIO2 = CommonPointerIOs.charIO;
    ios.put(char.class, pointerIO2);
    ios.put(Character.class, pointerIO2);
    PointerIO<Float> pointerIO1 = CommonPointerIOs.floatIO;
    ios.put(float.class, pointerIO1);
    ios.put(Float.class, pointerIO1);
    PointerIO<Double> pointerIO = CommonPointerIOs.doubleIO;
    ios.put(double.class, pointerIO);
    ios.put(Double.class, pointerIO);
    PointerIO<Boolean> io = CommonPointerIOs.booleanIO;
    ios.put(boolean.class, io);
    ios.put(Boolean.class, io);
  }
  
  public static <P> PointerIO<P> getInstance(Type type) {
    if (type == null)
      return null; 
    PointerIO<Pointer<?>> io = (PointerIO)ios.get(type);
    if (io == null) {
      Class<?> cl = Utils.getClass(type);
      if (cl != null)
        if (cl == Pointer.class) {
          io = getPointerInstance(((ParameterizedType)type).getActualTypeArguments()[0]);
        } else if (StructObject.class.isAssignableFrom(cl)) {
          io = getInstance(StructIO.getInstance(cl, type));
        } else if (Callback.class.isAssignableFrom(cl)) {
          io = new CommonPointerIOs.CallbackPointerIO(cl);
        } else if (NativeObject.class.isAssignableFrom(cl)) {
          io = new CommonPointerIOs.NativeObjectPointerIO<Pointer<?>>(type);
        } else if (IntValuedEnum.class.isAssignableFrom(cl)) {
          if (type instanceof ParameterizedType) {
            Type enumType = ((ParameterizedType)type).getActualTypeArguments()[0];
            if (enumType instanceof Class)
              io = new CommonPointerIOs.IntValuedEnumPointerIO((Class)enumType); 
          } 
        } else if (TypedPointer.class.isAssignableFrom(cl)) {
          io = new CommonPointerIOs.TypedPointerPointerIO(cl);
        }  
      if (io != null) {
        PointerIO<Pointer<?>> previousIO = (PointerIO)ios.putIfAbsent(type, io);
        if (previousIO != null)
          io = previousIO; 
      } 
    } 
    return (PointerIO)io;
  }
  
  public static PointerIO<Integer> getIntInstance() {
    return CommonPointerIOs.intIO;
  }
  
  public static PointerIO<Long> getLongInstance() {
    return CommonPointerIOs.longIO;
  }
  
  public static PointerIO<Short> getShortInstance() {
    return CommonPointerIOs.shortIO;
  }
  
  public static PointerIO<Byte> getByteInstance() {
    return CommonPointerIOs.byteIO;
  }
  
  public static PointerIO<Character> getCharInstance() {
    return CommonPointerIOs.charIO;
  }
  
  public static PointerIO<Float> getFloatInstance() {
    return CommonPointerIOs.floatIO;
  }
  
  public static PointerIO<Double> getDoubleInstance() {
    return CommonPointerIOs.doubleIO;
  }
  
  public static PointerIO<Boolean> getBooleanInstance() {
    return CommonPointerIOs.booleanIO;
  }
  
  public static PointerIO<CLong> getCLongInstance() {
    return CommonPointerIOs.CLongIO;
  }
  
  public static PointerIO<SizeT> getSizeTInstance() {
    return CommonPointerIOs.SizeTIO;
  }
  
  public static PointerIO<Pointer> getPointerInstance() {
    return PointerIO;
  }
  
  public static PointerIO<TimeT> getTimeTInstance() {
    return CommonPointerIOs.TimeTIO;
  }
  
  public static <P> PointerIO<P> getBufferPrimitiveInstance(Buffer buffer) {
    if (buffer instanceof java.nio.IntBuffer)
      return (PointerIO)CommonPointerIOs.intIO; 
    if (buffer instanceof java.nio.LongBuffer)
      return (PointerIO)CommonPointerIOs.longIO; 
    if (buffer instanceof java.nio.ShortBuffer)
      return (PointerIO)CommonPointerIOs.shortIO; 
    if (buffer instanceof java.nio.ByteBuffer)
      return (PointerIO)CommonPointerIOs.byteIO; 
    if (buffer instanceof java.nio.CharBuffer)
      return (PointerIO)CommonPointerIOs.charIO; 
    if (buffer instanceof java.nio.FloatBuffer)
      return (PointerIO)CommonPointerIOs.floatIO; 
    if (buffer instanceof java.nio.DoubleBuffer)
      return (PointerIO)CommonPointerIOs.doubleIO; 
    throw new UnsupportedOperationException();
  }
  
  abstract T get(Pointer<T> paramPointer, long paramLong);
  
  abstract void set(Pointer<T> paramPointer, long paramLong, T paramT);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\PointerIO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */