/*     */ package org.bridj;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Type;
/*     */ import org.bridj.util.DefaultParameterizedType;
/*     */ import org.bridj.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CommonPointerIOs
/*     */ {
/*     */   static class NativeObjectPointerIO<N extends NativeObject>
/*     */     extends PointerIO<N>
/*     */   {
/*  42 */     protected volatile long targetSize = -1L; protected volatile long targetAlignment = -1L; protected Type nativeObjectType;
/*     */     
/*     */     public NativeObjectPointerIO(Type nativeObjectType) {
/*  45 */       super(nativeObjectType, -1, null);
/*  46 */       this.nativeObjectType = nativeObjectType;
/*  47 */       if (Utils.containsTypeVariables(nativeObjectType)) {
/*  48 */         throw new RuntimeException("Type " + nativeObjectType + " contains unresolved type variables!");
/*     */       }
/*     */     }
/*     */     
/*     */     protected long computeTargetSize() {
/*  53 */       return BridJ.sizeOf(this.nativeObjectType);
/*     */     }
/*     */     protected long computeTargetAlignment() {
/*  56 */       return getTargetSize();
/*     */     }
/*     */     
/*     */     public long getTargetSize() {
/*  60 */       if (this.targetSize < 0L) {
/*  61 */         this.targetSize = computeTargetSize();
/*     */       }
/*  63 */       return this.targetSize;
/*     */     }
/*     */     
/*     */     public long getTargetAlignment() {
/*  67 */       if (this.targetAlignment < 0L) {
/*  68 */         this.targetAlignment = computeTargetAlignment();
/*     */       }
/*  70 */       return this.targetAlignment;
/*     */     }
/*     */ 
/*     */     
/*     */     public N get(Pointer<N> pointer, long index) {
/*  75 */       return pointer.getNativeObjectAtOffset(index * getTargetSize(), this.nativeObjectType);
/*     */     }
/*     */     
/*     */     public void set(Pointer<N> pointer, long index, N value) {
/*  79 */       Pointer<N> ps = Pointer.getPointer(value);
/*  80 */       ps.copyTo(pointer.offset(index * getTargetSize()));
/*     */     }
/*     */   }
/*     */   
/*     */   static class StructPointerIO<S extends StructObject> extends NativeObjectPointerIO<S> {
/*     */     public StructPointerIO(StructIO structIO) {
/*  86 */       super(structIO.desc.getStructType());
/*  87 */       this.structIO = structIO;
/*     */     }
/*     */     final StructIO structIO;
/*     */     
/*     */     protected long computeTargetSize() {
/*  92 */       return this.structIO.desc.getStructSize();
/*     */     }
/*     */     
/*     */     protected long computeTargetAlignment() {
/*  96 */       return this.structIO.desc.getStructAlignment();
/*     */     }
/*     */   }
/*     */   
/*     */   static class PointerPointerIO<T> extends PointerIO<Pointer<T>> {
/*     */     final PointerIO<T> underlyingIO;
/*     */     
/*     */     public PointerPointerIO(PointerIO<T> underlyingIO) {
/* 104 */       super((underlyingIO == null) ? Pointer.class : DefaultParameterizedType.paramType(Pointer.class, new Type[] { underlyingIO.getTargetType() }), Pointer.SIZE, null);
/* 105 */       this.underlyingIO = underlyingIO;
/*     */     }
/*     */ 
/*     */     
/*     */     public Pointer<T> get(Pointer<Pointer<T>> pointer, long index) {
/* 110 */       return pointer.getPointerAtOffset(index * Pointer.SIZE, this.underlyingIO);
/*     */     }
/*     */ 
/*     */     
/*     */     public void set(Pointer<Pointer<T>> pointer, long index, Pointer<T> value) {
/* 115 */       pointer.setPointerAtOffset(index * Pointer.SIZE, value);
/*     */     }
/*     */   }
/*     */   
/*     */   static class PointerArrayIO<T> extends PointerIO<Pointer<T>> {
/*     */     final PointerIO<T> underlyingIO;
/*     */     final long[] dimensions;
/*     */     final long totalRemainingDims;
/*     */     final int iDimension;
/*     */     
/*     */     static Type arrayPtrType(Type elementType, long... dimensions) {
/* 126 */       Type type = elementType;
/* 127 */       for (int i = 0; i < dimensions.length; i++) {
/* 128 */         type = DefaultParameterizedType.paramType(Pointer.class, new Type[] { type });
/* 129 */       }  return type;
/*     */     }
/*     */     static long getTotalRemainingDims(long[] dimensions, int iDimension) {
/* 132 */       long d = 1L;
/* 133 */       for (int i = iDimension + 1; i < dimensions.length; i++)
/* 134 */         d *= dimensions[i]; 
/* 135 */       return d;
/*     */     }
/*     */     
/*     */     public PointerArrayIO(PointerIO<T> underlyingIO, long[] dimensions, int iDimension) {
/* 139 */       super((underlyingIO == null) ? null : arrayPtrType(underlyingIO.getTargetType(), dimensions), -1, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 146 */       this.underlyingIO = underlyingIO;
/*     */ 
/*     */ 
/*     */       
/* 150 */       this.dimensions = dimensions;
/* 151 */       this.iDimension = iDimension;
/* 152 */       this.totalRemainingDims = getTotalRemainingDims(dimensions, iDimension);
/*     */     }
/*     */ 
/*     */     
/*     */     public long getTargetSize() {
/* 157 */       long subSize = this.underlyingIO.getTargetSize();
/* 158 */       return this.dimensions[this.iDimension + 1] * subSize;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Pointer<T> get(Pointer<Pointer<T>> pointer, long index) {
/* 164 */       long targetSize = getTargetSize();
/* 165 */       return pointer.offset(index * targetSize).as(this.underlyingIO);
/*     */     }
/*     */     
/*     */     long getOffset(long index) {
/* 169 */       assert this.iDimension < this.dimensions.length;
/* 170 */       return index * this.totalRemainingDims;
/*     */     }
/*     */     
/*     */     public void set(Pointer<Pointer<T>> pointer, long index, Pointer<T> value) {
/* 174 */       throw new RuntimeException("Cannot set a multi-dimensional array's sub-arrays pointers !");
/*     */     }
/*     */   }
/*     */   
/*     */   static class CallbackPointerIO<T extends CallbackInterface> extends PointerIO<T> {
/*     */     final Class<T> callbackClass;
/*     */     
/*     */     public CallbackPointerIO(Class<T> callbackClass) {
/* 182 */       super(callbackClass, Pointer.SIZE, null);
/* 183 */       this.callbackClass = callbackClass;
/*     */     }
/*     */ 
/*     */     
/*     */     public T get(Pointer<T> pointer, long index) {
/* 188 */       if (index != 0L) {
/* 189 */         throw new UnsupportedOperationException("Cannot get function pointer at index different from 0");
/*     */       }
/* 191 */       return (T)pointer.<CallbackInterface>getNativeObjectAtOffset(0L, this.callbackClass);
/*     */     }
/*     */ 
/*     */     
/*     */     public void set(Pointer<T> pointer, long index, T value) {
/* 196 */       throw new UnsupportedOperationException("Cannot write to body of function");
/*     */     }
/*     */   }
/*     */   
/*     */   static class IntValuedEnumPointerIO<E extends Enum<E>>
/*     */     extends PointerIO<IntValuedEnum<E>> {
/*     */     final Class<E> enumClass;
/*     */     
/*     */     public IntValuedEnumPointerIO(Class<E> enumClass) {
/* 205 */       super(IntValuedEnum.class, 4, null);
/* 206 */       this.enumClass = enumClass;
/*     */     }
/*     */ 
/*     */     
/*     */     public IntValuedEnum<E> get(Pointer<IntValuedEnum<E>> pointer, long index) {
/* 211 */       return FlagSet.fromValue(pointer.getIntAtOffset(4L * index), this.enumClass);
/*     */     }
/*     */ 
/*     */     
/*     */     public void set(Pointer<IntValuedEnum<E>> pointer, long index, IntValuedEnum<E> value) {
/* 216 */       pointer.setIntAtOffset(4L * index, (int)value.value());
/*     */     }
/*     */   }
/*     */   
/*     */   static class TypedPointerPointerIO<P extends TypedPointer> extends PointerIO<P> {
/*     */     final Constructor cons;
/*     */     final Class<P> pointerClass;
/*     */     
/*     */     public TypedPointerPointerIO(Class<P> pointerClass) {
/* 225 */       super(pointerClass, Pointer.SIZE, null);
/* 226 */       this.pointerClass = pointerClass;
/*     */       try {
/* 228 */         this.cons = pointerClass.getConstructor(new Class[] { long.class });
/*     */       }
/* 230 */       catch (Exception ex) {
/* 231 */         throw new RuntimeException("Cannot find constructor for " + pointerClass.getName(), ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public P castTarget(long peer) {
/* 237 */       if (peer == 0L)
/* 238 */         return null; 
/*     */       try {
/* 240 */         return (P)this.cons.newInstance(new Object[] { Long.valueOf(peer) });
/* 241 */       } catch (Exception ex) {
/* 242 */         throw new RuntimeException("Cannot create pointer of type " + this.pointerClass.getName(), ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public P get(Pointer<P> pointer, long index) {
/* 248 */       return castTarget(pointer.getSizeTAtOffset(index * Pointer.SIZE));
/*     */     }
/*     */ 
/*     */     
/*     */     public void set(Pointer<P> pointer, long index, P value) {
/* 253 */       pointer.setPointerAtOffset(index * Pointer.SIZE, (Pointer<?>)value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 258 */   public static final PointerIO<Integer> intIO = new PointerIO<Integer>(Integer.class, 4, null)
/*     */     {
/*     */       public Integer get(Pointer<Integer> pointer, long index) {
/* 261 */         return Integer.valueOf(pointer.getIntAtOffset(index * 4L));
/*     */       }
/*     */ 
/*     */       
/*     */       public void set(Pointer<Integer> pointer, long index, Integer value) {
/* 266 */         pointer.setIntAtOffset(index * 4L, value.intValue());
/*     */       }
/*     */ 
/*     */       
/*     */       public <B extends java.nio.Buffer> B getBuffer(Pointer<Integer> pointer, long byteOffset, int length) {
/* 271 */         return (B)pointer.getIntBufferAtOffset(byteOffset, length);
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getArray(Pointer<Integer> pointer, long byteOffset, int length) {
/* 276 */         return pointer.getIntsAtOffset(byteOffset, length);
/*     */       }
/*     */ 
/*     */       
/*     */       public void setArray(Pointer<Integer> pointer, long byteOffset, Object array) {
/* 281 */         if (array instanceof int[]) {
/* 282 */           pointer.setIntsAtOffset(byteOffset, (int[])array);
/*     */         } else {
/* 284 */           super.setArray(pointer, byteOffset, array);
/*     */         } 
/*     */       }
/*     */     };
/*     */ 
/*     */   
/* 290 */   public static final PointerIO<Long> longIO = new PointerIO<Long>(Long.class, 8, null)
/*     */     {
/*     */       public Long get(Pointer<Long> pointer, long index) {
/* 293 */         return Long.valueOf(pointer.getLongAtOffset(index * 8L));
/*     */       }
/*     */ 
/*     */       
/*     */       public void set(Pointer<Long> pointer, long index, Long value) {
/* 298 */         pointer.setLongAtOffset(index * 8L, value.longValue());
/*     */       }
/*     */ 
/*     */       
/*     */       public <B extends java.nio.Buffer> B getBuffer(Pointer<Long> pointer, long byteOffset, int length) {
/* 303 */         return (B)pointer.getLongBufferAtOffset(byteOffset, length);
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getArray(Pointer<Long> pointer, long byteOffset, int length) {
/* 308 */         return pointer.getLongsAtOffset(byteOffset, length);
/*     */       }
/*     */ 
/*     */       
/*     */       public void setArray(Pointer<Long> pointer, long byteOffset, Object array) {
/* 313 */         if (array instanceof long[]) {
/* 314 */           pointer.setLongsAtOffset(byteOffset, (long[])array);
/*     */         } else {
/* 316 */           super.setArray(pointer, byteOffset, array);
/*     */         } 
/*     */       }
/*     */     };
/*     */ 
/*     */   
/* 322 */   public static final PointerIO<Short> shortIO = new PointerIO<Short>(Short.class, 2, null)
/*     */     {
/*     */       public Short get(Pointer<Short> pointer, long index) {
/* 325 */         return Short.valueOf(pointer.getShortAtOffset(index * 2L));
/*     */       }
/*     */ 
/*     */       
/*     */       public void set(Pointer<Short> pointer, long index, Short value) {
/* 330 */         pointer.setShortAtOffset(index * 2L, value.shortValue());
/*     */       }
/*     */ 
/*     */       
/*     */       public <B extends java.nio.Buffer> B getBuffer(Pointer<Short> pointer, long byteOffset, int length) {
/* 335 */         return (B)pointer.getShortBufferAtOffset(byteOffset, length);
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getArray(Pointer<Short> pointer, long byteOffset, int length) {
/* 340 */         return pointer.getShortsAtOffset(byteOffset, length);
/*     */       }
/*     */ 
/*     */       
/*     */       public void setArray(Pointer<Short> pointer, long byteOffset, Object array) {
/* 345 */         if (array instanceof short[]) {
/* 346 */           pointer.setShortsAtOffset(byteOffset, (short[])array);
/*     */         } else {
/* 348 */           super.setArray(pointer, byteOffset, array);
/*     */         } 
/*     */       }
/*     */     };
/*     */ 
/*     */   
/* 354 */   public static final PointerIO<Byte> byteIO = new PointerIO<Byte>(Byte.class, 1, null)
/*     */     {
/*     */       public Byte get(Pointer<Byte> pointer, long index) {
/* 357 */         return Byte.valueOf(pointer.getByteAtOffset(index * 1L));
/*     */       }
/*     */ 
/*     */       
/*     */       public void set(Pointer<Byte> pointer, long index, Byte value) {
/* 362 */         pointer.setByteAtOffset(index * 1L, value.byteValue());
/*     */       }
/*     */ 
/*     */       
/*     */       public <B extends java.nio.Buffer> B getBuffer(Pointer<Byte> pointer, long byteOffset, int length) {
/* 367 */         return (B)pointer.getByteBufferAtOffset(byteOffset, length);
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getArray(Pointer<Byte> pointer, long byteOffset, int length) {
/* 372 */         return pointer.getBytesAtOffset(byteOffset, length);
/*     */       }
/*     */ 
/*     */       
/*     */       public void setArray(Pointer<Byte> pointer, long byteOffset, Object array) {
/* 377 */         if (array instanceof byte[]) {
/* 378 */           pointer.setBytesAtOffset(byteOffset, (byte[])array);
/*     */         } else {
/* 380 */           super.setArray(pointer, byteOffset, array);
/*     */         } 
/*     */       }
/*     */     };
/*     */ 
/*     */   
/* 386 */   public static final PointerIO<Character> charIO = new PointerIO<Character>(Character.class, Platform.WCHAR_T_SIZE, null)
/*     */     {
/*     */       public Character get(Pointer<Character> pointer, long index) {
/* 389 */         return Character.valueOf(pointer.getCharAtOffset(index * Platform.WCHAR_T_SIZE));
/*     */       }
/*     */ 
/*     */       
/*     */       public void set(Pointer<Character> pointer, long index, Character value) {
/* 394 */         pointer.setCharAtOffset(index * Platform.WCHAR_T_SIZE, value.charValue());
/*     */       }
/*     */ 
/*     */       
/*     */       public <B extends java.nio.Buffer> B getBuffer(Pointer<Character> pointer, long byteOffset, int length) {
/* 399 */         throw new UnsupportedOperationException("Creating direct char buffers in a cross-platform way is tricky, so it's currently disabled");
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getArray(Pointer<Character> pointer, long byteOffset, int length) {
/* 404 */         return pointer.getCharsAtOffset(byteOffset, length);
/*     */       }
/*     */ 
/*     */       
/*     */       public void setArray(Pointer<Character> pointer, long byteOffset, Object array) {
/* 409 */         if (array instanceof char[]) {
/* 410 */           pointer.setCharsAtOffset(byteOffset, (char[])array);
/*     */         } else {
/* 412 */           super.setArray(pointer, byteOffset, array);
/*     */         } 
/*     */       }
/*     */     };
/*     */ 
/*     */   
/* 418 */   public static final PointerIO<Float> floatIO = new PointerIO<Float>(Float.class, 4, null)
/*     */     {
/*     */       public Float get(Pointer<Float> pointer, long index) {
/* 421 */         return Float.valueOf(pointer.getFloatAtOffset(index * 4L));
/*     */       }
/*     */ 
/*     */       
/*     */       public void set(Pointer<Float> pointer, long index, Float value) {
/* 426 */         pointer.setFloatAtOffset(index * 4L, value.floatValue());
/*     */       }
/*     */ 
/*     */       
/*     */       public <B extends java.nio.Buffer> B getBuffer(Pointer<Float> pointer, long byteOffset, int length) {
/* 431 */         return (B)pointer.getFloatBufferAtOffset(byteOffset, length);
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getArray(Pointer<Float> pointer, long byteOffset, int length) {
/* 436 */         return pointer.getFloatsAtOffset(byteOffset, length);
/*     */       }
/*     */ 
/*     */       
/*     */       public void setArray(Pointer<Float> pointer, long byteOffset, Object array) {
/* 441 */         if (array instanceof float[]) {
/* 442 */           pointer.setFloatsAtOffset(byteOffset, (float[])array);
/*     */         } else {
/* 444 */           super.setArray(pointer, byteOffset, array);
/*     */         } 
/*     */       }
/*     */     };
/*     */ 
/*     */   
/* 450 */   public static final PointerIO<Double> doubleIO = new PointerIO<Double>(Double.class, 8, null)
/*     */     {
/*     */       public Double get(Pointer<Double> pointer, long index) {
/* 453 */         return Double.valueOf(pointer.getDoubleAtOffset(index * 8L));
/*     */       }
/*     */ 
/*     */       
/*     */       public void set(Pointer<Double> pointer, long index, Double value) {
/* 458 */         pointer.setDoubleAtOffset(index * 8L, value.doubleValue());
/*     */       }
/*     */ 
/*     */       
/*     */       public <B extends java.nio.Buffer> B getBuffer(Pointer<Double> pointer, long byteOffset, int length) {
/* 463 */         return (B)pointer.getDoubleBufferAtOffset(byteOffset, length);
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getArray(Pointer<Double> pointer, long byteOffset, int length) {
/* 468 */         return pointer.getDoublesAtOffset(byteOffset, length);
/*     */       }
/*     */ 
/*     */       
/*     */       public void setArray(Pointer<Double> pointer, long byteOffset, Object array) {
/* 473 */         if (array instanceof double[]) {
/* 474 */           pointer.setDoublesAtOffset(byteOffset, (double[])array);
/*     */         } else {
/* 476 */           super.setArray(pointer, byteOffset, array);
/*     */         } 
/*     */       }
/*     */     };
/*     */ 
/*     */   
/* 482 */   public static final PointerIO<Boolean> booleanIO = new PointerIO<Boolean>(Boolean.class, 1, null)
/*     */     {
/*     */       public Boolean get(Pointer<Boolean> pointer, long index) {
/* 485 */         return Boolean.valueOf(pointer.getBooleanAtOffset(index * 1L));
/*     */       }
/*     */ 
/*     */       
/*     */       public void set(Pointer<Boolean> pointer, long index, Boolean value) {
/* 490 */         pointer.setBooleanAtOffset(index * 1L, value.booleanValue());
/*     */       }
/*     */ 
/*     */       
/*     */       public <B extends java.nio.Buffer> B getBuffer(Pointer<Boolean> pointer, long byteOffset, int length) {
/* 495 */         return (B)pointer.getByteBufferAtOffset(byteOffset, length);
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getArray(Pointer<Boolean> pointer, long byteOffset, int length) {
/* 500 */         return pointer.getBooleansAtOffset(byteOffset, length);
/*     */       }
/*     */ 
/*     */       
/*     */       public void setArray(Pointer<Boolean> pointer, long byteOffset, Object array) {
/* 505 */         if (array instanceof boolean[]) {
/* 506 */           pointer.setBooleansAtOffset(byteOffset, (boolean[])array);
/*     */         } else {
/* 508 */           super.setArray(pointer, byteOffset, array);
/*     */         } 
/*     */       }
/*     */     };
/*     */ 
/*     */   
/* 514 */   public static final PointerIO<SizeT> SizeTIO = new PointerIO<SizeT>(SizeT.class, SizeT.SIZE, null)
/*     */     {
/*     */       public SizeT get(Pointer<SizeT> pointer, long index) {
/* 517 */         return new SizeT(pointer.getSizeTAtOffset(index * SizeT.SIZE));
/*     */       }
/*     */       
/*     */       public void set(Pointer<SizeT> pointer, long index, SizeT value) {
/* 521 */         pointer.setSizeTAtOffset(index * SizeT.SIZE, (value == null) ? 0L : value.longValue());
/*     */       }
/*     */     };
/*     */   
/* 525 */   public static final PointerIO<TimeT> TimeTIO = new PointerIO<TimeT>(TimeT.class, TimeT.SIZE, null)
/*     */     {
/*     */       public TimeT get(Pointer<TimeT> pointer, long index) {
/* 528 */         long offset = index * TimeT.SIZE;
/* 529 */         return new TimeT((TimeT.SIZE == 4) ? pointer.getIntAtOffset(offset) : pointer.getLongAtOffset(offset));
/*     */       }
/*     */       
/*     */       public void set(Pointer<TimeT> pointer, long index, TimeT value) {
/* 533 */         long offset = index * TimeT.SIZE;
/* 534 */         if (TimeT.SIZE == 4) {
/* 535 */           pointer.setIntAtOffset(offset, (value == null) ? 0 : value.intValue());
/*     */         } else {
/* 537 */           pointer.setLongAtOffset(offset, (value == null) ? 0L : value.longValue());
/*     */         } 
/*     */       }
/*     */     };
/* 541 */   public static final PointerIO<CLong> CLongIO = new PointerIO<CLong>(CLong.class, CLong.SIZE, null)
/*     */     {
/*     */       public CLong get(Pointer<CLong> pointer, long index) {
/* 544 */         return new CLong(pointer.getCLongAtOffset(index * CLong.SIZE));
/*     */       }
/*     */       
/*     */       public void set(Pointer<CLong> pointer, long index, CLong value) {
/* 548 */         pointer.setCLongAtOffset(index * CLong.SIZE, (value == null) ? 0L : value.longValue());
/*     */       }
/*     */     };
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\CommonPointerIOs.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */