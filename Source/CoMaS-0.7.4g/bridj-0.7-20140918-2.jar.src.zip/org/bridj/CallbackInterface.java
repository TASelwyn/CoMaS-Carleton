package org.bridj;

public interface CallbackInterface extends NativeObjectInterface {}
