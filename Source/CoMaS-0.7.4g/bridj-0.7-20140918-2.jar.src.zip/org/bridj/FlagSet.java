/*     */ package org.bridj;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.WeakHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlagSet<E extends Enum<E>>
/*     */   implements ValuedEnum<E>
/*     */ {
/*     */   private final long value;
/*     */   private final Class<E> enumClass;
/*     */   private E[] enumClassValues;
/*     */   
/*     */   protected FlagSet(long value, Class<E> enumClass, E[] enumClassValues) {
/*  58 */     this.enumClass = enumClass;
/*  59 */     this.value = value;
/*  60 */     this.enumClassValues = enumClassValues;
/*     */   }
/*  62 */   private static Map<Class<?>, Object[]> enumsCache = (Map)new WeakHashMap<Class<?>, Object>();
/*     */ 
/*     */   
/*     */   private static synchronized <EE extends Enum<EE>> EE[] getValues(Class<EE> enumClass) {
/*  66 */     Enum[] arrayOfEnum = (Enum[])enumsCache.get(enumClass);
/*  67 */     if (arrayOfEnum == null) {
/*     */       try {
/*  69 */         Method valuesMethod = enumClass.getMethod("values", new Class[0]);
/*  70 */         Class<?> valuesType = valuesMethod.getReturnType();
/*  71 */         if (!valuesType.isArray() || !ValuedEnum.class.isAssignableFrom(valuesType.getComponentType())) {
/*  72 */           throw new RuntimeException();
/*     */         }
/*  74 */         enumsCache.put(enumClass, arrayOfEnum = (Enum[])valuesMethod.invoke(null, new Object[0]));
/*  75 */       } catch (Exception ex) {
/*  76 */         throw new IllegalArgumentException("Class " + enumClass + " does not have a public static " + ValuedEnum.class.getName() + "[] values() method.", ex);
/*     */       } 
/*     */     }
/*  79 */     return (EE[])arrayOfEnum;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  84 */     if (!(o instanceof ValuedEnum)) {
/*  85 */       return false;
/*     */     }
/*  87 */     return (value() == ((ValuedEnum)o).value());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  92 */     return Long.valueOf(value()).hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<E> iterator() {
/*  97 */     return getMatchingEnums().iterator();
/*     */   }
/*     */   public E toEnum() {
/*     */     Enum enum_1, enum_2;
/* 101 */     E nullMatch = null;
/* 102 */     E match = null;
/* 103 */     for (Enum enum_ : getMatchingEnums()) {
/* 104 */       if (((ValuedEnum)enum_).value() == 0L) {
/* 105 */         enum_1 = enum_; continue;
/* 106 */       }  if (match == null) {
/* 107 */         enum_2 = enum_; continue;
/*     */       } 
/* 109 */       throw new NoSuchElementException("More than one enum value corresponding to " + this + " : " + enum_ + " and " + enum_2 + "...");
/*     */     } 
/*     */     
/* 112 */     if (enum_2 != null) {
/* 113 */       return (E)enum_2;
/*     */     }
/*     */     
/* 116 */     if (value() == 0L) {
/* 117 */       return (E)enum_1;
/*     */     }
/*     */     
/* 120 */     throw new NoSuchElementException("No enum value corresponding to " + this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 125 */     StringBuilder b = new StringBuilder();
/* 126 */     b.append(this.enumClass.getSimpleName()).append("(").append(value()).append(" = ");
/*     */     try {
/* 128 */       boolean first = true;
/* 129 */       for (Enum enum_ : getMatchingEnums()) {
/* 130 */         if (first) {
/* 131 */           first = false;
/*     */         } else {
/* 133 */           b.append(" | ");
/*     */         } 
/* 135 */         b.append(enum_);
/*     */       } 
/* 137 */     } catch (Throwable th) {
/* 138 */       b.append("?");
/*     */     } 
/* 140 */     b.append(")");
/* 141 */     return b.toString();
/*     */   }
/*     */   
/*     */   public static <EE extends Enum<EE>> FlagSet<EE> createFlagSet(long value, Class<EE> enumClass) {
/* 145 */     return new FlagSet<EE>(value, enumClass, null);
/*     */   }
/*     */   
/*     */   public static class IntFlagSet<E extends Enum<E>>
/*     */     extends FlagSet<E> implements IntValuedEnum<E> {
/*     */     protected IntFlagSet(long value, Class<E> enumClass, E[] enumClassValues) {
/* 151 */       super(value, enumClass, enumClassValues);
/*     */     }
/*     */   }
/*     */   
/*     */   public static <EE extends Enum<EE>> IntFlagSet<EE> createFlagSet(int value, Class<EE> enumClass) {
/* 156 */     return new IntFlagSet<EE>(value, enumClass, null);
/*     */   }
/*     */   
/*     */   public static <EE extends Enum<EE>> FlagSet<EE> fromValue(ValuedEnum<EE> value) {
/* 160 */     if (value instanceof Enum) {
/* 161 */       return createFlagSet(value.value(), (EE[])new Enum[] { (Enum)value });
/*     */     }
/* 163 */     return (FlagSet<EE>)value;
/*     */   }
/*     */ 
/*     */   
/*     */   public static <EE extends Enum<EE>> FlagSet<EE> createFlagSet(long value, EE... enumValue) {
/* 168 */     if (enumValue == null) {
/* 169 */       throw new IllegalArgumentException("Expected at least one enum value");
/*     */     }
/* 171 */     Class<EE> enumClass = (Class)enumValue[0].getClass();
/* 172 */     if (IntValuedEnum.class.isAssignableFrom(enumClass)) {
/* 173 */       return new IntFlagSet<EE>(value, enumClass, enumValue);
/*     */     }
/* 175 */     return new FlagSet<EE>(value, enumClass, enumValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <EE extends Enum<EE>> IntValuedEnum<EE> fromValue(int value, Class<EE> enumClass) {
/* 183 */     return (IntValuedEnum<EE>)fromValue(value, enumClass, enumClass.getEnumConstants());
/*     */   }
/*     */   
/*     */   public static <EE extends Enum<EE>> IntValuedEnum<EE> fromValue(int value, EE... enumValues) {
/* 187 */     return (IntValuedEnum<EE>)fromValue(value, enumValues);
/*     */   }
/*     */   
/*     */   public static <EE extends Enum<EE>> ValuedEnum<EE> fromValue(long value, EE... enumValues) {
/* 191 */     if (enumValues == null || enumValues.length == 0) {
/* 192 */       throw new IllegalArgumentException("Expected at least one enum value");
/*     */     }
/* 194 */     Class<EE> enumClass = (Class)enumValues[0].getClass();
/* 195 */     return fromValue(value, enumClass, enumValues);
/*     */   }
/*     */   
/*     */   protected static <EE extends Enum<EE>> ValuedEnum<EE> fromValue(long value, Class<EE> enumClass, EE... enumValue) {
/* 199 */     List<EE> enums = getMatchingEnums(value, enumClass.getEnumConstants());
/* 200 */     if (enums.size() == 1) {
/* 201 */       return (ValuedEnum<EE>)enums.get(0);
/*     */     }
/* 203 */     if (IntValuedEnum.class.isAssignableFrom(enumClass)) {
/* 204 */       return new IntFlagSet<EE>(value, enumClass, (EE[])enums.<Enum>toArray((Enum[])Array.newInstance(enumClass, enums.size())));
/*     */     }
/* 206 */     return new FlagSet<EE>(value, enumClass, (EE[])enums.<Enum>toArray((Enum[])Array.newInstance(enumClass, enums.size())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Long> getBits(long value) {
/* 218 */     List<Long> list = new ArrayList<Long>();
/* 219 */     for (int i = 0; i < 64; i++) {
/* 220 */       long bit = 1L << i;
/* 221 */       if ((value & bit) != 0L) {
/* 222 */         list.add(Long.valueOf(bit));
/*     */       }
/*     */     } 
/* 225 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long value() {
/* 235 */     return this.value;
/*     */   }
/*     */   
/*     */   public Class<E> getEnumClass() {
/* 239 */     return this.enumClass;
/*     */   }
/*     */   
/*     */   protected E[] getEnumClassValues() {
/* 243 */     return (this.enumClassValues == null) ? (this.enumClassValues = getValues(this.enumClass)) : this.enumClassValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean is(E... valuesToBeCombinedWithOR) {
/* 260 */     return (value() == orValue(valuesToBeCombinedWithOR));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean has(E... valuesToBeCombinedWithOR) {
/* 277 */     return ((value() & orValue(valuesToBeCombinedWithOR)) != 0L);
/*     */   }
/*     */   
/*     */   public FlagSet<E> or(E... valuesToBeCombinedWithOR) {
/* 281 */     return new FlagSet(value() | orValue(valuesToBeCombinedWithOR), this.enumClass, null);
/*     */   }
/*     */   
/*     */   static <E extends Enum<E>> long orValue(E... valuesToBeCombinedWithOR) {
/* 285 */     long value = 0L;
/* 286 */     for (E v : valuesToBeCombinedWithOR) {
/* 287 */       value |= ((ValuedEnum)v).value();
/*     */     }
/* 289 */     return value;
/*     */   }
/*     */   
/*     */   public FlagSet<E> without(E... valuesToBeCombinedWithOR) {
/* 293 */     return new FlagSet(value() & (orValue(valuesToBeCombinedWithOR) ^ 0xFFFFFFFFFFFFFFFFL), this.enumClass, null);
/*     */   }
/*     */   
/*     */   public FlagSet<E> and(E... valuesToBeCombinedWithOR) {
/* 297 */     return new FlagSet(value() & orValue(valuesToBeCombinedWithOR), this.enumClass, null);
/*     */   }
/*     */   
/*     */   protected List<E> getMatchingEnums() {
/* 301 */     return (this.enumClass == null) ? Collections.EMPTY_LIST : getMatchingEnums(this.value, getEnumClassValues());
/*     */   }
/*     */   
/*     */   protected static <EE extends Enum<EE>> List<EE> getMatchingEnums(long value, EE[] enums) {
/* 305 */     List<EE> ret = new ArrayList<EE>();
/* 306 */     for (EE e : enums) {
/* 307 */       long eMask = ((ValuedEnum)e).value();
/* 308 */       if ((eMask == 0L && value == 0L) || (eMask != 0L && (value & eMask) == eMask)) {
/* 309 */         ret.add(e);
/*     */       }
/*     */     } 
/* 312 */     return ret;
/*     */   }
/*     */   
/*     */   public static <E extends Enum<E>> FlagSet<E> fromValues(E... enumValues) {
/* 316 */     long value = 0L;
/* 317 */     Class<?> cl = null;
/* 318 */     for (E enumValue : enumValues) {
/* 319 */       if (enumValue != null) {
/*     */ 
/*     */         
/* 322 */         if (cl == null) {
/* 323 */           cl = enumValue.getClass();
/*     */         }
/* 325 */         value |= ((ValuedEnum)enumValue).value();
/*     */       } 
/* 327 */     }  return new FlagSet<E>(value, (Class)cl, enumValues);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\FlagSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */