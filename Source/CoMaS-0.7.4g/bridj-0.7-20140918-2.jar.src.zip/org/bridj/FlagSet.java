package org.bridj;

import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.WeakHashMap;

public class FlagSet<E extends Enum<E>> implements ValuedEnum<E> {
  private final long value;
  
  private final Class<E> enumClass;
  
  private E[] enumClassValues;
  
  protected FlagSet(long value, Class<E> enumClass, E[] enumClassValues) {
    this.enumClass = enumClass;
    this.value = value;
    this.enumClassValues = enumClassValues;
  }
  
  private static Map<Class<?>, Object[]> enumsCache = (Map)new WeakHashMap<Class<?>, Object>();
  
  private static synchronized <EE extends Enum<EE>> EE[] getValues(Class<EE> enumClass) {
    Enum[] arrayOfEnum = (Enum[])enumsCache.get(enumClass);
    if (arrayOfEnum == null)
      try {
        Method valuesMethod = enumClass.getMethod("values", new Class[0]);
        Class<?> valuesType = valuesMethod.getReturnType();
        if (!valuesType.isArray() || !ValuedEnum.class.isAssignableFrom(valuesType.getComponentType()))
          throw new RuntimeException(); 
        enumsCache.put(enumClass, arrayOfEnum = (Enum[])valuesMethod.invoke(null, new Object[0]));
      } catch (Exception ex) {
        throw new IllegalArgumentException("Class " + enumClass + " does not have a public static " + ValuedEnum.class.getName() + "[] values() method.", ex);
      }  
    return (EE[])arrayOfEnum;
  }
  
  public boolean equals(Object o) {
    if (!(o instanceof ValuedEnum))
      return false; 
    return (value() == ((ValuedEnum)o).value());
  }
  
  public int hashCode() {
    return Long.valueOf(value()).hashCode();
  }
  
  public Iterator<E> iterator() {
    return getMatchingEnums().iterator();
  }
  
  public E toEnum() {
    Enum enum_1, enum_2;
    E nullMatch = null;
    E match = null;
    for (Enum enum_ : getMatchingEnums()) {
      if (((ValuedEnum)enum_).value() == 0L) {
        enum_1 = enum_;
        continue;
      } 
      if (match == null) {
        enum_2 = enum_;
        continue;
      } 
      throw new NoSuchElementException("More than one enum value corresponding to " + this + " : " + enum_ + " and " + enum_2 + "...");
    } 
    if (enum_2 != null)
      return (E)enum_2; 
    if (value() == 0L)
      return (E)enum_1; 
    throw new NoSuchElementException("No enum value corresponding to " + this);
  }
  
  public String toString() {
    StringBuilder b = new StringBuilder();
    b.append(this.enumClass.getSimpleName()).append("(").append(value()).append(" = ");
    try {
      boolean first = true;
      for (Enum enum_ : getMatchingEnums()) {
        if (first) {
          first = false;
        } else {
          b.append(" | ");
        } 
        b.append(enum_);
      } 
    } catch (Throwable th) {
      b.append("?");
    } 
    b.append(")");
    return b.toString();
  }
  
  public static <EE extends Enum<EE>> FlagSet<EE> createFlagSet(long value, Class<EE> enumClass) {
    return new FlagSet<EE>(value, enumClass, null);
  }
  
  public static class IntFlagSet<E extends Enum<E>> extends FlagSet<E> implements IntValuedEnum<E> {
    protected IntFlagSet(long value, Class<E> enumClass, E[] enumClassValues) {
      super(value, enumClass, enumClassValues);
    }
  }
  
  public static <EE extends Enum<EE>> IntFlagSet<EE> createFlagSet(int value, Class<EE> enumClass) {
    return new IntFlagSet<EE>(value, enumClass, null);
  }
  
  public static <EE extends Enum<EE>> FlagSet<EE> fromValue(ValuedEnum<EE> value) {
    if (value instanceof Enum)
      return createFlagSet(value.value(), (EE[])new Enum[] { (Enum)value }); 
    return (FlagSet<EE>)value;
  }
  
  public static <EE extends Enum<EE>> FlagSet<EE> createFlagSet(long value, EE... enumValue) {
    if (enumValue == null)
      throw new IllegalArgumentException("Expected at least one enum value"); 
    Class<EE> enumClass = (Class)enumValue[0].getClass();
    if (IntValuedEnum.class.isAssignableFrom(enumClass))
      return new IntFlagSet<EE>(value, enumClass, enumValue); 
    return new FlagSet<EE>(value, enumClass, enumValue);
  }
  
  public static <EE extends Enum<EE>> IntValuedEnum<EE> fromValue(int value, Class<EE> enumClass) {
    return (IntValuedEnum<EE>)fromValue(value, enumClass, enumClass.getEnumConstants());
  }
  
  public static <EE extends Enum<EE>> IntValuedEnum<EE> fromValue(int value, EE... enumValues) {
    return (IntValuedEnum<EE>)fromValue(value, enumValues);
  }
  
  public static <EE extends Enum<EE>> ValuedEnum<EE> fromValue(long value, EE... enumValues) {
    if (enumValues == null || enumValues.length == 0)
      throw new IllegalArgumentException("Expected at least one enum value"); 
    Class<EE> enumClass = (Class)enumValues[0].getClass();
    return fromValue(value, enumClass, enumValues);
  }
  
  protected static <EE extends Enum<EE>> ValuedEnum<EE> fromValue(long value, Class<EE> enumClass, EE... enumValue) {
    List<EE> enums = getMatchingEnums(value, enumClass.getEnumConstants());
    if (enums.size() == 1)
      return (ValuedEnum<EE>)enums.get(0); 
    if (IntValuedEnum.class.isAssignableFrom(enumClass))
      return new IntFlagSet<EE>(value, enumClass, (EE[])enums.<Enum>toArray((Enum[])Array.newInstance(enumClass, enums.size()))); 
    return new FlagSet<EE>(value, enumClass, (EE[])enums.<Enum>toArray((Enum[])Array.newInstance(enumClass, enums.size())));
  }
  
  public static List<Long> getBits(long value) {
    List<Long> list = new ArrayList<Long>();
    for (int i = 0; i < 64; i++) {
      long bit = 1L << i;
      if ((value & bit) != 0L)
        list.add(Long.valueOf(bit)); 
    } 
    return list;
  }
  
  public long value() {
    return this.value;
  }
  
  public Class<E> getEnumClass() {
    return this.enumClass;
  }
  
  protected E[] getEnumClassValues() {
    return (this.enumClassValues == null) ? (this.enumClassValues = getValues(this.enumClass)) : this.enumClassValues;
  }
  
  public boolean is(E... valuesToBeCombinedWithOR) {
    return (value() == orValue(valuesToBeCombinedWithOR));
  }
  
  public boolean has(E... valuesToBeCombinedWithOR) {
    return ((value() & orValue(valuesToBeCombinedWithOR)) != 0L);
  }
  
  public FlagSet<E> or(E... valuesToBeCombinedWithOR) {
    return new FlagSet(value() | orValue(valuesToBeCombinedWithOR), this.enumClass, null);
  }
  
  static <E extends Enum<E>> long orValue(E... valuesToBeCombinedWithOR) {
    long value = 0L;
    for (E v : valuesToBeCombinedWithOR)
      value |= ((ValuedEnum)v).value(); 
    return value;
  }
  
  public FlagSet<E> without(E... valuesToBeCombinedWithOR) {
    return new FlagSet(value() & (orValue(valuesToBeCombinedWithOR) ^ 0xFFFFFFFFFFFFFFFFL), this.enumClass, null);
  }
  
  public FlagSet<E> and(E... valuesToBeCombinedWithOR) {
    return new FlagSet(value() & orValue(valuesToBeCombinedWithOR), this.enumClass, null);
  }
  
  protected List<E> getMatchingEnums() {
    return (this.enumClass == null) ? Collections.EMPTY_LIST : getMatchingEnums(this.value, getEnumClassValues());
  }
  
  protected static <EE extends Enum<EE>> List<EE> getMatchingEnums(long value, EE[] enums) {
    List<EE> ret = new ArrayList<EE>();
    for (EE e : enums) {
      long eMask = ((ValuedEnum)e).value();
      if ((eMask == 0L && value == 0L) || (eMask != 0L && (value & eMask) == eMask))
        ret.add(e); 
    } 
    return ret;
  }
  
  public static <E extends Enum<E>> FlagSet<E> fromValues(E... enumValues) {
    long value = 0L;
    Class<?> cl = null;
    for (E enumValue : enumValues) {
      if (enumValue != null) {
        if (cl == null)
          cl = enumValue.getClass(); 
        value |= ((ValuedEnum)enumValue).value();
      } 
    } 
    return new FlagSet<E>(value, (Class)cl, enumValues);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\FlagSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */