/*    */ package org.bridj;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypedPointer
/*    */   extends Pointer.OrderedPointer
/*    */ {
/*    */   Pointer<?> copy;
/*    */   
/*    */   private TypedPointer(PointerIO<?> io, long peer) {
/* 47 */     super((PointerIO)io, peer, -1L, -1L, null, 0L, null);
/*    */   }
/*    */   
/*    */   public TypedPointer(long address) {
/* 51 */     this(PointerIO.getPointerInstance(), address);
/*    */   }
/*    */   
/*    */   public TypedPointer(Pointer<?> ptr) {
/* 55 */     this(PointerIO.getPointerInstance(), ptr.getPeer());
/* 56 */     this.copy = ptr;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\TypedPointer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */