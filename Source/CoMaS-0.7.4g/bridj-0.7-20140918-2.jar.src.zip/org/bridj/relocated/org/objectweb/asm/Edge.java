package org.bridj.relocated.org.objectweb.asm;

class Edge {
  int a;
  
  Label b;
  
  Edge c;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\relocated\org\objectweb\asm\Edge.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */