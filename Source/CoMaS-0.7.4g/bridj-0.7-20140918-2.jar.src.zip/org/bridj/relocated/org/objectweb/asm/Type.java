package org.bridj.relocated.org.objectweb.asm;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class Type {
  public static final int VOID = 0;
  
  public static final int BOOLEAN = 1;
  
  public static final int CHAR = 2;
  
  public static final int BYTE = 3;
  
  public static final int SHORT = 4;
  
  public static final int INT = 5;
  
  public static final int FLOAT = 6;
  
  public static final int LONG = 7;
  
  public static final int DOUBLE = 8;
  
  public static final int ARRAY = 9;
  
  public static final int OBJECT = 10;
  
  public static final int METHOD = 11;
  
  public static final Type VOID_TYPE = new Type(0, null, 1443168256, 1);
  
  public static final Type BOOLEAN_TYPE = new Type(1, null, 1509950721, 1);
  
  public static final Type CHAR_TYPE = new Type(2, null, 1124075009, 1);
  
  public static final Type BYTE_TYPE = new Type(3, null, 1107297537, 1);
  
  public static final Type SHORT_TYPE = new Type(4, null, 1392510721, 1);
  
  public static final Type INT_TYPE = new Type(5, null, 1224736769, 1);
  
  public static final Type FLOAT_TYPE = new Type(6, null, 1174536705, 1);
  
  public static final Type LONG_TYPE = new Type(7, null, 1241579778, 1);
  
  public static final Type DOUBLE_TYPE = new Type(8, null, 1141048066, 1);
  
  private final int a;
  
  private final char[] b;
  
  private final int c;
  
  private final int d;
  
  private Type(int paramInt1, char[] paramArrayOfchar, int paramInt2, int paramInt3) {
    this.a = paramInt1;
    this.b = paramArrayOfchar;
    this.c = paramInt2;
    this.d = paramInt3;
  }
  
  public static Type getType(String paramString) {
    return a(paramString.toCharArray(), 0);
  }
  
  public static Type getObjectType(String paramString) {
    char[] arrayOfChar = paramString.toCharArray();
    return new Type((arrayOfChar[0] == '[') ? 9 : 10, arrayOfChar, 0, arrayOfChar.length);
  }
  
  public static Type getMethodType(String paramString) {
    return a(paramString.toCharArray(), 0);
  }
  
  public static Type getMethodType(Type paramType, Type... paramVarArgs) {
    return getType(getMethodDescriptor(paramType, paramVarArgs));
  }
  
  public static Type getType(Class paramClass) {
    return paramClass.isPrimitive() ? ((paramClass == int.class) ? INT_TYPE : ((paramClass == void.class) ? VOID_TYPE : ((paramClass == boolean.class) ? BOOLEAN_TYPE : ((paramClass == byte.class) ? BYTE_TYPE : ((paramClass == char.class) ? CHAR_TYPE : ((paramClass == short.class) ? SHORT_TYPE : ((paramClass == double.class) ? DOUBLE_TYPE : ((paramClass == float.class) ? FLOAT_TYPE : LONG_TYPE)))))))) : getType(getDescriptor(paramClass));
  }
  
  public static Type getType(Constructor paramConstructor) {
    return getType(getConstructorDescriptor(paramConstructor));
  }
  
  public static Type getType(Method paramMethod) {
    return getType(getMethodDescriptor(paramMethod));
  }
  
  public static Type[] getArgumentTypes(String paramString) {
    char[] arrayOfChar = paramString.toCharArray();
    int i = 1;
    byte b = 0;
    while (true) {
      Type[] arrayOfType;
      char c = arrayOfChar[i++];
      if (c == ')') {
        arrayOfType = new Type[b];
        i = 1;
        for (b = 0; arrayOfChar[i] != ')'; b++) {
          arrayOfType[b] = a(arrayOfChar, i);
          i += (arrayOfType[b]).d + (((arrayOfType[b]).a == 10) ? 2 : 0);
        } 
        return arrayOfType;
      } 
      if (arrayOfType == 76) {
        while (arrayOfChar[i++] != ';');
        b++;
        continue;
      } 
      if (arrayOfType != 91)
        b++; 
    } 
  }
  
  public static Type[] getArgumentTypes(Method paramMethod) {
    Class[] arrayOfClass = paramMethod.getParameterTypes();
    Type[] arrayOfType = new Type[arrayOfClass.length];
    for (int i = arrayOfClass.length - 1; i >= 0; i--)
      arrayOfType[i] = getType(arrayOfClass[i]); 
    return arrayOfType;
  }
  
  public static Type getReturnType(String paramString) {
    char[] arrayOfChar = paramString.toCharArray();
    return a(arrayOfChar, paramString.indexOf(')') + 1);
  }
  
  public static Type getReturnType(Method paramMethod) {
    return getType(paramMethod.getReturnType());
  }
  
  public static int getArgumentsAndReturnSizes(String paramString) {
    byte b1 = 1;
    byte b2 = 1;
    while (true) {
      char c = paramString.charAt(b2++);
      if (c == ')') {
        c = paramString.charAt(b2);
        return b1 << 2 | ((c == 'V') ? 0 : ((c == 'D' || c == 'J') ? 2 : 1));
      } 
      if (c == 'L') {
        while (paramString.charAt(b2++) != ';');
        b1++;
        continue;
      } 
      if (c == '[') {
        while ((c = paramString.charAt(b2)) == '[')
          b2++; 
        if (c == 'D' || c == 'J')
          b1--; 
        continue;
      } 
      if (c == 'D' || c == 'J') {
        b1 += 2;
        continue;
      } 
      b1++;
    } 
  }
  
  private static Type a(char[] paramArrayOfchar, int paramInt) {
    byte b;
    switch (paramArrayOfchar[paramInt]) {
      case 'V':
        return VOID_TYPE;
      case 'Z':
        return BOOLEAN_TYPE;
      case 'C':
        return CHAR_TYPE;
      case 'B':
        return BYTE_TYPE;
      case 'S':
        return SHORT_TYPE;
      case 'I':
        return INT_TYPE;
      case 'F':
        return FLOAT_TYPE;
      case 'J':
        return LONG_TYPE;
      case 'D':
        return DOUBLE_TYPE;
      case '[':
        for (b = 1; paramArrayOfchar[paramInt + b] == '['; b++);
        if (paramArrayOfchar[paramInt + b] == 'L')
          while (paramArrayOfchar[paramInt + ++b] != ';')
            b++;  
        return new Type(9, paramArrayOfchar, paramInt, b + 1);
      case 'L':
        for (b = 1; paramArrayOfchar[paramInt + b] != ';'; b++);
        return new Type(10, paramArrayOfchar, paramInt + 1, b - 1);
    } 
    return new Type(11, paramArrayOfchar, 0, paramArrayOfchar.length);
  }
  
  public int getSort() {
    return this.a;
  }
  
  public int getDimensions() {
    byte b;
    for (b = 1; this.b[this.c + b] == '['; b++);
    return b;
  }
  
  public Type getElementType() {
    return a(this.b, this.c + getDimensions());
  }
  
  public String getClassName() {
    StringBuffer stringBuffer;
    int i;
    switch (this.a) {
      case 0:
        return "void";
      case 1:
        return "boolean";
      case 2:
        return "char";
      case 3:
        return "byte";
      case 4:
        return "short";
      case 5:
        return "int";
      case 6:
        return "float";
      case 7:
        return "long";
      case 8:
        return "double";
      case 9:
        stringBuffer = new StringBuffer(getElementType().getClassName());
        for (i = getDimensions(); i > 0; i--)
          stringBuffer.append("[]"); 
        return stringBuffer.toString();
      case 10:
        return (new String(this.b, this.c, this.d)).replace('/', '.');
    } 
    return null;
  }
  
  public String getInternalName() {
    return new String(this.b, this.c, this.d);
  }
  
  public Type[] getArgumentTypes() {
    return getArgumentTypes(getDescriptor());
  }
  
  public Type getReturnType() {
    return getReturnType(getDescriptor());
  }
  
  public int getArgumentsAndReturnSizes() {
    return getArgumentsAndReturnSizes(getDescriptor());
  }
  
  public String getDescriptor() {
    StringBuffer stringBuffer = new StringBuffer();
    a(stringBuffer);
    return stringBuffer.toString();
  }
  
  public static String getMethodDescriptor(Type paramType, Type... paramVarArgs) {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append('(');
    for (byte b = 0; b < paramVarArgs.length; b++)
      paramVarArgs[b].a(stringBuffer); 
    stringBuffer.append(')');
    paramType.a(stringBuffer);
    return stringBuffer.toString();
  }
  
  private void a(StringBuffer paramStringBuffer) {
    if (this.b == null) {
      paramStringBuffer.append((char)((this.c & 0xFF000000) >>> 24));
    } else if (this.a == 10) {
      paramStringBuffer.append('L');
      paramStringBuffer.append(this.b, this.c, this.d);
      paramStringBuffer.append(';');
    } else {
      paramStringBuffer.append(this.b, this.c, this.d);
    } 
  }
  
  public static String getInternalName(Class paramClass) {
    return paramClass.getName().replace('.', '/');
  }
  
  public static String getDescriptor(Class paramClass) {
    StringBuffer stringBuffer = new StringBuffer();
    a(stringBuffer, paramClass);
    return stringBuffer.toString();
  }
  
  public static String getConstructorDescriptor(Constructor paramConstructor) {
    Class[] arrayOfClass = paramConstructor.getParameterTypes();
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append('(');
    for (byte b = 0; b < arrayOfClass.length; b++)
      a(stringBuffer, arrayOfClass[b]); 
    return stringBuffer.append(")V").toString();
  }
  
  public static String getMethodDescriptor(Method paramMethod) {
    Class[] arrayOfClass = paramMethod.getParameterTypes();
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append('(');
    for (byte b = 0; b < arrayOfClass.length; b++)
      a(stringBuffer, arrayOfClass[b]); 
    stringBuffer.append(')');
    a(stringBuffer, paramMethod.getReturnType());
    return stringBuffer.toString();
  }
  
  private static void a(StringBuffer paramStringBuffer, Class paramClass) {
    Class clazz = paramClass;
    while (true) {
      if (clazz.isPrimitive()) {
        byte b1;
        if (clazz == int.class) {
          b1 = 73;
        } else if (clazz == void.class) {
          b1 = 86;
        } else if (clazz == boolean.class) {
          b1 = 90;
        } else if (clazz == byte.class) {
          b1 = 66;
        } else if (clazz == char.class) {
          b1 = 67;
        } else if (clazz == short.class) {
          b1 = 83;
        } else if (clazz == double.class) {
          b1 = 68;
        } else if (clazz == float.class) {
          b1 = 70;
        } else {
          b1 = 74;
        } 
        paramStringBuffer.append(b1);
        return;
      } 
      if (clazz.isArray()) {
        paramStringBuffer.append('[');
        clazz = (Class)clazz.getComponentType();
        continue;
      } 
      paramStringBuffer.append('L');
      String str = clazz.getName();
      int i = str.length();
      for (byte b = 0; b < i; b++) {
        char c = str.charAt(b);
        paramStringBuffer.append((c == '.') ? 47 : c);
      } 
      paramStringBuffer.append(';');
      return;
    } 
  }
  
  public int getSize() {
    return (this.b == null) ? (this.c & 0xFF) : 1;
  }
  
  public int getOpcode(int paramInt) {
    return (paramInt == 46 || paramInt == 79) ? (paramInt + ((this.b == null) ? ((this.c & 0xFF00) >> 8) : 4)) : (paramInt + ((this.b == null) ? ((this.c & 0xFF0000) >> 16) : 4));
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof Type))
      return false; 
    Type type = (Type)paramObject;
    if (this.a != type.a)
      return false; 
    if (this.a >= 9) {
      if (this.d != type.d)
        return false; 
      int i = this.c;
      int j = type.c;
      int k = i + this.d;
      while (i < k) {
        if (this.b[i] != type.b[j])
          return false; 
        i++;
        j++;
      } 
    } 
    return true;
  }
  
  public int hashCode() {
    int i = 13 * this.a;
    if (this.a >= 9) {
      int j = this.c;
      int k = j + this.d;
      while (j < k) {
        i = 17 * (i + this.b[j]);
        j++;
      } 
    } 
    return i;
  }
  
  public String toString() {
    return getDescriptor();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\relocated\org\objectweb\asm\Type.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */