package org.bridj.relocated.org.objectweb.asm;

import java.io.IOException;
import java.io.InputStream;

public class ClassReader {
  public static final int SKIP_CODE = 1;
  
  public static final int SKIP_DEBUG = 2;
  
  public static final int SKIP_FRAMES = 4;
  
  public static final int EXPAND_FRAMES = 8;
  
  public final byte[] b;
  
  private final int[] a;
  
  private final String[] c;
  
  private final int d;
  
  public final int header;
  
  public ClassReader(byte[] paramArrayOfbyte) {
    this(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  public ClassReader(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    this.b = paramArrayOfbyte;
    if (readShort(6) > 51)
      throw new IllegalArgumentException(); 
    this.a = new int[readUnsignedShort(paramInt1 + 8)];
    int i = this.a.length;
    this.c = new String[i];
    int j = 0;
    int k = paramInt1 + 10;
    for (byte b = 1; b < i; b++) {
      int m;
      this.a[b] = k + 1;
      switch (paramArrayOfbyte[k]) {
        case 3:
        case 4:
        case 9:
        case 10:
        case 11:
        case 12:
        case 18:
          m = 5;
          break;
        case 5:
        case 6:
          m = 9;
          b++;
          break;
        case 1:
          m = 3 + readUnsignedShort(k + 1);
          if (m > j)
            j = m; 
          break;
        case 15:
          m = 4;
          break;
        default:
          m = 3;
          break;
      } 
      k += m;
    } 
    this.d = j;
    this.header = k;
  }
  
  public int getAccess() {
    return readUnsignedShort(this.header);
  }
  
  public String getClassName() {
    return readClass(this.header + 2, new char[this.d]);
  }
  
  public String getSuperName() {
    int i = this.a[readUnsignedShort(this.header + 4)];
    return (i == 0) ? null : readUTF8(i, new char[this.d]);
  }
  
  public String[] getInterfaces() {
    int i = this.header + 6;
    int j = readUnsignedShort(i);
    String[] arrayOfString = new String[j];
    if (j > 0) {
      char[] arrayOfChar = new char[this.d];
      for (byte b = 0; b < j; b++) {
        i += 2;
        arrayOfString[b] = readClass(i, arrayOfChar);
      } 
    } 
    return arrayOfString;
  }
  
  void a(ClassWriter paramClassWriter) {
    char[] arrayOfChar = new char[this.d];
    int i = this.a.length;
    Item[] arrayOfItem = new Item[i];
    int j;
    for (j = 1; j < i; j++) {
      int m;
      String str;
      int k = this.a[j];
      byte b = this.b[k - 1];
      Item item = new Item(j);
      switch (b) {
        case 9:
        case 10:
        case 11:
          m = this.a[readUnsignedShort(k + 2)];
          item.a(b, readClass(k, arrayOfChar), readUTF8(m, arrayOfChar), readUTF8(m + 2, arrayOfChar));
          break;
        case 3:
          item.a(readInt(k));
          break;
        case 4:
          item.a(Float.intBitsToFloat(readInt(k)));
          break;
        case 12:
          item.a(b, readUTF8(k, arrayOfChar), readUTF8(k + 2, arrayOfChar), null);
          break;
        case 5:
          item.a(readLong(k));
          j++;
          break;
        case 6:
          item.a(Double.longBitsToDouble(readLong(k)));
          j++;
          break;
        case 1:
          str = this.c[j];
          if (str == null) {
            k = this.a[j];
            str = this.c[j] = a(k + 2, readUnsignedShort(k), arrayOfChar);
          } 
          item.a(b, str, null, null);
          break;
        case 15:
          n = this.a[readUnsignedShort(k + 1)];
          m = this.a[readUnsignedShort(n + 2)];
          item.a(20 + readByte(k), readClass(n, arrayOfChar), readUTF8(m, arrayOfChar), readUTF8(m + 2, arrayOfChar));
          break;
        case 18:
          if (paramClassWriter.A == null)
            a(paramClassWriter, arrayOfItem, arrayOfChar); 
          m = this.a[readUnsignedShort(k + 2)];
          item.a(readUTF8(m, arrayOfChar), readUTF8(m + 2, arrayOfChar), readUnsignedShort(k));
          break;
        default:
          item.a(b, readUTF8(k, arrayOfChar), null, null);
          break;
      } 
      int n = item.j % arrayOfItem.length;
      item.k = arrayOfItem[n];
      arrayOfItem[n] = item;
    } 
    j = this.a[1] - 1;
    paramClassWriter.d.putByteArray(this.b, j, this.header - j);
    paramClassWriter.e = arrayOfItem;
    paramClassWriter.f = (int)(0.75D * i);
    paramClassWriter.c = i;
  }
  
  private void a(ClassWriter paramClassWriter, Item[] paramArrayOfItem, char[] paramArrayOfchar) {
    int i = this.header;
    i += 8 + (readUnsignedShort(i + 6) << 1);
    int j = readUnsignedShort(i);
    i += 2;
    while (j > 0) {
      int k = readUnsignedShort(i + 6);
      i += 8;
      while (k > 0) {
        i += 6 + readInt(i + 2);
        k--;
      } 
      j--;
    } 
    j = readUnsignedShort(i);
    i += 2;
    while (j > 0) {
      int k = readUnsignedShort(i + 6);
      i += 8;
      while (k > 0) {
        i += 6 + readInt(i + 2);
        k--;
      } 
      j--;
    } 
    j = readUnsignedShort(i);
    i += 2;
    while (j > 0) {
      String str = readUTF8(i, paramArrayOfchar);
      int k = readInt(i + 2);
      if ("BootstrapMethods".equals(str)) {
        int m = readUnsignedShort(i + 6);
        int n = i + 8;
        for (byte b = 0; b < m; b++) {
          int i1 = readConst(readUnsignedShort(n), paramArrayOfchar).hashCode();
          int i2 = readUnsignedShort(n + 2);
          int i3 = n + 4;
          while (i2 > 0) {
            i1 ^= readConst(readUnsignedShort(i3), paramArrayOfchar).hashCode();
            i3 += 2;
            i2--;
          } 
          Item item = new Item(b);
          item.a(n - i - 8, i1 & Integer.MAX_VALUE);
          int i4 = item.j % paramArrayOfItem.length;
          item.k = paramArrayOfItem[i4];
          paramArrayOfItem[i4] = item;
          n = i3;
        } 
        paramClassWriter.z = m;
        ByteVector byteVector = new ByteVector(k + 62);
        byteVector.putByteArray(this.b, i + 8, k - 2);
        paramClassWriter.A = byteVector;
        return;
      } 
      i += 6 + k;
      j--;
    } 
  }
  
  public ClassReader(InputStream paramInputStream) throws IOException {
    this(a(paramInputStream, false));
  }
  
  public ClassReader(String paramString) throws IOException {
    this(a(ClassLoader.getSystemResourceAsStream(paramString.replace('.', '/') + ".class"), true));
  }
  
  private static byte[] a(InputStream paramInputStream, boolean paramBoolean) throws IOException {
    if (paramInputStream == null)
      throw new IOException("Class not found"); 
    try {
      byte[] arrayOfByte = new byte[paramInputStream.available()];
      int i = 0;
      while (true) {
        int j = paramInputStream.read(arrayOfByte, i, arrayOfByte.length - i);
        if (j == -1) {
          if (i < arrayOfByte.length) {
            byte[] arrayOfByte1 = new byte[i];
            System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, i);
            arrayOfByte = arrayOfByte1;
          } 
          return arrayOfByte;
        } 
        i += j;
        if (i == arrayOfByte.length) {
          int k = paramInputStream.read();
          if (k < 0)
            return arrayOfByte; 
          byte[] arrayOfByte1 = new byte[arrayOfByte.length + 1000];
          System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, i);
          arrayOfByte1[i++] = (byte)k;
          arrayOfByte = arrayOfByte1;
        } 
      } 
    } finally {
      if (paramBoolean)
        paramInputStream.close(); 
    } 
  }
  
  public void accept(ClassVisitor paramClassVisitor, int paramInt) {
    accept(paramClassVisitor, new Attribute[0], paramInt);
  }
  
  public void accept(ClassVisitor paramClassVisitor, Attribute[] paramArrayOfAttribute, int paramInt) {
    byte[] arrayOfByte = this.b;
    char[] arrayOfChar = new char[this.d];
    int i = 0;
    int j = 0;
    Attribute attribute = null;
    int k = this.header;
    int m = readUnsignedShort(k);
    String str1 = readClass(k + 2, arrayOfChar);
    int n = this.a[readUnsignedShort(k + 4)];
    String str2 = (n == 0) ? null : readUTF8(n, arrayOfChar);
    String[] arrayOfString = new String[readUnsignedShort(k + 6)];
    int i1 = 0;
    k += 8;
    int i2;
    for (i2 = 0; i2 < arrayOfString.length; i2++) {
      arrayOfString[i2] = readClass(k, arrayOfChar);
      k += 2;
    } 
    boolean bool1 = ((paramInt & 0x1) != 0) ? true : false;
    boolean bool2 = ((paramInt & 0x2) != 0) ? true : false;
    boolean bool3 = ((paramInt & 0x8) != 0) ? true : false;
    n = k;
    i2 = readUnsignedShort(n);
    n += 2;
    while (i2 > 0) {
      int i3 = readUnsignedShort(n + 6);
      n += 8;
      while (i3 > 0) {
        n += 6 + readInt(n + 2);
        i3--;
      } 
      i2--;
    } 
    i2 = readUnsignedShort(n);
    n += 2;
    while (i2 > 0) {
      int i3 = readUnsignedShort(n + 6);
      n += 8;
      while (i3 > 0) {
        n += 6 + readInt(n + 2);
        i3--;
      } 
      i2--;
    } 
    String str3 = null;
    String str4 = null;
    String str5 = null;
    String str6 = null;
    String str7 = null;
    String str8 = null;
    int[] arrayOfInt = null;
    i2 = readUnsignedShort(n);
    n += 2;
    while (i2 > 0) {
      String str = readUTF8(n, arrayOfChar);
      if ("SourceFile".equals(str)) {
        str4 = readUTF8(n + 6, arrayOfChar);
      } else if ("InnerClasses".equals(str)) {
        i1 = n + 6;
      } else if ("EnclosingMethod".equals(str)) {
        str6 = readClass(n + 6, arrayOfChar);
        int i3 = readUnsignedShort(n + 8);
        if (i3 != 0) {
          str7 = readUTF8(this.a[i3], arrayOfChar);
          str8 = readUTF8(this.a[i3] + 2, arrayOfChar);
        } 
      } else if ("Signature".equals(str)) {
        str3 = readUTF8(n + 6, arrayOfChar);
      } else if ("RuntimeVisibleAnnotations".equals(str)) {
        i = n + 6;
      } else if ("Deprecated".equals(str)) {
        m |= 0x20000;
      } else if ("Synthetic".equals(str)) {
        m |= 0x41000;
      } else if ("SourceDebugExtension".equals(str)) {
        int i3 = readInt(n + 2);
        str5 = a(n + 6, i3, new char[i3]);
      } else if ("RuntimeInvisibleAnnotations".equals(str)) {
        j = n + 6;
      } else if ("BootstrapMethods".equals(str)) {
        int i3 = readUnsignedShort(n + 6);
        arrayOfInt = new int[i3];
        int i4 = n + 8;
        for (byte b = 0; b < i3; b++) {
          arrayOfInt[b] = i4;
          i4 += 2 + readUnsignedShort(i4 + 2) << 1;
        } 
      } else {
        Attribute attribute1 = a(paramArrayOfAttribute, str, n + 6, readInt(n + 2), arrayOfChar, -1, null);
        if (attribute1 != null) {
          attribute1.a = attribute;
          attribute = attribute1;
        } 
      } 
      n += 6 + readInt(n + 2);
      i2--;
    } 
    paramClassVisitor.visit(readInt(4), m, str1, str3, str2, arrayOfString);
    if (!bool2 && (str4 != null || str5 != null))
      paramClassVisitor.visitSource(str4, str5); 
    if (str6 != null)
      paramClassVisitor.visitOuterClass(str6, str7, str8); 
    for (i2 = 1; i2 >= 0; i2--) {
      n = (i2 == 0) ? j : i;
      if (n != 0) {
        int i3 = readUnsignedShort(n);
        n += 2;
        while (i3 > 0) {
          n = a(n + 2, arrayOfChar, true, paramClassVisitor.visitAnnotation(readUTF8(n, arrayOfChar), (i2 != 0)));
          i3--;
        } 
      } 
    } 
    while (attribute != null) {
      Attribute attribute1 = attribute.a;
      attribute.a = null;
      paramClassVisitor.visitAttribute(attribute);
      attribute = attribute1;
    } 
    if (i1 != 0) {
      i2 = readUnsignedShort(i1);
      i1 += 2;
      while (i2 > 0) {
        paramClassVisitor.visitInnerClass((readUnsignedShort(i1) == 0) ? null : readClass(i1, arrayOfChar), (readUnsignedShort(i1 + 2) == 0) ? null : readClass(i1 + 2, arrayOfChar), (readUnsignedShort(i1 + 4) == 0) ? null : readUTF8(i1 + 4, arrayOfChar), readUnsignedShort(i1 + 6));
        i1 += 8;
        i2--;
      } 
    } 
    i2 = readUnsignedShort(k);
    k += 2;
    while (i2 > 0) {
      m = readUnsignedShort(k);
      str1 = readUTF8(k + 2, arrayOfChar);
      String str = readUTF8(k + 4, arrayOfChar);
      int i4 = 0;
      str3 = null;
      i = 0;
      j = 0;
      attribute = null;
      int i3 = readUnsignedShort(k + 6);
      k += 8;
      while (i3 > 0) {
        String str9 = readUTF8(k, arrayOfChar);
        if ("ConstantValue".equals(str9)) {
          i4 = readUnsignedShort(k + 6);
        } else if ("Signature".equals(str9)) {
          str3 = readUTF8(k + 6, arrayOfChar);
        } else if ("Deprecated".equals(str9)) {
          m |= 0x20000;
        } else if ("Synthetic".equals(str9)) {
          m |= 0x41000;
        } else if ("RuntimeVisibleAnnotations".equals(str9)) {
          i = k + 6;
        } else if ("RuntimeInvisibleAnnotations".equals(str9)) {
          j = k + 6;
        } else {
          Attribute attribute1 = a(paramArrayOfAttribute, str9, k + 6, readInt(k + 2), arrayOfChar, -1, null);
          if (attribute1 != null) {
            attribute1.a = attribute;
            attribute = attribute1;
          } 
        } 
        k += 6 + readInt(k + 2);
        i3--;
      } 
      FieldVisitor fieldVisitor = paramClassVisitor.visitField(m, str1, str, str3, (i4 == 0) ? null : readConst(i4, arrayOfChar));
      if (fieldVisitor != null) {
        for (i3 = 1; i3 >= 0; i3--) {
          n = (i3 == 0) ? j : i;
          if (n != 0) {
            int i5 = readUnsignedShort(n);
            n += 2;
            while (i5 > 0) {
              n = a(n + 2, arrayOfChar, true, fieldVisitor.visitAnnotation(readUTF8(n, arrayOfChar), (i3 != 0)));
              i5--;
            } 
          } 
        } 
        while (attribute != null) {
          Attribute attribute1 = attribute.a;
          attribute.a = null;
          fieldVisitor.visitAttribute(attribute);
          attribute = attribute1;
        } 
        fieldVisitor.visitEnd();
      } 
      i2--;
    } 
    i2 = readUnsignedShort(k);
    k += 2;
    while (i2 > 0) {
      String[] arrayOfString1;
      int i4 = k + 6;
      m = readUnsignedShort(k);
      str1 = readUTF8(k + 2, arrayOfChar);
      String str = readUTF8(k + 4, arrayOfChar);
      str3 = null;
      i = 0;
      j = 0;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      attribute = null;
      n = 0;
      i1 = 0;
      int i3 = readUnsignedShort(k + 6);
      k += 8;
      while (i3 > 0) {
        String str9 = readUTF8(k, arrayOfChar);
        int i8 = readInt(k + 2);
        k += 6;
        if ("Code".equals(str9)) {
          if (!bool1)
            n = k; 
        } else if ("Exceptions".equals(str9)) {
          i1 = k;
        } else if ("Signature".equals(str9)) {
          str3 = readUTF8(k, arrayOfChar);
        } else if ("Deprecated".equals(str9)) {
          m |= 0x20000;
        } else if ("RuntimeVisibleAnnotations".equals(str9)) {
          i = k;
        } else if ("AnnotationDefault".equals(str9)) {
          i5 = k;
        } else if ("Synthetic".equals(str9)) {
          m |= 0x41000;
        } else if ("RuntimeInvisibleAnnotations".equals(str9)) {
          j = k;
        } else if ("RuntimeVisibleParameterAnnotations".equals(str9)) {
          i6 = k;
        } else if ("RuntimeInvisibleParameterAnnotations".equals(str9)) {
          i7 = k;
        } else {
          Attribute attribute1 = a(paramArrayOfAttribute, str9, k, i8, arrayOfChar, -1, null);
          if (attribute1 != null) {
            attribute1.a = attribute;
            attribute = attribute1;
          } 
        } 
        k += i8;
        i3--;
      } 
      if (i1 == 0) {
        arrayOfString1 = null;
      } else {
        arrayOfString1 = new String[readUnsignedShort(i1)];
        i1 += 2;
        for (i3 = 0; i3 < arrayOfString1.length; i3++) {
          arrayOfString1[i3] = readClass(i1, arrayOfChar);
          i1 += 2;
        } 
      } 
      MethodVisitor methodVisitor = paramClassVisitor.visitMethod(m, str1, str, str3, arrayOfString1);
      if (methodVisitor != null) {
        if (methodVisitor instanceof MethodWriter) {
          MethodWriter methodWriter = (MethodWriter)methodVisitor;
          if (methodWriter.b.M == this && str3 == methodWriter.g) {
            boolean bool = false;
            if (arrayOfString1 == null) {
              bool = (methodWriter.j == 0) ? true : false;
            } else if (arrayOfString1.length == methodWriter.j) {
              bool = true;
              for (i3 = arrayOfString1.length - 1; i3 >= 0; i3--) {
                i1 -= 2;
                if (methodWriter.k[i3] != readUnsignedShort(i1)) {
                  bool = false;
                  break;
                } 
              } 
            } 
            if (bool) {
              methodWriter.h = i4;
              methodWriter.i = k - i4;
              continue;
            } 
          } 
        } 
        if (i5 != 0) {
          AnnotationVisitor annotationVisitor = methodVisitor.visitAnnotationDefault();
          a(i5, arrayOfChar, (String)null, annotationVisitor);
          if (annotationVisitor != null)
            annotationVisitor.visitEnd(); 
        } 
        for (i3 = 1; i3 >= 0; i3--) {
          i1 = (i3 == 0) ? j : i;
          if (i1 != 0) {
            int i8 = readUnsignedShort(i1);
            i1 += 2;
            while (i8 > 0) {
              i1 = a(i1 + 2, arrayOfChar, true, methodVisitor.visitAnnotation(readUTF8(i1, arrayOfChar), (i3 != 0)));
              i8--;
            } 
          } 
        } 
        if (i6 != 0)
          a(i6, str, arrayOfChar, true, methodVisitor); 
        if (i7 != 0)
          a(i7, str, arrayOfChar, false, methodVisitor); 
        while (attribute != null) {
          Attribute attribute1 = attribute.a;
          attribute.a = null;
          methodVisitor.visitAttribute(attribute);
          attribute = attribute1;
        } 
      } 
      if (methodVisitor != null && n != 0) {
        int i8 = readUnsignedShort(n);
        int i9 = readUnsignedShort(n + 2);
        int i10 = readInt(n + 4);
        n += 8;
        int i11 = n;
        int i12 = n + i10;
        methodVisitor.visitCode();
        Label[] arrayOfLabel = new Label[i10 + 2];
        readLabel(i10 + 1, arrayOfLabel);
        while (n < i12) {
          i1 = n - i11;
          int i22 = arrayOfByte[n] & 0xFF;
          switch (ClassWriter.a[i22]) {
            case 0:
            case 4:
              n++;
              continue;
            case 9:
              readLabel(i1 + readShort(n + 1), arrayOfLabel);
              n += 3;
              continue;
            case 10:
              readLabel(i1 + readInt(n + 1), arrayOfLabel);
              n += 5;
              continue;
            case 17:
              i22 = arrayOfByte[n + 1] & 0xFF;
              if (i22 == 132) {
                n += 6;
                continue;
              } 
              n += 4;
              continue;
            case 14:
              n = n + 4 - (i1 & 0x3);
              readLabel(i1 + readInt(n), arrayOfLabel);
              i3 = readInt(n + 8) - readInt(n + 4) + 1;
              n += 12;
              while (i3 > 0) {
                readLabel(i1 + readInt(n), arrayOfLabel);
                n += 4;
                i3--;
              } 
              continue;
            case 15:
              n = n + 4 - (i1 & 0x3);
              readLabel(i1 + readInt(n), arrayOfLabel);
              i3 = readInt(n + 4);
              n += 8;
              while (i3 > 0) {
                readLabel(i1 + readInt(n + 4), arrayOfLabel);
                n += 8;
                i3--;
              } 
              continue;
            case 1:
            case 3:
            case 11:
              n += 2;
              continue;
            case 2:
            case 5:
            case 6:
            case 12:
            case 13:
              n += 3;
              continue;
            case 7:
            case 8:
              n += 5;
              continue;
          } 
          n += 4;
        } 
        i3 = readUnsignedShort(n);
        n += 2;
        while (i3 > 0) {
          Label label1 = readLabel(readUnsignedShort(n), arrayOfLabel);
          Label label2 = readLabel(readUnsignedShort(n + 2), arrayOfLabel);
          Label label3 = readLabel(readUnsignedShort(n + 4), arrayOfLabel);
          int i22 = readUnsignedShort(n + 6);
          if (i22 == 0) {
            methodVisitor.visitTryCatchBlock(label1, label2, label3, null);
          } else {
            methodVisitor.visitTryCatchBlock(label1, label2, label3, readUTF8(this.a[i22], arrayOfChar));
          } 
          n += 8;
          i3--;
        } 
        int i13 = 0;
        int i14 = 0;
        int i15 = 0;
        int i16 = 0;
        int i17 = 0;
        byte b = 0;
        int i18 = 0;
        int i19 = 0;
        int i20 = 0;
        int i21 = 0;
        Object[] arrayOfObject1 = null;
        Object[] arrayOfObject2 = null;
        boolean bool = true;
        attribute = null;
        i3 = readUnsignedShort(n);
        n += 2;
        while (i3 > 0) {
          String str9 = readUTF8(n, arrayOfChar);
          if ("LocalVariableTable".equals(str9)) {
            if (!bool2) {
              i13 = n + 6;
              int i22 = readUnsignedShort(n + 6);
              i1 = n + 8;
              while (i22 > 0) {
                int i23 = readUnsignedShort(i1);
                if (arrayOfLabel[i23] == null)
                  (readLabel(i23, arrayOfLabel)).a |= 0x1; 
                i23 += readUnsignedShort(i1 + 2);
                if (arrayOfLabel[i23] == null)
                  (readLabel(i23, arrayOfLabel)).a |= 0x1; 
                i1 += 10;
                i22--;
              } 
            } 
          } else if ("LocalVariableTypeTable".equals(str9)) {
            i14 = n + 6;
          } else if ("LineNumberTable".equals(str9)) {
            if (!bool2) {
              int i22 = readUnsignedShort(n + 6);
              i1 = n + 8;
              while (i22 > 0) {
                int i23 = readUnsignedShort(i1);
                if (arrayOfLabel[i23] == null)
                  (readLabel(i23, arrayOfLabel)).a |= 0x1; 
                (arrayOfLabel[i23]).b = readUnsignedShort(i1 + 2);
                i1 += 4;
                i22--;
              } 
            } 
          } else if ("StackMapTable".equals(str9)) {
            if ((paramInt & 0x4) == 0) {
              i15 = n + 8;
              i16 = readInt(n + 2);
              i17 = readUnsignedShort(n + 6);
            } 
          } else if ("StackMap".equals(str9)) {
            if ((paramInt & 0x4) == 0) {
              i15 = n + 8;
              i16 = readInt(n + 2);
              i17 = readUnsignedShort(n + 6);
              bool = false;
            } 
          } else {
            for (byte b1 = 0; b1 < paramArrayOfAttribute.length; b1++) {
              if ((paramArrayOfAttribute[b1]).type.equals(str9)) {
                Attribute attribute1 = paramArrayOfAttribute[b1].read(this, n + 6, readInt(n + 2), arrayOfChar, i11 - 8, arrayOfLabel);
                if (attribute1 != null) {
                  attribute1.a = attribute;
                  attribute = attribute1;
                } 
              } 
            } 
          } 
          n += 6 + readInt(n + 2);
          i3--;
        } 
        if (i15 != 0) {
          arrayOfObject1 = new Object[i9];
          arrayOfObject2 = new Object[i8];
          if (bool3) {
            byte b1 = 0;
            if ((m & 0x8) == 0)
              if ("<init>".equals(str1)) {
                arrayOfObject1[b1++] = Opcodes.UNINITIALIZED_THIS;
              } else {
                arrayOfObject1[b1++] = readClass(this.header + 2, arrayOfChar);
              }  
            i3 = 1;
            while (true) {
              int i22 = i3;
              switch (str.charAt(i3++)) {
                case 'B':
                case 'C':
                case 'I':
                case 'S':
                case 'Z':
                  arrayOfObject1[b1++] = Opcodes.INTEGER;
                  continue;
                case 'F':
                  arrayOfObject1[b1++] = Opcodes.FLOAT;
                  continue;
                case 'J':
                  arrayOfObject1[b1++] = Opcodes.LONG;
                  continue;
                case 'D':
                  arrayOfObject1[b1++] = Opcodes.DOUBLE;
                  continue;
                case '[':
                  while (str.charAt(i3) == '[')
                    i3++; 
                  if (str.charAt(i3) == 'L')
                    while (str.charAt(++i3) != ';')
                      i3++;  
                  arrayOfObject1[b1++] = str.substring(i22, ++i3);
                  continue;
                case 'L':
                  while (str.charAt(i3) != ';')
                    i3++; 
                  arrayOfObject1[b1++] = str.substring(i22 + 1, i3++);
                  continue;
              } 
              i19 = b1;
              break;
            } 
          } 
          i18 = -1;
          for (i3 = i15; i3 < i15 + i16 - 2; i3++) {
            if (arrayOfByte[i3] == 8) {
              int i22 = readUnsignedShort(i3 + 1);
              if (i22 >= 0 && i22 < i10 && (arrayOfByte[i11 + i22] & 0xFF) == 187)
                readLabel(i22, arrayOfLabel); 
            } 
          } 
        } 
        for (n = i11; n < i12; n += 4) {
          int i22;
          int i24;
          int i25;
          Label[] arrayOfLabel1;
          int[] arrayOfInt1;
          Label[] arrayOfLabel2;
          int i26;
          String str9;
          int i27;
          String str10;
          String str11;
          int i28;
          Handle handle;
          int i29;
          Object[] arrayOfObject;
          byte b1;
          i1 = n - i11;
          Label label1 = arrayOfLabel[i1];
          if (label1 != null) {
            methodVisitor.visitLabel(label1);
            if (!bool2 && label1.b > 0)
              methodVisitor.visitLineNumber(label1.b, label1); 
          } 
          while (arrayOfObject1 != null && (i18 == i1 || i18 == -1)) {
            if (!bool || bool3) {
              methodVisitor.visitFrame(-1, i19, arrayOfObject1, i21, arrayOfObject2);
            } else if (i18 != -1) {
              methodVisitor.visitFrame(b, i20, arrayOfObject1, i21, arrayOfObject2);
            } 
            if (i17 > 0) {
              char c;
              int i30;
              if (bool) {
                c = arrayOfByte[i15++] & 0xFF;
              } else {
                c = 'ÿ';
                i18 = -1;
              } 
              i20 = 0;
              if (c < '@') {
                i30 = c;
                b = 3;
                i21 = 0;
              } else if (c < '') {
                i30 = c - 64;
                i15 = a(arrayOfObject2, 0, i15, arrayOfChar, arrayOfLabel);
                b = 4;
                i21 = 1;
              } else {
                i30 = readUnsignedShort(i15);
                i15 += 2;
                if (c == '÷') {
                  i15 = a(arrayOfObject2, 0, i15, arrayOfChar, arrayOfLabel);
                  b = 4;
                  i21 = 1;
                } else if (c >= 'ø' && c < 'û') {
                  b = 2;
                  i20 = 251 - c;
                  i19 -= i20;
                  i21 = 0;
                } else if (c == 'û') {
                  b = 3;
                  i21 = 0;
                } else if (c < 'ÿ') {
                  i3 = bool3 ? i19 : 0;
                  for (int i31 = c - 251; i31 > 0; i31--)
                    i15 = a(arrayOfObject1, i3++, i15, arrayOfChar, arrayOfLabel); 
                  b = 1;
                  i20 = c - 251;
                  i19 += i20;
                  i21 = 0;
                } else {
                  b = 0;
                  int i31 = i20 = i19 = readUnsignedShort(i15);
                  i15 += 2;
                  i3 = 0;
                  while (i31 > 0) {
                    i15 = a(arrayOfObject1, i3++, i15, arrayOfChar, arrayOfLabel);
                    i31--;
                  } 
                  i31 = i21 = readUnsignedShort(i15);
                  i15 += 2;
                  i3 = 0;
                  while (i31 > 0) {
                    i15 = a(arrayOfObject2, i3++, i15, arrayOfChar, arrayOfLabel);
                    i31--;
                  } 
                } 
              } 
              i18 += i30 + 1;
              readLabel(i18, arrayOfLabel);
              i17--;
              continue;
            } 
            arrayOfObject1 = null;
          } 
          int i23 = arrayOfByte[n] & 0xFF;
          switch (ClassWriter.a[i23]) {
            case 0:
              methodVisitor.visitInsn(i23);
              n++;
              continue;
            case 4:
              if (i23 > 54) {
                i23 -= 59;
                methodVisitor.visitVarInsn(54 + (i23 >> 2), i23 & 0x3);
              } else {
                i23 -= 26;
                methodVisitor.visitVarInsn(21 + (i23 >> 2), i23 & 0x3);
              } 
              n++;
              continue;
            case 9:
              methodVisitor.visitJumpInsn(i23, arrayOfLabel[i1 + readShort(n + 1)]);
              n += 3;
              continue;
            case 10:
              methodVisitor.visitJumpInsn(i23 - 33, arrayOfLabel[i1 + readInt(n + 1)]);
              n += 5;
              continue;
            case 17:
              i23 = arrayOfByte[n + 1] & 0xFF;
              if (i23 == 132) {
                methodVisitor.visitIincInsn(readUnsignedShort(n + 2), readShort(n + 4));
                n += 6;
                continue;
              } 
              methodVisitor.visitVarInsn(i23, readUnsignedShort(n + 2));
              n += 4;
              continue;
            case 14:
              n = n + 4 - (i1 & 0x3);
              i22 = i1 + readInt(n);
              i24 = readInt(n + 4);
              i25 = readInt(n + 8);
              n += 12;
              arrayOfLabel1 = new Label[i25 - i24 + 1];
              for (i3 = 0; i3 < arrayOfLabel1.length; i3++) {
                arrayOfLabel1[i3] = arrayOfLabel[i1 + readInt(n)];
                n += 4;
              } 
              methodVisitor.visitTableSwitchInsn(i24, i25, arrayOfLabel[i22], arrayOfLabel1);
              continue;
            case 15:
              n = n + 4 - (i1 & 0x3);
              i22 = i1 + readInt(n);
              i3 = readInt(n + 4);
              n += 8;
              arrayOfInt1 = new int[i3];
              arrayOfLabel2 = new Label[i3];
              for (i3 = 0; i3 < arrayOfInt1.length; i3++) {
                arrayOfInt1[i3] = readInt(n);
                arrayOfLabel2[i3] = arrayOfLabel[i1 + readInt(n + 4)];
                n += 8;
              } 
              methodVisitor.visitLookupSwitchInsn(arrayOfLabel[i22], arrayOfInt1, arrayOfLabel2);
              continue;
            case 3:
              methodVisitor.visitVarInsn(i23, arrayOfByte[n + 1] & 0xFF);
              n += 2;
              continue;
            case 1:
              methodVisitor.visitIntInsn(i23, arrayOfByte[n + 1]);
              n += 2;
              continue;
            case 2:
              methodVisitor.visitIntInsn(i23, readShort(n + 1));
              n += 3;
              continue;
            case 11:
              methodVisitor.visitLdcInsn(readConst(arrayOfByte[n + 1] & 0xFF, arrayOfChar));
              n += 2;
              continue;
            case 12:
              methodVisitor.visitLdcInsn(readConst(readUnsignedShort(n + 1), arrayOfChar));
              n += 3;
              continue;
            case 6:
            case 7:
              i26 = this.a[readUnsignedShort(n + 1)];
              str9 = readClass(i26, arrayOfChar);
              i26 = this.a[readUnsignedShort(i26 + 2)];
              str10 = readUTF8(i26, arrayOfChar);
              str11 = readUTF8(i26 + 2, arrayOfChar);
              if (i23 < 182) {
                methodVisitor.visitFieldInsn(i23, str9, str10, str11);
              } else {
                methodVisitor.visitMethodInsn(i23, str9, str10, str11);
              } 
              if (i23 == 185) {
                n += 5;
                continue;
              } 
              n += 3;
              continue;
            case 8:
              i26 = this.a[readUnsignedShort(n + 1)];
              i27 = arrayOfInt[readUnsignedShort(i26)];
              i26 = this.a[readUnsignedShort(i26 + 2)];
              str10 = readUTF8(i26, arrayOfChar);
              str11 = readUTF8(i26 + 2, arrayOfChar);
              i28 = readUnsignedShort(i27);
              handle = (Handle)readConst(i28, arrayOfChar);
              i29 = readUnsignedShort(i27 + 2);
              arrayOfObject = new Object[i29];
              i27 += 4;
              for (b1 = 0; b1 < i29; b1++) {
                int i30 = readUnsignedShort(i27);
                arrayOfObject[b1] = readConst(i30, arrayOfChar);
                i27 += 2;
              } 
              methodVisitor.visitInvokeDynamicInsn(str10, str11, handle, arrayOfObject);
              n += 5;
              continue;
            case 5:
              methodVisitor.visitTypeInsn(i23, readClass(n + 1, arrayOfChar));
              n += 3;
              continue;
            case 13:
              methodVisitor.visitIincInsn(arrayOfByte[n + 1] & 0xFF, arrayOfByte[n + 2]);
              n += 3;
              continue;
          } 
          methodVisitor.visitMultiANewArrayInsn(readClass(n + 1, arrayOfChar), arrayOfByte[n + 3] & 0xFF);
        } 
        Label label = arrayOfLabel[i12 - i11];
        if (label != null)
          methodVisitor.visitLabel(label); 
        if (!bool2 && i13 != 0) {
          int[] arrayOfInt1 = null;
          if (i14 != 0) {
            int i23 = readUnsignedShort(i14) * 3;
            i1 = i14 + 2;
            arrayOfInt1 = new int[i23];
            while (i23 > 0) {
              arrayOfInt1[--i23] = i1 + 6;
              arrayOfInt1[--i23] = readUnsignedShort(i1 + 8);
              arrayOfInt1[--i23] = readUnsignedShort(i1);
              i1 += 10;
            } 
          } 
          int i22 = readUnsignedShort(i13);
          i1 = i13 + 2;
          while (i22 > 0) {
            int i23 = readUnsignedShort(i1);
            int i24 = readUnsignedShort(i1 + 2);
            int i25 = readUnsignedShort(i1 + 8);
            String str9 = null;
            if (arrayOfInt1 != null)
              for (byte b1 = 0; b1 < arrayOfInt1.length; b1 += 3) {
                if (arrayOfInt1[b1] == i23 && arrayOfInt1[b1 + 1] == i25) {
                  str9 = readUTF8(arrayOfInt1[b1 + 2], arrayOfChar);
                  break;
                } 
              }  
            methodVisitor.visitLocalVariable(readUTF8(i1 + 4, arrayOfChar), readUTF8(i1 + 6, arrayOfChar), str9, arrayOfLabel[i23], arrayOfLabel[i23 + i24], i25);
            i1 += 10;
            i22--;
          } 
        } 
        while (attribute != null) {
          Attribute attribute1 = attribute.a;
          attribute.a = null;
          methodVisitor.visitAttribute(attribute);
          attribute = attribute1;
        } 
        methodVisitor.visitMaxs(i8, i9);
      } 
      if (methodVisitor != null)
        methodVisitor.visitEnd(); 
      continue;
      i2--;
    } 
    paramClassVisitor.visitEnd();
  }
  
  private void a(int paramInt, String paramString, char[] paramArrayOfchar, boolean paramBoolean, MethodVisitor paramMethodVisitor) {
    int i = this.b[paramInt++] & 0xFF;
    int j = (Type.getArgumentTypes(paramString)).length - i;
    byte b;
    for (b = 0; b < j; b++) {
      AnnotationVisitor annotationVisitor = paramMethodVisitor.visitParameterAnnotation(b, "Ljava/lang/Synthetic;", false);
      if (annotationVisitor != null)
        annotationVisitor.visitEnd(); 
    } 
    while (b < i + j) {
      int k = readUnsignedShort(paramInt);
      paramInt += 2;
      while (k > 0) {
        AnnotationVisitor annotationVisitor = paramMethodVisitor.visitParameterAnnotation(b, readUTF8(paramInt, paramArrayOfchar), paramBoolean);
        paramInt = a(paramInt + 2, paramArrayOfchar, true, annotationVisitor);
        k--;
      } 
      b++;
    } 
  }
  
  private int a(int paramInt, char[] paramArrayOfchar, boolean paramBoolean, AnnotationVisitor paramAnnotationVisitor) {
    int i = readUnsignedShort(paramInt);
    paramInt += 2;
    if (paramBoolean) {
      while (i > 0) {
        paramInt = a(paramInt + 2, paramArrayOfchar, readUTF8(paramInt, paramArrayOfchar), paramAnnotationVisitor);
        i--;
      } 
    } else {
      while (i > 0) {
        paramInt = a(paramInt, paramArrayOfchar, (String)null, paramAnnotationVisitor);
        i--;
      } 
    } 
    if (paramAnnotationVisitor != null)
      paramAnnotationVisitor.visitEnd(); 
    return paramInt;
  }
  
  private int a(int paramInt, char[] paramArrayOfchar, String paramString, AnnotationVisitor paramAnnotationVisitor) {
    int i;
    byte[] arrayOfByte;
    byte b;
    boolean[] arrayOfBoolean;
    short[] arrayOfShort;
    char[] arrayOfChar;
    int[] arrayOfInt;
    long[] arrayOfLong;
    float[] arrayOfFloat;
    double[] arrayOfDouble;
    if (paramAnnotationVisitor == null) {
      switch (this.b[paramInt] & 0xFF) {
        case 101:
          return paramInt + 5;
        case 64:
          return a(paramInt + 3, paramArrayOfchar, true, (AnnotationVisitor)null);
        case 91:
          return a(paramInt + 1, paramArrayOfchar, false, (AnnotationVisitor)null);
      } 
      return paramInt + 3;
    } 
    switch (this.b[paramInt++] & 0xFF) {
      case 68:
      case 70:
      case 73:
      case 74:
        paramAnnotationVisitor.visit(paramString, readConst(readUnsignedShort(paramInt), paramArrayOfchar));
        paramInt += 2;
        break;
      case 66:
        paramAnnotationVisitor.visit(paramString, new Byte((byte)readInt(this.a[readUnsignedShort(paramInt)])));
        paramInt += 2;
        break;
      case 90:
        paramAnnotationVisitor.visit(paramString, (readInt(this.a[readUnsignedShort(paramInt)]) == 0) ? Boolean.FALSE : Boolean.TRUE);
        paramInt += 2;
        break;
      case 83:
        paramAnnotationVisitor.visit(paramString, new Short((short)readInt(this.a[readUnsignedShort(paramInt)])));
        paramInt += 2;
        break;
      case 67:
        paramAnnotationVisitor.visit(paramString, new Character((char)readInt(this.a[readUnsignedShort(paramInt)])));
        paramInt += 2;
        break;
      case 115:
        paramAnnotationVisitor.visit(paramString, readUTF8(paramInt, paramArrayOfchar));
        paramInt += 2;
        break;
      case 101:
        paramAnnotationVisitor.visitEnum(paramString, readUTF8(paramInt, paramArrayOfchar), readUTF8(paramInt + 2, paramArrayOfchar));
        paramInt += 4;
        break;
      case 99:
        paramAnnotationVisitor.visit(paramString, Type.getType(readUTF8(paramInt, paramArrayOfchar)));
        paramInt += 2;
        break;
      case 64:
        paramInt = a(paramInt + 2, paramArrayOfchar, true, paramAnnotationVisitor.visitAnnotation(paramString, readUTF8(paramInt, paramArrayOfchar)));
        break;
      case 91:
        i = readUnsignedShort(paramInt);
        paramInt += 2;
        if (i == 0)
          return a(paramInt - 2, paramArrayOfchar, false, paramAnnotationVisitor.visitArray(paramString)); 
        switch (this.b[paramInt++] & 0xFF) {
          case 66:
            arrayOfByte = new byte[i];
            for (b = 0; b < i; b++) {
              arrayOfByte[b] = (byte)readInt(this.a[readUnsignedShort(paramInt)]);
              paramInt += 3;
            } 
            paramAnnotationVisitor.visit(paramString, arrayOfByte);
            paramInt--;
            break;
          case 90:
            arrayOfBoolean = new boolean[i];
            for (b = 0; b < i; b++) {
              arrayOfBoolean[b] = (readInt(this.a[readUnsignedShort(paramInt)]) != 0);
              paramInt += 3;
            } 
            paramAnnotationVisitor.visit(paramString, arrayOfBoolean);
            paramInt--;
            break;
          case 83:
            arrayOfShort = new short[i];
            for (b = 0; b < i; b++) {
              arrayOfShort[b] = (short)readInt(this.a[readUnsignedShort(paramInt)]);
              paramInt += 3;
            } 
            paramAnnotationVisitor.visit(paramString, arrayOfShort);
            paramInt--;
            break;
          case 67:
            arrayOfChar = new char[i];
            for (b = 0; b < i; b++) {
              arrayOfChar[b] = (char)readInt(this.a[readUnsignedShort(paramInt)]);
              paramInt += 3;
            } 
            paramAnnotationVisitor.visit(paramString, arrayOfChar);
            paramInt--;
            break;
          case 73:
            arrayOfInt = new int[i];
            for (b = 0; b < i; b++) {
              arrayOfInt[b] = readInt(this.a[readUnsignedShort(paramInt)]);
              paramInt += 3;
            } 
            paramAnnotationVisitor.visit(paramString, arrayOfInt);
            paramInt--;
            break;
          case 74:
            arrayOfLong = new long[i];
            for (b = 0; b < i; b++) {
              arrayOfLong[b] = readLong(this.a[readUnsignedShort(paramInt)]);
              paramInt += 3;
            } 
            paramAnnotationVisitor.visit(paramString, arrayOfLong);
            paramInt--;
            break;
          case 70:
            arrayOfFloat = new float[i];
            for (b = 0; b < i; b++) {
              arrayOfFloat[b] = Float.intBitsToFloat(readInt(this.a[readUnsignedShort(paramInt)]));
              paramInt += 3;
            } 
            paramAnnotationVisitor.visit(paramString, arrayOfFloat);
            paramInt--;
            break;
          case 68:
            arrayOfDouble = new double[i];
            for (b = 0; b < i; b++) {
              arrayOfDouble[b] = Double.longBitsToDouble(readLong(this.a[readUnsignedShort(paramInt)]));
              paramInt += 3;
            } 
            paramAnnotationVisitor.visit(paramString, arrayOfDouble);
            paramInt--;
            break;
        } 
        paramInt = a(paramInt - 3, paramArrayOfchar, false, paramAnnotationVisitor.visitArray(paramString));
        break;
    } 
    return paramInt;
  }
  
  private int a(Object[] paramArrayOfObject, int paramInt1, int paramInt2, char[] paramArrayOfchar, Label[] paramArrayOfLabel) {
    int i = this.b[paramInt2++] & 0xFF;
    switch (i) {
      case 0:
        paramArrayOfObject[paramInt1] = Opcodes.TOP;
        return paramInt2;
      case 1:
        paramArrayOfObject[paramInt1] = Opcodes.INTEGER;
        return paramInt2;
      case 2:
        paramArrayOfObject[paramInt1] = Opcodes.FLOAT;
        return paramInt2;
      case 3:
        paramArrayOfObject[paramInt1] = Opcodes.DOUBLE;
        return paramInt2;
      case 4:
        paramArrayOfObject[paramInt1] = Opcodes.LONG;
        return paramInt2;
      case 5:
        paramArrayOfObject[paramInt1] = Opcodes.NULL;
        return paramInt2;
      case 6:
        paramArrayOfObject[paramInt1] = Opcodes.UNINITIALIZED_THIS;
        return paramInt2;
      case 7:
        paramArrayOfObject[paramInt1] = readClass(paramInt2, paramArrayOfchar);
        paramInt2 += 2;
        return paramInt2;
    } 
    paramArrayOfObject[paramInt1] = readLabel(readUnsignedShort(paramInt2), paramArrayOfLabel);
    paramInt2 += 2;
    return paramInt2;
  }
  
  protected Label readLabel(int paramInt, Label[] paramArrayOfLabel) {
    if (paramArrayOfLabel[paramInt] == null)
      paramArrayOfLabel[paramInt] = new Label(); 
    return paramArrayOfLabel[paramInt];
  }
  
  private Attribute a(Attribute[] paramArrayOfAttribute, String paramString, int paramInt1, int paramInt2, char[] paramArrayOfchar, int paramInt3, Label[] paramArrayOfLabel) {
    for (byte b = 0; b < paramArrayOfAttribute.length; b++) {
      if ((paramArrayOfAttribute[b]).type.equals(paramString))
        return paramArrayOfAttribute[b].read(this, paramInt1, paramInt2, paramArrayOfchar, paramInt3, paramArrayOfLabel); 
    } 
    return (new Attribute(paramString)).read(this, paramInt1, paramInt2, null, -1, null);
  }
  
  public int getItemCount() {
    return this.a.length;
  }
  
  public int getItem(int paramInt) {
    return this.a[paramInt];
  }
  
  public int getMaxStringLength() {
    return this.d;
  }
  
  public int readByte(int paramInt) {
    return this.b[paramInt] & 0xFF;
  }
  
  public int readUnsignedShort(int paramInt) {
    byte[] arrayOfByte = this.b;
    return (arrayOfByte[paramInt] & 0xFF) << 8 | arrayOfByte[paramInt + 1] & 0xFF;
  }
  
  public short readShort(int paramInt) {
    byte[] arrayOfByte = this.b;
    return (short)((arrayOfByte[paramInt] & 0xFF) << 8 | arrayOfByte[paramInt + 1] & 0xFF);
  }
  
  public int readInt(int paramInt) {
    byte[] arrayOfByte = this.b;
    return (arrayOfByte[paramInt] & 0xFF) << 24 | (arrayOfByte[paramInt + 1] & 0xFF) << 16 | (arrayOfByte[paramInt + 2] & 0xFF) << 8 | arrayOfByte[paramInt + 3] & 0xFF;
  }
  
  public long readLong(int paramInt) {
    long l1 = readInt(paramInt);
    long l2 = readInt(paramInt + 4) & 0xFFFFFFFFL;
    return l1 << 32L | l2;
  }
  
  public String readUTF8(int paramInt, char[] paramArrayOfchar) {
    int i = readUnsignedShort(paramInt);
    String str = this.c[i];
    if (str != null)
      return str; 
    paramInt = this.a[i];
    this.c[i] = a(paramInt + 2, readUnsignedShort(paramInt), paramArrayOfchar);
    return a(paramInt + 2, readUnsignedShort(paramInt), paramArrayOfchar);
  }
  
  private String a(int paramInt1, int paramInt2, char[] paramArrayOfchar) {
    int i = paramInt1 + paramInt2;
    byte[] arrayOfByte = this.b;
    byte b1 = 0;
    byte b2 = 0;
    char c = Character.MIN_VALUE;
    while (paramInt1 < i) {
      int j;
      byte b = arrayOfByte[paramInt1++];
      switch (b2) {
        case false:
          j = b & 0xFF;
          if (j < 128) {
            paramArrayOfchar[b1++] = (char)j;
            continue;
          } 
          if (j < 224 && j > 191) {
            c = (char)(j & 0x1F);
            b2 = 1;
            continue;
          } 
          c = (char)(j & 0xF);
          b2 = 2;
        case true:
          paramArrayOfchar[b1++] = (char)(c << 6 | j & 0x3F);
          b2 = 0;
        case true:
          c = (char)(c << 6 | j & 0x3F);
          b2 = 1;
      } 
    } 
    return new String(paramArrayOfchar, 0, b1);
  }
  
  public String readClass(int paramInt, char[] paramArrayOfchar) {
    return readUTF8(this.a[readUnsignedShort(paramInt)], paramArrayOfchar);
  }
  
  public Object readConst(int paramInt, char[] paramArrayOfchar) {
    int i = this.a[paramInt];
    switch (this.b[i - 1]) {
      case 3:
        return new Integer(readInt(i));
      case 4:
        return new Float(Float.intBitsToFloat(readInt(i)));
      case 5:
        return new Long(readLong(i));
      case 6:
        return new Double(Double.longBitsToDouble(readLong(i)));
      case 7:
        return Type.getObjectType(readUTF8(i, paramArrayOfchar));
      case 8:
        return readUTF8(i, paramArrayOfchar);
      case 16:
        return Type.getMethodType(readUTF8(i, paramArrayOfchar));
    } 
    int j = readByte(i);
    int[] arrayOfInt = this.a;
    int k = arrayOfInt[readUnsignedShort(i + 1)];
    String str1 = readClass(k, paramArrayOfchar);
    k = arrayOfInt[readUnsignedShort(k + 2)];
    String str2 = readUTF8(k, paramArrayOfchar);
    String str3 = readUTF8(k + 2, paramArrayOfchar);
    return new Handle(j, str1, str2, str3);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\relocated\org\objectweb\asm\ClassReader.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */