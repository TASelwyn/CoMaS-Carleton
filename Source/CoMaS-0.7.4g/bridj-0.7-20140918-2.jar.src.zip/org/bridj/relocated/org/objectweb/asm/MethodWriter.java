package org.bridj.relocated.org.objectweb.asm;

class MethodWriter extends MethodVisitor {
  final ClassWriter b;
  
  private int c;
  
  private final int d;
  
  private final int e;
  
  private final String f;
  
  String g;
  
  int h;
  
  int i;
  
  int j;
  
  int[] k;
  
  private ByteVector l;
  
  private AnnotationWriter m;
  
  private AnnotationWriter n;
  
  private AnnotationWriter[] o;
  
  private AnnotationWriter[] p;
  
  private int S;
  
  private Attribute q;
  
  private ByteVector r = new ByteVector();
  
  private int s;
  
  private int t;
  
  private int T;
  
  private int u;
  
  private ByteVector v;
  
  private int w;
  
  private int[] x;
  
  private int y;
  
  private int[] z;
  
  private int A;
  
  private Handler B;
  
  private Handler C;
  
  private int D;
  
  private ByteVector E;
  
  private int F;
  
  private ByteVector G;
  
  private int H;
  
  private ByteVector I;
  
  private Attribute J;
  
  private boolean K;
  
  private int L;
  
  private final int M;
  
  private Label N;
  
  private Label O;
  
  private Label P;
  
  private int Q;
  
  private int R;
  
  MethodWriter(ClassWriter paramClassWriter, int paramInt, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString, boolean paramBoolean1, boolean paramBoolean2) {
    super(262144);
    if (paramClassWriter.D == null) {
      paramClassWriter.D = this;
    } else {
      paramClassWriter.E.mv = this;
    } 
    paramClassWriter.E = this;
    this.b = paramClassWriter;
    this.c = paramInt;
    this.d = paramClassWriter.newUTF8(paramString1);
    this.e = paramClassWriter.newUTF8(paramString2);
    this.f = paramString2;
    this.g = paramString3;
    if (paramArrayOfString != null && paramArrayOfString.length > 0) {
      this.j = paramArrayOfString.length;
      this.k = new int[this.j];
      for (byte b = 0; b < this.j; b++)
        this.k[b] = paramClassWriter.newClass(paramArrayOfString[b]); 
    } 
    this.M = paramBoolean2 ? 0 : (paramBoolean1 ? 1 : 2);
    if (paramBoolean1 || paramBoolean2) {
      if (paramBoolean2 && "<init>".equals(paramString1))
        this.c |= 0x40000; 
      int i = Type.getArgumentsAndReturnSizes(this.f) >> 2;
      if ((paramInt & 0x8) != 0)
        i--; 
      this.t = i;
      this.T = i;
      this.N = new Label();
      this.N.a |= 0x8;
      visitLabel(this.N);
    } 
  }
  
  public AnnotationVisitor visitAnnotationDefault() {
    this.l = new ByteVector();
    return new AnnotationWriter(this.b, false, this.l, null, 0);
  }
  
  public AnnotationVisitor visitAnnotation(String paramString, boolean paramBoolean) {
    ByteVector byteVector = new ByteVector();
    byteVector.putShort(this.b.newUTF8(paramString)).putShort(0);
    AnnotationWriter annotationWriter = new AnnotationWriter(this.b, true, byteVector, byteVector, 2);
    if (paramBoolean) {
      annotationWriter.g = this.m;
      this.m = annotationWriter;
    } else {
      annotationWriter.g = this.n;
      this.n = annotationWriter;
    } 
    return annotationWriter;
  }
  
  public AnnotationVisitor visitParameterAnnotation(int paramInt, String paramString, boolean paramBoolean) {
    ByteVector byteVector = new ByteVector();
    if ("Ljava/lang/Synthetic;".equals(paramString)) {
      this.S = Math.max(this.S, paramInt + 1);
      return new AnnotationWriter(this.b, false, byteVector, null, 0);
    } 
    byteVector.putShort(this.b.newUTF8(paramString)).putShort(0);
    AnnotationWriter annotationWriter = new AnnotationWriter(this.b, true, byteVector, byteVector, 2);
    if (paramBoolean) {
      if (this.o == null)
        this.o = new AnnotationWriter[(Type.getArgumentTypes(this.f)).length]; 
      annotationWriter.g = this.o[paramInt];
      this.o[paramInt] = annotationWriter;
    } else {
      if (this.p == null)
        this.p = new AnnotationWriter[(Type.getArgumentTypes(this.f)).length]; 
      annotationWriter.g = this.p[paramInt];
      this.p[paramInt] = annotationWriter;
    } 
    return annotationWriter;
  }
  
  public void visitAttribute(Attribute paramAttribute) {
    if (paramAttribute.isCodeAttribute()) {
      paramAttribute.a = this.J;
      this.J = paramAttribute;
    } else {
      paramAttribute.a = this.q;
      this.q = paramAttribute;
    } 
  }
  
  public void visitCode() {}
  
  public void visitFrame(int paramInt1, int paramInt2, Object[] paramArrayOfObject1, int paramInt3, Object[] paramArrayOfObject2) {
    if (this.M == 0)
      return; 
    if (paramInt1 == -1) {
      this.T = paramInt2;
      a(this.r.b, paramInt2, paramInt3);
      byte b;
      for (b = 0; b < paramInt2; b++) {
        if (paramArrayOfObject1[b] instanceof String) {
          this.z[this.y++] = 0x1700000 | this.b.c((String)paramArrayOfObject1[b]);
        } else if (paramArrayOfObject1[b] instanceof Integer) {
          this.z[this.y++] = ((Integer)paramArrayOfObject1[b]).intValue();
        } else {
          this.z[this.y++] = 0x1800000 | this.b.a("", ((Label)paramArrayOfObject1[b]).c);
        } 
      } 
      for (b = 0; b < paramInt3; b++) {
        if (paramArrayOfObject2[b] instanceof String) {
          this.z[this.y++] = 0x1700000 | this.b.c((String)paramArrayOfObject2[b]);
        } else if (paramArrayOfObject2[b] instanceof Integer) {
          this.z[this.y++] = ((Integer)paramArrayOfObject2[b]).intValue();
        } else {
          this.z[this.y++] = 0x1800000 | this.b.a("", ((Label)paramArrayOfObject2[b]).c);
        } 
      } 
      b();
    } else {
      int i;
      byte b;
      if (this.v == null) {
        this.v = new ByteVector();
        i = this.r.b;
      } else {
        i = this.r.b - this.w - 1;
        if (i < 0) {
          if (paramInt1 == 3)
            return; 
          throw new IllegalStateException();
        } 
      } 
      switch (paramInt1) {
        case 0:
          this.T = paramInt2;
          this.v.putByte(255).putShort(i).putShort(paramInt2);
          for (b = 0; b < paramInt2; b++)
            a(paramArrayOfObject1[b]); 
          this.v.putShort(paramInt3);
          for (b = 0; b < paramInt3; b++)
            a(paramArrayOfObject2[b]); 
          break;
        case 1:
          this.T += paramInt2;
          this.v.putByte(251 + paramInt2).putShort(i);
          for (b = 0; b < paramInt2; b++)
            a(paramArrayOfObject1[b]); 
          break;
        case 2:
          this.T -= paramInt2;
          this.v.putByte(251 - paramInt2).putShort(i);
          break;
        case 3:
          if (i < 64) {
            this.v.putByte(i);
            break;
          } 
          this.v.putByte(251).putShort(i);
          break;
        case 4:
          if (i < 64) {
            this.v.putByte(64 + i);
          } else {
            this.v.putByte(247).putShort(i);
          } 
          a(paramArrayOfObject2[0]);
          break;
      } 
      this.w = this.r.b;
      this.u++;
    } 
    this.s = Math.max(this.s, paramInt3);
    this.t = Math.max(this.t, this.T);
  }
  
  public void visitInsn(int paramInt) {
    this.r.putByte(paramInt);
    if (this.P != null) {
      if (this.M == 0) {
        this.P.h.a(paramInt, 0, (ClassWriter)null, (Item)null);
      } else {
        int i = this.Q + Frame.a[paramInt];
        if (i > this.R)
          this.R = i; 
        this.Q = i;
      } 
      if ((paramInt >= 172 && paramInt <= 177) || paramInt == 191)
        e(); 
    } 
  }
  
  public void visitIntInsn(int paramInt1, int paramInt2) {
    if (this.P != null)
      if (this.M == 0) {
        this.P.h.a(paramInt1, paramInt2, (ClassWriter)null, (Item)null);
      } else if (paramInt1 != 188) {
        int i = this.Q + 1;
        if (i > this.R)
          this.R = i; 
        this.Q = i;
      }  
    if (paramInt1 == 17) {
      this.r.b(paramInt1, paramInt2);
    } else {
      this.r.a(paramInt1, paramInt2);
    } 
  }
  
  public void visitVarInsn(int paramInt1, int paramInt2) {
    if (this.P != null)
      if (this.M == 0) {
        this.P.h.a(paramInt1, paramInt2, (ClassWriter)null, (Item)null);
      } else if (paramInt1 == 169) {
        this.P.a |= 0x100;
        this.P.f = this.Q;
        e();
      } else {
        int i = this.Q + Frame.a[paramInt1];
        if (i > this.R)
          this.R = i; 
        this.Q = i;
      }  
    if (this.M != 2) {
      int i;
      if (paramInt1 == 22 || paramInt1 == 24 || paramInt1 == 55 || paramInt1 == 57) {
        i = paramInt2 + 2;
      } else {
        i = paramInt2 + 1;
      } 
      if (i > this.t)
        this.t = i; 
    } 
    if (paramInt2 < 4 && paramInt1 != 169) {
      int i;
      if (paramInt1 < 54) {
        i = 26 + (paramInt1 - 21 << 2) + paramInt2;
      } else {
        i = 59 + (paramInt1 - 54 << 2) + paramInt2;
      } 
      this.r.putByte(i);
    } else if (paramInt2 >= 256) {
      this.r.putByte(196).b(paramInt1, paramInt2);
    } else {
      this.r.a(paramInt1, paramInt2);
    } 
    if (paramInt1 >= 54 && this.M == 0 && this.A > 0)
      visitLabel(new Label()); 
  }
  
  public void visitTypeInsn(int paramInt, String paramString) {
    Item item = this.b.a(paramString);
    if (this.P != null)
      if (this.M == 0) {
        this.P.h.a(paramInt, this.r.b, this.b, item);
      } else if (paramInt == 187) {
        int i = this.Q + 1;
        if (i > this.R)
          this.R = i; 
        this.Q = i;
      }  
    this.r.b(paramInt, item.a);
  }
  
  public void visitFieldInsn(int paramInt, String paramString1, String paramString2, String paramString3) {
    Item item = this.b.a(paramString1, paramString2, paramString3);
    if (this.P != null)
      if (this.M == 0) {
        this.P.h.a(paramInt, 0, this.b, item);
      } else {
        int i;
        char c = paramString3.charAt(0);
        switch (paramInt) {
          case 178:
            i = this.Q + ((c == 'D' || c == 'J') ? 2 : 1);
            break;
          case 179:
            i = this.Q + ((c == 'D' || c == 'J') ? -2 : -1);
            break;
          case 180:
            i = this.Q + ((c == 'D' || c == 'J') ? 1 : 0);
            break;
          default:
            i = this.Q + ((c == 'D' || c == 'J') ? -3 : -2);
            break;
        } 
        if (i > this.R)
          this.R = i; 
        this.Q = i;
      }  
    this.r.b(paramInt, item.a);
  }
  
  public void visitMethodInsn(int paramInt, String paramString1, String paramString2, String paramString3) {
    boolean bool = (paramInt == 185) ? true : false;
    Item item = this.b.a(paramString1, paramString2, paramString3, bool);
    int i = item.c;
    if (this.P != null)
      if (this.M == 0) {
        this.P.h.a(paramInt, 0, this.b, item);
      } else {
        int j;
        if (i == 0) {
          i = Type.getArgumentsAndReturnSizes(paramString3);
          item.c = i;
        } 
        if (paramInt == 184) {
          j = this.Q - (i >> 2) + (i & 0x3) + 1;
        } else {
          j = this.Q - (i >> 2) + (i & 0x3);
        } 
        if (j > this.R)
          this.R = j; 
        this.Q = j;
      }  
    if (bool) {
      if (i == 0) {
        i = Type.getArgumentsAndReturnSizes(paramString3);
        item.c = i;
      } 
      this.r.b(185, item.a).a(i >> 2, 0);
    } else {
      this.r.b(paramInt, item.a);
    } 
  }
  
  public void visitInvokeDynamicInsn(String paramString1, String paramString2, Handle paramHandle, Object... paramVarArgs) {
    Item item = this.b.a(paramString1, paramString2, paramHandle, paramVarArgs);
    int i = item.c;
    if (this.P != null)
      if (this.M == 0) {
        this.P.h.a(186, 0, this.b, item);
      } else {
        if (i == 0) {
          i = Type.getArgumentsAndReturnSizes(paramString2);
          item.c = i;
        } 
        int j = this.Q - (i >> 2) + (i & 0x3) + 1;
        if (j > this.R)
          this.R = j; 
        this.Q = j;
      }  
    this.r.b(186, item.a);
    this.r.putShort(0);
  }
  
  public void visitJumpInsn(int paramInt, Label paramLabel) {
    Label label = null;
    if (this.P != null)
      if (this.M == 0) {
        this.P.h.a(paramInt, 0, (ClassWriter)null, (Item)null);
        (paramLabel.a()).a |= 0x10;
        a(0, paramLabel);
        if (paramInt != 167)
          label = new Label(); 
      } else if (paramInt == 168) {
        if ((paramLabel.a & 0x200) == 0) {
          paramLabel.a |= 0x200;
          this.L++;
        } 
        this.P.a |= 0x80;
        a(this.Q + 1, paramLabel);
        label = new Label();
      } else {
        this.Q += Frame.a[paramInt];
        a(this.Q, paramLabel);
      }  
    if ((paramLabel.a & 0x2) != 0 && paramLabel.c - this.r.b < -32768) {
      if (paramInt == 167) {
        this.r.putByte(200);
      } else if (paramInt == 168) {
        this.r.putByte(201);
      } else {
        if (label != null)
          label.a |= 0x10; 
        this.r.putByte((paramInt <= 166) ? ((paramInt + 1 ^ 0x1) - 1) : (paramInt ^ 0x1));
        this.r.putShort(8);
        this.r.putByte(200);
      } 
      paramLabel.a(this, this.r, this.r.b - 1, true);
    } else {
      this.r.putByte(paramInt);
      paramLabel.a(this, this.r, this.r.b - 1, false);
    } 
    if (this.P != null) {
      if (label != null)
        visitLabel(label); 
      if (paramInt == 167)
        e(); 
    } 
  }
  
  public void visitLabel(Label paramLabel) {
    this.K |= paramLabel.a(this, this.r.b, this.r.a);
    if ((paramLabel.a & 0x1) != 0)
      return; 
    if (this.M == 0) {
      if (this.P != null) {
        if (paramLabel.c == this.P.c) {
          this.P.a |= paramLabel.a & 0x10;
          paramLabel.h = this.P.h;
          return;
        } 
        a(0, paramLabel);
      } 
      this.P = paramLabel;
      if (paramLabel.h == null) {
        paramLabel.h = new Frame();
        paramLabel.h.b = paramLabel;
      } 
      if (this.O != null) {
        if (paramLabel.c == this.O.c) {
          this.O.a |= paramLabel.a & 0x10;
          paramLabel.h = this.O.h;
          this.P = this.O;
          return;
        } 
        this.O.i = paramLabel;
      } 
      this.O = paramLabel;
    } else if (this.M == 1) {
      if (this.P != null) {
        this.P.g = this.R;
        a(this.Q, paramLabel);
      } 
      this.P = paramLabel;
      this.Q = 0;
      this.R = 0;
      if (this.O != null)
        this.O.i = paramLabel; 
      this.O = paramLabel;
    } 
  }
  
  public void visitLdcInsn(Object paramObject) {
    Item item = this.b.a(paramObject);
    if (this.P != null)
      if (this.M == 0) {
        this.P.h.a(18, 0, this.b, item);
      } else {
        int j;
        if (item.b == 5 || item.b == 6) {
          j = this.Q + 2;
        } else {
          j = this.Q + 1;
        } 
        if (j > this.R)
          this.R = j; 
        this.Q = j;
      }  
    int i = item.a;
    if (item.b == 5 || item.b == 6) {
      this.r.b(20, i);
    } else if (i >= 256) {
      this.r.b(19, i);
    } else {
      this.r.a(18, i);
    } 
  }
  
  public void visitIincInsn(int paramInt1, int paramInt2) {
    if (this.P != null && this.M == 0)
      this.P.h.a(132, paramInt1, (ClassWriter)null, (Item)null); 
    if (this.M != 2) {
      int i = paramInt1 + 1;
      if (i > this.t)
        this.t = i; 
    } 
    if (paramInt1 > 255 || paramInt2 > 127 || paramInt2 < -128) {
      this.r.putByte(196).b(132, paramInt1).putShort(paramInt2);
    } else {
      this.r.putByte(132).a(paramInt1, paramInt2);
    } 
  }
  
  public void visitTableSwitchInsn(int paramInt1, int paramInt2, Label paramLabel, Label... paramVarArgs) {
    int i = this.r.b;
    this.r.putByte(170);
    this.r.putByteArray(null, 0, (4 - this.r.b % 4) % 4);
    paramLabel.a(this, this.r, i, true);
    this.r.putInt(paramInt1).putInt(paramInt2);
    for (byte b = 0; b < paramVarArgs.length; b++)
      paramVarArgs[b].a(this, this.r, i, true); 
    a(paramLabel, paramVarArgs);
  }
  
  public void visitLookupSwitchInsn(Label paramLabel, int[] paramArrayOfint, Label[] paramArrayOfLabel) {
    int i = this.r.b;
    this.r.putByte(171);
    this.r.putByteArray(null, 0, (4 - this.r.b % 4) % 4);
    paramLabel.a(this, this.r, i, true);
    this.r.putInt(paramArrayOfLabel.length);
    for (byte b = 0; b < paramArrayOfLabel.length; b++) {
      this.r.putInt(paramArrayOfint[b]);
      paramArrayOfLabel[b].a(this, this.r, i, true);
    } 
    a(paramLabel, paramArrayOfLabel);
  }
  
  private void a(Label paramLabel, Label[] paramArrayOfLabel) {
    if (this.P != null) {
      if (this.M == 0) {
        this.P.h.a(171, 0, (ClassWriter)null, (Item)null);
        a(0, paramLabel);
        (paramLabel.a()).a |= 0x10;
        for (byte b = 0; b < paramArrayOfLabel.length; b++) {
          a(0, paramArrayOfLabel[b]);
          (paramArrayOfLabel[b].a()).a |= 0x10;
        } 
      } else {
        this.Q--;
        a(this.Q, paramLabel);
        for (byte b = 0; b < paramArrayOfLabel.length; b++)
          a(this.Q, paramArrayOfLabel[b]); 
      } 
      e();
    } 
  }
  
  public void visitMultiANewArrayInsn(String paramString, int paramInt) {
    Item item = this.b.a(paramString);
    if (this.P != null)
      if (this.M == 0) {
        this.P.h.a(197, paramInt, this.b, item);
      } else {
        this.Q += 1 - paramInt;
      }  
    this.r.b(197, item.a).putByte(paramInt);
  }
  
  public void visitTryCatchBlock(Label paramLabel1, Label paramLabel2, Label paramLabel3, String paramString) {
    this.A++;
    Handler handler = new Handler();
    handler.a = paramLabel1;
    handler.b = paramLabel2;
    handler.c = paramLabel3;
    handler.d = paramString;
    handler.e = (paramString != null) ? this.b.newClass(paramString) : 0;
    if (this.C == null) {
      this.B = handler;
    } else {
      this.C.f = handler;
    } 
    this.C = handler;
  }
  
  public void visitLocalVariable(String paramString1, String paramString2, String paramString3, Label paramLabel1, Label paramLabel2, int paramInt) {
    if (paramString3 != null) {
      if (this.G == null)
        this.G = new ByteVector(); 
      this.F++;
      this.G.putShort(paramLabel1.c).putShort(paramLabel2.c - paramLabel1.c).putShort(this.b.newUTF8(paramString1)).putShort(this.b.newUTF8(paramString3)).putShort(paramInt);
    } 
    if (this.E == null)
      this.E = new ByteVector(); 
    this.D++;
    this.E.putShort(paramLabel1.c).putShort(paramLabel2.c - paramLabel1.c).putShort(this.b.newUTF8(paramString1)).putShort(this.b.newUTF8(paramString2)).putShort(paramInt);
    if (this.M != 2) {
      char c = paramString2.charAt(0);
      int i = paramInt + ((c == 'J' || c == 'D') ? 2 : 1);
      if (i > this.t)
        this.t = i; 
    } 
  }
  
  public void visitLineNumber(int paramInt, Label paramLabel) {
    if (this.I == null)
      this.I = new ByteVector(); 
    this.H++;
    this.I.putShort(paramLabel.c);
    this.I.putShort(paramInt);
  }
  
  public void visitMaxs(int paramInt1, int paramInt2) {
    if (this.M == 0) {
      Handler handler;
      for (handler = this.B; handler != null; handler = handler.f) {
        Label label3 = handler.a.a();
        Label label4 = handler.c.a();
        Label label5 = handler.b.a();
        String str = (handler.d == null) ? "java/lang/Throwable" : handler.d;
        int j = 0x1700000 | this.b.c(str);
        label4.a |= 0x10;
        while (label3 != label5) {
          Edge edge = new Edge();
          edge.a = j;
          edge.b = label4;
          edge.c = label3.j;
          label3.j = edge;
          label3 = label3.i;
        } 
      } 
      Frame frame = this.N.h;
      Type[] arrayOfType = Type.getArgumentTypes(this.f);
      frame.a(this.b, this.c, arrayOfType, this.t);
      b(frame);
      int i = 0;
      Label label1 = this.N;
      while (label1 != null) {
        Label label = label1;
        label1 = label1.k;
        label.k = null;
        frame = label.h;
        if ((label.a & 0x10) != 0)
          label.a |= 0x20; 
        label.a |= 0x40;
        int j = frame.d.length + label.g;
        if (j > i)
          i = j; 
        for (Edge edge = label.j; edge != null; edge = edge.c) {
          Label label3 = edge.b.a();
          boolean bool = frame.a(this.b, label3.h, edge.a);
          if (bool && label3.k == null) {
            label3.k = label1;
            label1 = label3;
          } 
        } 
      } 
      for (Label label2 = this.N; label2 != null; label2 = label2.i) {
        frame = label2.h;
        if ((label2.a & 0x20) != 0)
          b(frame); 
        if ((label2.a & 0x40) == 0) {
          Label label = label2.i;
          int j = label2.c;
          int k = ((label == null) ? this.r.b : label.c) - 1;
          if (k >= j) {
            i = Math.max(i, 1);
            for (int m = j; m < k; m++)
              this.r.a[m] = 0; 
            this.r.a[k] = -65;
            a(j, 0, 1);
            this.z[this.y++] = 0x1700000 | this.b.c("java/lang/Throwable");
            b();
            this.B = Handler.a(this.B, label2, label);
          } 
        } 
      } 
      handler = this.B;
      this.A = 0;
      while (handler != null) {
        this.A++;
        handler = handler.f;
      } 
      this.s = i;
    } else if (this.M == 1) {
      for (Handler handler = this.B; handler != null; handler = handler.f) {
        Label label1 = handler.a;
        Label label2 = handler.c;
        Label label3 = handler.b;
        while (label1 != label3) {
          Edge edge = new Edge();
          edge.a = Integer.MAX_VALUE;
          edge.b = label2;
          if ((label1.a & 0x80) == 0) {
            edge.c = label1.j;
            label1.j = edge;
          } else {
            edge.c = label1.j.c.c;
            label1.j.c.c = edge;
          } 
          label1 = label1.i;
        } 
      } 
      if (this.L > 0) {
        byte b = 0;
        this.N.b(null, 1L, this.L);
        Label label1;
        for (label1 = this.N; label1 != null; label1 = label1.i) {
          if ((label1.a & 0x80) != 0) {
            Label label2 = label1.j.c.b;
            if ((label2.a & 0x400) == 0)
              label2.b(null, ++b / 32L << 32L | 1L << b % 32, this.L); 
          } 
        } 
        for (label1 = this.N; label1 != null; label1 = label1.i) {
          if ((label1.a & 0x80) != 0) {
            for (Label label2 = this.N; label2 != null; label2 = label2.i)
              label2.a &= 0xFFFFF7FF; 
            Label label3 = label1.j.c.b;
            label3.b(label1, 0L, this.L);
          } 
        } 
      } 
      int i = 0;
      Label label = this.N;
      while (label != null) {
        Label label1 = label;
        label = label.k;
        int j = label1.f;
        int k = j + label1.g;
        if (k > i)
          i = k; 
        Edge edge = label1.j;
        if ((label1.a & 0x80) != 0)
          edge = edge.c; 
        while (edge != null) {
          label1 = edge.b;
          if ((label1.a & 0x8) == 0) {
            label1.f = (edge.a == Integer.MAX_VALUE) ? 1 : (j + edge.a);
            label1.a |= 0x8;
            label1.k = label;
            label = label1;
          } 
          edge = edge.c;
        } 
      } 
      this.s = Math.max(paramInt1, i);
    } else {
      this.s = paramInt1;
      this.t = paramInt2;
    } 
  }
  
  public void visitEnd() {}
  
  private void a(int paramInt, Label paramLabel) {
    Edge edge = new Edge();
    edge.a = paramInt;
    edge.b = paramLabel;
    edge.c = this.P.j;
    this.P.j = edge;
  }
  
  private void e() {
    if (this.M == 0) {
      Label label = new Label();
      label.h = new Frame();
      label.h.b = label;
      label.a(this, this.r.b, this.r.a);
      this.O.i = label;
      this.O = label;
    } else {
      this.P.g = this.R;
    } 
    this.P = null;
  }
  
  private void b(Frame paramFrame) {
    byte b1 = 0;
    int i = 0;
    byte b2 = 0;
    int[] arrayOfInt1 = paramFrame.c;
    int[] arrayOfInt2 = paramFrame.d;
    byte b3;
    for (b3 = 0; b3 < arrayOfInt1.length; b3++) {
      int j = arrayOfInt1[b3];
      if (j == 16777216) {
        b1++;
      } else {
        i += b1 + 1;
        b1 = 0;
      } 
      if (j == 16777220 || j == 16777219)
        b3++; 
    } 
    for (b3 = 0; b3 < arrayOfInt2.length; b3++) {
      int j = arrayOfInt2[b3];
      b2++;
      if (j == 16777220 || j == 16777219)
        b3++; 
    } 
    a(paramFrame.b.c, i, b2);
    b3 = 0;
    while (i > 0) {
      int j = arrayOfInt1[b3];
      this.z[this.y++] = j;
      if (j == 16777220 || j == 16777219)
        b3++; 
      b3++;
      i--;
    } 
    for (b3 = 0; b3 < arrayOfInt2.length; b3++) {
      int j = arrayOfInt2[b3];
      this.z[this.y++] = j;
      if (j == 16777220 || j == 16777219)
        b3++; 
    } 
    b();
  }
  
  private void a(int paramInt1, int paramInt2, int paramInt3) {
    int i = 3 + paramInt2 + paramInt3;
    if (this.z == null || this.z.length < i)
      this.z = new int[i]; 
    this.z[0] = paramInt1;
    this.z[1] = paramInt2;
    this.z[2] = paramInt3;
    this.y = 3;
  }
  
  private void b() {
    if (this.x != null) {
      if (this.v == null)
        this.v = new ByteVector(); 
      c();
      this.u++;
    } 
    this.x = this.z;
    this.z = null;
  }
  
  private void c() {
    int n;
    int i = this.z[1];
    int j = this.z[2];
    if ((this.b.b & 0xFFFF) < 50) {
      this.v.putShort(this.z[0]).putShort(i);
      a(3, 3 + i);
      this.v.putShort(j);
      a(3 + i, 3 + i + j);
      return;
    } 
    int k = this.x[1];
    char c = 'ÿ';
    int m = 0;
    if (this.u == 0) {
      n = this.z[0];
    } else {
      n = this.z[0] - this.x[0] - 1;
    } 
    if (j == 0) {
      m = i - k;
      switch (m) {
        case -3:
        case -2:
        case -1:
          c = 'ø';
          k = i;
          break;
        case 0:
          c = (n < 64) ? Character.MIN_VALUE : 'û';
          break;
        case 1:
        case 2:
        case 3:
          c = 'ü';
          break;
      } 
    } else if (i == k && j == 1) {
      c = (n < 63) ? '@' : '÷';
    } 
    if (c != 'ÿ') {
      byte b1 = 3;
      for (byte b2 = 0; b2 < k; b2++) {
        if (this.z[b1] != this.x[b1]) {
          c = 'ÿ';
          break;
        } 
        b1++;
      } 
    } 
    switch (c) {
      case '\000':
        this.v.putByte(n);
        return;
      case '@':
        this.v.putByte(64 + n);
        a(3 + i, 4 + i);
        return;
      case '÷':
        this.v.putByte(247).putShort(n);
        a(3 + i, 4 + i);
        return;
      case 'û':
        this.v.putByte(251).putShort(n);
        return;
      case 'ø':
        this.v.putByte(251 + m).putShort(n);
        return;
      case 'ü':
        this.v.putByte(251 + m).putShort(n);
        a(3 + k, 3 + i);
        return;
    } 
    this.v.putByte(255).putShort(n).putShort(i);
    a(3, 3 + i);
    this.v.putShort(j);
    a(3 + i, 3 + i + j);
  }
  
  private void a(int paramInt1, int paramInt2) {
    for (int i = paramInt1; i < paramInt2; i++) {
      int j = this.z[i];
      int k = j & 0xF0000000;
      if (k == 0) {
        int m = j & 0xFFFFF;
        switch (j & 0xFF00000) {
          case 24117248:
            this.v.putByte(7).putShort(this.b.newClass((this.b.H[m]).g));
            break;
          case 25165824:
            this.v.putByte(8).putShort((this.b.H[m]).c);
            break;
          default:
            this.v.putByte(m);
            break;
        } 
      } else {
        StringBuffer stringBuffer = new StringBuffer();
        k >>= 28;
        while (k-- > 0)
          stringBuffer.append('['); 
        if ((j & 0xFF00000) == 24117248) {
          stringBuffer.append('L');
          stringBuffer.append((this.b.H[j & 0xFFFFF]).g);
          stringBuffer.append(';');
        } else {
          switch (j & 0xF) {
            case 1:
              stringBuffer.append('I');
              break;
            case 2:
              stringBuffer.append('F');
              break;
            case 3:
              stringBuffer.append('D');
              break;
            case 9:
              stringBuffer.append('Z');
              break;
            case 10:
              stringBuffer.append('B');
              break;
            case 11:
              stringBuffer.append('C');
              break;
            case 12:
              stringBuffer.append('S');
              break;
            default:
              stringBuffer.append('J');
              break;
          } 
        } 
        this.v.putByte(7).putShort(this.b.newClass(stringBuffer.toString()));
      } 
    } 
  }
  
  private void a(Object paramObject) {
    if (paramObject instanceof String) {
      this.v.putByte(7).putShort(this.b.newClass((String)paramObject));
    } else if (paramObject instanceof Integer) {
      this.v.putByte(((Integer)paramObject).intValue());
    } else {
      this.v.putByte(8).putShort(((Label)paramObject).c);
    } 
  }
  
  final int a() {
    if (this.h != 0)
      return 6 + this.i; 
    if (this.K)
      d(); 
    int i = 8;
    if (this.r.b > 0) {
      if (this.r.b > 65536)
        throw new RuntimeException("Method code too large!"); 
      this.b.newUTF8("Code");
      i += 18 + this.r.b + 8 * this.A;
      if (this.E != null) {
        this.b.newUTF8("LocalVariableTable");
        i += 8 + this.E.b;
      } 
      if (this.G != null) {
        this.b.newUTF8("LocalVariableTypeTable");
        i += 8 + this.G.b;
      } 
      if (this.I != null) {
        this.b.newUTF8("LineNumberTable");
        i += 8 + this.I.b;
      } 
      if (this.v != null) {
        boolean bool = ((this.b.b & 0xFFFF) >= 50) ? true : false;
        this.b.newUTF8(bool ? "StackMapTable" : "StackMap");
        i += 8 + this.v.b;
      } 
      if (this.J != null)
        i += this.J.a(this.b, this.r.a, this.r.b, this.s, this.t); 
    } 
    if (this.j > 0) {
      this.b.newUTF8("Exceptions");
      i += 8 + 2 * this.j;
    } 
    if ((this.c & 0x1000) != 0 && ((this.b.b & 0xFFFF) < 49 || (this.c & 0x40000) != 0)) {
      this.b.newUTF8("Synthetic");
      i += 6;
    } 
    if ((this.c & 0x20000) != 0) {
      this.b.newUTF8("Deprecated");
      i += 6;
    } 
    if (this.g != null) {
      this.b.newUTF8("Signature");
      this.b.newUTF8(this.g);
      i += 8;
    } 
    if (this.l != null) {
      this.b.newUTF8("AnnotationDefault");
      i += 6 + this.l.b;
    } 
    if (this.m != null) {
      this.b.newUTF8("RuntimeVisibleAnnotations");
      i += 8 + this.m.a();
    } 
    if (this.n != null) {
      this.b.newUTF8("RuntimeInvisibleAnnotations");
      i += 8 + this.n.a();
    } 
    if (this.o != null) {
      this.b.newUTF8("RuntimeVisibleParameterAnnotations");
      i += 7 + 2 * (this.o.length - this.S);
      for (int j = this.o.length - 1; j >= this.S; j--)
        i += (this.o[j] == null) ? 0 : this.o[j].a(); 
    } 
    if (this.p != null) {
      this.b.newUTF8("RuntimeInvisibleParameterAnnotations");
      i += 7 + 2 * (this.p.length - this.S);
      for (int j = this.p.length - 1; j >= this.S; j--)
        i += (this.p[j] == null) ? 0 : this.p[j].a(); 
    } 
    if (this.q != null)
      i += this.q.a(this.b, null, 0, -1, -1); 
    return i;
  }
  
  final void a(ByteVector paramByteVector) {
    int i = 0x60000 | (this.c & 0x40000) / 64;
    paramByteVector.putShort(this.c & (i ^ 0xFFFFFFFF)).putShort(this.d).putShort(this.e);
    if (this.h != 0) {
      paramByteVector.putByteArray(this.b.M.b, this.h, this.i);
      return;
    } 
    int j = 0;
    if (this.r.b > 0)
      j++; 
    if (this.j > 0)
      j++; 
    if ((this.c & 0x1000) != 0 && ((this.b.b & 0xFFFF) < 49 || (this.c & 0x40000) != 0))
      j++; 
    if ((this.c & 0x20000) != 0)
      j++; 
    if (this.g != null)
      j++; 
    if (this.l != null)
      j++; 
    if (this.m != null)
      j++; 
    if (this.n != null)
      j++; 
    if (this.o != null)
      j++; 
    if (this.p != null)
      j++; 
    if (this.q != null)
      j += this.q.a(); 
    paramByteVector.putShort(j);
    if (this.r.b > 0) {
      int k = 12 + this.r.b + 8 * this.A;
      if (this.E != null)
        k += 8 + this.E.b; 
      if (this.G != null)
        k += 8 + this.G.b; 
      if (this.I != null)
        k += 8 + this.I.b; 
      if (this.v != null)
        k += 8 + this.v.b; 
      if (this.J != null)
        k += this.J.a(this.b, this.r.a, this.r.b, this.s, this.t); 
      paramByteVector.putShort(this.b.newUTF8("Code")).putInt(k);
      paramByteVector.putShort(this.s).putShort(this.t);
      paramByteVector.putInt(this.r.b).putByteArray(this.r.a, 0, this.r.b);
      paramByteVector.putShort(this.A);
      if (this.A > 0)
        for (Handler handler = this.B; handler != null; handler = handler.f)
          paramByteVector.putShort(handler.a.c).putShort(handler.b.c).putShort(handler.c.c).putShort(handler.e);  
      j = 0;
      if (this.E != null)
        j++; 
      if (this.G != null)
        j++; 
      if (this.I != null)
        j++; 
      if (this.v != null)
        j++; 
      if (this.J != null)
        j += this.J.a(); 
      paramByteVector.putShort(j);
      if (this.E != null) {
        paramByteVector.putShort(this.b.newUTF8("LocalVariableTable"));
        paramByteVector.putInt(this.E.b + 2).putShort(this.D);
        paramByteVector.putByteArray(this.E.a, 0, this.E.b);
      } 
      if (this.G != null) {
        paramByteVector.putShort(this.b.newUTF8("LocalVariableTypeTable"));
        paramByteVector.putInt(this.G.b + 2).putShort(this.F);
        paramByteVector.putByteArray(this.G.a, 0, this.G.b);
      } 
      if (this.I != null) {
        paramByteVector.putShort(this.b.newUTF8("LineNumberTable"));
        paramByteVector.putInt(this.I.b + 2).putShort(this.H);
        paramByteVector.putByteArray(this.I.a, 0, this.I.b);
      } 
      if (this.v != null) {
        boolean bool = ((this.b.b & 0xFFFF) >= 50) ? true : false;
        paramByteVector.putShort(this.b.newUTF8(bool ? "StackMapTable" : "StackMap"));
        paramByteVector.putInt(this.v.b + 2).putShort(this.u);
        paramByteVector.putByteArray(this.v.a, 0, this.v.b);
      } 
      if (this.J != null)
        this.J.a(this.b, this.r.a, this.r.b, this.t, this.s, paramByteVector); 
    } 
    if (this.j > 0) {
      paramByteVector.putShort(this.b.newUTF8("Exceptions")).putInt(2 * this.j + 2);
      paramByteVector.putShort(this.j);
      for (byte b = 0; b < this.j; b++)
        paramByteVector.putShort(this.k[b]); 
    } 
    if ((this.c & 0x1000) != 0 && ((this.b.b & 0xFFFF) < 49 || (this.c & 0x40000) != 0))
      paramByteVector.putShort(this.b.newUTF8("Synthetic")).putInt(0); 
    if ((this.c & 0x20000) != 0)
      paramByteVector.putShort(this.b.newUTF8("Deprecated")).putInt(0); 
    if (this.g != null)
      paramByteVector.putShort(this.b.newUTF8("Signature")).putInt(2).putShort(this.b.newUTF8(this.g)); 
    if (this.l != null) {
      paramByteVector.putShort(this.b.newUTF8("AnnotationDefault"));
      paramByteVector.putInt(this.l.b);
      paramByteVector.putByteArray(this.l.a, 0, this.l.b);
    } 
    if (this.m != null) {
      paramByteVector.putShort(this.b.newUTF8("RuntimeVisibleAnnotations"));
      this.m.a(paramByteVector);
    } 
    if (this.n != null) {
      paramByteVector.putShort(this.b.newUTF8("RuntimeInvisibleAnnotations"));
      this.n.a(paramByteVector);
    } 
    if (this.o != null) {
      paramByteVector.putShort(this.b.newUTF8("RuntimeVisibleParameterAnnotations"));
      AnnotationWriter.a(this.o, this.S, paramByteVector);
    } 
    if (this.p != null) {
      paramByteVector.putShort(this.b.newUTF8("RuntimeInvisibleParameterAnnotations"));
      AnnotationWriter.a(this.p, this.S, paramByteVector);
    } 
    if (this.q != null)
      this.q.a(this.b, null, 0, -1, -1, paramByteVector); 
  }
  
  private void d() {
    int i;
    ByteVector byteVector;
    int k;
    int m;
    int n;
    int i1;
    byte[] arrayOfByte = this.r.a;
    int[] arrayOfInt1 = new int[0];
    int[] arrayOfInt2 = new int[0];
    boolean[] arrayOfBoolean = new boolean[this.r.b];
    byte b = 3;
    while (true) {
      if (b == 3)
        b = 2; 
      i = 0;
      while (i < arrayOfByte.length) {
        int i4;
        int i2 = arrayOfByte[i] & 0xFF;
        int i3 = 0;
        switch (ClassWriter.a[i2]) {
          case 0:
          case 4:
            i++;
            break;
          case 9:
            if (i2 > 201) {
              i2 = (i2 < 218) ? (i2 - 49) : (i2 - 20);
              k = i + c(arrayOfByte, i + 1);
            } else {
              k = i + b(arrayOfByte, i + 1);
            } 
            i4 = a(arrayOfInt1, arrayOfInt2, i, k);
            if ((i4 < -32768 || i4 > 32767) && !arrayOfBoolean[i]) {
              if (i2 == 167 || i2 == 168) {
                i3 = 2;
              } else {
                i3 = 5;
              } 
              arrayOfBoolean[i] = true;
            } 
            i += 3;
            break;
          case 10:
            i += 5;
            break;
          case 14:
            if (b == 1) {
              i4 = a(arrayOfInt1, arrayOfInt2, 0, i);
              i3 = -(i4 & 0x3);
            } else if (!arrayOfBoolean[i]) {
              i3 = i & 0x3;
              arrayOfBoolean[i] = true;
            } 
            i = i + 4 - (i & 0x3);
            i += 4 * (a(arrayOfByte, i + 8) - a(arrayOfByte, i + 4) + 1) + 12;
            break;
          case 15:
            if (b == 1) {
              i4 = a(arrayOfInt1, arrayOfInt2, 0, i);
              i3 = -(i4 & 0x3);
            } else if (!arrayOfBoolean[i]) {
              i3 = i & 0x3;
              arrayOfBoolean[i] = true;
            } 
            i = i + 4 - (i & 0x3);
            i += 8 * a(arrayOfByte, i + 4) + 8;
            break;
          case 17:
            i2 = arrayOfByte[i + 1] & 0xFF;
            if (i2 == 132) {
              i += 6;
              break;
            } 
            i += 4;
            break;
          case 1:
          case 3:
          case 11:
            i += 2;
            break;
          case 2:
          case 5:
          case 6:
          case 12:
          case 13:
            i += 3;
            break;
          case 7:
          case 8:
            i += 5;
            break;
          default:
            i += 4;
            break;
        } 
        if (i3 != 0) {
          int[] arrayOfInt3 = new int[arrayOfInt1.length + 1];
          int[] arrayOfInt4 = new int[arrayOfInt2.length + 1];
          System.arraycopy(arrayOfInt1, 0, arrayOfInt3, 0, arrayOfInt1.length);
          System.arraycopy(arrayOfInt2, 0, arrayOfInt4, 0, arrayOfInt2.length);
          arrayOfInt3[arrayOfInt1.length] = i;
          arrayOfInt4[arrayOfInt2.length] = i3;
          arrayOfInt1 = arrayOfInt3;
          arrayOfInt2 = arrayOfInt4;
          if (i3 > 0)
            b = 3; 
        } 
      } 
      if (b < 3)
        b--; 
      if (b == 0) {
        byteVector = new ByteVector(this.r.b);
        for (i = 0;; i += 4)
          byteVector.putByteArray(arrayOfByte, i, 4); 
        if (this.u > 0)
          if (this.M == 0) {
            this.u = 0;
            this.v = null;
            this.x = null;
            this.z = null;
            Frame frame = new Frame();
            frame.b = this.N;
            Type[] arrayOfType = Type.getArgumentTypes(this.f);
            frame.a(this.b, this.c, arrayOfType, this.t);
            b(frame);
            for (Label label = this.N; label != null; label = label.i) {
              i = label.c - 3;
              if ((label.a & 0x20) != 0 || (i >= 0 && arrayOfBoolean[i])) {
                a(arrayOfInt1, arrayOfInt2, label);
                b(label.h);
              } 
            } 
          } else {
            this.b.L = true;
          }  
        for (Handler handler = this.B; handler != null; handler = handler.f) {
          a(arrayOfInt1, arrayOfInt2, handler.a);
          a(arrayOfInt1, arrayOfInt2, handler.b);
          a(arrayOfInt1, arrayOfInt2, handler.c);
        } 
        int i2;
        for (i2 = 0; i2 < 2; i2++) {
          ByteVector byteVector1 = (i2 == 0) ? this.E : this.G;
          if (byteVector1 != null) {
            arrayOfByte = byteVector1.a;
            for (i = 0; i < byteVector1.b; i += 10) {
              k = c(arrayOfByte, i);
              int i3 = a(arrayOfInt1, arrayOfInt2, 0, k);
              a(arrayOfByte, i, i3);
              k += c(arrayOfByte, i + 2);
              i3 = a(arrayOfInt1, arrayOfInt2, 0, k) - i3;
              a(arrayOfByte, i + 2, i3);
            } 
          } 
        } 
        if (this.I != null) {
          arrayOfByte = this.I.a;
          for (i = 0; i < this.I.b; i += 4)
            a(arrayOfByte, i, a(arrayOfInt1, arrayOfInt2, 0, c(arrayOfByte, i))); 
        } 
        for (Attribute attribute = this.J; attribute != null; attribute = attribute.a) {
          Label[] arrayOfLabel = attribute.getLabels();
          if (arrayOfLabel != null)
            for (i2 = arrayOfLabel.length - 1; i2 >= 0; i2--)
              a(arrayOfInt1, arrayOfInt2, arrayOfLabel[i2]);  
        } 
        this.r = byteVector;
        return;
      } 
    } 
    int j = arrayOfByte[i] & 0xFF;
    switch (ClassWriter.a[j]) {
      case 0:
      case 4:
        byteVector.putByte(j);
        i++;
        continue;
      case 9:
        if (j > 201) {
          j = (j < 218) ? (j - 49) : (j - 20);
          k = i + c(arrayOfByte, i + 1);
        } else {
          k = i + b(arrayOfByte, i + 1);
        } 
        m = a(arrayOfInt1, arrayOfInt2, i, k);
        if (arrayOfBoolean[i]) {
          if (j == 167) {
            byteVector.putByte(200);
          } else if (j == 168) {
            byteVector.putByte(201);
          } else {
            byteVector.putByte((j <= 166) ? ((j + 1 ^ 0x1) - 1) : (j ^ 0x1));
            byteVector.putShort(8);
            byteVector.putByte(200);
            m -= 3;
          } 
          byteVector.putInt(m);
        } else {
          byteVector.putByte(j);
          byteVector.putShort(m);
        } 
        i += 3;
        continue;
      case 10:
        k = i + a(arrayOfByte, i + 1);
        m = a(arrayOfInt1, arrayOfInt2, i, k);
        byteVector.putByte(j);
        byteVector.putInt(m);
        i += 5;
        continue;
      case 14:
        n = i;
        i = i + 4 - (n & 0x3);
        byteVector.putByte(170);
        byteVector.putByteArray(null, 0, (4 - byteVector.b % 4) % 4);
        k = n + a(arrayOfByte, i);
        i += 4;
        m = a(arrayOfInt1, arrayOfInt2, n, k);
        byteVector.putInt(m);
        i1 = a(arrayOfByte, i);
        i += 4;
        byteVector.putInt(i1);
        i1 = a(arrayOfByte, i) - i1 + 1;
        i += 4;
        byteVector.putInt(a(arrayOfByte, i - 4));
        while (i1 > 0) {
          k = n + a(arrayOfByte, i);
          i += 4;
          m = a(arrayOfInt1, arrayOfInt2, n, k);
          byteVector.putInt(m);
          i1--;
        } 
        continue;
      case 15:
        n = i;
        i = i + 4 - (n & 0x3);
        byteVector.putByte(171);
        byteVector.putByteArray(null, 0, (4 - byteVector.b % 4) % 4);
        k = n + a(arrayOfByte, i);
        i += 4;
        m = a(arrayOfInt1, arrayOfInt2, n, k);
        byteVector.putInt(m);
        i1 = a(arrayOfByte, i);
        i += 4;
        byteVector.putInt(i1);
        while (i1 > 0) {
          byteVector.putInt(a(arrayOfByte, i));
          i += 4;
          k = n + a(arrayOfByte, i);
          i += 4;
          m = a(arrayOfInt1, arrayOfInt2, n, k);
          byteVector.putInt(m);
          i1--;
        } 
        continue;
      case 17:
        j = arrayOfByte[i + 1] & 0xFF;
        if (j == 132) {
          byteVector.putByteArray(arrayOfByte, i, 6);
          i += 6;
          continue;
        } 
        byteVector.putByteArray(arrayOfByte, i, 4);
        i += 4;
        continue;
      case 1:
      case 3:
      case 11:
        byteVector.putByteArray(arrayOfByte, i, 2);
        i += 2;
        continue;
      case 2:
      case 5:
      case 6:
      case 12:
      case 13:
        byteVector.putByteArray(arrayOfByte, i, 3);
        i += 3;
        continue;
      case 7:
      case 8:
        byteVector.putByteArray(arrayOfByte, i, 5);
        i += 5;
        continue;
    } 
    continue;
  }
  
  static int c(byte[] paramArrayOfbyte, int paramInt) {
    return (paramArrayOfbyte[paramInt] & 0xFF) << 8 | paramArrayOfbyte[paramInt + 1] & 0xFF;
  }
  
  static short b(byte[] paramArrayOfbyte, int paramInt) {
    return (short)((paramArrayOfbyte[paramInt] & 0xFF) << 8 | paramArrayOfbyte[paramInt + 1] & 0xFF);
  }
  
  static int a(byte[] paramArrayOfbyte, int paramInt) {
    return (paramArrayOfbyte[paramInt] & 0xFF) << 24 | (paramArrayOfbyte[paramInt + 1] & 0xFF) << 16 | (paramArrayOfbyte[paramInt + 2] & 0xFF) << 8 | paramArrayOfbyte[paramInt + 3] & 0xFF;
  }
  
  static void a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    paramArrayOfbyte[paramInt1] = (byte)(paramInt2 >>> 8);
    paramArrayOfbyte[paramInt1 + 1] = (byte)paramInt2;
  }
  
  static int a(int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2) {
    int i = paramInt2 - paramInt1;
    for (byte b = 0; b < paramArrayOfint1.length; b++) {
      if (paramInt1 < paramArrayOfint1[b] && paramArrayOfint1[b] <= paramInt2) {
        i += paramArrayOfint2[b];
      } else if (paramInt2 < paramArrayOfint1[b] && paramArrayOfint1[b] <= paramInt1) {
        i -= paramArrayOfint2[b];
      } 
    } 
    return i;
  }
  
  static void a(int[] paramArrayOfint1, int[] paramArrayOfint2, Label paramLabel) {
    if ((paramLabel.a & 0x4) == 0) {
      paramLabel.c = a(paramArrayOfint1, paramArrayOfint2, 0, paramLabel.c);
      paramLabel.a |= 0x4;
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\relocated\org\objectweb\asm\MethodWriter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */