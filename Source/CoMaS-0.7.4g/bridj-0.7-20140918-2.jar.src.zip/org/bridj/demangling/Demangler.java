/*      */ package org.bridj.demangling;
/*      */ 
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.reflect.AnnotatedElement;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.GenericArrayType;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.ParameterizedType;
/*      */ import java.lang.reflect.Type;
/*      */ import java.lang.reflect.WildcardType;
/*      */ import java.util.Arrays;
/*      */ import java.util.regex.Pattern;
/*      */ import org.bridj.BridJ;
/*      */ import org.bridj.CLong;
/*      */ import org.bridj.CRuntime;
/*      */ import org.bridj.Callback;
/*      */ import org.bridj.FlagSet;
/*      */ import org.bridj.NativeLibrary;
/*      */ import org.bridj.NativeObject;
/*      */ import org.bridj.Platform;
/*      */ import org.bridj.Pointer;
/*      */ import org.bridj.SizeT;
/*      */ import org.bridj.TimeT;
/*      */ import org.bridj.ValuedEnum;
/*      */ import org.bridj.ann.CLong;
/*      */ import org.bridj.ann.Convention;
/*      */ import org.bridj.ann.Name;
/*      */ import org.bridj.ann.Namespace;
/*      */ import org.bridj.ann.Ptr;
/*      */ import org.bridj.ann.Template;
/*      */ import org.bridj.util.AnnotationUtils;
/*      */ import org.bridj.util.DefaultParameterizedType;
/*      */ import org.bridj.util.Utils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Demangler
/*      */ {
/*      */   protected final String str;
/*      */   protected final int length;
/*      */   
/*      */   public static void main(String[] args) {
/*   90 */     for (String arg : args) {
/*      */       try {
/*   92 */         System.out.println("VC9: " + (new VC9Demangler(null, arg)).parseSymbol());
/*   93 */       } catch (Exception ex) {
/*   94 */         ex.printStackTrace();
/*      */       } 
/*      */       try {
/*   97 */         System.out.println("GCC4: " + (new GCC4Demangler(null, arg)).parseSymbol());
/*   98 */       } catch (Exception ex) {
/*   99 */         ex.printStackTrace();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Annotations annotations(final Annotation[] aa) {
/*  112 */     return new Annotations()
/*      */       {
/*      */         public <A extends Annotation> A getAnnotation(Class<A> c) {
/*  115 */           if (aa == null) {
/*  116 */             return null;
/*      */           }
/*      */           
/*  119 */           for (Annotation a : aa) {
/*  120 */             if (c.isInstance(a)) {
/*  121 */               return (A)a;
/*      */             }
/*      */           } 
/*  124 */           return null;
/*      */         }
/*      */         
/*      */         public boolean isAnnotationPresent(Class<? extends Annotation> c) {
/*  128 */           return AnnotationUtils.isAnnotationPresent(c, aa);
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public static Annotations annotations(Type e) {
/*  134 */     return annotations(Utils.getClass(e));
/*      */   }
/*      */   
/*      */   public static Annotations annotations(final AnnotatedElement e) {
/*  138 */     return new Annotations()
/*      */       {
/*      */         public <A extends Annotation> A getAnnotation(Class<A> c) {
/*  141 */           return e.getAnnotation(c);
/*      */         }
/*      */         
/*      */         public boolean isAnnotationPresent(Class<? extends Annotation> c) {
/*  145 */           return AnnotationUtils.isAnnotationPresent(c, e, new Annotation[0]);
/*      */         }
/*      */       };
/*      */   }
/*      */   public static interface Annotations {
/*      */     <A extends Annotation> A getAnnotation(Class<A> param1Class);
/*      */     boolean isAnnotationPresent(Class<? extends Annotation> param1Class); }
/*      */   public class DemanglingException extends Exception { public DemanglingException(String mess) {
/*  153 */       this(mess, (Throwable)null);
/*      */     }
/*      */     
/*      */     public DemanglingException(String mess, Throwable cause) {
/*  157 */       super(mess + " (in symbol '" + Demangler.this.str + "')", cause);
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  164 */   protected int position = 0;
/*      */   protected final NativeLibrary library;
/*      */   
/*      */   public Demangler(NativeLibrary library, String str) {
/*  168 */     this.str = str;
/*  169 */     this.length = str.length();
/*  170 */     this.library = library;
/*      */   }
/*      */   
/*      */   public String getString() {
/*  174 */     return this.str;
/*      */   }
/*      */   
/*      */   protected void expectChars(char... cs) throws DemanglingException {
/*  178 */     for (char c : cs) {
/*  179 */       char cc = consumeChar();
/*  180 */       if (cc != c) {
/*  181 */         throw error("Expected char '" + c + "', found '" + cc + "'");
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void expectAnyChar(char... cs) throws DemanglingException {
/*  187 */     char cc = consumeChar();
/*  188 */     for (char c : cs) {
/*  189 */       if (cc == c) {
/*      */         return;
/*      */       }
/*      */     } 
/*  193 */     throw error("Expected any of " + Arrays.toString(cs) + ", found '" + cc + "'");
/*      */   }
/*      */   
/*      */   public static StringBuilder implode(StringBuilder b, Object[] items, String sep) {
/*  197 */     return implode(b, Arrays.asList(items), sep);
/*      */   }
/*      */   
/*      */   public static StringBuilder implode(StringBuilder b, Iterable<?> items, String sep) {
/*  201 */     boolean first = true;
/*  202 */     for (Object item : items) {
/*  203 */       if (first) {
/*  204 */         first = false;
/*      */       } else {
/*  206 */         b.append(sep);
/*      */       } 
/*  208 */       b.append(item);
/*      */     } 
/*  210 */     return b;
/*      */   }
/*      */   
/*      */   protected char peekChar() {
/*  214 */     return peekChar(1);
/*      */   }
/*      */   
/*      */   protected char peekChar(int dist) {
/*  218 */     int p = this.position + dist - 1;
/*  219 */     return (p >= this.length) ? Character.MIN_VALUE : this.str.charAt(p);
/*      */   }
/*      */   
/*      */   protected char lastChar() {
/*  223 */     return (this.position == 0) ? Character.MIN_VALUE : this.str.charAt(this.position - 1);
/*      */   }
/*      */   
/*      */   protected char consumeChar() throws DemanglingException {
/*  227 */     char c = peekChar();
/*  228 */     if (c != '\000') {
/*  229 */       this.position++;
/*      */     } else {
/*  231 */       throw new DemanglingException("Reached end of string '" + this.str + "'");
/*      */     } 
/*  233 */     return c;
/*      */   }
/*      */   
/*      */   protected boolean consumeCharsIf(char... nextChars) {
/*  237 */     int initialPosition = this.position;
/*      */     try {
/*  239 */       for (char c : nextChars) {
/*  240 */         char cc = consumeChar();
/*  241 */         if (cc != c) {
/*  242 */           this.position = initialPosition;
/*  243 */           return false;
/*      */         } 
/*      */       } 
/*  246 */       return true;
/*  247 */     } catch (DemanglingException ex) {
/*  248 */       this.position = initialPosition;
/*  249 */       return false;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected boolean consumeCharIf(char... allowedChars) {
/*  254 */     char c = peekChar();
/*  255 */     for (char allowedChar : allowedChars) {
/*  256 */       if (allowedChar == c) {
/*  257 */         this.position++;
/*  258 */         return true;
/*      */       } 
/*      */     } 
/*  261 */     return false;
/*      */   }
/*      */   
/*      */   protected DemanglingException error(int deltaPosition) {
/*  265 */     return error(null, deltaPosition);
/*      */   }
/*      */   
/*      */   protected DemanglingException error(String mess) {
/*  269 */     return error(mess, -1);
/*      */   }
/*      */   
/*      */   protected DemanglingException error(String mess, int deltaPosition) {
/*  273 */     StringBuilder err = new StringBuilder(this.position + 1);
/*  274 */     int position = this.position + deltaPosition;
/*  275 */     for (int i = 0; i < position; i++) {
/*  276 */       err.append(' ');
/*      */     }
/*  278 */     err.append('^');
/*  279 */     return new DemanglingException("Parsing error at position " + position + ((mess == null) ? "" : (": " + mess)) + " \n\t" + this.str + "\n\t" + err);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getMethodName(Method method) {
/*  288 */     Name name = method.<Name>getAnnotation(Name.class);
/*  289 */     return (name == null) ? method.getName() : name.value();
/*      */   }
/*      */   
/*      */   public static String getClassName(Type type) {
/*  293 */     assert type != null;
/*  294 */     Class<?> typeClass = Utils.getClass(type);
/*  295 */     Name name = typeClass.<Name>getAnnotation(Name.class);
/*  296 */     return (name == null) ? typeClass.getSimpleName() : name.value();
/*      */   }
/*      */   
/*      */   public static String getFullClassName(Type type) {
/*  300 */     Class<?> typeClass = Utils.getClass(type);
/*  301 */     String simpleName = getClassName(typeClass);
/*  302 */     Namespace namespace = typeClass.<Namespace>getAnnotation(Namespace.class);
/*  303 */     return (namespace != null) ? (namespace.value().replaceAll("::", ".") + "." + simpleName) : simpleName;
/*      */   }
/*      */   public static interface TemplateArg {
/*      */     boolean matchesParam(Object param1Object, Demangler.Annotations param1Annotations); }
/*      */   public static class Symbol { final String symbol;
/*      */     long address;
/*      */     Demangler.MemberRef ref;
/*      */     boolean refParsed;
/*      */     final NativeLibrary library;
/*      */     private Convention.Style style;
/*      */     
/*      */     public Symbol(String symbol, NativeLibrary library) {
/*  315 */       this.symbol = symbol;
/*  316 */       this.library = library;
/*      */     }
/*      */ 
/*      */     
/*      */     public NativeLibrary getLibrary() {
/*  321 */       return this.library;
/*      */     }
/*      */     
/*      */     public Demangler.MemberRef getRef() {
/*  325 */       return this.ref;
/*      */     }
/*      */     
/*      */     public Convention.Style getStyle() {
/*  329 */       return this.style;
/*      */     }
/*      */     
/*      */     public String getSymbol() {
/*  333 */       return this.symbol;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  338 */       return this.symbol + ((this.ref == null) ? "" : (" (" + this.ref + ")"));
/*      */     }
/*      */     
/*      */     public long getAddress() {
/*  342 */       if (this.address == 0L) {
/*  343 */         this.address = this.library.getSymbolAddress(this.symbol);
/*      */       }
/*  345 */       return this.address;
/*      */     }
/*      */     
/*      */     public void setAddress(long address) {
/*  349 */       this.address = address;
/*      */     }
/*      */ 
/*      */     
/*      */     public Convention.Style getInferredCallingConvention() {
/*  354 */       if (this.style == null)
/*      */       {
/*  356 */         if (this.symbol.matches("_.*?@\\d+")) {
/*  357 */           this.style = Convention.Style.StdCall;
/*  358 */         } else if (this.symbol.matches("@.*?@\\d+")) {
/*  359 */           this.style = Convention.Style.FastCall;
/*  360 */         } else if (Platform.isWindows() && this.symbol.contains("@")) {
/*      */           try {
/*  362 */             Demangler.MemberRef mr = getParsedRef();
/*  363 */             if (mr != null) {
/*  364 */               this.style = mr.callingConvention;
/*      */             }
/*  366 */           } catch (Throwable th) {}
/*      */         } 
/*      */       }
/*      */       
/*  370 */       return this.style;
/*      */     }
/*      */     
/*      */     public boolean matches(Method method) {
/*  374 */       if (!this.symbol.contains(Demangler.getMethodName(method))) {
/*  375 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  381 */       parse();
/*      */       
/*      */       try {
/*  384 */         if (this.ref != null) {
/*  385 */           boolean res = this.ref.matches(method);
/*  386 */           if (!res && BridJ.debug) {
/*  387 */             BridJ.debug("Symbol " + this.symbol + " was a good candidate but expected demangled signature " + this.ref + " did not match the method " + method);
/*      */           }
/*  389 */           return res;
/*      */         } 
/*  391 */       } catch (Exception ex) {
/*  392 */         ex.printStackTrace();
/*      */       } 
/*  394 */       return false;
/*      */     }
/*      */     
/*      */     public Demangler.MemberRef getParsedRef() {
/*  398 */       parse();
/*  399 */       return this.ref;
/*      */     }
/*      */     
/*      */     synchronized void parse() {
/*  403 */       if (!this.refParsed) {
/*      */         try {
/*  405 */           this.ref = this.library.parseSymbol(this.symbol);
/*  406 */         } catch (DemanglingException ex) {
/*  407 */           if (BridJ.debug) {
/*  408 */             ex.printStackTrace();
/*      */           }
/*  410 */           if (BridJ.verbose) {
/*  411 */             BridJ.warning("Symbol parsing failed : " + ex.getMessage());
/*      */           }
/*      */         } 
/*  414 */         this.refParsed = true;
/*      */       } 
/*      */     }
/*      */     
/*      */     public String getName() {
/*  419 */       return this.symbol;
/*      */     }
/*      */     
/*      */     public boolean matchesVirtualTable(Class<?> type) {
/*  423 */       if (!this.symbol.contains(type.getSimpleName())) {
/*  424 */         return false;
/*      */       }
/*      */       
/*  427 */       parse();
/*      */       
/*      */       try {
/*  430 */         if (this.ref != null) {
/*  431 */           return this.ref.matchesVirtualTable(type);
/*      */         }
/*  433 */       } catch (Exception ex) {
/*  434 */         ex.printStackTrace();
/*      */       } 
/*  436 */       return false;
/*      */     }
/*      */     
/*      */     public boolean matchesConstructor(Type type, Constructor<?> constr) {
/*  440 */       if (!this.symbol.contains(Demangler.getClassName(type))) {
/*  441 */         return false;
/*      */       }
/*      */       
/*  444 */       parse();
/*      */       
/*      */       try {
/*  447 */         if (this.ref != null) {
/*  448 */           return this.ref.matchesConstructor(type, constr);
/*      */         }
/*  450 */       } catch (Exception ex) {
/*  451 */         ex.printStackTrace();
/*      */       } 
/*  453 */       return false;
/*      */     }
/*      */     
/*      */     public boolean matchesDestructor(Class<?> type) {
/*  457 */       if (!this.symbol.contains(type.getSimpleName())) {
/*  458 */         return false;
/*      */       }
/*      */       
/*  461 */       parse();
/*      */       
/*      */       try {
/*  464 */         if (this.ref != null) {
/*  465 */           return this.ref.matchesDestructor(type);
/*      */         }
/*  467 */       } catch (Exception ex) {
/*  468 */         ex.printStackTrace();
/*      */       } 
/*  470 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isVirtualTable() {
/*  475 */       return false;
/*      */     } }
/*      */ 
/*      */   
/*      */   public static abstract class TypeRef
/*      */     implements TemplateArg {
/*      */     public abstract StringBuilder getQualifiedName(StringBuilder param1StringBuilder, boolean param1Boolean);
/*      */     
/*      */     public String getQualifiedName(boolean generic) {
/*  484 */       StringBuilder sb = getQualifiedName(new StringBuilder(), generic);
/*  485 */       return (sb == null) ? null : sb.toString();
/*      */     }
/*      */     
/*      */     public boolean matchesParam(Object param, Demangler.Annotations annotations) {
/*  489 */       return (param instanceof Type && matches((Type)param, annotations));
/*      */     }
/*      */     
/*      */     public boolean matches(Type type, Demangler.Annotations annotations) {
/*  493 */       String pack, thisName = getQualifiedName(false);
/*  494 */       if (thisName == null)
/*  495 */         return false; 
/*  496 */       Class<?> typeClass = Demangler.getTypeClass(type);
/*  497 */       String name = Demangler.getClassName(typeClass);
/*  498 */       if (thisName.equals(name))
/*  499 */         return true; 
/*  500 */       Namespace ns = typeClass.<Namespace>getAnnotation(Namespace.class);
/*      */       
/*  502 */       if (ns == null)
/*  503 */       { if (typeClass.getPackage() == null) {
/*  504 */           pack = "";
/*      */         } else {
/*  506 */           pack = typeClass.getPackage().getName();
/*      */         }  }
/*  508 */       else { pack = ns.value().replaceAll("\b::\b", ".").trim(); }
/*      */       
/*  510 */       if (pack.length() == 0)
/*  511 */         return false; 
/*  512 */       String qname = pack + "." + name;
/*  513 */       if (thisName.matches("\b" + Pattern.quote(qname)))
/*  514 */         return true; 
/*  515 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object obj) {
/*  520 */       return toString().equals(obj.toString());
/*      */     }
/*      */   }
/*      */   
/*      */   public static class Constant
/*      */     implements TemplateArg {
/*      */     Object value;
/*      */     
/*      */     public Constant(Object value) {
/*  529 */       this.value = value;
/*      */     }
/*      */     
/*      */     public boolean matchesParam(Object param, Demangler.Annotations annotations) {
/*  533 */       return this.value.equals(param);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  538 */       return this.value.toString();
/*      */     }
/*      */   }
/*      */   
/*      */   public static class NamespaceRef
/*      */     extends TypeRef {
/*      */     Object[] namespace;
/*      */     
/*      */     public NamespaceRef(Object... namespace) {
/*  547 */       this.namespace = namespace;
/*      */     }
/*      */     
/*      */     public StringBuilder getQualifiedName(StringBuilder b, boolean generic) {
/*  551 */       return Demangler.implode(b, this.namespace, ".");
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  556 */       return getQualifiedName(new StringBuilder(), true).toString();
/*      */     }
/*      */   }
/*      */   
/*      */   public static class PointerTypeRef
/*      */     extends TypeRef {
/*      */     public Demangler.TypeRef pointedType;
/*      */     
/*      */     public PointerTypeRef(Demangler.TypeRef pointedType) {
/*  565 */       assert pointedType != null;
/*  566 */       this.pointedType = pointedType;
/*      */     }
/*      */ 
/*      */     
/*      */     public StringBuilder getQualifiedName(StringBuilder b, boolean generic) {
/*  571 */       return b.append("org.bridj.Pointer");
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  576 */       return this.pointedType + "*";
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean matches(Type type, Demangler.Annotations annotations) {
/*  581 */       if (super.matches(type, annotations)) {
/*  582 */         return true;
/*      */       }
/*  584 */       if (type == long.class && annotations.isAnnotationPresent((Class)Ptr.class)) {
/*  585 */         return true;
/*      */       }
/*  587 */       Class<?> typeClass = Demangler.getTypeClass(type);
/*  588 */       if (!Pointer.class.isAssignableFrom(typeClass)) {
/*  589 */         return false;
/*      */       }
/*  591 */       Type pointedType = Demangler.normalize(Utils.getUniqueParameterizedTypeParameter(type));
/*  592 */       if (this.pointedType == null || this.pointedType.toString().equals("void"))
/*  593 */         return (pointedType == null); 
/*  594 */       if (pointedType == null) {
/*  595 */         return true;
/*      */       }
/*  597 */       return this.pointedType.matches(pointedType, annotations);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected static TypeRef pointerType(TypeRef tr) {
/*  604 */     return new PointerTypeRef(tr);
/*      */   }
/*      */   
/*      */   protected static TypeRef classType(Class<?> c, Class<? extends Annotation>... annotations) {
/*  608 */     return classType(c, null, annotations);
/*      */   }
/*      */   
/*      */   protected static TypeRef classType(Class<?> c, Type[] genericTypes, Class<? extends Annotation>... annotations) {
/*  612 */     JavaTypeRef tr = new JavaTypeRef();
/*  613 */     if (genericTypes == null) {
/*  614 */       tr.type = c;
/*      */     } else {
/*  616 */       tr.type = (Type)new DefaultParameterizedType(c, genericTypes);
/*      */     } 
/*      */     
/*  619 */     tr.annotations = annotations;
/*  620 */     return tr;
/*      */   }
/*      */   
/*      */   protected static TypeRef simpleType(String name, TemplateArg... args) {
/*  624 */     return new ClassRef(new Ident(name, args));
/*      */   }
/*      */   
/*      */   protected static TypeRef simpleType(Ident ident) {
/*  628 */     return new ClassRef(ident);
/*      */   }
/*      */ 
/*      */   
/*      */   static Class<?> getTypeClass(Type type) {
/*  633 */     if (type instanceof Class) {
/*  634 */       return (Class)type;
/*      */     }
/*  636 */     if (type instanceof ParameterizedType) {
/*  637 */       ParameterizedType pt = (ParameterizedType)type;
/*  638 */       Class<?> c = (Class)pt.getRawType();
/*  639 */       if (ValuedEnum.class.isAssignableFrom(c)) {
/*  640 */         Type[] types = pt.getActualTypeArguments();
/*  641 */         if (types == null || types.length != 1) {
/*  642 */           c = int.class;
/*      */         } else {
/*  644 */           c = getTypeClass(pt.getActualTypeArguments()[0]);
/*      */         } 
/*      */       } 
/*  647 */       return c;
/*      */     } 
/*  649 */     if (type instanceof GenericArrayType && 
/*  650 */       Object.class.isAssignableFrom(getTypeClass(((GenericArrayType)type).getGenericComponentType()))) {
/*  651 */       return Object[].class;
/*      */     }
/*      */     
/*  654 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private static Type normalize(Type t) {
/*  659 */     if (t instanceof WildcardType) {
/*  660 */       WildcardType wt = (WildcardType)t;
/*  661 */       if ((wt.getLowerBounds()).length == 1)
/*  662 */         return normalize(wt.getLowerBounds()[0]); 
/*  663 */       return null;
/*      */     } 
/*  665 */     Class<?> c = Utils.getClass(t);
/*  666 */     if (c != null && c.isPrimitive()) {
/*  667 */       if (t == float.class) return Float.class; 
/*  668 */       if (t == double.class) return Double.class; 
/*  669 */       if (t == byte.class) return Byte.class; 
/*  670 */       if (t == char.class) return Character.class; 
/*  671 */       if (t == short.class) return Short.class; 
/*  672 */       if (t == int.class) return Integer.class; 
/*  673 */       if (t == long.class) return Long.class; 
/*  674 */       if (t == boolean.class) return Boolean.class; 
/*  675 */       if (t == void.class) return Void.class; 
/*      */     } 
/*  677 */     return t;
/*      */   }
/*      */   static boolean equivalentTypes(Type a, Class ac, Annotations aAnnotations, Type b, Class bc, Annotations bAnnotations) {
/*  680 */     if (normalize(a).equals(normalize(b))) {
/*  681 */       return true;
/*      */     }
/*      */     
/*  684 */     if (aAnnotations != null && bAnnotations != null) {
/*  685 */       if (xor(isPointerLike(a, ac, aAnnotations), isPointerLike(b, bc, bAnnotations))) {
/*  686 */         return false;
/*      */       }
/*  688 */       if (xor(isCLong(a, ac, aAnnotations), isCLong(b, bc, bAnnotations))) {
/*  689 */         return false;
/*      */       }
/*      */     } 
/*  692 */     int as = getIntegralSize(a, ac, aAnnotations);
/*  693 */     int bs = getIntegralSize(b, bc, bAnnotations);
/*  694 */     return (as != -1 && as == bs);
/*      */   }
/*      */   
/*      */   static boolean xor(boolean a, boolean b) {
/*  698 */     return ((a && !b) || (!a && b));
/*      */   }
/*      */   static boolean isPointerLike(Type type, Class<?> typec, Annotations annotations) {
/*  701 */     if (type == long.class || type == Long.class) {
/*  702 */       return ((annotations == null && Pointer.SIZE == 8) || (annotations != null && annotations.isAnnotationPresent((Class)Ptr.class) && !annotations.isAnnotationPresent((Class)CLong.class)));
/*      */     }
/*      */ 
/*      */     
/*  706 */     return (type == SizeT.class || Pointer.class.isAssignableFrom(typec));
/*      */   }
/*      */   
/*      */   static boolean isCLong(Type type, Class typec, Annotations annotations) {
/*  710 */     if (type == long.class || type == Long.class) {
/*  711 */       return ((annotations == null && CLong.SIZE == 8) || (annotations != null && annotations.isAnnotationPresent((Class)CLong.class)));
/*      */     }
/*      */     
/*  714 */     return (type == CLong.class);
/*      */   }
/*      */   
/*      */   static int getIntegralSize(Type type, Class<?> typec, Annotations annotations) {
/*  718 */     if (type == int.class || type == Integer.class) {
/*  719 */       return 4;
/*      */     }
/*  721 */     if (type == long.class || type == Long.class) {
/*  722 */       if (annotations != null) {
/*  723 */         if (annotations.isAnnotationPresent((Class)Ptr.class)) {
/*  724 */           return Pointer.SIZE;
/*      */         }
/*  726 */         if (annotations.isAnnotationPresent((Class)CLong.class)) {
/*  727 */           return CLong.SIZE;
/*      */         }
/*      */       } 
/*  730 */       return 8;
/*      */     } 
/*  732 */     if (type == CLong.class) {
/*  733 */       return CLong.SIZE;
/*      */     }
/*  735 */     if (type == SizeT.class) {
/*  736 */       return SizeT.SIZE;
/*      */     }
/*  738 */     if (type == TimeT.class) {
/*  739 */       return TimeT.SIZE;
/*      */     }
/*  741 */     if (type == byte.class || type == Byte.class) {
/*  742 */       return 1;
/*      */     }
/*  744 */     if (type == char.class || type == Character.class || type == short.class || type == Short.class) {
/*  745 */       return 2;
/*      */     }
/*  747 */     if (ValuedEnum.class.isAssignableFrom(typec)) {
/*  748 */       return 4;
/*      */     }
/*  750 */     if (Pointer.class.isAssignableFrom(typec)) {
/*  751 */       return SizeT.SIZE;
/*      */     }
/*  753 */     return -1;
/*      */   }
/*      */   
/*      */   public static boolean equivalentTypes(Type a, Annotations aAnnotations, Type b, Annotations bAnnotations) {
/*  757 */     return equivalentTypes(a, getTypeClass(a), aAnnotations, b, getTypeClass(b), bAnnotations);
/*      */   }
/*      */   
/*      */   public static class JavaTypeRef
/*      */     extends TypeRef
/*      */   {
/*      */     Type type;
/*      */     Class<? extends Annotation>[] annotations;
/*      */     
/*      */     public StringBuilder getQualifiedName(StringBuilder b, boolean generic) {
/*  767 */       return b.append(Demangler.getFullClassName(this.type));
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean matches(Type type, Demangler.Annotations annotations) {
/*  772 */       Class<?> tc = Demangler.getTypeClass(this.type);
/*  773 */       Class<?> typec = Demangler.getTypeClass(type);
/*  774 */       if (typec == null)
/*  775 */         return true; 
/*  776 */       if (tc == typec || tc.equals(typec)) {
/*  777 */         return true;
/*      */       }
/*      */       
/*  780 */       if ((type == long.class && Pointer.class.isAssignableFrom(tc)) || (Pointer.class.isAssignableFrom(typec) && tc == long.class))
/*      */       {
/*  782 */         return true;
/*      */       }
/*      */       
/*  785 */       return Demangler.equivalentTypes(type, typec, annotations, this.type, tc, null);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  790 */       StringBuilder b = new StringBuilder();
/*  791 */       for (Class<?> ann : this.annotations) {
/*  792 */         b.append(ann.getSimpleName()).append(' ');
/*      */       }
/*  794 */       b.append((this.type instanceof Class) ? ((Class)this.type).getSimpleName() : this.type.toString());
/*  795 */       return b.toString();
/*      */     }
/*      */   }
/*      */   
/*      */   public static interface IdentLike {}
/*      */   
/*      */   public static class Ident
/*      */     implements IdentLike
/*      */   {
/*      */     Object simpleName;
/*      */     Demangler.TemplateArg[] templateArguments;
/*      */     
/*      */     public Ident(String simpleName, Demangler.TemplateArg... templateArguments) {
/*  808 */       this.simpleName = simpleName;
/*  809 */       this.templateArguments = templateArguments;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object o) {
/*  814 */       if (o == null || !(o instanceof Ident)) {
/*  815 */         return false;
/*      */       }
/*      */       
/*  818 */       Ident ident = (Ident)o;
/*  819 */       if (!this.simpleName.equals(ident.simpleName)) {
/*  820 */         return false;
/*      */       }
/*      */       
/*  823 */       int n = this.templateArguments.length;
/*  824 */       if (ident.templateArguments.length != n) {
/*  825 */         return false;
/*      */       }
/*      */       
/*  828 */       for (int i = 0; i < n; i++) {
/*  829 */         if (!this.templateArguments[i].equals(ident.templateArguments[i])) {
/*  830 */           return false;
/*      */         }
/*      */       } 
/*      */       
/*  834 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  839 */       StringBuilder b = new StringBuilder();
/*      */       
/*  841 */       b.append(this.simpleName);
/*  842 */       Demangler.appendTemplateArgs(b, (Object[])this.templateArguments);
/*  843 */       return b.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static class ClassRef
/*      */     extends TypeRef
/*      */   {
/*      */     private Demangler.TypeRef enclosingType;
/*      */     final Demangler.Ident ident;
/*      */     
/*      */     public ClassRef(Demangler.Ident ident) {
/*  855 */       this.ident = ident;
/*      */     }
/*      */     
/*      */     public StringBuilder getQualifiedName(StringBuilder b, boolean generic) {
/*  859 */       if (getEnclosingType() instanceof ClassRef) {
/*  860 */         getEnclosingType().getQualifiedName(b, generic).append('$');
/*  861 */       } else if (getEnclosingType() instanceof Demangler.NamespaceRef) {
/*  862 */         getEnclosingType().getQualifiedName(b, generic).append('.');
/*      */       } 
/*  864 */       b.append(this.ident.simpleName);
/*  865 */       if (generic && this.ident.templateArguments != null) {
/*  866 */         int args = 0;
/*  867 */         for (int i = 0, n = this.ident.templateArguments.length; i < n; i++) {
/*  868 */           Demangler.TemplateArg arg = this.ident.templateArguments[i];
/*  869 */           if (arg instanceof Demangler.TypeRef) {
/*      */ 
/*      */ 
/*      */             
/*  873 */             if (args == 0) {
/*  874 */               b.append('<');
/*      */             } else {
/*  876 */               b.append(", ");
/*      */             } 
/*  878 */             ((Demangler.TypeRef)arg).getQualifiedName(b, generic);
/*  879 */             args++;
/*      */           } 
/*  881 */         }  if (args > 0) {
/*  882 */           b.append('>');
/*      */         }
/*      */       } 
/*  885 */       return b;
/*      */     }
/*      */     
/*      */     public Demangler.Ident getIdent() {
/*  889 */       return this.ident;
/*      */     }
/*      */     
/*      */     public void setEnclosingType(Demangler.TypeRef enclosingType) {
/*  893 */       this.enclosingType = enclosingType;
/*      */     }
/*      */     
/*      */     public Demangler.TypeRef getEnclosingType() {
/*  897 */       return this.enclosingType;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean matches(Type type, Demangler.Annotations annotations) {
/*  902 */       Class<?> typeClass = Demangler.getTypeClass(type);
/*  903 */       if (typeClass == null) {
/*  904 */         return false;
/*      */       }
/*  906 */       String fullName = Demangler.getFullClassName(ValuedEnum.class.isAssignableFrom(typeClass) ? Demangler.normalize(Utils.getUniqueParameterizedTypeParameter(type)) : typeClass);
/*      */ 
/*      */ 
/*      */       
/*  910 */       String qname = getQualifiedName(false);
/*  911 */       if (fullName != null && fullName.equals(qname)) {
/*  912 */         return true;
/*      */       }
/*      */       
/*  915 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  920 */       StringBuilder b = new StringBuilder();
/*      */       
/*  922 */       if (this.enclosingType != null) {
/*  923 */         b.append(this.enclosingType).append('.');
/*      */       }
/*      */       
/*  926 */       b.append(this.ident);
/*  927 */       return b.toString();
/*      */     }
/*      */   }
/*      */   
/*      */   static void appendTemplateArgs(StringBuilder b, Object[] params) {
/*  932 */     if (params == null || params.length == 0) {
/*      */       return;
/*      */     }
/*  935 */     appendArgs(b, '<', '>', params);
/*      */   }
/*      */   
/*      */   static void appendArgs(StringBuilder b, char pre, char post, Object[] params) {
/*  939 */     b.append(pre);
/*  940 */     if (params != null) {
/*  941 */       for (int i = 0; i < params.length; i++) {
/*  942 */         if (i != 0) {
/*  943 */           b.append(", ");
/*      */         }
/*  945 */         b.append(params[i]);
/*      */       } 
/*      */     }
/*  948 */     b.append(post);
/*      */   }
/*      */   
/*      */   public abstract MemberRef parseSymbol() throws DemanglingException;
/*      */   
/*      */   public static class FunctionTypeRef extends TypeRef { Demangler.MemberRef function;
/*      */     
/*      */     public FunctionTypeRef(Demangler.MemberRef function) {
/*  956 */       this.function = function;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public StringBuilder getQualifiedName(StringBuilder b, boolean generic) {
/*  962 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean matches(Type type, Demangler.Annotations annotations) {
/*  967 */       Class<?> typeClass = Demangler.getTypeClass(type);
/*  968 */       if (!Callback.class.isAssignableFrom(typeClass))
/*  969 */         return false; 
/*  970 */       Method method = CRuntime.getInstance().getFastestCallbackMethod(typeClass);
/*  971 */       if (method == null)
/*  972 */         return false; 
/*  973 */       return this.function.matches(method);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  978 */       return this.function.toString();
/*      */     } }
/*      */ 
/*      */   
/*      */   public enum SpecialName
/*      */     implements IdentLike {
/*  984 */     Constructor("", true, true),
/*  985 */     SpecialConstructor("", true, true),
/*  986 */     Destructor("", true, true),
/*  987 */     SelfishDestructor("", true, true),
/*  988 */     DeletingDestructor("", true, true),
/*  989 */     New("new", true, true),
/*  990 */     Delete("delete", true, true),
/*  991 */     NewArray("new[]", true, true),
/*  992 */     DeleteArray("delete[]", true, true),
/*  993 */     VFTable("vftable", false, true),
/*  994 */     VBTable("vbtable", false, true),
/*  995 */     VCall("vcall", false, false),
/*  996 */     TypeOf("typeof", false, false),
/*  997 */     ScalarDeletingDestructor("'scalar deleting destructor'", true, true),
/*  998 */     VectorDeletingDestructor("'vector deleting destructor'", true, true),
/*  999 */     OperatorAssign("operator=", true, true),
/* 1000 */     OperatorRShift("operator>>", true, true),
/* 1001 */     OperatorDivideAssign("operator/=", true, true),
/* 1002 */     OperatorModuloAssign("operator%=", true, true),
/* 1003 */     OperatorRShiftAssign("operator>>=", true, true),
/* 1004 */     OperatorLShiftAssign("operator<<=", true, true),
/* 1005 */     OperatorBitAndAssign("operator&=", true, true),
/* 1006 */     OperatorBitOrAssign("operator|=", true, true),
/* 1007 */     OperatorXORAssign("operator^=", true, true),
/* 1008 */     OperatorLShift("operator<<", true, true),
/* 1009 */     OperatorLogicNot("operator!", true, true),
/* 1010 */     OperatorEquals("operator==", true, true),
/* 1011 */     OperatorDifferent("operator!=", true, true),
/* 1012 */     OperatorSquareBrackets("operator[]", true, true),
/* 1013 */     OperatorCast("'some cast operator'", true, true),
/* 1014 */     OperatorArrow("operator->", true, true),
/* 1015 */     OperatorMultiply("operator*", true, true),
/* 1016 */     OperatorIncrement("operator++", true, true),
/* 1017 */     OperatorDecrement("operator--", true, true),
/* 1018 */     OperatorSubstract("operator-", true, true),
/* 1019 */     OperatorAdd("operator+", true, true),
/* 1020 */     OperatorBitAnd("operator&=", true, true),
/*      */     
/* 1022 */     OperatorArrowStar("operator->*", true, true),
/* 1023 */     OperatorDivide("operator/", true, true),
/* 1024 */     OperatorModulo("operator%", true, true),
/* 1025 */     OperatorLower("operator<", true, true),
/* 1026 */     OperatorLowerEquals("operator<=", true, true),
/* 1027 */     OperatorGreater("operator>", true, true),
/* 1028 */     OperatorGreaterEquals("operator>=", true, true),
/* 1029 */     OperatorComma("operator,", true, true),
/* 1030 */     OperatorParenthesis("operator()", true, true),
/* 1031 */     OperatorBitNot("operator~", true, true),
/* 1032 */     OperatorXOR("operator^", true, true),
/* 1033 */     OperatorBitOr("operator|", true, true),
/* 1034 */     OperatorLogicAnd("operator&&", true, true),
/* 1035 */     OperatorLogicOr("operator||", true, true),
/* 1036 */     OperatorMultiplyAssign("operator*=", true, true),
/* 1037 */     OperatorAddAssign("operator+=", true, true),
/* 1038 */     OperatorSubstractAssign("operator-=", true, true); final String name; final boolean isFunction; final boolean isMember;
/*      */     
/*      */     SpecialName(String name, boolean isFunction, boolean isMember) {
/* 1041 */       this.name = name;
/* 1042 */       this.isFunction = isFunction;
/* 1043 */       this.isMember = isMember;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1051 */       return this.name;
/*      */     }
/*      */     
/*      */     public boolean isFunction() {
/* 1055 */       return this.isFunction;
/*      */     }
/*      */     
/*      */     public boolean isMember() {
/* 1059 */       return this.isMember;
/*      */     } }
/*      */   
/*      */   public static class MemberRef { private Integer argumentsStackSize;
/*      */     private Demangler.TypeRef enclosingType;
/*      */     private Demangler.TypeRef valueType;
/*      */     private Demangler.IdentLike memberName;
/*      */     Boolean isStatic;
/*      */     Boolean isProtected;
/*      */     Boolean isPrivate;
/*      */     public int modifiers;
/*      */     public Demangler.TypeRef[] paramTypes;
/*      */     public Demangler.TypeRef[] throwTypes;
/*      */     Demangler.TemplateArg[] templateArguments;
/*      */     public Convention.Style callingConvention;
/*      */     
/*      */     public void setTemplateArguments(Demangler.TemplateArg[] templateArguments) {
/* 1076 */       this.templateArguments = templateArguments;
/*      */     }
/*      */     
/*      */     public Integer getArgumentsStackSize() {
/* 1080 */       return this.argumentsStackSize;
/*      */     }
/*      */     
/*      */     public void setArgumentsStackSize(Integer argumentsStackSize) {
/* 1084 */       this.argumentsStackSize = argumentsStackSize;
/*      */     }
/*      */     
/*      */     protected boolean matchesEnclosingType(Type type) {
/* 1088 */       return (getEnclosingType() != null && getEnclosingType().matches(type, Demangler.annotations(type)));
/*      */     }
/*      */     
/*      */     protected boolean matchesVirtualTable(Type type) {
/* 1092 */       return (this.memberName == Demangler.SpecialName.VFTable && matchesEnclosingType(type));
/*      */     }
/*      */     
/*      */     protected boolean matchesConstructor(Type type, Constructor<?> constr) {
/* 1096 */       if (this.memberName != Demangler.SpecialName.Constructor) {
/* 1097 */         return false;
/*      */       }
/*      */       
/* 1100 */       if (!matchesEnclosingType(type)) {
/* 1101 */         return false;
/*      */       }
/*      */       
/* 1104 */       Template temp = (Template)Utils.getClass(type).getAnnotation(Template.class);
/* 1105 */       Annotation[][] anns = constr.getParameterAnnotations();
/* 1106 */       Type[] parameterTypes = constr.getGenericParameterTypes();
/*      */       
/* 1108 */       int overrideOffset = Utils.getEnclosedConstructorParametersOffset(constr);
/* 1109 */       if (!matchesArgs(parameterTypes, anns, overrideOffset + ((temp == null) ? 0 : (temp.value()).length))) {
/* 1110 */         return false;
/*      */       }
/*      */       
/* 1113 */       return true;
/*      */     }
/*      */     
/*      */     protected boolean matchesDestructor(Type type) {
/* 1117 */       return (this.memberName == Demangler.SpecialName.Destructor && matchesEnclosingType(type));
/*      */     }
/*      */     
/*      */     static boolean hasInstance(Object[] array, Class<? extends Annotation>... cs) {
/* 1121 */       for (Object o : array) {
/* 1122 */         for (Class<?> c : cs) {
/* 1123 */           if (c.isInstance(o)) {
/* 1124 */             return true;
/*      */           }
/*      */         } 
/*      */       } 
/* 1128 */       return false;
/*      */     }
/*      */     
/*      */     static int getArgumentsStackSize(Method method) {
/* 1132 */       int total = 0;
/* 1133 */       Type[] paramTypes = method.getGenericParameterTypes();
/* 1134 */       Annotation[][] anns = method.getParameterAnnotations();
/* 1135 */       for (int iArg = 0, nArgs = paramTypes.length; iArg < nArgs; iArg++) {
/* 1136 */         Class<?> paramType = Demangler.getTypeClass(paramTypes[iArg]);
/* 1137 */         if (paramType == int.class) {
/* 1138 */           total += 4;
/* 1139 */         } else if (paramType == long.class) {
/* 1140 */           Annotation[] as = anns[iArg];
/* 1141 */           if (AnnotationUtils.isAnnotationPresent(Ptr.class, as) || AnnotationUtils.isAnnotationPresent(CLong.class, as)) {
/*      */             
/* 1143 */             total += Pointer.SIZE;
/*      */           } else {
/* 1145 */             total += 8;
/*      */           } 
/* 1147 */         } else if (paramType == float.class) {
/* 1148 */           total += 4;
/* 1149 */         } else if (paramType == double.class) {
/* 1150 */           total += 8;
/* 1151 */         } else if (paramType == byte.class) {
/* 1152 */           total++;
/* 1153 */         } else if (paramType == char.class) {
/* 1154 */           total += Platform.WCHAR_T_SIZE;
/* 1155 */         } else if (paramType == CLong.class) {
/* 1156 */           total += Platform.CLONG_SIZE;
/* 1157 */         } else if (paramType == SizeT.class) {
/* 1158 */           total += Platform.SIZE_T_SIZE;
/* 1159 */         } else if (paramType == TimeT.class) {
/* 1160 */           total += Platform.TIME_T_SIZE;
/* 1161 */         } else if (paramType == short.class) {
/* 1162 */           total += 2;
/* 1163 */         } else if (paramType == boolean.class) {
/* 1164 */           total++;
/* 1165 */         } else if (Pointer.class.isAssignableFrom(paramType)) {
/* 1166 */           total += Pointer.SIZE;
/* 1167 */         } else if (NativeObject.class.isAssignableFrom(paramType)) {
/* 1168 */           total = (int)(total + ((CRuntime)BridJ.getRuntime(paramType)).sizeOf(paramTypes[iArg], null));
/* 1169 */         } else if (FlagSet.class.isAssignableFrom(paramType)) {
/* 1170 */           total += 4;
/*      */         } else {
/* 1172 */           throw new RuntimeException("Type not handled : " + paramType.getName());
/*      */         } 
/*      */       } 
/* 1175 */       return total;
/*      */     }
/*      */ 
/*      */     
/*      */     protected boolean matches(Method method) {
/* 1180 */       if (this.memberName instanceof Demangler.SpecialName) {
/* 1181 */         return false;
/*      */       }
/* 1183 */       if (!matchesEnclosingType(method)) {
/* 1184 */         return false;
/*      */       }
/*      */       
/* 1187 */       return matchesSignature(method);
/*      */     }
/*      */     
/*      */     public boolean matchesEnclosingType(Method method) {
/* 1191 */       Demangler.TypeRef et = getEnclosingType();
/* 1192 */       if (et == null) {
/* 1193 */         return true;
/*      */       }
/*      */       
/* 1196 */       Demangler.Annotations annotations = Demangler.annotations(method);
/* 1197 */       Class<?> dc = method.getDeclaringClass();
/*      */       do {
/* 1199 */         if (et.matches(dc, annotations)) {
/* 1200 */           return true;
/*      */         }
/*      */         
/* 1203 */         dc = dc.getSuperclass();
/* 1204 */       } while (dc != null && dc != Object.class);
/*      */       
/* 1206 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean matchesSignature(Method method) {
/* 1211 */       if (getArgumentsStackSize() != null && getArgumentsStackSize().intValue() != getArgumentsStackSize(method)) {
/* 1212 */         return false;
/*      */       }
/*      */       
/* 1215 */       if (getMemberName() != null && !getMemberName().toString().equals(Demangler.getMethodName(method))) {
/* 1216 */         return false;
/*      */       }
/*      */       
/* 1219 */       if (getValueType() != null && !getValueType().matches(method.getReturnType(), Demangler.annotations(method))) {
/* 1220 */         return false;
/*      */       }
/*      */       
/* 1223 */       Template temp = method.<Template>getAnnotation(Template.class);
/* 1224 */       Annotation[][] anns = method.getParameterAnnotations();
/*      */       
/* 1226 */       Type[] parameterTypes = method.getGenericParameterTypes();
/*      */ 
/*      */       
/* 1229 */       if (this.paramTypes != null && !matchesArgs(parameterTypes, anns, (temp == null) ? 0 : (temp.value()).length))
/*      */       {
/* 1231 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1257 */       return true;
/*      */     }
/*      */     
/*      */     private boolean matchesArgs(Type[] parameterTypes, Annotation[][] anns, int offset) {
/* 1261 */       int totalArgs = offset; int i, n;
/* 1262 */       for (i = 0, n = (this.templateArguments == null) ? 0 : this.templateArguments.length; i < n; i++) {
/* 1263 */         if (totalArgs >= parameterTypes.length) {
/* 1264 */           return false;
/*      */         }
/*      */         
/* 1267 */         Type paramType = parameterTypes[offset + i];
/*      */         
/* 1269 */         Demangler.TemplateArg arg = this.templateArguments[i];
/* 1270 */         if (arg instanceof Demangler.TypeRef) {
/* 1271 */           if (!paramType.equals(Class.class)) {
/* 1272 */             return false;
/*      */           }
/* 1274 */         } else if (arg instanceof Demangler.Constant) {
/*      */           try {
/* 1276 */             Demangler.getTypeClass(paramType).cast(((Demangler.Constant)arg).value);
/* 1277 */           } catch (ClassCastException ex) {
/* 1278 */             return false;
/*      */           } 
/*      */         } 
/* 1281 */         totalArgs++;
/*      */       } 
/*      */       
/* 1284 */       for (i = 0, n = (this.paramTypes == null) ? 0 : this.paramTypes.length; i < n; i++) {
/* 1285 */         if (totalArgs >= parameterTypes.length) {
/* 1286 */           return false;
/*      */         }
/*      */         
/* 1289 */         Demangler.TypeRef paramType = this.paramTypes[i];
/* 1290 */         Type parameterType = parameterTypes[totalArgs];
/* 1291 */         if (!paramType.matches(parameterType, Demangler.annotations((anns == null) ? null : anns[i]))) {
/* 1292 */           return false;
/*      */         }
/*      */         
/* 1295 */         totalArgs++;
/*      */       } 
/*      */       
/* 1298 */       if (totalArgs != parameterTypes.length)
/*      */       {
/* 1300 */         return false;
/*      */       }
/*      */       
/* 1303 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1308 */       StringBuilder b = new StringBuilder();
/*      */       
/* 1310 */       b.append(this.valueType).append(' ');
/* 1311 */       boolean nameWritten = false;
/* 1312 */       if (this.enclosingType != null) {
/* 1313 */         b.append(this.enclosingType);
/* 1314 */         b.append('.');
/* 1315 */         if (this.memberName instanceof Demangler.SpecialName) {
/* 1316 */           switch ((Demangler.SpecialName)this.memberName) {
/*      */             case Destructor:
/* 1318 */               b.append('~');
/*      */             case Constructor:
/* 1320 */               b.append(((Demangler.ClassRef)this.enclosingType).ident.simpleName);
/* 1321 */               nameWritten = true;
/*      */               break;
/*      */           } 
/*      */         }
/*      */       } 
/* 1326 */       if (!nameWritten) {
/* 1327 */         b.append(this.memberName);
/*      */       }
/*      */       
/* 1330 */       Demangler.appendTemplateArgs(b, (Object[])this.templateArguments);
/* 1331 */       Demangler.appendArgs(b, '(', ')', (Object[])this.paramTypes);
/* 1332 */       return b.toString();
/*      */     }
/*      */     
/*      */     public void setMemberName(Demangler.IdentLike memberName) {
/* 1336 */       this.memberName = memberName;
/*      */     }
/*      */     
/*      */     public Demangler.IdentLike getMemberName() {
/* 1340 */       return this.memberName;
/*      */     }
/*      */     
/*      */     public void setValueType(Demangler.TypeRef valueType) {
/* 1344 */       this.valueType = valueType;
/*      */     }
/*      */     
/*      */     public Demangler.TypeRef getValueType() {
/* 1348 */       return this.valueType;
/*      */     }
/*      */     
/*      */     public void setEnclosingType(Demangler.TypeRef enclosingType) {
/* 1352 */       this.enclosingType = enclosingType;
/*      */     }
/*      */     
/*      */     public Demangler.TypeRef getEnclosingType() {
/* 1356 */       return this.enclosingType;
/*      */     } }
/*      */ 
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\demangling\Demangler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */