package org.bridj.demangling;

import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Constructor;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.WildcardType;
import java.util.Arrays;
import java.util.regex.Pattern;
import org.bridj.BridJ;
import org.bridj.CLong;
import org.bridj.CRuntime;
import org.bridj.Callback;
import org.bridj.FlagSet;
import org.bridj.NativeLibrary;
import org.bridj.NativeObject;
import org.bridj.Platform;
import org.bridj.Pointer;
import org.bridj.SizeT;
import org.bridj.TimeT;
import org.bridj.ValuedEnum;
import org.bridj.ann.CLong;
import org.bridj.ann.Convention;
import org.bridj.ann.Name;
import org.bridj.ann.Namespace;
import org.bridj.ann.Ptr;
import org.bridj.ann.Template;
import org.bridj.util.AnnotationUtils;
import org.bridj.util.DefaultParameterizedType;
import org.bridj.util.Utils;

public abstract class Demangler {
  protected final String str;
  
  protected final int length;
  
  public static void main(String[] args) {
    for (String arg : args) {
      try {
        System.out.println("VC9: " + (new VC9Demangler(null, arg)).parseSymbol());
      } catch (Exception ex) {
        ex.printStackTrace();
      } 
      try {
        System.out.println("GCC4: " + (new GCC4Demangler(null, arg)).parseSymbol());
      } catch (Exception ex) {
        ex.printStackTrace();
      } 
    } 
  }
  
  public static Annotations annotations(final Annotation[] aa) {
    return new Annotations() {
        public <A extends Annotation> A getAnnotation(Class<A> c) {
          if (aa == null)
            return null; 
          for (Annotation a : aa) {
            if (c.isInstance(a))
              return (A)a; 
          } 
          return null;
        }
        
        public boolean isAnnotationPresent(Class<? extends Annotation> c) {
          return AnnotationUtils.isAnnotationPresent(c, aa);
        }
      };
  }
  
  public static Annotations annotations(Type e) {
    return annotations(Utils.getClass(e));
  }
  
  public static Annotations annotations(final AnnotatedElement e) {
    return new Annotations() {
        public <A extends Annotation> A getAnnotation(Class<A> c) {
          return e.getAnnotation(c);
        }
        
        public boolean isAnnotationPresent(Class<? extends Annotation> c) {
          return AnnotationUtils.isAnnotationPresent(c, e, new Annotation[0]);
        }
      };
  }
  
  public static interface Annotations {
    <A extends Annotation> A getAnnotation(Class<A> param1Class);
    
    boolean isAnnotationPresent(Class<? extends Annotation> param1Class);
  }
  
  public class DemanglingException extends Exception {
    public DemanglingException(String mess) {
      this(mess, (Throwable)null);
    }
    
    public DemanglingException(String mess, Throwable cause) {
      super(mess + " (in symbol '" + Demangler.this.str + "')", cause);
    }
  }
  
  protected int position = 0;
  
  protected final NativeLibrary library;
  
  public Demangler(NativeLibrary library, String str) {
    this.str = str;
    this.length = str.length();
    this.library = library;
  }
  
  public String getString() {
    return this.str;
  }
  
  protected void expectChars(char... cs) throws DemanglingException {
    for (char c : cs) {
      char cc = consumeChar();
      if (cc != c)
        throw error("Expected char '" + c + "', found '" + cc + "'"); 
    } 
  }
  
  protected void expectAnyChar(char... cs) throws DemanglingException {
    char cc = consumeChar();
    for (char c : cs) {
      if (cc == c)
        return; 
    } 
    throw error("Expected any of " + Arrays.toString(cs) + ", found '" + cc + "'");
  }
  
  public static StringBuilder implode(StringBuilder b, Object[] items, String sep) {
    return implode(b, Arrays.asList(items), sep);
  }
  
  public static StringBuilder implode(StringBuilder b, Iterable<?> items, String sep) {
    boolean first = true;
    for (Object item : items) {
      if (first) {
        first = false;
      } else {
        b.append(sep);
      } 
      b.append(item);
    } 
    return b;
  }
  
  protected char peekChar() {
    return peekChar(1);
  }
  
  protected char peekChar(int dist) {
    int p = this.position + dist - 1;
    return (p >= this.length) ? Character.MIN_VALUE : this.str.charAt(p);
  }
  
  protected char lastChar() {
    return (this.position == 0) ? Character.MIN_VALUE : this.str.charAt(this.position - 1);
  }
  
  protected char consumeChar() throws DemanglingException {
    char c = peekChar();
    if (c != '\000') {
      this.position++;
    } else {
      throw new DemanglingException("Reached end of string '" + this.str + "'");
    } 
    return c;
  }
  
  protected boolean consumeCharsIf(char... nextChars) {
    int initialPosition = this.position;
    try {
      for (char c : nextChars) {
        char cc = consumeChar();
        if (cc != c) {
          this.position = initialPosition;
          return false;
        } 
      } 
      return true;
    } catch (DemanglingException ex) {
      this.position = initialPosition;
      return false;
    } 
  }
  
  protected boolean consumeCharIf(char... allowedChars) {
    char c = peekChar();
    for (char allowedChar : allowedChars) {
      if (allowedChar == c) {
        this.position++;
        return true;
      } 
    } 
    return false;
  }
  
  protected DemanglingException error(int deltaPosition) {
    return error(null, deltaPosition);
  }
  
  protected DemanglingException error(String mess) {
    return error(mess, -1);
  }
  
  protected DemanglingException error(String mess, int deltaPosition) {
    StringBuilder err = new StringBuilder(this.position + 1);
    int position = this.position + deltaPosition;
    for (int i = 0; i < position; i++)
      err.append(' '); 
    err.append('^');
    return new DemanglingException("Parsing error at position " + position + ((mess == null) ? "" : (": " + mess)) + " \n\t" + this.str + "\n\t" + err);
  }
  
  public static String getMethodName(Method method) {
    Name name = method.<Name>getAnnotation(Name.class);
    return (name == null) ? method.getName() : name.value();
  }
  
  public static String getClassName(Type type) {
    assert type != null;
    Class<?> typeClass = Utils.getClass(type);
    Name name = typeClass.<Name>getAnnotation(Name.class);
    return (name == null) ? typeClass.getSimpleName() : name.value();
  }
  
  public static String getFullClassName(Type type) {
    Class<?> typeClass = Utils.getClass(type);
    String simpleName = getClassName(typeClass);
    Namespace namespace = typeClass.<Namespace>getAnnotation(Namespace.class);
    return (namespace != null) ? (namespace.value().replaceAll("::", ".") + "." + simpleName) : simpleName;
  }
  
  public static interface TemplateArg {
    boolean matchesParam(Object param1Object, Demangler.Annotations param1Annotations);
  }
  
  public static class Symbol {
    final String symbol;
    
    long address;
    
    Demangler.MemberRef ref;
    
    boolean refParsed;
    
    final NativeLibrary library;
    
    private Convention.Style style;
    
    public Symbol(String symbol, NativeLibrary library) {
      this.symbol = symbol;
      this.library = library;
    }
    
    public NativeLibrary getLibrary() {
      return this.library;
    }
    
    public Demangler.MemberRef getRef() {
      return this.ref;
    }
    
    public Convention.Style getStyle() {
      return this.style;
    }
    
    public String getSymbol() {
      return this.symbol;
    }
    
    public String toString() {
      return this.symbol + ((this.ref == null) ? "" : (" (" + this.ref + ")"));
    }
    
    public long getAddress() {
      if (this.address == 0L)
        this.address = this.library.getSymbolAddress(this.symbol); 
      return this.address;
    }
    
    public void setAddress(long address) {
      this.address = address;
    }
    
    public Convention.Style getInferredCallingConvention() {
      if (this.style == null)
        if (this.symbol.matches("_.*?@\\d+")) {
          this.style = Convention.Style.StdCall;
        } else if (this.symbol.matches("@.*?@\\d+")) {
          this.style = Convention.Style.FastCall;
        } else if (Platform.isWindows() && this.symbol.contains("@")) {
          try {
            Demangler.MemberRef mr = getParsedRef();
            if (mr != null)
              this.style = mr.callingConvention; 
          } catch (Throwable th) {}
        }  
      return this.style;
    }
    
    public boolean matches(Method method) {
      if (!this.symbol.contains(Demangler.getMethodName(method)))
        return false; 
      parse();
      try {
        if (this.ref != null) {
          boolean res = this.ref.matches(method);
          if (!res && BridJ.debug)
            BridJ.debug("Symbol " + this.symbol + " was a good candidate but expected demangled signature " + this.ref + " did not match the method " + method); 
          return res;
        } 
      } catch (Exception ex) {
        ex.printStackTrace();
      } 
      return false;
    }
    
    public Demangler.MemberRef getParsedRef() {
      parse();
      return this.ref;
    }
    
    synchronized void parse() {
      if (!this.refParsed) {
        try {
          this.ref = this.library.parseSymbol(this.symbol);
        } catch (DemanglingException ex) {
          if (BridJ.debug)
            ex.printStackTrace(); 
          if (BridJ.verbose)
            BridJ.warning("Symbol parsing failed : " + ex.getMessage()); 
        } 
        this.refParsed = true;
      } 
    }
    
    public String getName() {
      return this.symbol;
    }
    
    public boolean matchesVirtualTable(Class<?> type) {
      if (!this.symbol.contains(type.getSimpleName()))
        return false; 
      parse();
      try {
        if (this.ref != null)
          return this.ref.matchesVirtualTable(type); 
      } catch (Exception ex) {
        ex.printStackTrace();
      } 
      return false;
    }
    
    public boolean matchesConstructor(Type type, Constructor<?> constr) {
      if (!this.symbol.contains(Demangler.getClassName(type)))
        return false; 
      parse();
      try {
        if (this.ref != null)
          return this.ref.matchesConstructor(type, constr); 
      } catch (Exception ex) {
        ex.printStackTrace();
      } 
      return false;
    }
    
    public boolean matchesDestructor(Class<?> type) {
      if (!this.symbol.contains(type.getSimpleName()))
        return false; 
      parse();
      try {
        if (this.ref != null)
          return this.ref.matchesDestructor(type); 
      } catch (Exception ex) {
        ex.printStackTrace();
      } 
      return false;
    }
    
    public boolean isVirtualTable() {
      return false;
    }
  }
  
  public static abstract class TypeRef implements TemplateArg {
    public abstract StringBuilder getQualifiedName(StringBuilder param1StringBuilder, boolean param1Boolean);
    
    public String getQualifiedName(boolean generic) {
      StringBuilder sb = getQualifiedName(new StringBuilder(), generic);
      return (sb == null) ? null : sb.toString();
    }
    
    public boolean matchesParam(Object param, Demangler.Annotations annotations) {
      return (param instanceof Type && matches((Type)param, annotations));
    }
    
    public boolean matches(Type type, Demangler.Annotations annotations) {
      String pack, thisName = getQualifiedName(false);
      if (thisName == null)
        return false; 
      Class<?> typeClass = Demangler.getTypeClass(type);
      String name = Demangler.getClassName(typeClass);
      if (thisName.equals(name))
        return true; 
      Namespace ns = typeClass.<Namespace>getAnnotation(Namespace.class);
      if (ns == null) {
        if (typeClass.getPackage() == null) {
          pack = "";
        } else {
          pack = typeClass.getPackage().getName();
        } 
      } else {
        pack = ns.value().replaceAll("\b::\b", ".").trim();
      } 
      if (pack.length() == 0)
        return false; 
      String qname = pack + "." + name;
      if (thisName.matches("\b" + Pattern.quote(qname)))
        return true; 
      return false;
    }
    
    public boolean equals(Object obj) {
      return toString().equals(obj.toString());
    }
  }
  
  public static class Constant implements TemplateArg {
    Object value;
    
    public Constant(Object value) {
      this.value = value;
    }
    
    public boolean matchesParam(Object param, Demangler.Annotations annotations) {
      return this.value.equals(param);
    }
    
    public String toString() {
      return this.value.toString();
    }
  }
  
  public static class NamespaceRef extends TypeRef {
    Object[] namespace;
    
    public NamespaceRef(Object... namespace) {
      this.namespace = namespace;
    }
    
    public StringBuilder getQualifiedName(StringBuilder b, boolean generic) {
      return Demangler.implode(b, this.namespace, ".");
    }
    
    public String toString() {
      return getQualifiedName(new StringBuilder(), true).toString();
    }
  }
  
  public static class PointerTypeRef extends TypeRef {
    public Demangler.TypeRef pointedType;
    
    public PointerTypeRef(Demangler.TypeRef pointedType) {
      assert pointedType != null;
      this.pointedType = pointedType;
    }
    
    public StringBuilder getQualifiedName(StringBuilder b, boolean generic) {
      return b.append("org.bridj.Pointer");
    }
    
    public String toString() {
      return this.pointedType + "*";
    }
    
    public boolean matches(Type type, Demangler.Annotations annotations) {
      if (super.matches(type, annotations))
        return true; 
      if (type == long.class && annotations.isAnnotationPresent((Class)Ptr.class))
        return true; 
      Class<?> typeClass = Demangler.getTypeClass(type);
      if (!Pointer.class.isAssignableFrom(typeClass))
        return false; 
      Type pointedType = Demangler.normalize(Utils.getUniqueParameterizedTypeParameter(type));
      if (this.pointedType == null || this.pointedType.toString().equals("void"))
        return (pointedType == null); 
      if (pointedType == null)
        return true; 
      return this.pointedType.matches(pointedType, annotations);
    }
  }
  
  protected static TypeRef pointerType(TypeRef tr) {
    return new PointerTypeRef(tr);
  }
  
  protected static TypeRef classType(Class<?> c, Class<? extends Annotation>... annotations) {
    return classType(c, null, annotations);
  }
  
  protected static TypeRef classType(Class<?> c, Type[] genericTypes, Class<? extends Annotation>... annotations) {
    JavaTypeRef tr = new JavaTypeRef();
    if (genericTypes == null) {
      tr.type = c;
    } else {
      tr.type = (Type)new DefaultParameterizedType(c, genericTypes);
    } 
    tr.annotations = annotations;
    return tr;
  }
  
  protected static TypeRef simpleType(String name, TemplateArg... args) {
    return new ClassRef(new Ident(name, args));
  }
  
  protected static TypeRef simpleType(Ident ident) {
    return new ClassRef(ident);
  }
  
  static Class<?> getTypeClass(Type type) {
    if (type instanceof Class)
      return (Class)type; 
    if (type instanceof ParameterizedType) {
      ParameterizedType pt = (ParameterizedType)type;
      Class<?> c = (Class)pt.getRawType();
      if (ValuedEnum.class.isAssignableFrom(c)) {
        Type[] types = pt.getActualTypeArguments();
        if (types == null || types.length != 1) {
          c = int.class;
        } else {
          c = getTypeClass(pt.getActualTypeArguments()[0]);
        } 
      } 
      return c;
    } 
    if (type instanceof GenericArrayType && 
      Object.class.isAssignableFrom(getTypeClass(((GenericArrayType)type).getGenericComponentType())))
      return Object[].class; 
    return null;
  }
  
  private static Type normalize(Type t) {
    if (t instanceof WildcardType) {
      WildcardType wt = (WildcardType)t;
      if ((wt.getLowerBounds()).length == 1)
        return normalize(wt.getLowerBounds()[0]); 
      return null;
    } 
    Class<?> c = Utils.getClass(t);
    if (c != null && c.isPrimitive()) {
      if (t == float.class)
        return Float.class; 
      if (t == double.class)
        return Double.class; 
      if (t == byte.class)
        return Byte.class; 
      if (t == char.class)
        return Character.class; 
      if (t == short.class)
        return Short.class; 
      if (t == int.class)
        return Integer.class; 
      if (t == long.class)
        return Long.class; 
      if (t == boolean.class)
        return Boolean.class; 
      if (t == void.class)
        return Void.class; 
    } 
    return t;
  }
  
  static boolean equivalentTypes(Type a, Class ac, Annotations aAnnotations, Type b, Class bc, Annotations bAnnotations) {
    if (normalize(a).equals(normalize(b)))
      return true; 
    if (aAnnotations != null && bAnnotations != null) {
      if (xor(isPointerLike(a, ac, aAnnotations), isPointerLike(b, bc, bAnnotations)))
        return false; 
      if (xor(isCLong(a, ac, aAnnotations), isCLong(b, bc, bAnnotations)))
        return false; 
    } 
    int as = getIntegralSize(a, ac, aAnnotations);
    int bs = getIntegralSize(b, bc, bAnnotations);
    return (as != -1 && as == bs);
  }
  
  static boolean xor(boolean a, boolean b) {
    return ((a && !b) || (!a && b));
  }
  
  static boolean isPointerLike(Type type, Class<?> typec, Annotations annotations) {
    if (type == long.class || type == Long.class)
      return ((annotations == null && Pointer.SIZE == 8) || (annotations != null && annotations.isAnnotationPresent((Class)Ptr.class) && !annotations.isAnnotationPresent((Class)CLong.class))); 
    return (type == SizeT.class || Pointer.class.isAssignableFrom(typec));
  }
  
  static boolean isCLong(Type type, Class typec, Annotations annotations) {
    if (type == long.class || type == Long.class)
      return ((annotations == null && CLong.SIZE == 8) || (annotations != null && annotations.isAnnotationPresent((Class)CLong.class))); 
    return (type == CLong.class);
  }
  
  static int getIntegralSize(Type type, Class<?> typec, Annotations annotations) {
    if (type == int.class || type == Integer.class)
      return 4; 
    if (type == long.class || type == Long.class) {
      if (annotations != null) {
        if (annotations.isAnnotationPresent((Class)Ptr.class))
          return Pointer.SIZE; 
        if (annotations.isAnnotationPresent((Class)CLong.class))
          return CLong.SIZE; 
      } 
      return 8;
    } 
    if (type == CLong.class)
      return CLong.SIZE; 
    if (type == SizeT.class)
      return SizeT.SIZE; 
    if (type == TimeT.class)
      return TimeT.SIZE; 
    if (type == byte.class || type == Byte.class)
      return 1; 
    if (type == char.class || type == Character.class || type == short.class || type == Short.class)
      return 2; 
    if (ValuedEnum.class.isAssignableFrom(typec))
      return 4; 
    if (Pointer.class.isAssignableFrom(typec))
      return SizeT.SIZE; 
    return -1;
  }
  
  public static boolean equivalentTypes(Type a, Annotations aAnnotations, Type b, Annotations bAnnotations) {
    return equivalentTypes(a, getTypeClass(a), aAnnotations, b, getTypeClass(b), bAnnotations);
  }
  
  public static class JavaTypeRef extends TypeRef {
    Type type;
    
    Class<? extends Annotation>[] annotations;
    
    public StringBuilder getQualifiedName(StringBuilder b, boolean generic) {
      return b.append(Demangler.getFullClassName(this.type));
    }
    
    public boolean matches(Type type, Demangler.Annotations annotations) {
      Class<?> tc = Demangler.getTypeClass(this.type);
      Class<?> typec = Demangler.getTypeClass(type);
      if (typec == null)
        return true; 
      if (tc == typec || tc.equals(typec))
        return true; 
      if ((type == long.class && Pointer.class.isAssignableFrom(tc)) || (Pointer.class.isAssignableFrom(typec) && tc == long.class))
        return true; 
      return Demangler.equivalentTypes(type, typec, annotations, this.type, tc, null);
    }
    
    public String toString() {
      StringBuilder b = new StringBuilder();
      for (Class<?> ann : this.annotations)
        b.append(ann.getSimpleName()).append(' '); 
      b.append((this.type instanceof Class) ? ((Class)this.type).getSimpleName() : this.type.toString());
      return b.toString();
    }
  }
  
  public static interface IdentLike {}
  
  public static class Ident implements IdentLike {
    Object simpleName;
    
    Demangler.TemplateArg[] templateArguments;
    
    public Ident(String simpleName, Demangler.TemplateArg... templateArguments) {
      this.simpleName = simpleName;
      this.templateArguments = templateArguments;
    }
    
    public boolean equals(Object o) {
      if (o == null || !(o instanceof Ident))
        return false; 
      Ident ident = (Ident)o;
      if (!this.simpleName.equals(ident.simpleName))
        return false; 
      int n = this.templateArguments.length;
      if (ident.templateArguments.length != n)
        return false; 
      for (int i = 0; i < n; i++) {
        if (!this.templateArguments[i].equals(ident.templateArguments[i]))
          return false; 
      } 
      return true;
    }
    
    public String toString() {
      StringBuilder b = new StringBuilder();
      b.append(this.simpleName);
      Demangler.appendTemplateArgs(b, (Object[])this.templateArguments);
      return b.toString();
    }
  }
  
  public static class ClassRef extends TypeRef {
    private Demangler.TypeRef enclosingType;
    
    final Demangler.Ident ident;
    
    public ClassRef(Demangler.Ident ident) {
      this.ident = ident;
    }
    
    public StringBuilder getQualifiedName(StringBuilder b, boolean generic) {
      if (getEnclosingType() instanceof ClassRef) {
        getEnclosingType().getQualifiedName(b, generic).append('$');
      } else if (getEnclosingType() instanceof Demangler.NamespaceRef) {
        getEnclosingType().getQualifiedName(b, generic).append('.');
      } 
      b.append(this.ident.simpleName);
      if (generic && this.ident.templateArguments != null) {
        int args = 0;
        for (int i = 0, n = this.ident.templateArguments.length; i < n; i++) {
          Demangler.TemplateArg arg = this.ident.templateArguments[i];
          if (arg instanceof Demangler.TypeRef) {
            if (args == 0) {
              b.append('<');
            } else {
              b.append(", ");
            } 
            ((Demangler.TypeRef)arg).getQualifiedName(b, generic);
            args++;
          } 
        } 
        if (args > 0)
          b.append('>'); 
      } 
      return b;
    }
    
    public Demangler.Ident getIdent() {
      return this.ident;
    }
    
    public void setEnclosingType(Demangler.TypeRef enclosingType) {
      this.enclosingType = enclosingType;
    }
    
    public Demangler.TypeRef getEnclosingType() {
      return this.enclosingType;
    }
    
    public boolean matches(Type type, Demangler.Annotations annotations) {
      Class<?> typeClass = Demangler.getTypeClass(type);
      if (typeClass == null)
        return false; 
      String fullName = Demangler.getFullClassName(ValuedEnum.class.isAssignableFrom(typeClass) ? Demangler.normalize(Utils.getUniqueParameterizedTypeParameter(type)) : typeClass);
      String qname = getQualifiedName(false);
      if (fullName != null && fullName.equals(qname))
        return true; 
      return false;
    }
    
    public String toString() {
      StringBuilder b = new StringBuilder();
      if (this.enclosingType != null)
        b.append(this.enclosingType).append('.'); 
      b.append(this.ident);
      return b.toString();
    }
  }
  
  static void appendTemplateArgs(StringBuilder b, Object[] params) {
    if (params == null || params.length == 0)
      return; 
    appendArgs(b, '<', '>', params);
  }
  
  static void appendArgs(StringBuilder b, char pre, char post, Object[] params) {
    b.append(pre);
    if (params != null)
      for (int i = 0; i < params.length; i++) {
        if (i != 0)
          b.append(", "); 
        b.append(params[i]);
      }  
    b.append(post);
  }
  
  public abstract MemberRef parseSymbol() throws DemanglingException;
  
  public static class FunctionTypeRef extends TypeRef {
    Demangler.MemberRef function;
    
    public FunctionTypeRef(Demangler.MemberRef function) {
      this.function = function;
    }
    
    public StringBuilder getQualifiedName(StringBuilder b, boolean generic) {
      return null;
    }
    
    public boolean matches(Type type, Demangler.Annotations annotations) {
      Class<?> typeClass = Demangler.getTypeClass(type);
      if (!Callback.class.isAssignableFrom(typeClass))
        return false; 
      Method method = CRuntime.getInstance().getFastestCallbackMethod(typeClass);
      if (method == null)
        return false; 
      return this.function.matches(method);
    }
    
    public String toString() {
      return this.function.toString();
    }
  }
  
  public enum SpecialName implements IdentLike {
    Constructor("", true, true),
    SpecialConstructor("", true, true),
    Destructor("", true, true),
    SelfishDestructor("", true, true),
    DeletingDestructor("", true, true),
    New("new", true, true),
    Delete("delete", true, true),
    NewArray("new[]", true, true),
    DeleteArray("delete[]", true, true),
    VFTable("vftable", false, true),
    VBTable("vbtable", false, true),
    VCall("vcall", false, false),
    TypeOf("typeof", false, false),
    ScalarDeletingDestructor("'scalar deleting destructor'", true, true),
    VectorDeletingDestructor("'vector deleting destructor'", true, true),
    OperatorAssign("operator=", true, true),
    OperatorRShift("operator>>", true, true),
    OperatorDivideAssign("operator/=", true, true),
    OperatorModuloAssign("operator%=", true, true),
    OperatorRShiftAssign("operator>>=", true, true),
    OperatorLShiftAssign("operator<<=", true, true),
    OperatorBitAndAssign("operator&=", true, true),
    OperatorBitOrAssign("operator|=", true, true),
    OperatorXORAssign("operator^=", true, true),
    OperatorLShift("operator<<", true, true),
    OperatorLogicNot("operator!", true, true),
    OperatorEquals("operator==", true, true),
    OperatorDifferent("operator!=", true, true),
    OperatorSquareBrackets("operator[]", true, true),
    OperatorCast("'some cast operator'", true, true),
    OperatorArrow("operator->", true, true),
    OperatorMultiply("operator*", true, true),
    OperatorIncrement("operator++", true, true),
    OperatorDecrement("operator--", true, true),
    OperatorSubstract("operator-", true, true),
    OperatorAdd("operator+", true, true),
    OperatorBitAnd("operator&=", true, true),
    OperatorArrowStar("operator->*", true, true),
    OperatorDivide("operator/", true, true),
    OperatorModulo("operator%", true, true),
    OperatorLower("operator<", true, true),
    OperatorLowerEquals("operator<=", true, true),
    OperatorGreater("operator>", true, true),
    OperatorGreaterEquals("operator>=", true, true),
    OperatorComma("operator,", true, true),
    OperatorParenthesis("operator()", true, true),
    OperatorBitNot("operator~", true, true),
    OperatorXOR("operator^", true, true),
    OperatorBitOr("operator|", true, true),
    OperatorLogicAnd("operator&&", true, true),
    OperatorLogicOr("operator||", true, true),
    OperatorMultiplyAssign("operator*=", true, true),
    OperatorAddAssign("operator+=", true, true),
    OperatorSubstractAssign("operator-=", true, true);
    
    final String name;
    
    final boolean isFunction;
    
    final boolean isMember;
    
    SpecialName(String name, boolean isFunction, boolean isMember) {
      this.name = name;
      this.isFunction = isFunction;
      this.isMember = isMember;
    }
    
    public String toString() {
      return this.name;
    }
    
    public boolean isFunction() {
      return this.isFunction;
    }
    
    public boolean isMember() {
      return this.isMember;
    }
  }
  
  public static class MemberRef {
    private Integer argumentsStackSize;
    
    private Demangler.TypeRef enclosingType;
    
    private Demangler.TypeRef valueType;
    
    private Demangler.IdentLike memberName;
    
    Boolean isStatic;
    
    Boolean isProtected;
    
    Boolean isPrivate;
    
    public int modifiers;
    
    public Demangler.TypeRef[] paramTypes;
    
    public Demangler.TypeRef[] throwTypes;
    
    Demangler.TemplateArg[] templateArguments;
    
    public Convention.Style callingConvention;
    
    public void setTemplateArguments(Demangler.TemplateArg[] templateArguments) {
      this.templateArguments = templateArguments;
    }
    
    public Integer getArgumentsStackSize() {
      return this.argumentsStackSize;
    }
    
    public void setArgumentsStackSize(Integer argumentsStackSize) {
      this.argumentsStackSize = argumentsStackSize;
    }
    
    protected boolean matchesEnclosingType(Type type) {
      return (getEnclosingType() != null && getEnclosingType().matches(type, Demangler.annotations(type)));
    }
    
    protected boolean matchesVirtualTable(Type type) {
      return (this.memberName == Demangler.SpecialName.VFTable && matchesEnclosingType(type));
    }
    
    protected boolean matchesConstructor(Type type, Constructor<?> constr) {
      if (this.memberName != Demangler.SpecialName.Constructor)
        return false; 
      if (!matchesEnclosingType(type))
        return false; 
      Template temp = (Template)Utils.getClass(type).getAnnotation(Template.class);
      Annotation[][] anns = constr.getParameterAnnotations();
      Type[] parameterTypes = constr.getGenericParameterTypes();
      int overrideOffset = Utils.getEnclosedConstructorParametersOffset(constr);
      if (!matchesArgs(parameterTypes, anns, overrideOffset + ((temp == null) ? 0 : (temp.value()).length)))
        return false; 
      return true;
    }
    
    protected boolean matchesDestructor(Type type) {
      return (this.memberName == Demangler.SpecialName.Destructor && matchesEnclosingType(type));
    }
    
    static boolean hasInstance(Object[] array, Class<? extends Annotation>... cs) {
      for (Object o : array) {
        for (Class<?> c : cs) {
          if (c.isInstance(o))
            return true; 
        } 
      } 
      return false;
    }
    
    static int getArgumentsStackSize(Method method) {
      int total = 0;
      Type[] paramTypes = method.getGenericParameterTypes();
      Annotation[][] anns = method.getParameterAnnotations();
      for (int iArg = 0, nArgs = paramTypes.length; iArg < nArgs; iArg++) {
        Class<?> paramType = Demangler.getTypeClass(paramTypes[iArg]);
        if (paramType == int.class) {
          total += 4;
        } else if (paramType == long.class) {
          Annotation[] as = anns[iArg];
          if (AnnotationUtils.isAnnotationPresent(Ptr.class, as) || AnnotationUtils.isAnnotationPresent(CLong.class, as)) {
            total += Pointer.SIZE;
          } else {
            total += 8;
          } 
        } else if (paramType == float.class) {
          total += 4;
        } else if (paramType == double.class) {
          total += 8;
        } else if (paramType == byte.class) {
          total++;
        } else if (paramType == char.class) {
          total += Platform.WCHAR_T_SIZE;
        } else if (paramType == CLong.class) {
          total += Platform.CLONG_SIZE;
        } else if (paramType == SizeT.class) {
          total += Platform.SIZE_T_SIZE;
        } else if (paramType == TimeT.class) {
          total += Platform.TIME_T_SIZE;
        } else if (paramType == short.class) {
          total += 2;
        } else if (paramType == boolean.class) {
          total++;
        } else if (Pointer.class.isAssignableFrom(paramType)) {
          total += Pointer.SIZE;
        } else if (NativeObject.class.isAssignableFrom(paramType)) {
          total = (int)(total + ((CRuntime)BridJ.getRuntime(paramType)).sizeOf(paramTypes[iArg], null));
        } else if (FlagSet.class.isAssignableFrom(paramType)) {
          total += 4;
        } else {
          throw new RuntimeException("Type not handled : " + paramType.getName());
        } 
      } 
      return total;
    }
    
    protected boolean matches(Method method) {
      if (this.memberName instanceof Demangler.SpecialName)
        return false; 
      if (!matchesEnclosingType(method))
        return false; 
      return matchesSignature(method);
    }
    
    public boolean matchesEnclosingType(Method method) {
      Demangler.TypeRef et = getEnclosingType();
      if (et == null)
        return true; 
      Demangler.Annotations annotations = Demangler.annotations(method);
      Class<?> dc = method.getDeclaringClass();
      do {
        if (et.matches(dc, annotations))
          return true; 
        dc = dc.getSuperclass();
      } while (dc != null && dc != Object.class);
      return false;
    }
    
    public boolean matchesSignature(Method method) {
      if (getArgumentsStackSize() != null && getArgumentsStackSize().intValue() != getArgumentsStackSize(method))
        return false; 
      if (getMemberName() != null && !getMemberName().toString().equals(Demangler.getMethodName(method)))
        return false; 
      if (getValueType() != null && !getValueType().matches(method.getReturnType(), Demangler.annotations(method)))
        return false; 
      Template temp = method.<Template>getAnnotation(Template.class);
      Annotation[][] anns = method.getParameterAnnotations();
      Type[] parameterTypes = method.getGenericParameterTypes();
      if (this.paramTypes != null && !matchesArgs(parameterTypes, anns, (temp == null) ? 0 : (temp.value()).length))
        return false; 
      return true;
    }
    
    private boolean matchesArgs(Type[] parameterTypes, Annotation[][] anns, int offset) {
      int totalArgs = offset;
      int i, n;
      for (i = 0, n = (this.templateArguments == null) ? 0 : this.templateArguments.length; i < n; i++) {
        if (totalArgs >= parameterTypes.length)
          return false; 
        Type paramType = parameterTypes[offset + i];
        Demangler.TemplateArg arg = this.templateArguments[i];
        if (arg instanceof Demangler.TypeRef) {
          if (!paramType.equals(Class.class))
            return false; 
        } else if (arg instanceof Demangler.Constant) {
          try {
            Demangler.getTypeClass(paramType).cast(((Demangler.Constant)arg).value);
          } catch (ClassCastException ex) {
            return false;
          } 
        } 
        totalArgs++;
      } 
      for (i = 0, n = (this.paramTypes == null) ? 0 : this.paramTypes.length; i < n; i++) {
        if (totalArgs >= parameterTypes.length)
          return false; 
        Demangler.TypeRef paramType = this.paramTypes[i];
        Type parameterType = parameterTypes[totalArgs];
        if (!paramType.matches(parameterType, Demangler.annotations((anns == null) ? null : anns[i])))
          return false; 
        totalArgs++;
      } 
      if (totalArgs != parameterTypes.length)
        return false; 
      return true;
    }
    
    public String toString() {
      StringBuilder b = new StringBuilder();
      b.append(this.valueType).append(' ');
      boolean nameWritten = false;
      if (this.enclosingType != null) {
        b.append(this.enclosingType);
        b.append('.');
        if (this.memberName instanceof Demangler.SpecialName)
          switch ((Demangler.SpecialName)this.memberName) {
            case Destructor:
              b.append('~');
            case Constructor:
              b.append(((Demangler.ClassRef)this.enclosingType).ident.simpleName);
              nameWritten = true;
              break;
          }  
      } 
      if (!nameWritten)
        b.append(this.memberName); 
      Demangler.appendTemplateArgs(b, (Object[])this.templateArguments);
      Demangler.appendArgs(b, '(', ')', (Object[])this.paramTypes);
      return b.toString();
    }
    
    public void setMemberName(Demangler.IdentLike memberName) {
      this.memberName = memberName;
    }
    
    public Demangler.IdentLike getMemberName() {
      return this.memberName;
    }
    
    public void setValueType(Demangler.TypeRef valueType) {
      this.valueType = valueType;
    }
    
    public Demangler.TypeRef getValueType() {
      return this.valueType;
    }
    
    public void setEnclosingType(Demangler.TypeRef enclosingType) {
      this.enclosingType = enclosingType;
    }
    
    public Demangler.TypeRef getEnclosingType() {
      return this.enclosingType;
    }
  }
}
