/*     */ package org.bridj.demangling;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.math.BigInteger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.bridj.CLong;
/*     */ import org.bridj.NativeLibrary;
/*     */ import org.bridj.ann.Convention;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VC9Demangler
/*     */   extends Demangler
/*     */ {
/*     */   List<Demangler.TypeRef> allQualifiedNames;
/*     */   
/*     */   public VC9Demangler(NativeLibrary library, String str) {
/*  56 */     super(library, str);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 461 */     this.allQualifiedNames = new ArrayList<Demangler.TypeRef>();
/*     */   }
/*     */   private AccessLevelAndStorageClass parseAccessLevelAndStorageClass() throws Demangler.DemanglingException { AccessLevelAndStorageClass ac = new AccessLevelAndStorageClass(); switch (consumeChar()) { case 'A': case 'B': ac.modifiers = 2; return ac;case 'C': case 'D': ac.modifiers = 10; return ac;case 'E': case 'F': ac.modifiers = 2; ac.isVirtual = true; return ac;case 'G': case 'H': ac.modifiers = 2; ac.isThunk = true; return ac;case 'I': case 'J': ac.modifiers = 4; return ac;case 'K': case 'L': ac.modifiers = 12; return ac;case 'M': case 'N': ac.modifiers = 4; ac.isVirtual = true; return ac;case 'O': case 'P': ac.modifiers = 4; ac.isThunk = true; return ac;case 'Q': case 'R': ac.modifiers = 1; return ac;case 'S': case 'T': ac.modifiers = 9; return ac;case 'U': case 'V': ac.modifiers = 1; ac.isVirtual = true; return ac;case 'W': case 'X': ac.modifiers = 1; ac.isThunk = true; return ac;case 'Y': case 'Z': ac.modifiers = 0; return ac; }  throw error("Unknown access level + storage class"); }
/*     */   private Demangler.ClassRef parseTemplateType() throws Demangler.DemanglingException { String name = parseNameFragment(); List<Demangler.TemplateArg> args = parseTemplateParams(); List<Object> names = parseNameQualifications(); Demangler.ClassRef tr = new Demangler.ClassRef(new Demangler.Ident(name, args.<Demangler.TemplateArg>toArray(new Demangler.TemplateArg[args.size()]))); tr.setEnclosingType(reverseNamespace(names)); addBackRef(tr); return tr; }
/*     */   private void parseFunctionProperty(Demangler.MemberRef mr) throws Demangler.DemanglingException { mr.callingConvention = parseCallingConvention(); Demangler.TypeRef returnType = consumeCharIf(new char[] { '@' }) ? classType(void.class, (Class<? extends Annotation>[])new Class[0]) : parseType(true); List<Demangler.TypeRef> paramTypes = parseParams(); mr.paramTypes = paramTypes.<Demangler.TypeRef>toArray(new Demangler.TypeRef[paramTypes.size()]); if (!consumeCharIf(new char[] { 'Z' })) { List<Demangler.TypeRef> throwTypes = parseParams(); mr.throwTypes = throwTypes.<Demangler.TypeRef>toArray(new Demangler.TypeRef[throwTypes.size()]); }  mr.setValueType(returnType); }
/*     */   static class AnonymousTemplateArg implements Demangler.TemplateArg {
/*     */     String v;
/*     */     public AnonymousTemplateArg(String v) { this.v = v; } public boolean matchesParam(Object param, Demangler.Annotations annotations) { return true; } public String toString() { return this.v; } } private Demangler.TemplateArg parseTemplateParameter() throws Demangler.DemanglingException { int a; int b; switch (peekChar()) { case '?': consumeChar(); return new AnonymousTemplateArg("'anonymous template param " + parseNumber(false) + "'");case '$': consumeChar(); switch (consumeChar()) { case '0': return new Demangler.Constant(Integer.valueOf(parseNumber(true)));case '2': a = parseNumber(true); b = parseNumber(true); return new Demangler.Constant(Double.valueOf(a * Math.exp((10 * (int)Math.log(b - Math.log10(a) + 1.0D)))));case 'D': return new AnonymousTemplateArg("'anonymous template param " + parseNumber(false) + "'");case 'F': return new AnonymousTemplateArg("'tuple (" + parseNumber(true) + ", " + parseNumber(true) + ")'");case 'G': return new AnonymousTemplateArg("'tuple (" + parseNumber(true) + ", " + parseNumber(true) + ", " + parseNumber(true) + ")'");case 'Q': return new AnonymousTemplateArg("'anonymous non-type template param " + parseNumber(false) + "'"); }  break; }  return parseType(true); } static class AccessLevelAndStorageClass {
/* 469 */     int modifiers; boolean isVirtual = false, isThunk = false; } <T> T withEmptyQualifiedNames(DemanglingOp<T> action) throws Demangler.DemanglingException { List<Demangler.TypeRef> list = this.allQualifiedNames;
/*     */     
/* 471 */     try { this.allQualifiedNames = new ArrayList<Demangler.TypeRef>();
/* 472 */       return action.run(); }
/*     */     finally
/* 474 */     { this.allQualifiedNames = list; }  }
/*     */   public Demangler.MemberRef parseSymbol() throws Demangler.DemanglingException { Demangler.TypeRef encl; Demangler.MemberRef mr = new Demangler.MemberRef(); int iAt = this.str.indexOf('@'); if (iAt >= 0 && consumeCharIf(new char[] { '_' }) && iAt > 0) { mr.setMemberName(new Demangler.Ident(this.str.substring(1, iAt), new Demangler.TemplateArg[0])); mr.setArgumentsStackSize(Integer.valueOf(Integer.parseInt(this.str.substring(iAt + 1)))); return mr; }  if (!consumeCharIf(new char[] { '@', '?' })) return null;  Demangler.IdentLike memberName = parseFirstQualifiedTypeNameComponent(); if (memberName instanceof Demangler.SpecialName) { Demangler.SpecialName specialName = (Demangler.SpecialName)memberName; if (!specialName.isFunction()) return null;  }  mr.setMemberName(memberName); List<Object> qNames = parseNameQualifications(); AccessLevelAndStorageClass ac = parseAccessLevelAndStorageClass(); CVClassModifier cvMod = null; if (ac.modifiers != 0 && !Modifier.isStatic(ac.modifiers)) cvMod = parseCVClassModifier();  if (cvMod != null && (cvMod.isMember || memberName instanceof Demangler.SpecialName || Modifier.isPublic(ac.modifiers))) { Object r = qNames.get(0); Demangler.ClassRef tr = (r instanceof Demangler.ClassRef) ? (Demangler.ClassRef)r : new Demangler.ClassRef(new Demangler.Ident((String)r, new Demangler.TemplateArg[0])); qNames.remove(0); tr.setEnclosingType(reverseNamespace(qNames)); encl = tr; } else { encl = reverseNamespace(qNames); }  addBackRef(encl); mr.setEnclosingType(encl); parseFunctionProperty(mr); if (this.position != this.length) error("Failed to demangle the whole symbol");  return mr; }
/*     */   Demangler.TypeRef parseReturnType() throws Demangler.DemanglingException { Demangler.TypeRef tr = parseType(true); return tr; }
/*     */   int parseNumber(boolean allowSign) throws Demangler.DemanglingException { int sign = (allowSign && consumeCharIf(new char[] { '?' })) ? -1 : 1; if (Character.isDigit(peekChar())) { char c1 = consumeChar(); return sign * (c1 - 48); }  if (peekChar() == '@') return 0;  StringBuilder b = new StringBuilder(); long n = 0L; char c; while ((c = consumeChar()) >= 'A' && c <= 'P' && c != '@') n += (16 * (c - 65));  String s = b.toString().trim(); if (c != '@' || s.length() == 0) throw error("Expected a number here", -b.length());  return sign * Integer.parseInt(s, 16); }
/*     */   Demangler.TypeRef consumeIfBackRef() throws Demangler.DemanglingException { char c = peekChar(); if (Character.isDigit(c)) { consumeChar(); int iBack = c - 48; return getBackRef(iBack); }  return null; }
/* 479 */   Demangler.TypeRef parseType(boolean allowVoid) throws Demangler.DemanglingException { Demangler.TypeRef tr; CVClassModifier cvMods; Class<?> cl; Demangler.TypeRef qn, backRef = consumeIfBackRef(); if (backRef != null) return backRef;  char c = consumeChar(); switch (c) { case '_': switch (consumeChar()) { case 'D': case 'E': tr = classType(byte.class, (Class<? extends Annotation>[])new Class[0]); addBackRef(tr); return tr;case 'F': case 'G': tr = classType(short.class, (Class<? extends Annotation>[])new Class[0]); addBackRef(tr); return tr;case 'H': case 'I': tr = classType(int.class, (Class<? extends Annotation>[])new Class[0]); addBackRef(tr); return tr;case 'J': case 'K': tr = classType(long.class, (Class<? extends Annotation>[])new Class[0]); addBackRef(tr); return tr;case 'L': tr = classType(BigInteger.class, (Class<? extends Annotation>[])new Class[0]); addBackRef(tr); return tr;case 'N': tr = classType(boolean.class, (Class<? extends Annotation>[])new Class[0]); addBackRef(tr); return tr;case '0': parseCVClassModifier(); parseType(false); tr = classType(Object[].class, (Class<? extends Annotation>[])new Class[0]); addBackRef(tr); return tr;case 'W': tr = classType(char.class, (Class<? extends Annotation>[])new Class[0]); addBackRef(tr); return tr; }  throw error(-1);case 'Z': return classType(Object[].class, (Class<? extends Annotation>[])new Class[0]);case 'O': throw error("'long double' type cannot be mapped !", -1);case 'C': case 'D': case 'E': return classType(byte.class, (Class<? extends Annotation>[])new Class[0]);case 'F': case 'G': return classType(short.class, (Class<? extends Annotation>[])new Class[0]);case 'H': case 'I': return classType(int.class, (Class<? extends Annotation>[])new Class[0]);case 'J': case 'K': return classType(CLong.class, (Class<? extends Annotation>[])new Class[0]);case 'M': return classType(float.class, (Class<? extends Annotation>[])new Class[0]);case 'N': return classType(double.class, (Class<? extends Annotation>[])new Class[0]);case 'Y': throw error("TODO handle cointerfaces", -1);case 'X': if (!allowVoid) return null;  return classType(void.class, (Class<? extends Annotation>[])new Class[0]);case '?': parseCVClassModifier(); return parseType(allowVoid);case 'A': case 'B': case 'P': case 'Q': case 'R': case 'S': if (!consumeCharsIf(new char[] { '$', 'A' })) consumeCharsIf(new char[] { '$', 'B' });  cvMods = parseCVClassModifier(); if (cvMods.isVariable) { if (consumeCharIf(new char[] { 'Y' })) { int dimensions = parseNumber(false); int[] indices = new int[dimensions]; for (int i = 0; i < dimensions; i++) indices[i] = parseNumber(false);  }  tr = pointerType(parseType(true)); } else { Demangler.MemberRef mr = new Demangler.MemberRef(); parseFunctionProperty(mr); tr = pointerType(new Demangler.FunctionTypeRef(mr)); }  addBackRef(tr); return tr;case 'T': case 'U': case 'V': return parseQualifiedTypeName();case 'W': switch (consumeChar()) { case '0': case '1': cl = byte.class; qn = parseQualifiedTypeName(); addBackRef(qn); return classType(cl, (Class<? extends Annotation>[])new Class[0]);case '2': case '3': cl = short.class; qn = parseQualifiedTypeName(); addBackRef(qn); return classType(cl, (Class<? extends Annotation>[])new Class[0]);case '4': case '5': cl = int.class; qn = parseQualifiedTypeName(); addBackRef(qn); return classType(cl, (Class<? extends Annotation>[])new Class[0]);case '6': case '7': cl = int.class; qn = parseQualifiedTypeName(); addBackRef(qn); return classType(cl, (Class<? extends Annotation>[])new Class[0]); }  throw error("Unfinished enum", -1); }  throw error(-1); } static Demangler.NamespaceRef reverseNamespace(List<Object> names) { if (names == null || names.isEmpty()) return null;  Collections.reverse(names); return new Demangler.NamespaceRef(names.toArray()); } Demangler.IdentLike parseFirstQualifiedTypeNameComponent() throws Demangler.DemanglingException { if (consumeCharIf(new char[] { '?' })) {
/* 480 */       if (consumeCharIf(new char[] { '$' })) {
/* 481 */         return parseTemplateType().getIdent();
/*     */       }
/* 483 */       return parseSpecialName();
/*     */     } 
/*     */     
/* 486 */     return new Demangler.Ident(parseNameFragment(), new Demangler.TemplateArg[0]); }
/*     */ 
/*     */ 
/*     */   
/*     */   Demangler.TypeRef parseQualifiedTypeName() throws Demangler.DemanglingException {
/* 491 */     Demangler.TypeRef backRef = consumeIfBackRef();
/* 492 */     if (backRef != null) {
/* 493 */       return backRef;
/*     */     }
/*     */     
/* 496 */     char c = peekChar();
/* 497 */     List<Object> names = parseNameQualifications();
/*     */ 
/*     */ 
/*     */     
/* 501 */     Object first = names.get(0);
/* 502 */     names.set(0, (first instanceof String) ? new Demangler.Ident((String)first, new Demangler.TemplateArg[0]) : ((Demangler.ClassRef)first).getIdent());
/*     */     
/* 504 */     if (names.size() == 1 && names.get(0) instanceof Demangler.TypeRef) {
/* 505 */       return (Demangler.TypeRef)names.get(0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 519 */     Demangler.ClassRef tr = new Demangler.ClassRef((Demangler.Ident)names.get(0));
/* 520 */     names.remove(0);
/* 521 */     tr.setEnclosingType(reverseNamespace(names));
/* 522 */     return tr;
/*     */   }
/*     */   
/*     */   public Demangler.IdentLike parseSpecialName() throws Demangler.DemanglingException {
/* 526 */     switch (consumeChar()) {
/*     */       case '0':
/* 528 */         return Demangler.SpecialName.Constructor;
/*     */       case '1':
/* 530 */         return Demangler.SpecialName.Destructor;
/*     */       case '2':
/* 532 */         return Demangler.SpecialName.New;
/*     */       case '3':
/* 534 */         return Demangler.SpecialName.Delete;
/*     */       case '4':
/* 536 */         return Demangler.SpecialName.OperatorAssign;
/*     */       case '5':
/* 538 */         return Demangler.SpecialName.OperatorRShift;
/*     */       case '6':
/* 540 */         return Demangler.SpecialName.OperatorLShift;
/*     */       case '7':
/* 542 */         return Demangler.SpecialName.OperatorLogicNot;
/*     */       case '8':
/* 544 */         return Demangler.SpecialName.OperatorEquals;
/*     */       case '9':
/* 546 */         return Demangler.SpecialName.OperatorDifferent;
/*     */       case 'A':
/* 548 */         return Demangler.SpecialName.OperatorSquareBrackets;
/*     */       case 'B':
/* 550 */         return Demangler.SpecialName.OperatorCast;
/*     */       case 'C':
/* 552 */         return Demangler.SpecialName.OperatorArrow;
/*     */       case 'D':
/* 554 */         return Demangler.SpecialName.OperatorMultiply;
/*     */       case 'E':
/* 556 */         return Demangler.SpecialName.OperatorIncrement;
/*     */       case 'F':
/* 558 */         return Demangler.SpecialName.OperatorDecrement;
/*     */       case 'G':
/* 560 */         return Demangler.SpecialName.OperatorSubstract;
/*     */       case 'H':
/* 562 */         return Demangler.SpecialName.OperatorAdd;
/*     */       case 'I':
/* 564 */         return Demangler.SpecialName.OperatorBitAnd;
/*     */       case 'J':
/* 566 */         return Demangler.SpecialName.OperatorArrowStar;
/*     */       case 'K':
/* 568 */         return Demangler.SpecialName.OperatorDivide;
/*     */       case 'L':
/* 570 */         return Demangler.SpecialName.OperatorModulo;
/*     */       case 'M':
/* 572 */         return Demangler.SpecialName.OperatorLower;
/*     */       case 'N':
/* 574 */         return Demangler.SpecialName.OperatorLowerEquals;
/*     */       case 'O':
/* 576 */         return Demangler.SpecialName.OperatorGreater;
/*     */       case 'P':
/* 578 */         return Demangler.SpecialName.OperatorGreaterEquals;
/*     */       case 'Q':
/* 580 */         return Demangler.SpecialName.OperatorComma;
/*     */       case 'R':
/* 582 */         return Demangler.SpecialName.OperatorParenthesis;
/*     */       case 'S':
/* 584 */         return Demangler.SpecialName.OperatorBitNot;
/*     */       case 'T':
/* 586 */         return Demangler.SpecialName.OperatorXOR;
/*     */       case 'U':
/* 588 */         return Demangler.SpecialName.OperatorBitOr;
/*     */       case 'V':
/* 590 */         return Demangler.SpecialName.OperatorLogicAnd;
/*     */       case 'W':
/* 592 */         return Demangler.SpecialName.OperatorLogicOr;
/*     */       case 'X':
/* 594 */         return Demangler.SpecialName.OperatorMultiplyAssign;
/*     */       case 'Y':
/* 596 */         return Demangler.SpecialName.OperatorAddAssign;
/*     */       case 'Z':
/* 598 */         return Demangler.SpecialName.OperatorSubstractAssign;
/*     */       case '_':
/* 600 */         switch (consumeChar()) {
/*     */           case '0':
/* 602 */             return Demangler.SpecialName.OperatorDivideAssign;
/*     */           case '1':
/* 604 */             return Demangler.SpecialName.OperatorModuloAssign;
/*     */           case '2':
/* 606 */             return Demangler.SpecialName.OperatorLShiftAssign;
/*     */           case '3':
/* 608 */             return Demangler.SpecialName.OperatorRShiftAssign;
/*     */           case '4':
/* 610 */             return Demangler.SpecialName.OperatorBitAndAssign;
/*     */           case '5':
/* 612 */             return Demangler.SpecialName.OperatorBitOrAssign;
/*     */           case '6':
/* 614 */             return Demangler.SpecialName.OperatorXORAssign;
/*     */           case '7':
/* 616 */             return Demangler.SpecialName.VFTable;
/*     */           case '8':
/* 618 */             return Demangler.SpecialName.VBTable;
/*     */           case '9':
/* 620 */             return Demangler.SpecialName.VCall;
/*     */           case 'E':
/* 622 */             return Demangler.SpecialName.VectorDeletingDestructor;
/*     */           case 'G':
/* 624 */             return Demangler.SpecialName.ScalarDeletingDestructor;
/*     */         } 
/* 626 */         throw error("unhandled extended special name");
/*     */     } 
/*     */ 
/*     */     
/* 630 */     throw error("Invalid special name");
/*     */   }
/*     */ 
/*     */   
/*     */   private List<Demangler.TypeRef> parseParams() throws Demangler.DemanglingException {
/* 635 */     List<Demangler.TypeRef> paramTypes = new ArrayList<Demangler.TypeRef>();
/* 636 */     if (!consumeCharIf(new char[] { 'X' })) {
/*     */       char c;
/* 638 */       while ((c = peekChar()) != '@' && c != '\000' && (c != 'Z' || peekChar(2) == 'Z')) {
/* 639 */         Demangler.TypeRef tr = parseType(false);
/* 640 */         if (tr == null) {
/*     */           continue;
/*     */         }
/* 643 */         paramTypes.add(tr);
/*     */       } 
/* 645 */       if (c == 'Z') {
/* 646 */         consumeChar();
/*     */       }
/*     */       
/* 649 */       if (c == '@') {
/* 650 */         consumeChar();
/*     */       }
/*     */     } 
/* 653 */     return paramTypes;
/*     */   }
/*     */   
/*     */   private List<Demangler.TemplateArg> parseTemplateParams() throws Demangler.DemanglingException {
/* 657 */     return withEmptyQualifiedNames(new DemanglingOp<List<Demangler.TemplateArg>>() {
/*     */           public List<Demangler.TemplateArg> run() throws Demangler.DemanglingException {
/* 659 */             List<Demangler.TemplateArg> paramTypes = new ArrayList<Demangler.TemplateArg>();
/* 660 */             if (!VC9Demangler.this.consumeCharIf(new char[] { 'X' })) {
/*     */               char c;
/* 662 */               while ((c = VC9Demangler.this.peekChar()) != '@' && c != '\000') {
/* 663 */                 Demangler.TemplateArg tr = VC9Demangler.this.parseTemplateParameter();
/* 664 */                 if (tr == null) {
/*     */                   continue;
/*     */                 }
/* 667 */                 paramTypes.add(tr);
/*     */               } 
/*     */             } 
/* 670 */             return paramTypes;
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   String parseNameFragment() throws Demangler.DemanglingException {
/* 676 */     StringBuilder b = new StringBuilder();
/*     */     
/*     */     char c;
/* 679 */     while ((c = consumeChar()) != '@') {
/* 680 */       b.append(c);
/*     */     }
/*     */     
/* 683 */     if (b.length() == 0) {
/* 684 */       throw new Demangler.DemanglingException(this, "Unexpected empty name fragment");
/*     */     }
/*     */     
/* 687 */     String name = b.toString();
/*     */     
/* 689 */     return name;
/*     */   }
/*     */   
/*     */   void addBackRef(Demangler.TypeRef tr) {
/* 693 */     if (tr == null || this.allQualifiedNames.contains(tr)) {
/*     */       return;
/*     */     }
/*     */     
/* 697 */     this.allQualifiedNames.add(tr);
/*     */   }
/*     */   
/*     */   Demangler.TypeRef getBackRef(int i) throws Demangler.DemanglingException {
/* 701 */     if (i == this.allQualifiedNames.size()) {
/* 702 */       i--;
/*     */     }
/* 704 */     if (i < 0 || i >= this.allQualifiedNames.size()) {
/* 705 */       throw error("Invalid back references in name qualifications", -1);
/*     */     }
/* 707 */     return this.allQualifiedNames.get(i);
/*     */   }
/*     */   
/*     */   private List<Object> parseNameQualifications() throws Demangler.DemanglingException {
/* 711 */     List<Object> names = new ArrayList();
/*     */     
/* 713 */     if (Character.isDigit(peekChar())) {
/*     */       try {
/* 715 */         int i = consumeChar() - 48;
/* 716 */         names.add(getBackRef(i));
/* 717 */         expectChars(new char[] { '@' });
/* 718 */         return names;
/* 719 */       } catch (Exception ex) {
/* 720 */         throw error("Invalid back references in name qualifications", -1);
/*     */       } 
/*     */     }
/*     */     
/* 724 */     while (peekChar() != '@') {
/* 725 */       names.add(parseNameQualification());
/*     */     }
/*     */     
/* 728 */     expectChars(new char[] { '@' });
/* 729 */     return names;
/*     */   }
/*     */   
/*     */   Object parseNameQualification() throws Demangler.DemanglingException {
/* 733 */     if (consumeCharIf(new char[] { '?' })) {
/* 734 */       if (consumeCharIf(new char[] { '$' })) {
/* 735 */         return parseTemplateType();
/*     */       }
/* 737 */       if (peekChar() == 'A') {
/* 738 */         throw error("Anonymous numbered namespaces not handled yet");
/*     */       }
/* 740 */       int namespaceNumber = parseNumber(false);
/* 741 */       return String.valueOf(namespaceNumber);
/*     */     } 
/*     */     
/* 744 */     return parseNameFragment();
/*     */   }
/*     */ 
/*     */   
/*     */   Convention.Style parseCallingConvention() throws Demangler.DemanglingException {
/*     */     Convention.Style cc;
/* 750 */     boolean exported = true;
/* 751 */     switch (consumeChar()) {
/*     */       case 'A':
/* 753 */         exported = false;
/*     */       case 'B':
/* 755 */         cc = Convention.Style.CDecl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 788 */         return cc;case 'C': exported = false;case 'D': cc = Convention.Style.Pascal; return cc;case 'E': exported = false;case 'F': cc = Convention.Style.ThisCall; return cc;case 'G': exported = false;case 'H': cc = Convention.Style.StdCall; return cc;case 'I': exported = false;case 'J': cc = Convention.Style.FastCall; return cc;case 'K': exported = false;case 'L': cc = null; return cc;case 'N': cc = Convention.Style.CLRCall; return cc;
/*     */     } 
/*     */     throw error("Unknown calling convention");
/*     */   }
/*     */   
/*     */   static class CVClassModifier {
/*     */     boolean isVariable;
/*     */     boolean isMember;
/*     */     boolean isBased; }
/*     */   
/*     */   CVClassModifier parseCVClassModifier() throws Demangler.DemanglingException {
/* 799 */     CVClassModifier mod = new CVClassModifier();
/* 800 */     switch (peekChar()) {
/*     */       case 'E':
/*     */       case 'F':
/*     */       case 'I':
/* 804 */         consumeChar();
/*     */         break;
/*     */     } 
/* 807 */     boolean based = false;
/* 808 */     switch (consumeChar()) {
/*     */       case 'M':
/*     */       case 'N':
/*     */       case 'O':
/*     */       case 'P':
/* 813 */         mod.isBased = true;
/*     */       case 'A':
/*     */       case 'B':
/*     */       case 'C':
/*     */       case 'D':
/*     */       case 'G':
/*     */       case 'H':
/*     */       case 'J':
/*     */       case 'K':
/*     */       case 'L':
/* 823 */         mod.isVariable = true;
/* 824 */         mod.isMember = false;
/*     */         break;
/*     */       case '2':
/*     */       case '3':
/*     */       case '4':
/*     */       case '5':
/* 830 */         mod.isBased = true;
/*     */       case '0':
/*     */       case '1':
/*     */       case 'Q':
/*     */       case 'R':
/*     */       case 'S':
/*     */       case 'T':
/*     */       case 'U':
/*     */       case 'V':
/*     */       case 'W':
/*     */       case 'X':
/*     */       case 'Y':
/*     */       case 'Z':
/* 843 */         mod.isVariable = true;
/* 844 */         mod.isMember = true;
/*     */         break;
/*     */       case '_':
/* 847 */         mod.isBased = true;
/* 848 */         switch (consumeChar()) {
/*     */           case 'A':
/*     */           case 'B':
/* 851 */             mod.isVariable = false;
/*     */             break;
/*     */           case 'C':
/*     */           case 'D':
/* 855 */             mod.isVariable = false;
/* 856 */             mod.isMember = true;
/*     */             break;
/*     */         } 
/* 859 */         throw error("Unknown extended __based class modifier", -1);
/*     */ 
/*     */       
/*     */       case '6':
/*     */       case '7':
/* 864 */         mod.isVariable = false;
/* 865 */         mod.isMember = false;
/*     */         break;
/*     */       case '8':
/*     */       case '9':
/* 869 */         mod.isVariable = false;
/* 870 */         mod.isMember = true;
/*     */         break;
/*     */       default:
/* 873 */         throw error("Unknown CV class modifier", -1);
/*     */     } 
/* 875 */     if (mod.isBased) {
/* 876 */       switch (consumeChar()) {
/*     */ 
/*     */         
/*     */         case '2':
/* 880 */           parseNameQualifications();
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     }
/* 886 */     return mod;
/*     */   }
/*     */   
/*     */   static interface DemanglingOp<T> {
/*     */     T run() throws Demangler.DemanglingException;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\demangling\VC9Demangler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */