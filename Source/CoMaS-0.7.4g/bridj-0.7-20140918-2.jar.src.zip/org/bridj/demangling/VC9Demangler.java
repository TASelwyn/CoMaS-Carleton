package org.bridj.demangling;

import java.lang.annotation.Annotation;
import java.lang.reflect.Modifier;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bridj.CLong;
import org.bridj.NativeLibrary;
import org.bridj.ann.Convention;

public class VC9Demangler extends Demangler {
  List<Demangler.TypeRef> allQualifiedNames;
  
  public VC9Demangler(NativeLibrary library, String str) {
    super(library, str);
    this.allQualifiedNames = new ArrayList<Demangler.TypeRef>();
  }
  
  private AccessLevelAndStorageClass parseAccessLevelAndStorageClass() throws Demangler.DemanglingException {
    AccessLevelAndStorageClass ac = new AccessLevelAndStorageClass();
    switch (consumeChar()) {
      case 'A':
      case 'B':
        ac.modifiers = 2;
        return ac;
      case 'C':
      case 'D':
        ac.modifiers = 10;
        return ac;
      case 'E':
      case 'F':
        ac.modifiers = 2;
        ac.isVirtual = true;
        return ac;
      case 'G':
      case 'H':
        ac.modifiers = 2;
        ac.isThunk = true;
        return ac;
      case 'I':
      case 'J':
        ac.modifiers = 4;
        return ac;
      case 'K':
      case 'L':
        ac.modifiers = 12;
        return ac;
      case 'M':
      case 'N':
        ac.modifiers = 4;
        ac.isVirtual = true;
        return ac;
      case 'O':
      case 'P':
        ac.modifiers = 4;
        ac.isThunk = true;
        return ac;
      case 'Q':
      case 'R':
        ac.modifiers = 1;
        return ac;
      case 'S':
      case 'T':
        ac.modifiers = 9;
        return ac;
      case 'U':
      case 'V':
        ac.modifiers = 1;
        ac.isVirtual = true;
        return ac;
      case 'W':
      case 'X':
        ac.modifiers = 1;
        ac.isThunk = true;
        return ac;
      case 'Y':
      case 'Z':
        ac.modifiers = 0;
        return ac;
    } 
    throw error("Unknown access level + storage class");
  }
  
  private Demangler.ClassRef parseTemplateType() throws Demangler.DemanglingException {
    String name = parseNameFragment();
    List<Demangler.TemplateArg> args = parseTemplateParams();
    List<Object> names = parseNameQualifications();
    Demangler.ClassRef tr = new Demangler.ClassRef(new Demangler.Ident(name, args.<Demangler.TemplateArg>toArray(new Demangler.TemplateArg[args.size()])));
    tr.setEnclosingType(reverseNamespace(names));
    addBackRef(tr);
    return tr;
  }
  
  private void parseFunctionProperty(Demangler.MemberRef mr) throws Demangler.DemanglingException {
    mr.callingConvention = parseCallingConvention();
    Demangler.TypeRef returnType = consumeCharIf(new char[] { '@' }) ? classType(void.class, (Class<? extends Annotation>[])new Class[0]) : parseType(true);
    List<Demangler.TypeRef> paramTypes = parseParams();
    mr.paramTypes = paramTypes.<Demangler.TypeRef>toArray(new Demangler.TypeRef[paramTypes.size()]);
    if (!consumeCharIf(new char[] { 'Z' })) {
      List<Demangler.TypeRef> throwTypes = parseParams();
      mr.throwTypes = throwTypes.<Demangler.TypeRef>toArray(new Demangler.TypeRef[throwTypes.size()]);
    } 
    mr.setValueType(returnType);
  }
  
  static class AnonymousTemplateArg implements Demangler.TemplateArg {
    String v;
    
    public AnonymousTemplateArg(String v) {
      this.v = v;
    }
    
    public boolean matchesParam(Object param, Demangler.Annotations annotations) {
      return true;
    }
    
    public String toString() {
      return this.v;
    }
  }
  
  private Demangler.TemplateArg parseTemplateParameter() throws Demangler.DemanglingException {
    int a;
    int b;
    switch (peekChar()) {
      case '?':
        consumeChar();
        return new AnonymousTemplateArg("'anonymous template param " + parseNumber(false) + "'");
      case '$':
        consumeChar();
        switch (consumeChar()) {
          case '0':
            return new Demangler.Constant(Integer.valueOf(parseNumber(true)));
          case '2':
            a = parseNumber(true);
            b = parseNumber(true);
            return new Demangler.Constant(Double.valueOf(a * Math.exp((10 * (int)Math.log(b - Math.log10(a) + 1.0D)))));
          case 'D':
            return new AnonymousTemplateArg("'anonymous template param " + parseNumber(false) + "'");
          case 'F':
            return new AnonymousTemplateArg("'tuple (" + parseNumber(true) + ", " + parseNumber(true) + ")'");
          case 'G':
            return new AnonymousTemplateArg("'tuple (" + parseNumber(true) + ", " + parseNumber(true) + ", " + parseNumber(true) + ")'");
          case 'Q':
            return new AnonymousTemplateArg("'anonymous non-type template param " + parseNumber(false) + "'");
        } 
        break;
    } 
    return parseType(true);
  }
  
  static class AccessLevelAndStorageClass {
    int modifiers;
    
    boolean isVirtual = false, isThunk = false;
  }
  
  public Demangler.MemberRef parseSymbol() throws Demangler.DemanglingException {
    Demangler.TypeRef encl;
    Demangler.MemberRef mr = new Demangler.MemberRef();
    int iAt = this.str.indexOf('@');
    if (iAt >= 0 && consumeCharIf(new char[] { '_' }) && iAt > 0) {
      mr.setMemberName(new Demangler.Ident(this.str.substring(1, iAt), new Demangler.TemplateArg[0]));
      mr.setArgumentsStackSize(Integer.valueOf(Integer.parseInt(this.str.substring(iAt + 1))));
      return mr;
    } 
    if (!consumeCharIf(new char[] { '@', '?' }))
      return null; 
    Demangler.IdentLike memberName = parseFirstQualifiedTypeNameComponent();
    if (memberName instanceof Demangler.SpecialName) {
      Demangler.SpecialName specialName = (Demangler.SpecialName)memberName;
      if (!specialName.isFunction())
        return null; 
    } 
    mr.setMemberName(memberName);
    List<Object> qNames = parseNameQualifications();
    AccessLevelAndStorageClass ac = parseAccessLevelAndStorageClass();
    CVClassModifier cvMod = null;
    if (ac.modifiers != 0 && !Modifier.isStatic(ac.modifiers))
      cvMod = parseCVClassModifier(); 
    if (cvMod != null && (cvMod.isMember || memberName instanceof Demangler.SpecialName || Modifier.isPublic(ac.modifiers))) {
      Object r = qNames.get(0);
      Demangler.ClassRef tr = (r instanceof Demangler.ClassRef) ? (Demangler.ClassRef)r : new Demangler.ClassRef(new Demangler.Ident((String)r, new Demangler.TemplateArg[0]));
      qNames.remove(0);
      tr.setEnclosingType(reverseNamespace(qNames));
      encl = tr;
    } else {
      encl = reverseNamespace(qNames);
    } 
    addBackRef(encl);
    mr.setEnclosingType(encl);
    parseFunctionProperty(mr);
    if (this.position != this.length)
      error("Failed to demangle the whole symbol"); 
    return mr;
  }
  
  Demangler.TypeRef parseReturnType() throws Demangler.DemanglingException {
    Demangler.TypeRef tr = parseType(true);
    return tr;
  }
  
  int parseNumber(boolean allowSign) throws Demangler.DemanglingException {
    int sign = (allowSign && consumeCharIf(new char[] { '?' })) ? -1 : 1;
    if (Character.isDigit(peekChar())) {
      char c1 = consumeChar();
      return sign * (c1 - 48);
    } 
    if (peekChar() == '@')
      return 0; 
    StringBuilder b = new StringBuilder();
    long n = 0L;
    char c;
    while ((c = consumeChar()) >= 'A' && c <= 'P' && c != '@')
      n += (16 * (c - 65)); 
    String s = b.toString().trim();
    if (c != '@' || s.length() == 0)
      throw error("Expected a number here", -b.length()); 
    return sign * Integer.parseInt(s, 16);
  }
  
  Demangler.TypeRef consumeIfBackRef() throws Demangler.DemanglingException {
    char c = peekChar();
    if (Character.isDigit(c)) {
      consumeChar();
      int iBack = c - 48;
      return getBackRef(iBack);
    } 
    return null;
  }
  
  Demangler.TypeRef parseType(boolean allowVoid) throws Demangler.DemanglingException {
    Demangler.TypeRef tr;
    CVClassModifier cvMods;
    Class<?> cl;
    Demangler.TypeRef qn, backRef = consumeIfBackRef();
    if (backRef != null)
      return backRef; 
    char c = consumeChar();
    switch (c) {
      case '_':
        switch (consumeChar()) {
          case 'D':
          case 'E':
            tr = classType(byte.class, (Class<? extends Annotation>[])new Class[0]);
            addBackRef(tr);
            return tr;
          case 'F':
          case 'G':
            tr = classType(short.class, (Class<? extends Annotation>[])new Class[0]);
            addBackRef(tr);
            return tr;
          case 'H':
          case 'I':
            tr = classType(int.class, (Class<? extends Annotation>[])new Class[0]);
            addBackRef(tr);
            return tr;
          case 'J':
          case 'K':
            tr = classType(long.class, (Class<? extends Annotation>[])new Class[0]);
            addBackRef(tr);
            return tr;
          case 'L':
            tr = classType(BigInteger.class, (Class<? extends Annotation>[])new Class[0]);
            addBackRef(tr);
            return tr;
          case 'N':
            tr = classType(boolean.class, (Class<? extends Annotation>[])new Class[0]);
            addBackRef(tr);
            return tr;
          case '0':
            parseCVClassModifier();
            parseType(false);
            tr = classType(Object[].class, (Class<? extends Annotation>[])new Class[0]);
            addBackRef(tr);
            return tr;
          case 'W':
            tr = classType(char.class, (Class<? extends Annotation>[])new Class[0]);
            addBackRef(tr);
            return tr;
        } 
        throw error(-1);
      case 'Z':
        return classType(Object[].class, (Class<? extends Annotation>[])new Class[0]);
      case 'O':
        throw error("'long double' type cannot be mapped !", -1);
      case 'C':
      case 'D':
      case 'E':
        return classType(byte.class, (Class<? extends Annotation>[])new Class[0]);
      case 'F':
      case 'G':
        return classType(short.class, (Class<? extends Annotation>[])new Class[0]);
      case 'H':
      case 'I':
        return classType(int.class, (Class<? extends Annotation>[])new Class[0]);
      case 'J':
      case 'K':
        return classType(CLong.class, (Class<? extends Annotation>[])new Class[0]);
      case 'M':
        return classType(float.class, (Class<? extends Annotation>[])new Class[0]);
      case 'N':
        return classType(double.class, (Class<? extends Annotation>[])new Class[0]);
      case 'Y':
        throw error("TODO handle cointerfaces", -1);
      case 'X':
        if (!allowVoid)
          return null; 
        return classType(void.class, (Class<? extends Annotation>[])new Class[0]);
      case '?':
        parseCVClassModifier();
        return parseType(allowVoid);
      case 'A':
      case 'B':
      case 'P':
      case 'Q':
      case 'R':
      case 'S':
        if (!consumeCharsIf(new char[] { '$', 'A' }))
          consumeCharsIf(new char[] { '$', 'B' }); 
        cvMods = parseCVClassModifier();
        if (cvMods.isVariable) {
          if (consumeCharIf(new char[] { 'Y' })) {
            int dimensions = parseNumber(false);
            int[] indices = new int[dimensions];
            for (int i = 0; i < dimensions; i++)
              indices[i] = parseNumber(false); 
          } 
          tr = pointerType(parseType(true));
        } else {
          Demangler.MemberRef mr = new Demangler.MemberRef();
          parseFunctionProperty(mr);
          tr = pointerType(new Demangler.FunctionTypeRef(mr));
        } 
        addBackRef(tr);
        return tr;
      case 'T':
      case 'U':
      case 'V':
        return parseQualifiedTypeName();
      case 'W':
        switch (consumeChar()) {
          case '0':
          case '1':
            cl = byte.class;
            qn = parseQualifiedTypeName();
            addBackRef(qn);
            return classType(cl, (Class<? extends Annotation>[])new Class[0]);
          case '2':
          case '3':
            cl = short.class;
            qn = parseQualifiedTypeName();
            addBackRef(qn);
            return classType(cl, (Class<? extends Annotation>[])new Class[0]);
          case '4':
          case '5':
            cl = int.class;
            qn = parseQualifiedTypeName();
            addBackRef(qn);
            return classType(cl, (Class<? extends Annotation>[])new Class[0]);
          case '6':
          case '7':
            cl = int.class;
            qn = parseQualifiedTypeName();
            addBackRef(qn);
            return classType(cl, (Class<? extends Annotation>[])new Class[0]);
        } 
        throw error("Unfinished enum", -1);
    } 
    throw error(-1);
  }
  
  static Demangler.NamespaceRef reverseNamespace(List<Object> names) {
    if (names == null || names.isEmpty())
      return null; 
    Collections.reverse(names);
    return new Demangler.NamespaceRef(names.toArray());
  }
  
  <T> T withEmptyQualifiedNames(DemanglingOp<T> action) throws Demangler.DemanglingException {
    List<Demangler.TypeRef> list = this.allQualifiedNames;
    try {
      this.allQualifiedNames = new ArrayList<Demangler.TypeRef>();
      return action.run();
    } finally {
      this.allQualifiedNames = list;
    } 
  }
  
  Demangler.IdentLike parseFirstQualifiedTypeNameComponent() throws Demangler.DemanglingException {
    if (consumeCharIf(new char[] { '?' })) {
      if (consumeCharIf(new char[] { '$' }))
        return parseTemplateType().getIdent(); 
      return parseSpecialName();
    } 
    return new Demangler.Ident(parseNameFragment(), new Demangler.TemplateArg[0]);
  }
  
  Demangler.TypeRef parseQualifiedTypeName() throws Demangler.DemanglingException {
    Demangler.TypeRef backRef = consumeIfBackRef();
    if (backRef != null)
      return backRef; 
    char c = peekChar();
    List<Object> names = parseNameQualifications();
    Object first = names.get(0);
    names.set(0, (first instanceof String) ? new Demangler.Ident((String)first, new Demangler.TemplateArg[0]) : ((Demangler.ClassRef)first).getIdent());
    if (names.size() == 1 && names.get(0) instanceof Demangler.TypeRef)
      return (Demangler.TypeRef)names.get(0); 
    Demangler.ClassRef tr = new Demangler.ClassRef((Demangler.Ident)names.get(0));
    names.remove(0);
    tr.setEnclosingType(reverseNamespace(names));
    return tr;
  }
  
  public Demangler.IdentLike parseSpecialName() throws Demangler.DemanglingException {
    switch (consumeChar()) {
      case '0':
        return Demangler.SpecialName.Constructor;
      case '1':
        return Demangler.SpecialName.Destructor;
      case '2':
        return Demangler.SpecialName.New;
      case '3':
        return Demangler.SpecialName.Delete;
      case '4':
        return Demangler.SpecialName.OperatorAssign;
      case '5':
        return Demangler.SpecialName.OperatorRShift;
      case '6':
        return Demangler.SpecialName.OperatorLShift;
      case '7':
        return Demangler.SpecialName.OperatorLogicNot;
      case '8':
        return Demangler.SpecialName.OperatorEquals;
      case '9':
        return Demangler.SpecialName.OperatorDifferent;
      case 'A':
        return Demangler.SpecialName.OperatorSquareBrackets;
      case 'B':
        return Demangler.SpecialName.OperatorCast;
      case 'C':
        return Demangler.SpecialName.OperatorArrow;
      case 'D':
        return Demangler.SpecialName.OperatorMultiply;
      case 'E':
        return Demangler.SpecialName.OperatorIncrement;
      case 'F':
        return Demangler.SpecialName.OperatorDecrement;
      case 'G':
        return Demangler.SpecialName.OperatorSubstract;
      case 'H':
        return Demangler.SpecialName.OperatorAdd;
      case 'I':
        return Demangler.SpecialName.OperatorBitAnd;
      case 'J':
        return Demangler.SpecialName.OperatorArrowStar;
      case 'K':
        return Demangler.SpecialName.OperatorDivide;
      case 'L':
        return Demangler.SpecialName.OperatorModulo;
      case 'M':
        return Demangler.SpecialName.OperatorLower;
      case 'N':
        return Demangler.SpecialName.OperatorLowerEquals;
      case 'O':
        return Demangler.SpecialName.OperatorGreater;
      case 'P':
        return Demangler.SpecialName.OperatorGreaterEquals;
      case 'Q':
        return Demangler.SpecialName.OperatorComma;
      case 'R':
        return Demangler.SpecialName.OperatorParenthesis;
      case 'S':
        return Demangler.SpecialName.OperatorBitNot;
      case 'T':
        return Demangler.SpecialName.OperatorXOR;
      case 'U':
        return Demangler.SpecialName.OperatorBitOr;
      case 'V':
        return Demangler.SpecialName.OperatorLogicAnd;
      case 'W':
        return Demangler.SpecialName.OperatorLogicOr;
      case 'X':
        return Demangler.SpecialName.OperatorMultiplyAssign;
      case 'Y':
        return Demangler.SpecialName.OperatorAddAssign;
      case 'Z':
        return Demangler.SpecialName.OperatorSubstractAssign;
      case '_':
        switch (consumeChar()) {
          case '0':
            return Demangler.SpecialName.OperatorDivideAssign;
          case '1':
            return Demangler.SpecialName.OperatorModuloAssign;
          case '2':
            return Demangler.SpecialName.OperatorLShiftAssign;
          case '3':
            return Demangler.SpecialName.OperatorRShiftAssign;
          case '4':
            return Demangler.SpecialName.OperatorBitAndAssign;
          case '5':
            return Demangler.SpecialName.OperatorBitOrAssign;
          case '6':
            return Demangler.SpecialName.OperatorXORAssign;
          case '7':
            return Demangler.SpecialName.VFTable;
          case '8':
            return Demangler.SpecialName.VBTable;
          case '9':
            return Demangler.SpecialName.VCall;
          case 'E':
            return Demangler.SpecialName.VectorDeletingDestructor;
          case 'G':
            return Demangler.SpecialName.ScalarDeletingDestructor;
        } 
        throw error("unhandled extended special name");
    } 
    throw error("Invalid special name");
  }
  
  private List<Demangler.TypeRef> parseParams() throws Demangler.DemanglingException {
    List<Demangler.TypeRef> paramTypes = new ArrayList<Demangler.TypeRef>();
    if (!consumeCharIf(new char[] { 'X' })) {
      char c;
      while ((c = peekChar()) != '@' && c != '\000' && (c != 'Z' || peekChar(2) == 'Z')) {
        Demangler.TypeRef tr = parseType(false);
        if (tr == null)
          continue; 
        paramTypes.add(tr);
      } 
      if (c == 'Z')
        consumeChar(); 
      if (c == '@')
        consumeChar(); 
    } 
    return paramTypes;
  }
  
  private List<Demangler.TemplateArg> parseTemplateParams() throws Demangler.DemanglingException {
    return withEmptyQualifiedNames(new DemanglingOp<List<Demangler.TemplateArg>>() {
          public List<Demangler.TemplateArg> run() throws Demangler.DemanglingException {
            List<Demangler.TemplateArg> paramTypes = new ArrayList<Demangler.TemplateArg>();
            if (!VC9Demangler.this.consumeCharIf(new char[] { 'X' })) {
              char c;
              while ((c = VC9Demangler.this.peekChar()) != '@' && c != '\000') {
                Demangler.TemplateArg tr = VC9Demangler.this.parseTemplateParameter();
                if (tr == null)
                  continue; 
                paramTypes.add(tr);
              } 
            } 
            return paramTypes;
          }
        });
  }
  
  String parseNameFragment() throws Demangler.DemanglingException {
    StringBuilder b = new StringBuilder();
    char c;
    while ((c = consumeChar()) != '@')
      b.append(c); 
    if (b.length() == 0)
      throw new Demangler.DemanglingException(this, "Unexpected empty name fragment"); 
    String name = b.toString();
    return name;
  }
  
  void addBackRef(Demangler.TypeRef tr) {
    if (tr == null || this.allQualifiedNames.contains(tr))
      return; 
    this.allQualifiedNames.add(tr);
  }
  
  Demangler.TypeRef getBackRef(int i) throws Demangler.DemanglingException {
    if (i == this.allQualifiedNames.size())
      i--; 
    if (i < 0 || i >= this.allQualifiedNames.size())
      throw error("Invalid back references in name qualifications", -1); 
    return this.allQualifiedNames.get(i);
  }
  
  private List<Object> parseNameQualifications() throws Demangler.DemanglingException {
    List<Object> names = new ArrayList();
    if (Character.isDigit(peekChar()))
      try {
        int i = consumeChar() - 48;
        names.add(getBackRef(i));
        expectChars(new char[] { '@' });
        return names;
      } catch (Exception ex) {
        throw error("Invalid back references in name qualifications", -1);
      }  
    while (peekChar() != '@')
      names.add(parseNameQualification()); 
    expectChars(new char[] { '@' });
    return names;
  }
  
  Object parseNameQualification() throws Demangler.DemanglingException {
    if (consumeCharIf(new char[] { '?' })) {
      if (consumeCharIf(new char[] { '$' }))
        return parseTemplateType(); 
      if (peekChar() == 'A')
        throw error("Anonymous numbered namespaces not handled yet"); 
      int namespaceNumber = parseNumber(false);
      return String.valueOf(namespaceNumber);
    } 
    return parseNameFragment();
  }
  
  Convention.Style parseCallingConvention() throws Demangler.DemanglingException {
    Convention.Style cc;
    boolean exported = true;
    switch (consumeChar()) {
      case 'A':
        exported = false;
      case 'B':
        cc = Convention.Style.CDecl;
        return cc;
      case 'C':
        exported = false;
      case 'D':
        cc = Convention.Style.Pascal;
        return cc;
      case 'E':
        exported = false;
      case 'F':
        cc = Convention.Style.ThisCall;
        return cc;
      case 'G':
        exported = false;
      case 'H':
        cc = Convention.Style.StdCall;
        return cc;
      case 'I':
        exported = false;
      case 'J':
        cc = Convention.Style.FastCall;
        return cc;
      case 'K':
        exported = false;
      case 'L':
        cc = null;
        return cc;
      case 'N':
        cc = Convention.Style.CLRCall;
        return cc;
    } 
    throw error("Unknown calling convention");
  }
  
  static class CVClassModifier {
    boolean isVariable;
    
    boolean isMember;
    
    boolean isBased;
  }
  
  CVClassModifier parseCVClassModifier() throws Demangler.DemanglingException {
    CVClassModifier mod = new CVClassModifier();
    switch (peekChar()) {
      case 'E':
      case 'F':
      case 'I':
        consumeChar();
        break;
    } 
    boolean based = false;
    switch (consumeChar()) {
      case 'M':
      case 'N':
      case 'O':
      case 'P':
        mod.isBased = true;
      case 'A':
      case 'B':
      case 'C':
      case 'D':
      case 'G':
      case 'H':
      case 'J':
      case 'K':
      case 'L':
        mod.isVariable = true;
        mod.isMember = false;
        break;
      case '2':
      case '3':
      case '4':
      case '5':
        mod.isBased = true;
      case '0':
      case '1':
      case 'Q':
      case 'R':
      case 'S':
      case 'T':
      case 'U':
      case 'V':
      case 'W':
      case 'X':
      case 'Y':
      case 'Z':
        mod.isVariable = true;
        mod.isMember = true;
        break;
      case '_':
        mod.isBased = true;
        switch (consumeChar()) {
          case 'A':
          case 'B':
            mod.isVariable = false;
            break;
          case 'C':
          case 'D':
            mod.isVariable = false;
            mod.isMember = true;
            break;
        } 
        throw error("Unknown extended __based class modifier", -1);
      case '6':
      case '7':
        mod.isVariable = false;
        mod.isMember = false;
        break;
      case '8':
      case '9':
        mod.isVariable = false;
        mod.isMember = true;
        break;
      default:
        throw error("Unknown CV class modifier", -1);
    } 
    if (mod.isBased)
      switch (consumeChar()) {
        case '2':
          parseNameQualifications();
          break;
      }  
    return mod;
  }
  
  static interface DemanglingOp<T> {
    T run() throws Demangler.DemanglingException;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\demangling\VC9Demangler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */