/*     */ package org.bridj.demangling;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.bridj.CLong;
/*     */ import org.bridj.NativeLibrary;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GCC4Demangler
/*     */   extends Demangler
/*     */ {
/*     */   private Map<String, List<Demangler.IdentLike>> prefixShortcuts;
/*     */   private Set<String> shouldContinueAfterPrefix;
/*     */   private Map<String, Demangler.TypeRef> typeShortcuts;
/*     */   int nextShortcutId;
/*     */   
/*     */   public GCC4Demangler(NativeLibrary library, String symbol) {
/*  56 */     super(library, symbol);
/*     */     
/*  58 */     this.prefixShortcuts = new HashMap<String, List<Demangler.IdentLike>>()
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private Demangler.ClassRef enclosed(String ns, Demangler.ClassRef classRef)
/*     */         {
/*  78 */           classRef.setEnclosingType(new Demangler.NamespaceRef(new Object[] { new Demangler.Ident(ns, new Demangler.TemplateArg[0]) }));
/*  79 */           return classRef;
/*     */         }
/*     */       };
/*  82 */     this.shouldContinueAfterPrefix = new HashSet<String>(Arrays.asList(new String[] { "t" }));
/*  83 */     this.typeShortcuts = new HashMap<String, Demangler.TypeRef>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  92 */     this.nextShortcutId = -1;
/*     */   }
/*     */   
/*  95 */   private String nextShortcutId() { int n = this.nextShortcutId++;
/*  96 */     return (n == -1) ? "_" : (Integer.toString(n, 36).toUpperCase() + "_"); }
/*     */   private <T> T ensureOfType(Object o, Class<T> type) throws Demangler.DemanglingException { if (type.isInstance(o))
/*     */       return type.cast(o); 
/*     */     throw new Demangler.DemanglingException(this, "Internal error in demangler: trying to cast to " + type.getCanonicalName() + " the object '" + o.toString() + "'"); } private Demangler.TypeRef parsePointerType(boolean memorizePointed) throws Demangler.DemanglingException {
/* 100 */     String subId = memorizePointed ? nextShortcutId() : null;
/* 101 */     Demangler.TypeRef pointed = parseType();
/* 102 */     if (memorizePointed)
/* 103 */       this.typeShortcuts.put(subId, pointed); 
/* 104 */     Demangler.TypeRef res = pointerType(pointed);
/* 105 */     String id = nextShortcutId();
/* 106 */     this.typeShortcuts.put(id, res);
/* 107 */     return res;
/*     */   }
/*     */   
/*     */   public Demangler.TemplateArg parseTemplateArg() throws Demangler.DemanglingException {
/* 111 */     if (consumeCharIf(new char[] { 'L' })) {
/* 112 */       Demangler.TypeRef tr = parseType();
/* 113 */       StringBuffer b = new StringBuffer();
/*     */       char c;
/* 115 */       while (Character.isDigit(c = peekChar())) {
/* 116 */         consumeChar();
/* 117 */         b.append(c);
/*     */       } 
/* 119 */       expectChars(new char[] { 'E' });
/*     */       
/* 121 */       return new Demangler.Constant(Integer.valueOf(Integer.parseInt(b.toString())));
/*     */     } 
/* 123 */     return parseType(); } public Demangler.TypeRef parseType() throws Demangler.DemanglingException { char cc; List<Demangler.IdentLike> ns; char nextChar; Demangler.MemberRef mr;
/*     */     int delta;
/*     */     String newShortcutId;
/*     */     List<Demangler.TypeRef> argTypes;
/*     */     Demangler.ClassRef res;
/* 128 */     if (Character.isDigit(peekChar())) {
/* 129 */       Demangler.Ident name = ensureOfType(parseNonCompoundIdent(), Demangler.Ident.class);
/* 130 */       String id = nextShortcutId();
/* 131 */       Demangler.TypeRef typeRef = simpleType(name);
/* 132 */       this.typeShortcuts.put(id, typeRef);
/* 133 */       return typeRef;
/*     */     } 
/*     */     
/* 136 */     char c = consumeChar();
/* 137 */     switch (c) {
/*     */       case 'S':
/* 139 */         cc = peekChar();
/* 140 */         delta = 0;
/* 141 */         if (Character.isDigit(cc) || Character.isUpperCase(cc) || cc == '_') {
/* 142 */           String id = "";
/* 143 */           while ((c = peekChar()) != '_' && c != '\000') {
/* 144 */             id = id + consumeChar();
/* 145 */             delta++;
/*     */           } 
/* 147 */           if (peekChar() == '\000') {
/* 148 */             throw new Demangler.DemanglingException(this, "Encountered a unexpected end in gcc mangler shortcut '" + id + "' " + this.prefixShortcuts.keySet());
/*     */           }
/* 150 */           id = id + consumeChar();
/* 151 */           delta++;
/* 152 */           if (this.typeShortcuts.containsKey(id)) {
/* 153 */             if (peekChar() != 'I')
/*     */             {
/* 155 */               return this.typeShortcuts.get(id);
/*     */             }
/*     */             
/* 158 */             List<Demangler.IdentLike> nsPath = new ArrayList<Demangler.IdentLike>(this.prefixShortcuts.get(id));
/* 159 */             String templatedId = parsePossibleTemplateArguments(nsPath);
/* 160 */             if (templatedId != null) {
/* 161 */               return this.typeShortcuts.get(templatedId);
/*     */             }
/*     */           } 
/*     */           
/* 165 */           this.position -= delta;
/*     */         } 
/*     */ 
/*     */       
/*     */       case 'N':
/* 170 */         this.position--;
/*     */         
/* 172 */         ns = new ArrayList<Demangler.IdentLike>();
/* 173 */         newShortcutId = parseSimpleOrComplexIdentInto(ns, false);
/* 174 */         res = new Demangler.ClassRef(ensureOfType(ns.remove(ns.size() - 1), Demangler.Ident.class));
/* 175 */         if (!ns.isEmpty()) {
/* 176 */           res.setEnclosingType(new Demangler.NamespaceRef(ns.toArray()));
/*     */         }
/* 178 */         if (newShortcutId != null) {
/* 179 */           this.typeShortcuts.put(newShortcutId, res);
/*     */         }
/* 181 */         return res;
/*     */       
/*     */       case 'P':
/* 184 */         nextChar = peekChar();
/* 185 */         return parsePointerType((nextChar == 'K' || nextChar == 'N'));
/*     */ 
/*     */       
/*     */       case 'F':
/* 189 */         mr = new Demangler.MemberRef();
/* 190 */         mr.setValueType(parseType());
/* 191 */         argTypes = new ArrayList<Demangler.TypeRef>();
/* 192 */         while (peekChar() != 'E') {
/* 193 */           argTypes.add(parseType());
/*     */         }
/* 195 */         mr.paramTypes = argTypes.<Demangler.TypeRef>toArray(new Demangler.TypeRef[argTypes.size()]);
/* 196 */         expectChars(new char[] { 'E' });
/* 197 */         return new Demangler.FunctionTypeRef(mr);
/*     */       
/*     */       case 'K':
/* 200 */         return parseType();
/*     */       case 'v':
/* 202 */         return classType(void.class, (Class<? extends Annotation>[])new Class[0]);
/*     */       case 'a':
/*     */       case 'c':
/*     */       case 'h':
/* 206 */         return classType(byte.class, (Class<? extends Annotation>[])new Class[0]);
/*     */       case 'b':
/* 208 */         return classType(boolean.class, (Class<? extends Annotation>[])new Class[0]);
/*     */       case 'l':
/*     */       case 'm':
/* 211 */         return classType(CLong.class, (Class<? extends Annotation>[])new Class[0]);
/*     */       
/*     */       case 'x':
/*     */       case 'y':
/* 215 */         return classType(long.class, (Class<? extends Annotation>[])new Class[0]);
/*     */       case 'i':
/*     */       case 'j':
/* 218 */         return classType(int.class, (Class<? extends Annotation>[])new Class[0]);
/*     */       case 's':
/*     */       case 't':
/* 221 */         return classType(short.class, (Class<? extends Annotation>[])new Class[0]);
/*     */       case 'f':
/* 223 */         return classType(float.class, (Class<? extends Annotation>[])new Class[0]);
/*     */       case 'd':
/* 225 */         return classType(double.class, (Class<? extends Annotation>[])new Class[0]);
/*     */       case 'z':
/* 227 */         return classType(Object[].class, (Class<? extends Annotation>[])new Class[0]);
/*     */     } 
/* 229 */     throw error("Unexpected type char '" + c + "'", -1); }
/*     */ 
/*     */ 
/*     */   
/*     */   String parseName() throws Demangler.DemanglingException {
/*     */     int len;
/* 235 */     StringBuilder b = new StringBuilder(); char c;
/* 236 */     while (Character.isDigit(c = peekChar())) {
/* 237 */       consumeChar();
/* 238 */       b.append(c);
/*     */     } 
/*     */     
/*     */     try {
/* 242 */       len = Integer.parseInt(b.toString());
/* 243 */     } catch (NumberFormatException ex) {
/* 244 */       throw error("Expected a number", 0);
/*     */     } 
/* 246 */     b.setLength(0);
/* 247 */     for (int i = 0; i < len; i++) {
/* 248 */       b.append(consumeChar());
/*     */     }
/* 250 */     return b.toString();
/*     */   }
/*     */   
/*     */   private String parseSimpleOrComplexIdentInto(List<Demangler.IdentLike> res, boolean isParsingNonShortcutableElement) throws Demangler.DemanglingException {
/* 254 */     String newlyAddedShortcutForThisType = null;
/* 255 */     boolean shouldContinue = false;
/* 256 */     boolean expectEInTheEnd = false;
/* 257 */     if (consumeCharIf(new char[] { 'N' })) {
/* 258 */       if (consumeCharIf(new char[] { 'S' })) {
/* 259 */         parseShortcutInto(res);
/*     */       }
/* 261 */       shouldContinue = true;
/* 262 */       expectEInTheEnd = true;
/*     */     }
/* 264 */     else if (consumeCharIf(new char[] { 'S' })) {
/* 265 */       shouldContinue = parseShortcutInto(res);
/*     */     } else {
/* 267 */       res.add(parseNonCompoundIdent());
/*     */     } 
/*     */     
/* 270 */     if (shouldContinue) {
/* 271 */       int initialNextShortcutId = this.nextShortcutId;
/*     */       while (true) {
/* 273 */         String id = nextShortcutId();
/* 274 */         newlyAddedShortcutForThisType = id;
/* 275 */         Demangler.IdentLike part = parseNonCompoundIdent();
/* 276 */         res.add(part);
/* 277 */         this.prefixShortcuts.put(id, new ArrayList<Demangler.IdentLike>(res));
/* 278 */         parsePossibleTemplateArguments(res);
/* 279 */         if (!Character.isDigit(peekChar()) && peekChar() != 'C' && peekChar() != 'D') {
/* 280 */           if (isParsingNonShortcutableElement)
/*     */           {
/* 282 */             this.nextShortcutId = initialNextShortcutId; }  break;
/*     */         } 
/*     */       } 
/* 285 */     }  parsePossibleTemplateArguments(res);
/* 286 */     if (expectEInTheEnd) {
/* 287 */       expectAnyChar(new char[] { 'E' });
/*     */     }
/* 289 */     return newlyAddedShortcutForThisType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String parsePossibleTemplateArguments(List<Demangler.IdentLike> res) throws Demangler.DemanglingException {
/* 301 */     if (consumeCharIf(new char[] { 'I' })) {
/* 302 */       List<Demangler.TemplateArg> args = new ArrayList<Demangler.TemplateArg>();
/* 303 */       while (!consumeCharIf(new char[] { 'E' })) {
/* 304 */         args.add(parseTemplateArg());
/*     */       }
/* 306 */       String id = nextShortcutId();
/*     */       
/* 308 */       Demangler.Ident templatedIdent = new Demangler.Ident(((Demangler.Ident)ensureOfType(res.remove(res.size() - 1), Demangler.Ident.class)).toString(), args.<Demangler.TemplateArg>toArray(new Demangler.TemplateArg[args.size()]));
/* 309 */       res.add(templatedIdent);
/* 310 */       this.prefixShortcuts.put(id, new ArrayList<Demangler.IdentLike>(res));
/*     */       
/* 312 */       List<Demangler.IdentLike> ns = new ArrayList<Demangler.IdentLike>(res);
/* 313 */       Demangler.ClassRef clss = new Demangler.ClassRef(ensureOfType(ns.remove(ns.size() - 1), Demangler.Ident.class));
/* 314 */       if (!ns.isEmpty()) {
/* 315 */         clss.setEnclosingType(new Demangler.NamespaceRef(ns.toArray()));
/*     */       }
/* 317 */       this.typeShortcuts.put(id, clss);
/*     */       
/* 319 */       return id;
/*     */     } 
/* 321 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean parseShortcutInto(List<Demangler.IdentLike> res) throws Demangler.DemanglingException {
/* 330 */     char c = peekChar();
/*     */     
/* 332 */     if (c == '_') {
/* 333 */       List<Demangler.IdentLike> toAdd = this.prefixShortcuts.get(Character.toString(consumeChar()));
/* 334 */       if (toAdd == null) {
/* 335 */         throw new Demangler.DemanglingException(this, "Encountered a yet undefined gcc mangler shortcut S_ (first one), i.e. '_' " + this.prefixShortcuts.keySet());
/*     */       }
/* 337 */       res.addAll(toAdd);
/* 338 */       return false;
/* 339 */     }  if (Character.isDigit(c) || Character.isUpperCase(c)) {
/* 340 */       String id = "";
/* 341 */       while ((c = peekChar()) != '_' && c != '\000') {
/* 342 */         id = id + consumeChar();
/*     */       }
/* 344 */       if (peekChar() == '\000') {
/* 345 */         throw new Demangler.DemanglingException(this, "Encountered a unexpected end in gcc mangler shortcut '" + id + "' " + this.prefixShortcuts.keySet());
/*     */       }
/* 347 */       id = id + consumeChar();
/* 348 */       List<Demangler.IdentLike> toAdd = this.prefixShortcuts.get(id);
/* 349 */       if (toAdd == null) {
/* 350 */         throw new Demangler.DemanglingException(this, "Encountered a unexpected gcc mangler shortcut '" + id + "' " + this.prefixShortcuts.keySet());
/*     */       }
/* 352 */       res.addAll(toAdd);
/* 353 */       return false;
/* 354 */     }  if (Character.isLowerCase(c)) {
/* 355 */       String id = Character.toString(consumeChar());
/* 356 */       List<Demangler.IdentLike> toAdd = this.prefixShortcuts.get(id);
/* 357 */       if (toAdd == null) {
/* 358 */         throw new Demangler.DemanglingException(this, "Encountered a unexpected gcc mangler built-in shortcut '" + id + "' " + this.prefixShortcuts.keySet());
/*     */       }
/* 360 */       res.addAll(toAdd);
/* 361 */       return this.shouldContinueAfterPrefix.contains(id);
/*     */     } 
/* 363 */     throw new Demangler.DemanglingException(this, "Encountered a unexpected gcc unknown shortcut '" + c + "' " + this.prefixShortcuts.keySet());
/*     */   }
/*     */ 
/*     */   
/*     */   Demangler.IdentLike parseNonCompoundIdent() throws Demangler.DemanglingException {
/* 368 */     if (consumeCharIf(new char[] { 'C' })) {
/* 369 */       if (consumeCharIf(new char[] { '1' }))
/* 370 */         return Demangler.SpecialName.Constructor; 
/* 371 */       if (consumeCharIf(new char[] { '2' })) {
/* 372 */         return Demangler.SpecialName.SpecialConstructor;
/*     */       }
/* 374 */       throw error("Unknown constructor type 'C" + peekChar() + "'");
/*     */     } 
/* 376 */     if (consumeCharIf(new char[] { 'D' })) {
/*     */       
/* 378 */       if (consumeCharIf(new char[] { '0' }))
/* 379 */         return Demangler.SpecialName.DeletingDestructor; 
/* 380 */       if (consumeCharIf(new char[] { '1' }))
/* 381 */         return Demangler.SpecialName.Destructor; 
/* 382 */       if (consumeCharIf(new char[] { '2' })) {
/* 383 */         return Demangler.SpecialName.SelfishDestructor;
/*     */       }
/* 385 */       throw error("Unknown destructor type 'D" + peekChar() + "'");
/*     */     } 
/*     */     
/* 388 */     String n = parseName();
/* 389 */     return new Demangler.Ident(n, new Demangler.TemplateArg[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Demangler.MemberRef parseSymbol() throws Demangler.DemanglingException {
/* 395 */     Demangler.MemberRef mr = new Demangler.MemberRef();
/* 396 */     if (!consumeCharIf(new char[] { '_' })) {
/* 397 */       mr.setMemberName(new Demangler.Ident(this.str, new Demangler.TemplateArg[0]));
/* 398 */       return mr;
/*     */     } 
/* 400 */     consumeCharIf(new char[] { '_' });
/* 401 */     if (!consumeCharIf(new char[] { 'Z' })) {
/* 402 */       return null;
/*     */     }
/* 404 */     if (consumeCharIf(new char[] { 'T' })) {
/* 405 */       if (consumeCharIf(new char[] { 'V' })) {
/* 406 */         mr.setEnclosingType(ensureOfType(parseType(), (Class)Demangler.ClassRef.class));
/* 407 */         mr.setMemberName(Demangler.SpecialName.VFTable);
/* 408 */         return mr;
/*     */       } 
/* 410 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 419 */     if (consumeCharsIf(new char[] { 'd', 'l', 'P', 'v' })) {
/* 420 */       mr.setMemberName(Demangler.SpecialName.Delete);
/* 421 */       return mr;
/*     */     } 
/* 423 */     if (consumeCharsIf(new char[] { 'd', 'a', 'P', 'v' })) {
/* 424 */       mr.setMemberName(Demangler.SpecialName.DeleteArray);
/* 425 */       return mr;
/*     */     } 
/* 427 */     if (consumeCharsIf(new char[] { 'n', 'w', 'm' })) {
/* 428 */       mr.setMemberName(Demangler.SpecialName.New);
/* 429 */       return mr;
/*     */     } 
/* 431 */     if (consumeCharsIf(new char[] { 'n', 'a', 'm' })) {
/* 432 */       mr.setMemberName(Demangler.SpecialName.NewArray);
/* 433 */       return mr;
/*     */     } 
/*     */ 
/*     */     
/* 437 */     List<Demangler.IdentLike> ns = new ArrayList<Demangler.IdentLike>();
/* 438 */     parseSimpleOrComplexIdentInto(ns, true);
/* 439 */     mr.setMemberName(ns.remove(ns.size() - 1));
/* 440 */     if (!ns.isEmpty()) {
/* 441 */       Demangler.ClassRef parent = new Demangler.ClassRef(ensureOfType(ns.remove(ns.size() - 1), Demangler.Ident.class));
/* 442 */       if (mr.getMemberName() == Demangler.SpecialName.Constructor || mr.getMemberName() == Demangler.SpecialName.SpecialConstructor) {
/* 443 */         this.typeShortcuts.put(nextShortcutId(), parent);
/*     */       }
/* 445 */       if (!ns.isEmpty()) {
/* 446 */         parent.setEnclosingType(new Demangler.NamespaceRef(ns.toArray()));
/*     */       }
/* 448 */       mr.setEnclosingType(parent);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 457 */     if (consumeCharIf(new char[] { 'v' })) {
/* 458 */       if (this.position < this.length) {
/* 459 */         error("Expected end of symbol", 0);
/*     */       }
/* 461 */       mr.paramTypes = new Demangler.TypeRef[0];
/*     */     } else {
/* 463 */       List<Demangler.TypeRef> paramTypes = new ArrayList<Demangler.TypeRef>();
/* 464 */       while (this.position < this.length) {
/* 465 */         paramTypes.add(parseType());
/*     */       }
/* 467 */       mr.paramTypes = paramTypes.<Demangler.TypeRef>toArray(new Demangler.TypeRef[paramTypes.size()]);
/*     */     } 
/* 469 */     return mr;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\demangling\GCC4Demangler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */