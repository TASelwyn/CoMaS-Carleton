package org.bridj.demangling;

import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.bridj.CLong;
import org.bridj.NativeLibrary;

public class GCC4Demangler extends Demangler {
  private Map<String, List<Demangler.IdentLike>> prefixShortcuts;
  
  private Set<String> shouldContinueAfterPrefix;
  
  private Map<String, Demangler.TypeRef> typeShortcuts;
  
  int nextShortcutId;
  
  public GCC4Demangler(NativeLibrary library, String symbol) {
    super(library, symbol);
    this.prefixShortcuts = new HashMap<String, List<Demangler.IdentLike>>() {
        private Demangler.ClassRef enclosed(String ns, Demangler.ClassRef classRef) {
          classRef.setEnclosingType(new Demangler.NamespaceRef(new Object[] { new Demangler.Ident(ns, new Demangler.TemplateArg[0]) }));
          return classRef;
        }
      };
    this.shouldContinueAfterPrefix = new HashSet<String>(Arrays.asList(new String[] { "t" }));
    this.typeShortcuts = new HashMap<String, Demangler.TypeRef>();
    this.nextShortcutId = -1;
  }
  
  private <T> T ensureOfType(Object o, Class<T> type) throws Demangler.DemanglingException {
    if (type.isInstance(o))
      return type.cast(o); 
    throw new Demangler.DemanglingException(this, "Internal error in demangler: trying to cast to " + type.getCanonicalName() + " the object '" + o.toString() + "'");
  }
  
  private String nextShortcutId() {
    int n = this.nextShortcutId++;
    return (n == -1) ? "_" : (Integer.toString(n, 36).toUpperCase() + "_");
  }
  
  private Demangler.TypeRef parsePointerType(boolean memorizePointed) throws Demangler.DemanglingException {
    String subId = memorizePointed ? nextShortcutId() : null;
    Demangler.TypeRef pointed = parseType();
    if (memorizePointed)
      this.typeShortcuts.put(subId, pointed); 
    Demangler.TypeRef res = pointerType(pointed);
    String id = nextShortcutId();
    this.typeShortcuts.put(id, res);
    return res;
  }
  
  public Demangler.TemplateArg parseTemplateArg() throws Demangler.DemanglingException {
    if (consumeCharIf(new char[] { 'L' })) {
      Demangler.TypeRef tr = parseType();
      StringBuffer b = new StringBuffer();
      char c;
      while (Character.isDigit(c = peekChar())) {
        consumeChar();
        b.append(c);
      } 
      expectChars(new char[] { 'E' });
      return new Demangler.Constant(Integer.valueOf(Integer.parseInt(b.toString())));
    } 
    return parseType();
  }
  
  public Demangler.TypeRef parseType() throws Demangler.DemanglingException {
    char cc;
    List<Demangler.IdentLike> ns;
    char nextChar;
    Demangler.MemberRef mr;
    int delta;
    String newShortcutId;
    List<Demangler.TypeRef> argTypes;
    Demangler.ClassRef res;
    if (Character.isDigit(peekChar())) {
      Demangler.Ident name = ensureOfType(parseNonCompoundIdent(), Demangler.Ident.class);
      String id = nextShortcutId();
      Demangler.TypeRef typeRef = simpleType(name);
      this.typeShortcuts.put(id, typeRef);
      return typeRef;
    } 
    char c = consumeChar();
    switch (c) {
      case 'S':
        cc = peekChar();
        delta = 0;
        if (Character.isDigit(cc) || Character.isUpperCase(cc) || cc == '_') {
          String id = "";
          while ((c = peekChar()) != '_' && c != '\000') {
            id = id + consumeChar();
            delta++;
          } 
          if (peekChar() == '\000')
            throw new Demangler.DemanglingException(this, "Encountered a unexpected end in gcc mangler shortcut '" + id + "' " + this.prefixShortcuts.keySet()); 
          id = id + consumeChar();
          delta++;
          if (this.typeShortcuts.containsKey(id)) {
            if (peekChar() != 'I')
              return this.typeShortcuts.get(id); 
            List<Demangler.IdentLike> nsPath = new ArrayList<Demangler.IdentLike>(this.prefixShortcuts.get(id));
            String templatedId = parsePossibleTemplateArguments(nsPath);
            if (templatedId != null)
              return this.typeShortcuts.get(templatedId); 
          } 
          this.position -= delta;
        } 
      case 'N':
        this.position--;
        ns = new ArrayList<Demangler.IdentLike>();
        newShortcutId = parseSimpleOrComplexIdentInto(ns, false);
        res = new Demangler.ClassRef(ensureOfType(ns.remove(ns.size() - 1), Demangler.Ident.class));
        if (!ns.isEmpty())
          res.setEnclosingType(new Demangler.NamespaceRef(ns.toArray())); 
        if (newShortcutId != null)
          this.typeShortcuts.put(newShortcutId, res); 
        return res;
      case 'P':
        nextChar = peekChar();
        return parsePointerType((nextChar == 'K' || nextChar == 'N'));
      case 'F':
        mr = new Demangler.MemberRef();
        mr.setValueType(parseType());
        argTypes = new ArrayList<Demangler.TypeRef>();
        while (peekChar() != 'E')
          argTypes.add(parseType()); 
        mr.paramTypes = argTypes.<Demangler.TypeRef>toArray(new Demangler.TypeRef[argTypes.size()]);
        expectChars(new char[] { 'E' });
        return new Demangler.FunctionTypeRef(mr);
      case 'K':
        return parseType();
      case 'v':
        return classType(void.class, (Class<? extends Annotation>[])new Class[0]);
      case 'a':
      case 'c':
      case 'h':
        return classType(byte.class, (Class<? extends Annotation>[])new Class[0]);
      case 'b':
        return classType(boolean.class, (Class<? extends Annotation>[])new Class[0]);
      case 'l':
      case 'm':
        return classType(CLong.class, (Class<? extends Annotation>[])new Class[0]);
      case 'x':
      case 'y':
        return classType(long.class, (Class<? extends Annotation>[])new Class[0]);
      case 'i':
      case 'j':
        return classType(int.class, (Class<? extends Annotation>[])new Class[0]);
      case 's':
      case 't':
        return classType(short.class, (Class<? extends Annotation>[])new Class[0]);
      case 'f':
        return classType(float.class, (Class<? extends Annotation>[])new Class[0]);
      case 'd':
        return classType(double.class, (Class<? extends Annotation>[])new Class[0]);
      case 'z':
        return classType(Object[].class, (Class<? extends Annotation>[])new Class[0]);
    } 
    throw error("Unexpected type char '" + c + "'", -1);
  }
  
  String parseName() throws Demangler.DemanglingException {
    int len;
    StringBuilder b = new StringBuilder();
    char c;
    while (Character.isDigit(c = peekChar())) {
      consumeChar();
      b.append(c);
    } 
    try {
      len = Integer.parseInt(b.toString());
    } catch (NumberFormatException ex) {
      throw error("Expected a number", 0);
    } 
    b.setLength(0);
    for (int i = 0; i < len; i++)
      b.append(consumeChar()); 
    return b.toString();
  }
  
  private String parseSimpleOrComplexIdentInto(List<Demangler.IdentLike> res, boolean isParsingNonShortcutableElement) throws Demangler.DemanglingException {
    String newlyAddedShortcutForThisType = null;
    boolean shouldContinue = false;
    boolean expectEInTheEnd = false;
    if (consumeCharIf(new char[] { 'N' })) {
      if (consumeCharIf(new char[] { 'S' }))
        parseShortcutInto(res); 
      shouldContinue = true;
      expectEInTheEnd = true;
    } else if (consumeCharIf(new char[] { 'S' })) {
      shouldContinue = parseShortcutInto(res);
    } else {
      res.add(parseNonCompoundIdent());
    } 
    if (shouldContinue) {
      int initialNextShortcutId = this.nextShortcutId;
      while (true) {
        String id = nextShortcutId();
        newlyAddedShortcutForThisType = id;
        Demangler.IdentLike part = parseNonCompoundIdent();
        res.add(part);
        this.prefixShortcuts.put(id, new ArrayList<Demangler.IdentLike>(res));
        parsePossibleTemplateArguments(res);
        if (!Character.isDigit(peekChar()) && peekChar() != 'C' && peekChar() != 'D') {
          if (isParsingNonShortcutableElement)
            this.nextShortcutId = initialNextShortcutId; 
          break;
        } 
      } 
    } 
    parsePossibleTemplateArguments(res);
    if (expectEInTheEnd)
      expectAnyChar(new char[] { 'E' }); 
    return newlyAddedShortcutForThisType;
  }
  
  private String parsePossibleTemplateArguments(List<Demangler.IdentLike> res) throws Demangler.DemanglingException {
    if (consumeCharIf(new char[] { 'I' })) {
      List<Demangler.TemplateArg> args = new ArrayList<Demangler.TemplateArg>();
      while (!consumeCharIf(new char[] { 'E' }))
        args.add(parseTemplateArg()); 
      String id = nextShortcutId();
      Demangler.Ident templatedIdent = new Demangler.Ident(((Demangler.Ident)ensureOfType(res.remove(res.size() - 1), Demangler.Ident.class)).toString(), args.<Demangler.TemplateArg>toArray(new Demangler.TemplateArg[args.size()]));
      res.add(templatedIdent);
      this.prefixShortcuts.put(id, new ArrayList<Demangler.IdentLike>(res));
      List<Demangler.IdentLike> ns = new ArrayList<Demangler.IdentLike>(res);
      Demangler.ClassRef clss = new Demangler.ClassRef(ensureOfType(ns.remove(ns.size() - 1), Demangler.Ident.class));
      if (!ns.isEmpty())
        clss.setEnclosingType(new Demangler.NamespaceRef(ns.toArray())); 
      this.typeShortcuts.put(id, clss);
      return id;
    } 
    return null;
  }
  
  private boolean parseShortcutInto(List<Demangler.IdentLike> res) throws Demangler.DemanglingException {
    char c = peekChar();
    if (c == '_') {
      List<Demangler.IdentLike> toAdd = this.prefixShortcuts.get(Character.toString(consumeChar()));
      if (toAdd == null)
        throw new Demangler.DemanglingException(this, "Encountered a yet undefined gcc mangler shortcut S_ (first one), i.e. '_' " + this.prefixShortcuts.keySet()); 
      res.addAll(toAdd);
      return false;
    } 
    if (Character.isDigit(c) || Character.isUpperCase(c)) {
      String id = "";
      while ((c = peekChar()) != '_' && c != '\000')
        id = id + consumeChar(); 
      if (peekChar() == '\000')
        throw new Demangler.DemanglingException(this, "Encountered a unexpected end in gcc mangler shortcut '" + id + "' " + this.prefixShortcuts.keySet()); 
      id = id + consumeChar();
      List<Demangler.IdentLike> toAdd = this.prefixShortcuts.get(id);
      if (toAdd == null)
        throw new Demangler.DemanglingException(this, "Encountered a unexpected gcc mangler shortcut '" + id + "' " + this.prefixShortcuts.keySet()); 
      res.addAll(toAdd);
      return false;
    } 
    if (Character.isLowerCase(c)) {
      String id = Character.toString(consumeChar());
      List<Demangler.IdentLike> toAdd = this.prefixShortcuts.get(id);
      if (toAdd == null)
        throw new Demangler.DemanglingException(this, "Encountered a unexpected gcc mangler built-in shortcut '" + id + "' " + this.prefixShortcuts.keySet()); 
      res.addAll(toAdd);
      return this.shouldContinueAfterPrefix.contains(id);
    } 
    throw new Demangler.DemanglingException(this, "Encountered a unexpected gcc unknown shortcut '" + c + "' " + this.prefixShortcuts.keySet());
  }
  
  Demangler.IdentLike parseNonCompoundIdent() throws Demangler.DemanglingException {
    if (consumeCharIf(new char[] { 'C' })) {
      if (consumeCharIf(new char[] { '1' }))
        return Demangler.SpecialName.Constructor; 
      if (consumeCharIf(new char[] { '2' }))
        return Demangler.SpecialName.SpecialConstructor; 
      throw error("Unknown constructor type 'C" + peekChar() + "'");
    } 
    if (consumeCharIf(new char[] { 'D' })) {
      if (consumeCharIf(new char[] { '0' }))
        return Demangler.SpecialName.DeletingDestructor; 
      if (consumeCharIf(new char[] { '1' }))
        return Demangler.SpecialName.Destructor; 
      if (consumeCharIf(new char[] { '2' }))
        return Demangler.SpecialName.SelfishDestructor; 
      throw error("Unknown destructor type 'D" + peekChar() + "'");
    } 
    String n = parseName();
    return new Demangler.Ident(n, new Demangler.TemplateArg[0]);
  }
  
  public Demangler.MemberRef parseSymbol() throws Demangler.DemanglingException {
    Demangler.MemberRef mr = new Demangler.MemberRef();
    if (!consumeCharIf(new char[] { '_' })) {
      mr.setMemberName(new Demangler.Ident(this.str, new Demangler.TemplateArg[0]));
      return mr;
    } 
    consumeCharIf(new char[] { '_' });
    if (!consumeCharIf(new char[] { 'Z' }))
      return null; 
    if (consumeCharIf(new char[] { 'T' })) {
      if (consumeCharIf(new char[] { 'V' })) {
        mr.setEnclosingType(ensureOfType(parseType(), (Class)Demangler.ClassRef.class));
        mr.setMemberName(Demangler.SpecialName.VFTable);
        return mr;
      } 
      return null;
    } 
    if (consumeCharsIf(new char[] { 'd', 'l', 'P', 'v' })) {
      mr.setMemberName(Demangler.SpecialName.Delete);
      return mr;
    } 
    if (consumeCharsIf(new char[] { 'd', 'a', 'P', 'v' })) {
      mr.setMemberName(Demangler.SpecialName.DeleteArray);
      return mr;
    } 
    if (consumeCharsIf(new char[] { 'n', 'w', 'm' })) {
      mr.setMemberName(Demangler.SpecialName.New);
      return mr;
    } 
    if (consumeCharsIf(new char[] { 'n', 'a', 'm' })) {
      mr.setMemberName(Demangler.SpecialName.NewArray);
      return mr;
    } 
    List<Demangler.IdentLike> ns = new ArrayList<Demangler.IdentLike>();
    parseSimpleOrComplexIdentInto(ns, true);
    mr.setMemberName(ns.remove(ns.size() - 1));
    if (!ns.isEmpty()) {
      Demangler.ClassRef parent = new Demangler.ClassRef(ensureOfType(ns.remove(ns.size() - 1), Demangler.Ident.class));
      if (mr.getMemberName() == Demangler.SpecialName.Constructor || mr.getMemberName() == Demangler.SpecialName.SpecialConstructor)
        this.typeShortcuts.put(nextShortcutId(), parent); 
      if (!ns.isEmpty())
        parent.setEnclosingType(new Demangler.NamespaceRef(ns.toArray())); 
      mr.setEnclosingType(parent);
    } 
    if (consumeCharIf(new char[] { 'v' })) {
      if (this.position < this.length)
        error("Expected end of symbol", 0); 
      mr.paramTypes = new Demangler.TypeRef[0];
    } else {
      List<Demangler.TypeRef> paramTypes = new ArrayList<Demangler.TypeRef>();
      while (this.position < this.length)
        paramTypes.add(parseType()); 
      mr.paramTypes = paramTypes.<Demangler.TypeRef>toArray(new Demangler.TypeRef[paramTypes.size()]);
    } 
    return mr;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\demangling\GCC4Demangler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */