/*    */ package org.bridj;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CLong
/*    */   extends AbstractIntegral
/*    */ {
/* 46 */   public static final int SIZE = Platform.CLONG_SIZE;
/*    */   private static final long serialVersionUID = 1542942327767932396L;
/*    */   
/*    */   public CLong(long value) {
/* 50 */     super(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public int byteSize() {
/* 55 */     return SIZE;
/*    */   }
/*    */   
/*    */   public static CLong valueOf(long value) {
/* 59 */     return new CLong(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\CLong.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */