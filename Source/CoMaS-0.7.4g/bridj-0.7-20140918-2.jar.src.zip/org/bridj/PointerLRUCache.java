/*    */ package org.bridj;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class PointerLRUCache
/*    */ {
/*    */   private final Pointer<?>[] values;
/*    */   private int index;
/*    */   private final int tolerance;
/*    */   
/*    */   PointerLRUCache(int length, int tolerance) {
/* 43 */     assert tolerance >= 0;
/* 44 */     this.tolerance = tolerance;
/* 45 */     this.values = (Pointer<?>[])new Pointer[length];
/*    */   }
/*    */   
/*    */   protected abstract <T> Pointer<T> pointerToAddress(long paramLong, PointerIO<T> paramPointerIO);
/*    */   
/*    */   Pointer<?> get(long peer, PointerIO<?> pointerIO) {
/* 51 */     int idx = this.index;
/* 52 */     for (int i = 0, length = this.values.length; i < length; i++) {
/* 53 */       Pointer<?> pointer = this.values[idx];
/* 54 */       if (pointer == null) {
/*    */         
/* 56 */         this.values[idx] = pointer = pointerToAddress(peer, pointerIO);
/* 57 */         return pointer;
/* 58 */       }  if (pointer.getPeer() == peer && pointer.getIO() == pointerIO) {
/*    */         
/* 60 */         if (i > this.tolerance) {
/* 61 */           int idx2 = decrementedIndex();
/* 62 */           if (idx != idx2) {
/* 63 */             Pointer<?> temp = this.values[idx];
/* 64 */             this.values[idx] = this.values[idx2];
/* 65 */             this.values[idx2] = temp;
/*    */           } 
/*    */         } 
/* 68 */         return pointer;
/*    */       } 
/* 70 */       idx++;
/* 71 */       if (idx == length) {
/* 72 */         idx = 0;
/*    */       }
/*    */     } 
/*    */     
/* 76 */     Pointer<?> ptr = pointerToAddress(peer, pointerIO);
/* 77 */     this.values[decrementedIndex()] = ptr;
/* 78 */     return ptr;
/*    */   }
/*    */   
/*    */   private int decrementedIndex() {
/* 82 */     int i = this.index;
/* 83 */     i--;
/* 84 */     if (i < 0) {
/* 85 */       i = this.values.length - 1;
/*    */     }
/* 87 */     this.index = i;
/* 88 */     return i;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\PointerLRUCache.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */