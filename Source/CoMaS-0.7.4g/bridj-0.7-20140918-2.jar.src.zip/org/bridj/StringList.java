package org.bridj;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;

class StringList {
  public final ByteBuffer stringsBuffer;
  
  public final IntBuffer offsetsBuffer;
  
  public StringList(String[] strings) {
    int n = strings.length;
    byte[][] bytes = new byte[n][];
    this.offsetsBuffer = ByteBuffer.allocateDirect(n * 4).asIntBuffer();
    int offset = 0;
    int i;
    for (i = 0; i < n; i++) {
      this.offsetsBuffer.put(i, offset);
      bytes[i] = strings[i].getBytes();
      offset += (strings[i].getBytes()).length + 1;
    } 
    this.stringsBuffer = ByteBuffer.allocateDirect(offset);
    for (i = 0; i < n; i++) {
      byte[] str = bytes[i];
      this.stringsBuffer.put(str);
      this.stringsBuffer.put((byte)0);
    } 
  }
}
