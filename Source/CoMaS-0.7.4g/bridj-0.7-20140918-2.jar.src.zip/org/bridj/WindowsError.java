/*    */ package org.bridj;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WindowsError
/*    */   extends NativeError
/*    */ {
/*    */   final int code;
/*    */   final long info;
/*    */   final long address;
/*    */   
/*    */   WindowsError(int code, long info, long address) {
/* 48 */     super(computeMessage(code, info, address));
/* 49 */     this.code = code;
/* 50 */     this.info = info;
/* 51 */     this.address = address;
/*    */   }
/*    */   
/*    */   public static void throwNew(int code, long info, long address) {
/* 55 */     throw new WindowsError(code, info, address);
/*    */   }
/*    */   
/*    */   static String subMessage(long info, long address) {
/* 59 */     switch ((int)info) {
/*    */       case 0:
/* 61 */         return "Attempted to read from inaccessible address " + toHex(address);
/*    */       case 1:
/* 63 */         return "Attempted to write to inaccessible address " + toHex(address);
/*    */       case 8:
/* 65 */         return "Attempted to execute memory " + toHex(address) + " that's not executable  (DEP violation)";
/*    */     } 
/* 67 */     return "?";
/*    */   }
/*    */ 
/*    */   
/*    */   public static String computeMessage(int code, long info, long address) {
/* 72 */     switch (code) {
/*    */       case -1073741819:
/* 74 */         return "EXCEPTION_ACCESS_VIOLATION : " + subMessage(info, address);
/*    */       case -1073741818:
/* 76 */         return "EXCEPTION_IN_PAGE_ERROR : " + subMessage(info, address);
/*    */     } 
/*    */     try {
/* 79 */       for (Field field : WinExceptionsConstants.class.getFields()) {
/* 80 */         if (field.getName().startsWith("EXCEPTION_") && field.getType() == int.class) {
/* 81 */           int value = ((Integer)field.get(null)).intValue();
/* 82 */           if (value == code) {
/* 83 */             return field.getName();
/*    */           }
/*    */         } 
/*    */       } 
/* 87 */     } catch (Throwable th) {}
/*    */     
/* 89 */     return "Windows native error (code = " + code + ", info = " + info + ", address = " + address + ") !";
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\WindowsError.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */