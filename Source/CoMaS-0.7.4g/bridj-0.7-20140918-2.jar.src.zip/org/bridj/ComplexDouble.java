package org.bridj;

import org.bridj.ann.Field;

public class ComplexDouble extends StructObject {
  @Field(0)
  public double real() {
    return this.io.getDoubleField(this, 0);
  }
  
  @Field(0)
  public ComplexDouble real(double real) {
    this.io.setDoubleField(this, 0, real);
    return this;
  }
  
  @Field(1)
  public double imag() {
    return this.io.getDoubleField(this, 0);
  }
  
  @Field(1)
  public ComplexDouble imag(double imag) {
    this.io.setDoubleField(this, 0, imag);
    return this;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\ComplexDouble.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */