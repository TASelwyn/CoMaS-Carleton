package org.bridj;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class DynamicFunctionFactory {
  final Constructor<? extends DynamicFunction> constructor;
  
  final Method method;
  
  final long callbackHandle;
  
  DynamicFunctionFactory(Class<? extends DynamicFunction> callbackClass, Method method, CRuntime.MethodCallInfoBuilder methodCallInfoBuilder) {
    try {
      this.constructor = callbackClass.getConstructor(new Class[0]);
      this.method = method;
      MethodCallInfo mci = methodCallInfoBuilder.apply(method);
      this.callbackHandle = JNI.bindJavaToCCallbacks(new MethodCallInfo[] { mci });
    } catch (Throwable th) {
      th.printStackTrace();
      throw new RuntimeException("Failed to instantiate callback : " + th, th);
    } 
  }
  
  protected void finalize() throws Throwable {
    if (BridJ.debugNeverFree)
      return; 
    JNI.freeJavaToCCallbacks(this.callbackHandle, 1);
  }
  
  public DynamicFunction newInstance(Pointer<?> functionPointer) {
    if (functionPointer == null)
      return null; 
    try {
      DynamicFunction dcb = this.constructor.newInstance(new Object[0]);
      dcb.peer = (Pointer)functionPointer;
      dcb.method = this.method;
      dcb.factory = this;
      return dcb;
    } catch (Throwable th) {
      th.printStackTrace();
      throw new RuntimeException("Failed to instantiate callback : " + th, th);
    } 
  }
  
  public String toString() {
    return getClass().getSimpleName() + "(" + this.method + ")";
  }
}
