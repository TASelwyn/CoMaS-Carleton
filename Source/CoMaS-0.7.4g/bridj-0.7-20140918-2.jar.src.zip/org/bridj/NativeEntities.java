/*     */ package org.bridj;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeEntities
/*     */ {
/*     */   static class CBInfo
/*     */   {
/*     */     long handle;
/*     */     int size;
/*     */     
/*     */     public CBInfo(long handle, int size) {
/*  52 */       this.handle = handle;
/*  53 */       this.size = size;
/*     */     }
/*     */   }
/*  56 */   Map<Class<?>, CBInfo> functions = new HashMap<Class<?>, CBInfo>(); Map<Class<?>, CBInfo> virtualMethods = new HashMap<Class<?>, CBInfo>(); Map<Class<?>, CBInfo> javaToNativeCallbacks = new HashMap<Class<?>, CBInfo>(); Map<Class<?>, CBInfo> objcMethodInfos = new HashMap<Class<?>, CBInfo>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*  69 */     List<MethodCallInfo> functionInfos = new ArrayList<MethodCallInfo>(), virtualMethods = new ArrayList<MethodCallInfo>(), javaToNativeCallbacks = new ArrayList<MethodCallInfo>(), cppMethodInfos = new ArrayList<MethodCallInfo>(), objcMethodInfos = new ArrayList<MethodCallInfo>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void addFunction(MethodCallInfo info) {
/*  78 */       this.functionInfos.add(info);
/*     */     }
/*     */     
/*     */     public void addVirtualMethod(MethodCallInfo info) {
/*  82 */       this.virtualMethods.add(info);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void addJavaToNativeCallback(MethodCallInfo info) {
/*  92 */       this.javaToNativeCallbacks.add(info);
/*     */     }
/*     */     
/*     */     public void addMethodFunction(MethodCallInfo info) {
/*  96 */       this.cppMethodInfos.add(info);
/*     */     }
/*     */     
/*     */     public void addObjCMethod(MethodCallInfo info) {
/* 100 */       this.objcMethodInfos.add(info);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/* 110 */     if (BridJ.debugNeverFree) {
/*     */       return;
/*     */     }
/*     */     
/* 114 */     for (CBInfo callbacks : this.functions.values()) {
/* 115 */       JNI.freeCFunctionBindings(callbacks.handle, callbacks.size);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     for (CBInfo callbacks : this.javaToNativeCallbacks.values()) {
/* 123 */       JNI.freeJavaToCCallbacks(callbacks.handle, callbacks.size);
/*     */     }
/*     */     
/* 126 */     for (CBInfo callbacks : this.virtualMethods.values()) {
/* 127 */       JNI.freeVirtualMethodBindings(callbacks.handle, callbacks.size);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     for (CBInfo callbacks : this.objcMethodInfos.values()) {
/* 134 */       JNI.freeObjCMethodBindings(callbacks.handle, callbacks.size);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void finalize() {
/* 140 */     release();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDefinitions(Class<?> type, Builder builder) {
/*     */     try {
/* 147 */       int n = builder.functionInfos.size();
/* 148 */       if (n != 0) {
/* 149 */         this.functions.put(type, new CBInfo(JNI.bindJavaMethodsToCFunctions(builder.functionInfos.<MethodCallInfo>toArray(new MethodCallInfo[n])), n));
/*     */       }
/*     */       
/* 152 */       n = builder.virtualMethods.size();
/* 153 */       if (n != 0) {
/* 154 */         this.virtualMethods.put(type, new CBInfo(JNI.bindJavaMethodsToVirtualMethods(builder.virtualMethods.<MethodCallInfo>toArray(new MethodCallInfo[n])), n));
/*     */       }
/*     */       
/* 157 */       n = builder.javaToNativeCallbacks.size();
/* 158 */       if (n != 0) {
/* 159 */         this.javaToNativeCallbacks.put(type, new CBInfo(JNI.bindJavaToCCallbacks(builder.javaToNativeCallbacks.<MethodCallInfo>toArray(new MethodCallInfo[n])), n));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 167 */       n = builder.objcMethodInfos.size();
/* 168 */       if (n != 0) {
/* 169 */         this.objcMethodInfos.put(type, new CBInfo(JNI.bindJavaMethodsToObjCMethods(builder.objcMethodInfos.<MethodCallInfo>toArray(new MethodCallInfo[n])), n));
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 176 */     catch (Throwable th) {
/* 177 */       assert BridJ.error("Failed to add native definitions for class " + type.getName(), th);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\NativeEntities.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */