/*    */ package org.bridj.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.bridj.BridJ;
/*    */ import org.bridj.Platform;
/*    */ import org.bridj.ann.Convention;
/*    */ import org.bridj.ann.Library;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProcessUtils
/*    */ {
/*    */   @Library("kernel32")
/*    */   @Convention(Convention.Style.StdCall)
/*    */   static class Kernel32
/*    */   {
/*    */     public static native int GetCurrentProcessId();
/*    */   }
/*    */   
/*    */   @Library("c")
/*    */   static class LibC
/*    */   {
/*    */     public static native int getpid();
/*    */   }
/*    */   
/*    */   public static int getCurrentProcessId() {
/* 69 */     if (Platform.isWindows()) {
/* 70 */       BridJ.register(Kernel32.class);
/* 71 */       return Kernel32.GetCurrentProcessId();
/*    */     } 
/* 73 */     BridJ.register(LibC.class);
/* 74 */     return LibC.getpid();
/*    */   }
/*    */ 
/*    */   
/*    */   public static String[] computeJavaProcessArgs(Class<?> mainClass, List<?> mainArgs) {
/* 79 */     List<String> args = new ArrayList<String>();
/* 80 */     args.add((new File(new File(System.getProperty("java.home")), "bin" + File.separator + "java")).toString());
/* 81 */     args.add("-cp");
/* 82 */     args.add(System.getProperty("java.class.path"));
/* 83 */     args.add(mainClass.getName());
/* 84 */     for (Object arg : mainArgs) {
/* 85 */       args.add(arg.toString());
/*    */     }
/*    */     
/* 88 */     return args.<String>toArray(new String[args.size()]);
/*    */   }
/*    */   
/*    */   public static Process startJavaProcess(Class<?> mainClass, List<?> mainArgs) throws IOException {
/* 92 */     ProcessBuilder b = new ProcessBuilder(new String[0]);
/* 93 */     b.command(computeJavaProcessArgs(mainClass, mainArgs));
/* 94 */     b.redirectErrorStream(true);
/* 95 */     return b.start();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\brid\\util\ProcessUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */