/*     */ package org.bridj.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import org.bridj.BridJ;
/*     */ import org.bridj.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JNIUtils
/*     */ {
/*     */   private static class NativeMethodsCache
/*     */   {
/*  53 */     Map<String, String> signatures = new HashMap<String, String>();
/*     */     
/*     */     public NativeMethodsCache(String internalClassName) throws IOException {
/*  56 */       for (String[] sig : BytecodeAnalyzer.getNativeMethodSignatures(internalClassName, Platform.getClassLoader())) {
/*  57 */         this.signatures.put(sig[1], sig[2]);
/*     */       }
/*     */     }
/*     */     
/*     */     public String get(String name) {
/*  62 */       return this.signatures.get(name);
/*     */     }
/*     */     
/*     */     public Set<String> getNames() {
/*  66 */       return this.signatures.keySet();
/*     */     }
/*     */   }
/*  69 */   private static Map<String, NativeMethodsCache> nativeMethodsCache = new WeakHashMap<String, NativeMethodsCache>();
/*     */   
/*     */   private static synchronized NativeMethodsCache getNativeMethodsCache(String internalClassName) throws IOException {
/*  72 */     NativeMethodsCache cache = nativeMethodsCache.get(internalClassName);
/*  73 */     if (cache == null) {
/*  74 */       nativeMethodsCache.put(internalClassName, cache = new NativeMethodsCache(internalClassName));
/*     */     }
/*  76 */     return cache;
/*     */   }
/*  78 */   private static final String bridjPackage = (BridJ.class.getPackage() == null) ? "org.bridj" : BridJ.class.getPackage().getName();
/*     */   
/*  80 */   private static final String bridjNormalPackagePrefix = bridjPackage.endsWith("v0_7_0") ? bridjPackage.substring(0, bridjPackage.length() - "v0_7_0".length()) : (bridjPackage + ".");
/*  81 */   private static final String bridjVersionSpecificPackagePrefix = bridjPackage + ".";
/*     */   
/*     */   static int findLastNonEscapeUnderscore(String s) {
/*  84 */     int len = s.length(), i = len;
/*     */     while (true) {
/*  86 */       i = s.lastIndexOf("_", i - 1);
/*  87 */       if (i >= 0 && (i == len - 1 || !Character.isDigit(s.charAt(i + 1)))) {
/*  88 */         return i;
/*     */       }
/*  90 */       if (i <= 0)
/*  91 */         return -1; 
/*     */     } 
/*     */   }
/*     */   public static String decodeVersionSpecificMethodNameClassAndSignature(String symbolName, Object[] nameAndSigArray) throws NoSuchMethodException, IOException {
/*  95 */     return decodeMethodNameClassAndSignature(symbolName, nameAndSigArray, bridjNormalPackagePrefix, bridjVersionSpecificPackagePrefix);
/*     */   }
/*     */   
/*     */   static String decodeMethodNameClassAndSignature(String symbolName, Object[] nameAndSigArray, String normalClassPrefix, String replacementClassPrefix) throws NoSuchMethodException, IOException {
/*  99 */     if (symbolName.startsWith("_")) {
/* 100 */       symbolName = symbolName.substring(1);
/*     */     }
/* 102 */     if (symbolName.startsWith("Java_")) {
/* 103 */       symbolName = symbolName.substring("Java_".length());
/*     */     }
/*     */     
/* 106 */     int i = findLastNonEscapeUnderscore(symbolName);
/* 107 */     String className = symbolName.substring(0, i).replace('_', '.');
/* 108 */     if (normalClassPrefix != null && 
/* 109 */       className.startsWith(normalClassPrefix) && !className.startsWith(replacementClassPrefix)) {
/* 110 */       className = replacementClassPrefix + className.substring(normalClassPrefix.length());
/*     */     }
/*     */     
/* 113 */     String methodName = symbolName.substring(i + 1).replaceAll("_1", "_");
/*     */     
/* 115 */     NativeMethodsCache mc = getNativeMethodsCache(className.replace('.', '/'));
/* 116 */     String sig = mc.get(methodName);
/* 117 */     if (sig == null) {
/* 118 */       throw new NoSuchMethodException("Method " + methodName + " not found in class " + className + " : known method names = " + StringUtils.implode(mc.getNames(), ", "));
/*     */     }
/*     */     
/* 121 */     nameAndSigArray[0] = methodName;
/* 122 */     nameAndSigArray[1] = sig;
/*     */     
/* 124 */     String internalClassName = className.replace('.', '/');
/* 125 */     return internalClassName;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getNativeName(Class c) {
/* 130 */     return c.getName().replace('.', '/');
/*     */   }
/*     */   
/*     */   public static String getNativeSignature(Method m) {
/* 134 */     StringBuffer b = new StringBuffer();
/* 135 */     b.append('(');
/* 136 */     for (Class<?> c : m.getParameterTypes()) {
/* 137 */       b.append(getNativeSignature(c));
/*     */     }
/* 139 */     b.append(')');
/* 140 */     b.append(getNativeSignature(m.getReturnType()));
/* 141 */     return b.toString();
/*     */   }
/*     */   
/*     */   public static String getNativeSignature(Class<int> c) {
/* 145 */     if (c.isPrimitive()) {
/* 146 */       if (c == int.class) {
/* 147 */         return "I";
/*     */       }
/* 149 */       if (c == long.class) {
/* 150 */         return "J";
/*     */       }
/* 152 */       if (c == short.class) {
/* 153 */         return "S";
/*     */       }
/* 155 */       if (c == byte.class) {
/* 156 */         return "B";
/*     */       }
/* 158 */       if (c == boolean.class) {
/* 159 */         return "Z";
/*     */       }
/* 161 */       if (c == double.class) {
/* 162 */         return "D";
/*     */       }
/* 164 */       if (c == float.class) {
/* 165 */         return "F";
/*     */       }
/* 167 */       if (c == char.class) {
/* 168 */         return "C";
/*     */       }
/* 170 */       if (c == void.class) {
/* 171 */         return "V";
/*     */       }
/*     */       
/* 174 */       throw new RuntimeException("unexpected case");
/*     */     } 
/* 176 */     if (c.isArray()) {
/* 177 */       return "[" + getNativeSignature(c.getComponentType());
/*     */     }
/* 179 */     return "L" + getNativeName(c) + ";";
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\brid\\util\JNIUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */