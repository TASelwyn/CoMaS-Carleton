/*     */ package org.bridj.util;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Member;
/*     */ import org.bridj.ann.Forwardable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationUtils
/*     */ {
/*     */   public static <A extends Annotation> A getInheritableAnnotation(Class<A> ac, AnnotatedElement m, Annotation... directAnnotations) {
/*  48 */     return getAnnotation(ac, true, m, directAnnotations);
/*     */   }
/*     */   
/*     */   public static <A extends Annotation> A getAnnotation(Class<A> ac, AnnotatedElement m, Annotation... directAnnotations) {
/*  52 */     return getAnnotation(ac, false, m, directAnnotations);
/*     */   }
/*     */   
/*     */   private static boolean isForwardable(Class<? extends Annotation> ac) {
/*  56 */     return ac.isAnnotationPresent((Class)Forwardable.class);
/*     */   }
/*     */   
/*     */   public static boolean isAnnotationPresent(Class<? extends Annotation> ac, Annotation... annotations) {
/*  60 */     return isAnnotationPresent(ac, isForwardable(ac), annotations);
/*     */   }
/*     */   
/*     */   private static boolean isAnnotationPresent(Class<? extends Annotation> ac, boolean isForwardable, Annotation... annotations) {
/*  64 */     for (Annotation ann : annotations) {
/*  65 */       if (ac.isInstance(ann)) {
/*  66 */         return true;
/*     */       }
/*     */       
/*  69 */       if (isForwardable && 
/*  70 */         ann.annotationType().isAnnotationPresent(ac)) {
/*  71 */         return true;
/*     */       }
/*     */     } 
/*     */     
/*  75 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isAnnotationPresent(Class<? extends Annotation> ac, AnnotatedElement m, Annotation... directAnnotations) {
/*  79 */     boolean isForwardable = isForwardable(ac);
/*  80 */     if (m != null) {
/*  81 */       if (isForwardable) {
/*  82 */         if (isAnnotationPresent(ac, true, m.getAnnotations())) {
/*  83 */           return true;
/*     */         }
/*     */       }
/*  86 */       else if (m.isAnnotationPresent(ac)) {
/*  87 */         return true;
/*     */       } 
/*     */     }
/*     */     
/*  91 */     if (directAnnotations != null) {
/*  92 */       return isAnnotationPresent(ac, isForwardable, directAnnotations);
/*     */     }
/*     */     
/*  95 */     return false;
/*     */   }
/*     */   
/*     */   private static <A extends Annotation> A getAnnotation(Class<A> ac, boolean inherit, AnnotatedElement m, Annotation... directAnnotations) {
/*  99 */     if (directAnnotations != null) {
/* 100 */       for (Annotation ann : directAnnotations) {
/* 101 */         if (ac.isInstance(ann)) {
/* 102 */           return ac.cast(ann);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 107 */     if (m == null) {
/* 108 */       return null;
/*     */     }
/* 110 */     A a = m.getAnnotation(ac);
/* 111 */     if (a != null) {
/* 112 */       return a;
/*     */     }
/*     */     
/* 115 */     if (inherit) {
/* 116 */       if (m instanceof Member) {
/* 117 */         return getAnnotation(ac, inherit, ((Member)m).getDeclaringClass(), new Annotation[0]);
/*     */       }
/*     */       
/* 120 */       if (m instanceof Class) {
/* 121 */         Class<?> c = (Class)m, dc = c.getDeclaringClass();
/* 122 */         Class<?> p = c.getSuperclass();
/* 123 */         while (p != null) {
/* 124 */           a = getAnnotation(ac, true, p, new Annotation[0]);
/* 125 */           if (a != null) {
/* 126 */             return a;
/*     */           }
/* 128 */           p = p.getSuperclass();
/*     */         } 
/*     */         
/* 131 */         if (dc != null) {
/* 132 */           return getAnnotation(ac, inherit, dc, new Annotation[0]);
/*     */         }
/*     */       } 
/*     */     } 
/* 136 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\brid\\util\AnnotationUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */