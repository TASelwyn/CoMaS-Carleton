/*     */ package org.bridj.util;
/*     */ 
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultParameterizedType
/*     */   implements ParameterizedType
/*     */ {
/*     */   private final Type[] actualTypeArguments;
/*     */   private final Type ownerType;
/*     */   private final Type rawType;
/*     */   
/*     */   public DefaultParameterizedType(Type ownerType, Type rawType, Type[] actualTypeArguments) {
/*  48 */     this.ownerType = ownerType;
/*  49 */     this.actualTypeArguments = actualTypeArguments;
/*  50 */     this.rawType = rawType;
/*     */   }
/*     */   
/*     */   public DefaultParameterizedType(Type rawType, Type... actualTypeArguments) {
/*  54 */     this(null, rawType, actualTypeArguments);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  59 */     StringBuilder b = new StringBuilder();
/*  60 */     if (this.ownerType != null) {
/*  61 */       b.append(Utils.toString(this.ownerType)).append(".");
/*     */     }
/*  63 */     b.append(this.rawType);
/*  64 */     if (this.actualTypeArguments.length > 0) {
/*  65 */       b.append("<");
/*  66 */       for (int i = 0; i < this.actualTypeArguments.length; i++) {
/*  67 */         if (i > 0) {
/*  68 */           b.append(", ");
/*     */         }
/*  70 */         b.append(Utils.toString(this.actualTypeArguments[i]));
/*     */       } 
/*  72 */       b.append(">");
/*     */     } 
/*  74 */     return b.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type paramType(Type rawType, Type... actualTypeArguments) {
/*  86 */     return new DefaultParameterizedType(rawType, actualTypeArguments);
/*     */   }
/*     */ 
/*     */   
/*     */   public Type[] getActualTypeArguments() {
/*  91 */     return (Type[])this.actualTypeArguments.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getOwnerType() {
/*  96 */     return this.ownerType;
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getRawType() {
/* 101 */     return this.rawType;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 106 */     int h = getRawType().hashCode();
/* 107 */     if (getOwnerType() != null) {
/* 108 */       h ^= getOwnerType().hashCode();
/*     */     }
/* 110 */     for (int i = 0, n = this.actualTypeArguments.length; i < n; i++) {
/* 111 */       Type arg = this.actualTypeArguments[i];
/* 112 */       if (arg != null) {
/* 113 */         h ^= arg.hashCode();
/*     */       }
/*     */     } 
/* 116 */     return h;
/*     */   }
/*     */   
/*     */   static boolean eq(Object a, Object b) {
/* 120 */     if (((a == null) ? true : false) != ((b == null) ? true : false)) {
/* 121 */       return false;
/*     */     }
/* 123 */     if (a != null && !a.equals(b)) {
/* 124 */       return false;
/*     */     }
/* 126 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 131 */     if (o == null || !(o instanceof DefaultParameterizedType)) {
/* 132 */       return false;
/*     */     }
/*     */     
/* 135 */     DefaultParameterizedType t = (DefaultParameterizedType)o;
/* 136 */     if (!eq(getRawType(), t.getRawType())) {
/* 137 */       return false;
/*     */     }
/* 139 */     if (!eq(getOwnerType(), t.getOwnerType())) {
/* 140 */       return false;
/*     */     }
/*     */     
/* 143 */     Type[] arrayOfType = t.actualTypeArguments;
/* 144 */     if (this.actualTypeArguments.length != arrayOfType.length) {
/* 145 */       return false;
/*     */     }
/*     */     
/* 148 */     for (int i = 0, n = this.actualTypeArguments.length; i < n; i++) {
/* 149 */       if (!eq(this.actualTypeArguments[i], arrayOfType[i])) {
/* 150 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 154 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\brid\\util\DefaultParameterizedType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */