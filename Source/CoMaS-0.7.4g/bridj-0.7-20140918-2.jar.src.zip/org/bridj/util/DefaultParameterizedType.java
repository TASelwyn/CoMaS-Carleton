package org.bridj.util;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

public class DefaultParameterizedType implements ParameterizedType {
  private final Type[] actualTypeArguments;
  
  private final Type ownerType;
  
  private final Type rawType;
  
  public DefaultParameterizedType(Type ownerType, Type rawType, Type[] actualTypeArguments) {
    this.ownerType = ownerType;
    this.actualTypeArguments = actualTypeArguments;
    this.rawType = rawType;
  }
  
  public DefaultParameterizedType(Type rawType, Type... actualTypeArguments) {
    this(null, rawType, actualTypeArguments);
  }
  
  public String toString() {
    StringBuilder b = new StringBuilder();
    if (this.ownerType != null)
      b.append(Utils.toString(this.ownerType)).append("."); 
    b.append(this.rawType);
    if (this.actualTypeArguments.length > 0) {
      b.append("<");
      for (int i = 0; i < this.actualTypeArguments.length; i++) {
        if (i > 0)
          b.append(", "); 
        b.append(Utils.toString(this.actualTypeArguments[i]));
      } 
      b.append(">");
    } 
    return b.toString();
  }
  
  public static Type paramType(Type rawType, Type... actualTypeArguments) {
    return new DefaultParameterizedType(rawType, actualTypeArguments);
  }
  
  public Type[] getActualTypeArguments() {
    return (Type[])this.actualTypeArguments.clone();
  }
  
  public Type getOwnerType() {
    return this.ownerType;
  }
  
  public Type getRawType() {
    return this.rawType;
  }
  
  public int hashCode() {
    int h = getRawType().hashCode();
    if (getOwnerType() != null)
      h ^= getOwnerType().hashCode(); 
    for (int i = 0, n = this.actualTypeArguments.length; i < n; i++) {
      Type arg = this.actualTypeArguments[i];
      if (arg != null)
        h ^= arg.hashCode(); 
    } 
    return h;
  }
  
  static boolean eq(Object a, Object b) {
    if (((a == null) ? true : false) != ((b == null) ? true : false))
      return false; 
    if (a != null && !a.equals(b))
      return false; 
    return true;
  }
  
  public boolean equals(Object o) {
    if (o == null || !(o instanceof DefaultParameterizedType))
      return false; 
    DefaultParameterizedType t = (DefaultParameterizedType)o;
    if (!eq(getRawType(), t.getRawType()))
      return false; 
    if (!eq(getOwnerType(), t.getOwnerType()))
      return false; 
    Type[] arrayOfType = t.actualTypeArguments;
    if (this.actualTypeArguments.length != arrayOfType.length)
      return false; 
    for (int i = 0, n = this.actualTypeArguments.length; i < n; i++) {
      if (!eq(this.actualTypeArguments[i], arrayOfType[i]))
        return false; 
    } 
    return true;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\brid\\util\DefaultParameterizedType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */