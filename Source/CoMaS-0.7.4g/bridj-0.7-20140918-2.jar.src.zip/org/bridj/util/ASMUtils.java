package org.bridj.util;

import java.io.IOException;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import org.bridj.Pointer;
import org.bridj.relocated.org.objectweb.asm.ClassReader;
import org.bridj.relocated.org.objectweb.asm.ClassVisitor;
import org.bridj.relocated.org.objectweb.asm.ClassWriter;
import org.bridj.relocated.org.objectweb.asm.FieldVisitor;
import org.bridj.relocated.org.objectweb.asm.MethodVisitor;

public class ASMUtils {
  public static String typeDesc(Type t) {
    if (t instanceof Class) {
      Class<Pointer> c = (Class)t;
      if (c == Pointer.class)
        return "Pointer"; 
      if (c.isPrimitive()) {
        String s = c.getSimpleName();
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
      } 
      if (c.isArray())
        return typeDesc(c.getComponentType()) + "Array"; 
      return c.getName().replace('.', '_');
    } 
    ParameterizedType p = (ParameterizedType)t;
    StringBuilder b = new StringBuilder(typeDesc(p.getRawType()));
    for (Type pp : p.getActualTypeArguments())
      b.append("_").append(typeDesc(pp)); 
    return b.toString();
  }
  
  public static void addSuperCall(ClassVisitor cv, String superClassInternalName) {
    MethodVisitor mv = cv.visitMethod(1, "<init>", "()V", null, null);
    mv.visitCode();
    mv.visitVarInsn(25, 0);
    mv.visitMethodInsn(183, superClassInternalName, "<init>", "()V");
    mv.visitInsn(177);
    mv.visitMaxs(1, 1);
    mv.visitEnd();
  }
  
  public static <T> Class<? extends T> createSubclassWithSynchronizedNativeMethodsAndNoStaticFields(Class<T> original, ClassDefiner classDefiner) throws IOException {
    String suffix = "$SynchronizedNative";
    final String originalInternalName = JNIUtils.getNativeName(original);
    String synchronizedName = original.getName() + suffix;
    final String synchronizedInternalName = originalInternalName + suffix;
    ClassWriter classWriter = new ClassWriter(0);
    ClassVisitor cv = new ClassVisitor(262144, (ClassVisitor)classWriter) {
        public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
          super.visit(version, access, synchronizedInternalName, null, originalInternalName, new String[0]);
          ASMUtils.addSuperCall(this.cv, originalInternalName);
        }
        
        public void visitInnerClass(String name, String outerName, String innerName, int access) {}
        
        public FieldVisitor visitField(int access, String name, String desc, String signature, Object value) {
          return null;
        }
        
        public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
          if (!Modifier.isNative(access))
            return null; 
          return super.visitMethod(access | 0x20, name, desc, signature, exceptions);
        }
      };
    ClassReader classReader = new ClassReader(original.getName());
    classReader.accept(cv, 0);
    return (Class)classDefiner.defineClass(synchronizedName, classWriter.toByteArray());
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\brid\\util\ASMUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */