/*    */ package org.bridj.util;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringUtils
/*    */ {
/*    */   public static String implode(double[] array, String separator) {
/* 44 */     StringBuffer out = new StringBuffer();
/* 45 */     boolean first = true;
/* 46 */     for (double v : array) {
/* 47 */       if (first) {
/* 48 */         first = false;
/*    */       } else {
/* 50 */         out.append(separator);
/*    */       } 
/* 52 */       out.append(v);
/*    */     } 
/* 54 */     return out.toString();
/*    */   }
/*    */   
/*    */   public static String implode(Object[] values) {
/* 58 */     return implode(values, ", ");
/*    */   }
/*    */   
/*    */   public static String implode(Object[] values, Object separator) {
/* 62 */     return implode(Arrays.asList(values), separator);
/*    */   }
/*    */   
/*    */   public static final <T> String implode(Iterable<T> elements, Object separator) {
/* 66 */     String sepStr = separator.toString();
/* 67 */     StringBuilder out = new StringBuilder();
/* 68 */     boolean first = true;
/* 69 */     for (T s : elements) {
/* 70 */       if (s == null) {
/*    */         continue;
/*    */       }
/*    */       
/* 74 */       if (first) {
/* 75 */         first = false;
/*    */       } else {
/* 77 */         out.append(sepStr);
/*    */       } 
/* 79 */       out.append(s);
/*    */     } 
/* 81 */     return out.toString();
/*    */   }
/*    */   
/*    */   public static final String implode(Iterable<?> strings) {
/* 85 */     return implode(strings, ", ");
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\brid\\util\StringUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */