/*     */ package org.bridj.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tuple
/*     */ {
/*     */   protected final Object[] data;
/*     */   
/*     */   public Tuple(Object[] data) {
/*  38 */     this.data = data;
/*     */   }
/*     */   
/*     */   public Tuple(int n) {
/*  42 */     this.data = new Object[n];
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  47 */     int h = 0;
/*  48 */     for (int i = 0, n = size(); i < n; i++) {
/*  49 */       Object o = get(i);
/*  50 */       if (o != null)
/*     */       {
/*     */         
/*  53 */         h ^= o.hashCode(); } 
/*     */     } 
/*  55 */     return h;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  60 */     if (obj == null || !(obj instanceof Tuple)) {
/*  61 */       return false;
/*     */     }
/*  63 */     Tuple t = (Tuple)obj;
/*  64 */     int s = size();
/*  65 */     if (t.size() != s) {
/*  66 */       return false;
/*     */     }
/*  68 */     for (int i = 0; i < s; i++) {
/*  69 */       Object o1 = get(i), o2 = t.get(i);
/*  70 */       if (o1 == null) {
/*  71 */         if (o2 != null) {
/*  72 */           return false;
/*     */         }
/*  74 */       } else if (!o1.equals(o2)) {
/*  75 */         return false;
/*     */       } 
/*     */     } 
/*  78 */     return true;
/*     */   }
/*     */   
/*     */   public Object get(int index) {
/*  82 */     return this.data[index];
/*     */   }
/*     */   
/*     */   public void set(int index, Object value) {
/*  86 */     this.data[index] = value;
/*     */   }
/*     */   
/*     */   public int size() {
/*  90 */     return this.data.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  95 */     StringBuilder b = new StringBuilder("{");
/*  96 */     for (int i = 0, n = size(); i < n; i++) {
/*  97 */       if (i != 0) {
/*  98 */         b.append(',');
/*     */       }
/* 100 */       b.append('\n');
/* 101 */       b.append('\t').append(get(i));
/*     */     } 
/* 103 */     b.append("\n}");
/* 104 */     return b.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\brid\\util\Tuple.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */