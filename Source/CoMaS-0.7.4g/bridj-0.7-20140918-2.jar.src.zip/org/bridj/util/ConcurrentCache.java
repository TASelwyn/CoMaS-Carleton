/*    */ package org.bridj.util;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConcurrentCache<K, V>
/*    */ {
/* 46 */   protected final ConcurrentHashMap<K, V> map = new ConcurrentHashMap<K, V>();
/*    */   protected final Class<V> valueClass;
/*    */   
/*    */   public ConcurrentCache(Class<V> valueClass) {
/* 50 */     this.valueClass = valueClass;
/*    */   }
/*    */   private volatile Constructor<V> valueConstructor;
/*    */   
/*    */   private Constructor<V> getValueConstructor() {
/* 55 */     if (this.valueConstructor == null) {
/*    */       try {
/* 57 */         this.valueConstructor = this.valueClass.getConstructor(new Class[0]);
/* 58 */         if (this.valueConstructor != null && this.valueConstructor.isAccessible()) {
/* 59 */           this.valueConstructor.setAccessible(true);
/*    */         }
/* 61 */       } catch (Exception ex) {
/* 62 */         throw new RuntimeException("No accessible default constructor in class " + ((this.valueClass == null) ? "null" : this.valueClass.getName()), ex);
/*    */       } 
/*    */     }
/* 65 */     return this.valueConstructor;
/*    */   }
/*    */   
/*    */   protected V newInstance(K key) {
/*    */     try {
/* 70 */       return getValueConstructor().newInstance(new Object[0]);
/* 71 */     } catch (Exception ex) {
/* 72 */       throw new RuntimeException("Failed to call constructor " + this.valueConstructor, ex);
/*    */     } 
/*    */   }
/*    */   
/*    */   public V get(K key) {
/* 77 */     V v = this.map.get(key);
/* 78 */     if (v == null) {
/* 79 */       V newV = newInstance(key);
/* 80 */       V oldV = this.map.putIfAbsent(key, newV);
/* 81 */       if (oldV != null) {
/* 82 */         v = oldV;
/*    */       } else {
/* 84 */         v = newV;
/*    */       } 
/*    */     } 
/* 87 */     return v;
/*    */   }
/*    */   
/*    */   public void clear() {
/* 91 */     this.map.clear();
/*    */   }
/*    */   
/*    */   public Iterable<Map.Entry<K, V>> entrySet() {
/* 95 */     return this.map.entrySet();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\brid\\util\ConcurrentCache.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */