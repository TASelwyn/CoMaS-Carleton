/*     */ package org.bridj.util;
/*     */ 
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Pair<U, V>
/*     */   implements Comparable<Pair<U, V>>, Map.Entry<U, V>
/*     */ {
/*     */   private U first;
/*     */   private V second;
/*     */   
/*     */   public Pair(U first, V second) {
/*  41 */     this.first = first;
/*  42 */     this.second = second;
/*     */   }
/*     */ 
/*     */   
/*     */   public Pair() {}
/*     */   
/*     */   public U getFirst() {
/*  49 */     return this.first;
/*     */   }
/*     */   
/*     */   public V getSecond() {
/*  53 */     return this.second;
/*     */   }
/*     */   
/*     */   public void setFirst(U first) {
/*  57 */     this.first = first;
/*     */   }
/*     */   
/*     */   public void setSecond(V second) {
/*  61 */     this.second = second;
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(Pair<U, V> o) {
/*  66 */     Comparable<U> cu = (Comparable<U>)getFirst();
/*  67 */     if (cu == null) {
/*  68 */       if (this.first != null) {
/*  69 */         return 1;
/*     */       }
/*     */     } else {
/*  72 */       int d = cu.compareTo(o.getFirst());
/*  73 */       if (d != 0) {
/*  74 */         return d;
/*     */       }
/*     */     } 
/*     */     
/*  78 */     Comparable<V> cv = (Comparable<V>)getSecond();
/*  79 */     if (cv == null) {
/*  80 */       return (this.second != null) ? 1 : -1;
/*     */     }
/*  82 */     return cv.compareTo(o.getSecond());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  87 */     return "Pair(" + this.first + ", " + this.second + ")";
/*     */   }
/*     */   
/*     */   public U getKey() {
/*  91 */     return this.first;
/*     */   }
/*     */   
/*     */   public V getValue() {
/*  95 */     return this.second;
/*     */   }
/*     */   
/*     */   public V setValue(V value) {
/*  99 */     V oldValue = this.second;
/* 100 */     this.second = value;
/* 101 */     return oldValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 106 */     int prime = 31;
/* 107 */     int result = 1;
/* 108 */     result = 31 * result + ((this.first == null) ? 0 : this.first.hashCode());
/* 109 */     result = 31 * result + ((this.second == null) ? 0 : this.second.hashCode());
/* 110 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 115 */     if (this == obj) {
/* 116 */       return true;
/*     */     }
/* 118 */     if (obj == null) {
/* 119 */       return false;
/*     */     }
/* 121 */     if (getClass() != obj.getClass()) {
/* 122 */       return false;
/*     */     }
/* 124 */     Pair<?, ?> other = (Pair<?, ?>)obj;
/* 125 */     if (this.first == null) {
/* 126 */       if (other.first != null) {
/* 127 */         return false;
/*     */       }
/* 129 */     } else if (!this.first.equals(other.first)) {
/* 130 */       return false;
/*     */     } 
/* 132 */     if (this.second == null) {
/* 133 */       if (other.second != null) {
/* 134 */         return false;
/*     */       }
/* 136 */     } else if (!this.second.equals(other.second)) {
/* 137 */       return false;
/*     */     } 
/* 139 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isFull() {
/* 143 */     return (getFirst() != null && getSecond() != null);
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 147 */     return (getFirst() == null && getSecond() == null);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\brid\\util\Pair.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */