/*     */ package org.bridj;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Type;
/*     */ import org.bridj.ann.Constructor;
/*     */ import org.bridj.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractBridJRuntime
/*     */   implements BridJRuntime
/*     */ {
/*     */   public void unregister(Type type) {}
/*     */   
/*     */   public Type getType(NativeObject instance) {
/*  53 */     if (instance == null) {
/*  54 */       return null;
/*     */     }
/*  56 */     return Utils.getClass(instance.getClass());
/*     */   }
/*     */   
/*     */   protected Constructor findConstructor(Class<?> type, int constructorId, boolean onlyWithAnnotation) throws SecurityException, NoSuchMethodException {
/*  60 */     for (Constructor<?> c : type.getDeclaredConstructors()) {
/*  61 */       Constructor ca = c.<Constructor>getAnnotation(Constructor.class);
/*  62 */       if (ca != null)
/*     */       {
/*     */         
/*  65 */         if (ca.value() == constructorId)
/*  66 */           return c; 
/*     */       }
/*     */     } 
/*  69 */     if (constructorId < 0)
/*     */     {
/*  71 */       return type.getConstructor(new Class[0]);
/*     */     }
/*  73 */     Class<?> sup = type.getSuperclass();
/*  74 */     if (sup != null) {
/*     */       try {
/*  76 */         Constructor c = findConstructor(sup, constructorId, onlyWithAnnotation);
/*  77 */         if (onlyWithAnnotation && c != null) {
/*  78 */           return c;
/*     */         }
/*     */         
/*  81 */         Type[] params = c.getGenericParameterTypes();
/*  82 */         Constructor[] arrayOfConstructor = (Constructor[])type.getDeclaredConstructors();
/*  83 */         for (Constructor cc : arrayOfConstructor) {
/*  84 */           Type[] ccparams = cc.getGenericParameterTypes();
/*  85 */           int overrideOffset = Utils.getEnclosedConstructorParametersOffset(cc);
/*  86 */           if (isOverridenSignature(params, ccparams, overrideOffset)) {
/*  87 */             return cc;
/*     */           }
/*     */         } 
/*  90 */       } catch (Throwable th) {
/*  91 */         th.printStackTrace();
/*     */       } 
/*     */     }
/*  94 */     throw new NoSuchMethodException("Cannot find constructor with index " + constructorId);
/*     */   }
/*     */   
/*     */   public static boolean isOverridenSignature(Type[] parentSignature, Type[] overrideSignature, int overrideOffset) {
/*  98 */     int n = parentSignature.length;
/*  99 */     if (overrideSignature.length - overrideOffset != n) {
/* 100 */       return false;
/*     */     }
/* 102 */     for (int i = 0; i < n; i++) {
/* 103 */       if (!isOverride(parentSignature[i], overrideSignature[overrideOffset + i])) {
/* 104 */         return false;
/*     */       }
/*     */     } 
/* 107 */     return true;
/*     */   }
/*     */   
/*     */   protected static boolean isOverride(Type parentSignature, Type overrideSignature) {
/* 111 */     return Utils.getClass(parentSignature).isAssignableFrom(Utils.getClass(overrideSignature));
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\AbstractBridJRuntime.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */