package org.bridj;

import java.lang.reflect.Constructor;
import java.lang.reflect.Type;
import org.bridj.dyncall.DyncallLibrary;
import org.bridj.util.Utils;

interface CallIO {
  Object newInstance(long paramLong);
  
  long getDCStruct();
  
  long getPeer(Object paramObject);
  
  public static class Utils {
    public static CallIO createPointerCallIOToTargetType(Type targetType) {
      return new CallIO.GenericPointerHandler(targetType);
    }
    
    public static <EE extends Enum<EE>> CallIO createValuedEnumCallIO(final Class<EE> enumClass) {
      return new CallIO() {
          public Object newInstance(long value) {
            return FlagSet.fromValue(value, enumClass, new Enum[0]);
          }
          
          public long getDCStruct() {
            return 0L;
          }
          
          public long getPeer(Object o) {
            return 0L;
          }
        };
    }
    
    public static CallIO createPointerCallIO(Type type) {
      return createPointerCallIO(Utils.getClass(type), type);
    }
    
    public static CallIO createPointerCallIO(Class<?> cl, Type type) {
      if (cl == Pointer.class)
        return createPointerCallIOToTargetType(Utils.getUniqueParameterizedTypeParameter(type)); 
      assert TypedPointer.class.isAssignableFrom(cl);
      return new CallIO.TypedPointerIO((Class)cl);
    }
  }
  
  public static class TypedPointerIO implements CallIO {
    Class<? extends TypedPointer> type;
    
    Constructor<?> constructor;
    
    public TypedPointerIO(Class<? extends TypedPointer> type) {
      this.type = type;
      try {
        this.constructor = type.getConstructor(new Class[] { long.class });
      } catch (Exception ex) {
        throw new RuntimeException("Failed to create " + CallIO.class.getName() + " for type " + type.getName(), ex);
      } 
    }
    
    public Pointer<?> newInstance(long address) {
      try {
        return (address == 0L) ? null : (Pointer)this.constructor.newInstance(new Object[] { Long.valueOf(address) });
      } catch (Exception ex) {
        throw new RuntimeException("Failed to instantiate pointer of type " + this.type.getName(), ex);
      } 
    }
    
    public long getDCStruct() {
      return 0L;
    }
    
    public long getPeer(Object o) {
      return Pointer.getPeer((Pointer)o);
    }
  }
  
  public static class NativeObjectHandler implements CallIO {
    final Class<? extends NativeObject> nativeClass;
    
    final Type nativeType;
    
    final Pointer<DyncallLibrary.DCstruct> pStruct;
    
    public NativeObjectHandler(Class<? extends NativeObject> type, Type t, Pointer<DyncallLibrary.DCstruct> pStruct) {
      this.nativeClass = type;
      this.nativeType = t;
      this.pStruct = pStruct;
    }
    
    public NativeObject newInstance(long address) {
      return Pointer.pointerToAddress(address).getNativeObject((Class)this.nativeClass);
    }
    
    public long getDCStruct() {
      return Pointer.getPeer(this.pStruct);
    }
    
    public long getPeer(Object o) {
      return Pointer.getAddress((NativeObject)o, this.nativeClass);
    }
  }
  
  public static final class GenericPointerHandler implements CallIO {
    private final Type targetType;
    
    private final PointerIO pointerIO;
    
    public GenericPointerHandler(Type targetType) {
      this.targetType = targetType;
      this.pointerIO = PointerIO.getInstance(targetType);
    }
    
    public Pointer<?> newInstance(long address) {
      return Pointer.pointerToAddress(address, this.pointerIO);
    }
    
    public long getDCStruct() {
      return 0L;
    }
    
    public long getPeer(Object o) {
      return Pointer.getPeer((Pointer)o);
    }
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\CallIO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */