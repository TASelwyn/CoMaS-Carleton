package org.bridj.objc;

import org.bridj.BridJ;
import org.bridj.NativeObject;
import org.bridj.Pointer;
import org.bridj.ann.Runtime;

@Runtime(ObjectiveCRuntime.class)
public class ObjCObject extends NativeObject {
  ObjCObject type;
  
  static {
    BridJ.register();
  }
  
  public ObjCObject(Pointer<? extends NativeObject> peer) {
    super(peer, new Object[0]);
  }
  
  public ObjCObject() {}
  
  public ObjCObject(int constructorId, Object... args) {
    super(constructorId, args);
  }
  
  public String toString() {
    Pointer<NSString> p = description();
    if (p == null)
      p = stringValue(); 
    return ((NSString)p.get()).toString();
  }
  
  public boolean equals(Object o) {
    if (!(o instanceof ObjCObject))
      return false; 
    Pointer<ObjCObject> p = Pointer.getPointer((ObjCObject)o);
    return isEqual(p);
  }
  
  public int hashCode() {
    return hash();
  }
  
  public native Pointer<ObjCObject> init();
  
  public native Pointer<NSString> stringValue();
  
  public native Pointer<NSString> description();
  
  public native int hash();
  
  public native boolean isEqual(Pointer<? extends ObjCObject> paramPointer);
  
  public native boolean isKindOf(Pointer<? extends ObjCObject> paramPointer);
  
  public native boolean isMemberOf(Pointer<? extends ObjCObject> paramPointer);
  
  public native boolean isKindOfClassNamed(Pointer<Byte> paramPointer);
  
  public native boolean isMemberOfClassNamed(Pointer<Byte> paramPointer);
  
  public native boolean respondsTo(SEL paramSEL);
  
  public native IMP methodFor(SEL paramSEL);
  
  public native Pointer<?> perform(SEL paramSEL);
  
  public native Pointer<?> perform$with(SEL paramSEL, Pointer<?> paramPointer);
  
  public native Pointer<?> perform$with$with(SEL paramSEL, Pointer<?> paramPointer1, Pointer<?> paramPointer2);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\objc\ObjCObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */