package org.bridj.objc;

import java.nio.charset.Charset;
import org.bridj.BridJ;
import org.bridj.CRuntime;
import org.bridj.Pointer;
import org.bridj.ann.Library;
import org.bridj.ann.Ptr;
import org.bridj.ann.Runtime;

@Library("Foundation")
@Runtime(CRuntime.class)
public class FoundationLibrary {
  public static final int kCFStringEncodingASCII = 1536;
  
  public static final int kCFStringEncodingUnicode = 256;
  
  public static final int kCFStringEncodingUTF8 = 134217984;
  
  static {
    BridJ.register();
  }
  
  public static Pointer<NSString> pointerToNSString(String s) {
    Pointer<Byte> p = Pointer.pointerToString(s, Pointer.StringType.C, Charset.forName("utf-8"));
    assert p != null;
    Pointer<NSString> ps = CFStringCreateWithBytes(null, p, p.getValidBytes() - 1L, 134217984, false);
    assert ps != null;
    return ps;
  }
  
  public static native Pointer<NSString> CFStringCreateWithBytes(Pointer<?> paramPointer, Pointer<Byte> paramPointer1, @Ptr long paramLong, int paramInt, boolean paramBoolean);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\objc\FoundationLibrary.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */