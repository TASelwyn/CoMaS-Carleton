package org.bridj.objc;

import org.bridj.Pointer;
import org.bridj.TypedPointer;

public class SEL extends TypedPointer {
  protected volatile String name;
  
  public SEL(long peer) {
    super(peer);
  }
  
  public SEL(Pointer<?> ptr) {
    super(ptr);
  }
  
  public static SEL valueOf(String name) {
    return ObjectiveCRuntime.sel_registerName(pointerToCString(name));
  }
  
  public String getName() {
    if (this.name == null)
      this.name = ObjectiveCRuntime.sel_getName(this).getCString(); 
    return this.name;
  }
  
  public String toString() {
    return "@selector(" + getName() + ")";
  }
  
  public boolean equals(Object o) {
    if (!(o instanceof SEL))
      return false; 
    return getName().equals(((SEL)o).getName());
  }
  
  public int hashCode() {
    return getName().hashCode();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\objc\SEL.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */