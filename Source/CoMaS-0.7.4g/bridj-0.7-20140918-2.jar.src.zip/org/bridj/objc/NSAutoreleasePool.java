package org.bridj.objc;

import org.bridj.BridJ;
import org.bridj.Pointer;
import org.bridj.ann.Library;

@Library("Foundation")
public class NSAutoreleasePool extends NSObject {
  public static native Pointer<NSAutoreleasePool> new_();
  
  public native void drain();
  
  static {
    BridJ.register();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\objc\NSAutoreleasePool.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */