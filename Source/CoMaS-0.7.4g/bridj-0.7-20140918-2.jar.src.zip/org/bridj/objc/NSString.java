/*    */ package org.bridj.objc;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ import org.bridj.Pointer;
/*    */ import org.bridj.ann.Library;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Library("Foundation")
/*    */ public class NSString
/*    */   extends NSObject
/*    */ {
/*    */   public native int length();
/*    */   
/*    */   public native boolean isAbsolutePath();
/*    */   
/*    */   public native Pointer<Byte> UTF8String();
/*    */   
/*    */   public NSString() {}
/*    */   
/*    */   public NSString(String s) {
/* 53 */     super((Pointer)FoundationLibrary.pointerToNSString(s));
/*    */   }
/*    */   
/*    */   public String toString() {
/* 57 */     return UTF8String().getString(Pointer.StringType.C, Charset.forName("utf-8"));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 61 */     return toString().hashCode();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static NSString valueOf(String s) {
/* 72 */     return (NSString)FoundationLibrary.pointerToNSString(s).get();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\objc\NSString.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */