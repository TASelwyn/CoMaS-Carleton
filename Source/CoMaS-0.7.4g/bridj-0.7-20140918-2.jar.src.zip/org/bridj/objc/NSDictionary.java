/*     */ package org.bridj.objc;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.bridj.BridJ;
/*     */ import org.bridj.Pointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NSDictionary
/*     */   extends NSObject
/*     */ {
/*     */   static {
/*  47 */     BridJ.register();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Pointer<NSDictionary> pointerToNSDictionary(Map<String, NSObject> map) {
/*  70 */     int n = map.size();
/*  71 */     Pointer<Pointer<NSObject>> objects = Pointer.allocatePointers(NSObject.class, n);
/*  72 */     Pointer<Pointer<NSObject>> keys = Pointer.allocatePointers(NSObject.class, n);
/*     */     
/*  74 */     int i = 0;
/*  75 */     for (Map.Entry<String, NSObject> e : map.entrySet()) {
/*  76 */       keys.set(i, FoundationLibrary.pointerToNSString(e.getKey()));
/*  77 */       objects.set(i, Pointer.getPointer(e.getValue()));
/*  78 */       i++;
/*     */     } 
/*     */     
/*  81 */     return dictionaryWithObjects_forKeys_count(objects, keys, n);
/*     */   }
/*     */   
/*     */   public static NSDictionary valueOf(Map<String, NSObject> map) {
/*  85 */     return (NSDictionary)pointerToNSDictionary(map).get();
/*     */   }
/*     */   
/*     */   public Map<String, NSObject> toMap() {
/*  89 */     int n = count();
/*  90 */     Pointer<Pointer<NSObject>> objects = Pointer.allocatePointers(NSObject.class, n);
/*  91 */     Pointer<Pointer<NSString>> keys = Pointer.allocatePointers(NSString.class, n);
/*     */     
/*  93 */     getObjects_andKeys(objects, (Pointer)keys);
/*     */     
/*  95 */     Map<String, NSObject> ret = new HashMap<String, NSObject>();
/*  96 */     for (int i = 0; i < n; i++) {
/*  97 */       Pointer<NSString> key = (Pointer<NSString>)keys.get(i);
/*  98 */       Pointer<NSObject> value = (Pointer<NSObject>)objects.get(i);
/*     */       
/* 100 */       ret.put(((NSString)key.get()).toString(), (value == null) ? null : (NSObject)value.get());
/*     */     } 
/* 102 */     return ret;
/*     */   }
/*     */   
/*     */   public native Pointer<NSObject> valueForKey(Pointer<NSString> paramPointer);
/*     */   
/*     */   public native Pointer<NSObject> objectForKey(Pointer<NSObject> paramPointer);
/*     */   
/*     */   public native int count();
/*     */   
/*     */   public native void getObjects_andKeys(Pointer<Pointer<NSObject>> paramPointer1, Pointer<Pointer<NSObject>> paramPointer2);
/*     */   
/*     */   public static native Pointer<NSDictionary> dictionaryWithContentsOfFile(Pointer<NSString> paramPointer);
/*     */   
/*     */   public static native Pointer<NSDictionary> dictionaryWithObjects_forKeys_count(Pointer<Pointer<NSObject>> paramPointer1, Pointer<Pointer<NSObject>> paramPointer2, int paramInt);
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\objc\NSDictionary.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */