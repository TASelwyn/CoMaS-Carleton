package org.bridj.objc;

import org.bridj.BridJ;
import org.bridj.Pointer;
import org.bridj.ann.Library;
import org.bridj.ann.Ptr;

@Library("Foundation")
public class NSMethodSignature extends NSObject {
  public static native Pointer<NSMethodSignature> signatureWithObjCTypes(Pointer<Byte> paramPointer);
  
  public native Pointer<Byte> methodReturnType();
  
  @Ptr
  public native long numberOfArguments();
  
  public native boolean isOneway();
  
  public native Pointer<Byte> getArgumentTypeAtIndex(@Ptr long paramLong);
  
  @Ptr
  public native long frameLength();
  
  static {
    BridJ.register();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\objc\NSMethodSignature.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */