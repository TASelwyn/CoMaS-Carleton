/*     */ package org.bridj.objc;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.bridj.BridJ;
/*     */ import org.bridj.NativeObject;
/*     */ import org.bridj.Pointer;
/*     */ import org.bridj.PointerIO;
/*     */ import org.bridj.util.Pair;
/*     */ import org.bridj.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjCProxy
/*     */   extends ObjCObject
/*     */ {
/*  46 */   final Map<SEL, Pair<NSMethodSignature, Method>> signatures = new HashMap<SEL, Pair<NSMethodSignature, Method>>();
/*     */   final Object invocationTarget;
/*     */   static final String PROXY_OBJC_CLASS_NAME = "ObjCProxy";
/*     */   
/*     */   protected ObjCProxy() {
/*  51 */     super((Pointer<? extends NativeObject>)null);
/*  52 */     this.peer = ObjCJNI.createObjCProxyPeer(this);
/*  53 */     assert getClass() != ObjCProxy.class;
/*  54 */     this.invocationTarget = this;
/*     */   }
/*     */   
/*     */   public ObjCProxy(Object invocationTarget) {
/*  58 */     super((Pointer<? extends NativeObject>)null);
/*  59 */     this.peer = ObjCJNI.createObjCProxyPeer(this);
/*  60 */     assert invocationTarget != null;
/*  61 */     this.invocationTarget = invocationTarget;
/*     */   }
/*     */   
/*     */   public void addProtocol(String name) throws ClassNotFoundException {
/*  65 */     Pointer<? extends ObjCObject> protocol = ObjectiveCRuntime.objc_getProtocol(Pointer.pointerToCString(name));
/*  66 */     if (protocol == null) {
/*  67 */       throw new ClassNotFoundException("Protocol " + name + " not found !");
/*     */     }
/*  69 */     Pointer<? extends ObjCObject> cls = ObjectiveCRuntime.getObjCClass("ObjCProxy");
/*  70 */     if (!ObjectiveCRuntime.class_addProtocol(cls, protocol)) {
/*  71 */       throw new RuntimeException("Failed to add protocol " + name + " to class " + "ObjCProxy");
/*     */     }
/*     */   }
/*     */   
/*     */   public Object getInvocationTarget() {
/*  76 */     return this.invocationTarget;
/*     */   }
/*     */   
/*     */   public Pointer<NSMethodSignature> methodSignatureForSelector(SEL sel) {
/*  80 */     Pair<NSMethodSignature, Method> sig = getMethodAndSignature(sel);
/*  81 */     return (sig == null) ? null : Pointer.getPointer((NativeObject)sig.getFirst());
/*     */   }
/*     */   
/*     */   public synchronized Pair<NSMethodSignature, Method> getMethodAndSignature(SEL sel) {
/*  85 */     Pair<NSMethodSignature, Method> sig = this.signatures.get(sel);
/*  86 */     if (sig == null) {
/*     */       try {
/*  88 */         sig = computeMethodAndSignature(sel);
/*  89 */         if (sig != null) {
/*  90 */           this.signatures.put(sel, sig);
/*     */         }
/*  92 */       } catch (Throwable th) {
/*  93 */         BridJ.error("Failed to compute Objective-C signature for selector " + sel + ": " + th, th);
/*     */       } 
/*     */     }
/*  96 */     return sig;
/*     */   }
/*     */   
/*     */   Pair<NSMethodSignature, Method> computeMethodAndSignature(SEL sel) {
/* 100 */     String name = sel.getName();
/* 101 */     ObjectiveCRuntime rt = ObjectiveCRuntime.getInstance();
/* 102 */     for (Method method : this.invocationTarget.getClass().getMethods()) {
/* 103 */       String msel = rt.getSelector(method);
/*     */       
/* 105 */       if (msel.equals(name)) {
/* 106 */         String sig = rt.getMethodSignature(method);
/* 107 */         if (BridJ.debug) {
/* 108 */           BridJ.info("Objective-C signature for method " + method + " = '" + sig + "'");
/*     */         }
/* 110 */         NSMethodSignature ms = (NSMethodSignature)NSMethodSignature.signatureWithObjCTypes(Pointer.pointerToCString(sig)).get();
/* 111 */         long nArgs = ms.numberOfArguments() - 2L;
/* 112 */         if (nArgs != (method.getParameterTypes()).length) {
/* 113 */           throw new RuntimeException("Bad method signature (mismatching arg types) : '" + sig + "' for " + method);
/*     */         }
/* 115 */         return new Pair(ms, method);
/*     */       } 
/*     */     } 
/*     */     
/* 119 */     BridJ.error("Missing method for " + sel + " in class " + classHierarchyToString(getInvocationTarget().getClass()));
/*     */     
/* 121 */     return null;
/*     */   }
/*     */   
/*     */   static String classHierarchyToString(Class c) {
/* 125 */     String s = Utils.toString(c);
/* 126 */     Type p = c.getGenericSuperclass();
/* 127 */     while (p != null && p != Object.class && p != ObjCProxy.class) {
/* 128 */       s = s + " extends " + Utils.toString(p);
/* 129 */       p = Utils.getClass(p).getGenericSuperclass();
/*     */     } 
/* 131 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void forwardInvocation(Pointer<NSInvocation> pInvocation) {
/* 180 */     NSInvocation invocation = (NSInvocation)pInvocation.get();
/* 181 */     SEL sel = invocation.selector();
/* 182 */     Pair<NSMethodSignature, Method> sigMet = getMethodAndSignature(sel);
/* 183 */     NSMethodSignature sig = (NSMethodSignature)sigMet.getFirst();
/* 184 */     Method method = (Method)sigMet.getSecond();
/*     */ 
/*     */     
/* 187 */     Type[] paramTypes = method.getGenericParameterTypes();
/* 188 */     int nArgs = paramTypes.length;
/* 189 */     Object[] args = new Object[nArgs];
/* 190 */     for (int i = 0; i < nArgs; i++) {
/* 191 */       Type paramType = paramTypes[i];
/* 192 */       PointerIO<?> paramIO = PointerIO.getInstance(paramType);
/* 193 */       Pointer<?> pArg = Pointer.allocate(paramIO);
/* 194 */       invocation.getArgument_atIndex(pArg, (i + 2));
/* 195 */       Object arg = pArg.get();
/* 196 */       args[i] = arg;
/*     */     } 
/*     */     try {
/* 199 */       method.setAccessible(true);
/* 200 */       Object ret = method.invoke(getInvocationTarget(), args);
/*     */       
/* 202 */       Type returnType = method.getGenericReturnType();
/* 203 */       if (returnType == void.class) {
/* 204 */         assert ret == null;
/*     */       } else {
/* 206 */         PointerIO<?> returnIO = PointerIO.getInstance(returnType);
/* 207 */         Pointer<Object> pRet = Pointer.allocate(returnIO);
/* 208 */         pRet.set(ret);
/* 209 */         invocation.setReturnValue(pRet);
/*     */       } 
/* 211 */     } catch (Throwable ex) {
/* 212 */       throw new RuntimeException("Failed to forward invocation from Objective-C to Java invocation target " + getInvocationTarget() + " for method " + method + " : " + ex, ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\objc\ObjCProxy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */