package org.bridj;

import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Field;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import org.bridj.ann.Alignment;
import org.bridj.ann.Array;
import org.bridj.ann.Bits;
import org.bridj.ann.CLong;
import org.bridj.ann.Field;
import org.bridj.ann.Ptr;
import org.bridj.ann.Union;
import org.bridj.util.AnnotationUtils;

class StructFieldDeclaration {
  final StructFieldDescription desc = new StructFieldDescription();
  
  Method setter;
  
  long index = -1L;
  
  long unionWith = -1L;
  
  Class<?> valueClass;
  
  Class<?> declaringClass;
  
  public String toString() {
    return this.desc.name + " (index = " + this.index + ((this.unionWith < 0L) ? "" : (", unionWith = " + this.unionWith)) + ", desc = " + this.desc + ")";
  }
  
  protected static boolean acceptFieldGetter(Member member, boolean getter) {
    if (member instanceof Method && (((Method)member).getParameterTypes()).length != (getter ? 0 : 1))
      return false; 
    if (((AnnotatedElement)member).getAnnotation(Field.class) == null)
      return false; 
    int modifiers = member.getModifiers();
    return !Modifier.isStatic(modifiers);
  }
  
  protected static List<StructFieldDeclaration> listFields(Class<?> structClass) {
    List<StructFieldDeclaration> list = new ArrayList<StructFieldDeclaration>();
    for (Method method : structClass.getMethods()) {
      if (acceptFieldGetter(method, true)) {
        StructFieldDeclaration io = fromGetter(method);
        try {
          Method setter = structClass.getMethod(method.getName(), new Class[] { io.valueClass });
          if (acceptFieldGetter(setter, false))
            io.setter = setter; 
        } catch (Exception ex) {}
        if (io != null)
          list.add(io); 
      } 
    } 
    int nFieldFields = 0;
    for (Field field : structClass.getFields()) {
      if (acceptFieldGetter(field, true)) {
        StructFieldDeclaration io = fromField(field);
        if (io != null) {
          list.add(io);
          nFieldFields++;
        } 
      } 
    } 
    if (nFieldFields > 0)
      BridJ.warning("Struct " + structClass.getName() + " has " + nFieldFields + " struct fields implemented as Java fields, which won't give the best performance and might require counter-intuitive calls to BridJ.readFromNative / .writeToNative. Please consider using JNAerator to generate your struct instead."); 
    return list;
  }
  
  protected static StructFieldDeclaration fromField(Field getter) {
    StructFieldDeclaration field = fromMember(getter);
    field.desc.field = getter;
    field.desc.valueType = getter.getGenericType();
    field.valueClass = getter.getType();
    return field;
  }
  
  protected static StructFieldDeclaration fromGetter(Method getter) {
    StructFieldDeclaration field = fromMember(getter);
    field.desc.getter = getter;
    field.desc.valueType = getter.getGenericReturnType();
    field.valueClass = getter.getReturnType();
    return field;
  }
  
  private static StructFieldDeclaration fromMember(Member member) {
    StructFieldDeclaration field = new StructFieldDeclaration();
    field.declaringClass = member.getDeclaringClass();
    String name = member.getName();
    if (name.matches("get[A-Z].*"))
      name = Character.toLowerCase(name.charAt(3)) + name.substring(4); 
    field.desc.name = name;
    AnnotatedElement getter = (AnnotatedElement)member;
    Field fil = getter.<Field>getAnnotation(Field.class);
    Bits bits = getter.<Bits>getAnnotation(Bits.class);
    Alignment alignment = getter.<Alignment>getAnnotation(Alignment.class);
    Array arr = getter.<Array>getAnnotation(Array.class);
    if (fil != null) {
      field.index = fil.value();
      field.unionWith = fil.unionWith();
    } 
    if (field.unionWith < 0L && field.declaringClass.getAnnotation(Union.class) != null)
      field.unionWith = 0L; 
    if (bits != null)
      field.desc.bitLength = bits.value(); 
    if (alignment != null)
      field.desc.alignment = alignment.value(); 
    if (arr != null) {
      long length = 1L;
      for (long dim : arr.value())
        length *= dim; 
      field.desc.arrayLength = length;
      field.desc.isArray = true;
    } 
    field.desc.isCLong = AnnotationUtils.isAnnotationPresent(CLong.class, getter, new java.lang.annotation.Annotation[0]);
    field.desc.isSizeT = AnnotationUtils.isAnnotationPresent(Ptr.class, getter, new java.lang.annotation.Annotation[0]);
    return field;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\StructFieldDeclaration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */