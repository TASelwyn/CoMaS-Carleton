/*     */ package org.bridj;
/*     */ 
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.bridj.ann.Alignment;
/*     */ import org.bridj.ann.Array;
/*     */ import org.bridj.ann.Bits;
/*     */ import org.bridj.ann.CLong;
/*     */ import org.bridj.ann.Field;
/*     */ import org.bridj.ann.Ptr;
/*     */ import org.bridj.ann.Union;
/*     */ import org.bridj.util.AnnotationUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StructFieldDeclaration
/*     */ {
/*  48 */   final StructFieldDescription desc = new StructFieldDescription();
/*     */   Method setter;
/*  50 */   long index = -1L; long unionWith = -1L;
/*     */   
/*     */   Class<?> valueClass;
/*     */   Class<?> declaringClass;
/*     */   
/*     */   public String toString() {
/*  56 */     return this.desc.name + " (index = " + this.index + ((this.unionWith < 0L) ? "" : (", unionWith = " + this.unionWith)) + ", desc = " + this.desc + ")";
/*     */   }
/*     */   
/*     */   protected static boolean acceptFieldGetter(Member member, boolean getter) {
/*  60 */     if (member instanceof Method && (((Method)member).getParameterTypes()).length != (getter ? 0 : 1)) {
/*  61 */       return false;
/*     */     }
/*     */     
/*  64 */     if (((AnnotatedElement)member).getAnnotation(Field.class) == null) {
/*  65 */       return false;
/*     */     }
/*     */     
/*  68 */     int modifiers = member.getModifiers();
/*     */     
/*  70 */     return !Modifier.isStatic(modifiers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static List<StructFieldDeclaration> listFields(Class<?> structClass) {
/*  77 */     List<StructFieldDeclaration> list = new ArrayList<StructFieldDeclaration>();
/*  78 */     for (Method method : structClass.getMethods()) {
/*  79 */       if (acceptFieldGetter(method, true)) {
/*  80 */         StructFieldDeclaration io = fromGetter(method);
/*     */         try {
/*  82 */           Method setter = structClass.getMethod(method.getName(), new Class[] { io.valueClass });
/*  83 */           if (acceptFieldGetter(setter, false)) {
/*  84 */             io.setter = setter;
/*     */           }
/*  86 */         } catch (Exception ex) {}
/*     */ 
/*     */         
/*  89 */         if (io != null) {
/*  90 */           list.add(io);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  95 */     int nFieldFields = 0;
/*  96 */     for (Field field : structClass.getFields()) {
/*  97 */       if (acceptFieldGetter(field, true)) {
/*  98 */         StructFieldDeclaration io = fromField(field);
/*  99 */         if (io != null) {
/* 100 */           list.add(io);
/* 101 */           nFieldFields++;
/*     */         } 
/*     */       } 
/*     */     } 
/* 105 */     if (nFieldFields > 0) {
/* 106 */       BridJ.warning("Struct " + structClass.getName() + " has " + nFieldFields + " struct fields implemented as Java fields, which won't give the best performance and might require counter-intuitive calls to BridJ.readFromNative / .writeToNative. Please consider using JNAerator to generate your struct instead.");
/*     */     }
/*     */     
/* 109 */     return list;
/*     */   }
/*     */   
/*     */   protected static StructFieldDeclaration fromField(Field getter) {
/* 113 */     StructFieldDeclaration field = fromMember(getter);
/* 114 */     field.desc.field = getter;
/* 115 */     field.desc.valueType = getter.getGenericType();
/* 116 */     field.valueClass = getter.getType();
/* 117 */     return field;
/*     */   }
/*     */   
/*     */   protected static StructFieldDeclaration fromGetter(Method getter) {
/* 121 */     StructFieldDeclaration field = fromMember(getter);
/* 122 */     field.desc.getter = getter;
/* 123 */     field.desc.valueType = getter.getGenericReturnType();
/* 124 */     field.valueClass = getter.getReturnType();
/* 125 */     return field;
/*     */   }
/*     */   
/*     */   private static StructFieldDeclaration fromMember(Member member) {
/* 129 */     StructFieldDeclaration field = new StructFieldDeclaration();
/* 130 */     field.declaringClass = member.getDeclaringClass();
/*     */     
/* 132 */     String name = member.getName();
/* 133 */     if (name.matches("get[A-Z].*")) {
/* 134 */       name = Character.toLowerCase(name.charAt(3)) + name.substring(4);
/*     */     }
/*     */     
/* 137 */     field.desc.name = name;
/*     */     
/* 139 */     AnnotatedElement getter = (AnnotatedElement)member;
/* 140 */     Field fil = getter.<Field>getAnnotation(Field.class);
/* 141 */     Bits bits = getter.<Bits>getAnnotation(Bits.class);
/* 142 */     Alignment alignment = getter.<Alignment>getAnnotation(Alignment.class);
/* 143 */     Array arr = getter.<Array>getAnnotation(Array.class);
/* 144 */     if (fil != null) {
/* 145 */       field.index = fil.value();
/*     */       
/* 147 */       field.unionWith = fil.unionWith();
/*     */     } 
/* 149 */     if (field.unionWith < 0L && field.declaringClass.getAnnotation(Union.class) != null) {
/* 150 */       field.unionWith = 0L;
/*     */     }
/*     */     
/* 153 */     if (bits != null) {
/* 154 */       field.desc.bitLength = bits.value();
/*     */     }
/* 156 */     if (alignment != null) {
/* 157 */       field.desc.alignment = alignment.value();
/*     */     }
/* 159 */     if (arr != null) {
/* 160 */       long length = 1L;
/* 161 */       for (long dim : arr.value()) {
/* 162 */         length *= dim;
/*     */       }
/* 164 */       field.desc.arrayLength = length;
/* 165 */       field.desc.isArray = true;
/*     */     } 
/* 167 */     field.desc.isCLong = AnnotationUtils.isAnnotationPresent(CLong.class, getter, new java.lang.annotation.Annotation[0]);
/* 168 */     field.desc.isSizeT = AnnotationUtils.isAnnotationPresent(Ptr.class, getter, new java.lang.annotation.Annotation[0]);
/* 169 */     return field;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\StructFieldDeclaration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */