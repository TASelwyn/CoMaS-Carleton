/*      */ package org.bridj;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.lang.reflect.AnnotatedElement;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Type;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.Stack;
/*      */ import java.util.WeakHashMap;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import org.bridj.ann.Library;
/*      */ import org.bridj.ann.Runtime;
/*      */ import org.bridj.demangling.Demangler;
/*      */ import org.bridj.util.ASMUtils;
/*      */ import org.bridj.util.AnnotationUtils;
/*      */ import org.bridj.util.ClassDefiner;
/*      */ import org.bridj.util.StringUtils;
/*      */ import org.bridj.util.Utils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BridJ
/*      */ {
/*   94 */   static final Map<AnnotatedElement, NativeLibrary> librariesByClass = new HashMap<AnnotatedElement, NativeLibrary>();
/*   95 */   static final Map<String, File> librariesFilesByName = new HashMap<String, File>();
/*   96 */   static final Map<File, NativeLibrary> librariesByFile = new HashMap<File, NativeLibrary>();
/*   97 */   private static NativeEntities orphanEntities = new NativeEntities();
/*   98 */   static final Map<Class<?>, BridJRuntime> classRuntimes = new HashMap<Class<?>, BridJRuntime>();
/*   99 */   static final Map<Long, NativeObject> strongNativeObjects = new HashMap<Long, NativeObject>();
/*  100 */   static final Map<Long, NativeObject> weakNativeObjects = new WeakHashMap<Long, NativeObject>();
/*      */   
/*      */   public static long sizeOf(Type type) {
/*  103 */     Class<?> c = Utils.getClass(type);
/*  104 */     if (c.isPrimitive())
/*  105 */       return StructUtils.primTypeLength(c); 
/*  106 */     if (Pointer.class.isAssignableFrom(c))
/*  107 */       return Pointer.SIZE; 
/*  108 */     if (c == CLong.class)
/*  109 */       return CLong.SIZE; 
/*  110 */     if (c == TimeT.class)
/*  111 */       return TimeT.SIZE; 
/*  112 */     if (c == SizeT.class)
/*  113 */       return SizeT.SIZE; 
/*  114 */     if (c == Integer.class || c == Float.class)
/*  115 */       return 4L; 
/*  116 */     if (c == Character.class || c == Short.class)
/*  117 */       return 2L; 
/*  118 */     if (c == Long.class || c == Double.class)
/*  119 */       return 8L; 
/*  120 */     if (c == Boolean.class || c == Byte.class)
/*  121 */       return 1L; 
/*  122 */     if (NativeObject.class.isAssignableFrom(c))
/*  123 */       return getRuntime(c).<NativeObject>getTypeInfo(type).sizeOf(); 
/*  124 */     if (IntValuedEnum.class.isAssignableFrom(c)) {
/*  125 */       return 4L;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  131 */     throw new RuntimeException("Unable to compute size of type " + Utils.toString(type));
/*      */   }
/*      */   
/*      */   static synchronized void registerNativeObject(NativeObject ob) {
/*  135 */     weakNativeObjects.put(Long.valueOf(Pointer.getAddress(ob, null)), ob);
/*      */   }
/*      */ 
/*      */   
/*      */   static synchronized NativeObject getNativeObject(long peer) {
/*  140 */     NativeObject ob = weakNativeObjects.get(Long.valueOf(peer));
/*  141 */     if (ob == null) {
/*  142 */       ob = strongNativeObjects.get(Long.valueOf(peer));
/*      */     }
/*  144 */     return ob;
/*      */   }
/*      */   
/*      */   static synchronized void unregisterNativeObject(NativeObject ob) {
/*  148 */     long peer = Pointer.getAddress(ob, null);
/*  149 */     weakNativeObjects.remove(Long.valueOf(peer));
/*  150 */     strongNativeObjects.remove(Long.valueOf(peer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized <T extends NativeObject> T protectFromGC(T ob) {
/*  160 */     long peer = Pointer.getAddress((NativeObject)ob, null);
/*  161 */     weakNativeObjects.remove(Long.valueOf(peer));
/*  162 */     strongNativeObjects.put(Long.valueOf(peer), (NativeObject)ob);
/*  163 */     return ob;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized <T extends NativeObject> T unprotectFromGC(T ob) {
/*  171 */     long peer = Pointer.getAddress((NativeObject)ob, null);
/*  172 */     if (strongNativeObjects.remove(Long.valueOf(peer)) != null) {
/*  173 */       weakNativeObjects.put(Long.valueOf(peer), (NativeObject)ob);
/*      */     }
/*  175 */     return ob;
/*      */   }
/*      */   
/*      */   public static void delete(NativeObject nativeObject) {
/*  179 */     unregisterNativeObject(nativeObject);
/*  180 */     Pointer.<NativeObject>getPointer(nativeObject, null).release();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void register() {
/*  196 */     StackTraceElement[] stackTrace = (new Exception()).getStackTrace();
/*  197 */     if (stackTrace.length < 2) {
/*  198 */       throw new RuntimeException("No useful stack trace : cannot register with register(), please use register(Class) instead.");
/*      */     }
/*  200 */     String name = stackTrace[1].getClassName();
/*      */     try {
/*  202 */       Class<?> type = Class.forName(name, false, Platform.getClassLoader());
/*  203 */       register(type);
/*  204 */     } catch (Exception ex) {
/*  205 */       throw new RuntimeException("Failed to register class " + name, ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Class<? extends T> subclassWithSynchronizedNativeMethods(Class<T> original) throws IOException {
/*  219 */     ClassDefiner classDefiner = ((CRuntime)getRuntimeByRuntimeClass(CRuntime.class)).getCallbackNativeImplementer();
/*  220 */     return ASMUtils.createSubclassWithSynchronizedNativeMethodsAndNoStaticFields(original, classDefiner);
/*      */   }
/*      */   
/*      */   enum CastingType
/*      */   {
/*  225 */     None, CastingNativeObject, CastingNativeObjectReturnType; }
/*      */   
/*  227 */   static ThreadLocal<Stack<CastingType>> currentlyCastingNativeObject = new ThreadLocal<Stack<CastingType>>()
/*      */     {
/*      */       protected Stack<BridJ.CastingType> initialValue() {
/*  230 */         Stack<BridJ.CastingType> s = new Stack<BridJ.CastingType>();
/*  231 */         s.push(BridJ.CastingType.None);
/*  232 */         return s;
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static boolean isCastingNativeObjectInCurrentThread() {
/*  240 */     return (((Stack<CastingType>)currentlyCastingNativeObject.get()).peek() != CastingType.None);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static boolean isCastingNativeObjectReturnTypeInCurrentThread() {
/*  245 */     return (((Stack<CastingType>)currentlyCastingNativeObject.get()).peek() == CastingType.CastingNativeObjectReturnType);
/*      */   }
/*  247 */   private static WeakHashMap<Long, NativeObject> knownNativeObjects = new WeakHashMap<Long, NativeObject>();
/*      */   
/*      */   public static synchronized <O extends NativeObject> void setJavaObjectFromNativePeer(long peer, O object) {
/*  250 */     if (object == null) {
/*  251 */       knownNativeObjects.remove(Long.valueOf(peer));
/*      */     } else {
/*  253 */       knownNativeObjects.put(Long.valueOf(peer), (NativeObject)object);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static synchronized Object getJavaObjectFromNativePeer(long peer) {
/*  258 */     return knownNativeObjects.get(Long.valueOf(peer));
/*      */   }
/*      */   
/*      */   private static <O extends NativeObject> O createNativeObjectFromPointer(Pointer<? super O> pointer, Type type, CastingType castingType) {
/*  262 */     Stack<CastingType> s = currentlyCastingNativeObject.get();
/*  263 */     s.push(castingType);
/*      */     try {
/*  265 */       BridJRuntime runtime = getRuntime(Utils.getClass(type));
/*  266 */       BridJRuntime.TypeInfo<O> typeInfo = getTypeInfo(runtime, type);
/*  267 */       O instance = typeInfo.cast(pointer);
/*  268 */       if (debug) {
/*  269 */         info("Created native object from pointer " + pointer);
/*      */       }
/*  271 */       return instance;
/*  272 */     } catch (Exception ex) {
/*  273 */       throw new RuntimeException("Failed to cast pointer to native object of type " + Utils.getClass(type).getName(), ex);
/*      */     } finally {
/*  275 */       s.pop();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static <O extends NativeObject> void copyNativeObjectToAddress(O value, Type type, Pointer<O> ptr) {
/*  280 */     BridJRuntime runtime = getRuntime(Utils.getClass(type));
/*  281 */     getTypeInfo(runtime, type).copyNativeObjectToAddress(value, ptr);
/*      */   }
/*      */   
/*      */   public static <O extends NativeObject> O createNativeObjectFromPointer(Pointer<? super O> pointer, Type type) {
/*  285 */     return createNativeObjectFromPointer(pointer, type, CastingType.CastingNativeObject);
/*      */   }
/*      */   
/*      */   public static <O extends NativeObject> O createNativeObjectFromReturnValuePointer(Pointer<? super O> pointer, Type type) {
/*  289 */     return createNativeObjectFromPointer(pointer, type, CastingType.CastingNativeObjectReturnType);
/*      */   }
/*  291 */   private static Map<Class<? extends BridJRuntime>, BridJRuntime> runtimes = new HashMap<Class<? extends BridJRuntime>, BridJRuntime>();
/*      */   
/*      */   public static synchronized <R extends BridJRuntime> R getRuntimeByRuntimeClass(Class<R> runtimeClass) {
/*  294 */     BridJRuntime bridJRuntime = runtimes.get(runtimeClass);
/*  295 */     if (bridJRuntime == null) {
/*      */       try {
/*  297 */         runtimes.put(runtimeClass, bridJRuntime = (BridJRuntime)runtimeClass.newInstance());
/*  298 */       } catch (Exception e) {
/*  299 */         throw new RuntimeException("Failed to instantiate runtime " + runtimeClass.getName(), e);
/*      */       } 
/*      */     }
/*      */     
/*  303 */     return (R)bridJRuntime;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<? extends BridJRuntime> getRuntimeClass(Class<?> type) {
/*      */     Class<CRuntime> clazz;
/*  312 */     Runtime runtimeAnn = (Runtime)AnnotationUtils.getInheritableAnnotation(Runtime.class, type, new java.lang.annotation.Annotation[0]);
/*  313 */     Class<? extends BridJRuntime> runtimeClass = null;
/*  314 */     if (runtimeAnn != null) {
/*  315 */       runtimeClass = runtimeAnn.value();
/*      */     } else {
/*  317 */       clazz = CRuntime.class;
/*      */     } 
/*      */     
/*  320 */     return (Class)clazz;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BridJRuntime getRuntime(Class<?> type) {
/*  329 */     synchronized (classRuntimes) {
/*  330 */       BridJRuntime runtime = classRuntimes.get(type);
/*  331 */       if (runtime == null) {
/*  332 */         Class<? extends BridJRuntime> runtimeClass = getRuntimeClass(type);
/*  333 */         runtime = getRuntimeByRuntimeClass((Class)runtimeClass);
/*  334 */         classRuntimes.put(type, runtime);
/*      */         
/*  336 */         if (veryVerbose) {
/*  337 */           info("Runtime for " + type.getName() + " : " + runtimeClass.getName());
/*      */         }
/*      */       } 
/*  340 */       return runtime;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BridJRuntime register(Class<?> type) {
/*  357 */     BridJRuntime runtime = getRuntime(type);
/*  358 */     if (runtime == null) {
/*  359 */       for (Class<?> child : type.getClasses()) {
/*  360 */         register(child);
/*      */       }
/*      */     } else {
/*  363 */       runtime.register(type);
/*      */     } 
/*  365 */     return runtime;
/*      */   }
/*      */   
/*      */   public static void unregister(Class<?> type) {
/*  369 */     BridJRuntime runtime = getRuntime(type);
/*  370 */     if (runtime == null) {
/*  371 */       for (Class<?> child : type.getClasses()) {
/*  372 */         register(child);
/*      */       }
/*      */     } else {
/*  375 */       runtime.unregister(type);
/*      */     } 
/*      */   }
/*  378 */   static Map<Type, BridJRuntime.TypeInfo<?>> typeInfos = new HashMap<Type, BridJRuntime.TypeInfo<?>>();
/*      */   
/*      */   static <T extends NativeObject> BridJRuntime.TypeInfo<T> getTypeInfo(BridJRuntime runtime, Type t) {
/*  381 */     synchronized (typeInfos) {
/*  382 */       BridJRuntime.TypeInfo<NativeObject> info = (BridJRuntime.TypeInfo)typeInfos.get(t);
/*  383 */       if (info == null) {
/*      */         
/*  385 */         info = runtime.getTypeInfo(t);
/*  386 */         typeInfos.put(t, info);
/*      */       } 
/*  388 */       return (BridJRuntime.TypeInfo)info;
/*      */     } 
/*      */   }
/*      */   
/*      */   enum Switch
/*      */   {
/*  394 */     Debug("bridj.debug", "BRIDJ_DEBUG", false, "Debug mode (implies high verbosity)"),
/*      */     
/*  396 */     DebugNeverFree("bridj.debug.neverFree", "BRIDJ_DEBUG_NEVER_FREE", false, "Never free allocated pointers (deprecated)"),
/*      */     
/*  398 */     DebugPointers("bridj.debug.pointers", "BRIDJ_DEBUG_POINTERS", false, "Trace pointer allocations & deallocations (to debug memory issues)"),
/*      */     
/*  400 */     DebugPointerReleases("bridj.debug.pointer.releases", "BRIDJ_DEBUG_POINTER_RELEASES", false, "Prevent double releases of pointers and keep the trace of their first release (to debug memory issues)"),
/*      */     
/*  402 */     VeryVerbose("bridj.veryVerbose", "BRIDJ_VERY_VERBOSE", false, "Highly verbose mode"),
/*      */     
/*  404 */     Verbose("bridj.verbose", "BRIDJ_VERBOSE", false, "Verbose mode"),
/*      */     
/*  406 */     Quiet("bridj.quiet", "BRIDJ_QUIET", false, "Quiet mode"),
/*      */     
/*  408 */     CachePointers("bridj.cache.pointers", "BRIDJ_CACHE_POINTERS", true, "Cache last recently used pointers in each thread"),
/*      */     
/*  410 */     AlignDouble("bridj.alignDouble", "BRIDJ_ALIGN_DOUBLE", false, "Align doubles on 8 bytes boundaries even on Linux 32 bits (see -malign-double GCC option)."),
/*      */     
/*  412 */     LogCalls("bridj.logCalls", "BRIDJ_LOG_CALLS", false, "Log each native call performed (or call from native to Java callback)"),
/*      */     
/*  414 */     Protected("bridj.protected", "BRIDJ_PROTECTED", false, "Protect all native calls (including memory accesses) against native crashes (disables assembly optimizations and adds quite some overhead)."),
/*      */     
/*  416 */     Destructors("bridj.destructors", "BRIDJ_DESTRUCTORS", true, "Enable destructors (in languages that support them, such as C++)"),
/*      */     
/*  418 */     Direct("bridj.direct", "BRIDJ_DIRECT", true, "Direct mode (uses optimized assembler glue when possible to speed up calls)"),
/*      */     
/*  420 */     StructsByValue("bridj.structsByValue", "BRIDJ_STRUCT_BY_VALUE", false, "Enable experimental support for structs-by-value arguments and return values for C/C++ functions and methods.");
/*      */     
/*      */     public final boolean enabled;
/*      */     
/*      */     public final boolean enabledByDefault;
/*      */     public final String propertyName;
/*      */     public final String envName;
/*      */     public final String description;
/*      */     
/*      */     Switch(String propertyName, String envName, boolean enabledByDefault, String description) {
/*  430 */       if (enabledByDefault) {
/*  431 */         this.enabled = (!"false".equals(System.getProperty(propertyName)) && !"0".equals(System.getenv(envName)));
/*      */       } else {
/*  433 */         this.enabled = ("true".equals(System.getProperty(propertyName)) || "1".equals(System.getenv(envName)));
/*      */       } 
/*      */       
/*  436 */       this.enabledByDefault = enabledByDefault;
/*  437 */       this.propertyName = propertyName;
/*  438 */       this.envName = envName;
/*  439 */       this.description = description;
/*      */     }
/*      */     
/*      */     public String getFullDescription() {
/*  443 */       return this.envName + " / " + this.propertyName + " (" + (this.enabledByDefault ? "enabled" : "disabled") + " by default) :\n\t" + this.description.replaceAll("\n", "\n\t");
/*      */     }
/*      */   }
/*      */   
/*      */   static {
/*  448 */     checkOptions();
/*      */   }
/*      */   
/*      */   static void checkOptions() {
/*  452 */     Set<String> props = new HashSet<String>(), envs = new HashSet<String>();
/*  453 */     for (Switch s : Switch.values()) {
/*  454 */       props.add(s.propertyName);
/*  455 */       envs.add(s.envName);
/*      */     } 
/*  457 */     boolean hasUnknown = false;
/*  458 */     for (String n : System.getenv().keySet()) {
/*  459 */       if (!n.startsWith("BRIDJ_") || envs.contains(n)) {
/*      */         continue;
/*      */       }
/*      */       
/*  463 */       if (n.endsWith("_LIBRARY")) {
/*      */         continue;
/*      */       }
/*      */       
/*  467 */       if (n.endsWith("_DEPENDENCIES")) {
/*      */         continue;
/*      */       }
/*      */       
/*  471 */       error("Unknown environment variable : " + n + "=\"" + System.getenv(n) + "\"");
/*  472 */       hasUnknown = true;
/*      */     } 
/*      */     
/*  475 */     for (Enumeration<String> e = (Enumeration)System.getProperties().propertyNames(); e.hasMoreElements(); ) {
/*  476 */       String n = e.nextElement();
/*  477 */       if (!n.startsWith("bridj.") || props.contains(n)) {
/*      */         continue;
/*      */       }
/*      */       
/*  481 */       if (n.endsWith(".library")) {
/*      */         continue;
/*      */       }
/*      */       
/*  485 */       if (n.endsWith(".dependencies")) {
/*      */         continue;
/*      */       }
/*      */       
/*  489 */       error("Unknown property : " + n + "=\"" + System.getProperty(n) + "\"");
/*  490 */       hasUnknown = true;
/*      */     } 
/*  492 */     if (hasUnknown) {
/*  493 */       StringBuilder b = new StringBuilder();
/*  494 */       b.append("Available options (ENVIRONMENT_VAR_NAME / javaPropertyName) :\n");
/*  495 */       for (Switch s : Switch.values()) {
/*  496 */         b.append(s.getFullDescription() + "\n");
/*      */       }
/*  498 */       error(b.toString());
/*      */     } 
/*      */   }
/*  501 */   public static final boolean debug = Switch.Debug.enabled;
/*  502 */   public static final boolean debugNeverFree = Switch.DebugNeverFree.enabled;
/*  503 */   public static final boolean debugPointers = Switch.DebugPointers.enabled;
/*  504 */   public static final boolean debugPointerReleases = (Switch.DebugPointerReleases.enabled || debugPointers);
/*  505 */   public static final boolean veryVerbose = Switch.VeryVerbose.enabled;
/*  506 */   public static final boolean verbose = (debug || veryVerbose || Switch.Verbose.enabled);
/*  507 */   public static final boolean quiet = Switch.Quiet.enabled;
/*  508 */   public static final boolean logCalls = Switch.LogCalls.enabled;
/*  509 */   public static final boolean protectedMode = Switch.Protected.enabled;
/*  510 */   public static final boolean enableDestructors = Switch.Destructors.enabled;
/*  511 */   public static final boolean alignDoubles = Switch.AlignDouble.enabled;
/*  512 */   public static final boolean cachePointers = Switch.CachePointers.enabled;
/*  513 */   static volatile int minLogLevelValue = (verbose ? Level.WARNING : Level.INFO).intValue(); static Logger logger;
/*      */   
/*      */   public static void setMinLogLevel(Level level) {
/*  516 */     minLogLevelValue = level.intValue();
/*      */   }
/*      */   
/*      */   static boolean shouldLog(Level level) {
/*  520 */     return (!quiet && (verbose || level.intValue() >= minLogLevelValue));
/*      */   }
/*      */ 
/*      */   
/*      */   static synchronized Logger getLogger() {
/*  525 */     if (logger == null) {
/*  526 */       logger = Logger.getLogger(BridJ.class.getName());
/*      */     }
/*  528 */     return logger;
/*      */   }
/*      */   
/*      */   public static boolean info(String message) {
/*  532 */     return info(message, null);
/*      */   }
/*      */   
/*      */   public static boolean info(String message, Throwable ex) {
/*  536 */     return log(Level.INFO, message, ex);
/*      */   }
/*      */   
/*      */   public static boolean debug(String message) {
/*  540 */     if (!debug) {
/*  541 */       return true;
/*      */     }
/*  543 */     return info(message, null);
/*      */   }
/*      */   
/*      */   public static boolean error(String message) {
/*  547 */     return error(message, null);
/*      */   }
/*      */   
/*      */   public static boolean error(String message, Throwable ex) {
/*  551 */     return log(Level.INFO, message, ex);
/*      */   }
/*      */   
/*      */   public static boolean warning(String message) {
/*  555 */     return warning(message, null);
/*      */   }
/*      */   
/*      */   public static boolean warning(String message, Throwable ex) {
/*  559 */     return log(Level.INFO, message, ex);
/*      */   }
/*      */   
/*      */   private static boolean log(Level level, String message, Throwable ex) {
/*  563 */     if (!shouldLog(level)) {
/*  564 */       return true;
/*      */     }
/*  566 */     getLogger().log(level, message, ex);
/*  567 */     return true;
/*      */   }
/*      */   
/*      */   static void logCall(Method m) {
/*  571 */     info("Calling method " + m);
/*      */   }
/*      */   
/*      */   public static synchronized NativeEntities getNativeEntities(AnnotatedElement type) throws IOException {
/*  575 */     NativeLibrary lib = getNativeLibrary(type);
/*  576 */     if (lib != null) {
/*  577 */       return lib.getNativeEntities();
/*      */     }
/*  579 */     return getOrphanEntities();
/*      */   }
/*      */   
/*      */   public static synchronized NativeLibrary getNativeLibrary(AnnotatedElement type) throws IOException {
/*  583 */     NativeLibrary lib = librariesByClass.get(type);
/*  584 */     if (lib == null) {
/*  585 */       Library libraryAnnotation = getLibrary(type);
/*  586 */       if (libraryAnnotation != null) {
/*  587 */         String libraryName = libraryAnnotation.value();
/*  588 */         String dependenciesEnv = getDependenciesEnv(libraryName);
/*  589 */         List<String> dependencies = libraryDependencies.get(libraryName);
/*  590 */         List<String> staticDependencies = Arrays.asList((dependenciesEnv == null) ? libraryAnnotation.dependencies() : dependenciesEnv.split(","));
/*      */         
/*  592 */         if (dependencies == null) {
/*  593 */           dependencies = staticDependencies;
/*      */         } else {
/*  595 */           dependencies.addAll(staticDependencies);
/*      */         } 
/*      */         
/*  598 */         for (String dependency : dependencies) {
/*  599 */           if (verbose) {
/*  600 */             info("Trying to load dependency '" + dependency + "' of '" + libraryName + "'");
/*      */           }
/*  602 */           NativeLibrary depLib = getNativeLibrary(dependency);
/*  603 */           if (depLib == null) {
/*  604 */             throw new RuntimeException("Failed to load dependency '" + dependency + "' of library '" + libraryName + "'");
/*      */           }
/*      */         } 
/*  607 */         lib = getNativeLibrary(libraryName);
/*  608 */         if (lib != null) {
/*  609 */           librariesByClass.put(type, lib);
/*      */         }
/*      */       } 
/*      */     } 
/*  613 */     return lib;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void releaseAll() {
/*  621 */     strongNativeObjects.clear();
/*  622 */     weakNativeObjects.clear();
/*  623 */     System.gc();
/*      */     
/*  625 */     for (NativeLibrary lib : librariesByFile.values()) {
/*  626 */       lib.release();
/*      */     }
/*  628 */     librariesByFile.clear();
/*  629 */     librariesByClass.clear();
/*  630 */     getOrphanEntities().release();
/*  631 */     System.gc();
/*      */   }
/*      */ 
/*      */   
/*      */   public static synchronized void releaseLibrary(String name) {
/*  636 */     File file = librariesFilesByName.remove(name);
/*  637 */     if (file != null) {
/*  638 */       releaseLibrary(file);
/*      */     }
/*      */   }
/*      */   
/*      */   public static synchronized void releaseLibrary(File library) {
/*  643 */     NativeLibrary lib = librariesByFile.remove(library);
/*  644 */     if (lib != null)
/*  645 */       lib.release(); 
/*      */   }
/*      */   
/*  648 */   static Map<String, NativeLibrary> libHandles = new HashMap<String, NativeLibrary>();
/*      */   static volatile List<String> nativeLibraryPaths;
/*  650 */   static List<String> additionalPaths = new ArrayList<String>();
/*      */   
/*      */   public static synchronized void addLibraryPath(String path) {
/*  653 */     additionalPaths.add(path);
/*  654 */     nativeLibraryPaths = null;
/*      */   }
/*      */   
/*      */   private static void addPathsFromEnv(List<String> out, String name) {
/*  658 */     String env = System.getenv(name);
/*  659 */     if (verbose) {
/*  660 */       info("Environment var " + name + " = " + env);
/*      */     }
/*  662 */     addPaths(out, env);
/*      */   }
/*      */   
/*      */   private static void addPathsFromProperty(List<String> out, String name) {
/*  666 */     String env = System.getProperty(name);
/*  667 */     if (verbose) {
/*  668 */       info("Property " + name + " = " + env);
/*      */     }
/*  670 */     addPaths(out, env);
/*      */   }
/*      */   
/*      */   private static void addPaths(List<String> out, String env) {
/*  674 */     if (env == null) {
/*      */       return;
/*      */     }
/*      */     
/*  678 */     String[] paths = env.split(File.pathSeparator);
/*  679 */     if (paths.length == 0) {
/*      */       return;
/*      */     }
/*  682 */     if (paths.length == 1) {
/*  683 */       out.add(paths[0]);
/*      */       return;
/*      */     } 
/*  686 */     out.addAll(Arrays.asList(paths));
/*      */   }
/*      */   
/*      */   static synchronized List<String> getNativeLibraryPaths() {
/*  690 */     if (nativeLibraryPaths == null) {
/*  691 */       nativeLibraryPaths = new ArrayList<String>();
/*  692 */       nativeLibraryPaths.addAll(additionalPaths);
/*  693 */       nativeLibraryPaths.add(null);
/*  694 */       nativeLibraryPaths.add(".");
/*      */       
/*  696 */       addPathsFromEnv(nativeLibraryPaths, "LD_LIBRARY_PATH");
/*  697 */       addPathsFromEnv(nativeLibraryPaths, "DYLD_LIBRARY_PATH");
/*  698 */       addPathsFromEnv(nativeLibraryPaths, "PATH");
/*  699 */       addPathsFromProperty(nativeLibraryPaths, "java.library.path");
/*  700 */       addPathsFromProperty(nativeLibraryPaths, "sun.boot.library.path");
/*  701 */       addPathsFromProperty(nativeLibraryPaths, "gnu.classpath.boot.library.path");
/*      */       
/*  703 */       File javaHome = new File(System.getProperty("java.home"));
/*  704 */       nativeLibraryPaths.add((new File(javaHome, "bin")).toString());
/*  705 */       if (Platform.isMacOSX()) {
/*  706 */         nativeLibraryPaths.add((new File(javaHome, "../Libraries")).toString());
/*      */       }
/*      */ 
/*      */       
/*  710 */       if (Platform.isUnix()) {
/*  711 */         String bits = Platform.is64Bits() ? "64" : "32";
/*  712 */         if (Platform.isLinux()) {
/*      */           
/*  714 */           String abi = Platform.isArm() ? "gnueabi" : "gnu";
/*  715 */           String multiArch = Platform.getMachine() + "-linux-" + abi;
/*  716 */           nativeLibraryPaths.add("/lib/" + multiArch);
/*  717 */           nativeLibraryPaths.add("/usr/lib/" + multiArch);
/*      */ 
/*      */           
/*  720 */           nativeLibraryPaths.add("/usr/lib" + bits);
/*  721 */           nativeLibraryPaths.add("/lib" + bits);
/*  722 */         } else if (Platform.isSolaris()) {
/*      */           
/*  724 */           nativeLibraryPaths.add("/usr/lib/" + bits);
/*  725 */           nativeLibraryPaths.add("/lib/" + bits);
/*      */         } 
/*      */         
/*  728 */         nativeLibraryPaths.add("/usr/lib");
/*  729 */         nativeLibraryPaths.add("/lib");
/*  730 */         nativeLibraryPaths.add("/usr/local/lib");
/*      */       } 
/*      */     } 
/*  733 */     return nativeLibraryPaths;
/*      */   }
/*  735 */   static Map<String, String> libraryActualNames = new HashMap<String, String>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void setNativeLibraryActualName(String name, String actualName) {
/*  747 */     libraryActualNames.put(name, actualName);
/*      */   }
/*  749 */   static Map<String, List<String>> libraryAliases = new HashMap<String, List<String>>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void addNativeLibraryAlias(String name, String alias) {
/*  762 */     List<String> list = libraryAliases.get(name);
/*  763 */     if (list == null) {
/*  764 */       libraryAliases.put(name, list = new ArrayList<String>());
/*      */     }
/*  766 */     if (!list.contains(alias))
/*  767 */       list.add(alias); 
/*      */   }
/*      */   
/*  770 */   static Map<String, List<String>> libraryDependencies = new HashMap<String, List<String>>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void addNativeLibraryDependencies(String name, String... dependencyNames) {
/*  780 */     List<String> list = libraryDependencies.get(name);
/*  781 */     if (list == null) {
/*  782 */       libraryDependencies.put(name, list = new ArrayList<String>());
/*      */     }
/*  784 */     for (String dependencyName : dependencyNames) {
/*  785 */       if (!list.contains(dependencyName))
/*  786 */         list.add(dependencyName); 
/*      */     } 
/*      */   }
/*      */   
/*  790 */   private static final Pattern numPat = Pattern.compile("\\b(\\d+)\\b");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static double parseVersion(String s) {
/*  796 */     Matcher m = numPat.matcher(s);
/*  797 */     double res = 0.0D, f = 1.0D;
/*  798 */     while (m.find()) {
/*  799 */       res += Integer.parseInt(m.group(1)) * f;
/*  800 */       f /= 1000.0D;
/*      */     } 
/*  802 */     return res;
/*      */   }
/*      */   
/*      */   static File findFileWithGreaterVersion(File dir, String[] files, String baseFileName) {
/*  806 */     Pattern versionPattern = Pattern.compile(Pattern.quote(baseFileName) + "((:?\\.\\d+)+)");
/*  807 */     double maxVersion = 0.0D;
/*  808 */     String maxVersionFile = null;
/*  809 */     for (String fileName : files) {
/*  810 */       Matcher m = versionPattern.matcher(fileName);
/*  811 */       if (m.matches()) {
/*  812 */         double version = parseVersion(m.group(1));
/*  813 */         if (maxVersionFile == null || version > maxVersion) {
/*  814 */           maxVersionFile = fileName;
/*  815 */           maxVersion = version;
/*      */         } 
/*      */       } 
/*      */     } 
/*  819 */     if (maxVersionFile == null) {
/*  820 */       return null;
/*      */     }
/*      */     
/*  823 */     return new File(dir, maxVersionFile);
/*      */   }
/*  825 */   static Map<String, File> nativeLibraryFiles = new HashMap<String, File>();
/*      */ 
/*      */   
/*      */   static Boolean directModeEnabled;
/*      */ 
/*      */ 
/*      */   
/*      */   public static File getNativeLibraryFile(String libraryName) {
/*  833 */     if (libraryName == null) {
/*  834 */       return null;
/*      */     }
/*      */     
/*      */     try {
/*  838 */       synchronized (nativeLibraryFiles) {
/*  839 */         File nativeLibraryFile = nativeLibraryFiles.get(libraryName);
/*  840 */         if (nativeLibraryFile == null) {
/*  841 */           nativeLibraryFiles.put(libraryName, nativeLibraryFile = findNativeLibraryFile(libraryName));
/*      */         }
/*  843 */         return nativeLibraryFile;
/*      */       } 
/*  845 */     } catch (Throwable th) {
/*  846 */       warning("Library not found : " + libraryName, debug ? th : null);
/*  847 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setNativeLibraryFile(String libraryName, File nativeLibraryFile) {
/*  855 */     if (libraryName == null) {
/*      */       return;
/*      */     }
/*      */     
/*  859 */     synchronized (nativeLibraryFiles) {
/*  860 */       nativeLibraryFiles.put(libraryName, nativeLibraryFile);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static String getLibraryEnv(String libraryName) {
/*  865 */     String env = System.getenv("BRIDJ_" + libraryName.toUpperCase() + "_LIBRARY");
/*  866 */     if (env == null) {
/*  867 */       env = System.getProperty("bridj." + libraryName + ".library");
/*      */     }
/*  869 */     return env;
/*      */   }
/*      */   
/*      */   private static String getDependenciesEnv(String libraryName) {
/*  873 */     String env = System.getenv("BRIDJ_" + libraryName.toUpperCase() + "_DEPENDENCIES");
/*  874 */     if (env == null) {
/*  875 */       env = System.getProperty("bridj." + libraryName + ".dependencies");
/*      */     }
/*  877 */     return env;
/*      */   }
/*      */ 
/*      */   
/*      */   static File findNativeLibraryFile(String libraryName) throws IOException {
/*  882 */     String actualName = libraryActualNames.get(libraryName);
/*  883 */     List<String> aliases = libraryAliases.get(libraryName);
/*  884 */     List<String> possibleNames = new ArrayList<String>();
/*  885 */     if (Platform.isWindows() && (
/*  886 */       libraryName.equals("c") || libraryName.equals("m"))) {
/*  887 */       possibleNames.add("msvcrt");
/*      */     }
/*      */     
/*  890 */     if (aliases != null) {
/*  891 */       possibleNames.addAll(aliases);
/*      */     }
/*      */     
/*  894 */     possibleNames.add((actualName == null) ? libraryName : actualName);
/*      */ 
/*      */     
/*  897 */     List<String> paths = getNativeLibraryPaths();
/*  898 */     if (debug) {
/*  899 */       info("Looking for library '" + libraryName + "' " + ((actualName != null) ? ("('" + actualName + "') ") : "") + "in paths " + paths, null);
/*      */     }
/*      */     
/*  902 */     for (String name : possibleNames) {
/*  903 */       File f; String env = getLibraryEnv(name);
/*  904 */       if (env != null) {
/*  905 */         File file = new File(env);
/*  906 */         if (file.exists()) {
/*      */           try {
/*  908 */             return file.getCanonicalFile();
/*  909 */           } catch (IOException ex) {
/*  910 */             error(null, ex);
/*      */           } 
/*      */         }
/*      */       } 
/*  914 */       List<String> possibleFileNames = Platform.getPossibleFileNames(name);
/*  915 */       for (String path : paths) {
/*  916 */         File pathFile = (path == null) ? null : new File(path);
/*  917 */         File file1 = new File(name);
/*  918 */         if (!file1.isFile() && pathFile != null) {
/*  919 */           for (String possibleFileName : possibleFileNames) {
/*  920 */             file1 = new File(pathFile, possibleFileName);
/*  921 */             if (file1.isFile()) {
/*      */               break;
/*      */             }
/*      */           } 
/*      */           
/*  926 */           if (!file1.isFile() && Platform.isLinux()) {
/*  927 */             String[] files = pathFile.list();
/*  928 */             if (files != null) {
/*  929 */               for (String possibleFileName : possibleFileNames) {
/*  930 */                 File ff = findFileWithGreaterVersion(pathFile, files, possibleFileName);
/*  931 */                 if (ff != null && (file1 = ff).isFile()) {
/*  932 */                   if (verbose) {
/*  933 */                     info("File '" + possibleFileName + "' was not found, used versioned file '" + file1 + "' instead.");
/*      */                   }
/*      */                   
/*      */                   break;
/*      */                 } 
/*      */               } 
/*      */             }
/*      */           } 
/*      */         } 
/*  942 */         if (!file1.isFile()) {
/*      */           continue;
/*      */         }
/*      */         
/*      */         try {
/*  947 */           return file1.getCanonicalFile();
/*  948 */         } catch (IOException ex) {
/*  949 */           error(null, ex);
/*      */         } 
/*      */       } 
/*  952 */       if (Platform.isMacOSX()) {
/*  953 */         for (String s : new String[] { "/System/Library/Frameworks", "/System/Library/Frameworks/ApplicationServices.framework/Frameworks", (new File(System.getProperty("user.home"), "Library/Frameworks")).toString() }) {
/*      */ 
/*      */           
/*      */           try {
/*      */ 
/*      */             
/*  959 */             File file = new File(new File(s, name + ".framework"), name);
/*  960 */             if (file.isFile()) {
/*  961 */               return file.getCanonicalFile();
/*      */             }
/*  963 */           } catch (IOException ex) {
/*  964 */             ex.printStackTrace();
/*  965 */             return null;
/*      */           } 
/*      */         } 
/*      */       }
/*      */       
/*  970 */       if (Platform.isAndroid()) {
/*  971 */         f = new File("lib" + name + ".so");
/*      */       } else {
/*  973 */         f = Platform.extractEmbeddedLibraryResource(name);
/*      */       } 
/*      */       
/*  976 */       if (f != null && f.isFile()) {
/*  977 */         return f;
/*      */       }
/*      */     } 
/*  980 */     throw new FileNotFoundException(StringUtils.implode(possibleNames, ", "));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isDirectModeEnabled() {
/*  994 */     if (directModeEnabled == null) {
/*  995 */       directModeEnabled = Boolean.valueOf((Switch.Direct.enabled && !logCalls && !protectedMode));
/*      */ 
/*      */ 
/*      */       
/*  999 */       if (veryVerbose) {
/* 1000 */         info("directModeEnabled = " + directModeEnabled);
/*      */       }
/*      */     } 
/* 1003 */     return directModeEnabled.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void setDirectModeEnabled(boolean v) {
/* 1016 */     directModeEnabled = Boolean.valueOf(v);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized NativeLibrary getNativeLibrary(String name) throws IOException {
/* 1024 */     if (name == null) {
/* 1025 */       return null;
/*      */     }
/*      */     
/* 1028 */     NativeLibrary l = libHandles.get(name);
/* 1029 */     if (l != null) {
/* 1030 */       return l;
/*      */     }
/*      */     
/* 1033 */     File f = getNativeLibraryFile(name);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1038 */     return getNativeLibrary(name, f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NativeLibrary getNativeLibrary(String name, File f) throws IOException {
/* 1046 */     NativeLibrary ll = NativeLibrary.load((f == null) ? name : f.toString());
/* 1047 */     if (ll == null) {
/* 1048 */       ll = PlatformSupport.getInstance().loadNativeLibrary(name);
/* 1049 */       if (ll == null) {
/* 1050 */         boolean isWindows = Platform.isWindows();
/* 1051 */         if ("c".equals(name) || ("m".equals(name) && isWindows)) {
/* 1052 */           ll = new NativeLibrary(isWindows ? "msvcrt" : null, 0L, 0L);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1059 */     if (ll == null) {
/* 1060 */       if (f != null && f.exists()) {
/* 1061 */         throw new RuntimeException("Library '" + name + "' was not loaded successfully from file '" + f + "'");
/*      */       }
/* 1063 */       throw new FileNotFoundException("Library '" + name + "' was not found in path '" + getNativeLibraryPaths() + "'" + ((f != null && f.exists()) ? (" (failed to load " + f + ")") : ""));
/*      */     } 
/*      */     
/* 1066 */     if (verbose) {
/* 1067 */       info("Loaded library '" + name + "' from '" + f + "'", null);
/*      */     }
/*      */     
/* 1070 */     libHandles.put(name, ll);
/* 1071 */     return ll;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getNativeLibraryName(AnnotatedElement m) {
/* 1080 */     Library lib = getLibrary(m);
/* 1081 */     return (lib == null) ? null : lib.value();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Library getLibrary(AnnotatedElement m) {
/* 1090 */     return (Library)AnnotationUtils.getInheritableAnnotation(Library.class, m, new java.lang.annotation.Annotation[0]);
/*      */   }
/*      */   
/*      */   public static Demangler.Symbol getSymbolByAddress(long peer) {
/* 1094 */     for (NativeLibrary lib : libHandles.values()) {
/* 1095 */       Demangler.Symbol symbol = lib.getSymbol(peer);
/* 1096 */       if (symbol != null) {
/* 1097 */         return symbol;
/*      */       }
/*      */     } 
/* 1100 */     return null;
/*      */   }
/*      */   
/*      */   public static void setOrphanEntities(NativeEntities orphanEntities) {
/* 1104 */     BridJ.orphanEntities = orphanEntities;
/*      */   }
/*      */   
/*      */   public static NativeEntities getOrphanEntities() {
/* 1108 */     return orphanEntities;
/*      */   }
/*      */   
/*      */   static void initialize(NativeObject instance) {
/* 1112 */     Class<?> instanceClass = instance.getClass();
/* 1113 */     BridJRuntime runtime = getRuntime(instanceClass);
/* 1114 */     Type type = runtime.getType(instance);
/* 1115 */     BridJRuntime.TypeInfo<NativeObject> typeInfo = getTypeInfo(runtime, type);
/* 1116 */     instance.typeInfo = typeInfo;
/* 1117 */     typeInfo.initialize(instance);
/*      */   }
/*      */   
/*      */   static void initialize(NativeObject instance, Pointer peer, Object... targs) {
/* 1121 */     Class<?> instanceClass = instance.getClass();
/* 1122 */     BridJRuntime runtime = getRuntime(instanceClass);
/* 1123 */     Type type = runtime.getType(instanceClass, targs, null);
/* 1124 */     BridJRuntime.TypeInfo<NativeObject> typeInfo = getTypeInfo(runtime, type);
/* 1125 */     instance.typeInfo = typeInfo;
/* 1126 */     typeInfo.initialize(instance, peer);
/*      */   }
/*      */   
/*      */   static void initialize(NativeObject instance, int constructorId, Object[] targsAndArgs) {
/* 1130 */     Class<?> instanceClass = instance.getClass();
/* 1131 */     BridJRuntime runtime = getRuntime(instanceClass);
/* 1132 */     int[] typeParamCount = new int[1];
/* 1133 */     Type type = runtime.getType(instanceClass, targsAndArgs, typeParamCount);
/* 1134 */     int targsCount = typeParamCount[0];
/* 1135 */     Object[] args = Utils.takeRight(targsAndArgs, targsAndArgs.length - targsCount);
/*      */     
/* 1137 */     BridJRuntime.TypeInfo<NativeObject> typeInfo = getTypeInfo(runtime, type);
/* 1138 */     instance.typeInfo = typeInfo;
/* 1139 */     typeInfo.initialize(instance, constructorId, args);
/*      */   }
/*      */   
/*      */   static <T extends NativeObject> T clone(T instance) throws CloneNotSupportedException {
/* 1143 */     return ((NativeObject)instance).typeInfo.clone(instance);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends NativeObject> T readFromNative(T instance) {
/* 1152 */     ((NativeObject)instance).typeInfo.readFromNative(instance);
/* 1153 */     return instance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends NativeObject> T writeToNative(T instance) {
/* 1162 */     ((NativeObject)instance).typeInfo.writeToNative(instance);
/* 1163 */     return instance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String describe(NativeObject instance) {
/* 1173 */     return instance.typeInfo.describe(instance);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String describe(Type nativeObjectType) {
/* 1183 */     BridJRuntime runtime = getRuntime(Utils.getClass(nativeObjectType));
/* 1184 */     BridJRuntime.TypeInfo<NativeObject> typeInfo = getTypeInfo(runtime, nativeObjectType);
/* 1185 */     return (typeInfo == null) ? Utils.toString(nativeObjectType) : typeInfo.describe();
/*      */   }
/*      */   
/*      */   public static void main(String[] args) {
/* 1189 */     List<NativeLibrary> libraries = new ArrayList<NativeLibrary>();
/*      */     try {
/* 1191 */       File outputDir = new File(".");
/* 1192 */       for (int iArg = 0, nArgs = args.length; iArg < nArgs; iArg++) {
/* 1193 */         String arg = args[iArg];
/* 1194 */         if (arg.equals("-d")) {
/* 1195 */           outputDir = new File(args[++iArg]);
/*      */         } else {
/*      */           
/*      */           try {
/* 1199 */             NativeLibrary lib = getNativeLibrary(arg);
/* 1200 */             libraries.add(lib);
/*      */             
/* 1202 */             PrintWriter sout = new PrintWriter(new File(outputDir, (new File(arg)).getName() + ".symbols.txt"));
/* 1203 */             for (Demangler.Symbol sym : lib.getSymbols()) {
/* 1204 */               sout.print(sym.getSymbol());
/* 1205 */               sout.print(" // ");
/*      */               try {
/* 1207 */                 Demangler.MemberRef mr = sym.getParsedRef();
/* 1208 */                 sout.print(" // " + mr);
/* 1209 */               } catch (Throwable th) {
/* 1210 */                 sout.print("?");
/*      */               } 
/* 1212 */               sout.println();
/*      */             } 
/* 1214 */             sout.close();
/* 1215 */           } catch (Throwable th) {
/* 1216 */             th.printStackTrace();
/*      */           } 
/*      */         } 
/* 1219 */       }  PrintWriter out = new PrintWriter(new File(outputDir, "out.h"));
/* 1220 */       HeadersReconstructor.reconstructHeaders(libraries, out);
/* 1221 */       out.close();
/* 1222 */     } catch (Exception ex) {
/* 1223 */       ex.printStackTrace();
/* 1224 */       System.exit(1);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\BridJ.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */