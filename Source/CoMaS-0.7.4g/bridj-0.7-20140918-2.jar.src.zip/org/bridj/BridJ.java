package org.bridj;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.WeakHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bridj.ann.Library;
import org.bridj.ann.Runtime;
import org.bridj.demangling.Demangler;
import org.bridj.util.ASMUtils;
import org.bridj.util.AnnotationUtils;
import org.bridj.util.ClassDefiner;
import org.bridj.util.StringUtils;
import org.bridj.util.Utils;

public class BridJ {
  static final Map<AnnotatedElement, NativeLibrary> librariesByClass = new HashMap<AnnotatedElement, NativeLibrary>();
  
  static final Map<String, File> librariesFilesByName = new HashMap<String, File>();
  
  static final Map<File, NativeLibrary> librariesByFile = new HashMap<File, NativeLibrary>();
  
  private static NativeEntities orphanEntities = new NativeEntities();
  
  static final Map<Class<?>, BridJRuntime> classRuntimes = new HashMap<Class<?>, BridJRuntime>();
  
  static final Map<Long, NativeObject> strongNativeObjects = new HashMap<Long, NativeObject>();
  
  static final Map<Long, NativeObject> weakNativeObjects = new WeakHashMap<Long, NativeObject>();
  
  public static long sizeOf(Type type) {
    Class<?> c = Utils.getClass(type);
    if (c.isPrimitive())
      return StructUtils.primTypeLength(c); 
    if (Pointer.class.isAssignableFrom(c))
      return Pointer.SIZE; 
    if (c == CLong.class)
      return CLong.SIZE; 
    if (c == TimeT.class)
      return TimeT.SIZE; 
    if (c == SizeT.class)
      return SizeT.SIZE; 
    if (c == Integer.class || c == Float.class)
      return 4L; 
    if (c == Character.class || c == Short.class)
      return 2L; 
    if (c == Long.class || c == Double.class)
      return 8L; 
    if (c == Boolean.class || c == Byte.class)
      return 1L; 
    if (NativeObject.class.isAssignableFrom(c))
      return getRuntime(c).<NativeObject>getTypeInfo(type).sizeOf(); 
    if (IntValuedEnum.class.isAssignableFrom(c))
      return 4L; 
    throw new RuntimeException("Unable to compute size of type " + Utils.toString(type));
  }
  
  static synchronized void registerNativeObject(NativeObject ob) {
    weakNativeObjects.put(Long.valueOf(Pointer.getAddress(ob, null)), ob);
  }
  
  static synchronized NativeObject getNativeObject(long peer) {
    NativeObject ob = weakNativeObjects.get(Long.valueOf(peer));
    if (ob == null)
      ob = strongNativeObjects.get(Long.valueOf(peer)); 
    return ob;
  }
  
  static synchronized void unregisterNativeObject(NativeObject ob) {
    long peer = Pointer.getAddress(ob, null);
    weakNativeObjects.remove(Long.valueOf(peer));
    strongNativeObjects.remove(Long.valueOf(peer));
  }
  
  public static synchronized <T extends NativeObject> T protectFromGC(T ob) {
    long peer = Pointer.getAddress((NativeObject)ob, null);
    weakNativeObjects.remove(Long.valueOf(peer));
    strongNativeObjects.put(Long.valueOf(peer), (NativeObject)ob);
    return ob;
  }
  
  public static synchronized <T extends NativeObject> T unprotectFromGC(T ob) {
    long peer = Pointer.getAddress((NativeObject)ob, null);
    if (strongNativeObjects.remove(Long.valueOf(peer)) != null)
      weakNativeObjects.put(Long.valueOf(peer), (NativeObject)ob); 
    return ob;
  }
  
  public static void delete(NativeObject nativeObject) {
    unregisterNativeObject(nativeObject);
    Pointer.<NativeObject>getPointer(nativeObject, null).release();
  }
  
  public static synchronized void register() {
    StackTraceElement[] stackTrace = (new Exception()).getStackTrace();
    if (stackTrace.length < 2)
      throw new RuntimeException("No useful stack trace : cannot register with register(), please use register(Class) instead."); 
    String name = stackTrace[1].getClassName();
    try {
      Class<?> type = Class.forName(name, false, Platform.getClassLoader());
      register(type);
    } catch (Exception ex) {
      throw new RuntimeException("Failed to register class " + name, ex);
    } 
  }
  
  public static <T> Class<? extends T> subclassWithSynchronizedNativeMethods(Class<T> original) throws IOException {
    ClassDefiner classDefiner = ((CRuntime)getRuntimeByRuntimeClass(CRuntime.class)).getCallbackNativeImplementer();
    return ASMUtils.createSubclassWithSynchronizedNativeMethodsAndNoStaticFields(original, classDefiner);
  }
  
  enum CastingType {
    None, CastingNativeObject, CastingNativeObjectReturnType;
  }
  
  static ThreadLocal<Stack<CastingType>> currentlyCastingNativeObject = new ThreadLocal<Stack<CastingType>>() {
      protected Stack<BridJ.CastingType> initialValue() {
        Stack<BridJ.CastingType> s = new Stack<BridJ.CastingType>();
        s.push(BridJ.CastingType.None);
        return s;
      }
    };
  
  @Deprecated
  public static boolean isCastingNativeObjectInCurrentThread() {
    return (((Stack<CastingType>)currentlyCastingNativeObject.get()).peek() != CastingType.None);
  }
  
  @Deprecated
  public static boolean isCastingNativeObjectReturnTypeInCurrentThread() {
    return (((Stack<CastingType>)currentlyCastingNativeObject.get()).peek() == CastingType.CastingNativeObjectReturnType);
  }
  
  private static WeakHashMap<Long, NativeObject> knownNativeObjects = new WeakHashMap<Long, NativeObject>();
  
  public static synchronized <O extends NativeObject> void setJavaObjectFromNativePeer(long peer, O object) {
    if (object == null) {
      knownNativeObjects.remove(Long.valueOf(peer));
    } else {
      knownNativeObjects.put(Long.valueOf(peer), (NativeObject)object);
    } 
  }
  
  public static synchronized Object getJavaObjectFromNativePeer(long peer) {
    return knownNativeObjects.get(Long.valueOf(peer));
  }
  
  private static <O extends NativeObject> O createNativeObjectFromPointer(Pointer<? super O> pointer, Type type, CastingType castingType) {
    Stack<CastingType> s = currentlyCastingNativeObject.get();
    s.push(castingType);
    try {
      BridJRuntime runtime = getRuntime(Utils.getClass(type));
      BridJRuntime.TypeInfo<O> typeInfo = getTypeInfo(runtime, type);
      O instance = typeInfo.cast(pointer);
      if (debug)
        info("Created native object from pointer " + pointer); 
      return instance;
    } catch (Exception ex) {
      throw new RuntimeException("Failed to cast pointer to native object of type " + Utils.getClass(type).getName(), ex);
    } finally {
      s.pop();
    } 
  }
  
  public static <O extends NativeObject> void copyNativeObjectToAddress(O value, Type type, Pointer<O> ptr) {
    BridJRuntime runtime = getRuntime(Utils.getClass(type));
    getTypeInfo(runtime, type).copyNativeObjectToAddress(value, ptr);
  }
  
  public static <O extends NativeObject> O createNativeObjectFromPointer(Pointer<? super O> pointer, Type type) {
    return createNativeObjectFromPointer(pointer, type, CastingType.CastingNativeObject);
  }
  
  public static <O extends NativeObject> O createNativeObjectFromReturnValuePointer(Pointer<? super O> pointer, Type type) {
    return createNativeObjectFromPointer(pointer, type, CastingType.CastingNativeObjectReturnType);
  }
  
  private static Map<Class<? extends BridJRuntime>, BridJRuntime> runtimes = new HashMap<Class<? extends BridJRuntime>, BridJRuntime>();
  
  public static synchronized <R extends BridJRuntime> R getRuntimeByRuntimeClass(Class<R> runtimeClass) {
    BridJRuntime bridJRuntime = runtimes.get(runtimeClass);
    if (bridJRuntime == null)
      try {
        runtimes.put(runtimeClass, bridJRuntime = (BridJRuntime)runtimeClass.newInstance());
      } catch (Exception e) {
        throw new RuntimeException("Failed to instantiate runtime " + runtimeClass.getName(), e);
      }  
    return (R)bridJRuntime;
  }
  
  public static Class<? extends BridJRuntime> getRuntimeClass(Class<?> type) {
    Class<CRuntime> clazz;
    Runtime runtimeAnn = (Runtime)AnnotationUtils.getInheritableAnnotation(Runtime.class, type, new java.lang.annotation.Annotation[0]);
    Class<? extends BridJRuntime> runtimeClass = null;
    if (runtimeAnn != null) {
      runtimeClass = runtimeAnn.value();
    } else {
      clazz = CRuntime.class;
    } 
    return (Class)clazz;
  }
  
  public static BridJRuntime getRuntime(Class<?> type) {
    synchronized (classRuntimes) {
      BridJRuntime runtime = classRuntimes.get(type);
      if (runtime == null) {
        Class<? extends BridJRuntime> runtimeClass = getRuntimeClass(type);
        runtime = getRuntimeByRuntimeClass((Class)runtimeClass);
        classRuntimes.put(type, runtime);
        if (veryVerbose)
          info("Runtime for " + type.getName() + " : " + runtimeClass.getName()); 
      } 
      return runtime;
    } 
  }
  
  public static BridJRuntime register(Class<?> type) {
    BridJRuntime runtime = getRuntime(type);
    if (runtime == null) {
      for (Class<?> child : type.getClasses())
        register(child); 
    } else {
      runtime.register(type);
    } 
    return runtime;
  }
  
  public static void unregister(Class<?> type) {
    BridJRuntime runtime = getRuntime(type);
    if (runtime == null) {
      for (Class<?> child : type.getClasses())
        register(child); 
    } else {
      runtime.unregister(type);
    } 
  }
  
  static Map<Type, BridJRuntime.TypeInfo<?>> typeInfos = new HashMap<Type, BridJRuntime.TypeInfo<?>>();
  
  static <T extends NativeObject> BridJRuntime.TypeInfo<T> getTypeInfo(BridJRuntime runtime, Type t) {
    synchronized (typeInfos) {
      BridJRuntime.TypeInfo<NativeObject> info = (BridJRuntime.TypeInfo)typeInfos.get(t);
      if (info == null) {
        info = runtime.getTypeInfo(t);
        typeInfos.put(t, info);
      } 
      return (BridJRuntime.TypeInfo)info;
    } 
  }
  
  enum Switch {
    Debug("bridj.debug", "BRIDJ_DEBUG", false, "Debug mode (implies high verbosity)"),
    DebugNeverFree("bridj.debug.neverFree", "BRIDJ_DEBUG_NEVER_FREE", false, "Never free allocated pointers (deprecated)"),
    DebugPointers("bridj.debug.pointers", "BRIDJ_DEBUG_POINTERS", false, "Trace pointer allocations & deallocations (to debug memory issues)"),
    DebugPointerReleases("bridj.debug.pointer.releases", "BRIDJ_DEBUG_POINTER_RELEASES", false, "Prevent double releases of pointers and keep the trace of their first release (to debug memory issues)"),
    VeryVerbose("bridj.veryVerbose", "BRIDJ_VERY_VERBOSE", false, "Highly verbose mode"),
    Verbose("bridj.verbose", "BRIDJ_VERBOSE", false, "Verbose mode"),
    Quiet("bridj.quiet", "BRIDJ_QUIET", false, "Quiet mode"),
    CachePointers("bridj.cache.pointers", "BRIDJ_CACHE_POINTERS", true, "Cache last recently used pointers in each thread"),
    AlignDouble("bridj.alignDouble", "BRIDJ_ALIGN_DOUBLE", false, "Align doubles on 8 bytes boundaries even on Linux 32 bits (see -malign-double GCC option)."),
    LogCalls("bridj.logCalls", "BRIDJ_LOG_CALLS", false, "Log each native call performed (or call from native to Java callback)"),
    Protected("bridj.protected", "BRIDJ_PROTECTED", false, "Protect all native calls (including memory accesses) against native crashes (disables assembly optimizations and adds quite some overhead)."),
    Destructors("bridj.destructors", "BRIDJ_DESTRUCTORS", true, "Enable destructors (in languages that support them, such as C++)"),
    Direct("bridj.direct", "BRIDJ_DIRECT", true, "Direct mode (uses optimized assembler glue when possible to speed up calls)"),
    StructsByValue("bridj.structsByValue", "BRIDJ_STRUCT_BY_VALUE", false, "Enable experimental support for structs-by-value arguments and return values for C/C++ functions and methods.");
    
    public final boolean enabled;
    
    public final boolean enabledByDefault;
    
    public final String propertyName;
    
    public final String envName;
    
    public final String description;
    
    Switch(String propertyName, String envName, boolean enabledByDefault, String description) {
      if (enabledByDefault) {
        this.enabled = (!"false".equals(System.getProperty(propertyName)) && !"0".equals(System.getenv(envName)));
      } else {
        this.enabled = ("true".equals(System.getProperty(propertyName)) || "1".equals(System.getenv(envName)));
      } 
      this.enabledByDefault = enabledByDefault;
      this.propertyName = propertyName;
      this.envName = envName;
      this.description = description;
    }
    
    public String getFullDescription() {
      return this.envName + " / " + this.propertyName + " (" + (this.enabledByDefault ? "enabled" : "disabled") + " by default) :\n\t" + this.description.replaceAll("\n", "\n\t");
    }
  }
  
  static {
    checkOptions();
  }
  
  static void checkOptions() {
    Set<String> props = new HashSet<String>(), envs = new HashSet<String>();
    for (Switch s : Switch.values()) {
      props.add(s.propertyName);
      envs.add(s.envName);
    } 
    boolean hasUnknown = false;
    for (String n : System.getenv().keySet()) {
      if (!n.startsWith("BRIDJ_") || envs.contains(n))
        continue; 
      if (n.endsWith("_LIBRARY"))
        continue; 
      if (n.endsWith("_DEPENDENCIES"))
        continue; 
      error("Unknown environment variable : " + n + "=\"" + System.getenv(n) + "\"");
      hasUnknown = true;
    } 
    for (Enumeration<String> e = (Enumeration)System.getProperties().propertyNames(); e.hasMoreElements(); ) {
      String n = e.nextElement();
      if (!n.startsWith("bridj.") || props.contains(n))
        continue; 
      if (n.endsWith(".library"))
        continue; 
      if (n.endsWith(".dependencies"))
        continue; 
      error("Unknown property : " + n + "=\"" + System.getProperty(n) + "\"");
      hasUnknown = true;
    } 
    if (hasUnknown) {
      StringBuilder b = new StringBuilder();
      b.append("Available options (ENVIRONMENT_VAR_NAME / javaPropertyName) :\n");
      for (Switch s : Switch.values())
        b.append(s.getFullDescription() + "\n"); 
      error(b.toString());
    } 
  }
  
  public static final boolean debug = Switch.Debug.enabled;
  
  public static final boolean debugNeverFree = Switch.DebugNeverFree.enabled;
  
  public static final boolean debugPointers = Switch.DebugPointers.enabled;
  
  public static final boolean debugPointerReleases = (Switch.DebugPointerReleases.enabled || debugPointers);
  
  public static final boolean veryVerbose = Switch.VeryVerbose.enabled;
  
  public static final boolean verbose = (debug || veryVerbose || Switch.Verbose.enabled);
  
  public static final boolean quiet = Switch.Quiet.enabled;
  
  public static final boolean logCalls = Switch.LogCalls.enabled;
  
  public static final boolean protectedMode = Switch.Protected.enabled;
  
  public static final boolean enableDestructors = Switch.Destructors.enabled;
  
  public static final boolean alignDoubles = Switch.AlignDouble.enabled;
  
  public static final boolean cachePointers = Switch.CachePointers.enabled;
  
  static volatile int minLogLevelValue = (verbose ? Level.WARNING : Level.INFO).intValue();
  
  static Logger logger;
  
  public static void setMinLogLevel(Level level) {
    minLogLevelValue = level.intValue();
  }
  
  static boolean shouldLog(Level level) {
    return (!quiet && (verbose || level.intValue() >= minLogLevelValue));
  }
  
  static synchronized Logger getLogger() {
    if (logger == null)
      logger = Logger.getLogger(BridJ.class.getName()); 
    return logger;
  }
  
  public static boolean info(String message) {
    return info(message, null);
  }
  
  public static boolean info(String message, Throwable ex) {
    return log(Level.INFO, message, ex);
  }
  
  public static boolean debug(String message) {
    if (!debug)
      return true; 
    return info(message, null);
  }
  
  public static boolean error(String message) {
    return error(message, null);
  }
  
  public static boolean error(String message, Throwable ex) {
    return log(Level.INFO, message, ex);
  }
  
  public static boolean warning(String message) {
    return warning(message, null);
  }
  
  public static boolean warning(String message, Throwable ex) {
    return log(Level.INFO, message, ex);
  }
  
  private static boolean log(Level level, String message, Throwable ex) {
    if (!shouldLog(level))
      return true; 
    getLogger().log(level, message, ex);
    return true;
  }
  
  static void logCall(Method m) {
    info("Calling method " + m);
  }
  
  public static synchronized NativeEntities getNativeEntities(AnnotatedElement type) throws IOException {
    NativeLibrary lib = getNativeLibrary(type);
    if (lib != null)
      return lib.getNativeEntities(); 
    return getOrphanEntities();
  }
  
  public static synchronized NativeLibrary getNativeLibrary(AnnotatedElement type) throws IOException {
    NativeLibrary lib = librariesByClass.get(type);
    if (lib == null) {
      Library libraryAnnotation = getLibrary(type);
      if (libraryAnnotation != null) {
        String libraryName = libraryAnnotation.value();
        String dependenciesEnv = getDependenciesEnv(libraryName);
        List<String> dependencies = libraryDependencies.get(libraryName);
        List<String> staticDependencies = Arrays.asList((dependenciesEnv == null) ? libraryAnnotation.dependencies() : dependenciesEnv.split(","));
        if (dependencies == null) {
          dependencies = staticDependencies;
        } else {
          dependencies.addAll(staticDependencies);
        } 
        for (String dependency : dependencies) {
          if (verbose)
            info("Trying to load dependency '" + dependency + "' of '" + libraryName + "'"); 
          NativeLibrary depLib = getNativeLibrary(dependency);
          if (depLib == null)
            throw new RuntimeException("Failed to load dependency '" + dependency + "' of library '" + libraryName + "'"); 
        } 
        lib = getNativeLibrary(libraryName);
        if (lib != null)
          librariesByClass.put(type, lib); 
      } 
    } 
    return lib;
  }
  
  public static synchronized void releaseAll() {
    strongNativeObjects.clear();
    weakNativeObjects.clear();
    System.gc();
    for (NativeLibrary lib : librariesByFile.values())
      lib.release(); 
    librariesByFile.clear();
    librariesByClass.clear();
    getOrphanEntities().release();
    System.gc();
  }
  
  public static synchronized void releaseLibrary(String name) {
    File file = librariesFilesByName.remove(name);
    if (file != null)
      releaseLibrary(file); 
  }
  
  public static synchronized void releaseLibrary(File library) {
    NativeLibrary lib = librariesByFile.remove(library);
    if (lib != null)
      lib.release(); 
  }
  
  static Map<String, NativeLibrary> libHandles = new HashMap<String, NativeLibrary>();
  
  static volatile List<String> nativeLibraryPaths;
  
  static List<String> additionalPaths = new ArrayList<String>();
  
  public static synchronized void addLibraryPath(String path) {
    additionalPaths.add(path);
    nativeLibraryPaths = null;
  }
  
  private static void addPathsFromEnv(List<String> out, String name) {
    String env = System.getenv(name);
    if (verbose)
      info("Environment var " + name + " = " + env); 
    addPaths(out, env);
  }
  
  private static void addPathsFromProperty(List<String> out, String name) {
    String env = System.getProperty(name);
    if (verbose)
      info("Property " + name + " = " + env); 
    addPaths(out, env);
  }
  
  private static void addPaths(List<String> out, String env) {
    if (env == null)
      return; 
    String[] paths = env.split(File.pathSeparator);
    if (paths.length == 0)
      return; 
    if (paths.length == 1) {
      out.add(paths[0]);
      return;
    } 
    out.addAll(Arrays.asList(paths));
  }
  
  static synchronized List<String> getNativeLibraryPaths() {
    if (nativeLibraryPaths == null) {
      nativeLibraryPaths = new ArrayList<String>();
      nativeLibraryPaths.addAll(additionalPaths);
      nativeLibraryPaths.add(null);
      nativeLibraryPaths.add(".");
      addPathsFromEnv(nativeLibraryPaths, "LD_LIBRARY_PATH");
      addPathsFromEnv(nativeLibraryPaths, "DYLD_LIBRARY_PATH");
      addPathsFromEnv(nativeLibraryPaths, "PATH");
      addPathsFromProperty(nativeLibraryPaths, "java.library.path");
      addPathsFromProperty(nativeLibraryPaths, "sun.boot.library.path");
      addPathsFromProperty(nativeLibraryPaths, "gnu.classpath.boot.library.path");
      File javaHome = new File(System.getProperty("java.home"));
      nativeLibraryPaths.add((new File(javaHome, "bin")).toString());
      if (Platform.isMacOSX())
        nativeLibraryPaths.add((new File(javaHome, "../Libraries")).toString()); 
      if (Platform.isUnix()) {
        String bits = Platform.is64Bits() ? "64" : "32";
        if (Platform.isLinux()) {
          String abi = Platform.isArm() ? "gnueabi" : "gnu";
          String multiArch = Platform.getMachine() + "-linux-" + abi;
          nativeLibraryPaths.add("/lib/" + multiArch);
          nativeLibraryPaths.add("/usr/lib/" + multiArch);
          nativeLibraryPaths.add("/usr/lib" + bits);
          nativeLibraryPaths.add("/lib" + bits);
        } else if (Platform.isSolaris()) {
          nativeLibraryPaths.add("/usr/lib/" + bits);
          nativeLibraryPaths.add("/lib/" + bits);
        } 
        nativeLibraryPaths.add("/usr/lib");
        nativeLibraryPaths.add("/lib");
        nativeLibraryPaths.add("/usr/local/lib");
      } 
    } 
    return nativeLibraryPaths;
  }
  
  static Map<String, String> libraryActualNames = new HashMap<String, String>();
  
  public static synchronized void setNativeLibraryActualName(String name, String actualName) {
    libraryActualNames.put(name, actualName);
  }
  
  static Map<String, List<String>> libraryAliases = new HashMap<String, List<String>>();
  
  public static synchronized void addNativeLibraryAlias(String name, String alias) {
    List<String> list = libraryAliases.get(name);
    if (list == null)
      libraryAliases.put(name, list = new ArrayList<String>()); 
    if (!list.contains(alias))
      list.add(alias); 
  }
  
  static Map<String, List<String>> libraryDependencies = new HashMap<String, List<String>>();
  
  public static synchronized void addNativeLibraryDependencies(String name, String... dependencyNames) {
    List<String> list = libraryDependencies.get(name);
    if (list == null)
      libraryDependencies.put(name, list = new ArrayList<String>()); 
    for (String dependencyName : dependencyNames) {
      if (!list.contains(dependencyName))
        list.add(dependencyName); 
    } 
  }
  
  private static final Pattern numPat = Pattern.compile("\\b(\\d+)\\b");
  
  static double parseVersion(String s) {
    Matcher m = numPat.matcher(s);
    double res = 0.0D, f = 1.0D;
    while (m.find()) {
      res += Integer.parseInt(m.group(1)) * f;
      f /= 1000.0D;
    } 
    return res;
  }
  
  static File findFileWithGreaterVersion(File dir, String[] files, String baseFileName) {
    Pattern versionPattern = Pattern.compile(Pattern.quote(baseFileName) + "((:?\\.\\d+)+)");
    double maxVersion = 0.0D;
    String maxVersionFile = null;
    for (String fileName : files) {
      Matcher m = versionPattern.matcher(fileName);
      if (m.matches()) {
        double version = parseVersion(m.group(1));
        if (maxVersionFile == null || version > maxVersion) {
          maxVersionFile = fileName;
          maxVersion = version;
        } 
      } 
    } 
    if (maxVersionFile == null)
      return null; 
    return new File(dir, maxVersionFile);
  }
  
  static Map<String, File> nativeLibraryFiles = new HashMap<String, File>();
  
  static Boolean directModeEnabled;
  
  public static File getNativeLibraryFile(String libraryName) {
    if (libraryName == null)
      return null; 
    try {
      synchronized (nativeLibraryFiles) {
        File nativeLibraryFile = nativeLibraryFiles.get(libraryName);
        if (nativeLibraryFile == null)
          nativeLibraryFiles.put(libraryName, nativeLibraryFile = findNativeLibraryFile(libraryName)); 
        return nativeLibraryFile;
      } 
    } catch (Throwable th) {
      warning("Library not found : " + libraryName, debug ? th : null);
      return null;
    } 
  }
  
  public static void setNativeLibraryFile(String libraryName, File nativeLibraryFile) {
    if (libraryName == null)
      return; 
    synchronized (nativeLibraryFiles) {
      nativeLibraryFiles.put(libraryName, nativeLibraryFile);
    } 
  }
  
  private static String getLibraryEnv(String libraryName) {
    String env = System.getenv("BRIDJ_" + libraryName.toUpperCase() + "_LIBRARY");
    if (env == null)
      env = System.getProperty("bridj." + libraryName + ".library"); 
    return env;
  }
  
  private static String getDependenciesEnv(String libraryName) {
    String env = System.getenv("BRIDJ_" + libraryName.toUpperCase() + "_DEPENDENCIES");
    if (env == null)
      env = System.getProperty("bridj." + libraryName + ".dependencies"); 
    return env;
  }
  
  static File findNativeLibraryFile(String libraryName) throws IOException {
    String actualName = libraryActualNames.get(libraryName);
    List<String> aliases = libraryAliases.get(libraryName);
    List<String> possibleNames = new ArrayList<String>();
    if (Platform.isWindows() && (
      libraryName.equals("c") || libraryName.equals("m")))
      possibleNames.add("msvcrt"); 
    if (aliases != null)
      possibleNames.addAll(aliases); 
    possibleNames.add((actualName == null) ? libraryName : actualName);
    List<String> paths = getNativeLibraryPaths();
    if (debug)
      info("Looking for library '" + libraryName + "' " + ((actualName != null) ? ("('" + actualName + "') ") : "") + "in paths " + paths, null); 
    for (String name : possibleNames) {
      File f;
      String env = getLibraryEnv(name);
      if (env != null) {
        File file = new File(env);
        if (file.exists())
          try {
            return file.getCanonicalFile();
          } catch (IOException ex) {
            error(null, ex);
          }  
      } 
      List<String> possibleFileNames = Platform.getPossibleFileNames(name);
      for (String path : paths) {
        File pathFile = (path == null) ? null : new File(path);
        File file1 = new File(name);
        if (!file1.isFile() && pathFile != null) {
          for (String possibleFileName : possibleFileNames) {
            file1 = new File(pathFile, possibleFileName);
            if (file1.isFile())
              break; 
          } 
          if (!file1.isFile() && Platform.isLinux()) {
            String[] files = pathFile.list();
            if (files != null)
              for (String possibleFileName : possibleFileNames) {
                File ff = findFileWithGreaterVersion(pathFile, files, possibleFileName);
                if (ff != null && (file1 = ff).isFile()) {
                  if (verbose)
                    info("File '" + possibleFileName + "' was not found, used versioned file '" + file1 + "' instead."); 
                  break;
                } 
              }  
          } 
        } 
        if (!file1.isFile())
          continue; 
        try {
          return file1.getCanonicalFile();
        } catch (IOException ex) {
          error(null, ex);
        } 
      } 
      if (Platform.isMacOSX())
        for (String s : new String[] { "/System/Library/Frameworks", "/System/Library/Frameworks/ApplicationServices.framework/Frameworks", (new File(System.getProperty("user.home"), "Library/Frameworks")).toString() }) {
          try {
            File file = new File(new File(s, name + ".framework"), name);
            if (file.isFile())
              return file.getCanonicalFile(); 
          } catch (IOException ex) {
            ex.printStackTrace();
            return null;
          } 
        }  
      if (Platform.isAndroid()) {
        f = new File("lib" + name + ".so");
      } else {
        f = Platform.extractEmbeddedLibraryResource(name);
      } 
      if (f != null && f.isFile())
        return f; 
    } 
    throw new FileNotFoundException(StringUtils.implode(possibleNames, ", "));
  }
  
  public static boolean isDirectModeEnabled() {
    if (directModeEnabled == null) {
      directModeEnabled = Boolean.valueOf((Switch.Direct.enabled && !logCalls && !protectedMode));
      if (veryVerbose)
        info("directModeEnabled = " + directModeEnabled); 
    } 
    return directModeEnabled.booleanValue();
  }
  
  static void setDirectModeEnabled(boolean v) {
    directModeEnabled = Boolean.valueOf(v);
  }
  
  public static synchronized NativeLibrary getNativeLibrary(String name) throws IOException {
    if (name == null)
      return null; 
    NativeLibrary l = libHandles.get(name);
    if (l != null)
      return l; 
    File f = getNativeLibraryFile(name);
    return getNativeLibrary(name, f);
  }
  
  public static NativeLibrary getNativeLibrary(String name, File f) throws IOException {
    NativeLibrary ll = NativeLibrary.load((f == null) ? name : f.toString());
    if (ll == null) {
      ll = PlatformSupport.getInstance().loadNativeLibrary(name);
      if (ll == null) {
        boolean isWindows = Platform.isWindows();
        if ("c".equals(name) || ("m".equals(name) && isWindows))
          ll = new NativeLibrary(isWindows ? "msvcrt" : null, 0L, 0L); 
      } 
    } 
    if (ll == null) {
      if (f != null && f.exists())
        throw new RuntimeException("Library '" + name + "' was not loaded successfully from file '" + f + "'"); 
      throw new FileNotFoundException("Library '" + name + "' was not found in path '" + getNativeLibraryPaths() + "'" + ((f != null && f.exists()) ? (" (failed to load " + f + ")") : ""));
    } 
    if (verbose)
      info("Loaded library '" + name + "' from '" + f + "'", null); 
    libHandles.put(name, ll);
    return ll;
  }
  
  public static String getNativeLibraryName(AnnotatedElement m) {
    Library lib = getLibrary(m);
    return (lib == null) ? null : lib.value();
  }
  
  static Library getLibrary(AnnotatedElement m) {
    return (Library)AnnotationUtils.getInheritableAnnotation(Library.class, m, new java.lang.annotation.Annotation[0]);
  }
  
  public static Demangler.Symbol getSymbolByAddress(long peer) {
    for (NativeLibrary lib : libHandles.values()) {
      Demangler.Symbol symbol = lib.getSymbol(peer);
      if (symbol != null)
        return symbol; 
    } 
    return null;
  }
  
  public static void setOrphanEntities(NativeEntities orphanEntities) {
    BridJ.orphanEntities = orphanEntities;
  }
  
  public static NativeEntities getOrphanEntities() {
    return orphanEntities;
  }
  
  static void initialize(NativeObject instance) {
    Class<?> instanceClass = instance.getClass();
    BridJRuntime runtime = getRuntime(instanceClass);
    Type type = runtime.getType(instance);
    BridJRuntime.TypeInfo<NativeObject> typeInfo = getTypeInfo(runtime, type);
    instance.typeInfo = typeInfo;
    typeInfo.initialize(instance);
  }
  
  static void initialize(NativeObject instance, Pointer peer, Object... targs) {
    Class<?> instanceClass = instance.getClass();
    BridJRuntime runtime = getRuntime(instanceClass);
    Type type = runtime.getType(instanceClass, targs, null);
    BridJRuntime.TypeInfo<NativeObject> typeInfo = getTypeInfo(runtime, type);
    instance.typeInfo = typeInfo;
    typeInfo.initialize(instance, peer);
  }
  
  static void initialize(NativeObject instance, int constructorId, Object[] targsAndArgs) {
    Class<?> instanceClass = instance.getClass();
    BridJRuntime runtime = getRuntime(instanceClass);
    int[] typeParamCount = new int[1];
    Type type = runtime.getType(instanceClass, targsAndArgs, typeParamCount);
    int targsCount = typeParamCount[0];
    Object[] args = Utils.takeRight(targsAndArgs, targsAndArgs.length - targsCount);
    BridJRuntime.TypeInfo<NativeObject> typeInfo = getTypeInfo(runtime, type);
    instance.typeInfo = typeInfo;
    typeInfo.initialize(instance, constructorId, args);
  }
  
  static <T extends NativeObject> T clone(T instance) throws CloneNotSupportedException {
    return ((NativeObject)instance).typeInfo.clone(instance);
  }
  
  public static <T extends NativeObject> T readFromNative(T instance) {
    ((NativeObject)instance).typeInfo.readFromNative(instance);
    return instance;
  }
  
  public static <T extends NativeObject> T writeToNative(T instance) {
    ((NativeObject)instance).typeInfo.writeToNative(instance);
    return instance;
  }
  
  public static String describe(NativeObject instance) {
    return instance.typeInfo.describe(instance);
  }
  
  public static String describe(Type nativeObjectType) {
    BridJRuntime runtime = getRuntime(Utils.getClass(nativeObjectType));
    BridJRuntime.TypeInfo<NativeObject> typeInfo = getTypeInfo(runtime, nativeObjectType);
    return (typeInfo == null) ? Utils.toString(nativeObjectType) : typeInfo.describe();
  }
  
  public static void main(String[] args) {
    List<NativeLibrary> libraries = new ArrayList<NativeLibrary>();
    try {
      File outputDir = new File(".");
      for (int iArg = 0, nArgs = args.length; iArg < nArgs; iArg++) {
        String arg = args[iArg];
        if (arg.equals("-d")) {
          outputDir = new File(args[++iArg]);
        } else {
          try {
            NativeLibrary lib = getNativeLibrary(arg);
            libraries.add(lib);
            PrintWriter sout = new PrintWriter(new File(outputDir, (new File(arg)).getName() + ".symbols.txt"));
            for (Demangler.Symbol sym : lib.getSymbols()) {
              sout.print(sym.getSymbol());
              sout.print(" // ");
              try {
                Demangler.MemberRef mr = sym.getParsedRef();
                sout.print(" // " + mr);
              } catch (Throwable th) {
                sout.print("?");
              } 
              sout.println();
            } 
            sout.close();
          } catch (Throwable th) {
            th.printStackTrace();
          } 
        } 
      } 
      PrintWriter out = new PrintWriter(new File(outputDir, "out.h"));
      HeadersReconstructor.reconstructHeaders(libraries, out);
      out.close();
    } catch (Exception ex) {
      ex.printStackTrace();
      System.exit(1);
    } 
  }
}
