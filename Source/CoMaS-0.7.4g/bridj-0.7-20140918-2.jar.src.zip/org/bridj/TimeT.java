package org.bridj;

import java.util.Date;
import java.util.List;
import org.bridj.ann.Field;
import org.bridj.ann.Struct;

public final class TimeT extends AbstractIntegral {
  public static final int SIZE = Platform.TIME_T_SIZE;
  
  static {
    BridJ.register();
  }
  
  public TimeT(long value) {
    super(value);
  }
  
  public int byteSize() {
    return SIZE;
  }
  
  public Date toDate() {
    return new Date(this.value);
  }
  
  public static TimeT valueOf(long value) {
    return new TimeT(value);
  }
  
  public static TimeT valueOf(Date value) {
    return valueOf(value.getTime());
  }
  
  public String toString() {
    return "TimeT(value = " + this.value + ", time = " + toDate() + ")";
  }
  
  @Struct(customizer = timeval_customizer.class)
  public static class timeval extends StructObject {
    public long getTime() {
      return seconds() * 1000L + milliseconds();
    }
    
    @Field(0)
    public long seconds() {
      return this.io.getCLongField(this, 0);
    }
    
    @Field(0)
    public timeval seconds(long seconds) {
      this.io.setCLongField(this, 0, seconds);
      return this;
    }
    
    public final long seconds_$eq(long seconds) {
      seconds(seconds);
      return seconds;
    }
    
    @Field(1)
    public int milliseconds() {
      return this.io.getIntField(this, 1);
    }
    
    @Field(1)
    public timeval milliseconds(int milliseconds) {
      this.io.setIntField(this, 1, milliseconds);
      return this;
    }
    
    public final int milliseconds_$eq(int milliseconds) {
      milliseconds(milliseconds);
      return milliseconds;
    }
  }
  
  public static class timeval_customizer extends StructCustomizer {
    public void beforeLayout(StructDescription desc, List<StructFieldDescription> aggregatedFields) {
      StructFieldDescription secondsField = aggregatedFields.get(0);
      if (Platform.isWindows() || !Platform.is64Bits()) {
        secondsField.byteLength = 4L;
      } else {
        secondsField.byteLength = 8L;
      } 
      secondsField.alignment = secondsField.byteLength;
    }
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\TimeT.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */