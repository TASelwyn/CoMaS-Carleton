package org.bridj;

import org.bridj.ann.Runtime;

@Runtime(CRuntime.class)
public abstract class Callback<C extends Callback<C>> extends NativeObject implements CallbackInterface {
  public Pointer<C> toPointer() {
    return Pointer.getPointer((C)this);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\Callback.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */