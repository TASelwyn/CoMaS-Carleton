package org.bridj;

import org.bridj.ann.Runtime;

@Runtime(CRuntime.class)
public abstract class Callback<C extends Callback<C>> extends NativeObject implements CallbackInterface {
  public Pointer<C> toPointer() {
    return Pointer.getPointer((C)this);
  }
}
