package org.bridj.jawt;

import org.bridj.BridJ;
import org.bridj.CRuntime;
import org.bridj.Pointer;
import org.bridj.TypedPointer;
import org.bridj.ann.Library;
import org.bridj.ann.Runtime;

@Library("jawt")
@Runtime(CRuntime.class)
public class JawtLibrary {
  public static final int JAWT_LOCK_CLIP_CHANGED = 2;
  
  public static final int JAWT_VERSION_1_4 = 65540;
  
  public static final int JAWT_VERSION_1_3 = 65539;
  
  public static final int JAWT_LOCK_SURFACE_CHANGED = 8;
  
  public static final int JAWT_LOCK_ERROR = 1;
  
  public static final int JAWT_LOCK_BOUNDS_CHANGED = 4;
  
  public static native boolean JAWT_GetAWT(Pointer<JNIEnv> paramPointer, Pointer<JAWT> paramPointer1);
  
  static {
    BridJ.register();
  }
  
  public static class JNIEnv extends TypedPointer {
    public JNIEnv(long address) {
      super(address);
    }
    
    public JNIEnv(Pointer address) {
      super(address);
    }
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\jawt\JawtLibrary.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */