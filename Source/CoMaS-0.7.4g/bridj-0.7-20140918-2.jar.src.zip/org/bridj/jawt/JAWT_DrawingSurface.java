/*    */ package org.bridj.jawt;
/*    */ 
/*    */ import org.bridj.Callback;
/*    */ import org.bridj.Pointer;
/*    */ import org.bridj.StructObject;
/*    */ import org.bridj.ann.Convention;
/*    */ import org.bridj.ann.Field;
/*    */ import org.bridj.ann.Library;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Library("jawt")
/*    */ @Convention(Convention.Style.StdCall)
/*    */ public class JAWT_DrawingSurface
/*    */   extends StructObject
/*    */ {
/*    */   @Field(0)
/*    */   public Pointer env() {
/* 64 */     return this.io.getPointerField(this, 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Field(1)
/*    */   public Pointer target() {
/* 73 */     return this.io.getPointerField(this, 1);
/*    */   }
/*    */   
/*    */   @Field(2)
/*    */   public Pointer<Lock_callback> Lock() {
/* 78 */     return this.io.getPointerField(this, 2);
/*    */   }
/*    */   
/*    */   @Field(3)
/*    */   public Pointer<GetDrawingSurfaceInfo_callback> GetDrawingSurfaceInfo() {
/* 83 */     return this.io.getPointerField(this, 3);
/*    */   }
/*    */   
/*    */   @Field(4)
/*    */   public Pointer<FreeDrawingSurfaceInfo_callback> FreeDrawingSurfaceInfo() {
/* 88 */     return this.io.getPointerField(this, 4);
/*    */   }
/*    */   
/*    */   @Field(5)
/*    */   public Pointer<Unlock_callback> Unlock() {
/* 93 */     return this.io.getPointerField(this, 5);
/*    */   }
/*    */   
/*    */   public static abstract class Lock_callback extends Callback {
/*    */     public abstract int invoke(Pointer<JAWT_DrawingSurface> param1Pointer);
/*    */   }
/*    */   
/*    */   public static abstract class GetDrawingSurfaceInfo_callback extends Callback {
/*    */     public abstract Pointer<JAWT_DrawingSurfaceInfo> invoke(Pointer<JAWT_DrawingSurface> param1Pointer);
/*    */   }
/*    */   
/*    */   public static abstract class FreeDrawingSurfaceInfo_callback extends Callback {
/*    */     public abstract void invoke(Pointer<JAWT_DrawingSurfaceInfo> param1Pointer);
/*    */   }
/*    */   
/*    */   public static abstract class Unlock_callback extends Callback {
/*    */     public abstract void invoke(Pointer<JAWT_DrawingSurface> param1Pointer);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\jawt\JAWT_DrawingSurface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */