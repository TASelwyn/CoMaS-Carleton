package org.bridj.jawt;

import org.bridj.StructObject;
import org.bridj.ann.Field;
import org.bridj.ann.Library;

@Library("jawt")
public class JAWT_Rectangle extends StructObject {
  @Field(0)
  public int x() {
    return this.io.getIntField(this, 0);
  }
  
  @Field(1)
  public int y() {
    return this.io.getIntField(this, 1);
  }
  
  @Field(2)
  public int width() {
    return this.io.getIntField(this, 2);
  }
  
  @Field(3)
  public int height() {
    return this.io.getIntField(this, 3);
  }
}
