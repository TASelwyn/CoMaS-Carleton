/*    */ package org.bridj.jawt;
/*    */ 
/*    */ import org.bridj.StructObject;
/*    */ import org.bridj.ann.Field;
/*    */ import org.bridj.ann.Library;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Library("jawt")
/*    */ public class JAWT_Rectangle
/*    */   extends StructObject
/*    */ {
/*    */   @Field(0)
/*    */   public int x() {
/* 54 */     return this.io.getIntField(this, 0);
/*    */   }
/*    */   
/*    */   @Field(1)
/*    */   public int y() {
/* 59 */     return this.io.getIntField(this, 1);
/*    */   }
/*    */   
/*    */   @Field(2)
/*    */   public int width() {
/* 64 */     return this.io.getIntField(this, 2);
/*    */   }
/*    */   
/*    */   @Field(3)
/*    */   public int height() {
/* 69 */     return this.io.getIntField(this, 3);
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\jawt\JAWT_Rectangle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */