package org.bridj.jawt;

import org.bridj.Pointer;
import org.bridj.StructObject;
import org.bridj.ann.Field;
import org.bridj.ann.Library;

@Library("jawt")
public class JAWT_DrawingSurfaceInfo extends StructObject {
  @Field(0)
  public Pointer platformInfo() {
    return this.io.getPointerField(this, 0);
  }
  
  @Field(1)
  public Pointer ds() {
    return this.io.getPointerField(this, 1);
  }
  
  @Field(2)
  public JAWT_Rectangle bounds() {
    return (JAWT_Rectangle)this.io.getNativeObjectField(this, 2);
  }
  
  @Field(3)
  public int clipSize() {
    return this.io.getIntField(this, 3);
  }
  
  @Field(4)
  public JAWT_Rectangle clip() {
    return (JAWT_Rectangle)this.io.getNativeObjectField(this, 4);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\jawt\JAWT_DrawingSurfaceInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */