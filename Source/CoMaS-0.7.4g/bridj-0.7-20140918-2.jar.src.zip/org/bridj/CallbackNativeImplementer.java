/*     */ package org.bridj;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.bridj.ann.Convention;
/*     */ import org.bridj.relocated.org.objectweb.asm.ClassWriter;
/*     */ import org.bridj.relocated.org.objectweb.asm.Label;
/*     */ import org.bridj.relocated.org.objectweb.asm.MethodVisitor;
/*     */ import org.bridj.util.ASMUtils;
/*     */ import org.bridj.util.ClassDefiner;
/*     */ import org.bridj.util.JNIUtils;
/*     */ import org.bridj.util.Pair;
/*     */ import org.bridj.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CallbackNativeImplementer
/*     */   extends ClassLoader
/*     */   implements ClassDefiner
/*     */ {
/*  63 */   ConcurrentHashMap<Class<? extends CallbackInterface>, Class<?>> implClasses = new ConcurrentHashMap<Class<? extends CallbackInterface>, Class<?>>();
/*  64 */   String implNameSuffix = "_NativeImpl";
/*     */   final NativeEntities nativeEntities;
/*     */   final CRuntime runtime;
/*     */   volatile ClassDefiner classDefiner;
/*     */   protected Map<Pair<NativeLibrary, Pair<Convention.Style, List<Type>>>, DynamicFunctionFactory> dynamicCallbacks;
/*     */   
/*  70 */   public CallbackNativeImplementer(NativeEntities nativeEntities, CRuntime runtime) { super(Platform.getClassLoader());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     this.dynamicCallbacks = new HashMap<Pair<NativeLibrary, Pair<Convention.Style, List<Type>>>, DynamicFunctionFactory>(); this.nativeEntities = nativeEntities; this.runtime = runtime; }
/* 118 */   public synchronized ClassDefiner getClassDefiner() { if (this.classDefiner == null) this.classDefiner = PlatformSupport.getInstance().getClassDefiner(this, this);  return this.classDefiner; } private static volatile long nextDynamicCallbackId = 0L;
/*     */   public <T extends CallbackInterface> Class<? extends T> getCallbackImplType(Class<T> callbackType, NativeLibrary forcedLibrary) { Class<?> callbackImplType = this.implClasses.get(callbackType); if (callbackImplType == null)
/*     */       try { String callbackTypeName = callbackType.getName().replace('.', '/'); String callbackTypeImplName = callbackTypeName.replace('$', '_') + this.implNameSuffix; String sourceFile = callbackType.getSimpleName() + this.implNameSuffix + ".java"; Method callbackMethod = this.runtime.getFastestCallbackMethod(callbackType); Class<?>[] parameterTypes = callbackMethod.getParameterTypes(); MethodCallInfo mci = new MethodCallInfo(callbackMethod); String methodName = callbackMethod.getName(); String methodSignature = mci.getJavaSignature(); byte[] byteArray = emitBytes(sourceFile, callbackTypeName, callbackTypeImplName, methodName, methodSignature); callbackImplType = getClassDefiner().defineClass(callbackTypeImplName.replace('/', '.'), byteArray); Class<?> existingCallbackImplType = this.implClasses.putIfAbsent(callbackType, callbackImplType); if (existingCallbackImplType != null)
/* 121 */           return (Class)existingCallbackImplType;  this.runtime.register(callbackImplType, forcedLibrary, null); } catch (Exception ex) { throw new RuntimeException("Failed to create implementation class for callback type " + callbackType.getName() + " : " + ex, ex); }   return (Class)callbackImplType; } private static synchronized long getNextDynamicCallbackId() { return nextDynamicCallbackId++; }
/*     */ 
/*     */   
/*     */   public synchronized DynamicFunctionFactory getDynamicCallback(NativeLibrary library, final Convention.Style callingConvention, Type returnType, Type... paramTypes) {
/* 125 */     List<Type> list = new ArrayList<Type>(paramTypes.length + 1);
/* 126 */     list.add(returnType);
/* 127 */     list.addAll(Arrays.asList(paramTypes));
/* 128 */     Pair<Convention.Style, List<Type>> pl = new Pair(callingConvention, list);
/* 129 */     Pair<NativeLibrary, Pair<Convention.Style, List<Type>>> key = new Pair(library, pl);
/* 130 */     DynamicFunctionFactory cb = this.dynamicCallbacks.get(key);
/* 131 */     if (cb == null) {
/*     */       try {
/* 133 */         StringBuilder javaSig = new StringBuilder("("), desc = new StringBuilder();
/* 134 */         for (Type paramType : paramTypes) {
/* 135 */           javaSig.append(JNIUtils.getNativeSignature(Utils.getClass(paramType)));
/* 136 */           desc.append(ASMUtils.typeDesc(paramType));
/*     */         } 
/* 138 */         javaSig.append(")").append(JNIUtils.getNativeSignature(Utils.getClass(returnType)));
/* 139 */         desc.append("To").append(ASMUtils.typeDesc(returnType)).append("_").append(getNextDynamicCallbackId());
/*     */         
/* 141 */         String callbackTypeImplName = "org/bridj/dyncallbacks/" + desc;
/* 142 */         String methodName = "apply";
/*     */         
/* 144 */         byte[] byteArray = emitBytes("<anonymous>", DynamicFunction.class.getName().replace(".", "/"), callbackTypeImplName, methodName, javaSig.toString());
/* 145 */         Class<? extends DynamicFunction> callbackImplType = getClassDefiner().defineClass(callbackTypeImplName.replace('/', '.'), byteArray);
/*     */         
/* 147 */         Class<?>[] paramClasses = new Class[paramTypes.length];
/* 148 */         for (int i = 0, n = paramTypes.length; i < n; i++) {
/* 149 */           paramClasses[i] = Utils.getClass(paramTypes[i]);
/*     */         }
/*     */         
/* 152 */         CRuntime.MethodCallInfoBuilder methodCallInfoBuilder = new CRuntime.MethodCallInfoBuilder() {
/*     */             public MethodCallInfo apply(Method method) throws FileNotFoundException {
/* 154 */               MethodCallInfo mci = super.apply(method);
/* 155 */               mci.setCallingConvention(callingConvention);
/* 156 */               return mci;
/*     */             }
/*     */           };
/* 159 */         cb = new DynamicFunctionFactory(callbackImplType, callbackImplType.getMethod(methodName, paramClasses), methodCallInfoBuilder);
/* 160 */         this.dynamicCallbacks.put(key, cb);
/*     */         
/* 162 */         this.runtime.register(callbackImplType, null, methodCallInfoBuilder);
/*     */       }
/* 164 */       catch (Throwable th) {
/* 165 */         th.printStackTrace();
/* 166 */         throw new RuntimeException("Failed to create callback for " + list + " : " + th, th);
/*     */       } 
/*     */     }
/* 169 */     return cb;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] emitBytes(String sourceFile, String callbackTypeName, String callbackTypeImplName, String methodName, String methodSignature) {
/* 175 */     ClassWriter cw = new ClassWriter(0);
/* 176 */     cw.visit(49, 33, callbackTypeImplName, null, callbackTypeName, null);
/*     */ 
/*     */ 
/*     */     
/* 180 */     cw.visitSource(sourceFile, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 188 */     MethodVisitor mv = cw.visitMethod(1, "<init>", "()V", null, null);
/* 189 */     mv.visitCode();
/* 190 */     Label l0 = new Label();
/* 191 */     mv.visitLabel(l0);
/* 192 */     mv.visitLineNumber(5, l0);
/* 193 */     mv.visitVarInsn(25, 0);
/* 194 */     mv.visitMethodInsn(183, callbackTypeName, "<init>", "()V");
/*     */     
/* 196 */     mv.visitInsn(177);
/* 197 */     Label l1 = new Label();
/* 198 */     mv.visitLabel(l1);
/* 199 */     mv.visitLocalVariable("this", "L" + callbackTypeImplName + ";", null, l0, l1, 0);
/*     */     
/* 201 */     mv.visitMaxs(1, 1);
/* 202 */     mv.visitEnd();
/*     */ 
/*     */     
/* 205 */     mv = cw.visitMethod(257, methodName, methodSignature, null, null);
/* 206 */     mv.visitEnd();
/*     */     
/* 208 */     cw.visitEnd();
/*     */     
/* 210 */     return cw.toByteArray();
/*     */   }
/*     */   
/*     */   public Class<?> defineClass(String className, byte[] data) throws ClassFormatError {
/* 214 */     return defineClass(className, data, 0, data.length);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\CallbackNativeImplementer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */