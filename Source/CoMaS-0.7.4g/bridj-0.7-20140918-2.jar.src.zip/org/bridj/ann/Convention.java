/*    */ package org.bridj.ann;
/*    */ 
/*    */ import java.lang.annotation.ElementType;
/*    */ import java.lang.annotation.Inherited;
/*    */ import java.lang.annotation.Retention;
/*    */ import java.lang.annotation.RetentionPolicy;
/*    */ import java.lang.annotation.Target;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Retention(RetentionPolicy.RUNTIME)
/*    */ @Target({ElementType.METHOD, ElementType.TYPE, ElementType.FIELD, ElementType.PACKAGE, ElementType.PARAMETER, ElementType.CONSTRUCTOR})
/*    */ @Inherited
/*    */ public @interface Convention
/*    */ {
/*    */   Style value();
/*    */   
/*    */   public enum Style
/*    */   {
/* 61 */     StdCall,
/*    */ 
/*    */ 
/*    */     
/* 65 */     FastCall,
/*    */ 
/*    */ 
/*    */     
/* 69 */     CDecl,
/* 70 */     Pascal,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 75 */     CLRCall,
/*    */ 
/*    */ 
/*    */     
/* 79 */     ThisCall;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\ann\Convention.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */