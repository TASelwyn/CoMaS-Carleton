package org.bridj.ann;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.bridj.StructCustomizer;

@Target({ElementType.CONSTRUCTOR, ElementType.FIELD, ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
public @interface Struct {
  int pack() default -1;
  
  int fieldCount() default -1;
  
  int size() default -1;
  
  Class<? extends StructCustomizer> customizer() default StructCustomizer.class;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\ann\Struct.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */