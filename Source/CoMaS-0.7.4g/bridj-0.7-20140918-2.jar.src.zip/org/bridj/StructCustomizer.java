/*     */ package org.bridj;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.bridj.ann.Struct;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class StructCustomizer
/*     */ {
/*     */   public void beforeAggregation(StructDescription desc, List<StructFieldDeclaration> fieldDecls) {}
/*     */   
/*     */   public void beforeLayout(StructDescription desc, List<StructFieldDescription> aggregatedFields) {}
/*     */   
/*     */   public void afterLayout(StructDescription desc, List<StructFieldDescription> aggregatedFields) {}
/*     */   
/*     */   public void afterBuild(StructDescription desc) {}
/*     */   
/*  78 */   private static StructCustomizer dummyCustomizer = new StructCustomizer();
/*  79 */   private static ConcurrentHashMap<Class, StructCustomizer> customizers = new ConcurrentHashMap<Class<?>, StructCustomizer>();
/*     */   
/*     */   static StructCustomizer getInstance(Class<?> structClass) {
/*  82 */     StructCustomizer c = customizers.get(structClass);
/*  83 */     if (c == null) {
/*  84 */       Struct s = structClass.<Struct>getAnnotation(Struct.class);
/*  85 */       if (s != null) {
/*  86 */         Class<? extends StructCustomizer> customizerClass = s.customizer();
/*  87 */         if (customizerClass != null && customizerClass != StructCustomizer.class) {
/*     */           try {
/*  89 */             c = customizerClass.newInstance();
/*  90 */           } catch (Throwable th) {
/*  91 */             throw new RuntimeException("Failed to create customizer of class " + customizerClass.getName() + " for struct class " + structClass.getName() + " : " + th, th);
/*     */           } 
/*     */         }
/*     */       } 
/*  95 */       if (c == null) {
/*  96 */         c = dummyCustomizer;
/*     */       }
/*  98 */       StructCustomizer existingConcurrentCustomizer = customizers.putIfAbsent(structClass, c);
/*     */       
/* 100 */       if (existingConcurrentCustomizer != null) {
/* 101 */         return existingConcurrentCustomizer;
/*     */       }
/*     */     } 
/* 104 */     return c;
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\StructCustomizer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */