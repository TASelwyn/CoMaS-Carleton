package org.bridj;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

public class OSGiBundleActivator implements BundleActivator {
  public void start(BundleContext bundleContext) {}
  
  public void stop(BundleContext bundleContext) {}
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\OSGiBundleActivator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */