package org.bridj;

import java.io.IOException;
import org.bridj.util.ClassDefiner;

class PlatformSupport {
  private static final PlatformSupport instance;
  
  public ClassDefiner getClassDefiner(ClassDefiner defaultDefiner, ClassLoader parentClassLoader) {
    return defaultDefiner;
  }
  
  static {
    PlatformSupport _instance = null;
    if (Platform.isAndroid())
      try {
        _instance = (PlatformSupport)Class.forName("org.bridj.AndroidSupport").newInstance();
      } catch (Exception ex) {
        throw new RuntimeException("Failed to instantiate the Android support class... Was the BridJ jar tampered with / trimmed too much ?", ex);
      }  
    if (_instance == null)
      _instance = new PlatformSupport(); 
    instance = _instance;
  }
  
  public static PlatformSupport getInstance() {
    return instance;
  }
  
  public NativeLibrary loadNativeLibrary(String name) throws IOException {
    return null;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\PlatformSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */