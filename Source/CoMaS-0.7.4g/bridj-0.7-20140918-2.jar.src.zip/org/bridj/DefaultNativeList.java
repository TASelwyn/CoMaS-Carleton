/*     */ package org.bridj;
/*     */ 
/*     */ import java.util.AbstractList;
/*     */ import java.util.Collection;
/*     */ import java.util.RandomAccess;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultNativeList<T>
/*     */   extends AbstractList<T>
/*     */   implements NativeList<T>, RandomAccess
/*     */ {
/*     */   final Pointer.ListType type;
/*     */   final PointerIO<T> io;
/*     */   volatile Pointer<T> pointer;
/*     */   volatile long size;
/*     */   
/*     */   public Pointer<?> getPointer() {
/*  65 */     return this.pointer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DefaultNativeList(Pointer<T> pointer, Pointer.ListType type) {
/*  76 */     if (pointer == null || type == null) {
/*  77 */       throw new IllegalArgumentException("Cannot build a " + getClass().getSimpleName() + " with " + pointer + " and " + type);
/*     */     }
/*     */     
/*  80 */     this.io = pointer.getIO("Cannot create a list out of untyped pointer " + pointer);
/*  81 */     this.type = type;
/*  82 */     this.size = pointer.getValidElements();
/*  83 */     this.pointer = pointer;
/*     */   }
/*     */   
/*     */   protected void checkModifiable() {
/*  87 */     if (this.type == Pointer.ListType.Unmodifiable) {
/*  88 */       throw new UnsupportedOperationException("This list is unmodifiable");
/*     */     }
/*     */   }
/*     */   
/*     */   protected int safelyCastLongToInt(long i, String content) {
/*  93 */     if (i > 2147483647L) {
/*  94 */       throw new RuntimeException(content + " is bigger than Java int's maximum value : " + i);
/*     */     }
/*     */     
/*  97 */     return (int)i;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 102 */     return safelyCastLongToInt(this.size, "Size of the native list");
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 107 */     checkModifiable();
/* 108 */     this.size = 0L;
/*     */   }
/*     */ 
/*     */   
/*     */   public T get(int i) {
/* 113 */     if (i >= this.size || i < 0) {
/* 114 */       throw new IndexOutOfBoundsException("Invalid index : " + i + " (list has size " + this.size + ")");
/*     */     }
/*     */     
/* 117 */     return this.pointer.get(i);
/*     */   }
/*     */ 
/*     */   
/*     */   public T set(int i, T e) {
/* 122 */     checkModifiable();
/* 123 */     if (i >= this.size || i < 0) {
/* 124 */       throw new IndexOutOfBoundsException("Invalid index : " + i + " (list has size " + this.size + ")");
/*     */     }
/*     */     
/* 127 */     T old = this.pointer.get(i);
/* 128 */     this.pointer.set(i, e);
/* 129 */     return old;
/*     */   }
/*     */   
/*     */   void add(long i, T e) {
/* 133 */     checkModifiable();
/* 134 */     if (i > this.size || i < 0L) {
/* 135 */       throw new IndexOutOfBoundsException("Invalid index : " + i + " (list has size " + this.size + ")");
/*     */     }
/* 137 */     requireSize(this.size + 1L);
/* 138 */     if (i < this.size) {
/* 139 */       this.pointer.moveBytesAtOffsetTo(i, this.pointer, i + 1L, this.size - i);
/*     */     }
/* 141 */     this.pointer.set(i, e);
/* 142 */     this.size++;
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(int i, T e) {
/* 147 */     add(i, e);
/*     */   }
/*     */   
/*     */   protected void requireSize(long newSize) {
/* 151 */     if (newSize > this.pointer.getValidElements()) {
/* 152 */       long nextSize; Pointer<T> newPointer; switch (this.type) {
/*     */         case Dynamic:
/* 154 */           nextSize = (newSize < 5L) ? (newSize + 1L) : (long)(newSize * 1.6D);
/* 155 */           newPointer = Pointer.allocateArray(this.io, nextSize);
/* 156 */           this.pointer.copyTo(newPointer);
/* 157 */           this.pointer = newPointer;
/*     */           break;
/*     */         case FixedCapacity:
/* 160 */           throw new UnsupportedOperationException("This list has a fixed capacity, cannot grow its storage");
/*     */         
/*     */         case Unmodifiable:
/* 163 */           checkModifiable();
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   T remove(long i) {
/* 169 */     checkModifiable();
/* 170 */     if (i >= this.size || i < 0L) {
/* 171 */       throw new IndexOutOfBoundsException("Invalid index : " + i + " (list has size " + this.size + ")");
/*     */     }
/* 173 */     T old = this.pointer.get(i);
/* 174 */     long targetSize = this.io.getTargetSize();
/* 175 */     this.pointer.moveBytesAtOffsetTo((i + 1L) * targetSize, this.pointer, i * targetSize, targetSize);
/* 176 */     this.size--;
/* 177 */     return old;
/*     */   }
/*     */ 
/*     */   
/*     */   public T remove(int i) {
/* 182 */     return remove(i);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object o) {
/* 187 */     checkModifiable();
/* 188 */     long i = indexOf(o, true, 0);
/* 189 */     if (i < 0L) {
/* 190 */       return false;
/*     */     }
/*     */     
/* 193 */     remove(i);
/* 194 */     return true;
/*     */   }
/*     */   
/*     */   long indexOf(Object o, boolean last, int offset) {
/* 198 */     Pointer<T> pointer = this.pointer;
/* 199 */     assert offset >= 0 && (last || offset > 0);
/* 200 */     if (offset > 0) {
/* 201 */       pointer = pointer.next(offset);
/*     */     }
/*     */     
/* 204 */     Pointer<T> needle = Pointer.allocate(this.io);
/* 205 */     needle.set((T)o);
/* 206 */     Pointer<T> occurrence = last ? pointer.findLast(needle) : pointer.find(needle);
/* 207 */     if (occurrence == null) {
/* 208 */       return -1L;
/*     */     }
/*     */     
/* 211 */     return occurrence.getPeer() - pointer.getPeer();
/*     */   }
/*     */ 
/*     */   
/*     */   public int indexOf(Object o) {
/* 216 */     return safelyCastLongToInt(indexOf(o, false, 0), "Index of the object");
/*     */   }
/*     */ 
/*     */   
/*     */   public int lastIndexOf(Object o) {
/* 221 */     return safelyCastLongToInt(indexOf(o, true, 0), "Last index of the object");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object o) {
/* 226 */     return (indexOf(o) >= 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(int i, Collection<? extends T> clctn) {
/* 231 */     if (i >= 0 && i < this.size) {
/* 232 */       requireSize(this.size + clctn.size());
/*     */     }
/* 234 */     return super.addAll(i, clctn);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 239 */     return this.pointer.validElements(this.size).toArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T[] toArray(T[] ts) {
/* 244 */     return (T[])this.pointer.validElements(this.size).toArray((Object[])ts);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\DefaultNativeList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */