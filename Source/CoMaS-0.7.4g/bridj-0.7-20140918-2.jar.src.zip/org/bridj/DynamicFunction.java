package org.bridj;

import java.lang.reflect.Method;

public abstract class DynamicFunction<R> extends Callback {
  DynamicFunctionFactory factory;
  
  Method method;
  
  public R apply(Object... args) {
    try {
      return (R)this.method.invoke(this, args);
    } catch (Throwable th) {
      th.printStackTrace();
      throw new RuntimeException("Failed to invoke callback : " + th, th);
    } 
  }
  
  public String toString() {
    return this.method.toString();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\DynamicFunction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */