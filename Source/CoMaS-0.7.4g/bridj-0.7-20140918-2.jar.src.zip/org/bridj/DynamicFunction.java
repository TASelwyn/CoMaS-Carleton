/*    */ package org.bridj;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DynamicFunction<R>
/*    */   extends Callback
/*    */ {
/*    */   DynamicFunctionFactory factory;
/*    */   Method method;
/*    */   
/*    */   public R apply(Object... args) {
/*    */     try {
/* 58 */       return (R)this.method.invoke(this, args);
/* 59 */     } catch (Throwable th) {
/* 60 */       th.printStackTrace();
/* 61 */       throw new RuntimeException("Failed to invoke callback : " + th, th);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 67 */     return this.method.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\DynamicFunction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */