package org.bridj;

import java.lang.reflect.Type;

public interface BridJRuntime {
  Type getType(NativeObject paramNativeObject);
  
  void register(Type paramType);
  
  void unregister(Type paramType);
  
  <T extends NativeObject> TypeInfo<T> getTypeInfo(Type paramType);
  
  Type getType(Class<?> paramClass, Object[] paramArrayOfObject, int[] paramArrayOfint);
  
  boolean isAvailable();
  
  <T extends NativeObject> Class<? extends T> getActualInstanceClass(Pointer<T> paramPointer, Type paramType);
  
  public static interface TypeInfo<T extends NativeObject> {
    T cast(Pointer param1Pointer);
    
    void initialize(T param1T);
    
    void initialize(T param1T, Pointer param1Pointer);
    
    void initialize(T param1T, int param1Int, Object[] param1ArrayOfObject);
    
    void destroy(T param1T);
    
    T createReturnInstance();
    
    T clone(T param1T) throws CloneNotSupportedException;
    
    BridJRuntime getRuntime();
    
    Type getType();
    
    boolean equal(T param1T1, T param1T2);
    
    int compare(T param1T1, T param1T2);
    
    long sizeOf();
    
    void writeToNative(T param1T);
    
    String describe(T param1T);
    
    String describe();
    
    void readFromNative(T param1T);
    
    void copyNativeObjectToAddress(T param1T, Pointer<T> param1Pointer);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\BridJRuntime.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */