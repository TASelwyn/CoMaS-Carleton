package org.bridj;

import java.util.ArrayList;
import java.util.List;

final class SolidRanges {
  public final long[] offsets;
  
  public final long[] lengths;
  
  public SolidRanges(long[] offsets, long[] lengths) {
    this.offsets = offsets;
    this.lengths = lengths;
  }
  
  static class Builder {
    List<Long> offsets = new ArrayList<Long>();
    
    List<Long> lengths = new ArrayList<Long>();
    
    long lastOffset = -1L;
    
    long nextOffset = 0L;
    
    int count;
    
    void add(StructFieldDescription f) {
      long offset = f.byteOffset;
      long length = f.byteLength;
      if (offset == this.lastOffset) {
        length = Math.max(((Long)this.lengths.get(this.count - 1)).longValue(), length);
        this.lengths.set(this.count - 1, Long.valueOf(length));
      } else if (offset == this.nextOffset && this.count != 0) {
        this.lengths.set(this.count - 1, Long.valueOf(((Long)this.lengths.get(this.count - 1)).longValue() + length));
      } else {
        this.offsets.add(Long.valueOf(offset));
        this.lengths.add(Long.valueOf(length));
        this.count++;
      } 
      this.lastOffset = offset;
      this.nextOffset = offset + length;
    }
    
    SolidRanges toSolidRanges() {
      long[] offsets = new long[this.count];
      long[] lengths = new long[this.count];
      for (int i = 0; i < this.count; i++) {
        offsets[i] = ((Long)this.offsets.get(i)).longValue();
        lengths[i] = ((Long)this.lengths.get(i)).longValue();
      } 
      return new SolidRanges(offsets, lengths);
    }
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\SolidRanges.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */