/*    */ package org.bridj;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SolidRanges
/*    */ {
/*    */   public final long[] offsets;
/*    */   public final long[] lengths;
/*    */   
/*    */   public SolidRanges(long[] offsets, long[] lengths) {
/* 40 */     this.offsets = offsets;
/* 41 */     this.lengths = lengths;
/*    */   }
/*    */   
/*    */   static class Builder
/*    */   {
/* 46 */     List<Long> offsets = new ArrayList<Long>(); List<Long> lengths = new ArrayList<Long>();
/* 47 */     long lastOffset = -1L; long nextOffset = 0L;
/*    */     int count;
/*    */     
/*    */     void add(StructFieldDescription f) {
/* 51 */       long offset = f.byteOffset;
/* 52 */       long length = f.byteLength;
/*    */       
/* 54 */       if (offset == this.lastOffset) {
/* 55 */         length = Math.max(((Long)this.lengths.get(this.count - 1)).longValue(), length);
/* 56 */         this.lengths.set(this.count - 1, Long.valueOf(length));
/* 57 */       } else if (offset == this.nextOffset && this.count != 0) {
/* 58 */         this.lengths.set(this.count - 1, Long.valueOf(((Long)this.lengths.get(this.count - 1)).longValue() + length));
/*    */       } else {
/* 60 */         this.offsets.add(Long.valueOf(offset));
/* 61 */         this.lengths.add(Long.valueOf(length));
/* 62 */         this.count++;
/*    */       } 
/* 64 */       this.lastOffset = offset;
/* 65 */       this.nextOffset = offset + length;
/*    */     }
/*    */     
/*    */     SolidRanges toSolidRanges() {
/* 69 */       long[] offsets = new long[this.count];
/* 70 */       long[] lengths = new long[this.count];
/* 71 */       for (int i = 0; i < this.count; i++) {
/* 72 */         offsets[i] = ((Long)this.offsets.get(i)).longValue();
/* 73 */         lengths[i] = ((Long)this.lengths.get(i)).longValue();
/*    */       } 
/* 75 */       return new SolidRanges(offsets, lengths);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\SolidRanges.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */