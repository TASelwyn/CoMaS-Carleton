package org.bridj;

import java.lang.reflect.Type;
import java.util.List;
import org.bridj.dyncall.DyncallLibrary;
import org.bridj.util.Utils;

class DyncallStructs {
  Pointer<DyncallLibrary.DCstruct> struct;
  
  static int toDCAlignment(long structIOAlignment) {
    return (structIOAlignment <= 0L) ? 0 : (int)structIOAlignment;
  }
  
  public static Pointer<DyncallLibrary.DCstruct> buildDCstruct(StructDescription desc) {
    if (!BridJ.Switch.StructsByValue.enabled)
      return null; 
    List<StructFieldDescription> aggregatedFields = desc.getAggregatedFields();
    Pointer<DyncallLibrary.DCstruct> struct = DyncallLibrary.dcNewStruct(aggregatedFields.size(), toDCAlignment(desc.getStructAlignment())).withReleaser(new Pointer.Releaser() {
          public void release(Pointer<?> p) {
            DyncallLibrary.dcFreeStruct(p.as(DyncallLibrary.DCstruct.class));
          }
        });
    fillDCstruct(desc.structType, struct, aggregatedFields);
    DyncallLibrary.dcCloseStruct(struct);
    long expectedSize = desc.getStructSize();
    long size = DyncallLibrary.dcStructSize(struct);
    if (expectedSize != size) {
      BridJ.error("Struct size computed for " + Utils.toString(desc.structType) + " by BridJ (" + expectedSize + " bytes) and dyncall (" + size + " bytes) differ !");
      return null;
    } 
    return struct;
  }
  
  protected static void fillDCstruct(Type structType, Pointer<DyncallLibrary.DCstruct> struct, List<StructFieldDescription> aggregatedFields) {
    for (StructFieldDescription aggregatedField : aggregatedFields) {
      int dctype;
      StructFieldDeclaration field = aggregatedField.aggregatedFields.get(0);
      Type fieldType = field.desc.nativeTypeOrPointerTargetType;
      if (fieldType == null)
        fieldType = field.desc.valueType; 
      Class<?> fieldClass = Utils.getClass(fieldType);
      int alignment = toDCAlignment(aggregatedField.alignment);
      long arrayLength = field.desc.arrayLength;
      if (StructObject.class.isAssignableFrom(fieldClass)) {
        StructIO subIO = StructIO.getInstance(fieldClass, fieldType);
        List<StructFieldDescription> subAggregatedFields = subIO.desc.getAggregatedFields();
        DyncallLibrary.dcSubStruct(struct, subAggregatedFields.size(), alignment, arrayLength);
        try {
          fillDCstruct(subIO.desc.structType, struct, subAggregatedFields);
        } finally {
          DyncallLibrary.dcCloseStruct(struct);
        } 
        continue;
      } 
      if (fieldClass == int.class) {
        dctype = 105;
      } else if (fieldClass == long.class || fieldClass == Long.class) {
        dctype = 108;
      } else if (fieldClass == short.class || fieldClass == char.class || fieldClass == Short.class || fieldClass == Character.class) {
        dctype = 115;
      } else if (fieldClass == byte.class || fieldClass == boolean.class || fieldClass == Byte.class || fieldClass == Boolean.class) {
        dctype = 99;
      } else if (fieldClass == float.class || fieldClass == Float.class) {
        dctype = 102;
      } else if (fieldClass == double.class || fieldClass == Double.class) {
        dctype = 100;
      } else if (Pointer.class.isAssignableFrom(fieldClass)) {
        dctype = 112;
      } else {
        throw new IllegalArgumentException("Unable to create dyncall struct field for type " + Utils.toString(fieldType) + " in struct " + Utils.toString(structType));
      } 
      DyncallLibrary.dcStructField(struct, dctype, alignment, arrayLength);
    } 
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\DyncallStructs.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */