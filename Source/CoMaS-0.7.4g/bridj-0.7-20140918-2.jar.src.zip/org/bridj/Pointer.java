/*      */ package org.bridj;
/*      */ 
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Type;
/*      */ import java.nio.Buffer;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.DoubleBuffer;
/*      */ import java.nio.FloatBuffer;
/*      */ import java.nio.IntBuffer;
/*      */ import java.nio.LongBuffer;
/*      */ import java.nio.ShortBuffer;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.Arrays;
/*      */ import java.util.Iterator;
/*      */ import java.util.ListIterator;
/*      */ import java.util.NoSuchElementException;
/*      */ import org.bridj.ann.Convention;
/*      */ import org.bridj.util.DefaultParameterizedType;
/*      */ import org.bridj.util.Utils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Pointer<T>
/*      */   implements Comparable<Pointer<?>>, Iterable<T>
/*      */ {
/*  201 */   public static final Pointer<?> NULL = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  208 */   public static final int SIZE = Platform.POINTER_SIZE; protected static final long UNKNOWN_VALIDITY = -1L; protected static final long NO_PARENT = 0L;
/*      */   
/*      */   static {
/*  211 */     Platform.initLibrary();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  217 */   private static final long POINTER_MASK = Platform.is64Bits() ? -1L : 4294967295L;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  222 */   public static final int defaultAlignment = Integer.parseInt(Platform.getenvOrProperty("BRIDJ_DEFAULT_ALIGNMENT", "bridj.defaultAlignment", "-1"));
/*      */   
/*      */   protected final PointerIO<T> io;
/*      */   
/*      */   private final long peer_;
/*      */   
/*      */   protected final long offsetInParent;
/*      */   protected final Pointer<?> parent;
/*      */   protected volatile Object sibling;
/*      */   protected final long validStart;
/*      */   protected final long validEnd;
/*      */   Throwable creationTrace;
/*      */   Throwable deletionTrace;
/*      */   Throwable releaseTrace;
/*      */   private static final int LRU_POINTER_CACHE_SIZE = 8;
/*      */   private static final int LRU_POINTER_CACHE_TOLERANCE = 1;
/*      */   
/*      */   Pointer(PointerIO<T> io, long peer, long validStart, long validEnd, Pointer<?> parent, long offsetInParent, Object sibling) {
/*  240 */     this.io = io;
/*  241 */     this.peer_ = peer;
/*  242 */     this.validStart = validStart;
/*  243 */     this.validEnd = validEnd;
/*  244 */     this.parent = parent;
/*  245 */     this.offsetInParent = offsetInParent;
/*  246 */     this.sibling = sibling;
/*  247 */     if (peer == 0L)
/*  248 */       throw new IllegalArgumentException("Pointer instance cannot have NULL peer ! (use null Pointer instead)"); 
/*  249 */     if (BridJ.debugPointers) {
/*  250 */       this.creationTrace = (new RuntimeException()).fillInStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class OrderedPointer<T>
/*      */     extends Pointer<T>
/*      */   {
/*      */     OrderedPointer(PointerIO<T> io, long peer, long validStart, long validEnd, Pointer<?> parent, long offsetInParent, Object sibling) {
/*  260 */       super(io, peer, validStart, validEnd, parent, offsetInParent, sibling);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isOrdered() {
/*  265 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setInt(int value) {
/*  272 */       long checkedPeer = getPeer() + 0L;
/*  273 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  277 */         invalidPeer(checkedPeer, 4L);
/*      */       }
/*  279 */       JNI.set_int(checkedPeer, value);
/*  280 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Pointer<T> setIntAtOffset(long byteOffset, int value) {
/*  285 */       long checkedPeer = getPeer() + byteOffset;
/*  286 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  290 */         invalidPeer(checkedPeer, 4L);
/*      */       }
/*  292 */       JNI.set_int(checkedPeer, value);
/*  293 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public int getInt() {
/*  298 */       long checkedPeer = getPeer() + 0L;
/*  299 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  303 */         invalidPeer(checkedPeer, 4L);
/*      */       }
/*  305 */       return JNI.get_int(checkedPeer);
/*      */     }
/*      */ 
/*      */     
/*      */     public int getIntAtOffset(long byteOffset) {
/*  310 */       long checkedPeer = getPeer() + byteOffset;
/*  311 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  315 */         invalidPeer(checkedPeer, 4L);
/*      */       }
/*  317 */       return JNI.get_int(checkedPeer);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setLong(long value) {
/*  323 */       long checkedPeer = getPeer() + 0L;
/*  324 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  328 */         invalidPeer(checkedPeer, 8L);
/*      */       }
/*  330 */       JNI.set_long(checkedPeer, value);
/*  331 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Pointer<T> setLongAtOffset(long byteOffset, long value) {
/*  336 */       long checkedPeer = getPeer() + byteOffset;
/*  337 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  341 */         invalidPeer(checkedPeer, 8L);
/*      */       }
/*  343 */       JNI.set_long(checkedPeer, value);
/*  344 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public long getLong() {
/*  349 */       long checkedPeer = getPeer() + 0L;
/*  350 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  354 */         invalidPeer(checkedPeer, 8L);
/*      */       }
/*  356 */       return JNI.get_long(checkedPeer);
/*      */     }
/*      */ 
/*      */     
/*      */     public long getLongAtOffset(long byteOffset) {
/*  361 */       long checkedPeer = getPeer() + byteOffset;
/*  362 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  366 */         invalidPeer(checkedPeer, 8L);
/*      */       }
/*  368 */       return JNI.get_long(checkedPeer);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setShort(short value) {
/*  374 */       long checkedPeer = getPeer() + 0L;
/*  375 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 2L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  379 */         invalidPeer(checkedPeer, 2L);
/*      */       }
/*  381 */       JNI.set_short(checkedPeer, value);
/*  382 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Pointer<T> setShortAtOffset(long byteOffset, short value) {
/*  387 */       long checkedPeer = getPeer() + byteOffset;
/*  388 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 2L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  392 */         invalidPeer(checkedPeer, 2L);
/*      */       }
/*  394 */       JNI.set_short(checkedPeer, value);
/*  395 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public short getShort() {
/*  400 */       long checkedPeer = getPeer() + 0L;
/*  401 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 2L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  405 */         invalidPeer(checkedPeer, 2L);
/*      */       }
/*  407 */       return JNI.get_short(checkedPeer);
/*      */     }
/*      */ 
/*      */     
/*      */     public short getShortAtOffset(long byteOffset) {
/*  412 */       long checkedPeer = getPeer() + byteOffset;
/*  413 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 2L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  417 */         invalidPeer(checkedPeer, 2L);
/*      */       }
/*  419 */       return JNI.get_short(checkedPeer);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setByte(byte value) {
/*  425 */       long checkedPeer = getPeer() + 0L;
/*  426 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  430 */         invalidPeer(checkedPeer, 1L);
/*      */       }
/*  432 */       JNI.set_byte(checkedPeer, value);
/*  433 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Pointer<T> setByteAtOffset(long byteOffset, byte value) {
/*  438 */       long checkedPeer = getPeer() + byteOffset;
/*  439 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  443 */         invalidPeer(checkedPeer, 1L);
/*      */       }
/*  445 */       JNI.set_byte(checkedPeer, value);
/*  446 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public byte getByte() {
/*  451 */       long checkedPeer = getPeer() + 0L;
/*  452 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  456 */         invalidPeer(checkedPeer, 1L);
/*      */       }
/*  458 */       return JNI.get_byte(checkedPeer);
/*      */     }
/*      */ 
/*      */     
/*      */     public byte getByteAtOffset(long byteOffset) {
/*  463 */       long checkedPeer = getPeer() + byteOffset;
/*  464 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  468 */         invalidPeer(checkedPeer, 1L);
/*      */       }
/*  470 */       return JNI.get_byte(checkedPeer);
/*      */     }
/*      */ 
/*      */     
/*      */     public Pointer<T> setChar(char value) {
/*  475 */       if (Platform.WCHAR_T_SIZE == 4) {
/*  476 */         return setInt(value);
/*      */       }
/*  478 */       long checkedPeer = getPeer() + 0L;
/*  479 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + Platform.WCHAR_T_SIZE > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  483 */         invalidPeer(checkedPeer, Platform.WCHAR_T_SIZE);
/*      */       }
/*  485 */       JNI.set_char(checkedPeer, value);
/*  486 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Pointer<T> setCharAtOffset(long byteOffset, char value) {
/*  491 */       if (Platform.WCHAR_T_SIZE == 4)
/*  492 */         return setIntAtOffset(byteOffset, value); 
/*  493 */       long checkedPeer = getPeer() + byteOffset;
/*  494 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + Platform.WCHAR_T_SIZE > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  498 */         invalidPeer(checkedPeer, Platform.WCHAR_T_SIZE);
/*      */       }
/*  500 */       JNI.set_char(checkedPeer, value);
/*  501 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public char getChar() {
/*  506 */       if (Platform.WCHAR_T_SIZE == 4)
/*  507 */         return (char)getInt(); 
/*  508 */       long checkedPeer = getPeer() + 0L;
/*  509 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + Platform.WCHAR_T_SIZE > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  513 */         invalidPeer(checkedPeer, Platform.WCHAR_T_SIZE);
/*      */       }
/*  515 */       return JNI.get_char(checkedPeer);
/*      */     }
/*      */ 
/*      */     
/*      */     public char getCharAtOffset(long byteOffset) {
/*  520 */       if (Platform.WCHAR_T_SIZE == 4)
/*  521 */         return (char)getIntAtOffset(byteOffset); 
/*  522 */       long checkedPeer = getPeer() + byteOffset;
/*  523 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + Platform.WCHAR_T_SIZE > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  527 */         invalidPeer(checkedPeer, Platform.WCHAR_T_SIZE);
/*      */       }
/*  529 */       return JNI.get_char(checkedPeer);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setFloat(float value) {
/*  535 */       long checkedPeer = getPeer() + 0L;
/*  536 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  540 */         invalidPeer(checkedPeer, 4L);
/*      */       }
/*  542 */       JNI.set_float(checkedPeer, value);
/*  543 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Pointer<T> setFloatAtOffset(long byteOffset, float value) {
/*  548 */       long checkedPeer = getPeer() + byteOffset;
/*  549 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  553 */         invalidPeer(checkedPeer, 4L);
/*      */       }
/*  555 */       JNI.set_float(checkedPeer, value);
/*  556 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public float getFloat() {
/*  561 */       long checkedPeer = getPeer() + 0L;
/*  562 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  566 */         invalidPeer(checkedPeer, 4L);
/*      */       }
/*  568 */       return JNI.get_float(checkedPeer);
/*      */     }
/*      */ 
/*      */     
/*      */     public float getFloatAtOffset(long byteOffset) {
/*  573 */       long checkedPeer = getPeer() + byteOffset;
/*  574 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  578 */         invalidPeer(checkedPeer, 4L);
/*      */       }
/*  580 */       return JNI.get_float(checkedPeer);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setDouble(double value) {
/*  586 */       long checkedPeer = getPeer() + 0L;
/*  587 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  591 */         invalidPeer(checkedPeer, 8L);
/*      */       }
/*  593 */       JNI.set_double(checkedPeer, value);
/*  594 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Pointer<T> setDoubleAtOffset(long byteOffset, double value) {
/*  599 */       long checkedPeer = getPeer() + byteOffset;
/*  600 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  604 */         invalidPeer(checkedPeer, 8L);
/*      */       }
/*  606 */       JNI.set_double(checkedPeer, value);
/*  607 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public double getDouble() {
/*  612 */       long checkedPeer = getPeer() + 0L;
/*  613 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  617 */         invalidPeer(checkedPeer, 8L);
/*      */       }
/*  619 */       return JNI.get_double(checkedPeer);
/*      */     }
/*      */ 
/*      */     
/*      */     public double getDoubleAtOffset(long byteOffset) {
/*  624 */       long checkedPeer = getPeer() + byteOffset;
/*  625 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  629 */         invalidPeer(checkedPeer, 8L);
/*      */       }
/*  631 */       return JNI.get_double(checkedPeer);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setBoolean(boolean value) {
/*  637 */       long checkedPeer = getPeer() + 0L;
/*  638 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  642 */         invalidPeer(checkedPeer, 1L);
/*      */       }
/*  644 */       JNI.set_boolean(checkedPeer, value);
/*  645 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Pointer<T> setBooleanAtOffset(long byteOffset, boolean value) {
/*  650 */       long checkedPeer = getPeer() + byteOffset;
/*  651 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  655 */         invalidPeer(checkedPeer, 1L);
/*      */       }
/*  657 */       JNI.set_boolean(checkedPeer, value);
/*  658 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean getBoolean() {
/*  663 */       long checkedPeer = getPeer() + 0L;
/*  664 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  668 */         invalidPeer(checkedPeer, 1L);
/*      */       }
/*  670 */       return JNI.get_boolean(checkedPeer);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean getBooleanAtOffset(long byteOffset) {
/*  675 */       long checkedPeer = getPeer() + byteOffset;
/*  676 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  680 */         invalidPeer(checkedPeer, 1L);
/*      */       }
/*  682 */       return JNI.get_boolean(checkedPeer);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setSizeTsAtOffset(long byteOffset, long[] values, int valuesOffset, int length) {
/*  689 */       if (values == null)
/*  690 */         throw new IllegalArgumentException("Null values"); 
/*  691 */       if (SizeT.SIZE == 8) {
/*  692 */         setLongsAtOffset(byteOffset, values, valuesOffset, length);
/*      */       } else {
/*  694 */         int n = length;
/*  695 */         long checkedPeer = getPeer() + byteOffset;
/*  696 */         if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (n * 4) > this.validEnd))
/*      */         {
/*      */ 
/*      */           
/*  700 */           invalidPeer(checkedPeer, (n * 4));
/*      */         }
/*      */         
/*  703 */         long peer = checkedPeer;
/*  704 */         int valuesIndex = valuesOffset;
/*  705 */         for (int i = 0; i < n; i++) {
/*  706 */           int value = (int)values[valuesIndex];
/*  707 */           JNI.set_int(peer, value);
/*  708 */           peer += 4L;
/*  709 */           valuesIndex++;
/*      */         } 
/*      */       } 
/*  712 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setSizeTsAtOffset(long byteOffset, int[] values) {
/*  719 */       if (SizeT.SIZE == 4) {
/*  720 */         setIntsAtOffset(byteOffset, values);
/*      */       } else {
/*  722 */         int n = values.length;
/*  723 */         long checkedPeer = getPeer() + byteOffset;
/*  724 */         if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (n * 8) > this.validEnd))
/*      */         {
/*      */ 
/*      */           
/*  728 */           invalidPeer(checkedPeer, (n * 8));
/*      */         }
/*      */         
/*  731 */         long peer = checkedPeer;
/*  732 */         for (int i = 0; i < n; i++) {
/*  733 */           int value = values[i];
/*  734 */           JNI.set_long(peer, value);
/*  735 */           peer += 8L;
/*      */         } 
/*      */       } 
/*  738 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setCLongsAtOffset(long byteOffset, long[] values, int valuesOffset, int length) {
/*  744 */       if (values == null)
/*  745 */         throw new IllegalArgumentException("Null values"); 
/*  746 */       if (CLong.SIZE == 8) {
/*  747 */         setLongsAtOffset(byteOffset, values, valuesOffset, length);
/*      */       } else {
/*  749 */         int n = length;
/*  750 */         long checkedPeer = getPeer() + byteOffset;
/*  751 */         if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (n * 4) > this.validEnd))
/*      */         {
/*      */ 
/*      */           
/*  755 */           invalidPeer(checkedPeer, (n * 4));
/*      */         }
/*      */         
/*  758 */         long peer = checkedPeer;
/*  759 */         int valuesIndex = valuesOffset;
/*  760 */         for (int i = 0; i < n; i++) {
/*  761 */           int value = (int)values[valuesIndex];
/*  762 */           JNI.set_int(peer, value);
/*  763 */           peer += 4L;
/*  764 */           valuesIndex++;
/*      */         } 
/*      */       } 
/*  767 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setCLongsAtOffset(long byteOffset, int[] values) {
/*  774 */       if (CLong.SIZE == 4) {
/*  775 */         setIntsAtOffset(byteOffset, values);
/*      */       } else {
/*  777 */         int n = values.length;
/*  778 */         long checkedPeer = getPeer() + byteOffset;
/*  779 */         if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (n * 8) > this.validEnd))
/*      */         {
/*      */ 
/*      */           
/*  783 */           invalidPeer(checkedPeer, (n * 8));
/*      */         }
/*      */         
/*  786 */         long peer = checkedPeer;
/*  787 */         for (int i = 0; i < n; i++) {
/*  788 */           int value = values[i];
/*  789 */           JNI.set_long(peer, value);
/*  790 */           peer += 8L;
/*      */         } 
/*      */       } 
/*  793 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */   static class DisorderedPointer<T> extends Pointer<T> {
/*      */     DisorderedPointer(PointerIO<T> io, long peer, long validStart, long validEnd, Pointer<?> parent, long offsetInParent, Object sibling) {
/*  799 */       super(io, peer, validStart, validEnd, parent, offsetInParent, sibling);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isOrdered() {
/*  804 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setInt(int value) {
/*  811 */       long checkedPeer = getPeer() + 0L;
/*  812 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  816 */         invalidPeer(checkedPeer, 4L);
/*      */       }
/*  818 */       JNI.set_int_disordered(checkedPeer, value);
/*  819 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Pointer<T> setIntAtOffset(long byteOffset, int value) {
/*  824 */       long checkedPeer = getPeer() + byteOffset;
/*  825 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  829 */         invalidPeer(checkedPeer, 4L);
/*      */       }
/*  831 */       JNI.set_int_disordered(checkedPeer, value);
/*  832 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public int getInt() {
/*  837 */       long checkedPeer = getPeer() + 0L;
/*  838 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  842 */         invalidPeer(checkedPeer, 4L);
/*      */       }
/*  844 */       return JNI.get_int_disordered(checkedPeer);
/*      */     }
/*      */ 
/*      */     
/*      */     public int getIntAtOffset(long byteOffset) {
/*  849 */       long checkedPeer = getPeer() + byteOffset;
/*  850 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  854 */         invalidPeer(checkedPeer, 4L);
/*      */       }
/*  856 */       return JNI.get_int_disordered(checkedPeer);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setLong(long value) {
/*  862 */       long checkedPeer = getPeer() + 0L;
/*  863 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  867 */         invalidPeer(checkedPeer, 8L);
/*      */       }
/*  869 */       JNI.set_long_disordered(checkedPeer, value);
/*  870 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Pointer<T> setLongAtOffset(long byteOffset, long value) {
/*  875 */       long checkedPeer = getPeer() + byteOffset;
/*  876 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  880 */         invalidPeer(checkedPeer, 8L);
/*      */       }
/*  882 */       JNI.set_long_disordered(checkedPeer, value);
/*  883 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public long getLong() {
/*  888 */       long checkedPeer = getPeer() + 0L;
/*  889 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  893 */         invalidPeer(checkedPeer, 8L);
/*      */       }
/*  895 */       return JNI.get_long_disordered(checkedPeer);
/*      */     }
/*      */ 
/*      */     
/*      */     public long getLongAtOffset(long byteOffset) {
/*  900 */       long checkedPeer = getPeer() + byteOffset;
/*  901 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  905 */         invalidPeer(checkedPeer, 8L);
/*      */       }
/*  907 */       return JNI.get_long_disordered(checkedPeer);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setShort(short value) {
/*  913 */       long checkedPeer = getPeer() + 0L;
/*  914 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 2L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  918 */         invalidPeer(checkedPeer, 2L);
/*      */       }
/*  920 */       JNI.set_short_disordered(checkedPeer, value);
/*  921 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Pointer<T> setShortAtOffset(long byteOffset, short value) {
/*  926 */       long checkedPeer = getPeer() + byteOffset;
/*  927 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 2L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  931 */         invalidPeer(checkedPeer, 2L);
/*      */       }
/*  933 */       JNI.set_short_disordered(checkedPeer, value);
/*  934 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public short getShort() {
/*  939 */       long checkedPeer = getPeer() + 0L;
/*  940 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 2L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  944 */         invalidPeer(checkedPeer, 2L);
/*      */       }
/*  946 */       return JNI.get_short_disordered(checkedPeer);
/*      */     }
/*      */ 
/*      */     
/*      */     public short getShortAtOffset(long byteOffset) {
/*  951 */       long checkedPeer = getPeer() + byteOffset;
/*  952 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 2L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  956 */         invalidPeer(checkedPeer, 2L);
/*      */       }
/*  958 */       return JNI.get_short_disordered(checkedPeer);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setByte(byte value) {
/*  964 */       long checkedPeer = getPeer() + 0L;
/*  965 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  969 */         invalidPeer(checkedPeer, 1L);
/*      */       }
/*  971 */       JNI.set_byte(checkedPeer, value);
/*  972 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Pointer<T> setByteAtOffset(long byteOffset, byte value) {
/*  977 */       long checkedPeer = getPeer() + byteOffset;
/*  978 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  982 */         invalidPeer(checkedPeer, 1L);
/*      */       }
/*  984 */       JNI.set_byte(checkedPeer, value);
/*  985 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public byte getByte() {
/*  990 */       long checkedPeer = getPeer() + 0L;
/*  991 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/*  995 */         invalidPeer(checkedPeer, 1L);
/*      */       }
/*  997 */       return JNI.get_byte(checkedPeer);
/*      */     }
/*      */ 
/*      */     
/*      */     public byte getByteAtOffset(long byteOffset) {
/* 1002 */       long checkedPeer = getPeer() + byteOffset;
/* 1003 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 1007 */         invalidPeer(checkedPeer, 1L);
/*      */       }
/* 1009 */       return JNI.get_byte(checkedPeer);
/*      */     }
/*      */ 
/*      */     
/*      */     public Pointer<T> setChar(char value) {
/* 1014 */       if (Platform.WCHAR_T_SIZE == 4) {
/* 1015 */         return setInt(value);
/*      */       }
/* 1017 */       long checkedPeer = getPeer() + 0L;
/* 1018 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + Platform.WCHAR_T_SIZE > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 1022 */         invalidPeer(checkedPeer, Platform.WCHAR_T_SIZE);
/*      */       }
/* 1024 */       JNI.set_char_disordered(checkedPeer, value);
/* 1025 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Pointer<T> setCharAtOffset(long byteOffset, char value) {
/* 1030 */       if (Platform.WCHAR_T_SIZE == 4)
/* 1031 */         return setIntAtOffset(byteOffset, value); 
/* 1032 */       long checkedPeer = getPeer() + byteOffset;
/* 1033 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + Platform.WCHAR_T_SIZE > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 1037 */         invalidPeer(checkedPeer, Platform.WCHAR_T_SIZE);
/*      */       }
/* 1039 */       JNI.set_char_disordered(checkedPeer, value);
/* 1040 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public char getChar() {
/* 1045 */       if (Platform.WCHAR_T_SIZE == 4)
/* 1046 */         return (char)getInt(); 
/* 1047 */       long checkedPeer = getPeer() + 0L;
/* 1048 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + Platform.WCHAR_T_SIZE > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 1052 */         invalidPeer(checkedPeer, Platform.WCHAR_T_SIZE);
/*      */       }
/* 1054 */       return JNI.get_char_disordered(checkedPeer);
/*      */     }
/*      */ 
/*      */     
/*      */     public char getCharAtOffset(long byteOffset) {
/* 1059 */       if (Platform.WCHAR_T_SIZE == 4)
/* 1060 */         return (char)getIntAtOffset(byteOffset); 
/* 1061 */       long checkedPeer = getPeer() + byteOffset;
/* 1062 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + Platform.WCHAR_T_SIZE > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 1066 */         invalidPeer(checkedPeer, Platform.WCHAR_T_SIZE);
/*      */       }
/* 1068 */       return JNI.get_char_disordered(checkedPeer);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setFloat(float value) {
/* 1074 */       long checkedPeer = getPeer() + 0L;
/* 1075 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 1079 */         invalidPeer(checkedPeer, 4L);
/*      */       }
/* 1081 */       JNI.set_float_disordered(checkedPeer, value);
/* 1082 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Pointer<T> setFloatAtOffset(long byteOffset, float value) {
/* 1087 */       long checkedPeer = getPeer() + byteOffset;
/* 1088 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 1092 */         invalidPeer(checkedPeer, 4L);
/*      */       }
/* 1094 */       JNI.set_float_disordered(checkedPeer, value);
/* 1095 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public float getFloat() {
/* 1100 */       long checkedPeer = getPeer() + 0L;
/* 1101 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 1105 */         invalidPeer(checkedPeer, 4L);
/*      */       }
/* 1107 */       return JNI.get_float_disordered(checkedPeer);
/*      */     }
/*      */ 
/*      */     
/*      */     public float getFloatAtOffset(long byteOffset) {
/* 1112 */       long checkedPeer = getPeer() + byteOffset;
/* 1113 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 1117 */         invalidPeer(checkedPeer, 4L);
/*      */       }
/* 1119 */       return JNI.get_float_disordered(checkedPeer);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setDouble(double value) {
/* 1125 */       long checkedPeer = getPeer() + 0L;
/* 1126 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 1130 */         invalidPeer(checkedPeer, 8L);
/*      */       }
/* 1132 */       JNI.set_double_disordered(checkedPeer, value);
/* 1133 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Pointer<T> setDoubleAtOffset(long byteOffset, double value) {
/* 1138 */       long checkedPeer = getPeer() + byteOffset;
/* 1139 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 1143 */         invalidPeer(checkedPeer, 8L);
/*      */       }
/* 1145 */       JNI.set_double_disordered(checkedPeer, value);
/* 1146 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public double getDouble() {
/* 1151 */       long checkedPeer = getPeer() + 0L;
/* 1152 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 1156 */         invalidPeer(checkedPeer, 8L);
/*      */       }
/* 1158 */       return JNI.get_double_disordered(checkedPeer);
/*      */     }
/*      */ 
/*      */     
/*      */     public double getDoubleAtOffset(long byteOffset) {
/* 1163 */       long checkedPeer = getPeer() + byteOffset;
/* 1164 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 1168 */         invalidPeer(checkedPeer, 8L);
/*      */       }
/* 1170 */       return JNI.get_double_disordered(checkedPeer);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setBoolean(boolean value) {
/* 1176 */       long checkedPeer = getPeer() + 0L;
/* 1177 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 1181 */         invalidPeer(checkedPeer, 1L);
/*      */       }
/* 1183 */       JNI.set_boolean(checkedPeer, value);
/* 1184 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Pointer<T> setBooleanAtOffset(long byteOffset, boolean value) {
/* 1189 */       long checkedPeer = getPeer() + byteOffset;
/* 1190 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 1194 */         invalidPeer(checkedPeer, 1L);
/*      */       }
/* 1196 */       JNI.set_boolean(checkedPeer, value);
/* 1197 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean getBoolean() {
/* 1202 */       long checkedPeer = getPeer() + 0L;
/* 1203 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 1207 */         invalidPeer(checkedPeer, 1L);
/*      */       }
/* 1209 */       return JNI.get_boolean(checkedPeer);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean getBooleanAtOffset(long byteOffset) {
/* 1214 */       long checkedPeer = getPeer() + byteOffset;
/* 1215 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 1219 */         invalidPeer(checkedPeer, 1L);
/*      */       }
/* 1221 */       return JNI.get_boolean(checkedPeer);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setSizeTsAtOffset(long byteOffset, long[] values, int valuesOffset, int length) {
/* 1228 */       if (values == null)
/* 1229 */         throw new IllegalArgumentException("Null values"); 
/* 1230 */       if (SizeT.SIZE == 8) {
/* 1231 */         setLongsAtOffset(byteOffset, values, valuesOffset, length);
/*      */       } else {
/* 1233 */         int n = length;
/* 1234 */         long checkedPeer = getPeer() + byteOffset;
/* 1235 */         if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (n * 4) > this.validEnd))
/*      */         {
/*      */ 
/*      */           
/* 1239 */           invalidPeer(checkedPeer, (n * 4));
/*      */         }
/*      */         
/* 1242 */         long peer = checkedPeer;
/* 1243 */         int valuesIndex = valuesOffset;
/* 1244 */         for (int i = 0; i < n; i++) {
/* 1245 */           int value = (int)values[valuesIndex];
/* 1246 */           JNI.set_int_disordered(peer, value);
/* 1247 */           peer += 4L;
/* 1248 */           valuesIndex++;
/*      */         } 
/*      */       } 
/* 1251 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setSizeTsAtOffset(long byteOffset, int[] values) {
/* 1258 */       if (SizeT.SIZE == 4) {
/* 1259 */         setIntsAtOffset(byteOffset, values);
/*      */       } else {
/* 1261 */         int n = values.length;
/* 1262 */         long checkedPeer = getPeer() + byteOffset;
/* 1263 */         if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (n * 8) > this.validEnd))
/*      */         {
/*      */ 
/*      */           
/* 1267 */           invalidPeer(checkedPeer, (n * 8));
/*      */         }
/*      */         
/* 1270 */         long peer = checkedPeer;
/* 1271 */         for (int i = 0; i < n; i++) {
/* 1272 */           int value = values[i];
/* 1273 */           JNI.set_long_disordered(peer, value);
/* 1274 */           peer += 8L;
/*      */         } 
/*      */       } 
/* 1277 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setCLongsAtOffset(long byteOffset, long[] values, int valuesOffset, int length) {
/* 1283 */       if (values == null)
/* 1284 */         throw new IllegalArgumentException("Null values"); 
/* 1285 */       if (CLong.SIZE == 8) {
/* 1286 */         setLongsAtOffset(byteOffset, values, valuesOffset, length);
/*      */       } else {
/* 1288 */         int n = length;
/* 1289 */         long checkedPeer = getPeer() + byteOffset;
/* 1290 */         if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (n * 4) > this.validEnd))
/*      */         {
/*      */ 
/*      */           
/* 1294 */           invalidPeer(checkedPeer, (n * 4));
/*      */         }
/*      */         
/* 1297 */         long peer = checkedPeer;
/* 1298 */         int valuesIndex = valuesOffset;
/* 1299 */         for (int i = 0; i < n; i++) {
/* 1300 */           int value = (int)values[valuesIndex];
/* 1301 */           JNI.set_int_disordered(peer, value);
/* 1302 */           peer += 4L;
/* 1303 */           valuesIndex++;
/*      */         } 
/*      */       } 
/* 1306 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer<T> setCLongsAtOffset(long byteOffset, int[] values) {
/* 1313 */       if (CLong.SIZE == 4) {
/* 1314 */         setIntsAtOffset(byteOffset, values);
/*      */       } else {
/* 1316 */         int n = values.length;
/* 1317 */         long checkedPeer = getPeer() + byteOffset;
/* 1318 */         if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (n * 8) > this.validEnd))
/*      */         {
/*      */ 
/*      */           
/* 1322 */           invalidPeer(checkedPeer, (n * 8));
/*      */         }
/*      */         
/* 1325 */         long peer = checkedPeer;
/* 1326 */         for (int i = 0; i < n; i++) {
/* 1327 */           int value = values[i];
/* 1328 */           JNI.set_long_disordered(peer, value);
/* 1329 */           peer += 8L;
/*      */         } 
/*      */       } 
/* 1332 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Type pointerType(Type targetType) {
/* 1341 */     return DefaultParameterizedType.paramType(Pointer.class, new Type[] { targetType });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E extends Enum<E>> Type intEnumType(Class<? extends IntValuedEnum<E>> targetType) {
/* 1348 */     return DefaultParameterizedType.paramType(IntValuedEnum.class, new Type[] { targetType });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void release() {
/* 1359 */     Object sibling = this.sibling;
/* 1360 */     this.sibling = null;
/* 1361 */     if (sibling instanceof Pointer) {
/* 1362 */       ((Pointer)sibling).release();
/*      */     }
/*      */     
/* 1365 */     if (BridJ.debugPointerReleases) {
/* 1366 */       this.releaseTrace = (new RuntimeException()).fillInStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int compareTo(Pointer<?> p) {
/* 1377 */     if (p == null) {
/* 1378 */       return 1;
/*      */     }
/* 1380 */     long p1 = getPeer(), p2 = p.getPeer();
/* 1381 */     return (p1 == p2) ? 0 : ((p1 < p2) ? -1 : 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int compareBytes(Pointer<?> other, long byteCount) {
/* 1389 */     return compareBytesAtOffset(0L, other, 0L, byteCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int compareBytesAtOffset(long byteOffset, Pointer<?> other, long otherByteOffset, long byteCount) {
/* 1398 */     long checkedPeer = getPeer() + byteOffset;
/* 1399 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + byteCount > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 1403 */       invalidPeer(checkedPeer, byteCount);
/*      */     }
/* 1405 */     return JNI.memcmp(checkedPeer, other.getCheckedPeer(otherByteOffset, byteCount), byteCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1413 */     int hc = (new Long(getPeer())).hashCode();
/* 1414 */     return hc;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1419 */     return "Pointer(peer = 0x" + Long.toHexString(getPeer()) + ", targetType = " + Utils.toString(getTargetType()) + ", order = " + order() + ")";
/*      */   }
/*      */   
/*      */   protected final void invalidPeer(long peer, long validityCheckLength) {
/* 1423 */     throw new IndexOutOfBoundsException("Cannot access to memory data of length " + validityCheckLength + " at offset " + (peer - getPeer()) + " : valid memory start is " + this.validStart + ", valid memory size is " + (this.validEnd - this.validStart));
/*      */   }
/*      */   
/*      */   private final long getCheckedPeer(long byteOffset, long validityCheckLength) {
/* 1427 */     long checkedPeer = getPeer() + byteOffset;
/* 1428 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + validityCheckLength > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 1432 */       invalidPeer(checkedPeer, validityCheckLength);
/*      */     }
/* 1434 */     return checkedPeer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> offset(long byteOffset) {
/* 1443 */     return offset(byteOffset, getIO());
/*      */   }
/*      */   
/*      */   <U> Pointer<U> offset(long byteOffset, PointerIO<U> pio) {
/* 1447 */     if (byteOffset == 0L) {
/* 1448 */       return (pio == this.io) ? this : as(pio);
/*      */     }
/* 1450 */     long newPeer = getPeer() + byteOffset;
/*      */     
/* 1452 */     Object newSibling = (getSibling() != null) ? getSibling() : this;
/* 1453 */     if (this.validStart == -1L)
/* 1454 */       return newPointer(pio, newPeer, isOrdered(), -1L, -1L, null, 0L, null, newSibling); 
/* 1455 */     if (newPeer > this.validEnd || newPeer < this.validStart) {
/* 1456 */       throw new IndexOutOfBoundsException("Invalid pointer offset : " + byteOffset + " (validBytes = " + getValidBytes() + ") !");
/*      */     }
/* 1458 */     return newPointer(pio, newPeer, isOrdered(), this.validStart, this.validEnd, null, 0L, null, newSibling);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> validBytes(long byteCount) {
/* 1466 */     long peer = getPeer();
/* 1467 */     long newValidEnd = peer + byteCount;
/* 1468 */     if (this.validStart == peer && this.validEnd == newValidEnd) {
/* 1469 */       return this;
/*      */     }
/* 1471 */     if (this.validEnd != -1L && newValidEnd > this.validEnd) {
/* 1472 */       throw new IndexOutOfBoundsException("Cannot extend validity of pointed memory from " + this.validEnd + " to " + newValidEnd);
/*      */     }
/* 1474 */     Object newSibling = (getSibling() != null) ? getSibling() : this;
/* 1475 */     return newPointer(getIO(), peer, isOrdered(), this.validStart, newValidEnd, this.parent, this.offsetInParent, null, newSibling);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Pointer<T> withoutValidityInformation() {
/* 1485 */     long peer = getPeer();
/* 1486 */     if (this.validStart == -1L) {
/* 1487 */       return this;
/*      */     }
/* 1489 */     Object newSibling = (getSibling() != null) ? getSibling() : this;
/* 1490 */     return newPointer(getIO(), peer, isOrdered(), -1L, -1L, this.parent, this.offsetInParent, null, newSibling);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> clone() {
/* 1498 */     long length = getValidElements();
/* 1499 */     if (length < 0L) {
/* 1500 */       throw new UnsupportedOperationException("Number of bytes unknown, unable to clone memory (use validBytes(long))");
/*      */     }
/* 1502 */     Pointer<T> c = allocateArray(getIO(), length);
/* 1503 */     copyTo(c);
/* 1504 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> validElements(long elementCount) {
/* 1512 */     return validBytes(elementCount * getIO("Cannot define elements validity").getTargetSize());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<Pointer<T>> getReference() {
/* 1534 */     if (this.parent == null) {
/* 1535 */       throw new UnsupportedOperationException("Cannot get reference to this pointer, it wasn't created from Pointer.getPointer(offset) or from a similar method.");
/*      */     }
/* 1537 */     PointerIO<T> io = getIO();
/* 1538 */     return this.parent.offset(this.offsetInParent).as((io == null) ? null : io.getReferenceIO());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final long getPeer() {
/* 1547 */     if (BridJ.debugPointerReleases && 
/* 1548 */       this.releaseTrace != null) {
/* 1549 */       throw new RuntimeException("Pointer was released here:\n\t" + Utils.toString(this.releaseTrace).replaceAll("\n", "\n\t"));
/*      */     }
/*      */     
/* 1552 */     return this.peer_;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <R> Pointer<DynamicFunction<R>> allocateDynamicCallback(DynamicCallback<R> callback, Convention.Style callingConvention, Type returnType, Type... parameterTypes) {
/* 1589 */     if (callback == null)
/* 1590 */       throw new IllegalArgumentException("Java callback handler cannot be null !"); 
/* 1591 */     if (returnType == null)
/* 1592 */       throw new IllegalArgumentException("Callback return type cannot be null !"); 
/* 1593 */     if (parameterTypes == null)
/* 1594 */       throw new IllegalArgumentException("Invalid (null) list of parameter types !"); 
/*      */     try {
/* 1596 */       MethodCallInfo mci = new MethodCallInfo(returnType, parameterTypes, false);
/* 1597 */       Method method = DynamicCallback.class.getMethod("apply", new Class[] { Object[].class });
/* 1598 */       mci.setMethod(method);
/* 1599 */       mci.setJavaSignature("([Ljava/lang/Object;)Ljava/lang/Object;");
/* 1600 */       mci.setCallingConvention(callingConvention);
/* 1601 */       mci.setGenericCallback(true);
/* 1602 */       mci.setJavaCallback(callback);
/*      */ 
/*      */ 
/*      */       
/* 1606 */       return CRuntime.createCToJavaCallback(mci, DynamicCallback.class);
/* 1607 */     } catch (Exception ex) {
/* 1608 */       throw new RuntimeException("Failed to allocate dynamic callback for convention " + callingConvention + ", return type " + Utils.toString(returnType) + " and parameter types " + Arrays.asList(parameterTypes) + " : " + ex, ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <U> Pointer<U> as(PointerIO<U> newIO) {
/* 1617 */     return viewAs(isOrdered(), newIO);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> order(ByteOrder order) {
/* 1624 */     if (order.equals(ByteOrder.nativeOrder()) == isOrdered()) {
/* 1625 */       return this;
/*      */     }
/* 1627 */     return viewAs(!isOrdered(), getIO());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteOrder order() {
/* 1634 */     ByteOrder order = isOrdered() ? ByteOrder.nativeOrder() : ((ByteOrder.nativeOrder() == ByteOrder.BIG_ENDIAN) ? ByteOrder.LITTLE_ENDIAN : ByteOrder.BIG_ENDIAN);
/* 1635 */     return order;
/*      */   }
/*      */   
/*      */   <U> Pointer<U> viewAs(boolean ordered, PointerIO<U> newIO) {
/* 1639 */     if (newIO == this.io && ordered == isOrdered()) {
/* 1640 */       return this;
/*      */     }
/* 1642 */     return newPointer(newIO, getPeer(), ordered, getValidStart(), getValidEnd(), getParent(), getOffsetInParent(), null, (getSibling() != null) ? getSibling() : this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final PointerIO<T> getIO() {
/* 1649 */     return this.io;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final long getOffsetInParent() {
/* 1659 */     return this.offsetInParent;
/*      */   }
/*      */   final Pointer<?> getParent() {
/* 1662 */     return this.parent;
/*      */   }
/*      */   final Object getSibling() {
/* 1665 */     return this.sibling;
/*      */   }
/*      */   
/*      */   final long getValidEnd() {
/* 1669 */     return this.validEnd;
/*      */   }
/*      */   final long getValidStart() {
/* 1672 */     return this.validStart;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <U> Pointer<U> as(Type type) {
/* 1693 */     PointerIO<U> pio = PointerIO.getInstance(type);
/* 1694 */     return as(pio);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <U> Pointer<U> as(Class<U> type) {
/* 1715 */     return as(type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> DynamicFunction<R> asDynamicFunction(Convention.Style callingConvention, Type returnType, Type... parameterTypes) {
/* 1736 */     return CRuntime.getInstance().getDynamicFunctionFactory(null, callingConvention, returnType, parameterTypes).newInstance(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<?> asUntyped() {
/* 1756 */     return as((Class)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getValidBytes() {
/* 1765 */     long ve = getValidEnd();
/* 1766 */     return (ve == -1L) ? -1L : (ve - getPeer());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getValidElements() {
/* 1775 */     long bytes = getValidBytes();
/* 1776 */     long elementSize = getTargetSize();
/* 1777 */     if (bytes < 0L || elementSize <= 0L)
/* 1778 */       return -1L; 
/* 1779 */     return bytes / elementSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ListIterator<T> iterator() {
/* 1788 */     return new ListIterator<T>() {
/* 1789 */         Pointer<T> next = (Pointer.this.getValidElements() != 0L) ? Pointer.this : null;
/*      */         Pointer<T> previous;
/*      */         
/*      */         public T next() {
/* 1793 */           if (this.next == null)
/* 1794 */             throw new NoSuchElementException(); 
/* 1795 */           T value = this.next.get();
/* 1796 */           this.previous = this.next;
/* 1797 */           long valid = this.next.getValidElements();
/* 1798 */           this.next = (valid < 0L || valid > 1L) ? this.next.next(1L) : null;
/* 1799 */           return value;
/*      */         }
/*      */         
/*      */         public void remove() {
/* 1803 */           throw new UnsupportedOperationException();
/*      */         }
/*      */         
/*      */         public boolean hasNext() {
/*      */           long rem;
/* 1808 */           return (this.next != null && ((rem = this.next.getValidBytes()) < 0L || rem > 0L));
/*      */         }
/*      */         
/*      */         public void add(T o) {
/* 1812 */           throw new UnsupportedOperationException();
/*      */         }
/*      */         
/*      */         public boolean hasPrevious() {
/* 1816 */           return (this.previous != null);
/*      */         }
/*      */         
/*      */         public int nextIndex() {
/* 1820 */           throw new UnsupportedOperationException();
/*      */         }
/*      */ 
/*      */         
/*      */         public T previous() {
/* 1825 */           throw new UnsupportedOperationException();
/*      */         }
/*      */         
/*      */         public int previousIndex() {
/* 1829 */           throw new UnsupportedOperationException();
/*      */         }
/*      */         
/*      */         public void set(T o) {
/* 1833 */           if (this.previous == null)
/* 1834 */             throw new NoSuchElementException("You haven't called next() prior to calling ListIterator.set(E)"); 
/* 1835 */           this.previous.set(o);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E extends Enum<E>> Pointer<IntValuedEnum<E>> pointerToEnum(IntValuedEnum<E> instance) {
/*      */     Class<E> enumClass;
/* 1846 */     if (instance instanceof FlagSet) {
/* 1847 */       enumClass = ((FlagSet<E>)instance).getEnumClass();
/* 1848 */     } else if (instance instanceof Enum) {
/* 1849 */       enumClass = (Class)instance.getClass();
/*      */     } else {
/* 1851 */       throw new RuntimeException("Expected a FlagSet or an Enum, got " + instance);
/*      */     } 
/* 1853 */     PointerIO<IntValuedEnum<E>> io = PointerIO.getInstance(DefaultParameterizedType.paramType(IntValuedEnum.class, new Type[] { enumClass }));
/* 1854 */     Pointer<IntValuedEnum<E>> p = allocate(io);
/* 1855 */     p.setInt((int)instance.value());
/* 1856 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <N extends NativeObject> Pointer<N> pointerTo(N instance) {
/* 1864 */     return getPointer(instance);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <N extends NativeObject> Pointer<N> getPointer(N instance) {
/* 1871 */     return getPointer((NativeObject)instance, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <N extends NativeObjectInterface> Pointer<N> getPointer(N instance) {
/* 1877 */     return (Pointer)getPointer((NativeObject)instance);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <R extends NativeObject> Pointer<R> getPointer(NativeObject instance, Type targetType) {
/* 1885 */     return (instance == null) ? null : (Pointer)instance.peer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long getAddress(NativeObject instance, Class targetType) {
/* 1892 */     return getPeer(getPointer(instance, targetType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <O extends NativeObject> O getNativeObjectAtOffset(long byteOffset, Type type) {
/* 1900 */     return BridJ.createNativeObjectFromPointer((byteOffset == 0L) ? this : offset(byteOffset), type);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <O extends NativeObject> Pointer<T> setNativeObject(O value, Type type) {
/* 1906 */     BridJ.copyNativeObjectToAddress(value, type, this);
/* 1907 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <O extends NativeObject> O getNativeObjectAtOffset(long byteOffset, Class<O> type) {
/* 1914 */     return getNativeObjectAtOffset(byteOffset, type);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <O extends NativeObject> O getNativeObject(Class<O> type) {
/* 1920 */     return getNativeObject(type);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <O extends NativeObject> O getNativeObject(Type type) {
/* 1926 */     O o = getNativeObjectAtOffset(0L, type);
/* 1927 */     return o;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAligned() {
/* 1936 */     return isAligned(getIO("Cannot check alignment").getTargetAlignment());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAligned(long alignment) {
/* 1945 */     return isAligned(getPeer(), alignment);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static boolean isAligned(long address, long alignment) {
/* 1953 */     return (computeRemainder(address, alignment) == 0);
/*      */   }
/*      */   
/*      */   protected static int computeRemainder(long address, long alignment) {
/* 1957 */     switch ((int)alignment) {
/*      */       case -1:
/*      */       case 0:
/*      */       case 1:
/* 1961 */         return 0;
/*      */       case 2:
/* 1963 */         return (int)(address & 0x1L);
/*      */       case 4:
/* 1965 */         return (int)(address & 0x3L);
/*      */       case 8:
/* 1967 */         return (int)(address & 0x7L);
/*      */       case 16:
/* 1969 */         return (int)(address & 0xFL);
/*      */       case 32:
/* 1971 */         return (int)(address & 0x1FL);
/*      */       case 64:
/* 1973 */         return (int)(address & 0x3FL);
/*      */     } 
/* 1975 */     if (alignment < 0L)
/* 1976 */       return 0; 
/* 1977 */     return (int)(address % alignment);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T get() {
/* 2010 */     return get(0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T get(Pointer<T> pointer) {
/* 2017 */     return (pointer == null) ? null : pointer.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T get(long index) {
/* 2041 */     return getIO("Cannot get pointed value").get(this, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T set(T value) {
/* 2069 */     return set(0L, value);
/*      */   }
/*      */   
/*      */   private static long getTargetSizeToAllocateArrayOrThrow(PointerIO<?> io) {
/* 2073 */     long targetSize = -1L;
/* 2074 */     if (io == null || (targetSize = io.getTargetSize()) < 0L)
/* 2075 */       throwBecauseUntyped("Cannot allocate array "); 
/* 2076 */     return targetSize;
/*      */   }
/*      */   
/*      */   private static void throwBecauseUntyped(String message) {
/* 2080 */     throw new RuntimeException("Pointer is not typed (call Pointer.as(Type) to create a typed pointer) : " + message);
/*      */   }
/*      */   static void throwUnexpected(Throwable ex) {
/* 2083 */     throw new RuntimeException("Unexpected error", ex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T set(long index, T value) {
/* 2110 */     getIO("Cannot set pointed value").set(this, index, value);
/* 2111 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long getPeer(Pointer<?> pointer) {
/* 2118 */     return (pointer == null) ? 0L : pointer.getPeer();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getTargetSize() {
/* 2126 */     return getIO("Cannot compute target size").getTargetSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> next() {
/* 2135 */     return next(1L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> next(long delta) {
/* 2144 */     return offset(getIO("Cannot get pointers to next or previous targets").getTargetSize() * delta);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void release(Pointer... pointers) {
/* 2151 */     for (Pointer pointer : pointers) {
/* 2152 */       if (pointer != null) {
/* 2153 */         pointer.release();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object obj) {
/* 2162 */     if (obj == null || !(obj instanceof Pointer)) {
/* 2163 */       return false;
/*      */     }
/* 2165 */     Pointer p = (Pointer)obj;
/* 2166 */     return (getPeer() == p.getPeer());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Pointer<?> pointerToAddress(long peer) {
/* 2176 */     return pointerToAddress(peer, (PointerIO)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Pointer<?> pointerToAddress(long peer, long size) {
/* 2187 */     return newPointer(null, peer, true, peer, peer + size, null, 0L, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <P> Pointer<P> pointerToAddress(long peer, Class<P> targetClass, Releaser releaser) {
/* 2198 */     return pointerToAddress(peer, targetClass, releaser);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <P> Pointer<P> pointerToAddress(long peer, Type targetType, Releaser releaser) {
/* 2208 */     PointerIO<P> pio = PointerIO.getInstance(targetType);
/* 2209 */     return newPointer(pio, peer, true, -1L, -1L, null, -1L, releaser, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <P> Pointer<P> pointerToAddress(long peer, PointerIO<P> io) {
/* 2218 */     if (BridJ.cachePointers) {
/* 2219 */       return (Pointer)((PointerLRUCache)localCachedPointers.get()).get(peer, io);
/*      */     }
/* 2221 */     return pointerToAddress_(peer, io);
/*      */   }
/*      */   
/*      */   private static <P> Pointer<P> pointerToAddress_(long peer, PointerIO<P> io) {
/* 2225 */     return newPointer(io, peer, true, -1L, -1L, null, 0L, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 2230 */   private static final ThreadLocal<PointerLRUCache> localCachedPointers = new ThreadLocal<PointerLRUCache>()
/*      */     {
/*      */       protected PointerLRUCache initialValue() {
/* 2233 */         return new PointerLRUCache(8, 1)
/*      */           {
/*      */             protected <P> Pointer<P> pointerToAddress(long peer, PointerIO<P> io) {
/* 2236 */               return Pointer.pointerToAddress_(peer, io);
/*      */             }
/*      */           };
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <P> Pointer<P> pointerToAddress(long peer, PointerIO<P> io, Releaser releaser) {
/* 2250 */     return newPointer(io, peer, true, -1L, -1L, null, 0L, releaser, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Pointer<?> pointerToAddress(long peer, Releaser releaser) {
/* 2261 */     return newPointer(null, peer, true, -1L, -1L, null, 0L, releaser, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<?> pointerToAddress(long peer, long size, Releaser releaser) {
/* 2272 */     return newPointer(null, peer, true, peer, peer + size, null, 0L, releaser, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <P> Pointer<P> pointerToAddress(long peer, long size, PointerIO<P> io, Releaser releaser) {
/* 2284 */     return newPointer(io, peer, true, peer, peer + size, null, 0L, releaser, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <P> Pointer<P> pointerToAddress(long peer, Class<P> targetClass) {
/* 2295 */     return pointerToAddress(peer, targetClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <P> Pointer<P> pointerToAddress(long peer, Type targetType) {
/* 2306 */     return newPointer(PointerIO.getInstance(targetType), peer, true, -1L, -1L, null, -1L, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <U> Pointer<U> pointerToAddress(long peer, long size, PointerIO<U> io) {
/* 2317 */     return newPointer(io, peer, true, peer, peer + size, null, 0L, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <U> Pointer<U> newPointer(PointerIO<U> io, long peer, boolean ordered, long validStart, long validEnd, Pointer<?> parent, long offsetInParent, final Releaser releaser, Object sibling) {
/* 2337 */     peer &= POINTER_MASK;
/* 2338 */     if (peer == 0L) {
/* 2339 */       return null;
/*      */     }
/* 2341 */     if (validEnd != -1L && validEnd <= validStart) {
/* 2342 */       return null;
/*      */     }
/* 2344 */     if (releaser == null) {
/* 2345 */       if (ordered) {
/* 2346 */         return new OrderedPointer<U>(io, peer, validStart, validEnd, parent, offsetInParent, sibling);
/*      */       }
/* 2348 */       return new DisorderedPointer<U>(io, peer, validStart, validEnd, parent, offsetInParent, sibling);
/*      */     } 
/*      */     
/* 2351 */     assert sibling == null;
/* 2352 */     if (ordered)
/* 2353 */       return new OrderedPointer<U>(io, peer, validStart, validEnd, parent, offsetInParent, sibling) {
/* 2354 */           private volatile Pointer.Releaser rel = releaser;
/*      */           
/*      */           public synchronized void release() {
/* 2357 */             if (this.rel != null) {
/* 2358 */               Pointer.Releaser rel = this.rel;
/* 2359 */               this.rel = null;
/* 2360 */               rel.release(this);
/*      */             } 
/*      */             
/* 2363 */             if (BridJ.debugPointerReleases)
/* 2364 */               this.releaseTrace = (new RuntimeException()).fillInStackTrace(); 
/*      */           }
/*      */           protected void finalize() {
/* 2367 */             release();
/*      */           }
/*      */           
/*      */           @Deprecated
/*      */           public synchronized Pointer<U> withReleaser(final Pointer.Releaser beforeDeallocation) {
/* 2372 */             final Pointer.Releaser thisReleaser = this.rel;
/* 2373 */             this.rel = null;
/* 2374 */             return newPointer(getIO(), getPeer(), isOrdered(), getValidStart(), getValidEnd(), null, 0L, (beforeDeallocation == null) ? thisReleaser : new Pointer.Releaser()
/*      */                 {
/*      */                   public void release(Pointer<?> p) {
/* 2377 */                     beforeDeallocation.release(p);
/* 2378 */                     if (thisReleaser != null) {
/* 2379 */                       thisReleaser.release(p);
/*      */                     }
/*      */                   }
/*      */                 },  null);
/*      */           }
/*      */         }; 
/* 2385 */     return new DisorderedPointer<U>(io, peer, validStart, validEnd, parent, offsetInParent, sibling) {
/* 2386 */         private volatile Pointer.Releaser rel = releaser;
/*      */         
/*      */         public synchronized void release() {
/* 2389 */           if (this.rel != null) {
/* 2390 */             Pointer.Releaser rel = this.rel;
/* 2391 */             this.rel = null;
/* 2392 */             rel.release(this);
/*      */           } 
/*      */           
/* 2395 */           if (BridJ.debugPointerReleases)
/* 2396 */             this.releaseTrace = (new RuntimeException()).fillInStackTrace(); 
/*      */         }
/*      */         protected void finalize() {
/* 2399 */           release();
/*      */         }
/*      */         
/*      */         @Deprecated
/*      */         public synchronized Pointer<U> withReleaser(final Pointer.Releaser beforeDeallocation) {
/* 2404 */           final Pointer.Releaser thisReleaser = this.rel;
/* 2405 */           this.rel = null;
/* 2406 */           return newPointer(getIO(), getPeer(), isOrdered(), getValidStart(), getValidEnd(), null, 0L, (beforeDeallocation == null) ? thisReleaser : new Pointer.Releaser()
/*      */               {
/*      */                 public void release(Pointer<?> p) {
/* 2409 */                   beforeDeallocation.release(p);
/* 2410 */                   if (thisReleaser != null) {
/* 2411 */                     thisReleaser.release(p);
/*      */                   }
/*      */                 }
/*      */               },  null);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <P extends TypedPointer> Pointer<P> allocateTypedPointer(Class<P> type) {
/* 2426 */     return allocate(PointerIO.getInstance(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <P extends TypedPointer> Pointer<P> allocateTypedPointers(Class<P> type, long arrayLength) {
/* 2436 */     return allocateArray(PointerIO.getInstance(type), arrayLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <P> Pointer<Pointer<P>> allocatePointer(Class<P> targetType) {
/* 2444 */     return allocatePointer(targetType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <P> Pointer<Pointer<P>> allocatePointer(Type targetType) {
/* 2452 */     return allocate(PointerIO.getPointerInstance(targetType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <P> Pointer<Pointer<Pointer<P>>> allocatePointerPointer(Type targetType) {
/* 2460 */     return allocatePointer(pointerType(targetType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <P> Pointer<Pointer<Pointer<P>>> allocatePointerPointer(Class<P> targetType) {
/* 2467 */     return allocatePointerPointer(targetType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <V> Pointer<Pointer<?>> allocatePointer() {
/* 2479 */     return allocate((PointerIO)PointerIO.getPointerInstance());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<?>> allocatePointers(int arrayLength) {
/* 2489 */     return allocateArray((PointerIO)PointerIO.getPointerInstance(), arrayLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <P> Pointer<Pointer<P>> allocatePointers(Class<P> targetType, int arrayLength) {
/* 2499 */     return allocatePointers(targetType, arrayLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <P> Pointer<Pointer<P>> allocatePointers(Type targetType, int arrayLength) {
/* 2509 */     return allocateArray(PointerIO.getPointerInstance(targetType), arrayLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <V> Pointer<V> allocate(Class<V> elementClass) {
/* 2519 */     return allocate(elementClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <V> Pointer<V> allocate(Type elementClass) {
/* 2528 */     return allocateArray(elementClass, 1L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <V> Pointer<V> allocate(PointerIO<V> io) {
/* 2537 */     return allocateBytes(io, getTargetSizeToAllocateArrayOrThrow(io), (Releaser)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <V> Pointer<V> allocateArray(PointerIO<V> io, long arrayLength) {
/* 2546 */     return allocateBytes(io, getTargetSizeToAllocateArrayOrThrow(io) * arrayLength, (Releaser)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <V> Pointer<V> allocateArray(PointerIO<V> io, long arrayLength, Releaser beforeDeallocation) {
/* 2556 */     return allocateBytes(io, getTargetSizeToAllocateArrayOrThrow(io) * arrayLength, beforeDeallocation);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <V> Pointer<V> allocateBytes(PointerIO<V> io, long byteSize, Releaser beforeDeallocation) {
/* 2566 */     return allocateAlignedBytes(io, byteSize, defaultAlignment, beforeDeallocation);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <V> Pointer<V> allocateAlignedBytes(PointerIO<V> io, long byteSize, int alignment, final Releaser beforeDeallocation) {
/*      */     long address;
/* 2578 */     if (byteSize == 0L)
/* 2579 */       return null; 
/* 2580 */     if (byteSize < 0L) {
/* 2581 */       throw new IllegalArgumentException("Cannot allocate a negative amount of memory !");
/*      */     }
/* 2583 */     long offset = 0L;
/* 2584 */     if (alignment <= 1) {
/* 2585 */       address = JNI.mallocNulled(byteSize);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 2591 */       address = JNI.mallocNulled(byteSize + alignment - 1L);
/* 2592 */       long remainder = address % alignment;
/* 2593 */       if (remainder > 0L) {
/* 2594 */         offset = alignment - remainder;
/*      */       }
/*      */     } 
/*      */     
/* 2598 */     if (address == 0L) {
/* 2599 */       throw new RuntimeException("Failed to allocate " + byteSize);
/*      */     }
/* 2601 */     Pointer<V> ptr = newPointer(io, address, true, address, address + byteSize + offset, null, 0L, (beforeDeallocation == null) ? freeReleaser : new Releaser()
/*      */         {
/*      */           public void release(Pointer<?> p) {
/* 2604 */             beforeDeallocation.release(p);
/* 2605 */             Pointer.freeReleaser.release(p);
/*      */           }
/*      */         },  null);
/*      */     
/* 2609 */     if (offset > 0L) {
/* 2610 */       ptr = ptr.offset(offset);
/*      */     }
/* 2612 */     return ptr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public synchronized Pointer<T> withReleaser(Releaser beforeDeallocation) {
/* 2624 */     return newPointer(getIO(), getPeer(), isOrdered(), getValidStart(), getValidEnd(), null, 0L, beforeDeallocation, null);
/*      */   }
/* 2626 */   static Releaser freeReleaser = new FreeReleaser();
/*      */   
/*      */   static class FreeReleaser implements Releaser {
/*      */     public void release(Pointer<?> p) {
/* 2630 */       assert p.getSibling() == null;
/* 2631 */       assert p.validStart == p.getPeer();
/*      */       
/* 2633 */       if (BridJ.debugPointers) {
/* 2634 */         p.deletionTrace = (new RuntimeException()).fillInStackTrace();
/* 2635 */         BridJ.info("Freeing pointer " + p + " (peer = " + p.getPeer() + ", validStart = " + p.validStart + ", validEnd = " + p.validEnd + ", validBytes = " + p.getValidBytes() + ").\nCreation trace:\n\t" + Utils.toString(p.creationTrace).replaceAll("\n", "\n\t") + "\nDeletion trace:\n\t" + Utils.toString(p.deletionTrace).replaceAll("\n", "\n\t"));
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2643 */       if (!BridJ.debugNeverFree) {
/* 2644 */         JNI.free(p.getPeer());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <V> Pointer<V> allocateArray(Class<V> elementClass, long arrayLength) {
/* 2655 */     return allocateArray(elementClass, arrayLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <V> Pointer<V> allocateArray(Type elementClass, long arrayLength) {
/* 2664 */     if (arrayLength == 0L) {
/* 2665 */       return null;
/*      */     }
/* 2667 */     PointerIO<?> pio = PointerIO.getInstance(elementClass);
/* 2668 */     if (pio == null)
/* 2669 */       throw new UnsupportedOperationException("Cannot allocate memory for type " + ((elementClass instanceof Class) ? ((Class)elementClass).getName() : elementClass.toString())); 
/* 2670 */     return allocateArray((PointerIO)pio, arrayLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <V> Pointer<V> allocateAlignedArray(Class<V> elementClass, long arrayLength, int alignment) {
/* 2682 */     return allocateAlignedArray(elementClass, arrayLength, alignment);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <V> Pointer<V> allocateAlignedArray(Type elementClass, long arrayLength, int alignment) {
/* 2693 */     PointerIO<?> io = PointerIO.getInstance(elementClass);
/* 2694 */     if (io == null)
/* 2695 */       throw new UnsupportedOperationException("Cannot allocate memory for type " + ((elementClass instanceof Class) ? ((Class)elementClass).getName() : elementClass.toString())); 
/* 2696 */     return allocateAlignedBytes((PointerIO)io, getTargetSizeToAllocateArrayOrThrow(io) * arrayLength, alignment, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<?> pointerToBuffer(Buffer buffer) {
/* 2705 */     if (buffer == null) {
/* 2706 */       return null;
/*      */     }
/* 2708 */     if (buffer instanceof IntBuffer)
/* 2709 */       return pointerToInts((IntBuffer)buffer); 
/* 2710 */     if (buffer instanceof LongBuffer)
/* 2711 */       return pointerToLongs((LongBuffer)buffer); 
/* 2712 */     if (buffer instanceof ShortBuffer)
/* 2713 */       return pointerToShorts((ShortBuffer)buffer); 
/* 2714 */     if (buffer instanceof ByteBuffer)
/* 2715 */       return pointerToBytes((ByteBuffer)buffer); 
/* 2716 */     if (buffer instanceof CharBuffer)
/* 2717 */       return pointerToChars((CharBuffer)buffer); 
/* 2718 */     if (buffer instanceof FloatBuffer)
/* 2719 */       return pointerToFloats((FloatBuffer)buffer); 
/* 2720 */     if (buffer instanceof DoubleBuffer)
/* 2721 */       return pointerToDoubles((DoubleBuffer)buffer); 
/* 2722 */     throw new UnsupportedOperationException("Unhandled buffer type : " + buffer.getClass().getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBuffer(Buffer buffer) {
/* 2731 */     if (buffer == null) {
/* 2732 */       throw new IllegalArgumentException("Cannot update a null Buffer !");
/*      */     }
/* 2734 */     if (Utils.isDirect(buffer)) {
/* 2735 */       long address = JNI.getDirectBufferAddress(buffer);
/* 2736 */       if (address != getPeer()) {
/* 2737 */         throw new IllegalArgumentException("Direct buffer does not point to the same location as this Pointer instance, updating it makes no sense !");
/*      */       }
/*      */     } else {
/* 2740 */       if (buffer instanceof IntBuffer) {
/* 2741 */         ((IntBuffer)buffer).duplicate().put(getIntBuffer());
/*      */         return;
/*      */       } 
/* 2744 */       if (buffer instanceof LongBuffer) {
/* 2745 */         ((LongBuffer)buffer).duplicate().put(getLongBuffer());
/*      */         return;
/*      */       } 
/* 2748 */       if (buffer instanceof ShortBuffer) {
/* 2749 */         ((ShortBuffer)buffer).duplicate().put(getShortBuffer());
/*      */         return;
/*      */       } 
/* 2752 */       if (buffer instanceof ByteBuffer) {
/* 2753 */         ((ByteBuffer)buffer).duplicate().put(getByteBuffer());
/*      */         return;
/*      */       } 
/* 2756 */       if (buffer instanceof FloatBuffer) {
/* 2757 */         ((FloatBuffer)buffer).duplicate().put(getFloatBuffer());
/*      */         return;
/*      */       } 
/* 2760 */       if (buffer instanceof DoubleBuffer) {
/* 2761 */         ((DoubleBuffer)buffer).duplicate().put(getDoubleBuffer());
/*      */         return;
/*      */       } 
/* 2764 */       throw new UnsupportedOperationException("Unhandled buffer type : " + buffer.getClass().getName());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Integer> pointerToInt(int value) {
/* 2779 */     Pointer<Integer> mem = allocate(PointerIO.getIntInstance());
/* 2780 */     mem.setInt(value);
/* 2781 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Integer> pointerToInts(int... values) {
/* 2796 */     if (values == null)
/* 2797 */       return null; 
/* 2798 */     Pointer<Integer> mem = allocateArray(PointerIO.getIntInstance(), values.length);
/* 2799 */     mem.setIntsAtOffset(0L, values, 0, values.length);
/* 2800 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Integer>> pointerToInts(int[][] values) {
/* 2812 */     if (values == null)
/* 2813 */       return null; 
/* 2814 */     int dim1 = values.length, dim2 = (values[0]).length;
/* 2815 */     Pointer<Pointer<Integer>> mem = allocateInts(dim1, dim2);
/* 2816 */     for (int i1 = 0; i1 < dim1; i1++)
/* 2817 */       mem.setIntsAtOffset((i1 * dim2 * 4), values[i1], 0, dim2); 
/* 2818 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Pointer<Integer>>> pointerToInts(int[][][] values) {
/* 2830 */     if (values == null)
/* 2831 */       return null; 
/* 2832 */     int dim1 = values.length, dim2 = (values[0]).length, dim3 = (values[0][0]).length;
/* 2833 */     Pointer<Pointer<Pointer<Integer>>> mem = allocateInts(dim1, dim2, dim3);
/* 2834 */     for (int i1 = 0; i1 < dim1; i1++) {
/* 2835 */       int offset1 = i1 * dim2;
/* 2836 */       for (int i2 = 0; i2 < dim2; i2++) {
/* 2837 */         int offset2 = (offset1 + i2) * dim3;
/* 2838 */         mem.setIntsAtOffset((offset2 * 4), values[i1][i2], 0, dim3);
/*      */       } 
/*      */     } 
/* 2841 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Integer> allocateInt() {
/* 2850 */     return allocate(PointerIO.getIntInstance());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Integer> allocateInts(long arrayLength) {
/* 2860 */     return allocateArray(PointerIO.getIntInstance(), arrayLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Integer>> allocateInts(long dim1, long dim2) {
/* 2870 */     return allocateArray(PointerIO.getArrayInstance(PointerIO.getIntInstance(), new long[] { dim1, dim2 }, 0), dim1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Pointer<Integer>>> allocateInts(long dim1, long dim2, long dim3) {
/* 2880 */     long[] dims = { dim1, dim2, dim3 };
/* 2881 */     return allocateArray(PointerIO.getArrayInstance(PointerIO.getArrayInstance(PointerIO.getIntInstance(), dims, 1), dims, 0), dim1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Long> pointerToLong(long value) {
/* 2909 */     Pointer<Long> mem = allocate(PointerIO.getLongInstance());
/* 2910 */     mem.setLong(value);
/* 2911 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Long> pointerToLongs(long... values) {
/* 2926 */     if (values == null)
/* 2927 */       return null; 
/* 2928 */     Pointer<Long> mem = allocateArray(PointerIO.getLongInstance(), values.length);
/* 2929 */     mem.setLongsAtOffset(0L, values, 0, values.length);
/* 2930 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Long>> pointerToLongs(long[][] values) {
/* 2942 */     if (values == null)
/* 2943 */       return null; 
/* 2944 */     int dim1 = values.length, dim2 = (values[0]).length;
/* 2945 */     Pointer<Pointer<Long>> mem = allocateLongs(dim1, dim2);
/* 2946 */     for (int i1 = 0; i1 < dim1; i1++)
/* 2947 */       mem.setLongsAtOffset((i1 * dim2 * 8), values[i1], 0, dim2); 
/* 2948 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Pointer<Long>>> pointerToLongs(long[][][] values) {
/* 2960 */     if (values == null)
/* 2961 */       return null; 
/* 2962 */     int dim1 = values.length, dim2 = (values[0]).length, dim3 = (values[0][0]).length;
/* 2963 */     Pointer<Pointer<Pointer<Long>>> mem = allocateLongs(dim1, dim2, dim3);
/* 2964 */     for (int i1 = 0; i1 < dim1; i1++) {
/* 2965 */       int offset1 = i1 * dim2;
/* 2966 */       for (int i2 = 0; i2 < dim2; i2++) {
/* 2967 */         int offset2 = (offset1 + i2) * dim3;
/* 2968 */         mem.setLongsAtOffset((offset2 * 8), values[i1][i2], 0, dim3);
/*      */       } 
/*      */     } 
/* 2971 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Long> allocateLong() {
/* 2980 */     return allocate(PointerIO.getLongInstance());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Long> allocateLongs(long arrayLength) {
/* 2990 */     return allocateArray(PointerIO.getLongInstance(), arrayLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Long>> allocateLongs(long dim1, long dim2) {
/* 3000 */     return allocateArray(PointerIO.getArrayInstance(PointerIO.getLongInstance(), new long[] { dim1, dim2 }, 0), dim1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Pointer<Long>>> allocateLongs(long dim1, long dim2, long dim3) {
/* 3010 */     long[] dims = { dim1, dim2, dim3 };
/* 3011 */     return allocateArray(PointerIO.getArrayInstance(PointerIO.getArrayInstance(PointerIO.getLongInstance(), dims, 1), dims, 0), dim1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Short> pointerToShort(short value) {
/* 3039 */     Pointer<Short> mem = allocate(PointerIO.getShortInstance());
/* 3040 */     mem.setShort(value);
/* 3041 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Short> pointerToShorts(short... values) {
/* 3056 */     if (values == null)
/* 3057 */       return null; 
/* 3058 */     Pointer<Short> mem = allocateArray(PointerIO.getShortInstance(), values.length);
/* 3059 */     mem.setShortsAtOffset(0L, values, 0, values.length);
/* 3060 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Short>> pointerToShorts(short[][] values) {
/* 3072 */     if (values == null)
/* 3073 */       return null; 
/* 3074 */     int dim1 = values.length, dim2 = (values[0]).length;
/* 3075 */     Pointer<Pointer<Short>> mem = allocateShorts(dim1, dim2);
/* 3076 */     for (int i1 = 0; i1 < dim1; i1++)
/* 3077 */       mem.setShortsAtOffset((i1 * dim2 * 2), values[i1], 0, dim2); 
/* 3078 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Pointer<Short>>> pointerToShorts(short[][][] values) {
/* 3090 */     if (values == null)
/* 3091 */       return null; 
/* 3092 */     int dim1 = values.length, dim2 = (values[0]).length, dim3 = (values[0][0]).length;
/* 3093 */     Pointer<Pointer<Pointer<Short>>> mem = allocateShorts(dim1, dim2, dim3);
/* 3094 */     for (int i1 = 0; i1 < dim1; i1++) {
/* 3095 */       int offset1 = i1 * dim2;
/* 3096 */       for (int i2 = 0; i2 < dim2; i2++) {
/* 3097 */         int offset2 = (offset1 + i2) * dim3;
/* 3098 */         mem.setShortsAtOffset((offset2 * 2), values[i1][i2], 0, dim3);
/*      */       } 
/*      */     } 
/* 3101 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Short> allocateShort() {
/* 3110 */     return allocate(PointerIO.getShortInstance());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Short> allocateShorts(long arrayLength) {
/* 3120 */     return allocateArray(PointerIO.getShortInstance(), arrayLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Short>> allocateShorts(long dim1, long dim2) {
/* 3130 */     return allocateArray(PointerIO.getArrayInstance(PointerIO.getShortInstance(), new long[] { dim1, dim2 }, 0), dim1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Pointer<Short>>> allocateShorts(long dim1, long dim2, long dim3) {
/* 3140 */     long[] dims = { dim1, dim2, dim3 };
/* 3141 */     return allocateArray(PointerIO.getArrayInstance(PointerIO.getArrayInstance(PointerIO.getShortInstance(), dims, 1), dims, 0), dim1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Byte> pointerToByte(byte value) {
/* 3169 */     Pointer<Byte> mem = allocate(PointerIO.getByteInstance());
/* 3170 */     mem.setByte(value);
/* 3171 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Byte> pointerToBytes(byte... values) {
/* 3186 */     if (values == null)
/* 3187 */       return null; 
/* 3188 */     Pointer<Byte> mem = allocateArray(PointerIO.getByteInstance(), values.length);
/* 3189 */     mem.setBytesAtOffset(0L, values, 0, values.length);
/* 3190 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Byte>> pointerToBytes(byte[][] values) {
/* 3202 */     if (values == null)
/* 3203 */       return null; 
/* 3204 */     int dim1 = values.length, dim2 = (values[0]).length;
/* 3205 */     Pointer<Pointer<Byte>> mem = allocateBytes(dim1, dim2);
/* 3206 */     for (int i1 = 0; i1 < dim1; i1++)
/* 3207 */       mem.setBytesAtOffset((i1 * dim2 * 1), values[i1], 0, dim2); 
/* 3208 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Pointer<Byte>>> pointerToBytes(byte[][][] values) {
/* 3220 */     if (values == null)
/* 3221 */       return null; 
/* 3222 */     int dim1 = values.length, dim2 = (values[0]).length, dim3 = (values[0][0]).length;
/* 3223 */     Pointer<Pointer<Pointer<Byte>>> mem = allocateBytes(dim1, dim2, dim3);
/* 3224 */     for (int i1 = 0; i1 < dim1; i1++) {
/* 3225 */       int offset1 = i1 * dim2;
/* 3226 */       for (int i2 = 0; i2 < dim2; i2++) {
/* 3227 */         int offset2 = (offset1 + i2) * dim3;
/* 3228 */         mem.setBytesAtOffset((offset2 * 1), values[i1][i2], 0, dim3);
/*      */       } 
/*      */     } 
/* 3231 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Byte> allocateByte() {
/* 3240 */     return allocate(PointerIO.getByteInstance());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Byte> allocateBytes(long arrayLength) {
/* 3250 */     return allocateArray(PointerIO.getByteInstance(), arrayLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Byte>> allocateBytes(long dim1, long dim2) {
/* 3260 */     return allocateArray(PointerIO.getArrayInstance(PointerIO.getByteInstance(), new long[] { dim1, dim2 }, 0), dim1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Pointer<Byte>>> allocateBytes(long dim1, long dim2, long dim3) {
/* 3270 */     long[] dims = { dim1, dim2, dim3 };
/* 3271 */     return allocateArray(PointerIO.getArrayInstance(PointerIO.getArrayInstance(PointerIO.getByteInstance(), dims, 1), dims, 0), dim1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Character> pointerToChar(char value) {
/* 3299 */     Pointer<Character> mem = allocate(PointerIO.getCharInstance());
/* 3300 */     mem.setChar(value);
/* 3301 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Character> pointerToChars(char... values) {
/* 3316 */     if (values == null)
/* 3317 */       return null; 
/* 3318 */     Pointer<Character> mem = allocateArray(PointerIO.getCharInstance(), values.length);
/* 3319 */     mem.setCharsAtOffset(0L, values, 0, values.length);
/* 3320 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Character>> pointerToChars(char[][] values) {
/* 3332 */     if (values == null)
/* 3333 */       return null; 
/* 3334 */     int dim1 = values.length, dim2 = (values[0]).length;
/* 3335 */     Pointer<Pointer<Character>> mem = allocateChars(dim1, dim2);
/* 3336 */     for (int i1 = 0; i1 < dim1; i1++)
/* 3337 */       mem.setCharsAtOffset((i1 * dim2 * Platform.WCHAR_T_SIZE), values[i1], 0, dim2); 
/* 3338 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Pointer<Character>>> pointerToChars(char[][][] values) {
/* 3350 */     if (values == null)
/* 3351 */       return null; 
/* 3352 */     int dim1 = values.length, dim2 = (values[0]).length, dim3 = (values[0][0]).length;
/* 3353 */     Pointer<Pointer<Pointer<Character>>> mem = allocateChars(dim1, dim2, dim3);
/* 3354 */     for (int i1 = 0; i1 < dim1; i1++) {
/* 3355 */       int offset1 = i1 * dim2;
/* 3356 */       for (int i2 = 0; i2 < dim2; i2++) {
/* 3357 */         int offset2 = (offset1 + i2) * dim3;
/* 3358 */         mem.setCharsAtOffset((offset2 * Platform.WCHAR_T_SIZE), values[i1][i2], 0, dim3);
/*      */       } 
/*      */     } 
/* 3361 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Character> allocateChar() {
/* 3370 */     return allocate(PointerIO.getCharInstance());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Character> allocateChars(long arrayLength) {
/* 3380 */     return allocateArray(PointerIO.getCharInstance(), arrayLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Character>> allocateChars(long dim1, long dim2) {
/* 3390 */     return allocateArray(PointerIO.getArrayInstance(PointerIO.getCharInstance(), new long[] { dim1, dim2 }, 0), dim1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Pointer<Character>>> allocateChars(long dim1, long dim2, long dim3) {
/* 3400 */     long[] dims = { dim1, dim2, dim3 };
/* 3401 */     return allocateArray(PointerIO.getArrayInstance(PointerIO.getArrayInstance(PointerIO.getCharInstance(), dims, 1), dims, 0), dim1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Float> pointerToFloat(float value) {
/* 3429 */     Pointer<Float> mem = allocate(PointerIO.getFloatInstance());
/* 3430 */     mem.setFloat(value);
/* 3431 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Float> pointerToFloats(float... values) {
/* 3446 */     if (values == null)
/* 3447 */       return null; 
/* 3448 */     Pointer<Float> mem = allocateArray(PointerIO.getFloatInstance(), values.length);
/* 3449 */     mem.setFloatsAtOffset(0L, values, 0, values.length);
/* 3450 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Float>> pointerToFloats(float[][] values) {
/* 3462 */     if (values == null)
/* 3463 */       return null; 
/* 3464 */     int dim1 = values.length, dim2 = (values[0]).length;
/* 3465 */     Pointer<Pointer<Float>> mem = allocateFloats(dim1, dim2);
/* 3466 */     for (int i1 = 0; i1 < dim1; i1++)
/* 3467 */       mem.setFloatsAtOffset((i1 * dim2 * 4), values[i1], 0, dim2); 
/* 3468 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Pointer<Float>>> pointerToFloats(float[][][] values) {
/* 3480 */     if (values == null)
/* 3481 */       return null; 
/* 3482 */     int dim1 = values.length, dim2 = (values[0]).length, dim3 = (values[0][0]).length;
/* 3483 */     Pointer<Pointer<Pointer<Float>>> mem = allocateFloats(dim1, dim2, dim3);
/* 3484 */     for (int i1 = 0; i1 < dim1; i1++) {
/* 3485 */       int offset1 = i1 * dim2;
/* 3486 */       for (int i2 = 0; i2 < dim2; i2++) {
/* 3487 */         int offset2 = (offset1 + i2) * dim3;
/* 3488 */         mem.setFloatsAtOffset((offset2 * 4), values[i1][i2], 0, dim3);
/*      */       } 
/*      */     } 
/* 3491 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Float> allocateFloat() {
/* 3500 */     return allocate(PointerIO.getFloatInstance());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Float> allocateFloats(long arrayLength) {
/* 3510 */     return allocateArray(PointerIO.getFloatInstance(), arrayLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Float>> allocateFloats(long dim1, long dim2) {
/* 3520 */     return allocateArray(PointerIO.getArrayInstance(PointerIO.getFloatInstance(), new long[] { dim1, dim2 }, 0), dim1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Pointer<Float>>> allocateFloats(long dim1, long dim2, long dim3) {
/* 3530 */     long[] dims = { dim1, dim2, dim3 };
/* 3531 */     return allocateArray(PointerIO.getArrayInstance(PointerIO.getArrayInstance(PointerIO.getFloatInstance(), dims, 1), dims, 0), dim1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Double> pointerToDouble(double value) {
/* 3559 */     Pointer<Double> mem = allocate(PointerIO.getDoubleInstance());
/* 3560 */     mem.setDouble(value);
/* 3561 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Double> pointerToDoubles(double... values) {
/* 3576 */     if (values == null)
/* 3577 */       return null; 
/* 3578 */     Pointer<Double> mem = allocateArray(PointerIO.getDoubleInstance(), values.length);
/* 3579 */     mem.setDoublesAtOffset(0L, values, 0, values.length);
/* 3580 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Double>> pointerToDoubles(double[][] values) {
/* 3592 */     if (values == null)
/* 3593 */       return null; 
/* 3594 */     int dim1 = values.length, dim2 = (values[0]).length;
/* 3595 */     Pointer<Pointer<Double>> mem = allocateDoubles(dim1, dim2);
/* 3596 */     for (int i1 = 0; i1 < dim1; i1++)
/* 3597 */       mem.setDoublesAtOffset((i1 * dim2 * 8), values[i1], 0, dim2); 
/* 3598 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Pointer<Double>>> pointerToDoubles(double[][][] values) {
/* 3610 */     if (values == null)
/* 3611 */       return null; 
/* 3612 */     int dim1 = values.length, dim2 = (values[0]).length, dim3 = (values[0][0]).length;
/* 3613 */     Pointer<Pointer<Pointer<Double>>> mem = allocateDoubles(dim1, dim2, dim3);
/* 3614 */     for (int i1 = 0; i1 < dim1; i1++) {
/* 3615 */       int offset1 = i1 * dim2;
/* 3616 */       for (int i2 = 0; i2 < dim2; i2++) {
/* 3617 */         int offset2 = (offset1 + i2) * dim3;
/* 3618 */         mem.setDoublesAtOffset((offset2 * 8), values[i1][i2], 0, dim3);
/*      */       } 
/*      */     } 
/* 3621 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Double> allocateDouble() {
/* 3630 */     return allocate(PointerIO.getDoubleInstance());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Double> allocateDoubles(long arrayLength) {
/* 3640 */     return allocateArray(PointerIO.getDoubleInstance(), arrayLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Double>> allocateDoubles(long dim1, long dim2) {
/* 3650 */     return allocateArray(PointerIO.getArrayInstance(PointerIO.getDoubleInstance(), new long[] { dim1, dim2 }, 0), dim1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Pointer<Double>>> allocateDoubles(long dim1, long dim2, long dim3) {
/* 3660 */     long[] dims = { dim1, dim2, dim3 };
/* 3661 */     return allocateArray(PointerIO.getArrayInstance(PointerIO.getArrayInstance(PointerIO.getDoubleInstance(), dims, 1), dims, 0), dim1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Boolean> pointerToBoolean(boolean value) {
/* 3689 */     Pointer<Boolean> mem = allocate(PointerIO.getBooleanInstance());
/* 3690 */     mem.setBoolean(value);
/* 3691 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Boolean> pointerToBooleans(boolean... values) {
/* 3706 */     if (values == null)
/* 3707 */       return null; 
/* 3708 */     Pointer<Boolean> mem = allocateArray(PointerIO.getBooleanInstance(), values.length);
/* 3709 */     mem.setBooleansAtOffset(0L, values, 0, values.length);
/* 3710 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Boolean>> pointerToBooleans(boolean[][] values) {
/* 3722 */     if (values == null)
/* 3723 */       return null; 
/* 3724 */     int dim1 = values.length, dim2 = (values[0]).length;
/* 3725 */     Pointer<Pointer<Boolean>> mem = allocateBooleans(dim1, dim2);
/* 3726 */     for (int i1 = 0; i1 < dim1; i1++)
/* 3727 */       mem.setBooleansAtOffset((i1 * dim2 * 1), values[i1], 0, dim2); 
/* 3728 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Pointer<Boolean>>> pointerToBooleans(boolean[][][] values) {
/* 3740 */     if (values == null)
/* 3741 */       return null; 
/* 3742 */     int dim1 = values.length, dim2 = (values[0]).length, dim3 = (values[0][0]).length;
/* 3743 */     Pointer<Pointer<Pointer<Boolean>>> mem = allocateBooleans(dim1, dim2, dim3);
/* 3744 */     for (int i1 = 0; i1 < dim1; i1++) {
/* 3745 */       int offset1 = i1 * dim2;
/* 3746 */       for (int i2 = 0; i2 < dim2; i2++) {
/* 3747 */         int offset2 = (offset1 + i2) * dim3;
/* 3748 */         mem.setBooleansAtOffset((offset2 * 1), values[i1][i2], 0, dim3);
/*      */       } 
/*      */     } 
/* 3751 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Boolean> allocateBoolean() {
/* 3760 */     return allocate(PointerIO.getBooleanInstance());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Boolean> allocateBooleans(long arrayLength) {
/* 3770 */     return allocateArray(PointerIO.getBooleanInstance(), arrayLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Boolean>> allocateBooleans(long dim1, long dim2) {
/* 3780 */     return allocateArray(PointerIO.getArrayInstance(PointerIO.getBooleanInstance(), new long[] { dim1, dim2 }, 0), dim1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Pointer<Boolean>>> allocateBooleans(long dim1, long dim2, long dim3) {
/* 3790 */     long[] dims = { dim1, dim2, dim3 };
/* 3791 */     return allocateArray(PointerIO.getArrayInstance(PointerIO.getArrayInstance(PointerIO.getBooleanInstance(), dims, 1), dims, 0), dim1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Integer> pointerToInts(IntBuffer buffer) {
/* 3816 */     if (buffer == null) {
/* 3817 */       return null;
/*      */     }
/* 3819 */     if (!buffer.isDirect()) {
/* 3820 */       int[] array = buffer.array();
/* 3821 */       int offset = buffer.arrayOffset();
/* 3822 */       int length = array.length - offset;
/* 3823 */       Pointer<Integer> ptr = allocateInts(length);
/* 3824 */       ptr.setIntsAtOffset(0L, array, offset, length);
/* 3825 */       return ptr;
/*      */     } 
/*      */ 
/*      */     
/* 3829 */     long address = JNI.getDirectBufferAddress(buffer);
/* 3830 */     long size = JNI.getDirectBufferCapacity(buffer);
/*      */ 
/*      */     
/* 3833 */     size *= 4L;
/*      */ 
/*      */     
/* 3836 */     if (address == 0L || size == 0L) {
/* 3837 */       return null;
/*      */     }
/* 3839 */     PointerIO<Integer> io = CommonPointerIOs.intIO;
/* 3840 */     boolean ordered = buffer.order().equals(ByteOrder.nativeOrder());
/* 3841 */     return newPointer(io, address, ordered, address, address + size, null, 0L, null, buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Long> pointerToLongs(LongBuffer buffer) {
/* 3852 */     if (buffer == null) {
/* 3853 */       return null;
/*      */     }
/* 3855 */     if (!buffer.isDirect()) {
/* 3856 */       long[] array = buffer.array();
/* 3857 */       int offset = buffer.arrayOffset();
/* 3858 */       int length = array.length - offset;
/* 3859 */       Pointer<Long> ptr = allocateLongs(length);
/* 3860 */       ptr.setLongsAtOffset(0L, array, offset, length);
/* 3861 */       return ptr;
/*      */     } 
/*      */ 
/*      */     
/* 3865 */     long address = JNI.getDirectBufferAddress(buffer);
/* 3866 */     long size = JNI.getDirectBufferCapacity(buffer);
/*      */ 
/*      */     
/* 3869 */     size *= 8L;
/*      */ 
/*      */     
/* 3872 */     if (address == 0L || size == 0L) {
/* 3873 */       return null;
/*      */     }
/* 3875 */     PointerIO<Long> io = CommonPointerIOs.longIO;
/* 3876 */     boolean ordered = buffer.order().equals(ByteOrder.nativeOrder());
/* 3877 */     return newPointer(io, address, ordered, address, address + size, null, 0L, null, buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Short> pointerToShorts(ShortBuffer buffer) {
/* 3888 */     if (buffer == null) {
/* 3889 */       return null;
/*      */     }
/* 3891 */     if (!buffer.isDirect()) {
/* 3892 */       short[] array = buffer.array();
/* 3893 */       int offset = buffer.arrayOffset();
/* 3894 */       int length = array.length - offset;
/* 3895 */       Pointer<Short> ptr = allocateShorts(length);
/* 3896 */       ptr.setShortsAtOffset(0L, array, offset, length);
/* 3897 */       return ptr;
/*      */     } 
/*      */ 
/*      */     
/* 3901 */     long address = JNI.getDirectBufferAddress(buffer);
/* 3902 */     long size = JNI.getDirectBufferCapacity(buffer);
/*      */ 
/*      */     
/* 3905 */     size *= 2L;
/*      */ 
/*      */     
/* 3908 */     if (address == 0L || size == 0L) {
/* 3909 */       return null;
/*      */     }
/* 3911 */     PointerIO<Short> io = CommonPointerIOs.shortIO;
/* 3912 */     boolean ordered = buffer.order().equals(ByteOrder.nativeOrder());
/* 3913 */     return newPointer(io, address, ordered, address, address + size, null, 0L, null, buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Byte> pointerToBytes(ByteBuffer buffer) {
/* 3924 */     if (buffer == null) {
/* 3925 */       return null;
/*      */     }
/* 3927 */     if (!buffer.isDirect()) {
/* 3928 */       byte[] array = buffer.array();
/* 3929 */       int offset = buffer.arrayOffset();
/* 3930 */       int length = array.length - offset;
/* 3931 */       Pointer<Byte> ptr = allocateBytes(length);
/* 3932 */       ptr.setBytesAtOffset(0L, array, offset, length);
/* 3933 */       return ptr;
/*      */     } 
/*      */ 
/*      */     
/* 3937 */     long address = JNI.getDirectBufferAddress(buffer);
/* 3938 */     long size = JNI.getDirectBufferCapacity(buffer);
/*      */ 
/*      */     
/* 3941 */     size *= 1L;
/*      */ 
/*      */     
/* 3944 */     if (address == 0L || size == 0L) {
/* 3945 */       return null;
/*      */     }
/* 3947 */     PointerIO<Byte> io = CommonPointerIOs.byteIO;
/* 3948 */     boolean ordered = buffer.order().equals(ByteOrder.nativeOrder());
/* 3949 */     return newPointer(io, address, ordered, address, address + size, null, 0L, null, buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Character> pointerToChars(CharBuffer buffer) {
/* 3960 */     if (buffer == null) {
/* 3961 */       return null;
/*      */     }
/* 3963 */     if (!buffer.isDirect()) {
/* 3964 */       char[] array = buffer.array();
/* 3965 */       int offset = buffer.arrayOffset();
/* 3966 */       int length = array.length - offset;
/* 3967 */       Pointer<Character> ptr = allocateChars(length);
/* 3968 */       ptr.setCharsAtOffset(0L, array, offset, length);
/* 3969 */       return ptr;
/*      */     } 
/*      */ 
/*      */     
/* 3973 */     long address = JNI.getDirectBufferAddress(buffer);
/* 3974 */     long size = JNI.getDirectBufferCapacity(buffer);
/*      */ 
/*      */     
/* 3977 */     size *= Platform.WCHAR_T_SIZE;
/*      */ 
/*      */     
/* 3980 */     if (address == 0L || size == 0L) {
/* 3981 */       return null;
/*      */     }
/* 3983 */     PointerIO<Character> io = CommonPointerIOs.charIO;
/* 3984 */     boolean ordered = buffer.order().equals(ByteOrder.nativeOrder());
/* 3985 */     return newPointer(io, address, ordered, address, address + size, null, 0L, null, buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Float> pointerToFloats(FloatBuffer buffer) {
/* 3996 */     if (buffer == null) {
/* 3997 */       return null;
/*      */     }
/* 3999 */     if (!buffer.isDirect()) {
/* 4000 */       float[] array = buffer.array();
/* 4001 */       int offset = buffer.arrayOffset();
/* 4002 */       int length = array.length - offset;
/* 4003 */       Pointer<Float> ptr = allocateFloats(length);
/* 4004 */       ptr.setFloatsAtOffset(0L, array, offset, length);
/* 4005 */       return ptr;
/*      */     } 
/*      */ 
/*      */     
/* 4009 */     long address = JNI.getDirectBufferAddress(buffer);
/* 4010 */     long size = JNI.getDirectBufferCapacity(buffer);
/*      */ 
/*      */     
/* 4013 */     size *= 4L;
/*      */ 
/*      */     
/* 4016 */     if (address == 0L || size == 0L) {
/* 4017 */       return null;
/*      */     }
/* 4019 */     PointerIO<Float> io = CommonPointerIOs.floatIO;
/* 4020 */     boolean ordered = buffer.order().equals(ByteOrder.nativeOrder());
/* 4021 */     return newPointer(io, address, ordered, address, address + size, null, 0L, null, buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Double> pointerToDoubles(DoubleBuffer buffer) {
/* 4032 */     if (buffer == null) {
/* 4033 */       return null;
/*      */     }
/* 4035 */     if (!buffer.isDirect()) {
/* 4036 */       double[] array = buffer.array();
/* 4037 */       int offset = buffer.arrayOffset();
/* 4038 */       int length = array.length - offset;
/* 4039 */       Pointer<Double> ptr = allocateDoubles(length);
/* 4040 */       ptr.setDoublesAtOffset(0L, array, offset, length);
/* 4041 */       return ptr;
/*      */     } 
/*      */ 
/*      */     
/* 4045 */     long address = JNI.getDirectBufferAddress(buffer);
/* 4046 */     long size = JNI.getDirectBufferCapacity(buffer);
/*      */ 
/*      */     
/* 4049 */     size *= 8L;
/*      */ 
/*      */     
/* 4052 */     if (address == 0L || size == 0L) {
/* 4053 */       return null;
/*      */     }
/* 4055 */     PointerIO<Double> io = CommonPointerIOs.doubleIO;
/* 4056 */     boolean ordered = buffer.order().equals(ByteOrder.nativeOrder());
/* 4057 */     return newPointer(io, address, ordered, address, address + size, null, 0L, null, buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Type getTargetType() {
/* 4065 */     PointerIO<T> io = getIO();
/* 4066 */     return (io == null) ? null : io.getTargetType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Pointer<?> getPointer() {
/* 4075 */     return getPointerAtOffset(0L, (PointerIO)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<?> getPointerAtOffset(long byteOffset) {
/* 4082 */     return getPointerAtOffset(byteOffset, (PointerIO)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<?> getPointerAtIndex(long valueIndex) {
/* 4091 */     return getPointerAtOffset(valueIndex * SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <U> Pointer<U> getPointer(Class<U> c) {
/* 4099 */     return getPointerAtOffset(0L, PointerIO.getInstance(c));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <U> Pointer<U> getPointer(PointerIO<U> pio) {
/* 4107 */     return getPointerAtOffset(0L, pio);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <U> Pointer<U> getPointerAtOffset(long byteOffset, Class<U> c) {
/* 4115 */     return getPointerAtOffset(byteOffset, c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <U> Pointer<U> getPointerAtOffset(long byteOffset, Type t) {
/* 4123 */     return getPointerAtOffset(byteOffset, (t == null) ? null : PointerIO.<U>getInstance(t));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <U> Pointer<U> getPointerAtOffset(long byteOffset, PointerIO<U> pio) {
/* 4131 */     long value = getSizeTAtOffset(byteOffset);
/* 4132 */     if (value == 0L)
/* 4133 */       return null; 
/* 4134 */     return newPointer(pio, value, isOrdered(), -1L, -1L, this, byteOffset, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setPointer(Pointer<?> value) {
/* 4141 */     return setPointerAtOffset(0L, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setPointerAtOffset(long byteOffset, Pointer<?> value) {
/* 4148 */     setSizeTAtOffset(byteOffset, (value == null) ? 0L : value.getPeer());
/* 4149 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setPointerAtIndex(long valueIndex, Pointer<?> value) {
/* 4159 */     setPointerAtOffset(valueIndex * SIZE, value);
/* 4160 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<?>[] getPointersAtOffset(long byteOffset, int arrayLength) {
/* 4168 */     return getPointersAtOffset(byteOffset, arrayLength, (PointerIO)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Pointer<?>[] getPointers() {
/* 4176 */     long rem = getValidElements("Cannot create array if remaining length is not known. Please use getPointers(int length) instead.");
/* 4177 */     return getPointersAtOffset(0L, (int)rem);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Pointer<?>[] getPointers(int arrayLength) {
/* 4185 */     return getPointersAtOffset(0L, arrayLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <U> Pointer<U>[] getPointersAtOffset(long byteOffset, int arrayLength, Type t) {
/* 4192 */     return getPointersAtOffset(byteOffset, arrayLength, (t == null) ? null : PointerIO.getInstance(t));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <U> Pointer<U>[] getPointersAtOffset(long byteOffset, int arrayLength, Class<U> t) {
/* 4199 */     return getPointersAtOffset(byteOffset, arrayLength, t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <U> Pointer<U>[] getPointersAtOffset(long byteOffset, int arrayLength, PointerIO<?> pio) {
/* 4207 */     Pointer[] arrayOfPointer = new Pointer[arrayLength];
/* 4208 */     int s = Platform.POINTER_SIZE;
/* 4209 */     for (int i = 0; i < arrayLength; i++)
/* 4210 */       arrayOfPointer[i] = getPointerAtOffset(byteOffset + (i * s), pio); 
/* 4211 */     return (Pointer<U>[])arrayOfPointer;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setPointersAtOffset(long byteOffset, Pointer<?>[] values) {
/* 4217 */     return setPointersAtOffset(byteOffset, values, 0, values.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setPointersAtOffset(long byteOffset, Pointer<?>[] values, int valuesOffset, int length) {
/* 4224 */     if (values == null)
/* 4225 */       throw new IllegalArgumentException("Null values"); 
/* 4226 */     int n = length, s = Platform.POINTER_SIZE;
/* 4227 */     for (int i = 0; i < n; i++)
/* 4228 */       setPointerAtOffset(byteOffset + (i * s), values[valuesOffset + i]); 
/* 4229 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setPointers(Pointer<?>[] values) {
/* 4236 */     return setPointersAtOffset(0L, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getArrayAtOffset(long byteOffset, int length) {
/* 4245 */     return getIO("Cannot create sublist").getArray(this, byteOffset, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getArray(int length) {
/* 4254 */     return getArrayAtOffset(0L, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getArray() {
/* 4263 */     return getArray((int)getValidElements());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <B extends Buffer> B getBufferAtOffset(long byteOffset, int length) {
/* 4272 */     return getIO("Cannot create Buffer").getBuffer(this, byteOffset, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <B extends Buffer> B getBuffer(int length) {
/* 4281 */     return getBufferAtOffset(0L, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <B extends Buffer> B getBuffer() {
/* 4290 */     return getBuffer((int)getValidElements());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setArrayAtOffset(long byteOffset, Object array) {
/* 4298 */     getIO("Cannot create sublist").setArray(this, byteOffset, array);
/* 4299 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Pointer<T> pointerToArray(Object array) {
/* 4311 */     if (array == null) {
/* 4312 */       return null;
/*      */     }
/* 4314 */     PointerIO<T> io = PointerIO.getArrayIO(array);
/* 4315 */     if (io == null) {
/* 4316 */       throwBecauseUntyped("Cannot create pointer to array");
/*      */     }
/* 4318 */     Pointer<T> ptr = allocateArray(io, Array.getLength(array));
/* 4319 */     io.setArray(ptr, 0L, array);
/* 4320 */     return ptr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setArray(Object array) {
/* 4328 */     return setArrayAtOffset(0L, array);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<SizeT> pointerToSizeT(long value) {
/* 4341 */     Pointer<SizeT> p = allocate(PointerIO.getSizeTInstance());
/* 4342 */     p.setSizeT(value);
/* 4343 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<SizeT> pointerToSizeT(SizeT value) {
/* 4353 */     Pointer<SizeT> p = allocate(PointerIO.getSizeTInstance());
/* 4354 */     p.setSizeT(value);
/* 4355 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<SizeT> pointerToSizeTs(long... values) {
/* 4369 */     if (values == null)
/* 4370 */       return null; 
/* 4371 */     return allocateArray(PointerIO.getSizeTInstance(), values.length).setSizeTsAtOffset(0L, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<SizeT> pointerToSizeTs(SizeT... values) {
/* 4385 */     if (values == null)
/* 4386 */       return null; 
/* 4387 */     return allocateArray(PointerIO.getSizeTInstance(), values.length).setSizeTsAtOffset(0L, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<SizeT> pointerToSizeTs(int[] values) {
/* 4402 */     if (values == null)
/* 4403 */       return null; 
/* 4404 */     return allocateArray(PointerIO.getSizeTInstance(), values.length).setSizeTsAtOffset(0L, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<SizeT> allocateSizeTs(long arrayLength) {
/* 4415 */     return allocateArray(PointerIO.getSizeTInstance(), arrayLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<SizeT> allocateSizeT() {
/* 4423 */     return allocate(PointerIO.getSizeTInstance());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getSizeT() {
/* 4430 */     return (SizeT.SIZE == 8) ? getLong() : getInt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getSizeTAtOffset(long byteOffset) {
/* 4439 */     return (SizeT.SIZE == 8) ? getLongAtOffset(byteOffset) : getIntAtOffset(byteOffset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getSizeTAtIndex(long valueIndex) {
/* 4449 */     return getSizeTAtOffset(valueIndex * SizeT.SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long[] getSizeTs() {
/* 4455 */     long rem = getValidElements("Cannot create array if remaining length is not known. Please use getSizeTs(int length) instead.");
/* 4456 */     if (SizeT.SIZE == 8)
/* 4457 */       return getLongs((int)rem); 
/* 4458 */     return getSizeTs((int)rem);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long[] getSizeTs(int arrayLength) {
/* 4464 */     if (SizeT.SIZE == 8)
/* 4465 */       return getLongs(arrayLength); 
/* 4466 */     return getSizeTsAtOffset(0L, arrayLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long[] getSizeTsAtOffset(long byteOffset, int arrayLength) {
/* 4473 */     if (SizeT.SIZE == 8) {
/* 4474 */       return getLongsAtOffset(byteOffset, arrayLength);
/*      */     }
/* 4476 */     int[] values = getIntsAtOffset(byteOffset, arrayLength);
/* 4477 */     long[] ret = new long[arrayLength];
/* 4478 */     for (int i = 0; i < arrayLength; i++) {
/* 4479 */       ret[i] = values[i];
/*      */     }
/*      */     
/* 4482 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setSizeT(long value) {
/* 4489 */     if (SizeT.SIZE == 8) {
/* 4490 */       setLong(value);
/*      */     } else {
/* 4492 */       setInt(SizeT.safeIntCast(value));
/*      */     } 
/* 4494 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setSizeT(SizeT value) {
/* 4500 */     return setSizeT(value.longValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setSizeTAtOffset(long byteOffset, long value) {
/* 4507 */     if (SizeT.SIZE == 8) {
/* 4508 */       setLongAtOffset(byteOffset, value);
/*      */     } else {
/* 4510 */       setIntAtOffset(byteOffset, SizeT.safeIntCast(value));
/*      */     } 
/* 4512 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setSizeTAtIndex(long valueIndex, long value) {
/* 4521 */     return setSizeTAtOffset(valueIndex * SizeT.SIZE, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setSizeTAtOffset(long byteOffset, SizeT value) {
/* 4529 */     return setSizeTAtOffset(byteOffset, value.longValue());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setSizeTs(long[] values) {
/* 4535 */     if (SizeT.SIZE == 8)
/* 4536 */       return setLongs(values); 
/* 4537 */     return setSizeTsAtOffset(0L, values);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setSizeTs(int[] values) {
/* 4543 */     if (SizeT.SIZE == 4)
/* 4544 */       return setInts(values); 
/* 4545 */     return setSizeTsAtOffset(0L, values);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setSizeTs(SizeT[] values) {
/* 4551 */     return setSizeTsAtOffset(0L, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setSizeTsAtOffset(long byteOffset, long[] values) {
/* 4558 */     return setSizeTsAtOffset(byteOffset, values, 0, values.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setSizeTsAtOffset(long byteOffset, SizeT... values) {
/* 4570 */     if (values == null)
/* 4571 */       throw new IllegalArgumentException("Null values"); 
/* 4572 */     int n = values.length, s = SizeT.SIZE;
/* 4573 */     for (int i = 0; i < n; i++)
/* 4574 */       setSizeTAtOffset(byteOffset + (i * s), values[i].longValue()); 
/* 4575 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<CLong> pointerToCLong(long value) {
/* 4593 */     Pointer<CLong> p = allocate(PointerIO.getCLongInstance());
/* 4594 */     p.setCLong(value);
/* 4595 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<CLong> pointerToCLong(CLong value) {
/* 4605 */     Pointer<CLong> p = allocate(PointerIO.getCLongInstance());
/* 4606 */     p.setCLong(value);
/* 4607 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<CLong> pointerToCLongs(long... values) {
/* 4621 */     if (values == null)
/* 4622 */       return null; 
/* 4623 */     return allocateArray(PointerIO.getCLongInstance(), values.length).setCLongsAtOffset(0L, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<CLong> pointerToCLongs(CLong... values) {
/* 4637 */     if (values == null)
/* 4638 */       return null; 
/* 4639 */     return allocateArray(PointerIO.getCLongInstance(), values.length).setCLongsAtOffset(0L, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<CLong> pointerToCLongs(int[] values) {
/* 4654 */     if (values == null)
/* 4655 */       return null; 
/* 4656 */     return allocateArray(PointerIO.getCLongInstance(), values.length).setCLongsAtOffset(0L, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<CLong> allocateCLongs(long arrayLength) {
/* 4667 */     return allocateArray(PointerIO.getCLongInstance(), arrayLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<CLong> allocateCLong() {
/* 4675 */     return allocate(PointerIO.getCLongInstance());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getCLong() {
/* 4682 */     return (CLong.SIZE == 8) ? getLong() : getInt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getCLongAtOffset(long byteOffset) {
/* 4691 */     return (CLong.SIZE == 8) ? getLongAtOffset(byteOffset) : getIntAtOffset(byteOffset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getCLongAtIndex(long valueIndex) {
/* 4701 */     return getCLongAtOffset(valueIndex * CLong.SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long[] getCLongs() {
/* 4707 */     long rem = getValidElements("Cannot create array if remaining length is not known. Please use getCLongs(int length) instead.");
/* 4708 */     if (CLong.SIZE == 8)
/* 4709 */       return getLongs((int)rem); 
/* 4710 */     return getCLongs((int)rem);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long[] getCLongs(int arrayLength) {
/* 4716 */     if (CLong.SIZE == 8)
/* 4717 */       return getLongs(arrayLength); 
/* 4718 */     return getCLongsAtOffset(0L, arrayLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long[] getCLongsAtOffset(long byteOffset, int arrayLength) {
/* 4725 */     if (CLong.SIZE == 8) {
/* 4726 */       return getLongsAtOffset(byteOffset, arrayLength);
/*      */     }
/* 4728 */     int[] values = getIntsAtOffset(byteOffset, arrayLength);
/* 4729 */     long[] ret = new long[arrayLength];
/* 4730 */     for (int i = 0; i < arrayLength; i++) {
/* 4731 */       ret[i] = values[i];
/*      */     }
/*      */     
/* 4734 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setCLong(long value) {
/* 4741 */     if (CLong.SIZE == 8) {
/* 4742 */       setLong(value);
/*      */     } else {
/* 4744 */       setInt(SizeT.safeIntCast(value));
/*      */     } 
/* 4746 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setCLong(CLong value) {
/* 4752 */     return setCLong(value.longValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setCLongAtOffset(long byteOffset, long value) {
/* 4759 */     if (CLong.SIZE == 8) {
/* 4760 */       setLongAtOffset(byteOffset, value);
/*      */     } else {
/* 4762 */       setIntAtOffset(byteOffset, SizeT.safeIntCast(value));
/*      */     } 
/* 4764 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setCLongAtIndex(long valueIndex, long value) {
/* 4773 */     return setCLongAtOffset(valueIndex * CLong.SIZE, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setCLongAtOffset(long byteOffset, CLong value) {
/* 4781 */     return setCLongAtOffset(byteOffset, value.longValue());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setCLongs(long[] values) {
/* 4787 */     if (CLong.SIZE == 8)
/* 4788 */       return setLongs(values); 
/* 4789 */     return setCLongsAtOffset(0L, values);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setCLongs(int[] values) {
/* 4795 */     if (CLong.SIZE == 4)
/* 4796 */       return setInts(values); 
/* 4797 */     return setCLongsAtOffset(0L, values);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setCLongs(CLong[] values) {
/* 4803 */     return setCLongsAtOffset(0L, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setCLongsAtOffset(long byteOffset, long[] values) {
/* 4810 */     return setCLongsAtOffset(byteOffset, values, 0, values.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setCLongsAtOffset(long byteOffset, CLong... values) {
/* 4822 */     if (values == null)
/* 4823 */       throw new IllegalArgumentException("Null values"); 
/* 4824 */     int n = values.length, s = CLong.SIZE;
/* 4825 */     for (int i = 0; i < n; i++)
/* 4826 */       setCLongAtOffset(byteOffset + (i * s), values[i].longValue()); 
/* 4827 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setSignedIntegralAtOffset(long byteOffset, long value, long sizeOfIntegral) {
/* 4837 */     switch ((int)sizeOfIntegral) {
/*      */       case 1:
/* 4839 */         if (value > 127L || value < -128L)
/* 4840 */           throw new RuntimeException("Value out of byte bounds : " + value); 
/* 4841 */         setByteAtOffset(byteOffset, (byte)(int)value);
/*      */         return;
/*      */       case 2:
/* 4844 */         if (value > 32767L || value < -32768L)
/* 4845 */           throw new RuntimeException("Value out of short bounds : " + value); 
/* 4846 */         setShortAtOffset(byteOffset, (short)(int)value);
/*      */         return;
/*      */       case 4:
/* 4849 */         if (value > 2147483647L || value < -2147483648L)
/* 4850 */           throw new RuntimeException("Value out of int bounds : " + value); 
/* 4851 */         setIntAtOffset(byteOffset, (int)value);
/*      */         return;
/*      */       case 8:
/* 4854 */         setLongAtOffset(byteOffset, value);
/*      */         return;
/*      */     } 
/* 4857 */     throw new IllegalArgumentException("Cannot write integral type of size " + sizeOfIntegral + " (value = " + value + ")");
/*      */   }
/*      */   
/*      */   long getSignedIntegralAtOffset(long byteOffset, long sizeOfIntegral) {
/* 4861 */     switch ((int)sizeOfIntegral) {
/*      */       case 1:
/* 4863 */         return getByteAtOffset(byteOffset);
/*      */       case 2:
/* 4865 */         return getShortAtOffset(byteOffset);
/*      */       case 4:
/* 4867 */         return getIntAtOffset(byteOffset);
/*      */       case 8:
/* 4869 */         return getLongAtOffset(byteOffset);
/*      */     } 
/* 4871 */     throw new IllegalArgumentException("Cannot read integral type of size " + sizeOfIntegral);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Pointer<Pointer<T>> pointerToPointer(Pointer<T> value) {
/* 4883 */     Pointer<Pointer<T>> p = allocate((PointerIO)PointerIO.getPointerInstance());
/* 4884 */     p.setPointerAtOffset(0L, value);
/* 4885 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Pointer<Pointer<T>> pointerToPointers(Pointer<T>... values) {
/* 4900 */     if (values == null)
/* 4901 */       return null; 
/* 4902 */     int n = values.length, s = SIZE;
/* 4903 */     PointerIO<Pointer> pio = PointerIO.getPointerInstance();
/* 4904 */     Pointer<Pointer<T>> p = allocateArray((PointerIO)pio, n);
/* 4905 */     for (int i = 0; i < n; i++) {
/* 4906 */       p.setPointerAtOffset((i * s), values[i]);
/*      */     }
/* 4908 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setValuesAtOffset(long byteOffset, Buffer values) {
/* 4915 */     if (values instanceof IntBuffer) {
/* 4916 */       setIntsAtOffset(byteOffset, (IntBuffer)values);
/* 4917 */       return this;
/*      */     } 
/* 4919 */     if (values instanceof LongBuffer) {
/* 4920 */       setLongsAtOffset(byteOffset, (LongBuffer)values);
/* 4921 */       return this;
/*      */     } 
/* 4923 */     if (values instanceof ShortBuffer) {
/* 4924 */       setShortsAtOffset(byteOffset, (ShortBuffer)values);
/* 4925 */       return this;
/*      */     } 
/* 4927 */     if (values instanceof ByteBuffer) {
/* 4928 */       setBytesAtOffset(byteOffset, (ByteBuffer)values);
/* 4929 */       return this;
/*      */     } 
/* 4931 */     if (values instanceof CharBuffer) {
/* 4932 */       setCharsAtOffset(byteOffset, (CharBuffer)values);
/* 4933 */       return this;
/*      */     } 
/* 4935 */     if (values instanceof FloatBuffer) {
/* 4936 */       setFloatsAtOffset(byteOffset, (FloatBuffer)values);
/* 4937 */       return this;
/*      */     } 
/* 4939 */     if (values instanceof DoubleBuffer) {
/* 4940 */       setDoublesAtOffset(byteOffset, (DoubleBuffer)values);
/* 4941 */       return this;
/*      */     } 
/* 4943 */     throw new UnsupportedOperationException("Unhandled buffer type : " + values.getClass().getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setValuesAtOffset(long byteOffset, Buffer values, int valuesOffset, int length) {
/* 4950 */     if (values instanceof IntBuffer) {
/* 4951 */       setIntsAtOffset(byteOffset, (IntBuffer)values, valuesOffset, length);
/* 4952 */       return this;
/*      */     } 
/* 4954 */     if (values instanceof LongBuffer) {
/* 4955 */       setLongsAtOffset(byteOffset, (LongBuffer)values, valuesOffset, length);
/* 4956 */       return this;
/*      */     } 
/* 4958 */     if (values instanceof ShortBuffer) {
/* 4959 */       setShortsAtOffset(byteOffset, (ShortBuffer)values, valuesOffset, length);
/* 4960 */       return this;
/*      */     } 
/* 4962 */     if (values instanceof ByteBuffer) {
/* 4963 */       setBytesAtOffset(byteOffset, (ByteBuffer)values, valuesOffset, length);
/* 4964 */       return this;
/*      */     } 
/* 4966 */     if (values instanceof CharBuffer) {
/* 4967 */       setCharsAtOffset(byteOffset, (CharBuffer)values, valuesOffset, length);
/* 4968 */       return this;
/*      */     } 
/* 4970 */     if (values instanceof FloatBuffer) {
/* 4971 */       setFloatsAtOffset(byteOffset, (FloatBuffer)values, valuesOffset, length);
/* 4972 */       return this;
/*      */     } 
/* 4974 */     if (values instanceof DoubleBuffer) {
/* 4975 */       setDoublesAtOffset(byteOffset, (DoubleBuffer)values, valuesOffset, length);
/* 4976 */       return this;
/*      */     } 
/* 4978 */     throw new UnsupportedOperationException("Unhandled buffer type : " + values.getClass().getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setValues(Buffer values) {
/* 4985 */     if (values instanceof IntBuffer) {
/* 4986 */       setInts((IntBuffer)values);
/* 4987 */       return this;
/*      */     } 
/* 4989 */     if (values instanceof LongBuffer) {
/* 4990 */       setLongs((LongBuffer)values);
/* 4991 */       return this;
/*      */     } 
/* 4993 */     if (values instanceof ShortBuffer) {
/* 4994 */       setShorts((ShortBuffer)values);
/* 4995 */       return this;
/*      */     } 
/* 4997 */     if (values instanceof ByteBuffer) {
/* 4998 */       setBytes((ByteBuffer)values);
/* 4999 */       return this;
/*      */     } 
/* 5001 */     if (values instanceof CharBuffer) {
/* 5002 */       setChars((CharBuffer)values);
/* 5003 */       return this;
/*      */     } 
/* 5005 */     if (values instanceof FloatBuffer) {
/* 5006 */       setFloats((FloatBuffer)values);
/* 5007 */       return this;
/*      */     } 
/* 5009 */     if (values instanceof DoubleBuffer) {
/* 5010 */       setDoubles((DoubleBuffer)values);
/* 5011 */       return this;
/*      */     } 
/* 5013 */     throw new UnsupportedOperationException("Unhandled buffer type : " + values.getClass().getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Pointer<T> copyBytesAtOffsetTo(long byteOffset, Pointer<?> destination, long byteOffsetInDestination, long byteCount) {
/* 5022 */     long checkedPeer = getPeer() + byteOffset;
/* 5023 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + byteCount > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 5027 */       invalidPeer(checkedPeer, byteCount);
/*      */     }
/* 5029 */     JNI.memcpy(destination.getCheckedPeer(byteOffsetInDestination, byteCount), checkedPeer, byteCount);
/* 5030 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Pointer<T> copyBytesTo(Pointer<?> destination, long byteCount) {
/* 5040 */     return copyBytesAtOffsetTo(0L, destination, 0L, byteCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Pointer<T> moveBytesAtOffsetTo(long byteOffset, Pointer<?> destination, long byteOffsetInDestination, long byteCount) {
/* 5049 */     long checkedPeer = getPeer() + byteOffset;
/* 5050 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + byteCount > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 5054 */       invalidPeer(checkedPeer, byteCount);
/*      */     }
/* 5056 */     JNI.memmove(destination.getCheckedPeer(byteOffsetInDestination, byteCount), checkedPeer, byteCount);
/* 5057 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> moveBytesTo(Pointer<?> destination, long byteCount) {
/* 5065 */     return moveBytesAtOffsetTo(0L, destination, 0L, byteCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> moveBytesTo(Pointer<?> destination) {
/* 5073 */     return moveBytesTo(destination, getValidBytes("Cannot move an unbounded memory location. Please use validBytes(long)."));
/*      */   }
/*      */   
/*      */   final long getValidBytes(String error) {
/* 5077 */     long rem = getValidBytes();
/* 5078 */     if (rem < 0L) {
/* 5079 */       throw new IndexOutOfBoundsException(error);
/*      */     }
/* 5081 */     return rem;
/*      */   }
/*      */   final long getValidElements(String error) {
/* 5084 */     long rem = getValidElements();
/* 5085 */     if (rem < 0L) {
/* 5086 */       throw new IndexOutOfBoundsException(error);
/*      */     }
/* 5088 */     return rem;
/*      */   }
/*      */   final PointerIO<T> getIO(String error) {
/* 5091 */     PointerIO<T> io = getIO();
/* 5092 */     if (io == null)
/* 5093 */       throwBecauseUntyped(error); 
/* 5094 */     return io;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> copyTo(Pointer<?> destination) {
/* 5101 */     return copyTo(destination, getValidElements());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> copyTo(Pointer<?> destination, long elementCount) {
/* 5108 */     PointerIO<T> io = getIO("Cannot copy untyped pointer without byte count information. Please use copyBytesAtOffsetTo(offset, destination, destinationOffset, byteCount) instead");
/* 5109 */     return copyBytesAtOffsetTo(0L, destination, 0L, elementCount * io.getTargetSize());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> find(Pointer<?> needle) {
/* 5116 */     if (needle == null)
/* 5117 */       return null; 
/* 5118 */     long firstOccurrence = JNI.memmem(getPeer(), getValidBytes("Cannot search an unbounded memory area. Please set bounds with validBytes(long)."), needle.getPeer(), needle.getValidBytes("Cannot search for an unbounded content. Please set bounds with validBytes(long)."));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5124 */     return pointerToAddress(firstOccurrence, this.io);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> findLast(Pointer<?> needle) {
/* 5131 */     if (needle == null)
/* 5132 */       return null; 
/* 5133 */     long lastOccurrence = JNI.memmem_last(getPeer(), getValidBytes("Cannot search an unbounded memory area. Please set bounds with validBytes(long)."), needle.getPeer(), needle.getValidBytes("Cannot search for an unbounded content. Please set bounds with validBytes(long)."));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5139 */     return pointerToAddress(lastOccurrence, this.io);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setIntAtIndex(long valueIndex, int value) {
/* 5163 */     return setIntAtOffset(valueIndex * 4L, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setInts(int[] values) {
/* 5170 */     return setIntsAtOffset(0L, values, 0, values.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setIntsAtOffset(long byteOffset, int[] values) {
/* 5177 */     return setIntsAtOffset(byteOffset, values, 0, values.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setIntsAtOffset(long byteOffset, int[] values, int valuesOffset, int length) {
/* 5184 */     long checkedPeer = getPeer() + byteOffset;
/* 5185 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (4 * length) > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 5189 */       invalidPeer(checkedPeer, (4 * length));
/*      */     }
/* 5191 */     if (!isOrdered()) {
/* 5192 */       JNI.set_int_array_disordered(checkedPeer, values, valuesOffset, length);
/* 5193 */       return this;
/*      */     } 
/* 5195 */     JNI.set_int_array(checkedPeer, values, valuesOffset, length);
/* 5196 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getIntAtIndex(long valueIndex) {
/* 5216 */     return getIntAtOffset(valueIndex * 4L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getInts(int length) {
/* 5223 */     return getIntsAtOffset(0L, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getInts() {
/* 5231 */     long validBytes = getValidBytes("Cannot create array if remaining length is not known. Please use getInts(int length) instead.");
/* 5232 */     return getInts((int)(validBytes / 4L));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getIntsAtOffset(long byteOffset, int length) {
/* 5240 */     long checkedPeer = getPeer() + byteOffset;
/* 5241 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (4 * length) > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 5245 */       invalidPeer(checkedPeer, (4 * length));
/*      */     }
/* 5247 */     if (!isOrdered())
/* 5248 */       return JNI.get_int_array_disordered(checkedPeer, length); 
/* 5249 */     return JNI.get_int_array(checkedPeer, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setLongAtIndex(long valueIndex, long value) {
/* 5272 */     return setLongAtOffset(valueIndex * 8L, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setLongs(long[] values) {
/* 5279 */     return setLongsAtOffset(0L, values, 0, values.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setLongsAtOffset(long byteOffset, long[] values) {
/* 5286 */     return setLongsAtOffset(byteOffset, values, 0, values.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setLongsAtOffset(long byteOffset, long[] values, int valuesOffset, int length) {
/* 5293 */     long checkedPeer = getPeer() + byteOffset;
/* 5294 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (8 * length) > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 5298 */       invalidPeer(checkedPeer, (8 * length));
/*      */     }
/* 5300 */     if (!isOrdered()) {
/* 5301 */       JNI.set_long_array_disordered(checkedPeer, values, valuesOffset, length);
/* 5302 */       return this;
/*      */     } 
/* 5304 */     JNI.set_long_array(checkedPeer, values, valuesOffset, length);
/* 5305 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLongAtIndex(long valueIndex) {
/* 5325 */     return getLongAtOffset(valueIndex * 8L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long[] getLongs(int length) {
/* 5332 */     return getLongsAtOffset(0L, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long[] getLongs() {
/* 5340 */     long validBytes = getValidBytes("Cannot create array if remaining length is not known. Please use getLongs(int length) instead.");
/* 5341 */     return getLongs((int)(validBytes / 8L));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long[] getLongsAtOffset(long byteOffset, int length) {
/* 5349 */     long checkedPeer = getPeer() + byteOffset;
/* 5350 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (8 * length) > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 5354 */       invalidPeer(checkedPeer, (8 * length));
/*      */     }
/* 5356 */     if (!isOrdered())
/* 5357 */       return JNI.get_long_array_disordered(checkedPeer, length); 
/* 5358 */     return JNI.get_long_array(checkedPeer, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setShortAtIndex(long valueIndex, short value) {
/* 5381 */     return setShortAtOffset(valueIndex * 2L, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setShorts(short[] values) {
/* 5388 */     return setShortsAtOffset(0L, values, 0, values.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setShortsAtOffset(long byteOffset, short[] values) {
/* 5395 */     return setShortsAtOffset(byteOffset, values, 0, values.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setShortsAtOffset(long byteOffset, short[] values, int valuesOffset, int length) {
/* 5402 */     long checkedPeer = getPeer() + byteOffset;
/* 5403 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (2 * length) > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 5407 */       invalidPeer(checkedPeer, (2 * length));
/*      */     }
/* 5409 */     if (!isOrdered()) {
/* 5410 */       JNI.set_short_array_disordered(checkedPeer, values, valuesOffset, length);
/* 5411 */       return this;
/*      */     } 
/* 5413 */     JNI.set_short_array(checkedPeer, values, valuesOffset, length);
/* 5414 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShortAtIndex(long valueIndex) {
/* 5434 */     return getShortAtOffset(valueIndex * 2L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short[] getShorts(int length) {
/* 5441 */     return getShortsAtOffset(0L, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short[] getShorts() {
/* 5449 */     long validBytes = getValidBytes("Cannot create array if remaining length is not known. Please use getShorts(int length) instead.");
/* 5450 */     return getShorts((int)(validBytes / 2L));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short[] getShortsAtOffset(long byteOffset, int length) {
/* 5458 */     long checkedPeer = getPeer() + byteOffset;
/* 5459 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (2 * length) > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 5463 */       invalidPeer(checkedPeer, (2 * length));
/*      */     }
/* 5465 */     if (!isOrdered())
/* 5466 */       return JNI.get_short_array_disordered(checkedPeer, length); 
/* 5467 */     return JNI.get_short_array(checkedPeer, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setByteAtIndex(long valueIndex, byte value) {
/* 5490 */     return setByteAtOffset(valueIndex * 1L, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setBytes(byte[] values) {
/* 5497 */     return setBytesAtOffset(0L, values, 0, values.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setBytesAtOffset(long byteOffset, byte[] values) {
/* 5504 */     return setBytesAtOffset(byteOffset, values, 0, values.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setBytesAtOffset(long byteOffset, byte[] values, int valuesOffset, int length) {
/* 5511 */     long checkedPeer = getPeer() + byteOffset;
/* 5512 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (1 * length) > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 5516 */       invalidPeer(checkedPeer, (1 * length));
/*      */     }
/* 5518 */     JNI.set_byte_array(checkedPeer, values, valuesOffset, length);
/* 5519 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByteAtIndex(long valueIndex) {
/* 5539 */     return getByteAtOffset(valueIndex * 1L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int length) {
/* 5546 */     return getBytesAtOffset(0L, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes() {
/* 5554 */     long validBytes = getValidBytes("Cannot create array if remaining length is not known. Please use getBytes(int length) instead.");
/* 5555 */     return getBytes((int)(validBytes / 1L));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytesAtOffset(long byteOffset, int length) {
/* 5563 */     long checkedPeer = getPeer() + byteOffset;
/* 5564 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (1 * length) > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 5568 */       invalidPeer(checkedPeer, (1 * length));
/*      */     }
/* 5570 */     return JNI.get_byte_array(checkedPeer, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setCharAtIndex(long valueIndex, char value) {
/* 5593 */     return setCharAtOffset(valueIndex * Platform.WCHAR_T_SIZE, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setChars(char[] values) {
/* 5600 */     return setCharsAtOffset(0L, values, 0, values.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setCharsAtOffset(long byteOffset, char[] values) {
/* 5607 */     return setCharsAtOffset(byteOffset, values, 0, values.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setCharsAtOffset(long byteOffset, char[] values, int valuesOffset, int length) {
/* 5614 */     if (Platform.WCHAR_T_SIZE == 4)
/* 5615 */       return setIntsAtOffset(byteOffset, wcharsToInts(values, valuesOffset, length)); 
/* 5616 */     long checkedPeer = getPeer() + byteOffset;
/* 5617 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (Platform.WCHAR_T_SIZE * length) > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 5621 */       invalidPeer(checkedPeer, (Platform.WCHAR_T_SIZE * length));
/*      */     }
/* 5623 */     if (!isOrdered()) {
/* 5624 */       JNI.set_char_array_disordered(checkedPeer, values, valuesOffset, length);
/* 5625 */       return this;
/*      */     } 
/* 5627 */     JNI.set_char_array(checkedPeer, values, valuesOffset, length);
/* 5628 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char getCharAtIndex(long valueIndex) {
/* 5648 */     return getCharAtOffset(valueIndex * Platform.WCHAR_T_SIZE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getChars(int length) {
/* 5655 */     return getCharsAtOffset(0L, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getChars() {
/* 5663 */     long validBytes = getValidBytes("Cannot create array if remaining length is not known. Please use getChars(int length) instead.");
/* 5664 */     return getChars((int)(validBytes / Platform.WCHAR_T_SIZE));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getCharsAtOffset(long byteOffset, int length) {
/* 5672 */     if (Platform.WCHAR_T_SIZE == 4)
/* 5673 */       return intsToWChars(getIntsAtOffset(byteOffset, length)); 
/* 5674 */     long checkedPeer = getPeer() + byteOffset;
/* 5675 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (Platform.WCHAR_T_SIZE * length) > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 5679 */       invalidPeer(checkedPeer, (Platform.WCHAR_T_SIZE * length));
/*      */     }
/* 5681 */     if (!isOrdered())
/* 5682 */       return JNI.get_char_array_disordered(checkedPeer, length); 
/* 5683 */     return JNI.get_char_array(checkedPeer, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setFloatAtIndex(long valueIndex, float value) {
/* 5706 */     return setFloatAtOffset(valueIndex * 4L, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setFloats(float[] values) {
/* 5713 */     return setFloatsAtOffset(0L, values, 0, values.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setFloatsAtOffset(long byteOffset, float[] values) {
/* 5720 */     return setFloatsAtOffset(byteOffset, values, 0, values.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setFloatsAtOffset(long byteOffset, float[] values, int valuesOffset, int length) {
/* 5727 */     long checkedPeer = getPeer() + byteOffset;
/* 5728 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (4 * length) > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 5732 */       invalidPeer(checkedPeer, (4 * length));
/*      */     }
/* 5734 */     if (!isOrdered()) {
/* 5735 */       JNI.set_float_array_disordered(checkedPeer, values, valuesOffset, length);
/* 5736 */       return this;
/*      */     } 
/* 5738 */     JNI.set_float_array(checkedPeer, values, valuesOffset, length);
/* 5739 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloatAtIndex(long valueIndex) {
/* 5759 */     return getFloatAtOffset(valueIndex * 4L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float[] getFloats(int length) {
/* 5766 */     return getFloatsAtOffset(0L, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float[] getFloats() {
/* 5774 */     long validBytes = getValidBytes("Cannot create array if remaining length is not known. Please use getFloats(int length) instead.");
/* 5775 */     return getFloats((int)(validBytes / 4L));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float[] getFloatsAtOffset(long byteOffset, int length) {
/* 5783 */     long checkedPeer = getPeer() + byteOffset;
/* 5784 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (4 * length) > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 5788 */       invalidPeer(checkedPeer, (4 * length));
/*      */     }
/* 5790 */     if (!isOrdered())
/* 5791 */       return JNI.get_float_array_disordered(checkedPeer, length); 
/* 5792 */     return JNI.get_float_array(checkedPeer, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setDoubleAtIndex(long valueIndex, double value) {
/* 5815 */     return setDoubleAtOffset(valueIndex * 8L, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setDoubles(double[] values) {
/* 5822 */     return setDoublesAtOffset(0L, values, 0, values.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setDoublesAtOffset(long byteOffset, double[] values) {
/* 5829 */     return setDoublesAtOffset(byteOffset, values, 0, values.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setDoublesAtOffset(long byteOffset, double[] values, int valuesOffset, int length) {
/* 5836 */     long checkedPeer = getPeer() + byteOffset;
/* 5837 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (8 * length) > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 5841 */       invalidPeer(checkedPeer, (8 * length));
/*      */     }
/* 5843 */     if (!isOrdered()) {
/* 5844 */       JNI.set_double_array_disordered(checkedPeer, values, valuesOffset, length);
/* 5845 */       return this;
/*      */     } 
/* 5847 */     JNI.set_double_array(checkedPeer, values, valuesOffset, length);
/* 5848 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDoubleAtIndex(long valueIndex) {
/* 5868 */     return getDoubleAtOffset(valueIndex * 8L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double[] getDoubles(int length) {
/* 5875 */     return getDoublesAtOffset(0L, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double[] getDoubles() {
/* 5883 */     long validBytes = getValidBytes("Cannot create array if remaining length is not known. Please use getDoubles(int length) instead.");
/* 5884 */     return getDoubles((int)(validBytes / 8L));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double[] getDoublesAtOffset(long byteOffset, int length) {
/* 5892 */     long checkedPeer = getPeer() + byteOffset;
/* 5893 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (8 * length) > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 5897 */       invalidPeer(checkedPeer, (8 * length));
/*      */     }
/* 5899 */     if (!isOrdered())
/* 5900 */       return JNI.get_double_array_disordered(checkedPeer, length); 
/* 5901 */     return JNI.get_double_array(checkedPeer, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setBooleanAtIndex(long valueIndex, boolean value) {
/* 5924 */     return setBooleanAtOffset(valueIndex * 1L, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setBooleans(boolean[] values) {
/* 5931 */     return setBooleansAtOffset(0L, values, 0, values.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setBooleansAtOffset(long byteOffset, boolean[] values) {
/* 5938 */     return setBooleansAtOffset(byteOffset, values, 0, values.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setBooleansAtOffset(long byteOffset, boolean[] values, int valuesOffset, int length) {
/* 5945 */     long checkedPeer = getPeer() + byteOffset;
/* 5946 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (1 * length) > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 5950 */       invalidPeer(checkedPeer, (1 * length));
/*      */     }
/* 5952 */     JNI.set_boolean_array(checkedPeer, values, valuesOffset, length);
/* 5953 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBooleanAtIndex(long valueIndex) {
/* 5973 */     return getBooleanAtOffset(valueIndex * 1L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean[] getBooleans(int length) {
/* 5980 */     return getBooleansAtOffset(0L, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean[] getBooleans() {
/* 5988 */     long validBytes = getValidBytes("Cannot create array if remaining length is not known. Please use getBooleans(int length) instead.");
/* 5989 */     return getBooleans((int)(validBytes / 1L));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean[] getBooleansAtOffset(long byteOffset, int length) {
/* 5997 */     long checkedPeer = getPeer() + byteOffset;
/* 5998 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (1 * length) > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 6002 */       invalidPeer(checkedPeer, (1 * length));
/*      */     }
/* 6004 */     return JNI.get_boolean_array(checkedPeer, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getInts(int[] dest) {
/* 6013 */     getIntBuffer().get(dest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getInts(IntBuffer dest) {
/* 6020 */     dest.duplicate().put(getIntBuffer());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getIntsAtOffset(long byteOffset, int[] dest, int destOffset, int length) {
/* 6027 */     getIntBufferAtOffset(byteOffset, length).get(dest, destOffset, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setInts(IntBuffer values) {
/* 6034 */     return setIntsAtOffset(0L, values, 0L, values.capacity());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setIntsAtOffset(long byteOffset, IntBuffer values) {
/* 6041 */     return setIntsAtOffset(byteOffset, values, 0L, values.capacity());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setIntsAtOffset(long byteOffset, IntBuffer values, long valuesOffset, long length) {
/* 6048 */     if (values == null)
/* 6049 */       throw new IllegalArgumentException("Null values"); 
/* 6050 */     if (values.isDirect()) {
/* 6051 */       long len = length * 4L, off = valuesOffset * 4L;
/* 6052 */       long cap = JNI.getDirectBufferCapacity(values);
/*      */       
/* 6054 */       cap *= 4L;
/*      */       
/* 6056 */       if (cap < off + len) {
/* 6057 */         throw new IndexOutOfBoundsException("The provided buffer has a capacity (" + cap + " bytes) smaller than the requested write operation (" + len + " bytes starting at byte offset " + off + ")");
/*      */       }
/*      */       
/* 6060 */       long checkedPeer = getPeer() + byteOffset;
/* 6061 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L * length > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 6065 */         invalidPeer(checkedPeer, 4L * length);
/*      */       }
/* 6067 */       JNI.memcpy(checkedPeer, JNI.getDirectBufferAddress(values) + off, len);
/*      */     }
/* 6069 */     else if (values.isReadOnly()) {
/* 6070 */       getIntBufferAtOffset(byteOffset, length).put(values.duplicate());
/*      */     } else {
/*      */       
/* 6073 */       setIntsAtOffset(byteOffset, values.array(), (int)(values.arrayOffset() + valuesOffset), (int)length);
/*      */     } 
/* 6075 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IntBuffer getIntBuffer(long length) {
/* 6082 */     return getIntBufferAtOffset(0L, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IntBuffer getIntBuffer() {
/* 6089 */     long validBytes = getValidBytes("Cannot create buffer if remaining length is not known. Please use getIntBuffer(long length) instead.");
/* 6090 */     return getIntBufferAtOffset(0L, validBytes / 4L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IntBuffer getIntBufferAtOffset(long byteOffset, long length) {
/* 6097 */     long blen = 4L * length;
/* 6098 */     long checkedPeer = getPeer() + byteOffset;
/* 6099 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + blen > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 6103 */       invalidPeer(checkedPeer, blen);
/*      */     }
/* 6105 */     ByteBuffer buffer = JNI.newDirectByteBuffer(checkedPeer, blen);
/* 6106 */     buffer.order(order());
/* 6107 */     return buffer.asIntBuffer();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getLongs(long[] dest) {
/* 6116 */     getLongBuffer().get(dest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getLongs(LongBuffer dest) {
/* 6123 */     dest.duplicate().put(getLongBuffer());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getLongsAtOffset(long byteOffset, long[] dest, int destOffset, int length) {
/* 6130 */     getLongBufferAtOffset(byteOffset, length).get(dest, destOffset, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setLongs(LongBuffer values) {
/* 6137 */     return setLongsAtOffset(0L, values, 0L, values.capacity());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setLongsAtOffset(long byteOffset, LongBuffer values) {
/* 6144 */     return setLongsAtOffset(byteOffset, values, 0L, values.capacity());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setLongsAtOffset(long byteOffset, LongBuffer values, long valuesOffset, long length) {
/* 6151 */     if (values == null)
/* 6152 */       throw new IllegalArgumentException("Null values"); 
/* 6153 */     if (values.isDirect()) {
/* 6154 */       long len = length * 8L, off = valuesOffset * 8L;
/* 6155 */       long cap = JNI.getDirectBufferCapacity(values);
/*      */       
/* 6157 */       cap *= 8L;
/*      */       
/* 6159 */       if (cap < off + len) {
/* 6160 */         throw new IndexOutOfBoundsException("The provided buffer has a capacity (" + cap + " bytes) smaller than the requested write operation (" + len + " bytes starting at byte offset " + off + ")");
/*      */       }
/*      */       
/* 6163 */       long checkedPeer = getPeer() + byteOffset;
/* 6164 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L * length > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 6168 */         invalidPeer(checkedPeer, 8L * length);
/*      */       }
/* 6170 */       JNI.memcpy(checkedPeer, JNI.getDirectBufferAddress(values) + off, len);
/*      */     }
/* 6172 */     else if (values.isReadOnly()) {
/* 6173 */       getLongBufferAtOffset(byteOffset, length).put(values.duplicate());
/*      */     } else {
/*      */       
/* 6176 */       setLongsAtOffset(byteOffset, values.array(), (int)(values.arrayOffset() + valuesOffset), (int)length);
/*      */     } 
/* 6178 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LongBuffer getLongBuffer(long length) {
/* 6185 */     return getLongBufferAtOffset(0L, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LongBuffer getLongBuffer() {
/* 6192 */     long validBytes = getValidBytes("Cannot create buffer if remaining length is not known. Please use getLongBuffer(long length) instead.");
/* 6193 */     return getLongBufferAtOffset(0L, validBytes / 8L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LongBuffer getLongBufferAtOffset(long byteOffset, long length) {
/* 6200 */     long blen = 8L * length;
/* 6201 */     long checkedPeer = getPeer() + byteOffset;
/* 6202 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + blen > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 6206 */       invalidPeer(checkedPeer, blen);
/*      */     }
/* 6208 */     ByteBuffer buffer = JNI.newDirectByteBuffer(checkedPeer, blen);
/* 6209 */     buffer.order(order());
/* 6210 */     return buffer.asLongBuffer();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getShorts(short[] dest) {
/* 6219 */     getShortBuffer().get(dest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getShorts(ShortBuffer dest) {
/* 6226 */     dest.duplicate().put(getShortBuffer());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getShortsAtOffset(long byteOffset, short[] dest, int destOffset, int length) {
/* 6233 */     getShortBufferAtOffset(byteOffset, length).get(dest, destOffset, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setShorts(ShortBuffer values) {
/* 6240 */     return setShortsAtOffset(0L, values, 0L, values.capacity());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setShortsAtOffset(long byteOffset, ShortBuffer values) {
/* 6247 */     return setShortsAtOffset(byteOffset, values, 0L, values.capacity());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setShortsAtOffset(long byteOffset, ShortBuffer values, long valuesOffset, long length) {
/* 6254 */     if (values == null)
/* 6255 */       throw new IllegalArgumentException("Null values"); 
/* 6256 */     if (values.isDirect()) {
/* 6257 */       long len = length * 2L, off = valuesOffset * 2L;
/* 6258 */       long cap = JNI.getDirectBufferCapacity(values);
/*      */       
/* 6260 */       cap *= 2L;
/*      */       
/* 6262 */       if (cap < off + len) {
/* 6263 */         throw new IndexOutOfBoundsException("The provided buffer has a capacity (" + cap + " bytes) smaller than the requested write operation (" + len + " bytes starting at byte offset " + off + ")");
/*      */       }
/*      */       
/* 6266 */       long checkedPeer = getPeer() + byteOffset;
/* 6267 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 2L * length > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 6271 */         invalidPeer(checkedPeer, 2L * length);
/*      */       }
/* 6273 */       JNI.memcpy(checkedPeer, JNI.getDirectBufferAddress(values) + off, len);
/*      */     }
/* 6275 */     else if (values.isReadOnly()) {
/* 6276 */       getShortBufferAtOffset(byteOffset, length).put(values.duplicate());
/*      */     } else {
/*      */       
/* 6279 */       setShortsAtOffset(byteOffset, values.array(), (int)(values.arrayOffset() + valuesOffset), (int)length);
/*      */     } 
/* 6281 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ShortBuffer getShortBuffer(long length) {
/* 6288 */     return getShortBufferAtOffset(0L, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ShortBuffer getShortBuffer() {
/* 6295 */     long validBytes = getValidBytes("Cannot create buffer if remaining length is not known. Please use getShortBuffer(long length) instead.");
/* 6296 */     return getShortBufferAtOffset(0L, validBytes / 2L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ShortBuffer getShortBufferAtOffset(long byteOffset, long length) {
/* 6303 */     long blen = 2L * length;
/* 6304 */     long checkedPeer = getPeer() + byteOffset;
/* 6305 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + blen > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 6309 */       invalidPeer(checkedPeer, blen);
/*      */     }
/* 6311 */     ByteBuffer buffer = JNI.newDirectByteBuffer(checkedPeer, blen);
/* 6312 */     buffer.order(order());
/* 6313 */     return buffer.asShortBuffer();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getBytes(byte[] dest) {
/* 6322 */     getByteBuffer().get(dest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getBytes(ByteBuffer dest) {
/* 6329 */     dest.duplicate().put(getByteBuffer());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getBytesAtOffset(long byteOffset, byte[] dest, int destOffset, int length) {
/* 6336 */     getByteBufferAtOffset(byteOffset, length).get(dest, destOffset, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setBytes(ByteBuffer values) {
/* 6343 */     return setBytesAtOffset(0L, values, 0L, values.capacity());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setBytesAtOffset(long byteOffset, ByteBuffer values) {
/* 6350 */     return setBytesAtOffset(byteOffset, values, 0L, values.capacity());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setBytesAtOffset(long byteOffset, ByteBuffer values, long valuesOffset, long length) {
/* 6357 */     if (values == null)
/* 6358 */       throw new IllegalArgumentException("Null values"); 
/* 6359 */     if (values.isDirect()) {
/* 6360 */       long len = length * 1L, off = valuesOffset * 1L;
/* 6361 */       long cap = JNI.getDirectBufferCapacity(values);
/*      */       
/* 6363 */       cap *= 1L;
/*      */       
/* 6365 */       if (cap < off + len) {
/* 6366 */         throw new IndexOutOfBoundsException("The provided buffer has a capacity (" + cap + " bytes) smaller than the requested write operation (" + len + " bytes starting at byte offset " + off + ")");
/*      */       }
/*      */       
/* 6369 */       long checkedPeer = getPeer() + byteOffset;
/* 6370 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L * length > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 6374 */         invalidPeer(checkedPeer, 1L * length);
/*      */       }
/* 6376 */       JNI.memcpy(checkedPeer, JNI.getDirectBufferAddress(values) + off, len);
/*      */     }
/* 6378 */     else if (values.isReadOnly()) {
/* 6379 */       getByteBufferAtOffset(byteOffset, length).put(values.duplicate());
/*      */     } else {
/*      */       
/* 6382 */       setBytesAtOffset(byteOffset, values.array(), (int)(values.arrayOffset() + valuesOffset), (int)length);
/*      */     } 
/* 6384 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteBuffer getByteBuffer(long length) {
/* 6391 */     return getByteBufferAtOffset(0L, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteBuffer getByteBuffer() {
/* 6398 */     long validBytes = getValidBytes("Cannot create buffer if remaining length is not known. Please use getByteBuffer(long length) instead.");
/* 6399 */     return getByteBufferAtOffset(0L, validBytes / 1L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteBuffer getByteBufferAtOffset(long byteOffset, long length) {
/* 6406 */     long blen = 1L * length;
/* 6407 */     long checkedPeer = getPeer() + byteOffset;
/* 6408 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + blen > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 6412 */       invalidPeer(checkedPeer, blen);
/*      */     }
/* 6414 */     ByteBuffer buffer = JNI.newDirectByteBuffer(checkedPeer, blen);
/* 6415 */     buffer.order(order());
/* 6416 */     return buffer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setChars(CharBuffer values) {
/* 6426 */     return setCharsAtOffset(0L, values, 0L, values.capacity());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setCharsAtOffset(long byteOffset, CharBuffer values) {
/* 6433 */     return setCharsAtOffset(byteOffset, values, 0L, values.capacity());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setCharsAtOffset(long byteOffset, CharBuffer values, long valuesOffset, long length) {
/* 6440 */     if (values == null)
/* 6441 */       throw new IllegalArgumentException("Null values"); 
/* 6442 */     if (Platform.WCHAR_T_SIZE == 4) {
/* 6443 */       for (int i = 0; i < length; i++)
/* 6444 */         setCharAtOffset(byteOffset + i, values.get((int)(valuesOffset + i))); 
/* 6445 */       return this;
/*      */     } 
/* 6447 */     if (values.isDirect()) {
/* 6448 */       long len = length * Platform.WCHAR_T_SIZE, off = valuesOffset * Platform.WCHAR_T_SIZE;
/* 6449 */       long cap = JNI.getDirectBufferCapacity(values);
/*      */       
/* 6451 */       cap *= Platform.WCHAR_T_SIZE;
/*      */       
/* 6453 */       if (cap < off + len) {
/* 6454 */         throw new IndexOutOfBoundsException("The provided buffer has a capacity (" + cap + " bytes) smaller than the requested write operation (" + len + " bytes starting at byte offset " + off + ")");
/*      */       }
/*      */       
/* 6457 */       long checkedPeer = getPeer() + byteOffset;
/* 6458 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + Platform.WCHAR_T_SIZE * length > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 6462 */         invalidPeer(checkedPeer, Platform.WCHAR_T_SIZE * length);
/*      */       }
/* 6464 */       JNI.memcpy(checkedPeer, JNI.getDirectBufferAddress(values) + off, len);
/*      */     } else {
/*      */       
/* 6467 */       setCharsAtOffset(byteOffset, values.array(), (int)(values.arrayOffset() + valuesOffset), (int)length);
/*      */     } 
/* 6469 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getFloats(float[] dest) {
/* 6479 */     getFloatBuffer().get(dest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getFloats(FloatBuffer dest) {
/* 6486 */     dest.duplicate().put(getFloatBuffer());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getFloatsAtOffset(long byteOffset, float[] dest, int destOffset, int length) {
/* 6493 */     getFloatBufferAtOffset(byteOffset, length).get(dest, destOffset, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setFloats(FloatBuffer values) {
/* 6500 */     return setFloatsAtOffset(0L, values, 0L, values.capacity());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setFloatsAtOffset(long byteOffset, FloatBuffer values) {
/* 6507 */     return setFloatsAtOffset(byteOffset, values, 0L, values.capacity());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setFloatsAtOffset(long byteOffset, FloatBuffer values, long valuesOffset, long length) {
/* 6514 */     if (values == null)
/* 6515 */       throw new IllegalArgumentException("Null values"); 
/* 6516 */     if (values.isDirect()) {
/* 6517 */       long len = length * 4L, off = valuesOffset * 4L;
/* 6518 */       long cap = JNI.getDirectBufferCapacity(values);
/*      */       
/* 6520 */       cap *= 4L;
/*      */       
/* 6522 */       if (cap < off + len) {
/* 6523 */         throw new IndexOutOfBoundsException("The provided buffer has a capacity (" + cap + " bytes) smaller than the requested write operation (" + len + " bytes starting at byte offset " + off + ")");
/*      */       }
/*      */       
/* 6526 */       long checkedPeer = getPeer() + byteOffset;
/* 6527 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L * length > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 6531 */         invalidPeer(checkedPeer, 4L * length);
/*      */       }
/* 6533 */       JNI.memcpy(checkedPeer, JNI.getDirectBufferAddress(values) + off, len);
/*      */     }
/* 6535 */     else if (values.isReadOnly()) {
/* 6536 */       getFloatBufferAtOffset(byteOffset, length).put(values.duplicate());
/*      */     } else {
/*      */       
/* 6539 */       setFloatsAtOffset(byteOffset, values.array(), (int)(values.arrayOffset() + valuesOffset), (int)length);
/*      */     } 
/* 6541 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FloatBuffer getFloatBuffer(long length) {
/* 6548 */     return getFloatBufferAtOffset(0L, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FloatBuffer getFloatBuffer() {
/* 6555 */     long validBytes = getValidBytes("Cannot create buffer if remaining length is not known. Please use getFloatBuffer(long length) instead.");
/* 6556 */     return getFloatBufferAtOffset(0L, validBytes / 4L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FloatBuffer getFloatBufferAtOffset(long byteOffset, long length) {
/* 6563 */     long blen = 4L * length;
/* 6564 */     long checkedPeer = getPeer() + byteOffset;
/* 6565 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + blen > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 6569 */       invalidPeer(checkedPeer, blen);
/*      */     }
/* 6571 */     ByteBuffer buffer = JNI.newDirectByteBuffer(checkedPeer, blen);
/* 6572 */     buffer.order(order());
/* 6573 */     return buffer.asFloatBuffer();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getDoubles(double[] dest) {
/* 6582 */     getDoubleBuffer().get(dest);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getDoubles(DoubleBuffer dest) {
/* 6589 */     dest.duplicate().put(getDoubleBuffer());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getDoublesAtOffset(long byteOffset, double[] dest, int destOffset, int length) {
/* 6596 */     getDoubleBufferAtOffset(byteOffset, length).get(dest, destOffset, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setDoubles(DoubleBuffer values) {
/* 6603 */     return setDoublesAtOffset(0L, values, 0L, values.capacity());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setDoublesAtOffset(long byteOffset, DoubleBuffer values) {
/* 6610 */     return setDoublesAtOffset(byteOffset, values, 0L, values.capacity());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setDoublesAtOffset(long byteOffset, DoubleBuffer values, long valuesOffset, long length) {
/* 6617 */     if (values == null)
/* 6618 */       throw new IllegalArgumentException("Null values"); 
/* 6619 */     if (values.isDirect()) {
/* 6620 */       long len = length * 8L, off = valuesOffset * 8L;
/* 6621 */       long cap = JNI.getDirectBufferCapacity(values);
/*      */       
/* 6623 */       cap *= 8L;
/*      */       
/* 6625 */       if (cap < off + len) {
/* 6626 */         throw new IndexOutOfBoundsException("The provided buffer has a capacity (" + cap + " bytes) smaller than the requested write operation (" + len + " bytes starting at byte offset " + off + ")");
/*      */       }
/*      */       
/* 6629 */       long checkedPeer = getPeer() + byteOffset;
/* 6630 */       if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L * length > this.validEnd))
/*      */       {
/*      */ 
/*      */         
/* 6634 */         invalidPeer(checkedPeer, 8L * length);
/*      */       }
/* 6636 */       JNI.memcpy(checkedPeer, JNI.getDirectBufferAddress(values) + off, len);
/*      */     }
/* 6638 */     else if (values.isReadOnly()) {
/* 6639 */       getDoubleBufferAtOffset(byteOffset, length).put(values.duplicate());
/*      */     } else {
/*      */       
/* 6642 */       setDoublesAtOffset(byteOffset, values.array(), (int)(values.arrayOffset() + valuesOffset), (int)length);
/*      */     } 
/* 6644 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DoubleBuffer getDoubleBuffer(long length) {
/* 6651 */     return getDoubleBufferAtOffset(0L, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DoubleBuffer getDoubleBuffer() {
/* 6658 */     long validBytes = getValidBytes("Cannot create buffer if remaining length is not known. Please use getDoubleBuffer(long length) instead.");
/* 6659 */     return getDoubleBufferAtOffset(0L, validBytes / 8L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DoubleBuffer getDoubleBufferAtOffset(long byteOffset, long length) {
/* 6666 */     long blen = 8L * length;
/* 6667 */     long checkedPeer = getPeer() + byteOffset;
/* 6668 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + blen > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 6672 */       invalidPeer(checkedPeer, blen);
/*      */     }
/* 6674 */     ByteBuffer buffer = JNI.newDirectByteBuffer(checkedPeer, blen);
/* 6675 */     buffer.order(order());
/* 6676 */     return buffer.asDoubleBuffer();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum StringType
/*      */   {
/* 6693 */     C(false, true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6700 */     WideC(true, true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6709 */     PascalShort(false, true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6716 */     PascalWide(true, true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6722 */     PascalAnsi(false, true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6728 */     BSTR(true, true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6734 */     STL(false, false),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6740 */     WideSTL(true, false);
/*      */     
/*      */     final boolean isWide;
/*      */     
/*      */     final boolean canCreate;
/*      */     
/*      */     StringType(boolean isWide, boolean canCreate) {
/* 6747 */       this.isWide = isWide;
/* 6748 */       this.canCreate = canCreate;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static void notAString(StringType type, String reason) {
/* 6754 */     throw new RuntimeException("There is no " + type + " String here ! (" + reason + ")");
/*      */   }
/*      */   
/*      */   protected void checkIntRefCount(StringType type, long byteOffset) {
/* 6758 */     int refCount = getIntAtOffset(byteOffset);
/* 6759 */     if (refCount <= 0) {
/* 6760 */       notAString(type, "invalid refcount: " + refCount);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(StringType type) {
/* 6770 */     return getStringAtOffset(0L, type, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(StringType type, Charset charset) {
/* 6781 */     return getStringAtOffset(0L, type, charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getSTLStringAtOffset(long byteOffset, StringType type, Charset charset) {
/*      */     long pOff;
/*      */     Pointer<?> p;
/* 6791 */     boolean wide = (type == StringType.WideSTL);
/*      */     
/* 6793 */     int fixedBuffLength = 16;
/* 6794 */     int fixedBuffSize = wide ? (fixedBuffLength * Platform.WCHAR_T_SIZE) : fixedBuffLength;
/* 6795 */     long length = getSizeTAtOffset(byteOffset + fixedBuffSize + SIZE);
/*      */ 
/*      */     
/* 6798 */     if (length < (fixedBuffLength - 1)) {
/* 6799 */       pOff = byteOffset;
/* 6800 */       p = this;
/*      */     } else {
/* 6802 */       pOff = 0L;
/* 6803 */       p = getPointerAtOffset(byteOffset + fixedBuffSize + SIZE);
/*      */     } 
/* 6805 */     int endChar = wide ? p.getCharAtOffset(pOff + length * Platform.WCHAR_T_SIZE) : p.getByteAtOffset(pOff + length);
/* 6806 */     if (endChar != 0)
/* 6807 */       notAString(type, "STL string format is not recognized : did not find a NULL char at the expected end of string of expected length " + length); 
/* 6808 */     return p.getStringAtOffset(pOff, wide ? StringType.WideC : StringType.C, charset);
/*      */   } static <U> Pointer<U> setSTLString(Pointer<U> pointer, long byteOffset, String s, StringType type, Charset charset) {
/*      */     long pOff;
/*      */     Pointer<?> p;
/* 6812 */     boolean wide = (type == StringType.WideSTL);
/*      */     
/* 6814 */     int fixedBuffLength = 16;
/* 6815 */     int fixedBuffSize = wide ? (fixedBuffLength * Platform.WCHAR_T_SIZE) : fixedBuffLength;
/* 6816 */     long lengthOffset = byteOffset + fixedBuffSize + SIZE;
/* 6817 */     long capacityOffset = lengthOffset + SIZE;
/*      */     
/* 6819 */     long length = s.length();
/* 6820 */     if (pointer == null) {
/* 6821 */       throw new UnsupportedOperationException("Cannot create STL strings (yet)");
/*      */     }
/* 6823 */     long currentLength = pointer.getSizeTAtOffset(lengthOffset);
/* 6824 */     long currentCapacity = pointer.getSizeTAtOffset(capacityOffset);
/*      */     
/* 6826 */     if (currentLength < 0L || currentCapacity < 0L || currentLength > currentCapacity) {
/* 6827 */       notAString(type, "STL string format not recognized : currentLength = " + currentLength + ", currentCapacity = " + currentCapacity);
/*      */     }
/* 6829 */     if (length > currentCapacity) {
/* 6830 */       throw new RuntimeException("The target STL string is not large enough to write a string of length " + length + " (current capacity = " + currentCapacity + ")");
/*      */     }
/* 6832 */     pointer.setSizeTAtOffset(lengthOffset, length);
/*      */ 
/*      */ 
/*      */     
/* 6836 */     if (length < (fixedBuffLength - 1)) {
/* 6837 */       pOff = byteOffset;
/* 6838 */       p = pointer;
/*      */     } else {
/* 6840 */       pOff = 0L;
/* 6841 */       p = pointer.getPointerAtOffset(byteOffset + fixedBuffSize + SizeT.SIZE);
/*      */     } 
/*      */     
/* 6844 */     int endChar = wide ? p.getCharAtOffset(pOff + currentLength * Platform.WCHAR_T_SIZE) : p.getByteAtOffset(pOff + currentLength);
/* 6845 */     if (endChar != 0) {
/* 6846 */       notAString(type, "STL string format is not recognized : did not find a NULL char at the expected end of string of expected length " + currentLength);
/*      */     }
/* 6848 */     p.setStringAtOffset(pOff, s, wide ? StringType.WideC : StringType.C, charset);
/* 6849 */     return pointer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getStringAtOffset(long byteOffset, StringType type, Charset charset) {
/*      */     try {
/*      */       long len;
/* 6864 */       switch (type) {
/*      */         case PascalShort:
/* 6866 */           len = (getByteAtOffset(byteOffset) & 0xFF);
/* 6867 */           return new String(getBytesAtOffset(byteOffset + 1L, SizeT.safeIntCast(len)), charset(charset));
/*      */         case PascalWide:
/* 6869 */           checkIntRefCount(type, byteOffset - 8L);
/*      */         case BSTR:
/* 6871 */           len = getIntAtOffset(byteOffset - 4L);
/* 6872 */           if (len < 0L || (len & 0x1L) == 1L) {
/* 6873 */             notAString(type, "invalid byte length: " + len);
/*      */           }
/* 6875 */           if (getCharAtOffset(byteOffset + len) != '\000')
/* 6876 */             notAString(type, "no null short after the " + len + " declared bytes"); 
/* 6877 */           return new String(getCharsAtOffset(byteOffset, SizeT.safeIntCast(len / Platform.WCHAR_T_SIZE)));
/*      */         case PascalAnsi:
/* 6879 */           checkIntRefCount(type, byteOffset - 8L);
/* 6880 */           len = getIntAtOffset(byteOffset - 4L);
/* 6881 */           if (len < 0L)
/* 6882 */             notAString(type, "invalid byte length: " + len); 
/* 6883 */           if (getByteAtOffset(byteOffset + len) != 0)
/* 6884 */             notAString(type, "no null short after the " + len + " declared bytes"); 
/* 6885 */           return new String(getBytesAtOffset(byteOffset, SizeT.safeIntCast(len)), charset(charset));
/*      */         case C:
/* 6887 */           len = strlen(byteOffset);
/* 6888 */           return new String(getBytesAtOffset(byteOffset, SizeT.safeIntCast(len)), charset(charset));
/*      */         case WideC:
/* 6890 */           len = wcslen(byteOffset);
/* 6891 */           return new String(getCharsAtOffset(byteOffset, SizeT.safeIntCast(len)));
/*      */         case STL:
/*      */         case WideSTL:
/* 6894 */           return getSTLStringAtOffset(byteOffset, type, charset);
/*      */       } 
/* 6896 */       throw new RuntimeException("Unhandled string type : " + type);
/*      */     }
/* 6898 */     catch (UnsupportedEncodingException ex) {
/* 6899 */       throwUnexpected(ex);
/* 6900 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setString(String s, StringType type) {
/* 6912 */     return setString(this, 0L, s, type, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setStringAtOffset(long byteOffset, String s, StringType type, Charset charset) {
/* 6925 */     return setString(this, byteOffset, s, type, charset);
/*      */   }
/*      */   
/*      */   private static String charset(Charset charset) {
/* 6929 */     return ((charset == null) ? Charset.defaultCharset() : charset).name(); } static <U> Pointer<U> setString(Pointer<U> pointer, long byteOffset, String s, StringType type, Charset charset) { 
/*      */     try { byte[] bytes; int bytesCount;
/*      */       char[] chars;
/*      */       int headerBytes;
/*      */       int headerShift;
/* 6934 */       if (s == null) {
/* 6935 */         return null;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6942 */       switch (type)
/*      */       { case PascalShort:
/* 6944 */           bytes = s.getBytes(charset(charset));
/* 6945 */           bytesCount = bytes.length;
/* 6946 */           if (pointer == null)
/* 6947 */             pointer = (Pointer)allocateBytes((bytesCount + 1)); 
/* 6948 */           if (bytesCount > 255)
/* 6949 */             throw new IllegalArgumentException("Pascal strings cannot be more than 255 chars long (tried to write string of byte length " + bytesCount + ")"); 
/* 6950 */           pointer.setByteAtOffset(byteOffset, (byte)bytesCount);
/* 6951 */           pointer.setBytesAtOffset(byteOffset + 1L, bytes, 0, bytesCount);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 7020 */           return pointer;case C: bytes = s.getBytes(charset(charset)); bytesCount = bytes.length; if (pointer == null) pointer = (Pointer)allocateBytes((bytesCount + 1));  pointer.setBytesAtOffset(byteOffset, bytes, 0, bytesCount); pointer.setByteAtOffset(byteOffset + bytesCount, (byte)0); return pointer;case WideC: chars = s.toCharArray(); bytesCount = chars.length * Platform.WCHAR_T_SIZE; if (pointer == null) pointer = (Pointer)allocateChars((bytesCount + 2));  pointer.setCharsAtOffset(byteOffset, chars); pointer.setCharAtOffset(byteOffset + bytesCount, false); return pointer;case PascalWide: headerBytes = 8; chars = s.toCharArray(); bytesCount = chars.length * Platform.WCHAR_T_SIZE; if (pointer == null) { pointer = (Pointer)allocateChars((headerBytes + bytesCount + 2)); byteOffset = (headerShift = headerBytes); } else { headerShift = 0; }  pointer.setIntAtOffset(byteOffset - 8L, 1); pointer.setIntAtOffset(byteOffset - 4L, bytesCount); pointer.setCharsAtOffset(byteOffset, chars); pointer.setCharAtOffset(byteOffset + bytesCount, false); return pointer.offset(headerShift);case PascalAnsi: headerBytes = 8; bytes = s.getBytes(charset(charset)); bytesCount = bytes.length; if (pointer == null) { pointer = (Pointer)allocateBytes((headerBytes + bytesCount + 1)); byteOffset = (headerShift = headerBytes); } else { headerShift = 0; }  pointer.setIntAtOffset(byteOffset - 8L, 1); pointer.setIntAtOffset(byteOffset - 4L, bytesCount); pointer.setBytesAtOffset(byteOffset, bytes); pointer.setByteAtOffset(byteOffset + bytesCount, (byte)0); return pointer.offset(headerShift);case BSTR: headerBytes = 4; chars = s.toCharArray(); bytesCount = chars.length * Platform.WCHAR_T_SIZE; if (pointer == null) { pointer = (Pointer)allocateChars((headerBytes + bytesCount + 2)); byteOffset = (headerShift = headerBytes); } else { headerShift = 0; }  pointer.setIntAtOffset(byteOffset - 4L, bytesCount); pointer.setCharsAtOffset(byteOffset, chars); pointer.setCharAtOffset(byteOffset + bytesCount, false); return pointer.offset(headerShift);
/* 7021 */         case STL: case WideSTL: return setSTLString(pointer, byteOffset, s, type, charset); }  throw new RuntimeException("Unhandled string type : " + type); } catch (UnsupportedEncodingException ex)
/* 7022 */     { throwUnexpected(ex);
/* 7023 */       return null; }
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<?> pointerToString(String string, StringType type, Charset charset) {
/* 7034 */     return setString(null, 0L, string, type, charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Byte> pointerToCString(String string) {
/* 7044 */     return setString(null, 0L, string, StringType.C, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Byte>> pointerToCStrings(String... strings) {
/* 7051 */     if (strings == null)
/* 7052 */       return null; 
/* 7053 */     final int len = strings.length;
/* 7054 */     final Pointer[] pointers = new Pointer[len];
/* 7055 */     Pointer<Pointer<Byte>> mem = allocateArray(PointerIO.getPointerInstance(Byte.class), len, new Releaser()
/*      */         {
/*      */           public void release(Pointer<?> p) {
/* 7058 */             Pointer<Pointer<Byte>> mem = (Pointer)p;
/* 7059 */             for (int i = 0; i < len; i++) {
/* 7060 */               Pointer<Byte> pp = pointers[i];
/* 7061 */               if (pp != null)
/* 7062 */                 pp.release(); 
/*      */             }  }
/*      */         });
/* 7065 */     for (int i = 0; i < len; i++) {
/* 7066 */       mem.set(i, arrayOfPointer[i] = pointerToCString(strings[i]));
/*      */     }
/* 7068 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Character> pointerToWideCString(String string) {
/* 7077 */     return setString(null, 0L, string, StringType.WideC, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer<Pointer<Character>> pointerToWideCStrings(String... strings) {
/* 7084 */     if (strings == null)
/* 7085 */       return null; 
/* 7086 */     final int len = strings.length;
/* 7087 */     final Pointer[] pointers = new Pointer[len];
/* 7088 */     Pointer<Pointer<Character>> mem = allocateArray(PointerIO.getPointerInstance(Character.class), len, new Releaser()
/*      */         {
/*      */           public void release(Pointer<?> p) {
/* 7091 */             Pointer<Pointer<Character>> mem = (Pointer)p;
/* 7092 */             for (int i = 0; i < len; i++) {
/* 7093 */               Pointer<Character> pp = pointers[i];
/* 7094 */               if (pp != null)
/* 7095 */                 pp.release(); 
/*      */             }  }
/*      */         });
/* 7098 */     for (int i = 0; i < len; i++) {
/* 7099 */       mem.set(i, arrayOfPointer[i] = pointerToWideCString(strings[i]));
/*      */     }
/* 7101 */     return mem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCString() {
/* 7113 */     return getCStringAtOffset(0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCStringAtOffset(long byteOffset) {
/* 7121 */     return getStringAtOffset(byteOffset, StringType.C, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setCString(String s) {
/* 7129 */     return setCStringAtOffset(0L, s);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setCStringAtOffset(long byteOffset, String s) {
/* 7136 */     return setStringAtOffset(byteOffset, s, StringType.C, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getWideCString() {
/* 7146 */     return getWideCStringAtOffset(0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getWideCStringAtOffset(long byteOffset) {
/* 7154 */     return getStringAtOffset(byteOffset, StringType.WideC, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setWideCString(String s) {
/* 7162 */     return setWideCStringAtOffset(0L, s);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> setWideCStringAtOffset(long byteOffset, String s) {
/* 7169 */     return setStringAtOffset(byteOffset, s, StringType.WideC, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long strlen(long byteOffset) {
/* 7177 */     long checkedPeer = getPeer() + byteOffset;
/* 7178 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 7182 */       invalidPeer(checkedPeer, 1L);
/*      */     }
/* 7184 */     return JNI.strlen(checkedPeer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long wcslen(long byteOffset) {
/* 7191 */     long checkedPeer = getPeer() + byteOffset;
/* 7192 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + Platform.WCHAR_T_SIZE > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 7196 */       invalidPeer(checkedPeer, Platform.WCHAR_T_SIZE);
/*      */     }
/* 7198 */     return JNI.wcslen(checkedPeer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearValidBytes() {
/* 7205 */     long bytes = getValidBytes();
/* 7206 */     if (bytes < 0L)
/* 7207 */       throw new UnsupportedOperationException("Number of valid bytes is unknown. Please use clearBytes(long) or validBytes(long)."); 
/* 7208 */     clearBytes(bytes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearBytes(long length) {
/* 7215 */     clearBytesAtOffset(0L, length, (byte)0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearBytesAtOffset(long byteOffset, long length, byte value) {
/* 7221 */     long checkedPeer = getPeer() + byteOffset;
/* 7222 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + length > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 7226 */       invalidPeer(checkedPeer, length);
/*      */     }
/* 7228 */     JNI.memset(checkedPeer, value, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer<T> findByte(long byteOffset, byte value, long searchLength) {
/* 7235 */     long checkedPeer = getPeer() + byteOffset;
/* 7236 */     if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + searchLength > this.validEnd))
/*      */     {
/*      */ 
/*      */       
/* 7240 */       invalidPeer(checkedPeer, searchLength);
/*      */     }
/* 7242 */     long found = JNI.memchr(checkedPeer, value, searchLength);
/* 7243 */     return (found == 0L) ? null : offset(found - checkedPeer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final T apply(long index) {
/* 7250 */     return get(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void update(long index, T element) {
/* 7257 */     set(index, element);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T[] toArray() {
/* 7266 */     getIO("Cannot create array");
/* 7267 */     return toArray((int)getValidElements("Length of pointed memory is unknown, cannot create array out of this pointer"));
/*      */   }
/*      */   
/*      */   T[] toArray(int length) {
/* 7271 */     Class<?> c = Utils.getClass(getIO("Cannot create array").getTargetType());
/* 7272 */     if (c == null)
/* 7273 */       throw new RuntimeException("Unable to get the target type's class (target type = " + this.io.getTargetType() + ")"); 
/* 7274 */     return (T[])toArray((Object[])Array.newInstance(c, length));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <U> U[] toArray(U[] array) {
/* 7283 */     int n = (int)getValidElements();
/* 7284 */     if (n < 0) {
/* 7285 */       throwBecauseUntyped("Cannot create array");
/*      */     }
/* 7287 */     if (array.length != n) {
/* 7288 */       return (U[])toArray();
/*      */     }
/* 7290 */     for (int i = 0; i < n; i++)
/* 7291 */       array[i] = (U)get(i); 
/* 7292 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum ListType
/*      */   {
/* 7302 */     Unmodifiable,
/*      */ 
/*      */ 
/*      */     
/* 7306 */     FixedCapacity,
/*      */ 
/*      */ 
/*      */     
/* 7310 */     Dynamic;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NativeList<T> asList() {
/* 7318 */     return asList(ListType.FixedCapacity);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NativeList<T> asList(ListType type) {
/* 7325 */     return new DefaultNativeList<T>(this, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> NativeList<E> allocateList(PointerIO<E> io, long capacity) {
/* 7333 */     NativeList<E> list = new DefaultNativeList<E>(allocateArray(io, capacity), ListType.Dynamic);
/* 7334 */     list.clear();
/* 7335 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> NativeList<E> allocateList(Class<E> type, long capacity) {
/* 7343 */     return allocateList(type, capacity);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> NativeList<E> allocateList(Type type, long capacity) {
/* 7351 */     return allocateList(PointerIO.getInstance(type), capacity);
/*      */   }
/*      */   
/*      */   private static char[] intsToWChars(int[] in) {
/* 7355 */     int n = in.length;
/* 7356 */     char[] out = new char[n];
/* 7357 */     for (int i = 0; i < n; i++)
/* 7358 */       out[i] = (char)in[i]; 
/* 7359 */     return out;
/*      */   }
/*      */   private static int[] wcharsToInts(char[] in, int valuesOffset, int length) {
/* 7362 */     int[] out = new int[length];
/* 7363 */     for (int i = 0; i < length; i++)
/* 7364 */       out[i] = in[valuesOffset + i]; 
/* 7365 */     return out;
/*      */   }
/*      */   
/*      */   public Pointer<T> setIntegralAtOffset(long byteOffset, AbstractIntegral value) {
/* 7369 */     switch (value.byteSize()) {
/*      */       case 8:
/* 7371 */         setLongAtOffset(byteOffset, value.longValue());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 7379 */         return this;case 4: setIntAtOffset(byteOffset, SizeT.safeIntCast(value.longValue())); return this;
/*      */     } 
/*      */     throw new UnsupportedOperationException("Unsupported integral size"); } public long getIntegralAtOffset(long byteOffset, int integralSize) {
/* 7382 */     switch (integralSize) {
/*      */       case 8:
/* 7384 */         return getLongAtOffset(byteOffset);
/*      */       case 4:
/* 7386 */         return getIntAtOffset(byteOffset);
/*      */     } 
/* 7388 */     throw new UnsupportedOperationException("Unsupported integral size");
/*      */   }
/*      */   
/*      */   public abstract boolean isOrdered();
/*      */   
/*      */   public abstract Pointer<T> setSizeTsAtOffset(long paramLong, long[] paramArrayOflong, int paramInt1, int paramInt2);
/*      */   
/*      */   public abstract Pointer<T> setSizeTsAtOffset(long paramLong, int[] paramArrayOfint);
/*      */   
/*      */   public abstract Pointer<T> setCLongsAtOffset(long paramLong, long[] paramArrayOflong, int paramInt1, int paramInt2);
/*      */   
/*      */   public abstract Pointer<T> setCLongsAtOffset(long paramLong, int[] paramArrayOfint);
/*      */   
/*      */   public abstract Pointer<T> setInt(int paramInt);
/*      */   
/*      */   public abstract Pointer<T> setIntAtOffset(long paramLong, int paramInt);
/*      */   
/*      */   public abstract int getInt();
/*      */   
/*      */   public abstract int getIntAtOffset(long paramLong);
/*      */   
/*      */   public abstract Pointer<T> setLong(long paramLong);
/*      */   
/*      */   public abstract Pointer<T> setLongAtOffset(long paramLong1, long paramLong2);
/*      */   
/*      */   public abstract long getLong();
/*      */   
/*      */   public abstract long getLongAtOffset(long paramLong);
/*      */   
/*      */   public abstract Pointer<T> setShort(short paramShort);
/*      */   
/*      */   public abstract Pointer<T> setShortAtOffset(long paramLong, short paramShort);
/*      */   
/*      */   public abstract short getShort();
/*      */   
/*      */   public abstract short getShortAtOffset(long paramLong);
/*      */   
/*      */   public abstract Pointer<T> setByte(byte paramByte);
/*      */   
/*      */   public abstract Pointer<T> setByteAtOffset(long paramLong, byte paramByte);
/*      */   
/*      */   public abstract byte getByte();
/*      */   
/*      */   public abstract byte getByteAtOffset(long paramLong);
/*      */   
/*      */   public abstract Pointer<T> setChar(char paramChar);
/*      */   
/*      */   public abstract Pointer<T> setCharAtOffset(long paramLong, char paramChar);
/*      */   
/*      */   public abstract char getChar();
/*      */   
/*      */   public abstract char getCharAtOffset(long paramLong);
/*      */   
/*      */   public abstract Pointer<T> setFloat(float paramFloat);
/*      */   
/*      */   public abstract Pointer<T> setFloatAtOffset(long paramLong, float paramFloat);
/*      */   
/*      */   public abstract float getFloat();
/*      */   
/*      */   public abstract float getFloatAtOffset(long paramLong);
/*      */   
/*      */   public abstract Pointer<T> setDouble(double paramDouble);
/*      */   
/*      */   public abstract Pointer<T> setDoubleAtOffset(long paramLong, double paramDouble);
/*      */   
/*      */   public abstract double getDouble();
/*      */   
/*      */   public abstract double getDoubleAtOffset(long paramLong);
/*      */   
/*      */   public abstract Pointer<T> setBoolean(boolean paramBoolean);
/*      */   
/*      */   public abstract Pointer<T> setBooleanAtOffset(long paramLong, boolean paramBoolean);
/*      */   
/*      */   public abstract boolean getBoolean();
/*      */   
/*      */   public abstract boolean getBooleanAtOffset(long paramLong);
/*      */   
/*      */   public static interface Releaser {
/*      */     void release(Pointer<?> param1Pointer);
/*      */   }
/*      */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\Pointer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */