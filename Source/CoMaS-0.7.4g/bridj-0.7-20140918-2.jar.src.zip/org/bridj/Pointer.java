package org.bridj;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.CharBuffer;
import java.nio.DoubleBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.LongBuffer;
import java.nio.ShortBuffer;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;
import org.bridj.ann.Convention;
import org.bridj.util.DefaultParameterizedType;
import org.bridj.util.Utils;

public abstract class Pointer<T> implements Comparable<Pointer<?>>, Iterable<T> {
  public static final Pointer<?> NULL = null;
  
  public static final int SIZE = Platform.POINTER_SIZE;
  
  protected static final long UNKNOWN_VALIDITY = -1L;
  
  protected static final long NO_PARENT = 0L;
  
  static {
    Platform.initLibrary();
  }
  
  private static final long POINTER_MASK = Platform.is64Bits() ? -1L : 4294967295L;
  
  public static final int defaultAlignment = Integer.parseInt(Platform.getenvOrProperty("BRIDJ_DEFAULT_ALIGNMENT", "bridj.defaultAlignment", "-1"));
  
  protected final PointerIO<T> io;
  
  private final long peer_;
  
  protected final long offsetInParent;
  
  protected final Pointer<?> parent;
  
  protected volatile Object sibling;
  
  protected final long validStart;
  
  protected final long validEnd;
  
  Throwable creationTrace;
  
  Throwable deletionTrace;
  
  Throwable releaseTrace;
  
  private static final int LRU_POINTER_CACHE_SIZE = 8;
  
  private static final int LRU_POINTER_CACHE_TOLERANCE = 1;
  
  Pointer(PointerIO<T> io, long peer, long validStart, long validEnd, Pointer<?> parent, long offsetInParent, Object sibling) {
    this.io = io;
    this.peer_ = peer;
    this.validStart = validStart;
    this.validEnd = validEnd;
    this.parent = parent;
    this.offsetInParent = offsetInParent;
    this.sibling = sibling;
    if (peer == 0L)
      throw new IllegalArgumentException("Pointer instance cannot have NULL peer ! (use null Pointer instead)"); 
    if (BridJ.debugPointers)
      this.creationTrace = (new RuntimeException()).fillInStackTrace(); 
  }
  
  static class OrderedPointer<T> extends Pointer<T> {
    OrderedPointer(PointerIO<T> io, long peer, long validStart, long validEnd, Pointer<?> parent, long offsetInParent, Object sibling) {
      super(io, peer, validStart, validEnd, parent, offsetInParent, sibling);
    }
    
    public boolean isOrdered() {
      return true;
    }
    
    public Pointer<T> setInt(int value) {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
        invalidPeer(checkedPeer, 4L); 
      JNI.set_int(checkedPeer, value);
      return this;
    }
    
    public Pointer<T> setIntAtOffset(long byteOffset, int value) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
        invalidPeer(checkedPeer, 4L); 
      JNI.set_int(checkedPeer, value);
      return this;
    }
    
    public int getInt() {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
        invalidPeer(checkedPeer, 4L); 
      return JNI.get_int(checkedPeer);
    }
    
    public int getIntAtOffset(long byteOffset) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
        invalidPeer(checkedPeer, 4L); 
      return JNI.get_int(checkedPeer);
    }
    
    public Pointer<T> setLong(long value) {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
        invalidPeer(checkedPeer, 8L); 
      JNI.set_long(checkedPeer, value);
      return this;
    }
    
    public Pointer<T> setLongAtOffset(long byteOffset, long value) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
        invalidPeer(checkedPeer, 8L); 
      JNI.set_long(checkedPeer, value);
      return this;
    }
    
    public long getLong() {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
        invalidPeer(checkedPeer, 8L); 
      return JNI.get_long(checkedPeer);
    }
    
    public long getLongAtOffset(long byteOffset) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
        invalidPeer(checkedPeer, 8L); 
      return JNI.get_long(checkedPeer);
    }
    
    public Pointer<T> setShort(short value) {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 2L > this.validEnd))
        invalidPeer(checkedPeer, 2L); 
      JNI.set_short(checkedPeer, value);
      return this;
    }
    
    public Pointer<T> setShortAtOffset(long byteOffset, short value) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 2L > this.validEnd))
        invalidPeer(checkedPeer, 2L); 
      JNI.set_short(checkedPeer, value);
      return this;
    }
    
    public short getShort() {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 2L > this.validEnd))
        invalidPeer(checkedPeer, 2L); 
      return JNI.get_short(checkedPeer);
    }
    
    public short getShortAtOffset(long byteOffset) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 2L > this.validEnd))
        invalidPeer(checkedPeer, 2L); 
      return JNI.get_short(checkedPeer);
    }
    
    public Pointer<T> setByte(byte value) {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
        invalidPeer(checkedPeer, 1L); 
      JNI.set_byte(checkedPeer, value);
      return this;
    }
    
    public Pointer<T> setByteAtOffset(long byteOffset, byte value) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
        invalidPeer(checkedPeer, 1L); 
      JNI.set_byte(checkedPeer, value);
      return this;
    }
    
    public byte getByte() {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
        invalidPeer(checkedPeer, 1L); 
      return JNI.get_byte(checkedPeer);
    }
    
    public byte getByteAtOffset(long byteOffset) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
        invalidPeer(checkedPeer, 1L); 
      return JNI.get_byte(checkedPeer);
    }
    
    public Pointer<T> setChar(char value) {
      if (Platform.WCHAR_T_SIZE == 4)
        return setInt(value); 
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + Platform.WCHAR_T_SIZE > this.validEnd))
        invalidPeer(checkedPeer, Platform.WCHAR_T_SIZE); 
      JNI.set_char(checkedPeer, value);
      return this;
    }
    
    public Pointer<T> setCharAtOffset(long byteOffset, char value) {
      if (Platform.WCHAR_T_SIZE == 4)
        return setIntAtOffset(byteOffset, value); 
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + Platform.WCHAR_T_SIZE > this.validEnd))
        invalidPeer(checkedPeer, Platform.WCHAR_T_SIZE); 
      JNI.set_char(checkedPeer, value);
      return this;
    }
    
    public char getChar() {
      if (Platform.WCHAR_T_SIZE == 4)
        return (char)getInt(); 
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + Platform.WCHAR_T_SIZE > this.validEnd))
        invalidPeer(checkedPeer, Platform.WCHAR_T_SIZE); 
      return JNI.get_char(checkedPeer);
    }
    
    public char getCharAtOffset(long byteOffset) {
      if (Platform.WCHAR_T_SIZE == 4)
        return (char)getIntAtOffset(byteOffset); 
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + Platform.WCHAR_T_SIZE > this.validEnd))
        invalidPeer(checkedPeer, Platform.WCHAR_T_SIZE); 
      return JNI.get_char(checkedPeer);
    }
    
    public Pointer<T> setFloat(float value) {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
        invalidPeer(checkedPeer, 4L); 
      JNI.set_float(checkedPeer, value);
      return this;
    }
    
    public Pointer<T> setFloatAtOffset(long byteOffset, float value) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
        invalidPeer(checkedPeer, 4L); 
      JNI.set_float(checkedPeer, value);
      return this;
    }
    
    public float getFloat() {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
        invalidPeer(checkedPeer, 4L); 
      return JNI.get_float(checkedPeer);
    }
    
    public float getFloatAtOffset(long byteOffset) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
        invalidPeer(checkedPeer, 4L); 
      return JNI.get_float(checkedPeer);
    }
    
    public Pointer<T> setDouble(double value) {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
        invalidPeer(checkedPeer, 8L); 
      JNI.set_double(checkedPeer, value);
      return this;
    }
    
    public Pointer<T> setDoubleAtOffset(long byteOffset, double value) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
        invalidPeer(checkedPeer, 8L); 
      JNI.set_double(checkedPeer, value);
      return this;
    }
    
    public double getDouble() {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
        invalidPeer(checkedPeer, 8L); 
      return JNI.get_double(checkedPeer);
    }
    
    public double getDoubleAtOffset(long byteOffset) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
        invalidPeer(checkedPeer, 8L); 
      return JNI.get_double(checkedPeer);
    }
    
    public Pointer<T> setBoolean(boolean value) {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
        invalidPeer(checkedPeer, 1L); 
      JNI.set_boolean(checkedPeer, value);
      return this;
    }
    
    public Pointer<T> setBooleanAtOffset(long byteOffset, boolean value) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
        invalidPeer(checkedPeer, 1L); 
      JNI.set_boolean(checkedPeer, value);
      return this;
    }
    
    public boolean getBoolean() {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
        invalidPeer(checkedPeer, 1L); 
      return JNI.get_boolean(checkedPeer);
    }
    
    public boolean getBooleanAtOffset(long byteOffset) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
        invalidPeer(checkedPeer, 1L); 
      return JNI.get_boolean(checkedPeer);
    }
    
    public Pointer<T> setSizeTsAtOffset(long byteOffset, long[] values, int valuesOffset, int length) {
      if (values == null)
        throw new IllegalArgumentException("Null values"); 
      if (SizeT.SIZE == 8) {
        setLongsAtOffset(byteOffset, values, valuesOffset, length);
      } else {
        int n = length;
        long checkedPeer = getPeer() + byteOffset;
        if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (n * 4) > this.validEnd))
          invalidPeer(checkedPeer, (n * 4)); 
        long peer = checkedPeer;
        int valuesIndex = valuesOffset;
        for (int i = 0; i < n; i++) {
          int value = (int)values[valuesIndex];
          JNI.set_int(peer, value);
          peer += 4L;
          valuesIndex++;
        } 
      } 
      return this;
    }
    
    public Pointer<T> setSizeTsAtOffset(long byteOffset, int[] values) {
      if (SizeT.SIZE == 4) {
        setIntsAtOffset(byteOffset, values);
      } else {
        int n = values.length;
        long checkedPeer = getPeer() + byteOffset;
        if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (n * 8) > this.validEnd))
          invalidPeer(checkedPeer, (n * 8)); 
        long peer = checkedPeer;
        for (int i = 0; i < n; i++) {
          int value = values[i];
          JNI.set_long(peer, value);
          peer += 8L;
        } 
      } 
      return this;
    }
    
    public Pointer<T> setCLongsAtOffset(long byteOffset, long[] values, int valuesOffset, int length) {
      if (values == null)
        throw new IllegalArgumentException("Null values"); 
      if (CLong.SIZE == 8) {
        setLongsAtOffset(byteOffset, values, valuesOffset, length);
      } else {
        int n = length;
        long checkedPeer = getPeer() + byteOffset;
        if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (n * 4) > this.validEnd))
          invalidPeer(checkedPeer, (n * 4)); 
        long peer = checkedPeer;
        int valuesIndex = valuesOffset;
        for (int i = 0; i < n; i++) {
          int value = (int)values[valuesIndex];
          JNI.set_int(peer, value);
          peer += 4L;
          valuesIndex++;
        } 
      } 
      return this;
    }
    
    public Pointer<T> setCLongsAtOffset(long byteOffset, int[] values) {
      if (CLong.SIZE == 4) {
        setIntsAtOffset(byteOffset, values);
      } else {
        int n = values.length;
        long checkedPeer = getPeer() + byteOffset;
        if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (n * 8) > this.validEnd))
          invalidPeer(checkedPeer, (n * 8)); 
        long peer = checkedPeer;
        for (int i = 0; i < n; i++) {
          int value = values[i];
          JNI.set_long(peer, value);
          peer += 8L;
        } 
      } 
      return this;
    }
  }
  
  static class DisorderedPointer<T> extends Pointer<T> {
    DisorderedPointer(PointerIO<T> io, long peer, long validStart, long validEnd, Pointer<?> parent, long offsetInParent, Object sibling) {
      super(io, peer, validStart, validEnd, parent, offsetInParent, sibling);
    }
    
    public boolean isOrdered() {
      return false;
    }
    
    public Pointer<T> setInt(int value) {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
        invalidPeer(checkedPeer, 4L); 
      JNI.set_int_disordered(checkedPeer, value);
      return this;
    }
    
    public Pointer<T> setIntAtOffset(long byteOffset, int value) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
        invalidPeer(checkedPeer, 4L); 
      JNI.set_int_disordered(checkedPeer, value);
      return this;
    }
    
    public int getInt() {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
        invalidPeer(checkedPeer, 4L); 
      return JNI.get_int_disordered(checkedPeer);
    }
    
    public int getIntAtOffset(long byteOffset) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
        invalidPeer(checkedPeer, 4L); 
      return JNI.get_int_disordered(checkedPeer);
    }
    
    public Pointer<T> setLong(long value) {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
        invalidPeer(checkedPeer, 8L); 
      JNI.set_long_disordered(checkedPeer, value);
      return this;
    }
    
    public Pointer<T> setLongAtOffset(long byteOffset, long value) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
        invalidPeer(checkedPeer, 8L); 
      JNI.set_long_disordered(checkedPeer, value);
      return this;
    }
    
    public long getLong() {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
        invalidPeer(checkedPeer, 8L); 
      return JNI.get_long_disordered(checkedPeer);
    }
    
    public long getLongAtOffset(long byteOffset) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
        invalidPeer(checkedPeer, 8L); 
      return JNI.get_long_disordered(checkedPeer);
    }
    
    public Pointer<T> setShort(short value) {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 2L > this.validEnd))
        invalidPeer(checkedPeer, 2L); 
      JNI.set_short_disordered(checkedPeer, value);
      return this;
    }
    
    public Pointer<T> setShortAtOffset(long byteOffset, short value) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 2L > this.validEnd))
        invalidPeer(checkedPeer, 2L); 
      JNI.set_short_disordered(checkedPeer, value);
      return this;
    }
    
    public short getShort() {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 2L > this.validEnd))
        invalidPeer(checkedPeer, 2L); 
      return JNI.get_short_disordered(checkedPeer);
    }
    
    public short getShortAtOffset(long byteOffset) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 2L > this.validEnd))
        invalidPeer(checkedPeer, 2L); 
      return JNI.get_short_disordered(checkedPeer);
    }
    
    public Pointer<T> setByte(byte value) {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
        invalidPeer(checkedPeer, 1L); 
      JNI.set_byte(checkedPeer, value);
      return this;
    }
    
    public Pointer<T> setByteAtOffset(long byteOffset, byte value) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
        invalidPeer(checkedPeer, 1L); 
      JNI.set_byte(checkedPeer, value);
      return this;
    }
    
    public byte getByte() {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
        invalidPeer(checkedPeer, 1L); 
      return JNI.get_byte(checkedPeer);
    }
    
    public byte getByteAtOffset(long byteOffset) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
        invalidPeer(checkedPeer, 1L); 
      return JNI.get_byte(checkedPeer);
    }
    
    public Pointer<T> setChar(char value) {
      if (Platform.WCHAR_T_SIZE == 4)
        return setInt(value); 
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + Platform.WCHAR_T_SIZE > this.validEnd))
        invalidPeer(checkedPeer, Platform.WCHAR_T_SIZE); 
      JNI.set_char_disordered(checkedPeer, value);
      return this;
    }
    
    public Pointer<T> setCharAtOffset(long byteOffset, char value) {
      if (Platform.WCHAR_T_SIZE == 4)
        return setIntAtOffset(byteOffset, value); 
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + Platform.WCHAR_T_SIZE > this.validEnd))
        invalidPeer(checkedPeer, Platform.WCHAR_T_SIZE); 
      JNI.set_char_disordered(checkedPeer, value);
      return this;
    }
    
    public char getChar() {
      if (Platform.WCHAR_T_SIZE == 4)
        return (char)getInt(); 
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + Platform.WCHAR_T_SIZE > this.validEnd))
        invalidPeer(checkedPeer, Platform.WCHAR_T_SIZE); 
      return JNI.get_char_disordered(checkedPeer);
    }
    
    public char getCharAtOffset(long byteOffset) {
      if (Platform.WCHAR_T_SIZE == 4)
        return (char)getIntAtOffset(byteOffset); 
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + Platform.WCHAR_T_SIZE > this.validEnd))
        invalidPeer(checkedPeer, Platform.WCHAR_T_SIZE); 
      return JNI.get_char_disordered(checkedPeer);
    }
    
    public Pointer<T> setFloat(float value) {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
        invalidPeer(checkedPeer, 4L); 
      JNI.set_float_disordered(checkedPeer, value);
      return this;
    }
    
    public Pointer<T> setFloatAtOffset(long byteOffset, float value) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
        invalidPeer(checkedPeer, 4L); 
      JNI.set_float_disordered(checkedPeer, value);
      return this;
    }
    
    public float getFloat() {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
        invalidPeer(checkedPeer, 4L); 
      return JNI.get_float_disordered(checkedPeer);
    }
    
    public float getFloatAtOffset(long byteOffset) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L > this.validEnd))
        invalidPeer(checkedPeer, 4L); 
      return JNI.get_float_disordered(checkedPeer);
    }
    
    public Pointer<T> setDouble(double value) {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
        invalidPeer(checkedPeer, 8L); 
      JNI.set_double_disordered(checkedPeer, value);
      return this;
    }
    
    public Pointer<T> setDoubleAtOffset(long byteOffset, double value) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
        invalidPeer(checkedPeer, 8L); 
      JNI.set_double_disordered(checkedPeer, value);
      return this;
    }
    
    public double getDouble() {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
        invalidPeer(checkedPeer, 8L); 
      return JNI.get_double_disordered(checkedPeer);
    }
    
    public double getDoubleAtOffset(long byteOffset) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L > this.validEnd))
        invalidPeer(checkedPeer, 8L); 
      return JNI.get_double_disordered(checkedPeer);
    }
    
    public Pointer<T> setBoolean(boolean value) {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
        invalidPeer(checkedPeer, 1L); 
      JNI.set_boolean(checkedPeer, value);
      return this;
    }
    
    public Pointer<T> setBooleanAtOffset(long byteOffset, boolean value) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
        invalidPeer(checkedPeer, 1L); 
      JNI.set_boolean(checkedPeer, value);
      return this;
    }
    
    public boolean getBoolean() {
      long checkedPeer = getPeer() + 0L;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
        invalidPeer(checkedPeer, 1L); 
      return JNI.get_boolean(checkedPeer);
    }
    
    public boolean getBooleanAtOffset(long byteOffset) {
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
        invalidPeer(checkedPeer, 1L); 
      return JNI.get_boolean(checkedPeer);
    }
    
    public Pointer<T> setSizeTsAtOffset(long byteOffset, long[] values, int valuesOffset, int length) {
      if (values == null)
        throw new IllegalArgumentException("Null values"); 
      if (SizeT.SIZE == 8) {
        setLongsAtOffset(byteOffset, values, valuesOffset, length);
      } else {
        int n = length;
        long checkedPeer = getPeer() + byteOffset;
        if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (n * 4) > this.validEnd))
          invalidPeer(checkedPeer, (n * 4)); 
        long peer = checkedPeer;
        int valuesIndex = valuesOffset;
        for (int i = 0; i < n; i++) {
          int value = (int)values[valuesIndex];
          JNI.set_int_disordered(peer, value);
          peer += 4L;
          valuesIndex++;
        } 
      } 
      return this;
    }
    
    public Pointer<T> setSizeTsAtOffset(long byteOffset, int[] values) {
      if (SizeT.SIZE == 4) {
        setIntsAtOffset(byteOffset, values);
      } else {
        int n = values.length;
        long checkedPeer = getPeer() + byteOffset;
        if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (n * 8) > this.validEnd))
          invalidPeer(checkedPeer, (n * 8)); 
        long peer = checkedPeer;
        for (int i = 0; i < n; i++) {
          int value = values[i];
          JNI.set_long_disordered(peer, value);
          peer += 8L;
        } 
      } 
      return this;
    }
    
    public Pointer<T> setCLongsAtOffset(long byteOffset, long[] values, int valuesOffset, int length) {
      if (values == null)
        throw new IllegalArgumentException("Null values"); 
      if (CLong.SIZE == 8) {
        setLongsAtOffset(byteOffset, values, valuesOffset, length);
      } else {
        int n = length;
        long checkedPeer = getPeer() + byteOffset;
        if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (n * 4) > this.validEnd))
          invalidPeer(checkedPeer, (n * 4)); 
        long peer = checkedPeer;
        int valuesIndex = valuesOffset;
        for (int i = 0; i < n; i++) {
          int value = (int)values[valuesIndex];
          JNI.set_int_disordered(peer, value);
          peer += 4L;
          valuesIndex++;
        } 
      } 
      return this;
    }
    
    public Pointer<T> setCLongsAtOffset(long byteOffset, int[] values) {
      if (CLong.SIZE == 4) {
        setIntsAtOffset(byteOffset, values);
      } else {
        int n = values.length;
        long checkedPeer = getPeer() + byteOffset;
        if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (n * 8) > this.validEnd))
          invalidPeer(checkedPeer, (n * 8)); 
        long peer = checkedPeer;
        for (int i = 0; i < n; i++) {
          int value = values[i];
          JNI.set_long_disordered(peer, value);
          peer += 8L;
        } 
      } 
      return this;
    }
  }
  
  public static Type pointerType(Type targetType) {
    return DefaultParameterizedType.paramType(Pointer.class, new Type[] { targetType });
  }
  
  public static <E extends Enum<E>> Type intEnumType(Class<? extends IntValuedEnum<E>> targetType) {
    return DefaultParameterizedType.paramType(IntValuedEnum.class, new Type[] { targetType });
  }
  
  public synchronized void release() {
    Object sibling = this.sibling;
    this.sibling = null;
    if (sibling instanceof Pointer)
      ((Pointer)sibling).release(); 
    if (BridJ.debugPointerReleases)
      this.releaseTrace = (new RuntimeException()).fillInStackTrace(); 
  }
  
  public int compareTo(Pointer<?> p) {
    if (p == null)
      return 1; 
    long p1 = getPeer(), p2 = p.getPeer();
    return (p1 == p2) ? 0 : ((p1 < p2) ? -1 : 1);
  }
  
  public int compareBytes(Pointer<?> other, long byteCount) {
    return compareBytesAtOffset(0L, other, 0L, byteCount);
  }
  
  public int compareBytesAtOffset(long byteOffset, Pointer<?> other, long otherByteOffset, long byteCount) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + byteCount > this.validEnd))
      invalidPeer(checkedPeer, byteCount); 
    return JNI.memcmp(checkedPeer, other.getCheckedPeer(otherByteOffset, byteCount), byteCount);
  }
  
  public int hashCode() {
    int hc = (new Long(getPeer())).hashCode();
    return hc;
  }
  
  public String toString() {
    return "Pointer(peer = 0x" + Long.toHexString(getPeer()) + ", targetType = " + Utils.toString(getTargetType()) + ", order = " + order() + ")";
  }
  
  protected final void invalidPeer(long peer, long validityCheckLength) {
    throw new IndexOutOfBoundsException("Cannot access to memory data of length " + validityCheckLength + " at offset " + (peer - getPeer()) + " : valid memory start is " + this.validStart + ", valid memory size is " + (this.validEnd - this.validStart));
  }
  
  private final long getCheckedPeer(long byteOffset, long validityCheckLength) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + validityCheckLength > this.validEnd))
      invalidPeer(checkedPeer, validityCheckLength); 
    return checkedPeer;
  }
  
  public Pointer<T> offset(long byteOffset) {
    return offset(byteOffset, getIO());
  }
  
  <U> Pointer<U> offset(long byteOffset, PointerIO<U> pio) {
    if (byteOffset == 0L)
      return (pio == this.io) ? this : as(pio); 
    long newPeer = getPeer() + byteOffset;
    Object newSibling = (getSibling() != null) ? getSibling() : this;
    if (this.validStart == -1L)
      return newPointer(pio, newPeer, isOrdered(), -1L, -1L, null, 0L, null, newSibling); 
    if (newPeer > this.validEnd || newPeer < this.validStart)
      throw new IndexOutOfBoundsException("Invalid pointer offset : " + byteOffset + " (validBytes = " + getValidBytes() + ") !"); 
    return newPointer(pio, newPeer, isOrdered(), this.validStart, this.validEnd, null, 0L, null, newSibling);
  }
  
  public Pointer<T> validBytes(long byteCount) {
    long peer = getPeer();
    long newValidEnd = peer + byteCount;
    if (this.validStart == peer && this.validEnd == newValidEnd)
      return this; 
    if (this.validEnd != -1L && newValidEnd > this.validEnd)
      throw new IndexOutOfBoundsException("Cannot extend validity of pointed memory from " + this.validEnd + " to " + newValidEnd); 
    Object newSibling = (getSibling() != null) ? getSibling() : this;
    return newPointer(getIO(), peer, isOrdered(), this.validStart, newValidEnd, this.parent, this.offsetInParent, null, newSibling);
  }
  
  @Deprecated
  public Pointer<T> withoutValidityInformation() {
    long peer = getPeer();
    if (this.validStart == -1L)
      return this; 
    Object newSibling = (getSibling() != null) ? getSibling() : this;
    return newPointer(getIO(), peer, isOrdered(), -1L, -1L, this.parent, this.offsetInParent, null, newSibling);
  }
  
  public Pointer<T> clone() {
    long length = getValidElements();
    if (length < 0L)
      throw new UnsupportedOperationException("Number of bytes unknown, unable to clone memory (use validBytes(long))"); 
    Pointer<T> c = allocateArray(getIO(), length);
    copyTo(c);
    return c;
  }
  
  public Pointer<T> validElements(long elementCount) {
    return validBytes(elementCount * getIO("Cannot define elements validity").getTargetSize());
  }
  
  public Pointer<Pointer<T>> getReference() {
    if (this.parent == null)
      throw new UnsupportedOperationException("Cannot get reference to this pointer, it wasn't created from Pointer.getPointer(offset) or from a similar method."); 
    PointerIO<T> io = getIO();
    return this.parent.offset(this.offsetInParent).as((io == null) ? null : io.getReferenceIO());
  }
  
  public final long getPeer() {
    if (BridJ.debugPointerReleases && 
      this.releaseTrace != null)
      throw new RuntimeException("Pointer was released here:\n\t" + Utils.toString(this.releaseTrace).replaceAll("\n", "\n\t")); 
    return this.peer_;
  }
  
  public static <R> Pointer<DynamicFunction<R>> allocateDynamicCallback(DynamicCallback<R> callback, Convention.Style callingConvention, Type returnType, Type... parameterTypes) {
    if (callback == null)
      throw new IllegalArgumentException("Java callback handler cannot be null !"); 
    if (returnType == null)
      throw new IllegalArgumentException("Callback return type cannot be null !"); 
    if (parameterTypes == null)
      throw new IllegalArgumentException("Invalid (null) list of parameter types !"); 
    try {
      MethodCallInfo mci = new MethodCallInfo(returnType, parameterTypes, false);
      Method method = DynamicCallback.class.getMethod("apply", new Class[] { Object[].class });
      mci.setMethod(method);
      mci.setJavaSignature("([Ljava/lang/Object;)Ljava/lang/Object;");
      mci.setCallingConvention(callingConvention);
      mci.setGenericCallback(true);
      mci.setJavaCallback(callback);
      return CRuntime.createCToJavaCallback(mci, DynamicCallback.class);
    } catch (Exception ex) {
      throw new RuntimeException("Failed to allocate dynamic callback for convention " + callingConvention + ", return type " + Utils.toString(returnType) + " and parameter types " + Arrays.asList(parameterTypes) + " : " + ex, ex);
    } 
  }
  
  public <U> Pointer<U> as(PointerIO<U> newIO) {
    return viewAs(isOrdered(), newIO);
  }
  
  public Pointer<T> order(ByteOrder order) {
    if (order.equals(ByteOrder.nativeOrder()) == isOrdered())
      return this; 
    return viewAs(!isOrdered(), getIO());
  }
  
  public ByteOrder order() {
    ByteOrder order = isOrdered() ? ByteOrder.nativeOrder() : ((ByteOrder.nativeOrder() == ByteOrder.BIG_ENDIAN) ? ByteOrder.LITTLE_ENDIAN : ByteOrder.BIG_ENDIAN);
    return order;
  }
  
  <U> Pointer<U> viewAs(boolean ordered, PointerIO<U> newIO) {
    if (newIO == this.io && ordered == isOrdered())
      return this; 
    return newPointer(newIO, getPeer(), ordered, getValidStart(), getValidEnd(), getParent(), getOffsetInParent(), null, (getSibling() != null) ? getSibling() : this);
  }
  
  public final PointerIO<T> getIO() {
    return this.io;
  }
  
  final long getOffsetInParent() {
    return this.offsetInParent;
  }
  
  final Pointer<?> getParent() {
    return this.parent;
  }
  
  final Object getSibling() {
    return this.sibling;
  }
  
  final long getValidEnd() {
    return this.validEnd;
  }
  
  final long getValidStart() {
    return this.validStart;
  }
  
  public <U> Pointer<U> as(Type type) {
    PointerIO<U> pio = PointerIO.getInstance(type);
    return as(pio);
  }
  
  public <U> Pointer<U> as(Class<U> type) {
    return as(type);
  }
  
  public <R> DynamicFunction<R> asDynamicFunction(Convention.Style callingConvention, Type returnType, Type... parameterTypes) {
    return CRuntime.getInstance().getDynamicFunctionFactory(null, callingConvention, returnType, parameterTypes).newInstance(this);
  }
  
  public Pointer<?> asUntyped() {
    return as((Class)null);
  }
  
  public long getValidBytes() {
    long ve = getValidEnd();
    return (ve == -1L) ? -1L : (ve - getPeer());
  }
  
  public long getValidElements() {
    long bytes = getValidBytes();
    long elementSize = getTargetSize();
    if (bytes < 0L || elementSize <= 0L)
      return -1L; 
    return bytes / elementSize;
  }
  
  public ListIterator<T> iterator() {
    return new ListIterator<T>() {
        Pointer<T> next = (Pointer.this.getValidElements() != 0L) ? Pointer.this : null;
        
        Pointer<T> previous;
        
        public T next() {
          if (this.next == null)
            throw new NoSuchElementException(); 
          T value = this.next.get();
          this.previous = this.next;
          long valid = this.next.getValidElements();
          this.next = (valid < 0L || valid > 1L) ? this.next.next(1L) : null;
          return value;
        }
        
        public void remove() {
          throw new UnsupportedOperationException();
        }
        
        public boolean hasNext() {
          long rem;
          return (this.next != null && ((rem = this.next.getValidBytes()) < 0L || rem > 0L));
        }
        
        public void add(T o) {
          throw new UnsupportedOperationException();
        }
        
        public boolean hasPrevious() {
          return (this.previous != null);
        }
        
        public int nextIndex() {
          throw new UnsupportedOperationException();
        }
        
        public T previous() {
          throw new UnsupportedOperationException();
        }
        
        public int previousIndex() {
          throw new UnsupportedOperationException();
        }
        
        public void set(T o) {
          if (this.previous == null)
            throw new NoSuchElementException("You haven't called next() prior to calling ListIterator.set(E)"); 
          this.previous.set(o);
        }
      };
  }
  
  public static <E extends Enum<E>> Pointer<IntValuedEnum<E>> pointerToEnum(IntValuedEnum<E> instance) {
    Class<E> enumClass;
    if (instance instanceof FlagSet) {
      enumClass = ((FlagSet<E>)instance).getEnumClass();
    } else if (instance instanceof Enum) {
      enumClass = (Class)instance.getClass();
    } else {
      throw new RuntimeException("Expected a FlagSet or an Enum, got " + instance);
    } 
    PointerIO<IntValuedEnum<E>> io = PointerIO.getInstance(DefaultParameterizedType.paramType(IntValuedEnum.class, new Type[] { enumClass }));
    Pointer<IntValuedEnum<E>> p = allocate(io);
    p.setInt((int)instance.value());
    return p;
  }
  
  @Deprecated
  public static <N extends NativeObject> Pointer<N> pointerTo(N instance) {
    return getPointer(instance);
  }
  
  public static <N extends NativeObject> Pointer<N> getPointer(N instance) {
    return getPointer((NativeObject)instance, null);
  }
  
  public static <N extends NativeObjectInterface> Pointer<N> getPointer(N instance) {
    return (Pointer)getPointer((NativeObject)instance);
  }
  
  public static <R extends NativeObject> Pointer<R> getPointer(NativeObject instance, Type targetType) {
    return (instance == null) ? null : (Pointer)instance.peer;
  }
  
  public static long getAddress(NativeObject instance, Class targetType) {
    return getPeer(getPointer(instance, targetType));
  }
  
  public <O extends NativeObject> O getNativeObjectAtOffset(long byteOffset, Type type) {
    return BridJ.createNativeObjectFromPointer((byteOffset == 0L) ? this : offset(byteOffset), type);
  }
  
  public <O extends NativeObject> Pointer<T> setNativeObject(O value, Type type) {
    BridJ.copyNativeObjectToAddress(value, type, this);
    return this;
  }
  
  public <O extends NativeObject> O getNativeObjectAtOffset(long byteOffset, Class<O> type) {
    return getNativeObjectAtOffset(byteOffset, type);
  }
  
  public <O extends NativeObject> O getNativeObject(Class<O> type) {
    return getNativeObject(type);
  }
  
  public <O extends NativeObject> O getNativeObject(Type type) {
    O o = getNativeObjectAtOffset(0L, type);
    return o;
  }
  
  public boolean isAligned() {
    return isAligned(getIO("Cannot check alignment").getTargetAlignment());
  }
  
  public boolean isAligned(long alignment) {
    return isAligned(getPeer(), alignment);
  }
  
  protected static boolean isAligned(long address, long alignment) {
    return (computeRemainder(address, alignment) == 0);
  }
  
  protected static int computeRemainder(long address, long alignment) {
    switch ((int)alignment) {
      case -1:
      case 0:
      case 1:
        return 0;
      case 2:
        return (int)(address & 0x1L);
      case 4:
        return (int)(address & 0x3L);
      case 8:
        return (int)(address & 0x7L);
      case 16:
        return (int)(address & 0xFL);
      case 32:
        return (int)(address & 0x1FL);
      case 64:
        return (int)(address & 0x3FL);
    } 
    if (alignment < 0L)
      return 0; 
    return (int)(address % alignment);
  }
  
  public T get() {
    return get(0L);
  }
  
  public static <T> T get(Pointer<T> pointer) {
    return (pointer == null) ? null : pointer.get();
  }
  
  public T get(long index) {
    return getIO("Cannot get pointed value").get(this, index);
  }
  
  public T set(T value) {
    return set(0L, value);
  }
  
  private static long getTargetSizeToAllocateArrayOrThrow(PointerIO<?> io) {
    long targetSize = -1L;
    if (io == null || (targetSize = io.getTargetSize()) < 0L)
      throwBecauseUntyped("Cannot allocate array "); 
    return targetSize;
  }
  
  private static void throwBecauseUntyped(String message) {
    throw new RuntimeException("Pointer is not typed (call Pointer.as(Type) to create a typed pointer) : " + message);
  }
  
  static void throwUnexpected(Throwable ex) {
    throw new RuntimeException("Unexpected error", ex);
  }
  
  public T set(long index, T value) {
    getIO("Cannot set pointed value").set(this, index, value);
    return value;
  }
  
  public static long getPeer(Pointer<?> pointer) {
    return (pointer == null) ? 0L : pointer.getPeer();
  }
  
  public long getTargetSize() {
    return getIO("Cannot compute target size").getTargetSize();
  }
  
  public Pointer<T> next() {
    return next(1L);
  }
  
  public Pointer<T> next(long delta) {
    return offset(getIO("Cannot get pointers to next or previous targets").getTargetSize() * delta);
  }
  
  public static void release(Pointer... pointers) {
    for (Pointer pointer : pointers) {
      if (pointer != null)
        pointer.release(); 
    } 
  }
  
  public boolean equals(Object obj) {
    if (obj == null || !(obj instanceof Pointer))
      return false; 
    Pointer p = (Pointer)obj;
    return (getPeer() == p.getPeer());
  }
  
  @Deprecated
  public static Pointer<?> pointerToAddress(long peer) {
    return pointerToAddress(peer, (PointerIO)null);
  }
  
  @Deprecated
  public static Pointer<?> pointerToAddress(long peer, long size) {
    return newPointer(null, peer, true, peer, peer + size, null, 0L, null, null);
  }
  
  public static <P> Pointer<P> pointerToAddress(long peer, Class<P> targetClass, Releaser releaser) {
    return pointerToAddress(peer, targetClass, releaser);
  }
  
  public static <P> Pointer<P> pointerToAddress(long peer, Type targetType, Releaser releaser) {
    PointerIO<P> pio = PointerIO.getInstance(targetType);
    return newPointer(pio, peer, true, -1L, -1L, null, -1L, releaser, null);
  }
  
  public static <P> Pointer<P> pointerToAddress(long peer, PointerIO<P> io) {
    if (BridJ.cachePointers)
      return (Pointer)((PointerLRUCache)localCachedPointers.get()).get(peer, io); 
    return pointerToAddress_(peer, io);
  }
  
  private static <P> Pointer<P> pointerToAddress_(long peer, PointerIO<P> io) {
    return newPointer(io, peer, true, -1L, -1L, null, 0L, null, null);
  }
  
  private static final ThreadLocal<PointerLRUCache> localCachedPointers = new ThreadLocal<PointerLRUCache>() {
      protected PointerLRUCache initialValue() {
        return new PointerLRUCache(8, 1) {
            protected <P> Pointer<P> pointerToAddress(long peer, PointerIO<P> io) {
              return Pointer.pointerToAddress_(peer, io);
            }
          };
      }
    };
  
  static <P> Pointer<P> pointerToAddress(long peer, PointerIO<P> io, Releaser releaser) {
    return newPointer(io, peer, true, -1L, -1L, null, 0L, releaser, null);
  }
  
  @Deprecated
  public static Pointer<?> pointerToAddress(long peer, Releaser releaser) {
    return newPointer(null, peer, true, -1L, -1L, null, 0L, releaser, null);
  }
  
  public static Pointer<?> pointerToAddress(long peer, long size, Releaser releaser) {
    return newPointer(null, peer, true, peer, peer + size, null, 0L, releaser, null);
  }
  
  public static <P> Pointer<P> pointerToAddress(long peer, long size, PointerIO<P> io, Releaser releaser) {
    return newPointer(io, peer, true, peer, peer + size, null, 0L, releaser, null);
  }
  
  @Deprecated
  public static <P> Pointer<P> pointerToAddress(long peer, Class<P> targetClass) {
    return pointerToAddress(peer, targetClass);
  }
  
  @Deprecated
  public static <P> Pointer<P> pointerToAddress(long peer, Type targetType) {
    return newPointer(PointerIO.getInstance(targetType), peer, true, -1L, -1L, null, -1L, null, null);
  }
  
  static <U> Pointer<U> pointerToAddress(long peer, long size, PointerIO<U> io) {
    return newPointer(io, peer, true, peer, peer + size, null, 0L, null, null);
  }
  
  static <U> Pointer<U> newPointer(PointerIO<U> io, long peer, boolean ordered, long validStart, long validEnd, Pointer<?> parent, long offsetInParent, final Releaser releaser, Object sibling) {
    peer &= POINTER_MASK;
    if (peer == 0L)
      return null; 
    if (validEnd != -1L && validEnd <= validStart)
      return null; 
    if (releaser == null) {
      if (ordered)
        return new OrderedPointer<U>(io, peer, validStart, validEnd, parent, offsetInParent, sibling); 
      return new DisorderedPointer<U>(io, peer, validStart, validEnd, parent, offsetInParent, sibling);
    } 
    assert sibling == null;
    if (ordered)
      return new OrderedPointer<U>(io, peer, validStart, validEnd, parent, offsetInParent, sibling) {
          private volatile Pointer.Releaser rel = releaser;
          
          public synchronized void release() {
            if (this.rel != null) {
              Pointer.Releaser rel = this.rel;
              this.rel = null;
              rel.release(this);
            } 
            if (BridJ.debugPointerReleases)
              this.releaseTrace = (new RuntimeException()).fillInStackTrace(); 
          }
          
          protected void finalize() {
            release();
          }
          
          @Deprecated
          public synchronized Pointer<U> withReleaser(final Pointer.Releaser beforeDeallocation) {
            final Pointer.Releaser thisReleaser = this.rel;
            this.rel = null;
            return newPointer(getIO(), getPeer(), isOrdered(), getValidStart(), getValidEnd(), null, 0L, (beforeDeallocation == null) ? thisReleaser : new Pointer.Releaser() {
                  public void release(Pointer<?> p) {
                    beforeDeallocation.release(p);
                    if (thisReleaser != null)
                      thisReleaser.release(p); 
                  }
                },  null);
          }
        }; 
    return new DisorderedPointer<U>(io, peer, validStart, validEnd, parent, offsetInParent, sibling) {
        private volatile Pointer.Releaser rel = releaser;
        
        public synchronized void release() {
          if (this.rel != null) {
            Pointer.Releaser rel = this.rel;
            this.rel = null;
            rel.release(this);
          } 
          if (BridJ.debugPointerReleases)
            this.releaseTrace = (new RuntimeException()).fillInStackTrace(); 
        }
        
        protected void finalize() {
          release();
        }
        
        @Deprecated
        public synchronized Pointer<U> withReleaser(final Pointer.Releaser beforeDeallocation) {
          final Pointer.Releaser thisReleaser = this.rel;
          this.rel = null;
          return newPointer(getIO(), getPeer(), isOrdered(), getValidStart(), getValidEnd(), null, 0L, (beforeDeallocation == null) ? thisReleaser : new Pointer.Releaser() {
                public void release(Pointer<?> p) {
                  beforeDeallocation.release(p);
                  if (thisReleaser != null)
                    thisReleaser.release(p); 
                }
              },  null);
        }
      };
  }
  
  public static <P extends TypedPointer> Pointer<P> allocateTypedPointer(Class<P> type) {
    return allocate(PointerIO.getInstance(type));
  }
  
  public static <P extends TypedPointer> Pointer<P> allocateTypedPointers(Class<P> type, long arrayLength) {
    return allocateArray(PointerIO.getInstance(type), arrayLength);
  }
  
  public static <P> Pointer<Pointer<P>> allocatePointer(Class<P> targetType) {
    return allocatePointer(targetType);
  }
  
  public static <P> Pointer<Pointer<P>> allocatePointer(Type targetType) {
    return allocate(PointerIO.getPointerInstance(targetType));
  }
  
  public static <P> Pointer<Pointer<Pointer<P>>> allocatePointerPointer(Type targetType) {
    return allocatePointer(pointerType(targetType));
  }
  
  public static <P> Pointer<Pointer<Pointer<P>>> allocatePointerPointer(Class<P> targetType) {
    return allocatePointerPointer(targetType);
  }
  
  public static <V> Pointer<Pointer<?>> allocatePointer() {
    return allocate((PointerIO)PointerIO.getPointerInstance());
  }
  
  public static Pointer<Pointer<?>> allocatePointers(int arrayLength) {
    return allocateArray((PointerIO)PointerIO.getPointerInstance(), arrayLength);
  }
  
  public static <P> Pointer<Pointer<P>> allocatePointers(Class<P> targetType, int arrayLength) {
    return allocatePointers(targetType, arrayLength);
  }
  
  public static <P> Pointer<Pointer<P>> allocatePointers(Type targetType, int arrayLength) {
    return allocateArray(PointerIO.getPointerInstance(targetType), arrayLength);
  }
  
  public static <V> Pointer<V> allocate(Class<V> elementClass) {
    return allocate(elementClass);
  }
  
  public static <V> Pointer<V> allocate(Type elementClass) {
    return allocateArray(elementClass, 1L);
  }
  
  public static <V> Pointer<V> allocate(PointerIO<V> io) {
    return allocateBytes(io, getTargetSizeToAllocateArrayOrThrow(io), (Releaser)null);
  }
  
  public static <V> Pointer<V> allocateArray(PointerIO<V> io, long arrayLength) {
    return allocateBytes(io, getTargetSizeToAllocateArrayOrThrow(io) * arrayLength, (Releaser)null);
  }
  
  public static <V> Pointer<V> allocateArray(PointerIO<V> io, long arrayLength, Releaser beforeDeallocation) {
    return allocateBytes(io, getTargetSizeToAllocateArrayOrThrow(io) * arrayLength, beforeDeallocation);
  }
  
  public static <V> Pointer<V> allocateBytes(PointerIO<V> io, long byteSize, Releaser beforeDeallocation) {
    return allocateAlignedBytes(io, byteSize, defaultAlignment, beforeDeallocation);
  }
  
  public static <V> Pointer<V> allocateAlignedBytes(PointerIO<V> io, long byteSize, int alignment, final Releaser beforeDeallocation) {
    long address;
    if (byteSize == 0L)
      return null; 
    if (byteSize < 0L)
      throw new IllegalArgumentException("Cannot allocate a negative amount of memory !"); 
    long offset = 0L;
    if (alignment <= 1) {
      address = JNI.mallocNulled(byteSize);
    } else {
      address = JNI.mallocNulled(byteSize + alignment - 1L);
      long remainder = address % alignment;
      if (remainder > 0L)
        offset = alignment - remainder; 
    } 
    if (address == 0L)
      throw new RuntimeException("Failed to allocate " + byteSize); 
    Pointer<V> ptr = newPointer(io, address, true, address, address + byteSize + offset, null, 0L, (beforeDeallocation == null) ? freeReleaser : new Releaser() {
          public void release(Pointer<?> p) {
            beforeDeallocation.release(p);
            Pointer.freeReleaser.release(p);
          }
        },  null);
    if (offset > 0L)
      ptr = ptr.offset(offset); 
    return ptr;
  }
  
  @Deprecated
  public synchronized Pointer<T> withReleaser(Releaser beforeDeallocation) {
    return newPointer(getIO(), getPeer(), isOrdered(), getValidStart(), getValidEnd(), null, 0L, beforeDeallocation, null);
  }
  
  static Releaser freeReleaser = new FreeReleaser();
  
  static class FreeReleaser implements Releaser {
    public void release(Pointer<?> p) {
      assert p.getSibling() == null;
      assert p.validStart == p.getPeer();
      if (BridJ.debugPointers) {
        p.deletionTrace = (new RuntimeException()).fillInStackTrace();
        BridJ.info("Freeing pointer " + p + " (peer = " + p.getPeer() + ", validStart = " + p.validStart + ", validEnd = " + p.validEnd + ", validBytes = " + p.getValidBytes() + ").\nCreation trace:\n\t" + Utils.toString(p.creationTrace).replaceAll("\n", "\n\t") + "\nDeletion trace:\n\t" + Utils.toString(p.deletionTrace).replaceAll("\n", "\n\t"));
      } 
      if (!BridJ.debugNeverFree)
        JNI.free(p.getPeer()); 
    }
  }
  
  public static <V> Pointer<V> allocateArray(Class<V> elementClass, long arrayLength) {
    return allocateArray(elementClass, arrayLength);
  }
  
  public static <V> Pointer<V> allocateArray(Type elementClass, long arrayLength) {
    if (arrayLength == 0L)
      return null; 
    PointerIO<?> pio = PointerIO.getInstance(elementClass);
    if (pio == null)
      throw new UnsupportedOperationException("Cannot allocate memory for type " + ((elementClass instanceof Class) ? ((Class)elementClass).getName() : elementClass.toString())); 
    return allocateArray((PointerIO)pio, arrayLength);
  }
  
  public static <V> Pointer<V> allocateAlignedArray(Class<V> elementClass, long arrayLength, int alignment) {
    return allocateAlignedArray(elementClass, arrayLength, alignment);
  }
  
  public static <V> Pointer<V> allocateAlignedArray(Type elementClass, long arrayLength, int alignment) {
    PointerIO<?> io = PointerIO.getInstance(elementClass);
    if (io == null)
      throw new UnsupportedOperationException("Cannot allocate memory for type " + ((elementClass instanceof Class) ? ((Class)elementClass).getName() : elementClass.toString())); 
    return allocateAlignedBytes((PointerIO)io, getTargetSizeToAllocateArrayOrThrow(io) * arrayLength, alignment, null);
  }
  
  public static Pointer<?> pointerToBuffer(Buffer buffer) {
    if (buffer == null)
      return null; 
    if (buffer instanceof IntBuffer)
      return pointerToInts((IntBuffer)buffer); 
    if (buffer instanceof LongBuffer)
      return pointerToLongs((LongBuffer)buffer); 
    if (buffer instanceof ShortBuffer)
      return pointerToShorts((ShortBuffer)buffer); 
    if (buffer instanceof ByteBuffer)
      return pointerToBytes((ByteBuffer)buffer); 
    if (buffer instanceof CharBuffer)
      return pointerToChars((CharBuffer)buffer); 
    if (buffer instanceof FloatBuffer)
      return pointerToFloats((FloatBuffer)buffer); 
    if (buffer instanceof DoubleBuffer)
      return pointerToDoubles((DoubleBuffer)buffer); 
    throw new UnsupportedOperationException("Unhandled buffer type : " + buffer.getClass().getName());
  }
  
  public void updateBuffer(Buffer buffer) {
    if (buffer == null)
      throw new IllegalArgumentException("Cannot update a null Buffer !"); 
    if (Utils.isDirect(buffer)) {
      long address = JNI.getDirectBufferAddress(buffer);
      if (address != getPeer())
        throw new IllegalArgumentException("Direct buffer does not point to the same location as this Pointer instance, updating it makes no sense !"); 
    } else {
      if (buffer instanceof IntBuffer) {
        ((IntBuffer)buffer).duplicate().put(getIntBuffer());
        return;
      } 
      if (buffer instanceof LongBuffer) {
        ((LongBuffer)buffer).duplicate().put(getLongBuffer());
        return;
      } 
      if (buffer instanceof ShortBuffer) {
        ((ShortBuffer)buffer).duplicate().put(getShortBuffer());
        return;
      } 
      if (buffer instanceof ByteBuffer) {
        ((ByteBuffer)buffer).duplicate().put(getByteBuffer());
        return;
      } 
      if (buffer instanceof FloatBuffer) {
        ((FloatBuffer)buffer).duplicate().put(getFloatBuffer());
        return;
      } 
      if (buffer instanceof DoubleBuffer) {
        ((DoubleBuffer)buffer).duplicate().put(getDoubleBuffer());
        return;
      } 
      throw new UnsupportedOperationException("Unhandled buffer type : " + buffer.getClass().getName());
    } 
  }
  
  public static Pointer<Integer> pointerToInt(int value) {
    Pointer<Integer> mem = allocate(PointerIO.getIntInstance());
    mem.setInt(value);
    return mem;
  }
  
  public static Pointer<Integer> pointerToInts(int... values) {
    if (values == null)
      return null; 
    Pointer<Integer> mem = allocateArray(PointerIO.getIntInstance(), values.length);
    mem.setIntsAtOffset(0L, values, 0, values.length);
    return mem;
  }
  
  public static Pointer<Pointer<Integer>> pointerToInts(int[][] values) {
    if (values == null)
      return null; 
    int dim1 = values.length, dim2 = (values[0]).length;
    Pointer<Pointer<Integer>> mem = allocateInts(dim1, dim2);
    for (int i1 = 0; i1 < dim1; i1++)
      mem.setIntsAtOffset((i1 * dim2 * 4), values[i1], 0, dim2); 
    return mem;
  }
  
  public static Pointer<Pointer<Pointer<Integer>>> pointerToInts(int[][][] values) {
    if (values == null)
      return null; 
    int dim1 = values.length, dim2 = (values[0]).length, dim3 = (values[0][0]).length;
    Pointer<Pointer<Pointer<Integer>>> mem = allocateInts(dim1, dim2, dim3);
    for (int i1 = 0; i1 < dim1; i1++) {
      int offset1 = i1 * dim2;
      for (int i2 = 0; i2 < dim2; i2++) {
        int offset2 = (offset1 + i2) * dim3;
        mem.setIntsAtOffset((offset2 * 4), values[i1][i2], 0, dim3);
      } 
    } 
    return mem;
  }
  
  public static Pointer<Integer> allocateInt() {
    return allocate(PointerIO.getIntInstance());
  }
  
  public static Pointer<Integer> allocateInts(long arrayLength) {
    return allocateArray(PointerIO.getIntInstance(), arrayLength);
  }
  
  public static Pointer<Pointer<Integer>> allocateInts(long dim1, long dim2) {
    return allocateArray(PointerIO.getArrayInstance(PointerIO.getIntInstance(), new long[] { dim1, dim2 }, 0), dim1);
  }
  
  public static Pointer<Pointer<Pointer<Integer>>> allocateInts(long dim1, long dim2, long dim3) {
    long[] dims = { dim1, dim2, dim3 };
    return allocateArray(PointerIO.getArrayInstance(PointerIO.getArrayInstance(PointerIO.getIntInstance(), dims, 1), dims, 0), dim1);
  }
  
  public static Pointer<Long> pointerToLong(long value) {
    Pointer<Long> mem = allocate(PointerIO.getLongInstance());
    mem.setLong(value);
    return mem;
  }
  
  public static Pointer<Long> pointerToLongs(long... values) {
    if (values == null)
      return null; 
    Pointer<Long> mem = allocateArray(PointerIO.getLongInstance(), values.length);
    mem.setLongsAtOffset(0L, values, 0, values.length);
    return mem;
  }
  
  public static Pointer<Pointer<Long>> pointerToLongs(long[][] values) {
    if (values == null)
      return null; 
    int dim1 = values.length, dim2 = (values[0]).length;
    Pointer<Pointer<Long>> mem = allocateLongs(dim1, dim2);
    for (int i1 = 0; i1 < dim1; i1++)
      mem.setLongsAtOffset((i1 * dim2 * 8), values[i1], 0, dim2); 
    return mem;
  }
  
  public static Pointer<Pointer<Pointer<Long>>> pointerToLongs(long[][][] values) {
    if (values == null)
      return null; 
    int dim1 = values.length, dim2 = (values[0]).length, dim3 = (values[0][0]).length;
    Pointer<Pointer<Pointer<Long>>> mem = allocateLongs(dim1, dim2, dim3);
    for (int i1 = 0; i1 < dim1; i1++) {
      int offset1 = i1 * dim2;
      for (int i2 = 0; i2 < dim2; i2++) {
        int offset2 = (offset1 + i2) * dim3;
        mem.setLongsAtOffset((offset2 * 8), values[i1][i2], 0, dim3);
      } 
    } 
    return mem;
  }
  
  public static Pointer<Long> allocateLong() {
    return allocate(PointerIO.getLongInstance());
  }
  
  public static Pointer<Long> allocateLongs(long arrayLength) {
    return allocateArray(PointerIO.getLongInstance(), arrayLength);
  }
  
  public static Pointer<Pointer<Long>> allocateLongs(long dim1, long dim2) {
    return allocateArray(PointerIO.getArrayInstance(PointerIO.getLongInstance(), new long[] { dim1, dim2 }, 0), dim1);
  }
  
  public static Pointer<Pointer<Pointer<Long>>> allocateLongs(long dim1, long dim2, long dim3) {
    long[] dims = { dim1, dim2, dim3 };
    return allocateArray(PointerIO.getArrayInstance(PointerIO.getArrayInstance(PointerIO.getLongInstance(), dims, 1), dims, 0), dim1);
  }
  
  public static Pointer<Short> pointerToShort(short value) {
    Pointer<Short> mem = allocate(PointerIO.getShortInstance());
    mem.setShort(value);
    return mem;
  }
  
  public static Pointer<Short> pointerToShorts(short... values) {
    if (values == null)
      return null; 
    Pointer<Short> mem = allocateArray(PointerIO.getShortInstance(), values.length);
    mem.setShortsAtOffset(0L, values, 0, values.length);
    return mem;
  }
  
  public static Pointer<Pointer<Short>> pointerToShorts(short[][] values) {
    if (values == null)
      return null; 
    int dim1 = values.length, dim2 = (values[0]).length;
    Pointer<Pointer<Short>> mem = allocateShorts(dim1, dim2);
    for (int i1 = 0; i1 < dim1; i1++)
      mem.setShortsAtOffset((i1 * dim2 * 2), values[i1], 0, dim2); 
    return mem;
  }
  
  public static Pointer<Pointer<Pointer<Short>>> pointerToShorts(short[][][] values) {
    if (values == null)
      return null; 
    int dim1 = values.length, dim2 = (values[0]).length, dim3 = (values[0][0]).length;
    Pointer<Pointer<Pointer<Short>>> mem = allocateShorts(dim1, dim2, dim3);
    for (int i1 = 0; i1 < dim1; i1++) {
      int offset1 = i1 * dim2;
      for (int i2 = 0; i2 < dim2; i2++) {
        int offset2 = (offset1 + i2) * dim3;
        mem.setShortsAtOffset((offset2 * 2), values[i1][i2], 0, dim3);
      } 
    } 
    return mem;
  }
  
  public static Pointer<Short> allocateShort() {
    return allocate(PointerIO.getShortInstance());
  }
  
  public static Pointer<Short> allocateShorts(long arrayLength) {
    return allocateArray(PointerIO.getShortInstance(), arrayLength);
  }
  
  public static Pointer<Pointer<Short>> allocateShorts(long dim1, long dim2) {
    return allocateArray(PointerIO.getArrayInstance(PointerIO.getShortInstance(), new long[] { dim1, dim2 }, 0), dim1);
  }
  
  public static Pointer<Pointer<Pointer<Short>>> allocateShorts(long dim1, long dim2, long dim3) {
    long[] dims = { dim1, dim2, dim3 };
    return allocateArray(PointerIO.getArrayInstance(PointerIO.getArrayInstance(PointerIO.getShortInstance(), dims, 1), dims, 0), dim1);
  }
  
  public static Pointer<Byte> pointerToByte(byte value) {
    Pointer<Byte> mem = allocate(PointerIO.getByteInstance());
    mem.setByte(value);
    return mem;
  }
  
  public static Pointer<Byte> pointerToBytes(byte... values) {
    if (values == null)
      return null; 
    Pointer<Byte> mem = allocateArray(PointerIO.getByteInstance(), values.length);
    mem.setBytesAtOffset(0L, values, 0, values.length);
    return mem;
  }
  
  public static Pointer<Pointer<Byte>> pointerToBytes(byte[][] values) {
    if (values == null)
      return null; 
    int dim1 = values.length, dim2 = (values[0]).length;
    Pointer<Pointer<Byte>> mem = allocateBytes(dim1, dim2);
    for (int i1 = 0; i1 < dim1; i1++)
      mem.setBytesAtOffset((i1 * dim2 * 1), values[i1], 0, dim2); 
    return mem;
  }
  
  public static Pointer<Pointer<Pointer<Byte>>> pointerToBytes(byte[][][] values) {
    if (values == null)
      return null; 
    int dim1 = values.length, dim2 = (values[0]).length, dim3 = (values[0][0]).length;
    Pointer<Pointer<Pointer<Byte>>> mem = allocateBytes(dim1, dim2, dim3);
    for (int i1 = 0; i1 < dim1; i1++) {
      int offset1 = i1 * dim2;
      for (int i2 = 0; i2 < dim2; i2++) {
        int offset2 = (offset1 + i2) * dim3;
        mem.setBytesAtOffset((offset2 * 1), values[i1][i2], 0, dim3);
      } 
    } 
    return mem;
  }
  
  public static Pointer<Byte> allocateByte() {
    return allocate(PointerIO.getByteInstance());
  }
  
  public static Pointer<Byte> allocateBytes(long arrayLength) {
    return allocateArray(PointerIO.getByteInstance(), arrayLength);
  }
  
  public static Pointer<Pointer<Byte>> allocateBytes(long dim1, long dim2) {
    return allocateArray(PointerIO.getArrayInstance(PointerIO.getByteInstance(), new long[] { dim1, dim2 }, 0), dim1);
  }
  
  public static Pointer<Pointer<Pointer<Byte>>> allocateBytes(long dim1, long dim2, long dim3) {
    long[] dims = { dim1, dim2, dim3 };
    return allocateArray(PointerIO.getArrayInstance(PointerIO.getArrayInstance(PointerIO.getByteInstance(), dims, 1), dims, 0), dim1);
  }
  
  public static Pointer<Character> pointerToChar(char value) {
    Pointer<Character> mem = allocate(PointerIO.getCharInstance());
    mem.setChar(value);
    return mem;
  }
  
  public static Pointer<Character> pointerToChars(char... values) {
    if (values == null)
      return null; 
    Pointer<Character> mem = allocateArray(PointerIO.getCharInstance(), values.length);
    mem.setCharsAtOffset(0L, values, 0, values.length);
    return mem;
  }
  
  public static Pointer<Pointer<Character>> pointerToChars(char[][] values) {
    if (values == null)
      return null; 
    int dim1 = values.length, dim2 = (values[0]).length;
    Pointer<Pointer<Character>> mem = allocateChars(dim1, dim2);
    for (int i1 = 0; i1 < dim1; i1++)
      mem.setCharsAtOffset((i1 * dim2 * Platform.WCHAR_T_SIZE), values[i1], 0, dim2); 
    return mem;
  }
  
  public static Pointer<Pointer<Pointer<Character>>> pointerToChars(char[][][] values) {
    if (values == null)
      return null; 
    int dim1 = values.length, dim2 = (values[0]).length, dim3 = (values[0][0]).length;
    Pointer<Pointer<Pointer<Character>>> mem = allocateChars(dim1, dim2, dim3);
    for (int i1 = 0; i1 < dim1; i1++) {
      int offset1 = i1 * dim2;
      for (int i2 = 0; i2 < dim2; i2++) {
        int offset2 = (offset1 + i2) * dim3;
        mem.setCharsAtOffset((offset2 * Platform.WCHAR_T_SIZE), values[i1][i2], 0, dim3);
      } 
    } 
    return mem;
  }
  
  public static Pointer<Character> allocateChar() {
    return allocate(PointerIO.getCharInstance());
  }
  
  public static Pointer<Character> allocateChars(long arrayLength) {
    return allocateArray(PointerIO.getCharInstance(), arrayLength);
  }
  
  public static Pointer<Pointer<Character>> allocateChars(long dim1, long dim2) {
    return allocateArray(PointerIO.getArrayInstance(PointerIO.getCharInstance(), new long[] { dim1, dim2 }, 0), dim1);
  }
  
  public static Pointer<Pointer<Pointer<Character>>> allocateChars(long dim1, long dim2, long dim3) {
    long[] dims = { dim1, dim2, dim3 };
    return allocateArray(PointerIO.getArrayInstance(PointerIO.getArrayInstance(PointerIO.getCharInstance(), dims, 1), dims, 0), dim1);
  }
  
  public static Pointer<Float> pointerToFloat(float value) {
    Pointer<Float> mem = allocate(PointerIO.getFloatInstance());
    mem.setFloat(value);
    return mem;
  }
  
  public static Pointer<Float> pointerToFloats(float... values) {
    if (values == null)
      return null; 
    Pointer<Float> mem = allocateArray(PointerIO.getFloatInstance(), values.length);
    mem.setFloatsAtOffset(0L, values, 0, values.length);
    return mem;
  }
  
  public static Pointer<Pointer<Float>> pointerToFloats(float[][] values) {
    if (values == null)
      return null; 
    int dim1 = values.length, dim2 = (values[0]).length;
    Pointer<Pointer<Float>> mem = allocateFloats(dim1, dim2);
    for (int i1 = 0; i1 < dim1; i1++)
      mem.setFloatsAtOffset((i1 * dim2 * 4), values[i1], 0, dim2); 
    return mem;
  }
  
  public static Pointer<Pointer<Pointer<Float>>> pointerToFloats(float[][][] values) {
    if (values == null)
      return null; 
    int dim1 = values.length, dim2 = (values[0]).length, dim3 = (values[0][0]).length;
    Pointer<Pointer<Pointer<Float>>> mem = allocateFloats(dim1, dim2, dim3);
    for (int i1 = 0; i1 < dim1; i1++) {
      int offset1 = i1 * dim2;
      for (int i2 = 0; i2 < dim2; i2++) {
        int offset2 = (offset1 + i2) * dim3;
        mem.setFloatsAtOffset((offset2 * 4), values[i1][i2], 0, dim3);
      } 
    } 
    return mem;
  }
  
  public static Pointer<Float> allocateFloat() {
    return allocate(PointerIO.getFloatInstance());
  }
  
  public static Pointer<Float> allocateFloats(long arrayLength) {
    return allocateArray(PointerIO.getFloatInstance(), arrayLength);
  }
  
  public static Pointer<Pointer<Float>> allocateFloats(long dim1, long dim2) {
    return allocateArray(PointerIO.getArrayInstance(PointerIO.getFloatInstance(), new long[] { dim1, dim2 }, 0), dim1);
  }
  
  public static Pointer<Pointer<Pointer<Float>>> allocateFloats(long dim1, long dim2, long dim3) {
    long[] dims = { dim1, dim2, dim3 };
    return allocateArray(PointerIO.getArrayInstance(PointerIO.getArrayInstance(PointerIO.getFloatInstance(), dims, 1), dims, 0), dim1);
  }
  
  public static Pointer<Double> pointerToDouble(double value) {
    Pointer<Double> mem = allocate(PointerIO.getDoubleInstance());
    mem.setDouble(value);
    return mem;
  }
  
  public static Pointer<Double> pointerToDoubles(double... values) {
    if (values == null)
      return null; 
    Pointer<Double> mem = allocateArray(PointerIO.getDoubleInstance(), values.length);
    mem.setDoublesAtOffset(0L, values, 0, values.length);
    return mem;
  }
  
  public static Pointer<Pointer<Double>> pointerToDoubles(double[][] values) {
    if (values == null)
      return null; 
    int dim1 = values.length, dim2 = (values[0]).length;
    Pointer<Pointer<Double>> mem = allocateDoubles(dim1, dim2);
    for (int i1 = 0; i1 < dim1; i1++)
      mem.setDoublesAtOffset((i1 * dim2 * 8), values[i1], 0, dim2); 
    return mem;
  }
  
  public static Pointer<Pointer<Pointer<Double>>> pointerToDoubles(double[][][] values) {
    if (values == null)
      return null; 
    int dim1 = values.length, dim2 = (values[0]).length, dim3 = (values[0][0]).length;
    Pointer<Pointer<Pointer<Double>>> mem = allocateDoubles(dim1, dim2, dim3);
    for (int i1 = 0; i1 < dim1; i1++) {
      int offset1 = i1 * dim2;
      for (int i2 = 0; i2 < dim2; i2++) {
        int offset2 = (offset1 + i2) * dim3;
        mem.setDoublesAtOffset((offset2 * 8), values[i1][i2], 0, dim3);
      } 
    } 
    return mem;
  }
  
  public static Pointer<Double> allocateDouble() {
    return allocate(PointerIO.getDoubleInstance());
  }
  
  public static Pointer<Double> allocateDoubles(long arrayLength) {
    return allocateArray(PointerIO.getDoubleInstance(), arrayLength);
  }
  
  public static Pointer<Pointer<Double>> allocateDoubles(long dim1, long dim2) {
    return allocateArray(PointerIO.getArrayInstance(PointerIO.getDoubleInstance(), new long[] { dim1, dim2 }, 0), dim1);
  }
  
  public static Pointer<Pointer<Pointer<Double>>> allocateDoubles(long dim1, long dim2, long dim3) {
    long[] dims = { dim1, dim2, dim3 };
    return allocateArray(PointerIO.getArrayInstance(PointerIO.getArrayInstance(PointerIO.getDoubleInstance(), dims, 1), dims, 0), dim1);
  }
  
  public static Pointer<Boolean> pointerToBoolean(boolean value) {
    Pointer<Boolean> mem = allocate(PointerIO.getBooleanInstance());
    mem.setBoolean(value);
    return mem;
  }
  
  public static Pointer<Boolean> pointerToBooleans(boolean... values) {
    if (values == null)
      return null; 
    Pointer<Boolean> mem = allocateArray(PointerIO.getBooleanInstance(), values.length);
    mem.setBooleansAtOffset(0L, values, 0, values.length);
    return mem;
  }
  
  public static Pointer<Pointer<Boolean>> pointerToBooleans(boolean[][] values) {
    if (values == null)
      return null; 
    int dim1 = values.length, dim2 = (values[0]).length;
    Pointer<Pointer<Boolean>> mem = allocateBooleans(dim1, dim2);
    for (int i1 = 0; i1 < dim1; i1++)
      mem.setBooleansAtOffset((i1 * dim2 * 1), values[i1], 0, dim2); 
    return mem;
  }
  
  public static Pointer<Pointer<Pointer<Boolean>>> pointerToBooleans(boolean[][][] values) {
    if (values == null)
      return null; 
    int dim1 = values.length, dim2 = (values[0]).length, dim3 = (values[0][0]).length;
    Pointer<Pointer<Pointer<Boolean>>> mem = allocateBooleans(dim1, dim2, dim3);
    for (int i1 = 0; i1 < dim1; i1++) {
      int offset1 = i1 * dim2;
      for (int i2 = 0; i2 < dim2; i2++) {
        int offset2 = (offset1 + i2) * dim3;
        mem.setBooleansAtOffset((offset2 * 1), values[i1][i2], 0, dim3);
      } 
    } 
    return mem;
  }
  
  public static Pointer<Boolean> allocateBoolean() {
    return allocate(PointerIO.getBooleanInstance());
  }
  
  public static Pointer<Boolean> allocateBooleans(long arrayLength) {
    return allocateArray(PointerIO.getBooleanInstance(), arrayLength);
  }
  
  public static Pointer<Pointer<Boolean>> allocateBooleans(long dim1, long dim2) {
    return allocateArray(PointerIO.getArrayInstance(PointerIO.getBooleanInstance(), new long[] { dim1, dim2 }, 0), dim1);
  }
  
  public static Pointer<Pointer<Pointer<Boolean>>> allocateBooleans(long dim1, long dim2, long dim3) {
    long[] dims = { dim1, dim2, dim3 };
    return allocateArray(PointerIO.getArrayInstance(PointerIO.getArrayInstance(PointerIO.getBooleanInstance(), dims, 1), dims, 0), dim1);
  }
  
  public static Pointer<Integer> pointerToInts(IntBuffer buffer) {
    if (buffer == null)
      return null; 
    if (!buffer.isDirect()) {
      int[] array = buffer.array();
      int offset = buffer.arrayOffset();
      int length = array.length - offset;
      Pointer<Integer> ptr = allocateInts(length);
      ptr.setIntsAtOffset(0L, array, offset, length);
      return ptr;
    } 
    long address = JNI.getDirectBufferAddress(buffer);
    long size = JNI.getDirectBufferCapacity(buffer);
    size *= 4L;
    if (address == 0L || size == 0L)
      return null; 
    PointerIO<Integer> io = CommonPointerIOs.intIO;
    boolean ordered = buffer.order().equals(ByteOrder.nativeOrder());
    return newPointer(io, address, ordered, address, address + size, null, 0L, null, buffer);
  }
  
  public static Pointer<Long> pointerToLongs(LongBuffer buffer) {
    if (buffer == null)
      return null; 
    if (!buffer.isDirect()) {
      long[] array = buffer.array();
      int offset = buffer.arrayOffset();
      int length = array.length - offset;
      Pointer<Long> ptr = allocateLongs(length);
      ptr.setLongsAtOffset(0L, array, offset, length);
      return ptr;
    } 
    long address = JNI.getDirectBufferAddress(buffer);
    long size = JNI.getDirectBufferCapacity(buffer);
    size *= 8L;
    if (address == 0L || size == 0L)
      return null; 
    PointerIO<Long> io = CommonPointerIOs.longIO;
    boolean ordered = buffer.order().equals(ByteOrder.nativeOrder());
    return newPointer(io, address, ordered, address, address + size, null, 0L, null, buffer);
  }
  
  public static Pointer<Short> pointerToShorts(ShortBuffer buffer) {
    if (buffer == null)
      return null; 
    if (!buffer.isDirect()) {
      short[] array = buffer.array();
      int offset = buffer.arrayOffset();
      int length = array.length - offset;
      Pointer<Short> ptr = allocateShorts(length);
      ptr.setShortsAtOffset(0L, array, offset, length);
      return ptr;
    } 
    long address = JNI.getDirectBufferAddress(buffer);
    long size = JNI.getDirectBufferCapacity(buffer);
    size *= 2L;
    if (address == 0L || size == 0L)
      return null; 
    PointerIO<Short> io = CommonPointerIOs.shortIO;
    boolean ordered = buffer.order().equals(ByteOrder.nativeOrder());
    return newPointer(io, address, ordered, address, address + size, null, 0L, null, buffer);
  }
  
  public static Pointer<Byte> pointerToBytes(ByteBuffer buffer) {
    if (buffer == null)
      return null; 
    if (!buffer.isDirect()) {
      byte[] array = buffer.array();
      int offset = buffer.arrayOffset();
      int length = array.length - offset;
      Pointer<Byte> ptr = allocateBytes(length);
      ptr.setBytesAtOffset(0L, array, offset, length);
      return ptr;
    } 
    long address = JNI.getDirectBufferAddress(buffer);
    long size = JNI.getDirectBufferCapacity(buffer);
    size *= 1L;
    if (address == 0L || size == 0L)
      return null; 
    PointerIO<Byte> io = CommonPointerIOs.byteIO;
    boolean ordered = buffer.order().equals(ByteOrder.nativeOrder());
    return newPointer(io, address, ordered, address, address + size, null, 0L, null, buffer);
  }
  
  public static Pointer<Character> pointerToChars(CharBuffer buffer) {
    if (buffer == null)
      return null; 
    if (!buffer.isDirect()) {
      char[] array = buffer.array();
      int offset = buffer.arrayOffset();
      int length = array.length - offset;
      Pointer<Character> ptr = allocateChars(length);
      ptr.setCharsAtOffset(0L, array, offset, length);
      return ptr;
    } 
    long address = JNI.getDirectBufferAddress(buffer);
    long size = JNI.getDirectBufferCapacity(buffer);
    size *= Platform.WCHAR_T_SIZE;
    if (address == 0L || size == 0L)
      return null; 
    PointerIO<Character> io = CommonPointerIOs.charIO;
    boolean ordered = buffer.order().equals(ByteOrder.nativeOrder());
    return newPointer(io, address, ordered, address, address + size, null, 0L, null, buffer);
  }
  
  public static Pointer<Float> pointerToFloats(FloatBuffer buffer) {
    if (buffer == null)
      return null; 
    if (!buffer.isDirect()) {
      float[] array = buffer.array();
      int offset = buffer.arrayOffset();
      int length = array.length - offset;
      Pointer<Float> ptr = allocateFloats(length);
      ptr.setFloatsAtOffset(0L, array, offset, length);
      return ptr;
    } 
    long address = JNI.getDirectBufferAddress(buffer);
    long size = JNI.getDirectBufferCapacity(buffer);
    size *= 4L;
    if (address == 0L || size == 0L)
      return null; 
    PointerIO<Float> io = CommonPointerIOs.floatIO;
    boolean ordered = buffer.order().equals(ByteOrder.nativeOrder());
    return newPointer(io, address, ordered, address, address + size, null, 0L, null, buffer);
  }
  
  public static Pointer<Double> pointerToDoubles(DoubleBuffer buffer) {
    if (buffer == null)
      return null; 
    if (!buffer.isDirect()) {
      double[] array = buffer.array();
      int offset = buffer.arrayOffset();
      int length = array.length - offset;
      Pointer<Double> ptr = allocateDoubles(length);
      ptr.setDoublesAtOffset(0L, array, offset, length);
      return ptr;
    } 
    long address = JNI.getDirectBufferAddress(buffer);
    long size = JNI.getDirectBufferCapacity(buffer);
    size *= 8L;
    if (address == 0L || size == 0L)
      return null; 
    PointerIO<Double> io = CommonPointerIOs.doubleIO;
    boolean ordered = buffer.order().equals(ByteOrder.nativeOrder());
    return newPointer(io, address, ordered, address, address + size, null, 0L, null, buffer);
  }
  
  public Type getTargetType() {
    PointerIO<T> io = getIO();
    return (io == null) ? null : io.getTargetType();
  }
  
  @Deprecated
  public Pointer<?> getPointer() {
    return getPointerAtOffset(0L, (PointerIO)null);
  }
  
  public Pointer<?> getPointerAtOffset(long byteOffset) {
    return getPointerAtOffset(byteOffset, (PointerIO)null);
  }
  
  public Pointer<?> getPointerAtIndex(long valueIndex) {
    return getPointerAtOffset(valueIndex * SIZE);
  }
  
  public <U> Pointer<U> getPointer(Class<U> c) {
    return getPointerAtOffset(0L, PointerIO.getInstance(c));
  }
  
  public <U> Pointer<U> getPointer(PointerIO<U> pio) {
    return getPointerAtOffset(0L, pio);
  }
  
  public <U> Pointer<U> getPointerAtOffset(long byteOffset, Class<U> c) {
    return getPointerAtOffset(byteOffset, c);
  }
  
  public <U> Pointer<U> getPointerAtOffset(long byteOffset, Type t) {
    return getPointerAtOffset(byteOffset, (t == null) ? null : PointerIO.<U>getInstance(t));
  }
  
  public <U> Pointer<U> getPointerAtOffset(long byteOffset, PointerIO<U> pio) {
    long value = getSizeTAtOffset(byteOffset);
    if (value == 0L)
      return null; 
    return newPointer(pio, value, isOrdered(), -1L, -1L, this, byteOffset, null, null);
  }
  
  public Pointer<T> setPointer(Pointer<?> value) {
    return setPointerAtOffset(0L, value);
  }
  
  public Pointer<T> setPointerAtOffset(long byteOffset, Pointer<?> value) {
    setSizeTAtOffset(byteOffset, (value == null) ? 0L : value.getPeer());
    return this;
  }
  
  public Pointer<T> setPointerAtIndex(long valueIndex, Pointer<?> value) {
    setPointerAtOffset(valueIndex * SIZE, value);
    return this;
  }
  
  public Pointer<?>[] getPointersAtOffset(long byteOffset, int arrayLength) {
    return getPointersAtOffset(byteOffset, arrayLength, (PointerIO)null);
  }
  
  @Deprecated
  public Pointer<?>[] getPointers() {
    long rem = getValidElements("Cannot create array if remaining length is not known. Please use getPointers(int length) instead.");
    return getPointersAtOffset(0L, (int)rem);
  }
  
  @Deprecated
  public Pointer<?>[] getPointers(int arrayLength) {
    return getPointersAtOffset(0L, arrayLength);
  }
  
  public <U> Pointer<U>[] getPointersAtOffset(long byteOffset, int arrayLength, Type t) {
    return getPointersAtOffset(byteOffset, arrayLength, (t == null) ? null : PointerIO.getInstance(t));
  }
  
  public <U> Pointer<U>[] getPointersAtOffset(long byteOffset, int arrayLength, Class<U> t) {
    return getPointersAtOffset(byteOffset, arrayLength, t);
  }
  
  public <U> Pointer<U>[] getPointersAtOffset(long byteOffset, int arrayLength, PointerIO<?> pio) {
    Pointer[] arrayOfPointer = new Pointer[arrayLength];
    int s = Platform.POINTER_SIZE;
    for (int i = 0; i < arrayLength; i++)
      arrayOfPointer[i] = getPointerAtOffset(byteOffset + (i * s), pio); 
    return (Pointer<U>[])arrayOfPointer;
  }
  
  public Pointer<T> setPointersAtOffset(long byteOffset, Pointer<?>[] values) {
    return setPointersAtOffset(byteOffset, values, 0, values.length);
  }
  
  public Pointer<T> setPointersAtOffset(long byteOffset, Pointer<?>[] values, int valuesOffset, int length) {
    if (values == null)
      throw new IllegalArgumentException("Null values"); 
    int n = length, s = Platform.POINTER_SIZE;
    for (int i = 0; i < n; i++)
      setPointerAtOffset(byteOffset + (i * s), values[valuesOffset + i]); 
    return this;
  }
  
  public Pointer<T> setPointers(Pointer<?>[] values) {
    return setPointersAtOffset(0L, values);
  }
  
  public Object getArrayAtOffset(long byteOffset, int length) {
    return getIO("Cannot create sublist").getArray(this, byteOffset, length);
  }
  
  public Object getArray(int length) {
    return getArrayAtOffset(0L, length);
  }
  
  public Object getArray() {
    return getArray((int)getValidElements());
  }
  
  public <B extends Buffer> B getBufferAtOffset(long byteOffset, int length) {
    return getIO("Cannot create Buffer").getBuffer(this, byteOffset, length);
  }
  
  public <B extends Buffer> B getBuffer(int length) {
    return getBufferAtOffset(0L, length);
  }
  
  public <B extends Buffer> B getBuffer() {
    return getBuffer((int)getValidElements());
  }
  
  public Pointer<T> setArrayAtOffset(long byteOffset, Object array) {
    getIO("Cannot create sublist").setArray(this, byteOffset, array);
    return this;
  }
  
  public static <T> Pointer<T> pointerToArray(Object array) {
    if (array == null)
      return null; 
    PointerIO<T> io = PointerIO.getArrayIO(array);
    if (io == null)
      throwBecauseUntyped("Cannot create pointer to array"); 
    Pointer<T> ptr = allocateArray(io, Array.getLength(array));
    io.setArray(ptr, 0L, array);
    return ptr;
  }
  
  public Pointer<T> setArray(Object array) {
    return setArrayAtOffset(0L, array);
  }
  
  public static Pointer<SizeT> pointerToSizeT(long value) {
    Pointer<SizeT> p = allocate(PointerIO.getSizeTInstance());
    p.setSizeT(value);
    return p;
  }
  
  public static Pointer<SizeT> pointerToSizeT(SizeT value) {
    Pointer<SizeT> p = allocate(PointerIO.getSizeTInstance());
    p.setSizeT(value);
    return p;
  }
  
  public static Pointer<SizeT> pointerToSizeTs(long... values) {
    if (values == null)
      return null; 
    return allocateArray(PointerIO.getSizeTInstance(), values.length).setSizeTsAtOffset(0L, values);
  }
  
  public static Pointer<SizeT> pointerToSizeTs(SizeT... values) {
    if (values == null)
      return null; 
    return allocateArray(PointerIO.getSizeTInstance(), values.length).setSizeTsAtOffset(0L, values);
  }
  
  public static Pointer<SizeT> pointerToSizeTs(int[] values) {
    if (values == null)
      return null; 
    return allocateArray(PointerIO.getSizeTInstance(), values.length).setSizeTsAtOffset(0L, values);
  }
  
  public static Pointer<SizeT> allocateSizeTs(long arrayLength) {
    return allocateArray(PointerIO.getSizeTInstance(), arrayLength);
  }
  
  public static Pointer<SizeT> allocateSizeT() {
    return allocate(PointerIO.getSizeTInstance());
  }
  
  public long getSizeT() {
    return (SizeT.SIZE == 8) ? getLong() : getInt();
  }
  
  public long getSizeTAtOffset(long byteOffset) {
    return (SizeT.SIZE == 8) ? getLongAtOffset(byteOffset) : getIntAtOffset(byteOffset);
  }
  
  public long getSizeTAtIndex(long valueIndex) {
    return getSizeTAtOffset(valueIndex * SizeT.SIZE);
  }
  
  public long[] getSizeTs() {
    long rem = getValidElements("Cannot create array if remaining length is not known. Please use getSizeTs(int length) instead.");
    if (SizeT.SIZE == 8)
      return getLongs((int)rem); 
    return getSizeTs((int)rem);
  }
  
  public long[] getSizeTs(int arrayLength) {
    if (SizeT.SIZE == 8)
      return getLongs(arrayLength); 
    return getSizeTsAtOffset(0L, arrayLength);
  }
  
  public long[] getSizeTsAtOffset(long byteOffset, int arrayLength) {
    if (SizeT.SIZE == 8)
      return getLongsAtOffset(byteOffset, arrayLength); 
    int[] values = getIntsAtOffset(byteOffset, arrayLength);
    long[] ret = new long[arrayLength];
    for (int i = 0; i < arrayLength; i++)
      ret[i] = values[i]; 
    return ret;
  }
  
  public Pointer<T> setSizeT(long value) {
    if (SizeT.SIZE == 8) {
      setLong(value);
    } else {
      setInt(SizeT.safeIntCast(value));
    } 
    return this;
  }
  
  public Pointer<T> setSizeT(SizeT value) {
    return setSizeT(value.longValue());
  }
  
  public Pointer<T> setSizeTAtOffset(long byteOffset, long value) {
    if (SizeT.SIZE == 8) {
      setLongAtOffset(byteOffset, value);
    } else {
      setIntAtOffset(byteOffset, SizeT.safeIntCast(value));
    } 
    return this;
  }
  
  public Pointer<T> setSizeTAtIndex(long valueIndex, long value) {
    return setSizeTAtOffset(valueIndex * SizeT.SIZE, value);
  }
  
  public Pointer<T> setSizeTAtOffset(long byteOffset, SizeT value) {
    return setSizeTAtOffset(byteOffset, value.longValue());
  }
  
  public Pointer<T> setSizeTs(long[] values) {
    if (SizeT.SIZE == 8)
      return setLongs(values); 
    return setSizeTsAtOffset(0L, values);
  }
  
  public Pointer<T> setSizeTs(int[] values) {
    if (SizeT.SIZE == 4)
      return setInts(values); 
    return setSizeTsAtOffset(0L, values);
  }
  
  public Pointer<T> setSizeTs(SizeT[] values) {
    return setSizeTsAtOffset(0L, values);
  }
  
  public Pointer<T> setSizeTsAtOffset(long byteOffset, long[] values) {
    return setSizeTsAtOffset(byteOffset, values, 0, values.length);
  }
  
  public Pointer<T> setSizeTsAtOffset(long byteOffset, SizeT... values) {
    if (values == null)
      throw new IllegalArgumentException("Null values"); 
    int n = values.length, s = SizeT.SIZE;
    for (int i = 0; i < n; i++)
      setSizeTAtOffset(byteOffset + (i * s), values[i].longValue()); 
    return this;
  }
  
  public static Pointer<CLong> pointerToCLong(long value) {
    Pointer<CLong> p = allocate(PointerIO.getCLongInstance());
    p.setCLong(value);
    return p;
  }
  
  public static Pointer<CLong> pointerToCLong(CLong value) {
    Pointer<CLong> p = allocate(PointerIO.getCLongInstance());
    p.setCLong(value);
    return p;
  }
  
  public static Pointer<CLong> pointerToCLongs(long... values) {
    if (values == null)
      return null; 
    return allocateArray(PointerIO.getCLongInstance(), values.length).setCLongsAtOffset(0L, values);
  }
  
  public static Pointer<CLong> pointerToCLongs(CLong... values) {
    if (values == null)
      return null; 
    return allocateArray(PointerIO.getCLongInstance(), values.length).setCLongsAtOffset(0L, values);
  }
  
  public static Pointer<CLong> pointerToCLongs(int[] values) {
    if (values == null)
      return null; 
    return allocateArray(PointerIO.getCLongInstance(), values.length).setCLongsAtOffset(0L, values);
  }
  
  public static Pointer<CLong> allocateCLongs(long arrayLength) {
    return allocateArray(PointerIO.getCLongInstance(), arrayLength);
  }
  
  public static Pointer<CLong> allocateCLong() {
    return allocate(PointerIO.getCLongInstance());
  }
  
  public long getCLong() {
    return (CLong.SIZE == 8) ? getLong() : getInt();
  }
  
  public long getCLongAtOffset(long byteOffset) {
    return (CLong.SIZE == 8) ? getLongAtOffset(byteOffset) : getIntAtOffset(byteOffset);
  }
  
  public long getCLongAtIndex(long valueIndex) {
    return getCLongAtOffset(valueIndex * CLong.SIZE);
  }
  
  public long[] getCLongs() {
    long rem = getValidElements("Cannot create array if remaining length is not known. Please use getCLongs(int length) instead.");
    if (CLong.SIZE == 8)
      return getLongs((int)rem); 
    return getCLongs((int)rem);
  }
  
  public long[] getCLongs(int arrayLength) {
    if (CLong.SIZE == 8)
      return getLongs(arrayLength); 
    return getCLongsAtOffset(0L, arrayLength);
  }
  
  public long[] getCLongsAtOffset(long byteOffset, int arrayLength) {
    if (CLong.SIZE == 8)
      return getLongsAtOffset(byteOffset, arrayLength); 
    int[] values = getIntsAtOffset(byteOffset, arrayLength);
    long[] ret = new long[arrayLength];
    for (int i = 0; i < arrayLength; i++)
      ret[i] = values[i]; 
    return ret;
  }
  
  public Pointer<T> setCLong(long value) {
    if (CLong.SIZE == 8) {
      setLong(value);
    } else {
      setInt(SizeT.safeIntCast(value));
    } 
    return this;
  }
  
  public Pointer<T> setCLong(CLong value) {
    return setCLong(value.longValue());
  }
  
  public Pointer<T> setCLongAtOffset(long byteOffset, long value) {
    if (CLong.SIZE == 8) {
      setLongAtOffset(byteOffset, value);
    } else {
      setIntAtOffset(byteOffset, SizeT.safeIntCast(value));
    } 
    return this;
  }
  
  public Pointer<T> setCLongAtIndex(long valueIndex, long value) {
    return setCLongAtOffset(valueIndex * CLong.SIZE, value);
  }
  
  public Pointer<T> setCLongAtOffset(long byteOffset, CLong value) {
    return setCLongAtOffset(byteOffset, value.longValue());
  }
  
  public Pointer<T> setCLongs(long[] values) {
    if (CLong.SIZE == 8)
      return setLongs(values); 
    return setCLongsAtOffset(0L, values);
  }
  
  public Pointer<T> setCLongs(int[] values) {
    if (CLong.SIZE == 4)
      return setInts(values); 
    return setCLongsAtOffset(0L, values);
  }
  
  public Pointer<T> setCLongs(CLong[] values) {
    return setCLongsAtOffset(0L, values);
  }
  
  public Pointer<T> setCLongsAtOffset(long byteOffset, long[] values) {
    return setCLongsAtOffset(byteOffset, values, 0, values.length);
  }
  
  public Pointer<T> setCLongsAtOffset(long byteOffset, CLong... values) {
    if (values == null)
      throw new IllegalArgumentException("Null values"); 
    int n = values.length, s = CLong.SIZE;
    for (int i = 0; i < n; i++)
      setCLongAtOffset(byteOffset + (i * s), values[i].longValue()); 
    return this;
  }
  
  void setSignedIntegralAtOffset(long byteOffset, long value, long sizeOfIntegral) {
    switch ((int)sizeOfIntegral) {
      case 1:
        if (value > 127L || value < -128L)
          throw new RuntimeException("Value out of byte bounds : " + value); 
        setByteAtOffset(byteOffset, (byte)(int)value);
        return;
      case 2:
        if (value > 32767L || value < -32768L)
          throw new RuntimeException("Value out of short bounds : " + value); 
        setShortAtOffset(byteOffset, (short)(int)value);
        return;
      case 4:
        if (value > 2147483647L || value < -2147483648L)
          throw new RuntimeException("Value out of int bounds : " + value); 
        setIntAtOffset(byteOffset, (int)value);
        return;
      case 8:
        setLongAtOffset(byteOffset, value);
        return;
    } 
    throw new IllegalArgumentException("Cannot write integral type of size " + sizeOfIntegral + " (value = " + value + ")");
  }
  
  long getSignedIntegralAtOffset(long byteOffset, long sizeOfIntegral) {
    switch ((int)sizeOfIntegral) {
      case 1:
        return getByteAtOffset(byteOffset);
      case 2:
        return getShortAtOffset(byteOffset);
      case 4:
        return getIntAtOffset(byteOffset);
      case 8:
        return getLongAtOffset(byteOffset);
    } 
    throw new IllegalArgumentException("Cannot read integral type of size " + sizeOfIntegral);
  }
  
  public static <T> Pointer<Pointer<T>> pointerToPointer(Pointer<T> value) {
    Pointer<Pointer<T>> p = allocate((PointerIO)PointerIO.getPointerInstance());
    p.setPointerAtOffset(0L, value);
    return p;
  }
  
  public static <T> Pointer<Pointer<T>> pointerToPointers(Pointer<T>... values) {
    if (values == null)
      return null; 
    int n = values.length, s = SIZE;
    PointerIO<Pointer> pio = PointerIO.getPointerInstance();
    Pointer<Pointer<T>> p = allocateArray((PointerIO)pio, n);
    for (int i = 0; i < n; i++)
      p.setPointerAtOffset((i * s), values[i]); 
    return p;
  }
  
  public Pointer<T> setValuesAtOffset(long byteOffset, Buffer values) {
    if (values instanceof IntBuffer) {
      setIntsAtOffset(byteOffset, (IntBuffer)values);
      return this;
    } 
    if (values instanceof LongBuffer) {
      setLongsAtOffset(byteOffset, (LongBuffer)values);
      return this;
    } 
    if (values instanceof ShortBuffer) {
      setShortsAtOffset(byteOffset, (ShortBuffer)values);
      return this;
    } 
    if (values instanceof ByteBuffer) {
      setBytesAtOffset(byteOffset, (ByteBuffer)values);
      return this;
    } 
    if (values instanceof CharBuffer) {
      setCharsAtOffset(byteOffset, (CharBuffer)values);
      return this;
    } 
    if (values instanceof FloatBuffer) {
      setFloatsAtOffset(byteOffset, (FloatBuffer)values);
      return this;
    } 
    if (values instanceof DoubleBuffer) {
      setDoublesAtOffset(byteOffset, (DoubleBuffer)values);
      return this;
    } 
    throw new UnsupportedOperationException("Unhandled buffer type : " + values.getClass().getName());
  }
  
  public Pointer<T> setValuesAtOffset(long byteOffset, Buffer values, int valuesOffset, int length) {
    if (values instanceof IntBuffer) {
      setIntsAtOffset(byteOffset, (IntBuffer)values, valuesOffset, length);
      return this;
    } 
    if (values instanceof LongBuffer) {
      setLongsAtOffset(byteOffset, (LongBuffer)values, valuesOffset, length);
      return this;
    } 
    if (values instanceof ShortBuffer) {
      setShortsAtOffset(byteOffset, (ShortBuffer)values, valuesOffset, length);
      return this;
    } 
    if (values instanceof ByteBuffer) {
      setBytesAtOffset(byteOffset, (ByteBuffer)values, valuesOffset, length);
      return this;
    } 
    if (values instanceof CharBuffer) {
      setCharsAtOffset(byteOffset, (CharBuffer)values, valuesOffset, length);
      return this;
    } 
    if (values instanceof FloatBuffer) {
      setFloatsAtOffset(byteOffset, (FloatBuffer)values, valuesOffset, length);
      return this;
    } 
    if (values instanceof DoubleBuffer) {
      setDoublesAtOffset(byteOffset, (DoubleBuffer)values, valuesOffset, length);
      return this;
    } 
    throw new UnsupportedOperationException("Unhandled buffer type : " + values.getClass().getName());
  }
  
  public Pointer<T> setValues(Buffer values) {
    if (values instanceof IntBuffer) {
      setInts((IntBuffer)values);
      return this;
    } 
    if (values instanceof LongBuffer) {
      setLongs((LongBuffer)values);
      return this;
    } 
    if (values instanceof ShortBuffer) {
      setShorts((ShortBuffer)values);
      return this;
    } 
    if (values instanceof ByteBuffer) {
      setBytes((ByteBuffer)values);
      return this;
    } 
    if (values instanceof CharBuffer) {
      setChars((CharBuffer)values);
      return this;
    } 
    if (values instanceof FloatBuffer) {
      setFloats((FloatBuffer)values);
      return this;
    } 
    if (values instanceof DoubleBuffer) {
      setDoubles((DoubleBuffer)values);
      return this;
    } 
    throw new UnsupportedOperationException("Unhandled buffer type : " + values.getClass().getName());
  }
  
  @Deprecated
  public Pointer<T> copyBytesAtOffsetTo(long byteOffset, Pointer<?> destination, long byteOffsetInDestination, long byteCount) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + byteCount > this.validEnd))
      invalidPeer(checkedPeer, byteCount); 
    JNI.memcpy(destination.getCheckedPeer(byteOffsetInDestination, byteCount), checkedPeer, byteCount);
    return this;
  }
  
  @Deprecated
  public Pointer<T> copyBytesTo(Pointer<?> destination, long byteCount) {
    return copyBytesAtOffsetTo(0L, destination, 0L, byteCount);
  }
  
  @Deprecated
  public Pointer<T> moveBytesAtOffsetTo(long byteOffset, Pointer<?> destination, long byteOffsetInDestination, long byteCount) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + byteCount > this.validEnd))
      invalidPeer(checkedPeer, byteCount); 
    JNI.memmove(destination.getCheckedPeer(byteOffsetInDestination, byteCount), checkedPeer, byteCount);
    return this;
  }
  
  public Pointer<T> moveBytesTo(Pointer<?> destination, long byteCount) {
    return moveBytesAtOffsetTo(0L, destination, 0L, byteCount);
  }
  
  public Pointer<T> moveBytesTo(Pointer<?> destination) {
    return moveBytesTo(destination, getValidBytes("Cannot move an unbounded memory location. Please use validBytes(long)."));
  }
  
  final long getValidBytes(String error) {
    long rem = getValidBytes();
    if (rem < 0L)
      throw new IndexOutOfBoundsException(error); 
    return rem;
  }
  
  final long getValidElements(String error) {
    long rem = getValidElements();
    if (rem < 0L)
      throw new IndexOutOfBoundsException(error); 
    return rem;
  }
  
  final PointerIO<T> getIO(String error) {
    PointerIO<T> io = getIO();
    if (io == null)
      throwBecauseUntyped(error); 
    return io;
  }
  
  public Pointer<T> copyTo(Pointer<?> destination) {
    return copyTo(destination, getValidElements());
  }
  
  public Pointer<T> copyTo(Pointer<?> destination, long elementCount) {
    PointerIO<T> io = getIO("Cannot copy untyped pointer without byte count information. Please use copyBytesAtOffsetTo(offset, destination, destinationOffset, byteCount) instead");
    return copyBytesAtOffsetTo(0L, destination, 0L, elementCount * io.getTargetSize());
  }
  
  public Pointer<T> find(Pointer<?> needle) {
    if (needle == null)
      return null; 
    long firstOccurrence = JNI.memmem(getPeer(), getValidBytes("Cannot search an unbounded memory area. Please set bounds with validBytes(long)."), needle.getPeer(), needle.getValidBytes("Cannot search for an unbounded content. Please set bounds with validBytes(long)."));
    return pointerToAddress(firstOccurrence, this.io);
  }
  
  public Pointer<T> findLast(Pointer<?> needle) {
    if (needle == null)
      return null; 
    long lastOccurrence = JNI.memmem_last(getPeer(), getValidBytes("Cannot search an unbounded memory area. Please set bounds with validBytes(long)."), needle.getPeer(), needle.getValidBytes("Cannot search for an unbounded content. Please set bounds with validBytes(long)."));
    return pointerToAddress(lastOccurrence, this.io);
  }
  
  public Pointer<T> setIntAtIndex(long valueIndex, int value) {
    return setIntAtOffset(valueIndex * 4L, value);
  }
  
  public Pointer<T> setInts(int[] values) {
    return setIntsAtOffset(0L, values, 0, values.length);
  }
  
  public Pointer<T> setIntsAtOffset(long byteOffset, int[] values) {
    return setIntsAtOffset(byteOffset, values, 0, values.length);
  }
  
  public Pointer<T> setIntsAtOffset(long byteOffset, int[] values, int valuesOffset, int length) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (4 * length) > this.validEnd))
      invalidPeer(checkedPeer, (4 * length)); 
    if (!isOrdered()) {
      JNI.set_int_array_disordered(checkedPeer, values, valuesOffset, length);
      return this;
    } 
    JNI.set_int_array(checkedPeer, values, valuesOffset, length);
    return this;
  }
  
  public int getIntAtIndex(long valueIndex) {
    return getIntAtOffset(valueIndex * 4L);
  }
  
  public int[] getInts(int length) {
    return getIntsAtOffset(0L, length);
  }
  
  public int[] getInts() {
    long validBytes = getValidBytes("Cannot create array if remaining length is not known. Please use getInts(int length) instead.");
    return getInts((int)(validBytes / 4L));
  }
  
  public int[] getIntsAtOffset(long byteOffset, int length) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (4 * length) > this.validEnd))
      invalidPeer(checkedPeer, (4 * length)); 
    if (!isOrdered())
      return JNI.get_int_array_disordered(checkedPeer, length); 
    return JNI.get_int_array(checkedPeer, length);
  }
  
  public Pointer<T> setLongAtIndex(long valueIndex, long value) {
    return setLongAtOffset(valueIndex * 8L, value);
  }
  
  public Pointer<T> setLongs(long[] values) {
    return setLongsAtOffset(0L, values, 0, values.length);
  }
  
  public Pointer<T> setLongsAtOffset(long byteOffset, long[] values) {
    return setLongsAtOffset(byteOffset, values, 0, values.length);
  }
  
  public Pointer<T> setLongsAtOffset(long byteOffset, long[] values, int valuesOffset, int length) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (8 * length) > this.validEnd))
      invalidPeer(checkedPeer, (8 * length)); 
    if (!isOrdered()) {
      JNI.set_long_array_disordered(checkedPeer, values, valuesOffset, length);
      return this;
    } 
    JNI.set_long_array(checkedPeer, values, valuesOffset, length);
    return this;
  }
  
  public long getLongAtIndex(long valueIndex) {
    return getLongAtOffset(valueIndex * 8L);
  }
  
  public long[] getLongs(int length) {
    return getLongsAtOffset(0L, length);
  }
  
  public long[] getLongs() {
    long validBytes = getValidBytes("Cannot create array if remaining length is not known. Please use getLongs(int length) instead.");
    return getLongs((int)(validBytes / 8L));
  }
  
  public long[] getLongsAtOffset(long byteOffset, int length) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (8 * length) > this.validEnd))
      invalidPeer(checkedPeer, (8 * length)); 
    if (!isOrdered())
      return JNI.get_long_array_disordered(checkedPeer, length); 
    return JNI.get_long_array(checkedPeer, length);
  }
  
  public Pointer<T> setShortAtIndex(long valueIndex, short value) {
    return setShortAtOffset(valueIndex * 2L, value);
  }
  
  public Pointer<T> setShorts(short[] values) {
    return setShortsAtOffset(0L, values, 0, values.length);
  }
  
  public Pointer<T> setShortsAtOffset(long byteOffset, short[] values) {
    return setShortsAtOffset(byteOffset, values, 0, values.length);
  }
  
  public Pointer<T> setShortsAtOffset(long byteOffset, short[] values, int valuesOffset, int length) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (2 * length) > this.validEnd))
      invalidPeer(checkedPeer, (2 * length)); 
    if (!isOrdered()) {
      JNI.set_short_array_disordered(checkedPeer, values, valuesOffset, length);
      return this;
    } 
    JNI.set_short_array(checkedPeer, values, valuesOffset, length);
    return this;
  }
  
  public short getShortAtIndex(long valueIndex) {
    return getShortAtOffset(valueIndex * 2L);
  }
  
  public short[] getShorts(int length) {
    return getShortsAtOffset(0L, length);
  }
  
  public short[] getShorts() {
    long validBytes = getValidBytes("Cannot create array if remaining length is not known. Please use getShorts(int length) instead.");
    return getShorts((int)(validBytes / 2L));
  }
  
  public short[] getShortsAtOffset(long byteOffset, int length) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (2 * length) > this.validEnd))
      invalidPeer(checkedPeer, (2 * length)); 
    if (!isOrdered())
      return JNI.get_short_array_disordered(checkedPeer, length); 
    return JNI.get_short_array(checkedPeer, length);
  }
  
  public Pointer<T> setByteAtIndex(long valueIndex, byte value) {
    return setByteAtOffset(valueIndex * 1L, value);
  }
  
  public Pointer<T> setBytes(byte[] values) {
    return setBytesAtOffset(0L, values, 0, values.length);
  }
  
  public Pointer<T> setBytesAtOffset(long byteOffset, byte[] values) {
    return setBytesAtOffset(byteOffset, values, 0, values.length);
  }
  
  public Pointer<T> setBytesAtOffset(long byteOffset, byte[] values, int valuesOffset, int length) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (1 * length) > this.validEnd))
      invalidPeer(checkedPeer, (1 * length)); 
    JNI.set_byte_array(checkedPeer, values, valuesOffset, length);
    return this;
  }
  
  public byte getByteAtIndex(long valueIndex) {
    return getByteAtOffset(valueIndex * 1L);
  }
  
  public byte[] getBytes(int length) {
    return getBytesAtOffset(0L, length);
  }
  
  public byte[] getBytes() {
    long validBytes = getValidBytes("Cannot create array if remaining length is not known. Please use getBytes(int length) instead.");
    return getBytes((int)(validBytes / 1L));
  }
  
  public byte[] getBytesAtOffset(long byteOffset, int length) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (1 * length) > this.validEnd))
      invalidPeer(checkedPeer, (1 * length)); 
    return JNI.get_byte_array(checkedPeer, length);
  }
  
  public Pointer<T> setCharAtIndex(long valueIndex, char value) {
    return setCharAtOffset(valueIndex * Platform.WCHAR_T_SIZE, value);
  }
  
  public Pointer<T> setChars(char[] values) {
    return setCharsAtOffset(0L, values, 0, values.length);
  }
  
  public Pointer<T> setCharsAtOffset(long byteOffset, char[] values) {
    return setCharsAtOffset(byteOffset, values, 0, values.length);
  }
  
  public Pointer<T> setCharsAtOffset(long byteOffset, char[] values, int valuesOffset, int length) {
    if (Platform.WCHAR_T_SIZE == 4)
      return setIntsAtOffset(byteOffset, wcharsToInts(values, valuesOffset, length)); 
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (Platform.WCHAR_T_SIZE * length) > this.validEnd))
      invalidPeer(checkedPeer, (Platform.WCHAR_T_SIZE * length)); 
    if (!isOrdered()) {
      JNI.set_char_array_disordered(checkedPeer, values, valuesOffset, length);
      return this;
    } 
    JNI.set_char_array(checkedPeer, values, valuesOffset, length);
    return this;
  }
  
  public char getCharAtIndex(long valueIndex) {
    return getCharAtOffset(valueIndex * Platform.WCHAR_T_SIZE);
  }
  
  public char[] getChars(int length) {
    return getCharsAtOffset(0L, length);
  }
  
  public char[] getChars() {
    long validBytes = getValidBytes("Cannot create array if remaining length is not known. Please use getChars(int length) instead.");
    return getChars((int)(validBytes / Platform.WCHAR_T_SIZE));
  }
  
  public char[] getCharsAtOffset(long byteOffset, int length) {
    if (Platform.WCHAR_T_SIZE == 4)
      return intsToWChars(getIntsAtOffset(byteOffset, length)); 
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (Platform.WCHAR_T_SIZE * length) > this.validEnd))
      invalidPeer(checkedPeer, (Platform.WCHAR_T_SIZE * length)); 
    if (!isOrdered())
      return JNI.get_char_array_disordered(checkedPeer, length); 
    return JNI.get_char_array(checkedPeer, length);
  }
  
  public Pointer<T> setFloatAtIndex(long valueIndex, float value) {
    return setFloatAtOffset(valueIndex * 4L, value);
  }
  
  public Pointer<T> setFloats(float[] values) {
    return setFloatsAtOffset(0L, values, 0, values.length);
  }
  
  public Pointer<T> setFloatsAtOffset(long byteOffset, float[] values) {
    return setFloatsAtOffset(byteOffset, values, 0, values.length);
  }
  
  public Pointer<T> setFloatsAtOffset(long byteOffset, float[] values, int valuesOffset, int length) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (4 * length) > this.validEnd))
      invalidPeer(checkedPeer, (4 * length)); 
    if (!isOrdered()) {
      JNI.set_float_array_disordered(checkedPeer, values, valuesOffset, length);
      return this;
    } 
    JNI.set_float_array(checkedPeer, values, valuesOffset, length);
    return this;
  }
  
  public float getFloatAtIndex(long valueIndex) {
    return getFloatAtOffset(valueIndex * 4L);
  }
  
  public float[] getFloats(int length) {
    return getFloatsAtOffset(0L, length);
  }
  
  public float[] getFloats() {
    long validBytes = getValidBytes("Cannot create array if remaining length is not known. Please use getFloats(int length) instead.");
    return getFloats((int)(validBytes / 4L));
  }
  
  public float[] getFloatsAtOffset(long byteOffset, int length) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (4 * length) > this.validEnd))
      invalidPeer(checkedPeer, (4 * length)); 
    if (!isOrdered())
      return JNI.get_float_array_disordered(checkedPeer, length); 
    return JNI.get_float_array(checkedPeer, length);
  }
  
  public Pointer<T> setDoubleAtIndex(long valueIndex, double value) {
    return setDoubleAtOffset(valueIndex * 8L, value);
  }
  
  public Pointer<T> setDoubles(double[] values) {
    return setDoublesAtOffset(0L, values, 0, values.length);
  }
  
  public Pointer<T> setDoublesAtOffset(long byteOffset, double[] values) {
    return setDoublesAtOffset(byteOffset, values, 0, values.length);
  }
  
  public Pointer<T> setDoublesAtOffset(long byteOffset, double[] values, int valuesOffset, int length) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (8 * length) > this.validEnd))
      invalidPeer(checkedPeer, (8 * length)); 
    if (!isOrdered()) {
      JNI.set_double_array_disordered(checkedPeer, values, valuesOffset, length);
      return this;
    } 
    JNI.set_double_array(checkedPeer, values, valuesOffset, length);
    return this;
  }
  
  public double getDoubleAtIndex(long valueIndex) {
    return getDoubleAtOffset(valueIndex * 8L);
  }
  
  public double[] getDoubles(int length) {
    return getDoublesAtOffset(0L, length);
  }
  
  public double[] getDoubles() {
    long validBytes = getValidBytes("Cannot create array if remaining length is not known. Please use getDoubles(int length) instead.");
    return getDoubles((int)(validBytes / 8L));
  }
  
  public double[] getDoublesAtOffset(long byteOffset, int length) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (8 * length) > this.validEnd))
      invalidPeer(checkedPeer, (8 * length)); 
    if (!isOrdered())
      return JNI.get_double_array_disordered(checkedPeer, length); 
    return JNI.get_double_array(checkedPeer, length);
  }
  
  public Pointer<T> setBooleanAtIndex(long valueIndex, boolean value) {
    return setBooleanAtOffset(valueIndex * 1L, value);
  }
  
  public Pointer<T> setBooleans(boolean[] values) {
    return setBooleansAtOffset(0L, values, 0, values.length);
  }
  
  public Pointer<T> setBooleansAtOffset(long byteOffset, boolean[] values) {
    return setBooleansAtOffset(byteOffset, values, 0, values.length);
  }
  
  public Pointer<T> setBooleansAtOffset(long byteOffset, boolean[] values, int valuesOffset, int length) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (1 * length) > this.validEnd))
      invalidPeer(checkedPeer, (1 * length)); 
    JNI.set_boolean_array(checkedPeer, values, valuesOffset, length);
    return this;
  }
  
  public boolean getBooleanAtIndex(long valueIndex) {
    return getBooleanAtOffset(valueIndex * 1L);
  }
  
  public boolean[] getBooleans(int length) {
    return getBooleansAtOffset(0L, length);
  }
  
  public boolean[] getBooleans() {
    long validBytes = getValidBytes("Cannot create array if remaining length is not known. Please use getBooleans(int length) instead.");
    return getBooleans((int)(validBytes / 1L));
  }
  
  public boolean[] getBooleansAtOffset(long byteOffset, int length) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + (1 * length) > this.validEnd))
      invalidPeer(checkedPeer, (1 * length)); 
    return JNI.get_boolean_array(checkedPeer, length);
  }
  
  public void getInts(int[] dest) {
    getIntBuffer().get(dest);
  }
  
  public void getInts(IntBuffer dest) {
    dest.duplicate().put(getIntBuffer());
  }
  
  public void getIntsAtOffset(long byteOffset, int[] dest, int destOffset, int length) {
    getIntBufferAtOffset(byteOffset, length).get(dest, destOffset, length);
  }
  
  public Pointer<T> setInts(IntBuffer values) {
    return setIntsAtOffset(0L, values, 0L, values.capacity());
  }
  
  public Pointer<T> setIntsAtOffset(long byteOffset, IntBuffer values) {
    return setIntsAtOffset(byteOffset, values, 0L, values.capacity());
  }
  
  public Pointer<T> setIntsAtOffset(long byteOffset, IntBuffer values, long valuesOffset, long length) {
    if (values == null)
      throw new IllegalArgumentException("Null values"); 
    if (values.isDirect()) {
      long len = length * 4L, off = valuesOffset * 4L;
      long cap = JNI.getDirectBufferCapacity(values);
      cap *= 4L;
      if (cap < off + len)
        throw new IndexOutOfBoundsException("The provided buffer has a capacity (" + cap + " bytes) smaller than the requested write operation (" + len + " bytes starting at byte offset " + off + ")"); 
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L * length > this.validEnd))
        invalidPeer(checkedPeer, 4L * length); 
      JNI.memcpy(checkedPeer, JNI.getDirectBufferAddress(values) + off, len);
    } else if (values.isReadOnly()) {
      getIntBufferAtOffset(byteOffset, length).put(values.duplicate());
    } else {
      setIntsAtOffset(byteOffset, values.array(), (int)(values.arrayOffset() + valuesOffset), (int)length);
    } 
    return this;
  }
  
  public IntBuffer getIntBuffer(long length) {
    return getIntBufferAtOffset(0L, length);
  }
  
  public IntBuffer getIntBuffer() {
    long validBytes = getValidBytes("Cannot create buffer if remaining length is not known. Please use getIntBuffer(long length) instead.");
    return getIntBufferAtOffset(0L, validBytes / 4L);
  }
  
  public IntBuffer getIntBufferAtOffset(long byteOffset, long length) {
    long blen = 4L * length;
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + blen > this.validEnd))
      invalidPeer(checkedPeer, blen); 
    ByteBuffer buffer = JNI.newDirectByteBuffer(checkedPeer, blen);
    buffer.order(order());
    return buffer.asIntBuffer();
  }
  
  public void getLongs(long[] dest) {
    getLongBuffer().get(dest);
  }
  
  public void getLongs(LongBuffer dest) {
    dest.duplicate().put(getLongBuffer());
  }
  
  public void getLongsAtOffset(long byteOffset, long[] dest, int destOffset, int length) {
    getLongBufferAtOffset(byteOffset, length).get(dest, destOffset, length);
  }
  
  public Pointer<T> setLongs(LongBuffer values) {
    return setLongsAtOffset(0L, values, 0L, values.capacity());
  }
  
  public Pointer<T> setLongsAtOffset(long byteOffset, LongBuffer values) {
    return setLongsAtOffset(byteOffset, values, 0L, values.capacity());
  }
  
  public Pointer<T> setLongsAtOffset(long byteOffset, LongBuffer values, long valuesOffset, long length) {
    if (values == null)
      throw new IllegalArgumentException("Null values"); 
    if (values.isDirect()) {
      long len = length * 8L, off = valuesOffset * 8L;
      long cap = JNI.getDirectBufferCapacity(values);
      cap *= 8L;
      if (cap < off + len)
        throw new IndexOutOfBoundsException("The provided buffer has a capacity (" + cap + " bytes) smaller than the requested write operation (" + len + " bytes starting at byte offset " + off + ")"); 
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L * length > this.validEnd))
        invalidPeer(checkedPeer, 8L * length); 
      JNI.memcpy(checkedPeer, JNI.getDirectBufferAddress(values) + off, len);
    } else if (values.isReadOnly()) {
      getLongBufferAtOffset(byteOffset, length).put(values.duplicate());
    } else {
      setLongsAtOffset(byteOffset, values.array(), (int)(values.arrayOffset() + valuesOffset), (int)length);
    } 
    return this;
  }
  
  public LongBuffer getLongBuffer(long length) {
    return getLongBufferAtOffset(0L, length);
  }
  
  public LongBuffer getLongBuffer() {
    long validBytes = getValidBytes("Cannot create buffer if remaining length is not known. Please use getLongBuffer(long length) instead.");
    return getLongBufferAtOffset(0L, validBytes / 8L);
  }
  
  public LongBuffer getLongBufferAtOffset(long byteOffset, long length) {
    long blen = 8L * length;
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + blen > this.validEnd))
      invalidPeer(checkedPeer, blen); 
    ByteBuffer buffer = JNI.newDirectByteBuffer(checkedPeer, blen);
    buffer.order(order());
    return buffer.asLongBuffer();
  }
  
  public void getShorts(short[] dest) {
    getShortBuffer().get(dest);
  }
  
  public void getShorts(ShortBuffer dest) {
    dest.duplicate().put(getShortBuffer());
  }
  
  public void getShortsAtOffset(long byteOffset, short[] dest, int destOffset, int length) {
    getShortBufferAtOffset(byteOffset, length).get(dest, destOffset, length);
  }
  
  public Pointer<T> setShorts(ShortBuffer values) {
    return setShortsAtOffset(0L, values, 0L, values.capacity());
  }
  
  public Pointer<T> setShortsAtOffset(long byteOffset, ShortBuffer values) {
    return setShortsAtOffset(byteOffset, values, 0L, values.capacity());
  }
  
  public Pointer<T> setShortsAtOffset(long byteOffset, ShortBuffer values, long valuesOffset, long length) {
    if (values == null)
      throw new IllegalArgumentException("Null values"); 
    if (values.isDirect()) {
      long len = length * 2L, off = valuesOffset * 2L;
      long cap = JNI.getDirectBufferCapacity(values);
      cap *= 2L;
      if (cap < off + len)
        throw new IndexOutOfBoundsException("The provided buffer has a capacity (" + cap + " bytes) smaller than the requested write operation (" + len + " bytes starting at byte offset " + off + ")"); 
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 2L * length > this.validEnd))
        invalidPeer(checkedPeer, 2L * length); 
      JNI.memcpy(checkedPeer, JNI.getDirectBufferAddress(values) + off, len);
    } else if (values.isReadOnly()) {
      getShortBufferAtOffset(byteOffset, length).put(values.duplicate());
    } else {
      setShortsAtOffset(byteOffset, values.array(), (int)(values.arrayOffset() + valuesOffset), (int)length);
    } 
    return this;
  }
  
  public ShortBuffer getShortBuffer(long length) {
    return getShortBufferAtOffset(0L, length);
  }
  
  public ShortBuffer getShortBuffer() {
    long validBytes = getValidBytes("Cannot create buffer if remaining length is not known. Please use getShortBuffer(long length) instead.");
    return getShortBufferAtOffset(0L, validBytes / 2L);
  }
  
  public ShortBuffer getShortBufferAtOffset(long byteOffset, long length) {
    long blen = 2L * length;
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + blen > this.validEnd))
      invalidPeer(checkedPeer, blen); 
    ByteBuffer buffer = JNI.newDirectByteBuffer(checkedPeer, blen);
    buffer.order(order());
    return buffer.asShortBuffer();
  }
  
  public void getBytes(byte[] dest) {
    getByteBuffer().get(dest);
  }
  
  public void getBytes(ByteBuffer dest) {
    dest.duplicate().put(getByteBuffer());
  }
  
  public void getBytesAtOffset(long byteOffset, byte[] dest, int destOffset, int length) {
    getByteBufferAtOffset(byteOffset, length).get(dest, destOffset, length);
  }
  
  public Pointer<T> setBytes(ByteBuffer values) {
    return setBytesAtOffset(0L, values, 0L, values.capacity());
  }
  
  public Pointer<T> setBytesAtOffset(long byteOffset, ByteBuffer values) {
    return setBytesAtOffset(byteOffset, values, 0L, values.capacity());
  }
  
  public Pointer<T> setBytesAtOffset(long byteOffset, ByteBuffer values, long valuesOffset, long length) {
    if (values == null)
      throw new IllegalArgumentException("Null values"); 
    if (values.isDirect()) {
      long len = length * 1L, off = valuesOffset * 1L;
      long cap = JNI.getDirectBufferCapacity(values);
      cap *= 1L;
      if (cap < off + len)
        throw new IndexOutOfBoundsException("The provided buffer has a capacity (" + cap + " bytes) smaller than the requested write operation (" + len + " bytes starting at byte offset " + off + ")"); 
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L * length > this.validEnd))
        invalidPeer(checkedPeer, 1L * length); 
      JNI.memcpy(checkedPeer, JNI.getDirectBufferAddress(values) + off, len);
    } else if (values.isReadOnly()) {
      getByteBufferAtOffset(byteOffset, length).put(values.duplicate());
    } else {
      setBytesAtOffset(byteOffset, values.array(), (int)(values.arrayOffset() + valuesOffset), (int)length);
    } 
    return this;
  }
  
  public ByteBuffer getByteBuffer(long length) {
    return getByteBufferAtOffset(0L, length);
  }
  
  public ByteBuffer getByteBuffer() {
    long validBytes = getValidBytes("Cannot create buffer if remaining length is not known. Please use getByteBuffer(long length) instead.");
    return getByteBufferAtOffset(0L, validBytes / 1L);
  }
  
  public ByteBuffer getByteBufferAtOffset(long byteOffset, long length) {
    long blen = 1L * length;
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + blen > this.validEnd))
      invalidPeer(checkedPeer, blen); 
    ByteBuffer buffer = JNI.newDirectByteBuffer(checkedPeer, blen);
    buffer.order(order());
    return buffer;
  }
  
  public Pointer<T> setChars(CharBuffer values) {
    return setCharsAtOffset(0L, values, 0L, values.capacity());
  }
  
  public Pointer<T> setCharsAtOffset(long byteOffset, CharBuffer values) {
    return setCharsAtOffset(byteOffset, values, 0L, values.capacity());
  }
  
  public Pointer<T> setCharsAtOffset(long byteOffset, CharBuffer values, long valuesOffset, long length) {
    if (values == null)
      throw new IllegalArgumentException("Null values"); 
    if (Platform.WCHAR_T_SIZE == 4) {
      for (int i = 0; i < length; i++)
        setCharAtOffset(byteOffset + i, values.get((int)(valuesOffset + i))); 
      return this;
    } 
    if (values.isDirect()) {
      long len = length * Platform.WCHAR_T_SIZE, off = valuesOffset * Platform.WCHAR_T_SIZE;
      long cap = JNI.getDirectBufferCapacity(values);
      cap *= Platform.WCHAR_T_SIZE;
      if (cap < off + len)
        throw new IndexOutOfBoundsException("The provided buffer has a capacity (" + cap + " bytes) smaller than the requested write operation (" + len + " bytes starting at byte offset " + off + ")"); 
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + Platform.WCHAR_T_SIZE * length > this.validEnd))
        invalidPeer(checkedPeer, Platform.WCHAR_T_SIZE * length); 
      JNI.memcpy(checkedPeer, JNI.getDirectBufferAddress(values) + off, len);
    } else {
      setCharsAtOffset(byteOffset, values.array(), (int)(values.arrayOffset() + valuesOffset), (int)length);
    } 
    return this;
  }
  
  public void getFloats(float[] dest) {
    getFloatBuffer().get(dest);
  }
  
  public void getFloats(FloatBuffer dest) {
    dest.duplicate().put(getFloatBuffer());
  }
  
  public void getFloatsAtOffset(long byteOffset, float[] dest, int destOffset, int length) {
    getFloatBufferAtOffset(byteOffset, length).get(dest, destOffset, length);
  }
  
  public Pointer<T> setFloats(FloatBuffer values) {
    return setFloatsAtOffset(0L, values, 0L, values.capacity());
  }
  
  public Pointer<T> setFloatsAtOffset(long byteOffset, FloatBuffer values) {
    return setFloatsAtOffset(byteOffset, values, 0L, values.capacity());
  }
  
  public Pointer<T> setFloatsAtOffset(long byteOffset, FloatBuffer values, long valuesOffset, long length) {
    if (values == null)
      throw new IllegalArgumentException("Null values"); 
    if (values.isDirect()) {
      long len = length * 4L, off = valuesOffset * 4L;
      long cap = JNI.getDirectBufferCapacity(values);
      cap *= 4L;
      if (cap < off + len)
        throw new IndexOutOfBoundsException("The provided buffer has a capacity (" + cap + " bytes) smaller than the requested write operation (" + len + " bytes starting at byte offset " + off + ")"); 
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 4L * length > this.validEnd))
        invalidPeer(checkedPeer, 4L * length); 
      JNI.memcpy(checkedPeer, JNI.getDirectBufferAddress(values) + off, len);
    } else if (values.isReadOnly()) {
      getFloatBufferAtOffset(byteOffset, length).put(values.duplicate());
    } else {
      setFloatsAtOffset(byteOffset, values.array(), (int)(values.arrayOffset() + valuesOffset), (int)length);
    } 
    return this;
  }
  
  public FloatBuffer getFloatBuffer(long length) {
    return getFloatBufferAtOffset(0L, length);
  }
  
  public FloatBuffer getFloatBuffer() {
    long validBytes = getValidBytes("Cannot create buffer if remaining length is not known. Please use getFloatBuffer(long length) instead.");
    return getFloatBufferAtOffset(0L, validBytes / 4L);
  }
  
  public FloatBuffer getFloatBufferAtOffset(long byteOffset, long length) {
    long blen = 4L * length;
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + blen > this.validEnd))
      invalidPeer(checkedPeer, blen); 
    ByteBuffer buffer = JNI.newDirectByteBuffer(checkedPeer, blen);
    buffer.order(order());
    return buffer.asFloatBuffer();
  }
  
  public void getDoubles(double[] dest) {
    getDoubleBuffer().get(dest);
  }
  
  public void getDoubles(DoubleBuffer dest) {
    dest.duplicate().put(getDoubleBuffer());
  }
  
  public void getDoublesAtOffset(long byteOffset, double[] dest, int destOffset, int length) {
    getDoubleBufferAtOffset(byteOffset, length).get(dest, destOffset, length);
  }
  
  public Pointer<T> setDoubles(DoubleBuffer values) {
    return setDoublesAtOffset(0L, values, 0L, values.capacity());
  }
  
  public Pointer<T> setDoublesAtOffset(long byteOffset, DoubleBuffer values) {
    return setDoublesAtOffset(byteOffset, values, 0L, values.capacity());
  }
  
  public Pointer<T> setDoublesAtOffset(long byteOffset, DoubleBuffer values, long valuesOffset, long length) {
    if (values == null)
      throw new IllegalArgumentException("Null values"); 
    if (values.isDirect()) {
      long len = length * 8L, off = valuesOffset * 8L;
      long cap = JNI.getDirectBufferCapacity(values);
      cap *= 8L;
      if (cap < off + len)
        throw new IndexOutOfBoundsException("The provided buffer has a capacity (" + cap + " bytes) smaller than the requested write operation (" + len + " bytes starting at byte offset " + off + ")"); 
      long checkedPeer = getPeer() + byteOffset;
      if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 8L * length > this.validEnd))
        invalidPeer(checkedPeer, 8L * length); 
      JNI.memcpy(checkedPeer, JNI.getDirectBufferAddress(values) + off, len);
    } else if (values.isReadOnly()) {
      getDoubleBufferAtOffset(byteOffset, length).put(values.duplicate());
    } else {
      setDoublesAtOffset(byteOffset, values.array(), (int)(values.arrayOffset() + valuesOffset), (int)length);
    } 
    return this;
  }
  
  public DoubleBuffer getDoubleBuffer(long length) {
    return getDoubleBufferAtOffset(0L, length);
  }
  
  public DoubleBuffer getDoubleBuffer() {
    long validBytes = getValidBytes("Cannot create buffer if remaining length is not known. Please use getDoubleBuffer(long length) instead.");
    return getDoubleBufferAtOffset(0L, validBytes / 8L);
  }
  
  public DoubleBuffer getDoubleBufferAtOffset(long byteOffset, long length) {
    long blen = 8L * length;
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + blen > this.validEnd))
      invalidPeer(checkedPeer, blen); 
    ByteBuffer buffer = JNI.newDirectByteBuffer(checkedPeer, blen);
    buffer.order(order());
    return buffer.asDoubleBuffer();
  }
  
  public enum StringType {
    C(false, true),
    WideC(true, true),
    PascalShort(false, true),
    PascalWide(true, true),
    PascalAnsi(false, true),
    BSTR(true, true),
    STL(false, false),
    WideSTL(true, false);
    
    final boolean isWide;
    
    final boolean canCreate;
    
    StringType(boolean isWide, boolean canCreate) {
      this.isWide = isWide;
      this.canCreate = canCreate;
    }
  }
  
  private static void notAString(StringType type, String reason) {
    throw new RuntimeException("There is no " + type + " String here ! (" + reason + ")");
  }
  
  protected void checkIntRefCount(StringType type, long byteOffset) {
    int refCount = getIntAtOffset(byteOffset);
    if (refCount <= 0)
      notAString(type, "invalid refcount: " + refCount); 
  }
  
  public String getString(StringType type) {
    return getStringAtOffset(0L, type, null);
  }
  
  public String getString(StringType type, Charset charset) {
    return getStringAtOffset(0L, type, charset);
  }
  
  String getSTLStringAtOffset(long byteOffset, StringType type, Charset charset) {
    long pOff;
    Pointer<?> p;
    boolean wide = (type == StringType.WideSTL);
    int fixedBuffLength = 16;
    int fixedBuffSize = wide ? (fixedBuffLength * Platform.WCHAR_T_SIZE) : fixedBuffLength;
    long length = getSizeTAtOffset(byteOffset + fixedBuffSize + SIZE);
    if (length < (fixedBuffLength - 1)) {
      pOff = byteOffset;
      p = this;
    } else {
      pOff = 0L;
      p = getPointerAtOffset(byteOffset + fixedBuffSize + SIZE);
    } 
    int endChar = wide ? p.getCharAtOffset(pOff + length * Platform.WCHAR_T_SIZE) : p.getByteAtOffset(pOff + length);
    if (endChar != 0)
      notAString(type, "STL string format is not recognized : did not find a NULL char at the expected end of string of expected length " + length); 
    return p.getStringAtOffset(pOff, wide ? StringType.WideC : StringType.C, charset);
  }
  
  static <U> Pointer<U> setSTLString(Pointer<U> pointer, long byteOffset, String s, StringType type, Charset charset) {
    long pOff;
    Pointer<?> p;
    boolean wide = (type == StringType.WideSTL);
    int fixedBuffLength = 16;
    int fixedBuffSize = wide ? (fixedBuffLength * Platform.WCHAR_T_SIZE) : fixedBuffLength;
    long lengthOffset = byteOffset + fixedBuffSize + SIZE;
    long capacityOffset = lengthOffset + SIZE;
    long length = s.length();
    if (pointer == null)
      throw new UnsupportedOperationException("Cannot create STL strings (yet)"); 
    long currentLength = pointer.getSizeTAtOffset(lengthOffset);
    long currentCapacity = pointer.getSizeTAtOffset(capacityOffset);
    if (currentLength < 0L || currentCapacity < 0L || currentLength > currentCapacity)
      notAString(type, "STL string format not recognized : currentLength = " + currentLength + ", currentCapacity = " + currentCapacity); 
    if (length > currentCapacity)
      throw new RuntimeException("The target STL string is not large enough to write a string of length " + length + " (current capacity = " + currentCapacity + ")"); 
    pointer.setSizeTAtOffset(lengthOffset, length);
    if (length < (fixedBuffLength - 1)) {
      pOff = byteOffset;
      p = pointer;
    } else {
      pOff = 0L;
      p = pointer.getPointerAtOffset(byteOffset + fixedBuffSize + SizeT.SIZE);
    } 
    int endChar = wide ? p.getCharAtOffset(pOff + currentLength * Platform.WCHAR_T_SIZE) : p.getByteAtOffset(pOff + currentLength);
    if (endChar != 0)
      notAString(type, "STL string format is not recognized : did not find a NULL char at the expected end of string of expected length " + currentLength); 
    p.setStringAtOffset(pOff, s, wide ? StringType.WideC : StringType.C, charset);
    return pointer;
  }
  
  public String getStringAtOffset(long byteOffset, StringType type, Charset charset) {
    try {
      long len;
      switch (type) {
        case PascalShort:
          len = (getByteAtOffset(byteOffset) & 0xFF);
          return new String(getBytesAtOffset(byteOffset + 1L, SizeT.safeIntCast(len)), charset(charset));
        case PascalWide:
          checkIntRefCount(type, byteOffset - 8L);
        case BSTR:
          len = getIntAtOffset(byteOffset - 4L);
          if (len < 0L || (len & 0x1L) == 1L)
            notAString(type, "invalid byte length: " + len); 
          if (getCharAtOffset(byteOffset + len) != '\000')
            notAString(type, "no null short after the " + len + " declared bytes"); 
          return new String(getCharsAtOffset(byteOffset, SizeT.safeIntCast(len / Platform.WCHAR_T_SIZE)));
        case PascalAnsi:
          checkIntRefCount(type, byteOffset - 8L);
          len = getIntAtOffset(byteOffset - 4L);
          if (len < 0L)
            notAString(type, "invalid byte length: " + len); 
          if (getByteAtOffset(byteOffset + len) != 0)
            notAString(type, "no null short after the " + len + " declared bytes"); 
          return new String(getBytesAtOffset(byteOffset, SizeT.safeIntCast(len)), charset(charset));
        case C:
          len = strlen(byteOffset);
          return new String(getBytesAtOffset(byteOffset, SizeT.safeIntCast(len)), charset(charset));
        case WideC:
          len = wcslen(byteOffset);
          return new String(getCharsAtOffset(byteOffset, SizeT.safeIntCast(len)));
        case STL:
        case WideSTL:
          return getSTLStringAtOffset(byteOffset, type, charset);
      } 
      throw new RuntimeException("Unhandled string type : " + type);
    } catch (UnsupportedEncodingException ex) {
      throwUnexpected(ex);
      return null;
    } 
  }
  
  public Pointer<T> setString(String s, StringType type) {
    return setString(this, 0L, s, type, null);
  }
  
  public Pointer<T> setStringAtOffset(long byteOffset, String s, StringType type, Charset charset) {
    return setString(this, byteOffset, s, type, charset);
  }
  
  private static String charset(Charset charset) {
    return ((charset == null) ? Charset.defaultCharset() : charset).name();
  }
  
  static <U> Pointer<U> setString(Pointer<U> pointer, long byteOffset, String s, StringType type, Charset charset) {
    try {
      byte[] bytes;
      int bytesCount;
      char[] chars;
      int headerBytes;
      int headerShift;
      if (s == null)
        return null; 
      switch (type) {
        case PascalShort:
          bytes = s.getBytes(charset(charset));
          bytesCount = bytes.length;
          if (pointer == null)
            pointer = (Pointer)allocateBytes((bytesCount + 1)); 
          if (bytesCount > 255)
            throw new IllegalArgumentException("Pascal strings cannot be more than 255 chars long (tried to write string of byte length " + bytesCount + ")"); 
          pointer.setByteAtOffset(byteOffset, (byte)bytesCount);
          pointer.setBytesAtOffset(byteOffset + 1L, bytes, 0, bytesCount);
          return pointer;
        case C:
          bytes = s.getBytes(charset(charset));
          bytesCount = bytes.length;
          if (pointer == null)
            pointer = (Pointer)allocateBytes((bytesCount + 1)); 
          pointer.setBytesAtOffset(byteOffset, bytes, 0, bytesCount);
          pointer.setByteAtOffset(byteOffset + bytesCount, (byte)0);
          return pointer;
        case WideC:
          chars = s.toCharArray();
          bytesCount = chars.length * Platform.WCHAR_T_SIZE;
          if (pointer == null)
            pointer = (Pointer)allocateChars((bytesCount + 2)); 
          pointer.setCharsAtOffset(byteOffset, chars);
          pointer.setCharAtOffset(byteOffset + bytesCount, false);
          return pointer;
        case PascalWide:
          headerBytes = 8;
          chars = s.toCharArray();
          bytesCount = chars.length * Platform.WCHAR_T_SIZE;
          if (pointer == null) {
            pointer = (Pointer)allocateChars((headerBytes + bytesCount + 2));
            byteOffset = (headerShift = headerBytes);
          } else {
            headerShift = 0;
          } 
          pointer.setIntAtOffset(byteOffset - 8L, 1);
          pointer.setIntAtOffset(byteOffset - 4L, bytesCount);
          pointer.setCharsAtOffset(byteOffset, chars);
          pointer.setCharAtOffset(byteOffset + bytesCount, false);
          return pointer.offset(headerShift);
        case PascalAnsi:
          headerBytes = 8;
          bytes = s.getBytes(charset(charset));
          bytesCount = bytes.length;
          if (pointer == null) {
            pointer = (Pointer)allocateBytes((headerBytes + bytesCount + 1));
            byteOffset = (headerShift = headerBytes);
          } else {
            headerShift = 0;
          } 
          pointer.setIntAtOffset(byteOffset - 8L, 1);
          pointer.setIntAtOffset(byteOffset - 4L, bytesCount);
          pointer.setBytesAtOffset(byteOffset, bytes);
          pointer.setByteAtOffset(byteOffset + bytesCount, (byte)0);
          return pointer.offset(headerShift);
        case BSTR:
          headerBytes = 4;
          chars = s.toCharArray();
          bytesCount = chars.length * Platform.WCHAR_T_SIZE;
          if (pointer == null) {
            pointer = (Pointer)allocateChars((headerBytes + bytesCount + 2));
            byteOffset = (headerShift = headerBytes);
          } else {
            headerShift = 0;
          } 
          pointer.setIntAtOffset(byteOffset - 4L, bytesCount);
          pointer.setCharsAtOffset(byteOffset, chars);
          pointer.setCharAtOffset(byteOffset + bytesCount, false);
          return pointer.offset(headerShift);
        case STL:
        case WideSTL:
          return setSTLString(pointer, byteOffset, s, type, charset);
      } 
      throw new RuntimeException("Unhandled string type : " + type);
    } catch (UnsupportedEncodingException ex) {
      throwUnexpected(ex);
      return null;
    } 
  }
  
  public static Pointer<?> pointerToString(String string, StringType type, Charset charset) {
    return setString(null, 0L, string, type, charset);
  }
  
  public static Pointer<Byte> pointerToCString(String string) {
    return setString(null, 0L, string, StringType.C, null);
  }
  
  public static Pointer<Pointer<Byte>> pointerToCStrings(String... strings) {
    if (strings == null)
      return null; 
    final int len = strings.length;
    final Pointer[] pointers = new Pointer[len];
    Pointer<Pointer<Byte>> mem = allocateArray(PointerIO.getPointerInstance(Byte.class), len, new Releaser() {
          public void release(Pointer<?> p) {
            Pointer<Pointer<Byte>> mem = (Pointer)p;
            for (int i = 0; i < len; i++) {
              Pointer<Byte> pp = pointers[i];
              if (pp != null)
                pp.release(); 
            } 
          }
        });
    for (int i = 0; i < len; i++)
      mem.set(i, arrayOfPointer[i] = pointerToCString(strings[i])); 
    return mem;
  }
  
  public static Pointer<Character> pointerToWideCString(String string) {
    return setString(null, 0L, string, StringType.WideC, null);
  }
  
  public static Pointer<Pointer<Character>> pointerToWideCStrings(String... strings) {
    if (strings == null)
      return null; 
    final int len = strings.length;
    final Pointer[] pointers = new Pointer[len];
    Pointer<Pointer<Character>> mem = allocateArray(PointerIO.getPointerInstance(Character.class), len, new Releaser() {
          public void release(Pointer<?> p) {
            Pointer<Pointer<Character>> mem = (Pointer)p;
            for (int i = 0; i < len; i++) {
              Pointer<Character> pp = pointers[i];
              if (pp != null)
                pp.release(); 
            } 
          }
        });
    for (int i = 0; i < len; i++)
      mem.set(i, arrayOfPointer[i] = pointerToWideCString(strings[i])); 
    return mem;
  }
  
  public String getCString() {
    return getCStringAtOffset(0L);
  }
  
  public String getCStringAtOffset(long byteOffset) {
    return getStringAtOffset(byteOffset, StringType.C, null);
  }
  
  public Pointer<T> setCString(String s) {
    return setCStringAtOffset(0L, s);
  }
  
  public Pointer<T> setCStringAtOffset(long byteOffset, String s) {
    return setStringAtOffset(byteOffset, s, StringType.C, null);
  }
  
  public String getWideCString() {
    return getWideCStringAtOffset(0L);
  }
  
  public String getWideCStringAtOffset(long byteOffset) {
    return getStringAtOffset(byteOffset, StringType.WideC, null);
  }
  
  public Pointer<T> setWideCString(String s) {
    return setWideCStringAtOffset(0L, s);
  }
  
  public Pointer<T> setWideCStringAtOffset(long byteOffset, String s) {
    return setStringAtOffset(byteOffset, s, StringType.WideC, null);
  }
  
  protected long strlen(long byteOffset) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + 1L > this.validEnd))
      invalidPeer(checkedPeer, 1L); 
    return JNI.strlen(checkedPeer);
  }
  
  protected long wcslen(long byteOffset) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + Platform.WCHAR_T_SIZE > this.validEnd))
      invalidPeer(checkedPeer, Platform.WCHAR_T_SIZE); 
    return JNI.wcslen(checkedPeer);
  }
  
  public void clearValidBytes() {
    long bytes = getValidBytes();
    if (bytes < 0L)
      throw new UnsupportedOperationException("Number of valid bytes is unknown. Please use clearBytes(long) or validBytes(long)."); 
    clearBytes(bytes);
  }
  
  public void clearBytes(long length) {
    clearBytesAtOffset(0L, length, (byte)0);
  }
  
  public void clearBytesAtOffset(long byteOffset, long length, byte value) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + length > this.validEnd))
      invalidPeer(checkedPeer, length); 
    JNI.memset(checkedPeer, value, length);
  }
  
  public Pointer<T> findByte(long byteOffset, byte value, long searchLength) {
    long checkedPeer = getPeer() + byteOffset;
    if (this.validStart != -1L && (checkedPeer < this.validStart || checkedPeer + searchLength > this.validEnd))
      invalidPeer(checkedPeer, searchLength); 
    long found = JNI.memchr(checkedPeer, value, searchLength);
    return (found == 0L) ? null : offset(found - checkedPeer);
  }
  
  public final T apply(long index) {
    return get(index);
  }
  
  public final void update(long index, T element) {
    set(index, element);
  }
  
  public T[] toArray() {
    getIO("Cannot create array");
    return toArray((int)getValidElements("Length of pointed memory is unknown, cannot create array out of this pointer"));
  }
  
  T[] toArray(int length) {
    Class<?> c = Utils.getClass(getIO("Cannot create array").getTargetType());
    if (c == null)
      throw new RuntimeException("Unable to get the target type's class (target type = " + this.io.getTargetType() + ")"); 
    return (T[])toArray((Object[])Array.newInstance(c, length));
  }
  
  public <U> U[] toArray(U[] array) {
    int n = (int)getValidElements();
    if (n < 0)
      throwBecauseUntyped("Cannot create array"); 
    if (array.length != n)
      return (U[])toArray(); 
    for (int i = 0; i < n; i++)
      array[i] = (U)get(i); 
    return array;
  }
  
  public enum ListType {
    Unmodifiable, FixedCapacity, Dynamic;
  }
  
  public NativeList<T> asList() {
    return asList(ListType.FixedCapacity);
  }
  
  public NativeList<T> asList(ListType type) {
    return new DefaultNativeList<T>(this, type);
  }
  
  public static <E> NativeList<E> allocateList(PointerIO<E> io, long capacity) {
    NativeList<E> list = new DefaultNativeList<E>(allocateArray(io, capacity), ListType.Dynamic);
    list.clear();
    return list;
  }
  
  public static <E> NativeList<E> allocateList(Class<E> type, long capacity) {
    return allocateList(type, capacity);
  }
  
  public static <E> NativeList<E> allocateList(Type type, long capacity) {
    return allocateList(PointerIO.getInstance(type), capacity);
  }
  
  private static char[] intsToWChars(int[] in) {
    int n = in.length;
    char[] out = new char[n];
    for (int i = 0; i < n; i++)
      out[i] = (char)in[i]; 
    return out;
  }
  
  private static int[] wcharsToInts(char[] in, int valuesOffset, int length) {
    int[] out = new int[length];
    for (int i = 0; i < length; i++)
      out[i] = in[valuesOffset + i]; 
    return out;
  }
  
  public Pointer<T> setIntegralAtOffset(long byteOffset, AbstractIntegral value) {
    switch (value.byteSize()) {
      case 8:
        setLongAtOffset(byteOffset, value.longValue());
        return this;
      case 4:
        setIntAtOffset(byteOffset, SizeT.safeIntCast(value.longValue()));
        return this;
    } 
    throw new UnsupportedOperationException("Unsupported integral size");
  }
  
  public long getIntegralAtOffset(long byteOffset, int integralSize) {
    switch (integralSize) {
      case 8:
        return getLongAtOffset(byteOffset);
      case 4:
        return getIntAtOffset(byteOffset);
    } 
    throw new UnsupportedOperationException("Unsupported integral size");
  }
  
  public abstract boolean isOrdered();
  
  public abstract Pointer<T> setSizeTsAtOffset(long paramLong, long[] paramArrayOflong, int paramInt1, int paramInt2);
  
  public abstract Pointer<T> setSizeTsAtOffset(long paramLong, int[] paramArrayOfint);
  
  public abstract Pointer<T> setCLongsAtOffset(long paramLong, long[] paramArrayOflong, int paramInt1, int paramInt2);
  
  public abstract Pointer<T> setCLongsAtOffset(long paramLong, int[] paramArrayOfint);
  
  public abstract Pointer<T> setInt(int paramInt);
  
  public abstract Pointer<T> setIntAtOffset(long paramLong, int paramInt);
  
  public abstract int getInt();
  
  public abstract int getIntAtOffset(long paramLong);
  
  public abstract Pointer<T> setLong(long paramLong);
  
  public abstract Pointer<T> setLongAtOffset(long paramLong1, long paramLong2);
  
  public abstract long getLong();
  
  public abstract long getLongAtOffset(long paramLong);
  
  public abstract Pointer<T> setShort(short paramShort);
  
  public abstract Pointer<T> setShortAtOffset(long paramLong, short paramShort);
  
  public abstract short getShort();
  
  public abstract short getShortAtOffset(long paramLong);
  
  public abstract Pointer<T> setByte(byte paramByte);
  
  public abstract Pointer<T> setByteAtOffset(long paramLong, byte paramByte);
  
  public abstract byte getByte();
  
  public abstract byte getByteAtOffset(long paramLong);
  
  public abstract Pointer<T> setChar(char paramChar);
  
  public abstract Pointer<T> setCharAtOffset(long paramLong, char paramChar);
  
  public abstract char getChar();
  
  public abstract char getCharAtOffset(long paramLong);
  
  public abstract Pointer<T> setFloat(float paramFloat);
  
  public abstract Pointer<T> setFloatAtOffset(long paramLong, float paramFloat);
  
  public abstract float getFloat();
  
  public abstract float getFloatAtOffset(long paramLong);
  
  public abstract Pointer<T> setDouble(double paramDouble);
  
  public abstract Pointer<T> setDoubleAtOffset(long paramLong, double paramDouble);
  
  public abstract double getDouble();
  
  public abstract double getDoubleAtOffset(long paramLong);
  
  public abstract Pointer<T> setBoolean(boolean paramBoolean);
  
  public abstract Pointer<T> setBooleanAtOffset(long paramLong, boolean paramBoolean);
  
  public abstract boolean getBoolean();
  
  public abstract boolean getBooleanAtOffset(long paramLong);
  
  public static interface Releaser {
    void release(Pointer<?> param1Pointer);
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\Pointer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */