package org.bridj;

class NativeConstants {
  enum ValueType {
    eVoidValue, eWCharValue, eCLongValue, eCLongObjectValue, eSizeTValue, eSizeTObjectValue, eIntValue, eShortValue, eByteValue, eBooleanValue, eLongValue, eDoubleValue, eFloatValue, ePointerValue, eEllipsis, eIntFlagSet, eNativeObjectValue, eTimeTObjectValue;
  }
  
  enum CallbackType {
    eJavaCallbackToNativeFunction, eNativeToJavaCallback, eJavaToNativeFunction, eJavaToVirtualMethod;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\bridj-0.7-20140918-2.jar!\org\bridj\NativeConstants.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */