/*    */ package org.bridj;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NativeConstants
/*    */ {
/*    */   enum ValueType
/*    */   {
/* 45 */     eVoidValue,
/* 46 */     eWCharValue,
/* 47 */     eCLongValue,
/* 48 */     eCLongObjectValue,
/* 49 */     eSizeTValue,
/* 50 */     eSizeTObjectValue,
/* 51 */     eIntValue,
/* 52 */     eShortValue,
/* 53 */     eByteValue,
/* 54 */     eBooleanValue,
/* 55 */     eLongValue,
/* 56 */     eDoubleValue,
/* 57 */     eFloatValue,
/* 58 */     ePointerValue,
/* 59 */     eEllipsis,
/* 60 */     eIntFlagSet,
/* 61 */     eNativeObjectValue,
/* 62 */     eTimeTObjectValue;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   enum CallbackType
/*    */   {
/* 70 */     eJavaCallbackToNativeFunction,
/* 71 */     eNativeToJavaCallback,
/* 72 */     eJavaToNativeFunction,
/* 73 */     eJavaToVirtualMethod;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\NativeConstants.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */