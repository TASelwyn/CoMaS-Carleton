package org.bridj.func;

public interface Fun0<T> {
  T apply();
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\func\Fun0.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */