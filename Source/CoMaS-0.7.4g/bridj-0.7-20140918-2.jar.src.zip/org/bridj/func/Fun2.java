package org.bridj.func;

public interface Fun2<T, A1, A2> {
  T apply(A1 paramA1, A2 paramA2);
}
