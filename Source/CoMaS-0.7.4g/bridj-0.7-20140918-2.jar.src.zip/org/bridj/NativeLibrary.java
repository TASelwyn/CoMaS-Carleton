/*     */ package org.bridj;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.bridj.ann.Name;
/*     */ import org.bridj.ann.Symbol;
/*     */ import org.bridj.demangling.Demangler;
/*     */ import org.bridj.demangling.GCC4Demangler;
/*     */ import org.bridj.demangling.VC9Demangler;
/*     */ import org.bridj.util.AnnotationUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeLibrary
/*     */ {
/*     */   volatile long handle;
/*     */   volatile long symbols;
/*     */   String path;
/*     */   final File canonicalFile;
/*  83 */   NativeEntities nativeEntities = new NativeEntities();
/*     */   
/*     */   Map<Long, Demangler.Symbol> addrToName;
/*     */   Map<String, Demangler.Symbol> nameToSym;
/*     */   
/*     */   protected NativeLibrary(String path, long handle, long symbols) throws IOException {
/*  89 */     this.path = path;
/*  90 */     this.handle = handle;
/*  91 */     this.symbols = symbols;
/*  92 */     this.canonicalFile = (path == null) ? null : (new File(path)).getCanonicalFile();
/*     */     
/*  94 */     Platform.addNativeLibrary(this);
/*     */   }
/*     */   
/*     */   long getSymbolsHandle() {
/*  98 */     return this.symbols;
/*     */   }
/*     */   
/*     */   NativeEntities getNativeEntities() {
/* 102 */     return this.nativeEntities;
/*     */   }
/*     */   
/*     */   static String followGNULDScript(String path) {
/*     */     try {
/* 107 */       Reader r = new FileReader(path);
/*     */       try {
/*     */         char c;
/* 110 */         while ((c = (char)r.read()) == ' ' || c == '\t' || c == '\n');
/*     */         
/* 112 */         if (c == '/' && r.read() == 42) {
/* 113 */           BufferedReader br = new BufferedReader(r);
/* 114 */           r = br;
/*     */           
/* 116 */           StringBuilder b = new StringBuilder("/*"); String line;
/* 117 */           while ((line = br.readLine()) != null) {
/* 118 */             b.append(line).append('\n');
/*     */           }
/* 120 */           String src = b.toString();
/* 121 */           Pattern ldGroupPattern = Pattern.compile("GROUP\\s*\\(\\s*([^\\s)]+)[^)]*\\)");
/* 122 */           Matcher m = ldGroupPattern.matcher(src);
/* 123 */           if (m.find()) {
/* 124 */             String actualPath = m.group(1);
/* 125 */             if (BridJ.verbose) {
/* 126 */               BridJ.info("Parsed LD script '" + path + "', found absolute reference to '" + actualPath + "'");
/*     */             }
/* 128 */             return actualPath;
/*     */           } 
/* 130 */           BridJ.error("Failed to parse LD script '" + path + "' !");
/*     */         } 
/*     */       } finally {
/*     */         
/* 134 */         r.close();
/*     */       } 
/* 136 */     } catch (Throwable th) {
/* 137 */       BridJ.error("Unexpected error: " + th, th);
/*     */     } 
/* 139 */     return path;
/*     */   }
/*     */   
/*     */   public static NativeLibrary load(String path) throws IOException {
/* 143 */     long handle = 0L;
/* 144 */     File file = new File(path);
/* 145 */     boolean exists = file.exists();
/* 146 */     if (file.isAbsolute() && !exists) {
/* 147 */       return null;
/*     */     }
/*     */     
/* 150 */     if (Platform.isUnix() && exists) {
/* 151 */       path = followGNULDScript(path);
/*     */     }
/*     */     
/* 154 */     handle = JNI.loadLibrary(path);
/* 155 */     if (handle == 0L) {
/* 156 */       return null;
/*     */     }
/* 158 */     long symbols = JNI.loadLibrarySymbols(path);
/* 159 */     return new NativeLibrary(path, handle, symbols);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getHandle() {
/* 166 */     if (this.path != null && this.handle == 0L) {
/* 167 */       throw new RuntimeException("Library was released and cannot be used anymore");
/*     */     }
/* 169 */     return this.handle;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void finalize() throws Throwable {
/* 174 */     release();
/*     */   }
/*     */   
/*     */   public synchronized void release() {
/* 178 */     if (this.handle == 0L) {
/*     */       return;
/*     */     }
/*     */     
/* 182 */     if (BridJ.verbose) {
/* 183 */       BridJ.info("Releasing library '" + this.path + "'");
/*     */     }
/*     */     
/* 186 */     this.nativeEntities.release();
/*     */     
/* 188 */     JNI.freeLibrarySymbols(this.symbols);
/* 189 */     JNI.freeLibrary(this.handle);
/* 190 */     this.handle = 0L;
/*     */     
/* 192 */     if (this.canonicalFile != null && Platform.temporaryExtractedLibraryCanonicalFiles.remove(this.canonicalFile)) {
/* 193 */       if (this.canonicalFile.delete()) {
/* 194 */         if (BridJ.verbose) {
/* 195 */           BridJ.info("Deleted temporary library file '" + this.canonicalFile + "'");
/*     */         }
/*     */       } else {
/* 198 */         BridJ.error("Failed to delete temporary library file '" + this.canonicalFile + "'");
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Pointer<?> getSymbolPointer(String name) {
/* 205 */     return Pointer.pointerToAddress(getSymbolAddress(name));
/*     */   }
/*     */   
/*     */   public long getSymbolAddress(String name) {
/* 209 */     if (this.nameToSym != null) {
/* 210 */       Demangler.Symbol addr = this.nameToSym.get(name);
/*     */ 
/*     */       
/* 213 */       if (addr != null) {
/* 214 */         return addr.getAddress();
/*     */       }
/*     */     } 
/* 217 */     long address = JNI.findSymbolInLibrary(getHandle(), name);
/* 218 */     if (address == 0L) {
/* 219 */       address = JNI.findSymbolInLibrary(getHandle(), "_" + name);
/*     */     }
/* 221 */     return address;
/*     */   }
/*     */   
/*     */   public synchronized Demangler.Symbol getSymbol(AnnotatedElement member) throws FileNotFoundException {
/* 225 */     Symbol mg = (Symbol)AnnotationUtils.getAnnotation(Symbol.class, member, new java.lang.annotation.Annotation[0]);
/* 226 */     String name = null;
/*     */     
/* 228 */     Name nameAnn = member.<Name>getAnnotation(Name.class);
/* 229 */     if (nameAnn != null) {
/* 230 */       name = nameAnn.value();
/* 231 */     } else if (member instanceof Member) {
/* 232 */       name = ((Member)member).getName();
/*     */     } 
/*     */     
/* 235 */     List<String> names = new ArrayList<String>();
/* 236 */     if (mg != null) {
/* 237 */       names.addAll(Arrays.asList(mg.value()));
/*     */     }
/* 239 */     if (name != null) {
/* 240 */       names.add(name);
/*     */     }
/*     */     
/* 243 */     for (String n : names) {
/* 244 */       Demangler.Symbol handle = getSymbol(n);
/* 245 */       if (handle == null) {
/* 246 */         handle = getSymbol("_" + n);
/*     */       }
/* 248 */       if (handle == null) {
/* 249 */         handle = getSymbol(n + (Platform.useUnicodeVersionOfWindowsAPIs ? "W" : "A"));
/*     */       }
/* 251 */       if (handle != null) {
/* 252 */         return handle;
/*     */       }
/*     */     } 
/*     */     
/* 256 */     if (member instanceof Method) {
/* 257 */       Method method = (Method)member;
/* 258 */       for (Demangler.Symbol symbol : getSymbols()) {
/* 259 */         if (symbol.matches(method)) {
/* 260 */           return symbol;
/*     */         }
/*     */       } 
/*     */     } 
/* 264 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isMSVC() {
/* 268 */     return Platform.isWindows();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Demangler.Symbol getFirstMatchingSymbol(SymbolAccepter accepter) {
/* 280 */     for (Demangler.Symbol symbol : getSymbols()) {
/* 281 */       if (accepter.accept(symbol)) {
/* 282 */         return symbol;
/*     */       }
/*     */     } 
/* 285 */     return null;
/*     */   }
/*     */   
/*     */   public Collection<Demangler.Symbol> getSymbols() {
/*     */     try {
/* 290 */       scanSymbols();
/* 291 */     } catch (Exception ex) {
/* 292 */       assert BridJ.error("Failed to scan symbols of library '" + this.path + "'", ex);
/*     */     } 
/* 294 */     return (this.nameToSym == null) ? Collections.EMPTY_LIST : Collections.<Demangler.Symbol>unmodifiableCollection(this.nameToSym.values());
/*     */   }
/*     */   
/*     */   public String getSymbolName(long address) {
/* 298 */     if (this.addrToName == null && getSymbolsHandle() != 0L)
/*     */     {
/* 300 */       return JNI.findSymbolName(getHandle(), getSymbolsHandle(), address);
/*     */     }
/*     */     
/* 303 */     Demangler.Symbol symbol = getSymbol(address);
/* 304 */     return (symbol == null) ? null : symbol.getSymbol();
/*     */   }
/*     */   
/*     */   public Demangler.Symbol getSymbol(long address) {
/*     */     try {
/* 309 */       scanSymbols();
/* 310 */       Demangler.Symbol symbol = this.addrToName.get(Long.valueOf(address));
/* 311 */       return symbol;
/* 312 */     } catch (Exception ex) {
/* 313 */       throw new RuntimeException("Failed to get name of address " + address, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Demangler.Symbol getSymbol(String name) {
/*     */     try {
/* 322 */       if (this.nameToSym == null) {
/* 323 */         long addr = JNI.findSymbolInLibrary(getHandle(), name);
/* 324 */         if (addr != 0L) {
/* 325 */           Demangler.Symbol symbol1 = new Demangler.Symbol(name, this);
/* 326 */           symbol1.setAddress(addr);
/* 327 */           return symbol1;
/*     */         } 
/*     */       } 
/* 330 */       scanSymbols();
/* 331 */       if (this.nameToSym == null) {
/* 332 */         return null;
/*     */       }
/*     */       
/* 335 */       Demangler.Symbol symbol = this.nameToSym.get(name);
/* 336 */       if (this.addrToName == null && 
/* 337 */         symbol == null) {
/* 338 */         long addr = JNI.findSymbolInLibrary(getHandle(), name);
/* 339 */         if (addr != 0L) {
/* 340 */           symbol = new Demangler.Symbol(name, this);
/* 341 */           symbol.setAddress(addr);
/* 342 */           this.nameToSym.put(name, symbol);
/*     */         } 
/*     */       } 
/*     */       
/* 346 */       return symbol;
/* 347 */     } catch (Exception ex) {
/* 348 */       ex.printStackTrace();
/* 349 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void scanSymbols() throws Exception {
/* 355 */     if (this.addrToName != null) {
/*     */       return;
/*     */     }
/*     */     
/* 359 */     this.nameToSym = new HashMap<String, Demangler.Symbol>();
/*     */ 
/*     */     
/* 362 */     String[] symbs = null;
/* 363 */     if (symbs == null)
/*     */     {
/* 365 */       symbs = JNI.getLibrarySymbols(getHandle(), getSymbolsHandle());
/*     */     }
/*     */ 
/*     */     
/* 369 */     if (symbs == null) {
/*     */       return;
/*     */     }
/*     */     
/* 373 */     this.addrToName = new HashMap<Long, Demangler.Symbol>();
/*     */     
/* 375 */     boolean is32 = !Platform.is64Bits();
/* 376 */     for (String name : symbs) {
/* 377 */       if (name != null) {
/*     */ 
/*     */ 
/*     */         
/* 381 */         long addr = JNI.findSymbolInLibrary(getHandle(), name);
/* 382 */         if (addr == 0L && name.startsWith("_")) {
/* 383 */           String n2 = name.substring(1);
/* 384 */           addr = JNI.findSymbolInLibrary(getHandle(), n2);
/* 385 */           if (addr == 0L) {
/* 386 */             n2 = "_" + name;
/* 387 */             addr = JNI.findSymbolInLibrary(getHandle(), n2);
/*     */           } 
/* 389 */           if (addr != 0L) {
/* 390 */             name = n2;
/*     */           }
/*     */         } 
/*     */         
/* 394 */         if (addr == 0L) {
/* 395 */           if (BridJ.verbose) {
/* 396 */             BridJ.warning("Symbol '" + name + "' not found.");
/*     */           
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 404 */           Demangler.Symbol sym = new Demangler.Symbol(name, this);
/* 405 */           sym.setAddress(addr);
/* 406 */           this.addrToName.put(Long.valueOf(addr), sym);
/* 407 */           this.nameToSym.put(name, sym);
/*     */         } 
/*     */       } 
/*     */     } 
/* 411 */     if (BridJ.debug) {
/* 412 */       BridJ.info("Found " + this.nameToSym.size() + " symbols in '" + this.path + "' :");
/*     */       
/* 414 */       for (Demangler.Symbol sym : this.nameToSym.values()) {
/* 415 */         BridJ.info("DEBUG(BridJ): library=\"" + this.path + "\", symbol=\"" + sym.getSymbol() + "\", address=" + Long.toHexString(sym.getAddress()) + ", demangled=\"" + sym.getParsedRef() + "\"");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Demangler.MemberRef parseSymbol(String symbol) throws Demangler.DemanglingException {
/* 424 */     if ("__cxa_pure_virtual".equals(symbol)) {
/* 425 */       return null;
/*     */     }
/*     */     
/* 428 */     if (Platform.isWindows()) {
/*     */       try {
/* 430 */         Demangler.MemberRef result = (new VC9Demangler(this, symbol)).parseSymbol();
/* 431 */         if (result != null) {
/* 432 */           return result;
/*     */         }
/* 434 */       } catch (Throwable th) {}
/*     */     }
/*     */     
/* 437 */     return (new GCC4Demangler(this, symbol)).parseSymbol();
/*     */   }
/*     */   
/*     */   public static interface SymbolAccepter {
/*     */     boolean accept(Demangler.Symbol param1Symbol);
/*     */   }
/*     */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\bridj-0.7-20140918-2.jar!\org\bridj\NativeLibrary.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */