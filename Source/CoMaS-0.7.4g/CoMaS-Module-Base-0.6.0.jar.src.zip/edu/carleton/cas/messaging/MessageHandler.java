package edu.carleton.cas.messaging;

public interface MessageHandler {
  void handleMessage(Message paramMessage);
}
