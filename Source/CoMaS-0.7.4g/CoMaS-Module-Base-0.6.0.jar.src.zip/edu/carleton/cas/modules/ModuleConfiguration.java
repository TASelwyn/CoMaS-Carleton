package edu.carleton.cas.modules;

public interface ModuleConfiguration {
  String getStringProperty(String paramString);
  
  Object getObjectProperty(String paramString);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\CoMaS-Module-Base-0.6.0.jar!\edu\carleton\cas\modules\ModuleConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */