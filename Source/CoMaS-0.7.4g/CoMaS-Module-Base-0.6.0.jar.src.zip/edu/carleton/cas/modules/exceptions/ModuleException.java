package edu.carleton.cas.modules.exceptions;

public class ModuleException extends Exception {
  private static final long serialVersionUID = 1L;
  
  public ModuleException() {}
  
  public ModuleException(String message, Throwable throwable) {
    super(message, throwable);
  }
}
