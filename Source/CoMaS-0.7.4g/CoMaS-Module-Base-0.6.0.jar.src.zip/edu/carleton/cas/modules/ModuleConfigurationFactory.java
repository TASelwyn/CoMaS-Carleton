package edu.carleton.cas.modules;

public final class ModuleConfigurationFactory {
  private static ModuleConfiguration instance;
  
  public static void setDefault(ModuleConfiguration _instance) {
    instance = _instance;
  }
  
  public static ModuleConfiguration getDefault() {
    return instance;
  }
}
