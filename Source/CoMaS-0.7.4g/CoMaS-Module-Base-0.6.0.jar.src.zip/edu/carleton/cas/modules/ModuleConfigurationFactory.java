/*    */ package edu.carleton.cas.modules;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ModuleConfigurationFactory
/*    */ {
/*    */   private static ModuleConfiguration instance;
/*    */   
/*    */   public static void setDefault(ModuleConfiguration _instance) {
/* 19 */     instance = _instance;
/*    */   }
/*    */   
/*    */   public static ModuleConfiguration getDefault() {
/* 23 */     return instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\CoMaS-Module-Base-0.6.0.jar!\edu\carleton\cas\modules\ModuleConfigurationFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */