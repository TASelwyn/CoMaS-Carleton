package edu.carleton.cas.modules;

import edu.carleton.cas.modules.exceptions.ModuleException;

public interface ModuleManagerInterface extends Bridge {
  Module find(String paramString);
  
  void send(String paramString1, String paramString2, String paramString3) throws ModuleException;
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\CoMaS-Module-Base-0.6.0.jar!\edu\carleton\cas\modules\ModuleManagerInterface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */