package edu.carleton.cas.modules;

public interface Bridge {}
