package edu.carleton.cas.background;

import edu.carleton.cas.modules.Bridge;
import java.util.logging.Level;

public interface Logger extends Bridge {
  void put(Level paramLevel, String paramString);
}
