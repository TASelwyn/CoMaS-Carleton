package edu.carleton.cas.background;

import edu.carleton.cas.modules.Bridge;
import java.util.logging.Level;

public interface Logger extends Bridge {
  void put(Level paramLevel, String paramString);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\CoMaS-Module-Base-0.6.0.jar!\edu\carleton\cas\background\Logger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */