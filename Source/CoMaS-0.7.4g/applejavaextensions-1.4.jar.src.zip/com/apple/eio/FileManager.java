/*    */ package com.apple.eio;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileManager
/*    */ {
/*    */   public static final short kOnAppropriateDisk = -32767;
/*    */   public static final short kSystemDomain = -32766;
/*    */   public static final short kLocalDomain = -32765;
/*    */   public static final short kNetworkDomain = -32764;
/*    */   public static final short kUserDomain = -32763;
/*    */   
/*    */   static RuntimeException unimplemented() {
/* 18 */     return new RuntimeException("Unimplemented");
/*    */   }
/*    */   
/*    */   public static int OSTypeToInt(String paramString) {
/* 22 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public static void setFileTypeAndCreator(String paramString, int paramInt1, int paramInt2) throws IOException {
/* 26 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public static void setFileType(String paramString, int paramInt) throws IOException {
/* 30 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public static void setFileCreator(String paramString, int paramInt) throws IOException {
/* 34 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public static int getFileType(String paramString) throws IOException {
/* 38 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public static int getFileCreator(String paramString) throws IOException {
/* 42 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public static String findFolder(int paramInt) throws FileNotFoundException {
/* 46 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public static String findFolder(short paramShort, int paramInt) throws FileNotFoundException {
/* 50 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public static String findFolder(short paramShort, int paramInt, boolean paramBoolean) throws FileNotFoundException {
/* 54 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static void openURL(String paramString) throws IOException {
/* 59 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public static String getResource(String paramString) throws FileNotFoundException {
/* 63 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public static String getResource(String paramString1, String paramString2) throws FileNotFoundException {
/* 67 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public static String getResource(String paramString1, String paramString2, String paramString3) throws FileNotFoundException {
/* 71 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public static String getPathToApplicationBundle() {
/* 75 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public static boolean moveToTrash(File paramFile) throws FileNotFoundException {
/* 79 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public static boolean revealInFinder(File paramFile) throws FileNotFoundException {
/* 83 */     throw unimplemented();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\applejavaextensions-1.4.jar!\com\apple\eio\FileManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */