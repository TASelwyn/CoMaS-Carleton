package com.apple.eawt;

import java.util.EventListener;

public interface ApplicationListener extends EventListener {
  void handleAbout(ApplicationEvent paramApplicationEvent);
  
  void handleOpenApplication(ApplicationEvent paramApplicationEvent);
  
  void handleOpenFile(ApplicationEvent paramApplicationEvent);
  
  void handlePreferences(ApplicationEvent paramApplicationEvent);
  
  void handlePrintFile(ApplicationEvent paramApplicationEvent);
  
  void handleQuit(ApplicationEvent paramApplicationEvent);
  
  void handleReOpenApplication(ApplicationEvent paramApplicationEvent);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\applejavaextensions-1.4.jar!\com\apple\eawt\ApplicationListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */