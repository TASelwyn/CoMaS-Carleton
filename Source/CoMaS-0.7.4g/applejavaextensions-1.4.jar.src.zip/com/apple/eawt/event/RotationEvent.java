package com.apple.eawt.event;

public class RotationEvent extends GestureEvent {
  RotationEvent(double paramDouble) {
    GestureUtilities.unimplemented();
  }
  
  public double getRotation() {
    GestureUtilities.unimplemented();
    return 0.0D;
  }
}
