package com.apple.eawt.event;

public interface GesturePhaseListener extends GestureListener {
  void gestureBegan(GesturePhaseEvent paramGesturePhaseEvent);
  
  void gestureEnded(GesturePhaseEvent paramGesturePhaseEvent);
}
