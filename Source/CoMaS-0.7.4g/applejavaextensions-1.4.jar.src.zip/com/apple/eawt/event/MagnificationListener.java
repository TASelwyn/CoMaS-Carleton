package com.apple.eawt.event;

public interface MagnificationListener extends GestureListener {
  void magnify(MagnificationEvent paramMagnificationEvent);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\applejavaextensions-1.4.jar!\com\apple\eawt\event\MagnificationListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */