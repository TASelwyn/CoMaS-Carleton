package com.apple.eawt.event;

public abstract class GestureEvent {
  GestureEvent() {
    GestureUtilities.unimplemented();
  }
  
  public void consume() {
    GestureUtilities.unimplemented();
  }
  
  protected boolean isConsumed() {
    GestureUtilities.unimplemented();
    return false;
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\applejavaextensions-1.4.jar!\com\apple\eawt\event\GestureEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */