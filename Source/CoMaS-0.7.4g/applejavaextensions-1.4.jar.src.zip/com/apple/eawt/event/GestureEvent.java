/*    */ package com.apple.eawt.event;
/*    */ 
/*    */ public abstract class GestureEvent {
/*    */   GestureEvent() {
/*  5 */     GestureUtilities.unimplemented();
/*    */   }
/*    */   
/*    */   public void consume() {
/*  9 */     GestureUtilities.unimplemented();
/*    */   }
/*    */   
/*    */   protected boolean isConsumed() {
/* 13 */     GestureUtilities.unimplemented();
/* 14 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\applejavaextensions-1.4.jar!\com\apple\eawt\event\GestureEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */