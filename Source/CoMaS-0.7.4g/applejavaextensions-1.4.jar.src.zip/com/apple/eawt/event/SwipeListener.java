package com.apple.eawt.event;

public interface SwipeListener extends GestureListener {
  void swipedUp(SwipeEvent paramSwipeEvent);
  
  void swipedDown(SwipeEvent paramSwipeEvent);
  
  void swipedLeft(SwipeEvent paramSwipeEvent);
  
  void swipedRight(SwipeEvent paramSwipeEvent);
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\applejavaextensions-1.4.jar!\com\apple\eawt\event\SwipeListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */