package com.apple.eawt.event;

public interface SwipeListener extends GestureListener {
  void swipedUp(SwipeEvent paramSwipeEvent);
  
  void swipedDown(SwipeEvent paramSwipeEvent);
  
  void swipedLeft(SwipeEvent paramSwipeEvent);
  
  void swipedRight(SwipeEvent paramSwipeEvent);
}
