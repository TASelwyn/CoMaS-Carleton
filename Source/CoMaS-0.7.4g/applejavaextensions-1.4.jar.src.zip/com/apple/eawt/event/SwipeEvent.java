/*   */ package com.apple.eawt.event;
/*   */ 
/*   */ public class SwipeEvent
/*   */   extends GestureEvent {
/*   */   SwipeEvent() {
/* 6 */     GestureUtilities.unimplemented();
/*   */   }
/*   */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\applejavaextensions-1.4.jar!\com\apple\eawt\event\SwipeEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */