package com.apple.eawt.event;

public class SwipeEvent extends GestureEvent {
  SwipeEvent() {
    GestureUtilities.unimplemented();
  }
}
