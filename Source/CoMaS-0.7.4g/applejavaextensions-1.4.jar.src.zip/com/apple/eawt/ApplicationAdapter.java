/*    */ package com.apple.eawt;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApplicationAdapter
/*    */   implements ApplicationListener
/*    */ {
/*    */   public void handleAbout(ApplicationEvent paramApplicationEvent) {
/* 10 */     throw Application.unimplemented();
/*    */   }
/*    */   
/*    */   public void handleOpenApplication(ApplicationEvent paramApplicationEvent) {
/* 14 */     throw Application.unimplemented();
/*    */   }
/*    */   
/*    */   public void handleOpenFile(ApplicationEvent paramApplicationEvent) {
/* 18 */     throw Application.unimplemented();
/*    */   }
/*    */   
/*    */   public void handlePreferences(ApplicationEvent paramApplicationEvent) {
/* 22 */     throw Application.unimplemented();
/*    */   }
/*    */   
/*    */   public void handlePrintFile(ApplicationEvent paramApplicationEvent) {
/* 26 */     throw Application.unimplemented();
/*    */   }
/*    */   
/*    */   public void handleQuit(ApplicationEvent paramApplicationEvent) {
/* 30 */     throw Application.unimplemented();
/*    */   }
/*    */   
/*    */   public void handleReOpenApplication(ApplicationEvent paramApplicationEvent) {
/* 34 */     throw Application.unimplemented();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\applejavaextensions-1.4.jar!\com\apple\eawt\ApplicationAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */