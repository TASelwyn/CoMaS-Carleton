/*    */ package com.apple.eawt;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApplicationEvent
/*    */   extends EventObject
/*    */ {
/*    */   ApplicationEvent(Object paramObject) {
/* 12 */     super(paramObject);
/* 13 */     throw Application.unimplemented();
/*    */   }
/*    */   
/*    */   ApplicationEvent(Object paramObject, String paramString) {
/* 17 */     super(paramObject);
/* 18 */     throw Application.unimplemented();
/*    */   }
/*    */   
/*    */   public boolean isHandled() {
/* 22 */     throw Application.unimplemented();
/*    */   }
/*    */   
/*    */   public void setHandled(boolean paramBoolean) {
/* 26 */     throw Application.unimplemented();
/*    */   }
/*    */   
/*    */   public String getFilename() {
/* 30 */     throw Application.unimplemented();
/*    */   }
/*    */ }


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-0.7.4g\!\applejavaextensions-1.4.jar!\com\apple\eawt\ApplicationEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */