package com.apple.eawt;

import java.util.EventObject;

public class ApplicationEvent extends EventObject {
  ApplicationEvent(Object paramObject) {
    super(paramObject);
    throw Application.unimplemented();
  }
  
  ApplicationEvent(Object paramObject, String paramString) {
    super(paramObject);
    throw Application.unimplemented();
  }
  
  public boolean isHandled() {
    throw Application.unimplemented();
  }
  
  public void setHandled(boolean paramBoolean) {
    throw Application.unimplemented();
  }
  
  public String getFilename() {
    throw Application.unimplemented();
  }
}


/* Location:              C:\Users\Thomas\Desktop\Gamer Chair\CoMaS\CoMaS-Launcher-0.7.5\!\applejavaextensions-1.4.jar!\com\apple\eawt\ApplicationEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */