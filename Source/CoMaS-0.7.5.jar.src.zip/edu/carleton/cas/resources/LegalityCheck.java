package edu.carleton.cas.resources;

public interface LegalityCheck {
  boolean isIllegal(String paramString);
}
