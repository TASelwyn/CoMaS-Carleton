package edu.carleton.cas.resources;

public interface ResourceListener {
  void resourceEvent(Resource paramResource, String paramString1, String paramString2);
}
