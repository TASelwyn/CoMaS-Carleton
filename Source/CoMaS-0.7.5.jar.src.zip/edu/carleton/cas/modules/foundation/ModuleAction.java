package edu.carleton.cas.modules.foundation;

public enum ModuleAction {
  init, start, stop;
}
