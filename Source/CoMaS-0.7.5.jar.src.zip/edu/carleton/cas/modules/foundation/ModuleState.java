package edu.carleton.cas.modules.foundation;

public enum ModuleState {
  unknown, init, started, stopped;
}
