package edu.carleton.cas.background;

public interface ControlInterface {
  void start();
  
  void stop();
}
