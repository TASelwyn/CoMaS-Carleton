package edu.carleton.cas.messaging.handlers;

import edu.carleton.cas.messaging.Message;
import edu.carleton.cas.messaging.MessageHandler;

public class PingMessageHandler implements MessageHandler {
  public void handleMessage(Message message) {}
}
