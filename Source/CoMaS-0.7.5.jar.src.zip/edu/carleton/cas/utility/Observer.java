package edu.carleton.cas.utility;

public interface Observer {
  void update(Observable paramObservable, Object paramObject);
}
