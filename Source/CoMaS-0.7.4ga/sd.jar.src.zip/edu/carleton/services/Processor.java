package edu.carleton.services;

public interface Processor {
  void process() throws ProcessingException;
}
