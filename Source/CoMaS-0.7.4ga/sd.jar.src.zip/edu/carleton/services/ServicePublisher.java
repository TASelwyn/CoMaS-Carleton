package edu.carleton.services;

import edu.carleton.encryption.AES;
import java.io.Closeable;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.StandardProtocolFamily;
import java.net.StandardSocketOptions;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.nio.channels.MembershipKey;
import java.util.Enumeration;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;

public class ServicePublisher implements Processor, Closeable {
  private String name;
  
  private ServiceUtility.ProcessorThread reader;
  
  private InetSocketAddress inetSocketAddress;
  
  private DatagramChannel datagramChannel;
  
  private MembershipKey membershipKey;
  
  private DatagramChannel datagramChannelPublish;
  
  private ConcurrentHashMap<String, String> map;
  
  private CopyOnWriteArraySet<Subscriber> subscribers;
  
  public ServicePublisher(String name) throws SocketException, IOException {
    this(name, ServiceUtility.MULTICAST_IP, ServiceUtility.findInterface(), ServiceUtility.MULTICAST_PORT);
  }
  
  ServicePublisher(String name, String ip, String iface, int port) throws SocketException, IOException {
    this.name = name.toLowerCase().trim();
    this.map = new ConcurrentHashMap<>();
    this.subscribers = new CopyOnWriteArraySet<>();
    open(ip, iface, port);
    openPublish(ip, iface, port - 1);
    ServiceUtility.closeOnExit(this);
  }
  
  private void open(String ip, String iface, int port) throws IOException {
    this.datagramChannel = DatagramChannel.open(StandardProtocolFamily.INET);
    NetworkInterface networkInterface = NetworkInterface.getByName(iface);
    this.datagramChannel.setOption(StandardSocketOptions.SO_REUSEADDR, Boolean.valueOf(true));
    this.datagramChannel.bind(new InetSocketAddress(port));
    this.datagramChannel.setOption(StandardSocketOptions.IP_MULTICAST_IF, networkInterface);
    this.datagramChannel.configureBlocking(true);
    InetAddress inetAddress = InetAddress.getByName(ip);
    this.membershipKey = this.datagramChannel.join(inetAddress, networkInterface);
    this.reader = new ServiceUtility.ProcessorThread(this);
    this.reader.start();
  }
  
  public void openPublish(String ip, String iface, int port) throws IOException {
    this.datagramChannelPublish = DatagramChannel.open();
    this.datagramChannelPublish.bind((SocketAddress)null);
    NetworkInterface networkInterface = NetworkInterface.getByName(iface);
    this.datagramChannelPublish.setOption(StandardSocketOptions.IP_MULTICAST_IF, networkInterface);
    this.inetSocketAddress = new InetSocketAddress(ip, port);
  }
  
  public void close() throws IOException {
    this.reader.close();
    this.reader.interrupt();
    this.membershipKey.drop();
    if (this.datagramChannel.isOpen())
      this.datagramChannel.close(); 
    unpublishAll();
    if (this.datagramChannelPublish.isOpen())
      this.datagramChannelPublish.close(); 
  }
  
  public void send(String message) throws IOException {
    String encryptedMessage = AES.encrypt(message);
    ByteBuffer byteBuffer = ByteBuffer.wrap(encryptedMessage.getBytes("UTF-8"));
    this.datagramChannelPublish.send(byteBuffer, this.inetSocketAddress);
  }
  
  private String read() throws IOException {
    ByteBuffer byteBuffer = ByteBuffer.allocate(1024);
    this.datagramChannel.receive(byteBuffer);
    byteBuffer.flip();
    byte[] bytes = new byte[byteBuffer.limit()];
    byteBuffer.get(bytes, 0, byteBuffer.limit());
    return new String(bytes);
  }
  
  public void process() throws ProcessingException {
    String msg = null;
    String encryptedMessage = null;
    try {
      encryptedMessage = read();
      encryptedMessage = encryptedMessage.trim();
      msg = AES.decrypt(encryptedMessage);
      if (ServiceUtility.DEBUG)
        System.out.println("ServicePublisher: [" + msg + "]"); 
    } catch (IOException e) {
      throw new ProcessingException(e.getMessage());
    } 
    String[] fields = msg.split(ServiceUtility.DELIMETER);
    int port = 0;
    if (fields == null)
      throw new ProcessingException("Unknown message format: " + msg); 
    if (fields.length != 4)
      throw new ProcessingException("Illegal number of fields: " + fields.length); 
    try {
      port = Integer.valueOf(fields[3]).intValue();
    } catch (NumberFormatException e) {
      throw new ProcessingException("Illegal port field value: " + fields[3]);
    } 
    try {
      if (fields[0].equals("subscribe")) {
        subscribe(fields[1], fields[2], port);
      } else if (fields[0].equals("unsubscribe")) {
        unsubscribe(fields[1], fields[2], port);
      } 
    } catch (IOException e) {
      throw new ProcessingException(e.getMessage());
    } 
  }
  
  private void unpublishAll() throws IOException {
    Enumeration<String> keys = this.map.keys();
    while (keys.hasMoreElements()) {
      String service = keys.nextElement();
      String endpoint = this.map.get(service);
      unpublish(service, endpoint);
    } 
  }
  
  public void publish(String service, String endpoint) throws IOException {
    this.map.put(service, endpoint);
    send("added" + ServiceUtility.DELIMETER + this.name + "." + service + ServiceUtility.DELIMETER + endpoint);
  }
  
  public void unpublish(String service, String endpoint) throws IOException {
    send("removed" + ServiceUtility.DELIMETER + this.name + "." + service + ServiceUtility.DELIMETER + endpoint);
    this.map.remove(service);
  }
  
  private Subscriber get(String ipAddress, int port) throws SocketException, UnknownHostException {
    Subscriber subscriber = new Subscriber(ipAddress, port);
    for (Subscriber client : this.subscribers) {
      if (client.equals(subscriber))
        return client; 
    } 
    return subscriber;
  }
  
  public void subscribe(String service, String ipAddress, int port) throws SocketException, UnknownHostException {
    String endpoint = this.map.get(service);
    Subscriber subscriber = get(ipAddress, port);
    subscriber.open();
    subscriber.update(service, 3, endpoint);
    if (!subscriber.isClosed() && 
      !this.subscribers.contains(subscriber))
      this.subscribers.add(subscriber); 
  }
  
  public void unsubscribe(String service, String ipAddress, int port) throws SocketException, UnknownHostException {
    String endpoint = this.map.get(service);
    Subscriber subscriber = get(ipAddress, port);
    Subscriber toRemove = null;
    for (Subscriber c : this.subscribers) {
      if (c.equals(subscriber)) {
        c.update(service, 4, endpoint);
        if (!c.isSubscribed())
          toRemove = c; 
      } 
    } 
    this.subscribers.remove(toRemove);
  }
  
  public static void main(String[] args) throws SocketException, IOException {
    ServicePublisher sp = new ServicePublisher("test-comas");
    sp.publish("test", "https://sikaman.dyndns.org:8443/CMS/rest/index.jade");
    sp.close();
  }
  
  private class Subscriber {
    CopyOnWriteArraySet<String> services;
    
    DatagramSocket socket;
    
    InetAddress address;
    
    int port;
    
    public Subscriber(String ipAddress, int port) throws SocketException, UnknownHostException {
      this.address = InetAddress.getByName(ipAddress);
      this.port = port;
      this.services = new CopyOnWriteArraySet<>();
    }
    
    public void open() throws SocketException {
      if (this.socket == null)
        this.socket = new DatagramSocket(); 
    }
    
    public synchronized void update(String service, int action, String endpoint) {
      if (isSubscribedTo(service)) {
        if (action == 2 || action == 4) {
          send("removed" + ServiceUtility.DELIMETER + ServicePublisher.this.name + "." + service + ServiceUtility.DELIMETER + endpoint);
          unsubscribe(service);
        } 
      } else if (action == 3 || action == 1) {
        if (endpoint != null)
          send("added" + ServiceUtility.DELIMETER + ServicePublisher.this.name + "." + service + ServiceUtility.DELIMETER + endpoint); 
        subscribe(service);
      } 
    }
    
    public void send(String message) {
      try {
        String encryptedMessage = AES.encrypt(message);
        if (ServiceUtility.DEBUG)
          System.out.println("ServicePublisher send: [" + encryptedMessage + "]"); 
        byte[] msg = encryptedMessage.getBytes("UTF-8");
        DatagramPacket packet = new DatagramPacket(msg, msg.length, this.address, this.port);
        this.socket.send(packet);
      } catch (IOException e) {
        close();
      } 
    }
    
    public void close() {
      if (this.socket != null)
        this.socket.close(); 
    }
    
    public void subscribe(String service) {
      if (this.services.contains(service))
        return; 
      this.services.add(service);
    }
    
    public void unsubscribe(String service) {
      if (service.equals("*")) {
        this.services.clear();
      } else {
        this.services.remove(service);
      } 
      if (!isSubscribed())
        close(); 
    }
    
    public boolean isSubscribedTo(String service) {
      if (service.equals("*"))
        return true; 
      return this.services.contains(service);
    }
    
    public boolean isClosed() {
      if (this.socket == null)
        return true; 
      return this.socket.isClosed();
    }
    
    public boolean isSubscribed() {
      return (!this.services.isEmpty() && !isClosed());
    }
    
    public boolean equals(Subscriber subscriber) {
      return (this.address.getHostAddress().equals(subscriber.address.getHostAddress()) && this.port == subscriber.port);
    }
    
    public String toString() {
      return String.valueOf(this.address.getHostAddress()) + ":" + this.port + " " + this.services;
    }
  }
}
