package com.intel.bluetooth;

import java.io.IOException;

public interface BluetoothStackExtension {
  int readRemoteDeviceRSSI(long paramLong) throws IOException;
}
