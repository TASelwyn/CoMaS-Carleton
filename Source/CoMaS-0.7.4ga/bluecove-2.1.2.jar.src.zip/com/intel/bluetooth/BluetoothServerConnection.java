package com.intel.bluetooth;

public interface BluetoothServerConnection {}
