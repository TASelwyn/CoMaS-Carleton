package com.intel.bluetooth;

class ThreadLocalWrapper {
  static boolean java11 = false;
  
  private Object threadLocal;
  
  private Object java11Object;
  
  ThreadLocalWrapper() {
    if (java11)
      return; 
    try {
      this.threadLocal = new ThreadLocal();
    } catch (Throwable ejava11) {
      java11 = true;
    } 
  }
  
  public Object get() {
    if (java11)
      return this.java11Object; 
    return ((ThreadLocal)this.threadLocal).get();
  }
  
  public void set(Object value) {
    if (java11) {
      this.java11Object = value;
    } else {
      ((ThreadLocal)this.threadLocal).set(value);
    } 
  }
}
