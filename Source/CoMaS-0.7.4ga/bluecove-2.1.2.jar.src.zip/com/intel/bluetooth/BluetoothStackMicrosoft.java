package com.intel.bluetooth;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.bluetooth.BluetoothConnectionException;
import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DataElement;
import javax.bluetooth.DeviceClass;
import javax.bluetooth.DiscoveryListener;
import javax.bluetooth.RemoteDevice;
import javax.bluetooth.ServiceRecord;
import javax.bluetooth.ServiceRegistrationException;
import javax.bluetooth.UUID;

class BluetoothStackMicrosoft implements BluetoothStack {
  private static final int BTH_MODE_POWER_OFF = 1;
  
  private static final int BTH_MODE_CONNECTABLE = 2;
  
  private static final int BTH_MODE_DISCOVERABLE = 3;
  
  private static BluetoothStackMicrosoft singleInstance = null;
  
  private boolean peerInitialized = false;
  
  private boolean windowsCE;
  
  private long localBluetoothAddress = 0L;
  
  private DiscoveryListener currentDeviceDiscoveryListener;
  
  private Thread limitedDiscoverableTimer;
  
  private static final int ATTR_RETRIEVABLE_MAX = 256;
  
  private Hashtable deviceDiscoveryDevices;
  
  private static int connectThreadNumber;
  
  private static synchronized int nextConnectThreadNum() {
    return connectThreadNumber++;
  }
  
  public String getStackID() {
    return "winsock";
  }
  
  public BluetoothStack.LibraryInformation[] requireNativeLibraries() {
    return BluetoothStack.LibraryInformation.library("intelbth");
  }
  
  public String toString() {
    return getStackID();
  }
  
  public void initialize() throws BluetoothStateException {
    if (singleInstance != null)
      throw new BluetoothStateException("Only one instance of " + getStackID() + " stack supported"); 
    try {
      int status = initializationStatus();
      DebugLog.debug("initializationStatus", status);
      if (status == 1)
        this.peerInitialized = true; 
      this.windowsCE = isWindowsCE();
      singleInstance = this;
    } catch (BluetoothStateException e) {
      throw e;
    } catch (IOException e) {
      DebugLog.fatal("initialization", e);
      throw new BluetoothStateException(e.getMessage());
    } 
  }
  
  public void destroy() {
    if (singleInstance != this)
      throw new RuntimeException("Destroy invalid instance"); 
    if (this.peerInitialized) {
      this.peerInitialized = false;
      uninitialize();
    } 
    cancelLimitedDiscoverableTimer();
    singleInstance = null;
  }
  
  private void initialized() throws BluetoothStateException {
    if (!this.peerInitialized)
      throw new BluetoothStateException("Bluetooth system is unavailable"); 
  }
  
  public int getFeatureSet() {
    return 0x2 | (this.windowsCE ? 0 : 4);
  }
  
  public String getLocalDeviceBluetoothAddress() {
    try {
      long socket = socket(false, false);
      bind(socket);
      this.localBluetoothAddress = getsockaddress(socket);
      String address = RemoteDeviceHelper.getBluetoothAddress(this.localBluetoothAddress);
      storesockopt(socket);
      close(socket);
      return address;
    } catch (IOException e) {
      DebugLog.error("get local bluetoothAddress", e);
      return "000000000000";
    } 
  }
  
  public String getLocalDeviceName() {
    if (this.localBluetoothAddress == 0L)
      getLocalDeviceBluetoothAddress(); 
    return getradioname(this.localBluetoothAddress);
  }
  
  public String getRemoteDeviceFriendlyName(long address) throws IOException {
    return getpeername(address);
  }
  
  public DeviceClass getLocalDeviceClass() {
    return new DeviceClass(getDeviceClass(this.localBluetoothAddress));
  }
  
  public void setLocalDeviceServiceClasses(int classOfDevice) {}
  
  private void cancelLimitedDiscoverableTimer() {
    if (this.limitedDiscoverableTimer != null) {
      this.limitedDiscoverableTimer.interrupt();
      this.limitedDiscoverableTimer = null;
    } 
  }
  
  public boolean setLocalDeviceDiscoverable(int mode) throws BluetoothStateException {
    switch (mode) {
      case 0:
        cancelLimitedDiscoverableTimer();
        DebugLog.debug("setDiscoverable(false)");
        setDiscoverable(false);
        return (0 == getLocalDeviceDiscoverable());
      case 10390323:
        cancelLimitedDiscoverableTimer();
        DebugLog.debug("setDiscoverable(true)");
        setDiscoverable(true);
        return (10390323 == getLocalDeviceDiscoverable());
      case 10390272:
        cancelLimitedDiscoverableTimer();
        DebugLog.debug("setDiscoverable(LIAC)");
        setDiscoverable(true);
        if (10390323 != getLocalDeviceDiscoverable())
          return false; 
        this.limitedDiscoverableTimer = Utils.schedule(60000L, new Runnable(this) {
              private final BluetoothStackMicrosoft this$0;
              
              public void run() {
                try {
                  this.this$0.setDiscoverable(false);
                } catch (BluetoothStateException e) {
                  DebugLog.debug("error setDiscoverable", (Throwable)e);
                } finally {
                  this.this$0.limitedDiscoverableTimer = null;
                } 
              }
            });
        return true;
    } 
    return false;
  }
  
  public boolean isLocalDevicePowerOn() {
    int mode = getBluetoothRadioMode();
    if (mode == 1)
      return false; 
    return (mode == 2 || mode == 3);
  }
  
  public int getLocalDeviceDiscoverable() {
    int mode = getBluetoothRadioMode();
    if (mode == 3) {
      if (this.limitedDiscoverableTimer != null) {
        DebugLog.debug("Discoverable = LIAC");
        return 10390272;
      } 
      DebugLog.debug("Discoverable = GIAC");
      return 10390323;
    } 
    DebugLog.debug("Discoverable = NOT_DISCOVERABLE");
    return 0;
  }
  
  public String getLocalDeviceProperty(String property) {
    if ("bluetooth.connected.devices.max".equals(property))
      return "7"; 
    if ("bluetooth.sd.trans.max".equals(property))
      return "7"; 
    if ("bluetooth.connected.inquiry.scan".equals(property))
      return "true"; 
    if ("bluetooth.connected.page.scan".equals(property))
      return "true"; 
    if ("bluetooth.connected.inquiry".equals(property))
      return "true"; 
    if ("bluetooth.connected.page".equals(property))
      return "true"; 
    if ("bluetooth.sd.attr.retrievable.max".equals(property))
      return String.valueOf(256); 
    if ("bluetooth.master.switch".equals(property))
      return "false"; 
    if ("bluetooth.l2cap.receiveMTU.max".equals(property))
      return "0"; 
    if ("bluecove.radio.version".equals(property))
      return String.valueOf(getDeviceVersion(this.localBluetoothAddress)); 
    if ("bluecove.radio.manufacturer".equals(property))
      return String.valueOf(getDeviceManufacturer(this.localBluetoothAddress)); 
    return null;
  }
  
  public boolean isCurrentThreadInterruptedCallback() {
    return UtilsJavaSE.isCurrentThreadInterrupted();
  }
  
  public RemoteDevice[] retrieveDevices(int option) {
    if (this.windowsCE)
      return null; 
    Vector devices = new Vector();
    RetrieveDevicesCallback retrieveDevicesCallback = new RetrieveDevicesCallback(this, devices) {
        private final Vector val$devices;
        
        private final BluetoothStackMicrosoft this$0;
        
        public void deviceFoundCallback(long deviceAddr, int deviceClass, String deviceName, boolean paired) {
          DebugLog.debug("device found", deviceAddr);
          RemoteDevice remoteDevice = RemoteDeviceHelper.createRemoteDevice(this.this$0, deviceAddr, deviceName, paired);
          this.val$devices.add(remoteDevice);
        }
      };
    if (retrieveDevicesImpl(option, retrieveDevicesCallback))
      return RemoteDeviceHelper.remoteDeviceListToArray(devices); 
    return null;
  }
  
  public Boolean isRemoteDeviceTrusted(long address) {
    if (this.windowsCE)
      return null; 
    return new Boolean(isRemoteDeviceTrustedImpl(address));
  }
  
  public Boolean isRemoteDeviceAuthenticated(long address) {
    if (this.windowsCE)
      return null; 
    return new Boolean(isRemoteDeviceAuthenticatedImpl(address));
  }
  
  public boolean authenticateRemoteDevice(long address) throws IOException {
    return authenticateRemoteDeviceImpl(address, null);
  }
  
  public boolean authenticateRemoteDevice(long address, String passkey) throws IOException {
    return authenticateRemoteDeviceImpl(address, passkey);
  }
  
  public void removeAuthenticationWithRemoteDevice(long address) throws IOException {
    removeAuthenticationWithRemoteDeviceImpl(address);
  }
  
  public boolean startInquiry(int accessCode, DiscoveryListener listener) throws BluetoothStateException {
    initialized();
    if (this.currentDeviceDiscoveryListener != null)
      throw new BluetoothStateException("Another inquiry already running"); 
    this.currentDeviceDiscoveryListener = listener;
    DeviceInquiryRunnable inquiryRunnable = new DeviceInquiryRunnable(this) {
        private final BluetoothStackMicrosoft this$0;
        
        public int runDeviceInquiry(DeviceInquiryThread inquiryThread, int accessCode, DiscoveryListener listener) throws BluetoothStateException {
          try {
            this.this$0.deviceDiscoveryDevices = new Hashtable();
            int discType = this.this$0.runDeviceInquiryImpl(this, inquiryThread, accessCode, DeviceInquiryThread.getConfigDeviceInquiryDuration(), listener);
            if (discType == 0)
              for (Enumeration en = this.this$0.deviceDiscoveryDevices.keys(); en.hasMoreElements(); ) {
                RemoteDevice remoteDevice = en.nextElement();
                DeviceClass deviceClass = (DeviceClass)this.this$0.deviceDiscoveryDevices.get(remoteDevice);
                listener.deviceDiscovered(remoteDevice, deviceClass);
                if (this.this$0.currentDeviceDiscoveryListener == null)
                  return 5; 
              }  
            return discType;
          } finally {
            this.this$0.deviceDiscoveryDevices = null;
            this.this$0.currentDeviceDiscoveryListener = null;
          } 
        }
        
        public void deviceDiscoveredCallback(DiscoveryListener listener, long deviceAddr, int deviceClass, String deviceName, boolean paired) {
          RemoteDevice remoteDevice = RemoteDeviceHelper.createRemoteDevice(this.this$0, deviceAddr, deviceName, paired);
          if (this.this$0.currentDeviceDiscoveryListener == null || this.this$0.deviceDiscoveryDevices == null || this.this$0.currentDeviceDiscoveryListener != listener)
            return; 
          DeviceClass cod = new DeviceClass(deviceClass);
          DebugLog.debug("deviceDiscoveredCallback address", remoteDevice.getBluetoothAddress());
          DebugLog.debug("deviceDiscoveredCallback deviceClass", cod);
          this.this$0.deviceDiscoveryDevices.put(remoteDevice, cod);
        }
      };
    return DeviceInquiryThread.startInquiry(this, inquiryRunnable, accessCode, listener);
  }
  
  public boolean cancelInquiry(DiscoveryListener listener) {
    if (this.currentDeviceDiscoveryListener != listener)
      return false; 
    this.currentDeviceDiscoveryListener = null;
    return cancelInquiry();
  }
  
  public int searchServices(int[] attrSet, UUID[] uuidSet, RemoteDevice device, DiscoveryListener listener) throws BluetoothStateException {
    SearchServicesRunnable searchRunnable = new SearchServicesRunnable(this) {
        private final BluetoothStackMicrosoft this$0;
        
        public int runSearchServices(SearchServicesThread sst, int[] attrSet, UUID[] uuidSet, RemoteDevice device, DiscoveryListener listener) throws BluetoothStateException {
          int[] handles;
          sst.searchServicesStartedCallback();
          try {
            handles = this.this$0.runSearchServicesImpl(uuidSet, RemoteDeviceHelper.getAddress(device));
          } catch (SearchServicesDeviceNotReachableException e) {
            return 6;
          } catch (SearchServicesTerminatedException e) {
            return 2;
          } catch (SearchServicesException e) {
            return 3;
          } 
          if (handles == null)
            return 3; 
          if (handles.length > 0) {
            ServiceRecordImpl[] arrayOfServiceRecordImpl = new ServiceRecordImpl[handles.length];
            int[] requiredAttrIDs = { 0, 1, 2, 3, 4 };
            boolean hasError = false;
            for (int i = 0; i < handles.length; i++) {
              arrayOfServiceRecordImpl[i] = new ServiceRecordImpl(this.this$0, device, handles[i]);
              try {
                arrayOfServiceRecordImpl[i].populateRecord(requiredAttrIDs);
                if (attrSet != null)
                  arrayOfServiceRecordImpl[i].populateRecord(attrSet); 
              } catch (Exception e) {
                DebugLog.debug("populateRecord error", e);
                hasError = true;
              } 
              if (sst.isTerminated())
                return 2; 
            } 
            listener.servicesDiscovered(sst.getTransID(), (ServiceRecord[])arrayOfServiceRecordImpl);
            if (hasError)
              return 3; 
            return 1;
          } 
          return 4;
        }
      };
    return SearchServicesThread.startSearchServices(this, searchRunnable, attrSet, uuidSet, device, listener);
  }
  
  public boolean cancelServiceSearch(int transID) {
    SearchServicesThread sst = SearchServicesThread.getServiceSearchThread(transID);
    if (sst != null)
      return sst.setTerminated(); 
    return false;
  }
  
  public boolean populateServicesRecordAttributeValues(ServiceRecordImpl serviceRecord, int[] attrIDs) throws IOException {
    if (attrIDs.length > 256)
      throw new IllegalArgumentException(); 
    byte[] blob = getServiceAttributes(attrIDs, RemoteDeviceHelper.getAddress(serviceRecord.getHostDevice()), (int)serviceRecord.getHandle());
    if (blob.length > 0)
      try {
        boolean anyRetrived = false;
        DataElement element = (new SDPInputStream(new ByteArrayInputStream(blob))).readElement();
        for (Enumeration e = (Enumeration)element.getValue(); e.hasMoreElements(); ) {
          int attrID = (int)((DataElement)e.nextElement()).getLong();
          serviceRecord.populateAttributeValue(attrID, e.nextElement());
          if (!anyRetrived)
            for (int i = 0; i < attrIDs.length; i++) {
              if (attrIDs[i] == attrID) {
                anyRetrived = true;
                break;
              } 
            }  
        } 
        return anyRetrived;
      } catch (IOException e) {
        throw e;
      } catch (Throwable e) {
        throw new IOException();
      }  
    return false;
  }
  
  private class ConnectThread extends Thread {
    final Object event;
    
    final long socket;
    
    final BluetoothConnectionParams params;
    
    final int retryUnreachable;
    
    volatile IOException error;
    
    volatile boolean success;
    
    volatile boolean connecting;
    
    private final BluetoothStackMicrosoft this$0;
    
    ConnectThread(BluetoothStackMicrosoft this$0, Object event, long socket, BluetoothConnectionParams params) {
      super("ConnectThread-" + BluetoothStackMicrosoft.nextConnectThreadNum());
      this.this$0 = this$0;
      this.success = false;
      this.connecting = true;
      this.event = event;
      this.socket = socket;
      this.params = params;
      this.retryUnreachable = BlueCoveImpl.getConfigProperty("bluecove.connect.unreachable_retry", 2);
    }
    
    public void run() {
      try {
        this.this$0.connect(this.socket, this.params.address, this.params.channel, this.retryUnreachable);
        this.success = true;
      } catch (IOException e) {
        this.error = e;
      } finally {
        this.connecting = false;
        synchronized (this.event) {
          this.event.notifyAll();
        } 
      } 
    }
  }
  
  public long connectionRfOpenClientConnection(BluetoothConnectionParams params) throws IOException {
    long socket = socket(params.authenticate, params.encrypt);
    Object event = new Object();
    ConnectThread connectThread = new ConnectThread(this, event, socket, params);
    UtilsJavaSE.threadSetDaemon(connectThread);
    boolean timeoutHappend = false;
    synchronized (event) {
      connectThread.start();
      while (connectThread.connecting) {
        try {
          if (params.timeouts) {
            event.wait(params.timeout);
            timeoutHappend = connectThread.connecting;
            connectThread.interrupt();
            break;
          } 
          event.wait();
        } catch (InterruptedException e) {
          try {
            close(socket);
          } catch (Exception ignore) {}
          throw new InterruptedIOException();
        } 
      } 
    } 
    if (!connectThread.success)
      try {
        close(socket);
      } catch (Exception ignore) {} 
    if (connectThread.error != null)
      throw connectThread.error; 
    if (!connectThread.success) {
      if (timeoutHappend)
        throw new BluetoothConnectionException(5); 
      throw new BluetoothConnectionException(4);
    } 
    return socket;
  }
  
  public void connectionRfCloseClientConnection(long handle) throws IOException {
    close(handle);
  }
  
  public long rfServerOpen(BluetoothConnectionNotifierParams params, ServiceRecordImpl serviceRecord) throws IOException {
    long socket = socket(params.authenticate, params.encrypt);
    boolean success = false;
    try {
      synchronized (this) {
        bind(socket);
      } 
      listen(socket);
      int channel = getsockchannel(socket);
      DebugLog.debug("service channel ", channel);
      long serviceRecordHandle = socket;
      serviceRecord.populateRFCOMMAttributes(serviceRecordHandle, channel, params.uuid, params.name, params.obex);
      serviceRecord.setHandle(registerService(serviceRecord.toByteArray(), serviceRecord.deviceServiceClasses));
      success = true;
    } finally {
      if (!success)
        try {
          close(socket);
        } catch (IOException e) {
          DebugLog.debug("close on failure", e);
        }  
    } 
    return socket;
  }
  
  public void rfServerClose(long handle, ServiceRecordImpl serviceRecord) throws IOException {
    try {
      close(handle);
    } finally {
      unregisterService(serviceRecord.getHandle());
    } 
  }
  
  public long rfServerAcceptAndOpenRfServerConnection(long handle) throws IOException {
    return accept(handle);
  }
  
  public void rfServerUpdateServiceRecord(long handle, ServiceRecordImpl serviceRecord, boolean acceptAndOpen) throws ServiceRegistrationException {
    byte[] blob;
    unregisterService(serviceRecord.getHandle());
    try {
      blob = serviceRecord.toByteArray();
    } catch (IOException e) {
      throw new ServiceRegistrationException(e.toString());
    } 
    serviceRecord.setHandle(registerService(blob, serviceRecord.deviceServiceClasses));
    DebugLog.debug("new serviceRecord", serviceRecord);
  }
  
  public void connectionRfCloseServerConnection(long handle) throws IOException {
    connectionRfCloseClientConnection(handle);
  }
  
  public long getConnectionRfRemoteAddress(long handle) throws IOException {
    return getpeeraddress(handle);
  }
  
  public int connectionRfRead(long handle) throws IOException {
    return recv(handle);
  }
  
  public int connectionRfRead(long handle, byte[] b, int off, int len) throws IOException {
    return recv(handle, b, off, len);
  }
  
  public int connectionRfReadAvailable(long handle) throws IOException {
    return recvAvailable(handle);
  }
  
  public void connectionRfWrite(long handle, int b) throws IOException {
    send(handle, b);
  }
  
  public void connectionRfWrite(long handle, byte[] b, int off, int len) throws IOException {
    send(handle, b, off, len);
  }
  
  public void connectionRfFlush(long handle) throws IOException {}
  
  public int rfGetSecurityOpt(long handle, int expected) throws IOException {
    return expected;
  }
  
  public boolean rfEncrypt(long address, long handle, boolean on) throws IOException {
    return false;
  }
  
  public long l2OpenClientConnection(BluetoothConnectionParams params, int receiveMTU, int transmitMTU) throws IOException {
    throw new NotSupportedIOException(getStackID());
  }
  
  public void l2CloseClientConnection(long handle) throws IOException {
    throw new NotSupportedIOException(getStackID());
  }
  
  public long l2ServerOpen(BluetoothConnectionNotifierParams params, int receiveMTU, int transmitMTU, ServiceRecordImpl serviceRecord) throws IOException {
    throw new NotSupportedIOException(getStackID());
  }
  
  public void l2ServerUpdateServiceRecord(long handle, ServiceRecordImpl serviceRecord, boolean acceptAndOpen) throws ServiceRegistrationException {
    throw new ServiceRegistrationException("Not Supported on" + getStackID());
  }
  
  public long l2ServerAcceptAndOpenServerConnection(long handle) throws IOException {
    throw new NotSupportedIOException(getStackID());
  }
  
  public void l2CloseServerConnection(long handle) throws IOException {
    throw new NotSupportedIOException(getStackID());
  }
  
  public void l2ServerClose(long handle, ServiceRecordImpl serviceRecord) throws IOException {
    throw new NotSupportedIOException(getStackID());
  }
  
  public int l2GetSecurityOpt(long handle, int expected) throws IOException {
    throw new NotSupportedIOException(getStackID());
  }
  
  public boolean l2Ready(long handle) throws IOException {
    throw new NotSupportedIOException(getStackID());
  }
  
  public int l2Receive(long handle, byte[] inBuf) throws IOException {
    throw new NotSupportedIOException(getStackID());
  }
  
  public void l2Send(long handle, byte[] data, int transmitMTU) throws IOException {
    throw new NotSupportedIOException(getStackID());
  }
  
  public int l2GetReceiveMTU(long handle) throws IOException {
    throw new NotSupportedIOException(getStackID());
  }
  
  public int l2GetTransmitMTU(long handle) throws IOException {
    throw new NotSupportedIOException(getStackID());
  }
  
  public long l2RemoteAddress(long handle) throws IOException {
    throw new NotSupportedIOException(getStackID());
  }
  
  public boolean l2Encrypt(long address, long handle, boolean on) throws IOException {
    throw new NotSupportedIOException(getStackID());
  }
  
  public native boolean isNativeCodeLoaded();
  
  public native int getLibraryVersion();
  
  public native int detectBluetoothStack();
  
  public native void enableNativeDebug(Class paramClass, boolean paramBoolean);
  
  private static native int initializationStatus() throws IOException;
  
  private native void uninitialize();
  
  private native boolean isWindowsCE();
  
  private native int getDeviceClass(long paramLong);
  
  private native void setDiscoverable(boolean paramBoolean) throws BluetoothStateException;
  
  private native int getBluetoothRadioMode();
  
  private native String getradioname(long paramLong);
  
  private native int getDeviceVersion(long paramLong);
  
  private native int getDeviceManufacturer(long paramLong);
  
  private native boolean retrieveDevicesImpl(int paramInt, RetrieveDevicesCallback paramRetrieveDevicesCallback);
  
  private native boolean isRemoteDeviceTrustedImpl(long paramLong);
  
  private native boolean isRemoteDeviceAuthenticatedImpl(long paramLong);
  
  private native boolean authenticateRemoteDeviceImpl(long paramLong, String paramString) throws IOException;
  
  private native void removeAuthenticationWithRemoteDeviceImpl(long paramLong) throws IOException;
  
  private native int runDeviceInquiryImpl(DeviceInquiryRunnable paramDeviceInquiryRunnable, DeviceInquiryThread paramDeviceInquiryThread, int paramInt1, int paramInt2, DiscoveryListener paramDiscoveryListener) throws BluetoothStateException;
  
  private native boolean cancelInquiry();
  
  private native int[] runSearchServicesImpl(UUID[] paramArrayOfUUID, long paramLong) throws SearchServicesException;
  
  public native byte[] getServiceAttributes(int[] paramArrayOfint, long paramLong, int paramInt) throws IOException;
  
  private native long socket(boolean paramBoolean1, boolean paramBoolean2) throws IOException;
  
  private native long getsockaddress(long paramLong) throws IOException;
  
  private native void storesockopt(long paramLong);
  
  private native int getsockchannel(long paramLong) throws IOException;
  
  private native void connect(long paramLong1, long paramLong2, int paramInt1, int paramInt2) throws IOException;
  
  private native void bind(long paramLong) throws IOException;
  
  private native void listen(long paramLong) throws IOException;
  
  private native long accept(long paramLong) throws IOException;
  
  private native int recvAvailable(long paramLong) throws IOException;
  
  private native int recv(long paramLong) throws IOException;
  
  private native int recv(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
  
  private native void send(long paramLong, int paramInt) throws IOException;
  
  private native void send(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
  
  private native void close(long paramLong) throws IOException;
  
  private native String getpeername(long paramLong) throws IOException;
  
  private native long getpeeraddress(long paramLong) throws IOException;
  
  private native long registerService(byte[] paramArrayOfbyte, int paramInt) throws ServiceRegistrationException;
  
  private native void unregisterService(long paramLong) throws ServiceRegistrationException;
}
