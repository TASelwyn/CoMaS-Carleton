package com.intel.bluetooth;

public class NotSupportedRuntimeException extends RuntimeException {
  private static final long serialVersionUID = 1L;
  
  public NotSupportedRuntimeException() {
    super("Not Supported");
  }
  
  public NotSupportedRuntimeException(String stackName) {
    super("Not Supported on " + stackName);
  }
}
