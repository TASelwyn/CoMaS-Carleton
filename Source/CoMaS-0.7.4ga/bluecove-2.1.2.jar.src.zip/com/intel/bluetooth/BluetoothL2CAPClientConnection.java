package com.intel.bluetooth;

import java.io.IOException;

class BluetoothL2CAPClientConnection extends BluetoothL2CAPConnection {
  public BluetoothL2CAPClientConnection(BluetoothStack bluetoothStack, BluetoothConnectionParams params, int receiveMTU, int transmitMTU) throws IOException {
    super(bluetoothStack, bluetoothStack.l2OpenClientConnection(params, receiveMTU, transmitMTU));
    boolean initOK = false;
    try {
      this.securityOpt = bluetoothStack.l2GetSecurityOpt(this.handle, Utils.securityOpt(params.authenticate, params.encrypt));
      this.transmitMTU = getTransmitMTU();
      if (transmitMTU > 0 && transmitMTU < this.transmitMTU)
        this.transmitMTU = transmitMTU; 
      RemoteDeviceHelper.connected(this);
      initOK = true;
    } finally {
      if (!initOK)
        try {
          bluetoothStack.l2CloseClientConnection(this.handle);
        } catch (IOException e) {
          DebugLog.error("close error", e);
        }  
    } 
  }
  
  void closeConnectionHandle(long handle) throws IOException {
    RemoteDeviceHelper.disconnected(this);
    this.bluetoothStack.l2CloseClientConnection(handle);
  }
}
