package com.intel.bluetooth;

import java.util.NoSuchElementException;

class UtilsStringTokenizer {
  private int currentPosition;
  
  private int newPosition;
  
  private String str;
  
  private String delimiter;
  
  public UtilsStringTokenizer(String str, String delimiter) {
    this.str = str;
    this.delimiter = delimiter;
    this.currentPosition = 0;
    nextPosition();
  }
  
  public boolean hasMoreTokens() {
    return (this.newPosition != -1 && this.currentPosition < this.newPosition);
  }
  
  private void nextPosition() {
    this.newPosition = this.str.indexOf(this.delimiter, this.currentPosition);
    if (this.newPosition == -1) {
      this.newPosition = this.str.length();
    } else if (this.newPosition == this.currentPosition) {
      this.currentPosition++;
      nextPosition();
    } 
  }
  
  public String nextToken() throws NoSuchElementException {
    if (!hasMoreTokens())
      throw new NoSuchElementException(); 
    String next = this.str.substring(this.currentPosition, this.newPosition);
    this.currentPosition = this.newPosition + 1;
    nextPosition();
    return next;
  }
}
