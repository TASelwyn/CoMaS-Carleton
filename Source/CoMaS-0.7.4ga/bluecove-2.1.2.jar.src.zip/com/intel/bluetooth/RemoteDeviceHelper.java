package com.intel.bluetooth;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.RemoteDevice;
import javax.microedition.io.Connection;

public abstract class RemoteDeviceHelper {
  private static class RemoteDeviceWithExtendedInfo extends RemoteDevice {
    String name;
    
    long addressLong;
    
    BluetoothStack bluetoothStack;
    
    private Hashtable stackAttributes;
    
    private boolean paired;
    
    private WeakVectorFactory.WeakVector connections;
    
    private RemoteDeviceWithExtendedInfo(BluetoothStack bluetoothStack, long address, String name) {
      super(RemoteDeviceHelper.getBluetoothAddress(address));
      this.bluetoothStack = bluetoothStack;
      this.name = name;
      this.addressLong = address;
    }
    
    private void addConnection(Object connection) {
      synchronized (this) {
        if (this.connections == null)
          this.connections = WeakVectorFactory.createWeakVector(); 
      } 
      synchronized (this.connections) {
        this.connections.addElement(connection);
        DebugLog.debug("connection open, open now", this.connections.size());
      } 
    }
    
    private void removeConnection(Object connection) {
      if (this.connections == null)
        return; 
      synchronized (this.connections) {
        this.connections.removeElement(connection);
        DebugLog.debug("connection closed, open now", this.connections.size());
      } 
    }
    
    void shutdownConnections() {
      if (!hasConnections())
        return; 
      Vector c2shutdown = new Vector();
      synchronized (this.connections) {
        c2shutdown = Utils.clone(this.connections.elements());
      } 
      for (Enumeration en = c2shutdown.elements(); en.hasMoreElements(); ) {
        BluetoothConnectionAccess c = en.nextElement();
        try {
          c.shutdown();
        } catch (IOException e) {
          DebugLog.debug("connection shutdown", e);
        } 
      } 
      synchronized (this.connections) {
        this.connections.removeAllElements();
      } 
    }
    
    private void setStackAttributes(Object key, Object value) {
      if (this.stackAttributes == null)
        this.stackAttributes = new Hashtable(); 
      if (value == null) {
        this.stackAttributes.remove(key);
      } else {
        this.stackAttributes.put(key, value);
      } 
    }
    
    private Object getStackAttributes(Object key) {
      if (this.stackAttributes == null)
        return null; 
      return this.stackAttributes.get(key);
    }
    
    public String toString() {
      return getBluetoothAddress();
    }
    
    int connectionsCount() {
      if (this.connections == null)
        return 0; 
      return this.connections.size();
    }
    
    boolean hasConnections() {
      return (connectionsCount() != 0);
    }
    
    public boolean authenticate() throws IOException {
      if (!hasConnections())
        throw new IOException("No open connections to this RemoteDevice"); 
      if (isAuthenticated())
        return true; 
      boolean authenticated = this.bluetoothStack.authenticateRemoteDevice(this.addressLong);
      this.paired = authenticated;
      if (authenticated)
        updateConnectionMarkAuthenticated(); 
      return authenticated;
    }
    
    boolean authenticate(String passkey) throws IOException {
      boolean authenticated = this.bluetoothStack.authenticateRemoteDevice(this.addressLong, passkey);
      this.paired = authenticated;
      if (authenticated)
        updateConnectionMarkAuthenticated(); 
      return authenticated;
    }
    
    void removeAuthentication() throws IOException {
      this.bluetoothStack.removeAuthenticationWithRemoteDevice(this.addressLong);
      this.paired = false;
    }
    
    private void updateConnectionMarkAuthenticated() {
      if (this.connections == null)
        return; 
      synchronized (this.connections) {
        for (Enumeration en = this.connections.elements(); en.hasMoreElements(); ) {
          BluetoothConnectionAccess c = en.nextElement();
          c.markAuthenticated();
        } 
      } 
    }
    
    public boolean authorize(Connection conn) throws IOException {
      if (!(conn instanceof BluetoothConnectionAccess))
        throw new IllegalArgumentException("Connection is not a Bluetooth connection"); 
      if (((BluetoothConnectionAccess)conn).isClosed())
        throw new IOException("Connection is already closed"); 
      if (!(conn instanceof BluetoothServerConnection))
        throw new IllegalArgumentException("Connection is not an incomming Bluetooth connection"); 
      return (isTrustedDevice() || isAuthenticated());
    }
    
    public boolean isAuthorized(Connection conn) throws IOException {
      if (!(conn instanceof BluetoothConnectionAccess))
        throw new IllegalArgumentException("Connection is not a Bluetooth connection"); 
      if (((BluetoothConnectionAccess)conn).isClosed())
        throw new IOException("Connection is already closed"); 
      if (!(conn instanceof BluetoothServerConnection))
        throw new IllegalArgumentException("Connection is not an incomming Bluetooth connection"); 
      return isTrustedDevice();
    }
    
    public boolean encrypt(Connection conn, boolean on) throws IOException {
      if (!(conn instanceof BluetoothConnectionAccess))
        throw new IllegalArgumentException("Connection is not a Bluetooth connection"); 
      if (((BluetoothConnectionAccess)conn).getRemoteAddress() != this.addressLong)
        throw new IllegalArgumentException("Connection is not to this device"); 
      if (((((BluetoothConnectionAccess)conn).getSecurityOpt() == 2)) == on)
        return true; 
      return ((BluetoothConnectionAccess)conn).encrypt(this.addressLong, on);
    }
    
    public boolean isAuthenticated() {
      if (!hasConnections()) {
        DebugLog.debug("no connections, Authenticated = false");
        return false;
      } 
      Boolean authenticated = this.bluetoothStack.isRemoteDeviceAuthenticated(this.addressLong);
      if (authenticated != null)
        return authenticated.booleanValue(); 
      synchronized (this.connections) {
        for (Enumeration en = this.connections.elements(); en.hasMoreElements(); ) {
          BluetoothConnectionAccess c = en.nextElement();
          if (c.getSecurityOpt() != 0)
            return true; 
        } 
      } 
      return false;
    }
    
    public boolean isEncrypted() {
      if (!hasConnections())
        return false; 
      synchronized (this.connections) {
        for (Enumeration en = this.connections.elements(); en.hasMoreElements(); ) {
          BluetoothConnectionAccess c = en.nextElement();
          if (c.getSecurityOpt() == 2)
            return true; 
        } 
      } 
      return false;
    }
    
    public boolean isTrustedDevice() {
      Boolean trusted = this.bluetoothStack.isRemoteDeviceTrusted(this.addressLong);
      if (trusted == null)
        return this.paired; 
      return trusted.booleanValue();
    }
  }
  
  private static Hashtable stackDevicesCashed = new Hashtable();
  
  private static synchronized Hashtable devicesCashed(BluetoothStack bluetoothStack) {
    Hashtable devicesCashed = (Hashtable)stackDevicesCashed.get(bluetoothStack);
    if (devicesCashed == null) {
      devicesCashed = new Hashtable();
      stackDevicesCashed.put(bluetoothStack, devicesCashed);
    } 
    return devicesCashed;
  }
  
  private static RemoteDeviceWithExtendedInfo getCashedDeviceWithExtendedInfo(BluetoothStack bluetoothStack, long address) {
    Object key = new Long(address);
    return (RemoteDeviceWithExtendedInfo)devicesCashed(bluetoothStack).get(key);
  }
  
  static RemoteDevice getCashedDevice(BluetoothStack bluetoothStack, long address) {
    return getCashedDeviceWithExtendedInfo(bluetoothStack, address);
  }
  
  static RemoteDevice getStackBoundDevice(BluetoothStack bluetoothStack, RemoteDevice device) {
    if (device instanceof RemoteDeviceWithExtendedInfo && ((RemoteDeviceWithExtendedInfo)device).bluetoothStack == bluetoothStack)
      return device; 
    return createRemoteDevice(bluetoothStack, getAddress(device), null, false);
  }
  
  static RemoteDevice createRemoteDevice(BluetoothStack bluetoothStack, long address, String name, boolean paired) {
    RemoteDeviceWithExtendedInfo dev = getCashedDeviceWithExtendedInfo(bluetoothStack, address);
    if (dev == null) {
      Object saveID = BlueCoveImpl.getCurrentThreadBluetoothStackID();
      try {
        BlueCoveImpl.setThreadBluetoothStack(bluetoothStack);
        dev = new RemoteDeviceWithExtendedInfo(bluetoothStack, address, name);
      } finally {
        if (saveID != null)
          BlueCoveImpl.setThreadBluetoothStackID(saveID); 
      } 
      devicesCashed(bluetoothStack).put(new Long(address), dev);
      DebugLog.debug0x("new devicesCashed", address);
    } else if (!Utils.isStringSet(dev.name)) {
      dev.name = name;
    } else if (Utils.isStringSet(name)) {
      dev.name = name;
    } 
    if (paired)
      dev.paired = paired; 
    return dev;
  }
  
  private static BluetoothStack getBluetoothStack() throws RuntimeException {
    try {
      return BlueCoveImpl.instance().getBluetoothStack();
    } catch (BluetoothStateException e) {
      throw (RuntimeException)UtilsJavaSE.initCause(new RuntimeException("Can't initialize bluetooth support"), e);
    } 
  }
  
  private static RemoteDeviceWithExtendedInfo remoteDeviceImpl(RemoteDevice device) {
    return (RemoteDeviceWithExtendedInfo)createRemoteDevice(null, device);
  }
  
  static RemoteDevice createRemoteDevice(BluetoothStack bluetoothStack, RemoteDevice device) throws RuntimeException {
    if (device instanceof RemoteDeviceWithExtendedInfo)
      return device; 
    if (bluetoothStack == null)
      bluetoothStack = getBluetoothStack(); 
    return createRemoteDevice(bluetoothStack, getAddress(device), null, false);
  }
  
  static RemoteDevice[] remoteDeviceListToArray(Vector devices) {
    RemoteDevice[] devicesArray = new RemoteDevice[devices.size()];
    int i = 0;
    for (Enumeration en = devices.elements(); en.hasMoreElements();)
      devicesArray[i++] = en.nextElement(); 
    return devicesArray;
  }
  
  public static int openConnections() {
    int c = 0;
    Hashtable devicesCashed = devicesCashed(getBluetoothStack());
    synchronized (devicesCashed) {
      for (Enumeration en = devicesCashed.elements(); en.hasMoreElements();)
        c += ((RemoteDeviceWithExtendedInfo)en.nextElement()).connectionsCount(); 
    } 
    return c;
  }
  
  public static int openConnections(long address) {
    RemoteDeviceWithExtendedInfo dev = getCashedDeviceWithExtendedInfo(getBluetoothStack(), address);
    if (dev == null)
      return 0; 
    return dev.connectionsCount();
  }
  
  public static int connectedDevices() {
    int c = 0;
    Hashtable devicesCashed = devicesCashed(getBluetoothStack());
    synchronized (devicesCashed) {
      for (Enumeration en = devicesCashed.elements(); en.hasMoreElements();) {
        if (((RemoteDeviceWithExtendedInfo)en.nextElement()).hasConnections())
          c++; 
      } 
    } 
    return c;
  }
  
  static void shutdownConnections(BluetoothStack bluetoothStack) {
    Hashtable devicesCashed = devicesCashed(bluetoothStack);
    synchronized (devicesCashed) {
      for (Enumeration en = devicesCashed.elements(); en.hasMoreElements();)
        ((RemoteDeviceWithExtendedInfo)en.nextElement()).shutdownConnections(); 
    } 
  }
  
  public static String formatBluetoothAddress(String address) {
    String s = address.toUpperCase();
    return "000000000000".substring(s.length()) + s;
  }
  
  public static String getBluetoothAddress(long address) {
    return formatBluetoothAddress(Utils.toHexString(address));
  }
  
  public static long getAddress(String bluetoothAddress) {
    if (bluetoothAddress.indexOf('-') != -1)
      throw new IllegalArgumentException("Illegal bluetoothAddress {" + bluetoothAddress + "}"); 
    try {
      return Long.parseLong(bluetoothAddress, 16);
    } catch (NumberFormatException e) {
      throw new IllegalArgumentException("Illegal bluetoothAddress {" + bluetoothAddress + "}; should be hex number");
    } 
  }
  
  static long getAddress(RemoteDevice device) {
    if (device instanceof RemoteDeviceWithExtendedInfo)
      return ((RemoteDeviceWithExtendedInfo)device).addressLong; 
    return getAddress(device.getBluetoothAddress());
  }
  
  static void setStackAttributes(BluetoothStack bluetoothStack, RemoteDevice device, Object key, Object value) {
    RemoteDeviceWithExtendedInfo devInfo = (RemoteDeviceWithExtendedInfo)createRemoteDevice(bluetoothStack, device);
    devInfo.setStackAttributes(key, value);
  }
  
  static Object getStackAttributes(BluetoothStack bluetoothStack, RemoteDevice device, Object key) {
    RemoteDeviceWithExtendedInfo devInfo = null;
    if (device instanceof RemoteDeviceWithExtendedInfo) {
      devInfo = (RemoteDeviceWithExtendedInfo)device;
    } else {
      devInfo = getCashedDeviceWithExtendedInfo(bluetoothStack, getAddress(device));
    } 
    if (devInfo != null)
      return devInfo.getStackAttributes(key); 
    return null;
  }
  
  static void connected(BluetoothConnectionAccess connection) throws IOException {
    RemoteDeviceWithExtendedInfo device = (RemoteDeviceWithExtendedInfo)implGetRemoteDevice((Connection)connection);
    connection.setRemoteDevice(device);
    device.addConnection(connection);
  }
  
  static void disconnected(BluetoothConnectionAccess connection) {
    RemoteDevice d = connection.getRemoteDevice();
    if (d != null) {
      ((RemoteDeviceWithExtendedInfo)d).removeConnection(connection);
      connection.setRemoteDevice(null);
    } 
  }
  
  public static int readRSSI(RemoteDevice device) throws IOException {
    RemoteDeviceWithExtendedInfo deviceImpl = remoteDeviceImpl(device);
    if (deviceImpl.bluetoothStack instanceof BluetoothStackExtension)
      return ((BluetoothStackExtension)deviceImpl.bluetoothStack).readRemoteDeviceRSSI(deviceImpl.addressLong); 
    throw new NotSupportedIOException(deviceImpl.bluetoothStack.getStackID());
  }
  
  public static boolean authenticate(RemoteDevice device) throws IOException {
    return remoteDeviceImpl(device).authenticate();
  }
  
  public static boolean authenticate(RemoteDevice device, String passkey) throws IOException {
    return remoteDeviceImpl(device).authenticate(passkey);
  }
  
  public static void removeAuthentication(RemoteDevice device) throws IOException {
    remoteDeviceImpl(device).removeAuthentication();
  }
  
  public static String implGetFriendlyName(RemoteDevice device, long address, boolean alwaysAsk) throws IOException {
    if (!(device instanceof RemoteDeviceWithExtendedInfo))
      device = createRemoteDevice(null, device); 
    String name = ((RemoteDeviceWithExtendedInfo)device).name;
    if (alwaysAsk || name == null) {
      name = ((RemoteDeviceWithExtendedInfo)device).bluetoothStack.getRemoteDeviceFriendlyName(address);
      if (name != null)
        ((RemoteDeviceWithExtendedInfo)device).name = name; 
    } 
    return name;
  }
  
  public static RemoteDevice implGetRemoteDevice(Connection conn) throws IOException {
    if (!(conn instanceof BluetoothConnectionAccess))
      throw new IllegalArgumentException("Not a Bluetooth connection " + conn.getClass().getName()); 
    return createRemoteDevice(((BluetoothConnectionAccess)conn).getBluetoothStack(), ((BluetoothConnectionAccess)conn).getRemoteAddress(), null, false);
  }
  
  public static RemoteDevice[] implRetrieveDevices(BluetoothStack bluetoothStack, int option) {
    Vector devicesPaired;
    Enumeration en;
    RemoteDevice[] devices;
    int k;
    Enumeration enumeration;
    if (option != 1 && option != 0)
      throw new IllegalArgumentException("invalid option"); 
    RemoteDevice[] impl = bluetoothStack.retrieveDevices(option);
    if (impl != null) {
      if (impl.length == 0)
        return null; 
      return impl;
    } 
    Hashtable devicesCashed = devicesCashed(bluetoothStack);
    switch (option) {
      case 1:
        if (devicesCashed.size() == 0)
          return null; 
        devicesPaired = new Vector();
        for (en = devicesCashed.elements(); en.hasMoreElements(); ) {
          RemoteDeviceWithExtendedInfo d = en.nextElement();
          if (d.isTrustedDevice())
            devicesPaired.addElement(d); 
        } 
        if (devicesPaired.size() == 0)
          return null; 
        return remoteDeviceListToArray(devicesPaired);
      case 0:
        if (devicesCashed.size() == 0)
          return null; 
        devices = new RemoteDevice[devicesCashed.size()];
        k = 0;
        for (enumeration = devicesCashed.elements(); enumeration.hasMoreElements();)
          devices[k++] = enumeration.nextElement(); 
        return devices;
    } 
    throw new IllegalArgumentException("invalid option");
  }
  
  public static boolean implAuthorize(RemoteDevice device, Connection conn) throws IOException {
    return remoteDeviceImpl(device).authorize(conn);
  }
  
  public static boolean implEncrypt(RemoteDevice device, Connection conn, boolean on) throws IOException {
    return remoteDeviceImpl(device).encrypt(conn, on);
  }
  
  public static boolean implIsAuthenticated(RemoteDevice device) {
    return remoteDeviceImpl(device).isAuthenticated();
  }
  
  public static boolean implIsAuthorized(RemoteDevice device, Connection conn) throws IOException {
    return remoteDeviceImpl(device).isAuthorized(conn);
  }
  
  public static boolean implIsEncrypted(RemoteDevice device) {
    return remoteDeviceImpl(device).isEncrypted();
  }
  
  public static boolean implIsTrustedDevice(RemoteDevice device) {
    return remoteDeviceImpl(device).isTrustedDevice();
  }
}
