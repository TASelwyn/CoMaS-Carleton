package com.intel.bluetooth;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DiscoveryListener;
import javax.bluetooth.RemoteDevice;
import javax.bluetooth.ServiceRecord;
import javax.bluetooth.UUID;

class SearchServicesThread extends Thread {
  private static int transIDGenerator = 0;
  
  private static Hashtable threads = new Hashtable();
  
  private BluetoothStack stack;
  
  private SearchServicesRunnable serachRunnable;
  
  private int transID;
  
  private int[] attrSet;
  
  private Vector servicesRecords = new Vector();
  
  UUID[] uuidSet;
  
  private RemoteDevice device;
  
  private DiscoveryListener listener;
  
  private BluetoothStateException startException;
  
  private boolean started = false;
  
  private boolean finished = false;
  
  private boolean terminated = false;
  
  private Object serviceSearchStartedEvent = new Object();
  
  private static synchronized int nextThreadNum() {
    return ++transIDGenerator;
  }
  
  private SearchServicesThread(int transID, BluetoothStack stack, SearchServicesRunnable serachRunnable, int[] attrSet, UUID[] uuidSet, RemoteDevice device, DiscoveryListener listener) {
    super("SearchServicesThread-" + transID);
    this.stack = stack;
    this.serachRunnable = serachRunnable;
    this.transID = transID;
    this.attrSet = attrSet;
    this.listener = listener;
    this.uuidSet = uuidSet;
    this.device = RemoteDeviceHelper.getStackBoundDevice(stack, device);
  }
  
  static int startSearchServices(BluetoothStack stack, SearchServicesRunnable searchRunnable, int[] attrSet, UUID[] uuidSet, RemoteDevice device, DiscoveryListener listener) throws BluetoothStateException {
    SearchServicesThread t;
    synchronized (threads) {
      int runningCount = countRunningSearchServicesThreads(stack);
      int concurrentAllow = Integer.valueOf(stack.getLocalDeviceProperty("bluetooth.sd.trans.max")).intValue();
      if (runningCount >= concurrentAllow)
        throw new BluetoothStateException("Already running " + runningCount + " service discovery transactions"); 
      t = new SearchServicesThread(nextThreadNum(), stack, searchRunnable, attrSet, uuidSet, device, listener);
      threads.put(new Integer(t.getTransID()), t);
    } 
    UtilsJavaSE.threadSetDaemon(t);
    synchronized (t.serviceSearchStartedEvent) {
      t.start();
      while (!t.started && !t.finished) {
        try {
          t.serviceSearchStartedEvent.wait();
        } catch (InterruptedException e) {
          return 0;
        } 
        if (t.startException != null)
          throw t.startException; 
      } 
    } 
    if (t.started)
      return t.getTransID(); 
    throw new BluetoothStateException();
  }
  
  private static int countRunningSearchServicesThreads(BluetoothStack stack) {
    int count = 0;
    for (Enumeration en = threads.elements(); en.hasMoreElements(); ) {
      SearchServicesThread t = en.nextElement();
      if (t.stack == stack)
        count++; 
    } 
    return count;
  }
  
  static SearchServicesThread getServiceSearchThread(int transID) {
    return (SearchServicesThread)threads.get(new Integer(transID));
  }
  
  public void run() {
    int respCode = 3;
    try {
      BlueCoveImpl.setThreadBluetoothStack(this.stack);
      respCode = this.serachRunnable.runSearchServices(this, this.attrSet, this.uuidSet, this.device, this.listener);
    } catch (BluetoothStateException e) {
      this.startException = e;
      return;
    } finally {
      this.finished = true;
      unregisterThread();
      synchronized (this.serviceSearchStartedEvent) {
        this.serviceSearchStartedEvent.notifyAll();
      } 
      DebugLog.debug("runSearchServices ends", getTransID());
      if (this.started) {
        Utils.j2meUsagePatternDellay();
        this.listener.serviceSearchCompleted(getTransID(), respCode);
      } 
    } 
  }
  
  private void unregisterThread() {
    synchronized (threads) {
      threads.remove(new Integer(getTransID()));
    } 
  }
  
  public void searchServicesStartedCallback() {
    DebugLog.debug("searchServicesStartedCallback", getTransID());
    this.started = true;
    synchronized (this.serviceSearchStartedEvent) {
      this.serviceSearchStartedEvent.notifyAll();
    } 
  }
  
  int getTransID() {
    return this.transID;
  }
  
  boolean setTerminated() {
    if (isTerminated())
      return false; 
    this.terminated = true;
    unregisterThread();
    return true;
  }
  
  boolean isTerminated() {
    return this.terminated;
  }
  
  RemoteDevice getDevice() {
    return this.device;
  }
  
  DiscoveryListener getListener() {
    return this.listener;
  }
  
  void addServicesRecords(ServiceRecord servRecord) {
    this.servicesRecords.addElement(servRecord);
  }
  
  Vector getServicesRecords() {
    return this.servicesRecords;
  }
  
  public int[] getAttrSet() {
    int[] requiredAttrIDs = { 0, 1, 2, 3, 4 };
    if (this.attrSet == null)
      return requiredAttrIDs; 
    int len = requiredAttrIDs.length + this.attrSet.length;
    for (int i = 0; i < this.attrSet.length; i++) {
      for (int k = 0; k < requiredAttrIDs.length; k++) {
        if (requiredAttrIDs[k] == this.attrSet[i]) {
          len--;
          break;
        } 
      } 
    } 
    int[] allIDs = new int[len];
    System.arraycopy(requiredAttrIDs, 0, allIDs, 0, requiredAttrIDs.length);
    int appendPosition = requiredAttrIDs.length;
    for (int j = 0; j < this.attrSet.length; j++) {
      int k = 0;
      while (true) {
        if (k < requiredAttrIDs.length) {
          if (requiredAttrIDs[k] == this.attrSet[j])
            break; 
          k++;
          continue;
        } 
        allIDs[appendPosition] = this.attrSet[j];
        appendPosition++;
        break;
      } 
    } 
    return allIDs;
  }
}
