package com.intel.bluetooth.obex;

interface OBEXOperationCodes {
  public static final byte OBEX_VERSION = 16;
  
  public static final short OBEX_DEFAULT_MTU = 1024;
  
  public static final short OBEX_MINIMUM_MTU = 255;
  
  public static final short OBEX_MTU_HEADER_RESERVE = 11;
  
  public static final int OBEX_MAX_PACKET_LEN = 65535;
  
  public static final char FINAL_BIT = '';
  
  public static final char CONNECT = '';
  
  public static final char DISCONNECT = '';
  
  public static final char PUT = '\002';
  
  public static final char PUT_FINAL = '';
  
  public static final char GET = '\003';
  
  public static final char GET_FINAL = '';
  
  public static final char SETPATH = '\005';
  
  public static final char SETPATH_FINAL = '';
  
  public static final char SESSION = '\007';
  
  public static final char ABORT = 'ÿ';
  
  public static final int OBEX_RESPONSE_CONTINUE = 144;
  
  public static final int OBEX_RESPONSE_SUCCESS = 160;
}
