package javax.bluetooth;

public interface DiscoveryListener {
  public static final int INQUIRY_COMPLETED = 0;
  
  public static final int INQUIRY_TERMINATED = 5;
  
  public static final int INQUIRY_ERROR = 7;
  
  public static final int SERVICE_SEARCH_COMPLETED = 1;
  
  public static final int SERVICE_SEARCH_TERMINATED = 2;
  
  public static final int SERVICE_SEARCH_ERROR = 3;
  
  public static final int SERVICE_SEARCH_NO_RECORDS = 4;
  
  public static final int SERVICE_SEARCH_DEVICE_NOT_REACHABLE = 6;
  
  void deviceDiscovered(RemoteDevice paramRemoteDevice, DeviceClass paramDeviceClass);
  
  void servicesDiscovered(int paramInt, ServiceRecord[] paramArrayOfServiceRecord);
  
  void serviceSearchCompleted(int paramInt1, int paramInt2);
  
  void inquiryCompleted(int paramInt);
}
