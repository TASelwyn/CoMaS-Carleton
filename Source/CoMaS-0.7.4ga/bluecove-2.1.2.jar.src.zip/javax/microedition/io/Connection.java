package javax.microedition.io;

import java.io.IOException;

public interface Connection {
  void close() throws IOException;
}
