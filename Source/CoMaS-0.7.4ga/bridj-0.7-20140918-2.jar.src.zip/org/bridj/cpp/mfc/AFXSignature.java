package org.bridj.cpp.mfc;

import org.bridj.Pointer;

public enum AFXSignature {
  AfxSig_vwww(void.class, new Class[] { int.class, int.class, int.class }),
  AfxSig_vwp(void.class, new Class[] { Pointer.class, CPoint.class });
  
  final Class<?> returnType;
  
  final Class<?>[] paramTypes;
  
  AFXSignature(Class<?> returnType, Class<?>... paramTypes) {
    this.returnType = returnType;
    this.paramTypes = paramTypes;
  }
}
