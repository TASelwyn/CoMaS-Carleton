package org.bridj.cpp.mfc;

import java.lang.reflect.Method;

public class MessageMapBuilder {
  void add(Method method, OnCommand onCommand) {
    throw new UnsupportedOperationException("Not yet implemented");
  }
  
  void add(Method method, OnCommandEx onCommandEx) {
    throw new UnsupportedOperationException("Not yet implemented");
  }
  
  void add(Method method, OnUpdateCommand onUpdateCommand) {
    throw new UnsupportedOperationException("Not yet implemented");
  }
  
  void add(Method method, OnRegisteredMessage onRegisteredMessage) {
    throw new UnsupportedOperationException("Not yet implemented");
  }
  
  void add(Method method, OnMessage onMessage) {
    throw new UnsupportedOperationException("Not yet implemented");
  }
  
  boolean isEmpty() {
    throw new UnsupportedOperationException("Not yet implemented");
  }
  
  void register(MFCRuntime rt, Class<?> type) {
    throw new UnsupportedOperationException("Not yet implemented");
  }
}
