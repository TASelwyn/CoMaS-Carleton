package org.bridj.cpp.mfc;

public @interface OnUpdateCommand {
  int value();
}
