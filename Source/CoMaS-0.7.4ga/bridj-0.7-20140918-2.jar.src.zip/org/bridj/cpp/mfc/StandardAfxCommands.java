package org.bridj.cpp.mfc;

public interface StandardAfxCommands {
  public static final int ID_FILE_NEW = 57600;
  
  public static final int ID_FILE_OPEN = 57601;
  
  public static final int ID_FILE_CLOSE = 57602;
  
  public static final int ID_FILE_SAVE = 57603;
  
  public static final int ID_FILE_SAVE_AS = 57604;
  
  public static final int ID_FILE_PAGE_SETUP = 57605;
  
  public static final int ID_FILE_PRINT_SETUP = 57606;
  
  public static final int ID_FILE_PRINT = 57607;
  
  public static final int ID_FILE_PRINT_DIRECT = 57608;
  
  public static final int ID_FILE_PRINT_PREVIEW = 57609;
  
  public static final int ID_FILE_UPDATE = 57610;
  
  public static final int ID_FILE_SAVE_COPY_AS = 57611;
  
  public static final int ID_FILE_SEND_MAIL = 57612;
  
  public static final int ID_FILE_NEW_FRAME = 57613;
  
  public static final int ID_FILE_MRU_FIRST = 57616;
  
  public static final int ID_FILE_MRU_FILE1 = 57616;
  
  public static final int ID_FILE_MRU_FILE2 = 57617;
  
  public static final int ID_FILE_MRU_FILE3 = 57618;
  
  public static final int ID_FILE_MRU_FILE4 = 57619;
  
  public static final int ID_FILE_MRU_FILE5 = 57620;
  
  public static final int ID_FILE_MRU_FILE6 = 57621;
  
  public static final int ID_FILE_MRU_FILE7 = 57622;
  
  public static final int ID_FILE_MRU_FILE8 = 57623;
  
  public static final int ID_FILE_MRU_FILE9 = 57624;
  
  public static final int ID_FILE_MRU_FILE10 = 57625;
  
  public static final int ID_FILE_MRU_FILE11 = 57626;
  
  public static final int ID_FILE_MRU_FILE12 = 57627;
  
  public static final int ID_FILE_MRU_FILE13 = 57628;
  
  public static final int ID_FILE_MRU_FILE14 = 57629;
  
  public static final int ID_FILE_MRU_FILE15 = 57630;
  
  public static final int ID_FILE_MRU_FILE16 = 57631;
  
  public static final int ID_FILE_MRU_LAST = 57631;
  
  public static final int ID_EDIT_CLEAR = 57632;
  
  public static final int ID_EDIT_CLEAR_ALL = 57633;
  
  public static final int ID_EDIT_COPY = 57634;
  
  public static final int ID_EDIT_CUT = 57635;
  
  public static final int ID_EDIT_FIND = 57636;
  
  public static final int ID_EDIT_PASTE = 57637;
  
  public static final int ID_EDIT_PASTE_LINK = 57638;
  
  public static final int ID_EDIT_PASTE_SPECIAL = 57639;
  
  public static final int ID_EDIT_REPEAT = 57640;
  
  public static final int ID_EDIT_REPLACE = 57641;
  
  public static final int ID_EDIT_SELECT_ALL = 57642;
  
  public static final int ID_EDIT_UNDO = 57643;
  
  public static final int ID_EDIT_REDO = 57644;
  
  public static final int ID_WINDOW_NEW = 57648;
  
  public static final int ID_WINDOW_ARRANGE = 57649;
  
  public static final int ID_WINDOW_CASCADE = 57650;
  
  public static final int ID_WINDOW_TILE_HORZ = 57651;
  
  public static final int ID_WINDOW_TILE_VERT = 57652;
  
  public static final int ID_WINDOW_SPLIT = 57653;
  
  public static final int AFX_IDM_WINDOW_FIRST = 57648;
  
  public static final int AFX_IDM_WINDOW_LAST = 57663;
  
  public static final int AFX_IDM_FIRST_MDICHILD = 65280;
  
  public static final int ID_APP_ABOUT = 57664;
  
  public static final int ID_APP_EXIT = 57665;
  
  public static final int ID_HELP_INDEX = 57666;
  
  public static final int ID_HELP_FINDER = 57667;
  
  public static final int ID_HELP_USING = 57668;
  
  public static final int ID_CONTEXT_HELP = 57669;
  
  public static final int ID_HELP = 57670;
  
  public static final int ID_DEFAULT_HELP = 57671;
  
  public static final int ID_NEXT_PANE = 57680;
  
  public static final int ID_PREV_PANE = 57681;
  
  public static final int ID_FORMAT_FONT = 57696;
  
  public static final int ID_OLE_INSERT_NEW = 57856;
  
  public static final int ID_OLE_EDIT_LINKS = 57857;
  
  public static final int ID_OLE_EDIT_CONVERT = 57858;
  
  public static final int ID_OLE_EDIT_CHANGE_ICON = 57859;
  
  public static final int ID_OLE_EDIT_PROPERTIES = 57860;
  
  public static final int ID_OLE_VERB_FIRST = 57872;
  
  public static final int ID_OLE_VERB_LAST = 57887;
  
  public static final int AFX_ID_PREVIEW_CLOSE = 58112;
  
  public static final int AFX_ID_PREVIEW_NUMPAGE = 58113;
  
  public static final int AFX_ID_PREVIEW_NEXT = 58114;
  
  public static final int AFX_ID_PREVIEW_PREV = 58115;
  
  public static final int AFX_ID_PREVIEW_PRINT = 58116;
  
  public static final int AFX_ID_PREVIEW_ZOOMIN = 58117;
  
  public static final int AFX_ID_PREVIEW_ZOOMOUT = 58118;
  
  public static final int ID_VIEW_TOOLBAR = 59392;
  
  public static final int ID_VIEW_STATUS_BAR = 59393;
  
  public static final int ID_VIEW_REBAR = 59396;
  
  public static final int ID_VIEW_AUTOARRANGE = 59397;
  
  public static final int ID_VIEW_SMALLICON = 59408;
  
  public static final int ID_VIEW_LARGEICON = 59409;
  
  public static final int ID_VIEW_LIST = 59410;
  
  public static final int ID_VIEW_DETAILS = 59411;
  
  public static final int ID_VIEW_LINEUP = 59412;
  
  public static final int ID_VIEW_BYNAME = 59413;
  
  public static final int ID_RECORD_FIRST = 59648;
  
  public static final int ID_RECORD_LAST = 59649;
  
  public static final int ID_RECORD_NEXT = 59650;
  
  public static final int ID_RECORD_PREV = 59651;
  
  public static final int IDC_STATIC = -1;
}
