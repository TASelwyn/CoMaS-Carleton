package org.bridj.cpp;

import java.io.FileNotFoundException;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Constructor;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import org.bridj.BridJ;
import org.bridj.BridJRuntime;
import org.bridj.CRuntime;
import org.bridj.Callback;
import org.bridj.DynamicFunction;
import org.bridj.DynamicFunctionFactory;
import org.bridj.MethodCallInfo;
import org.bridj.NativeEntities;
import org.bridj.NativeLibrary;
import org.bridj.NativeObject;
import org.bridj.NativeObjectInterface;
import org.bridj.Platform;
import org.bridj.Pointer;
import org.bridj.PointerIO;
import org.bridj.SizeT;
import org.bridj.ann.Convention;
import org.bridj.ann.Template;
import org.bridj.ann.Virtual;
import org.bridj.demangling.Demangler;
import org.bridj.util.Pair;
import org.bridj.util.Utils;

public class CPPRuntime extends CRuntime {
  public static final int DEFAULT_CONSTRUCTOR = -1;
  
  public static final int SKIP_CONSTRUCTOR = -2;
  
  public static CPPRuntime getInstance() {
    return (CPPRuntime)BridJ.getRuntimeByRuntimeClass(CPPRuntime.class);
  }
  
  public Type getType(NativeObject instance) {
    if (!(instance instanceof CPPObject))
      return super.getType(instance); 
    Class<?> cls = instance.getClass();
    return new CPPType(cls, getTemplateParameters((CPPObject)instance, cls));
  }
  
  public static Object[] getTemplateParameters(CPPObject object, Class<?> typeClass) {
    synchronized (object) {
      Object[] params = null;
      if (object.templateParameters != null)
        params = object.templateParameters.get(typeClass); 
      return params;
    } 
  }
  
  public static Type[] getTemplateTypeParameters(CPPObject object, Type type) {
    if (!(type instanceof ParameterizedType))
      return new Type[0]; 
    Class<?> typeClass = Utils.getClass(type);
    ParameterizedType pt = (ParameterizedType)type;
    Object[] params = getTemplateParameters(object, typeClass);
    Template t = typeClass.<Template>getAnnotation(Template.class);
    if (t == null)
      throw new RuntimeException("No " + Template.class.getName() + " annotation on class " + typeClass.getName()); 
    if ((t.paramNames()).length != params.length)
      throw new RuntimeException(Template.class.getName() + " annotation's paramNames on class " + typeClass.getName() + " (" + Arrays.asList(t.paramNames()) + " does not match count of actual template params " + Arrays.asList(params)); 
    if ((t.paramNames()).length != (t.value()).length)
      throw new RuntimeException(Template.class.getName() + " annotation's paramNames and value lengths on class " + typeClass.getName() + " don't match"); 
    int typeParamCount = (pt.getActualTypeArguments()).length;
    Type[] ret = new Type[typeParamCount];
    int typeParamIndex = 0;
    for (int i = 0, n = params.length; i < typeParamCount; i++) {
      Object value = t.value()[i];
      if (Type.class.isInstance(value))
        ret[typeParamIndex++] = (Type)value; 
    } 
    assert typeParamIndex == typeParamCount;
    return ret;
  }
  
  public void setTemplateParameters(CPPObject object, Class<?> typeClass, Object[] params) {
    synchronized (object) {
      if (object.templateParameters == null) {
        object.templateParameters = Collections.singletonMap(typeClass, params);
      } else {
        try {
          object.templateParameters.put(typeClass, params);
        } catch (Throwable th) {
          object.templateParameters = (Map)new HashMap<Class<?>, Object>(object.templateParameters);
          object.templateParameters.put(typeClass, params);
        } 
      } 
    } 
  }
  
  protected static int getAnnotatedTemplateTypeVariableIndexInArguments(TypeVariable<?> var) {
    GenericDeclaration d = (GenericDeclaration)var.getGenericDeclaration();
    AnnotatedElement e = d;
    Template t = e.<Template>getAnnotation(Template.class);
    if (t == null)
      throw new RuntimeException(e + " is not a C++ class template (misses the @" + Template.class.getName() + " annotation)"); 
    int iTypeVar = Arrays.<TypeVariable<?>>asList(d.getTypeParameters()).indexOf(var);
    int nTypes = 0, iParam = -1;
    Class<?>[] values = t.value();
    for (int i = 0, n = values.length; i < n; i++) {
      Class<?> c = values[i];
      if (c == Class.class || c == Type.class)
        nTypes++; 
      if (nTypes == iTypeVar) {
        iParam = i;
        break;
      } 
    } 
    if (iParam < 0)
      throw new RuntimeException("Couldn't find the type variable " + var + " (offset " + iTypeVar + ") in the @" + Template.class.getName() + " annotation : " + Arrays.asList(values)); 
    return iParam;
  }
  
  protected ClassTypeVariableExtractor createClassTypeVariableExtractor(TypeVariable<Class<?>> var) {
    final Class<?> typeClass = var.getGenericDeclaration();
    final int iTypeInParams = getAnnotatedTemplateTypeVariableIndexInArguments(var);
    return new ClassTypeVariableExtractor() {
        public Type extract(CPPObject instance) {
          typeClass.cast(instance);
          Object[] params = CPPRuntime.getTemplateParameters(instance, typeClass);
          if (params == null)
            throw new RuntimeException("No type parameters found in this instance : " + instance); 
          return (Type)params[iTypeInParams];
        }
      };
  }
  
  protected MethodTypeVariableExtractor createMethodTypeVariableExtractor(TypeVariable<?> var) {
    GenericDeclaration d = (GenericDeclaration)var.getGenericDeclaration();
    if (d instanceof Class) {
      Class<?> clazz = (Class)d;
      final ClassTypeVariableExtractor ce = createClassTypeVariableExtractor((TypeVariable)var);
      return new MethodTypeVariableExtractor() {
          public Type extract(CPPObject instance, Object[] methodTemplateParameters) {
            return ce.extract(instance);
          }
        };
    } 
    Method method = (Method)d;
    final Class<?> typeClass = method.getDeclaringClass();
    final int iTypeInParams = getAnnotatedTemplateTypeVariableIndexInArguments(var);
    return new MethodTypeVariableExtractor() {
        public Type extract(CPPObject instance, Object[] methodTemplateParameters) {
          typeClass.cast(instance);
          return (Type)methodTemplateParameters[iTypeInParams];
        }
      };
  }
  
  public <T extends NativeObject> Class<? extends T> getActualInstanceClass(Pointer<T> pInstance, Type officialType) {
    return Utils.getClass(officialType);
  }
  
  Map<Class<?>, Integer> virtualMethodsCounts = new HashMap<Class<?>, Integer>();
  
  volatile MemoryOperators memoryOperators;
  
  public int getVirtualMethodsCount(Class<?> type) {
    Integer count = this.virtualMethodsCounts.get(type);
    if (count == null) {
      List<VirtMeth> mets = new ArrayList<VirtMeth>();
      listVirtualMethods(type, mets);
      this.virtualMethodsCounts.put(type, count = Integer.valueOf(mets.size()));
    } 
    return count.intValue();
  }
  
  protected static class VirtMeth {
    Method implementation;
    
    Method definition;
  }
  
  protected void listVirtualMethods(Class<?> type, List<VirtMeth> out) {
    if (!CPPObject.class.isAssignableFrom(type))
      return; 
    Class<?> sup = type.getSuperclass();
    if (sup != CPPObject.class)
      listVirtualMethods(sup, out); 
    int nParentMethods = out.size();
    Map<Integer, VirtMeth> newVirtuals = new TreeMap<Integer, VirtMeth>();
    label28: for (Method method : type.getDeclaredMethods()) {
      String methodName = Demangler.getMethodName(method);
      Type[] methodParameterTypes = method.getGenericParameterTypes();
      for (int iParentMethod = 0; iParentMethod < nParentMethods; iParentMethod++) {
        VirtMeth pvm = out.get(iParentMethod);
        Method parentMethod = pvm.definition;
        if (parentMethod.getDeclaringClass() != type)
          if (Demangler.getMethodName(parentMethod).equals(methodName) && isOverridenSignature(parentMethod.getGenericParameterTypes(), methodParameterTypes, 0)) {
            VirtMeth vm = new VirtMeth();
            vm.definition = pvm.definition;
            vm.implementation = method;
            out.set(iParentMethod, vm);
            continue label28;
          }  
      } 
      Virtual virtual = method.<Virtual>getAnnotation(Virtual.class);
      if (virtual != null) {
        VirtMeth vm = new VirtMeth();
        vm.definition = vm.implementation = method;
        newVirtuals.put(Integer.valueOf(virtual.value()), vm);
      } 
    } 
    out.addAll(newVirtuals.values());
  }
  
  protected void registerNativeMethod(Class<?> type, NativeLibrary typeLibrary, Method method, NativeLibrary methodLibrary, NativeEntities.Builder builder, CRuntime.MethodCallInfoBuilder methodCallInfoBuilder) throws FileNotFoundException {
    int modifiers = method.getModifiers();
    boolean isCPPClass = CPPObject.class.isAssignableFrom(method.getDeclaringClass());
    if (!isCPPClass) {
      super.registerNativeMethod(type, typeLibrary, method, methodLibrary, builder, methodCallInfoBuilder);
      return;
    } 
    MethodCallInfo mci = methodCallInfoBuilder.apply(method);
    Virtual va = method.<Virtual>getAnnotation(Virtual.class);
    if (va == null) {
      Demangler.Symbol symbol = methodLibrary.getSymbol(method);
      mci.setForwardedPointer((symbol == null) ? 0L : symbol.getAddress());
      if (mci.getForwardedPointer() == 0L) {
        assert BridJ.error("Method " + method.toGenericString() + " is not virtual but its address could not be resolved in the library.");
        return;
      } 
      if (Modifier.isStatic(modifiers)) {
        builder.addFunction(mci);
        if (BridJ.debug)
          BridJ.info("Registering " + method + " as function or static C++ method " + symbol.getName()); 
      } else {
        builder.addFunction(mci);
        if (BridJ.debug)
          BridJ.info("Registering " + method + " as C++ method " + symbol.getName()); 
      } 
    } else {
      int absoluteVirtualIndex;
      if (Modifier.isStatic(modifiers))
        BridJ.warning("Method " + method.toGenericString() + " is native and maps to a function, but is not static."); 
      int theoreticalVirtualIndex = va.value();
      int theoreticalAbsoluteVirtualIndex = (theoreticalVirtualIndex < 0) ? -1 : getAbsoluteVirtualIndex(method, theoreticalVirtualIndex, type);
      Pointer<Pointer<?>> pVirtualTable = (isCPPClass && typeLibrary != null) ? Pointer.pointerToAddress(getVirtualTable(type, typeLibrary), Pointer.class) : null;
      if (pVirtualTable == null) {
        if (theoreticalAbsoluteVirtualIndex < 0) {
          BridJ.error("Method " + method.toGenericString() + " is virtual but the virtual table of class " + type.getName() + " was not found and the virtual method index is not provided in its @Virtual annotation.");
          return;
        } 
        absoluteVirtualIndex = theoreticalAbsoluteVirtualIndex;
      } else {
        int guessedAbsoluteVirtualIndex = getPositionInVirtualTable(pVirtualTable, method, typeLibrary);
        if (guessedAbsoluteVirtualIndex < 0) {
          if (theoreticalAbsoluteVirtualIndex < 0) {
            BridJ.error("Method " + method.toGenericString() + " is virtual but its position could not be found in the virtual table.");
            return;
          } 
          absoluteVirtualIndex = theoreticalAbsoluteVirtualIndex;
        } else {
          if (theoreticalAbsoluteVirtualIndex >= 0 && guessedAbsoluteVirtualIndex != theoreticalAbsoluteVirtualIndex)
            BridJ.warning("Method " + method.toGenericString() + " has @Virtual annotation indicating virtual index " + theoreticalAbsoluteVirtualIndex + ", but analysis of the actual virtual table rather indicates it has index " + guessedAbsoluteVirtualIndex + " (using the guess)"); 
          absoluteVirtualIndex = guessedAbsoluteVirtualIndex;
        } 
      } 
      mci.setVirtualIndex(absoluteVirtualIndex);
      if (BridJ.debug)
        BridJ.info("Registering " + method.toGenericString() + " as virtual C++ method with absolute virtual table index = " + absoluteVirtualIndex); 
      builder.addVirtualMethod(mci);
    } 
  }
  
  int getAbsoluteVirtualIndex(Method method, int virtualIndex, Class<?> type) {
    Class<?> superclass = type.getSuperclass();
    int virtualOffset = getVirtualMethodsCount(superclass);
    boolean isNewVirtual = true;
    if (superclass != null)
      try {
        superclass.getMethod(Demangler.getMethodName(method), method.getParameterTypes());
        isNewVirtual = false;
      } catch (NoSuchMethodException ex) {} 
    int absoluteVirtualIndex = isNewVirtual ? (virtualOffset + virtualIndex) : virtualIndex;
    return absoluteVirtualIndex;
  }
  
  public static class MemoryOperators {
    protected DynamicFunction<Pointer<?>> newFct;
    
    protected DynamicFunction<Pointer<?>> newArrayFct;
    
    protected DynamicFunction<Void> deleteFct;
    
    protected DynamicFunction<Void> deleteArrayFct;
    
    protected MemoryOperators() {}
    
    public MemoryOperators(NativeLibrary library) {
      for (Demangler.Symbol sym : library.getSymbols()) {
        try {
          Demangler.MemberRef parsedRef = sym.getParsedRef();
          Demangler.IdentLike n = parsedRef.getMemberName();
          if (Demangler.SpecialName.New.equals(n)) {
            this.newFct = Pointer.pointerToAddress(sym.getAddress()).asDynamicFunction(null, Pointer.class, new Type[] { SizeT.class });
            continue;
          } 
          if (Demangler.SpecialName.NewArray.equals(n)) {
            this.newFct = Pointer.pointerToAddress(sym.getAddress()).asDynamicFunction(null, Pointer.class, new Type[] { SizeT.class });
            continue;
          } 
          if (Demangler.SpecialName.Delete.equals(n)) {
            this.newFct = Pointer.pointerToAddress(sym.getAddress()).asDynamicFunction(null, Void.class, new Type[] { Pointer.class });
            continue;
          } 
          if (Demangler.SpecialName.DeleteArray.equals(n))
            this.newFct = Pointer.pointerToAddress(sym.getAddress()).asDynamicFunction(null, Void.class, new Type[] { Pointer.class }); 
        } catch (Exception ex) {}
      } 
    }
    
    public Pointer<?> cppNew(long size) {
      return (Pointer)this.newFct.apply(new Object[] { new SizeT(size) });
    }
    
    public Pointer<?> cppNewArray(long size) {
      return (Pointer)this.newArrayFct.apply(new Object[] { new SizeT(size) });
    }
    
    public void cppDelete(Pointer<?> ptr) {
      this.deleteFct.apply(new Object[] { ptr });
    }
    
    public void cppDeleteArray(Pointer<?> ptr) {
      this.deleteArrayFct.apply(new Object[] { ptr });
    }
  }
  
  public synchronized MemoryOperators getMemoryOperators() {
    if (this.memoryOperators == null)
      try {
        NativeLibrary libStdCpp = BridJ.getNativeLibrary("stdc++");
        this.memoryOperators = new MemoryOperators(libStdCpp);
      } catch (Exception ex) {
        BridJ.error(null, ex);
      }  
    return this.memoryOperators;
  }
  
  int getPositionInVirtualTable(Method method, NativeLibrary library) {
    Class<?> type = method.getDeclaringClass();
    Pointer<Pointer<?>> pVirtualTable = Pointer.pointerToAddress(getVirtualTable(type, library), Pointer.class);
    return getPositionInVirtualTable(pVirtualTable, method, library);
  }
  
  public int getPositionInVirtualTable(Pointer<Pointer<?>> pVirtualTable, Method method, NativeLibrary library) {
    int methodsOffset = 0;
    String className = Demangler.getClassName(method.getDeclaringClass());
    for (int iVirtual = 0;; iVirtual++) {
      Pointer<?> pMethod = (Pointer)pVirtualTable.get((methodsOffset + iVirtual));
      String virtualMethodName = (pMethod == null) ? null : library.getSymbolName(pMethod.getPeer());
      if (virtualMethodName == null) {
        if (BridJ.debug)
          BridJ.info("\tVtable(" + className + ")[" + iVirtual + "] = null"); 
        return -1;
      } 
      try {
        Demangler.MemberRef mr = library.parseSymbol(virtualMethodName);
        if (BridJ.debug)
          BridJ.info("\tVtable(" + className + ")[" + iVirtual + "] = " + virtualMethodName + " = " + mr); 
        if (mr != null && mr.matchesSignature(method))
          return iVirtual; 
        if (library.isMSVC() && !mr.matchesEnclosingType(method))
          break; 
      } catch (org.bridj.demangling.Demangler.DemanglingException ex) {
        BridJ.warning("Failed to demangle '" + virtualMethodName + "' during inspection of virtual table for '" + method.toGenericString() + "' : " + ex);
      } 
    } 
    return -1;
  }
  
  static int getDefaultDyncallCppConvention() {
    int convention = 0;
    if (!Platform.is64Bits() && Platform.isWindows())
      convention = 5; 
    return convention;
  }
  
  private String ptrToString(Pointer<?> ptr, NativeLibrary library) {
    return (ptr == null) ? "null" : (Long.toHexString(ptr.getPeer()) + " (" + library.getSymbolName(ptr.getPeer()) + ")");
  }
  
  @Convention(Convention.Style.ThisCall)
  public static abstract class CPPDestructor extends Callback {
    public abstract void destroy(long param1Long);
  }
  
  Set<Type> typesThatDontNeedASyntheticVirtualTable = new HashSet<Type>();
  
  Map<Type, VTable> syntheticVirtualTables = new HashMap<Type, VTable>();
  
  protected boolean installRegularVTablePtr(Type type, NativeLibrary library, Pointer<?> peer) {
    long vtablePtr = getVirtualTable(type, library);
    if (vtablePtr != 0L) {
      if (BridJ.debug)
        BridJ.info("Installing regular vtable pointer " + Pointer.pointerToAddress(vtablePtr) + " to instance at " + peer + " (type = " + Utils.toString(type) + ")"); 
      peer.setSizeT(vtablePtr);
      return true;
    } 
    return false;
  }
  
  protected boolean installSyntheticVTablePtr(Type type, NativeLibrary library, Pointer<?> peer) {
    synchronized (this.syntheticVirtualTables) {
      VTable vtable = this.syntheticVirtualTables.get(type);
      if (vtable == null && 
        !this.typesThatDontNeedASyntheticVirtualTable.contains(type)) {
        List<VirtMeth> methods = new ArrayList<VirtMeth>();
        listVirtualMethods(Utils.getClass(type), methods);
        boolean needsASyntheticVirtualTable = false;
        for (VirtMeth method : methods) {
          if (!Modifier.isNative(method.implementation.getModifiers())) {
            needsASyntheticVirtualTable = true;
            break;
          } 
        } 
        if (needsASyntheticVirtualTable) {
          Type parentType = Utils.getParent(type);
          Pointer<Pointer> parentVTablePtr = null;
          if (CPPObject.class.isAssignableFrom(Utils.getClass(parentType))) {
            parentVTablePtr = peer.getPointer(Pointer.class);
            if (BridJ.debug)
              BridJ.info("Found parent virtual table pointer = " + ptrToString(parentVTablePtr, library)); 
          } 
          this.syntheticVirtualTables.put(type, vtable = synthetizeVirtualTable(type, parentVTablePtr, methods, library));
        } else {
          this.typesThatDontNeedASyntheticVirtualTable.add(type);
        } 
      } 
      if (vtable != null) {
        if (BridJ.debug)
          BridJ.info("Installing synthetic vtable pointer " + vtable.ptr + " to instance at " + peer + " (type = " + Utils.toString(type) + ", " + vtable.callbacks.size() + " callbacks)"); 
        peer.setPointer(vtable.ptr);
        return (vtable.ptr != null);
      } 
      return false;
    } 
  }
  
  static class VTable {
    Pointer<Pointer<?>> ptr;
    
    Map<Method, Pointer<?>> callbacks = new HashMap<Method, Pointer<?>>();
  }
  
  protected VTable synthetizeVirtualTable(Type type, Pointer<Pointer> parentVTablePtr, List<VirtMeth> methods, NativeLibrary library) {
    int nMethods = methods.size();
    VTable vtable = new VTable();
    vtable.ptr = Pointer.allocatePointers(nMethods + 2).next(2L);
    Class<?> c = Utils.getClass(type);
    for (int iMethod = 0; iMethod < nMethods; iMethod++) {
      Object object;
      VirtMeth vm = methods.get(iMethod);
      if (Modifier.isNative(vm.implementation.getModifiers())) {
        object = (parentVTablePtr == null) ? null : (Pointer)parentVTablePtr.get(iMethod);
      } else {
        try {
          MethodCallInfo mci = new MethodCallInfo(vm.implementation, vm.definition);
          mci.setDeclaringClass(vm.implementation.getDeclaringClass());
          object = createCToJavaCallback(mci, c);
          vtable.callbacks.put(vm.implementation, (Pointer<?>)object);
        } catch (Throwable th) {
          BridJ.error("Failed to register overridden method " + vm.implementation + " for type " + type + " (original method = " + vm.definition + ")", th);
          object = null;
        } 
      } 
      vtable.ptr.set(iMethod, object);
    } 
    return vtable;
  }
  
  static int getTemplateParametersCount(Class<?> typeClass) {
    Template t = typeClass.<Template>getAnnotation(Template.class);
    int templateParametersCount = (t == null) ? 0 : (t.value()).length;
    return templateParametersCount;
  }
  
  Map<Pair<Type, Integer>, DynamicFunction> constructors = new HashMap<Pair<Type, Integer>, DynamicFunction>();
  
  DynamicFunction getConstructor(Class<?> typeClass, final Type type, NativeLibrary lib, int constructorId) {
    Pair<Type, Integer> key = new Pair(type, Integer.valueOf(constructorId));
    DynamicFunction constructor = this.constructors.get(key);
    if (constructor == null)
      try {
        final Constructor<?> constr;
        try {
          constr = findConstructor(typeClass, constructorId, true);
          if (BridJ.debug)
            BridJ.info("Found constructor for " + Utils.toString(type) + " : " + constr); 
        } catch (NoSuchMethodException ex) {
          if (BridJ.debug)
            BridJ.info("No constructor for " + Utils.toString(type)); 
          return null;
        } 
        Demangler.Symbol symbol = (lib == null) ? null : lib.getFirstMatchingSymbol(new NativeLibrary.SymbolAccepter() {
              public boolean accept(Demangler.Symbol symbol) {
                return symbol.matchesConstructor((constr.getDeclaringClass() == Utils.getClass(type)) ? type : constr.getDeclaringClass(), constr);
              }
            });
        if (symbol == null) {
          if (BridJ.debug)
            BridJ.info("No matching constructor for " + Utils.toString(type) + " (" + constr + ")"); 
          return null;
        } 
        if (BridJ.debug)
          BridJ.info("Registering constructor " + constr + " as " + symbol.getName()); 
        int templateParametersCount = getTemplateParametersCount(typeClass);
        Class<?>[] consParamTypes = constr.getParameterTypes();
        Class<?>[] consThisParamTypes = new Class[consParamTypes.length + 1 - templateParametersCount];
        consThisParamTypes[0] = Pointer.class;
        System.arraycopy(consParamTypes, templateParametersCount, consThisParamTypes, 1, consParamTypes.length - templateParametersCount);
        DynamicFunctionFactory constructorFactory = getDynamicFunctionFactory(lib, Convention.Style.ThisCall, void.class, (Type[])consThisParamTypes);
        constructor = constructorFactory.newInstance(Pointer.pointerToAddress(symbol.getAddress()));
        this.constructors.put(key, constructor);
      } catch (Throwable th) {
        th.printStackTrace();
        throw new RuntimeException("Unable to create constructor " + constructorId + " for " + type + " : " + th, th);
      }  
    return constructor;
  }
  
  Map<Type, CPPDestructor> destructors = new HashMap<Type, CPPDestructor>();
  
  CPPDestructor getDestructor(final Class<?> typeClass, Type type, NativeLibrary lib) {
    CPPDestructor destructor = this.destructors.get(type);
    if (destructor == null) {
      Demangler.Symbol symbol = lib.getFirstMatchingSymbol(new NativeLibrary.SymbolAccepter() {
            public boolean accept(Demangler.Symbol symbol) {
              return symbol.matchesDestructor(typeClass);
            }
          });
      if (BridJ.debug && symbol != null)
        BridJ.info("Registering destructor of " + Utils.toString(type) + " as " + symbol.getName()); 
      if (symbol != null)
        this.destructors.put(type, destructor = (CPPDestructor)Pointer.pointerToAddress(symbol.getAddress(), CPPDestructor.class).get()); 
    } 
    return destructor;
  }
  
  Pointer.Releaser newCPPReleaser(Type type) {
    try {
      Class<?> typeClass = Utils.getClass(type);
      NativeLibrary lib = BridJ.getNativeLibrary(typeClass);
      return newCPPReleaser(type, typeClass, lib);
    } catch (Throwable th) {
      throw new RuntimeException("Failed to create a C++ destructor for type " + Utils.toString(type) + " : " + th, th);
    } 
  }
  
  Pointer.Releaser newCPPReleaser(final Type type, Class<?> typeClass, NativeLibrary lib) throws FileNotFoundException {
    Pointer.Releaser releaser = null;
    if (lib != null && BridJ.enableDestructors) {
      final CPPDestructor destructor = getDestructor(typeClass, type, lib);
      if (destructor != null)
        releaser = new Pointer.Releaser() {
            public void release(Pointer<?> p) {
              if (BridJ.debug)
                BridJ.info("Destructing instance of C++ type " + Utils.toString(type) + " (address = " + p + ", destructor = " + Pointer.getPointer((NativeObject)destructor) + ")"); 
              long peer = p.getPeer();
              destructor.destroy(peer);
              BridJ.setJavaObjectFromNativePeer(peer, null);
            }
          }; 
    } 
    return releaser;
  }
  
  protected <T extends CPPObject> Pointer<T> newCPPInstance(T instance, Type type, int constructorId, Object... args) {
    Pointer<T> peer = null;
    try {
      Class<T> typeClass = Utils.getClass(type);
      NativeLibrary lib = BridJ.getNativeLibrary(typeClass);
      if (BridJ.debug)
        BridJ.info("Creating C++ instance of type " + type + " with args " + Arrays.<Object>asList(args)); 
      Pointer.Releaser releaser = newCPPReleaser(type, typeClass, lib);
      long size = sizeOf(type, null);
      peer = Pointer.allocateBytes(PointerIO.getInstance(type), size, releaser).as(type);
      DynamicFunction constructor = (constructorId == -2) ? null : getConstructor(typeClass, type, lib, constructorId);
      if (lib != null && CPPObject.class.isAssignableFrom(typeClass))
        installRegularVTablePtr(type, lib, peer); 
      if (constructor != null) {
        Object[] consThisArgs = new Object[1 + args.length];
        consThisArgs[0] = peer;
        System.arraycopy(args, 0, consThisArgs, 1, args.length);
        constructor.apply(consThisArgs);
      } 
      if (CPPObject.class.isAssignableFrom(typeClass) && 
        installSyntheticVTablePtr(type, lib, peer))
        BridJ.setJavaObjectFromNativePeer(peer.getPeer(), (NativeObject)instance); 
      return peer;
    } catch (Exception ex) {
      ex.printStackTrace();
      if (peer != null)
        peer.release(); 
      throw new RuntimeException("Failed to allocate new instance of type " + type, ex);
    } 
  }
  
  Map<Type, Long> vtables = new HashMap<Type, Long>();
  
  long getVirtualTable(Type type, NativeLibrary library) {
    Long vtable = this.vtables.get(type);
    if (vtable == null) {
      final Class<?> typeClass = Utils.getClass(type);
      Demangler.Symbol symbol = library.getFirstMatchingSymbol(new NativeLibrary.SymbolAccepter() {
            public boolean accept(Demangler.Symbol symbol) {
              return symbol.matchesVirtualTable(typeClass);
            }
          });
      if (symbol != null) {
        if (BridJ.debug)
          BridJ.info("Registering vtable of " + Utils.toString(type) + " as " + symbol.getName()); 
      } else if (getVirtualMethodsCount(typeClass) > 0 && warnAboutMissingVTables()) {
        BridJ.error("Failed to find a vtable for type " + Utils.toString(type));
      } 
      if (symbol != null) {
        long address = symbol.getAddress();
        vtable = Long.valueOf(library.isMSVC() ? address : (address + (2 * Pointer.SIZE)));
      } else {
        vtable = Long.valueOf(0L);
      } 
      this.vtables.put(type, vtable);
    } 
    return vtable.longValue();
  }
  
  protected boolean warnAboutMissingVTables() {
    return true;
  }
  
  protected boolean shouldWarnIfNoFieldsInStruct() {
    return false;
  }
  
  public class CPPTypeInfo<T extends CPPObject> extends CRuntime.CTypeInfo<T> {
    protected final int typeParamCount;
    
    protected Object[] templateParameters;
    
    Map<TypeVariable<Class<?>>, CPPRuntime.ClassTypeVariableExtractor> classTypeVariableExtractors;
    
    Map<TypeVariable<?>, CPPRuntime.MethodTypeVariableExtractor> methodTypeVariableExtractors;
    
    public CPPTypeInfo(Type type) {
      super(CPPRuntime.this, type);
      Class<?> typeClass = Utils.getClass(type);
      this.typeParamCount = (typeClass.getTypeParameters()).length;
      if (this.typeParamCount > 0 && !(type instanceof ParameterizedType))
        throw new RuntimeException("Class " + typeClass.getName() + " takes type parameters"); 
      this.templateParameters = getTemplateParameters(type);
    }
    
    protected T newCastInstance() throws NoSuchMethodException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
      if (this.templateParameters.length == 0)
        return (T)super.newCastInstance(); 
      Class<?> cc = getCastClass();
      for (Constructor<CPPObject> c : cc.getConstructors()) {
        if (Utils.parametersComplyToSignature(this.templateParameters, c.getParameterTypes())) {
          c.setAccessible(true);
          return (T)c.newInstance(this.templateParameters);
        } 
      } 
      throw new RuntimeException("Failed to find template constructor in class " + cc.getName());
    }
    
    public Type resolveClassType(CPPObject instance, TypeVariable<?> var) {
      return getClassTypeVariableExtractor((TypeVariable)var).extract(instance);
    }
    
    public Type resolveMethodType(CPPObject instance, Object[] methodTemplateParameters, TypeVariable<?> var) {
      return getMethodTypeVariableExtractor(var).extract(instance, methodTemplateParameters);
    }
    
    protected synchronized CPPRuntime.ClassTypeVariableExtractor getClassTypeVariableExtractor(TypeVariable<Class<?>> var) {
      if (this.classTypeVariableExtractors == null)
        this.classTypeVariableExtractors = new HashMap<TypeVariable<Class<?>>, CPPRuntime.ClassTypeVariableExtractor>(); 
      CPPRuntime.ClassTypeVariableExtractor e = this.classTypeVariableExtractors.get(var);
      if (e == null)
        this.classTypeVariableExtractors.put(var, e = CPPRuntime.this.createClassTypeVariableExtractor(var)); 
      return e;
    }
    
    protected synchronized CPPRuntime.MethodTypeVariableExtractor getMethodTypeVariableExtractor(TypeVariable<?> var) {
      if (this.methodTypeVariableExtractors == null)
        this.methodTypeVariableExtractors = new HashMap<TypeVariable<?>, CPPRuntime.MethodTypeVariableExtractor>(); 
      CPPRuntime.MethodTypeVariableExtractor e = this.methodTypeVariableExtractors.get(var);
      if (e == null)
        this.methodTypeVariableExtractors.put(var, e = CPPRuntime.this.createMethodTypeVariableExtractor(var)); 
      return e;
    }
    
    public long sizeOf() {
      return super.sizeOf();
    }
    
    public T createReturnInstance() {
      try {
        T instance = newCastInstance();
        initialize(instance, -2, this.templateParameters);
        return instance;
      } catch (Throwable th) {
        throw new RuntimeException("Failed to create a return instance for type " + Utils.toString(this.type) + " : " + th, th);
      } 
    }
    
    public T cast(Pointer peer) {
      if (BridJ.isCastingNativeObjectReturnTypeInCurrentThread())
        peer = peer.withReleaser(CPPRuntime.this.newCPPReleaser(this.type)); 
      CPPObject cPPObject = (CPPObject)super.cast(peer);
      CPPRuntime.this.setTemplateParameters(cPPObject, this.typeClass, this.templateParameters);
      return (T)cPPObject;
    }
    
    public void initialize(T instance, Pointer peer) {
      CPPRuntime.this.setTemplateParameters((CPPObject)instance, this.typeClass, this.templateParameters);
      super.initialize((NativeObject)instance, peer);
    }
    
    public void initialize(T instance, int constructorId, Object... targsAndArgs) {
      if (instance instanceof CPPObject) {
        T t = instance;
        int[] position = { 0 };
        Type cppType = this.type;
        CPPRuntime.this.setTemplateParameters((CPPObject)instance, this.typeClass, this.templateParameters);
        CPPRuntime.this.setNativeObjectPeer((NativeObjectInterface)instance, CPPRuntime.this.newCPPInstance(instance, cppType, constructorId, targsAndArgs));
        super.initialize((NativeObject)instance, -1, new Object[0]);
      } else {
        super.initialize((NativeObject)instance, constructorId, targsAndArgs);
      } 
    }
    
    public T clone(T instance) throws CloneNotSupportedException {
      if (instance instanceof CPPObject);
      return (T)super.clone((NativeObject)instance);
    }
    
    public void destroy(T instance) {}
    
    private Object[] getTemplateParameters(Type type) {
      if (!(type instanceof CPPType))
        return new Object[0]; 
      return ((CPPType)type).getTemplateParameters();
    }
  }
  
  public <T extends NativeObject> BridJRuntime.TypeInfo<T> getTypeInfo(Type type) {
    return (BridJRuntime.TypeInfo)new CPPTypeInfo<CPPObject>(type);
  }
  
  public Type getType(Class<?> cls, Object[] targsAndArgs, int[] typeParamCount) {
    Template tpl = cls.<Template>getAnnotation(Template.class);
    int targsCount = (tpl != null) ? (tpl.value()).length : (cls.getTypeParameters()).length;
    if (typeParamCount != null) {
      assert typeParamCount.length == 1;
      typeParamCount[0] = targsCount;
    } 
    return new CPPType(cls, Utils.takeLeft(targsAndArgs, targsCount));
  }
  
  public <T extends CPPObject> CPPTypeInfo<T> getCPPTypeInfo(Type type) {
    return (CPPTypeInfo<T>)getTypeInfo(type);
  }
  
  protected static interface MethodTypeVariableExtractor {
    Type extract(CPPObject param1CPPObject, Object[] param1ArrayOfObject);
  }
  
  protected static interface ClassTypeVariableExtractor {
    Type extract(CPPObject param1CPPObject);
  }
}
