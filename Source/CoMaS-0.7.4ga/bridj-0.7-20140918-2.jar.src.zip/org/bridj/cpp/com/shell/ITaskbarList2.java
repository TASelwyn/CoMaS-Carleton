package org.bridj.cpp.com.shell;

import org.bridj.Pointer;
import org.bridj.ann.Virtual;

public class ITaskbarList2 extends ITaskbarList {
  @Virtual(0)
  public native int MarkFullscreenWindow(Pointer<Integer> paramPointer, boolean paramBoolean);
}
