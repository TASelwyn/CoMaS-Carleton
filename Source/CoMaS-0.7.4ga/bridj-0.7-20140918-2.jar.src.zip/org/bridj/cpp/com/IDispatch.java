package org.bridj.cpp.com;

import org.bridj.Pointer;
import org.bridj.StructObject;
import org.bridj.ann.Field;
import org.bridj.ann.Virtual;

@IID("00020400-0000-0000-C000-000000000046")
public class IDispatch extends IUnknown {
  @Virtual(0)
  public native int GetTypeInfoCount(Pointer<Integer> paramPointer);
  
  @Virtual(1)
  public native int GetTypeInfo(int paramInt1, int paramInt2, Pointer<Pointer<ITypeInfo>> paramPointer);
  
  @Virtual(2)
  public native int GetIDsOfNames(Pointer paramPointer, Pointer<Pointer<Character>> paramPointer1, int paramInt1, int paramInt2, Pointer<Integer> paramPointer2);
  
  @Virtual(3)
  public native int Invoke(int paramInt1, Pointer<Byte> paramPointer, int paramInt2, short paramShort, Pointer<DISPPARAMS> paramPointer1, Pointer<VARIANT> paramPointer2, Pointer<EXCEPINFO> paramPointer3, Pointer<Integer> paramPointer4);
  
  public static class DISPPARAMS extends StructObject {
    @Field(0)
    public native Pointer<VARIANT> rgvarg();
    
    @Field(1)
    public native Pointer<Integer> rgdispidNamedArgs();
    
    @Field(2)
    public native int cArgs();
    
    @Field(3)
    public native int cNamedArgs();
  }
  
  public static class EXCEPINFO extends StructObject {
    @Field(0)
    public native short wCode();
    
    @Field(1)
    public native short wReserved();
    
    @Field(2)
    public native Pointer<Character> bstrSource();
    
    @Field(3)
    public native Pointer<Character> bstrDescription();
    
    @Field(4)
    public native Pointer<Character> bstrHelpFile();
    
    @Field(5)
    public native int dwHelpContext();
    
    @Field(6)
    public native Pointer<?> pvReserved();
    
    @Field(7)
    public native Pointer<?> pfnDeferredFillIn();
    
    @Field(8)
    public native int scode();
  }
}
