package org.bridj.cpp.std;

import org.bridj.Platform;
import org.bridj.Pointer;
import org.bridj.StructCustomizer;
import org.bridj.StructDescription;

public final class STL extends StructCustomizer {
  public void afterBuild(StructDescription desc) {
    if (!Platform.isWindows())
      return; 
    Class<vector> c = desc.getStructClass();
    if (c == vector.class) {
      desc.prependBytes((3 * Pointer.SIZE));
    } else if (c == list.class || c == list.list_node.class) {
      desc.setFieldOffset("prev", (5 * Pointer.SIZE), false);
      if (c == list.list_node.class)
        desc.setFieldOffset("data", (6 * Pointer.SIZE), false); 
    } 
  }
}
