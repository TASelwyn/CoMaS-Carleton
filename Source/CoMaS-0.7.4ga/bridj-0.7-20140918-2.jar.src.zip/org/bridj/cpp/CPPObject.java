package org.bridj.cpp;

import java.util.Map;
import org.bridj.Pointer;
import org.bridj.StructObject;
import org.bridj.ann.Runtime;

@Runtime(CPPRuntime.class)
public abstract class CPPObject extends StructObject {
  Map<Class<?>, Object[]> templateParameters;
  
  protected CPPObject() {}
  
  protected CPPObject(Pointer<? extends CPPObject> peer, Object... targs) {
    super(peer, targs);
  }
  
  protected CPPObject(Void voidArg, int constructorId, Object... args) {
    super(voidArg, constructorId, args);
  }
}
