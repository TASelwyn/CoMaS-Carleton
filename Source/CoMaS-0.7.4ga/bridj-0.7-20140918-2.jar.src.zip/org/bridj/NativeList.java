package org.bridj;

import java.util.List;

public interface NativeList<T> extends List<T> {
  Pointer<?> getPointer();
}
