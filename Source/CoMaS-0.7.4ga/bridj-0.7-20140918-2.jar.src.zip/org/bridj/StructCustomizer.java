package org.bridj;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import org.bridj.ann.Struct;

@Deprecated
public class StructCustomizer {
  public void beforeAggregation(StructDescription desc, List<StructFieldDeclaration> fieldDecls) {}
  
  public void beforeLayout(StructDescription desc, List<StructFieldDescription> aggregatedFields) {}
  
  public void afterLayout(StructDescription desc, List<StructFieldDescription> aggregatedFields) {}
  
  public void afterBuild(StructDescription desc) {}
  
  private static StructCustomizer dummyCustomizer = new StructCustomizer();
  
  private static ConcurrentHashMap<Class, StructCustomizer> customizers = new ConcurrentHashMap<Class<?>, StructCustomizer>();
  
  static StructCustomizer getInstance(Class<?> structClass) {
    StructCustomizer c = customizers.get(structClass);
    if (c == null) {
      Struct s = structClass.<Struct>getAnnotation(Struct.class);
      if (s != null) {
        Class<? extends StructCustomizer> customizerClass = s.customizer();
        if (customizerClass != null && customizerClass != StructCustomizer.class)
          try {
            c = customizerClass.newInstance();
          } catch (Throwable th) {
            throw new RuntimeException("Failed to create customizer of class " + customizerClass.getName() + " for struct class " + structClass.getName() + " : " + th, th);
          }  
      } 
      if (c == null)
        c = dummyCustomizer; 
      StructCustomizer existingConcurrentCustomizer = customizers.putIfAbsent(structClass, c);
      if (existingConcurrentCustomizer != null)
        return existingConcurrentCustomizer; 
    } 
    return c;
  }
}
