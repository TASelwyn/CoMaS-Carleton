package org.bridj.func;

public interface Fun1<T, A1> {
  T apply(A1 paramA1);
}
