package org.bridj.func;

public interface Fun0<T> {
  T apply();
}
