package org.bridj;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

public class OSGiBundleActivator implements BundleActivator {
  public void start(BundleContext bundleContext) {}
  
  public void stop(BundleContext bundleContext) {}
}
