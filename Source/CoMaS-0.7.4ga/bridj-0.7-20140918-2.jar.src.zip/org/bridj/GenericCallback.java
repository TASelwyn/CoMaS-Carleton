package org.bridj;

public interface GenericCallback {
  Object apply(Object... paramVarArgs);
}
