package org.bridj;

class DefaultPointer<T> {}
