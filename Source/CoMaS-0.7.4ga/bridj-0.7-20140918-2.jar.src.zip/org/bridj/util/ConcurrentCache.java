package org.bridj.util;

import java.lang.reflect.Constructor;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentCache<K, V> {
  protected final ConcurrentHashMap<K, V> map = new ConcurrentHashMap<K, V>();
  
  protected final Class<V> valueClass;
  
  private volatile Constructor<V> valueConstructor;
  
  public ConcurrentCache(Class<V> valueClass) {
    this.valueClass = valueClass;
  }
  
  private Constructor<V> getValueConstructor() {
    if (this.valueConstructor == null)
      try {
        this.valueConstructor = this.valueClass.getConstructor(new Class[0]);
        if (this.valueConstructor != null && this.valueConstructor.isAccessible())
          this.valueConstructor.setAccessible(true); 
      } catch (Exception ex) {
        throw new RuntimeException("No accessible default constructor in class " + ((this.valueClass == null) ? "null" : this.valueClass.getName()), ex);
      }  
    return this.valueConstructor;
  }
  
  protected V newInstance(K key) {
    try {
      return getValueConstructor().newInstance(new Object[0]);
    } catch (Exception ex) {
      throw new RuntimeException("Failed to call constructor " + this.valueConstructor, ex);
    } 
  }
  
  public V get(K key) {
    V v = this.map.get(key);
    if (v == null) {
      V newV = newInstance(key);
      V oldV = this.map.putIfAbsent(key, newV);
      if (oldV != null) {
        v = oldV;
      } else {
        v = newV;
      } 
    } 
    return v;
  }
  
  public void clear() {
    this.map.clear();
  }
  
  public Iterable<Map.Entry<K, V>> entrySet() {
    return this.map.entrySet();
  }
}
