package org.bridj;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bridj.ann.Name;
import org.bridj.ann.Symbol;
import org.bridj.demangling.Demangler;
import org.bridj.demangling.GCC4Demangler;
import org.bridj.demangling.VC9Demangler;
import org.bridj.util.AnnotationUtils;

public class NativeLibrary {
  volatile long handle;
  
  volatile long symbols;
  
  String path;
  
  final File canonicalFile;
  
  NativeEntities nativeEntities = new NativeEntities();
  
  Map<Long, Demangler.Symbol> addrToName;
  
  Map<String, Demangler.Symbol> nameToSym;
  
  protected NativeLibrary(String path, long handle, long symbols) throws IOException {
    this.path = path;
    this.handle = handle;
    this.symbols = symbols;
    this.canonicalFile = (path == null) ? null : (new File(path)).getCanonicalFile();
    Platform.addNativeLibrary(this);
  }
  
  long getSymbolsHandle() {
    return this.symbols;
  }
  
  NativeEntities getNativeEntities() {
    return this.nativeEntities;
  }
  
  static String followGNULDScript(String path) {
    try {
      Reader r = new FileReader(path);
      try {
        char c;
        while ((c = (char)r.read()) == ' ' || c == '\t' || c == '\n');
        if (c == '/' && r.read() == 42) {
          BufferedReader br = new BufferedReader(r);
          r = br;
          StringBuilder b = new StringBuilder("/*");
          String line;
          while ((line = br.readLine()) != null)
            b.append(line).append('\n'); 
          String src = b.toString();
          Pattern ldGroupPattern = Pattern.compile("GROUP\\s*\\(\\s*([^\\s)]+)[^)]*\\)");
          Matcher m = ldGroupPattern.matcher(src);
          if (m.find()) {
            String actualPath = m.group(1);
            if (BridJ.verbose)
              BridJ.info("Parsed LD script '" + path + "', found absolute reference to '" + actualPath + "'"); 
            return actualPath;
          } 
          BridJ.error("Failed to parse LD script '" + path + "' !");
        } 
      } finally {
        r.close();
      } 
    } catch (Throwable th) {
      BridJ.error("Unexpected error: " + th, th);
    } 
    return path;
  }
  
  public static NativeLibrary load(String path) throws IOException {
    long handle = 0L;
    File file = new File(path);
    boolean exists = file.exists();
    if (file.isAbsolute() && !exists)
      return null; 
    if (Platform.isUnix() && exists)
      path = followGNULDScript(path); 
    handle = JNI.loadLibrary(path);
    if (handle == 0L)
      return null; 
    long symbols = JNI.loadLibrarySymbols(path);
    return new NativeLibrary(path, handle, symbols);
  }
  
  long getHandle() {
    if (this.path != null && this.handle == 0L)
      throw new RuntimeException("Library was released and cannot be used anymore"); 
    return this.handle;
  }
  
  protected void finalize() throws Throwable {
    release();
  }
  
  public synchronized void release() {
    if (this.handle == 0L)
      return; 
    if (BridJ.verbose)
      BridJ.info("Releasing library '" + this.path + "'"); 
    this.nativeEntities.release();
    JNI.freeLibrarySymbols(this.symbols);
    JNI.freeLibrary(this.handle);
    this.handle = 0L;
    if (this.canonicalFile != null && Platform.temporaryExtractedLibraryCanonicalFiles.remove(this.canonicalFile))
      if (this.canonicalFile.delete()) {
        if (BridJ.verbose)
          BridJ.info("Deleted temporary library file '" + this.canonicalFile + "'"); 
      } else {
        BridJ.error("Failed to delete temporary library file '" + this.canonicalFile + "'");
      }  
  }
  
  public Pointer<?> getSymbolPointer(String name) {
    return Pointer.pointerToAddress(getSymbolAddress(name));
  }
  
  public long getSymbolAddress(String name) {
    if (this.nameToSym != null) {
      Demangler.Symbol addr = this.nameToSym.get(name);
      if (addr != null)
        return addr.getAddress(); 
    } 
    long address = JNI.findSymbolInLibrary(getHandle(), name);
    if (address == 0L)
      address = JNI.findSymbolInLibrary(getHandle(), "_" + name); 
    return address;
  }
  
  public synchronized Demangler.Symbol getSymbol(AnnotatedElement member) throws FileNotFoundException {
    Symbol mg = (Symbol)AnnotationUtils.getAnnotation(Symbol.class, member, new java.lang.annotation.Annotation[0]);
    String name = null;
    Name nameAnn = member.<Name>getAnnotation(Name.class);
    if (nameAnn != null) {
      name = nameAnn.value();
    } else if (member instanceof Member) {
      name = ((Member)member).getName();
    } 
    List<String> names = new ArrayList<String>();
    if (mg != null)
      names.addAll(Arrays.asList(mg.value())); 
    if (name != null)
      names.add(name); 
    for (String n : names) {
      Demangler.Symbol handle = getSymbol(n);
      if (handle == null)
        handle = getSymbol("_" + n); 
      if (handle == null)
        handle = getSymbol(n + (Platform.useUnicodeVersionOfWindowsAPIs ? "W" : "A")); 
      if (handle != null)
        return handle; 
    } 
    if (member instanceof Method) {
      Method method = (Method)member;
      for (Demangler.Symbol symbol : getSymbols()) {
        if (symbol.matches(method))
          return symbol; 
      } 
    } 
    return null;
  }
  
  public boolean isMSVC() {
    return Platform.isWindows();
  }
  
  public Demangler.Symbol getFirstMatchingSymbol(SymbolAccepter accepter) {
    for (Demangler.Symbol symbol : getSymbols()) {
      if (accepter.accept(symbol))
        return symbol; 
    } 
    return null;
  }
  
  public Collection<Demangler.Symbol> getSymbols() {
    try {
      scanSymbols();
    } catch (Exception ex) {
      assert BridJ.error("Failed to scan symbols of library '" + this.path + "'", ex);
    } 
    return (this.nameToSym == null) ? Collections.EMPTY_LIST : Collections.<Demangler.Symbol>unmodifiableCollection(this.nameToSym.values());
  }
  
  public String getSymbolName(long address) {
    if (this.addrToName == null && getSymbolsHandle() != 0L)
      return JNI.findSymbolName(getHandle(), getSymbolsHandle(), address); 
    Demangler.Symbol symbol = getSymbol(address);
    return (symbol == null) ? null : symbol.getSymbol();
  }
  
  public Demangler.Symbol getSymbol(long address) {
    try {
      scanSymbols();
      Demangler.Symbol symbol = this.addrToName.get(Long.valueOf(address));
      return symbol;
    } catch (Exception ex) {
      throw new RuntimeException("Failed to get name of address " + address, ex);
    } 
  }
  
  public Demangler.Symbol getSymbol(String name) {
    try {
      if (this.nameToSym == null) {
        long addr = JNI.findSymbolInLibrary(getHandle(), name);
        if (addr != 0L) {
          Demangler.Symbol symbol1 = new Demangler.Symbol(name, this);
          symbol1.setAddress(addr);
          return symbol1;
        } 
      } 
      scanSymbols();
      if (this.nameToSym == null)
        return null; 
      Demangler.Symbol symbol = this.nameToSym.get(name);
      if (this.addrToName == null && 
        symbol == null) {
        long addr = JNI.findSymbolInLibrary(getHandle(), name);
        if (addr != 0L) {
          symbol = new Demangler.Symbol(name, this);
          symbol.setAddress(addr);
          this.nameToSym.put(name, symbol);
        } 
      } 
      return symbol;
    } catch (Exception ex) {
      ex.printStackTrace();
      return null;
    } 
  }
  
  void scanSymbols() throws Exception {
    if (this.addrToName != null)
      return; 
    this.nameToSym = new HashMap<String, Demangler.Symbol>();
    String[] symbs = null;
    if (symbs == null)
      symbs = JNI.getLibrarySymbols(getHandle(), getSymbolsHandle()); 
    if (symbs == null)
      return; 
    this.addrToName = new HashMap<Long, Demangler.Symbol>();
    boolean is32 = !Platform.is64Bits();
    for (String name : symbs) {
      if (name != null) {
        long addr = JNI.findSymbolInLibrary(getHandle(), name);
        if (addr == 0L && name.startsWith("_")) {
          String n2 = name.substring(1);
          addr = JNI.findSymbolInLibrary(getHandle(), n2);
          if (addr == 0L) {
            n2 = "_" + name;
            addr = JNI.findSymbolInLibrary(getHandle(), n2);
          } 
          if (addr != 0L)
            name = n2; 
        } 
        if (addr == 0L) {
          if (BridJ.verbose)
            BridJ.warning("Symbol '" + name + "' not found."); 
        } else {
          Demangler.Symbol sym = new Demangler.Symbol(name, this);
          sym.setAddress(addr);
          this.addrToName.put(Long.valueOf(addr), sym);
          this.nameToSym.put(name, sym);
        } 
      } 
    } 
    if (BridJ.debug) {
      BridJ.info("Found " + this.nameToSym.size() + " symbols in '" + this.path + "' :");
      for (Demangler.Symbol sym : this.nameToSym.values())
        BridJ.info("DEBUG(BridJ): library=\"" + this.path + "\", symbol=\"" + sym.getSymbol() + "\", address=" + Long.toHexString(sym.getAddress()) + ", demangled=\"" + sym.getParsedRef() + "\""); 
    } 
  }
  
  public Demangler.MemberRef parseSymbol(String symbol) throws Demangler.DemanglingException {
    if ("__cxa_pure_virtual".equals(symbol))
      return null; 
    if (Platform.isWindows())
      try {
        Demangler.MemberRef result = (new VC9Demangler(this, symbol)).parseSymbol();
        if (result != null)
          return result; 
      } catch (Throwable th) {} 
    return (new GCC4Demangler(this, symbol)).parseSymbol();
  }
  
  public static interface SymbolAccepter {
    boolean accept(Demangler.Symbol param1Symbol);
  }
}
