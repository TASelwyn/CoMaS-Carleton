package edu.carleton.cas.modules;

public interface Module {
  boolean init();
  
  boolean start();
  
  boolean stop();
}
