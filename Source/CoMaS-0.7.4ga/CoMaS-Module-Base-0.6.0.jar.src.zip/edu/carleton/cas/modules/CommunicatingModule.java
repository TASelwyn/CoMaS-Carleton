package edu.carleton.cas.modules;

public interface CommunicatingModule extends Module {
  void receive(String paramString1, String paramString2);
}
