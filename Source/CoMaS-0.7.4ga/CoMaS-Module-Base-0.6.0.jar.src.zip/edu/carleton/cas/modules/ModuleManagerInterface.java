package edu.carleton.cas.modules;

import edu.carleton.cas.modules.exceptions.ModuleException;

public interface ModuleManagerInterface extends Bridge {
  Module find(String paramString);
  
  void send(String paramString1, String paramString2, String paramString3) throws ModuleException;
}
