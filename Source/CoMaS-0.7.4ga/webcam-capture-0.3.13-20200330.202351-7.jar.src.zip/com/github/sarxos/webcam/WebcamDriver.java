package com.github.sarxos.webcam;

import java.util.List;

public interface WebcamDriver {
  List<WebcamDevice> getDevices();
  
  boolean isThreadSafe();
}
