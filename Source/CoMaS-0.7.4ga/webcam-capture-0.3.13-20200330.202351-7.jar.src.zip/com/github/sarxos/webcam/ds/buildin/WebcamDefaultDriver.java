package com.github.sarxos.webcam.ds.buildin;

import com.github.sarxos.webcam.WebcamDevice;
import com.github.sarxos.webcam.WebcamDiscoverySupport;
import com.github.sarxos.webcam.WebcamDriver;
import com.github.sarxos.webcam.WebcamTask;
import com.github.sarxos.webcam.ds.buildin.natives.Device;
import com.github.sarxos.webcam.ds.buildin.natives.DeviceList;
import com.github.sarxos.webcam.ds.buildin.natives.OpenIMAJGrabber;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import org.bridj.Pointer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WebcamDefaultDriver implements WebcamDriver, WebcamDiscoverySupport {
  static {
    if (!"true".equals(System.getProperty("webcam.debug")))
      System.setProperty("bridj.quiet", "true"); 
  }
  
  private static class WebcamNewGrabberTask extends WebcamTask {
    private AtomicReference<OpenIMAJGrabber> grabber = new AtomicReference<>();
    
    public WebcamNewGrabberTask(WebcamDriver driver) {
      super(driver, null);
    }
    
    public OpenIMAJGrabber newGrabber() {
      try {
        process();
      } catch (InterruptedException e) {
        WebcamDefaultDriver.LOG.error("Processor has been interrupted");
        return null;
      } 
      return this.grabber.get();
    }
    
    protected void handle() {
      this.grabber.set(new OpenIMAJGrabber());
    }
  }
  
  private static class GetDevicesTask extends WebcamTask {
    private volatile List<WebcamDevice> devices = null;
    
    private volatile OpenIMAJGrabber grabber = null;
    
    public GetDevicesTask(WebcamDriver driver) {
      super(driver, null);
    }
    
    public List<WebcamDevice> getDevices(OpenIMAJGrabber grabber) {
      this.grabber = grabber;
      try {
        process();
      } catch (InterruptedException e) {
        WebcamDefaultDriver.LOG.error("Processor has been interrupted");
        return Collections.emptyList();
      } 
      return this.devices;
    }
    
    protected void handle() {
      this.devices = new ArrayList<>();
      Pointer<DeviceList> pointer = this.grabber.getVideoDevices();
      DeviceList list = (DeviceList)pointer.get();
      for (Device device : list.asArrayList())
        this.devices.add(new WebcamDefaultDevice(device)); 
    }
  }
  
  private static final Logger LOG = LoggerFactory.getLogger(WebcamDefaultDriver.class);
  
  private static OpenIMAJGrabber grabber = null;
  
  public List<WebcamDevice> getDevices() {
    LOG.debug("Searching devices");
    if (grabber == null) {
      WebcamNewGrabberTask task = new WebcamNewGrabberTask(this);
      grabber = task.newGrabber();
      if (grabber == null)
        return Collections.emptyList(); 
    } 
    List<WebcamDevice> devices = (new GetDevicesTask(this)).getDevices(grabber);
    if (LOG.isDebugEnabled())
      for (WebcamDevice device : devices)
        LOG.debug("Found device {}", device.getName());  
    return devices;
  }
  
  public long getScanInterval() {
    return 3000L;
  }
  
  public boolean isScanPossible() {
    return true;
  }
  
  public boolean isThreadSafe() {
    return false;
  }
}
