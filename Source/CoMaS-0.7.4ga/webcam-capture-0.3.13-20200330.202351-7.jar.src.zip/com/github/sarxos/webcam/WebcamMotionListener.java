package com.github.sarxos.webcam;

public interface WebcamMotionListener {
  void motionDetected(WebcamMotionEvent paramWebcamMotionEvent);
}
