package com.github.sarxos.webcam.util.jh;

import com.github.sarxos.webcam.util.ImageUtils;
import java.awt.image.BufferedImage;

public class JHNormalizeFilter extends JHFilter {
  public BufferedImage filter(BufferedImage src, BufferedImage dest) {
    int w = src.getWidth();
    int h = src.getHeight();
    int max = 1;
    int x;
    for (x = 0; x < w; x++) {
      for (int y = 0; y < h; y++) {
        int c = src.getRGB(x, y);
        int a = ImageUtils.clamp(c >> 24 & 0xFF);
        int r = ImageUtils.clamp(c >> 16 & 0xFF);
        int g = ImageUtils.clamp(c >> 8 & 0xFF);
        int b = ImageUtils.clamp(c & 0xFF);
        int i = a << 24 | r << 16 | g << 8 | b;
        if (i > max)
          max = i; 
      } 
    } 
    for (x = 0; x < w; x++) {
      for (int y = 0; y < h; y++) {
        int c = src.getRGB(x, y);
        int i = c * 256 / max;
        dest.setRGB(x, y, i);
      } 
    } 
    return dest;
  }
}
