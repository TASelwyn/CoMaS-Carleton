package com.ibm.media.codec.audio.dvi;

class DVIState {
  public int valprev;
  
  public int index;
}
