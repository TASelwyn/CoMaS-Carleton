package com.ibm.media.bean.multiplayer;

import java.net.MalformedURLException;
import java.net.URL;

public class RelatedLink {
  public String link;
  
  public long startTime = 0L;
  
  public long stopTime = 0L;
  
  public URL uLink = null;
  
  public String description;
  
  private MultiPlayerBean owner = null;
  
  public RelatedLink(String rl, long st, long et, MultiPlayerBean o) throws MalformedURLException {
    this.owner = o;
    this.uLink = this.owner.getURL(rl);
    if (this.uLink == null)
      throw new MalformedURLException(); 
    this.link = rl;
    this.startTime = st;
    this.stopTime = et;
  }
  
  public void setLink(String l) {
    this.link = l;
    this.uLink = this.owner.getURL(l);
  }
}
