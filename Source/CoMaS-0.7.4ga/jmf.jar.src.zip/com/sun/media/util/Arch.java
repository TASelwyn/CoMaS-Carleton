package com.sun.media.util;

public class Arch {
  public static final int SPARC = 1;
  
  public static final int UNIX = 2;
  
  public static final int WIN32 = 4;
  
  public static final int SOLARIS = 8;
  
  public static final int LINUX = 16;
  
  public static final int X86 = 32;
  
  public static boolean isBigEndian() {
    return false;
  }
  
  public static boolean isLittleEndian() {
    return true;
  }
  
  public static int getAlignment() {
    return 1;
  }
  
  public static int getArch() {
    return 36;
  }
}
