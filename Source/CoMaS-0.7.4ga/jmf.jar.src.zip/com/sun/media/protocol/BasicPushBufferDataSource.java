package com.sun.media.protocol;

import java.io.IOException;
import javax.media.Duration;
import javax.media.Time;
import javax.media.protocol.PushBufferDataSource;

public abstract class BasicPushBufferDataSource extends PushBufferDataSource {
  protected Object[] controls = new Object[0];
  
  protected boolean started = false;
  
  protected String contentType = "content/unknown";
  
  protected boolean connected = false;
  
  protected Time duration = Duration.DURATION_UNKNOWN;
  
  public String getContentType() {
    if (!this.connected) {
      System.err.println("Error: DataSource not connected");
      return null;
    } 
    return this.contentType;
  }
  
  public void connect() throws IOException {
    if (this.connected)
      return; 
    this.connected = true;
  }
  
  public void disconnect() {
    try {
      if (this.started)
        stop(); 
    } catch (IOException e) {}
    this.connected = false;
  }
  
  public void start() throws IOException {
    if (!this.connected)
      throw new Error("DataSource must be connected before it can be started"); 
    if (this.started)
      return; 
    this.started = true;
  }
  
  public void stop() throws IOException {
    if (!this.connected || !this.started)
      return; 
    this.started = false;
  }
  
  public Object[] getControls() {
    return this.controls;
  }
  
  public Object getControl(String controlType) {
    try {
      Class cls = Class.forName(controlType);
      Object[] cs = getControls();
      for (int i = 0; i < cs.length; i++) {
        if (cls.isInstance(cs[i]))
          return cs[i]; 
      } 
      return null;
    } catch (Exception e) {
      return null;
    } 
  }
  
  public Time getDuration() {
    return this.duration;
  }
}
