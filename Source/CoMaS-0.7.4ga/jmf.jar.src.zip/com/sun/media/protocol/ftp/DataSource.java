package com.sun.media.protocol.ftp;

import com.sun.media.protocol.DataSource;

public class DataSource extends DataSource {}
