package com.sun.media.protocol;

public interface RTPSource {
  int getSSRC();
  
  String getCNAME();
  
  void prebuffer();
  
  void flush();
  
  void setBufferListener(BufferListener paramBufferListener);
}
