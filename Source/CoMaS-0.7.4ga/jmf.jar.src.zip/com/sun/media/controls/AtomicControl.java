package com.sun.media.controls;

import javax.media.Control;

public interface AtomicControl extends Control {
  boolean isDefault();
  
  void setVisible(boolean paramBoolean);
  
  boolean getVisible();
  
  void setEnabled(boolean paramBoolean);
  
  boolean getEnabled();
  
  Control getParent();
  
  void addControlChangeListener(ControlChangeListener paramControlChangeListener);
  
  void removeControlChangeListener(ControlChangeListener paramControlChangeListener);
  
  boolean isReadOnly();
  
  String getTip();
  
  void setTip(String paramString);
}
