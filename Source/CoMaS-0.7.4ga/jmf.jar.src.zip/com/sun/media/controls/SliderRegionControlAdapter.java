package com.sun.media.controls;

import java.awt.Component;
import javax.media.Control;

public class SliderRegionControlAdapter extends AtomicControlAdapter implements SliderRegionControl {
  long min;
  
  long max;
  
  boolean enable;
  
  public SliderRegionControlAdapter() {
    super(null, true, null);
    this.enable = true;
  }
  
  public SliderRegionControlAdapter(Component c, boolean def, Control parent) {
    super(c, def, parent);
  }
  
  public long setMinValue(long value) {
    this.min = value;
    informListeners();
    return this.min;
  }
  
  public long getMinValue() {
    return this.min;
  }
  
  public long setMaxValue(long value) {
    this.max = value;
    informListeners();
    return this.max;
  }
  
  public long getMaxValue() {
    return this.max;
  }
  
  public boolean isEnable() {
    return this.enable;
  }
  
  public void setEnable(boolean f) {
    this.enable = f;
  }
}
