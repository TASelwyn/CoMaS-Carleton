package com.sun.media.controls;

public interface BooleanControl extends AtomicControl {
  boolean getValue();
  
  boolean setValue(boolean paramBoolean);
}
