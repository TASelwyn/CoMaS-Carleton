package com.sun.media.codec.video.cinepak;

import javax.media.Buffer;
import javax.media.format.VideoFormat;

public class CPChunk {
  int fChunkType;
  
  int fChunkLen;
  
  int[] lookup;
  
  static int[] fBounding24;
  
  static int firstFlag;
  
  public CPChunk() {
    firstFlag = 1;
  }
  
  public CPChunk(int[] l) {
    this.lookup = l;
    firstFlag = 1;
  }
  
  public void setLookup(int[] l) {
    this.lookup = l;
  }
  
  public void processChunk(byte[] inData, CineStore myStor, int whichStrip, int ChunkStart, Buffer outBuffer) {
    fBounding24 = CineStore.BOUNDING24;
    this.fChunkType = (inData[ChunkStart] & 0xFF) * 256 + (inData[ChunkStart + 1] & 0xFF);
    this.fChunkLen = (inData[ChunkStart + 2] & 0xFF) * 256 + (inData[ChunkStart + 3] & 0xFF);
    switch (this.fChunkType) {
      case 8192:
        doCFUpdate(inData, ChunkStart + 4, (myStor.StripVec[whichStrip]).Detail);
        break;
      case 8704:
        doCFUpdate(inData, ChunkStart + 4, (myStor.StripVec[whichStrip]).Smooth);
        break;
      case 8448:
        doCPUpdate(inData, ChunkStart + 4, (myStor.StripVec[whichStrip]).Detail);
        break;
      case 8960:
        doCPUpdate(inData, ChunkStart + 4, (myStor.StripVec[whichStrip]).Smooth);
        break;
      case 12288:
        doFKUpdate(inData, ChunkStart + 4, myStor, whichStrip, outBuffer);
        break;
      case 12800:
        doFSKUpdate(inData, ChunkStart + 4, myStor, whichStrip, outBuffer);
        break;
      case 12544:
        doIUpdate(inData, ChunkStart + 4, myStor, whichStrip, outBuffer);
        break;
      case 9216:
        doGFUpdate(inData, ChunkStart + 4, (myStor.StripVec[whichStrip]).Detail);
        break;
      case 9728:
        doGFUpdate(inData, ChunkStart + 4, (myStor.StripVec[whichStrip]).Smooth);
        break;
      case 9472:
        doGPUpdate(inData, ChunkStart + 4, (myStor.StripVec[whichStrip]).Detail);
        break;
      case 9984:
        doGPUpdate(inData, ChunkStart + 4, (myStor.StripVec[whichStrip]).Smooth);
        break;
    } 
  }
  
  public String getChunkType() {
    switch (this.fChunkType) {
      case 8704:
        return "color full    smooth codebook update";
      case 8192:
        return "color full    detail codebook update";
      case 8960:
        return "color partial smooth codebook update";
      case 8448:
        return "color partial detail codebook update";
      case 12288:
        return "full key frame update";
      case 12800:
        return "full smooth key frame update";
      case 12544:
        return "interframe update";
      case 9216:
        return "greyscale full smooth codebook update";
      case 9728:
        return "greyscale full detail codebook update";
      case 9472:
        return "greyscale partial smooth codebook update";
      case 9984:
        return "greyscale partial detail codebook update";
    } 
    return "WARNING******* unknown atom chunk type...*******";
  }
  
  public int getChunkLength() {
    return this.fChunkLen;
  }
  
  private void doCFUpdate(byte[] ChunkArray, int ChunkDataStart, CodeEntry[] codebook) {
    int numberOfCodes = ((ChunkArray[ChunkDataStart - 2] & 0xFF) * 256 + (ChunkArray[ChunkDataStart - 1] & 0xFF) - 4) / 6;
    for (int i = 0; i < numberOfCodes; i++) {
      int Y0 = ChunkArray[ChunkDataStart + i * 6] & 0xFF;
      int Y1 = ChunkArray[ChunkDataStart + i * 6 + 1] & 0xFF;
      int Y2 = ChunkArray[ChunkDataStart + i * 6 + 2] & 0xFF;
      int Y3 = ChunkArray[ChunkDataStart + i * 6 + 3] & 0xFF;
      int U = ChunkArray[ChunkDataStart + i * 6 + 4];
      int V = ChunkArray[ChunkDataStart + i * 6 + 5];
      int delR = 2 * U + 128;
      int delB = 2 * V + 128;
      int delG = -(U / 2) - V + 128;
      (codebook[i]).aRGB0 = (fBounding24[Y0 + delR] << 16) + (fBounding24[Y0 + delG] << 8) + fBounding24[Y0 + delB];
      (codebook[i]).aRGB1 = (fBounding24[Y1 + delR] << 16) + (fBounding24[Y1 + delG] << 8) + fBounding24[Y1 + delB];
      (codebook[i]).aRGB2 = (fBounding24[Y2 + delR] << 16) + (fBounding24[Y2 + delG] << 8) + fBounding24[Y2 + delB];
      (codebook[i]).aRGB3 = (fBounding24[Y3 + delR] << 16) + (fBounding24[Y3 + delG] << 8) + fBounding24[Y3 + delB];
    } 
  }
  
  private void doCPUpdate(byte[] ChunkArray, int ChunkDataStart, CodeEntry[] codebook) {
    int ByteCounter = ChunkDataStart;
    int CodeCount = 0;
    int len = (ChunkArray[ChunkDataStart - 2] & 0xFF) * 256 + (ChunkArray[ChunkDataStart - 1] & 0xFF) - 4 + ByteCounter;
    while (ByteCounter < len && CodeCount < 256) {
      int Map = ChunkArray[ByteCounter++] & 0xFF;
      Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
      Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
      Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
      int Mask = Integer.MIN_VALUE;
      for (int i = 0; i < 32 && ByteCounter < len && CodeCount < 256; i++) {
        if ((Mask & Map) != 0) {
          int Y0 = ChunkArray[ByteCounter++] & 0xFF;
          int Y1 = ChunkArray[ByteCounter++] & 0xFF;
          int Y2 = ChunkArray[ByteCounter++] & 0xFF;
          int Y3 = ChunkArray[ByteCounter++] & 0xFF;
          int U = ChunkArray[ByteCounter++];
          int V = ChunkArray[ByteCounter++];
          int delR = 2 * U + 128;
          int delB = 2 * V + 128;
          int delG = -(U / 2) - V + 128;
          (codebook[CodeCount]).aRGB0 = (fBounding24[Y0 + delR] << 16) + (fBounding24[Y0 + delG] << 8) + fBounding24[Y0 + delB];
          (codebook[CodeCount]).aRGB1 = (fBounding24[Y1 + delR] << 16) + (fBounding24[Y1 + delG] << 8) + fBounding24[Y1 + delB];
          (codebook[CodeCount]).aRGB2 = (fBounding24[Y2 + delR] << 16) + (fBounding24[Y2 + delG] << 8) + fBounding24[Y2 + delB];
          (codebook[CodeCount]).aRGB3 = (fBounding24[Y3 + delR] << 16) + (fBounding24[Y3 + delG] << 8) + fBounding24[Y3 + delB];
        } 
        Mask >>>= 1;
        CodeCount++;
      } 
    } 
  }
  
  private void doFKUpdate(byte[] ChunkArray, int ChunkDataStart, CineStore myStor, int thisStrip, Buffer outBuffer) {
    int[] outData = (int[])outBuffer.getData();
    VideoFormat outFmt = (VideoFormat)outBuffer.getFormat();
    int outWidth = (outFmt.getSize()).width;
    CpStrip theStrip = myStor.StripVec[thisStrip];
    CodeEntry[] detailBook = theStrip.Detail;
    CodeEntry[] smoothBook = theStrip.Smooth;
    int len = (ChunkArray[ChunkDataStart - 2] & 0xFF) * 256 + (ChunkArray[ChunkDataStart - 1] & 0xFF) - 4 + ChunkDataStart;
    int xdraw = myStor.ImagePosX + myStor.StripPosX;
    int ydraw = myStor.ImagePosY + myStor.StripPosY;
    int ByteCounter = ChunkDataStart;
    int CodeCount = 0;
    while (ByteCounter < len && ydraw < myStor.ImagePosY + myStor.ImageSizeY) {
      int Map = ChunkArray[ByteCounter++] & 0xFF;
      Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
      Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
      Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
      int Mask = Integer.MIN_VALUE;
      for (int i = 0; i < 32 && ByteCounter < len && ydraw < myStor.ImagePosY + myStor.ImageSizeY; i++) {
        if ((Mask & Map) != 0) {
          CodeEntry thisCode = detailBook[ChunkArray[ByteCounter++] & 0xFF];
          int color = thisCode.aRGB0;
          int startLocation = xdraw + outWidth * ydraw;
          int location = startLocation;
          outData[location] = color;
          color = thisCode.aRGB1;
          location = startLocation + 1;
          outData[location] = color;
          color = thisCode.aRGB2;
          location = startLocation + outWidth;
          outData[location] = color;
          color = thisCode.aRGB3;
          location++;
          outData[location] = color;
          thisCode = detailBook[ChunkArray[ByteCounter++] & 0xFF];
          color = thisCode.aRGB0;
          startLocation = xdraw + 2 + outWidth * ydraw;
          location = startLocation;
          outData[location] = color;
          color = thisCode.aRGB1;
          location = startLocation + 1;
          outData[location] = color;
          color = thisCode.aRGB2;
          location = startLocation + outWidth;
          outData[location] = color;
          color = thisCode.aRGB3;
          location++;
          outData[location] = color;
          thisCode = detailBook[ChunkArray[ByteCounter++] & 0xFF];
          color = thisCode.aRGB0;
          startLocation = xdraw + outWidth * (ydraw + 2);
          location = startLocation;
          outData[location] = color;
          color = thisCode.aRGB1;
          location = startLocation + 1;
          outData[location] = color;
          color = thisCode.aRGB2;
          location = startLocation + outWidth;
          outData[location] = color;
          color = thisCode.aRGB3;
          location++;
          outData[location] = color;
          thisCode = detailBook[ChunkArray[ByteCounter++] & 0xFF];
          color = thisCode.aRGB0;
          startLocation = xdraw + 2 + outWidth * (ydraw + 2);
          location = startLocation;
          outData[location] = color;
          color = thisCode.aRGB1;
          location = startLocation + 1;
          outData[location] = color;
          color = thisCode.aRGB2;
          location = startLocation + outWidth;
          outData[location] = color;
          color = thisCode.aRGB3;
          outData[location + 1] = color;
        } else {
          CodeEntry codeEntry = smoothBook[ChunkArray[ByteCounter++] & 0xFF];
          int j = codeEntry.aRGB0;
          int k = xdraw + outWidth * ydraw;
          int m = k;
          outData[m] = j;
          outData[m + 1] = j;
          m += outWidth;
          outData[m] = j;
          outData[m + 1] = j;
          j = codeEntry.aRGB1;
          m = k + 2;
          outData[m] = j;
          outData[m + 1] = j;
          m += outWidth;
          outData[m] = j;
          outData[m + 1] = j;
          j = codeEntry.aRGB2;
          m = k += outWidth * 2;
          outData[m] = j;
          outData[m + 1] = j;
          m += outWidth;
          outData[m] = j;
          outData[m + 1] = j;
          j = codeEntry.aRGB3;
          m = k + 2;
          outData[m] = j;
          outData[m + 1] = j;
          m += outWidth;
          outData[m] = j;
          outData[m + 1] = j;
        } 
        xdraw += 4;
        Mask >>>= 1;
        CodeCount++;
        if (xdraw > myStor.ImageSizeX - 4) {
          xdraw = myStor.ImagePosX + myStor.StripPosX;
          ydraw += 4;
        } 
      } 
    } 
  }
  
  private void doFSKUpdate(byte[] ChunkArray, int ChunkDataStart, CineStore myStor, int thisStrip, Buffer outBuffer) {
    int[] outData = (int[])outBuffer.getData();
    VideoFormat outFmt = (VideoFormat)outBuffer.getFormat();
    int outWidth = (outFmt.getSize()).width;
    CpStrip theStrip = myStor.StripVec[thisStrip];
    CodeEntry[] detailBook = theStrip.Detail;
    CodeEntry[] smoothBook = theStrip.Smooth;
    int len = (ChunkArray[ChunkDataStart - 2] & 0xFF) * 256 + (ChunkArray[ChunkDataStart - 1] & 0xFF) - 4 + ChunkDataStart;
    int xdraw = myStor.ImagePosX + myStor.StripPosX;
    int ydraw = myStor.ImagePosY + myStor.StripPosY;
    int ByteCounter = ChunkDataStart;
    while (ByteCounter < len) {
      CodeEntry thisCode = smoothBook[ChunkArray[ByteCounter++] & 0xFF];
      int color = thisCode.aRGB0;
      int startLocation = xdraw + outWidth * ydraw;
      if (startLocation >= outData.length)
        break; 
      int location = startLocation;
      outData[location] = color;
      outData[location + 1] = color;
      location += outWidth;
      outData[location] = color;
      outData[location + 1] = color;
      color = thisCode.aRGB1;
      location = startLocation + 2;
      outData[location] = color;
      outData[location + 1] = color;
      location += outWidth;
      outData[location] = color;
      outData[location + 1] = color;
      color = thisCode.aRGB2;
      location = startLocation += outWidth * 2;
      outData[location] = color;
      outData[location + 1] = color;
      location += outWidth;
      outData[location] = color;
      outData[location + 1] = color;
      color = thisCode.aRGB3;
      location = startLocation + 2;
      outData[location] = color;
      outData[location + 1] = color;
      location += outWidth;
      outData[location] = color;
      outData[location + 1] = color;
      xdraw += 4;
      if (xdraw > myStor.ImageSizeX - 4) {
        xdraw = myStor.ImagePosX + myStor.StripPosX;
        ydraw += 4;
      } 
    } 
  }
  
  private void doIUpdate(byte[] ChunkArray, int ChunkDataStart, CineStore myStor, int thisStrip, Buffer outBuffer) {
    int[] outData = (int[])outBuffer.getData();
    VideoFormat outFmt = (VideoFormat)outBuffer.getFormat();
    int outWidth = (outFmt.getSize()).width;
    CodeEntry[] detailBook = (myStor.StripVec[thisStrip]).Detail;
    CodeEntry[] smoothBook = (myStor.StripVec[thisStrip]).Smooth;
    int len = (ChunkArray[ChunkDataStart - 2] & 0xFF) * 256 + (ChunkArray[ChunkDataStart - 1] & 0xFF) - 4 + ChunkDataStart;
    int xdraw = myStor.ImagePosX + myStor.StripPosX;
    int ydraw = myStor.ImagePosY + myStor.StripPosY;
    int ByteCounter = ChunkDataStart;
    int Map = 0;
    int Mask = 0;
    int FinishY = myStor.ImagePosY + myStor.StripPosY + myStor.StripPosY1;
    while (ByteCounter < len && ydraw < FinishY) {
      Mask >>>= 1;
      if (Mask == 0) {
        Map = ChunkArray[ByteCounter++] & 0xFF;
        Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
        Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
        Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
        Mask = Integer.MIN_VALUE;
      } 
      if ((Mask & Map) != 0 && ByteCounter < len) {
        Mask >>>= 1;
        if (Mask == 0) {
          Map = ChunkArray[ByteCounter++] & 0xFF;
          Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
          Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
          Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
          Mask = Integer.MIN_VALUE;
        } 
        if ((Mask & Map) != 0) {
          int startLocation = xdraw + outWidth * ydraw;
          CodeEntry thisCode = detailBook[ChunkArray[ByteCounter++] & 0xFF];
          outData[startLocation] = thisCode.aRGB0;
          outData[startLocation + 1] = thisCode.aRGB1;
          outData[startLocation + outWidth] = thisCode.aRGB2;
          outData[startLocation + outWidth + 1] = thisCode.aRGB3;
          startLocation = xdraw + 2 + outWidth * ydraw;
          thisCode = detailBook[ChunkArray[ByteCounter++] & 0xFF];
          outData[startLocation] = thisCode.aRGB0;
          outData[startLocation + 1] = thisCode.aRGB1;
          outData[startLocation + outWidth] = thisCode.aRGB2;
          outData[startLocation + outWidth + 1] = thisCode.aRGB3;
          thisCode = detailBook[ChunkArray[ByteCounter++] & 0xFF];
          startLocation = xdraw + outWidth * (ydraw + 2);
          outData[startLocation] = thisCode.aRGB0;
          outData[startLocation + 1] = thisCode.aRGB1;
          outData[startLocation + outWidth] = thisCode.aRGB2;
          outData[startLocation + outWidth + 1] = thisCode.aRGB3;
          thisCode = detailBook[ChunkArray[ByteCounter++] & 0xFF];
          startLocation = xdraw + 2 + outWidth * (ydraw + 2);
          outData[startLocation] = thisCode.aRGB0;
          outData[startLocation + 1] = thisCode.aRGB1;
          outData[startLocation + outWidth] = thisCode.aRGB2;
          outData[startLocation + outWidth + 1] = thisCode.aRGB3;
        } else {
          CodeEntry codeEntry = smoothBook[ChunkArray[ByteCounter++] & 0xFF];
          int color = codeEntry.aRGB0;
          int i = xdraw + outWidth * ydraw;
          int location = i;
          outData[location] = color;
          outData[location + 1] = color;
          location += outWidth;
          outData[location] = color;
          outData[location + 1] = color;
          color = codeEntry.aRGB1;
          location = i + 2;
          outData[location] = color;
          outData[location + 1] = color;
          location += outWidth;
          outData[location] = color;
          outData[location + 1] = color;
          color = codeEntry.aRGB2;
          i += outWidth * 2;
          location = i;
          outData[location] = color;
          outData[location + 1] = color;
          location += outWidth;
          outData[location] = color;
          outData[location + 1] = color;
          color = codeEntry.aRGB3;
          location = i + 2;
          outData[location] = color;
          outData[location + 1] = color;
          location += outWidth;
          outData[location] = color;
          outData[location + 1] = color;
        } 
      } 
      xdraw += 4;
      if (xdraw > myStor.ImageSizeX - 4) {
        xdraw = myStor.ImagePosX + myStor.StripPosX;
        ydraw += 4;
      } 
    } 
  }
  
  private void doGFUpdate(byte[] ChunkArray, int ChunkDataStart, CodeEntry[] codebook) {
    int ByteCounter = ChunkDataStart;
    int numberOfCodes = ((ChunkArray[ChunkDataStart - 2] & 0xFF) * 256 + (ChunkArray[ChunkDataStart - 1] & 0xFF) - 4) / 4;
    if (this.lookup == null) {
      for (int i = 0; i < numberOfCodes; i++) {
        if (firstFlag == 1) {
          int anInt = ChunkArray[ByteCounter++] & 0xFF;
          (codebook[i]).aRGB0 = (anInt << 16) + (anInt << 8) + anInt;
          anInt = ChunkArray[ByteCounter++] & 0xFF;
          (codebook[i]).aRGB1 = (anInt << 16) + (anInt << 8) + anInt;
          anInt = ChunkArray[ByteCounter++] & 0xFF;
          (codebook[i]).aRGB2 = (anInt << 16) + (anInt << 8) + anInt;
          anInt = ChunkArray[ByteCounter++] & 0xFF;
          (codebook[i]).aRGB3 = (anInt << 16) + (anInt << 8) + anInt;
        } else {
          int j = ChunkArray[ByteCounter++] & 0xFF;
          (codebook[i]).aRGB0 = j << 16 | j << 8 | j;
          j = ChunkArray[ByteCounter++] & 0xFF;
          (codebook[i]).aRGB1 = j << 16 | j << 8 | j;
          j = ChunkArray[ByteCounter++] & 0xFF;
          (codebook[i]).aRGB2 = j << 16 | j << 8 | j;
          j = ChunkArray[ByteCounter++] & 0xFF;
          (codebook[i]).aRGB3 = j << 16 | j << 8 | j;
        } 
      } 
    } else {
      for (byte b = 0; b < numberOfCodes; b++) {
        if (firstFlag == 1) {
          int i = ChunkArray[ByteCounter++] & 0xFF;
          (codebook[b]).aRGB0 = this.lookup[i];
          i = ChunkArray[ByteCounter++] & 0xFF;
          (codebook[b]).aRGB1 = this.lookup[i];
          i = ChunkArray[ByteCounter++] & 0xFF;
          (codebook[b]).aRGB2 = this.lookup[i];
          i = ChunkArray[ByteCounter++] & 0xFF;
          (codebook[b]).aRGB3 = this.lookup[i];
        } else {
          int i = ChunkArray[ByteCounter++] & 0xFF;
          (codebook[b]).aRGB0 = this.lookup[i];
          i = ChunkArray[ByteCounter++] & 0xFF;
          (codebook[b]).aRGB1 = this.lookup[i];
          i = ChunkArray[ByteCounter++] & 0xFF;
          (codebook[b]).aRGB2 = this.lookup[i];
          i = ChunkArray[ByteCounter++] & 0xFF;
          (codebook[b]).aRGB3 = this.lookup[i];
        } 
      } 
    } 
    firstFlag = 0;
  }
  
  private void doGPUpdate(byte[] ChunkArray, int ChunkDataStart, CodeEntry[] codebook) {
    int ByteCounter = ChunkDataStart;
    int CodeCount = 0;
    int len = (ChunkArray[ChunkDataStart - 2] & 0xFF) * 256 + (ChunkArray[ChunkDataStart - 1] & 0xFF) - 4 + ChunkDataStart;
    if (this.lookup == null) {
      while (ByteCounter < len && CodeCount < 256) {
        int Map = ChunkArray[ByteCounter++] & 0xFF;
        Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
        Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
        Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
        int Mask = Integer.MIN_VALUE;
        for (int i = 0; i < 32 && ByteCounter < len && CodeCount < 256; i++) {
          if ((Mask & Map) != 0) {
            int anInt = ChunkArray[ByteCounter++] & 0xFF;
            (codebook[CodeCount]).aRGB0 = anInt << 16 | anInt << 8 | anInt;
            anInt = ChunkArray[ByteCounter++] & 0xFF;
            (codebook[CodeCount]).aRGB1 = anInt << 16 | anInt << 8 | anInt;
            anInt = ChunkArray[ByteCounter++] & 0xFF;
            (codebook[CodeCount]).aRGB2 = anInt << 16 | anInt << 8 | anInt;
            anInt = ChunkArray[ByteCounter++] & 0xFF;
            (codebook[CodeCount]).aRGB3 = anInt << 16 | anInt << 8 | anInt;
          } 
          Mask >>>= 1;
          CodeCount++;
        } 
      } 
    } else {
      while (ByteCounter < len && CodeCount < 256) {
        int Map = ChunkArray[ByteCounter++] & 0xFF;
        Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
        Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
        Map = Map * 256 + (ChunkArray[ByteCounter++] & 0xFF);
        int Mask = Integer.MIN_VALUE;
        for (int i = 0; i < 32 && ByteCounter < len && CodeCount < 256; i++) {
          if ((Mask & Map) != 0) {
            int anInt = ChunkArray[ByteCounter++] & 0xFF;
            (codebook[CodeCount]).aRGB0 = this.lookup[anInt];
            anInt = ChunkArray[ByteCounter++] & 0xFF;
            (codebook[CodeCount]).aRGB1 = this.lookup[anInt];
            anInt = ChunkArray[ByteCounter++] & 0xFF;
            (codebook[CodeCount]).aRGB2 = this.lookup[anInt];
            anInt = ChunkArray[ByteCounter++] & 0xFF;
            (codebook[CodeCount]).aRGB3 = this.lookup[anInt];
          } 
          Mask >>>= 1;
          CodeCount++;
        } 
      } 
    } 
  }
}
