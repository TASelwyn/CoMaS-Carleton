package com.sun.media.rtp;

import com.sun.media.rtp.util.Packet;
import com.sun.media.rtp.util.RTPPacket;
import javax.media.Buffer;

public class RTPDemultiplexer {
  private SSRCCache cache;
  
  private RTPRawReceiver rtpr;
  
  private Buffer buffer;
  
  private StreamSynch streamSynch;
  
  public RTPDemultiplexer(SSRCCache c, RTPRawReceiver r, StreamSynch streamSynch) {
    this.cache = c;
    this.rtpr = r;
    this.streamSynch = streamSynch;
    this.buffer = new Buffer();
  }
  
  public String consumerString() {
    return "RTP DeMultiplexer";
  }
  
  public void demuxpayload(Packet p) {
    demuxpayload(p);
  }
  
  public void demuxpayload(SourceRTPPacket sp) {
    SSRCInfo info = sp.ssrcinfo;
    RTPPacket p = sp.p;
    info.payloadType = p.payloadType;
    if (info.dstream != null) {
      this.buffer.setData(p.base.data);
      this.buffer.setFlags(0);
      if (p.marker == 1)
        this.buffer.setFlags(this.buffer.getFlags() | 0x800); 
      this.buffer.setLength(p.payloadlength);
      this.buffer.setOffset(p.payloadoffset);
      if (info.dstream.getFormat() instanceof javax.media.format.AudioFormat) {
        long ts = this.streamSynch.calcTimestamp(info.ssrc, p.payloadType, p.timestamp);
        this.buffer.setTimeStamp(ts);
      } else {
        long ts = this.streamSynch.calcTimestamp(info.ssrc, p.payloadType, p.timestamp);
        this.buffer.setTimeStamp(ts);
      } 
      this;
      this.buffer.setFlags(this.buffer.getFlags() | 0x1000);
      this.buffer.setSequenceNumber(p.seqnum);
      this.buffer.setFormat(info.dstream.getFormat());
      info.dstream.add(this.buffer, info.wrapped, this.rtpr);
    } 
  }
}
