package com.sun.media.rtp.util;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import com.sun.media.JMFSecurity;
import com.sun.media.JMFSecurityManager;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketException;

public class UDPPacketSender implements PacketConsumer {
  private DatagramSocket sock;
  
  private InetAddress address;
  
  private int port;
  
  private int ttl;
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] m = new Method[1];
  
  private Class[] cl = new Class[1];
  
  private Object[][] args = new Object[1][0];
  
  static {
    try {
      jmfSecurity = JMFSecurityManager.getJMFSecurity();
      securityPrivelege = true;
    } catch (SecurityException e) {}
  }
  
  public UDPPacketSender(DatagramSocket sock) {
    this.sock = sock;
  }
  
  public UDPPacketSender() throws IOException {
    this(new DatagramSocket());
  }
  
  public UDPPacketSender(int localPort) throws IOException {
    this(new DatagramSocket(localPort));
  }
  
  public UDPPacketSender(InetAddress remoteAddress, int remotePort) throws IOException {
    if (remoteAddress.isMulticastAddress()) {
      MulticastSocket sock = new MulticastSocket();
      this.sock = sock;
    } else {
      this.sock = new DatagramSocket();
    } 
    setRemoteAddress(remoteAddress, remotePort);
  }
  
  public InetAddress getLocalAddress() {
    return this.sock.getLocalAddress();
  }
  
  public UDPPacketSender(int localPort, InetAddress localAddress, InetAddress remoteAddress, int remotePort) throws IOException {
    if (remoteAddress.isMulticastAddress()) {
      MulticastSocket sock = new MulticastSocket(localPort);
      if (localAddress != null)
        sock.setInterface(localAddress); 
      this.sock = sock;
    } else if (localAddress != null) {
      try {
        this.sock = new DatagramSocket(localPort, localAddress);
      } catch (SocketException e) {
        System.out.println(e);
        System.out.println("localPort: " + localPort);
        System.out.println("localAddress: " + localAddress);
        throw e;
      } 
    } else {
      this.sock = new DatagramSocket(localPort);
    } 
    setRemoteAddress(remoteAddress, remotePort);
  }
  
  public DatagramSocket getSocket() {
    return this.sock;
  }
  
  public void setRemoteAddress(InetAddress remoteAddress, int remotePort) {
    this.address = remoteAddress;
    this.port = remotePort;
  }
  
  public void setttl(int ttl) throws IOException {
    this.ttl = ttl;
    if (this.sock instanceof MulticastSocket)
      ((MulticastSocket)this.sock).setTTL((byte)this.ttl); 
  }
  
  public int getLocalPort() {
    return this.sock.getLocalPort();
  }
  
  public void sendTo(Packet p) throws IOException {
    InetAddress addr = null;
    int port = 0;
    if (p instanceof UDPPacket) {
      UDPPacket udpp = (UDPPacket)p;
      addr = udpp.remoteAddress;
      port = udpp.remotePort;
      if (jmfSecurity != null) {
        String permission = null;
        try {
          if (jmfSecurity.getName().startsWith("jmf-security")) {
            if (udpp.remoteAddress.isMulticastAddress()) {
              permission = "multicast";
              jmfSecurity.requestPermission(this.m, this.cl, this.args, 512);
              this.m[0].invoke(this.cl[0], this.args[0]);
            } 
            permission = "connect";
            jmfSecurity.requestPermission(this.m, this.cl, this.args, 128);
            this.m[0].invoke(this.cl[0], this.args[0]);
          } else if (jmfSecurity.getName().startsWith("internet")) {
            PolicyEngine.checkPermission(PermissionID.NETIO);
            PolicyEngine.assertPermission(PermissionID.NETIO);
          } 
        } catch (Throwable e) {
          if (permission.startsWith("multicast")) {
            jmfSecurity.permissionFailureNotification(512);
          } else {
            jmfSecurity.permissionFailureNotification(128);
          } 
        } 
      } 
    } 
    if (addr == null)
      throw new IllegalArgumentException("No address set"); 
    send(p, addr, port);
  }
  
  public void send(Packet p, InetAddress addr, int port) throws IOException {
    byte[] data = p.data;
    if (p.offset > 0)
      System.arraycopy(data, p.offset, data = new byte[p.length], 0, p.length); 
    DatagramPacket dp = new DatagramPacket(data, p.length, addr, port);
    this.sock.send(dp);
  }
  
  public void closeConsumer() {
    if (this.sock != null) {
      this.sock.close();
      this.sock = null;
    } 
  }
  
  public String consumerString() {
    String s = "UDP Datagram Packet Sender on port " + this.sock.getLocalPort();
    if (this.address != null)
      s = s + " sending to address " + this.address + ", port " + this.port + ", ttl" + this.ttl; 
    return s;
  }
}
