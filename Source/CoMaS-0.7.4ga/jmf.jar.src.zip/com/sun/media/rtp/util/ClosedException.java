package com.sun.media.rtp.util;

import java.io.IOException;

public class ClosedException extends IOException {
  public ClosedException() {}
  
  public ClosedException(String m) {
    super(m);
  }
}
