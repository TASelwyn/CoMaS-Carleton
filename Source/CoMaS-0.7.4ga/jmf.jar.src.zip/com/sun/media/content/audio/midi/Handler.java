package com.sun.media.content.audio.midi;

import com.sun.media.BasicController;
import com.sun.media.BasicPlayer;
import com.sun.media.Log;
import com.sun.media.controls.GainControlAdapter;
import com.sun.media.parser.BasicPullParser;
import com.sun.media.parser.BasicTrack;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.media.BadHeaderException;
import javax.media.Buffer;
import javax.media.Control;
import javax.media.Controller;
import javax.media.ControllerEvent;
import javax.media.Duration;
import javax.media.DurationUpdateEvent;
import javax.media.EndOfMediaEvent;
import javax.media.IncompatibleSourceException;
import javax.media.StopByRequestEvent;
import javax.media.SystemTimeBase;
import javax.media.Time;
import javax.media.TimeBase;
import javax.media.Track;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.DataSource;
import javax.media.protocol.PullSourceStream;
import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MetaEventListener;
import javax.sound.midi.MetaMessage;
import javax.sound.midi.MidiChannel;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.Sequence;
import javax.sound.midi.Sequencer;
import javax.sound.midi.Synthesizer;

public class Handler extends BasicPlayer {
  private MidiController controller;
  
  protected DataSource datasource = null;
  
  private boolean closed = false;
  
  private int META_EVENT_END_OF_MEDIA = 47;
  
  private Control[] controls = null;
  
  public Handler() {
    this.controller = new MidiController(this);
    manageController((Controller)this.controller);
  }
  
  public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
    super.setSource(source);
    this.controller.setSource(source);
  }
  
  protected boolean audioEnabled() {
    return true;
  }
  
  protected boolean videoEnabled() {
    return false;
  }
  
  protected TimeBase getMasterTimeBase() {
    return this.controller.getMasterTimeBase();
  }
  
  public void updateStats() {}
  
  class MidiController extends BasicController implements MetaEventListener {
    private Handler.MidiParser midiParser;
    
    private Track track;
    
    private Buffer buffer;
    
    private PullSourceStream stream;
    
    private Sequencer sequencer;
    
    private Synthesizer synthesizer;
    
    protected MidiChannel[] channels;
    
    private Sequence sequence;
    
    private byte[] mididata;
    
    private Handler.MidiFileInputStream is;
    
    private Time duration;
    
    private GCA gc;
    
    private final Handler this$0;
    
    MidiController(Handler this$0) {
      this.this$0 = this$0;
      this.track = null;
      this.buffer = new Buffer();
      this.sequencer = null;
      this.synthesizer = null;
      this.sequence = null;
      this.mididata = null;
      this.is = null;
      this.duration = Duration.DURATION_UNKNOWN;
    }
    
    protected boolean isConfigurable() {
      return false;
    }
    
    public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
      this.midiParser = new Handler.MidiParser(this.this$0);
      this.midiParser.setSource(source);
      this.this$0.datasource = source;
    }
    
    protected TimeBase getMasterTimeBase() {
      return (TimeBase)new SystemTimeBase();
    }
    
    protected boolean doRealize() {
      long l1;
      int i;
      if (this.this$0.datasource == null)
        return false; 
      try {
        this.this$0.datasource.start();
      } catch (IOException e) {
        return false;
      } 
      this.stream = this.midiParser.getStream();
      long contentLength = this.stream.getContentLength();
      long minLocation = 0L;
      minLocation = 0L;
      if (contentLength != -1L) {
        l1 = contentLength;
        i = (int)contentLength;
      } else {
        l1 = Long.MAX_VALUE;
        i = (int)l1;
      } 
      int numBuffers = 1;
      this.track = (Track)new BasicTrack(this.midiParser, null, true, Duration.DURATION_UNKNOWN, new Time(0L), numBuffers, i, this.stream, minLocation, l1);
      return true;
    }
    
    protected boolean doPrefetch() {
      if (this.track == null)
        return false; 
      if (this.sequencer == null) {
        try {
          this.sequencer = MidiSystem.getSequencer();
          if (this.sequencer instanceof Synthesizer) {
            this.synthesizer = (Synthesizer)this.sequencer;
            this.channels = this.synthesizer.getChannels();
          } 
        } catch (MidiUnavailableException e) {
          return false;
        } 
        this.sequencer.addMetaEventListener(this);
      } 
      if (this.buffer.getLength() == 0) {
        this.track.readFrame(this.buffer);
        if (this.buffer.isDiscard() || this.buffer.isEOM()) {
          this.buffer.setLength(0);
          return false;
        } 
        this.mididata = (byte[])this.buffer.getData();
        this.is = new Handler.MidiFileInputStream(this.this$0, this.mididata, this.buffer.getLength());
      } 
      synchronized (this) {
        if (this.is != null) {
          try {
            this.is.rewind();
          } catch (Exception e) {}
        } else {
          return false;
        } 
      } 
      try {
        this.sequencer.open();
      } catch (MidiUnavailableException e) {
        Log.error("Cannot open sequencer " + e + "\n");
        return false;
      } catch (Exception e) {
        Log.error("Cannot open sequencer " + e + "\n");
        return false;
      } 
      try {
        this.sequencer.setSequence(new BufferedInputStream(this.is));
        long durationNano = this.sequencer.getMicrosecondLength() * 1000L;
        this.duration = new Time(durationNano);
      } catch (InvalidMidiDataException e) {
        Log.error("Invalid Midi Data " + e + "\n");
        this.sequencer.close();
        return false;
      } catch (Exception e) {
        Log.error("Error setting sequence " + e + "\n");
        this.sequencer.close();
        return false;
      } 
      return true;
    }
    
    protected void abortRealize() {}
    
    protected void abortPrefetch() {
      if (this.sequencer != null && this.sequencer.isOpen())
        this.sequencer.close(); 
    }
    
    protected void doStart() {
      if (this.sequencer == null)
        return; 
      if (!this.sequencer.isOpen())
        return; 
      this.sequencer.start();
    }
    
    protected void doStop() {
      if (this.sequencer == null)
        return; 
      this.sequencer.stop();
      sendEvent((ControllerEvent)new StopByRequestEvent((Controller)this, 600, 500, getTargetState(), getMediaTime()));
    }
    
    protected void doDeallocate() {
      if (this.sequencer == null)
        return; 
      synchronized (this) {
        try {
          this.sequencer.close();
        } catch (Exception e) {
          Log.error("Exception when deallocating: " + e + "\n");
        } 
      } 
    }
    
    protected void doClose() {
      if (this.this$0.closed)
        return; 
      doDeallocate();
      if (this.this$0.datasource != null)
        this.this$0.datasource.disconnect(); 
      this.this$0.datasource = null;
      this.sequencer.removeMetaEventListener(this);
      this.this$0.closed = true;
      super.doClose();
    }
    
    protected float doSetRate(float factor) {
      if (this.sequencer != null) {
        this.sequencer.setTempoFactor(factor);
        return this.sequencer.getTempoFactor();
      } 
      return 1.0F;
    }
    
    protected void doSetMediaTime(Time when) {
      if (when != null && this.sequencer != null)
        this.sequencer.setMicrosecondPosition(when.getNanoseconds() / 1000L); 
    }
    
    public void meta(MetaMessage me) {
      if (me.getType() != this.this$0.META_EVENT_END_OF_MEDIA)
        return; 
      if (this.sequencer != null && this.sequencer.isOpen()) {
        stopControllerOnly();
        this.sequencer.stop();
        if (this.duration == Duration.DURATION_UNKNOWN) {
          this.duration = getMediaTime();
          sendEvent((ControllerEvent)new DurationUpdateEvent((Controller)this, this.duration));
        } 
        sendEvent((ControllerEvent)new EndOfMediaEvent((Controller)this, 600, 500, getTargetState(), getMediaTime()));
      } 
    }
    
    public Time getDuration() {
      return this.duration;
    }
    
    public Control[] getControls() {
      if (this.this$0.controls == null) {
        this.this$0.controls = new Control[1];
        this.gc = new GCA(this);
        this.this$0.controls[0] = (Control)this.gc;
      } 
      return this.this$0.controls;
    }
    
    public void gainChange(float g) {
      if (this.channels == null || this.gc == null)
        return; 
      float level = this.gc.getLevel();
      for (int i = 0; i < this.channels.length; i++)
        this.channels[i].controlChange(7, (int)(level * 127.0D)); 
    }
    
    public void muteChange(boolean muted) {
      if (this.channels == null)
        return; 
      for (int i = 0; i < this.channels.length; i++)
        this.channels[i].setMute(muted); 
    }
    
    class GCA extends GainControlAdapter {
      private final Handler.MidiController this$1;
      
      GCA(Handler.MidiController this$1) {
        super(1.0F);
        this.this$1 = this$1;
      }
      
      public void setMute(boolean mute) {
        super.setMute(mute);
        this.this$1.muteChange(mute);
      }
      
      public float setLevel(float g) {
        float level = super.setLevel(g);
        this.this$1.gainChange(g);
        return level;
      }
    }
  }
  
  class MidiParser extends BasicPullParser {
    private final Handler this$0;
    
    MidiParser(Handler this$0) {
      this.this$0 = this$0;
    }
    
    public ContentDescriptor[] getSupportedInputContentDescriptors() {
      return null;
    }
    
    public PullSourceStream getStream() {
      PullSourceStream stream = (PullSourceStream)this.streams[0];
      return stream;
    }
    
    public Track[] getTracks() throws IOException, BadHeaderException {
      return null;
    }
    
    public Time setPosition(Time where, int rounding) {
      return null;
    }
    
    public Time getMediaTime() {
      return null;
    }
    
    public Time getDuration() {
      return null;
    }
    
    public String getName() {
      return "Parser for MIDI file format";
    }
  }
  
  class MidiFileInputStream extends InputStream {
    private int length;
    
    private int index;
    
    private byte[] data;
    
    private int markpos;
    
    private final Handler this$0;
    
    MidiFileInputStream(Handler this$0, byte[] data, int length) {
      this.this$0 = this$0;
      this.index = 0;
      this.markpos = 0;
      this.data = data;
      this.length = length;
    }
    
    public void rewind() {
      this.index = 0;
      this.markpos = 0;
    }
    
    public int read() throws IOException {
      if (this.index >= this.length)
        return -1; 
      return this.data[this.index++];
    }
    
    public int available() throws IOException {
      return this.length - this.index;
    }
    
    public int read(byte[] b) throws IOException {
      return read(b, 0, b.length);
    }
    
    public int read(byte[] b, int off, int len) throws IOException {
      if (len > available())
        len = available(); 
      if (len == 0)
        return -1; 
      System.arraycopy(this.data, this.index, b, off, len);
      this.index += len;
      return len;
    }
  }
}
