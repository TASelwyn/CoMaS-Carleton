package com.sun.media.multiplexer.audio;

import com.sun.media.multiplexer.BasicMux;
import javax.media.Format;
import javax.media.format.AudioFormat;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.FileTypeDescriptor;

public class MPEGMux extends BasicMux {
  public MPEGMux() {
    this.supportedInputs = new Format[2];
    this.supportedInputs[0] = (Format)new AudioFormat("mpeglayer3");
    this.supportedInputs[1] = (Format)new AudioFormat("mpegaudio");
    this.supportedOutputs = new ContentDescriptor[1];
    this.supportedOutputs[0] = (ContentDescriptor)new FileTypeDescriptor("audio.mpeg");
  }
  
  public String getName() {
    return "MPEG Audio Multiplexer";
  }
  
  public Format setInputFormat(Format input, int trackID) {
    if (!(input instanceof AudioFormat))
      return null; 
    AudioFormat format = (AudioFormat)input;
    double sampleRate = format.getSampleRate();
    String reason = null;
    double epsilon = 0.25D;
    if (!format.getEncoding().equalsIgnoreCase("mpeglayer3") && !format.getEncoding().equalsIgnoreCase("mpegaudio"))
      reason = "Encoding has to be MPEG audio"; 
    if (reason != null)
      return null; 
    this.inputs[0] = (Format)format;
    return (Format)format;
  }
}
