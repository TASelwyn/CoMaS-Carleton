package com.sun.media.multiplexer.audio;

import com.sun.media.format.WavAudioFormat;
import com.sun.media.multiplexer.BasicMux;
import javax.media.Format;
import javax.media.format.AudioFormat;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.FileTypeDescriptor;

public class WAVMux extends BasicMux {
  private AudioFormat audioFormat;
  
  private WavAudioFormat wavAudioFormat;
  
  private int sampleSizeInBits;
  
  private double sampleRate;
  
  private int channels;
  
  private byte[] codecSpecificHeader;
  
  private short wFormatTag;
  
  private int blockAlign = 0;
  
  private int bytesPerSecond = 0;
  
  private int dataSizeOffset;
  
  private int numberOfSamplesOffset;
  
  private int factChunkLength = 0;
  
  Format signed;
  
  Format unsigned;
  
  public String getName() {
    return "WAVE Audio Multiplexer";
  }
  
  public WAVMux() {
    this.signed = (Format)new AudioFormat(null, -1.0D, -1, -1, 0, 1);
    this.unsigned = (Format)new AudioFormat(null, -1.0D, -1, -1, 0, 0);
    this.supportedInputs = new Format[1];
    this.supportedInputs[0] = (Format)new AudioFormat(null);
    this.supportedOutputs = new ContentDescriptor[1];
    this.supportedOutputs[0] = (ContentDescriptor)new FileTypeDescriptor("audio.x_wav");
  }
  
  public Format setInputFormat(Format input, int trackID) {
    if (!(input instanceof AudioFormat))
      return null; 
    AudioFormat format = (AudioFormat)input;
    this.sampleRate = format.getSampleRate();
    String reason = null;
    this.audioFormat = format;
    if (format instanceof WavAudioFormat)
      this.wavAudioFormat = (WavAudioFormat)format; 
    String encodingString = this.audioFormat.getEncoding();
    this.sampleSizeInBits = this.audioFormat.getSampleSizeInBits();
    if (encodingString.equalsIgnoreCase("LINEAR"))
      if (this.sampleSizeInBits > 8) {
        if (this.audioFormat.getEndian() == 1)
          return null; 
        if (this.audioFormat.getSigned() == 0)
          return null; 
        if (this.audioFormat.getEndian() == -1 || this.audioFormat.getSigned() == -1)
          format = (AudioFormat)this.audioFormat.intersects(this.signed); 
      } else {
        if (this.audioFormat.getSigned() == 1)
          return null; 
        if (this.audioFormat.getEndian() == -1 || this.audioFormat.getSigned() == -1)
          format = (AudioFormat)this.audioFormat.intersects(this.unsigned); 
      }  
    Integer formatTag = (Integer)WavAudioFormat.reverseFormatMapper.get(encodingString.toLowerCase());
    if (formatTag == null) {
      reason = "Cannot handle format";
      return null;
    } 
    this.wFormatTag = formatTag.shortValue();
    switch (this.wFormatTag) {
      case 2:
      case 17:
      case 49:
        if (this.wavAudioFormat == null)
          reason = "A WavAudioFormat is required  to provide encoding specific information for this encoding " + this.wFormatTag; 
        break;
    } 
    if (this.wavAudioFormat != null) {
      this.codecSpecificHeader = this.wavAudioFormat.getCodecSpecificHeader();
      this.bytesPerSecond = this.wavAudioFormat.getAverageBytesPerSecond();
    } 
    this.sampleRate = this.audioFormat.getSampleRate();
    this.channels = this.audioFormat.getChannels();
    if (reason != null)
      return null; 
    this.inputs[0] = (Format)format;
    return (Format)format;
  }
  
  public int setNumTracks(int nTracks) {
    if (nTracks != 1)
      return 1; 
    return super.setNumTracks(nTracks);
  }
  
  protected void writeHeader() {
    int formatSize = 16;
    bufClear();
    this.audioFormat = (AudioFormat)this.inputs[0];
    this.codecSpecificHeader = null;
    if (this.audioFormat instanceof WavAudioFormat)
      this.codecSpecificHeader = ((WavAudioFormat)this.audioFormat).getCodecSpecificHeader(); 
    if (this.codecSpecificHeader != null) {
      formatSize += 2 + this.codecSpecificHeader.length;
    } else if (this.wFormatTag == 85) {
      formatSize += 14;
    } 
    bufWriteBytes("RIFF");
    bufWriteInt(0);
    bufWriteBytes("WAVE");
    bufWriteBytes("fmt ");
    bufWriteIntLittleEndian(formatSize);
    int frameSizeInBits = this.audioFormat.getFrameSizeInBits();
    if (frameSizeInBits > 0) {
      this.blockAlign = frameSizeInBits / 8;
    } else {
      this.blockAlign = this.sampleSizeInBits / 8 * this.channels;
    } 
    bufWriteShortLittleEndian(this.wFormatTag);
    bufWriteShortLittleEndian((short)this.channels);
    bufWriteIntLittleEndian((int)this.sampleRate);
    int frameRate = -1;
    if (this.wFormatTag == 85) {
      this.blockAlign = 1;
      frameRate = (int)this.audioFormat.getFrameRate();
      if (frameRate != -1)
        this.bytesPerSecond = frameRate; 
    } 
    if (this.bytesPerSecond <= 0)
      this.bytesPerSecond = this.channels * this.sampleSizeInBits * (int)this.sampleRate / 8; 
    bufWriteIntLittleEndian(this.bytesPerSecond);
    bufWriteShortLittleEndian((short)this.blockAlign);
    if (this.wFormatTag == 85) {
      bufWriteShortLittleEndian((short)0);
    } else {
      bufWriteShortLittleEndian((short)this.sampleSizeInBits);
    } 
    if (this.codecSpecificHeader != null) {
      bufWriteShortLittleEndian((short)this.codecSpecificHeader.length);
      bufWriteBytes(this.codecSpecificHeader);
    } else if (this.wFormatTag == 85) {
      char c;
      if (frameRate > 0) {
        float temp = 72.0F * frameRate * 8.0F / 8000.0F;
        temp = (float)(temp * 8000.0D / this.sampleRate);
        c = (int)temp;
      } else {
        c = 'ơ';
      } 
      bufWriteShortLittleEndian((short)12);
      bufWriteShortLittleEndian((short)1);
      bufWriteIntLittleEndian(2);
      bufWriteShortLittleEndian((short)c);
      bufWriteShortLittleEndian((short)1);
      bufWriteShortLittleEndian((short)1393);
    } 
    this.factChunkLength = 0;
    if (this.wFormatTag != 1) {
      bufWriteBytes("fact");
      bufWriteIntLittleEndian(4);
      this.numberOfSamplesOffset = this.filePointer;
      bufWriteInt(0);
      this.factChunkLength = 12;
    } 
    bufWriteBytes("data");
    this.dataSizeOffset = this.filePointer;
    bufWriteInt(0);
    bufFlush();
  }
  
  protected void writeFooter() {
    seek(4);
    bufClear();
    bufWriteIntLittleEndian(this.fileSize - 8);
    bufFlush();
    seek(this.dataSizeOffset);
    bufClear();
    int dataSize = this.fileSize - this.dataSizeOffset + 4;
    bufWriteIntLittleEndian(dataSize);
    bufFlush();
    if (this.factChunkLength > 0) {
      float duration = dataSize / this.bytesPerSecond;
      int numberOfSamples = (int)(duration * this.sampleRate);
      seek(this.numberOfSamplesOffset);
      bufClear();
      bufWriteIntLittleEndian(numberOfSamples);
      bufFlush();
    } 
  }
}
