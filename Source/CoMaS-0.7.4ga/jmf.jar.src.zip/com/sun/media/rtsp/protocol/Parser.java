package com.sun.media.rtsp.protocol;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Vector;

public class Parser {
  private Vector buffer;
  
  public Parser() {
    init();
  }
  
  public int readChar(ByteArrayInputStream bin) {
    int i;
    if (this.buffer.size() > 0) {
      i = ((Integer)this.buffer.elementAt(0)).intValue();
      this.buffer.removeElementAt(0);
    } else {
      i = bin.read();
    } 
    return i;
  }
  
  public String getToken(ByteArrayInputStream bin) {
    ByteArrayOutputStream bout = new ByteArrayOutputStream();
    skipWhitespace(bin);
    if (bin.available() > 0) {
      int ch = readChar(bin);
      while (ch != 32 && ch != 10 && ch != 13 && ch != -1) {
        bout.write(ch);
        ch = readChar(bin);
      } 
      ungetChar(ch);
    } 
    String token = new String(bout.toByteArray());
    return token;
  }
  
  public void ungetChar(int ch) {
    this.buffer.insertElementAt(new Integer(ch), 0);
  }
  
  public String getLine(ByteArrayInputStream bin) {
    ByteArrayOutputStream bout = new ByteArrayOutputStream();
    int ch = readChar(bin);
    while (ch != 10 && ch != 13 && ch != -1) {
      bout.write(ch);
      ch = readChar(bin);
    } 
    ch = readChar(bin);
    if (ch != 10)
      ungetChar(ch); 
    String line = new String(bout.toByteArray());
    return line;
  }
  
  public String getStringToken(ByteArrayInputStream bin) {
    ByteArrayOutputStream bout = new ByteArrayOutputStream();
    skipWhitespace(bin);
    int ch = readChar(bin);
    while (ch != 10 && ch != 13 && ch != -1) {
      bout.write(ch);
      ch = readChar(bin);
    } 
    String token = new String(bout.toByteArray());
    return token;
  }
  
  public byte[] getContent(ByteArrayInputStream bin) {
    ByteArrayOutputStream bout = new ByteArrayOutputStream();
    skipWhitespace(bin);
    int ch = readChar(bin);
    while (ch != -1) {
      bout.write(ch);
      ch = readChar(bin);
    } 
    return bout.toByteArray();
  }
  
  private void skipWhitespace(ByteArrayInputStream bin) {
    int ch = readChar(bin);
    while (ch == 32 || ch == 10 || ch == 13)
      ch = readChar(bin); 
    ungetChar(ch);
  }
  
  private void init() {
    this.buffer = new Vector();
  }
}
