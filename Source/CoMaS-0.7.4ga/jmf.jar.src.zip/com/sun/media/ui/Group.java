package com.sun.media.ui;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.LayoutManager;

public class Group extends Container {
  protected int border;
  
  public Group() {
    this(null, 0);
  }
  
  public Group(LayoutManager layout) {
    this(layout, 0);
  }
  
  public Group(LayoutManager layout, int border) {
    setLayout(layout);
    this.border = border;
  }
  
  public void paint(Graphics g) {
    Dimension size = getSize();
    super.paint(g);
    if (this.border > 0) {
      g.setColor(getBackground());
      g.drawRect(0, 0, size.width - 1, size.height - 1);
      g.draw3DRect(this.border - 2, this.border - 2, size.width - 1 - 2 * (this.border - 2), size.height - 1 - 2 * (this.border - 2), false);
    } 
  }
  
  public Insets getInsets() {
    return new Insets(this.border, this.border, this.border, this.border);
  }
}
