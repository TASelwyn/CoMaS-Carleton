package com.sun.media.ui;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.PopupMenu;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class ButtonComp extends BasicComp implements MouseListener {
  Image[] imageNormal;
  
  Image[] imageActive;
  
  Image[] imageDown;
  
  Image[] imageDisabled;
  
  static final int NORMAL = 1;
  
  static final int ACTIVE = 2;
  
  static final int DOWN = 4;
  
  static final int DISABLED = 8;
  
  int width;
  
  int height;
  
  boolean state = false;
  
  boolean mouseIn = false;
  
  boolean mouseDown = false;
  
  boolean mouseUp = false;
  
  boolean mouseClick = false;
  
  int visualState = 1;
  
  private PopupMenu menuPopup = null;
  
  private ContPressThread threadContPress = null;
  
  private boolean boolContPress = false;
  
  private boolean boolPopup = false;
  
  private boolean boolDoAction = false;
  
  private static final int POPUP_DELAY = 1000;
  
  public ButtonComp(String label, String imgNormal0, String imgActive0, String imgDown0, String imgDisabled0, String imgNormal1, String imgActive1, String imgDown1, String imgDisabled1) {
    super(label);
    this.imageNormal = new Image[2];
    this.imageActive = new Image[2];
    this.imageDown = new Image[2];
    this.imageDisabled = new Image[2];
    this.imageNormal[0] = BasicComp.fetchImage(imgNormal0);
    this.imageNormal[1] = BasicComp.fetchImage(imgNormal1);
    this.imageActive[0] = BasicComp.fetchImage(imgActive0);
    this.imageActive[1] = BasicComp.fetchImage(imgActive1);
    this.imageDown[0] = BasicComp.fetchImage(imgDown0);
    this.imageDown[1] = BasicComp.fetchImage(imgDown1);
    this.imageDisabled[0] = BasicComp.fetchImage(imgDisabled0);
    this.imageDisabled[1] = BasicComp.fetchImage(imgDisabled1);
    this.width = this.imageNormal[0].getWidth(this);
    this.height = this.imageNormal[0].getHeight(this);
    this.visualState = 1;
    setSize(this.width, this.height);
    setVisible(true);
    addMouseListener(this);
  }
  
  public void mouseActivity() {
    if (isEnabled()) {
      if (this.mouseIn) {
        if (this.mouseDown) {
          this.visualState = 4;
          if (this.mouseUp) {
            action();
            this.visualState = 2;
          } 
        } else {
          this.visualState = 2;
        } 
      } else {
        this.visualState = 1;
      } 
    } else {
      this.visualState = 8;
    } 
    repaint();
  }
  
  public void action() {
    if (!this.boolDoAction)
      return; 
    this.state = !this.state;
    informListener();
  }
  
  public void paint(Graphics g) {
    int index = this.state ? 1 : 0;
    Image image = null;
    switch (this.visualState) {
      case 1:
        image = this.imageNormal[index];
        break;
      case 2:
        image = this.imageActive[index];
        break;
      case 4:
        image = this.imageDown[index];
        break;
      case 8:
        image = this.imageDisabled[index];
        break;
    } 
    if (image != null)
      g.drawImage(image, 0, 0, this); 
  }
  
  public void setEnabled(boolean value) {
    super.setEnabled(value);
    if (!value) {
      this.visualState = 8;
    } else if (this.mouseIn) {
      if (this.mouseDown) {
        this.visualState = 4;
      } else {
        this.visualState = 2;
      } 
    } else {
      this.visualState = 1;
    } 
    repaint();
  }
  
  public boolean getValue() {
    return this.state;
  }
  
  public void setValue(boolean newState) {
    if (this.state != newState) {
      this.state = newState;
      repaint();
    } 
  }
  
  public void setPopupMenu(PopupMenu menuPopup) {
    if (menuPopup != null) {
      setMousePopup(true);
      this.menuPopup = menuPopup;
      add(menuPopup);
    } else if (this.menuPopup != null) {
      setMousePopup(false);
      remove(this.menuPopup);
      this.menuPopup = null;
    } 
  }
  
  public void setMousePopup(boolean boolPopup) {
    this.boolPopup = boolPopup;
  }
  
  public void setContMousePress(boolean boolSet) {
    this.boolContPress = boolSet;
  }
  
  public void mouseEntered(MouseEvent e) {
    this.mouseIn = true;
    mouseActivity();
  }
  
  public void mouseExited(MouseEvent e) {
    this.mouseIn = false;
    mouseActivity();
    if (this.threadContPress != null) {
      this.threadContPress.stopNormaly();
      this.threadContPress = null;
    } 
  }
  
  public void mousePressed(MouseEvent e) {
    int modifier = e.getModifiers();
    if ((modifier & 0x8) == 0 && (modifier & 0x4) == 0) {
      this.mouseDown = true;
      this.mouseUp = false;
      mouseActivity();
      if (this.boolContPress == true || this.boolPopup == true) {
        if (this.threadContPress != null)
          this.threadContPress.stopNormaly(); 
        this.threadContPress = new ContPressThread(this, this);
        if (this.boolPopup == true)
          this.threadContPress.setDelayedPress(1000L); 
        this.threadContPress.start();
      } 
      this.boolDoAction = true;
    } 
  }
  
  public void mouseReleased(MouseEvent e) {
    int modifier = e.getModifiers();
    if ((modifier & 0x8) == 0 && (modifier & 0x4) == 0) {
      this.mouseUp = true;
      mouseActivity();
      this.mouseUp = false;
      this.mouseDown = false;
      if (this.threadContPress != null) {
        this.threadContPress.stopNormaly();
        this.threadContPress = null;
      } 
    } 
  }
  
  public void mouseClicked(MouseEvent e) {
    int modifier = e.getModifiers();
    if ((modifier & 0x8) == 0 && (modifier & 0x4) == 0) {
      this.mouseClick = true;
      mouseActivity();
      this.mouseClick = false;
    } 
  }
  
  public Dimension getPreferredSize() {
    return new Dimension(this.width, this.height);
  }
  
  protected void processMouseEvent(MouseEvent event) {
    super.processMouseEvent(event);
    if (event.isPopupTrigger())
      processMousePopup(); 
  }
  
  protected void processMousePopup() {
    if (this.menuPopup != null)
      this.menuPopup.show(this, 0, this.height); 
  }
  
  protected void processContPress() {
    if (this.boolContPress == true) {
      informListener();
    } else if (this.boolPopup == true && this.mouseIn && this.mouseDown) {
      this.boolDoAction = false;
      processMousePopup();
    } 
  }
  
  class ContPressThread extends Thread {
    protected ButtonComp button;
    
    protected boolean boolContinueRun;
    
    protected boolean boolIgnoreFirst;
    
    protected boolean boolDelayedPress;
    
    protected long lMills;
    
    private final ButtonComp this$0;
    
    public ContPressThread(ButtonComp this$0, ButtonComp button) {
      this.this$0 = this$0;
      this.button = null;
      this.boolContinueRun = true;
      this.boolIgnoreFirst = true;
      this.boolDelayedPress = false;
      this.lMills = 500L;
      this.button = button;
    }
    
    public void setDelayedPress(long lMills) {
      this.boolDelayedPress = true;
      this.lMills = lMills;
    }
    
    public void stopNormaly() {
      this.boolContinueRun = false;
    }
    
    public void run() {
      if (this.boolDelayedPress == true) {
        this.boolIgnoreFirst = false;
      } else {
        this.boolIgnoreFirst = true;
      } 
      while (this.boolContinueRun) {
        try {
          Thread.sleep(this.lMills);
        } catch (Exception exception) {}
        if (this.button != null && !this.boolIgnoreFirst)
          this.button.processContPress(); 
        this.boolIgnoreFirst = false;
        if (this.boolDelayedPress == true)
          this.boolContinueRun = false; 
      } 
      this.boolDelayedPress = false;
      this.lMills = 250L;
    }
  }
}
