package com.sun.media.ui;

class ColumnData {
  String strName;
  
  int nType;
  
  int nWidth = 120;
  
  public ColumnData(String strName, int nType) {
    this.strName = strName;
    this.nType = nType;
  }
  
  public String toString() {
    return this.strName;
  }
}
