package com.sun.media.renderer.video;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.awt.image.DirectColorModel;
import java.awt.image.Raster;
import java.awt.image.SinglePixelPackedSampleModel;
import java.awt.image.WritableRaster;
import java.util.Vector;
import javax.media.Buffer;
import javax.media.format.RGBFormat;

public class Java2DRenderer implements Blitter {
  private transient AffineTransformOp savedATO = null;
  
  private transient DirectColorModel dcm = null;
  
  private transient Image destImage = null;
  
  public Java2DRenderer() {
    try {
      Class.forName("java.awt.Graphics2D");
    } catch (ClassNotFoundException classNotFoundException) {
      throw new RuntimeException("No Java2D");
    } 
  }
  
  public Image process(Buffer paramBuffer, Object paramObject1, Object paramObject2, Dimension paramDimension) {
    return (Image)paramObject1;
  }
  
  public synchronized void draw(Graphics paramGraphics, Component paramComponent, Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8) {
    if (paramImage == null || paramInt3 < 1 || paramInt4 < 1)
      return; 
    if (this.savedATO == null) {
      AffineTransform affineTransform = new AffineTransform(paramInt3 / paramInt7, 0.0F, 
          0.0F, paramInt4 / paramInt8, 
          0.0F, 0.0F);
      AffineTransformOp affineTransformOp = new AffineTransformOp(affineTransform, null);
      this.savedATO = affineTransformOp;
      this.destImage = affineTransformOp.createCompatibleDestImage((BufferedImage)paramImage, 
          this.dcm);
    } 
    this.savedATO.filter((BufferedImage)paramImage, (BufferedImage)this.destImage);
    if (paramGraphics != null && paramImage != null && paramGraphics instanceof Graphics2D)
      ((Graphics2D)paramGraphics).drawImage(this.destImage, 0, 0, paramComponent); 
  }
  
  public int newData(Buffer paramBuffer, Vector paramVector1, Vector paramVector2, Vector paramVector3) {
    Object object = paramBuffer.getData();
    if (!(object instanceof int[]))
      return -1; 
    RGBFormat rGBFormat = (RGBFormat)paramBuffer.getFormat();
    int i = rGBFormat.getRedMask();
    int j = rGBFormat.getGreenMask();
    int k = rGBFormat.getBlueMask();
    int[] arrayOfInt = new int[3];
    arrayOfInt[0] = i;
    arrayOfInt[1] = j;
    arrayOfInt[2] = k;
    DataBufferInt dataBufferInt = new DataBufferInt((int[])object, 
        rGBFormat.getLineStride() * 
        (rGBFormat.getSize()).height);
    SinglePixelPackedSampleModel singlePixelPackedSampleModel = new SinglePixelPackedSampleModel(3, 
        rGBFormat.getLineStride(), 
        (rGBFormat.getSize()).height, 
        arrayOfInt);
    WritableRaster writableRaster = Raster.createWritableRaster(singlePixelPackedSampleModel, dataBufferInt, new Point(0, 0));
    this.dcm = new DirectColorModel(24, i, j, k);
    BufferedImage bufferedImage = new BufferedImage(this.dcm, writableRaster, true, null);
    paramVector3.addElement(object);
    paramVector1.addElement(bufferedImage);
    paramVector2.addElement(bufferedImage);
    synchronized (this) {
      this.savedATO = null;
    } 
    return paramVector1.size() - 1;
  }
  
  public void resized(Component paramComponent) {
    this.savedATO = null;
  }
}
