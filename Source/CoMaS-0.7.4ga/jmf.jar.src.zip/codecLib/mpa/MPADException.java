package codecLib.mpa;

public class MPADException extends Exception implements Constants {
  private int bB = -1;
  
  private String bC = "MPADException0";
  
  public MPADException() {}
  
  public MPADException(String paramString) {
    super(e.a(paramString));
    this.bC = paramString;
  }
  
  public MPADException(int paramInt) {
    this.bB = paramInt;
  }
  
  public String toString() {
    switch (this.bB) {
      case -1:
        str1 = "MPADException0";
        str2 = getClass().getName();
        return str2 + ": " + e.a(str1);
      case -2:
        str1 = "MPADException1";
        str2 = getClass().getName();
        return str2 + ": " + e.a(str1);
      case -3:
        str1 = "MPADException2";
        str2 = getClass().getName();
        return str2 + ": " + e.a(str1);
      case -4:
        str1 = "MPADException3";
        str2 = getClass().getName();
        return str2 + ": " + e.a(str1);
      case -7:
        str1 = "MPADException4";
        str2 = getClass().getName();
        return str2 + ": " + e.a(str1);
      case -8:
        str1 = "MPADException5";
        str2 = getClass().getName();
        return str2 + ": " + e.a(str1);
      case -9:
        str1 = "MPADException6";
        str2 = getClass().getName();
        return str2 + ": " + e.a(str1);
    } 
    String str1 = this.bC;
    String str2 = getClass().getName();
    return str2 + ": " + e.a(str1);
  }
  
  public int getState() {
    return this.bB;
  }
}
