package com.apple.eawt.event;

public class GesturePhaseEvent extends GestureEvent {
  GesturePhaseEvent() {
    GestureUtilities.unimplemented();
  }
}
