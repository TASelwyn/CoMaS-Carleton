package com.apple.eawt.event;

public class MagnificationEvent extends GestureEvent {
  MagnificationEvent(double paramDouble) {
    GestureUtilities.unimplemented();
  }
  
  public double getMagnification() {
    GestureUtilities.unimplemented();
    return 0.0D;
  }
}
