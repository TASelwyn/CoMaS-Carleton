package com.apple.eawt.event;

public interface RotationListener extends GestureListener {
  void rotate(RotationEvent paramRotationEvent);
}
