package codecLib.mpa;

class c extends Defines implements Tables {
  private static final int am = 64;
  
  private static final float aM = 0.03125F;
  
  private m X;
  
  private b ag = new b();
  
  private b ax = new b();
  
  private b ay = new b();
  
  private b ar = new b();
  
  private int[][] az = new int[7][32];
  
  private int[][][] ah = new int[7][3][32];
  
  a ao;
  
  int at;
  
  int aF;
  
  int T;
  
  int R;
  
  int Z;
  
  int aJ;
  
  int aw;
  
  int aB;
  
  int ac;
  
  int aH;
  
  int aL;
  
  int aA;
  
  int af;
  
  int aE;
  
  int Y;
  
  int U;
  
  int aI;
  
  int ak;
  
  int an;
  
  int aq;
  
  int aG;
  
  int as;
  
  int aD;
  
  int[] ab = new int[12];
  
  int[] ae = new int[12];
  
  int[] ai = new int[12];
  
  int[] ap = new int[8];
  
  int[][] W = new int[8][6];
  
  int[][][] ad = new int[8][6][3];
  
  int[][] aa = new int[8][6];
  
  int av;
  
  int aj;
  
  int[] aK = new int[12];
  
  float[] S = new float[12];
  
  b al = new b();
  
  float[][][] au;
  
  private static final byte[][] V = new byte[][] { { 
        6, 4, 4, 4, 2, 2, 2, 0, 2, 2, 
        2, 0, 0, 0, 0, 0 }, { 
        4, 2, 2, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0 }, { 
        2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0 }, { 
        4, 2, 2, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0 }, { 
        2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0 }, { 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0 } };
  
  private static final byte[] Q = new byte[] { 
      0, 1, 2, 3, 4, 5, 6, 7, 8, 8, 
      9, 9, 10, 10, 10, 10, 11, 11, 11, 11, 
      11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 
      11, 11 };
  
  private static final float[] aC = new float[] { 
      1.5258789E-5F, 1.922487E-5F, 2.4221818E-5F, 3.0517578E-5F, 3.844974E-5F, 4.8443635E-5F, 6.1035156E-5F, 7.689948E-5F, 9.688727E-5F, 1.2207031E-4F, 
      1.5379896E-4F, 1.9377454E-4F, 2.4414062E-4F, 3.0759792E-4F, 3.8754908E-4F, 4.8828125E-4F, 6.1519584E-4F, 7.7509816E-4F, 9.765625E-4F, 0.0012303917F, 
      0.0015501963F, 0.001953125F, 0.0024607833F, 0.0031003926F, 0.00390625F, 0.0049215667F, 0.0062007853F, 0.0078125F, 0.009843133F, 0.012401571F, 
      0.015625F, 0.019686267F, 0.024803141F, 0.03125F, 0.039372534F, 0.049606282F, 0.0625F, 0.07874507F, 0.099212565F, 0.125F, 
      0.15749013F, 0.19842513F, 0.25F, 0.31498027F, 0.39685026F, 0.5F, 0.62996054F, 0.7937005F, 1.0F, 1.2599211F, 
      1.587401F, 2.0F, 2.5198421F, 3.174802F, 4.0F, 5.0396843F, 6.349604F, 8.0F, 10.079369F, 12.699208F, 
      16.0F, 20.158737F, 25.398417F, 1.0E20F };
  
  c(m paramm, a parama) {
    this.X = paramm;
    this.ao = parama;
  }
  
  int int(int paramInt) {
    int j = this.X.bv.if();
    byte b1 = 16;
    b.a(this.ax, this.X.bv);
    b.a(this.ay, this.X.bv);
    int k = this.X.bv.for(9);
    if ((this.at = k >> 8) != 0) {
      if (this.ao.cB == null || this.ao.cG <= 4)
        return -4; 
      this.aF = k & 0xFF;
      b1 = 24;
      paramInt -= this.aF << 3;
    } 
    if (this.X.bv.goto() < paramInt)
      return -3; 
    this.X.bv.do(b1 - 15);
    k = this.X.bv.if(15);
    this.T = k >> 13;
    this.R = k >> 11 & 0x3;
    this.Z = k >> 10 & 0x1;
    this.aJ = k >> 9 & 0x1;
    this.aw = k >> 7 & 0x3;
    this.aB = k >> 4 & 0x7;
    this.ac = k >> 3 & 0x1;
    this.aH = k >> 2 & 0x1;
    this.aL = k >> 1 & 0x1;
    this.aA = k & 0x1;
    int n = g.a(this.ay, 65535, b1);
    paramInt -= b1;
    if (this.X.bn.l != 1 && this.at != 0) {
      int i1 = a(this.ar, paramInt);
      if (i1 < 0)
        return i1; 
      paramInt += i1;
    } 
    if (this.aA != 0) {
      b.a(this.ay, this.X.bv);
      n = g.a(this.ay, n, 71);
      this.X.bv.a(71);
      paramInt -= 71;
    } 
    this.af = this.X.bv.if(16);
    paramInt -= 16;
    int i = this.X.bv.if();
    b.a(this.ay, this.X.bv);
    if (this.X.bn.l != 1) {
      new();
      case();
      if(this.az);
      n = g.a(this.ay, n, this.X.bv.if() - i);
      if (this.af != n)
        return -2; 
      a(this.az);
      byte b2;
      for (b2 = 0; b2 < 12; b2++) {
        do(this.ah, b2);
        a(this.ah, b2);
        new(b2);
      } 
      if (this.aG != 0)
        for (byte b3 = 0; b3 < 2; b3++) {
          for (byte b4 = 0; b4 < 8; b4++) {
            byte b5;
            for (b5 = 0; b5 < 9; b5++)
              this.au[b3][b4][b5] = this.au[b3][b4][b5 + 36]; 
            for (b5 = 0; b5 < 3; b5++) {
              for (byte b6 = 0; b6 < 12; b6++)
                this.au[b3][b4][9 + 12 * b5 + b6] = this.X.bu[b5][b6][b3][b4]; 
            } 
          } 
        }  
      for();
      int();
      if (this.Z != 0) {
        try();
        for (b2 = 0; b2 < 12; b2++)
          this.ao.cI[b2] = this.S[b2]; 
      } 
    } else {
      return -10;
    } 
    if (this.aB > 0 && this.aH == 0) {
      if (this.ac != 0) {
        this.X.bA = Tables.t_bal[4];
      } else {
        this.X.bA = Tables.t_bal[(this.X.bn.g == 48000) ? 0 : 1];
      } 
      this.ak = this.X.bA.int;
      byte();
      do(this.az);
      for (byte b2 = 0; b2 < 12 >> this.ac; b2++) {
        a(this.ah);
        if(this.ah, b2);
      } 
    } 
    this.ao.cy = this.T & 0x1;
    this.ao.cH = this.Z;
    this.ao.cF = this.aB;
    this.ao.cM = this.X.bn.g >> this.ac;
    this.ao.cx = 1152 >> this.ac;
    this.ao.cC = (this.X.bn.k == 1) ? 4 : 12;
    if ((this.T & 0x1) != 0)
      this.ao.cC |= 0x10; 
    switch (this.R) {
      case 0:
        this.ao.cL = 0;
        break;
      case 1:
        this.ao.cL = 1;
        this.ao.cC |= 0x20;
        break;
      case 2:
        this.ao.cL = 2;
        this.ao.cC |= 0x60;
        break;
      case 3:
        this.ao.cL = 0;
        this.ao.cD = 2;
        this.ao.cC |= 0x8000;
        break;
    } 
    if (this.Z != 0)
      this.ao.cC |= 0x80; 
    this.ao.cK = this.ao.cy + this.ao.cL + this.ao.cD;
    if (this.aH == 0)
      for (byte b2 = 0; b2 < this.aB; b2++)
        this.ao.cC |= 256 << b2;  
    this.X.bv.a(j - this.X.bv.if());
    return 0;
  }
  
  private void new() {
    this.X.bA = Tables.t_bal[(this.X.bn.g == 48000) ? 0 : 1];
    this.ak = this.X.bA.int;
    if (this.R == 3) {
      if (this.T == 1 || this.T == 3) {
        this.aE = 3;
        this.Y = 2;
        this.U = 1;
        this.aI = 2;
      } else {
        this.aE = 2;
        this.Y = 0;
        this.U = 0;
        this.aI = 5;
      } 
    } else if (this.R == 2) {
      if (this.T == 1 || this.T == 3) {
        this.aE = 3;
        this.Y = 3;
        this.U = 4;
        this.aI = 0;
      } else {
        this.aE = 2;
        this.Y = 2;
        this.U = 3;
        this.aI = 3;
      } 
    } else if (this.R == 1) {
      if (this.T == 1 || this.T == 3) {
        this.aE = 2;
        this.Y = 3;
        this.U = 3;
        this.aI = 1;
      } else {
        this.aE = 1;
        this.Y = 2;
        this.U = 1;
        this.aI = 4;
      } 
    } else if (this.T == 1 || this.T == 3) {
      this.aE = 1;
      this.Y = 2;
      this.U = 1;
      this.aI = 2;
    } else {
      this.aE = 0;
      this.Y = 0;
      this.U = 0;
      this.aI = 5;
    } 
    if (this.aB > 0 && this.aH > 0)
      this.aB = 0; 
  }
  
  private void case() {
    int i = this.X.bv.if(3);
    this.an = i >>> 2;
    this.aq = (i & 0x2) >> 1;
    this.aG = i & 0x1;
    byte b1;
    for (b1 = 0; b1 < 12; b1++) {
      this.ab[b1] = 0;
      this.ae[b1] = 0;
    } 
    if (this.Y == 0) {
      this.as = 0;
    } else if (this.an == 1) {
      this.as = this.X.bv.if(this.Y);
      for (b1 = 0; b1 < 12; b1++)
        this.ab[b1] = this.as; 
    } else {
      this.as = 0;
      for (b1 = 0; b1 < 12; b1++)
        this.ab[b1] = this.X.bv.if(this.Y); 
    } 
    if (this.aq == 1) {
      this.aD = this.X.bv.if(1);
      if (this.U != 0)
        for (b1 = 0; b1 < 12; b1++) {
          this.ae[b1] = this.X.bv.if(this.U);
          if (this.R == 3)
            this.ai[b1] = this.X.bv.if(1); 
        }  
    } else {
      this.aD = 0;
    } 
    if (this.aG == 1)
      for (b1 = 0; b1 < 8; b1++) {
        this.ap[b1] = this.X.bv.if(1);
        if (this.X.bv.if(1) == 1) {
          i = V[this.aI][this.ae[b1]];
          for (byte b2 = 0; b2 < i; b2++)
            this.W[b1][b2] = this.X.bv.if(2); 
        } 
      }  
  }
  
  private void if(int[][] paramArrayOfint) {
    int i = this.X.bn.k;
    int j = this.X.bn.k + this.aE;
    f f = this.X.bA;
    int n = this.ak;
    byte[][] arrayOfByte = this.X.bs[0];
    if (this.Z != 0)
      this.av = this.X.bv.if(f.a[0]); 
    if (this.aq == 0) {
      for (byte b1 = 0; b1 < n; b1++) {
        for (int i1 = i; i1 < j; i1++) {
          if (this.T != 3 || b1 < 12 || i1 != 2) {
            arrayOfByte[i1][b1] = (byte)this.X.bv.if(f.a[b1]);
          } else {
            arrayOfByte[i1][b1] = 0;
          } 
        } 
      } 
    } else {
      for (byte b1 = 0; b1 < n; b1++) {
        byte b2 = Q[b1];
        if (this.ae[b2] == 0) {
          for (int i1 = i; i1 < j; i1++) {
            if (this.T == 3 && b1 >= 12 && i1 == 2) {
              arrayOfByte[i1][b1] = 0;
            } else if (this.R == 3 && this.ai[b2] == 1) {
              if (this.T != 0 && i1 == 4) {
                arrayOfByte[i1][b1] = arrayOfByte[3][b1];
              } else if (this.T == 0 && i1 == 3) {
                arrayOfByte[i1][b1] = arrayOfByte[2][b1];
              } else {
                arrayOfByte[i1][b1] = (byte)this.X.bv.if(f.a[b1]);
              } 
            } else {
              arrayOfByte[i1][b1] = (byte)this.X.bv.if(f.a[b1]);
            } 
          } 
        } else if (this.U == 1) {
          if (this.T == 3 && b1 >= 12) {
            arrayOfByte[2][b1] = 0;
          } else if (this.ab[b2] == 1) {
            arrayOfByte[2][b1] = arrayOfByte[0][b1];
          } else if (this.ab[b2] == 2) {
            arrayOfByte[2][b1] = arrayOfByte[1][b1];
          } else if (this.aD != 0) {
            arrayOfByte[2][b1] = arrayOfByte[1][b1];
          } else {
            arrayOfByte[2][b1] = arrayOfByte[0][b1];
          } 
          if (this.R == 3) {
            arrayOfByte[3][b1] = (byte)this.X.bv.if(f.a[b1]);
            if (this.ai[b2] == 1) {
              arrayOfByte[4][b1] = arrayOfByte[3][b1];
            } else {
              arrayOfByte[4][b1] = (byte)this.X.bv.if(f.a[b1]);
            } 
          } 
        } else if (this.U == 3) {
          if (this.T == 3 && b1 >= 12) {
            arrayOfByte[2][b1] = 0;
          } else if (this.ae[b2] == 1 || this.ae[b2] == 4) {
            arrayOfByte[2][b1] = (byte)this.X.bv.if(f.a[b1]);
          } else if (this.R == 2 || this.ab[b2] == 1 || this.ab[b2] == 5 || (this.ab[b2] != 2 && this.aD == 0)) {
            arrayOfByte[2][b1] = arrayOfByte[0][b1];
          } else {
            arrayOfByte[2][b1] = arrayOfByte[1][b1];
          } 
          if (this.ae[b2] == 2) {
            arrayOfByte[3][b1] = (byte)this.X.bv.if(f.a[b1]);
          } else if (this.ae[b2] == 4) {
            arrayOfByte[3][b1] = arrayOfByte[2][b1];
          } else if (this.R == 2 || this.ab[b2] == 4 || this.ab[b2] == 5 || (this.ab[b2] < 3 && this.aD != 0)) {
            arrayOfByte[3][b1] = arrayOfByte[1][b1];
          } else {
            arrayOfByte[3][b1] = arrayOfByte[0][b1];
          } 
        } else if (this.U == 4) {
          if (this.T == 3 && b1 >= 12) {
            arrayOfByte[2][b1] = 0;
          } else {
            switch (this.ae[b2]) {
              case 1:
              case 2:
              case 4:
              case 8:
              case 9:
              case 10:
              case 11:
              case 12:
              case 14:
                arrayOfByte[2][b1] = (byte)this.X.bv.if(f.a[b1]);
                break;
              case 3:
              case 5:
              case 6:
              case 7:
              case 13:
                if (this.ab[b2] == 1 || this.ab[b2] == 7) {
                  arrayOfByte[2][b1] = arrayOfByte[0][b1];
                  break;
                } 
                if (this.ab[b2] == 2 || this.ab[b2] == 6) {
                  arrayOfByte[2][b1] = arrayOfByte[1][b1];
                  break;
                } 
                if (this.aD != 0) {
                  arrayOfByte[2][b1] = arrayOfByte[1][b1];
                  break;
                } 
                arrayOfByte[2][b1] = arrayOfByte[0][b1];
                break;
            } 
          } 
          switch (this.ae[b2]) {
            case 1:
            case 3:
            case 5:
            case 8:
            case 10:
            case 13:
              arrayOfByte[3][b1] = (byte)this.X.bv.if(f.a[b1]);
              break;
            case 2:
            case 4:
            case 6:
            case 7:
            case 12:
              arrayOfByte[3][b1] = arrayOfByte[0][b1];
              break;
            case 9:
            case 11:
            case 14:
              arrayOfByte[3][b1] = arrayOfByte[2][b1];
              break;
          } 
          switch (this.ae[b2]) {
            case 2:
            case 3:
            case 6:
            case 9:
              arrayOfByte[4][b1] = (byte)this.X.bv.if(f.a[b1]);
              break;
            case 1:
            case 4:
            case 5:
            case 7:
            case 11:
              arrayOfByte[4][b1] = arrayOfByte[1][b1];
              break;
            case 10:
            case 12:
            case 14:
              arrayOfByte[4][b1] = arrayOfByte[2][b1];
              break;
            case 8:
            case 13:
              arrayOfByte[4][b1] = arrayOfByte[3][b1];
              break;
          } 
        } 
      } 
    } 
    int k;
    for (k = n; k < 32; k++) {
      for (int i1 = i; i1 < j; i1++)
        arrayOfByte[i1][k] = 0; 
    } 
    for (k = 0; k < n; k++) {
      for (int i1 = i; i1 < j; i1++) {
        if (arrayOfByte[i1][k] != 0) {
          paramArrayOfint[i1][k] = this.X.bv.if(2);
        } else {
          paramArrayOfint[i1][k] = 4;
        } 
      } 
    } 
    for (k = n; k < 32; k++) {
      for (int i1 = i; i1 < j; i1++)
        paramArrayOfint[i1][k] = 4; 
    } 
  }
  
  private void a(int[][] paramArrayOfint) {
    int i = this.X.bn.k;
    int j = this.X.bn.k + this.aE;
    int n = this.ak;
    byte[][] arrayOfByte = this.X.bs[0];
    byte[][][] arrayOfByte1 = this.X.bp;
    if (j > this.X.bn.k && j < 7 && this.aG == 1)
      for (byte b1 = 0; b1 < 8; b1++) {
        if (this.ap[b1] == 1)
          for (byte b2 = 0; b2 < V[this.aI][this.ae[b1]]; b2++) {
            if (this.W[b1][b2] != 0) {
              this.aa[b1][b2] = this.X.bv.if(3);
              for (byte b3 = 0; b3 < this.W[b1][b2]; b3++)
                this.ad[b1][b2][b3] = this.X.bv.if(8); 
            } else {
              this.ad[b1][b2][0] = 127;
              this.aa[b1][b2] = 0;
            } 
          }  
      }  
    if (i == this.X.bn.k && this.Z != 0 && this.av != 0)
      this.aj = this.X.bv.if(6); 
    int k;
    for (k = 0; k < n; k++) {
      for (int i1 = i; i1 < j; i1++) {
        if (arrayOfByte[i1][k] != 0) {
          switch (paramArrayOfint[i1][k]) {
            case 0:
              arrayOfByte1[0][i1][k] = (byte)this.X.bv.if(6);
              arrayOfByte1[1][i1][k] = (byte)this.X.bv.if(6);
              arrayOfByte1[2][i1][k] = (byte)this.X.bv.if(6);
              break;
            case 1:
              arrayOfByte1[1][i1][k] = (byte)this.X.bv.if(6);
              arrayOfByte1[0][i1][k] = (byte)this.X.bv.if(6);
              arrayOfByte1[2][i1][k] = (byte)this.X.bv.if(6);
              break;
            case 3:
              arrayOfByte1[0][i1][k] = (byte)this.X.bv.if(6);
              arrayOfByte1[2][i1][k] = (byte)this.X.bv.if(6);
              arrayOfByte1[1][i1][k] = (byte)this.X.bv.if(6);
              break;
            case 2:
              arrayOfByte1[2][i1][k] = (byte)this.X.bv.if(6);
              arrayOfByte1[1][i1][k] = (byte)this.X.bv.if(6);
              arrayOfByte1[0][i1][k] = (byte)this.X.bv.if(6);
              break;
            default:
              arrayOfByte1[2][i1][k] = 63;
              arrayOfByte1[1][i1][k] = 63;
              arrayOfByte1[0][i1][k] = 63;
              break;
          } 
        } else {
          arrayOfByte1[2][i1][k] = 63;
          arrayOfByte1[1][i1][k] = 63;
          arrayOfByte1[0][i1][k] = 63;
        } 
      } 
    } 
    for (k = n; k < 32; k++) {
      for (int i1 = i; i1 < j; i1++) {
        arrayOfByte1[2][i1][k] = 63;
        arrayOfByte1[1][i1][k] = 63;
        arrayOfByte1[0][i1][k] = 63;
      } 
    } 
  }
  
  private void do(int[][][] paramArrayOfint, int paramInt) {
    int i = this.X.bn.k;
    int j = this.X.bn.k + this.aE;
    int n = 0;
    f f = this.X.bA;
    int i1 = this.ak;
    byte[][] arrayOfByte = this.X.bs[0];
    if (this.Z != 0 && this.av > 0)
      this.aK[paramInt] = this.X.bv.if(this.av + 1); 
    int k;
    for (k = 0; k < i1; k++) {
      byte b1 = Q[k];
      for (int i2 = i; i2 < j; i2++) {
        boolean bool;
        if (arrayOfByte[i2][k] != 0) {
          bool = true;
          if (this.aq == 1) {
            if (this.U == 4 && ((this.ae[b1] == 1 && i2 == 4) || (this.ae[b1] == 2 && i2 == 3) || (this.ae[b1] == 3 && i2 == 2) || (this.ae[b1] == 4 && i2 != 2) || (this.ae[b1] == 5 && i2 != 3) || (this.ae[b1] == 6 && i2 != 4) || this.ae[b1] == 7 || (this.ae[b1] == 8 && i2 == 4) || (this.ae[b1] == 9 && i2 == 3) || (this.ae[b1] == 10 && i2 == 4) || (this.ae[b1] == 11 && i2 != 2) || (this.ae[b1] == 12 && i2 != 2) || (this.ae[b1] == 13 && i2 != 3) || (this.ae[b1] == 14 && i2 != 2)))
              bool = false; 
            if (this.U == 3 && ((this.ae[b1] == 1 && i2 == 3) || (this.ae[b1] == 2 && i2 == 2) || this.ae[b1] == 3 || (this.ae[b1] == 4 && i2 == 3)))
              bool = false; 
            if (this.U == 1 && this.ae[b1] == 1 && i2 == 2)
              bool = false; 
            if (this.R == 3 && this.ai[b1] == 1)
              if ((this.T == 1 || this.T == 3) && i2 == 4) {
                bool = false;
              } else if (this.T == 0 && i2 == 3) {
                bool = false;
              }  
          } 
        } else {
          bool = false;
        } 
        if (bool == true) {
          byte b2 = f.for[k][arrayOfByte[i2][k]];
          if (b2 > 0) {
            paramArrayOfint[i2][0][k] = this.X.bv.if(b2);
            paramArrayOfint[i2][1][k] = this.X.bv.if(b2);
            paramArrayOfint[i2][2][k] = this.X.bv.if(b2);
          } else {
            n = this.X.bv.if(-b2);
            int i3 = -b2 & 0x6;
            i3 /= 2;
            byte[] arrayOfByte1 = this.X.bw[i3];
            paramArrayOfint[i2][0][k] = arrayOfByte1[3 * n];
            paramArrayOfint[i2][1][k] = arrayOfByte1[3 * n + 1];
            paramArrayOfint[i2][2][k] = arrayOfByte1[3 * n + 2];
          } 
        } else {
          for (byte b2 = 0; b2 < 3; b2++)
            paramArrayOfint[i2][b2][k] = 0; 
        } 
      } 
    } 
    for (k = i1; k < 32; k++) {
      for (int i2 = i; i2 < j; i2++) {
        for (byte b1 = 0; b1 < 3; b1++)
          paramArrayOfint[i2][b1][k] = 0; 
      } 
    } 
  }
  
  private void a(int[][][] paramArrayOfint, int paramInt) {
    int i = this.X.bn.k;
    int j = this.X.bn.k + this.aE;
    f f = this.X.bA;
    int n = this.ak;
    byte[][] arrayOfByte = this.X.bs[0];
    float[][][][] arrayOfFloat = this.X.bu;
    paramInt *= 3;
    int k;
    for (k = 0; k < n; k++) {
      byte b2 = Q[k];
      for (byte b1 = 0; b1 < 3; b1++) {
        float[][] arrayOfFloat1 = arrayOfFloat[(paramInt + b1) / 12][(paramInt + b1) % 12];
        for (int i1 = i; i1 < j; i1++) {
          if (arrayOfByte[i1][k] != 0) {
            if (this.aq == 0) {
              byte b3 = f.if[k][arrayOfByte[i1][k]];
              int i2 = Tables.t_alloc[b3];
              int i3 = paramArrayOfint[i1][b1][k];
              float f1 = Tables.t_d[b3];
              if ((i3 & i2) == 0)
                f1 -= Tables.t_c[b3]; 
              f1 += (i3 & i2 - 1) * Tables.t_finv_alloc[b3];
              arrayOfFloat1[i1][k] = f1;
            } else {
              if (this.U == 4 && (this.ae[b2] == 0 || (this.ae[b2] == 1 && i1 != 4) || (this.ae[b2] == 2 && i1 != 3) || (this.ae[b2] == 3 && i1 != 2) || (this.ae[b2] == 8 && i1 != 4) || (this.ae[b2] == 9 && i1 != 3) || (this.ae[b2] == 10 && i1 != 4))) {
                byte b3 = f.if[k][arrayOfByte[i1][k]];
                int i2 = Tables.t_alloc[b3];
                int i3 = paramArrayOfint[i1][b1][k];
                float f1 = Tables.t_d[b3];
                if ((i3 & i2) == 0)
                  f1 -= Tables.t_c[b3]; 
                f1 += (i3 & i2 - 1) * Tables.t_finv_alloc[b3];
                arrayOfFloat1[i1][k] = f1;
              } 
              if ((this.U != 4 || (this.ae[b2] == 4 && i1 == 2) || (this.ae[b2] == 5 && i1 == 3) || (this.ae[b2] == 6 && i1 == 4) || (this.ae[b2] == 11 && i1 == 2) || (this.ae[b2] == 12 && i1 == 2) || (this.ae[b2] == 13 && i1 == 3) || (this.ae[b2] == 14 && i1 == 2)) && (this.U != 3 || ((this.ae[b2] != 1 || i1 != 3) && (this.ae[b2] != 2 || i1 != 2) && this.ae[b2] != 3 && (this.ae[b2] != 4 || i1 != 3))) && (this.U != 1 || this.ae[b2] != 1 || i1 != 2) && (this.R != 3 || this.ai[b2] != 1 || ((this.T == 0 || i1 != 4) && (this.T != 0 || i1 != 3)))) {
                byte b3 = f.if[k][arrayOfByte[i1][k]];
                int i2 = Tables.t_alloc[b3];
                int i3 = paramArrayOfint[i1][b1][k];
                float f1 = Tables.t_d[b3];
                if ((i3 & i2) == 0)
                  f1 -= Tables.t_c[b3]; 
                f1 += (i3 & i2 - 1) * Tables.t_finv_alloc[b3];
                arrayOfFloat1[i1][k] = f1;
              } 
            } 
          } else {
            arrayOfFloat1[i1][k] = 0.0F;
          } 
        } 
      } 
    } 
    for (k = n; k < 32; k++) {
      for (byte b1 = 0; b1 < 3; b1++) {
        float[][] arrayOfFloat1 = arrayOfFloat[(paramInt + b1) / 12][(paramInt + b1) % 12];
        for (int i1 = i; i1 < j; i1++)
          arrayOfFloat1[i1][k] = 0.0F; 
      } 
    } 
  }
  
  private void new(int paramInt) {
    int i = this.X.bn.k;
    int j = this.X.bn.k + this.aE;
    int k = paramInt >> 2;
    int n = this.ak;
    byte[][][] arrayOfByte = this.X.bp;
    float[][][][] arrayOfFloat = this.X.bu;
    paramInt *= 3;
    for (byte b1 = 0; b1 < n; b1++) {
      byte b2 = Q[b1];
      for (byte b3 = 0; b3 < 3; b3++) {
        float[][] arrayOfFloat1 = arrayOfFloat[(paramInt + b3) / 12][(paramInt + b3) % 12];
        if (this.aq == 0) {
          for (int i1 = i; i1 < j; i1++)
            arrayOfFloat1[i1][b1] = arrayOfFloat1[i1][b1] * Tables.t_multiple[arrayOfByte[k][i1][b1]]; 
        } else if (this.U == 0) {
          if (this.R == 3) {
            arrayOfFloat1[i][b1] = arrayOfFloat1[i][b1] * Tables.t_multiple[arrayOfByte[k][i][b1]];
            if (this.ai[b2] == 0) {
              arrayOfFloat1[i + 1][b1] = arrayOfFloat1[i + 1][b1] * Tables.t_multiple[arrayOfByte[k][i + 1][b1]];
            } else {
              arrayOfFloat1[i + 1][b1] = arrayOfFloat1[i][b1] * aC[arrayOfByte[k][i][b1]] * Tables.t_multiple[arrayOfByte[k][i + 1][b1]];
            } 
          } 
        } else if (this.U == 1) {
          switch (this.ae[b2]) {
            case 0:
              arrayOfFloat1[2][b1] = arrayOfFloat1[2][b1] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              if (this.R == 3) {
                arrayOfFloat1[3][b1] = arrayOfFloat1[3][b1] * Tables.t_multiple[arrayOfByte[k][3][b1]];
                if (this.ai[b2] == 0) {
                  arrayOfFloat1[4][b1] = arrayOfFloat1[4][b1] * Tables.t_multiple[arrayOfByte[k][4][b1]];
                  break;
                } 
                arrayOfFloat1[4][b1] = arrayOfFloat1[3][b1] * aC[arrayOfByte[k][3][b1]] * Tables.t_multiple[arrayOfByte[k][4][b1]];
              } 
              break;
            case 1:
              if (this.ab[b2] == 0)
                if (this.aD != 0) {
                  arrayOfFloat1[2][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
                } else {
                  arrayOfFloat1[2][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
                }  
              if (this.ab[b2] == 1)
                arrayOfFloat1[2][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]]; 
              if (this.ab[b2] == 2)
                arrayOfFloat1[2][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]]; 
              if (this.R == 3) {
                arrayOfFloat1[3][b1] = arrayOfFloat1[3][b1] * Tables.t_multiple[arrayOfByte[k][3][b1]];
                if (this.ai[b2] == 0) {
                  arrayOfFloat1[4][b1] = arrayOfFloat1[4][b1] * Tables.t_multiple[arrayOfByte[k][4][b1]];
                  break;
                } 
                arrayOfFloat1[4][b1] = arrayOfFloat1[3][b1] * aC[arrayOfByte[k][3][b1]] * Tables.t_multiple[arrayOfByte[k][4][b1]];
              } 
              break;
          } 
        } else if (this.U == 3) {
          int i1;
          switch (this.ae[b2]) {
            case 0:
              for (i1 = i; i1 < j; i1++)
                arrayOfFloat1[i1][b1] = arrayOfFloat1[i1][b1] * Tables.t_multiple[arrayOfByte[k][i1][b1]]; 
              break;
            case 1:
              arrayOfFloat1[2][b1] = arrayOfFloat1[2][b1] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              if (this.R == 2 || this.ab[b2] == 4 || this.ab[b2] == 5 || (this.ab[b2] != 3 && this.aD != 0)) {
                arrayOfFloat1[3][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][3][b1]];
                break;
              } 
              arrayOfFloat1[3][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][3][b1]];
              break;
            case 2:
              arrayOfFloat1[3][b1] = arrayOfFloat1[3][b1] * Tables.t_multiple[arrayOfByte[k][3][b1]];
              if (this.R == 2 || this.ab[b2] == 1 || this.ab[b2] == 5 || (this.ab[b2] != 2 && this.aD == 0)) {
                arrayOfFloat1[2][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
                break;
              } 
              arrayOfFloat1[2][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              break;
            case 3:
              if (this.R == 2 || this.ab[b2] == 1 || this.ab[b2] == 5 || (this.ab[b2] != 2 && this.aD == 0)) {
                arrayOfFloat1[2][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } else {
                arrayOfFloat1[2][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } 
              if (this.R == 2 || this.ab[b2] == 4 || this.ab[b2] == 5 || (this.ab[b2] != 3 && this.aD != 0)) {
                arrayOfFloat1[3][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][3][b1]];
                break;
              } 
              arrayOfFloat1[3][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][3][b1]];
              break;
            case 4:
              arrayOfFloat1[3][b1] = arrayOfFloat1[2][b1];
              arrayOfFloat1[2][b1] = arrayOfFloat1[2][b1] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              arrayOfFloat1[3][b1] = arrayOfFloat1[3][b1] * Tables.t_multiple[arrayOfByte[k][3][b1]];
              break;
          } 
        } else if (this.U == 4) {
          int i1;
          switch (this.ae[b2]) {
            case 0:
              for (i1 = i; i1 < j; i1++)
                arrayOfFloat1[i1][b1] = arrayOfFloat1[i1][b1] * Tables.t_multiple[arrayOfByte[k][i1][b1]]; 
              break;
            case 1:
              arrayOfFloat1[2][b1] = arrayOfFloat1[2][b1] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              arrayOfFloat1[3][b1] = arrayOfFloat1[3][b1] * Tables.t_multiple[arrayOfByte[k][3][b1]];
              arrayOfFloat1[4][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][4][b1]];
              break;
            case 2:
              arrayOfFloat1[2][b1] = arrayOfFloat1[2][b1] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              arrayOfFloat1[3][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][3][b1]];
              arrayOfFloat1[4][b1] = arrayOfFloat1[4][b1] * Tables.t_multiple[arrayOfByte[k][4][b1]];
              break;
            case 3:
              if (this.ab[b2] == 1 || this.ab[b2] == 7) {
                arrayOfFloat1[2][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } else if (this.ab[b2] == 2 || this.ab[b2] == 6) {
                arrayOfFloat1[2][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } else if (this.aD != 0) {
                arrayOfFloat1[2][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } else {
                arrayOfFloat1[2][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } 
              arrayOfFloat1[3][b1] = arrayOfFloat1[3][b1] * Tables.t_multiple[arrayOfByte[k][3][b1]];
              arrayOfFloat1[4][b1] = arrayOfFloat1[4][b1] * Tables.t_multiple[arrayOfByte[k][4][b1]];
              break;
            case 4:
              arrayOfFloat1[2][b1] = arrayOfFloat1[2][b1] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              arrayOfFloat1[3][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][3][b1]];
              arrayOfFloat1[4][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][4][b1]];
              break;
            case 5:
              if (this.ab[b2] == 1 || this.ab[b2] == 7) {
                arrayOfFloat1[2][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } else if (this.ab[b2] == 2 || this.ab[b2] == 6) {
                arrayOfFloat1[2][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } else if (this.aD != 0) {
                arrayOfFloat1[2][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } else {
                arrayOfFloat1[2][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } 
              arrayOfFloat1[3][b1] = arrayOfFloat1[3][b1] * Tables.t_multiple[arrayOfByte[k][3][b1]];
              arrayOfFloat1[4][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][4][b1]];
              break;
            case 6:
              if (this.ab[b2] == 1 || this.ab[b2] == 7) {
                arrayOfFloat1[2][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } else if (this.ab[b2] == 2 || this.ab[b2] == 6) {
                arrayOfFloat1[2][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } else if (this.aD != 0) {
                arrayOfFloat1[2][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } else {
                arrayOfFloat1[2][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } 
              arrayOfFloat1[3][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][3][b1]];
              arrayOfFloat1[4][b1] = arrayOfFloat1[4][b1] * Tables.t_multiple[arrayOfByte[k][4][b1]];
              break;
            case 7:
              if (this.ab[b2] == 1 || this.ab[b2] == 7) {
                arrayOfFloat1[2][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } else if (this.ab[b2] == 2 || this.ab[b2] == 6) {
                arrayOfFloat1[2][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } else if (this.aD != 0) {
                arrayOfFloat1[2][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } else {
                arrayOfFloat1[2][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } 
              arrayOfFloat1[3][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][3][b1]];
              arrayOfFloat1[4][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][4][b1]];
              break;
            case 8:
              arrayOfFloat1[2][b1] = arrayOfFloat1[2][b1] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              arrayOfFloat1[4][b1] = arrayOfFloat1[3][b1];
              arrayOfFloat1[3][b1] = arrayOfFloat1[3][b1] * Tables.t_multiple[arrayOfByte[k][3][b1]];
              arrayOfFloat1[4][b1] = arrayOfFloat1[4][b1] * Tables.t_multiple[arrayOfByte[k][4][b1]];
              break;
            case 9:
              arrayOfFloat1[3][b1] = arrayOfFloat1[2][b1];
              arrayOfFloat1[2][b1] = arrayOfFloat1[2][b1] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              arrayOfFloat1[3][b1] = arrayOfFloat1[3][b1] * Tables.t_multiple[arrayOfByte[k][3][b1]];
              arrayOfFloat1[4][b1] = arrayOfFloat1[4][b1] * Tables.t_multiple[arrayOfByte[k][4][b1]];
              break;
            case 10:
              arrayOfFloat1[4][b1] = arrayOfFloat1[2][b1];
              arrayOfFloat1[2][b1] = arrayOfFloat1[2][b1] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              arrayOfFloat1[3][b1] = arrayOfFloat1[3][b1] * Tables.t_multiple[arrayOfByte[k][3][b1]];
              arrayOfFloat1[4][b1] = arrayOfFloat1[4][b1] * Tables.t_multiple[arrayOfByte[k][4][b1]];
              break;
            case 11:
              arrayOfFloat1[3][b1] = arrayOfFloat1[2][b1];
              arrayOfFloat1[2][b1] = arrayOfFloat1[2][b1] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              arrayOfFloat1[3][b1] = arrayOfFloat1[3][b1] * Tables.t_multiple[arrayOfByte[k][3][b1]];
              arrayOfFloat1[4][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][4][b1]];
              break;
            case 12:
              arrayOfFloat1[4][b1] = arrayOfFloat1[2][b1];
              arrayOfFloat1[2][b1] = arrayOfFloat1[2][b1] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              arrayOfFloat1[3][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][3][b1]];
              arrayOfFloat1[4][b1] = arrayOfFloat1[4][b1] * Tables.t_multiple[arrayOfByte[k][4][b1]];
              break;
            case 13:
              if (this.ab[b2] == 1 || this.ab[b2] == 7) {
                arrayOfFloat1[2][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } else if (this.ab[b2] == 2 || this.ab[b2] == 6) {
                arrayOfFloat1[2][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } else if (this.aD != 0) {
                arrayOfFloat1[2][b1] = arrayOfFloat1[1][b1] * aC[arrayOfByte[k][1][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } else {
                arrayOfFloat1[2][b1] = arrayOfFloat1[0][b1] * aC[arrayOfByte[k][0][b1]] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              } 
              arrayOfFloat1[4][b1] = arrayOfFloat1[3][b1];
              arrayOfFloat1[3][b1] = arrayOfFloat1[3][b1] * Tables.t_multiple[arrayOfByte[k][3][b1]];
              arrayOfFloat1[4][b1] = arrayOfFloat1[4][b1] * Tables.t_multiple[arrayOfByte[k][4][b1]];
              break;
            case 14:
              arrayOfFloat1[4][b1] = arrayOfFloat1[2][b1];
              arrayOfFloat1[3][b1] = arrayOfFloat1[2][b1];
              arrayOfFloat1[2][b1] = arrayOfFloat1[2][b1] * Tables.t_multiple[arrayOfByte[k][2][b1]];
              arrayOfFloat1[3][b1] = arrayOfFloat1[3][b1] * Tables.t_multiple[arrayOfByte[k][3][b1]];
              arrayOfFloat1[4][b1] = arrayOfFloat1[4][b1] * Tables.t_multiple[arrayOfByte[k][4][b1]];
              break;
          } 
        } 
      } 
    } 
  }
  
  private void try() {
    f f = this.X.bA;
    for (byte b1 = 0; b1 < 12; b1++) {
      byte b2 = f.if[0][this.av];
      int i = Tables.t_alloc[b2];
      int j = this.aK[b1];
      float f1 = Tables.t_d[b2];
      if ((j & i) == 0)
        f1 -= Tables.t_c[b2]; 
      f1 += (j & i - 1) * Tables.t_finv_alloc[b2];
      this.S[b1] = f1 * Tables.t_multiple[this.aj];
    } 
  }
  
  private float a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    float[][][] arrayOfFloat = this.au;
    float f = 0.0F;
    for (byte b1 = 0; b1 < this.W[paramInt1][paramInt5]; b1++)
      f += arrayOfFloat[paramInt4][paramInt1][9 + paramInt2 + 12 * paramInt3 - b1 - this.aa[paramInt1][paramInt5]] * (this.ad[paramInt1][paramInt5][b1] - 127) * 0.03125F; 
    return f;
  }
  
  private void for() {
    byte b2 = 0;
    float[][][][] arrayOfFloat = this.X.bu;
    for (byte b1 = 0; b1 < 3; b1++) {
      for (byte b3 = 0; b3 < 12; b3++) {
        for (byte b4 = 0; b4 < 32; b4++) {
          int i;
          if (this.an == 1) {
            i = this.as;
          } else {
            b2 = Q[b4];
            i = this.ab[b2];
          } 
          if (this.aG != 0 && b4 < 8 && this.ap[b4] != 0)
            if (this.R == 2 && this.T != 0) {
              switch (this.ae[b4]) {
                case 0:
                  arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][2][b4] + a(b4, b3, b1, 0, 0) + a(b4, b3, b1, 1, 1);
                  arrayOfFloat[b1][b3][3][b4] = arrayOfFloat[b1][b3][3][b4] + a(b4, b3, b1, 0, 2) + a(b4, b3, b1, 1, 3);
                  arrayOfFloat[b1][b3][4][b4] = arrayOfFloat[b1][b3][4][b4] + a(b4, b3, b1, 0, 4) + a(b4, b3, b1, 1, 5);
                  break;
                case 1:
                  arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][2][b4] + a(b4, b3, b1, 0, 0) + a(b4, b3, b1, 1, 1);
                  arrayOfFloat[b1][b3][3][b4] = arrayOfFloat[b1][b3][3][b4] + a(b4, b3, b1, 0, 2) + a(b4, b3, b1, 1, 3);
                  break;
                case 2:
                  arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][2][b4] + a(b4, b3, b1, 0, 0) + a(b4, b3, b1, 1, 1);
                  arrayOfFloat[b1][b3][4][b4] = arrayOfFloat[b1][b3][4][b4] + a(b4, b3, b1, 0, 2) + a(b4, b3, b1, 1, 3);
                  break;
                case 3:
                  arrayOfFloat[b1][b3][3][b4] = arrayOfFloat[b1][b3][3][b4] + a(b4, b3, b1, 0, 0) + a(b4, b3, b1, 1, 1);
                  arrayOfFloat[b1][b3][4][b4] = arrayOfFloat[b1][b3][4][b4] + a(b4, b3, b1, 0, 2) + a(b4, b3, b1, 1, 3);
                  break;
                case 4:
                  arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][2][b4] + a(b4, b3, b1, 0, 0) + a(b4, b3, b1, 1, 1);
                  break;
                case 5:
                  arrayOfFloat[b1][b3][3][b4] = arrayOfFloat[b1][b3][3][b4] + a(b4, b3, b1, 0, 0) + a(b4, b3, b1, 1, 1);
                  break;
                case 6:
                  arrayOfFloat[b1][b3][4][b4] = arrayOfFloat[b1][b3][4][b4] + a(b4, b3, b1, 0, 0) + a(b4, b3, b1, 1, 1);
                  break;
                case 8:
                  arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][2][b4] + a(b4, b3, b1, 0, 0) + a(b4, b3, b1, 1, 1);
                  break;
                case 9:
                  arrayOfFloat[b1][b3][4][b4] = arrayOfFloat[b1][b3][4][b4] + a(b4, b3, b1, 0, 0) + a(b4, b3, b1, 1, 1);
                  break;
                case 10:
                  arrayOfFloat[b1][b3][3][b4] = arrayOfFloat[b1][b3][3][b4] + a(b4, b3, b1, 0, 0) + a(b4, b3, b1, 1, 1);
                  break;
              } 
            } else if ((this.R == 1 && this.T != 0) || (this.R == 2 && this.T == 0)) {
              switch (this.ae[b4]) {
                case 0:
                  arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][2][b4] + a(b4, b3, b1, 0, 0) + a(b4, b3, b1, 1, 1);
                  arrayOfFloat[b1][b3][3][b4] = arrayOfFloat[b1][b3][3][b4] + a(b4, b3, b1, 0, 2) + a(b4, b3, b1, 1, 3);
                  break;
                case 1:
                  arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][2][b4] + a(b4, b3, b1, 0, 0) + a(b4, b3, b1, 1, 1);
                  break;
                case 2:
                  arrayOfFloat[b1][b3][3][b4] = arrayOfFloat[b1][b3][3][b4] + a(b4, b3, b1, 0, 0) + a(b4, b3, b1, 1, 1);
                  break;
              } 
            } else if (((this.R == 0 || this.R == 3) && this.T != 0) || (this.R == 1 && this.T == 0)) {
              switch (this.ae[b4]) {
                case 0:
                  arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][2][b4] + a(b4, b3, b1, 0, 0) + a(b4, b3, b1, 1, 1);
                  break;
              } 
            }  
          if (this.aw != 3)
            if (this.R == 2 && this.T != 0) {
              float f;
              switch (i) {
                case 0:
                  if (this.aw == 2) {
                    float f1 = (arrayOfFloat[b1][b3][3][b4] + arrayOfFloat[b1][b3][4][b4]) * 0.5F;
                    arrayOfFloat[b1][b3][0][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4] + f1;
                    arrayOfFloat[b1][b3][1][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][2][b4] - f1;
                    break;
                  } 
                  arrayOfFloat[b1][b3][0][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][3][b4];
                  arrayOfFloat[b1][b3][1][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][4][b4];
                  break;
                case 1:
                  if (this.aw == 2) {
                    float f2 = (arrayOfFloat[b1][b3][3][b4] + arrayOfFloat[b1][b3][4][b4]) * 0.5F;
                    float f1 = arrayOfFloat[b1][b3][2][b4];
                    arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4] + f2;
                    arrayOfFloat[b1][b3][1][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][2][b4] - f2;
                    arrayOfFloat[b1][b3][0][b4] = f1;
                    break;
                  } 
                  f = arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][3][b4];
                  arrayOfFloat[b1][b3][1][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][4][b4];
                  arrayOfFloat[b1][b3][0][b4] = f;
                  break;
                case 2:
                  if (this.aw == 2) {
                    float f1 = (arrayOfFloat[b1][b3][3][b4] + arrayOfFloat[b1][b3][4][b4]) * 0.5F;
                    f = arrayOfFloat[b1][b3][2][b4];
                    arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][2][b4] - f1;
                    arrayOfFloat[b1][b3][0][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4] + f1;
                    arrayOfFloat[b1][b3][1][b4] = f;
                    break;
                  } 
                  f = arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][4][b4];
                  arrayOfFloat[b1][b3][0][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][3][b4];
                  arrayOfFloat[b1][b3][1][b4] = f;
                  break;
                case 3:
                  if (this.aw == 2) {
                    f = arrayOfFloat[b1][b3][3][b4];
                    arrayOfFloat[b1][b3][3][b4] = -2.0F * (arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][3][b4]) - arrayOfFloat[b1][b3][4][b4];
                    arrayOfFloat[b1][b3][1][b4] = arrayOfFloat[b1][b3][0][b4] + arrayOfFloat[b1][b3][1][b4] - 2.0F * arrayOfFloat[b1][b3][2][b4] - f;
                    arrayOfFloat[b1][b3][0][b4] = f;
                    break;
                  } 
                  f = arrayOfFloat[b1][b3][3][b4];
                  arrayOfFloat[b1][b3][3][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][3][b4] - arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][1][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][4][b4];
                  arrayOfFloat[b1][b3][0][b4] = f;
                  break;
                case 4:
                  if (this.aw == 2) {
                    f = arrayOfFloat[b1][b3][4][b4];
                    arrayOfFloat[b1][b3][0][b4] = arrayOfFloat[b1][b3][0][b4] + arrayOfFloat[b1][b3][1][b4] - 2.0F * arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][4][b4];
                    arrayOfFloat[b1][b3][4][b4] = 2.0F * arrayOfFloat[b1][b3][1][b4] - 2.0F * (arrayOfFloat[b1][b3][2][b4] + arrayOfFloat[b1][b3][4][b4]) - arrayOfFloat[b1][b3][3][b4];
                    arrayOfFloat[b1][b3][1][b4] = f;
                    break;
                  } 
                  f = arrayOfFloat[b1][b3][4][b4];
                  arrayOfFloat[b1][b3][0][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][3][b4];
                  arrayOfFloat[b1][b3][4][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][4][b4] - arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][1][b4] = f;
                  break;
                case 5:
                  if (this.aw == 2) {
                    f = arrayOfFloat[b1][b3][3][b4];
                    arrayOfFloat[b1][b3][3][b4] = 0.5F * (arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][0][b4] + arrayOfFloat[b1][b3][3][b4] - arrayOfFloat[b1][b3][4][b4]);
                    arrayOfFloat[b1][b3][0][b4] = f;
                    arrayOfFloat[b1][b3][1][b4] = arrayOfFloat[b1][b3][4][b4];
                    arrayOfFloat[b1][b3][4][b4] = arrayOfFloat[b1][b3][3][b4];
                    break;
                  } 
                  f = arrayOfFloat[b1][b3][3][b4];
                  arrayOfFloat[b1][b3][3][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][3][b4] - arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][0][b4] = f;
                  f = arrayOfFloat[b1][b3][4][b4];
                  arrayOfFloat[b1][b3][4][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][4][b4] - arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][1][b4] = f;
                  break;
                case 6:
                  if (this.aw == 2) {
                    f = arrayOfFloat[b1][b3][2][b4];
                    float f1 = arrayOfFloat[b1][b3][3][b4];
                    arrayOfFloat[b1][b3][3][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4] + arrayOfFloat[b1][b3][3][b4] - arrayOfFloat[b1][b3][4][b4];
                    arrayOfFloat[b1][b3][2][b4] = 0.5F * (arrayOfFloat[b1][b3][0][b4] + arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][2][b4] - f1);
                    arrayOfFloat[b1][b3][1][b4] = f;
                    arrayOfFloat[b1][b3][0][b4] = f1;
                    break;
                  } 
                  f = arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][4][b4];
                  arrayOfFloat[b1][b3][1][b4] = f;
                  f = arrayOfFloat[b1][b3][3][b4];
                  arrayOfFloat[b1][b3][3][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][3][b4] - arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][0][b4] = f;
                  break;
                case 7:
                  if (this.aw == 2) {
                    f = arrayOfFloat[b1][b3][2][b4];
                    float f1 = arrayOfFloat[b1][b3][4][b4];
                    arrayOfFloat[b1][b3][4][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][0][b4] + arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][3][b4] - arrayOfFloat[b1][b3][4][b4];
                    arrayOfFloat[b1][b3][2][b4] = 0.5F * (arrayOfFloat[b1][b3][0][b4] + arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][2][b4] - f1);
                    arrayOfFloat[b1][b3][0][b4] = f;
                    arrayOfFloat[b1][b3][1][b4] = f1;
                    break;
                  } 
                  f = arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][3][b4];
                  arrayOfFloat[b1][b3][0][b4] = f;
                  f = arrayOfFloat[b1][b3][4][b4];
                  arrayOfFloat[b1][b3][4][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][4][b4] - arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][1][b4] = f;
                  break;
              } 
            } else if (this.R == 1 && this.T != 0) {
              float f1;
              float f2;
              switch (i) {
                case 0:
                  if (this.aw == 2) {
                    arrayOfFloat[b1][b3][0][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4] + arrayOfFloat[b1][b3][3][b4];
                  } else {
                    arrayOfFloat[b1][b3][0][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][3][b4];
                  } 
                  arrayOfFloat[b1][b3][1][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][3][b4];
                  break;
                case 1:
                  f1 = arrayOfFloat[b1][b3][2][b4];
                  if (this.aw == 2) {
                    arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4] + arrayOfFloat[b1][b3][3][b4];
                  } else {
                    arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][3][b4];
                  } 
                  arrayOfFloat[b1][b3][1][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][3][b4];
                  arrayOfFloat[b1][b3][0][b4] = f1;
                  break;
                case 2:
                  f1 = arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][3][b4];
                  if (this.aw == 2) {
                    arrayOfFloat[b1][b3][0][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4] + arrayOfFloat[b1][b3][3][b4];
                  } else {
                    arrayOfFloat[b1][b3][0][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][3][b4];
                  } 
                  arrayOfFloat[b1][b3][1][b4] = f1;
                  break;
                case 3:
                  f1 = arrayOfFloat[b1][b3][3][b4];
                  if (this.aw == 2) {
                    arrayOfFloat[b1][b3][3][b4] = -arrayOfFloat[b1][b3][0][b4] + arrayOfFloat[b1][b3][2][b4] + arrayOfFloat[b1][b3][3][b4];
                  } else {
                    arrayOfFloat[b1][b3][3][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][3][b4];
                  } 
                  arrayOfFloat[b1][b3][1][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][3][b4];
                  arrayOfFloat[b1][b3][0][b4] = f1;
                  break;
                case 4:
                  f1 = arrayOfFloat[b1][b3][3][b4];
                  arrayOfFloat[b1][b3][3][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][3][b4];
                  if (this.aw == 2) {
                    arrayOfFloat[b1][b3][0][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4] + arrayOfFloat[b1][b3][3][b4];
                  } else {
                    arrayOfFloat[b1][b3][0][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4] - arrayOfFloat[b1][b3][3][b4];
                  } 
                  arrayOfFloat[b1][b3][1][b4] = f1;
                  break;
                case 5:
                  f1 = arrayOfFloat[b1][b3][2][b4];
                  f2 = arrayOfFloat[b1][b3][3][b4];
                  arrayOfFloat[b1][b3][2][b4] = 0.5F * (arrayOfFloat[b1][b3][0][b4] + arrayOfFloat[b1][b3][1][b4] - f1 - f2);
                  arrayOfFloat[b1][b3][3][b4] = 0.5F * (arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][0][b4] + f1 - f2);
                  arrayOfFloat[b1][b3][0][b4] = f1;
                  arrayOfFloat[b1][b3][1][b4] = f2;
                  break;
              } 
            } else if (this.R == 1 || this.T != 0) {
              float f;
              switch (i) {
                case 0:
                  arrayOfFloat[b1][b3][0][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][1][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][2][b4];
                  break;
                case 1:
                  f = arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][1][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][0][b4] = f;
                  break;
                case 2:
                  f = arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][0][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][1][b4] = f;
                  break;
              } 
            } else if (this.R == 2) {
              float f;
              switch (i) {
                case 0:
                  arrayOfFloat[b1][b3][0][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][1][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][3][b4];
                  break;
                case 1:
                  f = arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][1][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][3][b4];
                  arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][0][b4] = f;
                  break;
                case 2:
                  f = arrayOfFloat[b1][b3][3][b4];
                  arrayOfFloat[b1][b3][0][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][3][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][3][b4];
                  arrayOfFloat[b1][b3][1][b4] = f;
                  break;
                case 3:
                  f = arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][2][b4] = arrayOfFloat[b1][b3][0][b4] - arrayOfFloat[b1][b3][2][b4];
                  arrayOfFloat[b1][b3][0][b4] = f;
                  f = arrayOfFloat[b1][b3][3][b4];
                  arrayOfFloat[b1][b3][3][b4] = arrayOfFloat[b1][b3][1][b4] - arrayOfFloat[b1][b3][3][b4];
                  arrayOfFloat[b1][b3][1][b4] = f;
                  break;
              } 
            }  
        } 
      } 
    } 
  }
  
  private void int() {
    float f1 = 0.0F;
    float f2 = 0.0F;
    float f3 = 0.0F;
    int i = this.X.bn.k;
    float[][][][] arrayOfFloat = this.X.bu;
    int j = this.X.bn.k + this.aE;
    switch (this.aw) {
      case 0:
      case 2:
        f1 = 2.4142137F;
        f2 = 1.4142135F * f1;
        f3 = 1.4142135F * f1;
        break;
      case 1:
        f1 = 2.2071068F;
        f2 = 1.4142135F * f1;
        f3 = 2.0F * f1;
        break;
      case 3:
        f1 = 1.0F;
        f2 = 1.0F;
        f3 = 1.0F;
        break;
    } 
    if (this.aw != 3)
      for (byte b1 = 0; b1 < 12; b1++) {
        for (byte b2 = 0; b2 < 3; b2++) {
          for (byte b3 = 0; b3 < 32; b3++) {
            for (byte b4 = 0; b4 < i; b4++)
              arrayOfFloat[b2][b1][b4][b3] = arrayOfFloat[b2][b1][b4][b3] * f1; 
            if (this.aw != 1) {
              if (this.R == 3) {
                if (this.T != 0)
                  arrayOfFloat[b2][b1][2][b3] = arrayOfFloat[b2][b1][2][b3] * f2; 
              } else {
                for (byte b5 = 2; b5 < j; b5++)
                  arrayOfFloat[b2][b1][b5][b3] = arrayOfFloat[b2][b1][b5][b3] * f2; 
              } 
            } else if (this.R == 3) {
              if (this.T != 0)
                arrayOfFloat[b2][b1][2][b3] = arrayOfFloat[b2][b1][2][b3] * f2; 
            } else if (this.aE == 3) {
              arrayOfFloat[b2][b1][2][b3] = arrayOfFloat[b2][b1][2][b3] * f2;
              arrayOfFloat[b2][b1][3][b3] = arrayOfFloat[b2][b1][3][b3] * f3;
              arrayOfFloat[b2][b1][4][b3] = arrayOfFloat[b2][b1][4][b3] * f3;
            } else if (this.aE == 2) {
              if (this.R == 2) {
                arrayOfFloat[b2][b1][2][b3] = arrayOfFloat[b2][b1][2][b3] * f3;
                arrayOfFloat[b2][b1][3][b3] = arrayOfFloat[b2][b1][3][b3] * f3;
              } else {
                arrayOfFloat[b2][b1][2][b3] = arrayOfFloat[b2][b1][2][b3] * f2;
                arrayOfFloat[b2][b1][3][b3] = arrayOfFloat[b2][b1][3][b3] * f3;
              } 
            } else if (this.T == 0) {
              arrayOfFloat[b2][b1][2][b3] = arrayOfFloat[b2][b1][2][b3] * f3;
            } else {
              arrayOfFloat[b2][b1][2][b3] = arrayOfFloat[b2][b1][2][b3] * f2;
            } 
          } 
        } 
      }  
  }
  
  private void byte() {
    int j = this.ak;
    f f = this.X.bA;
    byte[][] arrayOfByte = this.X.bs[0];
    int k = this.aB;
    int i;
    for (i = 0; i < j; i++) {
      for (byte b2 = 0; b2 < k; b2++)
        arrayOfByte[b2][i] = (byte)this.X.bv.if(f.a[i]); 
    } 
    for (byte b1 = 0; b1 < k; b1++) {
      for (i = j; i < 32; i++)
        arrayOfByte[b1][i] = 0; 
    } 
  }
  
  private void do(int[][] paramArrayOfint) {
    int j = this.ak;
    byte[][][] arrayOfByte = this.X.bp;
    byte[][] arrayOfByte1 = this.X.bs[0];
    int k = this.aB;
    int i;
    for (i = 0; i < j; i++) {
      for (byte b2 = 0; b2 < k; b2++) {
        if (arrayOfByte1[b2][i] != 0) {
          paramArrayOfint[b2][i] = this.X.bv.if(2);
        } else {
          paramArrayOfint[b2][i] = 4;
        } 
      } 
    } 
    byte b1;
    for (b1 = 0; b1 < k; b1++) {
      for (i = j; i < 32; i++)
        paramArrayOfint[b1][i] = 4; 
    } 
    for (i = 0; i < j; i++) {
      for (b1 = 0; b1 < k; b1++) {
        if (arrayOfByte1[b1][i] != 0) {
          switch (paramArrayOfint[b1][i]) {
            case 0:
              arrayOfByte[0][b1][i] = (byte)this.X.bv.if(6);
              arrayOfByte[1][b1][i] = (byte)this.X.bv.if(6);
              arrayOfByte[2][b1][i] = (byte)this.X.bv.if(6);
              break;
            case 1:
              arrayOfByte[1][b1][i] = (byte)this.X.bv.if(6);
              arrayOfByte[0][b1][i] = (byte)this.X.bv.if(6);
              arrayOfByte[2][b1][i] = (byte)this.X.bv.if(6);
              break;
            case 3:
              arrayOfByte[0][b1][i] = (byte)this.X.bv.if(6);
              arrayOfByte[2][b1][i] = (byte)this.X.bv.if(6);
              arrayOfByte[1][b1][i] = (byte)this.X.bv.if(6);
              break;
            case 2:
              arrayOfByte[2][b1][i] = (byte)this.X.bv.if(6);
              arrayOfByte[1][b1][i] = (byte)this.X.bv.if(6);
              arrayOfByte[0][b1][i] = (byte)this.X.bv.if(6);
              break;
            default:
              arrayOfByte[2][b1][i] = 63;
              arrayOfByte[1][b1][i] = 63;
              arrayOfByte[0][b1][i] = 63;
              break;
          } 
        } else {
          arrayOfByte[2][b1][i] = 63;
          arrayOfByte[1][b1][i] = 63;
          arrayOfByte[0][b1][i] = 63;
        } 
      } 
    } 
    for (b1 = 0; b1 < k; b1++) {
      for (i = j; i < 32; i++) {
        arrayOfByte[2][b1][i] = 63;
        arrayOfByte[1][b1][i] = 63;
        arrayOfByte[0][b1][i] = 63;
      } 
    } 
  }
  
  private void a(int[][][] paramArrayOfint) {
    int j = 0;
    int k = this.ak;
    f f = this.X.bA;
    int n = this.aB;
    byte[][] arrayOfByte = this.X.bs[0];
    int i;
    for (i = 0; i < k; i++) {
      for (byte b1 = 0; b1 < n; b1++) {
        if (arrayOfByte[b1][i] != 0) {
          byte b2 = f.for[i][arrayOfByte[b1][i]];
          if (b2 > 0) {
            paramArrayOfint[b1][0][i] = this.X.bv.if(b2);
            paramArrayOfint[b1][1][i] = this.X.bv.if(b2);
            paramArrayOfint[b1][2][i] = this.X.bv.if(b2);
          } else {
            j = this.X.bv.if(-b2);
            int i1 = -b2 & 0x6;
            i1 /= 2;
            byte[] arrayOfByte1 = this.X.bw[i1];
            paramArrayOfint[b1][0][i] = arrayOfByte1[3 * j];
            paramArrayOfint[b1][1][i] = arrayOfByte1[3 * j + 1];
            paramArrayOfint[b1][2][i] = arrayOfByte1[3 * j + 2];
          } 
        } else {
          paramArrayOfint[b1][0][i] = 0;
          paramArrayOfint[b1][1][i] = 0;
          paramArrayOfint[b1][2][i] = 0;
        } 
      } 
    } 
    for (i = k; i < 32; i++) {
      for (byte b1 = 0; b1 < n; b1++) {
        for (byte b2 = 0; b2 < 3; b2++)
          paramArrayOfint[b1][b2][i] = 0; 
      } 
    } 
  }
  
  private void if(int[][][] paramArrayOfint, int paramInt) {
    int j = this.ak;
    f f = this.X.bA;
    int k = this.aB;
    byte[][] arrayOfByte = this.X.bs[0];
    float[][][][] arrayOfFloat = this.X.bu;
    byte[][][] arrayOfByte1 = this.X.bp;
    int n = this.X.bn.k + this.aE;
    int i1 = paramInt >> 2 - this.ac;
    paramInt *= 3;
    int i;
    for (i = 0; i < j; i++) {
      for (byte b1 = 0; b1 < 3; b1++) {
        float[][] arrayOfFloat1 = arrayOfFloat[(paramInt + b1) / 12][(paramInt + b1) % 12];
        for (byte b2 = 0; b2 < k; b2++) {
          if (arrayOfByte[b2][i] != 0) {
            byte b3 = f.if[i][arrayOfByte[b2][i]];
            int i2 = Tables.t_alloc[b3];
            int i3 = paramArrayOfint[b2][b1][i];
            float f1 = Tables.t_d[b3];
            if ((i3 & i2) == 0)
              f1 -= Tables.t_c[b3]; 
            f1 += (i3 & i2 - 1) * Tables.t_finv_alloc[b3];
            f1 *= Tables.t_multiple[arrayOfByte1[i1][b2][i]];
            arrayOfFloat1[b2 + n][i] = f1;
          } else {
            arrayOfFloat1[b2 + n][i] = 0.0F;
          } 
        } 
      } 
    } 
    for (i = j; i < 32; i++) {
      for (byte b1 = 0; b1 < 3; b1++) {
        float[][] arrayOfFloat1 = arrayOfFloat[(paramInt + b1) / 12][(paramInt + b1) % 12];
        for (byte b2 = 0; b2 < k; b2++)
          arrayOfFloat1[b2 + n][i] = 0.0F; 
      } 
    } 
  }
  
  private int a(b paramb, int paramInt) {
    byte[] arrayOfByte = this.ao.cB;
    int i1 = this.ao.cJ;
    int i = this.ao.cG;
    if (arrayOfByte == null)
      return -4; 
    if (i < 5)
      return -6; 
    if ((arrayOfByte[i1] & 0xFF) != 127 || (arrayOfByte[i1 + 1] & 0xFF) >> 4 != 15)
      return -4; 
    int k = (arrayOfByte[i1 + 1] & 0xF) << 12 | (arrayOfByte[i1 + 2] & 0xFF) << 4 | (arrayOfByte[i1 + 3] & 0xFF) >>> 4;
    int n = (arrayOfByte[i1 + 3] & 0xF) << 8 | arrayOfByte[i1 + 4] & 0xFF;
    int j = g.a(n, 65535, 12);
    n >>= 1;
    if (i < n)
      return -6; 
    if (k != 0) {
      int i2 = n - 5 << 3;
      if (i2 > 116) {
        i2 = 116;
      } else if (i2 == 0) {
        if (j == k) {
          this.ao.cA = n;
          return n - 5 << 3;
        } 
        return -5;
      } 
      this.ag.a(arrayOfByte, i1 + 5, n - 5);
      j = g.a(this.ag, j, i2);
      if (j != k)
        return -5; 
    } 
    b.a(this.X.bv.else(), this.X.bv.for(), arrayOfByte, i1 + 5, this.X.bv.new() + paramInt, 0, n - 5 << 3);
    this.X.bv.case();
    this.ao.cA = n;
    return n - 5 << 3;
  }
}
