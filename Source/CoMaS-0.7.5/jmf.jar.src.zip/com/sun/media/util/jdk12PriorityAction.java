package com.sun.media.util;

import java.lang.reflect.Constructor;
import java.security.PrivilegedAction;

public class jdk12PriorityAction implements PrivilegedAction {
  private Thread t;
  
  private int priority;
  
  public static Constructor cons;
  
  static {
    try {
      cons = jdk12PriorityAction.class.getConstructor(new Class[] { Thread.class, int.class });
    } catch (Throwable e) {}
  }
  
  public jdk12PriorityAction(Thread t, int priority) {
    this.t = t;
    this.priority = priority;
  }
  
  public Object run() {
    try {
      this.t.setPriority(this.priority);
      return null;
    } catch (Throwable t) {
      return null;
    } 
  }
}
