package com.sun.media.util;

import java.awt.Component;
import java.awt.Dimension;
import javax.media.Format;
import javax.media.format.UnsupportedFormatException;
import javax.media.format.VideoFormat;
import javax.media.renderer.VideoRenderer;

public class VideoCodecChain extends CodecChain {
  public VideoCodecChain(VideoFormat vf) throws UnsupportedFormatException {
    Dimension size = vf.getSize();
    VideoFormat inputFormat = vf;
    if (size == null || vf == null)
      throw new UnsupportedFormatException(vf); 
    if (!buildChain((Format)vf))
      throw new UnsupportedFormatException(vf); 
  }
  
  boolean isRawFormat(Format format) {
    return (format instanceof javax.media.format.RGBFormat || format instanceof javax.media.format.YUVFormat || (format.getEncoding() != null && (format.getEncoding().equalsIgnoreCase("jpeg") || format.getEncoding().equalsIgnoreCase("mpeg"))));
  }
  
  public Component getControlComponent() {
    if (this.renderer instanceof VideoRenderer)
      return ((VideoRenderer)this.renderer).getComponent(); 
    return null;
  }
}
