package com.sun.media;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import java.lang.reflect.Method;

public class IESecurity implements JMFSecurity {
  public static JMFSecurity security;
  
  public static boolean jview = false;
  
  private static Class cls = null;
  
  private static Method dummyMethodRef = null;
  
  public static final boolean DEBUG = false;
  
  static {
    security = new IESecurity();
    cls = security.getClass();
    try {
      dummyMethodRef = cls.getMethod("dummyMethod", new Class[0]);
    } catch (Exception e) {}
  }
  
  public String getName() {
    return "internetexplorer";
  }
  
  public static void dummyMethod() {}
  
  public void requestPermission(Method[] m, Class[] c, Object[][] args, int request) throws SecurityException {
    m[0] = dummyMethodRef;
    c[0] = cls;
    args[0] = null;
  }
  
  public void requestPermission(Method[] m, Class[] c, Object[][] args, int request, String parameter) throws SecurityException {
    requestPermission(m, c, args, request);
  }
  
  public boolean isLinkPermissionEnabled() {
    return jview;
  }
  
  public void permissionFailureNotification(int permission) {}
  
  public void loadLibrary(String name) throws UnsatisfiedLinkError {
    try {
      try {
        if (!jview)
          PolicyEngine.assertPermission(PermissionID.SYSTEM); 
      } catch (Throwable t) {}
      System.loadLibrary(name);
    } catch (Exception e) {
      throw new UnsatisfiedLinkError("Unable to get link privilege to " + name);
    } catch (Error e) {
      throw new UnsatisfiedLinkError("Unable to get link privilege to " + name);
    } 
  }
}
