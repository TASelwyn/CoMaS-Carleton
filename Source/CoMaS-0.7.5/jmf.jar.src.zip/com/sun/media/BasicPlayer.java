package com.sun.media;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import com.sun.media.controls.SliderRegionControl;
import com.sun.media.controls.SliderRegionControlAdapter;
import com.sun.media.ui.DefaultControlPanel;
import com.sun.media.util.JMFI18N;
import com.sun.media.util.jdk12;
import java.awt.Component;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Vector;
import javax.media.AudioDeviceUnavailableEvent;
import javax.media.CachingControl;
import javax.media.CachingControlEvent;
import javax.media.Clock;
import javax.media.ClockStartedError;
import javax.media.Control;
import javax.media.Controller;
import javax.media.ControllerClosedEvent;
import javax.media.ControllerErrorEvent;
import javax.media.ControllerEvent;
import javax.media.ControllerListener;
import javax.media.DownloadProgressListener;
import javax.media.Duration;
import javax.media.DurationUpdateEvent;
import javax.media.EndOfMediaEvent;
import javax.media.ExtendedCachingControl;
import javax.media.GainControl;
import javax.media.IncompatibleSourceException;
import javax.media.IncompatibleTimeBaseException;
import javax.media.MediaLocator;
import javax.media.NotPrefetchedError;
import javax.media.NotRealizedError;
import javax.media.Player;
import javax.media.Processor;
import javax.media.RestartingEvent;
import javax.media.SizeChangeEvent;
import javax.media.StartEvent;
import javax.media.StopAtTimeEvent;
import javax.media.StopByRequestEvent;
import javax.media.StopEvent;
import javax.media.StopTimeChangeEvent;
import javax.media.Time;
import javax.media.TimeBase;
import javax.media.control.BufferControl;
import javax.media.protocol.DataSource;
import javax.media.protocol.Positionable;
import javax.media.protocol.RateConfiguration;
import javax.media.protocol.RateConfigureable;
import javax.media.protocol.RateRange;

public abstract class BasicPlayer extends BasicController implements Player, ControllerListener, DownloadProgressListener {
  public static String VERSION = JMFI18N.getResource("mediaplayer.version");
  
  protected DataSource source = null;
  
  protected Vector controllerList = new Vector();
  
  private Vector optionalControllerList = new Vector();
  
  private Vector removedControllerList = new Vector();
  
  private Vector currentControllerList = new Vector();
  
  private Vector potentialEventsList = null;
  
  private Vector receivedEventList = new Vector();
  
  private boolean receivedAllEvents = false;
  
  private Vector configureEventList = new Vector();
  
  private Vector realizeEventList = new Vector();
  
  private Vector prefetchEventList = new Vector();
  
  private Vector stopEventList = new Vector();
  
  private ControllerEvent CachingControlEvent = null;
  
  private Controller restartFrom = null;
  
  private Vector eomEventsReceivedFrom = new Vector();
  
  private Vector stopAtTimeReceivedFrom = new Vector();
  
  private PlayThread playThread = null;
  
  private StatsThread statsThread = null;
  
  private Time duration = Duration.DURATION_UNKNOWN;
  
  private Time startTime;
  
  private Time mediaTimeAtStart;
  
  private boolean aboutToRestart = false;
  
  private boolean closing = false;
  
  private boolean prefetchFailed = false;
  
  protected boolean framePositioning = true;
  
  protected Control[] controls = null;
  
  protected Component controlComp = null;
  
  public SliderRegionControl regionControl = null;
  
  protected CachingControl cachingControl = null;
  
  protected ExtendedCachingControl extendedCachingControl = null;
  
  protected BufferControl bufferControl = null;
  
  private Object startSync = new Object();
  
  private Object mediaTimeSync = new Object();
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] m = new Method[1];
  
  private Class[] cl = new Class[1];
  
  private Object[][] args = new Object[1][0];
  
  long lastTime;
  
  static final int LOCAL_STOP = 0;
  
  static final int STOP_BY_REQUEST = 1;
  
  static final int RESTARTING = 2;
  
  static {
    try {
      jmfSecurity = JMFSecurityManager.getJMFSecurity();
      securityPrivelege = true;
    } catch (SecurityException e) {}
  }
  
  public boolean isFramePositionable() {
    return this.framePositioning;
  }
  
  protected boolean isConfigurable() {
    return false;
  }
  
  public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
    this.source = source;
    try {
      this.cachingControl = (CachingControl)source.getControl("javax.media.CachingControl");
      if (this.cachingControl != null && this.cachingControl instanceof ExtendedCachingControl) {
        this.extendedCachingControl = (ExtendedCachingControl)this.cachingControl;
        if (this.extendedCachingControl != null) {
          this.regionControl = (SliderRegionControl)new SliderRegionControlAdapter();
          this.extendedCachingControl.addDownloadProgressListener(this, 100);
        } 
      } 
    } catch (ClassCastException e) {}
  }
  
  public void downloadUpdate() {
    int i;
    if (this.extendedCachingControl == null)
      return; 
    sendEvent((ControllerEvent)new CachingControlEvent(this, this.cachingControl, this.cachingControl.getContentProgress()));
    if (this.regionControl == null)
      return; 
    long contentLength = this.cachingControl.getContentLength();
    if (contentLength == -1L || contentLength <= 0L) {
      i = 0;
    } else {
      long endOffset = this.extendedCachingControl.getEndOffset();
      i = (int)(100.0D * endOffset / contentLength);
      if (i < 0) {
        i = 0;
      } else if (i > 100) {
        i = 100;
      } 
    } 
    this.regionControl.setMinValue(0L);
    this.regionControl.setMaxValue(i);
  }
  
  public MediaLocator getMediaLocator() {
    if (this.source != null)
      return this.source.getLocator(); 
    return null;
  }
  
  public String getContentType() {
    if (this.source != null)
      return this.source.getContentType(); 
    return null;
  }
  
  protected DataSource getSource() {
    return this.source;
  }
  
  protected void doClose() {
    synchronized (this) {
      this.closing = true;
      notifyAll();
    } 
    if (getState() == 600)
      stop(0); 
    if (this.controllerList != null)
      while (!this.controllerList.isEmpty()) {
        Controller c = this.controllerList.firstElement();
        c.close();
        this.controllerList.removeElement(c);
      }  
    if (this.controlComp != null)
      ((DefaultControlPanel)this.controlComp).dispose(); 
    this.controlComp = null;
    if (this.statsThread != null)
      this.statsThread.kill(); 
    sendEvent((ControllerEvent)new ControllerClosedEvent(this));
  }
  
  public void setTimeBase(TimeBase tb) throws IncompatibleTimeBaseException {
    TimeBase oldTimeBase = getMasterTimeBase();
    if (tb == null)
      tb = oldTimeBase; 
    Controller c = null;
    if (this.controllerList != null)
      try {
        int i = this.controllerList.size();
        while (--i >= 0) {
          c = this.controllerList.elementAt(i);
          c.setTimeBase(tb);
        } 
      } catch (IncompatibleTimeBaseException e) {
        int i = this.controllerList.size();
        while (--i >= 0) {
          Controller cx = this.controllerList.elementAt(i);
          if (cx == c)
            break; 
          cx.setTimeBase(oldTimeBase);
        } 
        Log.dumpStack((Throwable)e);
        throw e;
      }  
    super.setTimeBase(tb);
  }
  
  protected void setMediaLength(long t) {
    this.duration = new Time(t);
    super.setMediaLength(t);
  }
  
  public BasicPlayer() {
    this.lastTime = 0L;
    this.configureEventList.addElement("javax.media.ConfigureCompleteEvent");
    this.configureEventList.addElement("javax.media.ResourceUnavailableEvent");
    this.realizeEventList.addElement("javax.media.RealizeCompleteEvent");
    this.realizeEventList.addElement("javax.media.ResourceUnavailableEvent");
    this.prefetchEventList.addElement("javax.media.PrefetchCompleteEvent");
    this.prefetchEventList.addElement("javax.media.ResourceUnavailableEvent");
    this.stopEventList.addElement("javax.media.StopEvent");
    this.stopEventList.addElement("javax.media.StopByRequestEvent");
    this.stopEventList.addElement("javax.media.StopAtTimeEvent");
    this.stopThreadEnabled = false;
  }
  
  public Time getDuration() {
    long t;
    if ((t = getMediaNanoseconds()) > this.lastTime) {
      this.lastTime = t;
      updateDuration();
    } 
    return this.duration;
  }
  
  protected synchronized void updateDuration() {
    Time oldDuration = this.duration;
    this.duration = Duration.DURATION_UNKNOWN;
    for (int i = 0; i < this.controllerList.size(); i++) {
      Controller c = this.controllerList.elementAt(i);
      Time dur = c.getDuration();
      if (dur.equals(Duration.DURATION_UNKNOWN)) {
        if (!(c instanceof BasicController)) {
          this.duration = Duration.DURATION_UNKNOWN;
          break;
        } 
      } else {
        if (dur.equals(Duration.DURATION_UNBOUNDED)) {
          this.duration = Duration.DURATION_UNBOUNDED;
          break;
        } 
        if (this.duration.equals(Duration.DURATION_UNKNOWN)) {
          this.duration = dur;
        } else if (this.duration.getNanoseconds() < dur.getNanoseconds()) {
          this.duration = dur;
        } 
      } 
    } 
    if (this.duration.getNanoseconds() != oldDuration.getNanoseconds()) {
      setMediaLength(this.duration.getNanoseconds());
      sendEvent((ControllerEvent)new DurationUpdateEvent(this, this.duration));
    } 
  }
  
  public Time getStartLatency() {
    super.getStartLatency();
    long t = 0L;
    for (int i = 0; i < this.controllerList.size(); i++) {
      Controller c = this.controllerList.elementAt(i);
      Time latency = c.getStartLatency();
      if (latency != Controller.LATENCY_UNKNOWN)
        if (latency.getNanoseconds() > t)
          t = latency.getNanoseconds();  
    } 
    if (t == 0L)
      return Controller.LATENCY_UNKNOWN; 
    return new Time(t);
  }
  
  protected void stopAtTime() {}
  
  protected void controllerStopAtTime() {
    super.stopAtTime();
  }
  
  public void setStopTime(Time t) {
    if (this.state < 300)
      throwError((Error)new NotRealizedError("Cannot set stop time on an unrealized controller.")); 
    if (getClock().getStopTime() == null || getClock().getStopTime().getNanoseconds() != t.getNanoseconds())
      sendEvent((ControllerEvent)new StopTimeChangeEvent(this, t)); 
    doSetStopTime(t);
  }
  
  private void doSetStopTime(Time t) {
    getClock().setStopTime(t);
    Vector list = this.controllerList;
    int i = list.size();
    while (--i >= 0) {
      Controller c = this.controllerList.elementAt(i);
      c.setStopTime(t);
    } 
  }
  
  protected void controllerSetStopTime(Time t) {
    super.setStopTime(t);
  }
  
  public final void setMediaTime(Time now) {
    if (this.state < 300)
      throwError((Error)new NotRealizedError(BasicController.MediaTimeError)); 
    synchronized (this.mediaTimeSync) {
      if (syncStartInProgress())
        return; 
      if (getState() == 600) {
        this.aboutToRestart = true;
        stop(2);
      } 
      if (this.source instanceof Positionable)
        now = ((Positionable)this.source).setPosition(now, 2); 
      super.setMediaTime(now);
      int i = this.controllerList.size();
      while (--i >= 0)
        ((Controller)this.controllerList.elementAt(i)).setMediaTime(now); 
      doSetMediaTime(now);
      if (this.aboutToRestart) {
        syncStart(getTimeBase().getTime());
        this.aboutToRestart = false;
      } 
    } 
  }
  
  public boolean isAboutToRestart() {
    return this.aboutToRestart;
  }
  
  protected void doSetMediaTime(Time now) {}
  
  public Component getVisualComponent() {
    int state = getState();
    if (state < 300)
      throwError((Error)new NotRealizedError("Cannot get visual component on an unrealized player")); 
    return null;
  }
  
  public Component getControlPanelComponent() {
    int state = getState();
    if (state < 300)
      throwError((Error)new NotRealizedError("Cannot get control panel component on an unrealized player")); 
    if (this.controlComp == null)
      this.controlComp = (Component)new DefaultControlPanel(this); 
    return this.controlComp;
  }
  
  public GainControl getGainControl() {
    int state = getState();
    if (state < 300) {
      throwError((Error)new NotRealizedError("Cannot get gain control on an unrealized player"));
    } else {
      return (GainControl)getControl("javax.media.GainControl");
    } 
    return null;
  }
  
  public Control[] getControls() {
    if (this.controls != null)
      return this.controls; 
    Vector cv = new Vector();
    if (this.cachingControl != null)
      cv.addElement(this.cachingControl); 
    if (this.bufferControl != null)
      cv.addElement(this.bufferControl); 
    int size = this.controllerList.size();
    int i;
    for (i = 0; i < size; i++) {
      Controller ctrller = this.controllerList.elementAt(i);
      Control[] arrayOfControl = ctrller.getControls();
      if (arrayOfControl != null)
        for (int j = 0; j < arrayOfControl.length; j++)
          cv.addElement(arrayOfControl[j]);  
    } 
    size = cv.size();
    Control[] ctrls = new Control[size];
    for (i = 0; i < size; i++)
      ctrls[i] = (Control)cv.elementAt(i); 
    if (getState() >= 300)
      this.controls = ctrls; 
    return ctrls;
  }
  
  public final void controllerUpdate(ControllerEvent evt) {
    processEvent(evt);
  }
  
  public final Vector getControllerList() {
    return this.controllerList;
  }
  
  private Vector getPotentialEventsList() {
    return this.potentialEventsList;
  }
  
  private void resetReceivedEventList() {
    if (this.receivedEventList != null)
      this.receivedEventList.removeAllElements(); 
  }
  
  private Vector getReceivedEventsList() {
    return this.receivedEventList;
  }
  
  private void updateReceivedEventsList(ControllerEvent event) {
    if (this.receivedEventList != null) {
      Controller source = event.getSourceController();
      if (this.receivedEventList.contains(source))
        return; 
      this.receivedEventList.addElement(source);
    } 
  }
  
  public final void start() {
    synchronized (this.startSync) {
      if (this.restartFrom != null)
        return; 
      if (getState() == 600) {
        sendEvent((ControllerEvent)new StartEvent(this, 600, 600, 600, this.mediaTimeAtStart, this.startTime));
        return;
      } 
      if (this.playThread == null || !this.playThread.isAlive()) {
        setTargetState(600);
        if (jmfSecurity != null) {
          String permission = null;
          try {
            if (jmfSecurity.getName().startsWith("jmf-security")) {
              permission = "thread";
              jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
              this.m[0].invoke(this.cl[0], this.args[0]);
              permission = "thread group";
              jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
              this.m[0].invoke(this.cl[0], this.args[0]);
            } else if (jmfSecurity.getName().startsWith("internet")) {
              PolicyEngine.checkPermission(PermissionID.THREAD);
              PolicyEngine.assertPermission(PermissionID.THREAD);
            } 
          } catch (Throwable e) {
            securityPrivelege = false;
          } 
        } 
        if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
          try {
            Constructor cons = CreateWorkThreadAction.cons;
            this.playThread = (PlayThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { PlayThread.class, BasicPlayer.class, this }) });
            this.playThread.start();
          } catch (Exception e) {}
        } else {
          this.playThread = new PlayThread(this);
          this.playThread.start();
        } 
      } 
    } 
  }
  
  public final void syncStart(Time tbt) {
    synchronized (this.mediaTimeSync) {
      if (syncStartInProgress())
        return; 
      int state = getState();
      if (state == 600)
        throwError((Error)new ClockStartedError("syncStart() cannot be used on an already started player")); 
      if (state != 500)
        throwError((Error)new NotPrefetchedError("Cannot start player before it has been prefetched")); 
      this.eomEventsReceivedFrom.removeAllElements();
      this.stopAtTimeReceivedFrom.removeAllElements();
      setTargetState(600);
      int i = this.controllerList.size();
      while (--i >= 0) {
        if (getTargetState() == 600)
          ((Controller)this.controllerList.elementAt(i)).syncStart(tbt); 
      } 
      if (getTargetState() == 600) {
        this.startTime = tbt;
        this.mediaTimeAtStart = getMediaTime();
        super.syncStart(tbt);
      } 
    } 
  }
  
  protected void doStart() {}
  
  final synchronized void play() {
    if (getTargetState() != 600)
      return; 
    this.prefetchFailed = false;
    int state = getState();
    if (state == 100 || state == 180 || state == 300)
      prefetch(); 
    while (!this.closing && !this.prefetchFailed && (getState() == 140 || getState() == 200 || getState() == 300 || getState() == 400)) {
      try {
        wait();
      } catch (InterruptedException e) {}
    } 
    if (getState() != 600 && getTargetState() == 600 && getState() == 500)
      syncStart(getTimeBase().getTime()); 
  }
  
  protected void doStop() {}
  
  public final void stop() {
    stop(1);
  }
  
  private void stop(int stopType) {
    int state;
    switch (state = getState()) {
      case 100:
      case 300:
      case 500:
        setTargetState(state);
        break;
      case 200:
        setTargetState(300);
        break;
      case 400:
      case 600:
        setTargetState(500);
        break;
    } 
    if (getState() != 600) {
      switch (stopType) {
        case 1:
          sendEvent((ControllerEvent)new StopByRequestEvent(this, getState(), getState(), getTargetState(), getMediaTime()));
          return;
        case 2:
          sendEvent((ControllerEvent)new RestartingEvent(this, getState(), getState(), 600, getMediaTime()));
          return;
      } 
      sendEvent((ControllerEvent)new StopEvent(this, getState(), getState(), getTargetState(), getMediaTime()));
    } else if (getState() == 600) {
      synchronized (this) {
        this.potentialEventsList = this.stopEventList;
        resetReceivedEventList();
        this.receivedAllEvents = false;
        this.currentControllerList.removeAllElements();
        int i = this.controllerList.size();
        while (--i >= 0) {
          Controller c = this.controllerList.elementAt(i);
          this.currentControllerList.addElement(c);
          c.stop();
        } 
        if (this.currentControllerList == null)
          return; 
        if (!this.currentControllerList.isEmpty()) {
          try {
            while (!this.closing && !this.receivedAllEvents)
              wait(); 
          } catch (InterruptedException e) {}
          this.currentControllerList.removeAllElements();
        } 
        super.stop();
        switch (stopType) {
          case 1:
            sendEvent((ControllerEvent)new StopByRequestEvent(this, 600, getState(), getTargetState(), getMediaTime()));
            break;
          case 2:
            sendEvent((ControllerEvent)new RestartingEvent(this, 600, getState(), 600, getMediaTime()));
            break;
          default:
            sendEvent((ControllerEvent)new StopEvent(this, 600, getState(), getTargetState(), getMediaTime()));
            break;
        } 
      } 
    } 
  }
  
  protected final void processEndOfMedia() {
    super.stop();
    sendEvent((ControllerEvent)new EndOfMediaEvent(this, 600, 500, getTargetState(), getMediaTime()));
  }
  
  protected final void manageController(Controller controller) {
    manageController(controller, false);
  }
  
  protected final void manageController(Controller controller, boolean optional) {
    if (controller != null && 
      !this.controllerList.contains(controller)) {
      this.controllerList.addElement(controller);
      if (optional)
        this.optionalControllerList.addElement(controller); 
      controller.addControllerListener(this);
    } 
    updateDuration();
  }
  
  public final void unmanageController(Controller controller) {
    if (controller != null && 
      this.controllerList.contains(controller)) {
      this.controllerList.removeElement(controller);
      controller.removeControllerListener(this);
    } 
  }
  
  public synchronized void addController(Controller newController) throws IncompatibleTimeBaseException {
    int playerState = getState();
    if (playerState == 600)
      throwError((Error)new ClockStartedError("Cannot add controller to a started player")); 
    if (playerState == 100 || playerState == 200)
      throwError((Error)new NotRealizedError("A Controller cannot be added to an Unrealized Player")); 
    if (newController == null || newController == this)
      return; 
    int controllerState = newController.getState();
    if (controllerState == 100 || controllerState == 200)
      throwError((Error)new NotRealizedError("An Unrealized Controller cannot be added to a Player")); 
    if (this.controllerList.contains(newController))
      return; 
    if (playerState == 500 && (
      controllerState == 300 || controllerState == 400))
      deallocate(); 
    manageController(newController);
    newController.setTimeBase(getTimeBase());
    newController.setMediaTime(getMediaTime());
    newController.setStopTime(getStopTime());
    if (newController.setRate(getRate()) != getRate())
      setRate(1.0F); 
  }
  
  public final synchronized void removeController(Controller oldController) {
    int state = getState();
    if (state < 300)
      throwError((Error)new NotRealizedError("Cannot remove controller from a unrealized player")); 
    if (state == 600)
      throwError((Error)new ClockStartedError("Cannot remove controller from a started player")); 
    if (oldController == null)
      return; 
    if (this.controllerList.contains(oldController)) {
      this.controllerList.removeElement(oldController);
      oldController.removeControllerListener(this);
      updateDuration();
      try {
        oldController.setTimeBase(null);
      } catch (IncompatibleTimeBaseException e) {}
    } 
  }
  
  protected synchronized boolean doConfigure() {
    this.potentialEventsList = this.configureEventList;
    resetReceivedEventList();
    this.receivedAllEvents = false;
    this.currentControllerList.removeAllElements();
    int i = this.controllerList.size();
    while (--i >= 0) {
      Controller c = this.controllerList.elementAt(i);
      if (c.getState() == 100 && (c instanceof Processor || c instanceof BasicController))
        this.currentControllerList.addElement(c); 
    } 
    i = this.currentControllerList.size();
    while (--i >= 0) {
      Controller c = this.currentControllerList.elementAt(i);
      if (c instanceof Processor) {
        ((Processor)c).configure();
        continue;
      } 
      if (c instanceof BasicController)
        ((BasicController)c).configure(); 
    } 
    if (!this.currentControllerList.isEmpty()) {
      try {
        while (!this.closing && !this.receivedAllEvents)
          wait(); 
      } catch (InterruptedException e) {}
      this.currentControllerList.removeAllElements();
    } 
    i = this.controllerList.size();
    while (--i >= 0) {
      Controller c = this.controllerList.elementAt(i);
      if ((c instanceof Processor || c instanceof BasicController) && c.getState() < 180) {
        Log.error("Error: Unable to configure " + c);
        this.source.disconnect();
        return false;
      } 
    } 
    return true;
  }
  
  protected void completeConfigure() {
    super.completeConfigure();
    synchronized (this) {
      notify();
    } 
  }
  
  protected void doFailedConfigure() {
    super.doFailedConfigure();
    synchronized (this) {
      notify();
    } 
    close();
  }
  
  protected synchronized boolean doRealize() {
    this.potentialEventsList = this.realizeEventList;
    resetReceivedEventList();
    this.receivedAllEvents = false;
    this.currentControllerList.removeAllElements();
    int i = this.controllerList.size();
    while (--i >= 0) {
      Controller c = this.controllerList.elementAt(i);
      if (c.getState() == 100 || c.getState() == 180)
        this.currentControllerList.addElement(c); 
    } 
    i = this.currentControllerList.size();
    while (--i >= 0) {
      Controller c = this.currentControllerList.elementAt(i);
      c.realize();
    } 
    if (!this.currentControllerList.isEmpty()) {
      try {
        while (!this.closing && !this.receivedAllEvents)
          wait(); 
      } catch (InterruptedException e) {}
      this.currentControllerList.removeAllElements();
    } 
    i = this.controllerList.size();
    while (--i >= 0) {
      Controller c = this.controllerList.elementAt(i);
      if (c.getState() < 300) {
        Log.error("Error: Unable to realize " + c);
        this.source.disconnect();
        return false;
      } 
    } 
    updateDuration();
    if (jmfSecurity != null) {
      String permission = null;
      try {
        if (jmfSecurity.getName().startsWith("jmf-security")) {
          permission = "thread";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
          this.m[0].invoke(this.cl[0], this.args[0]);
          permission = "thread group";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
          this.m[0].invoke(this.cl[0], this.args[0]);
        } else if (jmfSecurity.getName().startsWith("internet")) {
          PolicyEngine.checkPermission(PermissionID.THREAD);
          PolicyEngine.assertPermission(PermissionID.THREAD);
        } 
      } catch (Exception e) {
        securityPrivelege = false;
      } 
    } 
    if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
      try {
        Constructor cons = CreateWorkThreadAction.cons;
        this.statsThread = (StatsThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { StatsThread.class, BasicPlayer.class, this }) });
        this.statsThread.start();
      } catch (Exception e) {}
    } else {
      this.statsThread = new StatsThread(this);
      this.statsThread.start();
    } 
    return true;
  }
  
  protected void completeRealize() {
    this.state = 300;
    try {
      slaveToMasterTimeBase(getMasterTimeBase());
    } catch (IncompatibleTimeBaseException e) {
      Log.error(e);
    } 
    super.completeRealize();
    synchronized (this) {
      notify();
    } 
  }
  
  protected void doFailedRealize() {
    super.doFailedRealize();
    synchronized (this) {
      notify();
    } 
    close();
  }
  
  protected void completePrefetch() {
    super.completePrefetch();
    synchronized (this) {
      notify();
    } 
  }
  
  protected void doFailedPrefetch() {
    super.doFailedPrefetch();
    synchronized (this) {
      notify();
    } 
  }
  
  protected final void abortRealize() {
    if (this.controllerList != null) {
      int i = this.controllerList.size();
      while (--i >= 0) {
        Controller c = this.controllerList.elementAt(i);
        c.deallocate();
      } 
    } 
    synchronized (this) {
      notify();
    } 
  }
  
  protected boolean doPrefetch() {
    this.potentialEventsList = this.prefetchEventList;
    resetReceivedEventList();
    this.receivedAllEvents = false;
    this.currentControllerList.removeAllElements();
    Vector list = this.controllerList;
    if (list == null)
      return false; 
    int i = list.size();
    while (--i >= 0) {
      Controller c = list.elementAt(i);
      if (c.getState() == 300) {
        this.currentControllerList.addElement(c);
        c.prefetch();
      } 
    } 
    if (!this.currentControllerList.isEmpty())
      synchronized (this) {
        try {
          while (!this.closing && !this.receivedAllEvents)
            wait(); 
        } catch (InterruptedException e) {}
        this.currentControllerList.removeAllElements();
      }  
    i = list.size();
    while (--i >= 0) {
      Controller c = list.elementAt(i);
      if (c.getState() < 500) {
        Log.error("Error: Unable to prefetch " + c + "\n");
        if (this.optionalControllerList.contains(c)) {
          this.removedControllerList.addElement(c);
          continue;
        } 
        synchronized (this) {
          this.prefetchFailed = true;
          notifyAll();
        } 
        return false;
      } 
    } 
    if (this.removedControllerList != null) {
      i = this.removedControllerList.size();
      while (--i >= 0) {
        Object o = this.removedControllerList.elementAt(i);
        this.controllerList.removeElement(o);
        ((BasicController)o).close();
        if (!deviceBusy((BasicController)o)) {
          synchronized (this) {
            this.prefetchFailed = true;
            notifyAll();
          } 
          return false;
        } 
      } 
      this.removedControllerList.removeAllElements();
    } 
    return true;
  }
  
  protected final void abortPrefetch() {
    if (this.controllerList != null) {
      int i = this.controllerList.size();
      while (--i >= 0) {
        Controller c = this.controllerList.elementAt(i);
        c.deallocate();
      } 
    } 
    synchronized (this) {
      notify();
    } 
  }
  
  protected boolean deviceBusy(BasicController mc) {
    return true;
  }
  
  protected void slaveToMasterTimeBase(TimeBase tb) throws IncompatibleTimeBaseException {
    setTimeBase(tb);
  }
  
  private void notifyIfAllEventsArrived(Vector controllerList, Vector receivedEventList) {
    if (receivedEventList != null && receivedEventList.size() == this.currentControllerList.size()) {
      this.receivedAllEvents = true;
      resetReceivedEventList();
      synchronized (this) {
        notifyAll();
      } 
    } 
  }
  
  protected void processEvent(ControllerEvent evt) {
    Controller source = evt.getSourceController();
    if (evt instanceof AudioDeviceUnavailableEvent) {
      sendEvent((ControllerEvent)new AudioDeviceUnavailableEvent(this));
      return;
    } 
    if (evt instanceof ControllerClosedEvent && !this.closing && this.controllerList.contains(source) && !(evt instanceof javax.media.ResourceUnavailableEvent)) {
      this.controllerList.removeElement(source);
      if (evt instanceof ControllerErrorEvent)
        sendEvent((ControllerEvent)new ControllerErrorEvent(this, ((ControllerErrorEvent)evt).getMessage())); 
      close();
    } 
    if (evt instanceof SizeChangeEvent && this.controllerList.contains(source)) {
      sendEvent((ControllerEvent)new SizeChangeEvent(this, ((SizeChangeEvent)evt).getWidth(), ((SizeChangeEvent)evt).getHeight(), ((SizeChangeEvent)evt).getScale()));
      return;
    } 
    if (evt instanceof DurationUpdateEvent && this.controllerList.contains(source)) {
      updateDuration();
      return;
    } 
    if (evt instanceof RestartingEvent && this.controllerList.contains(source)) {
      this.restartFrom = source;
      int i = this.controllerList.size();
      super.stop();
      setTargetState(500);
      for (int ii = 0; ii < i; ii++) {
        Controller c = this.controllerList.elementAt(ii);
        if (c != source)
          c.stop(); 
      } 
      super.stop();
      sendEvent((ControllerEvent)new RestartingEvent(this, 600, 400, 600, getMediaTime()));
    } 
    if (evt instanceof StartEvent && source == this.restartFrom) {
      this.restartFrom = null;
      start();
    } 
    if (evt instanceof SeekFailedEvent && this.controllerList.contains(source)) {
      int i = this.controllerList.size();
      super.stop();
      setTargetState(500);
      for (int ii = 0; ii < i; ii++) {
        Controller c = this.controllerList.elementAt(ii);
        if (c != source)
          c.stop(); 
      } 
      sendEvent((ControllerEvent)new SeekFailedEvent(this, 600, 500, 500, getMediaTime()));
    } 
    if (evt instanceof EndOfMediaEvent && this.controllerList.contains(source)) {
      if (this.eomEventsReceivedFrom.contains(source))
        return; 
      this.eomEventsReceivedFrom.addElement(source);
      if (this.eomEventsReceivedFrom.size() == this.controllerList.size()) {
        super.stop();
        sendEvent((ControllerEvent)new EndOfMediaEvent(this, 600, 500, getTargetState(), getMediaTime()));
      } 
      return;
    } 
    if (evt instanceof StopAtTimeEvent && this.controllerList.contains(source) && getState() == 600)
      synchronized (this.stopAtTimeReceivedFrom) {
        if (this.stopAtTimeReceivedFrom.contains(source))
          return; 
        this.stopAtTimeReceivedFrom.addElement(source);
        boolean allStopped = (this.stopAtTimeReceivedFrom.size() == this.controllerList.size());
        if (!allStopped) {
          allStopped = true;
          for (int i = 0; i < this.controllerList.size(); i++) {
            Controller c = this.controllerList.elementAt(i);
            if (!this.stopAtTimeReceivedFrom.contains(c) && !this.eomEventsReceivedFrom.contains(c)) {
              allStopped = false;
              break;
            } 
          } 
        } 
        if (allStopped) {
          super.stop();
          doSetStopTime(Clock.RESET);
          sendEvent((ControllerEvent)new StopAtTimeEvent(this, 600, 500, getTargetState(), getMediaTime()));
        } 
        return;
      }  
    if (evt instanceof CachingControlEvent && this.controllerList.contains(source)) {
      CachingControl mcc = ((CachingControlEvent)evt).getCachingControl();
      sendEvent((ControllerEvent)new CachingControlEvent(this, mcc, mcc.getContentProgress()));
      return;
    } 
    Vector eventList = this.potentialEventsList;
    if (this.controllerList != null && this.controllerList.contains(source) && eventList != null && eventList.contains(evt.getClass().getName())) {
      updateReceivedEventsList(evt);
      notifyIfAllEventsArrived(this.controllerList, getReceivedEventsList());
    } 
  }
  
  private boolean trySetRate(float rate) {
    int i = this.controllerList.size();
    while (--i >= 0) {
      Controller c = this.controllerList.elementAt(i);
      if (c.setRate(rate) != rate)
        return false; 
    } 
    return true;
  }
  
  protected float doSetRate(float factor) {
    return factor;
  }
  
  public float setRate(float rate) {
    float f1;
    if (this.state < 300)
      throwError((Error)new NotRealizedError("Cannot set rate on an unrealized Player.")); 
    if (this.source instanceof RateConfigureable)
      rate = checkRateConfig((RateConfigureable)this.source, rate); 
    float oldRate = getRate();
    if (oldRate == rate)
      return rate; 
    if (getState() == 600) {
      this.aboutToRestart = true;
      stop(2);
    } 
    if (!trySetRate(rate)) {
      if (!trySetRate(oldRate)) {
        trySetRate(1.0F);
        f1 = 1.0F;
      } else {
        f1 = oldRate;
      } 
    } else {
      f1 = rate;
    } 
    super.setRate(f1);
    if (this.aboutToRestart) {
      syncStart(getTimeBase().getTime());
      this.aboutToRestart = false;
    } 
    return f1;
  }
  
  float checkRateConfig(RateConfigureable rc, float rate) {
    RateConfiguration[] config = rc.getRateConfigurations();
    if (config == null)
      return 1.0F; 
    float corrected = 1.0F;
    for (int i = 0; i < config.length; i++) {
      RateRange rr = config[i].getRate();
      if (rr != null && rr.inRange(rate)) {
        rr.setCurrentRate(rate);
        corrected = rate;
        RateConfiguration c = rc.setRateConfiguration(config[i]);
        if (c != null && (rr = c.getRate()) != null)
          corrected = rr.getCurrentRate(); 
        break;
      } 
    } 
    return corrected;
  }
  
  protected abstract boolean audioEnabled();
  
  protected abstract boolean videoEnabled();
  
  protected abstract TimeBase getMasterTimeBase();
  
  public abstract void updateStats();
}
