package com.sun.media.protocol.avi;

import com.sun.media.parser.video.AviParser;
import com.sun.media.protocol.BasicSourceStream;
import java.io.IOException;
import javax.media.BadHeaderException;
import javax.media.Buffer;
import javax.media.Duration;
import javax.media.Format;
import javax.media.IncompatibleSourceException;
import javax.media.MediaLocator;
import javax.media.Time;
import javax.media.Track;
import javax.media.protocol.BufferTransferHandler;
import javax.media.protocol.PushBufferDataSource;
import javax.media.protocol.PushBufferStream;

public class DataSource extends PushBufferDataSource {
  private String fileName;
  
  private javax.media.protocol.DataSource inputDataSource;
  
  private AviParser aviParser;
  
  private Track[] tracks;
  
  private Format[] formats;
  
  private int numTracks;
  
  private String contentType = "raw";
  
  private boolean connected = false;
  
  private PushBufferStream[] streams = new PushBufferStream[0];
  
  public void doConnect(String fileName) throws IOException {
    try {
      this.fileName = fileName;
      this.inputDataSource = (javax.media.protocol.DataSource)new FileDataSource(fileName);
      this.inputDataSource.connect();
      this.aviParser = new AviParser();
      this.aviParser.setSource(this.inputDataSource);
      try {
        this.tracks = this.aviParser.getTracks();
      } catch (BadHeaderException e) {
        throw new IOException("");
      } 
      if (this.tracks == null || this.tracks.length <= 0)
        throw new IOException("Unable to get the tracks"); 
      for (int i = 0; i < this.tracks.length; i++)
        System.out.println(this.tracks[i].getFormat().getEncoding()); 
      this.numTracks = this.tracks.length;
      this.formats = new Format[this.numTracks];
      for (int j = 0; j < this.numTracks; j++) {
        System.out.println(this.tracks[j]);
        this.formats[j] = this.tracks[j].getFormat();
        this.tracks[j].setEnabled(true);
      } 
    } catch (IncompatibleSourceException e) {
      throw new IOException(e.getMessage());
    } 
  }
  
  public void connect() throws IOException {
    if (this.connected)
      return; 
    MediaLocator locator = getLocator();
    if (locator == null) {
      System.err.println("medialocator is null");
      throw new IOException(this + ": connect() failed");
    } 
    String fileName = locator.getRemainder();
    doConnect(fileName);
    this.streams = new PushBufferStream[this.numTracks];
    for (int i = 0; i < this.numTracks; i++)
      this.streams[i] = new AviSourceStream(this, this.tracks[i]); 
    System.out.println("connected");
    this.connected = true;
  }
  
  public void disconnect() {}
  
  public void start() throws IOException {
    for (int i = 0; i < this.numTracks; i++) {
      if (this.streams[i] != null)
        ((AviSourceStream)this.streams[i]).start(); 
    } 
  }
  
  public void stop() throws IOException {}
  
  public String getContentType() {
    if (!this.connected)
      return null; 
    System.out.println("avids: getContentType returns " + this.contentType);
    return this.contentType;
  }
  
  public PushBufferStream[] getStreams() {
    if (!this.connected)
      return null; 
    return this.streams;
  }
  
  public Object[] getControls() {
    return new Object[0];
  }
  
  public Object getControl(String controlType) {
    return null;
  }
  
  public Time getDuration() {
    return Duration.DURATION_UNKNOWN;
  }
  
  class AviSourceStream extends BasicSourceStream implements PushBufferStream, Runnable {
    private BufferTransferHandler transferHandler;
    
    private boolean started;
    
    private Buffer buffer;
    
    private Format format;
    
    private Track track;
    
    private final DataSource this$0;
    
    AviSourceStream(DataSource this$0, Track track) {
      this.this$0 = this$0;
      this.transferHandler = null;
      this.started = false;
      this.buffer = new Buffer();
      this.track = track;
      this.buffer.setData(null);
      this.format = track.getFormat();
    }
    
    public Format getFormat() {
      return this.format;
    }
    
    public void setTransferHandler(BufferTransferHandler th) {
      System.out.println("setTransferHandler: " + th);
      this.transferHandler = th;
    }
    
    public void connect() throws IOException {}
    
    void disconnect() {}
    
    void start() throws IOException {
      if (this.started)
        return; 
      if (this.transferHandler != null) {
        (new Thread(this)).start();
        this.started = true;
      } 
    }
    
    void stop() throws IOException {
      this.started = false;
    }
    
    public synchronized void read(Buffer b) {
      if (this.buffer.getLength() > 0) {
        b.setOffset(this.buffer.getOffset());
        b.setData(this.buffer.getData());
        b.setLength(this.buffer.getLength());
        b.setTimeStamp(this.buffer.getTimeStamp());
        b.setFormat(this.format);
      } else {
        b.setLength(this.buffer.getLength());
      } 
    }
    
    public void run() {
      while (true) {
        this.track.readFrame(this.buffer);
        synchronized (this) {
          if (this.transferHandler != null)
            this.transferHandler.transferData(this); 
        } 
        Thread.currentThread();
        Thread.yield();
      } 
    }
  }
}
