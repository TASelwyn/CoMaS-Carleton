package com.sun.media.protocol;

public interface Streamable {
  boolean isPrefetchable();
}
