package com.sun.media.sdp;

public class MediaAttribute {
  private String name;
  
  private String value;
  
  public MediaAttribute(String name, String value) {
    this.name = name;
    this.value = value;
  }
  
  public String getName() {
    return this.name;
  }
  
  public String getValue() {
    return this.value;
  }
}
