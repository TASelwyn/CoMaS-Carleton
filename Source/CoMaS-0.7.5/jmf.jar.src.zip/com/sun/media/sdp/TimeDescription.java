package com.sun.media.sdp;

import java.io.ByteArrayInputStream;
import java.util.Vector;

public class TimeDescription extends Parser {
  public String timeActive;
  
  public Vector repeatTimes;
  
  public TimeDescription(ByteArrayInputStream bin) {
    this.timeActive = getLine(bin);
    this.repeatTimes = new Vector();
    boolean found = getToken(bin, "r=", false);
    while (found) {
      String repeatTime = getLine(bin);
      this.repeatTimes.addElement(repeatTime);
      found = getToken(bin, "r=", false);
    } 
  }
}
