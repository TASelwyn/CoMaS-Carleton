package com.sun.media.parser.video;

import com.sun.media.format.WavAudioFormat;
import com.sun.media.parser.BasicPullParser;
import com.sun.media.vfw.BitMapInfo;
import java.io.IOException;
import javax.media.BadHeaderException;
import javax.media.Buffer;
import javax.media.Duration;
import javax.media.Format;
import javax.media.IncompatibleSourceException;
import javax.media.Time;
import javax.media.Track;
import javax.media.TrackListener;
import javax.media.format.AudioFormat;
import javax.media.format.VideoFormat;
import javax.media.protocol.CachedStream;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.DataSource;
import javax.media.protocol.PullSourceStream;
import javax.media.protocol.Seekable;
import javax.media.protocol.SourceStream;

public class AviParser extends BasicPullParser {
  private static ContentDescriptor[] supportedFormat = new ContentDescriptor[] { new ContentDescriptor("video.x_msvideo") };
  
  private PullSourceStream stream = null;
  
  private CachedStream cacheStream;
  
  private Track[] tracks;
  
  private Seekable seekableStream;
  
  private int numSupportedTracks = 0;
  
  private int length;
  
  private int audioTrack = -1;
  
  private int videoTrack = -1;
  
  private int keyFrameTrack = -1;
  
  private static final int SIZE_OF_AVI_INDEX = 16;
  
  private static final int AVIH_HEADER_LENGTH = 56;
  
  private static final int STRH_HEADER_LENGTH = 56;
  
  private static final int STRF_VIDEO_HEADER_LENGTH = 40;
  
  private static final int STRF_AUDIO_HEADER_LENGTH = 16;
  
  static final int AVIF_HASINDEX = 16;
  
  static final int AVIF_MUSTUSEINDEX = 32;
  
  static final int AVIF_ISINTERLEAVED = 256;
  
  static final int AVIF_WASCAPTUREFILE = 65536;
  
  static final int AVIF_COPYRIGHTED = 131072;
  
  static final int AVIF_KEYFRAME = 16;
  
  static final String AUDIO = "auds";
  
  static final String VIDEO = "vids";
  
  static final String LISTRECORDCHUNK = "rec ";
  
  static final String VIDEO_MAGIC = "dc";
  
  static final String VIDEO_MAGIC_JPEG = "db";
  
  static final String VIDEO_MAGIC_IV32a = "iv";
  
  static final String VIDEO_MAGIC_IV32b = "32";
  
  static final String VIDEO_MAGIC_IV31 = "31";
  
  static final String VIDEO_MAGIC_CVID = "id";
  
  static final String AUDIO_MAGIC = "wb";
  
  private int usecPerFrame = 0;
  
  private long nanoSecPerFrame = 0L;
  
  private int maxBytesPerSecond;
  
  private int paddingGranularity;
  
  private int flags;
  
  private int totalFrames = 0;
  
  private int initialFrames;
  
  private int numTracks = 0;
  
  private int suggestedBufferSize;
  
  private int width;
  
  private int height;
  
  private TrakList[] trakList;
  
  private int idx1MinimumChunkOffset;
  
  private int moviOffset = 0;
  
  private Time duration = Duration.DURATION_UNKNOWN;
  
  private boolean moviChunkSeen = false;
  
  private boolean idx1ChunkSeen = false;
  
  private int maxAudioChunkIndex = 0;
  
  private int maxVideoChunkIndex = 0;
  
  private int extraHeaderLength = 0;
  
  private byte[] codecSpecificHeader = null;
  
  private Object seekSync = new Object();
  
  protected boolean supports(SourceStream[] streams) {
    return this.seekable;
  }
  
  public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
    super.setSource(source);
    this.stream = (PullSourceStream)this.streams[0];
    this.seekableStream = (Seekable)this.streams[0];
  }
  
  public ContentDescriptor[] getSupportedInputContentDescriptors() {
    return supportedFormat;
  }
  
  public Track[] getTracks() throws IOException, BadHeaderException {
    if (this.tracks != null)
      return this.tracks; 
    if (this.seekableStream == null)
      return new Track[0]; 
    readHeader();
    if (!this.moviChunkSeen)
      throw new BadHeaderException("No movi chunk"); 
    if (!this.idx1ChunkSeen)
      throw new BadHeaderException("Currently files with no idx1 chunk are not supported"); 
    if (this.numTracks <= 0)
      throw new BadHeaderException("Error parsing header"); 
    this.tracks = new Track[this.numTracks];
    for (int i = 0; i < this.tracks.length; i++) {
      TrakList trakInfo = this.trakList[i];
      if (trakInfo.trackType.equals("auds")) {
        this.tracks[i] = new AudioTrack(this, trakInfo);
      } else if (trakInfo.trackType.equals("vids")) {
        this.tracks[i] = new VideoTrack(this, trakInfo);
      } 
    } 
    return this.tracks;
  }
  
  private void readHeader() throws IOException, BadHeaderException {
    String magicRIFF = readString(this.stream);
    if (!magicRIFF.equals("RIFF"))
      throw new BadHeaderException("AVI Parser: expected string RIFF, got " + magicRIFF); 
    this.length = readInt(this.stream, false);
    this.length += 8;
    String magicAVI = readString(this.stream);
    if (!magicAVI.equals("AVI "))
      throw new BadHeaderException("AVI Parser: expected string AVI, got " + magicAVI); 
    int currentTrack = 0;
    while (getLocation(this.stream) <= (this.length - 12)) {
      String next = readString(this.stream);
      int subchunkLength = readInt(this.stream, false);
      if (next.equals("LIST")) {
        String subchunk = readString(this.stream);
        if (subchunk.equals("hdrl")) {
          parseHDRL();
          continue;
        } 
        if (subchunk.equals("strl")) {
          parseSTRL(subchunkLength, currentTrack);
          currentTrack++;
          continue;
        } 
        if (subchunk.equals("movi")) {
          parseMOVI(subchunkLength - 4);
          continue;
        } 
        skip(this.stream, subchunkLength - 4);
        continue;
      } 
      if (next.equals("idx1")) {
        parseIDX1(subchunkLength);
        continue;
      } 
      skip(this.stream, subchunkLength);
      if ((subchunkLength & 0x1) > 0)
        skip(this.stream, 1); 
    } 
    if (this.totalFrames != 0 && this.usecPerFrame != 0)
      this.duration = new Time(this.usecPerFrame * this.totalFrames * 1000L); 
  }
  
  private long getLocation() {
    return getLocation(this.stream);
  }
  
  private void parseHDRL() throws BadHeaderException {
    try {
      String next = readString(this.stream);
      if (!next.equals("avih"))
        throw new BadHeaderException("AVI Parser: expected string AVIH, got " + next); 
      int headerLength = readInt(this.stream, false);
      parseAVIH(headerLength);
      this.trakList = new TrakList[this.numTracks];
    } catch (IOException e) {
      throw new BadHeaderException("IOException when parsing hdrl");
    } 
  }
  
  private void parseSTRL(int length, int currentTrack) throws BadHeaderException {
    try {
      if (currentTrack >= this.trakList.length)
        throw new BadHeaderException("inconsistent number of strl atoms"); 
      length -= 12;
      while (length >= 12) {
        String subchunkid = readString(this.stream);
        int subchunkLength = readInt(this.stream, false);
        if (subchunkid.equals("strh")) {
          parseSTRH(subchunkLength, currentTrack);
        } else if (subchunkid.equals("strf")) {
          if (this.trakList[currentTrack] == null)
            throw new BadHeaderException("strf doesn't have a strh atom preceding it"); 
          parseSTRF(subchunkLength, currentTrack);
        } else {
          if ((subchunkLength & 0x1) > 0)
            subchunkLength++; 
          skip(this.stream, subchunkLength);
        } 
        length -= subchunkLength + 4;
      } 
    } catch (IOException e) {
      throw new BadHeaderException("IOException when parsing hdrl");
    } 
  }
  
  private void parseSTRH(int length, int currentTrack) throws BadHeaderException {
    try {
      if (length < 56)
        throw new BadHeaderException("strh: header length should be atleast 56 but is " + length); 
      this.trakList[currentTrack] = new TrakList();
      (this.trakList[currentTrack]).trackType = readString(this.stream);
      (this.trakList[currentTrack]).streamHandler = readString(this.stream);
      (this.trakList[currentTrack]).flags = readInt(this.stream, false);
      (this.trakList[currentTrack]).priority = readInt(this.stream, false);
      (this.trakList[currentTrack]).initialFrames = readInt(this.stream, false);
      (this.trakList[currentTrack]).scale = readInt(this.stream, false);
      (this.trakList[currentTrack]).rate = readInt(this.stream, false);
      (this.trakList[currentTrack]).start = readInt(this.stream, false);
      (this.trakList[currentTrack]).length = readInt(this.stream, false);
      (this.trakList[currentTrack]).suggestedBufferSize = readInt(this.stream, false);
      (this.trakList[currentTrack]).quality = readInt(this.stream, false);
      (this.trakList[currentTrack]).sampleSize = readInt(this.stream, false);
      skip(this.stream, 8);
      if (length - 56 > 0)
        skip(this.stream, length - 56); 
    } catch (IOException e) {
      throw new BadHeaderException("IOException when parsing hdrl");
    } 
  }
  
  private void parseSTRF(int length, int currentTrack) throws BadHeaderException {
    try {
      String trackType = (this.trakList[currentTrack]).trackType;
      if (trackType.equals("vids")) {
        Video video = new Video();
        video.size = readInt(this.stream, false);
        video.width = readInt(this.stream, false);
        video.height = readInt(this.stream, false);
        video.planes = readShort(this.stream, false);
        video.depth = readShort(this.stream, false);
        byte[] intArray = new byte[4];
        readBytes(this.stream, intArray, 4);
        if (intArray[0] > 32) {
          video.compressor = new String(intArray);
        } else {
          switch (intArray[0]) {
            case 0:
              video.compressor = "rgb";
              break;
            case 1:
              video.compressor = "rle8";
              break;
            case 2:
              video.compressor = "rle4";
              break;
            case 3:
              video.compressor = "rgb";
              break;
          } 
        } 
        BitMapInfo bmi = new BitMapInfo();
        bmi.biWidth = video.width;
        bmi.biHeight = video.height;
        bmi.biPlanes = video.planes;
        bmi.biBitCount = video.depth;
        bmi.fourcc = new String(video.compressor);
        video.bitMapInfo = bmi;
        bmi.biSizeImage = readInt(this.stream, false);
        bmi.biXPelsPerMeter = readInt(this.stream, false);
        bmi.biYPelsPerMeter = readInt(this.stream, false);
        bmi.biClrUsed = readInt(this.stream, false);
        bmi.biClrImportant = readInt(this.stream, false);
        if (length - 40 > 0) {
          bmi.extraSize = length - 40;
          bmi.extraBytes = new byte[bmi.extraSize];
          readBytes(this.stream, bmi.extraBytes, bmi.extraSize);
        } 
        (this.trakList[currentTrack]).media = video;
        (this.trakList[currentTrack]).media.maxSampleSize = (this.trakList[currentTrack]).suggestedBufferSize;
        this.videoTrack = currentTrack;
      } else if (trackType.equals("auds")) {
        Audio audio = new Audio();
        audio.formatTag = readShort(this.stream, false);
        audio.channels = readShort(this.stream, false);
        audio.sampleRate = readInt(this.stream, false);
        audio.avgBytesPerSec = readInt(this.stream, false);
        audio.blockAlign = readShort(this.stream, false);
        audio.bitsPerSample = readShort(this.stream, false);
        int remainingFormatSize = length - 16;
        this.codecSpecificHeader = null;
        int extraFieldsSize = 0;
        if (remainingFormatSize >= 2) {
          extraFieldsSize = readShort(this.stream, false);
          remainingFormatSize -= 2;
          if (extraFieldsSize > 0) {
            this.codecSpecificHeader = new byte[extraFieldsSize];
            readBytes(this.stream, this.codecSpecificHeader, this.codecSpecificHeader.length);
            remainingFormatSize -= extraFieldsSize;
          } 
          if (audio.formatTag == 2 || audio.formatTag == 17 || audio.formatTag == 49) {
            if (extraFieldsSize < 2)
              throw new BadHeaderException("samplesPerBlock field not available for encoding" + audio.formatTag); 
            audio.samplesPerBlock = BasicPullParser.parseShortFromArray(this.codecSpecificHeader, false);
          } 
        } 
        if (remainingFormatSize < 0)
          throw new BadHeaderException("Avi Parser: incorrect headersize in the STRF"); 
        if (remainingFormatSize > 0)
          skip(this.stream, length - 16); 
        (this.trakList[currentTrack]).media = audio;
        this.audioTrack = currentTrack;
      } else {
        throw new BadHeaderException("strf: unsupported stream type " + trackType);
      } 
    } catch (IOException e) {
      throw new BadHeaderException("IOException when parsing hdrl");
    } 
  }
  
  private void parseAVIH(int length) throws BadHeaderException {
    try {
      if (length < 56)
        throw new BadHeaderException("avih: header size is not 56"); 
      this.usecPerFrame = readInt(this.stream, false);
      this.nanoSecPerFrame = (this.usecPerFrame * 1000);
      this.maxBytesPerSecond = readInt(this.stream, false);
      this.paddingGranularity = readInt(this.stream, false);
      this.flags = readInt(this.stream, false);
      this.totalFrames = readInt(this.stream, false);
      this.initialFrames = readInt(this.stream, false);
      this.numTracks = readInt(this.stream, false);
      this.suggestedBufferSize = readInt(this.stream, false);
      this.width = readInt(this.stream, false);
      this.height = readInt(this.stream, false);
      skip(this.stream, 16);
      if (length - 56 > 0)
        skip(this.stream, length - 56); 
    } catch (IOException e) {
      throw new BadHeaderException("IOException when parsing hdrl");
    } 
  }
  
  private void parseIDX1(int length) throws BadHeaderException {
    try {
      if (!this.moviChunkSeen)
        throw new BadHeaderException("idx1 chunk appears before movi chunk"); 
      int numIndices = length / 16;
      for (int i = 0; i < this.numTracks; i++) {
        if (this.trakList[i] == null)
          throw new BadHeaderException("Bad file format"); 
        (this.trakList[i]).chunkInfo = new AVIIndexEntry[numIndices];
        if ((this.trakList[i]).trackType.equals("vids"))
          (this.trakList[i]).keyFrames = new int[numIndices]; 
      } 
      this.idx1MinimumChunkOffset = Integer.MAX_VALUE;
      for (int j = 0; j < numIndices; j++) {
        String id = readString(this.stream);
        if (id.equals("rec ")) {
          readInt(this.stream, false);
          readInt(this.stream, false);
          readInt(this.stream, false);
        } else {
          int streamNumber;
          try {
            streamNumber = Integer.parseInt(id.substring(0, 2));
          } catch (NumberFormatException e) {
            readInt(this.stream, false);
            readInt(this.stream, false);
            readInt(this.stream, false);
          } 
          if (streamNumber < 0 || streamNumber >= this.numTracks)
            throw new BadHeaderException("index chunk has illegal stream # " + streamNumber); 
          int flag = readInt(this.stream, false);
          int chunkOffset = readInt(this.stream, false);
          int chunkLength = readInt(this.stream, false);
          AVIIndexEntry[] chunkInfo = (this.trakList[streamNumber]).chunkInfo;
          int index = (this.trakList[streamNumber]).maxChunkIndex;
          chunkInfo[index] = new AVIIndexEntry();
          (chunkInfo[index]).id = id;
          (chunkInfo[index]).flag = flag;
          (chunkInfo[index]).chunkOffset = chunkOffset;
          (chunkInfo[index]).chunkLength = chunkLength;
          if ((this.trakList[streamNumber]).trackType.equals("auds")) {
            int c = (this.trakList[streamNumber]).tmpCumulativeChunkLength += chunkLength;
            (chunkInfo[index]).cumulativeChunkLength = c;
          } 
          if ((this.trakList[streamNumber]).trackType.equals("vids") && (
            flag & 0x10) > 0) {
            int keyFrameIndex = (this.trakList[streamNumber]).numKeyFrames;
            (this.trakList[streamNumber]).keyFrames[keyFrameIndex] = index;
            (this.trakList[streamNumber]).numKeyFrames++;
          } 
          (this.trakList[streamNumber]).maxChunkIndex++;
          if (chunkOffset < this.idx1MinimumChunkOffset)
            this.idx1MinimumChunkOffset = chunkOffset; 
        } 
      } 
      for (int k = 0; k < this.numTracks; k++) {
        if ((this.trakList[k]).trackType.equals("vids")) {
          int numKeyFrames = (this.trakList[k]).numKeyFrames;
          if (numKeyFrames > 0)
            this.keyFrameTrack = k; 
          int maxChunkIndex = (this.trakList[k]).maxChunkIndex;
          if (numKeyFrames > 0 && numKeyFrames < maxChunkIndex)
            (this.trakList[k]).indexToKeyframeIndex = buildIndexToKeyFrameIndexTable((this.trakList[k]).keyFrames, numKeyFrames, maxChunkIndex); 
          (this.trakList[k]).keyFrames = null;
        } 
      } 
      if (this.idx1MinimumChunkOffset >= this.moviOffset)
        this.moviOffset = 0; 
      this.moviOffset += 8;
    } catch (IOException e) {
      throw new BadHeaderException("IOException when parsing IDX1");
    } 
    this.idx1ChunkSeen = true;
  }
  
  private void parseMOVI(int length) throws BadHeaderException {
    try {
      this.moviChunkSeen = true;
      if ((this.flags & 0x10) > 0) {
        this.moviOffset = (int)getLocation(this.stream) - 4;
        skip(this.stream, length);
      } 
    } catch (IOException e) {
      throw new BadHeaderException("IOException when parsing movi");
    } 
  }
  
  public Time setPosition(Time where, int rounding) {
    int keyframeNum = -1;
    if (this.keyFrameTrack != -1 && this.tracks[this.keyFrameTrack].isEnabled()) {
      TrakList trakInfo = this.trakList[this.keyFrameTrack];
      Track track = this.tracks[this.keyFrameTrack];
      int frameNum = track.mapTimeToFrame(where);
      keyframeNum = frameNum;
      if (trakInfo.indexToKeyframeIndex.length > frameNum)
        keyframeNum = trakInfo.indexToKeyframeIndex[frameNum]; 
      if (keyframeNum != frameNum)
        where = track.mapFrameToTime(keyframeNum); 
    } 
    for (int i = 0; i < this.numTracks; i++) {
      if (!this.tracks[i].isEnabled())
        continue; 
      int chunkNumber = 0;
      int offsetWithinChunk = 0;
      try {
        if (i == this.keyFrameTrack) {
          chunkNumber = keyframeNum;
          continue;
        } 
        TrakList trakInfo = this.trakList[i];
        if (trakInfo.trackType.equals("vids")) {
          if (this.usecPerFrame != 0) {
            chunkNumber = (int)(where.getNanoseconds() / this.nanoSecPerFrame);
            if (chunkNumber < 0) {
              chunkNumber = 0;
            } else if (chunkNumber >= trakInfo.maxChunkIndex) {
            
            } 
          } 
          continue;
        } 
        if (trakInfo.trackType.equals("auds")) {
          int bytePos = (int)(where.getSeconds() * ((Audio)trakInfo.media).avgBytesPerSec);
          if (bytePos < 0)
            bytePos = 0; 
          if (trakInfo.maxChunkIndex == 1) {
            if (bytePos >= (trakInfo.chunkInfo[0]).chunkLength) {
              chunkNumber = trakInfo.maxChunkIndex;
            } else {
              chunkNumber = 0;
              offsetWithinChunk = bytePos;
              if ((offsetWithinChunk & 0x1) > 0)
                offsetWithinChunk--; 
            } 
            continue;
          } 
          chunkNumber = trakInfo.getChunkNumber(bytePos);
          if (chunkNumber >= trakInfo.maxChunkIndex)
            continue; 
          int approx = (trakInfo.chunkInfo[chunkNumber]).cumulativeChunkLength - (trakInfo.chunkInfo[chunkNumber]).chunkLength;
          offsetWithinChunk = bytePos - approx;
        } else {
          continue;
        } 
        if ((offsetWithinChunk & 0x1) > 0)
          offsetWithinChunk--; 
      } finally {}
    } 
    return where;
  }
  
  public Time getMediaTime() {
    return null;
  }
  
  public Time getDuration() {
    return this.duration;
  }
  
  public String getName() {
    return "Parser for avi file format";
  }
  
  private boolean isSupported(String trackType) {
    return (trackType.equals("vids") || trackType.equals("auds"));
  }
  
  private int[] buildIndexToKeyFrameIndexTable(int[] syncSamples, int numKeyFrames, int numberOfSamples) {
    int i, syncSampleMapping[] = new int[numberOfSamples];
    int index = 0;
    if (syncSamples[0] != 0) {
      i = syncSampleMapping[0] = 0;
    } else {
      i = syncSampleMapping[0] = 0;
      index++;
    } 
    for (; index < numKeyFrames; index++) {
      int next = syncSamples[index];
      for (int j = i + 1; j < next; j++)
        syncSampleMapping[j] = i; 
      syncSampleMapping[next] = next;
      i = next;
    } 
    int lastSyncFrame = syncSamples[numKeyFrames - 1];
    for (index = lastSyncFrame + 1; index < numberOfSamples; index++)
      syncSampleMapping[index] = lastSyncFrame; 
    return syncSampleMapping;
  }
  
  private abstract class Media {
    int maxSampleSize;
    
    private final AviParser this$0;
    
    private Media(AviParser this$0) {
      AviParser.this = AviParser.this;
    }
    
    abstract Format createFormat();
  }
  
  private class Audio extends Media {
    int formatTag;
    
    int channels;
    
    int sampleRate;
    
    int avgBytesPerSec;
    
    int blockAlign;
    
    int bitsPerSample;
    
    int samplesPerBlock;
    
    AudioFormat format;
    
    private final AviParser this$0;
    
    private Audio(AviParser this$0) {
      AviParser.this = AviParser.this;
      this.format = null;
    }
    
    Format createFormat() {
      boolean bool;
      if (this.format != null)
        return (Format)this.format; 
      String encodingString = (String)WavAudioFormat.formatMapper.get(new Integer(this.formatTag));
      if (encodingString == null)
        encodingString = "unknown"; 
      if (this.bitsPerSample > 8) {
        bool = true;
      } else {
        bool = false;
      } 
      this.format = (AudioFormat)new WavAudioFormat(encodingString, this.sampleRate, this.bitsPerSample, this.channels, this.blockAlign * 8, this.avgBytesPerSec, 0, bool ? 1 : 0, -1.0F, Format.byteArray, AviParser.this.codecSpecificHeader);
      return (Format)this.format;
    }
    
    public String toString() {
      System.out.println("Audio Media: " + this.format);
      System.out.println("Number of channels " + this.channels);
      System.out.println("average bytes per second " + this.avgBytesPerSec);
      System.out.println("sampleRate " + this.sampleRate);
      System.out.println("blockAlign " + this.blockAlign);
      System.out.println("bitsPerSample " + this.bitsPerSample);
      System.out.println("formatTag " + this.formatTag);
      return super.toString();
    }
  }
  
  private class Video extends Media {
    int size;
    
    int width;
    
    int height;
    
    int planes;
    
    int depth;
    
    String compressor;
    
    VideoFormat format;
    
    BitMapInfo bitMapInfo;
    
    private final AviParser this$0;
    
    private Video(AviParser this$0) {
      AviParser.this = AviParser.this;
      this.format = null;
      this.bitMapInfo = null;
    }
    
    Format createFormat() {
      if (this.format != null)
        return (Format)this.format; 
      if (AviParser.this.usecPerFrame != 0) {
        this.format = this.bitMapInfo.createVideoFormat(Format.byteArray, (float)(1.0D / AviParser.this.usecPerFrame * 1000000.0D));
      } else {
        this.format = this.bitMapInfo.createVideoFormat(Format.byteArray);
      } 
      return (Format)this.format;
    }
    
    public String toString() {
      System.out.println("size is " + this.size);
      System.out.println("width is " + this.width);
      System.out.println("height is " + this.height);
      System.out.println("planes is " + this.planes);
      System.out.println("depth is " + this.depth);
      System.out.println("compressor is " + this.compressor);
      return super.toString();
    }
  }
  
  private class TrakList {
    Time duration;
    
    String trackType;
    
    String streamHandler;
    
    int flags;
    
    int priority;
    
    int initialFrames;
    
    int scale;
    
    int rate;
    
    int start;
    
    int length;
    
    int suggestedBufferSize;
    
    int quality;
    
    int sampleSize;
    
    AviParser.Media media;
    
    boolean supported;
    
    AviParser.AVIIndexEntry[] chunkInfo;
    
    int maxChunkIndex;
    
    int[] indexToKeyframeIndex;
    
    int[] keyFrames;
    
    int numKeyFrames;
    
    int tmpCumulativeChunkLength;
    
    private final AviParser this$0;
    
    private TrakList(AviParser this$0) {
      AviParser.this = AviParser.this;
      this.duration = Duration.DURATION_UNKNOWN;
      this.supported = true;
      this.chunkInfo = new AviParser.AVIIndexEntry[0];
      this.maxChunkIndex = 0;
      this.indexToKeyframeIndex = new int[0];
      this.keyFrames = new int[0];
      this.numKeyFrames = 0;
      this.tmpCumulativeChunkLength = 0;
    }
    
    int getChunkNumber(int offset) {
      for (int i = 0; i < this.maxChunkIndex; i++) {
        if (offset < (this.chunkInfo[i]).cumulativeChunkLength)
          return i; 
      } 
      return this.maxChunkIndex;
    }
  }
  
  private abstract class MediaTrack implements Track {
    protected AviParser.TrakList trakInfo;
    
    private boolean enabled;
    
    private int numBuffers;
    
    private Format format;
    
    private long sequenceNumber;
    
    private int chunkNumber;
    
    protected int useChunkNumber;
    
    protected int offsetWithinChunk;
    
    protected int useOffsetWithinChunk;
    
    private AviParser parser;
    
    private AviParser.AVIIndexEntry indexEntry;
    
    private Object header;
    
    private TrackListener listener;
    
    private final AviParser this$0;
    
    MediaTrack(AviParser this$0, AviParser.TrakList trakInfo) {
      this.this$0 = this$0;
      this.enabled = true;
      this.numBuffers = 4;
      this.sequenceNumber = 0L;
      this.chunkNumber = 0;
      this.useChunkNumber = 0;
      this.offsetWithinChunk = -1;
      this.useOffsetWithinChunk = 0;
      this.parser = this.this$0;
      this.header = null;
      this.trakInfo = trakInfo;
      this.format = trakInfo.media.createFormat();
    }
    
    public void setTrackListener(TrackListener l) {
      this.listener = l;
    }
    
    public Format getFormat() {
      return this.format;
    }
    
    public void setEnabled(boolean t) {
      this.enabled = t;
    }
    
    public boolean isEnabled() {
      return this.enabled;
    }
    
    public Time getDuration() {
      return this.trakInfo.duration;
    }
    
    public Time getStartTime() {
      return new Time(0L);
    }
    
    synchronized void setChunkNumberAndOffset(int number, int offset) {
      this.chunkNumber = number;
      this.offsetWithinChunk = offset;
    }
    
    public void readFrame(Buffer buffer) {
      byte[] arrayOfByte;
      if (buffer == null)
        return; 
      if (!this.enabled) {
        buffer.setDiscard(true);
        return;
      } 
      synchronized (this) {
        if (this.offsetWithinChunk == -1) {
          this.useOffsetWithinChunk = 0;
        } else {
          this.useOffsetWithinChunk = this.offsetWithinChunk;
          this.offsetWithinChunk = -1;
        } 
        this.useChunkNumber = this.chunkNumber;
      } 
      if (this.useChunkNumber >= this.trakInfo.maxChunkIndex || this.useChunkNumber < 0) {
        buffer.setLength(0);
        buffer.setEOM(true);
        return;
      } 
      buffer.setFormat(this.format);
      this.indexEntry = this.trakInfo.chunkInfo[this.useChunkNumber];
      int chunkLength = this.indexEntry.chunkLength;
      Object obj = buffer.getData();
      buffer.setHeader(new Integer(this.indexEntry.flag));
      if (obj == null || !(obj instanceof byte[]) || ((byte[])obj).length < chunkLength) {
        arrayOfByte = new byte[chunkLength];
        buffer.setData(arrayOfByte);
      } else {
        arrayOfByte = (byte[])obj;
      } 
      try {
        int actualBytesRead;
        synchronized (this.this$0.seekSync) {
          this.this$0.seekableStream.seek((this.indexEntry.chunkOffset + this.this$0.moviOffset + this.useOffsetWithinChunk));
          actualBytesRead = this.parser.readBytes(this.this$0.stream, arrayOfByte, chunkLength - this.useOffsetWithinChunk);
          this.offsetWithinChunk = 0;
          buffer.setTimeStamp(getTimeStamp());
        } 
        buffer.setLength(actualBytesRead);
        long frameDuration = -1L;
        if (this.trakInfo.trackType.equals("vids")) {
          if (this.this$0.nanoSecPerFrame > 0L)
            frameDuration = this.this$0.nanoSecPerFrame; 
          if (this.trakInfo.indexToKeyframeIndex.length == 0 || this.useChunkNumber == this.trakInfo.indexToKeyframeIndex[this.useChunkNumber])
            buffer.setFlags(buffer.getFlags() | 0x10); 
        } 
        buffer.setDuration(frameDuration);
        buffer.setSequenceNumber(++this.sequenceNumber);
      } catch (IOException e) {
        buffer.setLength(0);
        buffer.setEOM(true);
      } 
      synchronized (this) {
        if (this.chunkNumber == this.useChunkNumber)
          this.chunkNumber++; 
      } 
    }
    
    abstract void doReadFrame(Buffer param1Buffer);
    
    public int mapTimeToFrame(Time t) {
      return Integer.MAX_VALUE;
    }
    
    public Time mapFrameToTime(int frameNumber) {
      return Track.TIME_UNKNOWN;
    }
    
    abstract long getTimeStamp();
  }
  
  private class AudioTrack extends MediaTrack {
    int channels;
    
    int avgBytesPerSec;
    
    AviParser.AVIIndexEntry[] chunkInfo;
    
    private final AviParser this$0;
    
    AudioTrack(AviParser this$0, AviParser.TrakList trakInfo) {
      super(this$0, trakInfo);
      this.this$0 = this$0;
      this.channels = ((AviParser.Audio)trakInfo.media).channels;
      this.avgBytesPerSec = ((AviParser.Audio)trakInfo.media).avgBytesPerSec;
      this.chunkInfo = trakInfo.chunkInfo;
    }
    
    void doReadFrame(Buffer buffer) {}
    
    long getTimeStamp() {
      if (this.avgBytesPerSec > 0) {
        long bytes = this.useOffsetWithinChunk;
        if (this.useChunkNumber > 0)
          bytes += (this.chunkInfo[this.useChunkNumber - 1]).cumulativeChunkLength; 
        return (long)(((float)bytes / this.avgBytesPerSec) * 1.0E9D);
      } 
      return 0L;
    }
  }
  
  private class VideoTrack extends MediaTrack {
    int needBufferSize;
    
    boolean variableSampleSize;
    
    private final AviParser this$0;
    
    VideoTrack(AviParser this$0, AviParser.TrakList trakInfo) {
      super(this$0, trakInfo);
      this.this$0 = this$0;
      this.variableSampleSize = true;
    }
    
    void doReadFrame(Buffer buffer) {}
    
    long getTimeStamp() {
      return this.useChunkNumber * this.this$0.usecPerFrame * 1000L;
    }
    
    public int mapTimeToFrame(Time t) {
      if (this.this$0.nanoSecPerFrame <= 0L)
        return Integer.MAX_VALUE; 
      if (t.getNanoseconds() < 0L)
        return Integer.MAX_VALUE; 
      int chunkNumber = (int)(t.getNanoseconds() / this.this$0.nanoSecPerFrame);
      if (chunkNumber >= this.trakInfo.maxChunkIndex)
        return this.trakInfo.maxChunkIndex - 1; 
      return chunkNumber;
    }
    
    public Time mapFrameToTime(int frameNumber) {
      if (frameNumber < 0 || frameNumber >= this.trakInfo.maxChunkIndex)
        return Track.TIME_UNKNOWN; 
      long time = frameNumber * this.this$0.nanoSecPerFrame;
      return new Time(time);
    }
  }
  
  private class AVIIndexEntry {
    public String id;
    
    public int flag;
    
    public int chunkOffset;
    
    public int chunkLength;
    
    public int cumulativeChunkLength;
    
    private final AviParser this$0;
    
    private AVIIndexEntry(AviParser this$0) {
      AviParser.this = AviParser.this;
      this.cumulativeChunkLength = 0;
    }
  }
}
