package com.sun.media.parser.audio;

import com.sun.media.parser.BasicPullParser;
import com.sun.media.parser.BasicTrack;
import com.sun.media.util.SettableTime;
import java.io.IOException;
import javax.media.BadHeaderException;
import javax.media.Duration;
import javax.media.Format;
import javax.media.Time;
import javax.media.Track;
import javax.media.format.AudioFormat;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.PullSourceStream;

public class GsmParser extends BasicPullParser {
  private Time duration = Duration.DURATION_UNKNOWN;
  
  private Format format = null;
  
  private Track[] tracks = new Track[1];
  
  private int numBuffers = 4;
  
  private int bufferSize;
  
  private int dataSize;
  
  private SettableTime mediaTime = new SettableTime(0L);
  
  private int encoding;
  
  private String encodingString;
  
  private int sampleRate;
  
  private int samplesPerBlock;
  
  private int bytesPerSecond = 1650;
  
  private int blockSize = 33;
  
  private long minLocation;
  
  private long maxLocation;
  
  private PullSourceStream stream = null;
  
  private static ContentDescriptor[] supportedFormat = new ContentDescriptor[] { new ContentDescriptor("audio.x_gsm") };
  
  public ContentDescriptor[] getSupportedInputContentDescriptors() {
    return supportedFormat;
  }
  
  public Track[] getTracks() throws IOException, BadHeaderException {
    if (this.tracks[0] != null)
      return this.tracks; 
    this.stream = (PullSourceStream)this.streams[0];
    readHeader();
    this.bufferSize = this.bytesPerSecond;
    this.tracks[0] = (Track)new GsmTrack((AudioFormat)this.format, true, new Time(0L), this.numBuffers, this.bufferSize, this.minLocation, this.maxLocation);
    return this.tracks;
  }
  
  private void readHeader() throws IOException, BadHeaderException {
    this.minLocation = getLocation(this.stream);
    long contentLength = this.stream.getContentLength();
    if (contentLength != -1L) {
      double durationSeconds = (contentLength / this.bytesPerSecond);
      this.duration = new Time(durationSeconds);
      this.maxLocation = contentLength;
    } else {
      this.maxLocation = Long.MAX_VALUE;
    } 
    boolean signed = true;
    boolean bigEndian = false;
    this.format = (Format)new AudioFormat("gsm", 8000.0D, 16, 1, bigEndian ? 1 : 0, signed ? 1 : 0, this.blockSize * 8, -1.0D, Format.byteArray);
  }
  
  public Time setPosition(Time where, int rounding) {
    if (!this.seekable)
      return getMediaTime(); 
    long time = where.getNanoseconds();
    if (time < 0L)
      time = 0L; 
    double newPosd = (time * this.bytesPerSecond) / 1.0E9D;
    double remainder = newPosd % this.blockSize;
    long newPos = (long)(newPosd - remainder);
    if (remainder > 0.0D)
      switch (rounding) {
        case 1:
          newPos += this.blockSize;
          break;
        case 3:
          if (remainder > this.blockSize / 2.0D)
            newPos += this.blockSize; 
          break;
      }  
    newPos += this.minLocation;
    ((BasicTrack)this.tracks[0]).setSeekLocation(newPos);
    if (this.cacheStream != null)
      synchronized (this) {
        this.cacheStream.abortRead();
      }  
    return where;
  }
  
  public Time getMediaTime() {
    long l1, seekLocation = ((BasicTrack)this.tracks[0]).getSeekLocation();
    if (seekLocation != -1L) {
      l1 = seekLocation - this.minLocation;
    } else {
      l1 = getLocation(this.stream) - this.minLocation;
    } 
    synchronized (this.mediaTime) {
      this.mediaTime.set(l1 / this.bytesPerSecond);
    } 
    return (Time)this.mediaTime;
  }
  
  public Time getDuration() {
    if (this.duration.equals(Duration.DURATION_UNKNOWN) && this.tracks[0] != null) {
      long mediaSizeAtEOM = ((BasicTrack)this.tracks[0]).getMediaSizeAtEOM();
      if (mediaSizeAtEOM > 0L) {
        double durationSeconds = (mediaSizeAtEOM / this.bytesPerSecond);
        this.duration = new Time(durationSeconds);
      } 
    } 
    return this.duration;
  }
  
  public String getName() {
    return "Parser for raw GSM";
  }
  
  class GsmTrack extends BasicTrack {
    private double sampleRate;
    
    private float timePerFrame;
    
    private SettableTime frameToTime;
    
    private final GsmParser this$0;
    
    GsmTrack(GsmParser this$0, AudioFormat format, boolean enabled, Time startTime, int numBuffers, int bufferSize, long minLocation, long maxLocation) {
      super(GsmParser.this, (Format)format, enabled, GsmParser.this.duration, startTime, numBuffers, bufferSize, GsmParser.this.stream, minLocation, maxLocation);
      GsmParser.this = GsmParser.this;
      this.timePerFrame = 0.02F;
      this.frameToTime = new SettableTime();
      double sampleRate = format.getSampleRate();
      int channels = format.getChannels();
      int sampleSizeInBits = format.getSampleSizeInBits();
      long durationNano = this.duration.getNanoseconds();
    }
    
    GsmTrack(AudioFormat format, boolean enabled, Time startTime, int numBuffers, int bufferSize) {
      this(format, enabled, startTime, numBuffers, bufferSize, 0L, Long.MAX_VALUE);
    }
  }
}
