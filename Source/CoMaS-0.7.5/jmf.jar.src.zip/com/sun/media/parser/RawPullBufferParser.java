package com.sun.media.parser;

import java.io.IOException;
import javax.media.Buffer;
import javax.media.Demultiplexer;
import javax.media.Format;
import javax.media.IncompatibleSourceException;
import javax.media.Time;
import javax.media.Track;
import javax.media.TrackListener;
import javax.media.protocol.DataSource;
import javax.media.protocol.PullBufferDataSource;
import javax.media.protocol.PullBufferStream;
import javax.media.protocol.SourceStream;

public class RawPullBufferParser extends RawPullStreamParser {
  static final String NAME = "Raw pull stream parser";
  
  public String getName() {
    return "Raw pull stream parser";
  }
  
  public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
    if (!(source instanceof PullBufferDataSource))
      throw new IncompatibleSourceException("DataSource not supported: " + source); 
    this.streams = (SourceStream[])((PullBufferDataSource)source).getStreams();
    if (this.streams == null)
      throw new IOException("Got a null stream from the DataSource"); 
    if (this.streams.length == 0)
      throw new IOException("Got a empty stream array from the DataSource"); 
    if (!supports(this.streams))
      throw new IncompatibleSourceException("DataSource not supported: " + source); 
    this.source = source;
    this.streams = this.streams;
  }
  
  protected boolean supports(SourceStream[] streams) {
    return (streams[0] != null && streams[0] instanceof PullBufferStream);
  }
  
  public void open() {
    if (this.tracks != null)
      return; 
    this.tracks = new Track[this.streams.length];
    for (int i = 0; i < this.streams.length; i++)
      this.tracks[i] = new FrameTrack(this, this, (PullBufferStream)this.streams[i]); 
  }
  
  class FrameTrack implements Track {
    Demultiplexer parser;
    
    PullBufferStream pbs;
    
    boolean enabled;
    
    Format format;
    
    TrackListener listener;
    
    Integer stateReq;
    
    private final RawPullBufferParser this$0;
    
    public FrameTrack(RawPullBufferParser this$0, Demultiplexer parser, PullBufferStream pbs) {
      this.this$0 = this$0;
      this.enabled = true;
      this.format = null;
      this.stateReq = new Integer(0);
      this.pbs = pbs;
      this.format = pbs.getFormat();
    }
    
    public Format getFormat() {
      return this.format;
    }
    
    public void setEnabled(boolean t) {
      this.enabled = t;
    }
    
    public boolean isEnabled() {
      return this.enabled;
    }
    
    public Time getDuration() {
      return this.parser.getDuration();
    }
    
    public Time getStartTime() {
      return new Time(0L);
    }
    
    public void setTrackListener(TrackListener l) {
      this.listener = l;
    }
    
    public void readFrame(Buffer buffer) {
      if (buffer.getData() == null)
        buffer.setData(new byte[500]); 
      try {
        this.pbs.read(buffer);
      } catch (IOException e) {
        buffer.setDiscard(true);
      } 
    }
    
    public int mapTimeToFrame(Time t) {
      return -1;
    }
    
    public Time mapFrameToTime(int frameNumber) {
      return new Time(0L);
    }
  }
}
