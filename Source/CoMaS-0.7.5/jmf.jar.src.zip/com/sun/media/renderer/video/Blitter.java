package com.sun.media.renderer.video;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.util.Vector;
import javax.media.Buffer;

public interface Blitter {
  int newData(Buffer paramBuffer, Vector paramVector1, Vector paramVector2, Vector paramVector3);
  
  Image process(Buffer paramBuffer, Object paramObject1, Object paramObject2, Dimension paramDimension);
  
  void draw(Graphics paramGraphics, Component paramComponent, Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8);
  
  void resized(Component paramComponent);
}
