package com.sun.media;

public interface ExclusiveUse {
  boolean isExclusive();
}
