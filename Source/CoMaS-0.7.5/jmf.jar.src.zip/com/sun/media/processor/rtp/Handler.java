package com.sun.media.processor.rtp;

import com.sun.media.BasicController;
import com.sun.media.BasicPlayer;
import com.sun.media.BasicProcessor;
import com.sun.media.JMFSecurity;
import com.sun.media.Log;
import com.sun.media.protocol.rtp.DataSource;
import com.sun.media.rtp.RTPMediaLocator;
import com.sun.media.rtp.RTPSessionMgr;
import java.awt.Component;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.util.Vector;
import javax.media.Control;
import javax.media.Controller;
import javax.media.ControllerErrorEvent;
import javax.media.ControllerEvent;
import javax.media.ControllerListener;
import javax.media.Format;
import javax.media.IncompatibleSourceException;
import javax.media.IncompatibleTimeBaseException;
import javax.media.Manager;
import javax.media.MediaLocator;
import javax.media.NotConfiguredError;
import javax.media.NotRealizedError;
import javax.media.Player;
import javax.media.Processor;
import javax.media.SystemTimeBase;
import javax.media.TimeBase;
import javax.media.control.TrackControl;
import javax.media.format.AudioFormat;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.DataSource;
import javax.media.rtp.RTPControl;
import javax.media.rtp.RTPManager;
import javax.media.rtp.RTPPushDataSource;
import javax.media.rtp.RTPSocket;
import javax.media.rtp.ReceiveStream;
import javax.media.rtp.ReceiveStreamListener;
import javax.media.rtp.SessionAddress;
import javax.media.rtp.event.NewReceiveStreamEvent;
import javax.media.rtp.event.ReceiveStreamEvent;

public class Handler extends BasicProcessor implements ReceiveStreamListener {
  RTPSessionMgr[] mgrs = null;
  
  DataSource[] sources = null;
  
  Processor processor = null;
  
  Format[] formats = null;
  
  Vector locators = null;
  
  Object dataLock = new Object();
  
  boolean dataReady = false;
  
  private boolean closed = false;
  
  private boolean audioEnabled = false;
  
  private boolean videoEnabled = false;
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] m = new Method[1];
  
  private Class[] cl = new Class[1];
  
  private Object[][] args = new Object[1][0];
  
  String sessionError;
  
  Object closeSync;
  
  public Handler() {
    this.sessionError = "cannot create and initialize the RTP Session.";
    this.closeSync = new Object();
    ((BasicPlayer)this).framePositioning = false;
  }
  
  protected synchronized boolean doConfigure() {
    super.doConfigure();
    try {
      if (((BasicPlayer)this).source instanceof RTPSocket) {
        this.mgrs = new RTPSessionMgr[1];
        this.mgrs[1] = new RTPSessionMgr((RTPPushDataSource)((BasicPlayer)this).source);
        this.mgrs[1].addReceiveStreamListener(this);
        this.sources = new DataSource[1];
        this.sources[0] = ((BasicPlayer)this).source;
        this.formats = new Format[1];
        this.dataReady = false;
      } else {
        SessionAddress localAddr = new SessionAddress();
        this.mgrs = new RTPSessionMgr[this.locators.size()];
        this.sources = new DataSource[this.locators.size()];
        this.formats = new Format[this.locators.size()];
        this.dataReady = false;
        for (int i = 0; i < this.locators.size(); i++) {
          SessionAddress sessionAddress;
          RTPMediaLocator rml = this.locators.elementAt(i);
          this.mgrs[i] = (RTPSessionMgr)RTPManager.newInstance();
          this.mgrs[i].addReceiveStreamListener(this);
          InetAddress ipAddr = InetAddress.getByName(rml.getSessionAddress());
          if (ipAddr.isMulticastAddress()) {
            localAddr = new SessionAddress(ipAddr, rml.getSessionPort(), rml.getTTL());
            sessionAddress = new SessionAddress(ipAddr, rml.getSessionPort(), rml.getTTL());
          } else {
            localAddr = new SessionAddress(InetAddress.getLocalHost(), rml.getSessionPort());
            sessionAddress = new SessionAddress(ipAddr, rml.getSessionPort());
          } 
          this.mgrs[i].initialize(localAddr);
          this.mgrs[i].addTarget(sessionAddress);
        } 
      } 
    } catch (Exception e) {
      Log.error("Cannot create the RTP Session: " + e.getMessage());
      ((BasicController)this).processError = this.sessionError;
      return false;
    } 
    try {
      synchronized (this.dataLock) {
        while (!this.dataReady && !isInterrupted() && !this.closed)
          this.dataLock.wait(); 
      } 
    } catch (Exception e) {}
    if (this.closed || isInterrupted()) {
      resetInterrupt();
      ((BasicController)this).processError = "no RTP data was received.";
      return false;
    } 
    return true;
  }
  
  protected void completeConfigure() {
    ((BasicController)this).state = 180;
    super.completeConfigure();
  }
  
  protected void doFailedConfigure() {
    closeSessions();
    super.doFailedConfigure();
  }
  
  private void closeSessions() {
    synchronized (this.closeSync) {
      for (int i = 0; i < this.mgrs.length; i++) {
        if (this.mgrs[i] != null) {
          this.mgrs[i].removeTargets("Closing session from the RTP Handler");
          this.mgrs[i].dispose();
          this.mgrs[i] = null;
        } 
      } 
    } 
  }
  
  protected boolean doRealize() {
    return waitForRealize(this.processor);
  }
  
  protected void completeRealize() {
    ((BasicController)this).state = 300;
    super.completeRealize();
  }
  
  protected void doFailedRealize() {
    closeSessions();
    super.doFailedRealize();
  }
  
  protected void doStart() {
    super.doStart();
    waitForStart((Player)this.processor);
  }
  
  protected void doStop() {
    super.doStop();
    waitForStop((Player)this.processor);
  }
  
  protected void doDeallocate() {
    this.processor.deallocate();
    synchronized (this.dataLock) {
      this.dataLock.notifyAll();
    } 
  }
  
  protected void doClose() {
    this.closed = true;
    synchronized (this.dataLock) {
      this.dataLock.notify();
    } 
    stop();
    if (this.processor != null)
      this.processor.close(); 
    closeSessions();
    super.doClose();
  }
  
  public void setTimeBase(TimeBase tb) throws IncompatibleTimeBaseException {}
  
  protected TimeBase getMasterTimeBase() {
    return (TimeBase)new SystemTimeBase();
  }
  
  protected boolean audioEnabled() {
    return this.audioEnabled;
  }
  
  protected boolean videoEnabled() {
    return this.videoEnabled;
  }
  
  private void sendMyEvent(ControllerEvent e) {
    sendEvent(e);
  }
  
  public void update(ReceiveStreamEvent event) {
    RTPSessionMgr mgr = (RTPSessionMgr)event.getSource();
    int idx;
    for (idx = 0; idx < this.mgrs.length && 
      this.mgrs[idx] != mgr; idx++);
    if (idx >= this.mgrs.length) {
      System.err.println("Unknown manager: " + mgr);
      return;
    } 
    if (event instanceof javax.media.rtp.event.RemotePayloadChangeEvent) {
      Log.comment("Received an RTP PayloadChangeEvent");
      Log.error("The RTP processor cannot handle mid-stream payload change.\n");
      sendEvent((ControllerEvent)new ControllerErrorEvent((Controller)this, "Cannot handle mid-stream payload change."));
      close();
    } 
    if (event instanceof NewReceiveStreamEvent) {
      if (this.sources[idx] != null)
        return; 
      ReceiveStream stream = null;
      try {
        DataSource mixDS;
        stream = ((NewReceiveStreamEvent)event).getReceiveStream();
        this.sources[idx] = stream.getDataSource();
        RTPControl ctl = (RTPControl)this.sources[idx].getControl("javax.media.rtp.RTPControl");
        if (ctl != null) {
          this.formats[idx] = ctl.getFormat();
          if (this.formats[idx] instanceof AudioFormat)
            this.audioEnabled = true; 
          if (this.formats[idx] instanceof javax.media.format.VideoFormat)
            this.videoEnabled = true; 
        } 
        if (((BasicPlayer)this).source instanceof RTPSocket) {
          ((RTPSocket)((BasicPlayer)this).source).setChild(this.sources[idx]);
        } else {
          ((DataSource)((BasicPlayer)this).source).setChild((DataSource)this.sources[idx]);
        } 
        for (int i = 0; i < this.sources.length; i++) {
          if (this.sources[i] == null)
            return; 
        } 
        try {
          mixDS = Manager.createMergingDataSource(this.sources);
        } catch (Exception e) {
          System.err.println("Cannot merge data sources.");
          return;
        } 
        try {
          this.processor = Manager.createProcessor(mixDS);
        } catch (Exception e) {
          System.err.println("Cannot create the mix processor.");
          return;
        } 
        if (!waitForConfigure(this.processor))
          return; 
        synchronized (this.dataLock) {
          this.dataReady = true;
          this.dataLock.notifyAll();
        } 
      } catch (Exception e) {
        System.err.println("NewReceiveStreamEvent exception " + e.getMessage());
        return;
      } 
    } 
  }
  
  public void setSource(DataSource source) throws IOException, IncompatibleSourceException {
    super.setSource(source);
    if (source instanceof DataSource) {
      MediaLocator ml = source.getLocator();
      String mlStr = ml.getRemainder();
      int start = 0;
      while (mlStr.charAt(start) == '/')
        start++; 
      this.locators = new Vector();
      try {
        String str;
        int idx;
        while (start < mlStr.length() && (idx = mlStr.indexOf("&", start)) != -1) {
          str = mlStr.substring(start, idx);
          RTPMediaLocator rml = new RTPMediaLocator("rtp://" + str);
          this.locators.addElement(rml);
          start = idx + 1;
        } 
        if (start != 0) {
          str = mlStr.substring(start);
        } else {
          str = mlStr;
        } 
        RTPMediaLocator rTPMediaLocator = new RTPMediaLocator("rtp://" + str);
        this.locators.addElement(rTPMediaLocator);
      } catch (Exception e) {
        throw new IncompatibleSourceException();
      } 
    } else if (!(source instanceof RTPSocket)) {
      throw new IncompatibleSourceException();
    } 
    RTPControl ctl = (RTPControl)source.getControl("javax.media.rtp.RTPControl");
    if (ctl != null)
      ctl.addFormat((Format)new AudioFormat("dvi/rtp", 44100.0D, 4, 1), 18); 
  }
  
  private void invalidateComp() {
    ((BasicPlayer)this).controlComp = null;
    ((BasicPlayer)this).controls = null;
  }
  
  public Component getVisualComponent() {
    super.getVisualComponent();
    return this.processor.getVisualComponent();
  }
  
  public Control[] getControls() {
    return this.processor.getControls();
  }
  
  public void updateStats() {
    if (this.processor != null)
      ((BasicProcessor)this.processor).updateStats(); 
  }
  
  public TrackControl[] getTrackControls() throws NotConfiguredError {
    super.getTrackControls();
    return this.processor.getTrackControls();
  }
  
  public ContentDescriptor[] getSupportedContentDescriptors() throws NotConfiguredError {
    super.getSupportedContentDescriptors();
    return this.processor.getSupportedContentDescriptors();
  }
  
  public ContentDescriptor setContentDescriptor(ContentDescriptor ocd) throws NotConfiguredError {
    super.setContentDescriptor(ocd);
    return this.processor.setContentDescriptor(ocd);
  }
  
  public ContentDescriptor getContentDescriptor() throws NotConfiguredError {
    super.getContentDescriptor();
    return this.processor.getContentDescriptor();
  }
  
  public DataSource getDataOutput() throws NotRealizedError {
    super.getDataOutput();
    return this.processor.getDataOutput();
  }
  
  private boolean waitForConfigure(Processor p) {
    return (new StateWaiter(this)).waitForConfigure(p);
  }
  
  private boolean waitForRealize(Processor p) {
    return (new StateWaiter(this)).waitForRealize(p);
  }
  
  private void waitForStart(Player p) {
    (new StateWaiter(this)).waitForStart(p, true);
  }
  
  private void waitForStop(Player p) {
    (new StateWaiter(this)).waitForStart(p, false);
  }
  
  private void waitForClose(Player p) {
    (new StateWaiter(this)).waitForClose(p);
  }
  
  class StateWaiter implements ControllerListener {
    boolean closeDown;
    
    Object stateLock;
    
    private final Handler this$0;
    
    StateWaiter(Handler this$0) {
      this.this$0 = this$0;
      this.closeDown = false;
      this.stateLock = new Object();
    }
    
    public boolean waitForConfigure(Processor p) {
      p.addControllerListener(this);
      p.configure();
      synchronized (this.stateLock) {
        while (p.getState() != 180 && !this.closeDown) {
          try {
            this.stateLock.wait(1000L);
          } catch (InterruptedException ie) {
            break;
          } 
        } 
      } 
      p.removeControllerListener(this);
      return !this.closeDown;
    }
    
    public boolean waitForRealize(Processor p) {
      p.addControllerListener(this);
      p.realize();
      synchronized (this.stateLock) {
        while (p.getState() != 300 && !this.closeDown) {
          try {
            this.stateLock.wait(1000L);
          } catch (InterruptedException ie) {
            break;
          } 
        } 
      } 
      p.removeControllerListener(this);
      return !this.closeDown;
    }
    
    public void waitForStart(Player p, boolean startOn) {
      p.addControllerListener(this);
      if (startOn) {
        p.start();
      } else {
        p.stop();
      } 
      synchronized (this.stateLock) {
        while (((startOn && p.getState() != 600) || (!startOn && p.getState() == 600)) && !this.closeDown) {
          try {
            this.stateLock.wait(1000L);
          } catch (InterruptedException ie) {
            break;
          } 
        } 
      } 
      p.removeControllerListener(this);
    }
    
    public void waitForClose(Player p) {
      p.addControllerListener(this);
      p.close();
      synchronized (this.stateLock) {
        while (!this.closeDown) {
          try {
            this.stateLock.wait(1000L);
          } catch (InterruptedException ie) {
            break;
          } 
        } 
      } 
      p.removeControllerListener(this);
    }
    
    public void controllerUpdate(ControllerEvent ce) {
      if (ce instanceof javax.media.ControllerClosedEvent || ce instanceof ControllerErrorEvent)
        this.closeDown = true; 
      synchronized (this.stateLock) {
        this.stateLock.notify();
      } 
    }
  }
}
