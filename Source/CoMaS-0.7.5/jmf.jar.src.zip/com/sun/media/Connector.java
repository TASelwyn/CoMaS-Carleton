package com.sun.media;

import javax.media.Format;

public interface Connector {
  public static final int ProtocolPush = 0;
  
  public static final int ProtocolSafe = 1;
  
  void setFormat(Format paramFormat);
  
  Format getFormat();
  
  void setSize(int paramInt);
  
  int getSize();
  
  void reset();
  
  String getName();
  
  void setName(String paramString);
  
  void setProtocol(int paramInt);
  
  int getProtocol();
  
  Object getCircularBuffer();
  
  void setCircularBuffer(Object paramObject);
  
  void setModule(Module paramModule);
  
  Module getModule();
}
