package com.sun.media.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.CardLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Panel;
import java.awt.Rectangle;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;

public class TabControl extends Panel implements MouseListener, FocusListener, KeyListener, ComponentListener {
  public static final int ALIGN_TOP = 0;
  
  public static final int ALIGN_LEFT = 1;
  
  private Panel panelPageContainer;
  
  private CardLayout layoutCard = new CardLayout();
  
  private int nCurrentPage = -1;
  
  private Button buttonFocus;
  
  private boolean boolFocus = false;
  
  private int nAlignment = 0;
  
  private int MARGIN_PAGE_VERT = 6;
  
  private int MARGIN_PAGE_HORZ = 6;
  
  private String strPageToShowAfterPaint = null;
  
  private Cursor cursorNormal = new Cursor(0);
  
  private Cursor cursorWait = new Cursor(3);
  
  private Vector vectorTabs = new Vector();
  
  private int nTabHeightMax = 1;
  
  private int nTabWidthMax = 1;
  
  private int nRowCount = 1;
  
  public TabControl() {
    this(0);
  }
  
  public TabControl(int nAlignment) {
    this.nAlignment = nAlignment;
    try {
      init();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  private void init() throws Exception {
    setLayout(new BorderLayout());
    addComponentListener(this);
    addMouseListener(this);
    this.buttonFocus = new Button("Focus");
    add(this.buttonFocus);
    this.buttonFocus.addKeyListener(this);
    this.buttonFocus.addFocusListener(this);
    this.panelPageContainer = new Panel(this.layoutCard);
    add(this.panelPageContainer, "Center");
    Font fontOld = this.panelPageContainer.getFont();
    if (fontOld == null)
      fontOld = new Font("Dialog", 0, 12); 
    Font font = new Font("Dialog", 0, 12);
    setFont(font);
    this.panelPageContainer.setFont(fontOld);
    setBackground(TabField.COLOR_BG);
    this.panelPageContainer.setBackground(TabField.COLOR_BG);
  }
  
  public int addPage(Panel panelPage, String strTitle) {
    int nIndex = addPage(panelPage, strTitle, null);
    return nIndex;
  }
  
  public int addPage(Panel panelPage, String strTitle, Image image) {
    int nIndex = this.vectorTabs.size();
    TabField tabField = new TabField(this, panelPage, strTitle, image);
    this.vectorTabs.addElement(tabField);
    this.panelPageContainer.add(panelPage, strTitle);
    if (nIndex == 0) {
      this.nCurrentPage = 0;
      this.layoutCard.show(this.panelPageContainer, strTitle);
    } 
    tabField.calculateTabDimension(getFontMetrics(getFont()));
    this.nTabHeightMax = Math.max(tabField.dim.height, this.nTabHeightMax);
    this.nTabWidthMax = Math.max(tabField.dim.width, this.nTabWidthMax);
    recalculateTabs();
    repaint();
    return nIndex;
  }
  
  public int setPageImage(Panel panelPage, Image imageTab) {
    int nIndex = findPage(panelPage);
    if (nIndex < 0 || nIndex >= this.vectorTabs.size())
      return nIndex; 
    TabField tabField = this.vectorTabs.elementAt(nIndex);
    if (tabField.image == imageTab)
      return nIndex; 
    tabField.image = imageTab;
    this.nTabHeightMax = 1;
    this.nTabWidthMax = 1;
    int nCount = this.vectorTabs.size();
    for (int i = 0; i < nCount; i++) {
      tabField = this.vectorTabs.elementAt(i);
      tabField.calculateTabDimension(getFontMetrics(getFont()));
      this.nTabHeightMax = Math.max(tabField.dim.height, this.nTabHeightMax);
      this.nTabWidthMax = Math.max(tabField.dim.width, this.nTabWidthMax);
    } 
    recalculateTabs();
    repaint();
    return nIndex;
  }
  
  public Dimension getPreferredSize() {
    Dimension dim = super.getPreferredSize();
    if (this.nAlignment == 1) {
      dim.height = Math.max(dim.height, this.nTabHeightMax * this.vectorTabs.size() + 1);
    } else {
      int nRowWidth = 0;
      for (int i = 0; i < this.vectorTabs.size(); i++) {
        TabField tabField = this.vectorTabs.elementAt(i);
        nRowWidth += tabField.dim.width;
      } 
      dim.width = Math.max(dim.width, nRowWidth + 1);
    } 
    return dim;
  }
  
  public Insets getInsets() {
    Insets insets = super.getInsets();
    if (this.nAlignment == 1) {
      insets = new Insets(insets.top + this.MARGIN_PAGE_VERT, insets.left + this.nRowCount * this.nTabWidthMax - 2 + this.MARGIN_PAGE_HORZ, insets.bottom + this.MARGIN_PAGE_VERT, insets.right + this.MARGIN_PAGE_HORZ);
    } else {
      insets = new Insets(insets.top + this.nRowCount * this.nTabHeightMax - 2 + this.MARGIN_PAGE_VERT, insets.left + this.MARGIN_PAGE_HORZ, insets.bottom + this.MARGIN_PAGE_VERT, insets.right + this.MARGIN_PAGE_HORZ);
    } 
    return insets;
  }
  
  public void update(Graphics g) {
    Graphics graphics;
    Rectangle rectClient = getBounds();
    if (rectClient.width < 1 || rectClient.height < 1)
      return; 
    Image image = createImage(rectClient.width, rectClient.height);
    if (image != null) {
      graphics = image.getGraphics();
    } else {
      graphics = g;
    } 
    paint(graphics);
    if (image != null)
      g.drawImage(image, 0, 0, this); 
  }
  
  public void paint(Graphics graphics) {
    super.paint(graphics);
    Rectangle rectClient = getBounds();
    rectClient.x = 0;
    rectClient.y = 0;
    Rectangle rect = new Rectangle(rectClient);
    if (this.nAlignment == 1) {
      rect.x += this.nTabWidthMax * this.nRowCount - 2;
      rect.width -= this.nTabWidthMax * this.nRowCount - 2;
    } else {
      rect.y += this.nTabHeightMax * this.nRowCount - 2;
      rect.height -= this.nTabHeightMax * this.nRowCount - 2;
    } 
    rect.width--;
    rect.height--;
    graphics.setColor(TabField.COLOR_SHADOW_BOTTOM);
    graphics.drawRect(rect.x, rect.y, rect.width, rect.height);
    graphics.setColor(TabField.COLOR_SHADOW_TOP);
    graphics.drawLine(rect.x + 1, rect.y + 1, rect.x + 1, rect.y + rect.height - 2);
    graphics.drawLine(rect.x + 1, rect.y + 1, rect.x + rect.width - 2, rect.y + 1);
    Font fontNormal = getFont();
    Font fontBold = fontNormal;
    int nSize = this.vectorTabs.size();
    for (int i = nSize - 1; i >= 0; i--) {
      FontMetrics fontMetrics;
      TabField tabField = this.vectorTabs.elementAt(i);
      if (i == this.nCurrentPage) {
        if (this.nAlignment == 1) {
          tabField.drawCurrentTabLeft(graphics);
        } else {
          tabField.drawCurrentTabTop(graphics);
        } 
      } else if (this.nAlignment == 1) {
        tabField.drawTabLeft(graphics);
      } else {
        tabField.drawTabTop(graphics);
      } 
      graphics.setColor(getForeground());
      Rectangle rectString = new Rectangle(tabField.rect);
      if (this.nAlignment == 1) {
        rectString.width = this.nTabWidthMax;
      } else {
        rectString.height = this.nTabHeightMax;
      } 
      if (tabField.image != null) {
        int nWidth = tabField.image.getWidth(this);
        rectString.x += nWidth + tabField.MARGIN_TAB_HORZ;
        rectString.width -= nWidth + tabField.MARGIN_TAB_HORZ;
      } 
      rectString.y++;
      if (i == this.nCurrentPage) {
        graphics.setFont(fontBold);
        fontMetrics = graphics.getFontMetrics(fontBold);
        if (this.boolFocus == true) {
          int m = fontMetrics.stringWidth(tabField.strTitle) + 6;
          int nHeight = fontMetrics.getHeight() + 1;
          int nX = rectString.x + (rectString.width - m) / 2;
          int nY = rectString.y + (this.nTabHeightMax - 2 - nHeight) / 2 + 1;
          drawDottedRectangle(graphics, nX, nY, m, nHeight);
        } 
      } else {
        graphics.setFont(fontNormal);
        fontMetrics = graphics.getFontMetrics(fontNormal);
      } 
      int j = rectString.x + (rectString.width - fontMetrics.stringWidth(tabField.strTitle)) / 2;
      int k = rectString.y + rectString.height - (rectString.height - fontMetrics.getHeight()) / 2 - fontMetrics.getMaxDescent();
      k--;
      if (i != this.nCurrentPage) {
        j++;
        k++;
      } 
      graphics.drawString(tabField.strTitle, j, k);
      if (tabField.image != null) {
        int m = tabField.image.getHeight(this);
        j = tabField.rect.x + tabField.MARGIN_TAB_HORZ;
        k = tabField.rect.y + (this.nTabHeightMax - m) / 2;
        if (i != this.nCurrentPage) {
          j++;
          k++;
        } 
        graphics.drawImage(tabField.image, j, k, this);
      } 
    } 
    if (this.strPageToShowAfterPaint != null) {
      this.layoutCard.show(this.panelPageContainer, this.strPageToShowAfterPaint);
      this.strPageToShowAfterPaint = null;
      setCursor(this.cursorNormal);
    } 
  }
  
  private void drawDottedRectangle(Graphics graphics, int nX, int nY, int nWidth, int nHeight) {
    drawDottedLine(graphics, nX, nY, nX + nWidth - 1, nY);
    drawDottedLine(graphics, nX + nWidth - 1, nY, nX + nWidth - 1, nY + nHeight - 1);
    drawDottedLine(graphics, nX + nWidth - 1, nY + nHeight - 1, nX, nY + nHeight - 1);
    drawDottedLine(graphics, nX, nY + nHeight - 1, nX, nY);
  }
  
  private void drawDottedLine(Graphics graphics, int nX1, int nY1, int nX2, int nY2) {
    if (nX1 == nX2 && nY1 == nY2) {
      drawDot(graphics, nX1, nY1);
      return;
    } 
    if (nX1 > nX2) {
      int nX = nX1;
      nX1 = nX2;
      nX2 = nX;
    } 
    if (nY1 > nY2) {
      int nY = nY1;
      nY1 = nY2;
      nY2 = nY;
    } 
    if (nX2 - nX1 > nY2 - nY1) {
      double dDiv = (nY2 - nY1) / (nX2 - nX1);
      for (int i = nX1; i <= nX2; i++) {
        int j = (int)Math.rint(nY1 + (i - nX1) * dDiv);
        drawDot(graphics, i, j);
      } 
    } else {
      double d = ((nX2 - nX1) / (nY2 - nY1));
      for (int i = nY1; i <= nY2; i++) {
        int j = (int)Math.rint(nX1 + (i - nY1) * d);
        drawDot(graphics, j, i);
      } 
    } 
  }
  
  private void drawDot(Graphics graphics, int nX, int nY) {
    if ((nX + nY) % 2 == 0)
      graphics.drawLine(nX, nY, nX, nY); 
  }
  
  public void mouseClicked(MouseEvent event) {}
  
  public void mousePressed(MouseEvent event) {
    int x = event.getX();
    int y = event.getY();
    int nTabCount = this.vectorTabs.size();
    for (int i = 0; i < nTabCount; i++) {
      TabField tabField = this.vectorTabs.elementAt(i);
      if (tabField.rect.contains(x, y)) {
        this.buttonFocus.requestFocus();
        this.nCurrentPage = i;
        this.strPageToShowAfterPaint = tabField.strTitle;
        setCursor(this.cursorWait);
        repaint();
        break;
      } 
    } 
  }
  
  public void mouseReleased(MouseEvent event) {}
  
  public void mouseEntered(MouseEvent event) {}
  
  public void mouseExited(MouseEvent event) {}
  
  public void keyTyped(KeyEvent event) {}
  
  public void keyPressed(KeyEvent event) {
    int nIndex = this.nCurrentPage;
    int nKeyCode = event.getKeyCode();
    if (nKeyCode == 40 || nKeyCode == 39) {
      nIndex++;
    } else if (nKeyCode == 38 || nKeyCode == 37) {
      nIndex--;
    } 
    if (nIndex >= this.vectorTabs.size())
      nIndex = this.vectorTabs.size() - 1; 
    if (nIndex < 0)
      nIndex = 0; 
    if (this.nCurrentPage != nIndex) {
      this.nCurrentPage = nIndex;
      TabField tabField = this.vectorTabs.elementAt(nIndex);
      this.strPageToShowAfterPaint = tabField.strTitle;
      setCursor(this.cursorWait);
      repaint();
    } 
  }
  
  public void keyReleased(KeyEvent event) {}
  
  public void focusGained(FocusEvent event) {
    if (this.boolFocus == true)
      return; 
    this.boolFocus = true;
    repaint();
  }
  
  public void focusLost(FocusEvent event) {
    if (!this.boolFocus)
      return; 
    this.boolFocus = false;
    repaint();
  }
  
  public void componentResized(ComponentEvent event) {
    recalculateTabs();
    doLayout();
    this.panelPageContainer.validate();
  }
  
  public void componentMoved(ComponentEvent event) {}
  
  public void componentShown(ComponentEvent event) {}
  
  public void componentHidden(ComponentEvent event) {}
  
  private void recalculateTabs() {
    int nRowSize = 1;
    Rectangle rectClient = getBounds();
    rectClient.x = 0;
    rectClient.y = 0;
    if (rectClient.width < 1 || rectClient.height < 1)
      return; 
    int nTabCount = this.vectorTabs.size();
    if (this.nAlignment == 1) {
      nRowSize = rectClient.height / this.nTabHeightMax;
      this.nRowCount = (nTabCount + nRowSize - 1) / nRowSize;
      int nOffsetX = this.nRowCount * this.nTabWidthMax;
      int nOffsetY = 0;
      for (int i = 0; i < nTabCount; i++) {
        if (i % nRowSize == 0) {
          nOffsetX -= this.nTabWidthMax;
          nOffsetY = 0;
        } 
        TabField tabField = this.vectorTabs.elementAt(i);
        tabField.rect.x = nOffsetX;
        tabField.rect.y = nOffsetY;
        tabField.rect.width = this.nTabWidthMax * (i / nRowSize + 1);
        tabField.rect.height = this.nTabHeightMax;
        tabField.nRowIndex = i / nRowSize;
        if (tabField.nRowIndex > 0)
          tabField.rect.width -= 2; 
        nOffsetY += this.nTabHeightMax;
      } 
    } else {
      this.nRowCount = 1;
      int nRowWidth = 0;
      byte b;
      for (b = 0; b < nTabCount; b++) {
        TabField tabField = this.vectorTabs.elementAt(b);
        if (nRowWidth + tabField.dim.width > rectClient.width) {
          nRowWidth = 0;
          this.nRowCount++;
        } 
        nRowWidth += tabField.dim.width;
      } 
      int i = 0;
      int k = this.nRowCount * this.nTabHeightMax;
      int nRowIndex = 0;
      int j = 0;
      for (b = 0; b < nTabCount; b++) {
        if (b == j) {
          i = 0;
          k -= this.nTabHeightMax;
          nRowWidth = 0;
          for (j = b; j < nTabCount; j++) {
            TabField tabField1 = this.vectorTabs.elementAt(j);
            if (j > b && nRowWidth + tabField1.dim.width > rectClient.width)
              break; 
            nRowWidth += tabField1.dim.width;
            tabField1.nRowIndex = nRowIndex;
          } 
          nRowSize = j - b;
          nRowIndex++;
        } 
        TabField tabField = this.vectorTabs.elementAt(b);
        tabField.rect.x = i;
        tabField.rect.y = k;
        tabField.rect.width = tabField.dim.width;
        if (this.nRowCount > 1 && nRowIndex < this.nRowCount) {
          tabField.rect.width += (rectClient.width - nRowWidth - 1) / nRowSize;
          tabField.rect.width += (j - b > (rectClient.width - nRowWidth - 1) % nRowSize) ? 0 : 1;
        } 
        tabField.rect.height = this.nTabHeightMax * nRowIndex;
        if (tabField.nRowIndex > 0)
          tabField.rect.height -= 2; 
        i += tabField.rect.width;
      } 
    } 
    repaint();
  }
  
  private int findPage(Panel panelPage) {
    int i = this.vectorTabs.size() - 1;
    while (i >= 0) {
      TabField tabField = this.vectorTabs.elementAt(i);
      if (tabField.panelPage == panelPage)
        break; 
      i--;
    } 
    return i;
  }
}
