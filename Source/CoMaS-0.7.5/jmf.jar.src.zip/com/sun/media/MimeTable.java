package com.sun.media;

import java.util.Hashtable;

final class MimeTable extends Hashtable {
  public final synchronized void clear() {}
  
  public final synchronized Object put(Object key, Object value) {
    return null;
  }
  
  public final synchronized Object remove(Object key) {
    return null;
  }
  
  protected final synchronized boolean doPut(String key, String value) {
    if (!MimeManager.defaultHashTable.containsKey(key)) {
      super.put(key, value);
      if (MimeManager.extTable.get(value) == null)
        MimeManager.extTable.put(value, key); 
      return true;
    } 
    System.err.println("Cannot override default mime-table entries");
    return false;
  }
  
  protected final synchronized boolean doRemove(String key) {
    if (!MimeManager.defaultHashTable.containsKey(key)) {
      if (get(key) != null)
        MimeManager.extTable.remove(get(key)); 
      return (super.remove(key) != null);
    } 
    return false;
  }
}
