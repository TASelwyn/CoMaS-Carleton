package com.sun.media.rtp;

import com.sun.media.rtp.util.RTPPacket;

public class SourceRTPPacket {
  RTPPacket p;
  
  SSRCInfo ssrcinfo;
  
  public SourceRTPPacket(RTPPacket p, SSRCInfo ssrcinfo) {
    this.p = p;
    this.ssrcinfo = ssrcinfo;
  }
}
