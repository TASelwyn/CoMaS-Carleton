package com.sun.media.rtp;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import com.sun.media.JMFSecurity;
import com.sun.media.JMFSecurityManager;
import com.sun.media.rtp.util.SSRCTable;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.media.Format;
import javax.media.format.AudioFormat;
import javax.media.rtp.ReceiveStream;
import javax.media.rtp.event.LocalCollisionEvent;
import javax.media.rtp.event.RTPEvent;
import javax.media.rtp.event.RemoteCollisionEvent;

public class SSRCCache {
  SSRCTable cache = new SSRCTable();
  
  RTPSourceInfoCache sourceInfoCache;
  
  OverallStats stats = null;
  
  OverallTransStats transstats = null;
  
  RTPEventHandler eventhandler;
  
  int[] clockrate = new int[128];
  
  static final int DATA = 1;
  
  static final int CONTROL = 2;
  
  static final int SRCDATA = 3;
  
  static final int RTCP_MIN_TIME = 5000;
  
  static final int BYE_THRESHOLD = 50;
  
  int sendercount = 0;
  
  double rtcp_bw_fraction = 0.0D;
  
  double rtcp_sender_bw_fraction = 0.0D;
  
  int rtcp_min_time = 5000;
  
  private static final int NOTIFYPERIOD = 500;
  
  int sessionbandwidth = 0;
  
  boolean initial = true;
  
  boolean byestate = false;
  
  boolean rtcpsent = false;
  
  int avgrtcpsize = 128;
  
  Hashtable conflicttable = new Hashtable(5);
  
  SSRCInfo ourssrc = null;
  
  public RTPSessionMgr sm;
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] m = new Method[1];
  
  private Class[] cl = new Class[1];
  
  private Object[][] args = new Object[1][0];
  
  static {
    try {
      jmfSecurity = JMFSecurityManager.getJMFSecurity();
      securityPrivelege = true;
    } catch (SecurityException e) {}
  }
  
  SSRCCache(RTPSessionMgr sm) {
    if (jmfSecurity != null) {
      String permission = null;
      try {
        if (jmfSecurity.getName().startsWith("jmf-security")) {
          permission = "thread";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
          this.m[0].invoke(this.cl[0], this.args[0]);
          permission = "thread group";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
          this.m[0].invoke(this.cl[0], this.args[0]);
        } else if (jmfSecurity.getName().startsWith("internet")) {
          PolicyEngine.checkPermission(PermissionID.THREAD);
          PolicyEngine.assertPermission(PermissionID.THREAD);
        } 
      } catch (Throwable e) {
        if (permission.endsWith("group")) {
          jmfSecurity.permissionFailureNotification(32);
        } else {
          jmfSecurity.permissionFailureNotification(16);
        } 
      } 
    } 
    this.stats = sm.defaultstats;
    this.transstats = sm.transstats;
    this.sourceInfoCache = new RTPSourceInfoCache();
    this.sourceInfoCache.setMainCache(this.sourceInfoCache);
    this.sourceInfoCache.setSSRCCache(this);
    this.sm = sm;
    this.eventhandler = new RTPEventHandler(sm);
    setclockrates();
  }
  
  SSRCCache(RTPSessionMgr sm, RTPSourceInfoCache sic) {
    this.stats = sm.defaultstats;
    this.transstats = sm.transstats;
    this.sourceInfoCache = sic;
    sic.setSSRCCache(this);
    this.sm = sm;
    this.eventhandler = new RTPEventHandler(sm);
  }
  
  int aliveCount() {
    int tot = 0;
    Enumeration e = this.cache.elements();
    while (e.hasMoreElements()) {
      SSRCInfo s = e.nextElement();
      if (s.alive)
        tot++; 
    } 
    return tot;
  }
  
  void setclockrates() {
    for (int i = 0; i < 16; i++)
      this.clockrate[i] = 8000; 
    this.clockrate[6] = 16000;
    this.clockrate[10] = 44100;
    this.clockrate[11] = 44100;
    this.clockrate[14] = 90000;
    this.clockrate[16] = 11025;
    this.clockrate[17] = 22050;
    this.clockrate[18] = 44100;
    for (int j = 24; j < 34; j++)
      this.clockrate[j] = 90000; 
    for (int k = 96; k < 128; k++) {
      Format fmt = this.sm.formatinfo.get(k);
      if (fmt != null && fmt instanceof AudioFormat) {
        this.clockrate[k] = (int)((AudioFormat)fmt).getSampleRate();
      } else {
        this.clockrate[k] = 90000;
      } 
    } 
  }
  
  synchronized void destroy() {
    this.cache.removeAll();
    if (this.eventhandler != null)
      this.eventhandler.close(); 
  }
  
  SSRCInfo lookup(int ssrc) {
    return (SSRCInfo)this.cache.get(ssrc);
  }
  
  SSRCInfo get(int ssrc, InetAddress address, int port, int mode) {
    SSRCInfo info = null;
    boolean localcollision = false;
    synchronized (this) {
      if (this.ourssrc != null && this.ourssrc.ssrc == ssrc && this.ourssrc.address != null && !this.ourssrc.address.equals(address)) {
        localcollision = true;
        LocalCollision(ssrc);
      } 
      info = lookup(ssrc);
      if (info != null)
        synchronized (info) {
          if (info.address == null || !info.alive) {
            info.address = address;
            info.port = port;
          } else if (!info.address.equals(address)) {
            if (info.probation > 0) {
              info.probation = 2;
              info.address = address;
              info.port = port;
            } else {
              this.stats.update(4, 1);
              this.transstats.remote_coll++;
              RemoteCollisionEvent evt = new RemoteCollisionEvent(this.sm, info.ssrc);
              this.eventhandler.postEvent((RTPEvent)evt);
              return null;
            } 
          } 
        }  
      if (info != null && mode == 1 && !(info instanceof RecvSSRCInfo)) {
        if (info.ours)
          return null; 
        SSRCInfo newinfo = new RecvSSRCInfo(info);
        info = newinfo;
        this.cache.put(ssrc, info);
      } 
      if (info != null && mode == 2 && !(info instanceof PassiveSSRCInfo)) {
        if (info.ours)
          return null; 
        System.out.println("changing to Passive");
        System.out.println("existing one " + info);
        SSRCInfo newinfo = new PassiveSSRCInfo(info);
        System.out.println("new one is " + newinfo);
        info = newinfo;
        this.cache.put(ssrc, info);
      } 
      if (info == null) {
        if (mode == 3) {
          if (this.ourssrc != null && this.ourssrc.ssrc == ssrc)
            return this.ourssrc; 
          info = new SendSSRCInfo(this, ssrc);
          info.initsource((int)TrueRandom.rand());
        } 
        if (mode == 1)
          info = new RecvSSRCInfo(this, ssrc); 
        if (mode == 2)
          info = new PassiveSSRCInfo(this, ssrc); 
        if (info == null)
          return null; 
        info.address = address;
        info.port = port;
        this.cache.put(ssrc, info);
      } 
      if (info.address == null && info.port == 0) {
        info.address = address;
        info.port = port;
      } 
      if (localcollision) {
        LocalCollisionEvent levt = null;
        if (info instanceof RecvSSRCInfo) {
          levt = new LocalCollisionEvent(this.sm, (ReceiveStream)info, this.ourssrc.ssrc);
        } else {
          levt = new LocalCollisionEvent(this.sm, null, this.ourssrc.ssrc);
        } 
        this.eventhandler.postEvent((RTPEvent)levt);
      } 
    } 
    return info;
  }
  
  private void changessrc(SSRCInfo info) {
    info.setOurs(true);
    if (this.ourssrc != null) {
      info.sourceInfo = this.sourceInfoCache.get(this.ourssrc.sourceInfo.getCNAME(), info.ours);
      info.sourceInfo.addSSRC(info);
    } 
    info.reporter.releasessrc("Local Collision Detected");
    this.ourssrc = info;
    info.reporter.restart = true;
  }
  
  private void LocalCollision(int ssrc) {
    int newssrc = 0;
    while (true) {
      newssrc = (int)TrueRandom.rand();
      if (lookup(newssrc) != null)
        continue; 
      break;
    } 
    SSRCInfo newinfo = new PassiveSSRCInfo(this.ourssrc);
    newinfo.ssrc = newssrc;
    this.cache.put(newssrc, newinfo);
    changessrc(newinfo);
    this.ourssrc = newinfo;
    this.stats.update(3, 1);
    this.transstats.local_coll++;
  }
  
  SSRCInfo get(int ssrc, InetAddress address, int port) {
    synchronized (this) {
      SSRCInfo info = lookup(ssrc);
      return info;
    } 
  }
  
  void remove(int ssrc) {
    SSRCInfo info = (SSRCInfo)this.cache.remove(ssrc);
    if (info != null)
      info.delete(); 
  }
  
  int getSessionBandwidth() {
    if (this.sessionbandwidth == 0)
      throw new IllegalArgumentException("Session Bandwidth not set"); 
    return this.sessionbandwidth;
  }
  
  double calcReportInterval(boolean sender, boolean recvfromothers) {
    this.rtcp_min_time = 5000;
    double rtcp_bw = this.rtcp_bw_fraction;
    if (this.initial)
      this.rtcp_min_time /= 2; 
    int n = aliveCount();
    if (this.sendercount > 0 && this.sendercount < n * this.rtcp_sender_bw_fraction)
      if (sender) {
        rtcp_bw *= this.rtcp_sender_bw_fraction;
        n = this.sendercount;
      } else {
        rtcp_bw *= 1.0D - this.rtcp_sender_bw_fraction;
        n -= this.sendercount;
      }  
    if (recvfromothers && rtcp_bw == 0.0D) {
      rtcp_bw = 0.05D;
      if (this.sendercount > 0 && this.sendercount < n * 0.25D)
        if (sender) {
          rtcp_bw *= 0.25D;
          n = this.sendercount;
        } else {
          rtcp_bw *= 0.75D;
          n -= this.sendercount;
        }  
    } 
    double time = 0.0D;
    if (rtcp_bw != 0.0D) {
      time = (this.avgrtcpsize * n) / rtcp_bw;
      if (time < this.rtcp_min_time)
        time = this.rtcp_min_time; 
    } 
    if (recvfromothers)
      return time; 
    return time * (Math.random() + 0.5D);
  }
  
  synchronized void updateavgrtcpsize(int size) {
    this.avgrtcpsize = (int)(0.0625D * size + 0.9375D * this.avgrtcpsize);
  }
  
  RTPSourceInfoCache getRTPSICache() {
    return this.sourceInfoCache;
  }
  
  SSRCTable getMainCache() {
    return this.cache;
  }
  
  public void reset(int size) {
    this.initial = true;
    this.sendercount = 0;
    this.avgrtcpsize = size;
  }
}
