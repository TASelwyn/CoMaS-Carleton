package com.sun.media.rtp;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import com.sun.media.JMFSecurity;
import com.sun.media.JMFSecurityManager;
import com.sun.media.Log;
import com.sun.media.rtp.util.RTPMediaThread;
import com.sun.media.util.MediaThread;
import com.sun.media.util.jdk12;
import com.sun.media.util.jdk12CreateThreadRunnableAction;
import com.sun.media.util.jdk12PriorityAction;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.util.Random;

public class RTCPReporter implements Runnable {
  RTCPTransmitter transmit;
  
  SSRCCache cache;
  
  RTPMediaThread reportthread;
  
  Random myrand;
  
  boolean restart = false;
  
  boolean closed = false;
  
  InetAddress host;
  
  String cname;
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] m = new Method[1];
  
  private Class[] cl = new Class[1];
  
  private Object[][] args = new Object[1][0];
  
  static {
    try {
      jmfSecurity = JMFSecurityManager.getJMFSecurity();
      securityPrivelege = true;
    } catch (SecurityException e) {}
  }
  
  public RTCPReporter(SSRCCache cache, RTCPTransmitter t) {
    this.cache = cache;
    setTransmitter(t);
    if (jmfSecurity != null) {
      String permission = null;
      try {
        if (jmfSecurity.getName().startsWith("jmf-security")) {
          permission = "thread";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
          this.m[0].invoke(this.cl[0], this.args[0]);
          permission = "thread group";
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
          this.m[0].invoke(this.cl[0], this.args[0]);
        } else if (jmfSecurity.getName().startsWith("internet")) {
          PolicyEngine.checkPermission(PermissionID.THREAD);
          PolicyEngine.assertPermission(PermissionID.THREAD);
        } 
      } catch (Throwable e) {
        if (permission.endsWith("group")) {
          jmfSecurity.permissionFailureNotification(32);
        } else {
          jmfSecurity.permissionFailureNotification(16);
        } 
      } 
    } 
    if (jmfSecurity != null && jmfSecurity.getName().startsWith("jdk12")) {
      try {
        Constructor cons = jdk12CreateThreadRunnableAction.cons;
        this.reportthread = (RTPMediaThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { RTPMediaThread.class, this }) });
        this.reportthread.setName("RTCP Reporter");
        cons = jdk12PriorityAction.cons;
        jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { this.reportthread, new Integer(MediaThread.getControlPriority()) }) });
      } catch (Exception e) {}
    } else {
      this.reportthread = new RTPMediaThread(this, "RTCP Reporter");
      this.reportthread.useControlPriority();
    } 
    this.reportthread.setDaemon(true);
    this.reportthread.start();
  }
  
  public void setTransmitter(RTCPTransmitter t) {
    this.transmit = t;
  }
  
  public void close(String reason) {
    synchronized (this.reportthread) {
      this.closed = true;
      this.reportthread.notify();
    } 
    releasessrc(reason);
    this.transmit.close();
  }
  
  public void releasessrc(String reason) {
    this.transmit.bye(reason);
    this.transmit.ssrcInfo.setOurs(false);
    this.transmit.ssrcInfo = null;
  }
  
  public void run() {
    if (jmfSecurity != null)
      try {
        if (jmfSecurity.getName().startsWith("jmf-security")) {
          jmfSecurity.requestPermission(this.m, this.cl, this.args, 128);
          this.m[0].invoke(this.cl[0], this.args[0]);
        } else if (jmfSecurity.getName().startsWith("internet")) {
          PolicyEngine.checkPermission(PermissionID.NETIO);
          PolicyEngine.assertPermission(PermissionID.NETIO);
        } 
      } catch (Throwable e) {
        jmfSecurity.permissionFailureNotification(128);
      }  
    if (this.restart)
      this.restart = false; 
    while (true) {
      double delay = this.cache.calcReportInterval(this.cache.ourssrc.sender, false);
      synchronized (this.reportthread) {
        try {
          this.reportthread.wait((long)delay);
        } catch (InterruptedException e) {
          Log.dumpStack(e);
        } 
      } 
      if (this.closed)
        return; 
      if (!this.restart) {
        this.transmit.report();
        continue;
      } 
      this.restart = false;
    } 
  }
}
