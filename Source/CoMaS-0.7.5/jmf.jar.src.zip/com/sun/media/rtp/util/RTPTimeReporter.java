package com.sun.media.rtp.util;

public interface RTPTimeReporter {
  long getRTPTime();
}
