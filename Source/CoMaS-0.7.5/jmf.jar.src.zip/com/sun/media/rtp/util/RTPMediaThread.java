package com.sun.media.rtp.util;

import com.sun.media.util.MediaThread;

public class RTPMediaThread extends MediaThread {
  public RTPMediaThread() {
    this("RTP thread");
  }
  
  public RTPMediaThread(String name) {
    super(name);
  }
  
  public RTPMediaThread(Runnable r) {
    this(r, "RTP thread");
  }
  
  public RTPMediaThread(Runnable r, String name) {
    super(r, name);
  }
}
