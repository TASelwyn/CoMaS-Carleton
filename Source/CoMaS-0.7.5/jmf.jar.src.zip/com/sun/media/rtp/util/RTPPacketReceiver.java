package com.sun.media.rtp.util;

import com.sun.media.CircularBuffer;
import java.io.IOException;
import javax.media.Buffer;
import javax.media.protocol.PushSourceStream;
import javax.media.protocol.SourceTransferHandler;
import javax.media.rtp.RTPPushDataSource;

public class RTPPacketReceiver implements PacketSource, SourceTransferHandler {
  RTPPushDataSource rtpsource = null;
  
  CircularBuffer bufQue = new CircularBuffer(2);
  
  boolean closed = false;
  
  boolean dataRead;
  
  public void transferData(PushSourceStream sourcestream) {
    Buffer buf;
    synchronized (this.bufQue) {
      while (!this.bufQue.canWrite() && !this.closed) {
        try {
          this.bufQue.wait(1000L);
        } catch (InterruptedException e) {}
      } 
      if (this.closed)
        return; 
      buf = this.bufQue.getEmptyBuffer();
    } 
    int size = sourcestream.getMinimumTransferSize();
    byte[] data = (byte[])buf.getData();
    int len = 0;
    if (data == null || data.length < size) {
      data = new byte[size];
      buf.setData(data);
    } 
    try {
      len = sourcestream.read(data, 0, size);
    } catch (IOException e) {}
    buf.setLength(len);
    buf.setOffset(0);
    synchronized (this.bufQue) {
      this.bufQue.writeReport();
      this.bufQue.notify();
    } 
  }
  
  public RTPPacketReceiver(RTPPushDataSource rtpsource) {
    this.dataRead = false;
    this.rtpsource = rtpsource;
    PushSourceStream output = rtpsource.getOutputStream();
    output.setTransferHandler(this);
  }
  
  public RTPPacketReceiver(PushSourceStream pss) {
    this.dataRead = false;
    pss.setTransferHandler(this);
  }
  
  public Packet receiveFrom() throws IOException {
    Buffer buffer;
    byte[] arrayOfByte;
    synchronized (this.bufQue) {
      if (this.dataRead) {
        this.bufQue.readReport();
        this.bufQue.notify();
      } 
      while (!this.bufQue.canRead() && !this.closed) {
        try {
          this.bufQue.wait(1000L);
        } catch (InterruptedException e) {}
      } 
      if (this.closed) {
        buffer = null;
        this.dataRead = false;
      } else {
        buffer = this.bufQue.read();
        this.dataRead = true;
      } 
    } 
    if (buffer != null) {
      arrayOfByte = (byte[])buffer.getData();
    } else {
      arrayOfByte = new byte[1];
    } 
    UDPPacket p = new UDPPacket();
    p.receiptTime = System.currentTimeMillis();
    p.data = arrayOfByte;
    p.offset = 0;
    p.length = (buffer == null) ? 0 : buffer.getLength();
    return p;
  }
  
  public void closeSource() {
    synchronized (this.bufQue) {
      this.closed = true;
      this.bufQue.notifyAll();
    } 
  }
  
  public String sourceString() {
    String s = "RTPPacketReceiver for " + this.rtpsource;
    return s;
  }
}
