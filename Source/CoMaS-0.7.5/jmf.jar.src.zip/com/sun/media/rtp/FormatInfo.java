package com.sun.media.rtp;

import javax.media.Format;
import javax.media.format.AudioFormat;
import javax.media.format.VideoFormat;

public class FormatInfo {
  private SSRCCache cache = null;
  
  public static final int PAYLOAD_NOTFOUND = -1;
  
  Format[] formatList = new Format[64];
  
  static AudioFormat mpegAudio = new AudioFormat("mpegaudio/rtp");
  
  public FormatInfo() {
    initFormats();
  }
  
  public void setCache(SSRCCache cache) {
    this.cache = cache;
  }
  
  public void add(int payload, Format fmt) {
    if (payload >= this.formatList.length)
      expandTable(payload); 
    Format located;
    if ((located = this.formatList[payload]) != null)
      return; 
    this.formatList[payload] = fmt;
    if (this.cache != null && fmt instanceof VideoFormat)
      this.cache.clockrate[payload] = 90000; 
    if (this.cache != null && fmt instanceof AudioFormat)
      if (mpegAudio.matches(fmt)) {
        this.cache.clockrate[payload] = 90000;
      } else {
        this.cache.clockrate[payload] = (int)((AudioFormat)fmt).getSampleRate();
      }  
  }
  
  private void expandTable(int num) {
    Format[] newList = new Format[num + 1];
    for (int i = 0; i < this.formatList.length; i++)
      newList[i] = this.formatList[i]; 
    this.formatList = newList;
  }
  
  public Format get(int payload) {
    return (payload >= this.formatList.length) ? null : this.formatList[payload];
  }
  
  public int getPayload(Format fmt) {
    AudioFormat audioFormat;
    if (fmt.getEncoding() != null && fmt.getEncoding().equals("g729a/rtp"))
      audioFormat = new AudioFormat("g729/rtp"); 
    for (int i = 0; i < this.formatList.length; i++) {
      if (audioFormat.matches(this.formatList[i]))
        return i; 
    } 
    return -1;
  }
  
  public void initFormats() {
    this.formatList[0] = (Format)new AudioFormat("ULAW/rtp", 8000.0D, 8, 1);
    this.formatList[3] = (Format)new AudioFormat("gsm/rtp", 8000.0D, -1, 1);
    this.formatList[4] = (Format)new AudioFormat("g723/rtp", 8000.0D, -1, 1);
    this.formatList[5] = (Format)new AudioFormat("dvi/rtp", 8000.0D, 4, 1);
    this.formatList[14] = (Format)new AudioFormat("mpegaudio/rtp", -1.0D, -1, -1);
    this.formatList[15] = (Format)new AudioFormat("g728/rtp", 8000.0D, -1, 1);
    this.formatList[16] = (Format)new AudioFormat("dvi/rtp", 11025.0D, 4, 1);
    this.formatList[17] = (Format)new AudioFormat("dvi/rtp", 22050.0D, 4, 1);
    this.formatList[18] = (Format)new AudioFormat("g729/rtp", 8000.0D, -1, 1);
    this.formatList[26] = (Format)new VideoFormat("jpeg/rtp");
    this.formatList[31] = (Format)new VideoFormat("h261/rtp");
    this.formatList[32] = (Format)new VideoFormat("mpeg/rtp");
    this.formatList[34] = (Format)new VideoFormat("h263/rtp");
    this.formatList[42] = (Format)new VideoFormat("h263-1998/rtp");
  }
  
  public static boolean isSupported(int payload) {
    switch (payload) {
      case 0:
      case 3:
      case 4:
      case 5:
      case 6:
      case 14:
      case 15:
      case 16:
      case 17:
      case 18:
      case 26:
      case 31:
      case 32:
      case 34:
        return true;
    } 
    return false;
  }
}
