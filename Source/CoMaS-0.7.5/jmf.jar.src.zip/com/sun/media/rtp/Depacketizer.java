package com.sun.media.rtp;

import javax.media.Buffer;
import javax.media.Format;
import javax.media.PlugIn;

public interface Depacketizer extends PlugIn {
  public static final int DEPACKETIZER = 6;
  
  Format[] getSupportedInputFormats();
  
  Format setInputFormat(Format paramFormat);
  
  Format parse(Buffer paramBuffer);
}
