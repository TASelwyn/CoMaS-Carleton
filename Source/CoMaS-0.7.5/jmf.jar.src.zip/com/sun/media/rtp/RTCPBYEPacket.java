package com.sun.media.rtp;

import java.io.DataOutputStream;
import java.io.IOException;

public class RTCPBYEPacket extends RTCPPacket {
  int[] ssrc;
  
  byte[] reason;
  
  public RTCPBYEPacket(RTCPPacket parent) {
    super(parent);
    this.type = 203;
  }
  
  public RTCPBYEPacket(int[] ssrc, byte[] reason) {
    this.ssrc = ssrc;
    if (reason != null) {
      this.reason = reason;
    } else {
      this.reason = new byte[0];
    } 
    if (ssrc.length > 31)
      throw new IllegalArgumentException("Too many SSRCs"); 
  }
  
  public String toString() {
    return "\tRTCP BYE packet for sync source(s) " + toString(this.ssrc) + " for " + ((this.reason.length > 0) ? ("reason " + new String(this.reason)) : "no reason") + "\n";
  }
  
  public String toString(int[] ints) {
    if (ints.length == 0)
      return "(none)"; 
    String s = "" + ints[0];
    for (int i = 1; i < ints.length; i++)
      s = s + ", " + ints[i]; 
    return s;
  }
  
  public int calcLength() {
    return 4 + (this.ssrc.length << 2) + ((this.reason.length > 0) ? (this.reason.length + 4 & 0xFFFFFFFC) : 0);
  }
  
  void assemble(DataOutputStream out) throws IOException {
    out.writeByte(128 + this.ssrc.length);
    out.writeByte(203);
    out.writeShort(this.ssrc.length + ((this.reason.length > 0) ? (this.reason.length + 4 >> 2) : 0));
    for (int i = 0; i < this.ssrc.length; i++)
      out.writeInt(this.ssrc[i]); 
    if (this.reason.length > 0) {
      out.writeByte(this.reason.length);
      out.write(this.reason);
      for (int j = (this.reason.length + 4 & 0xFFFFFFFC) - this.reason.length - 1; j > 0; j--)
        out.writeByte(0); 
    } 
  }
}
