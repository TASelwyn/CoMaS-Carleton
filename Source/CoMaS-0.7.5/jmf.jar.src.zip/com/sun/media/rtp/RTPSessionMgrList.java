package com.sun.media.rtp;

import java.util.Hashtable;
import javax.media.rtp.SessionAddress;

public final class RTPSessionMgrList {
  private static Hashtable list = new Hashtable(5);
  
  public static void addRTPSM(RTPSessionMgr sm) {
    SessionAddress destaddr = sm.getSessionAddress();
    RTPSessionMgr mgr = (RTPSessionMgr)list.get(destaddr);
    if (mgr == null)
      list.put(destaddr, sm); 
  }
  
  public static RTPSessionMgr getRTPSM(SessionAddress destaddr) {
    RTPSessionMgr mgr = (RTPSessionMgr)list.get(destaddr);
    return mgr;
  }
  
  public static void removeRTPSM(RTPSessionMgr sm) {
    SessionAddress destaddr = sm.getSessionAddress();
    list.remove(destaddr);
  }
}
