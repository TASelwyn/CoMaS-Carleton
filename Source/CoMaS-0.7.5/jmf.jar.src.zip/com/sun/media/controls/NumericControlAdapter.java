package com.sun.media.controls;

import java.awt.Component;
import javax.media.Control;

public class NumericControlAdapter extends AtomicControlAdapter implements NumericControl {
  protected float lowerLimit;
  
  protected float upperLimit;
  
  protected float defaultValue;
  
  protected float granularity;
  
  protected boolean logarithmic;
  
  public NumericControlAdapter() {
    super(null, true, null);
    this.lowerLimit = 0.0F;
    this.upperLimit = 1.0F;
    this.defaultValue = 0.5F;
    this.granularity = 0.001F;
    this.logarithmic = false;
  }
  
  public NumericControlAdapter(float ll, float ul, float dv, float gran, boolean log, Component comp, boolean def, Control parent) {
    super(comp, def, parent);
    this.lowerLimit = ll;
    this.upperLimit = ul;
    this.defaultValue = dv;
    this.granularity = gran;
    this.logarithmic = log;
  }
  
  public float getLowerLimit() {
    return this.lowerLimit;
  }
  
  public float getUpperLimit() {
    return this.upperLimit;
  }
  
  public float getValue() {
    return 0.0F;
  }
  
  public float setValue(float value) {
    return value;
  }
  
  public float getDefaultValue() {
    return this.defaultValue;
  }
  
  public float setDefaultValue(float value) {
    return this.defaultValue = value;
  }
  
  public float getGranularity() {
    return this.granularity;
  }
  
  public boolean isLogarithmic() {
    return this.logarithmic;
  }
  
  public float getLogarithmicBase() {
    return 0.0F;
  }
}
