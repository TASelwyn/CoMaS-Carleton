package com.sun.media.controls;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.media.Codec;
import javax.media.control.PacketSizeControl;

public class PacketSizeAdapter implements PacketSizeControl {
  protected Codec owner = null;
  
  protected boolean isSetable;
  
  protected int packetSize;
  
  Component component = null;
  
  String CONTROL_STRING = "Packet Size";
  
  public PacketSizeAdapter(Codec newOwner, int newPacketSize, boolean newIsSetable) {
    this.packetSize = newPacketSize;
    this.owner = newOwner;
    this.isSetable = newIsSetable;
  }
  
  public int setPacketSize(int numBytes) {
    return this.packetSize;
  }
  
  public int getPacketSize() {
    return this.packetSize;
  }
  
  public Component getControlComponent() {
    if (this.component == null) {
      Panel componentPanel = new Panel();
      componentPanel.setLayout(new BorderLayout());
      componentPanel.add("Center", new Label(this.CONTROL_STRING, 1));
      TextField tf = new TextField(this.packetSize + "", 5);
      tf.setEditable(this.isSetable);
      tf.addActionListener(new PacketSizeListner(this, tf));
      componentPanel.add("East", tf);
      componentPanel.invalidate();
      this.component = componentPanel;
    } 
    return this.component;
  }
  
  class PacketSizeListner implements ActionListener {
    TextField tf;
    
    private final PacketSizeAdapter this$0;
    
    public PacketSizeListner(PacketSizeAdapter this$0, TextField source) {
      this.this$0 = this$0;
      this.tf = source;
    }
    
    public void actionPerformed(ActionEvent e) {
      try {
        int newPacketSize = Integer.parseInt(this.tf.getText());
        System.out.println("newPacketSize " + newPacketSize);
        this.this$0.setPacketSize(newPacketSize);
      } catch (Exception exception) {}
      this.tf.setText(this.this$0.packetSize + "");
    }
  }
}
