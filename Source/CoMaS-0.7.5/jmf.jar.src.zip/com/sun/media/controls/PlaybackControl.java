package com.sun.media.controls;

public interface PlaybackControl extends GroupControl {
  BooleanControl getPlay();
  
  BooleanControl getStop();
  
  ActionControl getStepForward();
  
  ActionControl getStepBackward();
  
  NumericControl getPlayRate();
  
  NumericControl getSeek();
}
