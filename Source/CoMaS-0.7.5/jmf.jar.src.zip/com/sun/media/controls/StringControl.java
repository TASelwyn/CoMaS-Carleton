package com.sun.media.controls;

public interface StringControl extends AtomicControl {
  String setValue(String paramString);
  
  String getValue();
  
  String setTitle(String paramString);
  
  String getTitle();
}
