package com.sun.media.controls;

public interface SliderRegionControl extends AtomicControl {
  long setMaxValue(long paramLong);
  
  long getMaxValue();
  
  long setMinValue(long paramLong);
  
  long getMinValue();
  
  boolean isEnable();
  
  void setEnable(boolean paramBoolean);
}
