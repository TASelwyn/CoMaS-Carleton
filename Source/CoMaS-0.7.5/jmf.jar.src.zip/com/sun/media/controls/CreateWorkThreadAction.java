package com.sun.media.controls;

import java.lang.reflect.Constructor;
import java.security.PrivilegedAction;

public class CreateWorkThreadAction implements PrivilegedAction {
  private Class objclass;
  
  Class baseClass;
  
  Object arg;
  
  static Constructor cons;
  
  static {
    try {
      cons = CreateWorkThreadAction.class.getConstructor(new Class[] { Class.class, Class.class, Object.class });
    } catch (Throwable e) {}
  }
  
  public CreateWorkThreadAction(Class objclass, Class baseClass, Object arg) {
    try {
      this.objclass = objclass;
      this.baseClass = baseClass;
      this.arg = arg;
    } catch (Throwable e) {}
  }
  
  public Object run() {
    try {
      Constructor cons = this.objclass.getConstructor(new Class[] { this.baseClass });
      Object object = cons.newInstance(new Object[] { this.arg });
      return object;
    } catch (Throwable e) {
      return null;
    } 
  }
}
