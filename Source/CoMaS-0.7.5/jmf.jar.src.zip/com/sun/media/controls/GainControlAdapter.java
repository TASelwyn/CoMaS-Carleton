package com.sun.media.controls;

import java.awt.Component;
import java.util.Vector;
import javax.media.GainChangeEvent;
import javax.media.GainChangeListener;
import javax.media.GainControl;

public class GainControlAdapter implements GainControl {
  private Vector listeners = null;
  
  private boolean muteState;
  
  private Component component;
  
  private float DefLevel = 0.4F;
  
  private float dB = 0.0F;
  
  private float level = this.DefLevel;
  
  public GainControlAdapter() {}
  
  public GainControlAdapter(float defLevel) {
    this.DefLevel = defLevel;
    this.level = defLevel;
  }
  
  public GainControlAdapter(boolean mute) {
    this.muteState = mute;
    setLevel(this.DefLevel);
  }
  
  public void setMute(boolean mute) {
    if (this.muteState != mute) {
      this.muteState = mute;
      informListeners();
    } 
  }
  
  public boolean getMute() {
    return this.muteState;
  }
  
  public float setDB(float gain) {
    if (this.dB != gain) {
      this.dB = gain;
      float mult = (float)Math.pow(10.0D, this.dB / 20.0D);
      this.level = mult * this.DefLevel;
      if (this.level < 0.0D) {
        setLevel(0.0F);
      } else if (this.level > 1.0D) {
        setLevel(1.0F);
      } else {
        setLevel(this.level);
        informListeners();
      } 
    } 
    return this.dB;
  }
  
  public float getDB() {
    return this.dB;
  }
  
  public float setLevel(float level) {
    if (level < 0.0D)
      level = 0.0F; 
    if (level > 1.0D)
      level = 1.0F; 
    if (this.level != level) {
      this.level = level;
      float mult = level / this.DefLevel;
      this.dB = (float)(Math.log((mult == 0.0D) ? 1.0E-4D : mult) / Math.log(10.0D) * 20.0D);
      informListeners();
    } 
    return this.level;
  }
  
  public float getLevel() {
    return this.level;
  }
  
  public synchronized void addGainChangeListener(GainChangeListener listener) {
    if (listener != null) {
      if (this.listeners == null)
        this.listeners = new Vector(); 
      this.listeners.addElement(listener);
    } 
  }
  
  public synchronized void removeGainChangeListener(GainChangeListener listener) {
    if (listener != null && this.listeners != null)
      this.listeners.removeElement(listener); 
  }
  
  public Component getControlComponent() {
    return null;
  }
  
  protected synchronized void informListeners() {
    if (this.listeners != null) {
      GainChangeEvent gce = new GainChangeEvent(this, this.muteState, this.dB, this.level);
      for (int i = 0; i < this.listeners.size(); i++) {
        GainChangeListener gcl = this.listeners.elementAt(i);
        gcl.gainChange(gce);
      } 
    } 
  }
}
