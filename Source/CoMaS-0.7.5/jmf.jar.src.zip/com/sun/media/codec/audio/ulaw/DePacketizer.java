package com.sun.media.codec.audio.ulaw;

import com.sun.media.BasicCodec;
import com.sun.media.BasicPlugIn;
import com.sun.media.codec.audio.AudioCodec;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.format.AudioFormat;

public class DePacketizer extends AudioCodec {
  public DePacketizer() {
    ((BasicCodec)this).inputFormats = new Format[] { (Format)new AudioFormat("ULAW/rtp") };
  }
  
  public String getName() {
    return "ULAW DePacketizer";
  }
  
  public Format[] getSupportedOutputFormats(Format in) {
    if (in == null)
      return new Format[] { (Format)new AudioFormat("ULAW") }; 
    if (BasicPlugIn.matches(in, ((BasicCodec)this).inputFormats) == null)
      return new Format[1]; 
    if (!(in instanceof AudioFormat))
      return new Format[] { (Format)new AudioFormat("ULAW") }; 
    AudioFormat af = (AudioFormat)in;
    return new Format[] { (Format)new AudioFormat("ULAW", af.getSampleRate(), af.getSampleSizeInBits(), af.getChannels()) };
  }
  
  public void open() {}
  
  public void close() {}
  
  public int process(Buffer inputBuffer, Buffer outputBuffer) {
    if (!checkInputBuffer(inputBuffer))
      return 1; 
    if (isEOM(inputBuffer)) {
      propagateEOM(outputBuffer);
      return 0;
    } 
    Object outData = outputBuffer.getData();
    outputBuffer.setData(inputBuffer.getData());
    inputBuffer.setData(outData);
    outputBuffer.setLength(inputBuffer.getLength());
    outputBuffer.setFormat(((BasicCodec)this).outputFormat);
    outputBuffer.setOffset(inputBuffer.getOffset());
    return 0;
  }
}
