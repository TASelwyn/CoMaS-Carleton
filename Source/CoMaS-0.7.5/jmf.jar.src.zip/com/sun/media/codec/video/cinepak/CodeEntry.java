package com.sun.media.codec.video.cinepak;

public class CodeEntry {
  int aRGB0;
  
  int aRGB1;
  
  int aRGB2;
  
  int aRGB3;
  
  public CodeEntry(CodeEntry fromCode) {
    this.aRGB0 = fromCode.aRGB0;
    this.aRGB1 = fromCode.aRGB1;
    this.aRGB2 = fromCode.aRGB2;
    this.aRGB3 = fromCode.aRGB3;
  }
  
  public CodeEntry() {
    this.aRGB0 = 10724259;
    this.aRGB1 = 10724259;
    this.aRGB2 = 10724259;
    this.aRGB3 = 10724259;
  }
}
