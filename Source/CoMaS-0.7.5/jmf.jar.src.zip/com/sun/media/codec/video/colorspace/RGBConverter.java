package com.sun.media.codec.video.colorspace;

import com.sun.media.BasicCodec;
import com.sun.media.BasicPlugIn;
import java.awt.Component;
import java.awt.Dimension;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.ResourceUnavailableException;
import javax.media.control.FrameProcessingControl;
import javax.media.format.RGBFormat;
import javax.media.format.VideoFormat;

public abstract class RGBConverter extends BasicCodec {
  private static final String PLUGIN_NAME = "RGB To RGB Converter";
  
  private FrameProcessingControl frameControl = null;
  
  private boolean dropFrame;
  
  public RGBConverter() {
    this.inputFormats = new Format[] { (Format)new RGBFormat() };
    this.outputFormats = new Format[] { (Format)new RGBFormat() };
    if (this.frameControl == null) {
      this.frameControl = new RGBConverter$1$FPC(this);
      ((BasicPlugIn)this).controls = (Object[])new javax.media.Control[1];
      ((BasicPlugIn)this).controls[0] = this.frameControl;
    } 
  }
  
  public String getName() {
    return "RGB To RGB Converter";
  }
  
  public Format[] getSupportedOutputFormats(Format input) {
    if (input == null)
      return this.outputFormats; 
    if (input instanceof RGBFormat) {
      RGBFormat rgb = (RGBFormat)input;
      Dimension size = rgb.getSize();
      float frameRate = rgb.getFrameRate();
      int bpp = rgb.getBitsPerPixel();
      RGBFormat bits_16_p = new RGBFormat(size, size.width * size.height, Format.shortArray, frameRate, 16, -1, -1, -1, 1, size.width, -1, -1);
      RGBFormat bits_16_up = new RGBFormat(size, size.width * size.height * 2, Format.byteArray, frameRate, 16, -1, -1, -1, 2, size.width * 2, -1, -1);
      RGBFormat masks_565 = new RGBFormat(null, -1, null, -1.0F, -1, 63488, 2016, 31, -1, -1, -1, -1);
      RGBFormat masks_555 = new RGBFormat(null, -1, null, -1.0F, -1, 31744, 992, 31, -1, -1, -1, -1);
      RGBFormat bits_24_up = new RGBFormat(size, size.width * size.height * 3, Format.byteArray, frameRate, 24, -1, -1, -1, 3, size.width * 3, -1, -1);
      RGBFormat masks_RGB = new RGBFormat(null, -1, null, -1.0F, -1, 1, 2, 3, -1, -1, -1, -1);
      RGBFormat masks_BGR = new RGBFormat(null, -1, null, -1.0F, -1, 3, 2, 1, -1, -1, -1, -1);
      RGBFormat bits_32_p = new RGBFormat(size, size.width * size.height, Format.intArray, frameRate, 32, -1, -1, -1, 1, size.width, -1, -1);
      RGBFormat bits_32_up = new RGBFormat(size, size.width * size.height * 4, Format.byteArray, frameRate, 32, -1, -1, -1, 4, size.width * 4, -1, -1);
      RGBFormat masks_234 = new RGBFormat(null, -1, null, -1.0F, -1, 2, 3, 4, -1, -1, -1, -1);
      RGBFormat masks_432 = new RGBFormat(null, -1, null, -1.0F, -1, 4, 3, 2, -1, -1, -1, -1);
      RGBFormat masks_123 = new RGBFormat(null, -1, null, -1.0F, -1, 1, 2, 3, -1, -1, -1, -1);
      RGBFormat flipped = new RGBFormat(null, -1, null, -1.0F, -1, -1, -1, -1, -1, -1, 1, -1);
      RGBFormat straight = new RGBFormat(null, -1, null, -1.0F, -1, -1, -1, -1, -1, -1, 0, -1);
      RGBFormat big = new RGBFormat(null, -1, null, -1.0F, -1, -1, -1, -1, -1, -1, -1, 0);
      RGBFormat little = new RGBFormat(null, -1, null, -1.0F, -1, -1, -1, -1, -1, -1, -1, 1);
      RGBFormat masks_321 = new RGBFormat(null, -1, null, -1.0F, -1, 3, 2, 1, -1, -1, -1, -1);
      RGBFormat masks_XRGB = new RGBFormat(null, -1, null, -1.0F, -1, 16711680, 65280, 255, -1, -1, -1, -1);
      RGBFormat masks_XBGR = new RGBFormat(null, -1, null, -1.0F, -1, 255, 65280, 16711680, -1, -1, -1, -1);
      Format[] out = { 
          bits_16_p.intersects((Format)masks_565).intersects((Format)flipped), bits_16_p.intersects((Format)masks_565).intersects((Format)straight), bits_16_up.intersects((Format)masks_565).intersects((Format)flipped).intersects((Format)little), bits_16_up.intersects((Format)masks_565).intersects((Format)flipped).intersects((Format)big), bits_16_up.intersects((Format)masks_565).intersects((Format)straight).intersects((Format)little), bits_16_up.intersects((Format)masks_565).intersects((Format)straight).intersects((Format)big), bits_16_p.intersects((Format)masks_555).intersects((Format)flipped), bits_16_p.intersects((Format)masks_555).intersects((Format)straight), bits_16_up.intersects((Format)masks_555).intersects((Format)flipped).intersects((Format)little), bits_16_up.intersects((Format)masks_555).intersects((Format)flipped).intersects((Format)big), 
          bits_16_up.intersects((Format)masks_555).intersects((Format)straight).intersects((Format)little), bits_16_up.intersects((Format)masks_555).intersects((Format)straight).intersects((Format)big), bits_24_up.intersects((Format)masks_RGB).intersects((Format)flipped), bits_24_up.intersects((Format)masks_RGB).intersects((Format)straight), bits_24_up.intersects((Format)masks_BGR).intersects((Format)flipped), bits_24_up.intersects((Format)masks_BGR).intersects((Format)straight), bits_32_p.intersects((Format)masks_XRGB).intersects((Format)flipped), bits_32_p.intersects((Format)masks_XRGB).intersects((Format)straight), bits_32_p.intersects((Format)masks_XBGR).intersects((Format)flipped), bits_32_p.intersects((Format)masks_XBGR).intersects((Format)straight), 
          bits_32_up.intersects((Format)masks_123).intersects((Format)flipped), bits_32_up.intersects((Format)masks_123).intersects((Format)straight), bits_32_up.intersects((Format)masks_321).intersects((Format)flipped), bits_32_up.intersects((Format)masks_321).intersects((Format)straight), bits_32_up.intersects((Format)masks_234).intersects((Format)flipped), bits_32_up.intersects((Format)masks_234).intersects((Format)straight), bits_32_up.intersects((Format)masks_432).intersects((Format)flipped), bits_32_up.intersects((Format)masks_432).intersects((Format)straight) };
      return out;
    } 
    return null;
  }
  
  public Format setInputFormat(Format in) {
    Format returnFormat = super.setInputFormat(in);
    if (returnFormat == null)
      return null; 
    if (((RGBFormat)returnFormat).getBitsPerPixel() < 15)
      return null; 
    Dimension size = ((VideoFormat)in).getSize();
    if (this.opened)
      this.outputFormat = (Format)updateRGBFormat((VideoFormat)in, (RGBFormat)this.outputFormat); 
    return returnFormat;
  }
  
  public int process(Buffer inBuffer, Buffer outBuffer) {
    if (isEOM(inBuffer)) {
      propagateEOM(outBuffer);
      return 0;
    } 
    if (this.dropFrame) {
      outBuffer.setFlags(outBuffer.getFlags() | 0x2);
      return 0;
    } 
    RGBFormat inputRGB = (RGBFormat)this.inputFormat;
    RGBFormat outputRGB = (RGBFormat)this.outputFormat;
    Object inObject = inBuffer.getData();
    Object outObject = outBuffer.getData();
    if (inObject.getClass() != this.inputFormat.getDataType())
      return 1; 
    int outMaxDataLen = outputRGB.getMaxDataLength();
    int outLength = 0;
    if (outObject != null)
      if (outObject.getClass() == Format.byteArray) {
        outLength = ((byte[])outObject).length;
      } else if (outObject.getClass() == Format.shortArray) {
        outLength = ((short[])outObject).length;
      } else if (outObject.getClass() == Format.intArray) {
        outLength = ((int[])outObject).length;
      }  
    if (outObject == null || outLength < outMaxDataLen || this.outputFormat != outBuffer.getFormat() || !this.outputFormat.equals(outBuffer.getFormat())) {
      Class outputDataType = this.outputFormat.getDataType();
      if (outputDataType == Format.byteArray) {
        outObject = new byte[outputRGB.getMaxDataLength()];
      } else if (outputDataType == Format.shortArray) {
        outObject = new short[outputRGB.getMaxDataLength()];
      } else if (outputDataType == Format.intArray) {
        outObject = new int[outputRGB.getMaxDataLength()];
      } else {
        return 1;
      } 
      outBuffer.setData(outObject);
    } 
    if (outObject.getClass() != this.outputFormat.getDataType())
      return 1; 
    int inBPP = inputRGB.getBitsPerPixel();
    int outBPP = outputRGB.getBitsPerPixel();
    boolean inPacked = (inputRGB.getDataType() != Format.byteArray);
    boolean outPacked = (outputRGB.getDataType() != Format.byteArray);
    int inPS = inputRGB.getPixelStride();
    int outPS = outputRGB.getPixelStride();
    int inEndian = inputRGB.getEndian();
    int outEndian = outputRGB.getEndian();
    int inRed = inputRGB.getRedMask();
    int inGreen = inputRGB.getGreenMask();
    int inBlue = inputRGB.getBlueMask();
    int outRed = outputRGB.getRedMask();
    int outGreen = outputRGB.getGreenMask();
    int outBlue = outputRGB.getBlueMask();
    int inLS = inputRGB.getLineStride();
    int outLS = outputRGB.getLineStride();
    boolean flip = (inputRGB.getFlipped() != outputRGB.getFlipped());
    Dimension size = inputRGB.getSize();
    int width = size.width;
    int height = size.height;
    if (inBPP == 16 && outBPP == 16) {
      sixteenToSixteen(inObject, inPS, inLS, inBPP, inRed, inGreen, inBlue, inPacked, inEndian, outObject, outPS, outLS, outBPP, outRed, outGreen, outBlue, outPacked, outEndian, width, height, flip);
    } else if (inBPP == 16 && outBPP >= 24) {
      sixteenToComponent(inObject, inPS, inLS, inBPP, inRed, inGreen, inBlue, inPacked, inEndian, outObject, outPS, outLS, outBPP, outRed, outGreen, outBlue, outPacked, outEndian, width, height, flip);
    } else if (inBPP >= 24 && outBPP == 16) {
      componentToSixteen(inObject, inPS, inLS, inBPP, inRed, inGreen, inBlue, inPacked, inEndian, outObject, outPS, outLS, outBPP, outRed, outGreen, outBlue, outPacked, outEndian, width, height, flip);
    } else if (inBPP >= 24 && outBPP >= 24) {
      componentToComponent(inObject, inPS, inLS, inBPP, inRed, inGreen, inBlue, inPacked, inEndian, outObject, outPS, outLS, outBPP, outRed, outGreen, outBlue, outPacked, outEndian, width, height, flip);
    } 
    outBuffer.setFormat(this.outputFormat);
    outBuffer.setLength(outputRGB.getMaxDataLength());
    return 0;
  }
  
  public void open() throws ResourceUnavailableException {
    super.open();
  }
  
  public void close() {
    super.close();
  }
  
  public void reset() {}
  
  protected int getShift(int mask) {
    int shift = 0;
    while ((mask & 0x1) == 0) {
      mask >>= 1;
      shift++;
    } 
    return shift;
  }
  
  protected abstract void sixteenToSixteen(Object paramObject1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean1, int paramInt7, Object paramObject2, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, boolean paramBoolean2, int paramInt14, int paramInt15, int paramInt16, boolean paramBoolean3);
  
  protected abstract void sixteenToComponent(Object paramObject1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean1, int paramInt7, Object paramObject2, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, boolean paramBoolean2, int paramInt14, int paramInt15, int paramInt16, boolean paramBoolean3);
  
  protected abstract void componentToSixteen(Object paramObject1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean1, int paramInt7, Object paramObject2, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, boolean paramBoolean2, int paramInt14, int paramInt15, int paramInt16, boolean paramBoolean3);
  
  protected abstract void componentToComponent(Object paramObject1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean1, int paramInt7, Object paramObject2, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, boolean paramBoolean2, int paramInt14, int paramInt15, int paramInt16, boolean paramBoolean3);
}
