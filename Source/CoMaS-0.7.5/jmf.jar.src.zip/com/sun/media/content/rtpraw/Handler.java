package com.sun.media.content.rtpraw;

import com.sun.media.content.rtp.Handler;

public class Handler extends Handler {}
