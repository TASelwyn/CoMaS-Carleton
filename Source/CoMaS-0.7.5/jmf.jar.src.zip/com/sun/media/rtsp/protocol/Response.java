package com.sun.media.rtsp.protocol;

import com.sun.media.sdp.SdpParser;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Vector;

public class Response extends Parser {
  public StatusLine statusLine;
  
  public Vector headers;
  
  public SdpParser sdp;
  
  public Response(ByteArrayInputStream bin) {
    String line = getLine(bin);
    this.statusLine = new StatusLine(line);
    this.headers = new Vector();
    line = getLine(bin);
    int contentLength = 0;
    while (line.length() > 0) {
      if (line.length() > 0) {
        Header header = new Header(line);
        if (header.type == 10)
          contentLength = header.contentLength; 
        this.headers.addElement(header);
        line = getLine(bin);
      } 
    } 
    if (contentLength > 0) {
      byte[] data = new byte[bin.available()];
      try {
        bin.read(data);
        this.sdp = new SdpParser(data);
      } catch (IOException e) {
        e.printStackTrace();
      } 
    } 
  }
  
  public Header getHeader(int type) {
    Header header = null;
    for (int i = 0; i < this.headers.size(); i++) {
      Header tmpHeader = this.headers.elementAt(i);
      if (tmpHeader.type == type) {
        header = tmpHeader;
        break;
      } 
    } 
    return header;
  }
  
  public StatusLine getStatusLine() {
    return this.statusLine;
  }
}
