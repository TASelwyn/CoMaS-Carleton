package com.sun.media.rtsp.protocol;

public class ContentBaseHeader {
  private String contentBase;
  
  public ContentBaseHeader(String contentBase) {
    this.contentBase = contentBase;
  }
  
  public String getContentBase() {
    return this.contentBase;
  }
}
