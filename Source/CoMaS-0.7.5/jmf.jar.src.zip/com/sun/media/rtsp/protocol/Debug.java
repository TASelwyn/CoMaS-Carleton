package com.sun.media.rtsp.protocol;

abstract class Debug {
  static boolean debug_enabled = false;
  
  public static void println(Object object) {
    if (debug_enabled)
      System.out.println(object); 
  }
  
  public static void dump(byte[] data) {
    if (debug_enabled)
      for (int i = 0; i < data.length; i++) {
        int value = data[i] & 0xFF;
        System.out.println(i + ": " + Integer.toHexString(value));
      }  
  }
}
