package com.sun.media.rtsp.protocol;

import java.io.ByteArrayInputStream;

public class Header extends Parser {
  public int type;
  
  public Object parameter;
  
  public int contentLength;
  
  public static final int TRANSPORT = 1;
  
  public static final int CSEQ = 2;
  
  public static final int SESSION = 3;
  
  public static final int DURATION = 4;
  
  public static final int RANGE = 5;
  
  public static final int DATE = 6;
  
  public static final int SERVER = 7;
  
  public static final int CONTENT_TYPE = 8;
  
  public static final int CONTENT_BASE = 9;
  
  public static final int CONTENT_LENGTH = 10;
  
  public Header(String input) {
    ByteArrayInputStream bin = new ByteArrayInputStream(input.getBytes());
    String id = getToken(bin);
    if (id.equalsIgnoreCase("CSeq:")) {
      this.type = 2;
      String number = getStringToken(bin).trim();
      this.parameter = new CSeqHeader(number);
    } else if (id.equalsIgnoreCase("Transport:")) {
      this.type = 1;
      String tx = getToken(bin);
      this.parameter = new TransportHeader(tx);
    } else if (id.equalsIgnoreCase("Session:")) {
      this.type = 3;
      String tx = getToken(bin);
      this.parameter = new SessionHeader(tx);
    } else if (id.equalsIgnoreCase("Duration:")) {
      this.type = 4;
      String tx = getToken(bin);
      Debug.println("Duration : " + tx);
      this.parameter = new DurationHeader(tx);
    } else if (id.equalsIgnoreCase("Range:")) {
      this.type = 5;
      String tx = getToken(bin);
      this.parameter = new RangeHeader(tx);
    } else if (id.equalsIgnoreCase("Date:")) {
      this.type = 6;
      String date = getStringToken(bin);
    } else if (id.equalsIgnoreCase("Allow:")) {
      this.type = 6;
      String entries = getStringToken(bin);
    } else if (id.equalsIgnoreCase("Server:")) {
      this.type = 7;
      String server = getStringToken(bin);
    } else if (id.equalsIgnoreCase("Content-Type:")) {
      this.type = 8;
      String content_type = getStringToken(bin);
    } else if (id.equalsIgnoreCase("Content-Base:")) {
      this.type = 9;
      String content_base = getStringToken(bin);
      this.parameter = new ContentBaseHeader(content_base);
    } else if (id.equalsIgnoreCase("Content-Length:")) {
      this.type = 10;
      String content_length = getStringToken(bin);
      this.contentLength = (new Integer(content_length)).intValue();
    } else if (id.equalsIgnoreCase("Last-Modified:")) {
      String date = getStringToken(bin);
    } else if (id.equalsIgnoreCase("RTP-Info:")) {
      String rtpInfo = getStringToken(bin);
    } else if (id.length() > 0) {
      Debug.println("unknown id : <" + id + ">");
      String tmp = getStringToken(bin);
    } 
  }
}
