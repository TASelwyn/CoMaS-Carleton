package com.sun.media.rtsp;

public interface RtspAppListener {
  void streamsReceivedEvent();
  
  void postStatusMessage(int paramInt, String paramString);
}
