package com.sun.media.rtsp;

import com.sun.media.rtsp.protocol.Message;

public interface RtspListener {
  void rtspMessageIndication(int paramInt, Message paramMessage);
  
  void rtspConnectionTerminated(int paramInt);
}
