package com.sun.media.rtsp;

public interface TimerListener {
  void timerExpired();
}
