package com.ibm.media.codec.audio.g723;

class PFDEF {
  int Indx;
  
  float Gain;
  
  float ScGn;
}
