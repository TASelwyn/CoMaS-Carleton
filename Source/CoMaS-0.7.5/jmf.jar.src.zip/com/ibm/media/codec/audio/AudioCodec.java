package com.ibm.media.codec.audio;

import com.sun.media.BasicCodec;
import com.sun.media.BasicPlugIn;
import javax.media.Format;
import javax.media.format.AudioFormat;

public abstract class AudioCodec extends BasicCodec {
  protected String PLUGIN_NAME;
  
  protected AudioFormat[] defaultOutputFormats;
  
  protected AudioFormat[] supportedInputFormats;
  
  protected AudioFormat[] supportedOutputFormats;
  
  protected AudioFormat inputFormat;
  
  protected AudioFormat outputFormat;
  
  protected final boolean DEBUG = true;
  
  public String getName() {
    return this.PLUGIN_NAME;
  }
  
  public Format[] getSupportedInputFormats() {
    return (Format[])this.supportedInputFormats;
  }
  
  public Format setInputFormat(Format format) {
    if (!(format instanceof AudioFormat) || null == BasicPlugIn.matches(format, (Format[])this.supportedInputFormats))
      return null; 
    this.inputFormat = (AudioFormat)format;
    return format;
  }
  
  public Format setOutputFormat(Format format) {
    if (!(format instanceof AudioFormat) || null == BasicPlugIn.matches(format, getMatchingOutputFormats((Format)this.inputFormat)))
      return null; 
    this.outputFormat = (AudioFormat)format;
    return format;
  }
  
  protected Format getInputFormat() {
    return (Format)this.inputFormat;
  }
  
  protected Format getOutputFormat() {
    return (Format)this.outputFormat;
  }
  
  protected Format[] getMatchingOutputFormats(Format in) {
    return new Format[0];
  }
  
  public Format[] getSupportedOutputFormats(Format in) {
    if (in == null)
      return (Format[])this.defaultOutputFormats; 
    if (!(in instanceof AudioFormat) || BasicPlugIn.matches(in, (Format[])this.supportedInputFormats) == null)
      return new Format[0]; 
    return getMatchingOutputFormats(in);
  }
  
  public boolean checkFormat(Format format) {
    return true;
  }
}
