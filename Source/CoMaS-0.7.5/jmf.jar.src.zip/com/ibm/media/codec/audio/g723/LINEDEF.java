package com.ibm.media.codec.audio.g723;

class LINEDEF {
  private static final int SubFrames = 4;
  
  int Crc;
  
  int LspId;
  
  int[] Olp = new int[2];
  
  SFSDEF[] Sfs = new SFSDEF[] { new SFSDEF(), new SFSDEF(), new SFSDEF(), new SFSDEF() };
}
