package com.ibm.media.codec.audio.g723;

import com.ibm.media.codec.audio.AudioCodec;
import com.sun.media.BasicPlugIn;
import com.sun.media.controls.SilenceSuppressionAdapter;
import javax.media.Buffer;
import javax.media.Codec;
import javax.media.Format;
import javax.media.ResourceUnavailableException;
import javax.media.format.AudioFormat;

public class JavaDecoder extends AudioCodec {
  protected G723Dec decoder;
  
  public JavaDecoder() {
    this.supportedInputFormats = new AudioFormat[] { new AudioFormat("g723"), new AudioFormat("g723/rtp") };
    this.defaultOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR") };
    this.PLUGIN_NAME = "G723 Decoder";
  }
  
  protected Format[] getMatchingOutputFormats(Format in) {
    AudioFormat af = (AudioFormat)in;
    this.supportedOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR", af.getSampleRate(), 16, 1, 0, 1) };
    return (Format[])this.supportedOutputFormats;
  }
  
  public void open() throws ResourceUnavailableException {
    this.decoder = new G723Dec();
    this.decoder.decoderOpen();
  }
  
  public void reset() {
    resetDecoder();
  }
  
  public void close() {
    freeDecoder();
  }
  
  public int process(Buffer inputBuffer, Buffer outputBuffer) {
    if (!checkInputBuffer(inputBuffer))
      return 1; 
    if (isEOM(inputBuffer)) {
      propagateEOM(outputBuffer);
      return 0;
    } 
    int inpLength = inputBuffer.getLength();
    int outLength = calculateOutputSize(inputBuffer.getLength());
    byte[] inpData = (byte[])inputBuffer.getData();
    byte[] outData = validateByteArraySize(outputBuffer, outLength);
    decode(inpData, inputBuffer.getOffset(), outData, 0, inpLength);
    updateOutput(outputBuffer, (Format)this.outputFormat, outLength, 0);
    return 0;
  }
  
  protected void initDecoder() {
    this.decoder.decoderReset();
  }
  
  protected void freeDecoder() {
    this.decoder = null;
  }
  
  protected void resetDecoder() {
    this.decoder.decoderReset();
  }
  
  protected int calculateOutputSize(int inputSize) {
    return inputSize / 24 * 480;
  }
  
  protected void decode(byte[] inpData, int readPtr, byte[] outData, int writePtr, int inpLength) {
    int numberOfFrames = inpLength / 24;
    int frameSize = 24;
    for (int n = 0; n < numberOfFrames; n++, readPtr += frameSize, writePtr += 480)
      this.decoder.decodeFrame(inpData, readPtr, outData, writePtr); 
  }
  
  public Object[] getControls() {
    if (((BasicPlugIn)this).controls == null) {
      ((BasicPlugIn)this).controls = (Object[])new javax.media.Control[1];
      ((BasicPlugIn)this).controls[0] = new SilenceSuppressionAdapter((Codec)this, true, false);
    } 
    return ((BasicPlugIn)this).controls;
  }
}
