package com.ibm.media.codec.audio.rc;

import com.ibm.media.codec.audio.AudioCodec;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.ResourceUnavailableException;
import javax.media.format.AudioFormat;

public class RCModule extends AudioCodec {
  private RateConversion rateConversion = null;
  
  private Format lastInputFormat = null;
  
  private Format lastOutputFormat = null;
  
  private static boolean DEBUG = false;
  
  public RCModule() {
    this.supportedInputFormats = new AudioFormat[] { new AudioFormat("LINEAR", -1.0D, 16, 2, -1, -1), new AudioFormat("LINEAR", -1.0D, 16, 1, -1, -1), new AudioFormat("LINEAR", -1.0D, 8, 2, -1, -1), new AudioFormat("LINEAR", -1.0D, 8, 1, -1, -1) };
    this.defaultOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR", 8000.0D, 16, 2, 0, 1), new AudioFormat("LINEAR", 8000.0D, 16, 1, 0, 1) };
    this.PLUGIN_NAME = "Rate Conversion";
  }
  
  public Format setInputFormat(Format format) {
    if (!isSampleRateSupported(format))
      return null; 
    return super.setInputFormat(format);
  }
  
  protected Format[] getMatchingOutputFormats(Format in) {
    if (!isSampleRateSupported(in))
      return new Format[0]; 
    this.supportedOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR", 8000.0D, 16, 1, 0, 1), new AudioFormat("LINEAR", 8000.0D, 16, 2, 0, 1) };
    return (Format[])this.supportedOutputFormats;
  }
  
  public void open() throws ResourceUnavailableException {}
  
  public void reset() {
    if (null != this.rateConversion)
      this.rateConversion.reset(); 
  }
  
  public void close() {
    if (null != this.rateConversion)
      this.rateConversion.close(); 
    this.rateConversion = null;
  }
  
  public int process(Buffer inputBuffer, Buffer outputBuffer) {
    if (!checkInputBuffer(inputBuffer))
      return 1; 
    if (isEOM(inputBuffer)) {
      propagateEOM(outputBuffer);
      return 0;
    } 
    int inputLength = inputBuffer.getLength();
    if (this.lastInputFormat != this.inputFormat || this.lastOutputFormat != this.outputFormat || this.rateConversion == null)
      if (false == initConverter(this.inputFormat, this.outputFormat, inputLength))
        return 1;  
    int maxOutLength = this.rateConversion.getMaxOutputLength(inputLength);
    byte[] inputData = (byte[])inputBuffer.getData();
    byte[] outData = validateByteArraySize(outputBuffer, maxOutLength);
    int outLength = this.rateConversion.process(inputData, inputBuffer.getOffset(), inputLength, outData, outputBuffer.getOffset());
    updateOutput(outputBuffer, (Format)this.outputFormat, outLength, outputBuffer.getOffset());
    return 0;
  }
  
  private boolean isSampleRateSupported(Format format) {
    try {
      int sampleRate = (int)((AudioFormat)format).getSampleRate();
      if (sampleRate != 11025 && sampleRate != 11127 && sampleRate != 16000 && sampleRate != 22050 && sampleRate != 22254 && sampleRate != 22255 && sampleRate != 32000 && sampleRate != 44100 && sampleRate != 48000) {
        if (DEBUG)
          System.out.println("RCModule - input format sampling rate isn't supported"); 
        return false;
      } 
    } catch (Throwable t) {
      return false;
    } 
    return true;
  }
  
  private boolean initConverter(AudioFormat inFormat, AudioFormat outFormat, int inputLength) {
    this.lastInputFormat = (Format)inFormat;
    this.lastOutputFormat = (Format)outFormat;
    boolean isSigned = false;
    int numberOfInputChannels = inFormat.getChannels();
    int numberOfOutputChannels = outFormat.getChannels();
    int inputSampleSize = inFormat.getSampleSizeInBits();
    int sampleRate = (int)inFormat.getSampleRate();
    boolean ulawOutput = false;
    if (sampleRate == 8000)
      return false; 
    int pcmType = 1;
    if (inFormat.getEndian() == 1)
      pcmType = 0; 
    if (8 == inputSampleSize)
      pcmType = 2; 
    if (inFormat.getSigned() == 1)
      isSigned = true; 
    if (this.rateConversion != null)
      close(); 
    if (outFormat.getEncoding() == "ULAW")
      ulawOutput = true; 
    this.rateConversion = new RateConversion();
    if (-1 != this.rateConversion.init(inputLength, sampleRate, 8000, numberOfInputChannels, numberOfOutputChannels, pcmType, isSigned, ulawOutput)) {
      this.rateConversion = null;
      return false;
    } 
    return true;
  }
}
