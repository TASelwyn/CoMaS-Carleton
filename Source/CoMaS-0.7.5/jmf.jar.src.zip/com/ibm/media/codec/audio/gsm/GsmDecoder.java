package com.ibm.media.codec.audio.gsm;

public class GsmDecoder {
  private static final float[] QLB = new float[] { 0.1F, 0.35F, 0.65F, 1.0F };
  
  private static final int[] larInterpStart = new int[] { 0, 13, 27, 40, 160 };
  
  private static final float[][] InterpLarCoef = new float[][] { { 0.75F, 0.25F }, { 0.5F, 0.5F }, { 0.25F, 0.75F }, { 0.0F, 1.0F } };
  
  private short[] outsig = new short[160];
  
  private byte[] inByteStream = new byte[33];
  
  private float[] prevLARpp = new float[9];
  
  private float[] rp = new float[9];
  
  private float[] u = new float[9];
  
  private int[] lastSID = new int[76];
  
  private float[] quantRes = new float[280];
  
  private int[] parameters = new int[76];
  
  private float[] LARpp = new float[9];
  
  private int GSMrand() {
    this.seed = this.seed * 1103515245 + 12345;
    return this.seed & 0x7FFF;
  }
  
  static {
    short[] B = { 0, 0, 2048, -2560, 94, -1792, -341, -1144 };
    short[] MIC = { -32, -32, -16, -16, -8, -8, -4, -4 };
    short[] INVA = { 13107, 13107, 13107, 13107, 19223, 17476, 31454, 29708 };
  }
  
  private static float[] xmaxTable = new float[64];
  
  static {
    for (int xmaxc = 0; xmaxc < 64; xmaxc++) {
      int i;
      if (xmaxc < 16) {
        i = 31 + (xmaxc << 5);
      } else {
        int exp = xmaxc - 16 >> 3;
        i = (576 << exp) - 1 + (xmaxc - 16 - 8 * exp) * (64 << exp);
      } 
      xmaxTable[xmaxc] = i / 32768.0F;
    } 
  }
  
  private static float[][] larTable = new float[8][];
  
  public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997,1999.";
  
  private static final int OutputSize = 160;
  
  private static final int InputSize = 33;
  
  private static final int LpcOrder = 8;
  
  private static final int SubFrameSize = 40;
  
  private static final int NumOfSubframes = 4;
  
  private static final int NumOfParameters = 76;
  
  private static final int NumOfPulses = 13;
  
  private static final int NumOfLarInterp = 4;
  
  private static final int QuantResBase = 120;
  
  private static final int SidFrame = 2;
  
  private static final int SpeechFrame = 1;
  
  private static final int NullFrame = 0;
  
  private static final int Parameter_SubFramesBase = 8;
  
  private static final int Parameter_SubFramesLength = 17;
  
  private static final int Parameter_LtpLag = 0;
  
  private static final int Parameter_LtpGain = 1;
  
  private static final int Parameter_RpeGridPosition = 2;
  
  private static final int Parameter_BlockAmplitude = 3;
  
  private static final int Parameter_RpePulsesBase = 4;
  
  private int prevNc;
  
  private float prevOut;
  
  private int seed;
  
  private static final int GSM_MAGIC = 13;
  
  static {
    for (int larNum = 0; larNum < 8; larNum++) {
      larTable[larNum] = new float[-MIC[larNum] * 2];
      for (int larQuant = 0; larQuant < -MIC[larNum] * 2; larQuant++) {
        short temp = (short)((larQuant + MIC[larNum] << 10) - B[larNum] * 2);
        temp = (short)(int)((temp * INVA[larNum]) + 16384L >> 15L);
        larTable[larNum][larQuant] = (temp * 2) / 16384.0F;
      } 
    } 
  }
  
  public void decoderInit() {
    this.prevNc = 40;
    this.prevOut = 0.0F;
    for (int i = 0; i < 9; i++) {
      this.prevLARpp[i] = 0.0F;
      this.rp[i] = 0.0F;
      this.u[i] = 0.0F;
    } 
    for (int j = 0; j < this.lastSID.length; j++)
      this.lastSID[j] = 0; 
    this.lastSID[0] = 2;
    this.lastSID[1] = 28;
    this.lastSID[2] = 18;
    this.lastSID[3] = 12;
    this.lastSID[4] = 7;
    this.lastSID[5] = 5;
    this.lastSID[6] = 3;
    this.lastSID[7] = 2;
    for (int k = 0; k < this.quantRes.length; k++)
      this.quantRes[k] = 0.0F; 
    this.seed = 1;
  }
  
  public boolean decodeFrame(byte[] src, int srcoffset, byte[] dst, int dstoffset) {
    int[] parameters = this.parameters;
    int[] lastSID = this.lastSID;
    float[] LARpp = this.LARpp;
    float[] u = this.u;
    float[] rp = this.rp;
    float[] prevLARpp = this.prevLARpp;
    float[] quantRes = this.quantRes;
    System.arraycopy(quantRes, 160, quantRes, 0, 120);
    if (false == UnpackBitStream(src, srcoffset, parameters))
      return false; 
    int frameType = 0;
    for (int i = 0; i < 76; i++) {
      if (0 != parameters[i]) {
        frameType = 2;
        break;
      } 
    } 
    if (frameType == 0) {
      System.arraycopy(lastSID, 0, parameters, 0, 76);
      frameType = 2;
    } else {
      for (int m = 0; m < 4; m++) {
        int subFramePulseBase = m * 17 + 8 + 4;
        for (int n = 0; n < 13; n++) {
          if (parameters[subFramePulseBase + n] != 0) {
            frameType = 1;
            m = 4;
            break;
          } 
        } 
      } 
      if (frameType == 2)
        System.arraycopy(parameters, 0, lastSID, 0, 76); 
    } 
    if (frameType == 2)
      for (int m = 0; m < 4; m++) {
        int subFrameParamBase = m * 17 + 8;
        for (byte b = 0; b < 13; b++)
          parameters[subFrameParamBase + 4 + b] = GSMrand() / 5461 + 1; 
        parameters[subFrameParamBase + 2] = GSMrand() / 10923;
        parameters[subFrameParamBase + 1] = 0;
        parameters[subFrameParamBase + 0] = ((((m == 0) ? 1 : 0) | ((m == 2) ? 1 : 0)) != 0) ? 40 : 120;
      }  
    for (int subFrameNumber = 0; subFrameNumber < 4; subFrameNumber++) {
      int subFrameParamBase = subFrameNumber * 17 + 8;
      int tempLtpLag = parameters[subFrameParamBase + 0];
      if (tempLtpLag >= 40 && tempLtpLag <= 120)
        this.prevNc = tempLtpLag; 
      float ltpGain = QLB[parameters[subFrameParamBase + 1]];
      int rpeGridPos = parameters[subFrameParamBase + 2];
      float xmaxp = xmaxTable[parameters[subFrameParamBase + 3]];
      int subFrameResidualBase = subFrameNumber * 40 + 120;
      for (int m = 0; m < 40; m++)
        quantRes[subFrameResidualBase + m] = ltpGain * quantRes[subFrameResidualBase + m - this.prevNc]; 
      for (int n = 0; n < 13; n++)
        quantRes[subFrameResidualBase + rpeGridPos + 3 * n] = (float)(quantRes[subFrameResidualBase + rpeGridPos + 3 * n] + (0.25D * parameters[subFrameParamBase + 4 + n] - 0.875D) * xmaxp); 
    } 
    for (int larNum = 0; larNum < 8; larNum++)
      LARpp[larNum + 1] = larTable[larNum][parameters[larNum]]; 
    float prevOut = this.prevOut;
    for (int larInterpNumber = 0; larInterpNumber < 4; larInterpNumber++) {
      for (int m = 1; m <= 8; m++) {
        float LARpi = prevLARpp[m] * InterpLarCoef[larInterpNumber][0] + LARpp[m] * InterpLarCoef[larInterpNumber][1];
        if (Math.abs(LARpi) < 0.675D) {
          rp[m] = LARpi;
        } else if (Math.abs(LARpi) < 1.225D) {
          rp[m] = ((LARpi > 0.0F) ? 1.0F : -1.0F) * (0.5F * Math.abs(LARpi) + 0.3375F);
        } else {
          rp[m] = ((LARpi > 0.0F) ? 1.0F : -1.0F) * (0.125F * Math.abs(LARpi) + 0.796875F);
        } 
      } 
      for (int outCount = larInterpStart[larInterpNumber]; outCount < larInterpStart[larInterpNumber + 1]; outCount++) {
        float temp = quantRes[120 + outCount];
        temp -= rp[8] * u[7];
        u[8] = u[7] + rp[8] * temp;
        temp -= rp[7] * u[6];
        u[7] = u[6] + rp[7] * temp;
        temp -= rp[6] * u[5];
        u[6] = u[5] + rp[6] * temp;
        temp -= rp[5] * u[4];
        u[5] = u[4] + rp[5] * temp;
        temp -= rp[4] * u[3];
        u[4] = u[3] + rp[4] * temp;
        temp -= rp[3] * u[2];
        u[3] = u[2] + rp[3] * temp;
        temp -= rp[2] * u[1];
        u[2] = u[1] + rp[2] * temp;
        temp -= rp[1] * u[0];
        u[1] = u[0] + rp[1] * temp;
        prevOut = temp + prevOut * 0.85998535F;
        u[0] = temp;
        temp = 65532.0F * prevOut;
        if (temp > 32766.0F)
          temp = 32766.0F; 
        if (temp < -32766.0F)
          temp = -32766.0F; 
        this.outsig[outCount] = (short)(int)temp;
      } 
    } 
    for (int j = 1; j <= 8; j++)
      prevLARpp[j] = LARpp[j]; 
    this.prevOut = prevOut;
    int dstIndex = 0;
    for (int k = 0; k < 160; k++) {
      int TempInt = this.outsig[k];
      dst[dstoffset + dstIndex++] = (byte)(TempInt & 0xFF);
      dst[dstoffset + dstIndex++] = (byte)(TempInt >> 8);
    } 
    return true;
  }
  
  protected boolean UnpackBitStream(byte[] inByteStream, int inputIndex, int[] Parameters) {
    int paramIndex = 0;
    if ((inByteStream[inputIndex] >> 4 & 0xF) != 13)
      return false; 
    Parameters[paramIndex++] = (inByteStream[inputIndex] & 0xF) << 2 | inByteStream[++inputIndex] >> 6 & 0x3;
    Parameters[paramIndex++] = inByteStream[inputIndex] & 0x3F;
    Parameters[paramIndex++] = inByteStream[++inputIndex] >> 3 & 0x1F;
    Parameters[paramIndex++] = (inByteStream[inputIndex] & 0x7) << 2 | inByteStream[++inputIndex] >> 6 & 0x3;
    Parameters[paramIndex++] = inByteStream[inputIndex] >> 2 & 0xF;
    Parameters[paramIndex++] = (inByteStream[inputIndex] & 0x3) << 2 | inByteStream[++inputIndex] >> 6 & 0x3;
    Parameters[paramIndex++] = inByteStream[inputIndex] >> 3 & 0x7;
    Parameters[paramIndex++] = inByteStream[inputIndex] & 0x7;
    inputIndex++;
    for (int n = 0; n < 4; n++) {
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 1 & 0x7F;
      Parameters[paramIndex++] = (inByteStream[inputIndex] & 0x1) << 1 | inByteStream[++inputIndex] >> 7 & 0x1;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 5 & 0x3;
      Parameters[paramIndex++] = (inByteStream[inputIndex] & 0x1F) << 1 | inByteStream[++inputIndex] >> 7 & 0x1;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 4 & 0x7;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 1 & 0x7;
      Parameters[paramIndex++] = (inByteStream[inputIndex] & 0x1) << 2 | inByteStream[++inputIndex] >> 6 & 0x3;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 3 & 0x7;
      Parameters[paramIndex++] = inByteStream[inputIndex] & 0x7;
      Parameters[paramIndex++] = inByteStream[++inputIndex] >> 5 & 0x7;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 2 & 0x7;
      Parameters[paramIndex++] = (inByteStream[inputIndex] & 0x3) << 1 | inByteStream[++inputIndex] >> 7 & 0x1;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 4 & 0x7;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 1 & 0x7;
      Parameters[paramIndex++] = (inByteStream[inputIndex] & 0x1) << 2 | inByteStream[++inputIndex] >> 6 & 0x3;
      Parameters[paramIndex++] = inByteStream[inputIndex] >> 3 & 0x7;
      Parameters[paramIndex++] = inByteStream[inputIndex] & 0x7;
      inputIndex++;
    } 
    return true;
  }
}
