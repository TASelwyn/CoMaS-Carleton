package com.ibm.media.codec.video.h263;

public class FrameBuffer {
  public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997, 1998.";
  
  public int[] Y;
  
  public int[] Cr;
  
  public int[] Cb;
  
  public int width;
  
  public int height;
  
  public FrameBuffer(int Fwidth, int Fheight) {
    this.width = Fwidth;
    this.height = Fheight;
    this.Y = new int[Fheight * Fwidth];
    this.Cr = new int[(Fheight >> 1) * (Fwidth >> 1)];
    this.Cb = new int[(Fheight >> 1) * (Fwidth >> 1)];
    int i;
    for (i = 0; i < this.width * this.height >> 2; i++) {
      this.Cb[i] = 128;
      this.Cr[i] = 128;
    } 
    for (i = 0; i < this.width * this.height; i++)
      this.Y[i] = 128; 
  }
}
