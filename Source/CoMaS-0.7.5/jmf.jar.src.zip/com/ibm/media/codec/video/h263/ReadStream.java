package com.ibm.media.codec.video.h263;

public class ReadStream {
  public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997, 1998.";
  
  protected int rdptr;
  
  private byte[] rdbfr;
  
  private int incnt = 0;
  
  long lBufferHistory = 0L;
  
  public void initBitstream() {
    this.incnt = 0;
  }
  
  public void setInBuf(byte[] ds_rdbfr, int ds_rdbfr_offset) {
    this.rdbfr = ds_rdbfr;
    this.rdptr = ds_rdbfr_offset;
  }
  
  public int getInBufOffset() {
    return this.rdptr;
  }
  
  protected final int nextBits(int n) {
    if (this.incnt < n)
      fillBuffer(); 
    return (int)(this.lBufferHistory << 64 - this.incnt >>> 64 - n);
  }
  
  protected final void skipBits(int n) {
    this.incnt -= n;
    if (this.incnt < 0)
      fillBuffer(); 
  }
  
  protected final int getBits(int n) {
    int bits = nextBits(n);
    this.incnt -= n;
    return bits;
  }
  
  private final void fillBuffer() {
    this.lBufferHistory <<= 32L;
    int newBits = this.rdbfr[this.rdptr++] << 24 | (this.rdbfr[this.rdptr++] & 0xFF) << 16 | (this.rdbfr[this.rdptr++] & 0xFF) << 8 | this.rdbfr[this.rdptr++] & 0xFF;
    this.lBufferHistory |= newBits & 0xFFFFFFFFL;
    this.incnt += 32;
  }
}
