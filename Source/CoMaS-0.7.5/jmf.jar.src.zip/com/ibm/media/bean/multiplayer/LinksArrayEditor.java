package com.ibm.media.bean.multiplayer;

import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Label;
import java.awt.List;
import java.awt.Panel;
import java.awt.Rectangle;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.beans.PropertyEditor;
import java.beans.PropertyEditorSupport;
import java.io.Serializable;

public class LinksArrayEditor extends PropertyEditorSupport implements PropertyEditor, Serializable, ActionListener, ItemListener {
  PropertyChangeSupport support = new PropertyChangeSupport(this);
  
  Panel linksPanel = new Panel();
  
  transient String[] oldValue;
  
  transient String[] newValue;
  
  List mediaGroup = new List(5);
  
  List related = new List(5);
  
  List start = new List(5);
  
  List stop = new List(5);
  
  TextField relatedField = new TextField(20);
  
  TextField startField = new TextField(3);
  
  TextField stopField = new TextField(3);
  
  TextField mediaNumField = new TextField(3);
  
  Button addLink = new Button(JMFUtil.getBIString("ADD"));
  
  Button delLink = new Button(JMFUtil.getBIString("DELETE"));
  
  Label mediaLabel = new Label(JMFUtil.getBIString("MEDIA_GROUP"));
  
  Label linkLabel = new Label(JMFUtil.getBIString("RELATED_LINK_URL"));
  
  Label startLabel = new Label(JMFUtil.getBIString("START_TIME"));
  
  Label stopLabel = new Label(JMFUtil.getBIString("STOP_TIME"));
  
  Panel pan = null;
  
  String addLinkC = "addLink";
  
  String delLinkC = "delLink";
  
  public Component getCustomEditor() {
    if (this.pan == null)
      this.pan = createGuiPanel(); 
    return this.pan;
  }
  
  public void paintValue(Graphics g, Rectangle r) {
    g.setColor(Color.black);
    g.draw3DRect(1, 1, r.width - 2, r.height - 2, true);
    g.setColor(Color.black);
    g.setFont(new Font("Helevetica", 1, 9));
    g.drawString(getAsText(), 5, r.height / 2 + 5);
  }
  
  public boolean supportsCustomEditor() {
    return true;
  }
  
  public void setAsText(String s) {
    setValue(JMFUtil.parseStringIntoArray(s));
  }
  
  public String getAsText() {
    return JMFUtil.parseArrayIntoString(this.newValue);
  }
  
  public String getJavaInitializationString() {
    StringBuffer initString = new StringBuffer("");
    if (this.newValue == null)
      return "null"; 
    initString = new StringBuffer("new String[] {\"");
    for (int i = 0; i < this.newValue.length; i++) {
      initString.append(JMFUtil.convertString(this.newValue[i]));
      if (i + 1 != this.newValue.length)
        initString.append("\",\""); 
    } 
    initString.append("\"}");
    return initString.toString();
  }
  
  public boolean isPaintable() {
    return true;
  }
  
  public void setValue(Object val) {
    this.oldValue = this.newValue;
    if (val instanceof String) {
      this.newValue = JMFUtil.parseStringIntoArray((String)val);
    } else {
      this.newValue = (String[])val;
    } 
    firePropertyChange();
    this.support.firePropertyChange("links", (Object)null, this.newValue);
  }
  
  public Object getValue() {
    return this.newValue;
  }
  
  public Panel createGuiPanel() {
    GridBagLayout gridbag = new GridBagLayout();
    GridBagConstraints c = new GridBagConstraints();
    this.linksPanel.setLayout(gridbag);
    this.linksPanel.setBackground(Color.lightGray);
    this.linksPanel.setForeground(Color.black);
    this.delLink.setEnabled(false);
    this.linksPanel.setLayout(gridbag);
    refreshLists();
    c.gridx = 1;
    c.gridy = 1;
    c.gridwidth = 1;
    c.gridheight = 1;
    c.anchor = 17;
    c.fill = 0;
    c.weightx = 0.0D;
    c.weighty = 0.0D;
    this.linksPanel.add(this.mediaLabel, c);
    c.gridx = 2;
    c.gridy = 1;
    c.gridwidth = 3;
    c.gridheight = 1;
    c.anchor = 17;
    c.fill = 0;
    c.weightx = 0.0D;
    c.weighty = 0.0D;
    this.linksPanel.add(this.linkLabel, c);
    c.gridx = 5;
    c.gridy = 1;
    c.gridwidth = 1;
    c.gridheight = 1;
    c.anchor = 17;
    c.fill = 0;
    c.weightx = 0.0D;
    c.weighty = 0.0D;
    this.linksPanel.add(this.startLabel, c);
    c.gridx = 6;
    c.gridy = 1;
    c.gridwidth = 1;
    c.gridheight = 1;
    c.anchor = 17;
    c.fill = 0;
    c.weightx = 0.0D;
    c.weighty = 0.0D;
    this.linksPanel.add(this.stopLabel, c);
    c.gridx = 1;
    c.gridy = 2;
    c.gridwidth = 1;
    c.gridheight = 5;
    c.anchor = 17;
    c.fill = 3;
    c.weightx = 1.0D;
    c.weighty = 0.0D;
    this.mediaGroup.addItemListener(this);
    this.linksPanel.add(this.mediaGroup, c);
    c.gridx = 2;
    c.gridy = 2;
    c.gridwidth = 3;
    c.gridheight = 5;
    c.anchor = 17;
    c.fill = 1;
    c.weightx = 1.0D;
    c.weighty = 1.0D;
    this.related.addItemListener(this);
    this.linksPanel.add(this.related, c);
    c.gridx = 5;
    c.gridy = 2;
    c.gridwidth = 1;
    c.gridheight = 5;
    c.anchor = 17;
    c.fill = 3;
    c.weightx = 1.0D;
    c.weighty = 0.0D;
    this.start.addItemListener(this);
    this.linksPanel.add(this.start, c);
    c.gridx = 6;
    c.gridy = 2;
    c.gridwidth = 1;
    c.gridheight = 5;
    c.anchor = 17;
    c.fill = 3;
    c.weightx = 1.0D;
    c.weighty = 0.0D;
    this.stop.addItemListener(this);
    this.linksPanel.add(this.stop, c);
    c.gridx = 1;
    c.gridy = 7;
    c.gridwidth = 1;
    c.gridheight = 1;
    c.insets = new Insets(1, 1, 1, 1);
    c.anchor = 10;
    c.fill = 0;
    c.weightx = 0.0D;
    c.weighty = 0.0D;
    this.linksPanel.add(this.mediaNumField, c);
    c.gridx = 2;
    c.gridy = 7;
    c.gridwidth = 1;
    c.gridheight = 1;
    c.insets = new Insets(1, 1, 1, 1);
    c.anchor = 17;
    c.fill = 0;
    c.weightx = 0.0D;
    c.weighty = 0.0D;
    this.linksPanel.add(new Label("http://"), c);
    c.gridx = 3;
    c.gridy = 7;
    c.gridwidth = 2;
    c.gridheight = 1;
    c.insets = new Insets(1, 1, 1, 1);
    c.anchor = 10;
    c.fill = 2;
    c.weightx = 0.0D;
    c.weighty = 1.0D;
    this.linksPanel.add(this.relatedField, c);
    c.gridx = 5;
    c.gridy = 7;
    c.gridwidth = 1;
    c.gridheight = 1;
    c.insets = new Insets(1, 1, 1, 1);
    c.anchor = 10;
    c.fill = 0;
    c.weightx = 0.0D;
    c.weighty = 0.0D;
    this.linksPanel.add(this.startField, c);
    c.gridx = 6;
    c.gridy = 7;
    c.gridwidth = 1;
    c.gridheight = 1;
    c.insets = new Insets(1, 1, 1, 1);
    c.anchor = 10;
    c.fill = 0;
    c.weightx = 0.0D;
    c.weighty = 0.0D;
    this.linksPanel.add(this.stopField, c);
    c.gridx = 1;
    c.gridy = 9;
    c.gridwidth = 1;
    c.gridheight = 1;
    c.insets = new Insets(1, 1, 1, 1);
    c.anchor = 10;
    c.fill = 0;
    c.weightx = 0.0D;
    c.weighty = 0.0D;
    this.addLink.addActionListener(this);
    this.addLink.setActionCommand(this.addLinkC);
    this.linksPanel.add(this.addLink, c);
    c.gridx = 2;
    c.gridy = 9;
    c.gridwidth = 1;
    c.gridheight = 1;
    c.insets = new Insets(1, 1, 1, 1);
    c.anchor = 10;
    c.fill = 0;
    c.weightx = 0.0D;
    c.weighty = 0.0D;
    this.delLink.addActionListener(this);
    this.delLink.setActionCommand(this.delLinkC);
    this.linksPanel.add(this.delLink, c);
    return this.linksPanel;
  }
  
  private void refreshLists() {
    this.mediaGroup.removeAll();
    this.related.removeAll();
    this.start.removeAll();
    this.stop.removeAll();
    if (this.newValue != null)
      for (int i = 0; i < this.newValue.length; i += 4) {
        this.mediaGroup.add(this.newValue[i]);
        this.related.add(this.newValue[i + 1]);
        this.start.add(this.newValue[i + 2]);
        this.stop.add(this.newValue[i + 3]);
      }  
  }
  
  public void actionPerformed(ActionEvent e) {
    if (e.getActionCommand().equals(this.addLinkC)) {
      processAdd();
    } else if (e.getActionCommand().equals(this.delLinkC)) {
      deleteLink();
    } 
  }
  
  public void itemStateChanged(ItemEvent e) {
    Object o1 = e.getItemSelectable();
    if (o1 instanceof List) {
      List l1 = (List)o1;
      int i = ((Integer)e.getItem()).intValue();
      int state = e.getStateChange();
      if (l1 == this.related || l1 == this.start || l1 == this.stop || l1 == this.mediaGroup) {
        l1 = this.related;
        List l2 = this.start;
        List l3 = this.stop;
        List l4 = this.mediaGroup;
        if (state == 1) {
          l1.select(i);
          l2.select(i);
          l3.select(i);
          l4.select(i);
          this.delLink.setEnabled(true);
        } else if (state == 2) {
          l1.deselect(i);
          l2.deselect(i);
          l3.deselect(i);
          l4.deselect(i);
          this.delLink.setEnabled(false);
        } 
      } 
    } 
  }
  
  private void processAdd() {
    long startTime, stopTime;
    int mediaIndex;
    StringBuffer relatedBuffer = new StringBuffer("http://");
    String mString = this.mediaNumField.getText();
    String rString = this.relatedField.getText();
    String startString = this.startField.getText();
    String stopString = this.stopField.getText();
    if (startString.equals("") && stopString.equals("")) {
      startString = new String("0");
      stopString = new String("0");
    } 
    if (mString.equals("") || rString.equals("") || startString.equals("") || stopString.equals("")) {
      DTMsgBox.createAndGo(JMFUtil.getBIString("JMF_MultiPlayer"), JMFUtil.getBIString("NOVALUE"));
      return;
    } 
    try {
      startTime = Long.parseLong(startString);
      stopTime = Long.parseLong(stopString);
    } catch (NumberFormatException e) {
      DTMsgBox.createAndGo(JMFUtil.getBIString("JMF_MultiPlayer"), JMFUtil.getBIString("TIMES") + ": " + JMFUtil.getBIString("0orGreater"));
      return;
    } 
    try {
      mediaIndex = Integer.parseInt(mString);
    } catch (NumberFormatException e) {
      DTMsgBox.createAndGo(JMFUtil.getBIString("JMF_MultiPlayer"), JMFUtil.getBIString("INDEX") + ": " + JMFUtil.getBIString("1orGreater"));
      return;
    } 
    if (startTime < 0L || stopTime < 0L) {
      DTMsgBox.createAndGo(JMFUtil.getBIString("JMF_MultiPlayer"), JMFUtil.getBIString("TIMES") + ": " + JMFUtil.getBIString("0orGreater"));
      return;
    } 
    if (mediaIndex < 1) {
      DTMsgBox.createAndGo(JMFUtil.getBIString("JMF_MultiPlayer"), JMFUtil.getBIString("INDEX") + ": " + JMFUtil.getBIString("1orGreater"));
      return;
    } 
    relatedBuffer.append(rString);
    if (duplicate(mString, relatedBuffer.toString(), startString, stopString)) {
      DTMsgBox.createAndGo(JMFUtil.getBIString("JMF_MultiPlayer"), JMFUtil.getBIString("DUPLICATE_LINK"));
      return;
    } 
    int l = 0;
    if (this.newValue != null)
      l = this.newValue.length; 
    String[] temp = new String[l + 4];
    JMFUtil.copyStringArray(this.newValue, temp);
    temp[l] = mString;
    temp[l + 1] = relatedBuffer.toString();
    temp[l + 2] = startString;
    temp[l + 3] = stopString;
    this.mediaGroup.add(temp[l]);
    this.related.add(temp[l + 1]);
    this.start.add(temp[l + 2]);
    this.stop.add(temp[l + 3]);
    this.mediaNumField.setText("");
    this.relatedField.setText("");
    this.startField.setText("");
    this.stopField.setText("");
    setValue(temp);
  }
  
  private boolean duplicate(String media, String relatedS, String startS, String stopS) {
    for (int i = 0; i < this.mediaGroup.getItemCount(); i++) {
      if ((media.equals(this.mediaGroup.getItem(i)) & relatedS.equals(this.related.getItem(i)) & startS.equals(this.start.getItem(i)) & stopS.equals(this.stop.getItem(i))) != 0)
        return true; 
    } 
    return false;
  }
  
  private void deleteLink() {
    String[] temp = null;
    int j = this.mediaGroup.getSelectedIndex();
    int index = j * 4;
    int newSize = 0;
    if (this.newValue != null) {
      newSize = this.newValue.length - 4;
      if (newSize > 4) {
        temp = new String[newSize];
        JMFUtil.copyShortenStringArray(this.newValue, temp, index, 4);
      } 
    } 
    this.mediaGroup.remove(j);
    this.related.remove(j);
    this.start.remove(j);
    this.stop.remove(j);
    this.delLink.setEnabled(false);
    setValue(temp);
  }
  
  public void addPropertyChangeListener(PropertyChangeListener listener) {
    this.support.addPropertyChangeListener(listener);
  }
  
  public void removePropertyChangeListener(PropertyChangeListener listener) {
    this.support.removePropertyChangeListener(listener);
  }
}
