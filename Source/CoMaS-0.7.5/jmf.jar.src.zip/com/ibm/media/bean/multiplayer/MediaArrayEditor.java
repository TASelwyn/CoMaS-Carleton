package com.ibm.media.bean.multiplayer;

import java.awt.Button;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Component;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Label;
import java.awt.List;
import java.awt.Panel;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.beans.PropertyEditor;
import java.beans.PropertyEditorSupport;
import java.io.Serializable;

public class MediaArrayEditor extends PropertyEditorSupport implements PropertyEditor, Serializable, ActionListener, ItemListener {
  PropertyChangeSupport support = new PropertyChangeSupport(this);
  
  Panel guiP = new Panel();
  
  transient String[] oldValue;
  
  transient String[] newValue;
  
  List media = new List(10);
  
  List button = new List(10);
  
  Label mediaURL = new Label(JMFUtil.getBIString("MEDIA_URL"));
  
  Label buttonURL = new Label(JMFUtil.getBIString("BUTTON_IMAGE_URL"));
  
  Button add = new Button(JMFUtil.getBIString("ADD"));
  
  Button del = new Button(JMFUtil.getBIString("DELETE"));
  
  Button up = new Button(JMFUtil.getBIString("UP"));
  
  Button down = new Button(JMFUtil.getBIString("DOWN"));
  
  Label one = new Label("1", 1);
  
  Label two = new Label("2", 1);
  
  Label three = new Label("3", 1);
  
  Label four = new Label("4", 1);
  
  Label five = new Label("5", 1);
  
  Label six = new Label("6", 1);
  
  Label seven = new Label("7", 1);
  
  Label eight = new Label("8", 1);
  
  Label nine = new Label("9", 1);
  
  Label ten = new Label("10", 1);
  
  GridBagLayout gridbag = new GridBagLayout();
  
  GridBagConstraints c = new GridBagConstraints();
  
  Panel addPanel = null;
  
  Choice mediaChoice = new Choice();
  
  Choice buttonChoice = new Choice();
  
  TextField mediaField = new TextField(20);
  
  TextField buttonField = new TextField(20);
  
  String codebase = "codebase/";
  
  String http = "http://";
  
  String fileS = "file:///";
  
  private String browseString = "...";
  
  private Button mediaBrowse = new Button(this.browseString);
  
  private Button buttonBrowse = new Button(this.browseString);
  
  private String browseDir = ".";
  
  Panel pan = null;
  
  public Component getCustomEditor() {
    if (this.pan == null)
      this.pan = createGuiPanel(); 
    if ((this.pan.getSize()).width > 600)
      this.pan.setSize(600, (this.pan.getSize()).height); 
    return this.pan;
  }
  
  public void setAsText(String s) {
    setValue(JMFUtil.parseStringIntoArray(s));
  }
  
  public String getAsText() {
    return JMFUtil.parseArrayIntoString(this.newValue);
  }
  
  public String getJavaInitializationString() {
    StringBuffer initString = new StringBuffer("");
    if (this.newValue != null) {
      initString = new StringBuffer("new String[] {\"");
      for (int i = 0; i < this.newValue.length; i++) {
        initString.append(JMFUtil.convertString(this.newValue[i]));
        if (i + 1 != this.newValue.length)
          initString.append("\",\""); 
      } 
      initString.append("\"}");
    } 
    return initString.toString() + ",this";
  }
  
  public void paintValue(Graphics g, Rectangle r) {
    g.setColor(Color.black);
    g.draw3DRect(1, 1, r.width - 2, r.height - 2, true);
    g.setColor(Color.black);
    g.setFont(new Font("Helevetica", 1, 9));
    g.drawString(getAsText(), 5, r.height / 2 + 5);
  }
  
  public boolean supportsCustomEditor() {
    return true;
  }
  
  public boolean isPaintable() {
    return true;
  }
  
  public void setValue(Object val) {
    String newStrng = "";
    this.oldValue = this.newValue;
    if (val instanceof String) {
      this.newValue = JMFUtil.parseStringIntoArray((String)val);
    } else {
      this.newValue = (String[])val;
    } 
    newStrng = JMFUtil.parseArrayIntoString(this.newValue);
    doDebug("firePropertyChange in MediaNames: " + newStrng);
    this.support.firePropertyChange("mediaNames", (Object)null, this.newValue);
  }
  
  public Object getValue() {
    return this.newValue;
  }
  
  public Panel createGuiPanel() {
    this.guiP.setLayout(this.gridbag);
    this.guiP.setBackground(Color.lightGray);
    this.guiP.setForeground(Color.black);
    this.c.gridx = 2;
    this.c.gridy = 1;
    this.c.gridwidth = 5;
    this.c.gridheight = 1;
    this.c.anchor = 10;
    this.c.fill = 2;
    this.c.weightx = 1.0D;
    this.c.weighty = 0.0D;
    this.mediaURL.setAlignment(1);
    this.guiP.add(this.mediaURL, this.c);
    this.c.gridx = 7;
    this.c.gridy = 1;
    this.c.gridwidth = 5;
    this.c.gridheight = 1;
    this.c.anchor = 10;
    this.c.fill = 2;
    this.c.weightx = 1.0D;
    this.c.weighty = 0.0D;
    this.buttonURL.setAlignment(1);
    this.guiP.add(this.buttonURL, this.c);
    refreshLists();
    this.c.gridx = 1;
    this.c.gridy = 2;
    this.c.gridwidth = 1;
    this.c.gridheight = 1;
    this.c.anchor = 10;
    this.c.fill = 2;
    this.c.weightx = 0.0D;
    this.c.weighty = 0.0D;
    this.guiP.add(this.one, this.c);
    this.c.gridx = 1;
    this.c.gridy = 3;
    this.c.gridwidth = 1;
    this.c.gridheight = 1;
    this.c.anchor = 10;
    this.c.fill = 2;
    this.c.weightx = 0.0D;
    this.c.weighty = 0.0D;
    this.guiP.add(this.two, this.c);
    this.c.gridx = 1;
    this.c.gridy = 4;
    this.c.gridwidth = 1;
    this.c.gridheight = 1;
    this.c.anchor = 10;
    this.c.fill = 2;
    this.c.weightx = 0.0D;
    this.c.weighty = 0.0D;
    this.guiP.add(this.three, this.c);
    this.c.gridx = 1;
    this.c.gridy = 5;
    this.c.gridwidth = 1;
    this.c.gridheight = 1;
    this.c.anchor = 10;
    this.c.fill = 2;
    this.c.weightx = 0.0D;
    this.c.weighty = 0.0D;
    this.guiP.add(this.four, this.c);
    this.c.gridx = 1;
    this.c.gridy = 6;
    this.c.gridwidth = 1;
    this.c.gridheight = 1;
    this.c.anchor = 10;
    this.c.fill = 2;
    this.c.weightx = 0.0D;
    this.c.weighty = 0.0D;
    this.guiP.add(this.five, this.c);
    this.c.gridx = 1;
    this.c.gridy = 7;
    this.c.gridwidth = 1;
    this.c.gridheight = 1;
    this.c.anchor = 10;
    this.c.fill = 2;
    this.c.weightx = 0.0D;
    this.c.weighty = 0.0D;
    this.guiP.add(this.six, this.c);
    this.c.gridx = 1;
    this.c.gridy = 8;
    this.c.gridwidth = 1;
    this.c.gridheight = 1;
    this.c.anchor = 10;
    this.c.fill = 2;
    this.c.weightx = 0.0D;
    this.c.weighty = 0.0D;
    this.guiP.add(this.seven, this.c);
    this.c.gridx = 1;
    this.c.gridy = 9;
    this.c.gridwidth = 1;
    this.c.gridheight = 1;
    this.c.anchor = 10;
    this.c.fill = 2;
    this.c.weightx = 0.0D;
    this.c.weighty = 0.0D;
    this.guiP.add(this.eight, this.c);
    this.c.gridx = 1;
    this.c.gridy = 10;
    this.c.gridwidth = 1;
    this.c.gridheight = 1;
    this.c.anchor = 10;
    this.c.fill = 2;
    this.c.weightx = 0.0D;
    this.c.weighty = 0.0D;
    this.guiP.add(this.nine, this.c);
    this.c.gridx = 1;
    this.c.gridy = 11;
    this.c.gridwidth = 1;
    this.c.gridheight = 1;
    this.c.anchor = 10;
    this.c.fill = 2;
    this.c.weightx = 0.0D;
    this.c.weighty = 0.0D;
    this.guiP.add(this.ten, this.c);
    this.c.gridx = 2;
    this.c.gridy = 2;
    this.c.gridwidth = 5;
    this.c.gridheight = 10;
    this.c.anchor = 10;
    this.c.fill = 1;
    this.c.weightx = 1.0D;
    this.c.weighty = 1.0D;
    this.media.addItemListener(this);
    this.guiP.add(this.media, this.c);
    this.c.gridx = 7;
    this.c.gridy = 2;
    this.c.gridwidth = 5;
    this.c.gridheight = 10;
    this.c.anchor = 10;
    this.c.fill = 1;
    this.c.weightx = 1.0D;
    this.c.weighty = 1.0D;
    this.button.addItemListener(this);
    this.guiP.add(this.button, this.c);
    this.c.gridx = 2;
    this.c.gridy = 12;
    this.c.gridwidth = 5;
    this.c.gridheight = 1;
    this.c.anchor = 13;
    this.c.fill = 2;
    this.c.weightx = 1.0D;
    this.c.weighty = 0.0D;
    this.c.insets = new Insets(5, 0, 0, 5);
    this.mediaChoice.addItemListener(this);
    this.mediaChoice.add(this.codebase);
    this.mediaChoice.add(this.http);
    this.mediaChoice.add(this.fileS);
    this.mediaBrowse.addActionListener(this);
    this.mediaBrowse.setActionCommand("browseMedia");
    this.mediaBrowse.setEnabled(false);
    Component[] comp1 = { this.mediaChoice, this.mediaField, this.mediaBrowse };
    Panel p1 = JMFUtil.doGridbagLayout2(comp1, 3, 2);
    this.guiP.add(p1, this.c);
    this.c.gridx = 7;
    this.c.gridy = 12;
    this.c.gridwidth = 5;
    this.c.gridheight = 1;
    this.c.anchor = 13;
    this.c.fill = 2;
    this.c.weightx = 1.0D;
    this.c.weighty = 0.0D;
    this.c.insets = new Insets(5, 0, 0, 5);
    this.buttonChoice.addItemListener(this);
    this.buttonChoice.add(this.codebase);
    this.buttonChoice.add(this.http);
    this.buttonChoice.add(this.fileS);
    this.buttonBrowse.addActionListener(this);
    this.buttonBrowse.setActionCommand("browseButton");
    this.buttonBrowse.setEnabled(false);
    Component[] comp2 = { this.buttonChoice, this.buttonField, this.buttonBrowse };
    Panel p2 = JMFUtil.doGridbagLayout2(comp2, 3, 2);
    this.guiP.add(p2, this.c);
    this.c.gridx = 2;
    this.c.gridy = 13;
    this.c.gridwidth = 5;
    this.c.gridheight = 1;
    this.c.anchor = 16;
    this.c.fill = 2;
    this.c.weightx = 1.0D;
    this.c.weighty = 0.0D;
    this.add.setActionCommand("add");
    this.add.addActionListener(this);
    this.add.setEnabled(true);
    this.guiP.add(this.add, this.c);
    this.c.gridx = 7;
    this.c.gridy = 13;
    this.c.gridwidth = 5;
    this.c.gridheight = 1;
    this.c.anchor = 18;
    this.c.fill = 2;
    this.c.weightx = 1.0D;
    this.c.weighty = 0.0D;
    this.del.setActionCommand("del");
    this.del.addActionListener(this);
    this.del.setEnabled(false);
    this.guiP.add(this.del, this.c);
    this.c.gridx = 2;
    this.c.gridy = 14;
    this.c.gridwidth = 5;
    this.c.gridheight = 1;
    this.c.anchor = 16;
    this.c.fill = 2;
    this.c.weightx = 1.0D;
    this.c.weighty = 0.0D;
    this.up.setActionCommand("up");
    this.up.addActionListener(this);
    this.up.setEnabled(false);
    this.guiP.add(this.up, this.c);
    this.c.gridx = 7;
    this.c.gridy = 14;
    this.c.gridwidth = 5;
    this.c.gridheight = 1;
    this.c.anchor = 18;
    this.c.fill = 2;
    this.c.weightx = 1.0D;
    this.c.weighty = 0.0D;
    this.down.setActionCommand("down");
    this.down.addActionListener(this);
    this.down.setEnabled(false);
    this.guiP.add(this.down, this.c);
    return this.guiP;
  }
  
  private void refreshLists() {
    this.media.removeAll();
    this.button.removeAll();
    if (this.newValue != null)
      for (int i = 0; i < this.newValue.length; i += 2) {
        this.media.add(this.newValue[i]);
        this.button.add(this.newValue[i + 1]);
      }  
    this.media.setSize(75, 232);
    this.button.setSize(75, 232);
  }
  
  public void actionPerformed(ActionEvent e) {
    if (e.getActionCommand().equals("add")) {
      processAdd();
    } else if (e.getActionCommand().equals("del")) {
      deleteGroup();
    } else if (e.getActionCommand().equals("up")) {
      moveSelectedUp();
    } else if (e.getActionCommand().equals("down")) {
      moveSelectedDown();
    } else if (e.getActionCommand().equals("browseMedia")) {
      getFile(this.mediaField);
    } else if (e.getActionCommand().equals("browseButton")) {
      getFile(this.buttonField);
    } 
  }
  
  public void itemStateChanged(ItemEvent e) {
    Object o1 = e.getItemSelectable();
    if (o1 instanceof List) {
      List l1 = (List)o1;
      int i = ((Integer)e.getItem()).intValue();
      int state = e.getStateChange();
      if (l1 == this.media || l1 == this.button) {
        List list;
        if (l1 == this.media) {
          list = this.button;
        } else {
          list = this.media;
        } 
        if (state == 1) {
          list.select(i);
          this.del.setEnabled(true);
          enableUpDown(i);
        } else if (state == 2) {
          list.deselect(i);
          this.down.setEnabled(false);
          this.up.setEnabled(false);
          this.del.setEnabled(false);
        } 
      } 
    } else if (o1 instanceof Choice) {
      Choice c1 = (Choice)o1;
      String protocol = c1.getSelectedItem();
      if (c1 == this.mediaChoice) {
        if (protocol.equals(this.fileS)) {
          this.mediaBrowse.setEnabled(true);
        } else {
          this.mediaBrowse.setEnabled(false);
        } 
      } else if (c1 == this.buttonChoice) {
        if (protocol.equals(this.fileS)) {
          this.buttonBrowse.setEnabled(true);
        } else {
          this.buttonBrowse.setEnabled(false);
        } 
      } 
    } 
  }
  
  private void processAdd() {
    StringBuffer mText = new StringBuffer();
    StringBuffer bText = new StringBuffer();
    String mString = this.mediaField.getText();
    String bString = this.buttonField.getText();
    String bChoice = this.buttonChoice.getSelectedItem();
    String mChoice = this.mediaChoice.getSelectedItem();
    if (mString.equals("")) {
      DTMsgBox.createAndGo(JMFUtil.getBIString("JMF_MultiPlayer"), JMFUtil.getBIString("NOVALUE"));
      return;
    } 
    if (!mChoice.equals(this.codebase)) {
      mText.append(mChoice);
      mText.append(mString);
    } else {
      mText.append(mString);
    } 
    if (!bString.equals("")) {
      if (!bChoice.equals(this.codebase)) {
        bText.append(bChoice);
        bText.append(bString);
      } else {
        bText.append(bString);
      } 
    } else {
      bText.append("");
    } 
    int l = 0;
    if (this.newValue != null)
      l = this.newValue.length; 
    doDebug("Old length = " + l);
    String[] temp = new String[l + 2];
    JMFUtil.copyStringArray(this.newValue, temp);
    temp[l] = mText.toString();
    temp[l + 1] = bText.toString();
    this.media.add(temp[l]);
    this.button.add(temp[l + 1]);
    this.mediaField.setText("");
    this.buttonField.setText("");
    setValue(temp);
  }
  
  private void moveSelectedUp() {
    int i = this.media.getSelectedIndex();
    if (i != 0) {
      String mURL = this.media.getSelectedItem();
      String bURL = this.button.getSelectedItem();
      this.media.remove(i);
      this.button.remove(i);
      this.media.add(mURL, i - 1);
      this.button.add(bURL, i - 1);
      this.media.select(i - 1);
      this.button.select(i - 1);
      this.newValue[i * 2] = this.newValue[(i - 1) * 2];
      this.newValue[i * 2 + 1] = this.newValue[(i - 1) * 2 + 1];
      this.newValue[(i - 1) * 2] = mURL;
      this.newValue[(i - 1) * 2 + 1] = bURL;
      setValue(this.newValue);
      enableUpDown(i - 1);
    } 
  }
  
  private void moveSelectedDown() {
    int i = this.media.getSelectedIndex();
    if (i != this.media.getItemCount() - 1) {
      String mURL = this.media.getSelectedItem();
      String bURL = this.button.getSelectedItem();
      this.media.remove(i);
      this.button.remove(i);
      this.media.add(mURL, i + 1);
      this.button.add(bURL, i + 1);
      this.media.select(i + 1);
      this.button.select(i + 1);
      this.newValue[i * 2] = this.newValue[(i + 1) * 2];
      this.newValue[i * 2 + 1] = this.newValue[(i + 1) * 2 + 1];
      this.newValue[(i + 1) * 2] = mURL;
      this.newValue[(i + 1) * 2 + 1] = bURL;
      setValue(this.newValue);
      enableUpDown(i + 1);
    } 
  }
  
  private void enableUpDown(int i) {
    if (i < this.media.getItemCount() - 1) {
      this.down.setEnabled(true);
    } else {
      this.down.setEnabled(false);
    } 
    if (i > 0) {
      this.up.setEnabled(true);
    } else {
      this.up.setEnabled(false);
    } 
  }
  
  private void deleteGroup() {
    String[] temp = null;
    int j = this.media.getSelectedIndex();
    int index = j * 2;
    int newSize = 0;
    if (this.newValue != null) {
      newSize = this.newValue.length - 2;
      doDebug("NewValue size = " + newSize);
      if (newSize > 0) {
        temp = new String[newSize];
        JMFUtil.copyShortenStringArray(this.newValue, temp, index, 2);
      } 
    } 
    doDebug("Temp = " + temp);
    this.media.remove(j);
    this.button.remove(j);
    if (this.media.getItemCount() > j + 1) {
      this.media.select(j);
      this.button.select(j);
      enableUpDown(j);
    } else if (this.media.getItemCount() > 0) {
      this.media.select(j - 1);
      this.button.select(j - 1);
      enableUpDown(j - 1);
    } else {
      enableUpDown(-1);
      this.del.setEnabled(false);
    } 
    setValue(temp);
  }
  
  Frame getFrame(Component comp) {
    Point p = comp.getLocationOnScreen();
    Frame f = new Frame();
    f.setLocation(p);
    return f;
  }
  
  private void getFile(TextField tf) {
    String str1;
    doDebug("getFile " + tf);
    if (tf == this.mediaField) {
      str1 = JMFUtil.getBIString("SET_MEDIA_LOCATION");
    } else {
      str1 = JMFUtil.getBIString("SET_BUTTON_LOCATION");
    } 
    FileDialog fd = new FileDialog(getFrame(this.guiP), str1, 0);
    fd.setDirectory(this.browseDir);
    fd.setTitle(str1);
    fd.show();
    String filename = fd.getFile();
    if (fd.getDirectory() != null)
      this.browseDir = fd.getDirectory(); 
    if (filename != null && fd.getDirectory() != null)
      filename = fd.getDirectory() + filename; 
    if (filename != null) {
      filename = filename.replace('\\', '/');
      tf.setText(filename);
    } 
  }
  
  private void doDebug(String s) {}
  
  public void addPropertyChangeListener(PropertyChangeListener listener) {
    this.support.addPropertyChangeListener(listener);
  }
  
  public void removePropertyChangeListener(PropertyChangeListener listener) {
    this.support.removePropertyChangeListener(listener);
  }
  
  public String[] getTags() {
    return null;
  }
}
