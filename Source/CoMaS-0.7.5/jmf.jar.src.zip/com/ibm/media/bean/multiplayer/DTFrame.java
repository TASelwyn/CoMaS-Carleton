package com.ibm.media.bean.multiplayer;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Insets;

public class DTFrame extends Frame {
  public DTFrame(String str) {
    super(str);
    addWindowListener(new DTWinAdapter(false));
    enableEvents(8L);
    setBackground(Color.lightGray);
  }
  
  public DTFrame(String str, boolean doExit) {
    super(str);
    addWindowListener(new DTWinAdapter(doExit));
    enableEvents(8L);
    setBackground(Color.lightGray);
  }
  
  public Insets getInsets() {
    return new Insets(30, 10, 10, 10);
  }
}
