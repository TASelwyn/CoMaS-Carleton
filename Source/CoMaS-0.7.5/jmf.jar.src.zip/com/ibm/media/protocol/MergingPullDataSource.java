package com.ibm.media.protocol;

import java.io.IOException;
import javax.media.Time;
import javax.media.protocol.DataSource;
import javax.media.protocol.PullDataSource;
import javax.media.protocol.PullSourceStream;

public class MergingPullDataSource extends PullDataSource {
  MergingDataSource superClass;
  
  PullSourceStream[] streams;
  
  public MergingPullDataSource(PullDataSource[] sources) {
    this.superClass = new MergingDataSource((DataSource[])sources);
  }
  
  public PullSourceStream[] getStreams() {
    if (this.streams == null) {
      int totalNoOfStreams = 0;
      for (int i = 0; i < this.superClass.sources.length; i++)
        totalNoOfStreams += (((PullDataSource)this.superClass.sources[i]).getStreams()).length; 
      this.streams = new PullSourceStream[totalNoOfStreams];
      int totalIndex = 0;
      for (int sourceIndex = 0; sourceIndex < this.superClass.sources.length; sourceIndex++) {
        PullSourceStream[] s = ((PullDataSource)this.superClass.sources[sourceIndex]).getStreams();
        for (int streamIndex = 0; streamIndex < s.length; streamIndex++)
          this.streams[totalIndex++] = s[streamIndex]; 
      } 
    } 
    return this.streams;
  }
  
  public String getContentType() {
    return this.superClass.getContentType();
  }
  
  public void connect() throws IOException {
    this.superClass.connect();
  }
  
  public void disconnect() {
    this.superClass.disconnect();
  }
  
  public void start() throws IOException {
    this.superClass.start();
  }
  
  public void stop() throws IOException {
    this.superClass.stop();
  }
  
  public Time getDuration() {
    return this.superClass.getDuration();
  }
  
  public Object[] getControls() {
    return this.superClass.getControls();
  }
  
  public Object getControl(String controlType) {
    return this.superClass.getControl(controlType);
  }
}
