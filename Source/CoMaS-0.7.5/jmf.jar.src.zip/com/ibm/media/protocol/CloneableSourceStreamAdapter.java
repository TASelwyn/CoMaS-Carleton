package com.ibm.media.protocol;

import com.ms.security.PermissionID;
import com.ms.security.PolicyEngine;
import com.sun.media.JMFSecurity;
import com.sun.media.JMFSecurityManager;
import com.sun.media.util.MediaThread;
import com.sun.media.util.jdk12;
import com.sun.media.util.jdk12CreateThreadRunnableAction;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Vector;
import javax.media.Buffer;
import javax.media.Format;
import javax.media.protocol.BufferTransferHandler;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.PullBufferStream;
import javax.media.protocol.PullSourceStream;
import javax.media.protocol.PushBufferStream;
import javax.media.protocol.PushSourceStream;
import javax.media.protocol.SourceStream;
import javax.media.protocol.SourceTransferHandler;

public class CloneableSourceStreamAdapter {
  SourceStream master;
  
  SourceStream adapter = null;
  
  Vector slaves = new Vector();
  
  private static JMFSecurity jmfSecurity = null;
  
  private static boolean securityPrivelege = false;
  
  private Method[] m = new Method[1];
  
  private Class[] cl = new Class[1];
  
  private Object[][] args = new Object[1][0];
  
  protected int numTracks = 0;
  
  protected Format[] trackFormats;
  
  static {
    try {
      jmfSecurity = JMFSecurityManager.getJMFSecurity();
      securityPrivelege = true;
    } catch (SecurityException e) {}
  }
  
  CloneableSourceStreamAdapter(SourceStream master) {
    this.master = master;
    if (master instanceof PullSourceStream)
      this.adapter = new PullSourceStreamAdapter(this); 
    if (master instanceof PullBufferStream)
      this.adapter = new PullBufferStreamAdapter(this); 
    if (master instanceof PushSourceStream)
      this.adapter = new PushSourceStreamAdapter(this); 
    if (master instanceof PushBufferStream)
      this.adapter = new PushBufferStreamAdapter(this); 
  }
  
  SourceStream getAdapter() {
    return this.adapter;
  }
  
  SourceStream createSlave() {
    SourceStream slave = null;
    if (this.master instanceof PullSourceStream || this.master instanceof PushSourceStream)
      slave = new PushSourceStreamSlave(this); 
    if (this.master instanceof PullBufferStream || this.master instanceof PushBufferStream)
      slave = new PushBufferStreamSlave(this); 
    this.slaves.addElement(slave);
    return slave;
  }
  
  void copyAndRead(Buffer b) throws IOException {
    if (this.master instanceof PullBufferStream)
      ((PullBufferStream)this.master).read(b); 
    if (this.master instanceof PushBufferStream)
      ((PushBufferStream)this.master).read(b); 
    for (Enumeration e = this.slaves.elements(); e.hasMoreElements(); ) {
      Object stream = e.nextElement();
      ((PushBufferStreamSlave)stream).setBuffer((Buffer)b.clone());
      Thread.yield();
    } 
  }
  
  int copyAndRead(byte[] buffer, int offset, int length) throws IOException {
    int totalRead = 0;
    if (this.master instanceof PullSourceStream)
      totalRead = ((PullSourceStream)this.master).read(buffer, offset, length); 
    if (this.master instanceof PushSourceStream)
      totalRead = ((PushSourceStream)this.master).read(buffer, offset, length); 
    for (Enumeration e = this.slaves.elements(); e.hasMoreElements(); ) {
      Object stream = e.nextElement();
      byte[] copyBuffer = new byte[totalRead];
      System.arraycopy(buffer, offset, copyBuffer, 0, totalRead);
      ((PushSourceStreamSlave)stream).setBuffer(copyBuffer);
    } 
    return totalRead;
  }
  
  class SourceStreamAdapter implements SourceStream {
    private final CloneableSourceStreamAdapter this$0;
    
    SourceStreamAdapter(CloneableSourceStreamAdapter this$0) {
      this.this$0 = this$0;
    }
    
    public ContentDescriptor getContentDescriptor() {
      return this.this$0.master.getContentDescriptor();
    }
    
    public long getContentLength() {
      return this.this$0.master.getContentLength();
    }
    
    public boolean endOfStream() {
      return this.this$0.master.endOfStream();
    }
    
    public Object[] getControls() {
      return this.this$0.master.getControls();
    }
    
    public Object getControl(String controlType) {
      return this.this$0.master.getControl(controlType);
    }
  }
  
  abstract class PushStreamSlave extends SourceStreamAdapter implements SourceStreamSlave, Runnable {
    MediaThread notifyingThread;
    
    boolean connected;
    
    private final CloneableSourceStreamAdapter this$0;
    
    PushStreamSlave(CloneableSourceStreamAdapter this$0) {
      super(this$0);
      this.this$0 = this$0;
      this.connected = false;
    }
    
    public synchronized void connect() {
      if (this.connected)
        return; 
      this.connected = true;
      if (CloneableSourceStreamAdapter.jmfSecurity != null) {
        String permission = null;
        try {
          if (CloneableSourceStreamAdapter.jmfSecurity.getName().startsWith("jmf-security")) {
            permission = "thread";
            CloneableSourceStreamAdapter.jmfSecurity.requestPermission(this.this$0.m, this.this$0.cl, this.this$0.args, 16);
            this.this$0.m[0].invoke(this.this$0.cl[0], this.this$0.args[0]);
            permission = "thread group";
            CloneableSourceStreamAdapter.jmfSecurity.requestPermission(this.this$0.m, this.this$0.cl, this.this$0.args, 32);
            this.this$0.m[0].invoke(this.this$0.cl[0], this.this$0.args[0]);
          } else if (CloneableSourceStreamAdapter.jmfSecurity.getName().startsWith("internet")) {
            PolicyEngine.checkPermission(PermissionID.THREAD);
            PolicyEngine.assertPermission(PermissionID.THREAD);
          } 
        } catch (Throwable e) {
          CloneableSourceStreamAdapter.securityPrivelege = false;
        } 
      } 
      if (CloneableSourceStreamAdapter.jmfSecurity != null && CloneableSourceStreamAdapter.jmfSecurity.getName().startsWith("jdk12")) {
        try {
          Constructor cons = jdk12CreateThreadRunnableAction.cons;
          this.notifyingThread = (MediaThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { MediaThread.class, this }) });
        } catch (Exception e) {}
      } else {
        this.notifyingThread = new MediaThread(this);
      } 
      if (this.notifyingThread != null) {
        if (this.this$0.master instanceof PushBufferStream)
          if (((PushBufferStream)this.this$0.master).getFormat() instanceof javax.media.format.VideoFormat) {
            this.notifyingThread.useVideoPriority();
          } else {
            this.notifyingThread.useAudioPriority();
          }  
        this.notifyingThread.start();
      } 
    }
    
    public synchronized void disconnect() {
      this.connected = false;
      notifyAll();
    }
    
    public abstract void run();
  }
  
  class PushSourceStreamSlave extends PushStreamSlave implements PushSourceStream, Runnable {
    SourceTransferHandler handler;
    
    private byte[] buffer;
    
    private final CloneableSourceStreamAdapter this$0;
    
    PushSourceStreamSlave(CloneableSourceStreamAdapter this$0) {
      super(this$0);
      this.this$0 = this$0;
    }
    
    synchronized void setBuffer(byte[] buffer) {
      this.buffer = buffer;
      notifyAll();
    }
    
    public synchronized int read(byte[] buffer, int offset, int length) throws IOException {
      if (length + offset > buffer.length)
        throw new IOException("buffer is too small"); 
      while (this.buffer == null && this.connected) {
        try {
          wait(50L);
        } catch (InterruptedException e) {
          System.out.println("Exception: " + e);
        } 
      } 
      if (!this.connected)
        throw new IOException("DataSource is not connected"); 
      int copyLength = (length > this.buffer.length) ? this.buffer.length : length;
      System.arraycopy(this.buffer, 0, buffer, offset, copyLength);
      this.buffer = null;
      return copyLength;
    }
    
    public int getMinimumTransferSize() {
      return ((PushSourceStream)this.this$0.master).getMinimumTransferSize();
    }
    
    public void setTransferHandler(SourceTransferHandler transferHandler) {
      this.handler = transferHandler;
    }
    
    SourceTransferHandler getTransferHandler() {
      return this.handler;
    }
    
    public void run() {
      while (!endOfStream() && this.connected) {
        try {
          synchronized (this) {
            wait();
          } 
        } catch (InterruptedException e) {
          System.out.println("Exception: " + e);
        } 
        if (this.connected && this.handler != null)
          this.handler.transferData(this); 
      } 
    }
  }
  
  class PushBufferStreamSlave extends PushStreamSlave implements PushBufferStream, Runnable {
    BufferTransferHandler handler;
    
    private Buffer b;
    
    private final CloneableSourceStreamAdapter this$0;
    
    PushBufferStreamSlave(CloneableSourceStreamAdapter this$0) {
      super(this$0);
      this.this$0 = this$0;
    }
    
    synchronized void setBuffer(Buffer b) {
      this.b = b;
      notifyAll();
    }
    
    public Format getFormat() {
      return ((PushBufferStream)this.this$0.master).getFormat();
    }
    
    public synchronized void read(Buffer buffer) throws IOException {
      while (this.b == null && this.connected) {
        try {
          wait(50L);
        } catch (InterruptedException e) {
          System.out.println("Exception: " + e);
        } 
      } 
      if (!this.connected)
        throw new IOException("DataSource is not connected"); 
      buffer.copy(this.b);
      this.b = null;
    }
    
    public int getMinimumTransferSize() {
      return ((PushSourceStream)this.this$0.master).getMinimumTransferSize();
    }
    
    public void setTransferHandler(BufferTransferHandler transferHandler) {
      this.handler = transferHandler;
    }
    
    BufferTransferHandler getTransferHandler() {
      return this.handler;
    }
    
    public void run() {
      while (!endOfStream() && this.connected) {
        try {
          synchronized (this) {
            wait();
          } 
        } catch (InterruptedException e) {
          System.out.println("Exception: " + e);
        } 
        if (this.connected && this.handler != null)
          this.handler.transferData(this); 
      } 
    }
  }
  
  class PullSourceStreamAdapter extends SourceStreamAdapter implements PullSourceStream {
    private final CloneableSourceStreamAdapter this$0;
    
    PullSourceStreamAdapter(CloneableSourceStreamAdapter this$0) {
      super(this$0);
      this.this$0 = this$0;
    }
    
    public boolean willReadBlock() {
      return ((PullSourceStream)this.this$0.master).willReadBlock();
    }
    
    public int read(byte[] buffer, int offset, int length) throws IOException {
      return this.this$0.copyAndRead(buffer, offset, length);
    }
  }
  
  class PullBufferStreamAdapter extends SourceStreamAdapter implements PullBufferStream {
    private final CloneableSourceStreamAdapter this$0;
    
    PullBufferStreamAdapter(CloneableSourceStreamAdapter this$0) {
      super(this$0);
      this.this$0 = this$0;
    }
    
    public boolean willReadBlock() {
      return ((PullBufferStream)this.this$0.master).willReadBlock();
    }
    
    public void read(Buffer buffer) throws IOException {
      this.this$0.copyAndRead(buffer);
    }
    
    public Format getFormat() {
      return ((PullBufferStream)this.this$0.master).getFormat();
    }
  }
  
  class PushSourceStreamAdapter extends SourceStreamAdapter implements PushSourceStream, SourceTransferHandler {
    SourceTransferHandler handler;
    
    private final CloneableSourceStreamAdapter this$0;
    
    PushSourceStreamAdapter(CloneableSourceStreamAdapter this$0) {
      super(this$0);
      this.this$0 = this$0;
    }
    
    public int read(byte[] buffer, int offset, int length) throws IOException {
      return this.this$0.copyAndRead(buffer, offset, length);
    }
    
    public int getMinimumTransferSize() {
      return ((PushSourceStream)this.this$0.master).getMinimumTransferSize();
    }
    
    public void setTransferHandler(SourceTransferHandler transferHandler) {
      this.handler = transferHandler;
      ((PushSourceStream)this.this$0.master).setTransferHandler(this);
    }
    
    public void transferData(PushSourceStream stream) {
      if (this.handler != null)
        this.handler.transferData(this); 
    }
  }
  
  class PushBufferStreamAdapter extends SourceStreamAdapter implements PushBufferStream, BufferTransferHandler {
    BufferTransferHandler handler;
    
    private final CloneableSourceStreamAdapter this$0;
    
    PushBufferStreamAdapter(CloneableSourceStreamAdapter this$0) {
      super(this$0);
      this.this$0 = this$0;
    }
    
    public Format getFormat() {
      return ((PushBufferStream)this.this$0.master).getFormat();
    }
    
    public void read(Buffer buffer) throws IOException {
      this.this$0.copyAndRead(buffer);
    }
    
    public void setTransferHandler(BufferTransferHandler transferHandler) {
      this.handler = transferHandler;
      ((PushBufferStream)this.this$0.master).setTransferHandler(this);
    }
    
    public void transferData(PushBufferStream stream) {
      if (this.handler != null)
        this.handler.transferData(this); 
    }
  }
}
