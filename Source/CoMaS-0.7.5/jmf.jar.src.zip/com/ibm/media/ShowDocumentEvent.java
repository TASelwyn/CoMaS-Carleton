package com.ibm.media;

import java.net.URL;
import javax.media.Controller;
import javax.media.ControllerEvent;

public class ShowDocumentEvent extends ControllerEvent {
  private URL u;
  
  private String s;
  
  public ShowDocumentEvent(Controller from, URL u, String s) {
    super(from);
    this.u = u;
    this.s = s;
  }
  
  public URL getURL() {
    return this.u;
  }
  
  public String getString() {
    return this.s;
  }
}
