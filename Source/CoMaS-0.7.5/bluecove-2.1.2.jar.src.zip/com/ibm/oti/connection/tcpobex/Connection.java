package com.ibm.oti.connection.tcpobex;

import com.intel.bluetooth.tcpobex.Connection;

public class Connection extends Connection {}
