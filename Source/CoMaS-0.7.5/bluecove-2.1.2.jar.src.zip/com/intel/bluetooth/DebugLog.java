package com.intel.bluetooth;

import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Vector;

public abstract class DebugLog {
  private static final boolean debugCompiledOut = false;
  
  public static final int DEBUG = 1;
  
  public static final int ERROR = 4;
  
  private static boolean debugEnabled = false;
  
  private static boolean initialized = false;
  
  private static boolean debugInternalEnabled = false;
  
  private static final String FQCN = DebugLog.class.getName();
  
  private static final Vector fqcnSet = new Vector();
  
  private static boolean java13 = false;
  
  private static Vector loggerAppenders = new Vector();
  
  static {
    fqcnSet.addElement(FQCN);
  }
  
  private static synchronized void initialize() {
    if (initialized)
      return; 
    initialized = true;
    debugEnabled = BlueCoveImpl.getConfigProperty("bluecove.debug", false);
    if (debugEnabled);
    boolean useStdOut = BlueCoveImpl.getConfigProperty("bluecove.debug.stdout", true);
    debugInternalEnabled = (useStdOut && debugEnabled);
    boolean useLog4j = BlueCoveImpl.getConfigProperty("bluecove.debug.log4j", true);
    if (useLog4j)
      try {
        LoggerAppenderExt log4jAppender = (LoggerAppenderExt)Class.forName("com.intel.bluetooth.DebugLog4jAppender").newInstance();
        System.out.println("BlueCove log redirected to log4j");
        addAppender(log4jAppender);
        if (log4jAppender.isLogEnabled(1))
          debugEnabled = true; 
      } catch (Throwable e) {} 
  }
  
  public static boolean isDebugEnabled() {
    if (!initialized)
      initialize(); 
    return debugEnabled;
  }
  
  public static void setDebugEnabled(boolean debugEnabled) {
    if (!initialized)
      initialize(); 
    if (debugEnabled);
    BlueCoveImpl.instance().enableNativeDebug(debugEnabled);
    DebugLog.debugEnabled = debugEnabled;
    debugInternalEnabled = DebugLog.debugEnabled;
  }
  
  public static void debug(String message) {
    if (isDebugEnabled()) {
      log(message, null, null);
      printLocation();
      callAppenders(1, message, null);
    } 
  }
  
  public static void debug(String message, String v) {
    if (isDebugEnabled()) {
      log(message, " ", v);
      printLocation();
      callAppenders(1, message + " " + v, null);
    } 
  }
  
  public static void debug(String message, Throwable t) {
    if (isDebugEnabled()) {
      log(message, " ", t.toString());
      printLocation();
      if (!UtilsJavaSE.ibmJ9midp) {
        t.printStackTrace(System.out);
      } else if (debugInternalEnabled) {
        t.printStackTrace();
      } 
      callAppenders(1, message, t);
    } 
  }
  
  public static void debug(String message, Object obj) {
    if (isDebugEnabled()) {
      log(message, " ", obj.toString());
      printLocation();
      callAppenders(1, message + " " + obj.toString(), null);
    } 
  }
  
  public static void debug(String message, String v, String v2) {
    if (isDebugEnabled()) {
      log(message, " ", v + " " + v2);
      printLocation();
      callAppenders(1, message + " " + v + " " + v2, null);
    } 
  }
  
  public static void debug(String message, long v) {
    if (isDebugEnabled()) {
      log(message, " ", Long.toString(v));
      printLocation();
      callAppenders(1, message + " " + Long.toString(v), null);
    } 
  }
  
  public static void debug0x(String message, long v) {
    if (isDebugEnabled()) {
      log(message, " 0x", Utils.toHexString(v));
      printLocation();
      callAppenders(1, message + " 0x" + Utils.toHexString(v), null);
    } 
  }
  
  public static void debug0x(String message, String s, long v) {
    if (isDebugEnabled()) {
      log(message, " " + s + " 0x", Utils.toHexString(v));
      printLocation();
      callAppenders(1, message + " " + s + " 0x" + Utils.toHexString(v), null);
    } 
  }
  
  public static void debug(String message, boolean v) {
    if (isDebugEnabled()) {
      log(message, " ", String.valueOf(v));
      printLocation();
      callAppenders(1, message + " " + v, null);
    } 
  }
  
  public static void debug(String message, byte[] data) {
    debug(message, data, 0, (data == null) ? 0 : data.length);
  }
  
  public static void debug(String message, byte[] data, int off, int len) {
    if (isDebugEnabled()) {
      StringBuffer buf = new StringBuffer();
      if (data == null) {
        buf.append(" null byte[]");
      } else {
        buf.append(" [");
        for (int i = off; i < off + len; i++) {
          if (i != off)
            buf.append(", "); 
          buf.append((new Byte(data[i])).toString());
        } 
        buf.append("]");
        if (len > 4)
          buf.append(" ").append(len); 
      } 
      log(message, buf.toString(), null);
      printLocation();
      callAppenders(1, message + buf.toString(), null);
    } 
  }
  
  public static void debug(String message, int[] data) {
    debug(message, data, 0, (data == null) ? 0 : data.length);
  }
  
  public static void debug(String message, int[] data, int off, int len) {
    if (isDebugEnabled()) {
      StringBuffer buf = new StringBuffer();
      if (data == null) {
        buf.append(" null int[]");
      } else {
        buf.append(" [");
        for (int i = off; i < off + len; i++) {
          if (i != off)
            buf.append(", "); 
          buf.append(Integer.toString(data[i]));
        } 
        buf.append("]");
        if (len > 4)
          buf.append(" ").append(len); 
      } 
      log(message, buf.toString(), null);
      printLocation();
      callAppenders(1, message + buf.toString(), null);
    } 
  }
  
  public static void nativeDebugCallback(String fileName, int lineN, String message) {
    try {
      if (fileName != null && fileName.startsWith(".\\"))
        fileName = fileName.substring(2); 
      debugNative(fileName + ":" + lineN, message);
    } catch (Throwable e) {
      try {
        System.out.println("Error when calling debug " + e);
      } catch (Throwable e2) {}
    } 
  }
  
  public static void debugNative(String location, String message) {
    if (isDebugEnabled()) {
      log(message, "\n\t  ", location);
      callAppenders(1, message, null);
    } 
  }
  
  public static void error(String message) {
    if (isDebugEnabled()) {
      log("error ", message, null);
      printLocation();
      callAppenders(4, message, null);
    } 
  }
  
  public static void error(String message, long v) {
    if (isDebugEnabled()) {
      log("error ", message, " " + v);
      printLocation();
      callAppenders(4, message + " " + v, null);
    } 
  }
  
  public static void error(String message, String v) {
    if (isDebugEnabled()) {
      log("error ", message, " " + v);
      printLocation();
      callAppenders(4, message + " " + v, null);
    } 
  }
  
  public static void error(String message, Throwable t) {
    if (isDebugEnabled()) {
      log("error ", message, " " + t);
      printLocation();
      if (!UtilsJavaSE.ibmJ9midp) {
        t.printStackTrace(System.out);
      } else if (debugInternalEnabled) {
        t.printStackTrace();
      } 
      callAppenders(4, message, t);
    } 
  }
  
  public static void fatal(String message) {
    log("error ", message, null);
    printLocation();
    callAppenders(4, message, null);
  }
  
  public static void fatal(String message, Throwable t) {
    log("error ", message, " " + t);
    printLocation();
    if (!UtilsJavaSE.ibmJ9midp) {
      t.printStackTrace(System.out);
    } else if (debugInternalEnabled) {
      t.printStackTrace();
    } 
    callAppenders(4, message, t);
  }
  
  private static void callAppenders(int level, String message, Throwable throwable) {
    for (Enumeration iter = loggerAppenders.elements(); iter.hasMoreElements(); ) {
      LoggerAppender a = iter.nextElement();
      a.appendLog(level, message, throwable);
    } 
  }
  
  public static void addAppender(LoggerAppender newAppender) {
    loggerAppenders.addElement(newAppender);
  }
  
  public static void removeAppender(LoggerAppender newAppender) {
    loggerAppenders.removeElement(newAppender);
  }
  
  private static String d00(int i) {
    if (i > 9)
      return String.valueOf(i); 
    return "0" + String.valueOf(i);
  }
  
  private static String d000(int i) {
    if (i > 99)
      return String.valueOf(i); 
    if (i > 9)
      return "0" + String.valueOf(i); 
    return "00" + String.valueOf(i);
  }
  
  private static void log(String message, String va1, String va2) {
    if (!debugInternalEnabled)
      return; 
    try {
      Calendar calendar = Calendar.getInstance();
      calendar.setTime(new Date(System.currentTimeMillis()));
      StringBuffer sb = new StringBuffer();
      sb.append(d00(calendar.get(11))).append(":");
      sb.append(d00(calendar.get(12))).append(":");
      sb.append(d00(calendar.get(13))).append(".");
      sb.append(d000(calendar.get(14))).append(" ");
      sb.append(message);
      if (va1 != null)
        sb.append(va1); 
      if (va2 != null)
        sb.append(va2); 
      System.out.println(sb.toString());
    } catch (Throwable ignore) {}
  }
  
  private static void printLocation() {
    if (java13 || !debugInternalEnabled)
      return; 
    try {
      UtilsJavaSE.StackTraceLocation ste = UtilsJavaSE.getLocation(fqcnSet);
      if (ste != null)
        System.out.println("\t  " + formatLocation(ste)); 
    } catch (Throwable e) {
      java13 = true;
    } 
  }
  
  private static String formatLocation(UtilsJavaSE.StackTraceLocation ste) {
    if (ste == null)
      return ""; 
    return ste.className + "." + ste.methodName + "(" + ste.fileName + ":" + ste.lineNumber + ")";
  }
  
  public static interface LoggerAppenderExt extends LoggerAppender {
    boolean isLogEnabled(int param1Int);
  }
  
  public static interface LoggerAppender {
    void appendLog(int param1Int, String param1String, Throwable param1Throwable);
  }
}
