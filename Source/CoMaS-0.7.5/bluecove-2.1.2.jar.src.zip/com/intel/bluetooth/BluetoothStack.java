package com.intel.bluetooth;

import java.io.IOException;
import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DeviceClass;
import javax.bluetooth.DiscoveryListener;
import javax.bluetooth.RemoteDevice;
import javax.bluetooth.ServiceRegistrationException;
import javax.bluetooth.UUID;

public interface BluetoothStack {
  public static final int FEATURE_L2CAP = 1;
  
  public static final int FEATURE_SERVICE_ATTRIBUTES = 2;
  
  public static final int FEATURE_SET_DEVICE_SERVICE_CLASSES = 4;
  
  public static final int FEATURE_RSSI = 8;
  
  public static final int FEATURE_ASSIGN_SERVER_PSM = 16;
  
  boolean isNativeCodeLoaded();
  
  LibraryInformation[] requireNativeLibraries();
  
  int getLibraryVersion() throws BluetoothStateException;
  
  int detectBluetoothStack();
  
  void enableNativeDebug(Class paramClass, boolean paramBoolean);
  
  void initialize() throws BluetoothStateException;
  
  void destroy();
  
  String getStackID();
  
  boolean isCurrentThreadInterruptedCallback();
  
  int getFeatureSet();
  
  String getLocalDeviceBluetoothAddress() throws BluetoothStateException;
  
  String getLocalDeviceName();
  
  DeviceClass getLocalDeviceClass();
  
  void setLocalDeviceServiceClasses(int paramInt);
  
  boolean setLocalDeviceDiscoverable(int paramInt) throws BluetoothStateException;
  
  int getLocalDeviceDiscoverable();
  
  boolean isLocalDevicePowerOn();
  
  String getLocalDeviceProperty(String paramString);
  
  boolean authenticateRemoteDevice(long paramLong) throws IOException;
  
  boolean authenticateRemoteDevice(long paramLong, String paramString) throws IOException;
  
  void removeAuthenticationWithRemoteDevice(long paramLong) throws IOException;
  
  boolean startInquiry(int paramInt, DiscoveryListener paramDiscoveryListener) throws BluetoothStateException;
  
  boolean cancelInquiry(DiscoveryListener paramDiscoveryListener);
  
  String getRemoteDeviceFriendlyName(long paramLong) throws IOException;
  
  RemoteDevice[] retrieveDevices(int paramInt);
  
  Boolean isRemoteDeviceTrusted(long paramLong);
  
  Boolean isRemoteDeviceAuthenticated(long paramLong);
  
  int searchServices(int[] paramArrayOfint, UUID[] paramArrayOfUUID, RemoteDevice paramRemoteDevice, DiscoveryListener paramDiscoveryListener) throws BluetoothStateException;
  
  boolean cancelServiceSearch(int paramInt);
  
  boolean populateServicesRecordAttributeValues(ServiceRecordImpl paramServiceRecordImpl, int[] paramArrayOfint) throws IOException;
  
  long connectionRfOpenClientConnection(BluetoothConnectionParams paramBluetoothConnectionParams) throws IOException;
  
  int rfGetSecurityOpt(long paramLong, int paramInt) throws IOException;
  
  void connectionRfCloseClientConnection(long paramLong) throws IOException;
  
  void connectionRfCloseServerConnection(long paramLong) throws IOException;
  
  long rfServerOpen(BluetoothConnectionNotifierParams paramBluetoothConnectionNotifierParams, ServiceRecordImpl paramServiceRecordImpl) throws IOException;
  
  void rfServerUpdateServiceRecord(long paramLong, ServiceRecordImpl paramServiceRecordImpl, boolean paramBoolean) throws ServiceRegistrationException;
  
  long rfServerAcceptAndOpenRfServerConnection(long paramLong) throws IOException;
  
  void rfServerClose(long paramLong, ServiceRecordImpl paramServiceRecordImpl) throws IOException;
  
  long getConnectionRfRemoteAddress(long paramLong) throws IOException;
  
  boolean rfEncrypt(long paramLong1, long paramLong2, boolean paramBoolean) throws IOException;
  
  int connectionRfRead(long paramLong) throws IOException;
  
  int connectionRfRead(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
  
  int connectionRfReadAvailable(long paramLong) throws IOException;
  
  void connectionRfWrite(long paramLong, int paramInt) throws IOException;
  
  void connectionRfWrite(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
  
  void connectionRfFlush(long paramLong) throws IOException;
  
  long l2OpenClientConnection(BluetoothConnectionParams paramBluetoothConnectionParams, int paramInt1, int paramInt2) throws IOException;
  
  void l2CloseClientConnection(long paramLong) throws IOException;
  
  long l2ServerOpen(BluetoothConnectionNotifierParams paramBluetoothConnectionNotifierParams, int paramInt1, int paramInt2, ServiceRecordImpl paramServiceRecordImpl) throws IOException;
  
  void l2ServerUpdateServiceRecord(long paramLong, ServiceRecordImpl paramServiceRecordImpl, boolean paramBoolean) throws ServiceRegistrationException;
  
  long l2ServerAcceptAndOpenServerConnection(long paramLong) throws IOException;
  
  void l2CloseServerConnection(long paramLong) throws IOException;
  
  void l2ServerClose(long paramLong, ServiceRecordImpl paramServiceRecordImpl) throws IOException;
  
  int l2GetSecurityOpt(long paramLong, int paramInt) throws IOException;
  
  int l2GetTransmitMTU(long paramLong) throws IOException;
  
  int l2GetReceiveMTU(long paramLong) throws IOException;
  
  boolean l2Ready(long paramLong) throws IOException;
  
  int l2Receive(long paramLong, byte[] paramArrayOfbyte) throws IOException;
  
  void l2Send(long paramLong, byte[] paramArrayOfbyte, int paramInt) throws IOException;
  
  long l2RemoteAddress(long paramLong) throws IOException;
  
  boolean l2Encrypt(long paramLong1, long paramLong2, boolean paramBoolean) throws IOException;
  
  public static class LibraryInformation {
    public final String libraryName;
    
    public Class stackClass;
    
    public final boolean required;
    
    public LibraryInformation(String libraryName) {
      this(libraryName, true);
    }
    
    public LibraryInformation(String libraryName, boolean required) {
      this.libraryName = libraryName;
      this.required = required;
    }
    
    public static LibraryInformation[] library(String libraryName) {
      return new LibraryInformation[] { new LibraryInformation(libraryName) };
    }
  }
}
