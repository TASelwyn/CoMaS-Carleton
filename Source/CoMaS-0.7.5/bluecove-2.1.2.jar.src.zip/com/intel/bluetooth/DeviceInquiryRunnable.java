package com.intel.bluetooth;

import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DiscoveryListener;

interface DeviceInquiryRunnable {
  int runDeviceInquiry(DeviceInquiryThread paramDeviceInquiryThread, int paramInt, DiscoveryListener paramDiscoveryListener) throws BluetoothStateException;
  
  void deviceDiscoveredCallback(DiscoveryListener paramDiscoveryListener, long paramLong, int paramInt, String paramString, boolean paramBoolean);
}
