package com.intel.bluetooth;

import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DiscoveryListener;

class DeviceInquiryThread extends Thread {
  private BluetoothStack stack;
  
  private DeviceInquiryRunnable inquiryRunnable;
  
  private int accessCode;
  
  private DiscoveryListener listener;
  
  private BluetoothStateException startException;
  
  private boolean started = false;
  
  private boolean terminated = false;
  
  private Object inquiryStartedEvent = new Object();
  
  private static int threadNumber;
  
  private static synchronized int nextThreadNum() {
    return threadNumber++;
  }
  
  private DeviceInquiryThread(BluetoothStack stack, DeviceInquiryRunnable inquiryRunnable, int accessCode, DiscoveryListener listener) {
    super("DeviceInquiryThread-" + nextThreadNum());
    this.stack = stack;
    this.inquiryRunnable = inquiryRunnable;
    this.accessCode = accessCode;
    this.listener = listener;
  }
  
  static boolean startInquiry(BluetoothStack stack, DeviceInquiryRunnable inquiryRunnable, int accessCode, DiscoveryListener listener) throws BluetoothStateException {
    DeviceInquiryThread t = new DeviceInquiryThread(stack, inquiryRunnable, accessCode, listener);
    UtilsJavaSE.threadSetDaemon(t);
    synchronized (t.inquiryStartedEvent) {
      t.start();
      while (!t.started && !t.terminated) {
        try {
          t.inquiryStartedEvent.wait();
        } catch (InterruptedException e) {
          return false;
        } 
        if (t.startException != null)
          throw t.startException; 
      } 
    } 
    DebugLog.debug("startInquiry return", t.started);
    return t.started;
  }
  
  public static int getConfigDeviceInquiryDuration() {
    return BlueCoveImpl.getConfigProperty("bluecove.inquiry.duration", 11);
  }
  
  public void run() {
    int discType = 7;
    try {
      BlueCoveImpl.setThreadBluetoothStack(this.stack);
      discType = this.inquiryRunnable.runDeviceInquiry(this, this.accessCode, this.listener);
    } catch (BluetoothStateException e) {
      DebugLog.debug("runDeviceInquiry throw", (Throwable)e);
      this.startException = e;
    } catch (Throwable e) {
      DebugLog.error("runDeviceInquiry", e);
    } finally {
      this.terminated = true;
      synchronized (this.inquiryStartedEvent) {
        this.inquiryStartedEvent.notifyAll();
      } 
      DebugLog.debug("runDeviceInquiry ends");
      if (this.started) {
        Utils.j2meUsagePatternDellay();
        this.listener.inquiryCompleted(discType);
      } 
    } 
  }
  
  public void deviceInquiryStartedCallback() {
    DebugLog.debug("deviceInquiryStartedCallback");
    this.started = true;
    synchronized (this.inquiryStartedEvent) {
      this.inquiryStartedEvent.notifyAll();
    } 
  }
}
