package com.intel.bluetooth.obex;

import java.io.IOException;

interface OBEXOperationDelivery extends OBEXOperation {
  void deliverPacket(boolean paramBoolean, byte[] paramArrayOfbyte) throws IOException;
}
