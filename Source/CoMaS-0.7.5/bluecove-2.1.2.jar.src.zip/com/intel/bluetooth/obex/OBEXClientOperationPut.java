package com.intel.bluetooth.obex;

import com.intel.bluetooth.DebugLog;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

class OBEXClientOperationPut extends OBEXClientOperation {
  OBEXClientOperationPut(OBEXClientSessionImpl session, OBEXHeaderSetImpl sendHeaders) throws IOException {
    super(session, '\002', sendHeaders);
  }
  
  public InputStream openInputStream() throws IOException {
    validateOperationIsOpen();
    if (this.inputStreamOpened)
      throw new IOException("input stream already open"); 
    DebugLog.debug("openInputStream");
    this.inputStreamOpened = true;
    this.operationInProgress = true;
    return this.inputStream;
  }
  
  public OutputStream openOutputStream() throws IOException {
    validateOperationIsOpen();
    if (this.outputStreamOpened)
      throw new IOException("output already open"); 
    this.outputStreamOpened = true;
    this.outputStream = new OBEXOperationOutputStream(this.session.mtu, this);
    this.operationInProgress = true;
    return this.outputStream;
  }
}
