package com.intel.bluetooth;

import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DiscoveryListener;
import javax.bluetooth.RemoteDevice;
import javax.bluetooth.UUID;

interface SearchServicesRunnable {
  int runSearchServices(SearchServicesThread paramSearchServicesThread, int[] paramArrayOfint, UUID[] paramArrayOfUUID, RemoteDevice paramRemoteDevice, DiscoveryListener paramDiscoveryListener) throws BluetoothStateException;
}
