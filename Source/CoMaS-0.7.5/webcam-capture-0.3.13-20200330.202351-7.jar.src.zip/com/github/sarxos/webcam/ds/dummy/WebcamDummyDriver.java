package com.github.sarxos.webcam.ds.dummy;

import com.github.sarxos.webcam.WebcamDevice;
import com.github.sarxos.webcam.WebcamDiscoverySupport;
import com.github.sarxos.webcam.WebcamDriver;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class WebcamDummyDriver implements WebcamDriver, WebcamDiscoverySupport {
  private int count;
  
  public WebcamDummyDriver(int count) {
    this.count = count;
  }
  
  public long getScanInterval() {
    return 10000L;
  }
  
  public boolean isScanPossible() {
    return true;
  }
  
  public List<WebcamDevice> getDevices() {
    List<WebcamDevice> devices = new ArrayList<>();
    for (int i = 0; i < this.count; i++)
      devices.add(new WebcamDummyDevice(i)); 
    return Collections.unmodifiableList(devices);
  }
  
  public boolean isThreadSafe() {
    return false;
  }
}
