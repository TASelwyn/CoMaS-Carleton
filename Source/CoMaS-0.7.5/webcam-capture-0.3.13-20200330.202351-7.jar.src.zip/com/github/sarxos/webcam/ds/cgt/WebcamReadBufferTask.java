package com.github.sarxos.webcam.ds.cgt;

import com.github.sarxos.webcam.WebcamDevice;
import com.github.sarxos.webcam.WebcamDriver;
import com.github.sarxos.webcam.WebcamTask;
import java.nio.ByteBuffer;

public class WebcamReadBufferTask extends WebcamTask {
  private volatile ByteBuffer target = null;
  
  public WebcamReadBufferTask(WebcamDriver driver, WebcamDevice device, ByteBuffer target) {
    super(driver, device);
    this.target = target;
  }
  
  public ByteBuffer readBuffer() {
    try {
      process();
    } catch (InterruptedException e) {
      return null;
    } 
    return this.target;
  }
  
  protected void handle() {
    WebcamDevice device = getDevice();
    if (!device.isOpen())
      return; 
    if (!(device instanceof WebcamDevice.BufferAccess))
      return; 
    ((WebcamDevice.BufferAccess)device).getImageBytes(this.target);
  }
}
