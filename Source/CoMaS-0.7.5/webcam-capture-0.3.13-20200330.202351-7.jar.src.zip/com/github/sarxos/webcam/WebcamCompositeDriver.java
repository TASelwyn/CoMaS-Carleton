package com.github.sarxos.webcam;

import java.util.ArrayList;
import java.util.List;

public class WebcamCompositeDriver implements WebcamDriver, WebcamDiscoverySupport {
  private List<WebcamDriver> drivers = new ArrayList<>();
  
  private int scanInterval = -1;
  
  public WebcamCompositeDriver(WebcamDriver... drivers) {
    for (WebcamDriver driver : drivers)
      this.drivers.add(driver); 
  }
  
  public void add(WebcamDriver driver) {
    this.drivers.add(driver);
  }
  
  public List<WebcamDriver> getDrivers() {
    return this.drivers;
  }
  
  public List<WebcamDevice> getDevices() {
    List<WebcamDevice> all = new ArrayList<>();
    for (WebcamDriver driver : this.drivers)
      all.addAll(driver.getDevices()); 
    return all;
  }
  
  public boolean isThreadSafe() {
    boolean safe = true;
    for (WebcamDriver driver : this.drivers) {
      safe &= driver.isThreadSafe();
      if (!safe)
        break; 
    } 
    return safe;
  }
  
  public void setScanInterval(int scanInterval) {
    this.scanInterval = scanInterval;
  }
  
  public long getScanInterval() {
    if (this.scanInterval <= 0)
      return 3000L; 
    return this.scanInterval;
  }
  
  public boolean isScanPossible() {
    return true;
  }
}
