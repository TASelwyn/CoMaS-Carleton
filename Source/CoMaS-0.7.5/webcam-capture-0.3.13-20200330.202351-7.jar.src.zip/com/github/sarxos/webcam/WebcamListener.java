package com.github.sarxos.webcam;

public interface WebcamListener {
  void webcamOpen(WebcamEvent paramWebcamEvent);
  
  void webcamClosed(WebcamEvent paramWebcamEvent);
  
  void webcamDisposed(WebcamEvent paramWebcamEvent);
  
  void webcamImageObtained(WebcamEvent paramWebcamEvent);
}
