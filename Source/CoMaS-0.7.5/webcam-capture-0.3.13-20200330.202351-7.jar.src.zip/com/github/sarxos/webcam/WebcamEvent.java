package com.github.sarxos.webcam;

import java.awt.image.BufferedImage;
import java.util.EventObject;

public class WebcamEvent extends EventObject {
  private static final long serialVersionUID = 1L;
  
  private BufferedImage image = null;
  
  private WebcamEventType type = null;
  
  public WebcamEvent(WebcamEventType type, Webcam w) {
    this(type, w, null);
  }
  
  public WebcamEvent(WebcamEventType type, Webcam w, BufferedImage image) {
    super(w);
    this.type = type;
    this.image = image;
  }
  
  public Webcam getSource() {
    return (Webcam)super.getSource();
  }
  
  public BufferedImage getImage() {
    return this.image;
  }
  
  public WebcamEventType getType() {
    return this.type;
  }
}
