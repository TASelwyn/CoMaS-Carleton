package edu.carleton.services;

import edu.carleton.encryption.AES;
import java.io.Closeable;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.StandardSocketOptions;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.atomic.AtomicBoolean;

public class ServiceLocator implements Closeable {
  private DatagramChannel datagramChannel;
  
  private InetSocketAddress inetSocketAddress;
  
  private UDPChannel returnChannel;
  
  private ServiceListener listener;
  
  private ConcurrentHashMap<String, CopyOnWriteArraySet<String>> map;
  
  public ServiceLocator(ServiceListener listener) {
    this.listener = listener;
    this.map = new ConcurrentHashMap<>();
    ServiceUtility.closeOnExit(this);
  }
  
  public void open() throws IOException {
    String i_f = ServiceUtility.findInterface();
    String i_ip = ServiceUtility.findIP();
    open(ServiceUtility.MULTICAST_IP, i_f, i_ip, ServiceUtility.MULTICAST_PORT);
  }
  
  public void open(String ip, String iface, String i_ip, int port) throws IOException {
    this.datagramChannel = DatagramChannel.open();
    this.datagramChannel.bind((SocketAddress)null);
    NetworkInterface networkInterface = NetworkInterface.getByName(iface);
    if (networkInterface == null)
      networkInterface = NetworkInterface.getByInetAddress(InetAddress.getByName(i_ip)); 
    this.datagramChannel.setOption(StandardSocketOptions.IP_MULTICAST_IF, networkInterface);
    this.inetSocketAddress = new InetSocketAddress(ip, port);
    this.returnChannel = new UDPChannel(port + 1, this.listener);
    this.returnChannel.open();
  }
  
  public CopyOnWriteArraySet<String> serviceProviders(String service) {
    CopyOnWriteArraySet<String> providers = this.map.get(service);
    if (providers == null) {
      providers = new CopyOnWriteArraySet<>();
      this.map.put(service, providers);
    } 
    return providers;
  }
  
  private void addProvider(String service, String provider) {
    serviceProviders(service).add(provider);
  }
  
  private void removeProvider(String service, String provider) {
    serviceProviders(service).remove(provider);
  }
  
  public boolean hasProvider(String service) {
    return !serviceProviders(service).isEmpty();
  }
  
  public void subscribe(String service) throws IOException {
    String address = ServiceUtility.findIP();
    send("subscribe" + ServiceUtility.DELIMETER + service + ServiceUtility.DELIMETER + address + 
        ServiceUtility.DELIMETER + ServiceUtility.MULTICAST_RETURN_PORT);
  }
  
  public void unsubscribe(String service) throws IOException {
    String address = ServiceUtility.findIP();
    send("unsubscribe" + ServiceUtility.DELIMETER + service + ServiceUtility.DELIMETER + address + 
        ServiceUtility.DELIMETER + ServiceUtility.MULTICAST_RETURN_PORT);
  }
  
  public void send(String message) throws IOException {
    if (this.datagramChannel != null) {
      String encryptedMessage = AES.encrypt(message);
      ByteBuffer byteBuffer = ByteBuffer.wrap(encryptedMessage.getBytes("UTF-8"));
      this.datagramChannel.send(byteBuffer, this.inetSocketAddress);
    } 
  }
  
  public void close() throws IOException {
    unsubscribe("*");
    if (this.datagramChannel != null && 
      this.datagramChannel.isOpen())
      this.datagramChannel.close(); 
    if (this.returnChannel != null)
      this.returnChannel.close(); 
    this.map.clear();
  }
  
  private class UDPChannel implements Runnable {
    DatagramSocket socket;
    
    ServiceListener listener;
    
    Thread thread;
    
    AtomicBoolean isRunning;
    
    public UDPChannel(int port, ServiceListener listener) throws SocketException {
      this.listener = listener;
      this.isRunning = new AtomicBoolean(false);
      this.socket = new DatagramSocket(port);
    }
    
    private synchronized void open() {
      this.thread = new Thread(this);
      this.thread.start();
    }
    
    private DatagramPacket read() throws IOException {
      DatagramPacket pkt = new DatagramPacket(new byte[1024], 1024);
      this.socket.receive(pkt);
      return pkt;
    }
    
    private void process(String msg) {
      if (ServiceUtility.DEBUG)
        System.out.println("ServiceLocator: [" + msg + "]"); 
      String[] fields = msg.split(ServiceUtility.DELIMETER);
      if (fields != null && 
        fields.length >= 2) {
        if (fields[0].equals("added")) {
          ServiceLocator.this.addProvider(fields[1], fields[2]);
          this.listener.onAdd(fields[1], fields[2]);
        } 
        if (fields[0].equals("removed")) {
          ServiceLocator.this.removeProvider(fields[1], fields[2]);
          this.listener.onRemove(fields[1], fields[2]);
        } 
      } 
    }
    
    private synchronized void close() {
      this.thread.interrupt();
      if (this.socket != null && 
        !this.socket.isClosed())
        this.socket.close(); 
    }
    
    public void run() {
      this.isRunning.set(true);
      while (this.isRunning.get()) {
        try {
          DatagramPacket pkt = read();
          String encryptedMessage = (new String(pkt.getData())).trim();
          if (ServiceUtility.DEBUG)
            System.out.println("ServiceLocator encryptedMessage: [" + encryptedMessage + "]"); 
          String msg = AES.decrypt(encryptedMessage);
          if (ServiceUtility.DEBUG)
            System.out.println("ServiceLocator msg: [" + msg + "]"); 
          process(msg);
        } catch (Exception e) {
          this.isRunning.set(false);
          if (ServiceUtility.DEBUG)
            System.out.println(e); 
        } 
      } 
      close();
    }
  }
}
