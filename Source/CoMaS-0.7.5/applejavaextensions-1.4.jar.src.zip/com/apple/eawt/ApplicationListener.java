package com.apple.eawt;

import java.util.EventListener;

public interface ApplicationListener extends EventListener {
  void handleAbout(ApplicationEvent paramApplicationEvent);
  
  void handleOpenApplication(ApplicationEvent paramApplicationEvent);
  
  void handleOpenFile(ApplicationEvent paramApplicationEvent);
  
  void handlePreferences(ApplicationEvent paramApplicationEvent);
  
  void handlePrintFile(ApplicationEvent paramApplicationEvent);
  
  void handleQuit(ApplicationEvent paramApplicationEvent);
  
  void handleReOpenApplication(ApplicationEvent paramApplicationEvent);
}
