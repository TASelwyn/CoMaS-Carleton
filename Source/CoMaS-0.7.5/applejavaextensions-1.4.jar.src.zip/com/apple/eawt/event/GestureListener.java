package com.apple.eawt.event;

import java.util.EventListener;

public interface GestureListener extends EventListener {}
