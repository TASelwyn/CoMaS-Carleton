package edu.carleton.cas.modules;

public interface ModuleConfiguration {
  String getStringProperty(String paramString);
  
  Object getObjectProperty(String paramString);
}
