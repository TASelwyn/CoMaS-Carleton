package org.bridj.cpp.mfc;

import org.bridj.Pointer;
import org.bridj.ann.Virtual;

public class CWnd extends MFCObject {
  @Virtual
  public native int SendMessage(int paramInt1, int paramInt2, int paramInt3);
  
  @Virtual
  public native void SetWindowText(Pointer<CString> paramPointer);
}
