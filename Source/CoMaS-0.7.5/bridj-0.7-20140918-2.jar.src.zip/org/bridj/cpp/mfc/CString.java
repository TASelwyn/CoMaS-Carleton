package org.bridj.cpp.mfc;

public class CString extends CStringT {}
