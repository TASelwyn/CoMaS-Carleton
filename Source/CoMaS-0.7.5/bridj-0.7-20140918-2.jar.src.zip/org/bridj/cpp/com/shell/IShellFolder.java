package org.bridj.cpp.com.shell;

import org.bridj.cpp.com.CLSID;
import org.bridj.cpp.com.IID;
import org.bridj.cpp.com.IUnknown;

@IID("000214E6-0000-0000-C000-000000000046")
@CLSID("000214E6-0000-0000-C000-000000000046")
public class IShellFolder extends IUnknown {}
