package org.bridj;

public interface NativeObjectInterface {}
