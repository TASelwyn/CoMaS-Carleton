package org.bridj;

public class TypedPointer extends Pointer.OrderedPointer {
  Pointer<?> copy;
  
  private TypedPointer(PointerIO<?> io, long peer) {
    super((PointerIO)io, peer, -1L, -1L, null, 0L, null);
  }
  
  public TypedPointer(long address) {
    this(PointerIO.getPointerInstance(), address);
  }
  
  public TypedPointer(Pointer<?> ptr) {
    this(PointerIO.getPointerInstance(), ptr.getPeer());
    this.copy = ptr;
  }
}
