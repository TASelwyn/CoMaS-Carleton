package org.bridj.jawt;

import java.awt.Component;
import java.awt.GraphicsEnvironment;
import java.awt.HeadlessException;
import org.bridj.JNI;
import org.bridj.NativeObject;
import org.bridj.Pointer;

public class JAWTUtils {
  public static JawtLibrary.JNIEnv getJNIEnv() {
    return new JawtLibrary.JNIEnv(JNI.getEnv());
  }
  
  public static JAWT getJAWT(JawtLibrary.JNIEnv env) {
    if (GraphicsEnvironment.isHeadless())
      throw new HeadlessException("No native peers in headless mode."); 
    JAWT awt = (new JAWT()).version(65540);
    Pointer<JAWT> pAwt = Pointer.getPointer((NativeObject)awt);
    if (!JawtLibrary.JAWT_GetAWT((Pointer<JawtLibrary.JNIEnv>)env, pAwt))
      throw new RuntimeException("Failed to get JAWT pointer !"); 
    return (JAWT)pAwt.get();
  }
  
  public static void withLockedSurface(JawtLibrary.JNIEnv env, JAWT awt, Component component, LockedComponentRunnable runnable) {
    if (component.isLightweight())
      throw new IllegalArgumentException("Lightweight components do not have native peers."); 
    if (!component.isDisplayable())
      throw new IllegalArgumentException("Component that are not displayable do not have native peers."); 
    Pointer<?> componentPointer = JNI.getGlobalPointer(component);
    Pointer<JAWT_DrawingSurface> pSurface = ((JAWT.GetDrawingSurface_callback)awt.GetDrawingSurface().get()).invoke((Pointer<JawtLibrary.JNIEnv>)env, componentPointer).as(JAWT_DrawingSurface.class);
    if (pSurface == null)
      throw new RuntimeException("Cannot get drawing surface from " + component); 
    JAWT_DrawingSurface surface = (JAWT_DrawingSurface)pSurface.get();
    try {
      int lock = ((JAWT_DrawingSurface.Lock_callback)surface.Lock().get()).invoke(pSurface);
      if ((lock & 0x1) != 0)
        throw new RuntimeException("Cannot lock drawing surface of " + component); 
      try {
        Pointer<JAWT_DrawingSurface.GetDrawingSurfaceInfo_callback> cb = surface.GetDrawingSurfaceInfo().as(JAWT_DrawingSurface.GetDrawingSurfaceInfo_callback.class);
        Pointer<JAWT_DrawingSurfaceInfo> pInfo = ((JAWT_DrawingSurface.GetDrawingSurfaceInfo_callback)cb.get()).invoke(pSurface);
        if (pInfo != null)
          pInfo = pInfo.as(JAWT_DrawingSurfaceInfo.class); 
        Pointer<?> platformInfo = ((JAWT_DrawingSurfaceInfo)pInfo.get()).platformInfo();
        long peer = platformInfo.getSizeT();
        runnable.run(component, peer);
      } finally {
        ((JAWT_DrawingSurface.Unlock_callback)surface.Unlock().get()).invoke(pSurface);
      } 
    } finally {
      ((JAWT.FreeDrawingSurface_callback)awt.FreeDrawingSurface().get()).invoke(pSurface);
    } 
  }
  
  public static long getNativePeerHandle(Component component) {
    try {
      JawtLibrary.JNIEnv env = getJNIEnv();
      JAWT awt = getJAWT(env);
      final long[] ret = new long[1];
      withLockedSurface(env, awt, component, new LockedComponentRunnable() {
            public void run(Component component, long peer) {
              ret[0] = peer;
            }
          });
      return ret[0];
    } catch (Throwable ex) {
      ex.printStackTrace();
      return 0L;
    } 
  }
  
  public static interface LockedComponentRunnable {
    void run(Component param1Component, long param1Long);
  }
}
