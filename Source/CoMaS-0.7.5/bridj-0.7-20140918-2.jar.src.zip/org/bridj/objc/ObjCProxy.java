package org.bridj.objc;

import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import org.bridj.BridJ;
import org.bridj.NativeObject;
import org.bridj.Pointer;
import org.bridj.PointerIO;
import org.bridj.util.Pair;
import org.bridj.util.Utils;

public class ObjCProxy extends ObjCObject {
  final Map<SEL, Pair<NSMethodSignature, Method>> signatures = new HashMap<SEL, Pair<NSMethodSignature, Method>>();
  
  final Object invocationTarget;
  
  static final String PROXY_OBJC_CLASS_NAME = "ObjCProxy";
  
  protected ObjCProxy() {
    super((Pointer<? extends NativeObject>)null);
    this.peer = ObjCJNI.createObjCProxyPeer(this);
    assert getClass() != ObjCProxy.class;
    this.invocationTarget = this;
  }
  
  public ObjCProxy(Object invocationTarget) {
    super((Pointer<? extends NativeObject>)null);
    this.peer = ObjCJNI.createObjCProxyPeer(this);
    assert invocationTarget != null;
    this.invocationTarget = invocationTarget;
  }
  
  public void addProtocol(String name) throws ClassNotFoundException {
    Pointer<? extends ObjCObject> protocol = ObjectiveCRuntime.objc_getProtocol(Pointer.pointerToCString(name));
    if (protocol == null)
      throw new ClassNotFoundException("Protocol " + name + " not found !"); 
    Pointer<? extends ObjCObject> cls = ObjectiveCRuntime.getObjCClass("ObjCProxy");
    if (!ObjectiveCRuntime.class_addProtocol(cls, protocol))
      throw new RuntimeException("Failed to add protocol " + name + " to class " + "ObjCProxy"); 
  }
  
  public Object getInvocationTarget() {
    return this.invocationTarget;
  }
  
  public Pointer<NSMethodSignature> methodSignatureForSelector(SEL sel) {
    Pair<NSMethodSignature, Method> sig = getMethodAndSignature(sel);
    return (sig == null) ? null : Pointer.getPointer((NativeObject)sig.getFirst());
  }
  
  public synchronized Pair<NSMethodSignature, Method> getMethodAndSignature(SEL sel) {
    Pair<NSMethodSignature, Method> sig = this.signatures.get(sel);
    if (sig == null)
      try {
        sig = computeMethodAndSignature(sel);
        if (sig != null)
          this.signatures.put(sel, sig); 
      } catch (Throwable th) {
        BridJ.error("Failed to compute Objective-C signature for selector " + sel + ": " + th, th);
      }  
    return sig;
  }
  
  Pair<NSMethodSignature, Method> computeMethodAndSignature(SEL sel) {
    String name = sel.getName();
    ObjectiveCRuntime rt = ObjectiveCRuntime.getInstance();
    for (Method method : this.invocationTarget.getClass().getMethods()) {
      String msel = rt.getSelector(method);
      if (msel.equals(name)) {
        String sig = rt.getMethodSignature(method);
        if (BridJ.debug)
          BridJ.info("Objective-C signature for method " + method + " = '" + sig + "'"); 
        NSMethodSignature ms = (NSMethodSignature)NSMethodSignature.signatureWithObjCTypes(Pointer.pointerToCString(sig)).get();
        long nArgs = ms.numberOfArguments() - 2L;
        if (nArgs != (method.getParameterTypes()).length)
          throw new RuntimeException("Bad method signature (mismatching arg types) : '" + sig + "' for " + method); 
        return new Pair(ms, method);
      } 
    } 
    BridJ.error("Missing method for " + sel + " in class " + classHierarchyToString(getInvocationTarget().getClass()));
    return null;
  }
  
  static String classHierarchyToString(Class c) {
    String s = Utils.toString(c);
    Type p = c.getGenericSuperclass();
    while (p != null && p != Object.class && p != ObjCProxy.class) {
      s = s + " extends " + Utils.toString(p);
      p = Utils.getClass(p).getGenericSuperclass();
    } 
    return s;
  }
  
  public synchronized void forwardInvocation(Pointer<NSInvocation> pInvocation) {
    NSInvocation invocation = (NSInvocation)pInvocation.get();
    SEL sel = invocation.selector();
    Pair<NSMethodSignature, Method> sigMet = getMethodAndSignature(sel);
    NSMethodSignature sig = (NSMethodSignature)sigMet.getFirst();
    Method method = (Method)sigMet.getSecond();
    Type[] paramTypes = method.getGenericParameterTypes();
    int nArgs = paramTypes.length;
    Object[] args = new Object[nArgs];
    for (int i = 0; i < nArgs; i++) {
      Type paramType = paramTypes[i];
      PointerIO<?> paramIO = PointerIO.getInstance(paramType);
      Pointer<?> pArg = Pointer.allocate(paramIO);
      invocation.getArgument_atIndex(pArg, (i + 2));
      Object arg = pArg.get();
      args[i] = arg;
    } 
    try {
      method.setAccessible(true);
      Object ret = method.invoke(getInvocationTarget(), args);
      Type returnType = method.getGenericReturnType();
      if (returnType == void.class) {
        assert ret == null;
      } else {
        PointerIO<?> returnIO = PointerIO.getInstance(returnType);
        Pointer<Object> pRet = Pointer.allocate(returnIO);
        pRet.set(ret);
        invocation.setReturnValue(pRet);
      } 
    } catch (Throwable ex) {
      throw new RuntimeException("Failed to forward invocation from Objective-C to Java invocation target " + getInvocationTarget() + " for method " + method + " : " + ex, ex);
    } 
  }
}
