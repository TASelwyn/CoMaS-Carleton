package org.bridj.objc;

import org.bridj.BridJ;
import org.bridj.Pointer;
import org.bridj.ann.Library;

@Library("Foundation")
public class NSCalendar extends ObjCObject {
  public static native Pointer<NSCalendar> currentCalendar();
  
  public native Pointer<NSString> calendarIdentifier();
  
  static {
    BridJ.register();
  }
}
