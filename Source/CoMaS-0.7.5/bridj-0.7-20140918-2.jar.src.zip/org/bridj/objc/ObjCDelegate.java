package org.bridj.objc;

import org.bridj.NativeObjectInterface;

public interface ObjCDelegate extends NativeObjectInterface {}
