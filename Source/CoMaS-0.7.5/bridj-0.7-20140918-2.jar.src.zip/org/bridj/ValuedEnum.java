package org.bridj;

public interface ValuedEnum<E extends Enum<E>> extends Iterable<E> {
  long value();
}
