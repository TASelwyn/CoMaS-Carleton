package org.bridj.relocated.org.objectweb.asm;

public class ClassWriter extends ClassVisitor {
  public static final int COMPUTE_MAXS = 1;
  
  public static final int COMPUTE_FRAMES = 2;
  
  static final byte[] a;
  
  ClassReader M;
  
  int b;
  
  int c = 1;
  
  final ByteVector d = new ByteVector();
  
  Item[] e = new Item[256];
  
  int f = (int)(0.75D * this.e.length);
  
  final Item g = new Item();
  
  final Item h = new Item();
  
  final Item i = new Item();
  
  final Item j = new Item();
  
  Item[] H;
  
  private short G;
  
  private int k;
  
  private int l;
  
  String I;
  
  private int m;
  
  private int n;
  
  private int o;
  
  private int[] p;
  
  private int q;
  
  private ByteVector r;
  
  private int s;
  
  private int t;
  
  private AnnotationWriter u;
  
  private AnnotationWriter v;
  
  private Attribute w;
  
  private int x;
  
  private ByteVector y;
  
  int z;
  
  ByteVector A;
  
  FieldWriter B;
  
  FieldWriter C;
  
  MethodWriter D;
  
  MethodWriter E;
  
  private final boolean K;
  
  private final boolean J;
  
  boolean L;
  
  public ClassWriter(int paramInt) {
    super(262144);
    this.K = ((paramInt & 0x1) != 0);
    this.J = ((paramInt & 0x2) != 0);
  }
  
  public ClassWriter(ClassReader paramClassReader, int paramInt) {
    this(paramInt);
    paramClassReader.a(this);
    this.M = paramClassReader;
  }
  
  public final void visit(int paramInt1, int paramInt2, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString) {
    this.b = paramInt1;
    this.k = paramInt2;
    this.l = newClass(paramString1);
    this.I = paramString1;
    if (paramString2 != null)
      this.m = newUTF8(paramString2); 
    this.n = (paramString3 == null) ? 0 : newClass(paramString3);
    if (paramArrayOfString != null && paramArrayOfString.length > 0) {
      this.o = paramArrayOfString.length;
      this.p = new int[this.o];
      for (byte b = 0; b < this.o; b++)
        this.p[b] = newClass(paramArrayOfString[b]); 
    } 
  }
  
  public final void visitSource(String paramString1, String paramString2) {
    if (paramString1 != null)
      this.q = newUTF8(paramString1); 
    if (paramString2 != null)
      this.r = (new ByteVector()).putUTF8(paramString2); 
  }
  
  public final void visitOuterClass(String paramString1, String paramString2, String paramString3) {
    this.s = newClass(paramString1);
    if (paramString2 != null && paramString3 != null)
      this.t = newNameType(paramString2, paramString3); 
  }
  
  public final AnnotationVisitor visitAnnotation(String paramString, boolean paramBoolean) {
    ByteVector byteVector = new ByteVector();
    byteVector.putShort(newUTF8(paramString)).putShort(0);
    AnnotationWriter annotationWriter = new AnnotationWriter(this, true, byteVector, byteVector, 2);
    if (paramBoolean) {
      annotationWriter.g = this.u;
      this.u = annotationWriter;
    } else {
      annotationWriter.g = this.v;
      this.v = annotationWriter;
    } 
    return annotationWriter;
  }
  
  public final void visitAttribute(Attribute paramAttribute) {
    paramAttribute.a = this.w;
    this.w = paramAttribute;
  }
  
  public final void visitInnerClass(String paramString1, String paramString2, String paramString3, int paramInt) {
    if (this.y == null)
      this.y = new ByteVector(); 
    this.x++;
    this.y.putShort((paramString1 == null) ? 0 : newClass(paramString1));
    this.y.putShort((paramString2 == null) ? 0 : newClass(paramString2));
    this.y.putShort((paramString3 == null) ? 0 : newUTF8(paramString3));
    this.y.putShort(paramInt);
  }
  
  public final FieldVisitor visitField(int paramInt, String paramString1, String paramString2, String paramString3, Object paramObject) {
    return new FieldWriter(this, paramInt, paramString1, paramString2, paramString3, paramObject);
  }
  
  public final MethodVisitor visitMethod(int paramInt, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString) {
    return new MethodWriter(this, paramInt, paramString1, paramString2, paramString3, paramArrayOfString, this.K, this.J);
  }
  
  public final void visitEnd() {}
  
  public byte[] toByteArray() {
    if (this.c > 32767)
      throw new RuntimeException("Class file too large!"); 
    int i = 24 + 2 * this.o;
    byte b1 = 0;
    FieldWriter fieldWriter;
    for (fieldWriter = this.B; fieldWriter != null; fieldWriter = (FieldWriter)fieldWriter.fv) {
      b1++;
      i += fieldWriter.a();
    } 
    byte b2 = 0;
    MethodWriter methodWriter;
    for (methodWriter = this.D; methodWriter != null; methodWriter = (MethodWriter)methodWriter.mv) {
      b2++;
      i += methodWriter.a();
    } 
    int j = 0;
    if (this.A != null) {
      j++;
      i += 8 + this.A.b;
      newUTF8("BootstrapMethods");
    } 
    if (this.m != 0) {
      j++;
      i += 8;
      newUTF8("Signature");
    } 
    if (this.q != 0) {
      j++;
      i += 8;
      newUTF8("SourceFile");
    } 
    if (this.r != null) {
      j++;
      i += this.r.b + 4;
      newUTF8("SourceDebugExtension");
    } 
    if (this.s != 0) {
      j++;
      i += 10;
      newUTF8("EnclosingMethod");
    } 
    if ((this.k & 0x20000) != 0) {
      j++;
      i += 6;
      newUTF8("Deprecated");
    } 
    if ((this.k & 0x1000) != 0 && ((this.b & 0xFFFF) < 49 || (this.k & 0x40000) != 0)) {
      j++;
      i += 6;
      newUTF8("Synthetic");
    } 
    if (this.y != null) {
      j++;
      i += 8 + this.y.b;
      newUTF8("InnerClasses");
    } 
    if (this.u != null) {
      j++;
      i += 8 + this.u.a();
      newUTF8("RuntimeVisibleAnnotations");
    } 
    if (this.v != null) {
      j++;
      i += 8 + this.v.a();
      newUTF8("RuntimeInvisibleAnnotations");
    } 
    if (this.w != null) {
      j += this.w.a();
      i += this.w.a(this, null, 0, -1, -1);
    } 
    i += this.d.b;
    ByteVector byteVector = new ByteVector(i);
    byteVector.putInt(-889275714).putInt(this.b);
    byteVector.putShort(this.c).putByteArray(this.d.a, 0, this.d.b);
    int k = 0x60000 | (this.k & 0x40000) / 64;
    byteVector.putShort(this.k & (k ^ 0xFFFFFFFF)).putShort(this.l).putShort(this.n);
    byteVector.putShort(this.o);
    int m;
    for (m = 0; m < this.o; m++)
      byteVector.putShort(this.p[m]); 
    byteVector.putShort(b1);
    for (fieldWriter = this.B; fieldWriter != null; fieldWriter = (FieldWriter)fieldWriter.fv)
      fieldWriter.a(byteVector); 
    byteVector.putShort(b2);
    for (methodWriter = this.D; methodWriter != null; methodWriter = (MethodWriter)methodWriter.mv)
      methodWriter.a(byteVector); 
    byteVector.putShort(j);
    if (this.A != null) {
      byteVector.putShort(newUTF8("BootstrapMethods"));
      byteVector.putInt(this.A.b + 2).putShort(this.z);
      byteVector.putByteArray(this.A.a, 0, this.A.b);
    } 
    if (this.m != 0)
      byteVector.putShort(newUTF8("Signature")).putInt(2).putShort(this.m); 
    if (this.q != 0)
      byteVector.putShort(newUTF8("SourceFile")).putInt(2).putShort(this.q); 
    if (this.r != null) {
      m = this.r.b - 2;
      byteVector.putShort(newUTF8("SourceDebugExtension")).putInt(m);
      byteVector.putByteArray(this.r.a, 2, m);
    } 
    if (this.s != 0) {
      byteVector.putShort(newUTF8("EnclosingMethod")).putInt(4);
      byteVector.putShort(this.s).putShort(this.t);
    } 
    if ((this.k & 0x20000) != 0)
      byteVector.putShort(newUTF8("Deprecated")).putInt(0); 
    if ((this.k & 0x1000) != 0 && ((this.b & 0xFFFF) < 49 || (this.k & 0x40000) != 0))
      byteVector.putShort(newUTF8("Synthetic")).putInt(0); 
    if (this.y != null) {
      byteVector.putShort(newUTF8("InnerClasses"));
      byteVector.putInt(this.y.b + 2).putShort(this.x);
      byteVector.putByteArray(this.y.a, 0, this.y.b);
    } 
    if (this.u != null) {
      byteVector.putShort(newUTF8("RuntimeVisibleAnnotations"));
      this.u.a(byteVector);
    } 
    if (this.v != null) {
      byteVector.putShort(newUTF8("RuntimeInvisibleAnnotations"));
      this.v.a(byteVector);
    } 
    if (this.w != null)
      this.w.a(this, null, 0, -1, -1, byteVector); 
    if (this.L) {
      ClassWriter classWriter = new ClassWriter(2);
      (new ClassReader(byteVector.a)).accept(classWriter, 4);
      return classWriter.toByteArray();
    } 
    return byteVector.a;
  }
  
  Item a(Object paramObject) {
    if (paramObject instanceof Integer) {
      int i = ((Integer)paramObject).intValue();
      return a(i);
    } 
    if (paramObject instanceof Byte) {
      int i = ((Byte)paramObject).intValue();
      return a(i);
    } 
    if (paramObject instanceof Character) {
      char c = ((Character)paramObject).charValue();
      return a(c);
    } 
    if (paramObject instanceof Short) {
      int i = ((Short)paramObject).intValue();
      return a(i);
    } 
    if (paramObject instanceof Boolean) {
      boolean bool = ((Boolean)paramObject).booleanValue() ? true : false;
      return a(bool);
    } 
    if (paramObject instanceof Float) {
      float f = ((Float)paramObject).floatValue();
      return a(f);
    } 
    if (paramObject instanceof Long) {
      long l = ((Long)paramObject).longValue();
      return a(l);
    } 
    if (paramObject instanceof Double) {
      double d = ((Double)paramObject).doubleValue();
      return a(d);
    } 
    if (paramObject instanceof String)
      return b((String)paramObject); 
    if (paramObject instanceof Type) {
      Type type = (Type)paramObject;
      int i = type.getSort();
      return (i == 9) ? a(type.getDescriptor()) : ((i == 10) ? a(type.getInternalName()) : c(type.getDescriptor()));
    } 
    if (paramObject instanceof Handle) {
      Handle handle = (Handle)paramObject;
      return a(handle.a, handle.b, handle.c, handle.d);
    } 
    throw new IllegalArgumentException("value " + paramObject);
  }
  
  public int newConst(Object paramObject) {
    return (a(paramObject)).a;
  }
  
  public int newUTF8(String paramString) {
    this.g.a(1, paramString, null, null);
    Item item = a(this.g);
    if (item == null) {
      this.d.putByte(1).putUTF8(paramString);
      item = new Item(this.c++, this.g);
      b(item);
    } 
    return item.a;
  }
  
  Item a(String paramString) {
    this.h.a(7, paramString, null, null);
    Item item = a(this.h);
    if (item == null) {
      this.d.b(7, newUTF8(paramString));
      item = new Item(this.c++, this.h);
      b(item);
    } 
    return item;
  }
  
  public int newClass(String paramString) {
    return (a(paramString)).a;
  }
  
  Item c(String paramString) {
    this.h.a(16, paramString, null, null);
    Item item = a(this.h);
    if (item == null) {
      this.d.b(16, newUTF8(paramString));
      item = new Item(this.c++, this.h);
      b(item);
    } 
    return item;
  }
  
  public int newMethodType(String paramString) {
    return (c(paramString)).a;
  }
  
  Item a(int paramInt, String paramString1, String paramString2, String paramString3) {
    this.j.a(20 + paramInt, paramString1, paramString2, paramString3);
    Item item = a(this.j);
    if (item == null) {
      if (paramInt <= 4) {
        b(15, paramInt, newField(paramString1, paramString2, paramString3));
      } else {
        b(15, paramInt, newMethod(paramString1, paramString2, paramString3, (paramInt == 9)));
      } 
      item = new Item(this.c++, this.j);
      b(item);
    } 
    return item;
  }
  
  public int newHandle(int paramInt, String paramString1, String paramString2, String paramString3) {
    return (a(paramInt, paramString1, paramString2, paramString3)).a;
  }
  
  Item a(String paramString1, String paramString2, Handle paramHandle, Object... paramVarArgs) {
    int n;
    ByteVector byteVector = this.A;
    if (byteVector == null)
      byteVector = this.A = new ByteVector(); 
    int i = byteVector.b;
    int j = paramHandle.hashCode();
    byteVector.putShort(newHandle(paramHandle.a, paramHandle.b, paramHandle.c, paramHandle.d));
    int k = paramVarArgs.length;
    byteVector.putShort(k);
    for (byte b = 0; b < k; b++) {
      Object object = paramVarArgs[b];
      j ^= object.hashCode();
      byteVector.putShort(newConst(object));
    } 
    byte[] arrayOfByte = byteVector.a;
    int m = 2 + k << 1;
    j &= Integer.MAX_VALUE;
    Item item = this.e[j % this.e.length];
    label33: while (item != null) {
      if (item.b != 33 || item.j != j) {
        item = item.k;
        continue;
      } 
      n = item.c;
      for (byte b1 = 0; b1 < m; b1++) {
        if (arrayOfByte[i + b1] != arrayOfByte[n + b1]) {
          item = item.k;
          continue label33;
        } 
      } 
    } 
    if (item != null) {
      n = item.a;
      byteVector.b = i;
    } else {
      n = this.z++;
      item = new Item(n);
      item.a(i, j);
      b(item);
    } 
    this.i.a(paramString1, paramString2, n);
    item = a(this.i);
    if (item == null) {
      a(18, n, newNameType(paramString1, paramString2));
      item = new Item(this.c++, this.i);
      b(item);
    } 
    return item;
  }
  
  public int newInvokeDynamic(String paramString1, String paramString2, Handle paramHandle, Object... paramVarArgs) {
    return (a(paramString1, paramString2, paramHandle, paramVarArgs)).a;
  }
  
  Item a(String paramString1, String paramString2, String paramString3) {
    this.i.a(9, paramString1, paramString2, paramString3);
    Item item = a(this.i);
    if (item == null) {
      a(9, newClass(paramString1), newNameType(paramString2, paramString3));
      item = new Item(this.c++, this.i);
      b(item);
    } 
    return item;
  }
  
  public int newField(String paramString1, String paramString2, String paramString3) {
    return (a(paramString1, paramString2, paramString3)).a;
  }
  
  Item a(String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
    byte b = paramBoolean ? 11 : 10;
    this.i.a(b, paramString1, paramString2, paramString3);
    Item item = a(this.i);
    if (item == null) {
      a(b, newClass(paramString1), newNameType(paramString2, paramString3));
      item = new Item(this.c++, this.i);
      b(item);
    } 
    return item;
  }
  
  public int newMethod(String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
    return (a(paramString1, paramString2, paramString3, paramBoolean)).a;
  }
  
  Item a(int paramInt) {
    this.g.a(paramInt);
    Item item = a(this.g);
    if (item == null) {
      this.d.putByte(3).putInt(paramInt);
      item = new Item(this.c++, this.g);
      b(item);
    } 
    return item;
  }
  
  Item a(float paramFloat) {
    this.g.a(paramFloat);
    Item item = a(this.g);
    if (item == null) {
      this.d.putByte(4).putInt(this.g.c);
      item = new Item(this.c++, this.g);
      b(item);
    } 
    return item;
  }
  
  Item a(long paramLong) {
    this.g.a(paramLong);
    Item item = a(this.g);
    if (item == null) {
      this.d.putByte(5).putLong(paramLong);
      item = new Item(this.c, this.g);
      this.c += 2;
      b(item);
    } 
    return item;
  }
  
  Item a(double paramDouble) {
    this.g.a(paramDouble);
    Item item = a(this.g);
    if (item == null) {
      this.d.putByte(6).putLong(this.g.d);
      item = new Item(this.c, this.g);
      this.c += 2;
      b(item);
    } 
    return item;
  }
  
  private Item b(String paramString) {
    this.h.a(8, paramString, null, null);
    Item item = a(this.h);
    if (item == null) {
      this.d.b(8, newUTF8(paramString));
      item = new Item(this.c++, this.h);
      b(item);
    } 
    return item;
  }
  
  public int newNameType(String paramString1, String paramString2) {
    return (a(paramString1, paramString2)).a;
  }
  
  Item a(String paramString1, String paramString2) {
    this.h.a(12, paramString1, paramString2, null);
    Item item = a(this.h);
    if (item == null) {
      a(12, newUTF8(paramString1), newUTF8(paramString2));
      item = new Item(this.c++, this.h);
      b(item);
    } 
    return item;
  }
  
  int c(String paramString) {
    this.g.a(30, paramString, null, null);
    Item item = a(this.g);
    if (item == null)
      item = c(this.g); 
    return item.a;
  }
  
  int a(String paramString, int paramInt) {
    this.g.b = 31;
    this.g.c = paramInt;
    this.g.g = paramString;
    this.g.j = Integer.MAX_VALUE & 31 + paramString.hashCode() + paramInt;
    Item item = a(this.g);
    if (item == null)
      item = c(this.g); 
    return item.a;
  }
  
  private Item c(Item paramItem) {
    this.G = (short)(this.G + 1);
    Item item = new Item(this.G, this.g);
    b(item);
    if (this.H == null)
      this.H = new Item[16]; 
    if (this.G == this.H.length) {
      Item[] arrayOfItem = new Item[2 * this.H.length];
      System.arraycopy(this.H, 0, arrayOfItem, 0, this.H.length);
      this.H = arrayOfItem;
    } 
    this.H[this.G] = item;
    return item;
  }
  
  int a(int paramInt1, int paramInt2) {
    this.h.b = 32;
    this.h.d = paramInt1 | paramInt2 << 32L;
    this.h.j = Integer.MAX_VALUE & 32 + paramInt1 + paramInt2;
    Item item = a(this.h);
    if (item == null) {
      String str1 = (this.H[paramInt1]).g;
      String str2 = (this.H[paramInt2]).g;
      this.h.c = c(getCommonSuperClass(str1, str2));
      item = new Item(0, this.h);
      b(item);
    } 
    return item.c;
  }
  
  protected String getCommonSuperClass(String paramString1, String paramString2) {
    Class clazz1;
    Class clazz2;
    ClassLoader classLoader = getClass().getClassLoader();
    try {
      clazz1 = Class.forName(paramString1.replace('/', '.'), false, classLoader);
      clazz2 = Class.forName(paramString2.replace('/', '.'), false, classLoader);
    } catch (Exception exception) {
      throw new RuntimeException(exception.toString());
    } 
    if (clazz1.isAssignableFrom(clazz2))
      return paramString1; 
    if (clazz2.isAssignableFrom(clazz1))
      return paramString2; 
    if (clazz1.isInterface() || clazz2.isInterface())
      return "java/lang/Object"; 
    while (true) {
      clazz1 = clazz1.getSuperclass();
      if (clazz1.isAssignableFrom(clazz2))
        return clazz1.getName().replace('.', '/'); 
    } 
  }
  
  private Item a(Item paramItem) {
    Item item;
    for (item = this.e[paramItem.j % this.e.length]; item != null && (item.b != paramItem.b || !paramItem.a(item)); item = item.k);
    return item;
  }
  
  private void b(Item paramItem) {
    if (this.c + this.G > this.f) {
      int j = this.e.length;
      int k = j * 2 + 1;
      Item[] arrayOfItem = new Item[k];
      for (int m = j - 1; m >= 0; m--) {
        for (Item item = this.e[m]; item != null; item = item1) {
          int n = item.j % arrayOfItem.length;
          Item item1 = item.k;
          item.k = arrayOfItem[n];
          arrayOfItem[n] = item;
        } 
      } 
      this.e = arrayOfItem;
      this.f = (int)(k * 0.75D);
    } 
    int i = paramItem.j % this.e.length;
    paramItem.k = this.e[i];
    this.e[i] = paramItem;
  }
  
  private void a(int paramInt1, int paramInt2, int paramInt3) {
    this.d.b(paramInt1, paramInt2).putShort(paramInt3);
  }
  
  private void b(int paramInt1, int paramInt2, int paramInt3) {
    this.d.a(paramInt1, paramInt2).putShort(paramInt3);
  }
  
  static {
    byte[] arrayOfByte = new byte[220];
    String str = "AAAAAAAAAAAAAAAABCLMMDDDDDEEEEEEEEEEEEEEEEEEEEAAAAAAAADDDDDEEEEEEEEEEEEEEEEEEEEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANAAAAAAAAAAAAAAAAAAAAJJJJJJJJJJJJJJJJDOPAAAAAAGGGGGGGHIFBFAAFFAARQJJKKJJJJJJJJJJJJJJJJJJ";
    for (byte b = 0; b < arrayOfByte.length; b++)
      arrayOfByte[b] = (byte)(str.charAt(b) - 65); 
    a = arrayOfByte;
  }
}
