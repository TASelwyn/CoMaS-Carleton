package org.bridj.relocated.org.objectweb.asm;

class Edge {
  int a;
  
  Label b;
  
  Edge c;
}
