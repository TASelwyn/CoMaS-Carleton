package org.bridj;

import java.util.AbstractList;
import java.util.Collection;
import java.util.RandomAccess;

class DefaultNativeList<T> extends AbstractList<T> implements NativeList<T>, RandomAccess {
  final Pointer.ListType type;
  
  final PointerIO<T> io;
  
  volatile Pointer<T> pointer;
  
  volatile long size;
  
  public Pointer<?> getPointer() {
    return this.pointer;
  }
  
  DefaultNativeList(Pointer<T> pointer, Pointer.ListType type) {
    if (pointer == null || type == null)
      throw new IllegalArgumentException("Cannot build a " + getClass().getSimpleName() + " with " + pointer + " and " + type); 
    this.io = pointer.getIO("Cannot create a list out of untyped pointer " + pointer);
    this.type = type;
    this.size = pointer.getValidElements();
    this.pointer = pointer;
  }
  
  protected void checkModifiable() {
    if (this.type == Pointer.ListType.Unmodifiable)
      throw new UnsupportedOperationException("This list is unmodifiable"); 
  }
  
  protected int safelyCastLongToInt(long i, String content) {
    if (i > 2147483647L)
      throw new RuntimeException(content + " is bigger than Java int's maximum value : " + i); 
    return (int)i;
  }
  
  public int size() {
    return safelyCastLongToInt(this.size, "Size of the native list");
  }
  
  public void clear() {
    checkModifiable();
    this.size = 0L;
  }
  
  public T get(int i) {
    if (i >= this.size || i < 0)
      throw new IndexOutOfBoundsException("Invalid index : " + i + " (list has size " + this.size + ")"); 
    return this.pointer.get(i);
  }
  
  public T set(int i, T e) {
    checkModifiable();
    if (i >= this.size || i < 0)
      throw new IndexOutOfBoundsException("Invalid index : " + i + " (list has size " + this.size + ")"); 
    T old = this.pointer.get(i);
    this.pointer.set(i, e);
    return old;
  }
  
  void add(long i, T e) {
    checkModifiable();
    if (i > this.size || i < 0L)
      throw new IndexOutOfBoundsException("Invalid index : " + i + " (list has size " + this.size + ")"); 
    requireSize(this.size + 1L);
    if (i < this.size)
      this.pointer.moveBytesAtOffsetTo(i, this.pointer, i + 1L, this.size - i); 
    this.pointer.set(i, e);
    this.size++;
  }
  
  public void add(int i, T e) {
    add(i, e);
  }
  
  protected void requireSize(long newSize) {
    if (newSize > this.pointer.getValidElements()) {
      long nextSize;
      Pointer<T> newPointer;
      switch (this.type) {
        case Dynamic:
          nextSize = (newSize < 5L) ? (newSize + 1L) : (long)(newSize * 1.6D);
          newPointer = Pointer.allocateArray(this.io, nextSize);
          this.pointer.copyTo(newPointer);
          this.pointer = newPointer;
          break;
        case FixedCapacity:
          throw new UnsupportedOperationException("This list has a fixed capacity, cannot grow its storage");
        case Unmodifiable:
          checkModifiable();
          break;
      } 
    } 
  }
  
  T remove(long i) {
    checkModifiable();
    if (i >= this.size || i < 0L)
      throw new IndexOutOfBoundsException("Invalid index : " + i + " (list has size " + this.size + ")"); 
    T old = this.pointer.get(i);
    long targetSize = this.io.getTargetSize();
    this.pointer.moveBytesAtOffsetTo((i + 1L) * targetSize, this.pointer, i * targetSize, targetSize);
    this.size--;
    return old;
  }
  
  public T remove(int i) {
    return remove(i);
  }
  
  public boolean remove(Object o) {
    checkModifiable();
    long i = indexOf(o, true, 0);
    if (i < 0L)
      return false; 
    remove(i);
    return true;
  }
  
  long indexOf(Object o, boolean last, int offset) {
    Pointer<T> pointer = this.pointer;
    assert offset >= 0 && (last || offset > 0);
    if (offset > 0)
      pointer = pointer.next(offset); 
    Pointer<T> needle = Pointer.allocate(this.io);
    needle.set((T)o);
    Pointer<T> occurrence = last ? pointer.findLast(needle) : pointer.find(needle);
    if (occurrence == null)
      return -1L; 
    return occurrence.getPeer() - pointer.getPeer();
  }
  
  public int indexOf(Object o) {
    return safelyCastLongToInt(indexOf(o, false, 0), "Index of the object");
  }
  
  public int lastIndexOf(Object o) {
    return safelyCastLongToInt(indexOf(o, true, 0), "Last index of the object");
  }
  
  public boolean contains(Object o) {
    return (indexOf(o) >= 0);
  }
  
  public boolean addAll(int i, Collection<? extends T> clctn) {
    if (i >= 0 && i < this.size)
      requireSize(this.size + clctn.size()); 
    return super.addAll(i, clctn);
  }
  
  public Object[] toArray() {
    return this.pointer.validElements(this.size).toArray();
  }
  
  public <T> T[] toArray(T[] ts) {
    return (T[])this.pointer.validElements(this.size).toArray((Object[])ts);
  }
}
