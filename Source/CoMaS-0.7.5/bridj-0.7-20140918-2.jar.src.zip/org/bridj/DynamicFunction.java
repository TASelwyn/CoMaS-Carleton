package org.bridj;

import java.lang.reflect.Method;

public abstract class DynamicFunction<R> extends Callback {
  DynamicFunctionFactory factory;
  
  Method method;
  
  public R apply(Object... args) {
    try {
      return (R)this.method.invoke(this, args);
    } catch (Throwable th) {
      th.printStackTrace();
      throw new RuntimeException("Failed to invoke callback : " + th, th);
    } 
  }
  
  public String toString() {
    return this.method.toString();
  }
}
